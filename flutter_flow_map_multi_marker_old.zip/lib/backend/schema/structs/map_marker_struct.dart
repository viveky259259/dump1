// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MapMarkerStruct extends BaseStruct {
  MapMarkerStruct({
    String? markerId,
    LatLng? location,
    MarkerImageStruct? image,
  })  : _markerId = markerId,
        _location = location,
        _image = image;

  // "markerId" field.
  String? _markerId;
  String get markerId => _markerId ?? '';
  set markerId(String? val) => _markerId = val;

  bool hasMarkerId() => _markerId != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  set location(LatLng? val) => _location = val;

  bool hasLocation() => _location != null;

  // "image" field.
  MarkerImageStruct? _image;
  MarkerImageStruct get image => _image ?? MarkerImageStruct();
  set image(MarkerImageStruct? val) => _image = val;

  void updateImage(Function(MarkerImageStruct) updateFn) {
    updateFn(_image ??= MarkerImageStruct());
  }

  bool hasImage() => _image != null;

  static MapMarkerStruct fromMap(Map<String, dynamic> data) => MapMarkerStruct(
        markerId: data['markerId'] as String?,
        location: data['location'] as LatLng?,
        image: data['image'] is MarkerImageStruct
            ? data['image']
            : MarkerImageStruct.maybeFromMap(data['image']),
      );

  static MapMarkerStruct? maybeFromMap(dynamic data) => data is Map
      ? MapMarkerStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'markerId': _markerId,
        'location': _location,
        'image': _image?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'markerId': serializeParam(
          _markerId,
          ParamType.String,
        ),
        'location': serializeParam(
          _location,
          ParamType.LatLng,
        ),
        'image': serializeParam(
          _image,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static MapMarkerStruct fromSerializableMap(Map<String, dynamic> data) =>
      MapMarkerStruct(
        markerId: deserializeParam(
          data['markerId'],
          ParamType.String,
          false,
        ),
        location: deserializeParam(
          data['location'],
          ParamType.LatLng,
          false,
        ),
        image: deserializeStructParam(
          data['image'],
          ParamType.DataStruct,
          false,
          structBuilder: MarkerImageStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'MapMarkerStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is MapMarkerStruct &&
        markerId == other.markerId &&
        location == other.location &&
        image == other.image;
  }

  @override
  int get hashCode => const ListEquality().hash([markerId, location, image]);
}

MapMarkerStruct createMapMarkerStruct({
  String? markerId,
  LatLng? location,
  MarkerImageStruct? image,
}) =>
    MapMarkerStruct(
      markerId: markerId,
      location: location,
      image: image ?? MarkerImageStruct(),
    );
