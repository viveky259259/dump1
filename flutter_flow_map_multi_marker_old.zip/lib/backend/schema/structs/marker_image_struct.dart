// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MarkerImageStruct extends BaseStruct {
  MarkerImageStruct({
    String? imagePath,
    bool? isAssetImage,
    double? size,
    Color? markerColor,
    String? infoWindowTitle,
    String? infoWindowSnippet,
  })  : _imagePath = imagePath,
        _isAssetImage = isAssetImage,
        _size = size,
        _markerColor = markerColor,
        _infoWindowTitle = infoWindowTitle,
        _infoWindowSnippet = infoWindowSnippet;

  // "imagePath" field.
  String? _imagePath;
  String get imagePath => _imagePath ?? '';
  set imagePath(String? val) => _imagePath = val;

  bool hasImagePath() => _imagePath != null;

  // "isAssetImage" field.
  bool? _isAssetImage;
  bool get isAssetImage => _isAssetImage ?? false;
  set isAssetImage(bool? val) => _isAssetImage = val;

  bool hasIsAssetImage() => _isAssetImage != null;

  // "size" field.
  double? _size;
  double get size => _size ?? 0.0;
  set size(double? val) => _size = val;

  void incrementSize(double amount) => size = size + amount;

  bool hasSize() => _size != null;

  // "MarkerColor" field.
  Color? _markerColor;
  Color? get markerColor => _markerColor;
  set markerColor(Color? val) => _markerColor = val;

  bool hasMarkerColor() => _markerColor != null;

  // "infoWindowTitle" field.
  String? _infoWindowTitle;
  String get infoWindowTitle => _infoWindowTitle ?? '';
  set infoWindowTitle(String? val) => _infoWindowTitle = val;

  bool hasInfoWindowTitle() => _infoWindowTitle != null;

  // "infoWindowSnippet" field.
  String? _infoWindowSnippet;
  String get infoWindowSnippet => _infoWindowSnippet ?? '';
  set infoWindowSnippet(String? val) => _infoWindowSnippet = val;

  bool hasInfoWindowSnippet() => _infoWindowSnippet != null;

  static MarkerImageStruct fromMap(Map<String, dynamic> data) =>
      MarkerImageStruct(
        imagePath: data['imagePath'] as String?,
        isAssetImage: data['isAssetImage'] as bool?,
        size: castToType<double>(data['size']),
        markerColor: getSchemaColor(data['MarkerColor']),
        infoWindowTitle: data['infoWindowTitle'] as String?,
        infoWindowSnippet: data['infoWindowSnippet'] as String?,
      );

  static MarkerImageStruct? maybeFromMap(dynamic data) => data is Map
      ? MarkerImageStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'imagePath': _imagePath,
        'isAssetImage': _isAssetImage,
        'size': _size,
        'MarkerColor': _markerColor,
        'infoWindowTitle': _infoWindowTitle,
        'infoWindowSnippet': _infoWindowSnippet,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'imagePath': serializeParam(
          _imagePath,
          ParamType.String,
        ),
        'isAssetImage': serializeParam(
          _isAssetImage,
          ParamType.bool,
        ),
        'size': serializeParam(
          _size,
          ParamType.double,
        ),
        'MarkerColor': serializeParam(
          _markerColor,
          ParamType.Color,
        ),
        'infoWindowTitle': serializeParam(
          _infoWindowTitle,
          ParamType.String,
        ),
        'infoWindowSnippet': serializeParam(
          _infoWindowSnippet,
          ParamType.String,
        ),
      }.withoutNulls;

  static MarkerImageStruct fromSerializableMap(Map<String, dynamic> data) =>
      MarkerImageStruct(
        imagePath: deserializeParam(
          data['imagePath'],
          ParamType.String,
          false,
        ),
        isAssetImage: deserializeParam(
          data['isAssetImage'],
          ParamType.bool,
          false,
        ),
        size: deserializeParam(
          data['size'],
          ParamType.double,
          false,
        ),
        markerColor: deserializeParam(
          data['MarkerColor'],
          ParamType.Color,
          false,
        ),
        infoWindowTitle: deserializeParam(
          data['infoWindowTitle'],
          ParamType.String,
          false,
        ),
        infoWindowSnippet: deserializeParam(
          data['infoWindowSnippet'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'MarkerImageStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is MarkerImageStruct &&
        imagePath == other.imagePath &&
        isAssetImage == other.isAssetImage &&
        size == other.size &&
        markerColor == other.markerColor &&
        infoWindowTitle == other.infoWindowTitle &&
        infoWindowSnippet == other.infoWindowSnippet;
  }

  @override
  int get hashCode => const ListEquality().hash([
        imagePath,
        isAssetImage,
        size,
        markerColor,
        infoWindowTitle,
        infoWindowSnippet
      ]);
}

MarkerImageStruct createMarkerImageStruct({
  String? imagePath,
  bool? isAssetImage,
  double? size,
  Color? markerColor,
  String? infoWindowTitle,
  String? infoWindowSnippet,
}) =>
    MarkerImageStruct(
      imagePath: imagePath,
      isAssetImage: isAssetImage,
      size: size,
      markerColor: markerColor,
      infoWindowTitle: infoWindowTitle,
      infoWindowSnippet: infoWindowSnippet,
    );
