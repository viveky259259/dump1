// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom widgets

import 'index.dart'; // Imports other custom widgets

import 'index.dart'; // Imports other custom widgets

import 'index.dart'; // Imports other custom widgets

import 'index.dart'; // Imports other custom widgets

import 'dart:async';

import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as gmap;
import 'package:flutter/scheduler.dart';
import '/custom_code/map_helper.dart';

class FlutterFlowMapMultiMarker extends StatefulWidget {
  const FlutterFlowMapMultiMarker({
    super.key,
    this.width,
    this.height,
    required this.mapHelper,
    required this.onCameraIdle,
    required this.initialLocation,
    required this.markers,
    required this.style,
    required this.initialZoom,
    this.allowInteraction = true,
    this.allowZoom = true,
    this.showZoomControls = true,
    this.showLocation = true,
    this.showCompass = false,
    this.showMapToolbar = false,
    this.showTraffic = false,
    this.centerMapOnMarkerTap = false,
    this.mapTakesGesturePreference = false,
    this.onMapTap,
  });

  final double? width;
  final double? height;
  final GoogleMapHelper mapHelper;
  final Future Function(LatLng latlng) onCameraIdle;
  final LatLng initialLocation;
  final List<MapMarkerStruct> markers;
  final GoogleMapStyle style;
  final double initialZoom;
  final bool? allowInteraction;
  final bool? allowZoom;
  final bool? showZoomControls;
  final bool? showLocation;
  final bool? showCompass;
  final bool? showMapToolbar;
  final bool? showTraffic;
  final bool? centerMapOnMarkerTap;
  final bool? mapTakesGesturePreference;
  final Future Function(LatLng latlng)? onMapTap;

  @override
  State<StatefulWidget> createState() => _FlutterFlowGoogleMapState();
}

class _FlutterFlowGoogleMapState extends State<FlutterFlowMapMultiMarker> {
  double get initialZoom => max(double.minPositive, widget.initialZoom);
  LatLng get initialPosition =>
      widget.initialLocation ?? const LatLng(0.0, 0.0);

  gmap.BitmapDescriptor? _markerDescriptor;
  late LatLng currentMapCenter;
  // Cache for marker bitmap descriptors to avoid redundant image loading
  final Map<String, gmap.BitmapDescriptor> _markerDescriptorCache = {};
  void onCameraIdle() => widget.onCameraIdle?.call(currentMapCenter.toLatLng());

  /// Initialize bitmap descriptors for all unique marker images
  Future<void> initializeMarkerBitmaps() async {
    if (!mounted) return;

    final uniqueMarkerImages = <String, MarkerImageStruct>{};
    // Collect unique marker configurations
    for (final marker in widget.markers) {
      final markerImage = marker.image;

      final key =
          '${markerImage.imagePath}_${markerImage.size}_${markerImage.isAssetImage}';
      uniqueMarkerImages[key] = MarkerImageStruct(
          imagePath: markerImage.imagePath,
          isAssetImage: markerImage.isAssetImage,
          size: markerImage.size);
    }

    // Initialize image-based markers (asynchronous)
    if (uniqueMarkerImages.isNotEmpty) {
      SchedulerBinding.instance.addPostFrameCallback((_) async {
        for (final entry in uniqueMarkerImages.entries) {
          if (!mounted) return;

          final key = entry.key;
          final markerImage = entry.value;

          if (_markerDescriptorCache.containsKey(key)) continue;

          try {
            final descriptor = await _createBitmapDescriptor(markerImage);
            if (mounted && descriptor != null) {
              _markerDescriptorCache[key] = descriptor;
              setState(() {});
            }
          } catch (e) {
            debugPrint('Error loading marker image: $e');
          }
        }
      });
    }
  }

  /// Create a bitmap descriptor from a marker image
  Future<gmap.BitmapDescriptor?> _createBitmapDescriptor(
      MarkerImageStruct markerImage) async {
    if (!mounted) return null;

    try {
      final markerImageSize = Size.square(markerImage.size);
      var imageProvider = markerImage.isAssetImage
          ? Image.asset(markerImage.imagePath).image
          : CachedNetworkImageProvider(markerImage.imagePath);

      if (!kIsWeb) {
        // workaround for https://github.com/flutter/flutter/issues/34657
        final targetHeight =
            (markerImage.size * MediaQuery.of(context).devicePixelRatio)
                .toInt();
        imageProvider = ResizeImage(
          imageProvider,
          height: targetHeight,
          policy: ResizeImagePolicy.fit,
          allowUpscaling: true,
        );
      }

      final imageConfiguration =
          createLocalImageConfiguration(context, size: markerImageSize);

      final completer = Completer<gmap.BitmapDescriptor?>();

      imageProvider.resolve(imageConfiguration).addListener(
            ImageStreamListener((img, _) async {
              try {
                final bytes =
                    await img.image.toByteData(format: ImageByteFormat.png);
                if (bytes != null && mounted) {
                  final descriptor = gmap.BitmapDescriptor.fromBytes(
                    bytes.buffer.asUint8List(),
                    size: markerImageSize,
                  );
                  completer.complete(descriptor);
                } else {
                  completer.complete(null);
                }
              } catch (e) {
                completer.completeError(e);
              }
            }, onError: (error, stackTrace) {
              completer.completeError(error);
            }),
          );

      return completer.future;
    } catch (e) {
      debugPrint('Error creating bitmap descriptor: $e');
      return null;
    }
  }

  /// Get the cached bitmap descriptor for a marker
  gmap.BitmapDescriptor? _getMarkerDescriptor(MapMarkerStruct marker) {
    final markerImage = marker.image;
    final key =
        '${markerImage.imagePath}_${markerImage.size}_${markerImage.isAssetImage}';
    return _markerDescriptorCache[key];
  }

  @override
  void initState() {
    super.initState();
    currentMapCenter = initialPosition;
    initializeMarkerBitmaps();
  }

  @override
  void didUpdateWidget(FlutterFlowMapMultiMarker oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Rebuild marker bitmaps if markers change
    if (widget.markers != oldWidget.markers) {
      initializeMarkerBitmaps();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Build markers with individual icons
    final markers = widget.markers
        .map((m) {
          final descriptor = _getMarkerDescriptor(m);

          // Skip markers whose descriptors haven't loaded yet
          if (descriptor == null) return null;

          return gmap.Marker(
            markerId: gmap.MarkerId(m.markerId),
            position: m.location?.toGoogleMaps() ?? const gmap.LatLng(0.0, 0.0),
            icon: descriptor,
            infoWindow: gmap.InfoWindow(
              title: m.image.infoWindowTitle,
              snippet: m.image.infoWindowSnippet,
            ),
            onTap: () async {
              if (widget.centerMapOnMarkerTap != null &&
                  widget.centerMapOnMarkerTap!) {
                await widget.mapHelper.controller.animateCamera(
                  gmap.CameraUpdate.newLatLng(m.location?.toGoogleMaps() ??
                      const gmap.LatLng(0.0, 0.0)),
                );
                currentMapCenter =
                    m.location?.toLatLng() ?? const LatLng(0.0, 0.0);
                onCameraIdle();
              }
              // await m.onTap?.call();
            },
          );
        })
        .whereType<gmap.Marker>()
        .toSet();

    final mapHasGesturePreference =
        (widget.mapTakesGesturePreference ?? false) &&
            (widget.allowInteraction ?? false) &&
            (widget.allowZoom ?? false);

    final googleMapWidget = AbsorbPointer(
      absorbing: !(widget.allowInteraction ?? false),
      child: gmap.GoogleMap(
        onMapCreated: (controller) async {
          widget.mapHelper.controller = controller;
          await controller.setMapStyle(googleMapStyleStrings[widget.style]);
        },
        onTap: (latlng) async {
          await widget.onMapTap?.call(latlng.toLocalLatLng());
        },
        onCameraIdle: onCameraIdle,
        onCameraMove: (position) =>
            currentMapCenter = position.target.toLocalLatLng(),
        initialCameraPosition: gmap.CameraPosition(
          target: initialPosition.toGoogleMaps(),
          zoom: initialZoom,
        ),
        mapType: gmap.MapType.normal,
        zoomGesturesEnabled: widget.allowZoom ?? false,
        zoomControlsEnabled: widget.showZoomControls ?? false,
        myLocationEnabled: widget.showLocation ?? false,
        compassEnabled: widget.showCompass ?? false,
        mapToolbarEnabled: widget.showMapToolbar ?? false,
        trafficEnabled: widget.showTraffic ?? false,
        markers: markers,
        gestureRecognizers: {
          if (mapHasGesturePreference)
            const Factory<OneSequenceGestureRecognizer>(
              EagerGestureRecognizer.new,
            ),
        },
        webGestureHandling: mapHasGesturePreference
            ? gmap.WebGestureHandling.cooperative
            : null,
      ),
    );

    return Container(
      width: widget.width,
      height: widget.height,
      child: mapHasGesturePreference
          ? GestureDetector(
              onVerticalDragStart: (_) {},
              behavior: HitTestBehavior.opaque,
              child: googleMapWidget,
            )
          : googleMapWidget,
    );
  }
}

extension ToGoogleMapsLatLng on LatLng {
  gmap.LatLng toGoogleMaps() => gmap.LatLng(latitude, longitude);
  LatLng toLatLng() => LatLng(latitude, longitude);
}

extension GoogleMapsToLatLng on gmap.LatLng {
  LatLng toLocalLatLng() => LatLng(latitude, longitude);
}

Map<GoogleMapStyle, String> googleMapStyleStrings = {
  GoogleMapStyle.standard: '[]',
  GoogleMapStyle.silver:
      r'[{"elementType":"geometry","stylers":[{"color":"#f5f5f5"}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"elementType":"labels.text.fill","stylers":[{"color":"#616161"}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#f5f5f5"}]},{"featureType":"administrative.land_parcel","elementType":"labels.text.fill","stylers":[{"color":"#bdbdbd"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#eeeeee"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#e5e5e5"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"color":"#9e9e9e"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#ffffff"}]},{"featureType":"road.arterial","elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#dadada"}]},{"featureType":"road.highway","elementType":"labels.text.fill","stylers":[{"color":"#616161"}]},{"featureType":"road.local","elementType":"labels.text.fill","stylers":[{"color":"#9e9e9e"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"color":"#e5e5e5"}]},{"featureType":"transit.station","elementType":"geometry","stylers":[{"color":"#eeeeee"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#c9c9c9"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#9e9e9e"}]}]',
  GoogleMapStyle.retro:
      r'[{"elementType":"geometry","stylers":[{"color":"#ebe3cd"}]},{"elementType":"labels.text.fill","stylers":[{"color":"#523735"}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#f5f1e6"}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#c9b2a6"}]},{"featureType":"administrative.land_parcel","elementType":"geometry.stroke","stylers":[{"color":"#dcd2be"}]},{"featureType":"administrative.land_parcel","elementType":"labels.text.fill","stylers":[{"color":"#ae9e90"}]},{"featureType":"landscape.natural","elementType":"geometry","stylers":[{"color":"#dfd2ae"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#dfd2ae"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#93817c"}]},{"featureType":"poi.park","elementType":"geometry.fill","stylers":[{"color":"#a5b076"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"color":"#447530"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#f5f1e6"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#fdfcf8"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#f8c967"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#e9bc62"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry","stylers":[{"color":"#e98d58"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry.stroke","stylers":[{"color":"#db8555"}]},{"featureType":"road.local","elementType":"labels.text.fill","stylers":[{"color":"#806b63"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"color":"#dfd2ae"}]},{"featureType":"transit.line","elementType":"labels.text.fill","stylers":[{"color":"#8f7d77"}]},{"featureType":"transit.line","elementType":"labels.text.stroke","stylers":[{"color":"#ebe3cd"}]},{"featureType":"transit.station","elementType":"geometry","stylers":[{"color":"#dfd2ae"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#b9d3c2"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#92998d"}]}]',
  GoogleMapStyle.dark:
      r'[{"elementType":"geometry","stylers":[{"color":"#212121"}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#212121"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"color":"#757575"}]},{"featureType":"administrative.country","elementType":"labels.text.fill","stylers":[{"color":"#9e9e9e"}]},{"featureType":"administrative.land_parcel","stylers":[{"visibility":"off"}]},{"featureType":"administrative.locality","elementType":"labels.text.fill","stylers":[{"color":"#bdbdbd"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#181818"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"color":"#616161"}]},{"featureType":"poi.park","elementType":"labels.text.stroke","stylers":[{"color":"#1b1b1b"}]},{"featureType":"road","elementType":"geometry.fill","stylers":[{"color":"#2c2c2c"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#8a8a8a"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#373737"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#3c3c3c"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry","stylers":[{"color":"#4e4e4e"}]},{"featureType":"road.local","elementType":"labels.text.fill","stylers":[{"color":"#616161"}]},{"featureType":"transit","elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#3d3d3d"}]}]',
  GoogleMapStyle.night:
      r'[{"elementType":"geometry","stylers":[{"color":"#242f3e"}]},{"elementType":"labels.text.fill","stylers":[{"color":"#746855"}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#242f3e"}]},{"featureType":"administrative.locality","elementType":"labels.text.fill","stylers":[{"color":"#d59563"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#d59563"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#263c3f"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"color":"#6b9a76"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#38414e"}]},{"featureType":"road","elementType":"geometry.stroke","stylers":[{"color":"#212a37"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#9ca5b3"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#746855"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#1f2835"}]},{"featureType":"road.highway","elementType":"labels.text.fill","stylers":[{"color":"#f3d19c"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#2f3948"}]},{"featureType":"transit.station","elementType":"labels.text.fill","stylers":[{"color":"#d59563"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#17263c"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#515c6d"}]},{"featureType":"water","elementType":"labels.text.stroke","stylers":[{"color":"#17263c"}]}]',
  GoogleMapStyle.aubergine:
      r'[{"elementType":"geometry","stylers":[{"color":"#1d2c4d"}]},{"elementType":"labels.text.fill","stylers":[{"color":"#8ec3b9"}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#1a3646"}]},{"featureType":"administrative.country","elementType":"geometry.stroke","stylers":[{"color":"#4b6878"}]},{"featureType":"administrative.land_parcel","elementType":"labels.text.fill","stylers":[{"color":"#64779e"}]},{"featureType":"administrative.province","elementType":"geometry.stroke","stylers":[{"color":"#4b6878"}]},{"featureType":"landscape.man_made","elementType":"geometry.stroke","stylers":[{"color":"#334e87"}]},{"featureType":"landscape.natural","elementType":"geometry","stylers":[{"color":"#023e58"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#283d6a"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#6f9ba5"}]},{"featureType":"poi","elementType":"labels.text.stroke","stylers":[{"color":"#1d2c4d"}]},{"featureType":"poi.park","elementType":"geometry.fill","stylers":[{"color":"#023e58"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"color":"#3C7680"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#304a7d"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#98a5be"}]},{"featureType":"road","elementType":"labels.text.stroke","stylers":[{"color":"#1d2c4d"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#2c6675"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#255763"}]},{"featureType":"road.highway","elementType":"labels.text.fill","stylers":[{"color":"#b0d5ce"}]},{"featureType":"road.highway","elementType":"labels.text.stroke","stylers":[{"color":"#023e58"}]},{"featureType":"transit","elementType":"labels.text.fill","stylers":[{"color":"#98a5be"}]},{"featureType":"transit","elementType":"labels.text.stroke","stylers":[{"color":"#1d2c4d"}]},{"featureType":"transit.line","elementType":"geometry.fill","stylers":[{"color":"#283d6a"}]},{"featureType":"transit.station","elementType":"geometry","stylers":[{"color":"#3a4762"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#0e1626"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#4e6d70"}]}]',
};
