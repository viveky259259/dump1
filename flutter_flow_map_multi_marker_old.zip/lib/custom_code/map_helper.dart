import 'package:google_maps_flutter/google_maps_flutter.dart' as gmap;
import '/backend/schema/structs/index.dart';
import '/flutter_flow/lat_lng.dart';

class GoogleMapHelper {
  late final gmap.GoogleMapController _controller;
  bool hasControllerAssigned = false;

  gmap.GoogleMapController get controller => _controller;

  set controller(gmap.GoogleMapController value) {
    _controller = value;
    hasControllerAssigned = true;
  }

  void animate(LatLng latlng) {
    print(latlng);
    _controller
        .animateCamera(gmap.CameraUpdate.newCameraPosition(gmap.CameraPosition(
      bearing: 192.8334901395799,
      target: gmap.LatLng(latlng.latitude, latlng.longitude),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414,
    )));
  }

  Future<void> showAllMarkers(List<MapMarkerStruct> markers) async {
    if (markers.isEmpty) {
      return;
    }

    if (markers.length == 1 && markers.first.location != null) {
      final marker = markers.first;

      animate(marker.location!);
      return;
    }

    double minLat = markers.first.location!.latitude;
    double maxLat = markers.first.location!.latitude;
    double minLng = markers.first.location!.longitude;
    double maxLng = markers.first.location!.longitude;

    for (final marker in markers) {
      if (marker.location != null) {
        if (marker.location!.latitude < minLat)
          minLat = marker.location!.latitude;
        if (marker.location!.latitude > maxLat)
          maxLat = marker.location!.latitude;
        if (marker.location!.longitude < minLng)
          minLng = marker.location!.longitude;
        if (marker.location!.longitude > maxLng)
          maxLng = marker.location!.longitude;
      }
    }

    final bounds = gmap.LatLngBounds(
      southwest: gmap.LatLng(minLat, minLng),
      northeast: gmap.LatLng(maxLat, maxLng),
    );

    _controller.animateCamera(gmap.CameraUpdate.newLatLngBounds(
      bounds,
      50,
    ));
  }
}
