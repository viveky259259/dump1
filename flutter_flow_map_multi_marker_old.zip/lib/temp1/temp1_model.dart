import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'temp1_widget.dart' show Temp1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Temp1Model extends FlutterFlowModel<Temp1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
