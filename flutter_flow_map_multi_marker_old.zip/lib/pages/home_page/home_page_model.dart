import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/map_helper.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/flutter_flow/custom_functions.dart' as functions;
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  GoogleMapHelper? mapHelper;

  LatLng? initialLocation;

  List<MapMarkerStruct> markers = [];
  void addToMarkers(MapMarkerStruct item) => markers.add(item);
  void removeFromMarkers(MapMarkerStruct item) => markers.remove(item);
  void removeAtIndexFromMarkers(int index) => markers.removeAt(index);
  void insertAtIndexInMarkers(int index, MapMarkerStruct item) =>
      markers.insert(index, item);
  void updateMarkersAtIndex(int index, Function(MapMarkerStruct) updateFn) =>
      markers[index] = updateFn(markers[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
