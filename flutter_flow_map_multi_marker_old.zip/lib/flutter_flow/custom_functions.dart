import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';

List<MapMarkerStruct> getMarkers() {
  List<MapMarkerStruct> markers = [];
  for (int i = 0; i < 6; i++) {
    markers.add(createMapMarkerStruct(
      markerId: 'marker_$i',
      location: LatLng(22.3948488 - i * 0.001, 72.5995644 - i * 0.001),
      image: createMarkerImageStruct(
        imagePath: 'assets/images/location$i.png',
        isAssetImage: true,
        size: 50.0,
        markerColor: Colors.red,
        infoWindowTitle: 'Marker $i',
        infoWindowSnippet: 'This is marker number $i',
      ),
    ));
  }
  return markers;
}
