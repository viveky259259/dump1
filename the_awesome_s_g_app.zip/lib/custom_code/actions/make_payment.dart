// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<String> makePayment(
  String orderId,
  String userToken,
) async {
  // Add your function code here!

  final paymentId = await _makePaymentToUpi(orderId, userToken);
  return paymentId;
}

Future<String> _makePaymentToUpi(String orderId, String userToken) async {
  print("Initiating payment services");

  /// Returning a simulated payment response until I generate sufficient revenue to cover real transactions.
  return 'PayId_12345';
}
