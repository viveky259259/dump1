import '/backend/gemini/gemini.dart';
import '/components/gemini_chat_message_widget.dart';
import '/components/user_message_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'gemini_page_widget.dart' show GeminiPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GeminiPageModel extends FlutterFlowModel<GeminiPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for UserMessage component.
  late UserMessageModel userMessageModel;
  // Model for GeminiChatMessage component.
  late GeminiChatMessageModel geminiChatMessageModel;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Gemini - Generate Text] action in Icon widget.
  String? modelResponse;

  @override
  void initState(BuildContext context) {
    userMessageModel = createModel(context, () => UserMessageModel());
    geminiChatMessageModel =
        createModel(context, () => GeminiChatMessageModel());
  }

  @override
  void dispose() {
    userMessageModel.dispose();
    geminiChatMessageModel.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
