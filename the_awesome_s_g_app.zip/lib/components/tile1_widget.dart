import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'tile1_model.dart';
export 'tile1_model.dart';

class Tile1Widget extends StatefulWidget {
  const Tile1Widget({
    super.key,
    required this.title,
    required this.imagePath,
  });

  final String? title;
  final String? imagePath;

  @override
  State<Tile1Widget> createState() => _Tile1WidgetState();
}

class _Tile1WidgetState extends State<Tile1Widget> {
  late Tile1Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Tile1Model());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Container(
          width: 60.0,
          height: 60.0,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            shape: BoxShape.circle,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(60.0),
            child: Image.network(
              widget!.imagePath!,
              width: 60.0,
              height: 60.0,
              fit: BoxFit.cover,
            ),
          ),
        ),
        Text(
          valueOrDefault<String>(
            widget!.title,
            'N/a',
          ),
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Inter',
                fontSize: 12.0,
                letterSpacing: 0.0,
                fontWeight: FontWeight.w500,
              ),
        ),
      ].divide(SizedBox(height: 8.0)),
    );
  }
}
