import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'user_message_widget.dart' show UserMessageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class UserMessageModel extends FlutterFlowModel<UserMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
