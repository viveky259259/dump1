import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'gemini_chat_message_widget.dart' show GeminiChatMessageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GeminiChatMessageModel extends FlutterFlowModel<GeminiChatMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
