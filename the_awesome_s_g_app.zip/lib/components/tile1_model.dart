import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'tile1_widget.dart' show Tile1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Tile1Model extends FlutterFlowModel<Tile1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
