// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/product_list/product_list_widget.dart' show ProductListWidget;
export '/pages/product_description/product_description_widget.dart'
    show ProductDescriptionWidget;
export '/gemini_page/gemini_page_widget.dart' show GeminiPageWidget;
