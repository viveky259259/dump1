// Stub class

class Calculator {
  int addOne(int value){
    print('from stub');
    return -1;
  }
}