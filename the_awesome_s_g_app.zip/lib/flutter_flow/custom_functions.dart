import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';

double offeredPrice(
  double currentPrice,
  double discountPercentage,
) {
  if (discountPercentage < 0 || discountPercentage > 100) {
    return currentPrice;
  }

  double discountAmount = (currentPrice * discountPercentage) / 100;
  return currentPrice - discountAmount;
}
