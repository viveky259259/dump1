import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/components/product_item_widget.dart';
import '/components/tile1_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'product_list_widget.dart' show ProductListWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProductListModel extends FlutterFlowModel<ProductListWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Products)] action in ProductList widget.
  ApiCallResponse? apiResultjbb;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Model for tile1 component.
  late Tile1Model tile1Model1;
  // Model for tile1 component.
  late Tile1Model tile1Model2;
  // Model for tile1 component.
  late Tile1Model tile1Model3;
  // Model for tile1 component.
  late Tile1Model tile1Model4;
  // Model for tile1 component.
  late Tile1Model tile1Model5;
  // Model for ProductItem component.
  late ProductItemModel productItemModel;

  @override
  void initState(BuildContext context) {
    tile1Model1 = createModel(context, () => Tile1Model());
    tile1Model2 = createModel(context, () => Tile1Model());
    tile1Model3 = createModel(context, () => Tile1Model());
    tile1Model4 = createModel(context, () => Tile1Model());
    tile1Model5 = createModel(context, () => Tile1Model());
    productItemModel = createModel(context, () => ProductItemModel());
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();

    tile1Model1.dispose();
    tile1Model2.dispose();
    tile1Model3.dispose();
    tile1Model4.dispose();
    tile1Model5.dispose();
    productItemModel.dispose();
  }
}
