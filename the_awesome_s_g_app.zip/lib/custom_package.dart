export   'calc_stub.dart' if(isLocal) 'package:encryption/encryption.dart';
const bool isLocal = true;