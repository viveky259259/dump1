// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProductItemStruct extends BaseStruct {
  ProductItemStruct({
    int? id,
    String? title,
    double? price,
    String? description,
    String? category,
    RatingStruct? rating,
    String? image,
  })  : _id = id,
        _title = title,
        _price = price,
        _description = description,
        _category = category,
        _rating = rating,
        _image = image;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  set price(double? val) => _price = val;

  void incrementPrice(double amount) => price = price + amount;

  bool hasPrice() => _price != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  set description(String? val) => _description = val;

  bool hasDescription() => _description != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  set category(String? val) => _category = val;

  bool hasCategory() => _category != null;

  // "rating" field.
  RatingStruct? _rating;
  RatingStruct get rating => _rating ?? RatingStruct();
  set rating(RatingStruct? val) => _rating = val;

  void updateRating(Function(RatingStruct) updateFn) {
    updateFn(_rating ??= RatingStruct());
  }

  bool hasRating() => _rating != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;

  bool hasImage() => _image != null;

  static ProductItemStruct fromMap(Map<String, dynamic> data) =>
      ProductItemStruct(
        id: castToType<int>(data['id']),
        title: data['title'] as String?,
        price: castToType<double>(data['price']),
        description: data['description'] as String?,
        category: data['category'] as String?,
        rating: data['rating'] is RatingStruct
            ? data['rating']
            : RatingStruct.maybeFromMap(data['rating']),
        image: data['image'] as String?,
      );

  static ProductItemStruct? maybeFromMap(dynamic data) => data is Map
      ? ProductItemStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'title': _title,
        'price': _price,
        'description': _description,
        'category': _category,
        'rating': _rating?.toMap(),
        'image': _image,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'price': serializeParam(
          _price,
          ParamType.double,
        ),
        'description': serializeParam(
          _description,
          ParamType.String,
        ),
        'category': serializeParam(
          _category,
          ParamType.String,
        ),
        'rating': serializeParam(
          _rating,
          ParamType.DataStruct,
        ),
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
      }.withoutNulls;

  static ProductItemStruct fromSerializableMap(Map<String, dynamic> data) =>
      ProductItemStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        price: deserializeParam(
          data['price'],
          ParamType.double,
          false,
        ),
        description: deserializeParam(
          data['description'],
          ParamType.String,
          false,
        ),
        category: deserializeParam(
          data['category'],
          ParamType.String,
          false,
        ),
        rating: deserializeStructParam(
          data['rating'],
          ParamType.DataStruct,
          false,
          structBuilder: RatingStruct.fromSerializableMap,
        ),
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'ProductItemStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ProductItemStruct &&
        id == other.id &&
        title == other.title &&
        price == other.price &&
        description == other.description &&
        category == other.category &&
        rating == other.rating &&
        image == other.image;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([id, title, price, description, category, rating, image]);
}

ProductItemStruct createProductItemStruct({
  int? id,
  String? title,
  double? price,
  String? description,
  String? category,
  RatingStruct? rating,
  String? image,
}) =>
    ProductItemStruct(
      id: id,
      title: title,
      price: price,
      description: description,
      category: category,
      rating: rating ?? RatingStruct(),
      image: image,
    );
