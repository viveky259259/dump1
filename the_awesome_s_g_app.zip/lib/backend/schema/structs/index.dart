export '/backend/schema/util/schema_util.dart';

export 'category_item_struct.dart';
export 'product_item_struct.dart';
export 'professor_struct.dart';
export 'rating_struct.dart';
