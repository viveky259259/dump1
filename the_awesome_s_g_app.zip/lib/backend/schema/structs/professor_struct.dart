// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProfessorStruct extends BaseStruct {
  ProfessorStruct({
    int? id,
    List<String>? modules,
  })  : _id = id,
        _modules = modules;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "modules" field.
  List<String>? _modules;
  List<String> get modules => _modules ?? const [];
  set modules(List<String>? val) => _modules = val;

  void updateModules(Function(List<String>) updateFn) {
    updateFn(_modules ??= []);
  }

  bool hasModules() => _modules != null;

  static ProfessorStruct fromMap(Map<String, dynamic> data) => ProfessorStruct(
        id: castToType<int>(data['id']),
        modules: getDataList(data['modules']),
      );

  static ProfessorStruct? maybeFromMap(dynamic data) => data is Map
      ? ProfessorStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'modules': _modules,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'modules': serializeParam(
          _modules,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static ProfessorStruct fromSerializableMap(Map<String, dynamic> data) =>
      ProfessorStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        modules: deserializeParam<String>(
          data['modules'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'ProfessorStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is ProfessorStruct &&
        id == other.id &&
        listEquality.equals(modules, other.modules);
  }

  @override
  int get hashCode => const ListEquality().hash([id, modules]);
}

ProfessorStruct createProfessorStruct({
  int? id,
}) =>
    ProfessorStruct(
      id: id,
    );
