// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RatingStruct extends BaseStruct {
  RatingStruct({
    double? rate,
    int? count,
  })  : _rate = rate,
        _count = count;

  // "rate" field.
  double? _rate;
  double get rate => _rate ?? 0.0;
  set rate(double? val) => _rate = val;

  void incrementRate(double amount) => rate = rate + amount;

  bool hasRate() => _rate != null;

  // "count" field.
  int? _count;
  int get count => _count ?? 0;
  set count(int? val) => _count = val;

  void incrementCount(int amount) => count = count + amount;

  bool hasCount() => _count != null;

  static RatingStruct fromMap(Map<String, dynamic> data) => RatingStruct(
        rate: castToType<double>(data['rate']),
        count: castToType<int>(data['count']),
      );

  static RatingStruct? maybeFromMap(dynamic data) =>
      data is Map ? RatingStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'rate': _rate,
        'count': _count,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'rate': serializeParam(
          _rate,
          ParamType.double,
        ),
        'count': serializeParam(
          _count,
          ParamType.int,
        ),
      }.withoutNulls;

  static RatingStruct fromSerializableMap(Map<String, dynamic> data) =>
      RatingStruct(
        rate: deserializeParam(
          data['rate'],
          ParamType.double,
          false,
        ),
        count: deserializeParam(
          data['count'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'RatingStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is RatingStruct && rate == other.rate && count == other.count;
  }

  @override
  int get hashCode => const ListEquality().hash([rate, count]);
}

RatingStruct createRatingStruct({
  double? rate,
  int? count,
}) =>
    RatingStruct(
      rate: rate,
      count: count,
    );
