// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CategoryItemStruct extends BaseStruct {
  CategoryItemStruct({
    String? category,
    String? image,
  })  : _category = category,
        _image = image;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  set category(String? val) => _category = val;

  bool hasCategory() => _category != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;

  bool hasImage() => _image != null;

  static CategoryItemStruct fromMap(Map<String, dynamic> data) =>
      CategoryItemStruct(
        category: data['category'] as String?,
        image: data['image'] as String?,
      );

  static CategoryItemStruct? maybeFromMap(dynamic data) => data is Map
      ? CategoryItemStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'category': _category,
        'image': _image,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'category': serializeParam(
          _category,
          ParamType.String,
        ),
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
      }.withoutNulls;

  static CategoryItemStruct fromSerializableMap(Map<String, dynamic> data) =>
      CategoryItemStruct(
        category: deserializeParam(
          data['category'],
          ParamType.String,
          false,
        ),
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'CategoryItemStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is CategoryItemStruct &&
        category == other.category &&
        image == other.image;
  }

  @override
  int get hashCode => const ListEquality().hash([category, image]);
}

CategoryItemStruct createCategoryItemStruct({
  String? category,
  String? image,
}) =>
    CategoryItemStruct(
      category: category,
      image: image,
    );
