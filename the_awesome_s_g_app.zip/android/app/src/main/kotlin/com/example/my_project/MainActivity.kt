package com.mycompany.theawesomesgapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
