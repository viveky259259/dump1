// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:html' as html;
import 'dart:ui_web' as ui;
import 'dart:convert';

class QuillEditor extends StatefulWidget {
  QuillEditor(
      {super.key,
      this.width,
      this.height,
      this.onMessageReceived,
      this.realOnly = false,
      this.htmlString});

  final double? width;
  final double? height;
  final Future Function(String? message)? onMessageReceived;
  final bool? realOnly;
  final String? htmlString;

  @override
  State<QuillEditor> createState() => _QuillEditorState();
}

class _QuillEditorState extends State<QuillEditor> {
  html.IFrameElement? _iframe;
  static int _viewIdCounter = 0;
  late int _viewId;
  bool _hasInitializedContent = false;

  @override
  void initState() {
    print('QuillEditor.initState() called');
    super.initState();
    _viewId = ++_viewIdCounter;
    print('QuillEditor.initState() - viewId: $_viewId');
    _registerViewFactory();
  }

  void _registerViewFactory() {
    print('QuillEditor._registerViewFactory() called for viewId: $_viewId');
    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory('inline-html-$_viewId',
        (int viewId) {
      print('QuillEditor._registerViewFactory() - creating iframe');
      _iframe = html.IFrameElement()
        ..src = '/test_quill.html'
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%';

      // Listen for iframe load event
      _iframe!.onLoad.listen((_) {
        print('QuillEditor._registerViewFactory() - iframe loaded');
        // Insert initial content only once when iframe is loaded
        if (!_hasInitializedContent &&
            widget.htmlString != null &&
            widget.htmlString!.isNotEmpty) {
          _hasInitializedContent = true;
          print('QuillEditor._registerViewFactory() - setting initial content');
          // Small delay to ensure iframe is fully ready
          Future.delayed(const Duration(milliseconds: 100), () {
            // Check if the htmlString is Delta JSON or HTML
            try {
              final parsed = jsonDecode(widget.htmlString!);
              print(
                  'QuillEditor._registerViewFactory() - parsed as Delta JSON');
              // If it's valid JSON, assume it's Delta format
              setContents(parsed);
            } catch (e) {
              print('QuillEditor._registerViewFactory() - treating as HTML');
              // If not JSON, treat as HTML and set it
              setHTML(widget.htmlString!);
            }
          });
        }
      });

      // Listen for messages from the iframe
      html.window.addEventListener('message', (event) {
        final messageEvent = event as html.MessageEvent;

        // Only process messages from the iframe
        if (messageEvent.data != null) {
          print(
              'QuillEditor._registerViewFactory() - received message from iframe');
          try {
            // Ensure messageEvent.data is a String before parsing
            final messageData = messageEvent.data is String
                ? messageEvent.data as String
                : messageEvent.data.toString();

            final data = jsonDecode(messageData);
            final htmlValue = data["html"];
            final htmlPreview = htmlValue?.toString() ?? "null";

            // Safely create preview string
            final previewLength =
                htmlPreview.length > 100 ? 100 : htmlPreview.length;
            final preview = previewLength > 0
                ? htmlPreview.substring(0, previewLength)
                : htmlPreview;

            print(
                'QuillEditor._registerViewFactory() - message data: $preview...');
            widget.onMessageReceived
                ?.call(htmlValue is String ? htmlValue : htmlValue?.toString());
          } catch (e) {
            print(
                'QuillEditor._registerViewFactory() - message parse error: $e');
            // If not JSON, treat as plain string
            final messageData = messageEvent.data is String
                ? messageEvent.data as String
                : messageEvent.data.toString();
            widget.onMessageReceived?.call(messageData);
          }
        }
      });

      return _iframe!;
    });
  }

  void insertText(String text) {
    print('QuillEditor.insertText() called with text: $text');
    sendJsonToIframe({
      'action': 'insertText',
      'text': text,
    });
  }

  void setContents(dynamic delta) {
    print('QuillEditor.setContents() called with delta: $delta');
    sendJsonToIframe({
      'action': 'setContents',
      'delta': delta,
    });
  }

  void setHTML(String html) {
    print('QuillEditor.setHTML() called with html length: ${html.length}');
    // print('QuillEditor.setHTML() html content: $html');
    sendJsonToIframe({
      'action': 'setHTML',
      'html': html,
    });
  }

  void sendMessageToIframe(String message) {
    print('QuillEditor.sendMessageToIframe() called with message: $message');
    _iframe?.contentWindow?.postMessage(message, '*');
  }

  void sendJsonToIframe(Map<String, dynamic> data) {
    print(
        'QuillEditor.sendJsonToIframe() called with action: ${data['action']}');
    data['source'] = 'flutter';
    data['type'] = 'command';
    final jsonString = jsonEncode(data);
    print('QuillEditor.sendJsonToIframe() sending: $jsonString');
    _iframe?.contentWindow?.postMessage(jsonString, '*');
  }

  @override
  Widget build(BuildContext context) {
    print('QuillEditor.build() called - readOnly: ${widget.realOnly}');
    if (widget.realOnly == true) {
      print('QuillEditor.build() - returning ViewOnlyHtmlEditor');
      return ViewOnlyHtmlEditor(message: widget.htmlString ?? '');
    } else {
      print(
          'QuillEditor.build() - returning HtmlElementView with viewType: inline-html-$_viewId');
      return HtmlElementView(viewType: 'inline-html-$_viewId');
    }
  }
}

class ViewOnlyHtmlEditor extends StatefulWidget {
  const ViewOnlyHtmlEditor({super.key, required this.message});
  final String message;

  @override
  State<ViewOnlyHtmlEditor> createState() => _ViewOnlyHtmlEditorState();
}

class _ViewOnlyHtmlEditorState extends State<ViewOnlyHtmlEditor> {
  html.IFrameElement? _iframe;
  static int _viewIdCounter = 0;
  late int _viewId;
  bool _hasInitializedContent = false;

  @override
  void initState() {
    print('ViewOnlyHtmlEditor.initState() called');
    super.initState();
    _viewId = ++_viewIdCounter;
    print('ViewOnlyHtmlEditor.initState() - viewId: $_viewId');
    _registerViewFactory();
  }

  void _registerViewFactory() {
    print(
        'ViewOnlyHtmlEditor._registerViewFactory() called for viewId: $_viewId');
    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory('viewOnly-html-$_viewId',
        (int viewId) {
      print('ViewOnlyHtmlEditor._registerViewFactory() - creating iframe');
      _iframe = html.IFrameElement()
        ..src = '/delta_renderer.html'
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%';

      // Listen for iframe load event
      _iframe!.onLoad.listen((_) {
        print('ViewOnlyHtmlEditor._registerViewFactory() - iframe loaded');
        if (!_hasInitializedContent) {
          _hasInitializedContent = true;
          print(
              'ViewOnlyHtmlEditor._registerViewFactory() - setting initial content');
          // Small delay to ensure iframe is fully ready
          Future.delayed(const Duration(milliseconds: 100), () {
            sendMessageToIframe(widget.message);
          });
        }
      });

      return _iframe!;
    });
  }

  void sendMessageToIframe(String message) {
    print(
        'ViewOnlyHtmlEditor.sendMessageToIframe() called with message length: ${message.length}');
    _iframe?.contentWindow?.postMessage(message, '*');
  }

  void sendJsonToIframe(Map<String, dynamic> data) {
    print(
        'ViewOnlyHtmlEditor.sendJsonToIframe() called with action: ${data['action']}');
    data['source'] = 'flutter';
    data['type'] = 'command';
    final jsonString = jsonEncode(data);
    print('ViewOnlyHtmlEditor.sendJsonToIframe() sending: $jsonString');
    _iframe?.contentWindow?.postMessage(jsonString, '*');
  }

  @override
  Widget build(BuildContext context) {
    print(
        'ViewOnlyHtmlEditor.build() called - viewType: viewOnly-html-$_viewId');
    return HtmlElementView(viewType: 'viewOnly-html-$_viewId');
  }
}
