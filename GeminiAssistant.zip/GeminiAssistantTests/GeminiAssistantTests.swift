//
//  GeminiAssistantTests.swift
//  GeminiAssistantTests
//
//  Created by Vivek Yadav on 27/08/25.
//

import Testing

struct GeminiAssistantTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
