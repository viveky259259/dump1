import SwiftUI
import AVFoundation
import Speech
import AppKit

// MARK: - Main Application Entry Point
@main
struct GeminiAssistantApp: App {
    // Using AppDelegate to manage the app's lifecycle and background tasks
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        // The settings scene is the only visible window. The main app lives in the menu bar.
        Settings {
            SettingsView(viewModel: appDelegate.settingsViewModel)
        }
    }
}

// MARK: - Application Delegate
class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBarItem: NSStatusItem!
    var settingsViewModel = SettingsViewModel()

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Create the menu bar item
        statusBarItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)

        if let button = statusBarItem.button {
            button.image = NSImage(systemSymbolName: "sparkles", accessibilityDescription: "GeminiAssistant Assistant")
        }

        // Create the menu that appears when the user clicks the menu bar icon
        let menu = NSMenu()
        
        // Add a "Status" item that shows the current state
        let statusItem = NSMenuItem(title: "Status: Inactive", action: nil, keyEquivalent: "")
        menu.add(statusItem)
        
        menu.add(NSMenuItem.separator())

        // Add a "Settings" option
        menu.add(NSMenuItem(title: "Settings...", action: #selector(openSettings), keyEquivalent: ","))
        
        menu.add(NSMenuItem.separator())

        // Add a "Quit" option
        menu.add(NSMenuItem(title: "Quit GeminiAssistant", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))

        statusBarItem.menu = menu
        
        // Observe changes in the viewModel to update the status
        settingsViewModel.onStatusChange = { [weak self] status in
            DispatchQueue.main.async {
                statusItem.title = "Status: \(status)"
            }
        }
    }

    @objc func openSettings() {
        // This opens the Settings window defined in the Scene.
        if #available(macOS 14.0, *) {
            NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        } else {
            // Fallback for older macOS versions
            NSApp.sendAction(Selector(("showPreferencesWindow:")), to: nil, from: nil)
        }
        NSApp.activate(ignoringOtherApps: true)
    }
}


// MARK: - Settings View Model
class SettingsViewModel: ObservableObject {
    // Published properties will cause the UI to update when they change.
    @Published var apiKey: String = "" {
        didSet {
            // Save the API key securely to the Keychain whenever it's modified.
            KeychainHelper.standard.save(apiKey, service: "com.GeminiAssistant.apiKey", account: "user")
        }
    }
    @Published var isAssistantEnabled: Bool = false {
        didSet {
            toggleMonitoringServices()
        }
    }
    @Published var screenshotInterval: Double = 60.0
    @Published var statusMessage: String = "Inactive"
    
    // Callback to update the menu bar status
    var onStatusChange: ((String) -> Void)?

    // Services for capturing context
    private let screenCaptureService = ScreenCaptureService()
    private let audioCaptureService = AudioCaptureService()

    init() {
        // Load the saved API key from the Keychain on startup.
        self.apiKey = KeychainHelper.standard.read(service: "com.GeminiAssistant.apiKey", account: "user") ?? ""
        
        // Request permissions as soon as the app starts
        requestPermissions()
    }

    private func requestPermissions() {
        // Request microphone access
        AVAudioSession.sharedInstance().requestRecordPermission { granted in
            if !granted {
                DispatchQueue.main.async {
                    self.updateStatus("Microphone access denied.")
                }
            }
        }

        // Request screen recording access
        if !CGPreflightScreenCaptureAccess() {
             CGRequestScreenCaptureAccess()
        }
    }

    private func toggleMonitoringServices() {
        if isAssistantEnabled {
            guard !apiKey.isEmpty else {
                updateStatus("API Key is missing.")
                isAssistantEnabled = false
                return
            }
            
            guard CGPreflightScreenCaptureAccess() else {
                updateStatus("Screen Recording permission needed.")
                isAssistantEnabled = false
                return
            }
            
            guard AVAudioSession.sharedInstance().recordPermission == .granted else {
                updateStatus("Microphone permission needed.")
                isAssistantEnabled = false
                return
            }

            updateStatus("Active")
            screenCaptureService.startCapturing(interval: screenshotInterval)
            audioCaptureService.startCapturing()
        } else {
            updateStatus("Inactive")
            screenCaptureService.stopCapturing()
            audioCaptureService.stopCapturing()
        }
    }
    
    private func updateStatus(_ newStatus: String) {
        DispatchQueue.main.async {
            self.statusMessage = newStatus
            self.onStatusChange?(newStatus)
        }
    }
}

// MARK: - Settings View UI
struct SettingsView: View {
    @ObservedObject var viewModel: SettingsViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("GeminiAssistant Assistant Settings")
                .font(.title)
                .fontWeight(.bold)

            GroupBox(label: Text("Core Settings").fontWeight(.semibold)) {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Enable Assistant", isOn: $viewModel.isAssistantEnabled)
                        .toggleStyle(.switch)
                    
                    Text("Status: \(viewModel.statusMessage)")
                        .font(.caption)
                        .foregroundColor(.gray)

                    SecureField("Enter your AI API Key", text: $viewModel.apiKey)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Text("Your API key is stored securely in the macOS Keychain.")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .padding()
            }

            GroupBox(label: Text("Capture Settings").fontWeight(.semibold)) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Screenshot Interval: \(Int(viewModel.screenshotInterval)) seconds")
                    Slider(value: $viewModel.screenshotInterval, in: 10...300, step: 5) {
                        Text("Screenshot Interval")
                    } minimumValueLabel: {
                        Text("10s")
                    } maximumValueLabel: {
                        Text("5m")
                    }
                }
                .padding()
                .disabled(viewModel.isAssistantEnabled)
            }
            
            Spacer()
            
            Text("GeminiAssistant continuously monitors your screen and microphone to provide proactive assistance when enabled.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)


        }
        .padding(30)
        .frame(width: 450, height: 400)
    }
}

// MARK: - Screen Capture Service
class ScreenCaptureService {
    private var timer: Timer?

    func startCapturing(interval: TimeInterval) {
        // Invalidate any existing timer
        stopCapturing()
        // Create a new timer that fires repeatedly
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            self?.captureScreen()
        }
    }

    func stopCapturing() {
        timer?.invalidate()
        timer = nil
    }

    private func captureScreen() {
        // This uses the Core Graphics API to capture the screen.
        // It captures all windows on the main screen.
        let image = CGWindowListCreateImage(CGRect.infinite, .optionOnScreenOnly, kCGNullWindowID, .bestResolution)
        
        if let cgImage = image {
            // In a real app, you would now convert this CGImage to Data (e.g., PNG or JPEG)
            // and send it to the AI service along with the transcribed audio.
            print("Captured screenshot at \(Date())")
            // let bitmap = NSBitmapImageRep(cgImage: cgImage)
            // let pngData = bitmap.representation(using: .png, properties: [:])
            // processImageData(pngData)
        }
    }
}

// MARK: - Audio Capture Service
class AudioCaptureService: NSObject, SFSpeechRecognizerDelegate {
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    override init() {
        super.init()
        speechRecognizer.delegate = self
    }

    func startCapturing() {
        // Ensure the audio engine is not already running
        if audioEngine.isRunning {
            audioEngine.stop()
            recognitionRequest?.endAudio()
        }
        
        startRecording()
    }

    func stopCapturing() {
        if audioEngine.isRunning {
            audioEngine.stop()
            recognitionRequest?.endAudio()
        }
    }

    private func startRecording() {
        // Create a new recognition request.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        
        // Configure request so that results are returned before audio recording is finished
        recognitionRequest.shouldReportPartialResults = true
        
        // A recognition task represents a speech recognition session.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            var isFinal = false
            
            if let result = result {
                // The AI logic would go here.
                // We would analyze result.bestTranscription.formattedString for keywords.
                print("Transcribed Text: \(result.bestTranscription.formattedString)")
                
                // Example of detecting a question
                if result.bestTranscription.formattedString.lowercased().contains("how do i") {
                    print("--- Question Detected! Triggering AI assistant. ---")
                    // Here you would trigger the network call to the AI with the text and the latest screenshot.
                }
                
                isFinal = result.isFinal
            }
            
            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recognitionRequest = nil
                self.recognitionTask = nil
            }
        }
        
        // Configure the audio session for recording.
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        
        do {
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error: \(error)")
        }
    }
}


// MARK: - Keychain Helper
// A simple helper for securely storing the API key.
class KeychainHelper {
    static let standard = KeychainHelper()
    private init() {}

    func save(_ data: String, service: String, account: String) {
        guard let dataFromString = data.data(using: .utf8, allowLossyConversion: false) else { return }

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: dataFromString
        ]

        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }

    func read(service: String, account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: kCFBooleanTrue!,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var dataTypeRef: AnyObject?
        let status: OSStatus = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)

        if status == noErr {
            guard let retrievedData = dataTypeRef as? Data else { return nil }
            return String(data: retrievedData, encoding: .utf8)
        } else {
            return nil
        }
    }
}
