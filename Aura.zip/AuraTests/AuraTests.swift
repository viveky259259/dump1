//
//  AuraTests.swift
//  AuraTests
//
//  Created by Vivek Yadav on 27/08/25.
//

import Testing
@testable import Aura

struct AuraTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
