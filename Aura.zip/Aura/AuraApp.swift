import SwiftUI
import AVFoundation
import Speech
import AppKit
import ScreenCaptureKit

// MARK: - Main Application Entry Point
@main
struct AuraAppApp: App {
    // Using AppDelegate to manage the app's lifecycle and background tasks
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        // The settings scene is the only visible window. The main app lives in the menu bar.
        Settings {
            SettingsView(viewModel: appDelegate.settingsViewModel)
        }
    }
}

// MARK: - Application Delegate
@MainActor
class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBarItem: NSStatusItem!
    var settingsViewModel = SettingsViewModel()

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Create the menu bar item
        statusBarItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)

        if let button = statusBarItem.button {
            button.image = NSImage(systemSymbolName: "sparkles", accessibilityDescription: "Aura Assistant")
        }

        // Create the menu that appears when the user clicks the menu bar icon
        let menu = NSMenu()
        
        // Add a "Status" item that shows the current state
        let statusItem = NSMenuItem(title: "Status: Inactive", action: nil, keyEquivalent: "")
        menu.addItem(statusItem)
        
        menu.addItem(NSMenuItem.separator())

        // Add a "Settings" option
        menu.addItem(NSMenuItem(title: "Settings...", action: #selector(openSettings), keyEquivalent: ","))
        
        menu.addItem(NSMenuItem.separator())

        // Add a "Quit" option
        menu.addItem(NSMenuItem(title: "Quit Aura", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))

        statusBarItem.menu = menu
        
        // Observe changes in the viewModel to update the status
        settingsViewModel.onStatusChange = { status in
            DispatchQueue.main.async {
                statusItem.title = "Status: \(status)"
            }
        }
    }

    @objc func openSettings() {
        // This opens the Settings window defined in the Scene.
        if #available(macOS 14.0, *) {
            NSApp.sendAction(Selector(("showSettingsWindow:")), to: nil, from: nil)
        } else {
            // Fallback for older macOS versions
            NSApp.sendAction(Selector(("showPreferencesWindow:")), to: nil, from: nil)
        }
        NSApp.activate(ignoringOtherApps: true)
    }
}


// MARK: - Settings View Model
@MainActor
class SettingsViewModel: ObservableObject {
    // Published properties will cause the UI to update when they change.
    @Published var apiKey: String = "" {
        didSet {
            // Save the API key securely to the Keychain whenever it's modified.
            KeychainHelper.standard.save(apiKey, service: "com.aura.apiKey", account: "user")
        }
    }
    @Published var isAssistantEnabled: Bool = false {
        didSet {
            Task {
                await toggleMonitoringServices()
            }
        }
    }
    @Published var screenshotInterval: Double = 60.0
    @Published var statusMessage: String = "Inactive"
    
    // Callback to update the menu bar status
    var onStatusChange: ((String) -> Void)?

    // Services for capturing context
    private let screenCaptureService = ScreenCaptureService()
    private let audioCaptureService = AudioCaptureService()

    init() {
        // Load the saved API key from the Keychain on startup.
        self.apiKey = KeychainHelper.standard.read(service: "com.aura.apiKey", account: "user") ?? ""
        
        // Request permissions as soon as the app starts
        Task {
            await requestInitialPermissions()
        }
    }

    private func requestInitialPermissions() async {
        // This function will now just trigger the checks which in turn trigger the prompts if needed.
        _ = await screenCaptureService.hasPermission()
        await AVCaptureDevice.requestAccess(for: .audio)
    }

    private func toggleMonitoringServices() async {
        if isAssistantEnabled {
            guard !apiKey.isEmpty else {
                updateStatus("API Key is missing.")
                isAssistantEnabled = false
                return
            }
            
            let hasScreenAccess = await screenCaptureService.hasPermission()
            guard hasScreenAccess else {
                updateStatus("Screen Recording permission needed.")
                isAssistantEnabled = false
                return
            }
            
            let hasMicAccess = AVCaptureDevice.authorizationStatus(for: .audio) == .authorized
            guard hasMicAccess else {
                updateStatus("Microphone permission needed.")
                isAssistantEnabled = false
                return
            }

            updateStatus("Active")
            screenCaptureService.startCapturing(interval: screenshotInterval)
            audioCaptureService.startCapturing()
        } else {
            updateStatus("Inactive")
            screenCaptureService.stopCapturing()
            audioCaptureService.stopCapturing()
        }
    }
    
    private func updateStatus(_ newStatus: String) {
        DispatchQueue.main.async {
            self.statusMessage = newStatus
            self.onStatusChange?(newStatus)
        }
    }
}

// MARK: - Settings View UI
struct SettingsView: View {
    @ObservedObject var viewModel: SettingsViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Aura Assistant Settings")
                .font(.title)
                .fontWeight(.bold)

            GroupBox(label: Text("Core Settings").fontWeight(.semibold)) {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Enable Assistant", isOn: $viewModel.isAssistantEnabled)
                        .toggleStyle(.switch)
                    
                    Text("Status: \(viewModel.statusMessage)")
                        .font(.caption)
                        .foregroundColor(.gray)

                    SecureField("Enter your AI API Key", text: $viewModel.apiKey)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Text("Your API key is stored securely in the macOS Keychain.")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .padding()
            }

            GroupBox(label: Text("Capture Settings").fontWeight(.semibold)) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Screenshot Interval: \(Int(viewModel.screenshotInterval)) seconds")
                    Slider(value: $viewModel.screenshotInterval, in: 10...300, step: 5) {
                        Text("Screenshot Interval")
                    } minimumValueLabel: {
                        Text("10s")
                    } maximumValueLabel: {
                        Text("5m")
                    }
                }
                .padding()
                .disabled(viewModel.isAssistantEnabled)
            }
            
            Spacer()
            
            Text("Aura continuously monitors your screen and microphone to provide proactive assistance when enabled.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)


        }
        .padding(30)
        .frame(width: 450, height: 400)
    }
}

// MARK: - Screen Capture Service
class ScreenCaptureService {
    private var timer: Timer?

    func hasPermission() async -> Bool {
        // The modern way to request permission is to try to get the content.
        // This will prompt the user if access has not been granted.
        do {
            _ = try await SCShareableContent.current
            return true
        } catch {
            print("Screen capture permission was denied or failed: \(error.localizedDescription)")
            return false
        }
    }

    func startCapturing(interval: TimeInterval) {
        stopCapturing()
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            Task {
                await self?.captureScreen()
            }
        }
    }

    func stopCapturing() {
        timer?.invalidate()
        timer = nil
    }

    private func captureScreen() async {
        do {
            let content = try await SCShareableContent.current
            guard let display = content.displays.first else {
                print("No display found to capture.")
                return
            }
            
            let filter = SCContentFilter(display: display, excludingWindows: [])
            let config = SCStreamConfiguration()
            config.width = display.width * 2 // For Retina displays
            config.height = display.height * 2
            
            let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
            
            print("Captured screenshot at \(Date())")
            // In a real app, you would now convert this CGImage to Data
            // let pngData = NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:])
            // processImageData(pngData)
            
        } catch {
            print("Error capturing screen: \(error.localizedDescription)")
        }
    }
}

// MARK: - Audio Capture Service
class AudioCaptureService: NSObject, SFSpeechRecognizerDelegate {
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()

    override init() {
        super.init()
        speechRecognizer.delegate = self
    }

    func startCapturing() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        startRecording()
    }

    func stopCapturing() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
            recognitionRequest?.endAudio()
            recognitionTask?.cancel()
            recognitionRequest = nil
            recognitionTask = nil
        }
    }

    private func startRecording() {
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        
        recognitionRequest.shouldReportPartialResults = true
        
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            var isFinal = false
            
            if let result = result {
                print("Transcribed Text: \(result.bestTranscription.formattedString)")
                if result.bestTranscription.formattedString.lowercased().contains("how do i") {
                    print("--- Question Detected! Triggering AI assistant. ---")
                }
                isFinal = result.isFinal
            }
            
            if error != nil || isFinal {
                self.audioEngine.stop()
                self.audioEngine.inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
            }
        }
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        
        do {
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error: \(error)")
        }
    }
}


// MARK: - Keychain Helper
class KeychainHelper {
    static let standard = KeychainHelper()
    private init() {}

    func save(_ data: String, service: String, account: String) {
        guard let dataFromString = data.data(using: .utf8, allowLossyConversion: false) else { return }

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: dataFromString
        ]

        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }

    func read(service: String, account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: kCFBooleanTrue!,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var dataTypeRef: AnyObject?
        let status: OSStatus = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)

        if status == noErr {
            guard let retrievedData = dataTypeRef as? Data else { return nil }
            return String(data: retrievedData, encoding: .utf8)
        } else {
            return nil
        }
    }
}
