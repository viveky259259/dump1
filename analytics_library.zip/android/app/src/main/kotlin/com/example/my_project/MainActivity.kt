package com.mycompany.analyticslibrary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
