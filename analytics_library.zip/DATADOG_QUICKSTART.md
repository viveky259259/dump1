# Datadog Quick Start Guide

Get Datadog analytics running in your Flutter app in 5 minutes!

## Step 1: Get Your Credentials

1. Log in to your [Datadog account](https://app.datadoghq.com/)
2. Navigate to: **UX Monitoring** → **RUM Applications** → **New Application**
3. Select **Flutter** as the application type
4. Copy your:
   - **Application ID** (looks like: `abc12345-6789-def0-1234-567890abcdef`)
   - **Client Token** (looks like: `pub1234567890abcdef1234567890abcd`)
5. Note your **Datadog Site** (e.g., US1, EU1, etc.)

## Step 2: Install Dependencies

The Datadog SDK is already in your `pubspec.yaml`. Just run:

```bash
flutter pub get
```

## Step 3: Configure Datadog Constants

Update your Datadog credentials in `lib/custom_code/datadog_constants.dart`:

```dart
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';

class DatadogConstants {
  static const String clientToken = 'pub1234567890abcdef1234567890abcd'; // Your client token
  static const String applicationId = 'abc12345-6789-def0-1234-567890abcdef'; // Your app ID
  static const String env = 'prod'; // or 'dev', 'staging'
  static const DatadogSite site = DatadogSite.us1; // Change based on your region
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}
```

## Step 4: Initialize Datadog

In your app's initialization code (e.g., `main.dart` or startup action):

```dart
import 'package:analytics_library/custom_code/analytics_locator.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Datadog (config is read from DatadogConstants)
  await AnalyticsLocator.ensureInitialized(enableDatadog: true);
  await AnalyticsLocator.instance.initialize();
  
  runApp(MyApp());
}
```

## Step 5: Track Your First Event

```dart
import 'package:analytics_library/custom_code/analytics_locator.dart';
import 'package:analytics_library/custom_code/analytics_event.dart';

// Log an event
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent(
    'app_opened',
    properties: {
      'source': 'home_screen',
      'timestamp': DateTime.now().toIso8601String(),
    },
  ),
);
```

## Step 6: Verify in Datadog

1. Open your Datadog dashboard
2. Go to **UX Monitoring** → **RUM Applications**
3. Select your application
4. You should see events appearing within a few minutes

## Common Use Cases

### Track Button Clicks

```dart
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent('button_clicked', properties: {
    'button_name': 'login',
    'screen': 'home',
  }),
);
```

### Track Screen Views

```dart
await AnalyticsLocator.instance.logScreenView(
  ScreenEvent(
    screenName: 'Product Details',
    screenClass: 'ProductDetailsPage',
    properties: {'product_id': '12345'},
  ),
);
```

### Identify Users

```dart
await AnalyticsLocator.instance.setUserId('user_123');
await AnalyticsLocator.instance.setUserProperties({
  'email': 'user@example.com',
  'plan': 'premium',
});
```

### Clear Data on Logout

```dart
await AnalyticsLocator.instance.reset();
```

## Datadog Sites Reference

Choose your site based on where your Datadog account is hosted:

| Region | Site Value | URL |
|--------|-----------|-----|
| US1 | `DatadogSite.us1` | https://app.datadoghq.com |
| US3 | `DatadogSite.us3` | https://us3.datadoghq.com |
| US5 | `DatadogSite.us5` | https://us5.datadoghq.com |
| EU1 | `DatadogSite.eu1` | https://app.datadoghq.eu |
| AP1 | `DatadogSite.ap1` | https://ap1.datadoghq.com |
| US1-FED | `DatadogSite.us1Fed` | https://app.ddog-gov.com |

## Environment Configuration

Update `datadog_constants.dart` for different environments:

```dart
// Development
class DatadogConstants {
  static const String clientToken = 'YOUR_DEV_TOKEN';
  static const String applicationId = 'YOUR_DEV_APP_ID';
  static const String env = 'dev';
  static const DatadogSite site = DatadogSite.us1;
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}

// Staging
class DatadogConstants {
  static const String clientToken = 'YOUR_STAGING_TOKEN';
  static const String applicationId = 'YOUR_STAGING_APP_ID';
  static const String env = 'staging';
  static const DatadogSite site = DatadogSite.us1;
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}

// Production
class DatadogConstants {
  static const String clientToken = 'YOUR_PROD_TOKEN';
  static const String applicationId = 'YOUR_PROD_APP_ID';
  static const String env = 'prod';
  static const DatadogSite site = DatadogSite.us1;
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}
```

**Tip**: Use build flavors or environment variables to switch between configurations automatically.

## Troubleshooting

### Events Not Showing Up?

✅ **Check your credentials** - Make sure client token and app ID are correct  
✅ **Wait a few minutes** - Events can take 2-5 minutes to appear  
✅ **Check initialization** - Ensure you called both `ensureInitialized()` and `initialize()`  
✅ **Verify site** - Make sure you're using the correct Datadog site  

### Build Errors?

```bash
flutter clean
flutter pub get
cd ios && pod install && cd ..
flutter run
```

## Next Steps

- 📘 Read the [Complete Setup Guide](DATADOG_SETUP.md) for advanced features
- 📊 Explore [Datadog RUM Documentation](https://docs.datadoghq.com/real_user_monitoring/)
- 🔍 Set up [Error Tracking](https://docs.datadoghq.com/real_user_monitoring/error_tracking/)
- 📈 Create [Dashboards and Monitors](https://docs.datadoghq.com/dashboards/)

## Need Help?

Check out the [detailed setup guide](DATADOG_SETUP.md) for:
- Platform-specific configuration
- Privacy and consent management  
- Multiple analytics providers
- API reference
- Best practices

