# Datadog Integration Setup Guide

This guide will help you integrate Datadog analytics into your Flutter application using the analytics library.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [Features](#features)
- [Platform-Specific Setup](#platform-specific-setup)
- [API Reference](#api-reference)

## Prerequisites

Before you begin, you need:
1. A Datadog account ([sign up here](https://www.datadoghq.com/))
2. A Datadog Application ID (from RUM setup)
3. A Datadog Client Token (from RUM setup)

## Installation

The Datadog Flutter plugin is already included in `pubspec.yaml`:

```yaml
dependencies:
  datadog_flutter_plugin: ^2.0.0
```

Run the following command to install dependencies:

```bash
flutter pub get
```

## Configuration

### Basic Setup

Initialize Datadog in your app's initialization code:

```dart
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';
import 'package:analytics_library/custom_code/analytics_locator.dart';

Future<void> initializeAnalytics() async {
  await AnalyticsLocator.ensureInitialized(
    datadogConfig: DatadogConfig(
      clientToken: 'YOUR_CLIENT_TOKEN',
      applicationId: 'YOUR_APPLICATION_ID',
      env: 'prod', // or 'dev', 'staging', etc.
      site: DatadogSite.us1, // Choose based on your Datadog region
      trackingConsent: TrackingConsent.granted,
    ),
  );
  
  // Initialize the analytics manager
  await AnalyticsLocator.instance.initialize();
}
```

### Configuration Options

#### Environment (`env`)
Specify the environment for your app:
- `'prod'` - Production
- `'staging'` - Staging
- `'dev'` - Development

#### Datadog Site (`site`)
Choose the Datadog site based on your region:
- `DatadogSite.us1` - US1 (default)
- `DatadogSite.us3` - US3
- `DatadogSite.us5` - US5
- `DatadogSite.eu1` - EU1
- `DatadogSite.ap1` - AP1
- `DatadogSite.us1Fed` - US1-FED (Government)

#### Tracking Consent (`trackingConsent`)
Control user tracking consent:
- `TrackingConsent.granted` - Full tracking enabled
- `TrackingConsent.notGranted` - Tracking disabled
- `TrackingConsent.pending` - Waiting for user consent

### Multiple Analytics Providers

You can use Datadog alongside other analytics providers like MoEngage:

```dart
await AnalyticsLocator.ensureInitialized(
  moengageAppId: 'YOUR_MOENGAGE_APP_ID',
  datadogConfig: DatadogConfig(
    clientToken: 'YOUR_CLIENT_TOKEN',
    applicationId: 'YOUR_APPLICATION_ID',
    env: 'prod',
    site: DatadogSite.us1,
    trackingConsent: TrackingConsent.granted,
  ),
);
```

## Usage

### Logging Events

Track custom events with properties:

```dart
import 'package:analytics_library/custom_code/analytics_event.dart';
import 'package:analytics_library/custom_code/analytics_locator.dart';

// Log a simple event
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent('button_clicked'),
);

// Log an event with properties
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent(
    'purchase_completed',
    properties: {
      'product_id': '12345',
      'price': 29.99,
      'currency': 'USD',
    },
  ),
);
```

### Tracking Screen Views

Track screen navigation:

```dart
await AnalyticsLocator.instance.logScreenView(
  ScreenEvent(
    screenName: 'Home',
    screenClass: 'HomePage',
    properties: {
      'tab': 'featured',
    },
  ),
);
```

### Setting User Information

Identify users and their properties:

```dart
// Set user ID
await AnalyticsLocator.instance.setUserId('user_12345');

// Set a single user property
await AnalyticsLocator.instance.setUserProperty('subscription_tier', 'premium');

// Set multiple user properties
await AnalyticsLocator.instance.setUserProperties({
  'name': 'John Doe',
  'email': 'john@example.com',
  'age': 30,
  'subscription_tier': 'premium',
});
```

### Resetting User Data

Clear user data on logout:

```dart
await AnalyticsLocator.instance.reset();
```

## Features

### What Datadog Tracks

The integration automatically tracks:

1. **RUM (Real User Monitoring)**
   - Custom user actions/events
   - Screen views
   - User sessions
   - Application crashes (when enabled)

2. **Logs**
   - Custom event logs with attributes
   - Error and debug information

3. **User Information**
   - User ID
   - Custom user attributes
   - User behavior patterns

### Data Collected

- Custom events with properties
- Screen navigation and views
- User identification and properties
- Session information
- Application performance metrics

## Platform-Specific Setup

### Android Setup

Add the following to your `android/app/build.gradle`:

```gradle
android {
    defaultConfig {
        // Required for Datadog
        minSdkVersion 21
    }
}
```

### iOS Setup

For iOS, update your `ios/Podfile` to set the minimum platform version:

```ruby
platform :ios, '11.0'
```

Then run:

```bash
cd ios && pod install
```

### Web Support

Datadog Flutter plugin supports web. No additional configuration is required.

## API Reference

### DatadogConfig

Configuration class for initializing Datadog:

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `clientToken` | String | Yes | - | Your Datadog client token |
| `applicationId` | String | Yes | - | Your Datadog RUM application ID |
| `env` | String | No | `'prod'` | Environment name |
| `site` | DatadogSite | No | `DatadogSite.us1` | Datadog site/region |
| `trackingConsent` | TrackingConsent | No | `TrackingConsent.granted` | User tracking consent |

### AnalyticsManager Methods

| Method | Parameters | Description |
|--------|------------|-------------|
| `initialize()` | - | Initialize all analytics providers |
| `logEvent()` | `AnalyticsEvent` | Log a custom event |
| `logScreenView()` | `ScreenEvent` | Track screen views |
| `setUserId()` | `String userId` | Set the user ID |
| `setUserProperty()` | `String key, Object? value` | Set a single user property |
| `setUserProperties()` | `Map<String, Object?> properties` | Set multiple user properties |
| `reset()` | - | Clear all user data |

### AnalyticsEvent

Create custom events:

```dart
AnalyticsEvent(
  String name,
  {
    Map<String, dynamic> properties = const {},
    DateTime? timestamp,
  }
)
```

### ScreenEvent

Create screen view events:

```dart
ScreenEvent(
  {
    required String screenName,
    String? screenClass,
    Map<String, dynamic> properties = const {},
    DateTime? timestamp,
  }
)
```

## Best Practices

1. **Initialize Early**: Initialize analytics as early as possible in your app lifecycle
2. **Consistent Naming**: Use consistent event and property names across your app
3. **Meaningful Properties**: Include relevant context in event properties
4. **User Privacy**: Respect user privacy and comply with GDPR/CCPA regulations
5. **Error Handling**: The analytics manager automatically handles provider failures
6. **Environment Separation**: Use different configurations for dev/staging/prod

## Troubleshooting

### Events Not Appearing in Datadog

1. Verify your client token and application ID are correct
2. Check that you've called `initialize()` after `ensureInitialized()`
3. Ensure you're using the correct Datadog site for your region
4. Check network connectivity and firewall rules

### Build Errors

1. Run `flutter clean && flutter pub get`
2. For iOS: `cd ios && pod install && cd ..`
3. Verify minimum SDK versions meet requirements

### Performance Issues

1. Avoid logging excessive events in tight loops
2. Use batch operations when possible
3. Consider implementing event throttling for high-frequency events

## Additional Resources

- [Datadog Documentation](https://docs.datadoghq.com/real_user_monitoring/mobile_and_tv_monitoring/flutter/)
- [Flutter Plugin GitHub](https://github.com/DataDog/dd-sdk-flutter)
- [Analytics Library Example](./lib/custom_code/actions/example_init_analytics.dart)

## Support

For issues specific to:
- **Datadog SDK**: Check [Datadog Support](https://docs.datadoghq.com/help/)
- **Analytics Library**: Refer to the main [README.md](./README.md)

