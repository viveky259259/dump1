import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String dataDogClientToken = 'xxx-token';
  static const String applicationId = 'com.app.product';
}
