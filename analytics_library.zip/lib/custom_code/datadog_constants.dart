import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';

/// Datadog configuration constants
/// Update these values with your Datadog credentials
class DatadogConstants {
  // Datadog Client Token (from Datadog RUM Application setup)
  static const String clientToken = 'YOUR_CLIENT_TOKEN';

  // Datadog Application ID (from Datadog RUM Application setup)
  static const String applicationId = 'YOUR_APPLICATION_ID';

  // Environment: 'dev', 'staging', 'prod', etc.
  static const String env = 'prod';
}

