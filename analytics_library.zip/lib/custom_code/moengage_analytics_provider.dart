import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:moengage_flutter/moengage_flutter.dart';
import 'analytics_event.dart';
import 'analytics_provider.dart';

class MoEngageAnalyticsProvider implements AnalyticsProvider {
  static const SCREEN_NAME = 'screen_name';
  static const SCREEN_CLASS = 'screen_class';

  MoEngageAnalyticsProvider({required String appId})
      : _moePlugin = MoEngageFlutter(appId);

  final MoEngageFlutter _moePlugin;

  bool _initialized = false;

  @override
  Future<void> initialize() async {
    if (kIsWeb || Platform.isAndroid || Platform.isIOS) {
      _initialized = true;
    }
  }

  @override
  Future<void> logEvent(AnalyticsEvent event) async {
    if (!_initialized) return;
    final props = MoEProperties();

    event.properties.forEach(props.addAttribute);

    _moePlugin.trackEvent(event.name, props);
  }

  @override
  Future<void> logScreenView(ScreenEvent event) async {
    if (!_initialized) return;
    final MoEProperties props = MoEProperties();
    event.properties.forEach((key, value) => props.addAttribute(key, value));
    props.addAttribute(SCREEN_NAME, event.screenName);
    props.addAttribute(SCREEN_CLASS, event.screenClass ?? event.screenName);
    _moePlugin.trackEvent(event.name, props);
  }

  @override
  Future<void> reset() async {
    if (!_initialized) return;
    _moePlugin.logout();
    _initialized = false;
  }

  @override
  Future<void> setUserId(String userId) async {
    if (!_initialized) return;
    _moePlugin.identifyUser(userId);
  }

  @override
  Future<void> setUserProperties(Map<String, Object?> properties) async {
    if (!_initialized) return;
    properties.forEach((key, value) => _moePlugin.setUserAttribute(key, value));
  }

  @override
  Future<void> setUserProperty(String key, Object? value) async {
    if (!_initialized) return;
    _moePlugin.setUserAttribute(key, value);
  }
}
