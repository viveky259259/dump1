import 'package:flutter/foundation.dart';
import 'analytics_event.dart';

abstract class AnalyticsProvider {
  Future<void> initialize();

  Future<void> setUserId(String userId);
  Future<void> setUserProperty(String key, Object? value);
  Future<void> setUserProperties(Map<String, Object?> properties);

  Future<void> logEvent(AnalyticsEvent event);

  Future<void> logScreenView(ScreenEvent event);

  Future<void> reset();
}

/// A no-op provider to use for tests.
class NoOpAnalyticsProvider implements AnalyticsProvider {
  @visibleForTesting
  int eventsCount = 0;

  @override
  Future<void> initialize() async {}

  @override
  Future<void> setUserId(String userId) async {}

  @override
  Future<void> setUserProperty(String key, Object? value) async {}

  @override
  Future<void> setUserProperties(Map<String, Object?> properties) async {}

  @override
  Future<void> logEvent(AnalyticsEvent event) async {
    eventsCount++;
  }

  @override
  Future<void> logScreenView(ScreenEvent event) async {
    eventsCount++;
  }

  @override
  Future<void> reset() async {}
}
