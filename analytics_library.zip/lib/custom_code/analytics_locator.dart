import 'package:flutter/foundation.dart';
import 'analytics_manager.dart';
import 'analytics_provider.dart';
import 'console_analytics_provider.dart';
import 'moengage_analytics_provider.dart';
import 'data_dog_analytics_provider.dart';

/// Simple locator to hold a singleton manager instance.
class AnalyticsLocator {
  static AnalyticsManager? _instance;

  static AnalyticsManager ensureInitialized({
    String? moengageAppId,
    bool enableDatadog = false,
  }) {
    if (_instance != null) return _instance!;

    final List<AnalyticsProvider> providers = <AnalyticsProvider>[];

    // Always include a console logger for debugging
    providers.add(ConsoleAnalyticsProvider());

    // Add MoEngage only when app id is provided and platform is supported
    if (moengageAppId != null && moengageAppId.isNotEmpty && !kIsWeb) {
      providers.add(MoEngageAnalyticsProvider(appId: moengageAppId));
    }

    // Add Datadog when enabled (config is read from DatadogConstants)
    if (enableDatadog) {
      providers.add(DataDogAnalyticsProvider());
    }

    _instance = AnalyticsManager(providers);
    return _instance!;
  }

  static AnalyticsManager get analyticsManager {
    assert(_instance != null, 'Call ensureInitialized() first.');
    return _instance!;
  }
}
