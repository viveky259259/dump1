import 'package:flutter/foundation.dart';

/// Standardized analytics event used by the analytics manager.
@immutable
class AnalyticsEvent {
  const AnalyticsEvent(
    this.name, {
    this.properties = const <String, dynamic>{},
    this.timestamp,
  });

  final String name;
  final Map<String, dynamic> properties;
  final DateTime? timestamp;
}

@immutable
class ScreenEvent extends AnalyticsEvent {
  ScreenEvent(
      {required this.screenName,
      this.screenClass,
      super.properties,
      super.timestamp})
      : super(eventName);
  final String screenName;
  final String? screenClass;

  static const eventName = 'screen_view';
}
