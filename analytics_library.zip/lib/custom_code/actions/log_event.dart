// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '../analytics_locator.dart';
import '../analytics_event.dart';

Future logEvent(
  dynamic properties,
  String eventName,
) async {
  AnalyticsLocator.analyticsManager.logEvent(AnalyticsEvent(eventName,
      properties: (properties is Map<String, dynamic>) ? properties : {}));
}
