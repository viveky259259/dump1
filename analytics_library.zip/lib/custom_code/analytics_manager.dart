import 'dart:async';
import 'analytics_event.dart';
import 'analytics_provider.dart';

class AnalyticsManager {
  AnalyticsManager(List<AnalyticsProvider> providers)
      : _providers = List<AnalyticsProvider>.unmodifiable(providers);

  final List<AnalyticsProvider> _providers;

  Future<void> initialize() async {
    await Future.wait(_providers.map((provider) => provider.initialize()));
  }

  Future<void> setUserId(String userId) async {
    await _fanOut((p) => p.setUserId(userId));
  }

  Future<void> setUserProperty(String key, Object? value) async {
    await _fanOut((p) => p.setUserProperty(key, value));
  }

  Future<void> setUserProperties(Map<String, Object?> properties) async {
    await _fanOut((p) => p.setUserProperties(properties));
  }

  Future<void> logEvent(AnalyticsEvent event) async {
    await _fanOut((p) => p.logEvent(event));
  }

  Future<void> logScreenView(ScreenEvent event) async {
    await _fanOut(
      (p) => p.logScreenView(event),
    );
  }

  Future<void> reset() async {
    await _fanOut((p) => p.reset());
  }

  Future<void> _fanOut(Future<void> Function(AnalyticsProvider) call) async {
    final List<Future<void>> futures = <Future<void>>[];
    for (final AnalyticsProvider provider in _providers) {
      futures.add(_guarded(call, provider));
    }
    await Future.wait(futures);
  }

  Future<void> _guarded(
    Future<void> Function(AnalyticsProvider) call,
    AnalyticsProvider provider,
  ) async {
    try {
      await call(provider);
    } catch (_) {
      // Intentionally swallow errors from a single provider
      // to avoid blocking other providers.
    }
  }
}
