import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';
import 'analytics_event.dart';
import 'analytics_provider.dart';
import 'package:analytics_library/app_constants.dart';
import 'package:analytics_library/app_state.dart';

class DataDogAnalyticsProvider implements AnalyticsProvider {
  static const SCREEN_NAME = 'screen_name';
  static const SCREEN_CLASS = 'screen_class';

  DataDogAnalyticsProvider();

  bool _initialized = false;
  DatadogSdk? _datadogSdk;

  @override
  Future<void> initialize() async {
    if (_initialized) return;

    // Initialize Datadog SDK using constants
    final configuration = DatadogConfiguration(
      clientToken: FFAppConstants.dataDogClientToken,
      env: FFAppState().env,
      site: DatadogSite.us1, // default is us1
      nativeCrashReportEnabled: true,
      loggingConfiguration: DatadogLoggingConfiguration(),
      rumConfiguration: DatadogRumConfiguration(
        applicationId: FFAppConstants.applicationId,
      ),
    );

    _datadogSdk = DatadogSdk.instance;
    await _datadogSdk!.initialize(configuration, TrackingConsent.granted);

    _initialized = true;
  }

  @override
  Future<void> logEvent(AnalyticsEvent event) async {
    if (!_initialized || _datadogSdk == null) return;

    // Log as RUM action
    _datadogSdk!.rum?.addAction(
      event.properties['type'] ?? RumActionType.custom,
      event.name,
      event.properties,
    );

    // Also log to Datadog Logs - using the logger to create a log entry
    final logger = _datadogSdk!.logs?.createLogger(
      DatadogLoggerConfiguration(
        name: 'analytics',
      ),
    );
    logger?.info(event.name, attributes: event.properties);
  }

  @override
  Future<void> logScreenView(ScreenEvent event) async {
    if (!_initialized || _datadogSdk == null) return;

    final attributes = Map<String, dynamic>.from(event.properties);
    attributes[SCREEN_NAME] = event.screenName;
    attributes[SCREEN_CLASS] = event.screenClass ?? event.screenName;

    // Start RUM view
    _datadogSdk!.rum?.startView(
      event.screenName,
      event.screenName,
      attributes,
    );
  }

  @override
  Future<void> reset() async {
    if (!_initialized || _datadogSdk == null) return;

    // Clear user info
    _datadogSdk!.clearAllData();
    _initialized = false;
  }

  @override
  Future<void> setUserId(String userId) async {
    if (!_initialized || _datadogSdk == null) return;

    _datadogSdk!.setUserInfo(id: userId);
  }

  @override
  Future<void> setUserProperties(Map<String, Object?> properties) async {
    if (!_initialized || _datadogSdk == null) return;

    _datadogSdk!.setUserInfo(
      extraInfo: properties,
    );
  }

  @override
  Future<void> setUserProperty(String key, Object? value) async {
    if (!_initialized || _datadogSdk == null) return;

    _datadogSdk!.setUserInfo(
      extraInfo: {key: value},
    );
  }
}
