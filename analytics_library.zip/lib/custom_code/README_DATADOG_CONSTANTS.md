# Datadog Constants Configuration

This file contains the centralized configuration for Datadog analytics.

## Location

`lib/custom_code/datadog_constants.dart`

## Configuration

Update the constants with your Datadog credentials:

```dart
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';

class DatadogConstants {
  // Required: Get this from Datadog RUM Application setup
  static const String clientToken = 'YOUR_CLIENT_TOKEN';
  
  // Required: Get this from Datadog RUM Application setup
  static const String applicationId = 'YOUR_APPLICATION_ID';
  
  // Environment identifier
  static const String env = 'prod';
  
  // Datadog site/region
  static const DatadogSite site = DatadogSite.us1;
  
  // User tracking consent
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}
```

## Getting Your Credentials

1. Log in to [Datadog](https://app.datadoghq.com/)
2. Navigate to: **UX Monitoring** → **RUM Applications**
3. Click **New Application** or select existing
4. Choose **Flutter** as the application type
5. Copy the **Client Token** and **Application ID**

## Configuration Options

### Client Token
- Type: `String`
- Required: Yes
- Example: `'pub1234567890abcdef1234567890abcd'`
- Description: Public token for authenticating with Datadog

### Application ID
- Type: `String`
- Required: Yes
- Example: `'abc12345-6789-def0-1234-567890abcdef'`
- Description: Unique identifier for your application in Datadog

### Environment (env)
- Type: `String`
- Required: No
- Default: `'prod'`
- Options: Any string (e.g., `'dev'`, `'staging'`, `'prod'`, `'test'`)
- Description: Environment name for filtering data in Datadog

### Site
- Type: `DatadogSite`
- Required: No
- Default: `DatadogSite.us1`
- Options:
  - `DatadogSite.us1` - US1 (https://app.datadoghq.com)
  - `DatadogSite.us3` - US3 (https://us3.datadoghq.com)
  - `DatadogSite.us5` - US5 (https://us5.datadoghq.com)
  - `DatadogSite.eu1` - EU1 (https://app.datadoghq.eu)
  - `DatadogSite.ap1` - AP1 (https://ap1.datadoghq.com)
  - `DatadogSite.us1Fed` - US1-FED (https://app.ddog-gov.com)
- Description: Datadog site/region where your data will be sent

### Tracking Consent
- Type: `TrackingConsent`
- Required: No
- Default: `TrackingConsent.granted`
- Options:
  - `TrackingConsent.granted` - Full tracking enabled
  - `TrackingConsent.notGranted` - Tracking disabled
  - `TrackingConsent.pending` - Waiting for user consent
- Description: User's tracking consent status

## Environment-Specific Configuration

### Using Build Flavors

Create separate constant files for each environment:

```
lib/custom_code/
├── datadog_constants.dart (base)
├── datadog_constants_dev.dart
├── datadog_constants_staging.dart
└── datadog_constants_prod.dart
```

**datadog_constants_dev.dart:**
```dart
import 'package:datadog_flutter_plugin/datadog_flutter_plugin.dart';

class DatadogConstants {
  static const String clientToken = 'DEV_CLIENT_TOKEN';
  static const String applicationId = 'DEV_APPLICATION_ID';
  static const String env = 'dev';
  static const DatadogSite site = DatadogSite.us1;
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}
```

### Using Environment Variables

You can also use environment variables with `--dart-define`:

```dart
class DatadogConstants {
  static const String clientToken = String.fromEnvironment(
    'DATADOG_CLIENT_TOKEN',
    defaultValue: 'YOUR_CLIENT_TOKEN',
  );
  
  static const String applicationId = String.fromEnvironment(
    'DATADOG_APP_ID',
    defaultValue: 'YOUR_APPLICATION_ID',
  );
  
  static const String env = String.fromEnvironment(
    'DATADOG_ENV',
    defaultValue: 'prod',
  );
  
  // Note: Can't use fromEnvironment for enums, use string and convert
  static const DatadogSite site = DatadogSite.us1;
  static const TrackingConsent trackingConsent = TrackingConsent.granted;
}
```

Then run with:
```bash
flutter run --dart-define=DATADOG_CLIENT_TOKEN=your_token \
            --dart-define=DATADOG_APP_ID=your_app_id \
            --dart-define=DATADOG_ENV=dev
```

## Security Best Practices

✅ **DO**: Store client tokens in this constants file (they're safe for client-side use)  
✅ **DO**: Use different tokens for different environments  
✅ **DO**: Commit this file with placeholder values  
❌ **DON'T**: Store API keys or admin tokens here  
❌ **DON'T**: Use production tokens in development  

## After Configuration

Once you've updated the constants, initialize analytics:

```dart
import 'package:analytics_library/custom_code/analytics_locator.dart';

await AnalyticsLocator.ensureInitialized(enableDatadog: true);
await AnalyticsLocator.instance.initialize();
```

## Troubleshooting

### "Invalid client token" error
- Verify the client token is correct
- Ensure you copied the entire token without extra spaces
- Check that you're using a client token, not an API key

### Events not appearing
- Verify the application ID is correct
- Check that the site matches your Datadog account region
- Wait 2-5 minutes for events to propagate

### Build errors
- Run `flutter pub get`
- Verify import statements are correct
- Check that datadog_flutter_plugin is in pubspec.yaml

## Additional Resources

- [Datadog Documentation](https://docs.datadoghq.com/real_user_monitoring/mobile_and_tv_monitoring/flutter/)
- [Quick Start Guide](../../DATADOG_QUICKSTART.md)
- [Complete Setup Guide](../../DATADOG_SETUP.md)

