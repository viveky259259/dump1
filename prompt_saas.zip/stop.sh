#!/bin/bash

# PromptSaaS Stop Script
# This script stops the development server on port 4444

PORT=4444

echo "🛑 Stopping PromptSaaS Development Server"
echo "========================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if any process is using port 4444
if lsof -ti:$PORT > /dev/null 2>&1; then
    print_status "Found process(es) using port $PORT. Stopping them..."
    
    # Get PIDs using the port
    PIDS=$(lsof -ti:$PORT)
    
    for PID in $PIDS; do
        print_status "Stopping process $PID..."
        kill -TERM $PID 2>/dev/null || kill -9 $PID 2>/dev/null || true
    done
    
    # Wait a moment for processes to stop
    sleep 2
    
    # Verify port is free
    if lsof -ti:$PORT > /dev/null 2>&1; then
        print_warning "Some processes may still be running. Force killing..."
        lsof -ti:$PORT | xargs kill -9 2>/dev/null || true
        sleep 1
    fi
    
    if lsof -ti:$PORT > /dev/null 2>&1; then
        echo -e "${RED}[ERROR]${NC} Failed to stop all processes on port $PORT"
        exit 1
    else
        print_success "Development server stopped successfully"
    fi
else
    print_warning "No process found on port $PORT"
fi

echo ""
echo "✅ PromptSaaS development server has been stopped"
echo "   Run './dev.sh' to start it again"
