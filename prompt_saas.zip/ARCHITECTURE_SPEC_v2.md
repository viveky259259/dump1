# Architecture Specification: PromptSaaS System

**Type:** Architecture Specification  
**Version:** 2.0.0  
**Author:** Engineering Team  
**Created:** January 2025  
**Status:** Approved  

---

## Overview

This document defines the technical architecture for PromptSaaS, a full-stack SaaS application for managing AI prompts. The architecture prioritizes:
- **Clean Architecture**: Clear separation of concerns across layers
- **Scalability**: Modular design supporting future growth
- **Security**: Robust authentication and data protection
- **Performance**: Efficient data handling and caching
- **Maintainability**: Type-safe, well-structured codebase

## System Context

```
┌─────────────┐
│    User     │
└──────┬──────┘
       │
       │ HTTP/HTTPS
       ▼
┌─────────────────────────────────────────────┐
│           PromptSaaS System                  │
│                                              │
│  ┌────────────┐  ┌──────────────┐          │
│  │   Next.js  │  │  Firebase    │          │
│  │   Frontend │  │   Services   │          │
│  └────────────┘  └──────────────┘          │
│                                              │
│  ┌────────────┐  ┌──────────────┐          │
│  │   Clean    │  │   Gemini     │          │
│  │ Architecture│  │   AI API     │          │
│  └────────────┘  └──────────────┘          │
└─────────────────────────────────────────────┘
       │              │              │
       ▼              ▼              ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   Vercel    │  │ Firestore   │  │   Google    │
│   Hosting   │  │  Database   │  │   Gemini    │
└─────────────┘  └─────────────┘  └─────────────┘
```

## Components

### 1. Presentation Layer (`/app`, `/components`)
**Responsibility:** User interface and user interactions

**Key Abstractions:**
- **Pages**: Next.js App Router pages (`/app/dashboard`, `/app/auth`)
- **Components**: Reusable UI components (`/components/ui`)
- **Hooks**: Custom React hooks (`/lib/hooks`)

**Technology:**
- Next.js 14 with App Router
- React 18 with TypeScript
- Tailwind CSS for styling
- Radix UI for accessible components

**Key Files:**
```
app/
├── dashboard/page.tsx          # Main dashboard interface
├── auth/signin/page.tsx        # Authentication pages
├── auth/signup/page.tsx
├── landing/page.tsx            # Landing page
└── layout.tsx                  # Root layout

components/
├── ui/                         # Reusable UI components
│   ├── button.tsx
│   ├── card.tsx
│   ├── dialog.tsx
│   └── input.tsx
├── prompt-enhancement-dialog.tsx
└── providers/                  # Context providers
```

---

### 2. Application Layer (`/lib/services`, `/lib/hooks`)
**Responsibility:** Business logic and state management

**Key Abstractions:**
- **Services**: Business logic encapsulation
- **Custom Hooks**: React-specific application logic
- **State Management**: Global state handling

**Technology:**
- TypeScript for type safety
- Singleton pattern for services
- Observer pattern for state updates

**API:**
```typescript
// Authentication Service
class AuthService {
  private static instance: AuthService
  private authState: AuthState
  
  subscribe(listener: (state: AuthState) => void): () => void
  setUser(firebaseUser: User | null): void
  syncUserWithDatabase(firebaseUser: User): Promise<void>
  clearAuth(): void
}

// Prompt Service
class PromptService {
  private static instance: PromptService
  private prompts: Prompt[]
  
  subscribe(listener: (prompts: Prompt[]) => void): () => void
  async fetchPrompts(): Promise<Prompt[]>
  async createPrompt(data: CreatePromptData): Promise<Prompt>
  async updatePrompt(data: UpdatePromptData): Promise<Prompt>
  async deletePrompt(id: string): Promise<void>
  searchPrompts(query: string): Prompt[]
  filterByCategory(category: string): Prompt[]
}
```

**Key Files:**
```
lib/
├── services/
│   ├── auth.service.ts          # Authentication business logic
│   ├── prompt.service.ts        # Prompt management logic
│   └── firestore-prompt.service.ts # Firestore integration
├── hooks/
│   └── usePrompts.ts            # Custom React hooks
└── auth-context.tsx            # Authentication context
```

---

### 3. Domain Layer (`/lib/types`, `/lib/interfaces`)
**Responsibility:** Core business entities and contracts

**Key Abstractions:**
- **Entities**: Core business objects
- **Interfaces**: Contracts between layers
- **Types**: TypeScript type definitions

**Technology:**
- TypeScript interfaces
- Domain-driven design principles

**API:**
```typescript
// Core Entities
interface User {
  id: string
  email: string
  name: string
  photoURL?: string
  createdAt: Date
  updatedAt: Date
}

interface Prompt {
  id: string
  userId: string
  title: string
  description: string
  content: string
  category: string
  tags: string[]
  isPublic: boolean
  createdAt: Date
  updatedAt: Date
}

// Service Interfaces
interface PromptService {
  fetchPrompts(): Promise<Prompt[]>
  createPrompt(data: CreatePromptData): Promise<Prompt>
  updatePrompt(data: UpdatePromptData): Promise<Prompt>
  deletePrompt(id: string): Promise<void>
}

// Repository Interfaces
interface PromptRepository {
  getUserPrompts(userId: string): Promise<Prompt[]>
  createPrompt(data: CreatePromptData): Promise<Prompt>
  updatePrompt(id: string, data: UpdatePromptData): Promise<Prompt>
  deletePrompt(id: string): Promise<void>
}
```

---

### 4. Infrastructure Layer (`/lib/repositories`, `/lib/firebase`)
**Responsibility:** Data access and external service integration

**Key Abstractions:**
- **Repositories**: Data access abstraction
- **External APIs**: Third-party service integration
- **Database**: Data persistence layer

**Technology:**
- Firebase Firestore for data storage
- Firebase Auth for authentication
- Google Gemini API for AI enhancement

**API:**
```typescript
// User Repository
class UserRepository {
  private static instance: UserRepository
  
  private async verifyFirebaseToken(token: string)
  private extractToken(request: Request): string | null
  
  async upsertUser(request: Request): Promise<User>
  async getUserByEmail(email: string): Promise<User | null>
  async getUserById(id: string): Promise<User | null>
  async updateUser(id: string, data: UpdateUserData): Promise<User>
  async deleteUser(id: string): Promise<void>
}

// Prompt Repository
class PromptRepository {
  private static instance: PromptRepository
  
  private async verifyFirebaseToken(token: string)
  private async getUserFromToken(request: Request)
  
  async getUserPrompts(request: Request): Promise<Prompt[]>
  async getPromptById(request: Request, promptId: string): Promise<Prompt | null>
  async createPrompt(request: Request, data: CreatePromptData): Promise<Prompt>
  async updatePrompt(request: Request, promptId: string, data: UpdatePromptData): Promise<Prompt>
  async deletePrompt(request: Request, promptId: string): Promise<void>
  async searchPrompts(request: Request, query: string): Promise<Prompt[]>
  async getPromptsByCategory(request: Request, category: string): Promise<Prompt[]>
  async getPublicPrompts(): Promise<Prompt[]>
}
```

**Key Files:**
```
lib/
├── repositories/
│   ├── user.repository.ts       # User data access
│   └── prompt.repository.ts     # Prompt data access
├── firebase.ts                  # Firebase configuration
├── firebase-utils.ts            # Firebase utilities
├── gemini-service.ts           # Gemini AI integration
└── gemini-mock-service.ts      # Fallback service
```

---

## Data Flow

### Authentication Flow

```
User Action → Firebase Auth → Auth Service → Database Sync → UI Update
     ↓              ↓              ↓              ↓              ↓
Sign in with    Google OAuth   Update local   Upsert user   React to
Google button   validation      state          in Firestore  auth state
```

**Detailed Steps:**
1. User clicks "Sign in with Google"
2. Firebase Auth handles OAuth flow
3. AuthService receives Firebase user object
4. User data is synced to Firestore database
5. UI components react to authentication state changes

### Prompt Management Flow

```
User Action → Component → Hook → Service → Repository → Database → UI Update
     ↓           ↓         ↓        ↓          ↓           ↓          ↓
Create prompt  Form      usePrompts PromptService Repository Firestore  Dashboard
button click   submit    hook      singleton    singleton   database   refresh
```

**Detailed Steps:**
1. User submits prompt creation form
2. Component calls usePrompts hook
3. Hook calls PromptService method
4. Service calls Repository method
5. Repository performs Firestore operation
6. Service updates local state
7. Hook notifies components of changes
8. UI updates with new prompt

### AI Enhancement Flow

```
User Input → Enhancement Dialog → API Route → Gemini Service → AI Response → UI Update
     ↓              ↓               ↓             ↓              ↓              ↓
Simple idea    Form submission   POST request   Gemini API    Enhanced      Dialog with
text input     with validation   to /api/enhance  call        prompt        results
```

**Detailed Steps:**
1. User inputs simple prompt idea
2. Enhancement dialog validates input
3. API route receives enhancement request
4. Gemini service calls Google AI API
5. AI returns enhanced prompt structure
6. Dialog displays results for user review
7. User can accept/reject enhancement

---

## Technology Stack

### Frontend
- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI primitives
- **Icons**: Lucide React
- **State Management**: React Context + Custom Hooks

### Backend
- **Runtime**: Node.js 18+
- **Framework**: Next.js API Routes
- **Language**: TypeScript
- **Authentication**: Firebase Auth
- **Database**: Firebase Firestore
- **AI Integration**: Google Gemini API

### Development Tools
- **Package Manager**: npm
- **Linting**: ESLint
- **Formatting**: Prettier
- **Type Checking**: TypeScript compiler
- **Testing**: Jest (planned)

### Deployment
- **Hosting**: Vercel
- **Database**: Firebase Firestore
- **CDN**: Vercel Edge Network
- **Analytics**: Vercel Analytics
- **Monitoring**: Vercel Speed Insights

---

## File Structure

```
prompt-saas/
├── app/                        # Next.js App Router
│   ├── api/                    # API routes
│   │   ├── auth/              # Authentication endpoints
│   │   ├── prompts/           # Prompt management endpoints
│   │   └── enhance-prompt/    # AI enhancement endpoint
│   ├── auth/                  # Authentication pages
│   │   ├── signin/page.tsx
│   │   └── signup/page.tsx
│   ├── dashboard/page.tsx     # Main dashboard
│   ├── landing/page.tsx       # Landing page
│   ├── globals.css            # Global styles
│   ├── layout.tsx            # Root layout
│   └── page.tsx              # Home page
├── components/                # Reusable components
│   ├── ui/                   # UI component library
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── dialog.tsx
│   │   ├── input.tsx
│   │   ├── label.tsx
│   │   └── textarea.tsx
│   ├── prompt-enhancement-dialog.tsx
│   └── providers/             # Context providers
├── lib/                      # Core application logic
│   ├── services/             # Business logic services
│   │   ├── auth.service.ts
│   │   ├── prompt.service.ts
│   │   └── firestore-prompt.service.ts
│   ├── repositories/         # Data access layer
│   │   ├── user.repository.ts
│   │   └── prompt.repository.ts
│   ├── hooks/                # Custom React hooks
│   │   └── usePrompts.ts
│   ├── storage/              # Storage abstractions
│   │   └── in-memory-storage.ts
│   ├── auth-context.tsx      # Authentication context
│   ├── firebase.ts          # Firebase configuration
│   ├── firebase-utils.ts    # Firebase utilities
│   ├── gemini-service.ts    # Gemini AI service
│   ├── gemini-mock-service.ts # Fallback service
│   ├── demo-data.ts         # Sample data
│   └── utils.ts             # Utility functions
├── public/                   # Static assets
├── firebase.json            # Firebase configuration
├── firestore.rules         # Firestore security rules
├── firestore.indexes.json  # Firestore indexes
├── next.config.js          # Next.js configuration
├── tailwind.config.js       # Tailwind configuration
├── tsconfig.json           # TypeScript configuration
└── package.json            # Dependencies and scripts
```

---

## Configuration

### Environment Variables

```bash
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=your-api-key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your-sender-id
NEXT_PUBLIC_FIREBASE_APP_ID=your-app-id

# Gemini AI API
GEMINI_API_KEY=your-gemini-api-key

# NextAuth (optional)
NEXTAUTH_SECRET=your-secret
NEXTAUTH_URL=http://localhost:3000
```

### Firebase Configuration

```typescript
// lib/firebase.ts
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
```

### Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can only access their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Prompts are user-specific
    match /prompts/{promptId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.userId;
    }
  }
}
```

---

## Non-Functional Requirements

### Performance
- **Page Load Time**: < 2 seconds
- **API Response Time**: < 500ms
- **Time to Interactive**: < 3 seconds
- **Bundle Size**: < 1MB initial load

### Security
- **Authentication**: Firebase Auth with Google OAuth
- **Authorization**: Firestore security rules
- **Data Protection**: HTTPS enforcement
- **Input Validation**: Client and server-side validation

### Scalability
- **Database**: Firestore auto-scaling
- **Hosting**: Vercel edge network
- **CDN**: Global content delivery
- **Caching**: Service-level caching

### Reliability
- **Uptime**: 99.9% availability
- **Error Handling**: Comprehensive error boundaries
- **Fallback Mechanisms**: Mock services for AI features
- **Data Backup**: Firestore automatic backups

### Maintainability
- **Code Quality**: TypeScript strict mode
- **Architecture**: Clean Architecture principles
- **Testing**: Unit and integration tests (planned)
- **Documentation**: Comprehensive inline documentation

---

## Deployment Architecture

### Development Environment

```
Developer Machine → Local Development Server → Firebase Emulators → Local Database
```

### Production Environment

```
User → Vercel Edge Network → Next.js Application → Firebase Services → External APIs
```

### CI/CD Pipeline

```
GitHub Repository → Vercel Build → Firebase Deploy → Production Environment
```

---

## Monitoring and Observability

### Application Monitoring
- **Performance**: Vercel Speed Insights
- **Analytics**: Vercel Analytics
- **Errors**: Console error tracking
- **User Behavior**: Custom event tracking

### Infrastructure Monitoring
- **Database**: Firestore usage metrics
- **Authentication**: Firebase Auth analytics
- **API**: Request/response monitoring
- **Hosting**: Vercel deployment metrics

---

## Security Considerations

### Authentication Security
- **OAuth Flow**: Secure Google OAuth implementation
- **Token Management**: Automatic token refresh
- **Session Security**: Secure session handling
- **Logout**: Complete session cleanup

### Data Security
- **Encryption**: Firestore encryption at rest
- **Access Control**: Row-level security rules
- **Input Sanitization**: XSS prevention
- **CSRF Protection**: Built-in Next.js protection

### API Security
- **Rate Limiting**: API endpoint protection
- **Input Validation**: Request validation
- **Error Handling**: Secure error messages
- **CORS**: Proper cross-origin configuration

---

## Future Architecture Considerations

### Scalability Enhancements
- **Microservices**: Split into smaller services
- **Event Sourcing**: Event-driven architecture
- **Caching Layer**: Redis for distributed caching
- **Load Balancing**: Multiple server instances

### Feature Additions
- **Real-time Updates**: WebSocket integration
- **File Storage**: Firebase Storage integration
- **Advanced Analytics**: Custom analytics platform
- **Mobile App**: React Native application

### Technology Upgrades
- **GraphQL**: More flexible API layer
- **Serverless Functions**: Edge computing
- **Database Sharding**: Horizontal scaling
- **CDN Integration**: Advanced caching strategies

---

## Decision Log

### Decision 1: Next.js App Router over Pages Router
**Date:** 2025-01-01  
**Rationale:** App Router provides better performance, improved developer experience, and future-proof architecture.  
**Alternatives Considered:** Pages Router (legacy), Remix, SvelteKit

### Decision 2: Firebase over Custom Backend
**Rationale:** Firebase provides rapid development, built-in authentication, real-time database, and automatic scaling.  
**Trade-offs:** Vendor lock-in, limited customization

### Decision 3: Clean Architecture over MVC
**Rationale:** Clean Architecture provides better separation of concerns, testability, and maintainability.  
**Impact:** More complex initial setup, better long-term maintainability

### Decision 4: TypeScript over JavaScript
**Rationale:** TypeScript provides type safety, better IDE support, and reduced runtime errors.  
**Trade-offs:** Additional compilation step, steeper learning curve

### Decision 5: Tailwind CSS over Styled Components
**Rationale:** Tailwind provides utility-first approach, better performance, and consistent design system.  
**Trade-offs:** Larger CSS bundle, utility class learning curve

This architecture specification provides a comprehensive overview of the PromptSaaS system design and serves as the foundation for implementation and future enhancements.
