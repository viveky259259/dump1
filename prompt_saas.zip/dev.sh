#!/bin/bash

# PromptSaaS Development Server Script
# This script kills any process on port 4444 and starts the dev server

set -e  # Exit on any error

echo "🚀 PromptSaaS Development Server"
echo "================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

PORT=4444
PROJECT_DIR="/Users/vivekyadav/Documents/Projects/cursor/prompt_saas"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "package.json not found. Please run this script from the project root."
    exit 1
fi

print_status "Checking for processes on port $PORT..."

# Kill any process using port 4444
if lsof -ti:$PORT > /dev/null 2>&1; then
    print_warning "Found process(es) using port $PORT. Killing them..."
    
    # Get PIDs using the port
    PIDS=$(lsof -ti:$PORT)
    
    for PID in $PIDS; do
        print_status "Killing process $PID..."
        kill -9 $PID 2>/dev/null || true
    done
    
    # Wait a moment for the port to be released
    sleep 2
    
    # Verify port is free
    if lsof -ti:$PORT > /dev/null 2>&1; then
        print_error "Failed to kill process on port $PORT"
        exit 1
    else
        print_success "Port $PORT is now free"
    fi
else
    print_success "Port $PORT is available"
fi

print_status "Starting development server on port $PORT..."

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    print_warning "node_modules not found. Installing dependencies..."
    npm install
fi

# Check if .env.local exists
if [ ! -f ".env.local" ]; then
    print_warning ".env.local not found. Creating from template..."
    if [ -f "setup-env.sh" ]; then
        chmod +x setup-env.sh
        ./setup-env.sh
    else
        print_error "setup-env.sh not found. Please create .env.local manually."
        exit 1
    fi
fi

print_status "Environment setup complete"

# Start the development server
print_success "Starting Next.js development server..."
echo ""
echo "🌐 Server will be available at: http://localhost:$PORT"
echo "📱 Dashboard: http://localhost:$PORT/dashboard"
echo "🔐 Auth: http://localhost:$PORT/auth/signin"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Start the dev server
npm run dev:4444
