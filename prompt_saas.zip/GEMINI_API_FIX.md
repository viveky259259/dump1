# Gemini API Referrer Restriction Fix

## 🚨 **Error Description**
```
[403 Forbidden] Requests from referer <empty> are blocked.
API_KEY_HTTP_REFERRER_BLOCKED
```

## 🔍 **Root Cause**
The Gemini API key has HTTP referrer restrictions that block requests from localhost during development. This is a security feature in Google Cloud Console.

## 🛠️ **Solution: Update API Key Settings**

### **Method 1: Remove Referrer Restrictions (Recommended for Development)**

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/
   - Select your project: `family-hosehold-management-pro`

2. **Navigate to API Keys**
   - Go to "APIs & Services" → "Credentials"
   - Find your Gemini API key
   - Click on the key to edit

3. **Update Application Restrictions**
   - **Current**: "HTTP referrers (web sites)"
   - **Change to**: "None" (for development)
   - **Or add**: `http://localhost:*` and `https://localhost:*`

4. **Save Changes**
   - Click "Save"
   - Wait 5-10 minutes for changes to propagate

### **Method 2: Add Localhost to Referrer List**

1. **Keep HTTP referrer restrictions**
2. **Add these referrers:**
   ```
   http://localhost:*
   https://localhost:*
   http://127.0.0.1:*
   https://127.0.0.1:*
   ```
3. **Save changes**

### **Method 3: Create New API Key (Alternative)**

1. **Create new API key**
   - Go to "APIs & Services" → "Credentials"
   - Click "Create Credentials" → "API Key"

2. **Configure restrictions**
   - Set "Application restrictions" to "None"
   - Set "API restrictions" to "Restrict key" → Select "Generative Language API"

3. **Update environment variable**
   ```bash
   # Update .env.local with new key
   GEMINI_API_KEY="your-new-api-key-here"
   ```

## 🔧 **Immediate Workaround**

### **Option 1: Use Production Domain**
If you have a deployed version, test the API there instead of localhost.

### **Option 2: Mock Response (Development)**
I can create a mock enhancement service for development:

```typescript
// Mock enhancement for development
export async function enhancePromptMock(request: PromptEnhancementRequest): Promise<PromptEnhancementResponse> {
  return {
    title: `Enhanced: ${request.simplePrompt}`,
    description: 'AI-enhanced prompt for development',
    suggestedCategory: request.category || 'Development',
    suggestedTags: ['ai-enhanced', 'development', 'mock'],
    enhancedPrompt: `# ${request.simplePrompt}

## Project Overview
This is a comprehensive project based on your simple prompt: "${request.simplePrompt}"

## Functional Requirements
- Core functionality implementation
- User interface design
- Data management
- Performance optimization

## Technical Specifications
- Modern web technologies
- Responsive design
- Scalable architecture
- Security considerations

## Implementation Phases
1. Planning and design
2. Core development
3. Testing and optimization
4. Deployment and maintenance

## Success Metrics
- User engagement
- Performance benchmarks
- Feature completion
- User satisfaction

*This is a mock enhancement for development purposes.*`
  }
}
```

## 📋 **Step-by-Step Fix**

### **1. Access Google Cloud Console**
```
https://console.cloud.google.com/apis/credentials?project=family-hosehold-management-pro
```

### **2. Find Your API Key**
- Look for the key: `AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y`
- Click on it to edit

### **3. Update Restrictions**
- **Application restrictions**: Change to "None"
- **API restrictions**: Keep "Restrict key" → "Generative Language API"

### **4. Save and Test**
- Save changes
- Wait 5-10 minutes
- Test the API again

## 🧪 **Test the Fix**

### **Test Command**
```bash
curl -X POST 'http://localhost:4444/api/enhance-prompt' \
  -H 'Content-Type: application/json' \
  -d '{"simplePrompt":"I want to build chess app","category":"Development"}'
```

### **Expected Response**
```json
{
  "enhancedPrompt": "# Chess Application Development...",
  "title": "Chess Application Development",
  "description": "Comprehensive chess app development guide",
  "suggestedCategory": "Development",
  "suggestedTags": ["chess", "game", "development", "strategy"]
}
```

## 🔒 **Security Considerations**

### **For Development**
- Use "None" restrictions for localhost development
- Keep API key in environment variables
- Never commit API keys to version control

### **For Production**
- Set proper referrer restrictions
- Use domain-specific restrictions
- Monitor API usage
- Set usage quotas

## 🚀 **Alternative Solutions**

### **1. Use Different API Key for Development**
- Create separate keys for dev/prod
- Use different environment files

### **2. Proxy Requests**
- Set up a proxy server
- Route requests through allowed domain

### **3. Use Server-Side Only**
- Move Gemini calls to server-side
- Use Firebase Functions or Vercel API routes

## 📞 **Support**

If you need help:
1. Check Google Cloud Console documentation
2. Verify API key permissions
3. Test with different browsers
4. Check network connectivity

---

**The fix is simple: Update your Gemini API key restrictions in Google Cloud Console to allow localhost requests!** 🎉
