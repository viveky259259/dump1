#!/bin/bash

echo "Setting up environment variables for PromptSaaS..."

# Create .env.local file
cat > .env.local << EOF
# Firebase Configuration (Client-side - for authentication only)
NEXT_PUBLIC_FIREBASE_API_KEY="AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU"
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN="family-hosehold-management-pro.firebaseapp.com"
NEXT_PUBLIC_FIREBASE_PROJECT_ID="family-hosehold-management-pro"
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET="family-hosehold-management-pro.firebasestorage.app"
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID="963076663974"
NEXT_PUBLIC_FIREBASE_APP_ID="1:963076663974:web:b468c7e0a6669e19dca267"

# Gemini AI API
GEMINI_API_KEY="AIzaSyDZcDTVKf7R74kvLdGXbvvuvHJy1QQbflw"

# NextAuth (if using)
NEXTAUTH_SECRET="your-nextauth-secret-here"
NEXTAUTH_URL="http://localhost:3000"
EOF

echo "✅ Environment file created: .env.local"
echo "📝 You can now run: npm run dev"
echo "🌐 Visit: http://localhost:3000"
echo ""
echo "Note: The app will run with Firebase authentication enabled!"
