import { NextRequest, NextResponse } from 'next/server'
import { enhancePrompt } from '@/lib/gemini-service'
import { enhancePromptMock } from '@/lib/gemini-mock-service'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { simplePrompt, category } = body

    if (!simplePrompt || simplePrompt.trim().length === 0) {
      return NextResponse.json({ error: 'Simple prompt is required' }, { status: 400 })
    }

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json({ 
        error: 'Gemini API key not configured. Please add GEMINI_API_KEY to your environment variables.' 
      }, { status: 500 })
    }

    try {
      // Try the real Gemini API first
      const result = await enhancePrompt({
        simplePrompt: simplePrompt.trim(),
        category
      })
      return NextResponse.json(result)
    } catch (apiError) {
      console.warn('Gemini API failed, using mock service:', apiError)
      
      // If API fails due to referrer restrictions, use mock service
      if (apiError instanceof Error && 
          (apiError.message.includes('API_KEY_HTTP_REFERRER_BLOCKED') || 
           apiError.message.includes('403 Forbidden'))) {
        
        const mockResult = await enhancePromptMock({
          simplePrompt: simplePrompt.trim(),
          category
        })
        
        return NextResponse.json({
          ...mockResult,
          _mock: true,
          _message: 'Using mock service due to API key restrictions. Please update your Gemini API key settings.'
        })
      }
      
      // Re-throw other errors
      throw apiError
    }
  } catch (error) {
    console.error('Error in enhance-prompt API:', error)
    return NextResponse.json(
      { error: 'Failed to enhance prompt. Please try again.' }, 
      { status: 500 }
    )
  }
}
