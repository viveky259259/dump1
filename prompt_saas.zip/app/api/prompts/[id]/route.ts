import { NextRequest, NextResponse } from 'next/server'
import InMemoryPromptStorage from '@/lib/storage/in-memory-storage'

// Simple token validation (in production, you'd validate with Firebase Admin)
function validateToken(request: NextRequest): string | null {
  const authHeader = request.headers.get('authorization')
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null
  }
  
  const token = authHeader.substring(7)
  // For demo purposes, we'll accept any token
  // In production, you'd validate the Firebase token here
  return token ? 'demo-user-123' : null
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const storage = InMemoryPromptStorage.getInstance()
    const prompt = storage.getPromptById(params.id)
    
    if (!prompt) {
      return NextResponse.json({ error: 'Prompt not found' }, { status: 404 })
    }

    return NextResponse.json(prompt)
  } catch (error: any) {
    console.error('Error fetching prompt:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userId = validateToken(request) || 'demo-user-123'
    const body = await request.json()
    const { title, content, description, category, tags, isPublic } = body

    if (!title || !content) {
      return NextResponse.json({ error: 'Title and content are required' }, { status: 400 })
    }

    const storage = InMemoryPromptStorage.getInstance()
    const prompt = storage.updatePrompt(params.id, {
      title,
      content,
      description,
      category,
      tags: tags || [],
      isPublic: isPublic || false
    })

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt not found' }, { status: 404 })
    }

    return NextResponse.json(prompt)
  } catch (error: any) {
    console.error('Error updating prompt:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userId = validateToken(request) || 'demo-user-123'
    const storage = InMemoryPromptStorage.getInstance()
    const deleted = storage.deletePrompt(params.id)

    if (!deleted) {
      return NextResponse.json({ error: 'Prompt not found' }, { status: 404 })
    }

    return NextResponse.json({ message: 'Prompt deleted successfully' })
  } catch (error: any) {
    console.error('Error deleting prompt:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}