import { NextRequest, NextResponse } from 'next/server'
import InMemoryPromptStorage from '@/lib/storage/in-memory-storage'

// Simple token validation (in production, you'd validate with Firebase Admin)
function validateToken(request: NextRequest): string | null {
  const authHeader = request.headers.get('authorization')
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null
  }
  
  const token = authHeader.substring(7)
  // For demo purposes, we'll accept any token
  // In production, you'd validate the Firebase token here
  return token ? 'demo-user-123' : null
}

export async function GET(request: NextRequest) {
  try {
    const userId = validateToken(request) || 'demo-user-123'
    const storage = InMemoryPromptStorage.getInstance()
    const prompts = storage.getUserPrompts(userId)
    
    return NextResponse.json(prompts)
  } catch (error: any) {
    console.error('Error fetching prompts:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const userId = validateToken(request) || 'demo-user-123'
    const body = await request.json()
    const { title, content, description, category, tags, isPublic } = body

    if (!title || !content) {
      return NextResponse.json({ error: 'Title and content are required' }, { status: 400 })
    }

    const storage = InMemoryPromptStorage.getInstance()
    
    const prompt = storage.createPrompt(userId, {
      title,
      content,
      description,
      category,
      tags: tags || [],
      isPublic: isPublic || false
    })

    return NextResponse.json(prompt)
  } catch (error: any) {
    console.error('Error creating prompt:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
