import { redirect } from 'next/navigation'

export default function HomePage() {
  // Redirect to dashboard in demo mode by default
  redirect('/dashboard')
}
