'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { useAuth } from '@/lib/auth-context'
import { usePrompts } from '@/lib/hooks/usePrompts'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Plus, Search, Filter, Copy, Edit, Trash2, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react'
import { demoPrompts, demoUser, DemoPrompt } from '@/lib/demo-data'
import { PromptEnhancementDialog } from '@/components/prompt-enhancement-dialog'

interface Prompt {
  id: string
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
  createdAt: string
  updatedAt: string
}

function DashboardContent() {
  const { user, firebaseUser, loading, logout } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const isDemo = searchParams.get('demo') === 'true'
  const { prompts, loading: promptsLoading, createPrompt, deletePrompt, refreshPrompts } = usePrompts(isDemo)
  
  const [searchTerm, setSearchTerm] = useState('')
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [expandedPrompts, setExpandedPrompts] = useState<Set<string>>(new Set())
  const [newPrompt, setNewPrompt] = useState({
    title: '',
    content: '',
    description: '',
    category: '',
    tags: '',
    isPublic: false
  })

  useEffect(() => {
    // Only redirect to signin if not in demo mode and no user
    if (!loading && !user && !isDemo) {
      router.push('/auth/signin')
    }
  }, [loading, user, router, isDemo])

  const handleCreatePrompt = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      await createPrompt({
        title: newPrompt.title,
        content: newPrompt.content,
        description: newPrompt.description || null,
        category: newPrompt.category || null,
        tags: newPrompt.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
        isPublic: newPrompt.isPublic
      })

      // Reset form
      setNewPrompt({
        title: '',
        content: '',
        description: '',
        category: '',
        tags: '',
        isPublic: false
      })
      setShowCreateForm(false)
    } catch (error) {
      console.error('Error creating prompt:', error)
    }
  }

  const handleDeletePrompt = async (id: string) => {
    try {
      await deletePrompt(id)
    } catch (error) {
      console.error('Error deleting prompt:', error)
    }
  }

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const togglePromptExpansion = (promptId: string) => {
    setExpandedPrompts(prev => {
      const newSet = new Set(prev)
      if (newSet.has(promptId)) {
        newSet.delete(promptId)
      } else {
        newSet.add(promptId)
      }
      return newSet
    })
  }

  const isPromptExpanded = (promptId: string) => {
    return expandedPrompts.has(promptId)
  }

  const expandAllPrompts = () => {
    const allPromptIds = new Set(prompts.map(p => p.id))
    setExpandedPrompts(allPromptIds)
  }

  const collapseAllPrompts = () => {
    setExpandedPrompts(new Set())
  }

  const handleEnhancementComplete = (enhancedData: {
    title: string
    content: string
    description: string
    category: string
    tags: string[]
  }) => {
    setNewPrompt({
      title: enhancedData.title,
      content: enhancedData.content,
      description: enhancedData.description,
      category: enhancedData.category,
      tags: enhancedData.tags.join(', '),
      isPublic: false
    })
    setShowCreateForm(true)
  }

  const filteredPrompts = prompts.filter(prompt =>
    prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prompt.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prompt.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  if (loading || promptsLoading) {
    console.log('Dashboard: Loading state active:', { loading, promptsLoading, user: user?.email })
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
          <p className="mt-2 text-sm text-gray-500">
            Auth: {loading ? 'Loading' : 'Ready'} | Prompts: {promptsLoading ? 'Loading' : 'Ready'}
          </p>
        </div>
      </div>
    )
  }

  if (!user && !isDemo) {
    return null
  }

  const currentUser = isDemo ? demoUser : user
  
  // Debug: Log user data
  console.log('Dashboard: Current user data:', {
    isDemo,
    user: user ? { id: user.id, email: user.email, name: user.name, image: user.image } : null,
    currentUser: currentUser ? { id: currentUser.id, email: currentUser.email, name: currentUser.name } : null
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/landing" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg"></div>
            <span className="text-xl font-bold text-gray-900">PromptSaaS</span>
          </Link>
          <div className="flex items-center space-x-4">
            {isDemo && (
              <div className="flex items-center space-x-2 bg-yellow-50 border border-yellow-200 rounded-lg px-3 py-1">
                <AlertCircle className="w-4 h-4 text-yellow-600" />
                <span className="text-sm text-yellow-800 font-medium">Demo Mode</span>
              </div>
            )}
            {currentUser && (
              <div className="flex items-center space-x-3">
                {currentUser.image && (
                  <img 
                    src={currentUser.image} 
                    alt="User avatar" 
                    className="w-8 h-8 rounded-full"
                  />
                )}
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-gray-900">
                    {currentUser.name || 'User'}
                  </span>
                  <span className="text-xs text-gray-500">
                    {currentUser.email}
                  </span>
                </div>
              </div>
            )}
            {isDemo ? (
              <Link href="/auth/signin">
                <Button variant="outline">Sign In</Button>
              </Link>
            ) : (
              <Button variant="outline" onClick={logout}>
                Sign Out
              </Button>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Manage your AI prompts and boost your productivity</p>
          {isDemo && (
            <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-blue-800">🚀 Welcome to PromptSaaS Demo!</h3>
                  <p className="text-sm text-blue-700 mt-1">
                    You're exploring the full app with sample data. Try creating prompts, using AI enhancement, and exploring all features. 
                    <Link href="/auth/signup" className="ml-1 underline hover:no-underline font-medium">
                      Create a free account
                    </Link> to save your prompts permanently and unlock all features.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Prompts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{prompts.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Public Prompts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{prompts.filter(p => p.isPublic).length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{new Set(prompts.map(p => p.category).filter(Boolean)).size}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Tags</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{new Set(prompts.flatMap(p => p.tags)).size}</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Create */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search prompts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            {filteredPrompts.length > 0 && (
              <div className="flex gap-1">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={expandAllPrompts}
                  className="text-xs"
                >
                  <ChevronDown className="w-3 h-3 mr-1" />
                  Expand All
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={collapseAllPrompts}
                  className="text-xs"
                >
                  <ChevronUp className="w-3 h-3 mr-1" />
                  Collapse All
                </Button>
              </div>
            )}
            <PromptEnhancementDialog onEnhancementComplete={handleEnhancementComplete} />
            <Button onClick={() => setShowCreateForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Prompt
            </Button>
          </div>
        </div>

        {/* Create Prompt Form */}
        {showCreateForm && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Create New Prompt</CardTitle>
              <CardDescription>Add a new prompt to your collection</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreatePrompt} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      placeholder="Enter prompt title"
                      value={newPrompt.title}
                      onChange={(e) => setNewPrompt({ ...newPrompt, title: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      placeholder="e.g., Writing, Coding, Analysis"
                      value={newPrompt.category}
                      onChange={(e) => setNewPrompt({ ...newPrompt, category: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    placeholder="Brief description of the prompt"
                    value={newPrompt.description}
                    onChange={(e) => setNewPrompt({ ...newPrompt, description: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="content">Prompt Content</Label>
                  <Textarea
                    id="content"
                    placeholder="Enter your prompt content here..."
                    value={newPrompt.content}
                    onChange={(e) => setNewPrompt({ ...newPrompt, content: e.target.value })}
                    rows={6}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input
                    id="tags"
                    placeholder="tag1, tag2, tag3"
                    value={newPrompt.tags}
                    onChange={(e) => setNewPrompt({ ...newPrompt, tags: e.target.value })}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isPublic"
                    checked={newPrompt.isPublic}
                    onChange={(e) => setNewPrompt({ ...newPrompt, isPublic: e.target.checked })}
                    className="rounded"
                  />
                  <Label htmlFor="isPublic">Make this prompt public</Label>
                </div>
                <div className="flex space-x-2">
                  <Button type="submit">Create Prompt</Button>
                  <Button type="button" variant="outline" onClick={() => setShowCreateForm(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Prompts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPrompts.map((prompt) => (
            <Card key={prompt.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{prompt.title}</CardTitle>
                    {prompt.description && (
                      <CardDescription className="mt-1">{prompt.description}</CardDescription>
                    )}
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => copyToClipboard(prompt.content)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleDeletePrompt(prompt.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="relative">
                    <div className={`text-sm text-gray-600 bg-gray-50 p-3 rounded-lg transition-all duration-300 ${
                      isPromptExpanded(prompt.id) ? 'max-h-none' : 'max-h-20 overflow-hidden'
                    }`}>
                      {isPromptExpanded(prompt.id) ? prompt.content : (
                        prompt.content.length > 150 
                          ? `${prompt.content.substring(0, 150)}...` 
                          : prompt.content
                      )}
                    </div>
                    {!isPromptExpanded(prompt.id) && prompt.content.length > 150 && (
                      <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-gray-50 to-transparent pointer-events-none rounded-b-lg"></div>
                    )}
                    {prompt.content.length > 150 && (
                      <div className="flex justify-center mt-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => togglePromptExpansion(prompt.id)}
                          className="text-xs text-gray-500 hover:text-gray-700"
                        >
                          {isPromptExpanded(prompt.id) ? (
                            <>
                              <ChevronUp className="w-3 h-3 mr-1" />
                              Show Less
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-3 h-3 mr-1" />
                              Show More
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {prompt.category && (
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-medium text-gray-500">Category:</span>
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {prompt.category}
                      </span>
                    </div>
                  )}
                  
                  {prompt.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {prompt.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{prompt.isPublic ? 'Public' : 'Private'}</span>
                    <span>{new Date(prompt.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredPrompts.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Plus className="w-12 h-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No prompts found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm ? 'Try adjusting your search terms' : 'Create your first prompt to get started'}
            </p>
            {!searchTerm && (
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <PromptEnhancementDialog onEnhancementComplete={handleEnhancementComplete} />
                <Button onClick={() => setShowCreateForm(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Manually
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default function DashboardPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    }>
      <DashboardContent />
    </Suspense>
  )
}
