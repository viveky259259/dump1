import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { AuthProvider } from '@/lib/auth-context'
import { Analytics } from '@vercel/analytics/react'
import { SpeedInsights } from '@vercel/speed-insights/next'
import VersionFooter from '@/components/version-footer'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'PromptSaaS - AI Prompt Management Platform',
  description: 'Manage, organize, and share your AI prompts with ease',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          <main className="flex-1">
            <AuthProvider>
              {children}
            </AuthProvider>
          </main>
          <VersionFooter />
        </div>
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  )
}
