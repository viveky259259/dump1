#!/bin/bash

echo "🚀 PromptSaaS Deployment Script"
echo "================================"
echo "📊 Database: Firestore (NoSQL)"
echo "🔧 Backend: Next.js API Routes"
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the project root."
    exit 1
fi

# Check if service account key exists
if [ ! -f ".firebase-keys/family-hosehold-management-pro-firebase-adminsdk-fbsvc-b4cf91b44c.json" ]; then
    echo "❌ Error: Service account key not found in .firebase-keys/"
    echo "Please ensure the Firebase service account key is in the .firebase-keys/ directory"
    exit 1
fi

echo "✅ Service account key found and secured"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the project
echo "🔨 Building the project..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Build failed. Please fix the errors and try again."
    exit 1
fi

echo "✅ Build successful"

# Check if .next directory exists (for Next.js build)
if [ -d ".next" ]; then
    echo "✅ Next.js build found in '.next' directory"
else
    echo "❌ Error: '.next' directory not found. Build may have failed."
    exit 1
fi

# Ask user for deployment method
echo ""
echo "Choose deployment method:"
echo "1) Vercel (Recommended for Next.js with API routes - Full functionality)"
echo "2) Firebase Hosting (Static site only - API routes will NOT work)"
echo ""
echo "⚠️  Note: Your app has API routes in app/api/. Firebase Hosting will not support these."
echo "   Choose Vercel for full functionality or remove API routes for Firebase Hosting."
echo ""
read -p "Enter your choice (1 or 2): " choice

case $choice in
    1)
        echo "🚀 Deploying to Vercel..."
        if ! command -v vercel &> /dev/null; then
            echo "📦 Installing Vercel CLI..."
            npm install -g vercel
        fi
        vercel --prod
        ;;
    2)
        echo "🚀 Deploying to Firebase Hosting..."
        if ! command -v firebase &> /dev/null; then
            echo "❌ Firebase CLI not found. Please install it first."
            exit 1
        fi
        firebase deploy --only hosting
        ;;
    *)
        echo "❌ Invalid choice. Please run the script again."
        exit 1
        ;;
esac

echo ""
echo "🎉 Deployment completed!"
echo ""
echo "📝 Next steps:"
echo "1. Test your deployed application"
echo "2. Verify authentication works"
echo "3. Test API routes (if using Vercel)"
echo "4. Configure custom domain if needed"
echo ""
echo "🔒 Security reminder:"
echo "- Service account key is secured in .firebase-keys/"
echo "- Never commit .firebase-keys/ to version control"
echo "- Set environment variables in your hosting platform"
