#!/bin/bash

echo "🔐 Setting up Vercel Environment Variables for PromptSaaS"
echo "========================================================"
echo ""

# Check if we're logged into Vercel
if ! vercel whoami &> /dev/null; then
    echo "❌ Please login to Vercel first: vercel login"
    exit 1
fi

echo "✅ Logged into Vercel as: $(vercel whoami)"
echo ""

# Function to add environment variable
add_env_var() {
    local var_name="$1"
    local var_value="$2"
    local description="$3"
    
    echo "Adding $var_name..."
    echo "$var_value" | vercel env add "$var_name" --scope production,preview,development
    echo "✅ $description"
    echo ""
}

echo "📝 Adding Firebase Configuration Variables..."
echo "--------------------------------------------"

add_env_var "NEXT_PUBLIC_FIREBASE_API_KEY" "AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU" "Firebase API Key"
add_env_var "NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN" "family-hosehold-management-pro.firebaseapp.com" "Firebase Auth Domain"
add_env_var "NEXT_PUBLIC_FIREBASE_PROJECT_ID" "family-hosehold-management-pro" "Firebase Project ID"
add_env_var "NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET" "family-hosehold-management-pro.firebasestorage.app" "Firebase Storage Bucket"
add_env_var "NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID" "963076663974" "Firebase Messaging Sender ID"
add_env_var "NEXT_PUBLIC_FIREBASE_APP_ID" "1:963076663974:web:b468c7e0a6669e19dca267" "Firebase App ID"

echo "🤖 Adding AI Configuration Variables..."
echo "---------------------------------------"

add_env_var "GEMINI_API_KEY" "AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y" "Gemini AI API Key"

echo "🔑 Adding NextAuth Configuration Variables..."
echo "---------------------------------------------"

add_env_var "NEXTAUTH_SECRET" "promptsaas-secret-key-$(date +%s)" "NextAuth Secret"
add_env_var "NEXTAUTH_URL" "https://promptsaas.vercel.app" "NextAuth URL"

echo "🎉 Environment Variables Setup Complete!"
echo "=========================================="
echo ""
echo "📋 Next Steps:"
echo "1. Verify variables: vercel env ls"
echo "2. Redeploy app: vercel --prod"
echo "3. Test authentication and AI features"
echo ""
echo "🔗 Dashboard: https://vercel.com/vivek-yadavs-projects-61bbeef1/prompt_saas/settings/environment-variables"
