# PromptSaaS - AI Prompt Management Platform

A modern, full-stack SaaS application for managing AI prompts with a beautiful UI and powerful features.

## Features

- 🔐 **Firebase Authentication** - Secure sign-in with Google
- 📝 **Prompt Management** - Create, edit, delete, and organize prompts
- 🤖 **AI Enhancement** - Transform simple ideas into comprehensive prompts using Gemini AI
- 🏷️ **Categorization** - Organize prompts with categories and tags
- 🔍 **Search & Filter** - Find prompts quickly with powerful search
- 📊 **Dashboard** - Beautiful analytics and overview
- 🌐 **Public Sharing** - Share prompts publicly or keep them private
- 🚀 **Demo Mode** - Try the app immediately with sample data
- 📱 **Responsive Design** - Works perfectly on all devices
- ⚡ **Modern Stack** - Built with Next.js 14, TypeScript, and Tailwind CSS

## Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes with in-memory storage
- **Authentication**: Firebase Auth (Google Sign-in)
- **AI Integration**: Google Gemini API for prompt enhancement
- **UI Components**: Radix UI, Lucide React
- **Styling**: Tailwind CSS with custom design system
- **Analytics**: Vercel Analytics and Speed Insights

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd prompt-saas
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   # Quick setup (recommended)
   ./setup-env.sh
   
   # Or manually copy and edit
   cp env.example .env.local
   ```
   
   The setup script creates `.env.local` with:
   ```env
   # Gemini AI API
   GEMINI_API_KEY="your-gemini-api-key-here"
   
   # NextAuth (if using)
   NEXTAUTH_SECRET="your-nextauth-secret-here"
   NEXTAUTH_URL="http://localhost:3000"
   ```

4. **Run the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)
   
   The app will automatically start in **Demo Mode** with sample data, so you can explore all features immediately without any setup!

## Project Structure

```
prompt-saas/
├── app/                    # Next.js 13+ app directory
│   ├── api/               # API routes
│   │   ├── auth/          # Authentication endpoints
│   │   └── prompts/       # Prompt management endpoints
│   ├── auth/              # Authentication pages
│   ├── dashboard/         # Dashboard page
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   └── page.tsx           # Home page
├── components/            # Reusable components
│   ├── ui/               # UI components (Button, Card, etc.)
│   └── providers/        # Context providers
├── lib/                  # Utility functions
│   ├── auth.ts           # NextAuth configuration
│   ├── prisma.ts         # Prisma client
│   └── utils.ts          # Utility functions
├── prisma/               # Database schema
│   └── schema.prisma     # Prisma schema
└── public/               # Static assets
```

## Database Schema

The application uses the following main entities:

- **User** - User accounts with authentication
- **Prompt** - AI prompts with metadata
- **Account/Session** - NextAuth.js authentication tables

## API Endpoints

### Authentication
- `POST /api/auth/signin` - Sign in
- `POST /api/auth/signout` - Sign out
- `GET /api/auth/session` - Get current session

### Prompts
- `GET /api/prompts` - Get user's prompts
- `POST /api/prompts` - Create new prompt
- `GET /api/prompts/[id]` - Get specific prompt
- `PUT /api/prompts/[id]` - Update prompt
- `DELETE /api/prompts/[id]` - Delete prompt

### AI Enhancement
- `POST /api/enhance-prompt` - Enhance simple prompts using Gemini AI

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Set environment variables in Vercel dashboard
4. Deploy!

### Other Platforms

The app can be deployed to any platform that supports Next.js:
- Railway
- Render
- DigitalOcean App Platform
- AWS Amplify

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

If you have any questions or need help, please open an issue on GitHub.



KEYS::

# Firebase Configuration
vercel env add NEXT_PUBLIC_FIREBASE_API_KEY production
# Enter: AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU

vercel env add NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN production
# Enter: family-hosehold-management-pro.firebaseapp.com

vercel env add NEXT_PUBLIC_FIREBASE_PROJECT_ID production
# Enter: family-hosehold-management-pro

vercel env add NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET production
# Enter: family-hosehold-management-pro.firebasestorage.app

vercel env add NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID production
# Enter: 963076663974

vercel env add NEXT_PUBLIC_FIREBASE_APP_ID production
# Enter: 1:963076663974:web:b468c7e0a6669e19dca267

# Gemini AI API
vercel env add GEMINI_API_KEY production
# Enter: AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y

# NextAuth
vercel env add NEXTAUTH_SECRET production
# Enter: your-secure-random-string-here

vercel env add NEXTAUTH_URL production
# Enter: https://promptsaas.vercel.app