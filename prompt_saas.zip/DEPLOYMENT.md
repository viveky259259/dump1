# Deployment Guide

## Prerequisites

1. **Firebase CLI**: Already installed
2. **Firebase Project**: `family-hosehold-management-pro`
3. **Service Account Key**: Secured in `.firebase-keys/` directory
4. **Database**: Firestore (NoSQL) - configured and ready

## Deployment Options

### Option 1: Vercel (Recommended)
**Best for**: Full-stack Next.js apps with API routes and Firestore integration

1. **Install Vercel CLI**:
   ```bash
   npm install -g vercel
   ```

2. **Deploy to Vercel**:
   ```bash
   vercel --prod
   ```

3. **Set Environment Variables** in Vercel Dashboard:
   - `FIREBASE_PROJECT_ID`: `family-hosehold-management-pro`
   - `FIREBASE_CLIENT_EMAIL`: From your service account key
   - `FIREBASE_PRIVATE_KEY`: From your service account key
   - `NEXT_PUBLIC_FIREBASE_API_KEY`: From Firebase project settings
   - `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`: `family-hosehold-management-pro.firebaseapp.com`
   - `NEXT_PUBLIC_FIREBASE_PROJECT_ID`: `family-hosehold-management-pro`
   - `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`: `family-hosehold-management-pro.firebasestorage.app`
   - `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`: `963076663974`
   - `NEXT_PUBLIC_FIREBASE_APP_ID`: `1:963076663974:web:b468c7e0a6669e19dca267`

### Option 2: Firebase Hosting (Static Only)
**Note**: This will disable API routes and server-side functionality.

1. **Enable static export** in `next.config.js`:
   ```javascript
   const nextConfig = {
     output: 'export',
     trailingSlash: true,
     images: { unoptimized: true }
   }
   ```

2. **Build and deploy**:
   ```bash
   npm run build
   firebase deploy --only hosting
   ```

### Option 3: Firebase Functions + Hosting
**Advanced**: Full Firebase integration with server-side functions.

1. **Install Firebase Functions**:
   ```bash
   npm install firebase-functions
   ```

2. **Configure for Functions** (requires additional setup)

## Security Notes

- ✅ Service account key moved to `.firebase-keys/` directory
- ✅ Added `.firebase-keys/` to `.gitignore`
- ✅ Never commit service account keys to version control

## Environment Variables

For production deployment, set these environment variables:

```bash
# Firebase Client Configuration (Public)
NEXT_PUBLIC_FIREBASE_API_KEY="AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU"
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN="family-hosehold-management-pro.firebaseapp.com"
NEXT_PUBLIC_FIREBASE_PROJECT_ID="family-hosehold-management-pro"
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET="family-hosehold-management-pro.firebasestorage.app"
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID="963076663974"
NEXT_PUBLIC_FIREBASE_APP_ID="1:963076663974:web:b468c7e0a6669e19dca267"

# Firebase Admin Configuration (Server-side only)
FIREBASE_PROJECT_ID="family-hosehold-management-pro"
FIREBASE_CLIENT_EMAIL="firebase-adminsdk-fbsvc@family-hosehold-management-pro.iam.gserviceaccount.com"
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n[YOUR_PRIVATE_KEY_HERE]\n-----END PRIVATE KEY-----"

# Gemini AI API
GEMINI_API_KEY="AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y"
```

## Quick Deploy Commands

### Firebase Hosting (Static)
```bash
npm run build
firebase deploy --only hosting
```

### Vercel (Full Next.js)
```bash
vercel --prod
```

## Post-Deployment

1. **Test Authentication**: Verify Google sign-in works
2. **Test API Routes**: Check if prompts API works
3. **Test Database**: Verify user creation and prompt storage
4. **Update Domain**: Configure custom domain if needed
