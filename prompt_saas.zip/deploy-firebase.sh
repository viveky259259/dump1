#!/bin/bash

# PromptSaaS Firebase Deployment Script
# This script builds and deploys the app to Firebase Hosting

set -e  # Exit on any error

echo "🔥 PromptSaaS Firebase Deployment"
echo "================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "package.json not found. Please run this script from the project root."
    exit 1
fi

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    print_warning "Firebase CLI not found. Installing..."
    npm install -g firebase-tools
fi

# Check if user is logged in to Firebase
if ! firebase projects:list &> /dev/null; then
    print_warning "Not logged in to Firebase. Please login first:"
    echo "firebase login"
    exit 1
fi

print_status "Building Next.js app for Firebase..."

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    print_status "Installing dependencies..."
    npm install
fi

# Build the app for Firebase
print_status "Building static export..."
npm run build:firebase

if [ ! -d "out" ]; then
    print_error "Build failed - 'out' directory not found"
    exit 1
fi

print_success "Build completed successfully"

# Deploy to Firebase
print_status "Deploying to Firebase Hosting..."

if firebase deploy --only hosting; then
    print_success "Deployment completed successfully!"
    echo ""
    echo "🌐 Your app is now live at:"
    firebase hosting:sites:list --json | grep -o '"url":"[^"]*"' | head -1 | cut -d'"' -f4
    echo ""
    echo "📱 Firebase Console: https://console.firebase.google.com/"
else
    print_error "Deployment failed"
    exit 1
fi

echo ""
echo "✅ Firebase deployment complete!"
echo "   Run 'firebase serve' to test locally"
echo "   Run 'firebase deploy' to deploy all services"
