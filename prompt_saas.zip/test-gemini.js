const { GoogleGenerativeAI } = require('@google/generative-ai');

async function testGemini() {
  try {
    console.log('Testing Gemini API...');
    
    const apiKey = process.env.GEMINI_API_KEY || 'AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y';
    console.log('API Key:', apiKey ? 'Present' : 'Missing');
    
    if (!apiKey) {
      throw new Error('Gemini API key not found');
    }
    
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    const prompt = 'Test prompt: "I want to build chess app"';
    console.log('Sending prompt:', prompt);
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log('Response:', text);
    console.log('Success!');
    
  } catch (error) {
    console.error('Error:', error.message);
    console.error('Full error:', error);
  }
}

testGemini();
