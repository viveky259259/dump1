/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['lh3.googleusercontent.com']
  },
  webpack: (config, { isServer }) => {
    if (!isServer) {
      // Exclude Firebase Admin SDK from client-side bundle
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        net: false,
        http2: false,
        crypto: false,
        stream: false,
        util: false,
        url: false,
        assert: false,
        os: false,
        path: false,
        child_process: false,
      }
    }
    return config
  }
}

module.exports = nextConfig
