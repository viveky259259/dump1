@echo off
REM PromptSaaS Development Server Script for Windows
REM This script kills any process on port 4444 and starts the dev server

echo 🚀 PromptSaaS Development Server
echo =================================
echo.

set PORT=4444

REM Check if package.json exists
if not exist "package.json" (
    echo [ERROR] package.json not found. Please run this script from the project root.
    pause
    exit /b 1
)

echo [INFO] Checking for processes on port %PORT%...

REM Kill any process using port 4444
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :%PORT%') do (
    echo [INFO] Killing process %%a...
    taskkill /PID %%a /F >nul 2>&1
)

REM Wait a moment
timeout /t 2 /nobreak >nul

echo [SUCCESS] Port %PORT% is now free

REM Check if node_modules exists
if not exist "node_modules" (
    echo [WARNING] node_modules not found. Installing dependencies...
    npm install
)

REM Check if .env.local exists
if not exist ".env.local" (
    echo [WARNING] .env.local not found. Please create it manually or run setup-env.sh
)

echo [SUCCESS] Starting Next.js development server...
echo.
echo 🌐 Server will be available at: http://localhost:%PORT%
echo 📱 Dashboard: http://localhost:%PORT%/dashboard
echo 🔐 Auth: http://localhost:%PORT%/auth/signin
echo.
echo Press Ctrl+C to stop the server
echo.

REM Start the dev server
npm run dev:4444

pause
