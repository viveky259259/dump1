# Development Scripts

This directory contains scripts to help you run the PromptSaaS application locally with automatic port cleanup.

## 🚀 Quick Start

### **Start Development Server**
```bash
# Method 1: Using the script directly
./dev.sh

# Method 2: Using npm script
npm run dev:clean
```

### **Stop Development Server**
```bash
# Method 1: Using the script directly
./stop.sh

# Method 2: Using npm script
npm run stop
```

## 📋 Available Scripts

| Script | Command | Description |
|--------|---------|-------------|
| `dev.sh` | `./dev.sh` | **Smart dev server** - Kills port 4444 first, then starts |
| `stop.sh` | `./stop.sh` | **Stop dev server** - Gracefully stops all processes on port 4444 |
| `dev.bat` | `dev.bat` | **Windows version** of dev.sh |
| `npm run dev:clean` | `npm run dev:clean` | **NPM wrapper** for dev.sh |
| `npm run stop` | `npm run stop` | **NPM wrapper** for stop.sh |

## 🔧 What the Scripts Do

### **dev.sh Features:**
- ✅ **Port Cleanup** - Automatically kills any process on port 4444
- ✅ **Dependency Check** - Installs node_modules if missing
- ✅ **Environment Setup** - Creates .env.local if missing
- ✅ **Colored Output** - Beautiful terminal output with status messages
- ✅ **Error Handling** - Graceful error handling and recovery
- ✅ **Cross-Platform** - Works on macOS and Linux

### **stop.sh Features:**
- ✅ **Graceful Shutdown** - Tries TERM signal first, then KILL
- ✅ **Process Detection** - Finds and stops all processes on port 4444
- ✅ **Status Feedback** - Clear success/error messages
- ✅ **Safety Checks** - Verifies processes are actually stopped

## 🌐 Access Points

Once the server is running, you can access:

- **Main App**: http://localhost:4444
- **Dashboard**: http://localhost:4444/dashboard
- **Sign In**: http://localhost:4444/auth/signin
- **Sign Up**: http://localhost:4444/auth/signup
- **Landing**: http://localhost:4444/landing

## 🛠️ Manual Commands

If you prefer to run commands manually:

```bash
# Kill processes on port 4444
lsof -ti:4444 | xargs kill -9

# Start dev server
npm run dev:4444

# Or use the direct Next.js command
next dev -p 4444
```

## 🔍 Troubleshooting

### **Port Already in Use**
```bash
# The dev.sh script handles this automatically, but if you need to manually:
lsof -ti:4444 | xargs kill -9
```

### **Permission Denied**
```bash
# Make scripts executable
chmod +x dev.sh stop.sh
```

### **Environment Variables Missing**
```bash
# Run the setup script
./setup-env.sh
```

### **Dependencies Missing**
```bash
# Install dependencies
npm install
```

## 📱 Platform Support

- **✅ macOS** - Full support with dev.sh
- **✅ Linux** - Full support with dev.sh  
- **✅ Windows** - Use dev.bat or WSL with dev.sh
- **✅ Cross-Platform** - npm scripts work everywhere

## 🎯 Pro Tips

1. **Always use `./dev.sh`** - It handles port conflicts automatically
2. **Use `./stop.sh`** - Cleaner shutdown than Ctrl+C
3. **Check the terminal output** - Scripts provide helpful status messages
4. **Keep scripts in project root** - They expect to be run from there
5. **Use npm scripts** - They're cross-platform compatible

## 🔗 Related Files

- `package.json` - Contains npm script definitions
- `setup-env.sh` - Environment variable setup
- `.env.local` - Local environment variables (created by setup)
- `next.config.js` - Next.js configuration

---

**Happy coding! 🚀**
