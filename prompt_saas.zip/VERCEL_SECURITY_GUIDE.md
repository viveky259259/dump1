# Vercel Environment Variables Setup Guide

## 🔐 Secure Key Storage Methods

### Method 1: Vercel Dashboard (Recommended)
1. Go to: https://vercel.com/vivek-yadavs-projects-61bbeef1/prompt_saas/settings/environment-variables
2. Click "Add New" for each variable
3. Set environment scope (Production, Preview, Development)

### Method 2: Vercel CLI
```bash
# Add variables one by one
vercel env add GEMINI_API_KEY
vercel env add NEXTAUTH_SECRET
vercel env add NEXTAUTH_URL

# List all variables
vercel env ls

# Pull to local file
vercel env pull .env.local
```

### Method 3: Bulk Setup Script
```bash
# Create setup script
cat > setup-vercel-env.sh << 'EOF'
#!/bin/bash
echo "Setting up Vercel environment variables..."

# Add all required variables
vercel env add GEMINI_API_KEY
vercel env add NEXTAUTH_SECRET
vercel env add NEXTAUTH_URL

echo "Environment variables setup complete!"
EOF

chmod +x setup-vercel-env.sh
./setup-vercel-env.sh
```

## 🛡️ Security Best Practices

### ✅ DO:
- Use environment variables for all secrets
- Use different values for different environments
- Rotate keys regularly
- Use strong, unique secrets

### ❌ DON'T:
- Hardcode secrets in code
- Commit .env files to git
- Share secrets in chat/email
- Use the same secret for multiple purposes
- Store secrets in client-side code

## 🔍 Variable Types

### Server-Side Variables (Keep secret)
- GEMINI_API_KEY
- NEXTAUTH_SECRET
- NEXTAUTH_URL

## 🚀 Deployment
After setting environment variables:
1. Redeploy your app: `vercel --prod`
2. Variables are automatically injected at build time
3. Access in code: `process.env.VARIABLE_NAME`