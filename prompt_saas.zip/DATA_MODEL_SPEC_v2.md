# Data Model Specification: PromptSaaS System

**Type:** Data Model Specification  
**Version:** 2.0.0  
**Author:** Engineering Team  
**Created:** January 2025  
**Status:** Approved  

---

## Overview

This document defines the data models, schemas, and data flow for the PromptSaaS application. The data architecture supports user authentication, prompt management, AI enhancement, and secure data isolation using Firebase Firestore.

## Core Data Models

### User Entity

**Purpose:** Represents authenticated users in the system

```typescript
interface User {
  id: string                    // Firebase Auth UID
  email: string                 // User's email address
  name: string                  // Display name
  photoURL?: string            // Profile picture URL
  createdAt: Date              // Account creation timestamp
  updatedAt: Date              // Last update timestamp
  lastLoginAt?: Date           // Last login timestamp
  isActive: boolean            // Account status
}
```

**Firestore Collection:** `users`

**Document Structure:**
```json
{
  "id": "firebase-auth-uid",
  "email": "user@example.com",
  "name": "John Doe",
  "photoURL": "https://lh3.googleusercontent.com/...",
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-01-01T00:00:00Z",
  "lastLoginAt": "2025-01-01T00:00:00Z",
  "isActive": true
}
```

**Constraints:**
- `id` must match Firebase Auth UID
- `email` must be valid email format
- `name` is required and non-empty
- `createdAt` and `updatedAt` are automatically managed

---

### Prompt Entity

**Purpose:** Represents AI prompts created by users

```typescript
interface Prompt {
  id: string                   // Unique prompt identifier
  userId: string              // Owner's Firebase Auth UID
  title: string               // Prompt title
  description: string         // Brief description
  content: string             // Full prompt content
  category: PromptCategory    // Predefined category
  tags: string[]              // User-defined tags
  isPublic: boolean           // Public/private visibility
  createdAt: Date            // Creation timestamp
  updatedAt: Date            // Last modification timestamp
  version: number             // Version number for tracking
  metadata: PromptMetadata    // Additional metadata
}

type PromptCategory = 
  | 'Development'
  | 'Writing'
  | 'Analytics'
  | 'Communication'
  | 'Marketing'
  | 'Productivity'
  | 'Design'
  | 'Research'
  | 'Education'
  | 'Other'

interface PromptMetadata {
  wordCount: number           // Content word count
  characterCount: number      // Content character count
  isEnhanced: boolean         // AI-enhanced flag
  enhancementSource?: string  // Source of enhancement
  lastAccessedAt?: Date       // Last access timestamp
  accessCount: number         // Number of times accessed
}
```

**Firestore Collection:** `prompts`

**Document Structure:**
```json
{
  "id": "prompt-uuid",
  "userId": "firebase-auth-uid",
  "title": "E-commerce Website Development",
  "description": "Comprehensive prompt for building an e-commerce platform",
  "content": "# E-commerce Website Development\n\n## Project Overview\n...",
  "category": "Development",
  "tags": ["ecommerce", "web-development", "react", "nodejs"],
  "isPublic": false,
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-01-01T00:00:00Z",
  "version": 1,
  "metadata": {
    "wordCount": 1250,
    "characterCount": 7500,
    "isEnhanced": true,
    "enhancementSource": "gemini-api",
    "lastAccessedAt": "2025-01-01T00:00:00Z",
    "accessCount": 5
  }
}
```

**Constraints:**
- `userId` must reference existing user
- `title` is required and max 200 characters
- `content` is required and max 50,000 characters
- `category` must be from predefined list
- `tags` array max 10 items, each max 50 characters
- `isPublic` defaults to false

---

### Enhancement Request Entity

**Purpose:** Tracks AI enhancement requests and responses

```typescript
interface EnhancementRequest {
  id: string                   // Unique request identifier
  userId: string              // Requesting user's UID
  originalPrompt: string       // Original simple prompt
  enhancedPrompt: string       // AI-generated enhanced prompt
  suggestedTitle: string       // AI-suggested title
  suggestedDescription: string // AI-suggested description
  suggestedCategory: string    // AI-suggested category
  suggestedTags: string[]      // AI-suggested tags
  status: EnhancementStatus    // Request status
  createdAt: Date            // Request timestamp
  completedAt?: Date         // Completion timestamp
  errorMessage?: string      // Error details if failed
  metadata: EnhancementMetadata // Additional metadata
}

type EnhancementStatus = 
  | 'pending'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled'

interface EnhancementMetadata {
  apiProvider: string         // AI service used
  modelVersion: string        // AI model version
  processingTimeMs: number    // Processing duration
  tokenCount: number          // Tokens used
  cost: number               // API cost (if applicable)
}
```

**Firestore Collection:** `enhancement_requests`

**Document Structure:**
```json
{
  "id": "enhancement-uuid",
  "userId": "firebase-auth-uid",
  "originalPrompt": "Build a todo app",
  "enhancedPrompt": "# Todo Application Development\n\n## Project Overview\n...",
  "suggestedTitle": "Modern Todo Application with React",
  "suggestedDescription": "A comprehensive todo app with advanced features",
  "suggestedCategory": "Development",
  "suggestedTags": ["react", "todo", "productivity", "web-app"],
  "status": "completed",
  "createdAt": "2025-01-01T00:00:00Z",
  "completedAt": "2025-01-01T00:00:05Z",
  "metadata": {
    "apiProvider": "gemini",
    "modelVersion": "gemini-2.0-flash",
    "processingTimeMs": 2500,
    "tokenCount": 1500,
    "cost": 0.001
  }
}
```

---

### Demo Data Entity

**Purpose:** Sample data for demo mode

```typescript
interface DemoPrompt {
  id: string
  title: string
  description: string
  content: string
  category: PromptCategory
  tags: string[]
  isPublic: boolean
  createdAt: Date
  metadata: PromptMetadata
}
```

**Storage:** In-memory during demo mode

**Sample Data:**
```typescript
const demoPrompts: DemoPrompt[] = [
  {
    id: "demo-1",
    title: "E-commerce Website Development",
    description: "Comprehensive guide for building modern e-commerce platforms",
    content: "# E-commerce Website Development\n\n## Project Overview\n...",
    category: "Development",
    tags: ["ecommerce", "web-development", "react"],
    isPublic: true,
    createdAt: new Date("2025-01-01"),
    metadata: {
      wordCount: 1200,
      characterCount: 7000,
      isEnhanced: true,
      enhancementSource: "demo",
      accessCount: 0
    }
  }
  // ... more demo prompts
]
```

---

## Database Schema

### Firestore Collections

#### Users Collection
```
users/
├── {userId}/
    ├── id: string
    ├── email: string
    ├── name: string
    ├── photoURL?: string
    ├── createdAt: timestamp
    ├── updatedAt: timestamp
    ├── lastLoginAt?: timestamp
    └── isActive: boolean
```

#### Prompts Collection
```
prompts/
├── {promptId}/
    ├── id: string
    ├── userId: string
    ├── title: string
    ├── description: string
    ├── content: string
    ├── category: string
    ├── tags: string[]
    ├── isPublic: boolean
    ├── createdAt: timestamp
    ├── updatedAt: timestamp
    ├── version: number
    └── metadata: object
```

#### Enhancement Requests Collection
```
enhancement_requests/
├── {requestId}/
    ├── id: string
    ├── userId: string
    ├── originalPrompt: string
    ├── enhancedPrompt: string
    ├── suggestedTitle: string
    ├── suggestedDescription: string
    ├── suggestedCategory: string
    ├── suggestedTags: string[]
    ├── status: string
    ├── createdAt: timestamp
    ├── completedAt?: timestamp
    ├── errorMessage?: string
    └── metadata: object
```

---

## Data Relationships

### User-Prompt Relationship
```
User (1) ←→ (N) Prompt
- One user can have many prompts
- Each prompt belongs to exactly one user
- Foreign key: Prompt.userId → User.id
```

### User-Enhancement Request Relationship
```
User (1) ←→ (N) EnhancementRequest
- One user can have many enhancement requests
- Each enhancement request belongs to exactly one user
- Foreign key: EnhancementRequest.userId → User.id
```

### Prompt-Enhancement Request Relationship
```
Prompt (1) ←→ (0..1) EnhancementRequest
- One prompt can be created from one enhancement request
- Enhancement requests may not result in saved prompts
- Optional relationship for tracking enhancement history
```

---

## Data Validation Rules

### User Validation
```typescript
const userValidationRules = {
  id: {
    required: true,
    type: 'string',
    pattern: /^[a-zA-Z0-9_-]+$/,
    maxLength: 128
  },
  email: {
    required: true,
    type: 'string',
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    maxLength: 254
  },
  name: {
    required: true,
    type: 'string',
    minLength: 1,
    maxLength: 100,
    trim: true
  },
  photoURL: {
    required: false,
    type: 'string',
    pattern: /^https?:\/\/.+/,
    maxLength: 2048
  }
}
```

### Prompt Validation
```typescript
const promptValidationRules = {
  title: {
    required: true,
    type: 'string',
    minLength: 1,
    maxLength: 200,
    trim: true
  },
  description: {
    required: true,
    type: 'string',
    minLength: 1,
    maxLength: 500,
    trim: true
  },
  content: {
    required: true,
    type: 'string',
    minLength: 1,
    maxLength: 50000,
    trim: true
  },
  category: {
    required: true,
    type: 'string',
    enum: ['Development', 'Writing', 'Analytics', 'Communication', 'Marketing', 'Productivity', 'Design', 'Research', 'Education', 'Other']
  },
  tags: {
    required: true,
    type: 'array',
    maxItems: 10,
    items: {
      type: 'string',
      minLength: 1,
      maxLength: 50,
      pattern: /^[a-zA-Z0-9_-]+$/
    }
  },
  isPublic: {
    required: true,
    type: 'boolean'
  }
}
```

---

## Data Access Patterns

### Query Patterns

#### Get User Prompts
```typescript
// Firestore query
const userPrompts = await db
  .collection('prompts')
  .where('userId', '==', userId)
  .orderBy('updatedAt', 'desc')
  .get()
```

#### Search Prompts
```typescript
// Text search across title, description, and content
const searchResults = await db
  .collection('prompts')
  .where('userId', '==', userId)
  .where('title', '>=', searchTerm)
  .where('title', '<=', searchTerm + '\uf8ff')
  .get()
```

#### Filter by Category
```typescript
// Filter prompts by category
const categoryPrompts = await db
  .collection('prompts')
  .where('userId', '==', userId)
  .where('category', '==', category)
  .get()
```

#### Get Public Prompts
```typescript
// Get all public prompts
const publicPrompts = await db
  .collection('prompts')
  .where('isPublic', '==', true)
  .orderBy('createdAt', 'desc')
  .limit(50)
  .get()
```

### Index Requirements

#### Composite Indexes
```json
{
  "indexes": [
    {
      "collectionGroup": "prompts",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "userId", "order": "ASCENDING" },
        { "fieldPath": "updatedAt", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "prompts",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "userId", "order": "ASCENDING" },
        { "fieldPath": "category", "order": "ASCENDING" }
      ]
    },
    {
      "collectionGroup": "prompts",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "isPublic", "order": "ASCENDING" },
        { "fieldPath": "createdAt", "order": "DESCENDING" }
      ]
    }
  ]
}
```

---

## Data Migration Strategy

### Version 1.0 to 2.0 Migration

#### Schema Changes
1. **Add metadata field to prompts**
2. **Add version field to prompts**
3. **Add enhancement_requests collection**
4. **Update user schema with lastLoginAt**

#### Migration Script
```typescript
async function migrateToV2() {
  const promptsSnapshot = await db.collection('prompts').get()
  
  const batch = db.batch()
  
  promptsSnapshot.forEach(doc => {
    const promptData = doc.data()
    
    // Add missing fields with default values
    batch.update(doc.ref, {
      version: 1,
      metadata: {
        wordCount: promptData.content.split(' ').length,
        characterCount: promptData.content.length,
        isEnhanced: false,
        accessCount: 0
      }
    })
  })
  
  await batch.commit()
}
```

---

## Data Security

### Firestore Security Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can only access their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == userId;
    }
    
    // Prompts are user-specific
    match /prompts/{promptId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.userId;
      // Allow public read access for public prompts
      allow read: if resource.data.isPublic == true;
    }
    
    // Enhancement requests are user-specific
    match /enhancement_requests/{requestId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.userId;
    }
  }
}
```

### Data Privacy

#### Personal Data Handling
- **Email addresses**: Stored for authentication, not shared
- **Profile pictures**: Optional, stored as URLs
- **User names**: Display names only, not real names required
- **Prompt content**: User-owned, private by default

#### Data Retention
- **User accounts**: Retained until user deletion
- **Prompts**: Retained until user deletion
- **Enhancement requests**: Retained for 90 days, then purged
- **Analytics data**: Anonymized, retained for 1 year

---

## Performance Considerations

### Data Optimization

#### Caching Strategy
```typescript
// Service-level caching
class PromptService {
  private cache = new Map<string, Prompt>()
  private cacheExpiry = 5 * 60 * 1000 // 5 minutes
  
  async getPrompt(id: string): Promise<Prompt> {
    const cached = this.cache.get(id)
    if (cached && Date.now() - cached.cachedAt < this.cacheExpiry) {
      return cached
    }
    
    const prompt = await this.repository.getPrompt(id)
    this.cache.set(id, { ...prompt, cachedAt: Date.now() })
    return prompt
  }
}
```

#### Pagination
```typescript
// Implement pagination for large datasets
interface PaginationOptions {
  limit: number
  startAfter?: DocumentSnapshot
  orderBy: string
  orderDirection: 'asc' | 'desc'
}

async function getPromptsPaginated(
  userId: string, 
  options: PaginationOptions
): Promise<{ prompts: Prompt[], lastDoc: DocumentSnapshot }> {
  let query = db.collection('prompts')
    .where('userId', '==', userId)
    .orderBy(options.orderBy, options.orderDirection)
    .limit(options.limit)
  
  if (options.startAfter) {
    query = query.startAfter(options.startAfter)
  }
  
  const snapshot = await query.get()
  const prompts = snapshot.docs.map(doc => doc.data() as Prompt)
  
  return {
    prompts,
    lastDoc: snapshot.docs[snapshot.docs.length - 1]
  }
}
```

### Data Size Limits

#### Firestore Limits
- **Document size**: 1MB maximum
- **Array size**: 20MB maximum
- **String field**: 1MB maximum
- **Collection size**: Unlimited

#### Application Limits
- **Prompt content**: 50,000 characters maximum
- **Prompt title**: 200 characters maximum
- **Tags array**: 10 items maximum
- **Description**: 500 characters maximum

---

## Backup and Recovery

### Automated Backups
- **Firestore**: Automatic daily backups
- **Retention**: 30 days of backup history
- **Recovery**: Point-in-time recovery available

### Data Export
```typescript
// User data export functionality
async function exportUserData(userId: string): Promise<UserDataExport> {
  const [user, prompts, enhancementRequests] = await Promise.all([
    db.collection('users').doc(userId).get(),
    db.collection('prompts').where('userId', '==', userId).get(),
    db.collection('enhancement_requests').where('userId', '==', userId).get()
  ])
  
  return {
    user: user.data(),
    prompts: prompts.docs.map(doc => doc.data()),
    enhancementRequests: enhancementRequests.docs.map(doc => doc.data()),
    exportedAt: new Date()
  }
}
```

---

## Monitoring and Analytics

### Data Metrics
- **User growth**: Daily active users, new registrations
- **Prompt usage**: Prompts created, enhanced, accessed
- **Feature adoption**: Enhancement usage, search patterns
- **Performance**: Query response times, error rates

### Data Quality Monitoring
- **Validation failures**: Track invalid data submissions
- **Data consistency**: Monitor referential integrity
- **Storage usage**: Track database size and growth
- **Error rates**: Monitor data access failures

---

## Future Enhancements

### Planned Data Model Extensions

#### Prompt Templates
```typescript
interface PromptTemplate {
  id: string
  name: string
  description: string
  category: PromptCategory
  templateContent: string
  variables: TemplateVariable[]
  isPublic: boolean
  createdBy: string
  usageCount: number
}

interface TemplateVariable {
  name: string
  type: 'string' | 'number' | 'boolean' | 'array'
  required: boolean
  defaultValue?: any
  description: string
}
```

#### Prompt Sharing
```typescript
interface PromptShare {
  id: string
  promptId: string
  sharedBy: string
  shareToken: string
  expiresAt?: Date
  accessCount: number
  maxAccess?: number
  isActive: boolean
}
```

#### User Preferences
```typescript
interface UserPreferences {
  userId: string
  defaultCategory: PromptCategory
  defaultTags: string[]
  enhancementSettings: {
    autoEnhance: boolean
    preferredModel: string
    maxEnhancementLength: number
  }
  uiSettings: {
    theme: 'light' | 'dark' | 'auto'
    itemsPerPage: number
    defaultSort: 'createdAt' | 'updatedAt' | 'title'
  }
}
```

This data model specification provides a comprehensive foundation for the PromptSaaS data architecture and serves as the blueprint for implementation and future enhancements.
