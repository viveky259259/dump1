// Simple in-memory storage for prompts (demo purposes)
interface Prompt {
  id: string
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
  createdAt: string
  updatedAt: string
  userId: string
}

class InMemoryPromptStorage {
  private static instance: InMemoryPromptStorage
  private prompts: Map<string, Prompt> = new Map()
  private userPrompts: Map<string, string[]> = new Map() // userId -> promptIds[]

  static getInstance(): InMemoryPromptStorage {
    if (!InMemoryPromptStorage.instance) {
      InMemoryPromptStorage.instance = new InMemoryPromptStorage()
    }
    return InMemoryPromptStorage.instance
  }

  createPrompt(userId: string, promptData: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt' | 'userId'>): Prompt {
    const id = `prompt-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    const now = new Date().toISOString()
    
    const prompt: Prompt = {
      id,
      userId,
      createdAt: now,
      updatedAt: now,
      ...promptData
    }

    this.prompts.set(id, prompt)
    
    // Add to user's prompts
    if (!this.userPrompts.has(userId)) {
      this.userPrompts.set(userId, [])
    }
    this.userPrompts.get(userId)!.push(id)

    return prompt
  }

  getUserPrompts(userId: string): Prompt[] {
    const promptIds = this.userPrompts.get(userId) || []
    return promptIds.map(id => this.prompts.get(id)!).filter(Boolean)
  }

  getPromptById(id: string): Prompt | null {
    return this.prompts.get(id) || null
  }

  updatePrompt(id: string, updates: Partial<Omit<Prompt, 'id' | 'userId' | 'createdAt'>>): Prompt | null {
    const prompt = this.prompts.get(id)
    if (!prompt) return null

    const updatedPrompt: Prompt = {
      ...prompt,
      ...updates,
      updatedAt: new Date().toISOString()
    }

    this.prompts.set(id, updatedPrompt)
    return updatedPrompt
  }

  deletePrompt(id: string): boolean {
    const prompt = this.prompts.get(id)
    if (!prompt) return false

    // Remove from user's prompts
    const userPromptIds = this.userPrompts.get(prompt.userId)
    if (userPromptIds) {
      const index = userPromptIds.indexOf(id)
      if (index > -1) {
        userPromptIds.splice(index, 1)
      }
    }

    // Remove the prompt
    this.prompts.delete(id)
    return true
  }
}

export default InMemoryPromptStorage
