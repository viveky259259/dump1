import { 
  collection, 
  doc, 
  addDoc, 
  getDocs, 
  getDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  Timestamp 
} from 'firebase/firestore'
import { db } from '../firebase'

export interface Prompt {
  id: string
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
  userId: string
  createdAt: string
  updatedAt: string
}

export interface CreatePromptData {
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
}

export interface UpdatePromptData extends Partial<CreatePromptData> {
  id: string
}

class FirestorePromptService {
  private static instance: FirestorePromptService
  private prompts: Prompt[] = []
  private listeners: Set<(prompts: Prompt[]) => void> = new Set()

  private constructor() {}

  static getInstance(): FirestorePromptService {
    if (!FirestorePromptService.instance) {
      FirestorePromptService.instance = new FirestorePromptService()
    }
    return FirestorePromptService.instance
  }

  // Subscribe to prompts changes
  subscribe(listener: (prompts: Prompt[]) => void): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  // Notify listeners of prompts changes
  private notifyListeners(): void {
    this.listeners.forEach(listener => listener([...this.prompts]))
  }

  // Convert Firestore document to Prompt
  private docToPrompt(doc: any): Prompt {
    const data = doc.data()
    return {
      id: doc.id,
      title: data.title,
      content: data.content,
      description: data.description || null,
      category: data.category || null,
      tags: data.tags || [],
      isPublic: data.isPublic || false,
      userId: data.userId,
      createdAt: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
      updatedAt: data.updatedAt?.toDate?.()?.toISOString() || new Date().toISOString()
    }
  }

  // Fetch prompts from Firestore
  async fetchPrompts(userId: string): Promise<Prompt[]> {
    try {
      console.log('FirestorePromptService: Fetching prompts for user:', userId)

      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptsRef = collection(db, 'prompts')
      const q = query(
        promptsRef,
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      )

      const querySnapshot = await getDocs(q)
      const prompts: Prompt[] = []

      querySnapshot.forEach((doc) => {
        prompts.push(this.docToPrompt(doc))
      })

      console.log('FirestorePromptService: Got prompts:', prompts.length)
      this.prompts = prompts
      this.notifyListeners()
      return prompts
    } catch (error) {
      console.error('FirestorePromptService: Error fetching prompts:', error)
      throw error
    }
  }

  // Create a new prompt in Firestore
  async createPrompt(userId: string, data: CreatePromptData): Promise<Prompt> {
    try {
      console.log('FirestorePromptService: Creating prompt for user:', userId)

      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptsRef = collection(db, 'prompts')
      const now = Timestamp.now()

      const docRef = await addDoc(promptsRef, {
        ...data,
        userId,
        createdAt: now,
        updatedAt: now
      })

      const newPrompt: Prompt = {
        id: docRef.id,
        title: data.title,
        content: data.content,
        description: data.description || null,
        category: data.category || null,
        tags: data.tags || [],
        isPublic: data.isPublic || false,
        userId,
        createdAt: now.toDate().toISOString(),
        updatedAt: now.toDate().toISOString()
      }

      this.prompts.unshift(newPrompt)
      this.notifyListeners()
      return newPrompt
    } catch (error) {
      console.error('FirestorePromptService: Error creating prompt:', error)
      throw error
    }
  }

  // Update a prompt in Firestore
  async updatePrompt(promptId: string, data: UpdatePromptData): Promise<Prompt> {
    try {
      console.log('FirestorePromptService: Updating prompt:', promptId)

      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptRef = doc(db, 'prompts', promptId)
      const updateData: any = {
        ...data,
        updatedAt: Timestamp.now()
      }

      // Remove id from update data
      delete updateData.id

      await updateDoc(promptRef, updateData)

      // Get updated document
      const docSnap = await getDoc(promptRef)
      if (!docSnap.exists()) {
        throw new Error('Prompt not found')
      }

      const updatedPrompt = this.docToPrompt(docSnap)
      
      // Update local cache
      const index = this.prompts.findIndex(p => p.id === promptId)
      if (index !== -1) {
        this.prompts[index] = updatedPrompt
        this.notifyListeners()
      }

      return updatedPrompt
    } catch (error) {
      console.error('FirestorePromptService: Error updating prompt:', error)
      throw error
    }
  }

  // Delete a prompt from Firestore
  async deletePrompt(promptId: string): Promise<void> {
    try {
      console.log('FirestorePromptService: Deleting prompt:', promptId)

      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptRef = doc(db, 'prompts', promptId)
      await deleteDoc(promptRef)

      // Remove from local cache
      this.prompts = this.prompts.filter(p => p.id !== promptId)
      this.notifyListeners()
    } catch (error) {
      console.error('FirestorePromptService: Error deleting prompt:', error)
      throw error
    }
  }

  // Get all prompts (from cache)
  getPrompts(): Prompt[] {
    return [...this.prompts]
  }

  // Get prompt by ID (from cache)
  getPromptById(id: string): Prompt | undefined {
    return this.prompts.find(p => p.id === id)
  }

  // Search prompts
  searchPrompts(query: string): Prompt[] {
    if (!query.trim()) {
      return this.prompts
    }

    const lowercaseQuery = query.toLowerCase()
    return this.prompts.filter(prompt =>
      prompt.title.toLowerCase().includes(lowercaseQuery) ||
      prompt.content.toLowerCase().includes(lowercaseQuery) ||
      prompt.description?.toLowerCase().includes(lowercaseQuery) ||
      prompt.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery))
    )
  }

  // Filter prompts by category
  filterByCategory(category: string): Prompt[] {
    if (!category) {
      return this.prompts
    }
    return this.prompts.filter(prompt => prompt.category === category)
  }

  // Filter prompts by tags
  filterByTags(tags: string[]): Prompt[] {
    if (!tags.length) {
      return this.prompts
    }
    return this.prompts.filter(prompt =>
      tags.some(tag => prompt.tags.includes(tag))
    )
  }

  // Clear all prompts (for logout)
  clearPrompts(): void {
    this.prompts = []
    this.notifyListeners()
  }
}

export default FirestorePromptService
