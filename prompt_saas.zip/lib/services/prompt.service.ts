import FirestorePromptService, { Prompt, CreatePromptData, UpdatePromptData } from './firestore-prompt.service'

class PromptService {
  private static instance: PromptService
  private firestoreService: FirestorePromptService

  private constructor() {
    this.firestoreService = FirestorePromptService.getInstance()
  }

  static getInstance(): PromptService {
    if (!PromptService.instance) {
      PromptService.instance = new PromptService()
    }
    return PromptService.instance
  }

  // Subscribe to prompts changes
  subscribe(listener: (prompts: Prompt[]) => void): () => void {
    return this.firestoreService.subscribe(listener)
  }

  // Fetch prompts from Firestore
  async fetchPrompts(userId: string): Promise<Prompt[]> {
    try {
      console.log('PromptService: Fetching prompts for user:', userId)
      return await this.firestoreService.fetchPrompts(userId)
    } catch (error) {
      console.error('PromptService: Error fetching prompts:', error)
      throw error
    }
  }

  // Create a new prompt
  async createPrompt(userId: string, data: CreatePromptData): Promise<Prompt> {
    try {
      console.log('PromptService: Creating prompt for user:', userId)
      return await this.firestoreService.createPrompt(userId, data)
    } catch (error) {
      console.error('PromptService: Error creating prompt:', error)
      throw error
    }
  }

  // Update a prompt
  async updatePrompt(data: UpdatePromptData): Promise<Prompt> {
    try {
      console.log('PromptService: Updating prompt:', data.id)
      return await this.firestoreService.updatePrompt(data.id, data)
    } catch (error) {
      console.error('PromptService: Error updating prompt:', error)
      throw error
    }
  }

  // Delete a prompt
  async deletePrompt(id: string): Promise<void> {
    try {
      console.log('PromptService: Deleting prompt:', id)
      await this.firestoreService.deletePrompt(id)
    } catch (error) {
      console.error('PromptService: Error deleting prompt:', error)
      throw error
    }
  }

  // Get all prompts
  getPrompts(): Prompt[] {
    return this.firestoreService.getPrompts()
  }

  // Get prompt by ID
  getPromptById(id: string): Prompt | undefined {
    return this.firestoreService.getPromptById(id)
  }

  // Search prompts
  searchPrompts(query: string): Prompt[] {
    return this.firestoreService.searchPrompts(query)
  }

  // Filter prompts by category
  filterByCategory(category: string): Prompt[] {
    return this.firestoreService.filterByCategory(category)
  }

  // Filter prompts by tags
  filterByTags(tags: string[]): Prompt[] {
    return this.firestoreService.filterByTags(tags)
  }

  // Clear all prompts (for logout)
  clearPrompts(): void {
    this.firestoreService.clearPrompts()
  }
}

export default PromptService
export type { Prompt, CreatePromptData, UpdatePromptData }
