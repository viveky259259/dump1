export interface DemoPrompt {
  id: string
  title: string
  content: string
  description?: string
  category?: string
  tags: string[]
  isPublic: boolean
  createdAt: string
  updatedAt: string
}

export const demoPrompts: DemoPrompt[] = [
  {
    id: 'demo-1',
    title: 'Code Review Assistant',
    content: 'Please review the following code and provide feedback on:\n1. Code quality and best practices\n2. Potential bugs or issues\n3. Performance optimizations\n4. Security concerns\n5. Suggestions for improvement\n\nCode:\n```\n[PASTE YOUR CODE HERE]\n```',
    description: 'Get comprehensive code reviews with actionable feedback',
    category: 'Development',
    tags: ['code', 'review', 'feedback', 'programming'],
    isPublic: true,
    createdAt: '2024-01-15T10:30:00Z',
    updatedAt: '2024-01-15T10:30:00Z'
  },
  {
    id: 'demo-2',
    title: 'Blog Post Generator',
    content: 'Write a comprehensive blog post about [TOPIC] with the following structure:\n\n1. Engaging introduction that hooks the reader\n2. Clear problem statement or main argument\n3. Supporting evidence or examples\n4. Practical solutions or insights\n5. Strong conclusion with call-to-action\n\nTarget audience: [SPECIFY AUDIENCE]\nTone: [PROFESSIONAL/CASUAL/FRIENDLY]\nWord count: [TARGET LENGTH]',
    description: 'Create engaging blog posts with proper structure',
    category: 'Writing',
    tags: ['blog', 'content', 'writing', 'seo'],
    isPublic: true,
    createdAt: '2024-01-14T14:20:00Z',
    updatedAt: '2024-01-14T14:20:00Z'
  },
  {
    id: 'demo-3',
    title: 'Data Analysis Report',
    content: 'Analyze the following dataset and provide:\n\n1. Executive Summary\n2. Key Findings and Insights\n3. Data Quality Assessment\n4. Statistical Analysis\n5. Visualizations Recommendations\n6. Actionable Recommendations\n7. Limitations and Assumptions\n\nDataset: [DESCRIBE YOUR DATA]\nBusiness Context: [EXPLAIN THE BUSINESS PROBLEM]',
    description: 'Generate comprehensive data analysis reports',
    category: 'Analytics',
    tags: ['data', 'analysis', 'report', 'insights'],
    isPublic: false,
    createdAt: '2024-01-13T09:15:00Z',
    updatedAt: '2024-01-13T09:15:00Z'
  },
  {
    id: 'demo-4',
    title: 'Email Template Generator',
    content: 'Create a professional email template for [PURPOSE] with:\n\nSubject Line: [COMPELLING SUBJECT]\n\nBody Structure:\n- Personalized greeting\n- Clear purpose statement\n- Supporting details\n- Call to action\n- Professional closing\n\nTone: [FORMAL/SEMI-FORMAL/CASUAL]\nRecipient: [TARGET AUDIENCE]\nGoal: [DESIRED OUTCOME]',
    description: 'Generate professional email templates for various purposes',
    category: 'Communication',
    tags: ['email', 'template', 'communication', 'professional'],
    isPublic: true,
    createdAt: '2024-01-12T16:45:00Z',
    updatedAt: '2024-01-12T16:45:00Z'
  },
  {
    id: 'demo-5',
    title: 'Product Description Writer',
    content: 'Write compelling product descriptions for [PRODUCT NAME] that:\n\n1. Highlight key features and benefits\n2. Address customer pain points\n3. Use persuasive language\n4. Include relevant keywords\n5. Create urgency or desire\n6. End with clear call-to-action\n\nProduct Details:\n- Name: [PRODUCT NAME]\n- Category: [PRODUCT CATEGORY]\n- Key Features: [LIST FEATURES]\n- Target Audience: [CUSTOMER SEGMENT]\n- Price Point: [PRICING TIER]',
    description: 'Create compelling product descriptions for e-commerce',
    category: 'Marketing',
    tags: ['product', 'description', 'marketing', 'ecommerce'],
    isPublic: true,
    createdAt: '2024-01-11T11:30:00Z',
    updatedAt: '2024-01-11T11:30:00Z'
  },
  {
    id: 'demo-6',
    title: 'Meeting Summary Generator',
    content: 'Summarize the following meeting and provide:\n\n1. Meeting Overview\n2. Key Discussion Points\n3. Decisions Made\n4. Action Items (with owners and deadlines)\n5. Next Steps\n6. Follow-up Required\n\nMeeting Details:\n- Date: [MEETING DATE]\n- Attendees: [LIST PARTICIPANTS]\n- Duration: [MEETING LENGTH]\n- Purpose: [MEETING OBJECTIVE]\n\nMeeting Notes:\n[PASTE YOUR MEETING NOTES HERE]',
    description: 'Generate structured meeting summaries and action items',
    category: 'Productivity',
    tags: ['meeting', 'summary', 'productivity', 'notes'],
    isPublic: false,
    createdAt: '2024-01-10T13:20:00Z',
    updatedAt: '2024-01-10T13:20:00Z'
  }
]

export const demoUser = {
  id: 'demo-user',
  name: 'Demo User',
  email: 'demo@promptsaas.com',
  image: null
}
