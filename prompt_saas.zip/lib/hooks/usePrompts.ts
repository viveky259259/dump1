import { useState, useEffect, useCallback } from 'react'
import PromptService, { Prompt, CreatePromptData } from '../services/prompt.service'
import { useAuth } from '../auth-context'

export interface UsePromptsReturn {
  prompts: Prompt[]
  loading: boolean
  error: string | null
  createPrompt: (data: CreatePromptData) => Promise<void>
  updatePrompt: (id: string, data: Partial<CreatePromptData>) => Promise<void>
  deletePrompt: (id: string) => Promise<void>
  searchPrompts: (query: string) => Prompt[]
  filterByCategory: (category: string) => Prompt[]
  refreshPrompts: () => Promise<void>
}

export function usePrompts(isDemo: boolean = false): UsePromptsReturn {
  const [prompts, setPrompts] = useState<Prompt[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()
  const promptService = PromptService.getInstance()

  // Subscribe to prompt service changes
  useEffect(() => {
    const unsubscribe = promptService.subscribe((newPrompts) => {
      setPrompts(newPrompts)
    })

    return unsubscribe
  }, [])

  // Load prompts when user changes
  useEffect(() => {
    if (user && !isDemo) {
      loadPrompts()
    } else if (isDemo) {
      // Load demo prompts
      setPrompts(getDemoPrompts())
    } else {
      setPrompts([])
    }
  }, [user, isDemo])

  const loadPrompts = async () => {
    if (!user) {
      console.log('usePrompts: No user, skipping loadPrompts')
      return
    }

    console.log('usePrompts: Starting to load prompts for user:', user.email)
    setLoading(true)
    setError(null)
    
    try {
      await promptService.fetchPrompts(user.id)
      console.log('usePrompts: Successfully loaded prompts')
    } catch (err) {
      console.error('usePrompts: Error loading prompts:', err)
      setError(err instanceof Error ? err.message : 'Failed to load prompts')
    } finally {
      console.log('usePrompts: Setting loading to false')
      setLoading(false)
    }
  }

  const createPrompt = async (data: CreatePromptData) => {
    if (isDemo) {
      // Handle demo mode
      const newPrompt: Prompt = {
        id: `demo-${Date.now()}`,
        ...data,
        userId: 'demo-user',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
      setPrompts(prev => [newPrompt, ...prev])
      return
    }

    if (!user) {
      throw new Error('User not authenticated')
    }

    setError(null)
    try {
      await promptService.createPrompt(user.id, data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create prompt')
      throw err
    }
  }

  const updatePrompt = async (id: string, data: Partial<CreatePromptData>) => {
    if (isDemo) {
      // Handle demo mode
      setPrompts(prev => prev.map(prompt => 
        prompt.id === id 
          ? { ...prompt, ...data, updatedAt: new Date().toISOString() }
          : prompt
      ))
      return
    }

    setError(null)
    try {
      await promptService.updatePrompt({ id, ...data })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update prompt')
      throw err
    }
  }

  const deletePrompt = async (id: string) => {
    if (isDemo) {
      // Handle demo mode
      setPrompts(prev => prev.filter(prompt => prompt.id !== id))
      return
    }

    setError(null)
    try {
      await promptService.deletePrompt(id)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete prompt')
      throw err
    }
  }

  const searchPrompts = useCallback((query: string) => {
    return promptService.searchPrompts(query)
  }, [])

  const filterByCategory = useCallback((category: string) => {
    return promptService.filterByCategory(category)
  }, [])

  const refreshPrompts = useCallback(async () => {
    if (user && !isDemo) {
      await loadPrompts()
    }
  }, [user, isDemo])

  return {
    prompts,
    loading,
    error,
    createPrompt,
    updatePrompt,
    deletePrompt,
    searchPrompts,
    filterByCategory,
    refreshPrompts
  }
}

// Demo prompts for demo mode
function getDemoPrompts(): Prompt[] {
  return [
    {
      id: 'demo-1',
      title: 'E-commerce Product Description Generator',
      content: 'Create compelling product descriptions for e-commerce websites that highlight key features, benefits, and use cases while maintaining SEO optimization.',
      description: 'Generate product descriptions that convert visitors into customers',
      category: 'E-commerce',
      tags: ['product', 'description', 'ecommerce', 'seo'],
      isPublic: false,
      userId: 'demo-user',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'demo-2',
      title: 'Social Media Content Calendar',
      content: 'Plan and create engaging social media content across multiple platforms with consistent branding and optimal posting times.',
      description: 'Streamline social media content planning and creation',
      category: 'Social Media',
      tags: ['social', 'content', 'calendar', 'marketing'],
      isPublic: true,
      userId: 'demo-user',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'demo-3',
      title: 'Technical Documentation Writer',
      content: 'Generate comprehensive technical documentation including API references, user guides, and troubleshooting sections.',
      description: 'Create clear and comprehensive technical documentation',
      category: 'Documentation',
      tags: ['technical', 'documentation', 'api', 'guide'],
      isPublic: false,
      userId: 'demo-user',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ]
}
