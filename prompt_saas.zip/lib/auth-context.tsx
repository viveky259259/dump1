'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth'
import { auth, googleProvider } from './firebase'
import { handleFirebaseError, clearFirebaseStorage } from './firebase-utils'

interface AuthUser {
  id: string
  email: string
  name: string
  image?: string
}

interface AuthContextType {
  user: AuthUser | null
  firebaseUser: User | null
  loading: boolean
  signInWithGoogle: () => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  firebaseUser: null,
  loading: true,
  signInWithGoogle: async () => {},
  logout: async () => {}
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Only set up Firebase auth listener if Firebase is initialized
    if (!auth) {
      console.warn('Firebase auth not initialized, using demo mode')
      setLoading(false)
      return
    }

    // Set up Firebase auth listener
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      console.log('AuthContext: Firebase auth state changed:', {
        email: firebaseUser?.email,
        displayName: firebaseUser?.displayName,
        photoURL: firebaseUser?.photoURL,
        uid: firebaseUser?.uid
      })
      
      setFirebaseUser(firebaseUser)
      
      if (firebaseUser) {
        // Convert Firebase user to our AuthUser format
        const authUser: AuthUser = {
          id: firebaseUser.uid,
          email: firebaseUser.email || '',
          name: firebaseUser.displayName || firebaseUser.email || 'User',
          image: firebaseUser.photoURL || undefined
        }
        setUser(authUser)
      } else {
        setUser(null)
      }
      
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const signInWithGoogle = async () => {
    try {
      setLoading(true)
      
      if (!auth || !googleProvider) {
        throw new Error('Firebase authentication not available')
      }
      
      // Clear any existing auth state to avoid IndexedDB conflicts
      try {
        await signOut(auth)
        await clearFirebaseStorage()
      } catch (error) {
        // Ignore sign out errors
        console.log('Sign out before sign in:', error)
      }
      
      const result = await signInWithPopup(auth, googleProvider)
      console.log('Sign in successful:', result.user.email)
    } catch (error) {
      console.error('Error signing in with Google:', error)
      setLoading(false)
      
      // Handle specific IndexedDB errors
      if (error instanceof Error && error.message.includes('IndexedDB')) {
        console.warn('IndexedDB error detected, clearing storage and retrying')
        await clearFirebaseStorage()
        throw new Error('Browser storage error. Please refresh the page and try again.')
      }
      
      throw new Error(handleFirebaseError(error))
    }
  }

  const logout = async () => {
    try {
      if (!auth) {
        throw new Error('Firebase authentication not available')
      }
      
      await signOut(auth)
      await clearFirebaseStorage()
      console.log('Sign out successful')
    } catch (error) {
      console.error('Error signing out:', error)
      throw new Error(handleFirebaseError(error))
    }
  }

  const value = {
    user,
    firebaseUser,
    loading,
    signInWithGoogle,
    logout
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
