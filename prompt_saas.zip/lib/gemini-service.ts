import { GoogleGenerativeAI } from '@google/generative-ai'

const genAI = process.env.GEMINI_API_KEY ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY) : null

export interface PromptEnhancementRequest {
  simplePrompt: string
  category?: string
}

export interface PromptEnhancementResponse {
  enhancedPrompt: string
  title: string
  description: string
  suggestedCategory: string
  suggestedTags: string[]
}

export async function enhancePrompt(request: PromptEnhancementRequest): Promise<PromptEnhancementResponse> {
  try {
    if (!genAI) {
      throw new Error('Gemini API key not configured')
    }
    
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" })

    const prompt = `
You are an expert prompt engineer and technical consultant. Your task is to take a simple, unstructured prompt or app idea and transform it into a comprehensive, detailed prompt or project blueprint.

User's simple prompt: "${request.simplePrompt}"

Please generate a comprehensive response that includes:

1. **Enhanced Prompt Title**: A clear, descriptive title
2. **Brief Description**: A 1-2 sentence summary
3. **Suggested Category**: One of: Development, Writing, Analytics, Communication, Marketing, Productivity, Design, Research, Education, Other
4. **Suggested Tags**: 3-5 relevant tags
5. **Comprehensive Enhanced Prompt**: A detailed, structured prompt that includes:

   - **Project Overview**: Clear description of what needs to be built/created
   - **Functional Requirements**: Detailed features and capabilities
   - **Technical Specifications**: Technology stack, architecture, integrations
   - **User Experience Guidelines**: UI/UX considerations, user flows
   - **Non-Functional Requirements**: Performance, security, scalability, accessibility
   - **Implementation Phases**: Step-by-step development approach
   - **Success Metrics**: How to measure success
   - **Constraints & Assumptions**: Any limitations or assumptions
   - **Deliverables**: What should be produced

Format your response as JSON with the following structure:
{
  "title": "Enhanced Prompt Title",
  "description": "Brief description",
  "suggestedCategory": "Category name",
  "suggestedTags": ["tag1", "tag2", "tag3"],
  "enhancedPrompt": "The comprehensive enhanced prompt content"
}

Make the enhanced prompt detailed, actionable, and professional. Use markdown formatting for better readability.
`

    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()

    // Try to parse JSON response
    try {
      const parsed = JSON.parse(text)
      return {
        enhancedPrompt: parsed.enhancedPrompt,
        title: parsed.title,
        description: parsed.description,
        suggestedCategory: parsed.suggestedCategory,
        suggestedTags: parsed.suggestedTags
      }
    } catch (parseError) {
      // If JSON parsing fails, return the raw text
      return {
        enhancedPrompt: text,
        title: request.simplePrompt.substring(0, 50) + (request.simplePrompt.length > 50 ? '...' : ''),
        description: 'AI-enhanced prompt',
        suggestedCategory: request.category || 'Other',
        suggestedTags: ['ai-enhanced', 'comprehensive']
      }
    }
  } catch (error) {
    console.error('Error enhancing prompt with Gemini:', error)
    
    // Handle specific API key referrer restriction error
    if (error instanceof Error && error.message.includes('API_KEY_HTTP_REFERRER_BLOCKED')) {
      throw new Error('Gemini API key has referrer restrictions. Please update the API key settings in Google Cloud Console to allow requests from localhost or remove referrer restrictions.')
    }
    
    // Handle other API errors
    if (error instanceof Error && error.message.includes('403 Forbidden')) {
      throw new Error('Gemini API access denied. Please check your API key permissions and referrer restrictions.')
    }
    
    throw new Error('Failed to enhance prompt. Please try again.')
  }
}
