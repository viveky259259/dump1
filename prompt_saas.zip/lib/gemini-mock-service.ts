import { PromptEnhancementRequest, PromptEnhancementResponse } from './gemini-service'

// Mock enhancement service for development when API key has restrictions
export async function enhancePromptMock(request: PromptEnhancementRequest): Promise<PromptEnhancementResponse> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  const category = request.category || 'Development'
  const simplePrompt = request.simplePrompt.toLowerCase()
  
  // Generate mock response based on input
  let title = `Enhanced: ${request.simplePrompt}`
  let description = 'AI-enhanced prompt for development'
  let suggestedTags = ['ai-enhanced', 'development', 'mock']
  let enhancedPrompt = `# ${request.simplePrompt}

## Project Overview
This is a comprehensive project based on your simple prompt: "${request.simplePrompt}"

## Functional Requirements
- Core functionality implementation
- User interface design
- Data management
- Performance optimization

## Technical Specifications
- Modern web technologies
- Responsive design
- Scalable architecture
- Security considerations

## Implementation Phases
1. Planning and design
2. Core development
3. Testing and optimization
4. Deployment and maintenance

## Success Metrics
- User engagement
- Performance benchmarks
- Feature completion
- User satisfaction

*This is a mock enhancement for development purposes.*`

  // Customize based on common keywords
  if (simplePrompt.includes('chess')) {
    title = 'Chess Application Development'
    description = 'Comprehensive chess game development guide'
    suggestedTags = ['chess', 'game', 'development', 'strategy', 'ai']
    enhancedPrompt = `# Chess Application Development

## Project Overview
Develop a complete chess application with modern features including AI opponents, online multiplayer, and educational tools.

## Functional Requirements
- **Game Engine**: Complete chess rule implementation
- **User Interface**: Intuitive board with drag-and-drop
- **AI Opponent**: Multiple difficulty levels
- **Multiplayer**: Online and local play
- **Game Modes**: Classic, variants, puzzles
- **User Accounts**: Progress tracking and statistics

## Technical Specifications
- **Frontend**: React/Next.js with TypeScript
- **Backend**: Node.js with WebSocket support
- **Database**: PostgreSQL for game history
- **AI Engine**: Chess.js with minimax algorithm
- **Deployment**: Docker containers on cloud platform

## User Experience Guidelines
- Responsive design for mobile and desktop
- Accessibility features for visually impaired
- Tutorial system for beginners
- Spectator mode for ongoing games

## Implementation Phases
1. **Phase 1**: Basic game engine and UI
2. **Phase 2**: AI opponent implementation
3. **Phase 3**: Multiplayer functionality
4. **Phase 4**: Advanced features and polish

## Success Metrics
- User retention rate > 70%
- Average session duration > 15 minutes
- AI difficulty satisfaction > 80%
- Mobile responsiveness score > 95%

*This is a mock enhancement for development purposes.*`
  } else if (simplePrompt.includes('todo') || simplePrompt.includes('task')) {
    title = 'Task Management Application'
    description = 'Comprehensive task and project management solution'
    suggestedTags = ['productivity', 'tasks', 'management', 'organization']
    enhancedPrompt = `# Task Management Application

## Project Overview
Create a comprehensive task management application with team collaboration features, project tracking, and productivity analytics.

## Functional Requirements
- **Task Management**: Create, edit, delete, and organize tasks
- **Project Organization**: Group tasks into projects and categories
- **Team Collaboration**: Share projects and assign tasks
- **Time Tracking**: Built-in timer and time logging
- **Notifications**: Real-time updates and reminders
- **Reporting**: Progress analytics and productivity insights

## Technical Specifications
- **Frontend**: React with drag-and-drop functionality
- **Backend**: Node.js with real-time WebSocket updates
- **Database**: MongoDB for flexible task schemas
- **Authentication**: JWT with role-based access
- **File Storage**: AWS S3 for attachments

## User Experience Guidelines
- Intuitive drag-and-drop interface
- Keyboard shortcuts for power users
- Mobile-first responsive design
- Dark/light theme support

## Implementation Phases
1. **Phase 1**: Core task management
2. **Phase 2**: Project organization
3. **Phase 3**: Team collaboration
4. **Phase 4**: Analytics and reporting

## Success Metrics
- Task completion rate > 85%
- User adoption rate > 60%
- Team collaboration usage > 40%
- Mobile app usage > 30%

*This is a mock enhancement for development purposes.*`
  } else if (simplePrompt.includes('blog') || simplePrompt.includes('content')) {
    title = 'Content Management System'
    description = 'Modern blog and content management platform'
    suggestedTags = ['cms', 'blog', 'content', 'publishing']
    enhancedPrompt = `# Content Management System

## Project Overview
Build a modern content management system with advanced features for bloggers, content creators, and businesses.

## Functional Requirements
- **Content Creation**: Rich text editor with media support
- **Publishing**: Draft, schedule, and publish content
- **SEO Tools**: Built-in SEO optimization
- **Analytics**: Content performance tracking
- **User Management**: Multi-author support
- **Customization**: Themes and layout options

## Technical Specifications
- **Frontend**: Next.js with headless CMS
- **Backend**: Strapi or Sanity CMS
- **Database**: PostgreSQL for content storage
- **Search**: Elasticsearch for content discovery
- **CDN**: CloudFlare for global content delivery

## User Experience Guidelines
- WYSIWYG editor with markdown support
- Real-time preview functionality
- Mobile-responsive admin interface
- Accessibility compliance (WCAG 2.1)

## Implementation Phases
1. **Phase 1**: Core CMS functionality
2. **Phase 2**: Advanced editor features
3. **Phase 3**: SEO and analytics
4. **Phase 4**: Multi-site management

## Success Metrics
- Content creation efficiency > 50% improvement
- SEO score improvement > 30%
- User satisfaction > 90%
- Page load speed < 2 seconds

*This is a mock enhancement for development purposes.*`
  }

  return {
    title,
    description,
    suggestedCategory: category,
    suggestedTags,
    enhancedPrompt
  }
}
