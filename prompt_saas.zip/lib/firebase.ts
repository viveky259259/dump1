import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider, connectAuthEmulator } from 'firebase/auth'
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

// Only initialize Firebase if we have the required config
let app: any = null
let auth: any = null
let googleProvider: any = null
let db: any = null

if (firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId) {
  try {
    // Initialize Firebase
    app = initializeApp(firebaseConfig)

    // Initialize Firebase Auth with persistence settings
    auth = getAuth(app)
    
    // Configure auth persistence to avoid IndexedDB issues
    if (typeof window !== 'undefined') {
      // Set persistence to session storage to avoid IndexedDB issues
      auth.setPersistence = auth.setPersistence || (() => Promise.resolve())
    }

    // Initialize Google Auth Provider
    googleProvider = new GoogleAuthProvider()
    
    // Add additional scopes if needed
    googleProvider.addScope('email')
    googleProvider.addScope('profile')

    // Initialize Firestore
    db = getFirestore(app)
    
    console.log('Firebase initialized successfully')
  } catch (error) {
    console.warn('Firebase initialization failed:', error)
  }
} else {
  console.warn('Firebase configuration incomplete, skipping initialization')
}

export { auth, googleProvider, db }
export default app
