// Firebase error handling utilities
export const handleFirebaseError = (error: any): string => {
  console.error('Firebase error:', error)
  
  if (error.code) {
    switch (error.code) {
      case 'auth/popup-closed-by-user':
        return 'Sign-in was cancelled. Please try again.'
      case 'auth/popup-blocked':
        return 'Popup was blocked by your browser. Please allow popups and try again.'
      case 'auth/cancelled-popup-request':
        return 'Another sign-in process is already in progress.'
      case 'auth/network-request-failed':
        return 'Network error. Please check your internet connection.'
      case 'auth/too-many-requests':
        return 'Too many failed attempts. Please try again later.'
      case 'auth/user-disabled':
        return 'This account has been disabled.'
      case 'auth/user-not-found':
        return 'No account found with this email.'
      case 'auth/wrong-password':
        return 'Incorrect password.'
      case 'auth/email-already-in-use':
        return 'An account with this email already exists.'
      case 'auth/weak-password':
        return 'Password is too weak.'
      case 'auth/invalid-email':
        return 'Invalid email address.'
      default:
        return `Authentication error: ${error.message}`
    }
  }
  
  // Handle IndexedDB errors specifically
  if (error.message && error.message.includes('IndexedDB')) {
    return 'Browser storage error. Please try refreshing the page and signing in again.'
  }
  
  // Handle generic errors
  if (error.message) {
    return error.message
  }
  
  return 'An unexpected error occurred. Please try again.'
}

export const clearFirebaseStorage = async (): Promise<void> => {
  try {
    // Clear localStorage
    if (typeof window !== 'undefined') {
      const keys = Object.keys(localStorage)
      keys.forEach(key => {
        if (key.startsWith('firebase:') || key.startsWith('firebaseui:')) {
          localStorage.removeItem(key)
        }
      })
      
      // Clear sessionStorage
      const sessionKeys = Object.keys(sessionStorage)
      sessionKeys.forEach(key => {
        if (key.startsWith('firebase:') || key.startsWith('firebaseui:')) {
          sessionStorage.removeItem(key)
        }
      })
    }
  } catch (error) {
    console.warn('Error clearing Firebase storage:', error)
  }
}
