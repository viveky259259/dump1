# Vercel Secure Key Storage Setup Guide

## 🔐 Method 1: Vercel CLI (Recommended)

Run these commands one by one and enter your actual values when prompted:

```bash
# Firebase Configuration (Client-side)
vercel env add NEXT_PUBLIC_FIREBASE_API_KEY
# Enter: AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU

vercel env add NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN
# Enter: family-hosehold-management-pro.firebaseapp.com

vercel env add NEXT_PUBLIC_FIREBASE_PROJECT_ID
# Enter: family-hosehold-management-pro

vercel env add NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET
# Enter: family-hosehold-management-pro.firebasestorage.app

vercel env add NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID
# Enter: 963076663974

vercel env add NEXT_PUBLIC_FIREBASE_APP_ID
# Enter: 1:963076663974:web:b468c7e0a6669e19dca267

# Gemini AI API (Server-side)
vercel env add GEMINI_API_KEY
# Enter: AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y

# NextAuth (Optional)
vercel env add NEXTAUTH_SECRET
# Enter: your-secure-random-string-here

vercel env add NEXTAUTH_URL
# Enter: https://promptsaas.vercel.app
```

## 🔐 Method 2: Vercel Dashboard

1. Go to: https://vercel.com/vivek-yadavs-projects-61bbeef1/prompt_saas/settings/environment-variables
2. Click "Add New" for each variable
3. Set environment scope: **Production, Preview, Development**

### Required Variables:

| Variable Name | Value | Environment |
|---------------|-------|-------------|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | `AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU` | All |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | `family-hosehold-management-pro.firebaseapp.com` | All |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | `family-hosehold-management-pro` | All |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | `family-hosehold-management-pro.firebasestorage.app` | All |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | `963076663974` | All |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | `1:963076663974:web:b468c7e0a6669e19dca267` | All |
| `GEMINI_API_KEY` | `AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y` | All |
| `NEXTAUTH_SECRET` | `your-secure-random-string` | All |
| `NEXTAUTH_URL` | `https://promptsaas.vercel.app` | All |

## 🔐 Method 3: Bulk Setup Script

Create and run this script:

```bash
#!/bin/bash
echo "Setting up Vercel environment variables..."

# Firebase Configuration
echo "Adding Firebase variables..."
vercel env add NEXT_PUBLIC_FIREBASE_API_KEY <<< "AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU"
vercel env add NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN <<< "family-hosehold-management-pro.firebaseapp.com"
vercel env add NEXT_PUBLIC_FIREBASE_PROJECT_ID <<< "family-hosehold-management-pro"
vercel env add NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET <<< "family-hosehold-management-pro.firebasestorage.app"
vercel env add NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID <<< "963076663974"
vercel env add NEXT_PUBLIC_FIREBASE_APP_ID <<< "1:963076663974:web:b468c7e0a6669e19dca267"

# Gemini AI API
echo "Adding Gemini API key..."
vercel env add GEMINI_API_KEY <<< "AIzaSyAPHPNm6sWTSoKY5IItl8hQFOtPMEz4H1Y"

# NextAuth
echo "Adding NextAuth variables..."
vercel env add NEXTAUTH_SECRET <<< "your-secure-random-string-here"
vercel env add NEXTAUTH_URL <<< "https://promptsaas.vercel.app"

echo "✅ All environment variables added successfully!"
```

## 🔍 Verify Setup

After adding variables, verify they're set:

```bash
# List all environment variables
vercel env ls

# Pull variables to local file (for testing)
vercel env pull .env.local
```

## 🚀 Deploy with Secure Keys

After setting up environment variables:

```bash
# Redeploy with new environment variables
vercel --prod

# Or trigger a new deployment
vercel env pull && vercel --prod
```

## 🛡️ Security Best Practices

### ✅ DO:
- Use different values for different environments
- Rotate keys regularly
- Use strong, unique secrets
- Never commit .env files to git

### ❌ DON'T:
- Hardcode secrets in code
- Share secrets in chat/email
- Use the same secret for multiple purposes
- Store secrets in client-side code

## 🔧 Access in Code

Environment variables are automatically available in your code:

```typescript
// Client-side (NEXT_PUBLIC_*)
const firebaseApiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY

// Server-side
const geminiApiKey = process.env.GEMINI_API_KEY
```

## 📋 Next Steps

1. **Set Environment Variables** using one of the methods above
2. **Verify Setup** with `vercel env ls`
3. **Redeploy** your app: `vercel --prod`
4. **Test Authentication** - Sign in with Google
5. **Test AI Features** - Try prompt enhancement
