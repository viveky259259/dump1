'use client'

import { useEffect, useState } from 'react'

interface VersionFooterProps {
  className?: string
}

export default function VersionFooter({ className = '' }: VersionFooterProps) {
  const [version, setVersion] = useState('1.0.0')
  const [buildTime, setBuildTime] = useState<string | null>(null)

  useEffect(() => {
    // Get version from package.json (this will be available at build time)
    if (typeof window !== 'undefined') {
      // Try to get build time from environment or use current time as fallback
      const buildTime = process.env.NEXT_PUBLIC_BUILD_TIME || new Date().toISOString()
      setBuildTime(buildTime)
    }
  }, [])

  return (
    <footer className={`text-center text-sm text-gray-500 py-4 border-t border-gray-200 ${className}`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-center items-center gap-2 sm:gap-4">
          <span className="flex items-center gap-2">
            <span className="font-medium">PromptSaaS</span>
            <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-mono">
              v{version}
            </span>
          </span>
          
          <span className="hidden sm:inline text-gray-300">•</span>
          
          <span className="text-xs text-gray-400">
            Built with Next.js & Firebase
          </span>
          
          {buildTime && (
            <>
              <span className="hidden sm:inline text-gray-300">•</span>
              <span className="text-xs text-gray-400 font-mono">
                {new Date(buildTime).toLocaleDateString()}
              </span>
            </>
          )}
        </div>
        
        <div className="mt-2 text-xs text-gray-400">
          <span>Powered by </span>
          <a 
            href="https://vercel.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800 transition-colors"
          >
            Vercel
          </a>
          <span> • </span>
          <a 
            href="https://firebase.google.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-orange-600 hover:text-orange-800 transition-colors"
          >
            Firebase
          </a>
          <span> • </span>
          <a 
            href="https://ai.google.dev" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-purple-600 hover:text-purple-800 transition-colors"
          >
            Gemini AI
          </a>
        </div>
      </div>
    </footer>
  )
}
