'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Wand2, Loader2, Sparkles } from 'lucide-react'

interface PromptEnhancementDialogProps {
  onEnhancementComplete: (enhancedData: {
    title: string
    content: string
    description: string
    category: string
    tags: string[]
  }) => void
}

export function PromptEnhancementDialog({ onEnhancementComplete }: PromptEnhancementDialogProps) {
  const [open, setOpen] = useState(false)
  const [simplePrompt, setSimplePrompt] = useState('')
  const [category, setCategory] = useState('')
  const [isEnhancing, setIsEnhancing] = useState(false)
  const [error, setError] = useState('')

  const handleEnhance = async () => {
    if (!simplePrompt.trim()) {
      setError('Please enter a prompt or idea to enhance')
      return
    }

    setIsEnhancing(true)
    setError('')

    try {
      const response = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          simplePrompt: simplePrompt.trim(),
          category: category.trim() || undefined
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to enhance prompt')
      }

      const result = await response.json()
      
      onEnhancementComplete({
        title: result.title,
        content: result.enhancedPrompt,
        description: result.description,
        category: result.suggestedCategory,
        tags: result.suggestedTags
      })

      setOpen(false)
      setSimplePrompt('')
      setCategory('')
    } catch (error) {
      console.error('Error enhancing prompt:', error)
      setError('Failed to enhance prompt. Please try again.')
    } finally {
      setIsEnhancing(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full">
          <Wand2 className="w-4 h-4 mr-2" />
          Enhance with AI
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <span>AI Prompt Enhancement</span>
          </DialogTitle>
          <DialogDescription>
            Describe your idea or simple prompt, and our AI will generate a comprehensive, 
            detailed prompt with technical specifications, requirements, and best practices.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="simplePrompt">Your Idea or Simple Prompt</Label>
            <Textarea
              id="simplePrompt"
              placeholder="e.g., 'I want to build a task management app' or 'Create a prompt for writing product descriptions'"
              value={simplePrompt}
              onChange={(e) => setSimplePrompt(e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="category">Category (Optional)</Label>
            <Input
              id="category"
              placeholder="e.g., Development, Writing, Marketing"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleEnhance} disabled={isEnhancing || !simplePrompt.trim()}>
            {isEnhancing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Enhancing...
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4 mr-2" />
                Enhance Prompt
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
