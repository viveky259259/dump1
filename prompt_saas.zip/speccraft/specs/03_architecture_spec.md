# Architecture Specification: SpecCraft System

**Type:** Architecture Specification  
**Version:** 1.0.0  
**Author:** Engineering Team  
**Created:** September 30, 2025  
**Status:** Draft  

---

## Overview

This document defines the technical architecture for SpecCraft, a system for creating and validating software specifications. The architecture prioritizes:
- **Simplicity:** Easy to understand and extend
- **Performance:** Fast feedback for developers
- **Extensibility:** Plugin system for customization
- **Offline-first:** Core functionality works without internet

## System Context

```
┌─────────────┐
│    User     │
└──────┬──────┘
       │
       │ CLI Commands
       ▼
┌─────────────────────────────────────────────┐
│           SpecCraft System                   │
│                                              │
│  ┌────────────┐  ┌──────────────┐          │
│  │  Template  │  │  Validation  │          │
│  │   System   │  │    Engine    │          │
│  └────────────┘  └──────────────┘          │
│                                              │
│  ┌────────────┐  ┌──────────────┐          │
│  │   Spec     │  │   Analyzer   │          │
│  │  Storage   │  │  (AI-powered)│          │
│  └────────────┘  └──────────────┘          │
└─────────────────────────────────────────────┘
       │              │
       │              │ (optional)
       ▼              ▼
┌─────────────┐  ┌─────────────┐
│ File System │  │  Claude API │
│  (.yaml)    │  │  (Anthropic)│
└─────────────┘  └─────────────┘
```

## Components

### 1. CLI Interface
**Responsibility:** User interaction and command routing

**Key Abstractions:**
- `Command`: Base class for all CLI commands
- `create`, `validate`, `analyze`, `templates` commands
- Interactive prompts and output formatting

**Technology:**
- Click (Python CLI framework)
- Rich (terminal formatting and colors)

**Interactions:**
- Receives user commands
- Routes to appropriate subsystem
- Formats and displays results

---

### 2. Template System
**Responsibility:** Manage specification templates

**Key Abstractions:**
- `Template`: Template definition and metadata
- `TemplateField`: Field definition with validation rules
- `TemplateRegistry`: Load and manage templates

**Technology:**
- YAML for template storage
- JSON Schema for field validation

**API:**
```python
class Template:
    def __init__(self, name: str, version: str, schema: dict)
    def instantiate(self, output_path: str) -> Specification
    def validate_spec(self, spec: Specification) -> ValidationResult
    
class TemplateRegistry:
    def load_templates(self, directory: str)
    def get_template(self, name: str) -> Template
    def list_templates(self) -> List[Template]
```

**Storage:**
- Built-in templates: `speccraft/templates/`
- Custom templates: `.speccraft/templates/`

---

### 3. Specification Model
**Responsibility:** Core data structures for specifications

**Key Abstractions:**
- `Specification`: Root spec object
- `Requirement`: Individual requirement with metadata
- `EdgeCase`, `Risk`, `Constraint`: Supporting entities

**Technology:**
- Dataclasses for type safety
- YAML for serialization

**API:**
```python
@dataclass
class Specification:
    type: SpecType
    version: str
    title: str
    overview: str
    functional_requirements: List[Requirement]
    non_functional_requirements: List[Requirement]
    
    def validate(self) -> ValidationResult
    def calculate_score(self) -> QualityScore
    def to_yaml(self) -> str
    def from_yaml(cls, yaml_str: str) -> Specification
```

---

### 4. Validation Engine
**Responsibility:** Analyze and validate specifications

**Key Abstractions:**
- `Validator`: Base class for validators
- `ValidationRule`: Individual validation rule
- `ValidationResult`: Validation outcomes

**Validator Types:**
- `StructuralValidator`: Schema compliance
- `CompletenessValidator`: Missing information
- `AmbiguityValidator`: Vague language
- `ConsistencyValidator`: Internal consistency
- `BestPracticeValidator`: Industry standards

**API:**
```python
class Validator:
    def validate(self, spec: Specification) -> ValidationResult
    
class ValidationRule:
    def __init__(self, id: str, severity: Severity, description: str)
    def check(self, spec: Specification) -> List[Issue]
    
class ValidationResult:
    errors: List[Issue]
    warnings: List[Issue]
    suggestions: List[Issue]
    quality_score: QualityScore
```

**Extension Points:**
- Custom validators via plugins
- Custom rules via config

---

### 5. Quality Scorer
**Responsibility:** Calculate objective quality metrics

**Scoring Algorithm:**
```
Total Score = Completeness (40) + Quality (40) + Detail (20)

Completeness:
  - Required fields present: 10pts
  - Optional fields present: 10pts
  - Acceptance criteria: 10pts
  - Edge cases: 5pts
  - Risks: 5pts

Quality:
  - No ambiguous language: 15pts
  - Rationale provided: 10pts
  - Measurable criteria: 15pts

Detail:
  - Number of requirements: 10pts
  - Depth of documentation: 10pts
```

**API:**
```python
class QualityScorer:
    def calculate_score(self, spec: Specification) -> QualityScore
    
@dataclass
class QualityScore:
    total: int  # 0-100
    completeness: int
    quality: int
    detail: int
    grade: str  # A-F
    suggestions: List[str]
```

---

### 6. AI Analyzer (Optional)
**Responsibility:** Intelligent spec analysis and suggestions

**Capabilities:**
- Detect subtle ambiguities beyond pattern matching
- Suggest missing edge cases
- Recommend architectural improvements
- Generate example acceptance criteria

**Technology:**
- Anthropic Claude API (sonnet model)
- Structured prompting for consistency
- Fallback to rule-based if API unavailable

**API:**
```python
class AIAnalyzer:
    def analyze(self, spec: Specification) -> AnalysisResult
    def suggest_improvements(self, requirement: Requirement) -> List[Suggestion]
    def detect_gaps(self, spec: Specification) -> List[Gap]
```

**Privacy:**
- Specs never leave user's machine without explicit consent
- API key required (user provides own key)
- Can be disabled entirely

---

### 7. Report Generator
**Responsibility:** Format validation results for different audiences

**Output Formats:**
- Console (colored, interactive)
- JSON (for CI/CD)
- HTML (for stakeholders)
- Markdown (for documentation)

**API:**
```python
class ReportGenerator:
    def generate(self, result: ValidationResult, format: Format) -> str
    
class ConsoleReporter(ReportGenerator):
    def generate(self, result: ValidationResult) -> str
        # Rich formatted console output
        
class JSONReporter(ReportGenerator):
    def generate(self, result: ValidationResult) -> str
        # Machine-readable JSON
```

---

## Data Flow

### Create Spec Flow

```
User: speccraft create --type feature
        ↓
CLI → TemplateRegistry.get_template("feature")
        ↓
Template.instantiate("new_spec.yaml")
        ↓
Write Specification to file
        ↓
Return: File path and next steps
```

### Validate Spec Flow

```
User: speccraft validate my_spec.yaml
        ↓
CLI → Read file
        ↓
Specification.from_yaml(file_content)
        ↓
ValidationEngine.validate(spec)
        ↓
  ├→ StructuralValidator.validate()
  ├→ CompletenessValidator.validate()
  ├→ AmbiguityValidator.validate()
  ├→ ConsistencyValidator.validate()
  └→ BestPracticeValidator.validate()
        ↓
QualityScorer.calculate_score(spec)
        ↓
ReportGenerator.generate(results, format="console")
        ↓
Display to user
```

### Analyze Spec Flow (AI)

```
User: speccraft analyze my_spec.yaml
        ↓
CLI → Read file & validate
        ↓
AIAnalyzer.analyze(spec)
        ↓
  ├→ Format prompt with spec content
  ├→ Call Claude API
  ├→ Parse structured response
  └→ Generate suggestions
        ↓
Display analysis results
```

## Technology Stack

### Core
- **Language:** Python 3.10+
- **CLI Framework:** Click 8.1+
- **YAML Parser:** PyYAML 6.0+
- **Schema Validator:** jsonschema 4.20+

### UI/UX
- **Terminal UI:** Rich 13.7+
- **Colors:** Rich built-in
- **Prompts:** Click built-in

### Optional (AI)
- **AI API:** Anthropic Claude (via anthropic SDK)
- **Token Management:** tiktoken

### Development
- **Testing:** pytest
- **Linting:** ruff
- **Type Checking:** mypy
- **Packaging:** setuptools / pip

## File Structure

```
speccraft/
├── cli.py                 # CLI entry point
├── commands/
│   ├── create.py         # Create command
│   ├── validate.py       # Validate command
│   ├── analyze.py        # Analyze command
│   └── templates.py      # Template commands
├── models/
│   ├── specification.py  # Spec data models
│   ├── requirement.py
│   └── types.py
├── templates/
│   ├── registry.py       # Template registry
│   ├── template.py       # Template class
│   └── built_in/         # Built-in templates
│       ├── feature.yaml
│       ├── api.yaml
│       ├── architecture.yaml
│       ├── data.yaml
│       └── integration.yaml
├── validation/
│   ├── engine.py         # Validation orchestrator
│   ├── validators/
│   │   ├── structural.py
│   │   ├── completeness.py
│   │   ├── ambiguity.py
│   │   ├── consistency.py
│   │   └── best_practice.py
│   ├── rules.py          # Validation rules
│   └── scorer.py         # Quality scoring
├── analysis/
│   ├── analyzer.py       # AI analyzer
│   └── prompts.py        # AI prompts
├── reporting/
│   ├── generator.py      # Report generator
│   ├── console.py        # Console reporter
│   ├── json.py           # JSON reporter
│   ├── html.py           # HTML reporter
│   └── markdown.py       # Markdown reporter
└── utils/
    ├── yaml_parser.py
    ├── file_io.py
    └── config.py

tests/
├── test_models.py
├── test_validation.py
├── test_templates.py
└── fixtures/
    └── example_specs/

.speccraft/                # User config (gitignored)
├── config.yaml
├── templates/             # Custom templates
└── rules.yaml             # Custom validation rules

specs/                     # Specification documents
└── *.yaml                 # User's specs
```

## Configuration

### User Config (`.speccraft/config.yaml`)

```yaml
# Validation settings
validation:
  strict_mode: false
  min_quality_score: 70
  disabled_rules:
    - best_practice.passive_voice
  
# AI settings
ai:
  enabled: true
  api_key_env: ANTHROPIC_API_KEY
  model: claude-sonnet-4
  
# Output settings
output:
  color: true
  verbose: false
  default_format: console

# Template settings
templates:
  custom_dir: .speccraft/templates
  default_author: "Team Name"
```

## Non-Functional Requirements

### Performance
- Template instantiation: <100ms
- Validation (small spec): <200ms
- Validation (large spec): <2s
- AI analysis: <10s (network dependent)

### Reliability
- No data loss (atomic file writes)
- Graceful degradation (AI optional)
- Clear error messages

### Security
- No arbitrary code execution
- Sandbox custom rules
- User controls AI data sharing

### Maintainability
- Modular architecture
- Comprehensive tests (80%+ coverage)
- Type hints throughout
- Clear documentation

## Deployment

### Installation
```bash
pip install speccraft
```

### Packaging
- PyPI package
- Single-command install
- No complex dependencies

### Updates
- Semantic versioning
- Backward-compatible config
- Migration guides for breaking changes

## Risks & Mitigations

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| YAML parsing vulnerabilities | High | Low | Use safe_load only, validate schemas |
| AI API reliability | Medium | Medium | Make AI optional, cache results |
| Performance with large specs | Medium | Medium | Incremental validation, async processing |
| Template schema evolution | High | Medium | Version templates, migration tools |
| Custom rule security | High | Low | Sandbox execution, timeout limits |

## Open Questions

1. Should we support multiple spec formats (YAML, JSON, TOML)?
2. How do we handle very large specs (1000+ requirements)?
3. Should validation be client-server for team-wide consistency?
4. What level of plugin sandboxing is necessary?
5. Should we build a language server protocol (LSP) for IDE integration?

## Future Architecture Considerations

- **LSP Server:** Real-time validation in IDEs
- **Web UI:** Visual spec editor for non-technical users
- **Distributed Validation:** Server-side validation for consistency
- **Spec Database:** Query and analyze specs at scale
- **CI/CD Plugins:** Native GitHub Actions, GitLab CI integration

---

## Decision Log

### Decision 1: Python over TypeScript
**Date:** 2025-09-30  
**Rationale:** Python has better AI/NLP libraries, YAML support, and is familiar to DevOps/ML engineers who are target users.  
**Alternatives Considered:** TypeScript (better for web UI later), Rust (performance)

### Decision 2: YAML over JSON
**Rationale:** YAML is more human-readable, supports comments, better for version control.  
**Trade-offs:** Slightly slower parsing, more permissive syntax

### Decision 3: CLI-first over Web-first
**Rationale:** Developers prefer CLI, fits Git workflow, lower initial complexity.  
**Future:** Web UI can be added later for PMs and stakeholders

### Decision 4: Offline-first architecture
**Rationale:** Core value should work without external dependencies. AI is enhancement, not requirement.  
**Impact:** More complex fallback logic, but better reliability

### Decision 5: Plugin system for extensibility
**Rationale:** Can't anticipate all use cases. Let users extend for their needs.  
**Concerns:** Security, stability, documentation burden
