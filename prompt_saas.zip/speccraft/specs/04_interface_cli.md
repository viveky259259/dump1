# Interface Specification: Command Line Interface

**Type:** Interface Specification  
**Version:** 1.0.0  
**Author:** Engineering Team  
**Created:** September 30, 2025  
**Status:** Draft  
**Priority:** Critical  

---

## Overview

The SpecCraft CLI is the primary interface for users to interact with the system. It provides commands for creating, validating, analyzing, and managing specifications. The CLI is designed to be intuitive, fast, and fit naturally into developer workflows.

## Design Principles

1. **Intuitive:** Commands follow Git-like conventions (verb-noun pattern)
2. **Fast:** Sub-second response for common operations
3. **Informative:** Clear output with actionable feedback
4. **Scriptable:** Easy to integrate into CI/CD pipelines
5. **Beautiful:** Colored output, progress indicators, clean formatting

## Commands

### `speccraft create`

**Purpose:** Create a new specification from a template

**Syntax:**
```bash
speccraft create [OPTIONS]
```

**Options:**
| Flag | Short | Type | Required | Description | Default |
|------|-------|------|----------|-------------|---------|
| `--type` | `-t` | choice | No | Template type (feature, api, architecture, data, integration) | Interactive prompt |
| `--output` | `-o` | path | No | Output file path | `<type>_spec.yaml` |
| `--title` | | text | No | Specification title | Interactive prompt |
| `--author` | | text | No | Author name | Git config user.name |
| `--interactive` | `-i` | flag | No | Interactive mode with prompts | True if no options provided |

**Examples:**
```bash
# Interactive mode (default)
speccraft create

# Quick create with type
speccraft create --type feature --title "User Authentication"

# Fully specified
speccraft create -t api -o auth_api.yaml --title "Auth API v2" --author "Alice"
```

**Output:**
```
✨ Creating new feature specification...

Title: User Authentication
Author: Alice Chen
Output: auth_spec.yaml

✅ Specification created successfully!

Next steps:
  1. Edit: auth_spec.yaml
  2. Validate: speccraft validate auth_spec.yaml
  3. Get suggestions: speccraft analyze auth_spec.yaml
```

**Exit Codes:**
- `0`: Success
- `1`: Invalid options or template not found
- `2`: File already exists (use --force to overwrite)

---

### `speccraft validate`

**Purpose:** Validate a specification and show quality score

**Syntax:**
```bash
speccraft validate [SPEC_FILES...] [OPTIONS]
```

**Arguments:**
| Argument | Type | Required | Description |
|----------|------|----------|-------------|
| `SPEC_FILES` | path(s) | Yes | One or more spec files to validate |

**Options:**
| Flag | Short | Type | Description | Default |
|------|-------|------|-------------|---------|
| `--format` | `-f` | choice | Output format (console, json, html, markdown) | console |
| `--output` | `-o` | path | Save report to file | stdout |
| `--min-score` | | int | Minimum acceptable score (exits 1 if below) | 0 |
| `--strict` | | flag | Treat warnings as errors | False |
| `--watch` | `-w` | flag | Watch file and re-validate on changes | False |
| `--quiet` | `-q` | flag | Only show errors, suppress warnings | False |

**Examples:**
```bash
# Basic validation
speccraft validate auth_spec.yaml

# Validate multiple specs
speccraft validate specs/*.yaml

# CI/CD mode with minimum score
speccraft validate auth_spec.yaml --min-score 80 --format json

# Watch mode for development
speccraft validate -w auth_spec.yaml
```

**Output (Console Format):**
```
Validating: auth_spec.yaml
Template: feature v1.0.0

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ STRUCTURAL VALIDATION
   All required fields present

⚠️  COMPLETENESS (2 warnings)
   Line 45: FR-3 missing acceptance criteria
   Line 67: No edge cases documented

❌ AMBIGUITY (1 error)
   Line 23: "should be fast" - quantify performance
   
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 QUALITY SCORE: 78/100 (C+)

  Completeness:  32/40
  Quality:       34/40
  Detail:        12/20

💡 Fix 1 error and 2 warnings to reach B grade

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Output (JSON Format):**
```json
{
  "file": "auth_spec.yaml",
  "template": {
    "type": "feature",
    "version": "1.0.0"
  },
  "validation": {
    "structural": {
      "status": "pass",
      "issues": []
    },
    "completeness": {
      "status": "warning",
      "issues": [
        {
          "line": 45,
          "severity": "warning",
          "message": "FR-3 missing acceptance criteria",
          "rule": "requirement_acceptance_criteria"
        }
      ]
    },
    "ambiguity": {
      "status": "error",
      "issues": [
        {
          "line": 23,
          "severity": "error",
          "message": "\"should be fast\" - quantify performance",
          "rule": "ambiguous_language",
          "suggestion": "Specify exact threshold (e.g., \"responds in <200ms\")"
        }
      ]
    }
  },
  "quality_score": {
    "total": 78,
    "max": 100,
    "grade": "C+",
    "breakdown": {
      "completeness": 32,
      "quality": 34,
      "detail": 12
    }
  },
  "summary": {
    "errors": 1,
    "warnings": 2,
    "suggestions": 3
  }
}
```

**Exit Codes:**
- `0`: Validation passed
- `1`: Validation failed (errors found) or score below --min-score
- `2`: Invalid spec file or parse error

---

### `speccraft analyze`

**Purpose:** Get AI-powered suggestions for improving a specification

**Syntax:**
```bash
speccraft analyze [SPEC_FILE] [OPTIONS]
```

**Arguments:**
| Argument | Type | Required | Description |
|----------|------|----------|-------------|
| `SPEC_FILE` | path | Yes | Specification file to analyze |

**Options:**
| Flag | Short | Type | Description | Default |
|------|-------|------|-------------|---------|
| `--focus` | | choice | Focus area (completeness, clarity, quality, all) | all |
| `--format` | `-f` | choice | Output format (console, json, markdown) | console |
| `--no-validate` | | flag | Skip validation before analysis | False |

**Examples:**
```bash
# Full analysis
speccraft analyze auth_spec.yaml

# Focus on specific area
speccraft analyze auth_spec.yaml --focus clarity

# JSON output for processing
speccraft analyze auth_spec.yaml --format json
```

**Output:**
```
🔍 Analyzing: auth_spec.yaml

Running validation first...
✅ Structural validation passed
⚠️  2 warnings found

Analyzing with AI... ⠋

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 ANALYSIS RESULTS

Completeness (3 suggestions):
  ✦ Add edge case: "User OAuth email already exists as local account"
  ✦ Consider security requirement: "Rate limiting on auth endpoints"
  ✦ Missing success metrics: How will you measure auth system success?

Clarity (2 suggestions):
  ✦ FR-1: "secure authentication" is vague - specify encryption, password rules
  ✦ NFR-1: Define "high availability" - target uptime percentage?

Quality (1 suggestion):
  ✦ Strong requirement structure overall
  ✦ Consider adding rationale for OAuth provider choices

Missing Risks:
  ✦ OAuth provider API changes or deprecation
  ✦ Session management at scale

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 Implementing these suggestions could improve score to: 88/100 (B+)
```

**Exit Codes:**
- `0`: Analysis completed
- `1`: Analysis failed (API error, invalid spec)
- `2`: AI feature not configured (missing API key)

---

### `speccraft templates`

**Purpose:** Manage specification templates

**Subcommands:**

#### `speccraft templates list`
List available templates

```bash
speccraft templates list [OPTIONS]

Options:
  --show-custom    Include custom templates
  --verbose   -v   Show detailed template information
```

**Output:**
```
Available Templates:

Built-in:
  feature       User-facing features and functionality
  api           RESTful APIs, GraphQL, gRPC interfaces
  architecture  System design and technical decisions
  data          Database schemas and data models
  integration   Third-party integrations

Custom (.speccraft/templates/):
  feature-fintech   Feature template with compliance requirements
  api-internal      Internal API template with auth requirements

Use: speccraft create --type <template-name>
```

#### `speccraft templates info`
Show template details

```bash
speccraft templates info <TEMPLATE_NAME>
```

**Output:**
```
Template: feature
Version: 1.0.0
Type: Built-in
Author: SpecCraft Team

Description:
  Template for user-facing features and functionality.
  Includes sections for requirements, edge cases, dependencies, and risks.

Required Fields:
  • title
  • overview
  • functional_requirements

Optional Fields:
  • non_functional_requirements
  • edge_cases
  • constraints
  • dependencies
  • risks

Validation Rules: 8 rules
  ✓ All requirements must have acceptance criteria
  ✓ No ambiguous language (should, might, etc.)
  ⚠ Edge cases should be documented

Example: speccraft templates example feature
```

#### `speccraft templates create`
Create a custom template

```bash
speccraft templates create [OPTIONS]

Options:
  --name NAME       Name for custom template
  --base TEMPLATE   Base template to extend
  --output PATH     Output path for template file
```

#### `speccraft templates example`
Show example specification for a template

```bash
speccraft templates example <TEMPLATE_NAME>
```

---

### `speccraft init`

**Purpose:** Initialize SpecCraft in a project

**Syntax:**
```bash
speccraft init [OPTIONS]
```

**Options:**
| Flag | Short | Description | Default |
|------|-------|-------------|---------|
| `--force` | `-f` | Overwrite existing config | False |

**Behavior:**
- Creates `.speccraft/` directory
- Generates default `config.yaml`
- Creates `specs/` directory for specifications
- Adds `.speccraft/` to `.gitignore`

**Output:**
```
✨ Initializing SpecCraft...

Created:
  .speccraft/config.yaml
  .speccraft/templates/
  specs/

Updated:
  .gitignore

✅ SpecCraft initialized!

Next steps:
  1. Configure: .speccraft/config.yaml
  2. Create spec: speccraft create
  3. Read docs: https://speccraft.dev/docs
```

---

### `speccraft config`

**Purpose:** View or edit configuration

**Syntax:**
```bash
speccraft config [KEY] [VALUE] [OPTIONS]
```

**Examples:**
```bash
# View all config
speccraft config

# View specific key
speccraft config validation.min_quality_score

# Set value
speccraft config validation.strict_mode true

# Edit in $EDITOR
speccraft config --edit
```

---

### Global Options

All commands support these global options:

| Flag | Short | Description | Default |
|------|-------|-------------|---------|
| `--help` | `-h` | Show help message | |
| `--version` | | Show SpecCraft version | |
| `--verbose` | `-v` | Verbose output | False |
| `--quiet` | `-q` | Suppress non-error output | False |
| `--no-color` | | Disable colored output | False |
| `--config` | `-c` | Path to config file | `.speccraft/config.yaml` |

---

## Output Formatting

### Color Scheme

- ✅ **Green**: Success, passed validation
- ❌ **Red**: Errors, failed validation
- ⚠️  **Yellow**: Warnings
- 💡 **Blue**: Suggestions, info
- 📊 **Cyan**: Metrics, scores

### Progress Indicators

For long-running operations:
```
Analyzing with AI... ⠋  (spinner)
Validating specs... ████████░░ 80% (progress bar)
```

### Tables

Use Rich tables for structured data:
```
┏━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━┓
┃ Category ┃ Score   ┃ Grade ┃
┡━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━┩
│ Complete │  32/40  │   B   │
│ Quality  │  34/40  │   B   │
│ Detail   │  12/20  │   C   │
└──────────┴─────────┴───────┘
```

---

## Non-Functional Requirements

### Performance
- Command startup: <100ms
- Validation (small spec): <200ms
- Tab completion: <50ms

### Usability
- All commands have helpful error messages
- `--help` available for all commands
- Examples in help text
- Suggestions when command is misspelled

### Reliability
- Graceful error handling
- No crashes on invalid input
- Clear error messages with remediation steps

### Compatibility
- Works on macOS, Linux, Windows
- Python 3.10+
- Terminal width auto-detection

---

## Error Handling

### Error Message Format

```
❌ Error: Invalid specification file

File: auth_spec.yaml
Line: 23
Issue: YAML parsing error - unexpected token

  21 | requirements:
  22 |   - id: FR-1
> 23 |     description = "User login"
         ~~~~~~~~~~~~^
  24 |     priority: high

Expected: ':' after field name
Got: '='

💡 Tip: YAML uses colons, not equals signs for key-value pairs
```

### Error Categories

1. **User Errors** (exit code 1)
   - Invalid command options
   - File not found
   - Validation failures

2. **System Errors** (exit code 2)
   - Parse errors
   - IO errors
   - API failures

3. **Configuration Errors** (exit code 3)
   - Invalid config file
   - Missing required config
   - API key issues

---

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Validate Specs

on: [pull_request]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install SpecCraft
        run: pip install speccraft
        
      - name: Validate Specifications
        run: |
          speccraft validate specs/*.yaml \
            --format json \
            --min-score 80 \
            --output validation-report.json
            
      - name: Upload Report
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: validation-report
          path: validation-report.json
```

### GitLab CI Example

```yaml
validate-specs:
  stage: test
  script:
    - pip install speccraft
    - speccraft validate specs/*.yaml --min-score 80 --format json
  artifacts:
    when: on_failure
    reports:
      json: validation-report.json
```

---

## Future Enhancements

- **Tab Completion:** Bash/Zsh completion for commands and options
- **Interactive Mode:** Full TUI for spec creation and editing
- **Diff Command:** Compare two spec versions
- **Export Command:** Generate docs from specs (PDF, HTML, etc.)
- **Stats Command:** Analytics on spec quality trends
- **AI Chat:** Conversational interface for spec improvement

---

## Open Questions

1. Should we support spec "profiles" (e.g., `--profile strict` for extra validation)?
2. How should we handle specs in subdirectories (recursive search)?
3. Should `validate` command auto-fix simple issues with a `--fix` flag?
4. Do we need a `speccraft check` command that's faster but less thorough?
5. Should we support piping specs from stdin?
