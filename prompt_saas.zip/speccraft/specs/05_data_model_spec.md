# Data Model Specification: Core Data Structures

**Type:** Data Specification  
**Version:** 1.0.0  
**Author:** Engineering Team  
**Created:** September 30, 2025  
**Status:** Draft  

---

## Overview

This specification defines the core data models for SpecCraft. These models represent specifications, requirements, templates, and validation results. The models are designed to be:

- **Serializable**: Easy to convert to/from YAML and JSON
- **Validated**: Type-safe with schema validation
- **Extensible**: Support for custom fields and extensions
- **Versioned**: Backward-compatible evolution

## Data Models

### 1. Specification

**Purpose:** Root object representing a complete specification

**Schema:**

```yaml
Specification:
  # Core metadata
  type: SpecType                  # enum: feature, api, architecture, data, integration
  version: string                 # semantic version (e.g., "1.0.0")
  template_version: string        # template version used to create this spec
  
  # Identity
  id: string                      # unique identifier (UUID or slug)
  title: string                   # concise title (5-100 chars)
  status: SpecStatus              # enum: draft, review, approved, deprecated
  
  # Authorship
  author: string                  # primary author name
  created: datetime               # creation timestamp
  updated: datetime               # last update timestamp
  reviewers: list<string>         # list of reviewer names
  
  # Content
  overview: string                # high-level description (min 50 chars)
  
  # Requirements
  functional_requirements: list<Requirement>
  non_functional_requirements: list<Requirement>
  
  # Additional context
  constraints: list<string>       # technical, legal, business constraints
  edge_cases: list<EdgeCase>      # unusual scenarios
  dependencies: list<Dependency>  # external systems/services
  risks: list<Risk>               # potential problems
  
  # Success criteria
  success_metrics: list<Metric>   # how to measure success
  
  # Type-specific fields (optional)
  api_spec: APISpecification      # only for type=api
  data_spec: DataSpecification    # only for type=data
  arch_spec: ArchSpecification    # only for type=architecture
  
  # Metadata
  tags: list<string>              # categorization tags
  related_specs: list<string>     # references to other spec IDs
  custom_fields: map<string, any> # extensibility
```

**Constraints:**
- `id` must be unique across all specs
- `title` length: 5-100 characters
- `overview` length: 50-5000 characters
- `created` cannot be in the future
- `updated` must be >= `created`
- At least one functional requirement is required
- If `status` is "approved", must have at least one reviewer

**Indexes:**
- Primary: `id`
- Secondary: `type`, `status`, `author`, `tags`

---

### 2. Requirement

**Purpose:** A single functional or non-functional requirement

**Schema:**

```yaml
Requirement:
  # Identity
  id: string                      # unique within spec (e.g., "FR-1", "NFR-2")
  type: RequirementType           # enum: functional, non_functional
  
  # Content
  description: string             # what this requirement specifies (min 10 chars)
  rationale: string               # why this requirement exists (optional)
  
  # Classification
  priority: Priority              # enum: critical, high, medium, low
  category: string                # custom categorization (optional)
  
  # Verification
  acceptance_criteria: list<string>  # measurable criteria (min 1 item)
  test_cases: list<string>        # test case IDs (optional)
  
  # Dependencies
  depends_on: list<string>        # other requirement IDs
  blocks: list<string>            # requirements blocked by this one
  
  # Metadata
  status: RequirementStatus       # enum: proposed, accepted, implemented, rejected
  assigned_to: string             # team/person responsible (optional)
  estimated_effort: string        # effort estimate (optional)
```

**Constraints:**
- `id` must be unique within the specification
- `id` should follow pattern: `(FR|NFR)-\d+` (e.g., "FR-1", "NFR-3")
- `description` length: 10-500 characters
- `acceptance_criteria` must have at least 1 item
- `depends_on` IDs must reference existing requirements
- No circular dependencies allowed

**Validation Rules:**
- Description must not contain ambiguous words: "should", "might", "could", "maybe"
- Acceptance criteria must be measurable/verifiable
- Critical/High priority requirements should have rationale

---

### 3. EdgeCase

**Purpose:** Document unusual or boundary scenarios

**Schema:**

```yaml
EdgeCase:
  scenario: string                # description of the edge case
  expected_behavior: string       # how the system should handle it
  mitigation: string              # how to prevent/handle this case (optional)
  likelihood: Likelihood          # enum: rare, occasional, common
  impact: Impact                  # enum: low, medium, high, critical
```

**Constraints:**
- `scenario` length: 10-500 characters
- `expected_behavior` length: 10-500 characters

**Examples:**
```yaml
- scenario: "User attempts OAuth login but provider is down"
  expected_behavior: "Show friendly error, fall back to email/password option"
  likelihood: occasional
  impact: medium
```

---

### 4. Risk

**Purpose:** Potential problems and their mitigations

**Schema:**

```yaml
Risk:
  description: string             # what could go wrong
  severity: Priority              # impact if it occurs
  probability: Probability        # likelihood of occurring
  mitigation: string              # how to prevent/reduce this risk
  contingency: string             # what to do if it happens (optional)
  owner: string                   # who's responsible for monitoring (optional)
```

**Constraints:**
- `description` length: 10-500 characters
- `mitigation` is required for high/critical severity risks

**Risk Score:**
```
risk_score = severity_value * probability_value
where:
  critical=4, high=3, medium=2, low=1
  very_likely=4, likely=3, possible=2, unlikely=1
```

---

### 5. Dependency

**Purpose:** External systems, services, or teams required

**Schema:**

```yaml
Dependency:
  name: string                    # dependency name
  type: DependencyType            # enum: service, library, team, data, infrastructure
  description: string             # what it provides
  version: string                 # version or version constraint (optional)
  critical: boolean               # is this a blocking dependency?
  contact: string                 # owner/contact (optional)
  status: DependencyStatus        # enum: available, planned, at_risk, unavailable
```

---

### 6. Metric

**Purpose:** Success criteria and measurements

**Schema:**

```yaml
Metric:
  name: string                    # metric name
  description: string             # what this measures
  target: string                  # target value (e.g., "< 200ms", "> 95%")
  measurement_method: string      # how to measure this
  priority: Priority              # importance of this metric
```

**Example:**
```yaml
- name: "Login Success Rate"
  description: "Percentage of successful login attempts"
  target: "> 99.5%"
  measurement_method: "Production logs, weekly average"
  priority: high
```

---

### 7. Template

**Purpose:** Specification template definition

**Schema:**

```yaml
Template:
  # Metadata
  name: string                    # template identifier
  version: string                 # template version
  type: SpecType                  # what kind of specs this produces
  description: string             # template purpose
  author: string                  # template author
  
  # Structure
  fields: list<TemplateField>     # field definitions
  sections: list<Section>         # organized sections
  
  # Validation
  validation_rules: list<ValidationRule>
  
  # Inheritance
  extends: string                 # base template name (optional)
  
  # Examples
  examples: list<string>          # paths to example specs
```

---

### 8. TemplateField

**Purpose:** Field definition within a template

**Schema:**

```yaml
TemplateField:
  name: string                    # field name
  type: FieldType                 # data type
  required: boolean               # is this field required?
  description: string             # help text
  default: any                    # default value (optional)
  validation: FieldValidation     # validation rules (optional)
  placeholder: string             # example/placeholder text (optional)
  section: string                 # which section this belongs to (optional)
```

**Field Types:**
- `text`: Single-line string
- `textarea`: Multi-line string
- `list`: Array of items
- `object`: Nested object
- `enum`: Predefined choices
- `date`: Date/timestamp
- `number`: Numeric value
- `boolean`: True/false
- `requirement`: Requirement object
- `edge_case`: EdgeCase object
- `risk`: Risk object

**Validation:**
```yaml
FieldValidation:
  min_length: int                 # minimum string length
  max_length: int                 # maximum string length
  pattern: string                 # regex pattern
  min_items: int                  # minimum list items
  max_items: int                  # maximum list items
  min_value: number               # minimum numeric value
  max_value: number               # maximum numeric value
  choices: list<string>           # allowed values for enum
  custom_rule: string             # custom validation rule name
```

---

### 9. ValidationResult

**Purpose:** Result of validating a specification

**Schema:**

```yaml
ValidationResult:
  # Summary
  spec_id: string                 # which spec was validated
  timestamp: datetime             # when validation ran
  passed: boolean                 # overall pass/fail
  
  # Issues
  errors: list<Issue>             # critical problems
  warnings: list<Issue>           # recommended fixes
  suggestions: list<Issue>        # nice-to-have improvements
  
  # Quality
  quality_score: QualityScore     # calculated quality metrics
  
  # Details
  validations_run: list<string>   # which validators ran
  duration_ms: int                # validation duration
```

---

### 10. Issue

**Purpose:** A single validation issue

**Schema:**

```yaml
Issue:
  rule_id: string                 # validation rule that triggered
  severity: Severity              # error, warning, suggestion
  message: string                 # human-readable description
  location: Location              # where in the spec
  suggestion: string              # how to fix (optional)
  documentation: string           # link to docs (optional)
```

**Location:**
```yaml
Location:
  file: string                    # file path
  line: int                       # line number (optional)
  column: int                     # column number (optional)
  field: string                   # field path (e.g., "requirements[2].description")
```

---

### 11. QualityScore

**Purpose:** Quantitative spec quality metrics

**Schema:**

```yaml
QualityScore:
  # Overall
  total: int                      # 0-100
  grade: string                   # A, B, C, D, F
  
  # Breakdown
  completeness: int               # 0-40
  quality: int                    # 0-40
  detail: int                     # 0-20
  
  # Details
  breakdown: map<string, any>     # detailed scoring
  recommendations: list<string>   # how to improve
```

---

## Enumerations

```yaml
SpecType:
  - feature
  - api
  - architecture
  - data
  - integration

SpecStatus:
  - draft
  - review
  - approved
  - implemented
  - deprecated

RequirementType:
  - functional
  - non_functional

Priority:
  - critical
  - high
  - medium
  - low

RequirementStatus:
  - proposed
  - accepted
  - implemented
  - rejected

Probability:
  - very_likely
  - likely
  - possible
  - unlikely

Likelihood:
  - rare
  - occasional
  - common

Impact:
  - low
  - medium
  - high
  - critical

DependencyType:
  - service
  - library
  - team
  - data
  - infrastructure

DependencyStatus:
  - available
  - planned
  - at_risk
  - unavailable

Severity:
  - error
  - warning
  - suggestion
  - info
```

---

## Serialization Formats

### YAML (Primary)

```yaml
type: feature
version: 1.0.0
title: User Authentication
author: Alice Chen
created: 2025-09-30T10:00:00Z

overview: |
  Implement secure user authentication with email/password and OAuth2.

functional_requirements:
  - id: FR-1
    description: Users can register with email and password
    priority: high
    acceptance_criteria:
      - Email validation is performed
      - Password must be at least 12 characters
      - Confirmation email is sent
```

### JSON (For APIs)

```json
{
  "type": "feature",
  "version": "1.0.0",
  "title": "User Authentication",
  "author": "Alice Chen",
  "created": "2025-09-30T10:00:00Z",
  "overview": "Implement secure user authentication...",
  "functional_requirements": [
    {
      "id": "FR-1",
      "description": "Users can register with email and password",
      "priority": "high",
      "acceptance_criteria": [
        "Email validation is performed",
        "Password must be at least 12 characters",
        "Confirmation email is sent"
      ]
    }
  ]
}
```

---

## Storage

### File System (V1)
- Specs stored as individual YAML files
- Templates stored in `templates/` directory
- Validation results cached in `.speccraft/cache/`

### Future: Database
- SQLite for local storage
- PostgreSQL for team/server deployment
- Graph database for dependency analysis

---

## Versioning

### Specification Versioning
- Semantic versioning: `major.minor.patch`
- Major: Breaking changes to requirements
- Minor: New requirements added
- Patch: Clarifications, typo fixes

### Schema Versioning
- Data models versioned independently
- Migration scripts for schema changes
- Backward compatibility for at least 2 major versions

---

## Validation

### Schema Validation
- JSON Schema for structural validation
- Type checking for all fields
- Range and pattern validation

### Business Logic Validation
- No circular requirement dependencies
- Unique IDs within scope
- Valid references
- Consistent state (e.g., approved specs have reviewers)

### Custom Validation
- Plugin system for custom validators
- Team-specific rules
- Domain-specific constraints

---

## Open Questions

1. Should we support spec composition (one spec references another)?
2. How do we handle very large specs (1000+ requirements)?
3. Should specs be immutable once approved (append-only history)?
4. Do we need a query language for specs (like GraphQL)?
5. How do we handle spec localization/internationalization?

---

## Future Enhancements

- **Spec Database**: Query specs like a database
- **Spec Linking**: Cross-spec references and dependency graphs
- **Spec Diffing**: Visual diff between versions
- **Spec Merging**: Combine specs (e.g., for releases)
- **Spec Analytics**: Aggregate metrics across many specs
- **Spec Generation**: AI-generated specs from conversations
