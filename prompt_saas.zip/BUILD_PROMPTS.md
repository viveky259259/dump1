# PromptSaaS - Step-by-Step Build Prompts

This document contains comprehensive prompts to build the PromptSaaS application from scratch. Each prompt focuses on one specific aspect and includes rules, constraints, and error checking guidelines.

## Master Prompt - Application Overview

**Objective**: Build a modern, full-stack SaaS application for managing AI prompts with Firebase authentication, AI enhancement capabilities, and a beautiful responsive UI.

**Core Features**:
- Firebase Authentication with Google Sign-in
- Prompt CRUD operations with Firestore database
- AI-powered prompt enhancement using Google Gemini API
- Responsive dashboard with search and filtering
- Demo mode with sample data
- Public/private prompt sharing
- Category and tag management

**Tech Stack**:
- Frontend: Next.js 14, React, TypeScript, Tailwind CSS
- Backend: Next.js API Routes
- Database: Firebase Firestore
- Authentication: Firebase Auth
- AI Integration: Google Gemini API
- UI Components: Radix UI, Lucide React

**Architecture**: Clean Architecture with separation of concerns across Presentation, Application, Domain, and Infrastructure layers.

---

## Step 1: Project Setup and Configuration

**Prompt**: Set up a Next.js 14 project with TypeScript, Tailwind CSS, and essential dependencies for building a prompt management SaaS application.

**Rules**:
- Use Next.js 14 with App Router
- Configure TypeScript with strict mode
- Set up Tailwind CSS with custom design system
- Install Radix UI components and Lucide React icons
- Configure ESLint and Prettier
- Set up environment variable management

**Constraints**:
- Node.js 18+ required
- Use npm as package manager
- Follow Next.js 14 best practices
- Ensure TypeScript strict mode compliance

**Configuration Details**:

### Package.json Configuration
```json
{
  "name": "prompt-saas",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "@google/generative-ai": "^0.2.1",
    "@radix-ui/react-dialog": "^1.0.5",
    "@radix-ui/react-label": "^2.0.2",
    "@radix-ui/react-slot": "^1.0.2",
    "@vercel/analytics": "^1.5.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "firebase": "^12.3.0",
    "lucide-react": "^0.294.0",
    "next": "^14.2.33",
    "react": "^18",
    "react-dom": "^18",
    "tailwind-merge": "^2.2.0",
    "tailwindcss-animate": "^1.0.7"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "autoprefixer": "^10.0.1",
    "eslint": "^8",
    "eslint-config-next": "14.0.4",
    "postcss": "^8",
    "tailwindcss": "^3.3.0",
    "typescript": "^5"
  }
}
```

### TypeScript Configuration (tsconfig.json)
```json
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "es6"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

### Tailwind CSS Configuration (tailwind.config.js)
```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
```

### Next.js Configuration (next.config.js)
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  images: {
    domains: ['lh3.googleusercontent.com'],
  },
  env: {
    NEXT_PUBLIC_BUILD_TIME: process.env.NEXT_PUBLIC_BUILD_TIME,
  },
}

module.exports = nextConfig
```

### Environment Variables (.env.local)
```env
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=your-firebase-api-key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your-sender-id
NEXT_PUBLIC_FIREBASE_APP_ID=your-app-id

# Gemini AI API
GEMINI_API_KEY=your-gemini-api-key

# NextAuth (if using)
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=http://localhost:3000
```

### ESLint Configuration (.eslintrc.json)
```json
{
  "extends": "next/core-web-vitals"
}
```

### PostCSS Configuration (postcss.config.js)
```javascript
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

**Error Checking**:
- Verify all dependencies install without conflicts
- Check TypeScript compilation passes
- Ensure Tailwind CSS builds correctly
- Validate ESLint configuration
- Test development server starts successfully

**Expected Output**:
- Working Next.js 14 project structure
- Configured TypeScript and Tailwind CSS
- Essential UI component dependencies installed
- Development environment ready

---

## Step 2: Firebase Configuration and Authentication Setup

**Prompt**: Configure Firebase project with Authentication and Firestore, implement Google Sign-in authentication flow with proper error handling and user state management.

**Rules**:
- Set up Firebase project with Authentication and Firestore
- Configure Google OAuth provider
- Implement Firebase initialization with environment variables
- Create authentication context with React Context API
- Handle authentication state changes
- Implement sign-in, sign-out, and user state persistence

**Constraints**:
- Use Firebase v9+ modular SDK
- Implement proper error handling for auth failures
- Ensure environment variables are properly configured
- Handle Firebase initialization failures gracefully
- Follow Firebase security best practices

**Configuration Details**:

### Firebase Project Setup
1. Create Firebase project at https://console.firebase.google.com
2. Enable Authentication with Google provider
3. Enable Firestore Database
4. Configure OAuth consent screen
5. Add authorized domains for production

### Firebase Configuration (lib/firebase.ts)
```typescript
import { initializeApp } from 'firebase/app'
import { getAuth, GoogleAuthProvider } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

// Only initialize Firebase if we have the required config
let app: any = null
let auth: any = null
let googleProvider: any = null
let db: any = null

if (firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId) {
  try {
    // Initialize Firebase
    app = initializeApp(firebaseConfig)

    // Initialize Firebase Auth
    auth = getAuth(app)

    // Initialize Google Auth Provider
    googleProvider = new GoogleAuthProvider()

    // Initialize Firestore
    db = getFirestore(app)
  } catch (error) {
    console.warn('Firebase initialization failed:', error)
  }
} else {
  console.warn('Firebase configuration incomplete, skipping initialization')
}

export { auth, googleProvider, db }
export default app
```

### Authentication Context (lib/auth-context.tsx)
```typescript
'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth'
import { auth, googleProvider } from './firebase'

interface AuthUser {
  id: string
  email: string
  name: string
  image?: string
}

interface AuthContextType {
  user: AuthUser | null
  firebaseUser: User | null
  loading: boolean
  signInWithGoogle: () => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  firebaseUser: null,
  loading: true,
  signInWithGoogle: async () => {},
  logout: async () => {}
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Only set up Firebase auth listener if Firebase is initialized
    if (!auth) {
      console.warn('Firebase auth not initialized, using demo mode')
      setLoading(false)
      return
    }

    // Set up Firebase auth listener
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      console.log('AuthContext: Firebase auth state changed:', {
        email: firebaseUser?.email,
        displayName: firebaseUser?.displayName,
        photoURL: firebaseUser?.photoURL,
        uid: firebaseUser?.uid
      })
      
      setFirebaseUser(firebaseUser)
      
      if (firebaseUser) {
        // Convert Firebase user to our AuthUser format
        const authUser: AuthUser = {
          id: firebaseUser.uid,
          email: firebaseUser.email || '',
          name: firebaseUser.displayName || firebaseUser.email || 'User',
          image: firebaseUser.photoURL || undefined
        }
        setUser(authUser)
      } else {
        setUser(null)
      }
      
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const signInWithGoogle = async () => {
    try {
      setLoading(true)
      
      if (!auth || !googleProvider) {
        throw new Error('Firebase authentication not available')
      }
      
      const result = await signInWithPopup(auth, googleProvider)
      console.log('Sign in successful:', result.user.email)
    } catch (error) {
      console.error('Error signing in with Google:', error)
      setLoading(false)
      throw error
    }
  }

  const logout = async () => {
    try {
      if (!auth) {
        throw new Error('Firebase authentication not available')
      }
      
      await signOut(auth)
      console.log('Sign out successful')
    } catch (error) {
      console.error('Error signing out:', error)
      throw error
    }
  }

  const value = {
    user,
    firebaseUser,
    loading,
    signInWithGoogle,
    logout
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
```

### Firebase Security Rules (firestore.rules)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can only access their own user document
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Users can only access their own prompts
    match /prompts/{promptId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && request.auth.uid == request.resource.data.userId;
    }
    
    // Public prompts can be read by anyone
    match /prompts/{promptId} {
      allow read: if resource.data.isPublic == true;
    }
  }
}
```

### Firebase Indexes (firestore.indexes.json)
```json
{
  "indexes": [
    {
      "collectionGroup": "prompts",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "userId",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "createdAt",
          "order": "DESCENDING"
        }
      ]
    },
    {
      "collectionGroup": "prompts",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "isPublic",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "createdAt",
          "order": "DESCENDING"
        }
      ]
    },
    {
      "collectionGroup": "prompts",
      "queryScope": "COLLECTION",
      "fields": [
        {
          "fieldPath": "userId",
          "order": "ASCENDING"
        },
        {
          "fieldPath": "category",
          "order": "ASCENDING"
        }
      ]
    }
  ],
  "fieldOverrides": []
}
```

### Firebase Configuration File (firebase.json)
```json
{
  "firestore": {
    "rules": "firestore.rules",
    "indexes": "firestore.indexes.json"
  }
}
```

### Environment Variables for Firebase
```env
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSyCPkH1FJ0HDWSn0CvMelJpB7j7nWWTnctU
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.firebasestorage.app
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=963076663974
NEXT_PUBLIC_FIREBASE_APP_ID=1:963076663974:web:b468c7e0a6669e19dca267
```

**Error Checking**:
- Verify Firebase configuration is complete
- Test Google Sign-in flow works correctly
- Check authentication state persistence
- Validate error handling for network failures
- Ensure proper cleanup of auth listeners

**Expected Output**:
- Firebase project configured with Auth and Firestore
- Working Google Sign-in authentication
- Authentication context provider
- User state management with loading states

---

## Step 3: Database Schema and Firestore Service Layer

**Prompt**: Design and implement Firestore database schema for prompts and users, create service layer with CRUD operations, implement proper data validation and error handling.

**Rules**:
- Design Firestore collections: `users` and `prompts`
- Implement proper data validation with TypeScript interfaces
- Create service layer with singleton pattern
- Implement CRUD operations for prompts
- Add user isolation (users can only access their own data)
- Implement local state management with observer pattern

**Constraints**:
- Use Firestore security rules for data protection
- Implement proper indexing for queries
- Handle Firestore errors gracefully
- Ensure data consistency and validation
- Follow Firestore best practices for queries

**Configuration Details**:

### Database Schema Design

#### Users Collection Schema
```typescript
interface User {
  id: string
  email: string
  name: string
  image?: string
  createdAt: Timestamp
  updatedAt: Timestamp
}
```

#### Prompts Collection Schema
```typescript
interface Prompt {
  id: string
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
  userId: string
  createdAt: Timestamp
  updatedAt: Timestamp
}
```

### Firestore Service Implementation (lib/services/firestore-prompt.service.ts)
```typescript
import { 
  collection, 
  doc, 
  addDoc, 
  getDocs, 
  getDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  Timestamp 
} from 'firebase/firestore'
import { db } from '../firebase'

export interface Prompt {
  id: string
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
  userId: string
  createdAt: string
  updatedAt: string
}

export interface CreatePromptData {
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
}

export interface UpdatePromptData extends Partial<CreatePromptData> {
  id: string
}

class FirestorePromptService {
  private static instance: FirestorePromptService
  private prompts: Prompt[] = []
  private listeners: Set<(prompts: Prompt[]) => void> = new Set()

  private constructor() {}

  static getInstance(): FirestorePromptService {
    if (!FirestorePromptService.instance) {
      FirestorePromptService.instance = new FirestorePromptService()
    }
    return FirestorePromptService.instance
  }

  subscribe(listener: (prompts: Prompt[]) => void): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener([...this.prompts]))
  }

  private convertFirestorePrompt(doc: any): Prompt {
    const data = doc.data()
    return {
      id: doc.id,
      title: data.title,
      content: data.content,
      description: data.description || null,
      category: data.category || null,
      tags: data.tags || [],
      isPublic: data.isPublic || false,
      userId: data.userId,
      createdAt: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
      updatedAt: data.updatedAt?.toDate?.()?.toISOString() || new Date().toISOString()
    }
  }

  async fetchPrompts(userId: string): Promise<Prompt[]> {
    try {
      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptsRef = collection(db, 'prompts')
      const q = query(
        promptsRef,
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      )

      const querySnapshot = await getDocs(q)
      const prompts = querySnapshot.docs.map(doc => this.convertFirestorePrompt(doc))
      
      this.prompts = prompts
      this.notifyListeners()
      
      return prompts
    } catch (error) {
      console.error('Error fetching prompts:', error)
      throw new Error('Failed to fetch prompts')
    }
  }

  async createPrompt(userId: string, data: CreatePromptData): Promise<Prompt> {
    try {
      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptsRef = collection(db, 'prompts')
      const now = Timestamp.now()
      
      const docData = {
        ...data,
        userId,
        createdAt: now,
        updatedAt: now
      }

      const docRef = await addDoc(promptsRef, docData)
      
      const newPrompt: Prompt = {
        id: docRef.id,
        ...data,
        userId,
        createdAt: now.toDate().toISOString(),
        updatedAt: now.toDate().toISOString()
      }

      this.prompts.unshift(newPrompt)
      this.notifyListeners()
      
      return newPrompt
    } catch (error) {
      console.error('Error creating prompt:', error)
      throw new Error('Failed to create prompt')
    }
  }

  async updatePrompt(userId: string, promptId: string, data: UpdatePromptData): Promise<Prompt> {
    try {
      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptRef = doc(db, 'prompts', promptId)
      const updateData = {
        ...data,
        updatedAt: Timestamp.now()
      }

      await updateDoc(promptRef, updateData)

      const updatedPrompt = this.prompts.find(p => p.id === promptId)
      if (updatedPrompt) {
        Object.assign(updatedPrompt, data, {
          updatedAt: new Date().toISOString()
        })
        this.notifyListeners()
        return updatedPrompt
      }

      throw new Error('Prompt not found')
    } catch (error) {
      console.error('Error updating prompt:', error)
      throw new Error('Failed to update prompt')
    }
  }

  async deletePrompt(userId: string, promptId: string): Promise<void> {
    try {
      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptRef = doc(db, 'prompts', promptId)
      await deleteDoc(promptRef)

      this.prompts = this.prompts.filter(p => p.id !== promptId)
      this.notifyListeners()
    } catch (error) {
      console.error('Error deleting prompt:', error)
      throw new Error('Failed to delete prompt')
    }
  }

  async getPromptById(userId: string, promptId: string): Promise<Prompt | null> {
    try {
      if (!db) {
        throw new Error('Firestore not initialized')
      }

      const promptRef = doc(db, 'prompts', promptId)
      const promptSnap = await getDoc(promptRef)

      if (promptSnap.exists()) {
        const prompt = this.convertFirestorePrompt(promptSnap)
        // Check if user owns this prompt or if it's public
        if (prompt.userId === userId || prompt.isPublic) {
          return prompt
        }
      }

      return null
    } catch (error) {
      console.error('Error fetching prompt:', error)
      throw new Error('Failed to fetch prompt')
    }
  }

  searchPrompts(userId: string, query: string): Prompt[] {
    const searchTerm = query.toLowerCase()
    return this.prompts.filter(prompt => 
      prompt.userId === userId && (
        prompt.title.toLowerCase().includes(searchTerm) ||
        prompt.content.toLowerCase().includes(searchTerm) ||
        prompt.tags.some(tag => tag.toLowerCase().includes(searchTerm))
      )
    )
  }

  filterByCategory(userId: string, category: string): Prompt[] {
    return this.prompts.filter(prompt => 
      prompt.userId === userId && prompt.category === category
    )
  }

  getPublicPrompts(): Prompt[] {
    return this.prompts.filter(prompt => prompt.isPublic)
  }
}

export default FirestorePromptService
```

### Custom Hook for Prompts (lib/hooks/usePrompts.ts)
```typescript
import { useState, useEffect, useCallback } from 'react'
import FirestorePromptService, { CreatePromptData, UpdatePromptData } from '../services/firestore-prompt.service'
import { demoPrompts } from '../demo-data'

interface UsePromptsReturn {
  prompts: any[]
  loading: boolean
  error: string | null
  createPrompt: (data: CreatePromptData) => Promise<void>
  updatePrompt: (data: UpdatePromptData) => Promise<void>
  deletePrompt: (id: string) => Promise<void>
  searchPrompts: (query: string) => any[]
  filterByCategory: (category: string) => any[]
  refreshPrompts: () => Promise<void>
}

export function usePrompts(isDemo: boolean = false): UsePromptsReturn {
  const [prompts, setPrompts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const service = FirestorePromptService.getInstance()

  const fetchPrompts = useCallback(async () => {
    if (isDemo) {
      setPrompts(demoPrompts)
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)
      // Note: userId should be passed from auth context
      // For now, using a placeholder
      const userId = 'current-user-id'
      const fetchedPrompts = await service.fetchPrompts(userId)
      setPrompts(fetchedPrompts)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch prompts')
    } finally {
      setLoading(false)
    }
  }, [isDemo, service])

  useEffect(() => {
    fetchPrompts()

    // Subscribe to prompt changes
    const unsubscribe = service.subscribe((updatedPrompts) => {
      setPrompts(updatedPrompts)
    })

    return unsubscribe
  }, [fetchPrompts, service])

  const createPrompt = useCallback(async (data: CreatePromptData) => {
    try {
      setError(null)
      const userId = 'current-user-id' // Should come from auth context
      await service.createPrompt(userId, data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create prompt')
      throw err
    }
  }, [service])

  const updatePrompt = useCallback(async (data: UpdatePromptData) => {
    try {
      setError(null)
      const userId = 'current-user-id' // Should come from auth context
      await service.updatePrompt(userId, data.id, data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update prompt')
      throw err
    }
  }, [service])

  const deletePrompt = useCallback(async (id: string) => {
    try {
      setError(null)
      const userId = 'current-user-id' // Should come from auth context
      await service.deletePrompt(userId, id)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete prompt')
      throw err
    }
  }, [service])

  const searchPrompts = useCallback((query: string) => {
    const userId = 'current-user-id' // Should come from auth context
    return service.searchPrompts(userId, query)
  }, [service])

  const filterByCategory = useCallback((category: string) => {
    const userId = 'current-user-id' // Should come from auth context
    return service.filterByCategory(userId, category)
  }, [service])

  const refreshPrompts = useCallback(async () => {
    await fetchPrompts()
  }, [fetchPrompts])

  return {
    prompts,
    loading,
    error,
    createPrompt,
    updatePrompt,
    deletePrompt,
    searchPrompts,
    filterByCategory,
    refreshPrompts
  }
}
```

### Demo Data Configuration (lib/demo-data.ts)
```typescript
export interface DemoPrompt {
  id: string
  title: string
  content: string
  description?: string | null
  category?: string | null
  tags: string[]
  isPublic: boolean
  createdAt: string
  updatedAt: string
}

export const demoUser = {
  id: 'demo-user',
  email: 'demo@promptsaas.com',
  name: 'Demo User',
  image: 'https://via.placeholder.com/150'
}

export const demoPrompts: DemoPrompt[] = [
  {
    id: '1',
    title: 'Code Review Assistant',
    content: 'Act as a senior software engineer conducting a thorough code review. Analyze the provided code for:\n\n1. **Code Quality**: Check for clean code principles, readability, and maintainability\n2. **Performance**: Identify potential performance bottlenecks and optimization opportunities\n3. **Security**: Look for security vulnerabilities and best practices\n4. **Testing**: Evaluate test coverage and suggest improvements\n5. **Architecture**: Assess design patterns and architectural decisions\n\nProvide specific, actionable feedback with examples and suggestions for improvement.',
    description: 'A comprehensive prompt for conducting thorough code reviews',
    category: 'Development',
    tags: ['code-review', 'development', 'best-practices', 'quality'],
    isPublic: true,
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z'
  },
  {
    id: '2',
    title: 'Product Description Generator',
    content: 'Create compelling product descriptions that drive sales. For the given product, generate:\n\n1. **Headline**: Attention-grabbing title (max 60 characters)\n2. **Key Benefits**: 3-5 main value propositions\n3. **Feature List**: Bullet points highlighting key features\n4. **Call-to-Action**: Persuasive CTA that encourages purchase\n5. **SEO Keywords**: Relevant keywords for search optimization\n\nMake the description persuasive, informative, and optimized for conversion.',
    description: 'Generate high-converting product descriptions',
    category: 'Marketing',
    tags: ['marketing', 'copywriting', 'ecommerce', 'sales'],
    isPublic: true,
    createdAt: '2024-01-14T15:30:00Z',
    updatedAt: '2024-01-14T15:30:00Z'
  },
  {
    id: '3',
    title: 'Technical Documentation Writer',
    content: 'Write comprehensive technical documentation that is clear, accurate, and user-friendly. Include:\n\n1. **Overview**: Brief introduction and purpose\n2. **Prerequisites**: Required knowledge and setup\n3. **Step-by-Step Instructions**: Detailed, numbered steps\n4. **Code Examples**: Well-commented code snippets\n5. **Troubleshooting**: Common issues and solutions\n6. **References**: Links to additional resources\n\nEnsure the documentation is accessible to both beginners and experienced users.',
    description: 'Create detailed technical documentation',
    category: 'Writing',
    tags: ['documentation', 'technical-writing', 'tutorials', 'guides'],
    isPublic: false,
    createdAt: '2024-01-13T09:15:00Z',
    updatedAt: '2024-01-13T09:15:00Z'
  }
]
```

**Error Checking**:
- Verify Firestore security rules work correctly
- Test CRUD operations with various data scenarios
- Check user isolation and data access control
- Validate error handling for network issues
- Ensure proper data validation and sanitization

**Expected Output**:
- Firestore collections with proper schema
- Service layer with CRUD operations
- Data validation and error handling
- User isolation and security rules

---

## Step 4: AI Integration with Google Gemini API

**Prompt**: Integrate Google Gemini API for prompt enhancement, create service for transforming simple prompts into comprehensive ones with proper error handling and response parsing.

**Rules**:
- Set up Google Generative AI SDK
- Create prompt enhancement service
- Implement structured prompt generation
- Handle API errors and rate limiting
- Parse and validate AI responses
- Implement fallback for API failures

**Constraints**:
- Use Gemini 1.5 Flash model for cost efficiency
- Implement proper API key management
- Handle response parsing errors gracefully
- Ensure prompt content is properly sanitized
- Follow Google AI API best practices

**Configuration Details**:

### Google Gemini API Setup
1. Get API key from Google AI Studio (https://makersuite.google.com/app/apikey)
2. Add API key to environment variables
3. Install Google Generative AI SDK
4. Configure model parameters and safety settings

### Gemini Service Implementation (lib/gemini-service.ts)
```typescript
import { GoogleGenerativeAI } from '@google/generative-ai'

const genAI = process.env.GEMINI_API_KEY ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY) : null

export interface PromptEnhancementRequest {
  simplePrompt: string
  category?: string
}

export interface PromptEnhancementResponse {
  enhancedPrompt: string
  title: string
  description: string
  suggestedCategory: string
  suggestedTags: string[]
}

export async function enhancePrompt(request: PromptEnhancementRequest): Promise<PromptEnhancementResponse> {
  try {
    if (!genAI) {
      throw new Error('Gemini API key not configured')
    }
    
    const model = genAI.getGenerativeModel({ 
      model: "gemini-1.5-flash",
      generationConfig: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 2048,
      },
      safetySettings: [
        {
          category: "HARM_CATEGORY_HARASSMENT",
          threshold: "BLOCK_MEDIUM_AND_ABOVE",
        },
        {
          category: "HARM_CATEGORY_HATE_SPEECH",
          threshold: "BLOCK_MEDIUM_AND_ABOVE",
        },
        {
          category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
          threshold: "BLOCK_MEDIUM_AND_ABOVE",
        },
        {
          category: "HARM_CATEGORY_DANGEROUS_CONTENT",
          threshold: "BLOCK_MEDIUM_AND_ABOVE",
        },
      ],
    })

    const prompt = `
You are an expert prompt engineer and technical consultant. Your task is to take a simple, unstructured prompt or app idea and transform it into a comprehensive, detailed prompt or project blueprint.

User's simple prompt: "${request.simplePrompt}"

Please generate a comprehensive response that includes:

1. **Enhanced Prompt Title**: A clear, descriptive title
2. **Brief Description**: A 1-2 sentence summary
3. **Suggested Category**: One of: Development, Writing, Analytics, Communication, Marketing, Productivity, Design, Research, Education, Other
4. **Suggested Tags**: 3-5 relevant tags
5. **Comprehensive Enhanced Prompt**: A detailed, structured prompt that includes:

   - **Project Overview**: Clear description of what needs to be built/created
   - **Functional Requirements**: Detailed features and capabilities
   - **Technical Specifications**: Technology stack, architecture, integrations
   - **User Experience Guidelines**: UI/UX considerations, user flows
   - **Non-Functional Requirements**: Performance, security, scalability, accessibility
   - **Implementation Phases**: Step-by-step development approach
   - **Success Metrics**: How to measure success
   - **Constraints & Assumptions**: Any limitations or assumptions
   - **Deliverables**: What should be produced

Format your response as JSON with the following structure:
{
  "title": "Enhanced Prompt Title",
  "description": "Brief description",
  "suggestedCategory": "Category name",
  "suggestedTags": ["tag1", "tag2", "tag3"],
  "enhancedPrompt": "The comprehensive enhanced prompt content"
}

Make the enhanced prompt detailed, actionable, and professional. Use markdown formatting for better readability.
`

    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()

    // Try to parse JSON response
    try {
      const parsed = JSON.parse(text)
      return {
        enhancedPrompt: parsed.enhancedPrompt,
        title: parsed.title,
        description: parsed.description,
        suggestedCategory: parsed.suggestedCategory,
        suggestedTags: parsed.suggestedTags
      }
    } catch (parseError) {
      // If JSON parsing fails, return the raw text
      return {
        enhancedPrompt: text,
        title: request.simplePrompt.substring(0, 50) + (request.simplePrompt.length > 50 ? '...' : ''),
        description: 'AI-enhanced prompt',
        suggestedCategory: request.category || 'Other',
        suggestedTags: ['ai-enhanced', 'comprehensive']
      }
    }
  } catch (error) {
    console.error('Error enhancing prompt with Gemini:', error)
    throw new Error('Failed to enhance prompt. Please try again.')
  }
}
```

### API Route for Prompt Enhancement (app/api/enhance-prompt/route.ts)
```typescript
import { NextRequest, NextResponse } from 'next/server'
import { enhancePrompt } from '@/lib/gemini-service'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { simplePrompt, category } = body

    if (!simplePrompt || simplePrompt.trim().length === 0) {
      return NextResponse.json({ error: 'Simple prompt is required' }, { status: 400 })
    }

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json({ 
        error: 'Gemini API key not configured. Please add GEMINI_API_KEY to your environment variables.' 
      }, { status: 500 })
    }

    const result = await enhancePrompt({
      simplePrompt: simplePrompt.trim(),
      category
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error in enhance-prompt API:', error)
    return NextResponse.json(
      { error: 'Failed to enhance prompt. Please try again.' }, 
      { status: 500 }
    )
  }
}
```

### Prompt Enhancement Dialog Component (components/prompt-enhancement-dialog.tsx)
```typescript
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Wand2, Loader2, Sparkles } from 'lucide-react'

interface PromptEnhancementDialogProps {
  onEnhancementComplete: (enhancedData: {
    title: string
    content: string
    description: string
    category: string
    tags: string[]
  }) => void
}

export function PromptEnhancementDialog({ onEnhancementComplete }: PromptEnhancementDialogProps) {
  const [open, setOpen] = useState(false)
  const [simplePrompt, setSimplePrompt] = useState('')
  const [category, setCategory] = useState('')
  const [isEnhancing, setIsEnhancing] = useState(false)
  const [error, setError] = useState('')

  const handleEnhance = async () => {
    if (!simplePrompt.trim()) {
      setError('Please enter a prompt or idea to enhance')
      return
    }

    setIsEnhancing(true)
    setError('')

    try {
      const response = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          simplePrompt: simplePrompt.trim(),
          category: category.trim() || undefined
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to enhance prompt')
      }

      const result = await response.json()
      
      onEnhancementComplete({
        title: result.title,
        content: result.enhancedPrompt,
        description: result.description,
        category: result.suggestedCategory,
        tags: result.suggestedTags
      })

      setOpen(false)
      setSimplePrompt('')
      setCategory('')
    } catch (error) {
      console.error('Error enhancing prompt:', error)
      setError('Failed to enhance prompt. Please try again.')
    } finally {
      setIsEnhancing(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full">
          <Wand2 className="w-4 h-4 mr-2" />
          Enhance with AI
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <span>AI Prompt Enhancement</span>
          </DialogTitle>
          <DialogDescription>
            Describe your idea or simple prompt, and our AI will generate a comprehensive, 
            detailed prompt with technical specifications, requirements, and best practices.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="simplePrompt">Your Idea or Simple Prompt</Label>
            <Textarea
              id="simplePrompt"
              placeholder="e.g., 'I want to build a task management app' or 'Create a prompt for writing product descriptions'"
              value={simplePrompt}
              onChange={(e) => setSimplePrompt(e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="category">Category (Optional)</Label>
            <Input
              id="category"
              placeholder="e.g., Development, Writing, Marketing"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleEnhance} disabled={isEnhancing || !simplePrompt.trim()}>
            {isEnhancing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Enhancing...
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4 mr-2" />
                Enhance Prompt
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
```

### Environment Variables for Gemini API
```env
# Gemini AI API
GEMINI_API_KEY=your-gemini-api-key-here
```

### Rate Limiting and Error Handling Configuration
```typescript
// Add to your API route for rate limiting
const rateLimitMap = new Map()

export function rateLimit(identifier: string, limit: number = 10, windowMs: number = 60000) {
  const now = Date.now()
  const windowStart = now - windowMs
  
  if (!rateLimitMap.has(identifier)) {
    rateLimitMap.set(identifier, [])
  }
  
  const requests = rateLimitMap.get(identifier)
  const validRequests = requests.filter((time: number) => time > windowStart)
  
  if (validRequests.length >= limit) {
    return false
  }
  
  validRequests.push(now)
  rateLimitMap.set(identifier, validRequests)
  return true
}
```

**Error Checking**:
- Verify API key configuration
- Test prompt enhancement with various inputs
- Check error handling for API failures
- Validate response parsing and structure
- Ensure proper fallback mechanisms

**Expected Output**:
- Working Gemini API integration
- Prompt enhancement service
- Structured AI response handling
- Error handling and fallback mechanisms

---

## Step 5: Core UI Components and Design System

**Prompt**: Create reusable UI components using Radix UI primitives, implement consistent design system with Tailwind CSS, and build core components for the application.

**Rules**:
- Create reusable UI components (Button, Card, Input, Textarea, Dialog, etc.)
- Implement consistent design system with Tailwind CSS
- Use Radix UI primitives for accessibility
- Create responsive layouts and components
- Implement proper component composition
- Add loading states and animations

**Constraints**:
- Ensure all components are accessible (WCAG compliant)
- Use consistent spacing and typography
- Implement responsive design patterns
- Follow Radix UI best practices
- Ensure components are properly typed with TypeScript

**Error Checking**:
- Test components in various screen sizes
- Verify accessibility compliance
- Check component composition and reusability
- Validate TypeScript types and props
- Ensure consistent styling and behavior

**Expected Output**:
- Complete UI component library
- Consistent design system
- Responsive and accessible components
- Proper TypeScript definitions

---

## Step 6: Authentication Pages and User Flow

**Prompt**: Create authentication pages (sign-in, sign-up) with proper form validation, error handling, and user experience considerations.

**Rules**:
- Create sign-in and sign-up pages
- Implement form validation and error handling
- Add loading states and user feedback
- Handle authentication errors gracefully
- Implement proper redirects after authentication
- Add demo mode option for users

**Constraints**:
- Use Firebase Auth for authentication
- Implement proper form validation
- Handle network errors and timeouts
- Ensure proper security measures
- Follow UX best practices for auth flows

**Error Checking**:
- Test authentication flow with valid/invalid credentials
- Check error handling for network issues
- Verify proper redirects and state management
- Test form validation and user feedback
- Ensure security measures are in place

**Expected Output**:
- Working authentication pages
- Proper form validation and error handling
- Smooth user authentication flow
- Demo mode functionality

---

## Step 7: Dashboard and Prompt Management Interface

**Prompt**: Build the main dashboard interface with prompt listing, search functionality, filtering, and CRUD operations for prompts.

**Rules**:
- Create responsive dashboard layout
- Implement prompt listing with cards
- Add search and filtering functionality
- Implement prompt creation, editing, and deletion
- Add expand/collapse functionality for long prompts
- Implement copy-to-clipboard functionality

**Constraints**:
- Ensure responsive design for all screen sizes
- Implement proper loading states
- Handle empty states gracefully
- Ensure proper data validation
- Follow UX best practices for data management

**Error Checking**:
- Test CRUD operations with various data scenarios
- Check search and filtering functionality
- Verify responsive design across devices
- Test loading states and error handling
- Ensure proper data validation and sanitization

**Expected Output**:
- Complete dashboard interface
- Working CRUD operations for prompts
- Search and filtering functionality
- Responsive and user-friendly design

---

## Step 8: AI Prompt Enhancement Feature

**Prompt**: Implement AI-powered prompt enhancement dialog that transforms simple user ideas into comprehensive prompts using the Gemini API integration.

**Rules**:
- Create enhancement dialog component
- Implement form for simple prompt input
- Connect to Gemini API service
- Handle loading states and user feedback
- Parse and display enhanced results
- Allow users to accept/reject enhancements

**Constraints**:
- Ensure proper error handling for API failures
- Implement loading states and user feedback
- Handle response parsing and validation
- Ensure proper form validation
- Follow UX best practices for AI interactions

**Error Checking**:
- Test enhancement with various input types
- Check error handling for API failures
- Verify loading states and user feedback
- Test response parsing and display
- Ensure proper form validation and submission

**Expected Output**:
- Working AI enhancement dialog
- Proper integration with Gemini API
- User-friendly enhancement workflow
- Error handling and fallback mechanisms

---

## Step 9: API Routes and Backend Logic

**Prompt**: Create Next.js API routes for prompt management, authentication verification, and AI enhancement with proper error handling and security measures.

**Rules**:
- Create API routes for CRUD operations
- Implement authentication verification middleware
- Create AI enhancement API endpoint
- Add proper error handling and validation
- Implement rate limiting and security measures
- Add proper HTTP status codes and responses

**Constraints**:
- Use Next.js 14 App Router API routes
- Implement proper authentication verification
- Handle errors gracefully with appropriate status codes
- Ensure data validation and sanitization
- Follow REST API best practices

**Error Checking**:
- Test all API endpoints with valid/invalid data
- Check authentication verification
- Verify error handling and status codes
- Test rate limiting and security measures
- Ensure proper data validation and responses

**Expected Output**:
- Complete API route implementation
- Proper authentication and security
- Error handling and validation
- RESTful API design

---

## Step 10: Demo Mode and Sample Data

**Prompt**: Implement demo mode functionality with sample data to allow users to explore the application without authentication.

**Rules**:
- Create demo data with realistic prompts
- Implement demo mode toggle
- Handle demo mode in all components
- Ensure demo data is properly structured
- Add demo mode indicators in UI
- Implement seamless transition to authenticated mode

**Constraints**:
- Ensure demo data is realistic and comprehensive
- Handle demo mode consistently across all features
- Implement proper state management for demo mode
- Ensure smooth transition between modes
- Follow UX best practices for demo experiences

**Error Checking**:
- Test demo mode functionality across all features
- Verify demo data is properly displayed
- Check transition between demo and authenticated modes
- Ensure demo mode indicators work correctly
- Test demo mode with various user interactions

**Expected Output**:
- Working demo mode functionality
- Realistic sample data
- Seamless user experience
- Proper demo mode indicators

---

## Step 11: Responsive Design and Mobile Optimization

**Prompt**: Optimize the application for mobile devices and ensure responsive design across all screen sizes with proper touch interactions and mobile-specific UX patterns.

**Rules**:
- Implement responsive design for all components
- Optimize for mobile touch interactions
- Ensure proper mobile navigation
- Implement mobile-specific UI patterns
- Test across various device sizes
- Optimize performance for mobile devices

**Constraints**:
- Ensure touch targets are properly sized
- Implement proper mobile navigation patterns
- Optimize images and assets for mobile
- Ensure proper viewport configuration
- Follow mobile UX best practices

**Error Checking**:
- Test on various mobile devices and screen sizes
- Verify touch interactions work correctly
- Check mobile navigation and user flow
- Test performance on mobile devices
- Ensure proper responsive behavior

**Expected Output**:
- Fully responsive application
- Optimized mobile experience
- Proper touch interactions
- Mobile-specific UX patterns

---

## Step 12: Error Handling and User Feedback

**Prompt**: Implement comprehensive error handling throughout the application with proper user feedback, loading states, and error recovery mechanisms.

**Rules**:
- Implement error boundaries for React components
- Add proper error handling for API calls
- Implement user-friendly error messages
- Add loading states for all async operations
- Implement error recovery mechanisms
- Add proper logging for debugging

**Constraints**:
- Ensure errors are user-friendly and actionable
- Implement proper error boundaries
- Handle network errors gracefully
- Ensure proper loading states
- Follow error handling best practices

**Error Checking**:
- Test error handling with various failure scenarios
- Check user feedback and error messages
- Verify loading states work correctly
- Test error recovery mechanisms
- Ensure proper error logging and debugging

**Expected Output**:
- Comprehensive error handling
- User-friendly error messages
- Proper loading states
- Error recovery mechanisms

---

## Step 13: Performance Optimization and Caching

**Prompt**: Optimize application performance with proper caching strategies, code splitting, and performance monitoring.

**Rules**:
- Implement proper caching for API responses
- Add code splitting for better performance
- Optimize images and assets
- Implement lazy loading for components
- Add performance monitoring
- Optimize bundle size

**Constraints**:
- Ensure caching doesn't break data consistency
- Implement proper cache invalidation
- Optimize for Core Web Vitals
- Ensure proper code splitting
- Follow performance best practices

**Error Checking**:
- Test performance across various network conditions
- Verify caching works correctly
- Check code splitting and lazy loading
- Test performance metrics and monitoring
- Ensure proper cache invalidation

**Expected Output**:
- Optimized application performance
- Proper caching implementation
- Code splitting and lazy loading
- Performance monitoring

---

## Step 14: Security Implementation and Best Practices

**Prompt**: Implement comprehensive security measures including input validation, authentication security, and data protection.

**Rules**:
- Implement proper input validation and sanitization
- Add authentication security measures
- Implement proper data protection
- Add security headers and CORS configuration
- Implement rate limiting
- Add proper error handling without information leakage

**Constraints**:
- Ensure all user inputs are properly validated
- Implement proper authentication security
- Follow security best practices
- Ensure proper data protection
- Implement proper error handling

**Error Checking**:
- Test input validation with malicious inputs
- Check authentication security measures
- Verify data protection and privacy
- Test rate limiting and security headers
- Ensure proper error handling

**Expected Output**:
- Comprehensive security implementation
- Proper input validation and sanitization
- Authentication security measures
- Data protection and privacy

---

## Step 15: Testing and Quality Assurance

**Prompt**: Implement comprehensive testing strategy including unit tests, integration tests, and end-to-end testing for the application.

**Rules**:
- Implement unit tests for utility functions and services
- Add integration tests for API routes
- Implement component testing for React components
- Add end-to-end tests for critical user flows
- Implement proper test data and mocking
- Add test coverage reporting

**Constraints**:
- Ensure tests cover critical functionality
- Implement proper test data and mocking
- Follow testing best practices
- Ensure tests are maintainable and reliable
- Implement proper test organization

**Error Checking**:
- Verify all tests pass consistently
- Check test coverage for critical functionality
- Test error scenarios and edge cases
- Verify test data and mocking work correctly
- Ensure tests are maintainable

**Expected Output**:
- Comprehensive test suite
- Proper test coverage
- Reliable and maintainable tests
- Test automation and reporting

---

## Step 16: Deployment and Production Setup

**Prompt**: Set up production deployment with proper environment configuration, monitoring, and deployment automation.

**Rules**:
- Configure production environment variables
- Set up deployment pipeline
- Implement proper monitoring and logging
- Configure production database and services
- Add health checks and monitoring
- Implement proper backup and recovery

**Constraints**:
- Ensure proper environment configuration
- Implement secure deployment practices
- Set up proper monitoring and alerting
- Ensure proper backup and recovery
- Follow deployment best practices

**Error Checking**:
- Test deployment pipeline
- Verify production environment configuration
- Check monitoring and logging
- Test backup and recovery procedures
- Ensure proper security measures

**Expected Output**:
- Production-ready deployment
- Proper environment configuration
- Monitoring and logging setup
- Backup and recovery procedures

---

## Additional Guidelines

### Code Quality Standards
- Follow TypeScript strict mode
- Implement proper error handling
- Use consistent naming conventions
- Add proper documentation and comments
- Follow React and Next.js best practices

### Security Considerations
- Validate all user inputs
- Implement proper authentication
- Use environment variables for secrets
- Follow OWASP security guidelines
- Implement proper CORS and security headers

### Performance Requirements
- Optimize for Core Web Vitals
- Implement proper caching strategies
- Use code splitting and lazy loading
- Optimize images and assets
- Monitor performance metrics

### Accessibility Requirements
- Follow WCAG 2.1 AA guidelines
- Implement proper ARIA labels
- Ensure keyboard navigation
- Test with screen readers
- Ensure proper color contrast

### Testing Requirements
- Implement unit tests for critical functions
- Add integration tests for API routes
- Test error scenarios and edge cases
- Implement proper test data and mocking
- Ensure test coverage for critical functionality

This comprehensive guide provides step-by-step prompts to build the PromptSaaS application from scratch, with each step focusing on a specific aspect while maintaining quality, security, and performance standards.
