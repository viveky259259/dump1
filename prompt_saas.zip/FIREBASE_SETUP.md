# Firebase Configuration Guide

This project is now configured with Firebase's recommended settings for Next.js applications.

## 🔥 Firebase Configuration Files

### **firebase.json**
- **Hosting**: Configured for static export with optimized caching
- **Firestore**: Rules and indexes configured
- **Headers**: Optimized caching for static assets

### **firestore.rules**
- **Security Rules**: Users can only access their own data
- **Public Prompts**: Allow reading of public prompts
- **User Data**: Secure user document access

### **firestore.indexes.json**
- **Query Optimization**: Indexes for common queries
- **Performance**: Optimized for prompts by user, category, tags

## 🚀 Firebase Deployment Commands

### **Build for Firebase**
```bash
npm run build:firebase
```

### **Deploy to Firebase**
```bash
# Deploy everything
npm run firebase:deploy

# Deploy only hosting
npm run firebase:deploy:hosting

# Test locally
npm run firebase:serve
```

### **Manual Commands**
```bash
# Build and deploy
firebase deploy

# Deploy only hosting
firebase deploy --only hosting

# Deploy only Firestore rules
firebase deploy --only firestore:rules

# Serve locally
firebase serve
```

## 📁 Project Structure

```
prompt_saas/
├── firebase.json          # Firebase configuration
├── firestore.rules        # Security rules
├── firestore.indexes.json # Database indexes
├── deploy-firebase.sh     # Deployment script
├── out/                   # Static build output
└── app/
    ├── api/              # API routes (excluded from static build)
    ├── auth/             # Authentication pages
    ├── dashboard/        # Dashboard page
    └── landing/          # Landing page
```

## 🔧 Configuration Details

### **Static Export Settings**
- **Output**: `out` directory for Firebase Hosting
- **Trailing Slash**: Enabled for better routing
- **Images**: Unoptimized for static hosting
- **API Routes**: Excluded from static build

### **Caching Strategy**
- **Static Assets**: 1 year cache with immutable flag
- **HTML Pages**: No cache for dynamic content
- **Images**: 1 year cache for performance

### **Security Rules**
```javascript
// Users can only access their own data
match /users/{userId} {
  allow read, write: if request.auth != null && request.auth.uid == userId;
}

// Users can manage their own prompts
match /prompts/{promptId} {
  allow read, write: if request.auth != null && 
    request.auth.uid == resource.data.userId;
}

// Public prompts are readable by everyone
match /prompts/{promptId} {
  allow read: if resource.data.isPublic == true;
}
```

## 🌐 Deployment Process

1. **Build**: `npm run build:firebase`
2. **Deploy**: `firebase deploy --only hosting`
3. **Verify**: Check Firebase Console

## 📱 Features Supported

### **✅ Working with Firebase Hosting**
- Static pages (landing, auth, dashboard)
- Firebase Authentication
- Client-side routing
- Static asset optimization

### **⚠️ Limitations**
- API routes need separate deployment (Firebase Functions)
- Server-side rendering not available
- Dynamic server features disabled

## 🔗 Firebase Console

- **Project**: https://console.firebase.google.com/project/prompt-saas
- **Hosting**: https://console.firebase.google.com/project/prompt-saas/hosting
- **Firestore**: https://console.firebase.google.com/project/prompt-saas/firestore

## 🛠️ Development vs Production

### **Development**
```bash
# Use Vercel for full Next.js features
npm run dev:clean
# Access: http://localhost:4444
```

### **Production**
```bash
# Use Firebase for static hosting
npm run firebase:deploy
# Access: https://prompt-saas.web.app
```

## 📋 Next Steps

1. **Deploy to Firebase**: `npm run firebase:deploy`
2. **Configure Custom Domain**: Firebase Console → Hosting
3. **Set up CI/CD**: GitHub Actions for automatic deployment
4. **Monitor Performance**: Firebase Analytics

---

**Firebase configuration is complete and ready for deployment! 🚀**
