#!/bin/sh
flutter pub run pigeon --input pigeon/message.dart \
  --dart_out lib/api.dart \
  --java_out ../MyApp/app/src/main/java/com/example/myapplication \
  --java_package "com.example.myapplication"