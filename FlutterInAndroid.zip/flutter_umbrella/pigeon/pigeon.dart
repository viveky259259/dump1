import 'package:pigeon/pigeon.dart';

@ConfigurePigeon(PigeonOptions(
  dartOut: 'lib/src/messages.g.dart',
  dartOptions: DartOptions(),
  kotlinOut:
      '../MyApp/app/src/main/kotlin/com.example.myapplication/Messages.g.kt',
  kotlinOptions: KotlinOptions(package: 'com.example.myapplication'),
  javaOut:
      '../MyApp/app/src/main/kotlin/com/example/myapplication/Messages.java',
  javaOptions: JavaOptions(),
  // swiftOut: 'ios/Runner/Messages.g.swift',
  // swiftOptions: SwiftOptions(),
  // Set this to a unique prefix for your plugin or application, per Objective-C naming conventions.
  objcOptions: ObjcOptions(prefix: 'PGN'),
  // copyrightHeader: 'pigeons/copyright.txt',
  dartPackageName: 'flutter_umbrella',
))

class Message {
  String? message;
  Sender? sender;
}

class Sender {
  String? name;
}

@FlutterApi()
abstract class FlutterMessageApi {
  void displayMessage(Message message);
}

@HostApi()
abstract class HostMessageApi {
  void cancel();
  void finishEditingMessage(Message message);
}

@ConfigurePigeon(PigeonOptions(
  dartOut: 'lib/src/sync.g.dart',
  dartOptions: DartOptions(),
  kotlinOut: '../MyApp/app/src/main/kotlin/com.example.myapplication/Sync.g.kt',
  kotlinOptions: KotlinOptions(package: 'com.example.myapplication',),
  dartPackageName: 'flutter_umbrella',

))
class SyncTime {
  String? time;
}

@FlutterApi()
abstract class FlutterSyncApi {
  void syncCompleted();
  void syncFailed();
}

@HostApi()
abstract class HostSyncApi {
  void syncTime(SyncTime syncTime);
  void closeFlutterScreen();
  void navigateTo(String routeName);
}
