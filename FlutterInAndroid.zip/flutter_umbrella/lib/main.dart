import 'package:dreamflow/main.dart' as dreamflow;
import 'package:flutter/material.dart';
import 'package:flutter_umbrella/src/messages.g.dart' as messages;
import 'package:flutter_umbrella/src/sync.g.dart' as sync;

class _FlutterUmbrellaMessageApi
    implements messages.FlutterMessageApi, sync.FlutterSyncApi {
  @override
  void displayMessage(messages.Message message) {
    print('Message from native ${message.sender?.name}: ${message.message}');
  }

  @override
  void syncCompleted() {
    print('Sync completed');
  }

  @override
  void syncFailed() {
    print('Sync failed');
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  messages.FlutterMessageApi.setUp(
    _FlutterUmbrellaMessageApi(),
  );
  sync.FlutterSyncApi.setUp(
    _FlutterUmbrellaMessageApi(),
  );

  dreamflow.main();
  final api = messages.HostMessageApi();
  api.finishEditingMessage(messages.Message(
      message: 'Hello from Flutter Umbrella',
      sender: messages.Sender(name: 'Vivek')));

  Future.delayed(Duration(seconds: 4), () {
    final api = messages.HostMessageApi();
    api.finishEditingMessage(messages.Message(
        message: 'Hello from Flutter Umbrella',
        sender: messages.Sender(name: 'Pooja')));
  });
}
