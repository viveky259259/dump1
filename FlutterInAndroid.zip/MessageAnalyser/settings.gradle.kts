pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
    resolutionStrategy {
        eachPlugin {
            if (requested.id.id == "dev.flutter.flutter-gradle-plugin") {
                useModule("dev.flutter:flutter-gradle-plugin:${requested.version}")
            }
        }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "MessageAnalyser"
include(":app")
val filePath ="/Users/vivekyadav/Documents/Projects/solutions/FlutterInAndroid/flutter_umbrella/.android/include_flutter.groovy"
apply(from = File(filePath))
