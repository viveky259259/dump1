package com.example.messageanalyser

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.messageanalyser.ui.theme.MessageAnalyserTheme
import io.flutter.embedding.android.FlutterActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MessageAnalyserTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                   Column {

                       Greeting(
                           name = "Android",
                           modifier = Modifier.padding(innerPadding)
                       )
                       MyButton(onClick = {
                           startActivity(
                               FlutterActivity.createDefaultIntent(this@MainActivity)
                           )
                       })
                   }

                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}
@Composable
fun MyButton(onClick: () -> Unit) {
    Button (onClick = onClick) {
        Text("Launch Flutter!")
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MessageAnalyserTheme {
        Greeting("Android")
    }
}