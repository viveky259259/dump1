package com.example.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.annotation.NonNull
import androidx.annotation.RequiresApi
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugins.GeneratedPluginRegistrant
import java.io.Serializable

class FlutterExtendedActivity : FlutterActivity() {
    companion object {
        const val EXTRA_MESSAGE = "message_text"
        const val EXTRA_SENDER="sender_name"
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        GeneratedPluginRegistrant.registerWith(flutterEngine)
        val messageReceived = intent.getStringExtra(EXTRA_MESSAGE)
        val senderReceived = intent.getStringExtra(EXTRA_SENDER)
        val message:Message=Message(messageReceived, Sender(senderReceived) )
        HostMessageApi.setUp(flutterEngine.dartExecutor, HostMessageApiHandler())
        FlutterMessageApi(flutterEngine.dartExecutor).displayMessage(message) {

        }
    }

    // This {@link Api.HostBookApi} subclass will be called by Pigeon when the corresponding
    // APIs are invoked on the Dart side.
    inner class HostMessageApiHandler : HostMessageApi {
        override fun cancel() {
            // Flutter called cancel. Finish the activity with a cancel result.
            setResult(Activity.RESULT_CANCELED)
            finish()
        }

        override fun finishEditingMessage(message: Message) {
            // Flutter returned an edited book instance. Return it to the MainActivity via the
            // standard Android Activity set result mechanism.

            Log.e("Received Message", message.toString())
            setResult(
                Activity.RESULT_OK,
                Intent().putExtra(EXTRA_MESSAGE, message.toString())
            )


        }
    }

    inner class HostSyncApiHandler : HostSyncApi {
        override fun syncTime(syncTime: SyncTime) {
// data sync completed
        }

        override fun closeFlutterScreen() {
            finish();
        }
        override fun navigateTo(routeName: String) {
            // go to screen
        }

    }
}

//class FlutterBookActivity: FlutterActivity() {
//
//    // Intent builder class to build a FlutterBookActivity instance instead of the default FlutterActivity.
//    class CachedEngineBookIntentBuilder(engineId: String): CachedEngineIntentBuilder(FlutterBookActivity::class.java, engineId) { }
//
//    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
//        // Called shortly after the activity is created, when the activity is bound to a
//        // FlutterEngine responsible for rendering the Flutter activity's content.
//        super.configureFlutterEngine(flutterEngine)
//
//        // The book to give to Flutter is passed in from the MainActivity via this activity's
//        // source intent getter. The intent contains the book serialized as on extra.
//        val bookToShow = Api.Book.fromMap(intent.getSerializableExtra(EXTRA_BOOK) as HashMap<String, Any>)
//
//        // Register the HostBookApiHandler callback class to get results from Flutter.
//        Api.HostBookApi.setup(flutterEngine.dartExecutor, HostBookApiHandler())
//
//        // Send in the book instance to Flutter.
//        Api.FlutterBookApi(flutterEngine.dartExecutor).displayBookDetails(bookToShow) {
//            // We don't care about the callback
//        }
//    }
//
//    // This {@link Api.HostBookApi} subclass will be called by Pigeon when the corresponding
//    // APIs are invoked on the Dart side.
//    inner class HostBookApiHandler: Api.HostBookApi {
//        override fun cancel() {
//            // Flutter called cancel. Finish the activity with a cancel result.
//            setResult(Activity.RESULT_CANCELED)
//            finish()
//        }
//
//        override fun finishEditingBook(book: Api.Book?) {
//            if (book == null) {
//                throw IllegalArgumentException("finishedEditingBook cannot be called with a null argument")
//            }
//            // Flutter returned an edited book instance. Return it to the MainActivity via the
//            // standard Android Activity set result mechanism.
//            setResult(Activity.RESULT_OK, Intent().putExtra(EXTRA_BOOK, HashMap(book.toMap())))
//            finish()
//        }
//    }
//}