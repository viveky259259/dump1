# GitHub Repository Analyzer - Development Notes

## Session Summary (2026-02-03) - Complete 10 Iterations

### Overview
Transformed the GitHub Repository Analyzer into an essential developer tool with 10 comprehensive analysis features. The app now provides deep insights into repositories covering code quality, workflows, security, documentation, and more.

### Key Files Modified
- `lib/src/models/analysis_result.dart` - Added 10+ model classes for all analysis types
- `lib/src/services/analyzer_service.dart` - Added 10 analysis methods (~2000 lines)
- `lib/src/screens/home_screen.dart` - AI options UI, settings persistence
- `lib/src/screens/analysis_screen.dart` - AI parameter passing
- `DEVELOPMENT_NOTES.md` - Documentation

---

## Session Details (2026-02-03)

### Features Implemented

#### 1. Fixed Issues/PR Data Accuracy
- GitHub's Issues API returns PRs as issues - now filtering by checking `pull_request == null`
- Overview section shows correct open issues count (not GitHub's combined count)
- Added separate "Open PRs" count in Overview
- Report shows accurate Issue and PR statistics with close/merge rates

#### 2. AI-Powered Analysis Feature
Added AI capabilities to analyze repository activity:

**What AI Analyzes:**
1. **Merged PRs (Last 3 Months)** - What improvements were made
2. **Latest 50 PRs** - What improvements are coming
3. **Recent Issues (Last 3 Months)** - What users are complaining about

**Files Modified:**
- `lib/src/models/analysis_result.dart` - Added `AIInsights` class and new phases
- `lib/src/services/analyzer_service.dart` - Added AI analysis methods
- `lib/src/screens/home_screen.dart` - Added AI options UI
- `lib/src/screens/analysis_screen.dart` - Pass AI parameters

**AI Provider Support:**
- Claude API (claude-sonnet-4-20250514)
- OpenAI API (gpt-4o-mini)

#### 3. Settings Persistence
- AI API key saved securely via SharedPreferences
- AI provider selection saved
- AI enabled state saved
- Settings restored on app restart

### Bug Fixes

1. **setState during build error** - Fixed by using `addPostFrameCallback` in:
   - `home_screen.dart` - `_loadSavedAiApiKey()`
   - `analysis_screen.dart` - `_startAnalysis()` call in initState

2. **Issues/PRs showing incorrect counts** - Fixed by:
   - Filtering PRs from issues list
   - Using filtered counts instead of GitHub's combined `open_issues_count`

### Code Structure

```
lib/src/
├── models/
│   └── analysis_result.dart    # AIInsights, AnalysisPhase updates
├── services/
│   └── analyzer_service.dart   # _performAiAnalysis, _callClaudeApi, _callOpenAiApi
├── screens/
│   ├── home_screen.dart        # AI options card, settings persistence
│   └── analysis_screen.dart    # AI parameter passing
```

### How to Use AI Analysis

1. Enable "AI Analysis" toggle in the app
2. Select provider (Claude or OpenAI)
3. Enter API key:
   - Claude: Get from console.anthropic.com
   - OpenAI: Get from platform.openai.com
4. Run analysis - AI insights appear in report under "AI-Powered Insights"

### API Keys Required

- **GitHub Token** (optional): For private repos or higher rate limits
- **AI API Key** (optional): For AI-powered insights
  - Claude API key (sk-ant-...)
  - OpenAI API key (sk-...)

### 5 Iterations - Making This Essential for Developers

#### Iteration 1: Dependency & Security Analysis
- Parse package.json, requirements.txt, Cargo.toml, pubspec.yaml, go.mod
- Count total dependencies, outdated, and vulnerable packages
- Calculate dependency health score
- Show outdated dependency list with versions

#### Iteration 2: Technical Debt Detection
- Search for TODO, FIXME, HACK comments via GitHub Code Search API
- Identify large files needing refactoring
- Calculate debt score
- Show top debt items with file locations

#### Iteration 3: Contributor Insights & Code Ownership
- Calculate bus factor (minimum contributors owning 50% of code)
- Identify code ownership by contributor
- Generate onboarding recommendations for new contributors
- Identify key entry points for codebase understanding

#### Iteration 4: Repository Comparison (model ready)
- Models added for comparing two repositories side-by-side
- Compare tech stacks, quality scores, activity levels

#### Iteration 5: AI-Powered Actionable Roadmap
- AI generates prioritized improvement roadmap
- Critical, High, Medium, Low priority items
- Categories: security, maintenance, documentation, testing
- Predicted impact assessment

### Iterations 6-10 - Essential Developer Features

#### Iteration 6: Git Workflow & Commit Quality Analysis
- Analyze commit message quality and conventional commit usage
- Track conventional commit ratio (feat:, fix:, docs:, etc.)
- Calculate average PR turnaround time and size
- Detect branching strategy (gitflow, trunk-based, feature-branch)
- Generate commit quality score (0-100)
- Provide workflow recommendations

#### Iteration 7: CI/CD Pipeline Analysis
- Detect CI/CD platforms (GitHub Actions, Travis CI, Circle CI, Jenkins)
- Analyze workflow configurations
- Check for pipeline stages: testing, linting, building, deployment, security
- Calculate pipeline score (0-100)
- List detected workflows with triggers
- Identify missing stages and provide recommendations

#### Iteration 8: Documentation Completeness Analysis
- Analyze README.md sections (installation, usage, API, badges)
- Check for CONTRIBUTING.md, CODE_OF_CONDUCT.md, CHANGELOG.md
- Detect API documentation and Wiki
- Calculate documentation score (0-100)
- Identify missing documentation sections
- Generate documentation improvement recommendations

#### Iteration 9: Release Management Analysis
- Analyze release history and frequency
- Check semantic versioning compliance
- Track release notes quality
- Calculate releases per month and days since last release
- Detect release strategy (rolling, periodic, milestone-based)
- Calculate release score (0-100)
- Provide release management recommendations

#### Iteration 10: Security Posture Deep Scan
- Check for SECURITY.md policy
- Detect Dependabot configuration
- Analyze branch protection settings
- Check for required PR reviews and signed commits
- Scan for potential secrets in file names
- Analyze .gitignore configuration
- Calculate security score (0-100) and risk level
- List enabled/missing security features
- Generate security recommendations

### Report Sections

1. Executive Summary (branch-oriented analysis)
2. **AI-Powered Insights**
   - Recent Improvements (Merged PRs)
   - Upcoming Improvements (Latest PRs)
   - User Feedback Analysis (Issues)
   - Overall Development Trend
3. **Actionable Improvement Roadmap** (AI-generated)
4. Overview
5. Languages
6. Tech Stack
7. Quality Assessment
8. **Dependency Analysis**
9. **Technical Debt Analysis**
10. **Contributor Insights**
11. **Git Workflow Analysis** (NEW - Iteration 6)
12. **CI/CD Pipeline Analysis** (NEW - Iteration 7)
13. **Documentation Analysis** (NEW - Iteration 8)
14. **Release Management** (NEW - Iteration 9)
15. **Security Posture Analysis** (NEW - Iteration 10)
16. Top Contributors
17. Issues
18. Pull Requests

### Debug Logging

Debug messages added for troubleshooting AI analysis:
- `AI Analysis check: enableAiAnalysis=X, aiApiKey=X chars`
- `Starting AI analysis...`
- `Claude API response status: X`
- `AI Analysis completed: mergedPrAnalysis=X chars`

### Known Issues

- `file_picker` package shows warnings (non-blocking)
- "Failed to foreground app" message (non-blocking)

### Completed Features

- [x] Dependency Analysis (Iteration 1)
- [x] Technical Debt Detection (Iteration 2)
- [x] Contributor Insights & Code Ownership (Iteration 3)
- [x] AI-Powered Actionable Roadmap (Iteration 5)
- [x] Git Workflow & Commit Quality Analysis (Iteration 6)
- [x] CI/CD Pipeline Analysis (Iteration 7)
- [x] Documentation Completeness Analysis (Iteration 8)
- [x] Release Management Analysis (Iteration 9)
- [x] Security Posture Deep Scan (Iteration 10)
- [x] AI Analysis of PRs and Issues
- [x] Settings persistence

### Next Steps (TODO)

- [ ] Repository Comparison UI (Iteration 4 - model ready)
- [ ] Add loading indicator during AI analysis
- [ ] Add error messages for AI API failures in UI
- [ ] Enhance dependency vulnerability detection with security advisories
- [ ] Add code complexity metrics
- [ ] Export reports to PDF/HTML
- [ ] Integrate with GitHub Actions API for workflow run statistics
- [ ] Add trend analysis over time

---

## Implementation Reference

### Model Classes Added (analysis_result.dart)

**Iterations 1-5:**
- `Dependency`, `DependencyAnalysis` - Package dependency tracking
- `TechDebtItem`, `TechDebtAnalysis` - TODO/FIXME/HACK detection
- `ContributorDetail`, `CodeOwnership`, `ContributorInsights` - Bus factor, ownership
- `RoadmapItem`, `ActionableRoadmap` - AI-generated improvement plan
- `AIInsights` - PR and issue analysis

**Iterations 6-10:**
- `CommitQuality`, `GitWorkflowAnalysis` - Commit patterns, branching strategy
- `WorkflowInfo`, `CiCdAnalysis` - CI/CD pipeline detection
- `DocumentationAnalysis` - README sections, docs completeness
- `ReleaseInfo`, `ReleaseAnalysis` - Release frequency, semver compliance
- `SecurityFinding`, `SecurityPostureAnalysis` - Security features, risk assessment

### Analysis Methods Added (analyzer_service.dart)

```dart
// Iteration 1-5
_analyzeDependencies()      // Parse package.json, requirements.txt, etc.
_analyzeTechDebt()          // GitHub Code Search for TODO/FIXME/HACK
_analyzeContributorInsights() // Bus factor, code ownership
_generateActionableRoadmap() // AI-powered improvement plan
_performAiAnalysis()        // Claude/OpenAI PR and issue analysis

// Iteration 6-10
_analyzeGitWorkflow()       // Commit quality, branching strategy
_analyzeCiCd()              // GitHub Actions, Travis, Circle CI detection
_analyzeDocumentation()     // README analysis, docs completeness
_analyzeReleases()          // Release history, semver compliance
_analyzeSecurityPosture()   // Security policy, branch protection, secrets
```

### Analysis Phases (AnalysisPhase enum)

```dart
analyzingDependencies,
analyzingTechDebt,
analyzingContributors,
analyzingGitWorkflow,      // Iteration 6
analyzingCiCd,             // Iteration 7
analyzingDocumentation,    // Iteration 8
analyzingReleases,         // Iteration 9
analyzingSecurityPosture,  // Iteration 10
aiAnalyzingPrs,
aiAnalyzingIssues,
aiGeneratingRoadmap,
```

### GitHub APIs Used

- `repos/{owner}/{repo}` - Repository info
- `repos/{owner}/{repo}/languages` - Language breakdown
- `repos/{owner}/{repo}/contributors` - Contributor list
- `repos/{owner}/{repo}/contents` - File listing
- `repos/{owner}/{repo}/branches` - Branch info
- `repos/{owner}/{repo}/commits` - Commit history
- `repos/{owner}/{repo}/pulls` - Pull requests
- `repos/{owner}/{repo}/issues` - Issues (filter PRs)
- `repos/{owner}/{repo}/releases` - Release history
- `repos/{owner}/{repo}/readme` - README content
- `repos/{owner}/{repo}/branches/{branch}/protection` - Branch protection
- `search/code` - Code search (TODO/FIXME/HACK)
- `repos/{owner}/{repo}/stats/commit_activity` - Commit velocity

### AI API Integration

```dart
// Claude API
POST https://api.anthropic.com/v1/messages
Model: claude-sonnet-4-20250514
Headers: x-api-key, anthropic-version: 2023-06-01

// OpenAI API
POST https://api.openai.com/v1/chat/completions
Model: gpt-4o-mini
Headers: Authorization: Bearer {key}
```

### Running the App

```bash
cd /Users/vivekyadav/Documents/Projects/claude/github_analysis/github_analyzer
flutter run -d macos
```

### Test Repositories

- `facebook/react` - Large, active repo
- `flutter/flutter` - Flutter framework
- `anthropics/claude-code` - Claude Code CLI

---

*Last updated: 2026-02-03*
