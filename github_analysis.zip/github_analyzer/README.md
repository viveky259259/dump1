# GitHub Repository Analyzer

A comprehensive cross-platform macOS desktop application for analyzing GitHub repositories. Built with **Flutter** (UI) and **Rust** (backend analysis engine).

## Features

### Repository Analysis
- **URL Validation**: Supports multiple GitHub URL formats (`https://github.com/owner/repo`, `owner/repo`, SSH URLs)
- **Public & Private Repos**: Analyze public repositories freely, or use a GitHub token for private repos
- **Real-time Progress**: Visual progress indicators showing each analysis phase

### Statistics & Metrics
- **Repository Stats**: Stars, forks, watchers, open issues count
- **Contributor Analysis**: Top contributors with contribution counts
- **Language Breakdown**: Percentage breakdown of programming languages used
- **Activity Metrics**: Recent commit activity and update timestamps

### Tech Stack Detection
- **Frameworks**: Detects React, Vue, Angular, Django, Rails, Spring, Express, and 50+ more
- **Build Tools**: Webpack, Vite, Gradle, Maven, CMake, Make, etc.
- **Package Managers**: npm, yarn, pip, cargo, go modules, composer, etc.
- **CI/CD**: GitHub Actions, Travis CI, CircleCI, Jenkins, GitLab CI
- **Databases**: PostgreSQL, MySQL, MongoDB, Redis, SQLite, etc.
- **Cloud Services**: AWS, GCP, Azure, Heroku, Vercel, Netlify
- **Containerization**: Docker, Kubernetes, Docker Compose

### Code Quality Scoring
- **Overall Score**: Weighted average of all quality metrics (0-100)
- **Documentation Score**: Based on README quality, comments, and docs presence
- **Test Coverage Score**: Evaluates test file presence and testing frameworks
- **Maintenance Score**: Based on recent activity, issue response time, PR merge rate
- **Security Score**: Checks for security policies, dependency management, vulnerability scanning

### Quality Checklist
- README file presence and quality
- LICENSE file
- CONTRIBUTING guidelines
- Code of Conduct
- Security Policy
- CI/CD configuration
- Test directory presence
- Changelog maintenance

### Issues Analysis
- **Categorization**: Bugs, feature requests, questions, documentation issues
- **Common Complaints**: Identifies frequently reported problems
- **Label Analysis**: Distribution of issue labels
- **Response Time**: Average time to first response
- **Close Rate**: Percentage of issues resolved

### Pull Request Analysis
- **PR Status**: Open, merged, and closed PR counts
- **Focus Areas**: Identifies which parts of the codebase receive most attention
- **Active Contributors**: Most active PR authors
- **Merge Time**: Average time from PR creation to merge
- **Review Patterns**: Code review engagement metrics

### Report Generation
- **Markdown Reports**: Comprehensive, well-formatted markdown reports
- **Custom Output Path**: Choose where to save reports
- **In-App Preview**: View reports directly in the application
- **File Export**: Save reports for sharing and documentation

## Screenshots

The application features a clean, modern UI with:
- Home screen with URL input and configuration options
- Progress screen showing real-time analysis status
- Report screen with markdown preview and export options

## Architecture

```
github_analyzer/
├── rust/                       # Rust backend (business logic)
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs             # Core types and main analysis function
│       ├── api/
│       │   ├── mod.rs         # Bridge API for Flutter integration
│       │   ├── auth.rs        # Token validation
│       │   └── github.rs      # GitHub API client (octocrab)
│       ├── analyzer/
│       │   ├── stats.rs       # Repository statistics
│       │   ├── structure.rs   # Directory tree analysis
│       │   ├── architecture.rs # Tech stack detection
│       │   ├── features.rs    # Feature extraction from README
│       │   ├── quality.rs     # Quality scoring
│       │   ├── issues.rs      # Issues analysis
│       │   └── pull_requests.rs # PR analysis
│       ├── git/
│       │   └── clone.rs       # Git clone operations
│       └── output/
│           └── markdown.rs    # Report generation
│
├── lib/                        # Flutter frontend (UI)
│   ├── main.dart
│   └── src/
│       ├── app.dart           # App theme and configuration
│       ├── screens/
│       │   ├── home_screen.dart      # URL input & settings
│       │   ├── analysis_screen.dart  # Progress display
│       │   └── report_screen.dart    # Report viewer
│       ├── widgets/
│       │   ├── url_input_field.dart
│       │   ├── token_input_field.dart
│       │   ├── progress_indicator.dart
│       │   └── markdown_viewer.dart
│       ├── services/
│       │   └── analyzer_service.dart # GitHub API integration
│       └── models/
│           ├── repo_info.dart
│           └── analysis_result.dart
│
├── macos/                      # macOS platform configuration
├── pubspec.yaml               # Flutter dependencies
└── flutter_rust_bridge.yaml   # Rust-Flutter bridge config
```

## Requirements

- **Flutter**: 3.10.8 or higher
- **Rust**: 1.70 or higher (1.93+ recommended)
- **macOS**: 12.0 (Monterey) or higher
- **Xcode**: 14.0 or higher

## Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd github_analyzer
```

### 2. Install Flutter Dependencies

```bash
flutter pub get
```

### 3. Build Rust Library (Optional)

```bash
cd rust
cargo build --release
cd ..
```

### 4. Run the Application

```bash
flutter run -d macos
```

### 5. Build for Distribution

```bash
flutter build macos
```

The built app will be at `build/macos/Build/Products/Release/github_analyzer.app`

## Usage

### Basic Analysis

1. **Enter Repository URL**: Type or paste a GitHub repository URL
   - Full URL: `https://github.com/flutter/flutter`
   - Short format: `flutter/flutter`

2. **Click Analyze**: Press the "Analyze Repository" button

3. **View Results**: The app will show real-time progress and then display the report

### With Authentication

For private repositories or to avoid rate limits:

1. **Get a GitHub Token**:
   - Go to GitHub → Settings → Developer settings → Personal access tokens
   - Generate a new token (classic) with `repo` scope

2. **Enter Token**: Paste the token in the "GitHub Token" field

3. **Analyze**: The app will use authenticated requests

### Configuring Output

1. **Change Output Path**: Click "Change" next to the output path
2. **Select Directory**: Choose where to save the report
3. **Custom Filename**: Reports are named `<repo>_analysis_<timestamp>.md`

## API Rate Limits

- **Without Token**: 60 requests/hour (limited analysis)
- **With Token**: 5,000 requests/hour (full analysis)

For comprehensive analysis of large repositories, using a token is recommended.

## Development

### Running in Debug Mode

```bash
flutter run -d macos
```

Press `r` for hot reload, `R` for hot restart.

### Running Rust Tests

```bash
cd rust
cargo test
```

### Building Release Version

```bash
flutter build macos --release
```

### Project Structure

| Directory | Purpose |
|-----------|---------|
| `lib/src/screens/` | Flutter UI screens |
| `lib/src/widgets/` | Reusable UI components |
| `lib/src/services/` | Business logic and API calls |
| `rust/src/analyzer/` | Analysis modules |
| `rust/src/api/` | GitHub API client |
| `rust/src/output/` | Report generation |

## Technologies Used

### Frontend (Flutter)
- **Provider**: State management
- **http**: HTTP client for GitHub API
- **flutter_markdown**: Markdown rendering
- **path_provider**: File system access
- **url_launcher**: Opening links
- **shared_preferences**: Local storage

### Backend (Rust)
- **octocrab**: GitHub API client
- **git2**: Git operations
- **tokei**: Code statistics
- **chrono**: Date/time handling
- **serde**: Serialization
- **regex**: Pattern matching
- **walkdir**: Directory traversal

## Troubleshooting

### Rate Limit Errors
- Add a GitHub Personal Access Token for higher rate limits

### Network Errors
- Check your internet connection
- Verify the repository URL is correct
- Ensure the repository exists and is accessible

### Build Errors
- Run `flutter clean` and rebuild
- Update Flutter: `flutter upgrade`
- Update Rust: `rustup update stable`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Acknowledgments

- [Flutter](https://flutter.dev/) - UI framework
- [Rust](https://www.rust-lang.org/) - Backend language
- [octocrab](https://github.com/XAMPPRocky/octocrab) - GitHub API client
- [tokei](https://github.com/XAMPPRocky/tokei) - Code statistics
