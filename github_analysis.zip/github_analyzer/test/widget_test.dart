import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:github_analyzer/src/app.dart';
import 'package:github_analyzer/src/services/analyzer_service.dart';

void main() {
  testWidgets('App loads home screen', (WidgetTester tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => AnalyzerService(),
        child: const GitHubAnalyzerApp(),
      ),
    );

    // Verify that the app title is shown
    expect(find.text('GitHub Repository Analyzer'), findsOneWidget);

    // Verify that the analyze button exists
    expect(find.text('Analyze Repository'), findsOneWidget);
  });
}
