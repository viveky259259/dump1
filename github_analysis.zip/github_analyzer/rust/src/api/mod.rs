//! API module for flutter_rust_bridge
//!
//! This module contains only the FFI-safe types and functions that are
//! exposed to Flutter via flutter_rust_bridge.

// Internal modules - private to avoid codegen scanning
mod auth;
mod github;

// Re-export GitHubClient and fetch_repo_stats for internal crate use (not for FFI)
pub(crate) use github::GitHubClient;
pub(crate) use github::fetch_repo_stats as github_fetch_repo_stats;

use crate::{AnalysisConfig, AnalysisProgress, AnalysisResult, IssuesAnalysis, PullRequestsAnalysis};

/// Simple greeting function to test the bridge
#[flutter_rust_bridge::frb(sync)]
pub fn greet(name: String) -> String {
    format!("Hello, {}! From Rust with love.", name)
}

/// Validate a GitHub URL
#[flutter_rust_bridge::frb(sync)]
pub fn validate_github_url(url: String) -> Result<(String, String), String> {
    match crate::RepoUrl::parse(&url) {
        Ok(repo_url) => Ok((repo_url.owner, repo_url.repo)),
        Err(e) => Err(e.to_string()),
    }
}

/// Analysis configuration for the bridge
#[derive(Clone)]
pub struct BridgeAnalysisConfig {
    pub repo_url: String,
    pub token: Option<String>,
    pub output_path: String,
    pub include_issues: bool,
    pub include_prs: bool,
    pub max_issues: u32,
    pub max_prs: u32,
}

impl Default for BridgeAnalysisConfig {
    fn default() -> Self {
        Self {
            repo_url: String::new(),
            token: None,
            output_path: String::from("./analysis_report.md"),
            include_issues: true,
            include_prs: true,
            max_issues: 100,
            max_prs: 50,
        }
    }
}

impl From<BridgeAnalysisConfig> for AnalysisConfig {
    fn from(config: BridgeAnalysisConfig) -> Self {
        AnalysisConfig {
            repo_url: config.repo_url,
            token: config.token,
            output_path: config.output_path,
            include_issues: config.include_issues,
            include_prs: config.include_prs,
            max_issues: config.max_issues,
            max_prs: config.max_prs,
        }
    }
}

/// Progress update for the bridge
#[derive(Clone)]
pub struct BridgeProgress {
    pub phase: String,
    pub message: String,
    pub percent: f32,
}

impl From<AnalysisProgress> for BridgeProgress {
    fn from(progress: AnalysisProgress) -> Self {
        Self {
            phase: progress.phase.to_string(),
            message: progress.message,
            percent: progress.percent,
        }
    }
}

/// Simplified analysis result for the bridge
#[derive(Clone)]
pub struct BridgeAnalysisResult {
    pub repo_name: String,
    pub repo_full_name: String,
    pub description: Option<String>,
    pub html_url: String,
    pub stars: u32,
    pub forks: u32,
    pub watchers: u32,
    pub open_issues: u32,
    pub primary_language: Option<String>,
    pub license: Option<String>,
    pub topics: Vec<String>,
    pub created_at: String,
    pub updated_at: String,
    // Quality scores
    pub overall_score: f32,
    pub documentation_score: f32,
    pub test_score: f32,
    pub maintenance_score: f32,
    pub security_score: f32,
    // Checklist
    pub has_readme: bool,
    pub has_license: bool,
    pub has_contributing: bool,
    pub has_tests: bool,
    pub has_ci: bool,
    // Report
    pub report_path: Option<String>,
    pub report_content: String,
    pub analyzed_at: String,
}

/// Run analysis on a repository
pub async fn analyze_repository_bridge(
    config: BridgeAnalysisConfig,
) -> Result<BridgeAnalysisResult, String> {
    use crate::analyzer::{
        architecture::analyze_architecture, features::analyze_features, issues::analyze_issues,
        pull_requests::analyze_pull_requests, quality::analyze_quality, stats::fetch_repo_stats,
        structure::analyze_structure,
    };
    use crate::git::clone::clone_repository;
    use crate::output::markdown::generate_report;

    // Parse URL
    let repo_url = crate::RepoUrl::parse(&config.repo_url).map_err(|e| e.to_string())?;

    // Create GitHub client
    let client =
        github::GitHubClient::new(config.token.clone()).map_err(|e| e.to_string())?;

    // Fetch repo info
    let repo_info = client
        .get_repo_info(&repo_url.owner, &repo_url.repo)
        .await
        .map_err(|e| e.to_string())?;

    // Clone repository
    let clone_path = clone_repository(
        &repo_info.clone_url,
        &repo_info.default_branch,
        config.token.as_deref(),
    )
    .map_err(|e| e.to_string())?;

    // Run analysis
    let stats = fetch_repo_stats(&client, &repo_url.owner, &repo_url.repo).await;
    let structure = analyze_structure(&clone_path);
    let architecture = analyze_architecture(&clone_path);
    let features = analyze_features(&clone_path);
    let quality = analyze_quality(&clone_path, &repo_info);

    let issues = if config.include_issues {
        analyze_issues(&client, &repo_url.owner, &repo_url.repo, config.max_issues).await
    } else {
        IssuesAnalysis::default()
    };

    let pull_requests = if config.include_prs {
        analyze_pull_requests(&client, &repo_url.owner, &repo_url.repo, config.max_prs).await
    } else {
        PullRequestsAnalysis::default()
    };

    // Create result
    let result = AnalysisResult {
        repo_info: repo_info.clone(),
        stats,
        structure,
        architecture,
        features,
        quality: quality.clone(),
        issues,
        pull_requests,
        analyzed_at: chrono::Utc::now(),
        report_path: None,
    };

    // Generate report
    let report_path = generate_report(&result, &config.output_path).map_err(|e| e.to_string())?;

    // Read report content
    let report_content =
        std::fs::read_to_string(&report_path).unwrap_or_else(|_| String::from("Report generated"));

    // Cleanup
    let _ = std::fs::remove_dir_all(&clone_path);

    Ok(BridgeAnalysisResult {
        repo_name: repo_info.name,
        repo_full_name: repo_info.full_name,
        description: repo_info.description,
        html_url: repo_info.html_url,
        stars: repo_info.stars,
        forks: repo_info.forks,
        watchers: repo_info.watchers,
        open_issues: repo_info.open_issues,
        primary_language: repo_info.language,
        license: repo_info.license,
        topics: repo_info.topics,
        created_at: repo_info.created_at.to_rfc3339(),
        updated_at: repo_info.updated_at.to_rfc3339(),
        overall_score: quality.overall_score,
        documentation_score: quality.documentation_score,
        test_score: quality.test_coverage_score,
        maintenance_score: quality.maintenance_score,
        security_score: quality.security_score,
        has_readme: quality.has_readme,
        has_license: quality.has_license,
        has_contributing: quality.has_contributing,
        has_tests: quality.has_tests,
        has_ci: quality.has_ci,
        report_path: Some(report_path),
        report_content,
        analyzed_at: chrono::Utc::now().to_rfc3339(),
    })
}
