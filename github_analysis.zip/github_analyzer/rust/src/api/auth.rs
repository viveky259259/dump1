//! Token validation and authentication utilities

use crate::AnalyzerError;

/// Validates a GitHub Personal Access Token format
pub fn validate_token_format(token: &str) -> Result<(), AnalyzerError> {
    let token = token.trim();

    if token.is_empty() {
        return Err(AnalyzerError::AuthError("Token cannot be empty".to_string()));
    }

    // GitHub tokens can be:
    // - Classic tokens: ghp_xxxx (40 chars after prefix)
    // - Fine-grained tokens: github_pat_xxxx
    // - OAuth tokens: gho_xxxx
    // - User-to-server tokens: ghu_xxxx
    // - Server-to-server tokens: ghs_xxxx
    // - Refresh tokens: ghr_xxxx

    let valid_prefixes = ["ghp_", "github_pat_", "gho_", "ghu_", "ghs_", "ghr_"];

    let has_valid_prefix = valid_prefixes.iter().any(|prefix| token.starts_with(prefix));

    if !has_valid_prefix {
        // Allow legacy tokens (40 hex characters)
        if token.len() == 40 && token.chars().all(|c| c.is_ascii_hexdigit()) {
            return Ok(());
        }

        return Err(AnalyzerError::AuthError(
            "Invalid token format. Expected a GitHub Personal Access Token".to_string(),
        ));
    }

    Ok(())
}

/// Check required scopes for the token (basic validation)
pub fn check_required_scopes(token: &str) -> Result<(), AnalyzerError> {
    // For now, just validate the format
    // Actual scope checking would require an API call
    validate_token_format(token)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_classic_token() {
        let token = "ghp_1234567890abcdef1234567890abcdef12345678";
        assert!(validate_token_format(token).is_ok());
    }

    #[test]
    fn test_valid_fine_grained_token() {
        let token = "github_pat_1234567890abcdef";
        assert!(validate_token_format(token).is_ok());
    }

    #[test]
    fn test_valid_legacy_token() {
        let token = "1234567890abcdef1234567890abcdef12345678";
        assert!(validate_token_format(token).is_ok());
    }

    #[test]
    fn test_invalid_token() {
        let token = "invalid_token";
        assert!(validate_token_format(token).is_err());
    }

    #[test]
    fn test_empty_token() {
        assert!(validate_token_format("").is_err());
    }
}
