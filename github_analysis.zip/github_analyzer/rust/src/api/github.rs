//! GitHub API client using octocrab

use crate::{AnalyzerError, ContributorInfo, RepoInfo, RepoStats};
use chrono::Utc;
use octocrab::Octocrab;

/// GitHub API client wrapper
#[flutter_rust_bridge::frb(ignore)]
pub struct GitHubClient {
    client: Octocrab,
    has_token: bool,
}

impl GitHubClient {
    /// Create a new GitHub client, optionally with authentication
    pub fn new(token: Option<String>) -> Result<Self, AnalyzerError> {
        let client = if let Some(token) = token.as_ref() {
            super::auth::validate_token_format(token)?;
            Octocrab::builder()
                .personal_token(token.clone())
                .build()
                .map_err(|e| AnalyzerError::AuthError(e.to_string()))?
        } else {
            Octocrab::builder()
                .build()
                .map_err(|e| AnalyzerError::ApiError(e.to_string()))?
        };

        Ok(Self {
            client,
            has_token: token.is_some(),
        })
    }

    /// Check if client has authentication token
    pub fn is_authenticated(&self) -> bool {
        self.has_token
    }

    /// Get the underlying octocrab client
    pub fn inner(&self) -> &Octocrab {
        &self.client
    }

    /// Fetch repository information
    pub async fn get_repo_info(&self, owner: &str, repo: &str) -> Result<RepoInfo, AnalyzerError> {
        let repository = self
            .client
            .repos(owner, repo)
            .get()
            .await
            .map_err(|e| match e {
                octocrab::Error::GitHub { source, .. } if source.message.contains("Not Found") => {
                    AnalyzerError::NotFound
                }
                octocrab::Error::GitHub { source, .. }
                    if source.message.contains("rate limit") =>
                {
                    AnalyzerError::RateLimited(60)
                }
                _ => AnalyzerError::ApiError(e.to_string()),
            })?;

        Ok(RepoInfo {
            name: repository.name.clone(),
            full_name: repository.full_name.unwrap_or_else(|| format!("{}/{}", owner, repo)),
            description: repository.description.clone(),
            html_url: repository
                .html_url
                .map(|u| u.to_string())
                .unwrap_or_default(),
            clone_url: repository
                .clone_url
                .map(|u| u.to_string())
                .unwrap_or_else(|| format!("https://github.com/{}/{}.git", owner, repo)),
            default_branch: repository
                .default_branch
                .unwrap_or_else(|| "main".to_string()),
            language: repository.language.map(|l| l.to_string()),
            stars: repository.stargazers_count.unwrap_or(0) as u32,
            forks: repository.forks_count.unwrap_or(0) as u32,
            watchers: repository.watchers_count.unwrap_or(0) as u32,
            open_issues: repository.open_issues_count.unwrap_or(0) as u32,
            size_kb: repository.size.unwrap_or(0) as u32,
            created_at: repository.created_at.unwrap_or_else(Utc::now),
            updated_at: repository.updated_at.unwrap_or_else(Utc::now),
            pushed_at: repository.pushed_at,
            is_fork: repository.fork.unwrap_or(false),
            is_archived: repository.archived.unwrap_or(false),
            license: repository.license.map(|l| l.name),
            topics: repository.topics.unwrap_or_default(),
        })
    }

    /// Fetch repository contributors (simplified - returns empty for now due to API changes)
    pub async fn get_contributors(
        &self,
        _owner: &str,
        _repo: &str,
        _limit: u32,
    ) -> Result<Vec<ContributorInfo>, AnalyzerError> {
        // The list_contributors API has changed in this version of octocrab
        // For now, return empty and rely on other stats
        Ok(Vec::new())
    }

    /// Fetch open issues
    pub async fn get_issues(
        &self,
        owner: &str,
        repo: &str,
        state: &str,
        limit: u32,
    ) -> Result<Vec<octocrab::models::issues::Issue>, AnalyzerError> {
        let state = match state {
            "open" => octocrab::params::State::Open,
            "closed" => octocrab::params::State::Closed,
            _ => octocrab::params::State::All,
        };

        let issues = self
            .client
            .issues(owner, repo)
            .list()
            .state(state)
            .per_page(limit.min(100) as u8)
            .send()
            .await
            .map_err(|e| AnalyzerError::ApiError(e.to_string()))?;

        // Filter out pull requests (they're included in issues API)
        Ok(issues
            .items
            .into_iter()
            .filter(|i| i.pull_request.is_none())
            .collect())
    }

    /// Fetch pull requests
    pub async fn get_pull_requests(
        &self,
        owner: &str,
        repo: &str,
        state: &str,
        limit: u32,
    ) -> Result<Vec<octocrab::models::pulls::PullRequest>, AnalyzerError> {
        let state = match state {
            "open" => octocrab::params::State::Open,
            "closed" => octocrab::params::State::Closed,
            _ => octocrab::params::State::All,
        };

        let prs = self
            .client
            .pulls(owner, repo)
            .list()
            .state(state)
            .per_page(limit.min(100) as u8)
            .send()
            .await
            .map_err(|e| AnalyzerError::ApiError(e.to_string()))?;

        Ok(prs.items)
    }

    /// Get release count
    pub async fn get_releases(&self, owner: &str, repo: &str) -> Result<u32, AnalyzerError> {
        let releases = self
            .client
            .repos(owner, repo)
            .releases()
            .list()
            .per_page(100)
            .send()
            .await
            .map_err(|e| AnalyzerError::ApiError(e.to_string()))?;

        Ok(releases.items.len() as u32)
    }

    /// Get branch count
    pub async fn get_branches(&self, owner: &str, repo: &str) -> Result<u32, AnalyzerError> {
        let branches = self
            .client
            .repos(owner, repo)
            .list_branches()
            .per_page(100)
            .send()
            .await
            .map_err(|e| AnalyzerError::ApiError(e.to_string()))?;

        Ok(branches.items.len() as u32)
    }
}

/// Fetch repository statistics
pub async fn fetch_repo_stats(client: &GitHubClient, owner: &str, repo: &str) -> RepoStats {
    let contributors = client.get_contributors(owner, repo, 10).await.unwrap_or_default();
    let releases = client.get_releases(owner, repo).await.unwrap_or(0);
    let branches = client.get_branches(owner, repo).await.unwrap_or(0);

    RepoStats {
        total_commits: 0,
        total_contributors: contributors.len() as u32,
        total_branches: branches,
        total_releases: releases,
        code_frequency: vec![],
        commit_activity: vec![],
        top_contributors: contributors,
    }
}
