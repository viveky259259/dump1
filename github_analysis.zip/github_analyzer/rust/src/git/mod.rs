//! Git operations module

pub mod clone;
