//! Git clone operations using git2

use crate::AnalyzerError;
use git2::{build::RepoBuilder, Cred, FetchOptions, RemoteCallbacks};
use std::path::PathBuf;

/// Clone a repository to a temporary directory
pub fn clone_repository(
    url: &str,
    branch: &str,
    token: Option<&str>,
) -> Result<PathBuf, AnalyzerError> {
    let temp_dir = std::env::temp_dir().join(format!(
        "github_analyzer_{}",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_millis()
    ));

    // Create the directory
    std::fs::create_dir_all(&temp_dir)?;

    // Set up callbacks for authentication
    let mut callbacks = RemoteCallbacks::new();

    if let Some(token) = token {
        let token = token.to_string();
        callbacks.credentials(move |_url, _username_from_url, _allowed_types| {
            Cred::userpass_plaintext("git", &token)
        });
    }

    // Set up fetch options with shallow clone (depth=1)
    let mut fetch_opts = FetchOptions::new();
    fetch_opts.remote_callbacks(callbacks);
    fetch_opts.depth(1);

    // Build and execute clone
    let mut builder = RepoBuilder::new();
    builder.branch(branch);
    builder.fetch_options(fetch_opts);

    builder
        .clone(url, &temp_dir)
        .map_err(|e| AnalyzerError::GitError(format!("Failed to clone repository: {}", e)))?;

    Ok(temp_dir)
}

/// Remove a cloned repository directory
pub fn cleanup_clone(path: &PathBuf) -> Result<(), AnalyzerError> {
    if path.exists() {
        std::fs::remove_dir_all(path)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_temp_dir_creation() {
        let temp_dir = std::env::temp_dir().join("test_clone_dir");
        std::fs::create_dir_all(&temp_dir).unwrap();
        assert!(temp_dir.exists());
        std::fs::remove_dir_all(&temp_dir).unwrap();
    }
}
