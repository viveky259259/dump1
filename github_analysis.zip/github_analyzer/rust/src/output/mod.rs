//! Output generation modules

pub mod markdown;
