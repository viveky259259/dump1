//! Markdown report generation

use crate::{AnalysisResult, AnalyzerError};
use std::path::Path;

/// Generate markdown report from analysis result
pub fn generate_report(result: &AnalysisResult, output_path: &str) -> Result<String, AnalyzerError> {
    let mut md = String::new();

    // Header
    md.push_str(&format!(
        "# Repository Analysis: {}\n\n",
        result.repo_info.full_name
    ));

    md.push_str(&format!(
        "> Generated on {}\n\n",
        result.analyzed_at.format("%Y-%m-%d %H:%M:%S UTC")
    ));

    // Table of Contents
    md.push_str("## Table of Contents\n\n");
    md.push_str("1. [Overview](#overview)\n");
    md.push_str("2. [Repository Statistics](#repository-statistics)\n");
    md.push_str("3. [Tech Stack & Architecture](#tech-stack--architecture)\n");
    md.push_str("4. [Code Structure](#code-structure)\n");
    md.push_str("5. [Features](#features)\n");
    md.push_str("6. [Quality Assessment](#quality-assessment)\n");
    md.push_str("7. [Issues Analysis](#issues-analysis)\n");
    md.push_str("8. [Pull Requests Analysis](#pull-requests-analysis)\n");
    md.push_str("9. [Contributors](#contributors)\n\n");

    // Overview Section
    md.push_str("---\n\n## Overview\n\n");
    md.push_str(&format!("**Repository:** [{}]({})\n\n", result.repo_info.full_name, result.repo_info.html_url));

    if let Some(ref desc) = result.repo_info.description {
        md.push_str(&format!("**Description:** {}\n\n", desc));
    }

    md.push_str(&format!("| Metric | Value |\n"));
    md.push_str("|--------|-------|\n");
    md.push_str(&format!("| Stars | {} |\n", format_number(result.repo_info.stars)));
    md.push_str(&format!("| Forks | {} |\n", format_number(result.repo_info.forks)));
    md.push_str(&format!("| Watchers | {} |\n", format_number(result.repo_info.watchers)));
    md.push_str(&format!("| Open Issues | {} |\n", format_number(result.repo_info.open_issues)));
    md.push_str(&format!("| Size | {} KB |\n", format_number(result.repo_info.size_kb)));
    md.push_str(&format!("| Default Branch | `{}` |\n", result.repo_info.default_branch));

    if let Some(ref lang) = result.repo_info.language {
        md.push_str(&format!("| Primary Language | {} |\n", lang));
    }

    if let Some(ref license) = result.repo_info.license {
        md.push_str(&format!("| License | {} |\n", license));
    }

    md.push_str(&format!("| Created | {} |\n", result.repo_info.created_at.format("%Y-%m-%d")));
    md.push_str(&format!("| Last Updated | {} |\n", result.repo_info.updated_at.format("%Y-%m-%d")));

    if result.repo_info.is_archived {
        md.push_str("| Status | Archived |\n");
    }
    if result.repo_info.is_fork {
        md.push_str("| Fork | Yes |\n");
    }
    md.push('\n');

    if !result.repo_info.topics.is_empty() {
        md.push_str("**Topics:** ");
        md.push_str(&result.repo_info.topics.iter()
            .map(|t| format!("`{}`", t))
            .collect::<Vec<_>>()
            .join(", "));
        md.push_str("\n\n");
    }

    // Repository Statistics
    md.push_str("---\n\n## Repository Statistics\n\n");
    md.push_str(&format!("| Metric | Count |\n"));
    md.push_str("|--------|-------|\n");
    md.push_str(&format!("| Contributors | {} |\n", result.stats.total_contributors));
    md.push_str(&format!("| Branches | {} |\n", result.stats.total_branches));
    md.push_str(&format!("| Releases | {} |\n", result.stats.total_releases));
    md.push('\n');

    // Tech Stack & Architecture
    md.push_str("---\n\n## Tech Stack & Architecture\n\n");

    if let Some(ref lang) = result.architecture.primary_language {
        md.push_str(&format!("**Primary Language:** {}\n\n", lang));
    }

    if !result.architecture.frameworks.is_empty() {
        md.push_str("### Frameworks\n");
        for fw in &result.architecture.frameworks {
            md.push_str(&format!("- {}\n", fw));
        }
        md.push('\n');
    }

    if !result.architecture.build_tools.is_empty() {
        md.push_str("### Build Tools\n");
        for tool in &result.architecture.build_tools {
            md.push_str(&format!("- {}\n", tool));
        }
        md.push('\n');
    }

    if !result.architecture.package_managers.is_empty() {
        md.push_str("### Package Managers\n");
        for pm in &result.architecture.package_managers {
            md.push_str(&format!("- {}\n", pm));
        }
        md.push('\n');
    }

    if !result.architecture.ci_cd.is_empty() {
        md.push_str("### CI/CD\n");
        for ci in &result.architecture.ci_cd {
            md.push_str(&format!("- {}\n", ci));
        }
        md.push('\n');
    }

    if !result.architecture.testing_frameworks.is_empty() {
        md.push_str("### Testing\n");
        for tf in &result.architecture.testing_frameworks {
            md.push_str(&format!("- {}\n", tf));
        }
        md.push('\n');
    }

    if !result.architecture.databases.is_empty() {
        md.push_str("### Databases\n");
        for db in &result.architecture.databases {
            md.push_str(&format!("- {}\n", db));
        }
        md.push('\n');
    }

    if !result.architecture.cloud_services.is_empty() {
        md.push_str("### Cloud Services\n");
        for cs in &result.architecture.cloud_services {
            md.push_str(&format!("- {}\n", cs));
        }
        md.push('\n');
    }

    if !result.architecture.containerization.is_empty() {
        md.push_str("### Containerization\n");
        for c in &result.architecture.containerization {
            md.push_str(&format!("- {}\n", c));
        }
        md.push('\n');
    }

    if !result.architecture.patterns.is_empty() {
        md.push_str("### Architectural Patterns\n");
        for p in &result.architecture.patterns {
            md.push_str(&format!("- {}\n", p));
        }
        md.push('\n');
    }

    // Code Structure
    md.push_str("---\n\n## Code Structure\n\n");
    md.push_str(&format!("| Metric | Value |\n"));
    md.push_str("|--------|-------|\n");
    md.push_str(&format!("| Total Files | {} |\n", format_number(result.structure.total_files)));
    md.push_str(&format!("| Total Directories | {} |\n", format_number(result.structure.total_directories)));
    md.push_str(&format!("| Total Lines of Code | {} |\n", format_number(result.structure.total_lines as u32)));
    md.push('\n');

    if !result.structure.languages.is_empty() {
        md.push_str("### Language Breakdown\n\n");
        md.push_str("| Language | Files | Code | Comments | Blanks | % |\n");
        md.push_str("|----------|-------|------|----------|--------|---|\n");
        for lang in result.structure.languages.iter().take(15) {
            md.push_str(&format!(
                "| {} | {} | {} | {} | {} | {:.1}% |\n",
                lang.name, lang.files, lang.code, lang.comments, lang.blanks, lang.percentage
            ));
        }
        md.push('\n');
    }

    if !result.structure.entry_points.is_empty() {
        md.push_str("### Entry Points\n");
        for ep in &result.structure.entry_points {
            md.push_str(&format!("- `{}`\n", ep));
        }
        md.push('\n');
    }

    if !result.structure.config_files.is_empty() {
        md.push_str("### Configuration Files\n");
        for cf in &result.structure.config_files {
            md.push_str(&format!("- `{}`\n", cf));
        }
        md.push('\n');
    }

    if !result.structure.directory_tree.is_empty() {
        md.push_str("### Directory Structure\n\n");
        md.push_str("```\n");
        md.push_str(&result.structure.directory_tree);
        md.push_str("```\n\n");
    }

    // Features
    md.push_str("---\n\n## Features\n\n");

    if let Some(ref summary) = result.features.readme_summary {
        md.push_str("### Summary\n\n");
        md.push_str(summary);
        md.push_str("\n\n");
    }

    if !result.features.features.is_empty() {
        md.push_str("### Key Features\n\n");
        for feature in &result.features.features {
            md.push_str(&format!("- {}\n", feature));
        }
        md.push('\n');
    }

    if !result.features.installation_steps.is_empty() {
        md.push_str("### Installation\n\n");
        md.push_str("```bash\n");
        for step in &result.features.installation_steps {
            md.push_str(step);
            md.push('\n');
        }
        md.push_str("```\n\n");
    }

    if !result.features.api_endpoints.is_empty() {
        md.push_str("### API Endpoints\n\n");
        for endpoint in &result.features.api_endpoints {
            md.push_str(&format!("- `{}`\n", endpoint));
        }
        md.push('\n');
    }

    if !result.features.cli_commands.is_empty() {
        md.push_str("### CLI Commands\n\n");
        for cmd in &result.features.cli_commands {
            md.push_str(&format!("- `{}`\n", cmd));
        }
        md.push('\n');
    }

    // Quality Assessment
    md.push_str("---\n\n## Quality Assessment\n\n");

    md.push_str(&format!("### Overall Score: {:.0}/100\n\n", result.quality.overall_score));

    md.push_str("| Category | Score | Status |\n");
    md.push_str("|----------|-------|--------|\n");
    md.push_str(&format!("| Documentation | {:.0}/100 | {} |\n",
        result.quality.documentation_score,
        score_status(result.quality.documentation_score)));
    md.push_str(&format!("| Testing | {:.0}/100 | {} |\n",
        result.quality.test_coverage_score,
        score_status(result.quality.test_coverage_score)));
    md.push_str(&format!("| Maintenance | {:.0}/100 | {} |\n",
        result.quality.maintenance_score,
        score_status(result.quality.maintenance_score)));
    md.push_str(&format!("| Security | {:.0}/100 | {} |\n",
        result.quality.security_score,
        score_status(result.quality.security_score)));
    md.push_str(&format!("| Code Quality | {:.0}/100 | {} |\n",
        result.quality.code_quality_score,
        score_status(result.quality.code_quality_score)));
    md.push('\n');

    md.push_str("### Checklist\n\n");
    md.push_str(&format!("- [{}] README\n", if result.quality.has_readme { "x" } else { " " }));
    md.push_str(&format!("- [{}] LICENSE\n", if result.quality.has_license { "x" } else { " " }));
    md.push_str(&format!("- [{}] CONTRIBUTING guide\n", if result.quality.has_contributing { "x" } else { " " }));
    md.push_str(&format!("- [{}] CHANGELOG\n", if result.quality.has_changelog { "x" } else { " " }));
    md.push_str(&format!("- [{}] CI/CD configuration\n", if result.quality.has_ci { "x" } else { " " }));
    md.push_str(&format!("- [{}] Tests\n", if result.quality.has_tests { "x" } else { " " }));
    md.push_str(&format!("- [{}] Security policy\n", if result.quality.has_security_policy { "x" } else { " " }));
    md.push_str(&format!("- [{}] Code of Conduct\n", if result.quality.has_code_of_conduct { "x" } else { " " }));
    md.push('\n');

    if !result.quality.issues.is_empty() {
        md.push_str("### Quality Issues\n\n");
        for issue in &result.quality.issues {
            let icon = match issue.severity.as_str() {
                "high" => "!",
                "medium" => "?",
                _ => "i",
            };
            md.push_str(&format!("- [{}] **{}**: {}\n", icon, issue.category, issue.message));
        }
        md.push('\n');
    }

    // Issues Analysis
    md.push_str("---\n\n## Issues Analysis\n\n");
    md.push_str(&format!("| Status | Count |\n"));
    md.push_str("|--------|-------|\n");
    md.push_str(&format!("| Open | {} |\n", result.issues.total_open));
    md.push_str(&format!("| Closed | {} |\n", result.issues.total_closed));

    if let Some(avg) = result.issues.avg_close_time_days {
        md.push_str(&format!("| Avg. Close Time | {:.1} days |\n", avg));
    }
    md.push('\n');

    if !result.issues.categories.is_empty() {
        md.push_str("### Issue Categories\n\n");
        for cat in result.issues.categories.iter().take(10) {
            md.push_str(&format!("- **{}**: {} issues\n", cat.name, cat.count));
        }
        md.push('\n');
    }

    if !result.issues.bug_reports.is_empty() {
        md.push_str("### Recent Bug Reports\n\n");
        for bug in result.issues.bug_reports.iter().take(5) {
            md.push_str(&format!("- {}\n", bug));
        }
        md.push('\n');
    }

    if !result.issues.feature_requests.is_empty() {
        md.push_str("### Feature Requests\n\n");
        for fr in result.issues.feature_requests.iter().take(5) {
            md.push_str(&format!("- {}\n", fr));
        }
        md.push('\n');
    }

    // Pull Requests Analysis
    md.push_str("---\n\n## Pull Requests Analysis\n\n");
    md.push_str(&format!("| Status | Count |\n"));
    md.push_str("|--------|-------|\n");
    md.push_str(&format!("| Open | {} |\n", result.pull_requests.total_open));
    md.push_str(&format!("| Merged | {} |\n", result.pull_requests.total_merged));
    md.push_str(&format!("| Closed (unmerged) | {} |\n", result.pull_requests.total_closed));

    if let Some(avg) = result.pull_requests.avg_merge_time_days {
        md.push_str(&format!("| Avg. Merge Time | {:.1} days |\n", avg));
    }
    md.push('\n');

    if !result.pull_requests.focus_areas.is_empty() {
        md.push_str("### Focus Areas\n\n");
        for area in &result.pull_requests.focus_areas {
            md.push_str(&format!("- {}\n", area));
        }
        md.push('\n');
    }

    if !result.pull_requests.recent_prs.is_empty() {
        md.push_str("### Recent Pull Requests\n\n");
        md.push_str("| # | Title | Author | Status |\n");
        md.push_str("|---|-------|--------|--------|\n");
        for pr in result.pull_requests.recent_prs.iter().take(10) {
            md.push_str(&format!(
                "| #{} | {} | @{} | {} |\n",
                pr.number,
                truncate(&pr.title, 50),
                pr.author,
                pr.state
            ));
        }
        md.push('\n');
    }

    // Contributors
    md.push_str("---\n\n## Contributors\n\n");

    if !result.stats.top_contributors.is_empty() {
        md.push_str("### Top Contributors\n\n");
        md.push_str("| Contributor | Contributions |\n");
        md.push_str("|-------------|---------------|\n");
        for contributor in result.stats.top_contributors.iter().take(10) {
            md.push_str(&format!(
                "| @{} | {} |\n",
                contributor.login, contributor.contributions
            ));
        }
        md.push('\n');
    }

    if !result.pull_requests.active_contributors.is_empty() {
        md.push_str("### Active PR Contributors\n\n");
        md.push_str(&result.pull_requests.active_contributors
            .iter()
            .take(20)
            .map(|c| format!("@{}", c))
            .collect::<Vec<_>>()
            .join(", "));
        md.push_str("\n\n");
    }

    // Footer
    md.push_str("---\n\n");
    md.push_str("*Report generated by GitHub Repository Analyzer*\n");

    // Write to file
    let path = Path::new(output_path);

    // Create parent directories if needed
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }

    std::fs::write(path, &md)?;

    Ok(output_path.to_string())
}

fn format_number(n: u32) -> String {
    if n >= 1_000_000 {
        format!("{:.1}M", n as f64 / 1_000_000.0)
    } else if n >= 1_000 {
        format!("{:.1}K", n as f64 / 1_000.0)
    } else {
        n.to_string()
    }
}

fn score_status(score: f32) -> &'static str {
    if score >= 80.0 {
        "Excellent"
    } else if score >= 60.0 {
        "Good"
    } else if score >= 40.0 {
        "Fair"
    } else {
        "Needs Improvement"
    }
}

fn truncate(s: &str, max_len: usize) -> String {
    if s.len() <= max_len {
        s.to_string()
    } else {
        format!("{}...", &s[..max_len - 3])
    }
}
