//! GitHub Repository Analyzer Core Library
//!
//! This library provides the business logic for analyzing GitHub repositories,
//! including fetching repository data, cloning repos, and generating reports.

pub mod api;
pub mod analyzer;
pub mod git;
pub mod output;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use thiserror::Error;

/// Errors that can occur during analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Error, Debug)]
pub enum AnalyzerError {
    #[error("Invalid GitHub URL: {0}")]
    InvalidUrl(String),

    #[error("Authentication failed: {0}")]
    AuthError(String),

    #[error("GitHub API error: {0}")]
    ApiError(String),

    #[error("Git operation failed: {0}")]
    GitError(String),

    #[error("Analysis failed: {0}")]
    AnalysisError(String),

    #[error("IO error: {0}")]
    IoError(String),

    #[error("Repository not found")]
    NotFound,

    #[error("Rate limited. Retry after {0} seconds")]
    RateLimited(u64),
}

impl From<std::io::Error> for AnalyzerError {
    fn from(err: std::io::Error) -> Self {
        AnalyzerError::IoError(err.to_string())
    }
}

impl From<git2::Error> for AnalyzerError {
    fn from(err: git2::Error) -> Self {
        AnalyzerError::GitError(err.to_string())
    }
}

impl From<octocrab::Error> for AnalyzerError {
    fn from(err: octocrab::Error) -> Self {
        AnalyzerError::ApiError(err.to_string())
    }
}

/// Parsed GitHub repository URL
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RepoUrl {
    pub owner: String,
    pub repo: String,
    pub full_url: String,
}

impl RepoUrl {
    /// Parse a GitHub URL into owner and repo components
    pub fn parse(url: &str) -> Result<Self, AnalyzerError> {
        let url = url.trim();

        // Handle various GitHub URL formats
        let patterns = [
            r"^https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$",
            r"^git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$",
            r"^([^/]+)/([^/]+)$",
        ];

        for pattern in patterns {
            let re = regex::Regex::new(pattern).unwrap();
            if let Some(caps) = re.captures(url) {
                let owner = caps.get(1).unwrap().as_str().to_string();
                let repo = caps.get(2).unwrap().as_str().to_string();
                return Ok(Self {
                    full_url: format!("https://github.com/{}/{}", owner, repo),
                    owner,
                    repo,
                });
            }
        }

        Err(AnalyzerError::InvalidUrl(format!(
            "Could not parse GitHub URL: {}",
            url
        )))
    }
}

/// Configuration for the analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisConfig {
    pub repo_url: String,
    pub token: Option<String>,
    pub output_path: String,
    pub include_issues: bool,
    pub include_prs: bool,
    pub max_issues: u32,
    pub max_prs: u32,
}

impl Default for AnalysisConfig {
    fn default() -> Self {
        Self {
            repo_url: String::new(),
            token: None,
            output_path: String::from("./analysis_report.md"),
            include_issues: true,
            include_prs: true,
            max_issues: 100,
            max_prs: 50,
        }
    }
}

/// Progress phases during analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum AnalysisPhase {
    Initializing,
    ValidatingUrl,
    Authenticating,
    FetchingRepoInfo,
    CloningRepository,
    AnalyzingStructure,
    AnalyzingArchitecture,
    AnalyzingFeatures,
    AnalyzingQuality,
    FetchingIssues,
    AnalyzingIssues,
    FetchingPullRequests,
    AnalyzingPullRequests,
    GeneratingReport,
    WritingReport,
    Completed,
    Failed,
}

impl std::fmt::Display for AnalysisPhase {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            AnalysisPhase::Initializing => write!(f, "Initializing"),
            AnalysisPhase::ValidatingUrl => write!(f, "Validating URL"),
            AnalysisPhase::Authenticating => write!(f, "Authenticating"),
            AnalysisPhase::FetchingRepoInfo => write!(f, "Fetching repository info"),
            AnalysisPhase::CloningRepository => write!(f, "Cloning repository"),
            AnalysisPhase::AnalyzingStructure => write!(f, "Analyzing structure"),
            AnalysisPhase::AnalyzingArchitecture => write!(f, "Analyzing architecture"),
            AnalysisPhase::AnalyzingFeatures => write!(f, "Analyzing features"),
            AnalysisPhase::AnalyzingQuality => write!(f, "Analyzing quality"),
            AnalysisPhase::FetchingIssues => write!(f, "Fetching issues"),
            AnalysisPhase::AnalyzingIssues => write!(f, "Analyzing issues"),
            AnalysisPhase::FetchingPullRequests => write!(f, "Fetching pull requests"),
            AnalysisPhase::AnalyzingPullRequests => write!(f, "Analyzing pull requests"),
            AnalysisPhase::GeneratingReport => write!(f, "Generating report"),
            AnalysisPhase::WritingReport => write!(f, "Writing report"),
            AnalysisPhase::Completed => write!(f, "Completed"),
            AnalysisPhase::Failed => write!(f, "Failed"),
        }
    }
}

/// Progress update sent to UI
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisProgress {
    pub phase: AnalysisPhase,
    pub message: String,
    pub percent: f32,
}

/// Basic repository information from GitHub API
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RepoInfo {
    pub name: String,
    pub full_name: String,
    pub description: Option<String>,
    pub html_url: String,
    pub clone_url: String,
    pub default_branch: String,
    pub language: Option<String>,
    pub stars: u32,
    pub forks: u32,
    pub watchers: u32,
    pub open_issues: u32,
    pub size_kb: u32,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub pushed_at: Option<DateTime<Utc>>,
    pub is_fork: bool,
    pub is_archived: bool,
    pub license: Option<String>,
    pub topics: Vec<String>,
}

/// Repository statistics
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RepoStats {
    pub total_commits: u32,
    pub total_contributors: u32,
    pub total_branches: u32,
    pub total_releases: u32,
    pub code_frequency: Vec<(String, i64, i64)>, // week, additions, deletions
    pub commit_activity: Vec<u32>, // commits per week for last 52 weeks
    pub top_contributors: Vec<ContributorInfo>,
}

/// Contributor information
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContributorInfo {
    pub login: String,
    pub contributions: u32,
    pub avatar_url: String,
}

/// Directory structure analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct StructureAnalysis {
    pub total_files: u32,
    pub total_directories: u32,
    pub total_lines: u64,
    pub languages: Vec<LanguageStats>,
    pub entry_points: Vec<String>,
    pub config_files: Vec<String>,
    pub doc_files: Vec<String>,
    pub test_directories: Vec<String>,
    pub directory_tree: String,
}

/// Language statistics from tokei
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LanguageStats {
    pub name: String,
    pub files: u32,
    pub lines: u64,
    pub code: u64,
    pub comments: u64,
    pub blanks: u64,
    pub percentage: f32,
}

/// Architecture and tech stack analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ArchitectureAnalysis {
    pub primary_language: Option<String>,
    pub frameworks: Vec<String>,
    pub build_tools: Vec<String>,
    pub package_managers: Vec<String>,
    pub ci_cd: Vec<String>,
    pub testing_frameworks: Vec<String>,
    pub databases: Vec<String>,
    pub cloud_services: Vec<String>,
    pub containerization: Vec<String>,
    pub patterns: Vec<String>,
}

/// Features extracted from README and code
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct FeaturesAnalysis {
    pub readme_summary: Option<String>,
    pub features: Vec<String>,
    pub installation_steps: Vec<String>,
    pub usage_examples: Vec<String>,
    pub api_endpoints: Vec<String>,
    pub cli_commands: Vec<String>,
}

/// Quality scoring
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct QualityAnalysis {
    pub overall_score: f32,
    pub documentation_score: f32,
    pub test_coverage_score: f32,
    pub maintenance_score: f32,
    pub security_score: f32,
    pub code_quality_score: f32,
    pub has_readme: bool,
    pub has_contributing: bool,
    pub has_license: bool,
    pub has_changelog: bool,
    pub has_ci: bool,
    pub has_tests: bool,
    pub has_security_policy: bool,
    pub has_code_of_conduct: bool,
    pub issues: Vec<QualityIssue>,
}

/// Quality issue found during analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QualityIssue {
    pub severity: String,
    pub category: String,
    pub message: String,
}

/// GitHub issue data
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IssueInfo {
    pub number: u32,
    pub title: String,
    pub state: String,
    pub labels: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub closed_at: Option<DateTime<Utc>>,
    pub comments: u32,
    pub author: String,
    pub body_preview: Option<String>,
}

/// Issues analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct IssuesAnalysis {
    pub total_open: u32,
    pub total_closed: u32,
    pub avg_close_time_days: Option<f32>,
    pub avg_response_time_hours: Option<f32>,
    pub categories: Vec<IssueCategory>,
    pub recent_issues: Vec<IssueInfo>,
    pub common_complaints: Vec<String>,
    pub feature_requests: Vec<String>,
    pub bug_reports: Vec<String>,
}

/// Issue category with count
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IssueCategory {
    pub name: String,
    pub count: u32,
}

/// Pull request data
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PullRequestInfo {
    pub number: u32,
    pub title: String,
    pub state: String,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub merged_at: Option<DateTime<Utc>>,
    pub closed_at: Option<DateTime<Utc>>,
    pub author: String,
    pub labels: Vec<String>,
    pub additions: u32,
    pub deletions: u32,
    pub changed_files: u32,
}

/// Pull requests analysis
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PullRequestsAnalysis {
    pub total_open: u32,
    pub total_merged: u32,
    pub total_closed: u32,
    pub avg_merge_time_days: Option<f32>,
    pub avg_review_time_hours: Option<f32>,
    pub focus_areas: Vec<String>,
    pub recent_prs: Vec<PullRequestInfo>,
    pub active_contributors: Vec<String>,
}

/// Complete analysis result
#[flutter_rust_bridge::frb(ignore)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisResult {
    pub repo_info: RepoInfo,
    pub stats: RepoStats,
    pub structure: StructureAnalysis,
    pub architecture: ArchitectureAnalysis,
    pub features: FeaturesAnalysis,
    pub quality: QualityAnalysis,
    pub issues: IssuesAnalysis,
    pub pull_requests: PullRequestsAnalysis,
    pub analyzed_at: DateTime<Utc>,
    pub report_path: Option<String>,
}

/// Main entry point for running analysis
pub async fn analyze_repository(
    config: AnalysisConfig,
    progress_callback: impl Fn(AnalysisProgress) + Send + Sync + 'static,
) -> Result<AnalysisResult, AnalyzerError> {
    use crate::analyzer::{
        architecture::analyze_architecture,
        features::analyze_features,
        issues::analyze_issues,
        pull_requests::analyze_pull_requests,
        quality::analyze_quality,
        stats::fetch_repo_stats,
        structure::analyze_structure,
    };
    use crate::api::GitHubClient;
    use crate::git::clone::clone_repository;
    use crate::output::markdown::generate_report;

    let send_progress = |phase: AnalysisPhase, message: &str, percent: f32| {
        progress_callback(AnalysisProgress {
            phase,
            message: message.to_string(),
            percent,
        });
    };

    // Phase 1: Validate URL
    send_progress(AnalysisPhase::ValidatingUrl, "Parsing repository URL...", 0.0);
    let repo_url = RepoUrl::parse(&config.repo_url)?;

    // Phase 2: Initialize GitHub client
    send_progress(AnalysisPhase::Authenticating, "Setting up GitHub client...", 5.0);
    let client = GitHubClient::new(config.token.clone())?;

    // Phase 3: Fetch repository info
    send_progress(AnalysisPhase::FetchingRepoInfo, "Fetching repository information...", 10.0);
    let repo_info = client.get_repo_info(&repo_url.owner, &repo_url.repo).await?;

    // Phase 4: Clone repository
    send_progress(AnalysisPhase::CloningRepository, "Cloning repository...", 15.0);
    let clone_path = clone_repository(&repo_info.clone_url, &repo_info.default_branch, config.token.as_deref())?;

    // Phase 5: Fetch stats
    send_progress(AnalysisPhase::FetchingRepoInfo, "Fetching repository statistics...", 25.0);
    let stats = fetch_repo_stats(&client, &repo_url.owner, &repo_url.repo).await;

    // Phase 6: Analyze structure
    send_progress(AnalysisPhase::AnalyzingStructure, "Analyzing repository structure...", 35.0);
    let structure = analyze_structure(&clone_path);

    // Phase 7: Analyze architecture
    send_progress(AnalysisPhase::AnalyzingArchitecture, "Detecting tech stack...", 45.0);
    let architecture = analyze_architecture(&clone_path);

    // Phase 8: Analyze features
    send_progress(AnalysisPhase::AnalyzingFeatures, "Extracting features...", 55.0);
    let features = analyze_features(&clone_path);

    // Phase 9: Analyze quality
    send_progress(AnalysisPhase::AnalyzingQuality, "Calculating quality scores...", 60.0);
    let quality = analyze_quality(&clone_path, &repo_info);

    // Phase 10: Analyze issues
    let issues = if config.include_issues {
        send_progress(AnalysisPhase::FetchingIssues, "Fetching issues...", 65.0);
        send_progress(AnalysisPhase::AnalyzingIssues, "Analyzing issues...", 70.0);
        analyze_issues(&client, &repo_url.owner, &repo_url.repo, config.max_issues).await
    } else {
        IssuesAnalysis::default()
    };

    // Phase 11: Analyze pull requests
    let pull_requests = if config.include_prs {
        send_progress(AnalysisPhase::FetchingPullRequests, "Fetching pull requests...", 75.0);
        send_progress(AnalysisPhase::AnalyzingPullRequests, "Analyzing pull requests...", 80.0);
        analyze_pull_requests(&client, &repo_url.owner, &repo_url.repo, config.max_prs).await
    } else {
        PullRequestsAnalysis::default()
    };

    // Phase 12: Generate report
    send_progress(AnalysisPhase::GeneratingReport, "Generating markdown report...", 85.0);
    let mut result = AnalysisResult {
        repo_info,
        stats,
        structure,
        architecture,
        features,
        quality,
        issues,
        pull_requests,
        analyzed_at: Utc::now(),
        report_path: None,
    };

    // Phase 13: Write report
    send_progress(AnalysisPhase::WritingReport, "Writing report to file...", 95.0);
    let report_path = generate_report(&result, &config.output_path)?;
    result.report_path = Some(report_path.clone());

    // Cleanup clone directory
    if let Err(e) = std::fs::remove_dir_all(&clone_path) {
        eprintln!("Warning: Failed to cleanup clone directory: {}", e);
    }

    send_progress(AnalysisPhase::Completed, "Analysis complete!", 100.0);

    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_github_url() {
        let url = "https://github.com/rust-lang/rust";
        let parsed = RepoUrl::parse(url).unwrap();
        assert_eq!(parsed.owner, "rust-lang");
        assert_eq!(parsed.repo, "rust");
    }

    #[test]
    fn test_parse_github_url_with_git() {
        let url = "https://github.com/rust-lang/rust.git";
        let parsed = RepoUrl::parse(url).unwrap();
        assert_eq!(parsed.owner, "rust-lang");
        assert_eq!(parsed.repo, "rust");
    }

    #[test]
    fn test_parse_short_format() {
        let url = "rust-lang/rust";
        let parsed = RepoUrl::parse(url).unwrap();
        assert_eq!(parsed.owner, "rust-lang");
        assert_eq!(parsed.repo, "rust");
    }

    #[test]
    fn test_invalid_url() {
        let url = "not-a-valid-url";
        assert!(RepoUrl::parse(url).is_err());
    }
}
