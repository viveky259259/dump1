//! Quality scoring and analysis

use crate::{QualityAnalysis, QualityIssue, RepoInfo};
use std::path::Path;

/// Analyze repository quality
pub fn analyze_quality(repo_path: &Path, repo_info: &RepoInfo) -> QualityAnalysis {
    let mut analysis = QualityAnalysis::default();

    // Check for various files/directories
    analysis.has_readme = has_readme(repo_path);
    analysis.has_contributing = has_file(repo_path, &["CONTRIBUTING.md", "CONTRIBUTING"]);
    analysis.has_license = has_file(repo_path, &["LICENSE", "LICENSE.md", "LICENSE.txt"]);
    analysis.has_changelog = has_file(
        repo_path,
        &["CHANGELOG.md", "CHANGELOG", "HISTORY.md", "NEWS.md"],
    );
    analysis.has_ci = has_ci(repo_path);
    analysis.has_tests = has_tests(repo_path);
    analysis.has_security_policy = has_file(repo_path, &["SECURITY.md", ".github/SECURITY.md"]);
    analysis.has_code_of_conduct = has_file(
        repo_path,
        &["CODE_OF_CONDUCT.md", ".github/CODE_OF_CONDUCT.md"],
    );

    // Calculate scores
    analysis.documentation_score = calculate_documentation_score(&analysis, repo_path);
    analysis.test_coverage_score = calculate_test_score(repo_path);
    analysis.maintenance_score = calculate_maintenance_score(repo_info);
    analysis.security_score = calculate_security_score(&analysis, repo_path);
    analysis.code_quality_score = calculate_code_quality_score(repo_path);

    // Calculate overall score (weighted average)
    analysis.overall_score = (analysis.documentation_score * 0.2
        + analysis.test_coverage_score * 0.25
        + analysis.maintenance_score * 0.2
        + analysis.security_score * 0.15
        + analysis.code_quality_score * 0.2)
        .min(100.0);

    // Find issues
    analysis.issues = find_quality_issues(&analysis, repo_path);

    analysis
}

fn has_readme(path: &Path) -> bool {
    let readme_names = [
        "README.md",
        "readme.md",
        "Readme.md",
        "README.rst",
        "README.txt",
        "README",
    ];
    readme_names.iter().any(|name| path.join(name).exists())
}

fn has_file(path: &Path, names: &[&str]) -> bool {
    names.iter().any(|name| path.join(name).exists())
}

fn has_ci(path: &Path) -> bool {
    path.join(".github/workflows").exists()
        || path.join(".gitlab-ci.yml").exists()
        || path.join(".travis.yml").exists()
        || path.join("Jenkinsfile").exists()
        || path.join(".circleci").exists()
        || path.join("azure-pipelines.yml").exists()
}

fn has_tests(path: &Path) -> bool {
    // Check for test directories
    let test_dirs = ["tests", "test", "spec", "__tests__"];
    if test_dirs.iter().any(|dir| path.join(dir).exists()) {
        return true;
    }

    // Check for test files pattern
    for entry in walkdir::WalkDir::new(path)
        .max_depth(4)
        .into_iter()
        .filter_map(|e| e.ok())
    {
        if let Some(name) = entry.file_name().to_str() {
            let name_lower = name.to_lowercase();
            if name_lower.contains("test")
                || name_lower.contains("spec")
                || name_lower.ends_with("_test.go")
                || name_lower.ends_with("_test.rs")
            {
                return true;
            }
        }
    }

    false
}

fn calculate_documentation_score(analysis: &QualityAnalysis, repo_path: &Path) -> f32 {
    let mut score: f32 = 0.0;

    // README (40 points)
    if analysis.has_readme {
        score += 20.0;

        // Check README quality
        if let Ok(content) = std::fs::read_to_string(repo_path.join("README.md")) {
            let len = content.len();
            if len > 500 {
                score += 5.0;
            }
            if len > 2000 {
                score += 5.0;
            }
            if content.contains("## ") || content.contains("### ") {
                score += 5.0; // Has structure
            }
            if content.contains("```") {
                score += 5.0; // Has code examples
            }
        }
    }

    // Contributing guide (15 points)
    if analysis.has_contributing {
        score += 15.0;
    }

    // Changelog (15 points)
    if analysis.has_changelog {
        score += 15.0;
    }

    // License (15 points)
    if analysis.has_license {
        score += 15.0;
    }

    // Code of conduct (5 points)
    if analysis.has_code_of_conduct {
        score += 5.0;
    }

    // Docs directory (10 points)
    if repo_path.join("docs").exists() || repo_path.join("documentation").exists() {
        score += 10.0;
    }

    score.min(100.0)
}

fn calculate_test_score(repo_path: &Path) -> f32 {
    let mut score: f32 = 0.0;

    // Has any tests (base 30 points)
    let has_test_dir = repo_path.join("tests").exists()
        || repo_path.join("test").exists()
        || repo_path.join("__tests__").exists()
        || repo_path.join("spec").exists();

    if has_test_dir {
        score += 30.0;
    }

    // Count test files
    let mut test_file_count = 0u32;
    let mut total_files = 0u32;

    for entry in walkdir::WalkDir::new(repo_path)
        .max_depth(6)
        .into_iter()
        .filter_entry(|e| {
            e.file_name()
                .to_str()
                .map(|s| !s.starts_with('.') && s != "node_modules" && s != "vendor")
                .unwrap_or(false)
        })
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
    {
        if let Some(name) = entry.file_name().to_str() {
            let name_lower = name.to_lowercase();
            let is_code = name.ends_with(".rs")
                || name.ends_with(".py")
                || name.ends_with(".js")
                || name.ends_with(".ts")
                || name.ends_with(".go")
                || name.ends_with(".java");

            if is_code {
                total_files += 1;
                if name_lower.contains("test") || name_lower.contains("spec") {
                    test_file_count += 1;
                }
            }
        }
    }

    // Test coverage approximation
    if total_files > 0 {
        let ratio = test_file_count as f32 / total_files as f32;
        score += (ratio * 50.0).min(50.0); // Up to 50 points for coverage ratio
    }

    // Check for testing config (10 points)
    let has_test_config = repo_path.join("jest.config.js").exists()
        || repo_path.join("jest.config.ts").exists()
        || repo_path.join("vitest.config.ts").exists()
        || repo_path.join("pytest.ini").exists()
        || repo_path.join("phpunit.xml").exists();

    if has_test_config {
        score += 10.0;
    }

    // Check for coverage config (10 points)
    let has_coverage_config = repo_path.join(".coveragerc").exists()
        || repo_path.join("codecov.yml").exists()
        || repo_path.join(".codecov.yml").exists();

    if has_coverage_config {
        score += 10.0;
    }

    score.min(100.0)
}

fn calculate_maintenance_score(repo_info: &RepoInfo) -> f32 {
    let mut score: f32 = 50.0; // Base score

    // Recent activity
    if let Some(pushed_at) = repo_info.pushed_at {
        let days_since_push = (chrono::Utc::now() - pushed_at).num_days();
        if days_since_push < 7 {
            score += 30.0;
        } else if days_since_push < 30 {
            score += 20.0;
        } else if days_since_push < 90 {
            score += 10.0;
        } else if days_since_push > 365 {
            score -= 20.0;
        }
    }

    // Not archived
    if repo_info.is_archived {
        score -= 30.0;
    }

    // Stars indicate community interest
    if repo_info.stars > 1000 {
        score += 10.0;
    } else if repo_info.stars > 100 {
        score += 5.0;
    }

    // Forks indicate active development
    if repo_info.forks > 100 {
        score += 5.0;
    }

    // Open issues ratio (too many might be bad)
    if repo_info.open_issues < 50 {
        score += 5.0;
    } else if repo_info.open_issues > 500 {
        score -= 10.0;
    }

    score.max(0.0).min(100.0)
}

fn calculate_security_score(analysis: &QualityAnalysis, repo_path: &Path) -> f32 {
    let mut score: f32 = 50.0; // Base score

    // Security policy (20 points)
    if analysis.has_security_policy {
        score += 20.0;
    }

    // License (10 points)
    if analysis.has_license {
        score += 10.0;
    }

    // Check for security-related files
    if repo_path.join(".github/dependabot.yml").exists()
        || repo_path.join(".github/dependabot.yaml").exists()
    {
        score += 10.0; // Dependabot
    }

    // Check for .env.example (good practice)
    if repo_path.join(".env.example").exists() {
        score += 5.0;
    }

    // Check for secrets in .gitignore
    if let Ok(content) = std::fs::read_to_string(repo_path.join(".gitignore")) {
        if content.contains(".env") || content.contains("secrets") {
            score += 5.0;
        }
    }

    score.min(100.0)
}

fn calculate_code_quality_score(repo_path: &Path) -> f32 {
    let mut score: f32 = 50.0; // Base score

    // Linting config
    let lint_configs = [
        ".eslintrc",
        ".eslintrc.js",
        ".eslintrc.json",
        "eslint.config.js",
        ".prettierrc",
        ".prettierrc.js",
        "prettier.config.js",
        "rustfmt.toml",
        ".rustfmt.toml",
        "clippy.toml",
        ".pylintrc",
        "pyproject.toml",
        ".rubocop.yml",
        ".golangci.yml",
    ];

    let has_lint_config = lint_configs.iter().any(|f| repo_path.join(f).exists());
    if has_lint_config {
        score += 20.0;
    }

    // TypeScript (type safety)
    if repo_path.join("tsconfig.json").exists() {
        score += 10.0;
    }

    // EditorConfig
    if repo_path.join(".editorconfig").exists() {
        score += 5.0;
    }

    // Pre-commit hooks
    if repo_path.join(".husky").exists() || repo_path.join(".pre-commit-config.yaml").exists() {
        score += 10.0;
    }

    // Gitignore
    if repo_path.join(".gitignore").exists() {
        score += 5.0;
    }

    score.min(100.0)
}

fn find_quality_issues(analysis: &QualityAnalysis, repo_path: &Path) -> Vec<QualityIssue> {
    let mut issues = Vec::new();

    // Documentation issues
    if !analysis.has_readme {
        issues.push(QualityIssue {
            severity: "high".to_string(),
            category: "documentation".to_string(),
            message: "No README file found".to_string(),
        });
    }

    if !analysis.has_license {
        issues.push(QualityIssue {
            severity: "medium".to_string(),
            category: "legal".to_string(),
            message: "No LICENSE file found".to_string(),
        });
    }

    if !analysis.has_contributing && analysis.has_readme {
        issues.push(QualityIssue {
            severity: "low".to_string(),
            category: "documentation".to_string(),
            message: "No CONTRIBUTING guide found".to_string(),
        });
    }

    // Testing issues
    if !analysis.has_tests {
        issues.push(QualityIssue {
            severity: "high".to_string(),
            category: "testing".to_string(),
            message: "No test files or test directory found".to_string(),
        });
    }

    // CI/CD issues
    if !analysis.has_ci {
        issues.push(QualityIssue {
            severity: "medium".to_string(),
            category: "automation".to_string(),
            message: "No CI/CD configuration found".to_string(),
        });
    }

    // Security issues
    if !analysis.has_security_policy {
        issues.push(QualityIssue {
            severity: "low".to_string(),
            category: "security".to_string(),
            message: "No SECURITY.md policy found".to_string(),
        });
    }

    // Check for .env file (should not be committed)
    if repo_path.join(".env").exists() {
        issues.push(QualityIssue {
            severity: "high".to_string(),
            category: "security".to_string(),
            message: ".env file is committed (may contain secrets)".to_string(),
        });
    }

    // Check gitignore
    if !repo_path.join(".gitignore").exists() {
        issues.push(QualityIssue {
            severity: "medium".to_string(),
            category: "configuration".to_string(),
            message: "No .gitignore file found".to_string(),
        });
    }

    issues
}
