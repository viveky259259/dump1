//! Feature extraction from README and code

use crate::FeaturesAnalysis;
use regex::Regex;
use std::path::Path;

/// Analyze features from README and code structure
pub fn analyze_features(repo_path: &Path) -> FeaturesAnalysis {
    let mut analysis = FeaturesAnalysis::default();

    // Try to read README
    let readme_content = read_readme(repo_path);

    if let Some(ref content) = readme_content {
        analysis.readme_summary = extract_summary(content);
        analysis.features = extract_features(content);
        analysis.installation_steps = extract_installation(content);
        analysis.usage_examples = extract_usage(content);
    }

    // Extract API endpoints if applicable
    analysis.api_endpoints = find_api_endpoints(repo_path);

    // Extract CLI commands if applicable
    analysis.cli_commands = find_cli_commands(repo_path);

    analysis
}

fn read_readme(path: &Path) -> Option<String> {
    let readme_names = [
        "README.md",
        "readme.md",
        "Readme.md",
        "README.rst",
        "README.txt",
        "README",
    ];

    for name in readme_names {
        if let Ok(content) = std::fs::read_to_string(path.join(name)) {
            return Some(content);
        }
    }
    None
}

fn extract_summary(content: &str) -> Option<String> {
    // Get first paragraph after main heading
    let lines: Vec<&str> = content.lines().collect();

    let mut found_heading = false;
    let mut summary_lines = Vec::new();

    for line in lines {
        let trimmed = line.trim();

        // Skip badges and empty lines at start
        if !found_heading {
            if trimmed.starts_with('#') && !trimmed.starts_with("##") {
                found_heading = true;
                continue;
            }
            continue;
        }

        // Skip badges
        if trimmed.starts_with("[![") || trimmed.starts_with("![") {
            continue;
        }

        // Stop at next heading
        if trimmed.starts_with('#') {
            break;
        }

        // Empty line ends paragraph
        if trimmed.is_empty() && !summary_lines.is_empty() {
            break;
        }

        if !trimmed.is_empty() {
            summary_lines.push(trimmed);
        }
    }

    if summary_lines.is_empty() {
        None
    } else {
        Some(summary_lines.join(" "))
    }
}

fn extract_features(content: &str) -> Vec<String> {
    let mut features = Vec::new();

    // Look for "Features" section
    let feature_section = find_section(content, &["features", "highlights", "what's included"]);

    if let Some(section) = feature_section {
        // Extract bullet points
        for line in section.lines() {
            let trimmed = line.trim();
            if trimmed.starts_with('-')
                || trimmed.starts_with('*')
                || trimmed.starts_with("•")
                || (trimmed.len() > 2 && trimmed.chars().nth(1) == Some('.'))
            {
                let feature = trimmed
                    .trim_start_matches(|c| c == '-' || c == '*' || c == '•')
                    .trim_start_matches(|c: char| c.is_numeric())
                    .trim_start_matches('.')
                    .trim();
                if !feature.is_empty() && feature.len() < 200 {
                    features.push(feature.to_string());
                }
            }
        }
    }

    // Limit to first 20 features
    features.truncate(20);
    features
}

fn extract_installation(content: &str) -> Vec<String> {
    let mut steps = Vec::new();

    let install_section = find_section(
        content,
        &[
            "installation",
            "install",
            "getting started",
            "setup",
            "quick start",
        ],
    );

    if let Some(section) = install_section {
        // Look for code blocks
        let code_block_re = Regex::new(r"```(?:bash|sh|shell|zsh)?\n([\s\S]*?)```").unwrap();

        for cap in code_block_re.captures_iter(&section) {
            if let Some(code) = cap.get(1) {
                for line in code.as_str().lines() {
                    let trimmed = line.trim();
                    if !trimmed.is_empty()
                        && !trimmed.starts_with('#')
                        && !trimmed.starts_with("//")
                    {
                        steps.push(trimmed.to_string());
                    }
                }
            }
        }

        // Also check for numbered steps
        let numbered_re = Regex::new(r"^\d+\.\s+(.+)$").unwrap();
        for line in section.lines() {
            if let Some(cap) = numbered_re.captures(line.trim()) {
                if let Some(step) = cap.get(1) {
                    steps.push(step.as_str().to_string());
                }
            }
        }
    }

    // Limit
    steps.truncate(15);
    steps
}

fn extract_usage(content: &str) -> Vec<String> {
    let mut examples = Vec::new();

    let usage_section = find_section(content, &["usage", "example", "examples", "basic usage"]);

    if let Some(section) = usage_section {
        // Extract code blocks
        let code_block_re = Regex::new(r"```[\w]*\n([\s\S]*?)```").unwrap();

        for cap in code_block_re.captures_iter(&section) {
            if let Some(code) = cap.get(1) {
                let code_str = code.as_str().trim();
                if !code_str.is_empty() && code_str.len() < 500 {
                    examples.push(code_str.to_string());
                }
            }
        }
    }

    examples.truncate(5);
    examples
}

fn find_section(content: &str, headings: &[&str]) -> Option<String> {
    let heading_re = Regex::new(r"(?m)^#{1,3}\s*(.+)$").unwrap();
    let lines: Vec<&str> = content.lines().collect();

    let mut section_start = None;
    let mut section_level = 0;

    for (i, line) in lines.iter().enumerate() {
        if let Some(cap) = heading_re.captures(line) {
            let heading_text = cap.get(1).unwrap().as_str().to_lowercase();
            let level = line.chars().take_while(|&c| c == '#').count();

            if section_start.is_some() {
                // Found next heading at same or higher level
                if level <= section_level {
                    let section: String = lines[section_start.unwrap()..i].join("\n");
                    return Some(section);
                }
            } else {
                // Check if this heading matches
                for search_heading in headings {
                    if heading_text.contains(search_heading) {
                        section_start = Some(i + 1);
                        section_level = level;
                        break;
                    }
                }
            }
        }
    }

    // Return rest of document if section found but no end
    if let Some(start) = section_start {
        return Some(lines[start..].join("\n"));
    }

    None
}

fn find_api_endpoints(path: &Path) -> Vec<String> {
    let mut endpoints = Vec::new();

    // Look for common API route patterns in source files
    let route_patterns = [
        r#"@(?:app|router)\.\w+\(['"](/[^'"]*)['"]\)"#,      // Flask/FastAPI
        r#"router\.(?:get|post|put|delete|patch)\(['"](/[^'"]*)['"]\)"#, // Express
        r#"@(?:Get|Post|Put|Delete|Patch)\(['"](/[^'"]*)['"]\)"#, // NestJS
        r#"path\(['"](/[^'"]*)['"]\)"#,                      // Django
    ];

    let combined_pattern = route_patterns.join("|");
    let re = Regex::new(&combined_pattern).ok();

    if let Some(re) = re {
        for entry in walkdir::WalkDir::new(path)
            .max_depth(5)
            .into_iter()
            .filter_map(|e| e.ok())
            .filter(|e| {
                e.file_type().is_file()
                    && e.path()
                        .extension()
                        .map(|ext| {
                            matches!(
                                ext.to_str(),
                                Some("py") | Some("js") | Some("ts") | Some("rs") | Some("go")
                            )
                        })
                        .unwrap_or(false)
            })
        {
            if let Ok(content) = std::fs::read_to_string(entry.path()) {
                for cap in re.captures_iter(&content) {
                    // Get the first captured group that matched
                    for i in 1..cap.len() {
                        if let Some(m) = cap.get(i) {
                            endpoints.push(m.as_str().to_string());
                            break;
                        }
                    }
                }
            }
        }
    }

    // Dedupe and limit
    endpoints.sort();
    endpoints.dedup();
    endpoints.truncate(30);
    endpoints
}

fn find_cli_commands(path: &Path) -> Vec<String> {
    let mut commands = Vec::new();

    // Check for CLI patterns in package.json bin
    if let Ok(content) = std::fs::read_to_string(path.join("package.json")) {
        if let Ok(json) = serde_json::from_str::<serde_json::Value>(&content) {
            if let Some(bin) = json.get("bin") {
                match bin {
                    serde_json::Value::String(_cmd) => {
                        if let Some(name) = json.get("name").and_then(|n| n.as_str()) {
                            commands.push(name.to_string());
                        }
                    }
                    serde_json::Value::Object(map) => {
                        for key in map.keys() {
                            commands.push(key.clone());
                        }
                    }
                    _ => {}
                }
            }
        }
    }

    // Check Cargo.toml for binary targets
    if let Ok(content) = std::fs::read_to_string(path.join("Cargo.toml")) {
        let bin_re = Regex::new(r#"\[\[bin\]\]\s*name\s*=\s*"([^"]+)""#).unwrap();
        for cap in bin_re.captures_iter(&content) {
            if let Some(name) = cap.get(1) {
                commands.push(name.as_str().to_string());
            }
        }

        // Also check package name for default binary
        let name_re = Regex::new(r#"name\s*=\s*"([^"]+)""#).unwrap();
        if let Some(cap) = name_re.captures(&content) {
            if let Some(name) = cap.get(1) {
                let name_str = name.as_str().to_string();
                if !commands.contains(&name_str) {
                    commands.push(name_str);
                }
            }
        }
    }

    // Check for CLI frameworks
    if let Ok(content) = std::fs::read_to_string(path.join("package.json")) {
        if content.contains("commander") || content.contains("yargs") || content.contains("meow") {
            // Already captured in bin section
        }
    }

    commands.truncate(10);
    commands
}
