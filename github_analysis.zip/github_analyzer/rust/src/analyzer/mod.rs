//! Analysis modules for repository inspection

pub mod architecture;
pub mod features;
pub mod issues;
pub mod pull_requests;
pub mod quality;
pub mod stats;
pub mod structure;
