//! GitHub issues analysis

use crate::api::GitHubClient;
use crate::{IssueCategory, IssueInfo, IssuesAnalysis};
use std::collections::HashMap;

/// Analyze repository issues
pub async fn analyze_issues(
    client: &GitHubClient,
    owner: &str,
    repo: &str,
    max_issues: u32,
) -> IssuesAnalysis {
    let mut analysis = IssuesAnalysis::default();

    // Fetch open issues
    let open_issues = client
        .get_issues(owner, repo, "open", max_issues)
        .await
        .unwrap_or_default();

    // Fetch closed issues
    let closed_issues = client
        .get_issues(owner, repo, "closed", max_issues)
        .await
        .unwrap_or_default();

    analysis.total_open = open_issues.len() as u32;
    analysis.total_closed = closed_issues.len() as u32;

    // Calculate average close time
    let close_times: Vec<f32> = closed_issues
        .iter()
        .filter_map(|issue| {
            issue.closed_at.map(|closed| {
                let duration = closed - issue.created_at;
                duration.num_hours() as f32 / 24.0
            })
        })
        .collect();

    if !close_times.is_empty() {
        analysis.avg_close_time_days =
            Some(close_times.iter().sum::<f32>() / close_times.len() as f32);
    }

    // Categorize issues by labels
    let mut label_counts: HashMap<String, u32> = HashMap::new();
    for issue in open_issues.iter().chain(closed_issues.iter()) {
        for label in &issue.labels {
            *label_counts.entry(label.name.clone()).or_insert(0) += 1;
        }
    }

    // Convert to categories
    let mut categories: Vec<IssueCategory> = label_counts
        .into_iter()
        .map(|(name, count)| IssueCategory { name, count })
        .collect();
    categories.sort_by(|a, b| b.count.cmp(&a.count));
    categories.truncate(15);
    analysis.categories = categories;

    // Get recent issues
    let mut recent: Vec<IssueInfo> = open_issues
        .iter()
        .take(10)
        .map(|issue| IssueInfo {
            number: issue.number as u32,
            title: issue.title.clone(),
            state: format!("{:?}", issue.state),
            labels: issue.labels.iter().map(|l| l.name.clone()).collect(),
            created_at: issue.created_at,
            updated_at: issue.updated_at,
            closed_at: issue.closed_at,
            comments: issue.comments as u32,
            author: issue.user.login.clone(),
            body_preview: issue.body.as_ref().map(|b| {
                let preview: String = b.chars().take(200).collect();
                if b.len() > 200 {
                    format!("{}...", preview)
                } else {
                    preview
                }
            }),
        })
        .collect();
    recent.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    analysis.recent_issues = recent;

    // Identify common complaints and feature requests
    analysis.bug_reports = identify_issues_by_type(&open_issues, &["bug", "defect", "error"]);
    analysis.feature_requests =
        identify_issues_by_type(&open_issues, &["feature", "enhancement", "request"]);
    analysis.common_complaints = extract_common_themes(&open_issues);

    analysis
}

fn identify_issues_by_type(
    issues: &[octocrab::models::issues::Issue],
    type_labels: &[&str],
) -> Vec<String> {
    issues
        .iter()
        .filter(|issue| {
            issue
                .labels
                .iter()
                .any(|label| type_labels.iter().any(|t| label.name.to_lowercase().contains(t)))
        })
        .take(10)
        .map(|issue| format!("#{}: {}", issue.number, issue.title))
        .collect()
}

fn extract_common_themes(issues: &[octocrab::models::issues::Issue]) -> Vec<String> {
    let mut word_counts: HashMap<String, u32> = HashMap::new();

    // Common words to ignore
    let stop_words = [
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
        "do", "does", "did", "will", "would", "could", "should", "may", "might", "must", "shall",
        "can", "need", "dare", "ought", "used", "to", "of", "in", "for", "on", "with", "at", "by",
        "from", "as", "into", "through", "during", "before", "after", "above", "below", "between",
        "under", "again", "further", "then", "once", "here", "there", "when", "where", "why",
        "how", "all", "each", "few", "more", "most", "other", "some", "such", "no", "nor", "not",
        "only", "own", "same", "so", "than", "too", "very", "just", "and", "but", "if", "or",
        "because", "until", "while", "this", "that", "these", "those", "it", "its", "i", "you",
        "he", "she", "we", "they", "what", "which", "who", "whom", "whose", "when",
    ];

    for issue in issues {
        let title_words: Vec<String> = issue
            .title
            .to_lowercase()
            .split(|c: char| !c.is_alphanumeric())
            .filter(|w| w.len() > 3 && !stop_words.contains(&w.as_ref()))
            .map(|s| s.to_string())
            .collect();

        for word in title_words {
            *word_counts.entry(word).or_insert(0) += 1;
        }
    }

    // Get top themes
    let mut themes: Vec<(String, u32)> = word_counts.into_iter().collect();
    themes.sort_by(|a, b| b.1.cmp(&a.1));

    themes
        .into_iter()
        .take(10)
        .filter(|(_, count)| *count > 1)
        .map(|(word, count)| format!("{} ({} mentions)", word, count))
        .collect()
}
