//! Repository statistics analysis

use crate::api::GitHubClient;
use crate::RepoStats;

/// Fetch repository statistics from GitHub API
pub async fn fetch_repo_stats(client: &GitHubClient, owner: &str, repo: &str) -> RepoStats {
    crate::api::github_fetch_repo_stats(client, owner, repo).await
}
