//! Pull requests analysis

use crate::api::GitHubClient;
use crate::{PullRequestInfo, PullRequestsAnalysis};
use std::collections::{HashMap, HashSet};

/// Analyze repository pull requests
pub async fn analyze_pull_requests(
    client: &GitHubClient,
    owner: &str,
    repo: &str,
    max_prs: u32,
) -> PullRequestsAnalysis {
    let mut analysis = PullRequestsAnalysis::default();

    // Fetch open PRs
    let open_prs = client
        .get_pull_requests(owner, repo, "open", max_prs)
        .await
        .unwrap_or_default();

    // Fetch closed PRs (includes merged)
    let closed_prs = client
        .get_pull_requests(owner, repo, "closed", max_prs)
        .await
        .unwrap_or_default();

    analysis.total_open = open_prs.len() as u32;

    // Count merged vs just closed
    let merged_count = closed_prs.iter().filter(|pr| pr.merged_at.is_some()).count();
    let closed_count = closed_prs.len() - merged_count;

    analysis.total_merged = merged_count as u32;
    analysis.total_closed = closed_count as u32;

    // Calculate average merge time
    let merge_times: Vec<f32> = closed_prs
        .iter()
        .filter_map(|pr| {
            pr.merged_at.map(|merged| {
                let duration = merged - pr.created_at.unwrap_or_else(chrono::Utc::now);
                duration.num_hours() as f32 / 24.0
            })
        })
        .collect();

    if !merge_times.is_empty() {
        analysis.avg_merge_time_days =
            Some(merge_times.iter().sum::<f32>() / merge_times.len() as f32);
    }

    // Get recent PRs
    let recent_prs: Vec<PullRequestInfo> = open_prs
        .iter()
        .chain(closed_prs.iter())
        .take(15)
        .map(|pr| PullRequestInfo {
            number: pr.number as u32,
            title: pr.title.clone().unwrap_or_default(),
            state: if pr.merged_at.is_some() {
                "merged".to_string()
            } else if pr.closed_at.is_some() {
                "closed".to_string()
            } else {
                "open".to_string()
            },
            created_at: pr.created_at.unwrap_or_else(chrono::Utc::now),
            updated_at: pr.updated_at.unwrap_or_else(chrono::Utc::now),
            merged_at: pr.merged_at,
            closed_at: pr.closed_at,
            author: pr
                .user
                .as_ref()
                .map(|u| u.login.clone())
                .unwrap_or_else(|| "unknown".to_string()),
            labels: pr.labels.as_ref().map(|labels| {
                labels.iter().map(|l| l.name.clone()).collect()
            }).unwrap_or_default(),
            additions: pr.additions.unwrap_or(0) as u32,
            deletions: pr.deletions.unwrap_or(0) as u32,
            changed_files: pr.changed_files.unwrap_or(0) as u32,
        })
        .collect();
    analysis.recent_prs = recent_prs;

    // Identify focus areas from PR titles
    analysis.focus_areas = extract_focus_areas(&open_prs, &closed_prs);

    // Get active contributors
    let mut contributors: HashSet<String> = HashSet::new();
    for pr in open_prs.iter().chain(closed_prs.iter()) {
        if let Some(user) = &pr.user {
            contributors.insert(user.login.clone());
        }
    }
    analysis.active_contributors = contributors.into_iter().take(20).collect();

    analysis
}

fn extract_focus_areas(
    open_prs: &[octocrab::models::pulls::PullRequest],
    closed_prs: &[octocrab::models::pulls::PullRequest],
) -> Vec<String> {
    let mut area_counts: HashMap<String, u32> = HashMap::new();

    // Common prefixes/patterns in PR titles that indicate focus areas
    let area_patterns = [
        ("fix", "Bug Fixes"),
        ("feat", "New Features"),
        ("feature", "New Features"),
        ("add", "Additions"),
        ("update", "Updates"),
        ("refactor", "Refactoring"),
        ("docs", "Documentation"),
        ("test", "Testing"),
        ("ci", "CI/CD"),
        ("build", "Build System"),
        ("perf", "Performance"),
        ("security", "Security"),
        ("deps", "Dependencies"),
        ("chore", "Maintenance"),
    ];

    for pr in open_prs.iter().chain(closed_prs.iter()) {
        let title = pr.title.clone().unwrap_or_default().to_lowercase();

        for (pattern, area) in &area_patterns {
            if title.starts_with(pattern) || title.contains(&format!("[{}]", pattern)) {
                *area_counts.entry(area.to_string()).or_insert(0) += 1;
                break;
            }
        }

        // Also check labels
        if let Some(labels) = &pr.labels {
            for label in labels {
                let label_name = label.name.to_lowercase();
                for (pattern, area) in &area_patterns {
                    if label_name.contains(pattern) {
                        *area_counts.entry(area.to_string()).or_insert(0) += 1;
                        break;
                    }
                }
            }
        }
    }

    // Sort by count and return top areas
    let mut areas: Vec<(String, u32)> = area_counts.into_iter().collect();
    areas.sort_by(|a, b| b.1.cmp(&a.1));

    areas
        .into_iter()
        .take(8)
        .map(|(area, count)| format!("{} ({} PRs)", area, count))
        .collect()
}
