//! Directory structure analysis using tokei

use crate::{LanguageStats, StructureAnalysis};
use std::path::Path;
use tokei::{Config, Languages};
use walkdir::WalkDir;

/// Analyze repository structure and language statistics
pub fn analyze_structure(repo_path: &Path) -> StructureAnalysis {
    let mut analysis = StructureAnalysis::default();

    // Count files and directories
    let (files, dirs) = count_files_and_dirs(repo_path);
    analysis.total_files = files;
    analysis.total_directories = dirs;

    // Analyze languages with tokei
    let languages = analyze_languages(repo_path);
    let total_code: u64 = languages.iter().map(|l| l.code).sum();
    analysis.total_lines = total_code;
    analysis.languages = languages;

    // Find entry points
    analysis.entry_points = find_entry_points(repo_path);

    // Find config files
    analysis.config_files = find_config_files(repo_path);

    // Find documentation files
    analysis.doc_files = find_doc_files(repo_path);

    // Find test directories
    analysis.test_directories = find_test_dirs(repo_path);

    // Generate directory tree
    analysis.directory_tree = generate_tree(repo_path, 3);

    analysis
}

fn count_files_and_dirs(path: &Path) -> (u32, u32) {
    let mut files = 0u32;
    let mut dirs = 0u32;

    for entry in WalkDir::new(path)
        .into_iter()
        .filter_entry(|e| !is_hidden(e) && !is_git_dir(e))
        .filter_map(|e| e.ok())
    {
        if entry.file_type().is_file() {
            files += 1;
        } else if entry.file_type().is_dir() && entry.path() != path {
            dirs += 1;
        }
    }

    (files, dirs)
}

fn is_hidden(entry: &walkdir::DirEntry) -> bool {
    entry
        .file_name()
        .to_str()
        .map(|s| s.starts_with('.') && s != ".")
        .unwrap_or(false)
}

fn is_git_dir(entry: &walkdir::DirEntry) -> bool {
    entry.file_name().to_str() == Some(".git")
}

fn analyze_languages(path: &Path) -> Vec<LanguageStats> {
    let config = Config::default();
    let mut languages = Languages::new();
    languages.get_statistics(&[path], &[], &config);

    let total_code: u64 = languages.iter().map(|(_, l)| l.code as u64).sum();

    let mut stats: Vec<LanguageStats> = languages
        .iter()
        .filter(|(_, l)| l.code > 0)
        .map(|(lang_type, lang)| {
            let code = lang.code as u64;
            LanguageStats {
                name: format!("{:?}", lang_type),
                files: lang.reports.len() as u32,
                lines: (lang.code + lang.comments + lang.blanks) as u64,
                code,
                comments: lang.comments as u64,
                blanks: lang.blanks as u64,
                percentage: if total_code > 0 {
                    (code as f32 / total_code as f32) * 100.0
                } else {
                    0.0
                },
            }
        })
        .collect();

    // Sort by code lines descending
    stats.sort_by(|a, b| b.code.cmp(&a.code));
    stats
}

fn find_entry_points(path: &Path) -> Vec<String> {
    let entry_point_patterns = [
        "main.rs",
        "lib.rs",
        "main.py",
        "__main__.py",
        "app.py",
        "index.js",
        "index.ts",
        "main.js",
        "main.ts",
        "app.js",
        "app.ts",
        "main.go",
        "Main.java",
        "Program.cs",
        "main.c",
        "main.cpp",
        "index.html",
        "main.dart",
    ];

    let mut entry_points = Vec::new();

    for entry in WalkDir::new(path)
        .max_depth(5)
        .into_iter()
        .filter_entry(|e| !is_hidden(e) && !is_git_dir(e))
        .filter_map(|e| e.ok())
    {
        if let Some(name) = entry.file_name().to_str() {
            if entry_point_patterns.contains(&name) {
                if let Ok(rel_path) = entry.path().strip_prefix(path) {
                    entry_points.push(rel_path.display().to_string());
                }
            }
        }
    }

    entry_points
}

fn find_config_files(path: &Path) -> Vec<String> {
    let config_patterns = [
        "package.json",
        "Cargo.toml",
        "pyproject.toml",
        "setup.py",
        "requirements.txt",
        "go.mod",
        "pom.xml",
        "build.gradle",
        "Gemfile",
        "composer.json",
        "tsconfig.json",
        "webpack.config.js",
        "vite.config.ts",
        ".env.example",
        "docker-compose.yml",
        "Dockerfile",
        "Makefile",
        "CMakeLists.txt",
        "pubspec.yaml",
    ];

    let mut configs = Vec::new();

    for entry in WalkDir::new(path)
        .max_depth(3)
        .into_iter()
        .filter_entry(|e| !is_hidden(e) && !is_git_dir(e))
        .filter_map(|e| e.ok())
    {
        if let Some(name) = entry.file_name().to_str() {
            if config_patterns.contains(&name) {
                if let Ok(rel_path) = entry.path().strip_prefix(path) {
                    configs.push(rel_path.display().to_string());
                }
            }
        }
    }

    configs
}

fn find_doc_files(path: &Path) -> Vec<String> {
    let doc_patterns = [
        "README.md",
        "README.rst",
        "README.txt",
        "README",
        "CONTRIBUTING.md",
        "CHANGELOG.md",
        "HISTORY.md",
        "LICENSE",
        "LICENSE.md",
        "LICENSE.txt",
        "CODE_OF_CONDUCT.md",
        "SECURITY.md",
        "docs",
        "documentation",
    ];

    let mut docs = Vec::new();

    for entry in WalkDir::new(path)
        .max_depth(2)
        .into_iter()
        .filter_entry(|e| !is_hidden(e) && !is_git_dir(e))
        .filter_map(|e| e.ok())
    {
        if let Some(name) = entry.file_name().to_str() {
            let name_lower = name.to_lowercase();
            if doc_patterns
                .iter()
                .any(|p| p.to_lowercase() == name_lower || name_lower.starts_with(&p.to_lowercase()))
            {
                if let Ok(rel_path) = entry.path().strip_prefix(path) {
                    docs.push(rel_path.display().to_string());
                }
            }
        }
    }

    docs
}

fn find_test_dirs(path: &Path) -> Vec<String> {
    let test_patterns = ["test", "tests", "spec", "specs", "__tests__", "test_"];

    let mut test_dirs = Vec::new();

    for entry in WalkDir::new(path)
        .max_depth(3)
        .into_iter()
        .filter_entry(|e| !is_hidden(e) && !is_git_dir(e))
        .filter_map(|e| e.ok())
    {
        if entry.file_type().is_dir() {
            if let Some(name) = entry.file_name().to_str() {
                let name_lower = name.to_lowercase();
                if test_patterns
                    .iter()
                    .any(|p| name_lower == *p || name_lower.starts_with(p))
                {
                    if let Ok(rel_path) = entry.path().strip_prefix(path) {
                        test_dirs.push(rel_path.display().to_string());
                    }
                }
            }
        }
    }

    test_dirs
}

fn generate_tree(path: &Path, max_depth: usize) -> String {
    let mut tree = String::new();

    if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
        tree.push_str(name);
        tree.push('\n');
    }

    generate_tree_recursive(path, &mut tree, "", max_depth, 0);
    tree
}

fn generate_tree_recursive(
    path: &Path,
    tree: &mut String,
    prefix: &str,
    max_depth: usize,
    current_depth: usize,
) {
    if current_depth >= max_depth {
        return;
    }

    let mut entries: Vec<_> = std::fs::read_dir(path)
        .ok()
        .map(|rd| rd.filter_map(|e| e.ok()).collect())
        .unwrap_or_default();

    // Filter and sort entries
    entries.retain(|e| {
        e.file_name()
            .to_str()
            .map(|s| !s.starts_with('.'))
            .unwrap_or(false)
    });
    entries.sort_by(|a, b| {
        let a_is_dir = a.file_type().map(|t| t.is_dir()).unwrap_or(false);
        let b_is_dir = b.file_type().map(|t| t.is_dir()).unwrap_or(false);
        match (a_is_dir, b_is_dir) {
            (true, false) => std::cmp::Ordering::Less,
            (false, true) => std::cmp::Ordering::Greater,
            _ => a.file_name().cmp(&b.file_name()),
        }
    });

    let count = entries.len();
    for (i, entry) in entries.into_iter().enumerate() {
        let is_last = i == count - 1;
        let connector = if is_last { "└── " } else { "├── " };
        let name = entry.file_name().to_string_lossy().to_string();

        tree.push_str(prefix);
        tree.push_str(connector);
        tree.push_str(&name);
        tree.push('\n');

        if entry.file_type().map(|t| t.is_dir()).unwrap_or(false) {
            let new_prefix = format!("{}{}   ", prefix, if is_last { " " } else { "│" });
            generate_tree_recursive(&entry.path(), tree, &new_prefix, max_depth, current_depth + 1);
        }
    }
}
