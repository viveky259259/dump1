//! Architecture and tech stack detection

use crate::ArchitectureAnalysis;
use std::collections::HashSet;
use std::path::Path;

/// Analyze repository architecture and tech stack
pub fn analyze_architecture(repo_path: &Path) -> ArchitectureAnalysis {
    let mut analysis = ArchitectureAnalysis::default();

    // Detect primary language from file extensions
    analysis.primary_language = detect_primary_language(repo_path);

    // Detect frameworks
    analysis.frameworks = detect_frameworks(repo_path);

    // Detect build tools
    analysis.build_tools = detect_build_tools(repo_path);

    // Detect package managers
    analysis.package_managers = detect_package_managers(repo_path);

    // Detect CI/CD
    analysis.ci_cd = detect_ci_cd(repo_path);

    // Detect testing frameworks
    analysis.testing_frameworks = detect_testing_frameworks(repo_path);

    // Detect databases
    analysis.databases = detect_databases(repo_path);

    // Detect cloud services
    analysis.cloud_services = detect_cloud_services(repo_path);

    // Detect containerization
    analysis.containerization = detect_containerization(repo_path);

    // Detect patterns
    analysis.patterns = detect_patterns(repo_path);

    analysis
}

fn detect_primary_language(path: &Path) -> Option<String> {
    let mut lang_counts: std::collections::HashMap<&str, u32> = std::collections::HashMap::new();

    for entry in walkdir::WalkDir::new(path)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
    {
        if let Some(ext) = entry.path().extension().and_then(|e| e.to_str()) {
            let lang = match ext {
                "rs" => "Rust",
                "py" => "Python",
                "js" | "jsx" => "JavaScript",
                "ts" | "tsx" => "TypeScript",
                "go" => "Go",
                "java" => "Java",
                "kt" => "Kotlin",
                "swift" => "Swift",
                "c" | "h" => "C",
                "cpp" | "cc" | "cxx" | "hpp" => "C++",
                "cs" => "C#",
                "rb" => "Ruby",
                "php" => "PHP",
                "dart" => "Dart",
                "scala" => "Scala",
                "ex" | "exs" => "Elixir",
                "hs" => "Haskell",
                "clj" => "Clojure",
                _ => continue,
            };
            *lang_counts.entry(lang).or_insert(0) += 1;
        }
    }

    lang_counts
        .into_iter()
        .max_by_key(|(_, count)| *count)
        .map(|(lang, _)| lang.to_string())
}

fn detect_frameworks(path: &Path) -> Vec<String> {
    let mut frameworks = HashSet::new();

    // Check package.json for JS frameworks
    if let Ok(content) = std::fs::read_to_string(path.join("package.json")) {
        let content_lower = content.to_lowercase();
        if content_lower.contains("\"react\"") {
            frameworks.insert("React".to_string());
        }
        if content_lower.contains("\"vue\"") {
            frameworks.insert("Vue.js".to_string());
        }
        if content_lower.contains("\"angular\"") || content_lower.contains("\"@angular/core\"") {
            frameworks.insert("Angular".to_string());
        }
        if content_lower.contains("\"next\"") {
            frameworks.insert("Next.js".to_string());
        }
        if content_lower.contains("\"express\"") {
            frameworks.insert("Express.js".to_string());
        }
        if content_lower.contains("\"nestjs\"") || content_lower.contains("\"@nestjs/") {
            frameworks.insert("NestJS".to_string());
        }
        if content_lower.contains("\"svelte\"") {
            frameworks.insert("Svelte".to_string());
        }
        if content_lower.contains("\"electron\"") {
            frameworks.insert("Electron".to_string());
        }
    }

    // Check Cargo.toml for Rust frameworks
    if let Ok(content) = std::fs::read_to_string(path.join("Cargo.toml")) {
        let content_lower = content.to_lowercase();
        if content_lower.contains("actix-web") {
            frameworks.insert("Actix Web".to_string());
        }
        if content_lower.contains("axum") {
            frameworks.insert("Axum".to_string());
        }
        if content_lower.contains("rocket") {
            frameworks.insert("Rocket".to_string());
        }
        if content_lower.contains("warp") {
            frameworks.insert("Warp".to_string());
        }
        if content_lower.contains("tokio") {
            frameworks.insert("Tokio".to_string());
        }
        if content_lower.contains("tauri") {
            frameworks.insert("Tauri".to_string());
        }
    }

    // Check Python frameworks
    let python_files = ["requirements.txt", "pyproject.toml", "setup.py", "Pipfile"];
    for file in python_files {
        if let Ok(content) = std::fs::read_to_string(path.join(file)) {
            let content_lower = content.to_lowercase();
            if content_lower.contains("django") {
                frameworks.insert("Django".to_string());
            }
            if content_lower.contains("flask") {
                frameworks.insert("Flask".to_string());
            }
            if content_lower.contains("fastapi") {
                frameworks.insert("FastAPI".to_string());
            }
            if content_lower.contains("pytorch") || content_lower.contains("torch") {
                frameworks.insert("PyTorch".to_string());
            }
            if content_lower.contains("tensorflow") {
                frameworks.insert("TensorFlow".to_string());
            }
        }
    }

    // Check Go frameworks
    if let Ok(content) = std::fs::read_to_string(path.join("go.mod")) {
        if content.contains("gin-gonic") {
            frameworks.insert("Gin".to_string());
        }
        if content.contains("labstack/echo") {
            frameworks.insert("Echo".to_string());
        }
        if content.contains("gorilla/mux") {
            frameworks.insert("Gorilla Mux".to_string());
        }
    }

    // Check Flutter/Dart
    if let Ok(content) = std::fs::read_to_string(path.join("pubspec.yaml")) {
        if content.contains("flutter:") {
            frameworks.insert("Flutter".to_string());
        }
    }

    // Check Ruby frameworks
    if let Ok(content) = std::fs::read_to_string(path.join("Gemfile")) {
        if content.contains("rails") {
            frameworks.insert("Ruby on Rails".to_string());
        }
        if content.contains("sinatra") {
            frameworks.insert("Sinatra".to_string());
        }
    }

    frameworks.into_iter().collect()
}

fn detect_build_tools(path: &Path) -> Vec<String> {
    let mut tools = HashSet::new();

    // File-based detection
    let build_files = [
        ("Makefile", "Make"),
        ("CMakeLists.txt", "CMake"),
        ("build.gradle", "Gradle"),
        ("build.gradle.kts", "Gradle (Kotlin DSL)"),
        ("pom.xml", "Maven"),
        ("webpack.config.js", "Webpack"),
        ("vite.config.ts", "Vite"),
        ("vite.config.js", "Vite"),
        ("rollup.config.js", "Rollup"),
        ("esbuild.config.js", "esbuild"),
        ("turbo.json", "Turborepo"),
        ("nx.json", "Nx"),
        ("bazel", "Bazel"),
        ("BUILD", "Bazel"),
        ("meson.build", "Meson"),
    ];

    for (file, tool) in build_files {
        if path.join(file).exists() {
            tools.insert(tool.to_string());
        }
    }

    // Cargo.toml means Cargo
    if path.join("Cargo.toml").exists() {
        tools.insert("Cargo".to_string());
    }

    tools.into_iter().collect()
}

fn detect_package_managers(path: &Path) -> Vec<String> {
    let mut managers = HashSet::new();

    let manager_files = [
        ("package-lock.json", "npm"),
        ("yarn.lock", "Yarn"),
        ("pnpm-lock.yaml", "pnpm"),
        ("bun.lockb", "Bun"),
        ("Cargo.lock", "Cargo"),
        ("Pipfile.lock", "Pipenv"),
        ("poetry.lock", "Poetry"),
        ("go.sum", "Go Modules"),
        ("Gemfile.lock", "Bundler"),
        ("composer.lock", "Composer"),
        ("pubspec.lock", "Pub"),
        ("Package.resolved", "Swift Package Manager"),
    ];

    for (file, manager) in manager_files {
        if path.join(file).exists() {
            managers.insert(manager.to_string());
        }
    }

    managers.into_iter().collect()
}

fn detect_ci_cd(path: &Path) -> Vec<String> {
    let mut ci_cd = HashSet::new();

    // GitHub Actions
    if path.join(".github/workflows").exists() {
        ci_cd.insert("GitHub Actions".to_string());
    }

    // GitLab CI
    if path.join(".gitlab-ci.yml").exists() {
        ci_cd.insert("GitLab CI".to_string());
    }

    // Jenkins
    if path.join("Jenkinsfile").exists() {
        ci_cd.insert("Jenkins".to_string());
    }

    // Travis CI
    if path.join(".travis.yml").exists() {
        ci_cd.insert("Travis CI".to_string());
    }

    // CircleCI
    if path.join(".circleci/config.yml").exists() {
        ci_cd.insert("CircleCI".to_string());
    }

    // Azure Pipelines
    if path.join("azure-pipelines.yml").exists() {
        ci_cd.insert("Azure Pipelines".to_string());
    }

    // Buildkite
    if path.join(".buildkite").exists() {
        ci_cd.insert("Buildkite".to_string());
    }

    ci_cd.into_iter().collect()
}

fn detect_testing_frameworks(path: &Path) -> Vec<String> {
    let mut frameworks = HashSet::new();

    // Check package.json for JS testing
    if let Ok(content) = std::fs::read_to_string(path.join("package.json")) {
        let content_lower = content.to_lowercase();
        if content_lower.contains("\"jest\"") {
            frameworks.insert("Jest".to_string());
        }
        if content_lower.contains("\"mocha\"") {
            frameworks.insert("Mocha".to_string());
        }
        if content_lower.contains("\"vitest\"") {
            frameworks.insert("Vitest".to_string());
        }
        if content_lower.contains("\"cypress\"") {
            frameworks.insert("Cypress".to_string());
        }
        if content_lower.contains("\"playwright\"") {
            frameworks.insert("Playwright".to_string());
        }
    }

    // Check Python testing
    let python_files = ["requirements.txt", "pyproject.toml", "setup.py"];
    for file in python_files {
        if let Ok(content) = std::fs::read_to_string(path.join(file)) {
            let content_lower = content.to_lowercase();
            if content_lower.contains("pytest") {
                frameworks.insert("pytest".to_string());
            }
            if content_lower.contains("unittest") {
                frameworks.insert("unittest".to_string());
            }
        }
    }

    // Check for test directories
    if path.join("tests").exists() || path.join("test").exists() {
        // Rust has built-in testing
        if path.join("Cargo.toml").exists() {
            frameworks.insert("Rust built-in tests".to_string());
        }
    }

    frameworks.into_iter().collect()
}

fn detect_databases(path: &Path) -> Vec<String> {
    let mut databases = HashSet::new();

    // Search in common config files
    let search_files = [
        "package.json",
        "Cargo.toml",
        "requirements.txt",
        "docker-compose.yml",
        ".env.example",
    ];

    for file in search_files {
        if let Ok(content) = std::fs::read_to_string(path.join(file)) {
            let content_lower = content.to_lowercase();
            if content_lower.contains("postgres") || content_lower.contains("postgresql") {
                databases.insert("PostgreSQL".to_string());
            }
            if content_lower.contains("mysql") {
                databases.insert("MySQL".to_string());
            }
            if content_lower.contains("mongodb") || content_lower.contains("mongo") {
                databases.insert("MongoDB".to_string());
            }
            if content_lower.contains("redis") {
                databases.insert("Redis".to_string());
            }
            if content_lower.contains("sqlite") {
                databases.insert("SQLite".to_string());
            }
            if content_lower.contains("dynamodb") {
                databases.insert("DynamoDB".to_string());
            }
            if content_lower.contains("elasticsearch") {
                databases.insert("Elasticsearch".to_string());
            }
        }
    }

    databases.into_iter().collect()
}

fn detect_cloud_services(path: &Path) -> Vec<String> {
    let mut services = HashSet::new();

    // Check for AWS
    if path.join("serverless.yml").exists()
        || path.join("template.yaml").exists()
        || path.join("samconfig.toml").exists()
    {
        services.insert("AWS".to_string());
    }

    // Check for various cloud config files
    let search_files = ["package.json", "requirements.txt", "docker-compose.yml"];
    for file in search_files {
        if let Ok(content) = std::fs::read_to_string(path.join(file)) {
            let content_lower = content.to_lowercase();
            if content_lower.contains("@aws-sdk")
                || content_lower.contains("boto3")
                || content_lower.contains("aws-")
            {
                services.insert("AWS".to_string());
            }
            if content_lower.contains("@google-cloud")
                || content_lower.contains("google-cloud-")
                || content_lower.contains("firebase")
            {
                services.insert("Google Cloud".to_string());
            }
            if content_lower.contains("@azure") || content_lower.contains("azure-") {
                services.insert("Azure".to_string());
            }
            if content_lower.contains("vercel") {
                services.insert("Vercel".to_string());
            }
            if content_lower.contains("netlify") {
                services.insert("Netlify".to_string());
            }
        }
    }

    // Check for Vercel
    if path.join("vercel.json").exists() {
        services.insert("Vercel".to_string());
    }

    // Check for Netlify
    if path.join("netlify.toml").exists() {
        services.insert("Netlify".to_string());
    }

    services.into_iter().collect()
}

fn detect_containerization(path: &Path) -> Vec<String> {
    let mut containers = HashSet::new();

    if path.join("Dockerfile").exists() {
        containers.insert("Docker".to_string());
    }

    if path.join("docker-compose.yml").exists() || path.join("docker-compose.yaml").exists() {
        containers.insert("Docker Compose".to_string());
    }

    if path.join("kubernetes").exists()
        || path.join("k8s").exists()
        || path.join("helm").exists()
    {
        containers.insert("Kubernetes".to_string());
    }

    containers.into_iter().collect()
}

fn detect_patterns(path: &Path) -> Vec<String> {
    let mut patterns = HashSet::new();

    // Check directory structure for common patterns
    let dirs: Vec<String> = std::fs::read_dir(path)
        .ok()
        .map(|rd| {
            rd.filter_map(|e| e.ok())
                .filter(|e| e.file_type().map(|t| t.is_dir()).unwrap_or(false))
                .filter_map(|e| e.file_name().to_str().map(|s| s.to_lowercase()))
                .collect()
        })
        .unwrap_or_default();

    // MVC pattern
    if dirs.iter().any(|d| d == "models" || d == "model")
        && dirs.iter().any(|d| d == "views" || d == "view")
        && dirs.iter().any(|d| d == "controllers" || d == "controller")
    {
        patterns.insert("MVC".to_string());
    }

    // Domain-Driven Design
    if dirs.iter().any(|d| d == "domain" || d == "domains")
        && dirs.iter().any(|d| d == "infrastructure" || d == "infra")
    {
        patterns.insert("Domain-Driven Design".to_string());
    }

    // Clean Architecture
    if dirs.iter().any(|d| d == "entities" || d == "entity")
        && dirs.iter().any(|d| d == "usecases" || d == "use_cases" || d == "use-cases")
    {
        patterns.insert("Clean Architecture".to_string());
    }

    // Microservices
    if dirs.iter().any(|d| d == "services" || d == "microservices") {
        patterns.insert("Microservices".to_string());
    }

    // Monorepo
    if path.join("lerna.json").exists()
        || path.join("pnpm-workspace.yaml").exists()
        || path.join("turbo.json").exists()
        || dirs.iter().any(|d| d == "packages")
    {
        patterns.insert("Monorepo".to_string());
    }

    patterns.into_iter().collect()
}
