/// Analysis progress phases
enum AnalysisPhase {
  initializing,
  validatingUrl,
  authenticating,
  fetchingRepoInfo,
  cloningRepository,
  analyzingStructure,
  analyzingArchitecture,
  analyzingFeatures,
  analyzingQuality,
  fetchingIssues,
  analyzingIssues,
  fetchingPullRequests,
  analyzingPullRequests,
  analyzingDependencies,
  analyzingTechDebt,
  analyzingContributors,
  analyzingGitWorkflow,
  analyzingCiCd,
  analyzingDocumentation,
  analyzingReleases,
  analyzingSecurityPosture,
  aiAnalyzingPrs,
  aiAnalyzingIssues,
  aiGeneratingRoadmap,
  generatingReport,
  writingReport,
  completed,
  failed;

  String get displayName {
    switch (this) {
      case AnalysisPhase.initializing:
        return 'Initializing';
      case AnalysisPhase.validatingUrl:
        return 'Validating URL';
      case AnalysisPhase.authenticating:
        return 'Authenticating';
      case AnalysisPhase.fetchingRepoInfo:
        return 'Fetching repository info';
      case AnalysisPhase.cloningRepository:
        return 'Cloning repository';
      case AnalysisPhase.analyzingStructure:
        return 'Analyzing structure';
      case AnalysisPhase.analyzingArchitecture:
        return 'Analyzing architecture';
      case AnalysisPhase.analyzingFeatures:
        return 'Analyzing features';
      case AnalysisPhase.analyzingQuality:
        return 'Analyzing quality';
      case AnalysisPhase.fetchingIssues:
        return 'Fetching issues';
      case AnalysisPhase.analyzingIssues:
        return 'Analyzing issues';
      case AnalysisPhase.fetchingPullRequests:
        return 'Fetching pull requests';
      case AnalysisPhase.analyzingPullRequests:
        return 'Analyzing pull requests';
      case AnalysisPhase.analyzingDependencies:
        return 'Analyzing dependencies';
      case AnalysisPhase.analyzingTechDebt:
        return 'Detecting technical debt';
      case AnalysisPhase.analyzingContributors:
        return 'Analyzing contributors';
      case AnalysisPhase.analyzingGitWorkflow:
        return 'Analyzing git workflow';
      case AnalysisPhase.analyzingCiCd:
        return 'Analyzing CI/CD pipelines';
      case AnalysisPhase.analyzingDocumentation:
        return 'Analyzing documentation';
      case AnalysisPhase.analyzingReleases:
        return 'Analyzing releases';
      case AnalysisPhase.analyzingSecurityPosture:
        return 'Security posture scan';
      case AnalysisPhase.aiAnalyzingPrs:
        return 'AI analyzing pull requests';
      case AnalysisPhase.aiAnalyzingIssues:
        return 'AI analyzing issues';
      case AnalysisPhase.aiGeneratingRoadmap:
        return 'AI generating roadmap';
      case AnalysisPhase.generatingReport:
        return 'Generating report';
      case AnalysisPhase.writingReport:
        return 'Writing report';
      case AnalysisPhase.completed:
        return 'Completed';
      case AnalysisPhase.failed:
        return 'Failed';
    }
  }
}

/// Analysis progress update
class AnalysisProgress {
  final AnalysisPhase phase;
  final String message;
  final double percent;

  AnalysisProgress({
    required this.phase,
    required this.message,
    required this.percent,
  });

  factory AnalysisProgress.fromJson(Map<String, dynamic> json) {
    return AnalysisProgress(
      phase: AnalysisPhase.values.firstWhere(
        (e) => e.name == json['phase'],
        orElse: () => AnalysisPhase.initializing,
      ),
      message: json['message'] as String,
      percent: (json['percent'] as num).toDouble(),
    );
  }
}

/// Analysis configuration
class AnalysisConfig {
  final String repoUrl;
  final String? token;
  final String outputPath;
  final bool includeIssues;
  final bool includePrs;
  final int maxIssues;
  final int maxPrs;

  AnalysisConfig({
    required this.repoUrl,
    this.token,
    required this.outputPath,
    this.includeIssues = true,
    this.includePrs = true,
    this.maxIssues = 100,
    this.maxPrs = 50,
  });

  Map<String, dynamic> toJson() {
    return {
      'repo_url': repoUrl,
      'token': token,
      'output_path': outputPath,
      'include_issues': includeIssues,
      'include_prs': includePrs,
      'max_issues': maxIssues,
      'max_prs': maxPrs,
    };
  }
}

/// Quality analysis scores
class QualityAnalysis {
  final double overallScore;
  final double documentationScore;
  final double testCoverageScore;
  final double maintenanceScore;
  final double securityScore;
  final double codeQualityScore;
  final bool hasReadme;
  final bool hasContributing;
  final bool hasLicense;
  final bool hasChangelog;
  final bool hasCi;
  final bool hasTests;
  final bool hasSecurityPolicy;
  final bool hasCodeOfConduct;
  final List<QualityIssue> issues;

  QualityAnalysis({
    required this.overallScore,
    required this.documentationScore,
    required this.testCoverageScore,
    required this.maintenanceScore,
    required this.securityScore,
    required this.codeQualityScore,
    required this.hasReadme,
    required this.hasContributing,
    required this.hasLicense,
    required this.hasChangelog,
    required this.hasCi,
    required this.hasTests,
    required this.hasSecurityPolicy,
    required this.hasCodeOfConduct,
    required this.issues,
  });

  factory QualityAnalysis.fromJson(Map<String, dynamic> json) {
    return QualityAnalysis(
      overallScore: (json['overall_score'] as num).toDouble(),
      documentationScore: (json['documentation_score'] as num).toDouble(),
      testCoverageScore: (json['test_coverage_score'] as num).toDouble(),
      maintenanceScore: (json['maintenance_score'] as num).toDouble(),
      securityScore: (json['security_score'] as num).toDouble(),
      codeQualityScore: (json['code_quality_score'] as num).toDouble(),
      hasReadme: json['has_readme'] as bool,
      hasContributing: json['has_contributing'] as bool,
      hasLicense: json['has_license'] as bool,
      hasChangelog: json['has_changelog'] as bool,
      hasCi: json['has_ci'] as bool,
      hasTests: json['has_tests'] as bool,
      hasSecurityPolicy: json['has_security_policy'] as bool,
      hasCodeOfConduct: json['has_code_of_conduct'] as bool,
      issues: (json['issues'] as List)
          .map((e) => QualityIssue.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

/// Quality issue
class QualityIssue {
  final String severity;
  final String category;
  final String message;

  QualityIssue({
    required this.severity,
    required this.category,
    required this.message,
  });

  factory QualityIssue.fromJson(Map<String, dynamic> json) {
    return QualityIssue(
      severity: json['severity'] as String,
      category: json['category'] as String,
      message: json['message'] as String,
    );
  }
}

/// Language statistics
class LanguageStats {
  final String name;
  final int files;
  final int lines;
  final int code;
  final int comments;
  final int blanks;
  final double percentage;

  LanguageStats({
    required this.name,
    required this.files,
    required this.lines,
    required this.code,
    required this.comments,
    required this.blanks,
    required this.percentage,
  });

  factory LanguageStats.fromJson(Map<String, dynamic> json) {
    return LanguageStats(
      name: json['name'] as String,
      files: json['files'] as int,
      lines: json['lines'] as int,
      code: json['code'] as int,
      comments: json['comments'] as int,
      blanks: json['blanks'] as int,
      percentage: (json['percentage'] as num).toDouble(),
    );
  }
}

/// Branch information
class BranchInfo {
  final String name;
  final bool isDefault;
  final bool isProtected;
  final String? lastCommitDate;
  final String? lastCommitAuthor;

  BranchInfo({
    required this.name,
    required this.isDefault,
    required this.isProtected,
    this.lastCommitDate,
    this.lastCommitAuthor,
  });

  factory BranchInfo.fromJson(Map<String, dynamic> json) {
    return BranchInfo(
      name: json['name'] as String,
      isDefault: json['is_default'] as bool? ?? false,
      isProtected: json['protected'] as bool? ?? false,
      lastCommitDate: json['last_commit_date'] as String?,
      lastCommitAuthor: json['last_commit_author'] as String?,
    );
  }
}

/// Branch analysis for Executive Summary
class BranchAnalysis {
  final int totalBranches;
  final int activeBranches; // updated within 30 days
  final int staleBranches; // not updated in 90+ days
  final List<BranchInfo> branches;
  final Map<String, int> branchTypes; // feature, bugfix, release, etc.
  final double avgBranchAge; // in days
  final int protectedBranches;

  BranchAnalysis({
    required this.totalBranches,
    required this.activeBranches,
    required this.staleBranches,
    required this.branches,
    required this.branchTypes,
    required this.avgBranchAge,
    required this.protectedBranches,
  });

  factory BranchAnalysis.empty() {
    return BranchAnalysis(
      totalBranches: 0,
      activeBranches: 0,
      staleBranches: 0,
      branches: [],
      branchTypes: {},
      avgBranchAge: 0,
      protectedBranches: 0,
    );
  }
}

/// Executive Summary - High-level insights based on branch-oriented analysis
class ExecutiveSummary {
  final String healthStatus; // Excellent, Good, Fair, Needs Attention
  final int healthScore; // 0-100
  final BranchAnalysis branchAnalysis;
  final int concurrentDevelopmentIndex; // number of active branches
  final double developmentVelocity; // commits per week
  final String projectMaturity; // Active, Mature, Declining, New
  final List<String> keyInsights;
  final List<String> recommendations;
  final Map<String, dynamic> metrics;

  ExecutiveSummary({
    required this.healthStatus,
    required this.healthScore,
    required this.branchAnalysis,
    required this.concurrentDevelopmentIndex,
    required this.developmentVelocity,
    required this.projectMaturity,
    required this.keyInsights,
    required this.recommendations,
    required this.metrics,
  });

  factory ExecutiveSummary.empty() {
    return ExecutiveSummary(
      healthStatus: 'Unknown',
      healthScore: 0,
      branchAnalysis: BranchAnalysis.empty(),
      concurrentDevelopmentIndex: 0,
      developmentVelocity: 0,
      projectMaturity: 'Unknown',
      keyInsights: [],
      recommendations: [],
      metrics: {},
    );
  }
}

// ============================================================================
// ITERATION 1: Dependency Analysis
// ============================================================================

/// Single dependency information
class Dependency {
  final String name;
  final String? currentVersion;
  final String? latestVersion;
  final bool isOutdated;
  final bool hasVulnerability;
  final String? vulnerabilitySeverity;
  final String? vulnerabilityDescription;

  Dependency({
    required this.name,
    this.currentVersion,
    this.latestVersion,
    this.isOutdated = false,
    this.hasVulnerability = false,
    this.vulnerabilitySeverity,
    this.vulnerabilityDescription,
  });
}

/// Dependency analysis results
class DependencyAnalysis {
  final int totalDependencies;
  final int outdatedCount;
  final int vulnerableCount;
  final double healthScore;
  final List<Dependency> dependencies;
  final Map<String, int> dependencyTypes; // dev, prod, peer, etc.
  final String? packageManager; // npm, pip, cargo, etc.

  DependencyAnalysis({
    required this.totalDependencies,
    required this.outdatedCount,
    required this.vulnerableCount,
    required this.healthScore,
    required this.dependencies,
    required this.dependencyTypes,
    this.packageManager,
  });

  factory DependencyAnalysis.empty() {
    return DependencyAnalysis(
      totalDependencies: 0,
      outdatedCount: 0,
      vulnerableCount: 0,
      healthScore: 100,
      dependencies: [],
      dependencyTypes: {},
    );
  }
}

// ============================================================================
// ITERATION 2: Technical Debt Detection
// ============================================================================

/// A technical debt item found in code
class TechDebtItem {
  final String type; // TODO, FIXME, HACK, LARGE_FILE, COMPLEX_FILE
  final String filePath;
  final int? lineNumber;
  final String description;
  final String severity; // low, medium, high

  TechDebtItem({
    required this.type,
    required this.filePath,
    this.lineNumber,
    required this.description,
    required this.severity,
  });
}

/// Technical debt analysis results
class TechDebtAnalysis {
  final int totalItems;
  final int todoCount;
  final int fixmeCount;
  final int hackCount;
  final int largeFilesCount;
  final int complexFilesCount;
  final double debtScore; // 0-100, lower is better (less debt)
  final List<TechDebtItem> items;
  final List<String> largeFiles; // files > 500 lines
  final Map<String, int> debtByCategory;

  TechDebtAnalysis({
    required this.totalItems,
    required this.todoCount,
    required this.fixmeCount,
    required this.hackCount,
    required this.largeFilesCount,
    required this.complexFilesCount,
    required this.debtScore,
    required this.items,
    required this.largeFiles,
    required this.debtByCategory,
  });

  factory TechDebtAnalysis.empty() {
    return TechDebtAnalysis(
      totalItems: 0,
      todoCount: 0,
      fixmeCount: 0,
      hackCount: 0,
      largeFilesCount: 0,
      complexFilesCount: 0,
      debtScore: 0,
      items: [],
      largeFiles: [],
      debtByCategory: {},
    );
  }
}

// ============================================================================
// ITERATION 3: Contributor Insights
// ============================================================================

/// Detailed contributor information
class ContributorDetail {
  final String login;
  final String? name;
  final int totalCommits;
  final int recentCommits; // last 30 days
  final List<String> primaryFiles; // files they work on most
  final double ownershipPercentage;
  final bool isActive; // committed in last 30 days

  ContributorDetail({
    required this.login,
    this.name,
    required this.totalCommits,
    required this.recentCommits,
    required this.primaryFiles,
    required this.ownershipPercentage,
    required this.isActive,
  });
}

/// Code ownership map entry
class CodeOwnership {
  final String path;
  final String primaryOwner;
  final List<String> contributors;
  final int totalCommits;

  CodeOwnership({
    required this.path,
    required this.primaryOwner,
    required this.contributors,
    required this.totalCommits,
  });
}

/// Contributor insights and code ownership analysis
class ContributorInsights {
  final int totalContributors;
  final int activeContributors; // last 30 days
  final int busFactor; // minimum contributors who own 50% of code
  final String busFactorRisk; // low, medium, high, critical
  final List<ContributorDetail> topContributors;
  final List<CodeOwnership> codeOwnership;
  final List<String> keyEntryPoints; // important files for new contributors
  final List<String> onboardingRecommendations;

  ContributorInsights({
    required this.totalContributors,
    required this.activeContributors,
    required this.busFactor,
    required this.busFactorRisk,
    required this.topContributors,
    required this.codeOwnership,
    required this.keyEntryPoints,
    required this.onboardingRecommendations,
  });

  factory ContributorInsights.empty() {
    return ContributorInsights(
      totalContributors: 0,
      activeContributors: 0,
      busFactor: 0,
      busFactorRisk: 'unknown',
      topContributors: [],
      codeOwnership: [],
      keyEntryPoints: [],
      onboardingRecommendations: [],
    );
  }
}

// ============================================================================
// ITERATION 5: Actionable Roadmap
// ============================================================================

/// A single roadmap action item
class RoadmapItem {
  final String title;
  final String description;
  final String priority; // critical, high, medium, low
  final String category; // security, performance, maintenance, feature
  final String? estimatedImpact;
  final List<String> affectedFiles;

  RoadmapItem({
    required this.title,
    required this.description,
    required this.priority,
    required this.category,
    this.estimatedImpact,
    this.affectedFiles = const [],
  });
}

/// AI-generated actionable improvement roadmap
class ActionableRoadmap {
  final List<RoadmapItem> criticalItems;
  final List<RoadmapItem> highPriorityItems;
  final List<RoadmapItem> mediumPriorityItems;
  final List<RoadmapItem> lowPriorityItems;
  final String? predictedQualityImprovement;
  final String? predictedSecurityImprovement;
  final String? overallAssessment;

  ActionableRoadmap({
    required this.criticalItems,
    required this.highPriorityItems,
    required this.mediumPriorityItems,
    required this.lowPriorityItems,
    this.predictedQualityImprovement,
    this.predictedSecurityImprovement,
    this.overallAssessment,
  });

  factory ActionableRoadmap.empty() {
    return ActionableRoadmap(
      criticalItems: [],
      highPriorityItems: [],
      mediumPriorityItems: [],
      lowPriorityItems: [],
    );
  }

  int get totalItems =>
      criticalItems.length +
      highPriorityItems.length +
      mediumPriorityItems.length +
      lowPriorityItems.length;
}

// ============================================================================
// ITERATION 6: Git Workflow & Commit Quality Analysis
// ============================================================================

/// Commit quality metrics
class CommitQuality {
  final String sha;
  final String message;
  final int messageLength;
  final bool hasPrefix; // feat:, fix:, docs:, etc.
  final String? prefix;
  final bool isConventional; // follows conventional commits
  final int filesChanged;
  final int additions;
  final int deletions;

  CommitQuality({
    required this.sha,
    required this.message,
    required this.messageLength,
    required this.hasPrefix,
    this.prefix,
    required this.isConventional,
    required this.filesChanged,
    required this.additions,
    required this.deletions,
  });
}

/// Git workflow analysis results
class GitWorkflowAnalysis {
  final int totalCommits;
  final int recentCommits; // last 30 days
  final double avgCommitsPerWeek;
  final double conventionalCommitRatio; // 0-1
  final String primaryMergeStrategy; // merge, squash, rebase
  final double avgPrTurnaround; // hours from open to merge
  final int avgPrSize; // avg lines changed
  final Map<String, int> commitPrefixes; // feat, fix, docs counts
  final List<CommitQuality> sampleCommits;
  final double commitQualityScore; // 0-100
  final String branchingStrategy; // gitflow, trunk-based, feature-branch
  final List<String> workflowRecommendations;

  GitWorkflowAnalysis({
    required this.totalCommits,
    required this.recentCommits,
    required this.avgCommitsPerWeek,
    required this.conventionalCommitRatio,
    required this.primaryMergeStrategy,
    required this.avgPrTurnaround,
    required this.avgPrSize,
    required this.commitPrefixes,
    required this.sampleCommits,
    required this.commitQualityScore,
    required this.branchingStrategy,
    required this.workflowRecommendations,
  });

  factory GitWorkflowAnalysis.empty() {
    return GitWorkflowAnalysis(
      totalCommits: 0,
      recentCommits: 0,
      avgCommitsPerWeek: 0,
      conventionalCommitRatio: 0,
      primaryMergeStrategy: 'unknown',
      avgPrTurnaround: 0,
      avgPrSize: 0,
      commitPrefixes: {},
      sampleCommits: [],
      commitQualityScore: 0,
      branchingStrategy: 'unknown',
      workflowRecommendations: [],
    );
  }
}

// ============================================================================
// ITERATION 7: CI/CD Pipeline Analysis
// ============================================================================

/// GitHub Actions workflow info
class WorkflowInfo {
  final String name;
  final String path;
  final String trigger; // push, pull_request, schedule, etc.
  final bool isActive;
  final int runsLast30Days;
  final double successRate;
  final int avgDurationSeconds;

  WorkflowInfo({
    required this.name,
    required this.path,
    required this.trigger,
    required this.isActive,
    required this.runsLast30Days,
    required this.successRate,
    required this.avgDurationSeconds,
  });
}

/// CI/CD pipeline analysis results
class CiCdAnalysis {
  final bool hasGitHubActions;
  final bool hasTravisCI;
  final bool hasCircleCI;
  final bool hasJenkinsfile;
  final int totalWorkflows;
  final List<WorkflowInfo> workflows;
  final double overallSuccessRate;
  final int avgBuildTime; // seconds
  final bool hasTestStage;
  final bool hasLintStage;
  final bool hasBuildStage;
  final bool hasDeployStage;
  final bool hasSecurityScan;
  final double pipelineScore; // 0-100
  final List<String> missingStages;
  final List<String> recommendations;

  CiCdAnalysis({
    required this.hasGitHubActions,
    required this.hasTravisCI,
    required this.hasCircleCI,
    required this.hasJenkinsfile,
    required this.totalWorkflows,
    required this.workflows,
    required this.overallSuccessRate,
    required this.avgBuildTime,
    required this.hasTestStage,
    required this.hasLintStage,
    required this.hasBuildStage,
    required this.hasDeployStage,
    required this.hasSecurityScan,
    required this.pipelineScore,
    required this.missingStages,
    required this.recommendations,
  });

  factory CiCdAnalysis.empty() {
    return CiCdAnalysis(
      hasGitHubActions: false,
      hasTravisCI: false,
      hasCircleCI: false,
      hasJenkinsfile: false,
      totalWorkflows: 0,
      workflows: [],
      overallSuccessRate: 0,
      avgBuildTime: 0,
      hasTestStage: false,
      hasLintStage: false,
      hasBuildStage: false,
      hasDeployStage: false,
      hasSecurityScan: false,
      pipelineScore: 0,
      missingStages: [],
      recommendations: [],
    );
  }
}

// ============================================================================
// ITERATION 8: Documentation Completeness Analysis
// ============================================================================

/// Documentation analysis results
class DocumentationAnalysis {
  final bool hasReadme;
  final int readmeLength;
  final bool readmeHasInstallation;
  final bool readmeHasUsage;
  final bool readmeHasApi;
  final bool readmeHasContributing;
  final bool readmeHasLicense;
  final bool readmeHasBadges;
  final bool hasContributingFile;
  final bool hasCodeOfConduct;
  final bool hasChangelog;
  final bool hasApiDocs;
  final bool hasWiki;
  final double commentRatio; // comments/code ratio
  final int inlineDocsCount;
  final double documentationScore; // 0-100
  final List<String> missingSections;
  final List<String> recommendations;

  DocumentationAnalysis({
    required this.hasReadme,
    required this.readmeLength,
    required this.readmeHasInstallation,
    required this.readmeHasUsage,
    required this.readmeHasApi,
    required this.readmeHasContributing,
    required this.readmeHasLicense,
    required this.readmeHasBadges,
    required this.hasContributingFile,
    required this.hasCodeOfConduct,
    required this.hasChangelog,
    required this.hasApiDocs,
    required this.hasWiki,
    required this.commentRatio,
    required this.inlineDocsCount,
    required this.documentationScore,
    required this.missingSections,
    required this.recommendations,
  });

  factory DocumentationAnalysis.empty() {
    return DocumentationAnalysis(
      hasReadme: false,
      readmeLength: 0,
      readmeHasInstallation: false,
      readmeHasUsage: false,
      readmeHasApi: false,
      readmeHasContributing: false,
      readmeHasLicense: false,
      readmeHasBadges: false,
      hasContributingFile: false,
      hasCodeOfConduct: false,
      hasChangelog: false,
      hasApiDocs: false,
      hasWiki: false,
      commentRatio: 0,
      inlineDocsCount: 0,
      documentationScore: 0,
      missingSections: [],
      recommendations: [],
    );
  }
}

// ============================================================================
// ITERATION 9: Release Management Analysis
// ============================================================================

/// Release information
class ReleaseInfo {
  final String tagName;
  final String name;
  final DateTime publishedAt;
  final bool isPrerelease;
  final bool isDraft;
  final int downloadCount;
  final bool hasReleaseNotes;
  final int releaseNotesLength;

  ReleaseInfo({
    required this.tagName,
    required this.name,
    required this.publishedAt,
    required this.isPrerelease,
    required this.isDraft,
    required this.downloadCount,
    required this.hasReleaseNotes,
    required this.releaseNotesLength,
  });
}

/// Release management analysis results
class ReleaseAnalysis {
  final int totalReleases;
  final int releasesLastYear;
  final double avgReleaseFrequency; // releases per month
  final bool usesSemver;
  final double semverCompliance; // 0-1
  final bool hasLatestRelease;
  final DateTime? lastReleaseDate;
  final int daysSinceLastRelease;
  final bool hasReleaseNotes;
  final double releaseNotesQuality; // 0-100
  final List<ReleaseInfo> recentReleases;
  final String releaseStrategy; // rolling, periodic, milestone-based
  final double releaseScore; // 0-100
  final List<String> recommendations;

  ReleaseAnalysis({
    required this.totalReleases,
    required this.releasesLastYear,
    required this.avgReleaseFrequency,
    required this.usesSemver,
    required this.semverCompliance,
    required this.hasLatestRelease,
    this.lastReleaseDate,
    required this.daysSinceLastRelease,
    required this.hasReleaseNotes,
    required this.releaseNotesQuality,
    required this.recentReleases,
    required this.releaseStrategy,
    required this.releaseScore,
    required this.recommendations,
  });

  factory ReleaseAnalysis.empty() {
    return ReleaseAnalysis(
      totalReleases: 0,
      releasesLastYear: 0,
      avgReleaseFrequency: 0,
      usesSemver: false,
      semverCompliance: 0,
      hasLatestRelease: false,
      daysSinceLastRelease: 0,
      hasReleaseNotes: false,
      releaseNotesQuality: 0,
      recentReleases: [],
      releaseStrategy: 'unknown',
      releaseScore: 0,
      recommendations: [],
    );
  }
}

// ============================================================================
// ITERATION 10: Security Posture Deep Scan
// ============================================================================

/// Security finding
class SecurityFinding {
  final String type; // secret, vulnerability, misconfiguration
  final String severity; // critical, high, medium, low, info
  final String title;
  final String description;
  final String? filePath;
  final int? lineNumber;
  final String? remediation;

  SecurityFinding({
    required this.type,
    required this.severity,
    required this.title,
    required this.description,
    this.filePath,
    this.lineNumber,
    this.remediation,
  });
}

/// Security posture analysis results
class SecurityPostureAnalysis {
  final bool hasSecurityPolicy;
  final bool hasSecurityAdvisories;
  final bool hasDependabot;
  final bool hasCodeScanning;
  final bool hasSecretScanning;
  final bool hasBranchProtection;
  final bool requiresReviews;
  final bool requiresSignedCommits;
  final int secretsDetected;
  final int vulnerabilitiesFound;
  final int misconfigurationsFound;
  final List<SecurityFinding> findings;
  final double securityScore; // 0-100
  final String riskLevel; // critical, high, medium, low
  final List<String> enabledSecurityFeatures;
  final List<String> missingSecurityFeatures;
  final List<String> recommendations;

  SecurityPostureAnalysis({
    required this.hasSecurityPolicy,
    required this.hasSecurityAdvisories,
    required this.hasDependabot,
    required this.hasCodeScanning,
    required this.hasSecretScanning,
    required this.hasBranchProtection,
    required this.requiresReviews,
    required this.requiresSignedCommits,
    required this.secretsDetected,
    required this.vulnerabilitiesFound,
    required this.misconfigurationsFound,
    required this.findings,
    required this.securityScore,
    required this.riskLevel,
    required this.enabledSecurityFeatures,
    required this.missingSecurityFeatures,
    required this.recommendations,
  });

  factory SecurityPostureAnalysis.empty() {
    return SecurityPostureAnalysis(
      hasSecurityPolicy: false,
      hasSecurityAdvisories: false,
      hasDependabot: false,
      hasCodeScanning: false,
      hasSecretScanning: false,
      hasBranchProtection: false,
      requiresReviews: false,
      requiresSignedCommits: false,
      secretsDetected: 0,
      vulnerabilitiesFound: 0,
      misconfigurationsFound: 0,
      findings: [],
      securityScore: 0,
      riskLevel: 'unknown',
      enabledSecurityFeatures: [],
      missingSecurityFeatures: [],
      recommendations: [],
    );
  }
}

// ============================================================================
// AI Insights (existing, enhanced)
// ============================================================================

/// AI-powered insights from PR and Issue analysis
class AIInsights {
  final String? mergedPrSummary; // What improvements came from merged PRs (last 3 months)
  final String? upcomingPrSummary; // What improvements are coming in latest 50 PRs
  final String? issuesSummary; // What users are complaining about (last 3 months)
  final List<String> improvementCategories;
  final List<String> commonComplaints;
  final String? overallTrend;

  AIInsights({
    this.mergedPrSummary,
    this.upcomingPrSummary,
    this.issuesSummary,
    this.improvementCategories = const [],
    this.commonComplaints = const [],
    this.overallTrend,
  });

  factory AIInsights.empty() {
    return AIInsights(
      mergedPrSummary: null,
      upcomingPrSummary: null,
      issuesSummary: null,
      improvementCategories: [],
      commonComplaints: [],
      overallTrend: null,
    );
  }
}

/// Complete analysis result
class AnalysisResult {
  final String repoName;
  final String repoFullName;
  final String? description;
  final String htmlUrl;
  final int stars;
  final int forks;
  final int openIssues;
  final String? primaryLanguage;
  final List<LanguageStats> languages;
  final List<String> frameworks;
  final List<String> buildTools;
  final QualityAnalysis quality;
  final ExecutiveSummary? executiveSummary;
  final AIInsights? aiInsights;
  // New analysis types (Iterations 1-5)
  final DependencyAnalysis? dependencyAnalysis;
  final TechDebtAnalysis? techDebtAnalysis;
  final ContributorInsights? contributorInsights;
  final ActionableRoadmap? actionableRoadmap;
  // New analysis types (Iterations 6-10)
  final GitWorkflowAnalysis? gitWorkflowAnalysis;
  final CiCdAnalysis? ciCdAnalysis;
  final DocumentationAnalysis? documentationAnalysis;
  final ReleaseAnalysis? releaseAnalysis;
  final SecurityPostureAnalysis? securityPostureAnalysis;
  final DateTime analyzedAt;
  final String? reportPath;
  final String? reportContent;

  AnalysisResult({
    required this.repoName,
    required this.repoFullName,
    this.description,
    required this.htmlUrl,
    required this.stars,
    required this.forks,
    required this.openIssues,
    this.primaryLanguage,
    required this.languages,
    required this.frameworks,
    required this.buildTools,
    required this.quality,
    this.executiveSummary,
    this.aiInsights,
    this.dependencyAnalysis,
    this.techDebtAnalysis,
    this.contributorInsights,
    this.actionableRoadmap,
    this.gitWorkflowAnalysis,
    this.ciCdAnalysis,
    this.documentationAnalysis,
    this.releaseAnalysis,
    this.securityPostureAnalysis,
    required this.analyzedAt,
    this.reportPath,
    this.reportContent,
  });

  factory AnalysisResult.fromJson(Map<String, dynamic> json) {
    return AnalysisResult(
      repoName: json['repo_info']['name'] as String,
      repoFullName: json['repo_info']['full_name'] as String,
      description: json['repo_info']['description'] as String?,
      htmlUrl: json['repo_info']['html_url'] as String,
      stars: json['repo_info']['stars'] as int,
      forks: json['repo_info']['forks'] as int,
      openIssues: json['repo_info']['open_issues'] as int,
      primaryLanguage: json['architecture']['primary_language'] as String?,
      languages: (json['structure']['languages'] as List)
          .map((e) => LanguageStats.fromJson(e as Map<String, dynamic>))
          .toList(),
      frameworks: List<String>.from(json['architecture']['frameworks'] as List),
      buildTools: List<String>.from(json['architecture']['build_tools'] as List),
      quality: QualityAnalysis.fromJson(json['quality'] as Map<String, dynamic>),
      analyzedAt: DateTime.parse(json['analyzed_at'] as String),
      reportPath: json['report_path'] as String?,
      reportContent: json['report_content'] as String?,
    );
  }
}
