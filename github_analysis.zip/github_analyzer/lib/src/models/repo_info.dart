/// Repository information model
class RepoInfo {
  final String name;
  final String fullName;
  final String? description;
  final String htmlUrl;
  final String cloneUrl;
  final String defaultBranch;
  final String? language;
  final int stars;
  final int forks;
  final int watchers;
  final int openIssues;
  final int sizeKb;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? pushedAt;
  final bool isFork;
  final bool isArchived;
  final String? license;
  final List<String> topics;

  RepoInfo({
    required this.name,
    required this.fullName,
    this.description,
    required this.htmlUrl,
    required this.cloneUrl,
    required this.defaultBranch,
    this.language,
    required this.stars,
    required this.forks,
    required this.watchers,
    required this.openIssues,
    required this.sizeKb,
    required this.createdAt,
    required this.updatedAt,
    this.pushedAt,
    required this.isFork,
    required this.isArchived,
    this.license,
    required this.topics,
  });

  factory RepoInfo.fromJson(Map<String, dynamic> json) {
    return RepoInfo(
      name: json['name'] as String,
      fullName: json['full_name'] as String,
      description: json['description'] as String?,
      htmlUrl: json['html_url'] as String,
      cloneUrl: json['clone_url'] as String,
      defaultBranch: json['default_branch'] as String,
      language: json['language'] as String?,
      stars: json['stars'] as int,
      forks: json['forks'] as int,
      watchers: json['watchers'] as int,
      openIssues: json['open_issues'] as int,
      sizeKb: json['size_kb'] as int,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      pushedAt: json['pushed_at'] != null
          ? DateTime.parse(json['pushed_at'] as String)
          : null,
      isFork: json['is_fork'] as bool,
      isArchived: json['is_archived'] as bool,
      license: json['license'] as String?,
      topics: List<String>.from(json['topics'] as List),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'full_name': fullName,
      'description': description,
      'html_url': htmlUrl,
      'clone_url': cloneUrl,
      'default_branch': defaultBranch,
      'language': language,
      'stars': stars,
      'forks': forks,
      'watchers': watchers,
      'open_issues': openIssues,
      'size_kb': sizeKb,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'pushed_at': pushedAt?.toIso8601String(),
      'is_fork': isFork,
      'is_archived': isArchived,
      'license': license,
      'topics': topics,
    };
  }
}
