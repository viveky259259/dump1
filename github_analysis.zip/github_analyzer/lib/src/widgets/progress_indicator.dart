import 'package:flutter/material.dart';
import '../models/analysis_result.dart';

class AnalysisProgressIndicator extends StatelessWidget {
  final AnalysisPhase phase;
  final String message;
  final double progress;
  final VoidCallback? onCancel;

  const AnalysisProgressIndicator({
    super.key,
    required this.phase,
    required this.message,
    required this.progress,
    this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _PhaseIcon(phase: phase),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        phase.displayName,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        message,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                if (onCancel != null && phase != AnalysisPhase.completed)
                  TextButton(
                    onPressed: onCancel,
                    child: const Text('Cancel'),
                  ),
              ],
            ),
            const SizedBox(height: 24),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                backgroundColor: colorScheme.surfaceContainerHighest,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '${(progress * 100).toInt()}% complete',
              style: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 24),
            _PhaseTimeline(currentPhase: phase),
          ],
        ),
      ),
    );
  }
}

class _PhaseIcon extends StatelessWidget {
  final AnalysisPhase phase;

  const _PhaseIcon({required this.phase});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    IconData icon;
    Color color;

    switch (phase) {
      case AnalysisPhase.completed:
        icon = Icons.check_circle;
        color = Colors.green;
      case AnalysisPhase.failed:
        icon = Icons.error;
        color = colorScheme.error;
      default:
        icon = Icons.sync;
        color = colorScheme.primary;
    }

    if (phase != AnalysisPhase.completed && phase != AnalysisPhase.failed) {
      return SizedBox(
        width: 48,
        height: 48,
        child: CircularProgressIndicator(
          strokeWidth: 3,
          color: color,
        ),
      );
    }

    return Icon(icon, size: 48, color: color);
  }
}

class _PhaseTimeline extends StatelessWidget {
  final AnalysisPhase currentPhase;

  const _PhaseTimeline({required this.currentPhase});

  static const _phases = [
    (AnalysisPhase.validatingUrl, 'Validate'),
    (AnalysisPhase.fetchingRepoInfo, 'Fetch Info'),
    (AnalysisPhase.cloningRepository, 'Clone'),
    (AnalysisPhase.analyzingStructure, 'Structure'),
    (AnalysisPhase.analyzingArchitecture, 'Tech Stack'),
    (AnalysisPhase.analyzingQuality, 'Quality'),
    (AnalysisPhase.generatingReport, 'Report'),
    (AnalysisPhase.completed, 'Done'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final currentIndex = _phases.indexWhere((p) =>
        p.$1.index >= currentPhase.index && currentPhase != AnalysisPhase.failed);

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(_phases.length * 2 - 1, (index) {
          if (index.isOdd) {
            // Connector line
            final phaseIndex = index ~/ 2;
            final isCompleted = phaseIndex < currentIndex ||
                currentPhase == AnalysisPhase.completed;
            return Container(
              width: 24,
              height: 2,
              color: isCompleted
                  ? colorScheme.primary
                  : colorScheme.surfaceContainerHighest,
            );
          }

          // Phase dot
          final phaseIndex = index ~/ 2;
          final phase = _phases[phaseIndex];
          final isCompleted = phaseIndex < currentIndex ||
              currentPhase == AnalysisPhase.completed;
          final isCurrent = phaseIndex == currentIndex &&
              currentPhase != AnalysisPhase.completed &&
              currentPhase != AnalysisPhase.failed;

          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isCompleted
                      ? colorScheme.primary
                      : isCurrent
                          ? colorScheme.primary.withValues(alpha: 0.5)
                          : colorScheme.surfaceContainerHighest,
                  border: isCurrent
                      ? Border.all(color: colorScheme.primary, width: 2)
                      : null,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                phase.$2,
                style: theme.textTheme.labelSmall?.copyWith(
                  color: isCompleted || isCurrent
                      ? colorScheme.onSurface
                      : colorScheme.onSurfaceVariant,
                  fontWeight: isCurrent ? FontWeight.bold : null,
                ),
              ),
            ],
          );
        }),
      ),
    );
  }
}
