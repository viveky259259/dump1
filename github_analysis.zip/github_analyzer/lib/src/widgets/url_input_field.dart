import 'package:flutter/material.dart';

class UrlInputField extends StatelessWidget {
  final TextEditingController controller;
  final String? errorText;
  final bool enabled;
  final VoidCallback? onSubmitted;

  const UrlInputField({
    super.key,
    required this.controller,
    this.errorText,
    this.enabled = true,
    this.onSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      enabled: enabled,
      decoration: InputDecoration(
        labelText: 'GitHub Repository URL',
        hintText: 'https://github.com/owner/repo or owner/repo',
        prefixIcon: const Icon(Icons.link),
        errorText: errorText,
        helperText: 'Enter a GitHub repository URL to analyze',
        suffixIcon: controller.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear),
                onPressed: enabled ? () => controller.clear() : null,
              )
            : null,
      ),
      keyboardType: TextInputType.url,
      textInputAction: TextInputAction.go,
      onSubmitted: enabled && onSubmitted != null ? (_) => onSubmitted!() : null,
    );
  }
}
