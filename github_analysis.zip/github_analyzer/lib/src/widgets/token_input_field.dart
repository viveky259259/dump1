import 'package:flutter/material.dart';

class TokenInputField extends StatefulWidget {
  final TextEditingController controller;
  final bool enabled;

  const TokenInputField({
    super.key,
    required this.controller,
    this.enabled = true,
  });

  @override
  State<TokenInputField> createState() => _TokenInputFieldState();
}

class _TokenInputFieldState extends State<TokenInputField> {
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      enabled: widget.enabled,
      obscureText: _obscureText,
      decoration: InputDecoration(
        labelText: 'GitHub Token (Optional)',
        hintText: 'ghp_xxxx or github_pat_xxxx',
        prefixIcon: const Icon(Icons.key),
        helperText: 'Required for private repos or higher rate limits',
        suffixIcon: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(
                _obscureText ? Icons.visibility : Icons.visibility_off,
              ),
              onPressed: widget.enabled
                  ? () => setState(() => _obscureText = !_obscureText)
                  : null,
              tooltip: _obscureText ? 'Show token' : 'Hide token',
            ),
            if (widget.controller.text.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.clear),
                onPressed: widget.enabled
                    ? () {
                        widget.controller.clear();
                        setState(() {});
                      }
                    : null,
                tooltip: 'Clear token',
              ),
          ],
        ),
      ),
      keyboardType: TextInputType.visiblePassword,
    );
  }
}
