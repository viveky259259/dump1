import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/analysis_result.dart';

/// AI Provider enum
enum AIProvider { claude, openai }

/// Service to manage repository analysis with real GitHub API calls
class AnalyzerService extends ChangeNotifier {
  AnalysisPhase _currentPhase = AnalysisPhase.initializing;
  String _currentMessage = '';
  double _progress = 0.0;
  bool _isAnalyzing = false;
  String? _error;
  AnalysisResult? _result;
  List<String> _recentUrls = [];

  // Getters
  AnalysisPhase get currentPhase => _currentPhase;
  String get currentMessage => _currentMessage;
  double get progress => _progress;
  bool get isAnalyzing => _isAnalyzing;
  String? get error => _error;
  AnalysisResult? get result => _result;
  List<String> get recentUrls => _recentUrls;

  AnalyzerService() {
    _loadRecentUrls();
  }

  Future<void> _loadRecentUrls() async {
    final prefs = await SharedPreferences.getInstance();
    _recentUrls = prefs.getStringList('recent_urls') ?? [];
    notifyListeners();
  }

  Future<void> _saveRecentUrls() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('recent_urls', _recentUrls);
  }

  void _addRecentUrl(String url) {
    _recentUrls.remove(url);
    _recentUrls.insert(0, url);
    if (_recentUrls.length > 10) {
      _recentUrls = _recentUrls.sublist(0, 10);
    }
    _saveRecentUrls();
  }

  Future<void> clearRecentUrls() async {
    _recentUrls.clear();
    await _saveRecentUrls();
    notifyListeners();
  }

  bool validateUrl(String url) {
    final patterns = [
      RegExp(r'^https?://github\.com/[^/]+/[^/]+/?$'),
      RegExp(r'^[^/]+/[^/]+$'),
    ];
    return patterns.any((p) => p.hasMatch(url.trim()));
  }

  (String owner, String repo)? parseUrl(String url) {
    url = url.trim();
    var match = RegExp(r'github\.com/([^/]+)/([^/]+)').firstMatch(url);
    if (match != null) {
      return (match.group(1)!, match.group(2)!.replaceAll('.git', ''));
    }
    match = RegExp(r'^([^/]+)/([^/]+)$').firstMatch(url);
    if (match != null) {
      return (match.group(1)!, match.group(2)!);
    }
    return null;
  }

  void _updateProgress(AnalysisPhase phase, String message, double percent) {
    _currentPhase = phase;
    _currentMessage = message;
    _progress = percent / 100.0;
    notifyListeners();
  }

  Map<String, String> _getHeaders(String? token) {
    final headers = {
      'Accept': 'application/vnd.github.v3+json',
      'User-Agent': 'GitHub-Analyzer-App',
    };
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  Future<Map<String, dynamic>> _fetchJson(String url, String? token) async {
    final response = await http.get(Uri.parse(url), headers: _getHeaders(token));
    if (response.statusCode == 200) {
      return json.decode(response.body) as Map<String, dynamic>;
    } else if (response.statusCode == 404) {
      throw Exception('Repository not found');
    } else if (response.statusCode == 403) {
      throw Exception('API rate limit exceeded. Please add a GitHub token.');
    } else {
      throw Exception('GitHub API error: ${response.statusCode}');
    }
  }

  Future<List<dynamic>> _fetchJsonList(String url, String? token) async {
    final response = await http.get(Uri.parse(url), headers: _getHeaders(token));
    if (response.statusCode == 200) {
      return json.decode(response.body) as List<dynamic>;
    }
    return [];
  }

  Future<void> analyze({
    required String repoUrl,
    String? token,
    required String outputPath,
    bool includeIssues = true,
    bool includePrs = true,
    bool enableAiAnalysis = false,
    String? aiApiKey,
    AIProvider aiProvider = AIProvider.claude,
  }) async {
    _isAnalyzing = true;
    _error = null;
    _result = null;
    notifyListeners();

    try {
      // Validate URL
      _updateProgress(AnalysisPhase.validatingUrl, 'Validating URL...', 0);

      final parsed = parseUrl(repoUrl);
      if (parsed == null) {
        throw Exception('Invalid GitHub URL');
      }
      final (owner, repo) = parsed;
      _addRecentUrl(repoUrl);

      // Fetch repository info
      _updateProgress(AnalysisPhase.fetchingRepoInfo, 'Fetching repository info...', 10);
      final repoData = await _fetchJson(
        'https://api.github.com/repos/$owner/$repo',
        token,
      );

      // Fetch languages
      _updateProgress(AnalysisPhase.analyzingStructure, 'Analyzing languages...', 25);
      final languagesData = await _fetchJson(
        'https://api.github.com/repos/$owner/$repo/languages',
        token,
      );

      // Fetch contributors
      _updateProgress(AnalysisPhase.analyzingStructure, 'Fetching contributors...', 35);
      final contributorsData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/contributors?per_page=10',
        token,
      );

      // Fetch README
      _updateProgress(AnalysisPhase.analyzingFeatures, 'Fetching README...', 45);
      String? readmeContent;
      try {
        final readmeResponse = await http.get(
          Uri.parse('https://api.github.com/repos/$owner/$repo/readme'),
          headers: _getHeaders(token),
        );
        if (readmeResponse.statusCode == 200) {
          final readmeData = json.decode(readmeResponse.body);
          if (readmeData['content'] != null) {
            readmeContent = utf8.decode(base64.decode(
              readmeData['content'].toString().replaceAll('\n', ''),
            ));
          }
        }
      } catch (_) {}

      // Fetch issues (GitHub API returns PRs as issues, so we filter them out)
      List<dynamic> issuesData = [];
      List<dynamic> closedIssuesData = [];
      if (includeIssues) {
        _updateProgress(AnalysisPhase.fetchingIssues, 'Fetching issues...', 55);
        final rawOpenIssues = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/issues?state=open&per_page=100',
          token,
        );
        // Filter out pull requests (they have a 'pull_request' field)
        issuesData = rawOpenIssues.where((i) => i['pull_request'] == null).toList();

        final rawClosedIssues = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/issues?state=closed&per_page=100',
          token,
        );
        closedIssuesData = rawClosedIssues.where((i) => i['pull_request'] == null).toList();
      }

      // Fetch PRs
      List<dynamic> prsData = [];
      List<dynamic> openPrsData = [];
      List<dynamic> closedPrsData = [];
      if (includePrs) {
        _updateProgress(AnalysisPhase.fetchingPullRequests, 'Fetching pull requests...', 70);
        openPrsData = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/pulls?state=open&per_page=100',
          token,
        );
        closedPrsData = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/pulls?state=closed&per_page=100',
          token,
        );
        prsData = [...openPrsData, ...closedPrsData];
      }

      // Fetch contents for structure analysis
      _updateProgress(AnalysisPhase.analyzingArchitecture, 'Analyzing structure...', 75);
      final contentsData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/contents',
        token,
      );

      // Fetch branches for Executive Summary
      _updateProgress(AnalysisPhase.analyzingArchitecture, 'Analyzing branches...', 80);
      final branchesData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/branches?per_page=100',
        token,
      );

      // Fetch commit activity for velocity calculation
      _updateProgress(AnalysisPhase.analyzingArchitecture, 'Analyzing commit activity...', 85);
      List<dynamic> commitActivityData = [];
      try {
        commitActivityData = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/stats/commit_activity',
          token,
        );
      } catch (_) {}

      // Generate Executive Summary
      _updateProgress(AnalysisPhase.generatingReport, 'Generating Executive Summary...', 82);
      final executiveSummary = _generateExecutiveSummary(
        repoData: repoData,
        branchesData: branchesData,
        commitActivityData: commitActivityData,
        issuesData: issuesData,
        closedIssuesData: closedIssuesData,
        prsData: prsData,
        contentsData: contentsData,
      );

      // ITERATION 1: Dependency Analysis
      _updateProgress(AnalysisPhase.analyzingDependencies, 'Analyzing dependencies...', 72);
      final dependencyAnalysis = await _analyzeDependencies(
        owner: owner,
        repo: repo,
        token: token,
        contentsData: contentsData,
      );

      // ITERATION 2: Technical Debt Detection
      _updateProgress(AnalysisPhase.analyzingTechDebt, 'Detecting technical debt...', 75);
      final techDebtAnalysis = await _analyzeTechDebt(
        owner: owner,
        repo: repo,
        token: token,
        contentsData: contentsData,
      );

      // ITERATION 3: Contributor Insights
      _updateProgress(AnalysisPhase.analyzingContributors, 'Analyzing contributors...', 73);
      final contributorInsights = await _analyzeContributorInsights(
        owner: owner,
        repo: repo,
        token: token,
        contributorsData: contributorsData,
        contentsData: contentsData,
      );

      // ITERATION 6: Git Workflow Analysis
      _updateProgress(AnalysisPhase.analyzingGitWorkflow, 'Analyzing git workflow...', 75);
      final gitWorkflowAnalysis = await _analyzeGitWorkflow(
        owner: owner,
        repo: repo,
        token: token,
        prsData: prsData,
      );

      // ITERATION 7: CI/CD Pipeline Analysis
      _updateProgress(AnalysisPhase.analyzingCiCd, 'Analyzing CI/CD pipelines...', 77);
      final ciCdAnalysis = await _analyzeCiCd(
        owner: owner,
        repo: repo,
        token: token,
        contentsData: contentsData,
      );

      // ITERATION 8: Documentation Analysis
      _updateProgress(AnalysisPhase.analyzingDocumentation, 'Analyzing documentation...', 79);
      final documentationAnalysis = await _analyzeDocumentation(
        owner: owner,
        repo: repo,
        token: token,
        contentsData: contentsData,
        readmeContent: readmeContent,
      );

      // ITERATION 9: Release Management Analysis
      _updateProgress(AnalysisPhase.analyzingReleases, 'Analyzing releases...', 81);
      final releaseAnalysis = await _analyzeReleases(
        owner: owner,
        repo: repo,
        token: token,
      );

      // ITERATION 10: Security Posture Analysis
      _updateProgress(AnalysisPhase.analyzingSecurityPosture, 'Security posture scan...', 83);
      final securityPostureAnalysis = await _analyzeSecurityPosture(
        owner: owner,
        repo: repo,
        token: token,
        contentsData: contentsData,
      );

      // Process quality data (needed for AI roadmap)
      _updateProgress(AnalysisPhase.analyzingQuality, 'Analyzing quality...', 80);
      final languages = _processLanguages(languagesData);
      final frameworks = _detectFrameworks(contentsData, languagesData);
      final quality = _analyzeQuality(repoData, contentsData, readmeContent);

      // AI Analysis (if enabled)
      AIInsights? aiInsights;
      ActionableRoadmap? actionableRoadmap;
      debugPrint('AI Analysis check: enableAiAnalysis=$enableAiAnalysis, aiApiKey=${aiApiKey != null ? '${aiApiKey.length} chars' : 'null'}');
      if (enableAiAnalysis && aiApiKey != null && aiApiKey.isNotEmpty) {
        debugPrint('Starting AI analysis...');
        aiInsights = await _performAiAnalysis(
          owner: owner,
          repo: repo,
          token: token,
          aiApiKey: aiApiKey,
          aiProvider: aiProvider,
        );
        debugPrint('AI insights result: ${aiInsights != null ? 'received' : 'null'}');

        // ITERATION 5: AI-Powered Actionable Roadmap
        _updateProgress(AnalysisPhase.aiGeneratingRoadmap, 'AI generating improvement roadmap...', 92);
        actionableRoadmap = await _generateActionableRoadmap(
          aiApiKey: aiApiKey,
          aiProvider: aiProvider,
          quality: quality,
          dependencyAnalysis: dependencyAnalysis,
          techDebtAnalysis: techDebtAnalysis,
          contributorInsights: contributorInsights,
        );
      } else {
        debugPrint('AI analysis skipped - not enabled or no API key');
      }

      // Generate report
      _updateProgress(AnalysisPhase.generatingReport, 'Generating report...', 95);

      final reportContent = _generateReport(
        owner: owner,
        repo: repo,
        repoData: repoData,
        languages: languages,
        frameworks: frameworks,
        contributors: contributorsData,
        issues: issuesData,
        closedIssues: closedIssuesData,
        prs: prsData,
        quality: quality,
        readmeContent: readmeContent,
        executiveSummary: executiveSummary,
        aiInsights: aiInsights,
        dependencyAnalysis: dependencyAnalysis,
        techDebtAnalysis: techDebtAnalysis,
        contributorInsights: contributorInsights,
        actionableRoadmap: actionableRoadmap,
        gitWorkflowAnalysis: gitWorkflowAnalysis,
        ciCdAnalysis: ciCdAnalysis,
        documentationAnalysis: documentationAnalysis,
        releaseAnalysis: releaseAnalysis,
        securityPostureAnalysis: securityPostureAnalysis,
      );

      // Write report
      _updateProgress(AnalysisPhase.writingReport, 'Writing report...', 95);
      final reportFile = File(outputPath);
      await reportFile.parent.create(recursive: true);
      await reportFile.writeAsString(reportContent);

      _updateProgress(AnalysisPhase.completed, 'Analysis complete!', 100);

      // Create result
      _result = AnalysisResult(
        repoName: repo,
        repoFullName: '$owner/$repo',
        description: repoData['description'] as String?,
        htmlUrl: repoData['html_url'] as String,
        stars: repoData['stargazers_count'] as int,
        forks: repoData['forks_count'] as int,
        openIssues: issuesData.length, // Use filtered count (excludes PRs)
        primaryLanguage: repoData['language'] as String?,
        languages: languages,
        frameworks: frameworks,
        buildTools: _detectBuildTools(contentsData),
        quality: quality,
        executiveSummary: executiveSummary,
        aiInsights: aiInsights,
        dependencyAnalysis: dependencyAnalysis,
        techDebtAnalysis: techDebtAnalysis,
        contributorInsights: contributorInsights,
        actionableRoadmap: actionableRoadmap,
        gitWorkflowAnalysis: gitWorkflowAnalysis,
        ciCdAnalysis: ciCdAnalysis,
        documentationAnalysis: documentationAnalysis,
        releaseAnalysis: releaseAnalysis,
        securityPostureAnalysis: securityPostureAnalysis,
        analyzedAt: DateTime.now(),
        reportPath: outputPath,
        reportContent: reportContent,
      );

    } catch (e) {
      _currentPhase = AnalysisPhase.failed;
      _error = e.toString();
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  List<LanguageStats> _processLanguages(Map<String, dynamic> languagesData) {
    final total = languagesData.values.fold<int>(0, (sum, v) => sum + (v as int));
    if (total == 0) return [];

    return languagesData.entries.map((e) {
      final bytes = e.value as int;
      return LanguageStats(
        name: e.key,
        files: 0,
        lines: bytes ~/ 30, // rough estimate
        code: bytes ~/ 35,
        comments: bytes ~/ 200,
        blanks: bytes ~/ 150,
        percentage: (bytes / total) * 100,
      );
    }).toList()..sort((a, b) => b.percentage.compareTo(a.percentage));
  }

  List<String> _detectFrameworks(List<dynamic> contents, Map<String, dynamic> languages) {
    final frameworks = <String>[];
    final fileNames = contents.map((c) => c['name'].toString().toLowerCase()).toSet();

    if (fileNames.contains('package.json')) {
      if (languages.containsKey('TypeScript') || languages.containsKey('JavaScript')) {
        frameworks.add('Node.js');
      }
    }
    if (fileNames.contains('cargo.toml')) frameworks.add('Rust/Cargo');
    if (fileNames.contains('pubspec.yaml')) frameworks.add('Flutter/Dart');
    if (fileNames.contains('requirements.txt') || fileNames.contains('pyproject.toml')) {
      frameworks.add('Python');
    }
    if (fileNames.contains('go.mod')) frameworks.add('Go');
    if (fileNames.contains('pom.xml') || fileNames.contains('build.gradle')) {
      frameworks.add('Java/JVM');
    }
    if (fileNames.contains('gemfile')) frameworks.add('Ruby');
    if (fileNames.contains('dockerfile')) frameworks.add('Docker');

    return frameworks;
  }

  List<String> _detectBuildTools(List<dynamic> contents) {
    final tools = <String>[];
    final fileNames = contents.map((c) => c['name'].toString().toLowerCase()).toSet();

    if (fileNames.contains('makefile')) tools.add('Make');
    if (fileNames.contains('cargo.toml')) tools.add('Cargo');
    if (fileNames.contains('package.json')) tools.add('npm/yarn');
    if (fileNames.contains('pubspec.yaml')) tools.add('Flutter');
    if (fileNames.contains('dockerfile')) tools.add('Docker');
    if (fileNames.any((f) => f.contains('webpack'))) tools.add('Webpack');
    if (fileNames.contains('vite.config.ts') || fileNames.contains('vite.config.js')) {
      tools.add('Vite');
    }

    return tools;
  }

  QualityAnalysis _analyzeQuality(
    Map<String, dynamic> repoData,
    List<dynamic> contents,
    String? readmeContent,
  ) {
    final fileNames = contents.map((c) => c['name'].toString().toLowerCase()).toSet();

    final hasReadme = fileNames.any((f) => f.startsWith('readme'));
    final hasLicense = fileNames.any((f) => f.startsWith('license'));
    final hasContributing = fileNames.any((f) => f.contains('contributing'));
    final hasChangelog = fileNames.any((f) => f.contains('changelog') || f.contains('history'));
    final hasCi = fileNames.contains('.github') || fileNames.contains('.travis.yml') ||
                  fileNames.contains('.circleci');
    final hasTests = fileNames.any((f) => f == 'tests' || f == 'test' || f == 'spec' || f == '__tests__');
    final hasSecurityPolicy = fileNames.contains('security.md');
    final hasCodeOfConduct = fileNames.any((f) => f.contains('code_of_conduct'));

    // Calculate scores
    var docScore = 0.0;
    if (hasReadme) docScore += 40;
    if (readmeContent != null && readmeContent.length > 500) docScore += 20;
    if (hasContributing) docScore += 20;
    if (hasChangelog) docScore += 10;
    if (hasLicense) docScore += 10;

    var testScore = hasTests ? 60.0 : 20.0;
    if (hasCi) testScore += 40;

    var maintenanceScore = 50.0;
    final updatedAt = DateTime.tryParse(repoData['updated_at'] ?? '');
    if (updatedAt != null) {
      final daysSinceUpdate = DateTime.now().difference(updatedAt).inDays;
      if (daysSinceUpdate < 7) maintenanceScore += 30;
      else if (daysSinceUpdate < 30) maintenanceScore += 20;
      else if (daysSinceUpdate < 90) maintenanceScore += 10;
    }
    if ((repoData['stargazers_count'] ?? 0) > 100) maintenanceScore += 10;
    if ((repoData['forks_count'] ?? 0) > 10) maintenanceScore += 10;

    var securityScore = 50.0;
    if (hasSecurityPolicy) securityScore += 25;
    if (hasLicense) securityScore += 15;
    if (hasCi) securityScore += 10;

    var codeQualityScore = 50.0;
    if (hasTests) codeQualityScore += 25;
    if (hasCi) codeQualityScore += 15;
    if (hasReadme) codeQualityScore += 10;

    final overallScore = (docScore * 0.2 + testScore * 0.25 + maintenanceScore * 0.2 +
                         securityScore * 0.15 + codeQualityScore * 0.2).clamp(0.0, 100.0);

    final issues = <QualityIssue>[];
    if (!hasReadme) {
      issues.add(QualityIssue(severity: 'high', category: 'documentation', message: 'No README file found'));
    }
    if (!hasLicense) {
      issues.add(QualityIssue(severity: 'medium', category: 'legal', message: 'No LICENSE file found'));
    }
    if (!hasTests) {
      issues.add(QualityIssue(severity: 'medium', category: 'testing', message: 'No test directory found'));
    }
    if (!hasCi) {
      issues.add(QualityIssue(severity: 'low', category: 'automation', message: 'No CI/CD configuration found'));
    }

    return QualityAnalysis(
      overallScore: overallScore,
      documentationScore: docScore.clamp(0.0, 100.0),
      testCoverageScore: testScore.clamp(0.0, 100.0),
      maintenanceScore: maintenanceScore.clamp(0.0, 100.0),
      securityScore: securityScore.clamp(0.0, 100.0),
      codeQualityScore: codeQualityScore.clamp(0.0, 100.0),
      hasReadme: hasReadme,
      hasContributing: hasContributing,
      hasLicense: hasLicense,
      hasChangelog: hasChangelog,
      hasCi: hasCi,
      hasTests: hasTests,
      hasSecurityPolicy: hasSecurityPolicy,
      hasCodeOfConduct: hasCodeOfConduct,
      issues: issues,
    );
  }

  ExecutiveSummary _generateExecutiveSummary({
    required Map<String, dynamic> repoData,
    required List<dynamic> branchesData,
    required List<dynamic> commitActivityData,
    required List<dynamic> issuesData,
    required List<dynamic> closedIssuesData,
    required List<dynamic> prsData,
    required List<dynamic> contentsData,
  }) {
    // Analyze branches
    final defaultBranch = repoData['default_branch'] as String? ?? 'main';
    final now = DateTime.now();

    final branches = branchesData.map((b) {
      final name = b['name'] as String;
      return BranchInfo(
        name: name,
        isDefault: name == defaultBranch,
        isProtected: b['protected'] as bool? ?? false,
      );
    }).toList();

    // Categorize branches by naming convention
    final branchTypes = <String, int>{};
    int activeBranches = 0;
    int staleBranches = 0;
    int protectedCount = 0;

    for (final branch in branches) {
      final name = branch.name.toLowerCase();

      // Categorize branch types
      if (name.startsWith('feature/') || name.startsWith('feat/')) {
        branchTypes['Feature'] = (branchTypes['Feature'] ?? 0) + 1;
      } else if (name.startsWith('bugfix/') || name.startsWith('fix/') || name.startsWith('hotfix/')) {
        branchTypes['Bugfix'] = (branchTypes['Bugfix'] ?? 0) + 1;
      } else if (name.startsWith('release/')) {
        branchTypes['Release'] = (branchTypes['Release'] ?? 0) + 1;
      } else if (name.startsWith('develop') || name == 'dev') {
        branchTypes['Development'] = (branchTypes['Development'] ?? 0) + 1;
      } else if (name == 'main' || name == 'master') {
        branchTypes['Main'] = (branchTypes['Main'] ?? 0) + 1;
      } else {
        branchTypes['Other'] = (branchTypes['Other'] ?? 0) + 1;
      }

      if (branch.isProtected) protectedCount++;
    }

    // Calculate development velocity (commits per week)
    double developmentVelocity = 0;
    if (commitActivityData.isNotEmpty) {
      final recentWeeks = commitActivityData.take(4).toList();
      final totalCommits = recentWeeks.fold<int>(0, (sum, week) {
        return sum + ((week['total'] as int?) ?? 0);
      });
      developmentVelocity = totalCommits / recentWeeks.length;
    }

    // Determine concurrent development index (active branches)
    activeBranches = branches.length > 1 ? branches.length - 1 : 0; // Exclude main
    final concurrentDevelopmentIndex = activeBranches;

    // Calculate health score
    int healthScore = 50;
    final insights = <String>[];
    final recommendations = <String>[];

    // Stars impact
    final stars = repoData['stargazers_count'] as int? ?? 0;
    if (stars > 1000) {
      healthScore += 15;
      insights.add('High community interest with ${_formatNumber(stars)} stars');
    } else if (stars > 100) {
      healthScore += 10;
    } else if (stars > 10) {
      healthScore += 5;
    }

    // Activity impact
    final updatedAt = DateTime.tryParse(repoData['updated_at'] ?? '');
    if (updatedAt != null) {
      final daysSinceUpdate = now.difference(updatedAt).inDays;
      if (daysSinceUpdate < 7) {
        healthScore += 15;
        insights.add('Very active - updated within the last week');
      } else if (daysSinceUpdate < 30) {
        healthScore += 10;
        insights.add('Active development - updated within the last month');
      } else if (daysSinceUpdate < 90) {
        healthScore += 5;
      } else {
        healthScore -= 10;
        recommendations.add('Consider reviewing project activity - last update was ${daysSinceUpdate} days ago');
      }
    }

    // Branch strategy impact
    if (branches.length > 1) {
      healthScore += 5;
      insights.add('Uses branching strategy with ${branches.length} branches');
    }
    if (protectedCount > 0) {
      healthScore += 5;
      insights.add('Has $protectedCount protected branch(es)');
    }
    if (branchTypes.containsKey('Feature') && (branchTypes['Feature'] ?? 0) > 0) {
      insights.add('Active feature development with ${branchTypes['Feature']} feature branch(es)');
    }

    // Velocity impact
    if (developmentVelocity > 10) {
      healthScore += 10;
      insights.add('High development velocity (~${developmentVelocity.toStringAsFixed(1)} commits/week)');
    } else if (developmentVelocity > 3) {
      healthScore += 5;
      insights.add('Moderate development velocity (~${developmentVelocity.toStringAsFixed(1)} commits/week)');
    } else if (developmentVelocity < 1 && developmentVelocity > 0) {
      recommendations.add('Consider increasing development activity');
    }

    // Issue management
    final openIssues = issuesData.length;
    final closedIssues = closedIssuesData.length;
    final totalIssues = openIssues + closedIssues;
    if (totalIssues > 0) {
      final closeRate = closedIssues / totalIssues * 100;
      if (closeRate > 70) {
        healthScore += 5;
        insights.add('Good issue management - ${closeRate.toStringAsFixed(0)}% close rate');
      } else if (closeRate < 30) {
        recommendations.add('Consider addressing open issues - only ${closeRate.toStringAsFixed(0)}% close rate');
      }
    }

    // PR activity
    final openPrs = prsData.where((p) => p['state'] == 'open').length;
    final mergedPrs = prsData.where((p) => p['merged_at'] != null).length;
    if (mergedPrs > 0) {
      insights.add('$mergedPrs pull request(s) merged recently');
    }
    if (openPrs > 10) {
      recommendations.add('Consider reviewing $openPrs open pull requests');
    }

    // Determine health status
    String healthStatus;
    if (healthScore >= 80) {
      healthStatus = 'Excellent';
    } else if (healthScore >= 65) {
      healthStatus = 'Good';
    } else if (healthScore >= 50) {
      healthStatus = 'Fair';
    } else {
      healthStatus = 'Needs Attention';
    }

    // Determine project maturity
    String projectMaturity;
    final createdAt = DateTime.tryParse(repoData['created_at'] ?? '');
    if (createdAt != null) {
      final ageInDays = now.difference(createdAt).inDays;
      if (ageInDays < 90) {
        projectMaturity = 'New';
      } else if (developmentVelocity > 5 && stars > 50) {
        projectMaturity = 'Active';
      } else if (ageInDays > 365 && developmentVelocity < 1) {
        projectMaturity = 'Declining';
      } else {
        projectMaturity = 'Mature';
      }
    } else {
      projectMaturity = 'Unknown';
    }

    // Compile metrics
    final metrics = <String, dynamic>{
      'total_branches': branches.length,
      'active_branches': activeBranches,
      'protected_branches': protectedCount,
      'commits_per_week': developmentVelocity,
      'open_issues': openIssues,
      'closed_issues': closedIssues,
      'open_prs': openPrs,
      'merged_prs': mergedPrs,
    };

    return ExecutiveSummary(
      healthStatus: healthStatus,
      healthScore: healthScore.clamp(0, 100),
      branchAnalysis: BranchAnalysis(
        totalBranches: branches.length,
        activeBranches: activeBranches,
        staleBranches: staleBranches,
        branches: branches,
        branchTypes: branchTypes,
        avgBranchAge: 0, // Would need more API calls to calculate
        protectedBranches: protectedCount,
      ),
      concurrentDevelopmentIndex: concurrentDevelopmentIndex,
      developmentVelocity: developmentVelocity,
      projectMaturity: projectMaturity,
      keyInsights: insights,
      recommendations: recommendations,
      metrics: metrics,
    );
  }

  String _generateReport({
    required String owner,
    required String repo,
    required Map<String, dynamic> repoData,
    required List<LanguageStats> languages,
    required List<String> frameworks,
    required List<dynamic> contributors,
    required List<dynamic> issues,
    required List<dynamic> closedIssues,
    required List<dynamic> prs,
    required QualityAnalysis quality,
    String? readmeContent,
    ExecutiveSummary? executiveSummary,
    AIInsights? aiInsights,
    DependencyAnalysis? dependencyAnalysis,
    TechDebtAnalysis? techDebtAnalysis,
    ContributorInsights? contributorInsights,
    ActionableRoadmap? actionableRoadmap,
    GitWorkflowAnalysis? gitWorkflowAnalysis,
    CiCdAnalysis? ciCdAnalysis,
    DocumentationAnalysis? documentationAnalysis,
    ReleaseAnalysis? releaseAnalysis,
    SecurityPostureAnalysis? securityPostureAnalysis,
  }) {
    final buffer = StringBuffer();

    buffer.writeln('# Repository Analysis: $owner/$repo\n');
    buffer.writeln('> Generated on ${DateTime.now().toIso8601String()}\n');

    // Executive Summary
    if (executiveSummary != null) {
      buffer.writeln('## Executive Summary\n');
      buffer.writeln('### Project Health: ${executiveSummary.healthStatus} (${executiveSummary.healthScore}/100)\n');
      buffer.writeln('| Metric | Value |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Project Maturity | ${executiveSummary.projectMaturity} |');
      buffer.writeln('| Development Velocity | ${executiveSummary.developmentVelocity.toStringAsFixed(1)} commits/week |');
      buffer.writeln('| Concurrent Development | ${executiveSummary.concurrentDevelopmentIndex} active branches |');
      buffer.writeln('| Total Branches | ${executiveSummary.branchAnalysis.totalBranches} |');
      if (executiveSummary.branchAnalysis.protectedBranches > 0) {
        buffer.writeln('| Protected Branches | ${executiveSummary.branchAnalysis.protectedBranches} |');
      }
      buffer.writeln();

      // Branch Types
      if (executiveSummary.branchAnalysis.branchTypes.isNotEmpty) {
        buffer.writeln('### Branch Distribution\n');
        buffer.writeln('| Type | Count |');
        buffer.writeln('|------|-------|');
        executiveSummary.branchAnalysis.branchTypes.forEach((type, count) {
          buffer.writeln('| $type | $count |');
        });
        buffer.writeln();
      }

      // Key Insights
      if (executiveSummary.keyInsights.isNotEmpty) {
        buffer.writeln('### Key Insights\n');
        for (final insight in executiveSummary.keyInsights) {
          buffer.writeln('- $insight');
        }
        buffer.writeln();
      }

      // Recommendations
      if (executiveSummary.recommendations.isNotEmpty) {
        buffer.writeln('### Recommendations\n');
        for (final rec in executiveSummary.recommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // AI Insights Section
    if (aiInsights != null) {
      buffer.writeln('## AI-Powered Insights\n');

      if (aiInsights.mergedPrSummary != null && aiInsights.mergedPrSummary!.isNotEmpty) {
        buffer.writeln('### Recent Improvements (Last 3 Months - Merged PRs)\n');
        buffer.writeln(aiInsights.mergedPrSummary);
        buffer.writeln();
      }

      if (aiInsights.upcomingPrSummary != null && aiInsights.upcomingPrSummary!.isNotEmpty) {
        buffer.writeln('### Upcoming Improvements (Latest 50 PRs)\n');
        buffer.writeln(aiInsights.upcomingPrSummary);
        buffer.writeln();
      }

      if (aiInsights.issuesSummary != null && aiInsights.issuesSummary!.isNotEmpty) {
        buffer.writeln('### User Feedback Analysis (Last 3 Months Issues)\n');
        buffer.writeln(aiInsights.issuesSummary);
        buffer.writeln();
      }

      if (aiInsights.overallTrend != null && aiInsights.overallTrend!.isNotEmpty) {
        buffer.writeln('### Overall Development Trend\n');
        buffer.writeln(aiInsights.overallTrend);
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 5: Actionable Roadmap Section
    if (actionableRoadmap != null && actionableRoadmap.totalItems > 0) {
      buffer.writeln('## Actionable Improvement Roadmap\n');

      if (actionableRoadmap.criticalItems.isNotEmpty) {
        buffer.writeln('### Priority 1: Critical\n');
        for (final item in actionableRoadmap.criticalItems) {
          buffer.writeln('- [ ] **${item.title}** (${item.category})');
          buffer.writeln('  - ${item.description}');
        }
        buffer.writeln();
      }

      if (actionableRoadmap.highPriorityItems.isNotEmpty) {
        buffer.writeln('### Priority 2: High Impact\n');
        for (final item in actionableRoadmap.highPriorityItems) {
          buffer.writeln('- [ ] **${item.title}** (${item.category})');
          buffer.writeln('  - ${item.description}');
        }
        buffer.writeln();
      }

      if (actionableRoadmap.mediumPriorityItems.isNotEmpty) {
        buffer.writeln('### Priority 3: Medium\n');
        for (final item in actionableRoadmap.mediumPriorityItems) {
          buffer.writeln('- [ ] **${item.title}** (${item.category})');
          buffer.writeln('  - ${item.description}');
        }
        buffer.writeln();
      }

      if (actionableRoadmap.lowPriorityItems.isNotEmpty) {
        buffer.writeln('### Priority 4: Nice to Have\n');
        for (final item in actionableRoadmap.lowPriorityItems) {
          buffer.writeln('- [ ] **${item.title}** (${item.category})');
          buffer.writeln('  - ${item.description}');
        }
        buffer.writeln();
      }

      if (actionableRoadmap.overallAssessment != null) {
        buffer.writeln('### Predicted Impact\n');
        buffer.writeln(actionableRoadmap.overallAssessment);
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // Overview
    buffer.writeln('## Overview\n');
    buffer.writeln('**Repository:** [$owner/$repo](https://github.com/$owner/$repo)\n');
    if (repoData['description'] != null) {
      buffer.writeln('**Description:** ${repoData['description']}\n');
    }

    buffer.writeln('| Metric | Value |');
    buffer.writeln('|--------|-------|');
    buffer.writeln('| Stars | ${_formatNumber(repoData['stargazers_count'])} |');
    buffer.writeln('| Forks | ${_formatNumber(repoData['forks_count'])} |');
    buffer.writeln('| Watchers | ${_formatNumber(repoData['watchers_count'])} |');
    buffer.writeln('| Open Issues | ${issues.length} |');
    buffer.writeln('| Open PRs | ${prs.where((p) => p['state'] == 'open').length} |');
    buffer.writeln('| Size | ${_formatNumber(repoData['size'])} KB |');
    buffer.writeln('| Default Branch | `${repoData['default_branch']}` |');
    if (repoData['language'] != null) {
      buffer.writeln('| Primary Language | ${repoData['language']} |');
    }
    if (repoData['license'] != null && repoData['license']['name'] != null) {
      buffer.writeln('| License | ${repoData['license']['name']} |');
    }
    buffer.writeln('| Created | ${repoData['created_at']?.toString().split('T')[0]} |');
    buffer.writeln('| Last Updated | ${repoData['updated_at']?.toString().split('T')[0]} |');
    buffer.writeln();

    // Topics
    if (repoData['topics'] != null && (repoData['topics'] as List).isNotEmpty) {
      buffer.writeln('**Topics:** ${(repoData['topics'] as List).map((t) => '`$t`').join(', ')}\n');
    }

    buffer.writeln('---\n');

    // Languages
    if (languages.isNotEmpty) {
      buffer.writeln('## Languages\n');
      buffer.writeln('| Language | Percentage |');
      buffer.writeln('|----------|------------|');
      for (final lang in languages.take(10)) {
        buffer.writeln('| ${lang.name} | ${lang.percentage.toStringAsFixed(1)}% |');
      }
      buffer.writeln();
      buffer.writeln('---\n');
    }

    // Tech Stack
    if (frameworks.isNotEmpty) {
      buffer.writeln('## Tech Stack\n');
      for (final fw in frameworks) {
        buffer.writeln('- $fw');
      }
      buffer.writeln();
      buffer.writeln('---\n');
    }

    // Quality
    buffer.writeln('## Quality Assessment\n');
    buffer.writeln('### Overall Score: ${quality.overallScore.toInt()}/100\n');
    buffer.writeln('| Category | Score | Status |');
    buffer.writeln('|----------|-------|--------|');
    buffer.writeln('| Documentation | ${quality.documentationScore.toInt()}/100 | ${_scoreStatus(quality.documentationScore)} |');
    buffer.writeln('| Testing | ${quality.testCoverageScore.toInt()}/100 | ${_scoreStatus(quality.testCoverageScore)} |');
    buffer.writeln('| Maintenance | ${quality.maintenanceScore.toInt()}/100 | ${_scoreStatus(quality.maintenanceScore)} |');
    buffer.writeln('| Security | ${quality.securityScore.toInt()}/100 | ${_scoreStatus(quality.securityScore)} |');
    buffer.writeln('| Code Quality | ${quality.codeQualityScore.toInt()}/100 | ${_scoreStatus(quality.codeQualityScore)} |');
    buffer.writeln();

    buffer.writeln('### Checklist\n');
    buffer.writeln('- [${quality.hasReadme ? 'x' : ' '}] README');
    buffer.writeln('- [${quality.hasLicense ? 'x' : ' '}] LICENSE');
    buffer.writeln('- [${quality.hasContributing ? 'x' : ' '}] CONTRIBUTING guide');
    buffer.writeln('- [${quality.hasChangelog ? 'x' : ' '}] CHANGELOG');
    buffer.writeln('- [${quality.hasCi ? 'x' : ' '}] CI/CD configuration');
    buffer.writeln('- [${quality.hasTests ? 'x' : ' '}] Tests');
    buffer.writeln('- [${quality.hasSecurityPolicy ? 'x' : ' '}] Security policy');
    buffer.writeln('- [${quality.hasCodeOfConduct ? 'x' : ' '}] Code of Conduct');
    buffer.writeln();

    if (quality.issues.isNotEmpty) {
      buffer.writeln('### Issues Found\n');
      for (final issue in quality.issues) {
        buffer.writeln('- **${issue.category}**: ${issue.message}');
      }
      buffer.writeln();
    }

    buffer.writeln('---\n');

    // ITERATION 1: Dependency Analysis Section
    if (dependencyAnalysis != null && dependencyAnalysis.totalDependencies > 0) {
      buffer.writeln('## Dependency Analysis\n');
      buffer.writeln('| Metric | Value |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Total Dependencies | ${dependencyAnalysis.totalDependencies} |');
      buffer.writeln('| Outdated | ${dependencyAnalysis.outdatedCount} |');
      buffer.writeln('| Vulnerable | ${dependencyAnalysis.vulnerableCount} |');
      buffer.writeln('| Health Score | ${dependencyAnalysis.healthScore.toInt()}/100 |');
      if (dependencyAnalysis.packageManager != null) {
        buffer.writeln('| Package Manager | ${dependencyAnalysis.packageManager} |');
      }
      buffer.writeln();

      if (dependencyAnalysis.outdatedCount > 0) {
        buffer.writeln('### Outdated Dependencies\n');
        final outdated = dependencyAnalysis.dependencies.where((d) => d.isOutdated).take(10);
        for (final dep in outdated) {
          buffer.writeln('- **${dep.name}**: ${dep.currentVersion ?? 'unknown'} → ${dep.latestVersion ?? 'latest'}');
        }
        buffer.writeln();
      }

      if (dependencyAnalysis.vulnerableCount > 0) {
        buffer.writeln('### Security Vulnerabilities\n');
        final vulnerable = dependencyAnalysis.dependencies.where((d) => d.hasVulnerability).take(10);
        for (final dep in vulnerable) {
          buffer.writeln('- **${dep.name}** [${dep.vulnerabilitySeverity ?? 'unknown'}]: ${dep.vulnerabilityDescription ?? 'vulnerability detected'}');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 2: Technical Debt Section
    if (techDebtAnalysis != null && techDebtAnalysis.totalItems > 0) {
      buffer.writeln('## Technical Debt Analysis\n');
      buffer.writeln('| Metric | Value |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Total Debt Items | ${techDebtAnalysis.totalItems} |');
      buffer.writeln('| TODO Comments | ${techDebtAnalysis.todoCount} |');
      buffer.writeln('| FIXME Comments | ${techDebtAnalysis.fixmeCount} |');
      buffer.writeln('| HACK Comments | ${techDebtAnalysis.hackCount} |');
      buffer.writeln('| Large Files (>500 lines) | ${techDebtAnalysis.largeFilesCount} |');
      buffer.writeln('| Debt Score | ${techDebtAnalysis.debtScore.toInt()}/100 (lower is better) |');
      buffer.writeln();

      if (techDebtAnalysis.items.isNotEmpty) {
        buffer.writeln('### Top Debt Items\n');
        for (final item in techDebtAnalysis.items.take(15)) {
          buffer.writeln('- **[${item.type}]** `${item.filePath}${item.lineNumber != null ? ':${item.lineNumber}' : ''}`');
          buffer.writeln('  - ${item.description}');
        }
        buffer.writeln();
      }

      if (techDebtAnalysis.largeFiles.isNotEmpty) {
        buffer.writeln('### Large Files Needing Refactoring\n');
        for (final file in techDebtAnalysis.largeFiles.take(10)) {
          buffer.writeln('- `$file`');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 3: Contributor Insights Section
    if (contributorInsights != null) {
      buffer.writeln('## Contributor Insights\n');
      buffer.writeln('| Metric | Value |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Total Contributors | ${contributorInsights.totalContributors} |');
      buffer.writeln('| Active (30 days) | ${contributorInsights.activeContributors} |');
      buffer.writeln('| Bus Factor | ${contributorInsights.busFactor} (${contributorInsights.busFactorRisk} risk) |');
      buffer.writeln();

      if (contributorInsights.topContributors.isNotEmpty) {
        buffer.writeln('### Code Ownership\n');
        buffer.writeln('| Contributor | Commits | Ownership |');
        buffer.writeln('|-------------|---------|-----------|');
        for (final c in contributorInsights.topContributors.take(5)) {
          buffer.writeln('| @${c.login} | ${c.totalCommits} | ${c.ownershipPercentage.toStringAsFixed(1)}% |');
        }
        buffer.writeln();
      }

      if (contributorInsights.keyEntryPoints.isNotEmpty) {
        buffer.writeln('### Onboarding Guide for New Contributors\n');
        buffer.writeln('**Key Entry Points:**\n');
        for (final file in contributorInsights.keyEntryPoints.take(5)) {
          buffer.writeln('- `$file`');
        }
        buffer.writeln();
      }

      if (contributorInsights.onboardingRecommendations.isNotEmpty) {
        buffer.writeln('**Recommendations:**\n');
        for (final rec in contributorInsights.onboardingRecommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 6: Git Workflow Analysis Section
    if (gitWorkflowAnalysis != null) {
      buffer.writeln('## Git Workflow Analysis\n');
      buffer.writeln('| Metric | Value |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Total Commits (sampled) | ${gitWorkflowAnalysis.totalCommits} |');
      buffer.writeln('| Recent Commits (30 days) | ${gitWorkflowAnalysis.recentCommits} |');
      buffer.writeln('| Commits per Week | ${gitWorkflowAnalysis.avgCommitsPerWeek.toStringAsFixed(1)} |');
      buffer.writeln('| Conventional Commits | ${(gitWorkflowAnalysis.conventionalCommitRatio * 100).toStringAsFixed(0)}% |');
      buffer.writeln('| Branching Strategy | ${gitWorkflowAnalysis.branchingStrategy} |');
      buffer.writeln('| Avg PR Turnaround | ${gitWorkflowAnalysis.avgPrTurnaround.toStringAsFixed(0)} hours |');
      buffer.writeln('| Avg PR Size | ${gitWorkflowAnalysis.avgPrSize} lines |');
      buffer.writeln('| Commit Quality Score | ${gitWorkflowAnalysis.commitQualityScore.toInt()}/100 |');
      buffer.writeln();

      if (gitWorkflowAnalysis.commitPrefixes.isNotEmpty) {
        buffer.writeln('### Commit Types\n');
        buffer.writeln('| Type | Count |');
        buffer.writeln('|------|-------|');
        gitWorkflowAnalysis.commitPrefixes.forEach((type, count) {
          buffer.writeln('| $type | $count |');
        });
        buffer.writeln();
      }

      if (gitWorkflowAnalysis.workflowRecommendations.isNotEmpty) {
        buffer.writeln('### Workflow Recommendations\n');
        for (final rec in gitWorkflowAnalysis.workflowRecommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 7: CI/CD Analysis Section
    if (ciCdAnalysis != null) {
      buffer.writeln('## CI/CD Pipeline Analysis\n');
      buffer.writeln('| Platform | Status |');
      buffer.writeln('|----------|--------|');
      buffer.writeln('| GitHub Actions | ${ciCdAnalysis.hasGitHubActions ? 'Enabled' : 'Not Found'} |');
      buffer.writeln('| Travis CI | ${ciCdAnalysis.hasTravisCI ? 'Enabled' : 'Not Found'} |');
      buffer.writeln('| Circle CI | ${ciCdAnalysis.hasCircleCI ? 'Enabled' : 'Not Found'} |');
      buffer.writeln('| Jenkins | ${ciCdAnalysis.hasJenkinsfile ? 'Enabled' : 'Not Found'} |');
      buffer.writeln();

      buffer.writeln('### Pipeline Stages\n');
      buffer.writeln('- [${ciCdAnalysis.hasTestStage ? 'x' : ' '}] Automated Testing');
      buffer.writeln('- [${ciCdAnalysis.hasLintStage ? 'x' : ' '}] Code Linting');
      buffer.writeln('- [${ciCdAnalysis.hasBuildStage ? 'x' : ' '}] Build Verification');
      buffer.writeln('- [${ciCdAnalysis.hasDeployStage ? 'x' : ' '}] Deployment');
      buffer.writeln('- [${ciCdAnalysis.hasSecurityScan ? 'x' : ' '}] Security Scanning');
      buffer.writeln();

      buffer.writeln('**Pipeline Score:** ${ciCdAnalysis.pipelineScore.toInt()}/100\n');

      if (ciCdAnalysis.workflows.isNotEmpty) {
        buffer.writeln('### Workflows\n');
        buffer.writeln('| Name | Trigger |');
        buffer.writeln('|------|---------|');
        for (final wf in ciCdAnalysis.workflows.take(10)) {
          buffer.writeln('| ${wf.name} | ${wf.trigger} |');
        }
        buffer.writeln();
      }

      if (ciCdAnalysis.recommendations.isNotEmpty) {
        buffer.writeln('### CI/CD Recommendations\n');
        for (final rec in ciCdAnalysis.recommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 8: Documentation Analysis Section
    if (documentationAnalysis != null) {
      buffer.writeln('## Documentation Analysis\n');
      buffer.writeln('**Documentation Score:** ${documentationAnalysis.documentationScore.toInt()}/100\n');

      buffer.writeln('### Documentation Files\n');
      buffer.writeln('- [${documentationAnalysis.hasReadme ? 'x' : ' '}] README.md (${documentationAnalysis.readmeLength} chars)');
      buffer.writeln('- [${documentationAnalysis.hasContributingFile ? 'x' : ' '}] CONTRIBUTING.md');
      buffer.writeln('- [${documentationAnalysis.hasCodeOfConduct ? 'x' : ' '}] CODE_OF_CONDUCT.md');
      buffer.writeln('- [${documentationAnalysis.hasChangelog ? 'x' : ' '}] CHANGELOG.md');
      buffer.writeln('- [${documentationAnalysis.hasApiDocs ? 'x' : ' '}] API Documentation');
      buffer.writeln('- [${documentationAnalysis.hasWiki ? 'x' : ' '}] Wiki');
      buffer.writeln();

      buffer.writeln('### README Sections\n');
      buffer.writeln('- [${documentationAnalysis.readmeHasInstallation ? 'x' : ' '}] Installation Instructions');
      buffer.writeln('- [${documentationAnalysis.readmeHasUsage ? 'x' : ' '}] Usage Examples');
      buffer.writeln('- [${documentationAnalysis.readmeHasApi ? 'x' : ' '}] API Reference');
      buffer.writeln('- [${documentationAnalysis.readmeHasBadges ? 'x' : ' '}] Status Badges');
      buffer.writeln();

      if (documentationAnalysis.recommendations.isNotEmpty) {
        buffer.writeln('### Documentation Recommendations\n');
        for (final rec in documentationAnalysis.recommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 9: Release Analysis Section
    if (releaseAnalysis != null && releaseAnalysis.totalReleases > 0) {
      buffer.writeln('## Release Management\n');
      buffer.writeln('| Metric | Value |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Total Releases | ${releaseAnalysis.totalReleases} |');
      buffer.writeln('| Releases (Last Year) | ${releaseAnalysis.releasesLastYear} |');
      buffer.writeln('| Release Frequency | ${releaseAnalysis.avgReleaseFrequency.toStringAsFixed(1)}/month |');
      buffer.writeln('| Uses Semver | ${releaseAnalysis.usesSemver ? 'Yes' : 'No'} |');
      buffer.writeln('| Semver Compliance | ${(releaseAnalysis.semverCompliance * 100).toStringAsFixed(0)}% |');
      buffer.writeln('| Days Since Last Release | ${releaseAnalysis.daysSinceLastRelease} |');
      buffer.writeln('| Release Strategy | ${releaseAnalysis.releaseStrategy} |');
      buffer.writeln('| Release Score | ${releaseAnalysis.releaseScore.toInt()}/100 |');
      buffer.writeln();

      if (releaseAnalysis.recentReleases.isNotEmpty) {
        buffer.writeln('### Recent Releases\n');
        buffer.writeln('| Version | Date | Type |');
        buffer.writeln('|---------|------|------|');
        for (final r in releaseAnalysis.recentReleases.take(5)) {
          final type = r.isPrerelease ? 'Pre-release' : 'Stable';
          buffer.writeln('| ${r.tagName} | ${r.publishedAt.toIso8601String().split('T')[0]} | $type |');
        }
        buffer.writeln();
      }

      if (releaseAnalysis.recommendations.isNotEmpty) {
        buffer.writeln('### Release Recommendations\n');
        for (final rec in releaseAnalysis.recommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // ITERATION 10: Security Posture Section
    if (securityPostureAnalysis != null) {
      buffer.writeln('## Security Posture Analysis\n');
      buffer.writeln('**Security Score:** ${securityPostureAnalysis.securityScore.toInt()}/100 | **Risk Level:** ${securityPostureAnalysis.riskLevel.toUpperCase()}\n');

      buffer.writeln('### Security Features\n');
      buffer.writeln('- [${securityPostureAnalysis.hasSecurityPolicy ? 'x' : ' '}] Security Policy (SECURITY.md)');
      buffer.writeln('- [${securityPostureAnalysis.hasDependabot ? 'x' : ' '}] Dependabot');
      buffer.writeln('- [${securityPostureAnalysis.hasBranchProtection ? 'x' : ' '}] Branch Protection');
      buffer.writeln('- [${securityPostureAnalysis.requiresReviews ? 'x' : ' '}] Required PR Reviews');
      buffer.writeln('- [${securityPostureAnalysis.requiresSignedCommits ? 'x' : ' '}] Signed Commits Required');
      buffer.writeln('- [${securityPostureAnalysis.hasCodeScanning ? 'x' : ' '}] Code Scanning');
      buffer.writeln('- [${securityPostureAnalysis.hasSecretScanning ? 'x' : ' '}] Secret Scanning');
      buffer.writeln();

      buffer.writeln('### Findings Summary\n');
      buffer.writeln('| Type | Count |');
      buffer.writeln('|------|-------|');
      buffer.writeln('| Potential Secrets | ${securityPostureAnalysis.secretsDetected} |');
      buffer.writeln('| Vulnerabilities | ${securityPostureAnalysis.vulnerabilitiesFound} |');
      buffer.writeln('| Misconfigurations | ${securityPostureAnalysis.misconfigurationsFound} |');
      buffer.writeln();

      if (securityPostureAnalysis.findings.isNotEmpty) {
        buffer.writeln('### Security Findings\n');
        for (final finding in securityPostureAnalysis.findings.take(10)) {
          buffer.writeln('- **[${finding.severity.toUpperCase()}]** ${finding.title}');
          buffer.writeln('  - ${finding.description}');
        }
        buffer.writeln();
      }

      if (securityPostureAnalysis.recommendations.isNotEmpty) {
        buffer.writeln('### Security Recommendations\n');
        for (final rec in securityPostureAnalysis.recommendations) {
          buffer.writeln('- $rec');
        }
        buffer.writeln();
      }

      buffer.writeln('---\n');
    }

    // Contributors
    if (contributors.isNotEmpty) {
      buffer.writeln('## Top Contributors\n');
      buffer.writeln('| Contributor | Contributions |');
      buffer.writeln('|-------------|---------------|');
      for (final c in contributors.take(10)) {
        buffer.writeln('| [@${c['login']}](${c['html_url']}) | ${c['contributions']} |');
      }
      buffer.writeln();
      buffer.writeln('---\n');
    }

    // Issues (already filtered to exclude PRs)
    if (issues.isNotEmpty || closedIssues.isNotEmpty) {
      final totalIssues = issues.length + closedIssues.length;
      buffer.writeln('## Issues\n');
      buffer.writeln('| Status | Count |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Open | ${issues.length} |');
      buffer.writeln('| Closed | ${closedIssues.length} |');
      buffer.writeln('| Total | $totalIssues |');
      if (totalIssues > 0) {
        final closeRate = (closedIssues.length / totalIssues * 100).toStringAsFixed(1);
        buffer.writeln('| Close Rate | $closeRate% |');
      }
      buffer.writeln();

      if (issues.isNotEmpty) {
        buffer.writeln('### Recent Open Issues\n');
        for (final issue in issues.take(5)) {
          final labels = (issue['labels'] as List?)?.map((l) => l['name']).join(', ') ?? '';
          buffer.writeln('- [#${issue['number']}](${issue['html_url']}) ${issue['title']}${labels.isNotEmpty ? ' `$labels`' : ''}');
        }
        buffer.writeln();
      }
      buffer.writeln('---\n');
    }

    // Pull Requests
    if (prs.isNotEmpty) {
      buffer.writeln('## Pull Requests\n');
      final openPrs = prs.where((p) => p['state'] == 'open').toList();
      final mergedPrs = prs.where((p) => p['merged_at'] != null).toList();
      final closedNotMergedPrs = prs.where((p) => p['state'] == 'closed' && p['merged_at'] == null).toList();

      buffer.writeln('| Status | Count |');
      buffer.writeln('|--------|-------|');
      buffer.writeln('| Open | ${openPrs.length} |');
      buffer.writeln('| Merged | ${mergedPrs.length} |');
      buffer.writeln('| Closed (not merged) | ${closedNotMergedPrs.length} |');
      buffer.writeln('| Total | ${prs.length} |');
      if (prs.isNotEmpty) {
        final mergeRate = (mergedPrs.length / prs.length * 100).toStringAsFixed(1);
        buffer.writeln('| Merge Rate | $mergeRate% |');
      }
      buffer.writeln();

      if (openPrs.isNotEmpty) {
        buffer.writeln('### Open PRs\n');
        for (final pr in openPrs.take(5)) {
          buffer.writeln('- [#${pr['number']}](${pr['html_url']}) ${pr['title']} by @${pr['user']['login']}');
        }
        buffer.writeln();
      }

      if (mergedPrs.isNotEmpty) {
        buffer.writeln('### Recently Merged PRs\n');
        for (final pr in mergedPrs.take(5)) {
          buffer.writeln('- [#${pr['number']}](${pr['html_url']}) ${pr['title']} by @${pr['user']['login']}');
        }
        buffer.writeln();
      }
      buffer.writeln('---\n');
    }

    buffer.writeln('*Report generated by GitHub Repository Analyzer*');

    return buffer.toString();
  }

  String _formatNumber(dynamic n) {
    if (n == null) return '0';
    final num = n as int;
    if (num >= 1000000) return '${(num / 1000000).toStringAsFixed(1)}M';
    if (num >= 1000) return '${(num / 1000).toStringAsFixed(1)}K';
    return num.toString();
  }

  String _scoreStatus(double score) {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Fair';
    return 'Needs Improvement';
  }

  // ==========================================================================
  // ITERATION 1: Dependency Analysis
  // ==========================================================================

  Future<DependencyAnalysis> _analyzeDependencies({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> contentsData,
  }) async {
    final dependencies = <Dependency>[];
    String? packageManager;
    final dependencyTypes = <String, int>{};

    final fileNames = contentsData.map((c) => c['name'].toString().toLowerCase()).toSet();

    try {
      // Check for package.json (npm/yarn)
      if (fileNames.contains('package.json')) {
        packageManager = 'npm';
        final packageJson = await _fetchFileContent(owner, repo, 'package.json', token);
        if (packageJson != null) {
          final data = json.decode(packageJson) as Map<String, dynamic>;

          // Parse dependencies
          final deps = data['dependencies'] as Map<String, dynamic>? ?? {};
          final devDeps = data['devDependencies'] as Map<String, dynamic>? ?? {};

          dependencyTypes['production'] = deps.length;
          dependencyTypes['development'] = devDeps.length;

          for (final entry in deps.entries) {
            dependencies.add(Dependency(
              name: entry.key,
              currentVersion: entry.value?.toString(),
              isOutdated: _isVersionOld(entry.value?.toString()),
            ));
          }
          for (final entry in devDeps.entries) {
            dependencies.add(Dependency(
              name: entry.key,
              currentVersion: entry.value?.toString(),
              isOutdated: _isVersionOld(entry.value?.toString()),
            ));
          }
        }
      }

      // Check for requirements.txt (pip)
      if (fileNames.contains('requirements.txt')) {
        packageManager ??= 'pip';
        final requirements = await _fetchFileContent(owner, repo, 'requirements.txt', token);
        if (requirements != null) {
          final lines = requirements.split('\n').where((l) => l.trim().isNotEmpty && !l.startsWith('#'));
          dependencyTypes['python'] = lines.length;
          for (final line in lines) {
            final parts = line.split(RegExp(r'[=<>]'));
            dependencies.add(Dependency(
              name: parts[0].trim(),
              currentVersion: parts.length > 1 ? parts.last.trim() : null,
            ));
          }
        }
      }

      // Check for Cargo.toml (Rust)
      if (fileNames.contains('cargo.toml')) {
        packageManager ??= 'cargo';
        dependencyTypes['rust'] = 0;
        // Simplified - would need proper TOML parsing
      }

      // Check for pubspec.yaml (Dart/Flutter)
      if (fileNames.contains('pubspec.yaml')) {
        packageManager ??= 'pub';
        dependencyTypes['dart'] = 0;
      }

      // Check for go.mod (Go)
      if (fileNames.contains('go.mod')) {
        packageManager ??= 'go';
        dependencyTypes['go'] = 0;
      }

    } catch (e) {
      debugPrint('Dependency analysis error: $e');
    }

    final outdatedCount = dependencies.where((d) => d.isOutdated).length;
    final vulnerableCount = dependencies.where((d) => d.hasVulnerability).length;
    final healthScore = dependencies.isEmpty
        ? 100.0
        : ((dependencies.length - outdatedCount - vulnerableCount * 2) / dependencies.length * 100).clamp(0.0, 100.0);

    return DependencyAnalysis(
      totalDependencies: dependencies.length,
      outdatedCount: outdatedCount,
      vulnerableCount: vulnerableCount,
      healthScore: healthScore,
      dependencies: dependencies,
      dependencyTypes: dependencyTypes,
      packageManager: packageManager,
    );
  }

  bool _isVersionOld(String? version) {
    if (version == null) return false;
    // Check for old major versions (0.x or very old patterns)
    if (version.startsWith('^0.') || version.startsWith('~0.')) return true;
    // Check for versions without caret/tilde (pinned to specific)
    if (RegExp(r'^\d+\.\d+\.\d+$').hasMatch(version)) return true;
    return false;
  }

  Future<String?> _fetchFileContent(String owner, String repo, String path, String? token) async {
    try {
      final response = await http.get(
        Uri.parse('https://api.github.com/repos/$owner/$repo/contents/$path'),
        headers: _getHeaders(token),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['content'] != null) {
          return utf8.decode(base64.decode(data['content'].toString().replaceAll('\n', '')));
        }
      }
    } catch (e) {
      debugPrint('Error fetching $path: $e');
    }
    return null;
  }

  // ==========================================================================
  // ITERATION 2: Technical Debt Detection
  // ==========================================================================

  Future<TechDebtAnalysis> _analyzeTechDebt({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> contentsData,
  }) async {
    final items = <TechDebtItem>[];
    final largeFiles = <String>[];
    final debtByCategory = <String, int>{};
    int todoCount = 0;
    int fixmeCount = 0;
    int hackCount = 0;

    try {
      // Search for TODO/FIXME/HACK comments using GitHub search API
      final searchResults = await _searchCode(owner, repo, 'TODO OR FIXME OR HACK', token);

      for (final result in searchResults.take(50)) {
        final path = result['path'] as String? ?? '';
        final textMatches = result['text_matches'] as List? ?? [];

        for (final match in textMatches) {
          final fragment = match['fragment'] as String? ?? '';

          if (fragment.toUpperCase().contains('TODO')) {
            todoCount++;
            items.add(TechDebtItem(
              type: 'TODO',
              filePath: path,
              description: _extractComment(fragment, 'TODO'),
              severity: 'low',
            ));
          }
          if (fragment.toUpperCase().contains('FIXME')) {
            fixmeCount++;
            items.add(TechDebtItem(
              type: 'FIXME',
              filePath: path,
              description: _extractComment(fragment, 'FIXME'),
              severity: 'medium',
            ));
          }
          if (fragment.toUpperCase().contains('HACK')) {
            hackCount++;
            items.add(TechDebtItem(
              type: 'HACK',
              filePath: path,
              description: _extractComment(fragment, 'HACK'),
              severity: 'high',
            ));
          }
        }
      }

      debtByCategory['TODO'] = todoCount;
      debtByCategory['FIXME'] = fixmeCount;
      debtByCategory['HACK'] = hackCount;

    } catch (e) {
      debugPrint('Tech debt analysis error: $e');
    }

    final totalItems = todoCount + fixmeCount + hackCount + largeFiles.length;
    final debtScore = (todoCount * 1 + fixmeCount * 2 + hackCount * 3 + largeFiles.length * 2).clamp(0, 100).toDouble();

    return TechDebtAnalysis(
      totalItems: totalItems,
      todoCount: todoCount,
      fixmeCount: fixmeCount,
      hackCount: hackCount,
      largeFilesCount: largeFiles.length,
      complexFilesCount: 0,
      debtScore: debtScore,
      items: items,
      largeFiles: largeFiles,
      debtByCategory: debtByCategory,
    );
  }

  Future<List<dynamic>> _searchCode(String owner, String repo, String query, String? token) async {
    try {
      final response = await http.get(
        Uri.parse('https://api.github.com/search/code?q=${Uri.encodeComponent(query)}+repo:$owner/$repo&per_page=50'),
        headers: {
          ..._getHeaders(token),
          'Accept': 'application/vnd.github.text-match+json',
        },
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['items'] as List? ?? [];
      }
    } catch (e) {
      debugPrint('Code search error: $e');
    }
    return [];
  }

  String _extractComment(String fragment, String marker) {
    final upper = fragment.toUpperCase();
    final index = upper.indexOf(marker);
    if (index >= 0) {
      final start = index + marker.length;
      final end = fragment.indexOf('\n', start);
      return fragment.substring(start, end > start ? end : fragment.length).trim().replaceAll(RegExp(r'^[:\s]+'), '');
    }
    return fragment.trim();
  }

  // ==========================================================================
  // ITERATION 3: Contributor Insights
  // ==========================================================================

  Future<ContributorInsights> _analyzeContributorInsights({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> contributorsData,
    required List<dynamic> contentsData,
  }) async {
    final topContributors = <ContributorDetail>[];
    final codeOwnership = <CodeOwnership>[];
    final keyEntryPoints = <String>[];
    final onboardingRecommendations = <String>[];

    try {
      // Get total commits for ownership calculation
      int totalCommits = 0;
      for (final c in contributorsData) {
        totalCommits += (c['contributions'] as int? ?? 0);
      }

      // Process top contributors
      for (final c in contributorsData.take(10)) {
        final commits = c['contributions'] as int? ?? 0;
        topContributors.add(ContributorDetail(
          login: c['login'] as String? ?? 'unknown',
          totalCommits: commits,
          recentCommits: 0, // Would need additional API call
          primaryFiles: [],
          ownershipPercentage: totalCommits > 0 ? (commits / totalCommits * 100) : 0,
          isActive: true, // Would need additional API call to verify
        ));
      }

      // Calculate bus factor
      int busFactor = 0;
      double cumulativeOwnership = 0;
      for (final c in topContributors) {
        cumulativeOwnership += c.ownershipPercentage;
        busFactor++;
        if (cumulativeOwnership >= 50) break;
      }

      String busFactorRisk;
      if (busFactor <= 1) {
        busFactorRisk = 'critical';
      } else if (busFactor <= 2) {
        busFactorRisk = 'high';
      } else if (busFactor <= 4) {
        busFactorRisk = 'medium';
      } else {
        busFactorRisk = 'low';
      }

      // Identify key entry points
      final importantFiles = ['README.md', 'CONTRIBUTING.md', 'src/index', 'lib/main', 'app/', 'index.'];
      for (final content in contentsData) {
        final name = content['name'].toString().toLowerCase();
        if (importantFiles.any((f) => name.contains(f.toLowerCase()))) {
          keyEntryPoints.add(content['name'].toString());
        }
      }

      // Generate onboarding recommendations
      if (busFactor <= 2) {
        onboardingRecommendations.add('Consider documenting tribal knowledge from top contributors');
      }
      if (!contentsData.any((c) => c['name'].toString().toLowerCase().contains('contributing'))) {
        onboardingRecommendations.add('Add a CONTRIBUTING.md file to guide new contributors');
      }
      onboardingRecommendations.add('Start with good-first-issue labeled issues');
      onboardingRecommendations.add('Review recent merged PRs to understand coding patterns');

      return ContributorInsights(
        totalContributors: contributorsData.length,
        activeContributors: topContributors.where((c) => c.isActive).length,
        busFactor: busFactor,
        busFactorRisk: busFactorRisk,
        topContributors: topContributors,
        codeOwnership: codeOwnership,
        keyEntryPoints: keyEntryPoints,
        onboardingRecommendations: onboardingRecommendations,
      );
    } catch (e) {
      debugPrint('Contributor insights error: $e');
      return ContributorInsights.empty();
    }
  }

  // ==========================================================================
  // ITERATION 6: Git Workflow & Commit Quality Analysis
  // ==========================================================================

  Future<GitWorkflowAnalysis> _analyzeGitWorkflow({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> prsData,
  }) async {
    final commitPrefixes = <String, int>{};
    final sampleCommits = <CommitQuality>[];
    int conventionalCount = 0;
    int totalPrSize = 0;
    int totalPrTurnaround = 0;
    int mergedPrCount = 0;

    try {
      // Fetch recent commits
      final commitsData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/commits?per_page=100',
        token,
      );

      final recentCommits = commitsData.take(100).toList();
      final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));

      for (final commit in recentCommits.take(50)) {
        final message = commit['commit']['message'] as String? ?? '';
        final sha = commit['sha'] as String? ?? '';

        // Check for conventional commit prefixes
        final prefixMatch = RegExp(r'^(feat|fix|docs|style|refactor|test|chore|perf|ci|build|revert)(\(.+\))?:').firstMatch(message);
        final hasPrefix = prefixMatch != null;
        String? prefix;

        if (hasPrefix) {
          prefix = prefixMatch.group(1);
          commitPrefixes[prefix!] = (commitPrefixes[prefix] ?? 0) + 1;
          conventionalCount++;
        }

        sampleCommits.add(CommitQuality(
          sha: sha.substring(0, 7),
          message: message.split('\n').first,
          messageLength: message.length,
          hasPrefix: hasPrefix,
          prefix: prefix,
          isConventional: hasPrefix,
          filesChanged: 0,
          additions: 0,
          deletions: 0,
        ));
      }

      // Analyze PR turnaround time
      for (final pr in prsData.where((p) => p['merged_at'] != null).take(50)) {
        final createdAt = DateTime.tryParse(pr['created_at'] ?? '');
        final mergedAt = DateTime.tryParse(pr['merged_at'] ?? '');
        if (createdAt != null && mergedAt != null) {
          totalPrTurnaround += mergedAt.difference(createdAt).inHours;
          mergedPrCount++;
        }

        final additions = pr['additions'] as int? ?? 0;
        final deletions = pr['deletions'] as int? ?? 0;
        totalPrSize += additions + deletions;
      }

      // Calculate velocity
      int recentCommitCount = 0;
      for (final commit in recentCommits) {
        final dateStr = commit['commit']?['committer']?['date'] as String?;
        if (dateStr != null) {
          final date = DateTime.tryParse(dateStr);
          if (date != null && date.isAfter(thirtyDaysAgo)) {
            recentCommitCount++;
          }
        }
      }

      // Determine branching strategy
      String branchingStrategy = 'unknown';
      final branchesData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/branches?per_page=30',
        token,
      );
      final branchNames = branchesData.map((b) => (b['name'] as String).toLowerCase()).toList();
      if (branchNames.contains('develop') || branchNames.contains('development')) {
        branchingStrategy = 'gitflow';
      } else if (branchNames.length <= 3) {
        branchingStrategy = 'trunk-based';
      } else {
        branchingStrategy = 'feature-branch';
      }

      // Determine primary merge strategy
      String mergeStrategy = 'merge';
      // This would require more API calls to determine accurately

      // Calculate score
      final conventionalRatio = recentCommits.isNotEmpty ? conventionalCount / recentCommits.length : 0.0;
      double score = 50.0;
      score += conventionalRatio * 30;
      if (mergedPrCount > 0 && totalPrTurnaround / mergedPrCount < 48) score += 10;
      if (branchingStrategy != 'unknown') score += 10;

      // Generate recommendations
      final recommendations = <String>[];
      if (conventionalRatio < 0.5) {
        recommendations.add('Adopt conventional commit messages (feat:, fix:, docs:, etc.)');
      }
      if (mergedPrCount > 0 && totalPrTurnaround / mergedPrCount > 168) {
        recommendations.add('PR turnaround time is high - consider more frequent code reviews');
      }
      if (branchingStrategy == 'unknown') {
        recommendations.add('Consider establishing a clear branching strategy');
      }

      return GitWorkflowAnalysis(
        totalCommits: recentCommits.length,
        recentCommits: recentCommitCount,
        avgCommitsPerWeek: recentCommitCount / 4.0,
        conventionalCommitRatio: conventionalRatio,
        primaryMergeStrategy: mergeStrategy,
        avgPrTurnaround: mergedPrCount > 0 ? totalPrTurnaround / mergedPrCount : 0,
        avgPrSize: mergedPrCount > 0 ? totalPrSize ~/ mergedPrCount : 0,
        commitPrefixes: commitPrefixes,
        sampleCommits: sampleCommits.take(10).toList(),
        commitQualityScore: score.clamp(0, 100),
        branchingStrategy: branchingStrategy,
        workflowRecommendations: recommendations,
      );
    } catch (e) {
      debugPrint('Git workflow analysis error: $e');
      return GitWorkflowAnalysis.empty();
    }
  }

  // ==========================================================================
  // ITERATION 7: CI/CD Pipeline Analysis
  // ==========================================================================

  Future<CiCdAnalysis> _analyzeCiCd({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> contentsData,
  }) async {
    final workflows = <WorkflowInfo>[];
    bool hasGitHubActions = false;
    bool hasTravisCI = false;
    bool hasCircleCI = false;
    bool hasJenkinsfile = false;
    bool hasTestStage = false;
    bool hasLintStage = false;
    bool hasBuildStage = false;
    bool hasDeployStage = false;
    bool hasSecurityScan = false;

    try {
      final fileNames = contentsData.map((c) => c['name'].toString().toLowerCase()).toSet();

      // Check for CI/CD config files
      hasTravisCI = fileNames.contains('.travis.yml');
      hasJenkinsfile = fileNames.contains('jenkinsfile');
      hasCircleCI = fileNames.any((f) => f.contains('circleci'));

      // Check for GitHub Actions
      if (fileNames.contains('.github')) {
        final githubContents = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/contents/.github',
          token,
        );
        if (githubContents.any((c) => c['name'].toString().toLowerCase() == 'workflows')) {
          hasGitHubActions = true;

          // Fetch workflow files
          final workflowsContents = await _fetchJsonList(
            'https://api.github.com/repos/$owner/$repo/contents/.github/workflows',
            token,
          );

          for (final wf in workflowsContents.where((w) => w['name'].toString().endsWith('.yml') || w['name'].toString().endsWith('.yaml'))) {
            final workflowContent = await _fetchFileContent(owner, repo, '.github/workflows/${wf['name']}', token);

            String trigger = 'unknown';
            if (workflowContent != null) {
              if (workflowContent.contains('push:')) trigger = 'push';
              if (workflowContent.contains('pull_request:')) trigger = 'pull_request';
              if (workflowContent.contains('schedule:')) trigger = 'schedule';
              if (workflowContent.contains('workflow_dispatch:')) trigger = 'manual';

              // Check for stages
              final contentLower = workflowContent.toLowerCase();
              if (contentLower.contains('test') || contentLower.contains('jest') || contentLower.contains('pytest')) hasTestStage = true;
              if (contentLower.contains('lint') || contentLower.contains('eslint') || contentLower.contains('flake8')) hasLintStage = true;
              if (contentLower.contains('build') || contentLower.contains('compile')) hasBuildStage = true;
              if (contentLower.contains('deploy') || contentLower.contains('release')) hasDeployStage = true;
              if (contentLower.contains('security') || contentLower.contains('snyk') || contentLower.contains('codeql')) hasSecurityScan = true;
            }

            workflows.add(WorkflowInfo(
              name: wf['name'].toString().replaceAll(RegExp(r'\.(yml|yaml)$'), ''),
              path: '.github/workflows/${wf['name']}',
              trigger: trigger,
              isActive: true,
              runsLast30Days: 0, // Would need workflow runs API
              successRate: 0,
              avgDurationSeconds: 0,
            ));
          }
        }
      }

      // Calculate pipeline score
      double score = 0;
      if (hasGitHubActions || hasTravisCI || hasCircleCI || hasJenkinsfile) score += 30;
      if (hasTestStage) score += 20;
      if (hasLintStage) score += 15;
      if (hasBuildStage) score += 15;
      if (hasDeployStage) score += 10;
      if (hasSecurityScan) score += 10;

      // Identify missing stages
      final missingStages = <String>[];
      if (!hasTestStage) missingStages.add('Automated Testing');
      if (!hasLintStage) missingStages.add('Code Linting');
      if (!hasBuildStage) missingStages.add('Build Verification');
      if (!hasDeployStage) missingStages.add('Deployment Automation');
      if (!hasSecurityScan) missingStages.add('Security Scanning');

      // Generate recommendations
      final recommendations = <String>[];
      if (!hasGitHubActions && !hasTravisCI && !hasCircleCI) {
        recommendations.add('Set up CI/CD pipeline using GitHub Actions or similar');
      }
      if (!hasTestStage) {
        recommendations.add('Add automated tests to your CI pipeline');
      }
      if (!hasSecurityScan) {
        recommendations.add('Consider adding security scanning (CodeQL, Snyk, etc.)');
      }

      return CiCdAnalysis(
        hasGitHubActions: hasGitHubActions,
        hasTravisCI: hasTravisCI,
        hasCircleCI: hasCircleCI,
        hasJenkinsfile: hasJenkinsfile,
        totalWorkflows: workflows.length,
        workflows: workflows,
        overallSuccessRate: 0,
        avgBuildTime: 0,
        hasTestStage: hasTestStage,
        hasLintStage: hasLintStage,
        hasBuildStage: hasBuildStage,
        hasDeployStage: hasDeployStage,
        hasSecurityScan: hasSecurityScan,
        pipelineScore: score.clamp(0, 100),
        missingStages: missingStages,
        recommendations: recommendations,
      );
    } catch (e) {
      debugPrint('CI/CD analysis error: $e');
      return CiCdAnalysis.empty();
    }
  }

  // ==========================================================================
  // ITERATION 8: Documentation Completeness Analysis
  // ==========================================================================

  Future<DocumentationAnalysis> _analyzeDocumentation({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> contentsData,
    String? readmeContent,
  }) async {
    try {
      final fileNames = contentsData.map((c) => c['name'].toString().toLowerCase()).toSet();

      final hasReadme = readmeContent != null && readmeContent.isNotEmpty;
      final readmeLength = readmeContent?.length ?? 0;
      final readmeLower = readmeContent?.toLowerCase() ?? '';

      // Check README sections
      final readmeHasInstallation = readmeLower.contains('install') || readmeLower.contains('getting started');
      final readmeHasUsage = readmeLower.contains('usage') || readmeLower.contains('how to use') || readmeLower.contains('example');
      final readmeHasApi = readmeLower.contains('api') || readmeLower.contains('reference');
      final readmeHasContributing = readmeLower.contains('contribut');
      final readmeHasLicense = readmeLower.contains('license');
      final readmeHasBadges = readmeLower.contains('![') || readmeLower.contains('badge');

      // Check for other documentation files
      final hasContributingFile = fileNames.any((f) => f.contains('contributing'));
      final hasCodeOfConduct = fileNames.any((f) => f.contains('code_of_conduct'));
      final hasChangelog = fileNames.any((f) => f.contains('changelog') || f.contains('history'));
      final hasApiDocs = fileNames.any((f) => f == 'docs' || f == 'api' || f == 'documentation');

      // Check for wiki
      bool hasWiki = false;
      try {
        final repoInfo = await _fetchJson('https://api.github.com/repos/$owner/$repo', token);
        hasWiki = repoInfo['has_wiki'] == true;
      } catch (_) {}

      // Calculate documentation score
      double score = 0;
      if (hasReadme) score += 20;
      if (readmeLength > 500) score += 10;
      if (readmeLength > 2000) score += 5;
      if (readmeHasInstallation) score += 10;
      if (readmeHasUsage) score += 10;
      if (readmeHasApi) score += 5;
      if (readmeHasBadges) score += 5;
      if (hasContributingFile) score += 10;
      if (hasCodeOfConduct) score += 5;
      if (hasChangelog) score += 10;
      if (hasApiDocs) score += 5;
      if (hasWiki) score += 5;

      // Identify missing sections
      final missingSections = <String>[];
      if (!hasReadme) missingSections.add('README.md');
      if (!readmeHasInstallation) missingSections.add('Installation instructions');
      if (!readmeHasUsage) missingSections.add('Usage examples');
      if (!hasContributingFile) missingSections.add('CONTRIBUTING.md');
      if (!hasChangelog) missingSections.add('CHANGELOG.md');

      // Generate recommendations
      final recommendations = <String>[];
      if (!hasReadme || readmeLength < 200) {
        recommendations.add('Create or expand README.md with project overview');
      }
      if (!readmeHasInstallation) {
        recommendations.add('Add installation instructions to README');
      }
      if (!readmeHasUsage) {
        recommendations.add('Add usage examples to README');
      }
      if (!hasContributingFile && !readmeHasContributing) {
        recommendations.add('Create CONTRIBUTING.md to guide contributors');
      }
      if (!hasChangelog) {
        recommendations.add('Maintain a CHANGELOG.md for release notes');
      }
      if (!readmeHasBadges) {
        recommendations.add('Add status badges (build, coverage, version) to README');
      }

      return DocumentationAnalysis(
        hasReadme: hasReadme,
        readmeLength: readmeLength,
        readmeHasInstallation: readmeHasInstallation,
        readmeHasUsage: readmeHasUsage,
        readmeHasApi: readmeHasApi,
        readmeHasContributing: readmeHasContributing,
        readmeHasLicense: readmeHasLicense,
        readmeHasBadges: readmeHasBadges,
        hasContributingFile: hasContributingFile,
        hasCodeOfConduct: hasCodeOfConduct,
        hasChangelog: hasChangelog,
        hasApiDocs: hasApiDocs,
        hasWiki: hasWiki,
        commentRatio: 0, // Would need code analysis
        inlineDocsCount: 0,
        documentationScore: score.clamp(0, 100),
        missingSections: missingSections,
        recommendations: recommendations,
      );
    } catch (e) {
      debugPrint('Documentation analysis error: $e');
      return DocumentationAnalysis.empty();
    }
  }

  // ==========================================================================
  // ITERATION 9: Release Management Analysis
  // ==========================================================================

  Future<ReleaseAnalysis> _analyzeReleases({
    required String owner,
    required String repo,
    required String? token,
  }) async {
    try {
      // Fetch releases
      final releasesData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/releases?per_page=100',
        token,
      );

      final now = DateTime.now();
      final oneYearAgo = now.subtract(const Duration(days: 365));
      int releasesLastYear = 0;
      int semverCompliant = 0;
      int totalReleaseNotesLength = 0;
      int releasesWithNotes = 0;

      final recentReleases = <ReleaseInfo>[];

      for (final release in releasesData) {
        final tagName = release['tag_name'] as String? ?? '';
        final name = release['name'] as String? ?? tagName;
        final publishedAtStr = release['published_at'] as String?;
        final publishedAt = publishedAtStr != null ? DateTime.tryParse(publishedAtStr) : null;
        final isPrerelease = release['prerelease'] as bool? ?? false;
        final isDraft = release['draft'] as bool? ?? false;
        final body = release['body'] as String? ?? '';

        if (publishedAt != null && publishedAt.isAfter(oneYearAgo)) {
          releasesLastYear++;
        }

        // Check semver compliance
        if (RegExp(r'^v?\d+\.\d+\.\d+').hasMatch(tagName)) {
          semverCompliant++;
        }

        if (body.isNotEmpty) {
          releasesWithNotes++;
          totalReleaseNotesLength += body.length;
        }

        if (recentReleases.length < 10 && publishedAt != null) {
          recentReleases.add(ReleaseInfo(
            tagName: tagName,
            name: name,
            publishedAt: publishedAt,
            isPrerelease: isPrerelease,
            isDraft: isDraft,
            downloadCount: 0, // Would need assets API
            hasReleaseNotes: body.isNotEmpty,
            releaseNotesLength: body.length,
          ));
        }
      }

      final totalReleases = releasesData.length;
      final semverCompliance = totalReleases > 0 ? semverCompliant / totalReleases : 0.0;
      final avgReleaseFrequency = releasesLastYear / 12.0;
      final releaseNotesQuality = releasesWithNotes > 0
          ? (totalReleaseNotesLength / releasesWithNotes / 10).clamp(0.0, 100.0)
          : 0.0;

      DateTime? lastReleaseDate;
      int daysSinceLastRelease = 0;
      if (recentReleases.isNotEmpty) {
        lastReleaseDate = recentReleases.first.publishedAt;
        daysSinceLastRelease = now.difference(lastReleaseDate).inDays;
      }

      // Determine release strategy
      String releaseStrategy = 'unknown';
      if (avgReleaseFrequency >= 2) {
        releaseStrategy = 'rolling';
      } else if (avgReleaseFrequency >= 0.5) {
        releaseStrategy = 'periodic';
      } else if (totalReleases > 0) {
        releaseStrategy = 'milestone-based';
      }

      // Calculate score
      double score = 0;
      if (totalReleases > 0) score += 20;
      if (semverCompliance > 0.8) score += 20;
      if (avgReleaseFrequency >= 0.5) score += 15;
      if (releasesWithNotes > totalReleases * 0.5) score += 15;
      if (releaseNotesQuality > 50) score += 15;
      if (daysSinceLastRelease < 90) score += 15;

      // Generate recommendations
      final recommendations = <String>[];
      if (totalReleases == 0) {
        recommendations.add('Start creating releases to track versions');
      }
      if (semverCompliance < 0.8 && totalReleases > 0) {
        recommendations.add('Follow semantic versioning (MAJOR.MINOR.PATCH)');
      }
      if (releasesWithNotes < totalReleases * 0.5 && totalReleases > 0) {
        recommendations.add('Add detailed release notes for each release');
      }
      if (daysSinceLastRelease > 180 && totalReleases > 0) {
        recommendations.add('Consider making a new release - last one was $daysSinceLastRelease days ago');
      }

      return ReleaseAnalysis(
        totalReleases: totalReleases,
        releasesLastYear: releasesLastYear,
        avgReleaseFrequency: avgReleaseFrequency,
        usesSemver: semverCompliance > 0.8,
        semverCompliance: semverCompliance,
        hasLatestRelease: recentReleases.isNotEmpty,
        lastReleaseDate: lastReleaseDate,
        daysSinceLastRelease: daysSinceLastRelease,
        hasReleaseNotes: releasesWithNotes > 0,
        releaseNotesQuality: releaseNotesQuality,
        recentReleases: recentReleases,
        releaseStrategy: releaseStrategy,
        releaseScore: score.clamp(0, 100),
        recommendations: recommendations,
      );
    } catch (e) {
      debugPrint('Release analysis error: $e');
      return ReleaseAnalysis.empty();
    }
  }

  // ==========================================================================
  // ITERATION 10: Security Posture Deep Scan
  // ==========================================================================

  Future<SecurityPostureAnalysis> _analyzeSecurityPosture({
    required String owner,
    required String repo,
    required String? token,
    required List<dynamic> contentsData,
  }) async {
    final findings = <SecurityFinding>[];
    final enabledFeatures = <String>[];
    final missingFeatures = <String>[];

    try {
      final fileNames = contentsData.map((c) => c['name'].toString().toLowerCase()).toSet();

      // Check for security policy
      final hasSecurityPolicy = fileNames.any((f) => f.contains('security'));
      if (hasSecurityPolicy) enabledFeatures.add('Security Policy');
      else missingFeatures.add('Security Policy (SECURITY.md)');

      // Check repository security features via API
      bool hasDependabot = false;
      bool hasCodeScanning = false;
      bool hasSecretScanning = false;
      bool hasBranchProtection = false;
      bool requiresReviews = false;
      bool requiresSignedCommits = false;

      // Check for dependabot
      if (fileNames.contains('.github')) {
        final githubContents = await _fetchJsonList(
          'https://api.github.com/repos/$owner/$repo/contents/.github',
          token,
        );
        hasDependabot = githubContents.any((c) =>
          c['name'].toString().toLowerCase().contains('dependabot'));
        if (hasDependabot) enabledFeatures.add('Dependabot');
        else missingFeatures.add('Dependabot for dependency updates');
      }

      // Check branch protection (requires admin access)
      try {
        final repoInfo = await _fetchJson('https://api.github.com/repos/$owner/$repo', token);
        final defaultBranch = repoInfo['default_branch'] as String? ?? 'main';

        try {
          final protection = await _fetchJson(
            'https://api.github.com/repos/$owner/$repo/branches/$defaultBranch/protection',
            token,
          );
          hasBranchProtection = true;
          enabledFeatures.add('Branch Protection');

          if (protection['required_pull_request_reviews'] != null) {
            requiresReviews = true;
            enabledFeatures.add('Required PR Reviews');
          }
          if (protection['required_signatures'] == true) {
            requiresSignedCommits = true;
            enabledFeatures.add('Signed Commits Required');
          }
        } catch (_) {
          missingFeatures.add('Branch Protection');
        }
      } catch (_) {}

      // Scan for potential secrets in file names
      int secretsDetected = 0;
      final suspiciousPatterns = ['.env', 'credentials', 'secret', 'key', 'token', 'password', 'auth'];
      for (final file in contentsData) {
        final name = file['name'].toString().toLowerCase();
        if (suspiciousPatterns.any((p) => name.contains(p)) && !name.endsWith('.example') && !name.endsWith('.sample')) {
          secretsDetected++;
          findings.add(SecurityFinding(
            type: 'secret',
            severity: 'high',
            title: 'Potential sensitive file',
            description: 'File "${file['name']}" may contain secrets',
            filePath: file['name'].toString(),
          ));
        }
      }

      // Check for security headers in common config files
      final vulnerabilitiesFound = 0;
      final misconfigurationsFound = 0;

      // Check for .gitignore with sensitive patterns
      final gitignoreContent = await _fetchFileContent(owner, repo, '.gitignore', token);
      if (gitignoreContent != null) {
        final gitignoreLower = gitignoreContent.toLowerCase();
        final missingIgnores = <String>[];
        if (!gitignoreLower.contains('.env')) missingIgnores.add('.env');
        if (!gitignoreLower.contains('node_modules')) missingIgnores.add('node_modules');
        if (!gitignoreLower.contains('.secret')) missingIgnores.add('*.secret');

        if (missingIgnores.isNotEmpty) {
          findings.add(SecurityFinding(
            type: 'misconfiguration',
            severity: 'medium',
            title: '.gitignore may be missing patterns',
            description: 'Consider adding: ${missingIgnores.join(", ")}',
            filePath: '.gitignore',
          ));
        }
      } else {
        findings.add(SecurityFinding(
          type: 'misconfiguration',
          severity: 'medium',
          title: 'No .gitignore file found',
          description: 'Add .gitignore to prevent committing sensitive files',
        ));
        missingFeatures.add('.gitignore file');
      }

      // Calculate security score
      double score = 50.0;
      if (hasSecurityPolicy) score += 10;
      if (hasDependabot) score += 10;
      if (hasBranchProtection) score += 10;
      if (requiresReviews) score += 10;
      if (secretsDetected == 0) score += 10;
      score -= secretsDetected * 5;
      score -= findings.where((f) => f.severity == 'high').length * 5;
      score -= findings.where((f) => f.severity == 'medium').length * 2;

      // Determine risk level
      String riskLevel;
      if (score >= 80) riskLevel = 'low';
      else if (score >= 60) riskLevel = 'medium';
      else if (score >= 40) riskLevel = 'high';
      else riskLevel = 'critical';

      // Generate recommendations
      final recommendations = <String>[];
      if (!hasSecurityPolicy) {
        recommendations.add('Add SECURITY.md with vulnerability reporting instructions');
      }
      if (!hasDependabot) {
        recommendations.add('Enable Dependabot for automated dependency updates');
      }
      if (!hasBranchProtection) {
        recommendations.add('Enable branch protection on main branch');
      }
      if (!requiresReviews) {
        recommendations.add('Require PR reviews before merging');
      }
      if (secretsDetected > 0) {
        recommendations.add('Review and remove potential secrets from repository');
      }

      return SecurityPostureAnalysis(
        hasSecurityPolicy: hasSecurityPolicy,
        hasSecurityAdvisories: false, // Would need security advisories API
        hasDependabot: hasDependabot,
        hasCodeScanning: hasCodeScanning,
        hasSecretScanning: hasSecretScanning,
        hasBranchProtection: hasBranchProtection,
        requiresReviews: requiresReviews,
        requiresSignedCommits: requiresSignedCommits,
        secretsDetected: secretsDetected,
        vulnerabilitiesFound: vulnerabilitiesFound,
        misconfigurationsFound: findings.where((f) => f.type == 'misconfiguration').length,
        findings: findings,
        securityScore: score.clamp(0, 100),
        riskLevel: riskLevel,
        enabledSecurityFeatures: enabledFeatures,
        missingSecurityFeatures: missingFeatures,
        recommendations: recommendations,
      );
    } catch (e) {
      debugPrint('Security posture analysis error: $e');
      return SecurityPostureAnalysis.empty();
    }
  }

  // ==========================================================================
  // ITERATION 5: AI-Powered Actionable Roadmap
  // ==========================================================================

  Future<ActionableRoadmap?> _generateActionableRoadmap({
    required String aiApiKey,
    required AIProvider aiProvider,
    required QualityAnalysis quality,
    required DependencyAnalysis dependencyAnalysis,
    required TechDebtAnalysis techDebtAnalysis,
    required ContributorInsights contributorInsights,
  }) async {
    try {
      final context = '''
Repository Analysis Summary:

QUALITY SCORES:
- Overall: ${quality.overallScore.toInt()}/100
- Documentation: ${quality.documentationScore.toInt()}/100
- Testing: ${quality.testCoverageScore.toInt()}/100
- Maintenance: ${quality.maintenanceScore.toInt()}/100
- Security: ${quality.securityScore.toInt()}/100

DEPENDENCY ANALYSIS:
- Total dependencies: ${dependencyAnalysis.totalDependencies}
- Outdated: ${dependencyAnalysis.outdatedCount}
- Vulnerable: ${dependencyAnalysis.vulnerableCount}
- Health score: ${dependencyAnalysis.healthScore.toInt()}/100

TECHNICAL DEBT:
- TODO comments: ${techDebtAnalysis.todoCount}
- FIXME comments: ${techDebtAnalysis.fixmeCount}
- HACK comments: ${techDebtAnalysis.hackCount}
- Large files needing refactoring: ${techDebtAnalysis.largeFilesCount}

CONTRIBUTOR INSIGHTS:
- Bus factor: ${contributorInsights.busFactor} (${contributorInsights.busFactorRisk} risk)
- Active contributors: ${contributorInsights.activeContributors}

QUALITY CHECKLIST:
- README: ${quality.hasReadme ? 'Yes' : 'No'}
- License: ${quality.hasLicense ? 'Yes' : 'No'}
- Contributing guide: ${quality.hasContributing ? 'Yes' : 'No'}
- CI/CD: ${quality.hasCi ? 'Yes' : 'No'}
- Tests: ${quality.hasTests ? 'Yes' : 'No'}
- Security policy: ${quality.hasSecurityPolicy ? 'Yes' : 'No'}
''';

      final response = await _callAiApi(
        apiKey: aiApiKey,
        provider: aiProvider,
        prompt: '''Based on this repository analysis, generate a prioritized improvement roadmap.

$context

Generate a JSON response with this exact structure:
{
  "critical": [{"title": "...", "description": "...", "category": "security|maintenance|documentation|testing"}],
  "high": [{"title": "...", "description": "...", "category": "..."}],
  "medium": [{"title": "...", "description": "...", "category": "..."}],
  "low": [{"title": "...", "description": "...", "category": "..."}],
  "assessment": "Brief 2-3 sentence overall assessment and predicted impact of implementing these changes"
}

Focus on actionable, specific improvements. Include 2-4 items per priority level based on the data above.''',
      );

      if (response != null) {
        // Try to parse JSON from response
        final jsonMatch = RegExp(r'\{[\s\S]*\}').firstMatch(response);
        if (jsonMatch != null) {
          final data = json.decode(jsonMatch.group(0)!) as Map<String, dynamic>;

          return ActionableRoadmap(
            criticalItems: _parseRoadmapItems(data['critical'] as List? ?? [], 'critical'),
            highPriorityItems: _parseRoadmapItems(data['high'] as List? ?? [], 'high'),
            mediumPriorityItems: _parseRoadmapItems(data['medium'] as List? ?? [], 'medium'),
            lowPriorityItems: _parseRoadmapItems(data['low'] as List? ?? [], 'low'),
            overallAssessment: data['assessment'] as String?,
          );
        }
      }
    } catch (e) {
      debugPrint('Roadmap generation error: $e');
    }
    return null;
  }

  List<RoadmapItem> _parseRoadmapItems(List<dynamic> items, String priority) {
    return items.map((item) {
      final map = item as Map<String, dynamic>;
      return RoadmapItem(
        title: map['title'] as String? ?? 'Untitled',
        description: map['description'] as String? ?? '',
        priority: priority,
        category: map['category'] as String? ?? 'maintenance',
      );
    }).toList();
  }

  /// Perform AI-powered analysis of PRs and Issues
  Future<AIInsights?> _performAiAnalysis({
    required String owner,
    required String repo,
    required String? token,
    required String aiApiKey,
    required AIProvider aiProvider,
  }) async {
    debugPrint('Starting AI analysis with provider: $aiProvider');
    debugPrint('AI API Key length: ${aiApiKey.length}');
    try {
      final threeMonthsAgo = DateTime.now().subtract(const Duration(days: 90));
      final sinceDate = threeMonthsAgo.toIso8601String();

      // Fetch merged PRs from last 3 months
      _updateProgress(AnalysisPhase.aiAnalyzingPrs, 'Fetching merged PRs for AI analysis...', 84);
      final mergedPrsData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/pulls?state=closed&sort=updated&direction=desc&per_page=100',
        token,
      );

      // Filter to merged PRs in last 3 months
      final recentMergedPrs = mergedPrsData.where((pr) {
        final mergedAt = pr['merged_at'];
        if (mergedAt == null) return false;
        final mergedDate = DateTime.tryParse(mergedAt);
        return mergedDate != null && mergedDate.isAfter(threeMonthsAgo);
      }).take(50).toList();

      // Fetch latest 50 PRs (all states)
      final latestPrsData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/pulls?state=all&sort=created&direction=desc&per_page=50',
        token,
      );

      // Fetch issues from last 3 months
      _updateProgress(AnalysisPhase.aiAnalyzingIssues, 'Fetching issues for AI analysis...', 87);
      final recentIssuesData = await _fetchJsonList(
        'https://api.github.com/repos/$owner/$repo/issues?state=all&since=$sinceDate&sort=created&direction=desc&per_page=100',
        token,
      );

      // Filter out PRs from issues (GitHub API returns PRs as issues)
      final recentIssues = recentIssuesData
          .where((i) => i['pull_request'] == null)
          .take(100)
          .toList();

      // Prepare data for AI analysis
      _updateProgress(AnalysisPhase.aiAnalyzingPrs, 'AI analyzing pull requests...', 89);

      // Build merged PRs summary
      final mergedPrsSummary = recentMergedPrs.map((pr) {
        final title = pr['title'] ?? '';
        final body = (pr['body'] ?? '').toString();
        final labels = (pr['labels'] as List?)?.map((l) => l['name']).join(', ') ?? '';
        // Truncate body to avoid token limits
        final truncatedBody = body.length > 500 ? '${body.substring(0, 500)}...' : body;
        return '- **${pr['number']}**: $title${labels.isNotEmpty ? ' [Labels: $labels]' : ''}\n  $truncatedBody';
      }).join('\n\n');

      // Build latest PRs summary
      final latestPrsSummary = latestPrsData.map((pr) {
        final title = pr['title'] ?? '';
        final body = (pr['body'] ?? '').toString();
        final state = pr['state'] ?? '';
        final labels = (pr['labels'] as List?)?.map((l) => l['name']).join(', ') ?? '';
        final truncatedBody = body.length > 300 ? '${body.substring(0, 300)}...' : body;
        return '- **#${pr['number']}** [$state]: $title${labels.isNotEmpty ? ' [Labels: $labels]' : ''}\n  $truncatedBody';
      }).join('\n\n');

      // Build issues summary
      final issuesSummary = recentIssues.map((issue) {
        final title = issue['title'] ?? '';
        final body = (issue['body'] ?? '').toString();
        final state = issue['state'] ?? '';
        final labels = (issue['labels'] as List?)?.map((l) => l['name']).join(', ') ?? '';
        final truncatedBody = body.length > 300 ? '${body.substring(0, 300)}...' : body;
        return '- **#${issue['number']}** [$state]: $title${labels.isNotEmpty ? ' [Labels: $labels]' : ''}\n  $truncatedBody';
      }).join('\n\n');

      // Call AI API for merged PRs analysis
      String? mergedPrAnalysis;
      if (recentMergedPrs.isNotEmpty) {
        mergedPrAnalysis = await _callAiApi(
          apiKey: aiApiKey,
          provider: aiProvider,
          prompt: '''Analyze the following merged pull requests from the last 3 months and summarize:
1. What types of improvements/changes were made (features, bug fixes, refactoring, documentation, etc.)
2. Key areas of the codebase that received attention
3. Notable patterns or trends in development

Be concise but comprehensive. Use bullet points for clarity.

Merged Pull Requests:
$mergedPrsSummary''',
        );
      }

      // Call AI API for upcoming PRs analysis
      _updateProgress(AnalysisPhase.aiAnalyzingPrs, 'AI analyzing upcoming changes...', 91);
      String? upcomingPrAnalysis;
      if (latestPrsData.isNotEmpty) {
        upcomingPrAnalysis = await _callAiApi(
          apiKey: aiApiKey,
          provider: aiProvider,
          prompt: '''Analyze the following latest 50 pull requests and summarize:
1. What improvements/features are being worked on or proposed
2. Current development focus areas
3. Upcoming changes users can expect

Be concise but comprehensive. Use bullet points for clarity.

Latest Pull Requests:
$latestPrsSummary''',
        );
      }

      // Call AI API for issues analysis
      _updateProgress(AnalysisPhase.aiAnalyzingIssues, 'AI analyzing user issues...', 93);
      String? issuesAnalysis;
      if (recentIssues.isNotEmpty) {
        issuesAnalysis = await _callAiApi(
          apiKey: aiApiKey,
          provider: aiProvider,
          prompt: '''Analyze the following issues from the last 3 months and summarize:
1. What are users primarily complaining about or requesting?
2. Common pain points or bugs being reported
3. Most requested features or improvements
4. Overall user sentiment and satisfaction indicators

Be concise but comprehensive. Use bullet points for clarity.

Recent Issues:
$issuesSummary''',
        );
      }

      // Generate overall trend
      String? overallTrend;
      if (mergedPrAnalysis != null || upcomingPrAnalysis != null || issuesAnalysis != null) {
        final trendContext = '''
${mergedPrAnalysis != null ? 'Recent Merged PRs Summary:\n$mergedPrAnalysis\n\n' : ''}
${upcomingPrAnalysis != null ? 'Upcoming PRs Summary:\n$upcomingPrAnalysis\n\n' : ''}
${issuesAnalysis != null ? 'Issues Summary:\n$issuesAnalysis' : ''}
''';
        overallTrend = await _callAiApi(
          apiKey: aiApiKey,
          provider: aiProvider,
          prompt: '''Based on the following analysis summaries, provide a brief overall assessment of:
1. The project's development trajectory and health
2. How well the team is addressing user concerns
3. One or two key recommendations for the project

Keep it to 3-4 concise paragraphs.

$trendContext''',
        );
      }

      debugPrint('AI Analysis completed:');
      debugPrint('  - mergedPrAnalysis: ${mergedPrAnalysis != null ? '${mergedPrAnalysis.length} chars' : 'null'}');
      debugPrint('  - upcomingPrAnalysis: ${upcomingPrAnalysis != null ? '${upcomingPrAnalysis.length} chars' : 'null'}');
      debugPrint('  - issuesAnalysis: ${issuesAnalysis != null ? '${issuesAnalysis.length} chars' : 'null'}');
      debugPrint('  - overallTrend: ${overallTrend != null ? '${overallTrend.length} chars' : 'null'}');

      return AIInsights(
        mergedPrSummary: mergedPrAnalysis,
        upcomingPrSummary: upcomingPrAnalysis,
        issuesSummary: issuesAnalysis,
        overallTrend: overallTrend,
      );
    } catch (e, stackTrace) {
      debugPrint('AI Analysis error: $e');
      debugPrint('Stack trace: $stackTrace');
      return null;
    }
  }

  /// Call AI API (Claude or OpenAI)
  Future<String?> _callAiApi({
    required String apiKey,
    required AIProvider provider,
    required String prompt,
  }) async {
    try {
      if (provider == AIProvider.claude) {
        return await _callClaudeApi(apiKey, prompt);
      } else {
        return await _callOpenAiApi(apiKey, prompt);
      }
    } catch (e) {
      debugPrint('AI API call error: $e');
      return null;
    }
  }

  /// Call Claude API
  Future<String?> _callClaudeApi(String apiKey, String prompt) async {
    debugPrint('Calling Claude API...');
    final response = await http.post(
      Uri.parse('https://api.anthropic.com/v1/messages'),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: json.encode({
        'model': 'claude-sonnet-4-20250514',
        'max_tokens': 1024,
        'messages': [
          {
            'role': 'user',
            'content': prompt,
          }
        ],
      }),
    );

    debugPrint('Claude API response status: ${response.statusCode}');
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final content = data['content'] as List?;
      if (content != null && content.isNotEmpty) {
        debugPrint('Claude API returned content successfully');
        return content[0]['text'] as String?;
      }
    } else {
      debugPrint('Claude API error: ${response.statusCode} - ${response.body}');
    }
    return null;
  }

  /// Call OpenAI API
  Future<String?> _callOpenAiApi(String apiKey, String prompt) async {
    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: json.encode({
        'model': 'gpt-4o-mini',
        'messages': [
          {
            'role': 'user',
            'content': prompt,
          }
        ],
        'max_tokens': 1024,
      }),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final choices = data['choices'] as List?;
      if (choices != null && choices.isNotEmpty) {
        return choices[0]['message']['content'] as String?;
      }
    } else {
      debugPrint('OpenAI API error: ${response.statusCode} - ${response.body}');
    }
    return null;
  }

  void cancel() {
    _isAnalyzing = false;
    _currentPhase = AnalysisPhase.failed;
    _currentMessage = 'Cancelled';
    _error = 'Analysis cancelled by user';
    notifyListeners();
  }

  void reset() {
    _currentPhase = AnalysisPhase.initializing;
    _currentMessage = '';
    _progress = 0.0;
    _isAnalyzing = false;
    _error = null;
    _result = null;
    notifyListeners();
  }

  Future<String> getDefaultOutputPath(String repoName) async {
    final docsDir = await getApplicationDocumentsDirectory();
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
    return '${docsDir.path}/github_analyzer/${repoName}_$timestamp.md';
  }
}
