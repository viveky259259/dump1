import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/analyzer_service.dart';
import '../models/analysis_result.dart';
import '../widgets/progress_indicator.dart';
import 'report_screen.dart';

export '../services/analyzer_service.dart' show AIProvider;

class AnalysisScreen extends StatefulWidget {
  final String repoUrl;
  final String? token;
  final String outputPath;
  final bool includeIssues;
  final bool includePrs;
  final bool enableAiAnalysis;
  final String? aiApiKey;
  final AIProvider aiProvider;

  const AnalysisScreen({
    super.key,
    required this.repoUrl,
    this.token,
    required this.outputPath,
    this.includeIssues = true,
    this.includePrs = true,
    this.enableAiAnalysis = false,
    this.aiApiKey,
    this.aiProvider = AIProvider.claude,
  });

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  late AnalyzerService _service;
  bool _hasNavigated = false;

  @override
  void initState() {
    super.initState();
    _service = context.read<AnalyzerService>();
    // Schedule analysis after the first frame to avoid build-phase notifications
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startAnalysis();
    });
  }

  Future<void> _startAnalysis() async {
    _service.reset();
    await _service.analyze(
      repoUrl: widget.repoUrl,
      token: widget.token,
      outputPath: widget.outputPath,
      includeIssues: widget.includeIssues,
      includePrs: widget.includePrs,
      enableAiAnalysis: widget.enableAiAnalysis,
      aiApiKey: widget.aiApiKey,
      aiProvider: widget.aiProvider,
    );
  }

  void _navigateToReport(AnalysisResult result) {
    if (_hasNavigated) return;
    _hasNavigated = true;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => ReportScreen(result: result),
      ),
    );
  }

  void _cancel() {
    _service.cancel();
    Navigator.of(context).pop();
  }

  void _retry() {
    _hasNavigated = false;
    _startAnalysis();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Analyzing Repository'),
        automaticallyImplyLeading: false,
      ),
      body: Consumer<AnalyzerService>(
        builder: (context, service, child) {
          // Navigate to report when completed
          if (service.currentPhase == AnalysisPhase.completed &&
              service.result != null) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _navigateToReport(service.result!);
            });
          }

          return Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Repository info
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.folder_outlined,
                              size: 48,
                              color: theme.colorScheme.primary,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Repository',
                                    style: theme.textTheme.labelMedium?.copyWith(
                                      color: theme.colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    widget.repoUrl,
                                    style: theme.textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Progress indicator
                    if (service.currentPhase != AnalysisPhase.failed)
                      AnalysisProgressIndicator(
                        phase: service.currentPhase,
                        message: service.currentMessage,
                        progress: service.progress,
                        onCancel: _cancel,
                      ),

                    // Error state
                    if (service.currentPhase == AnalysisPhase.failed) ...[
                      Card(
                        color: theme.colorScheme.errorContainer,
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Column(
                            children: [
                              Icon(
                                Icons.error_outline,
                                size: 64,
                                color: theme.colorScheme.error,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'Analysis Failed',
                                style: theme.textTheme.titleLarge?.copyWith(
                                  color: theme.colorScheme.onErrorContainer,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                service.error ?? 'An unknown error occurred',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: theme.colorScheme.onErrorContainer,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          OutlinedButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: const Text('Go Back'),
                          ),
                          const SizedBox(width: 16),
                          FilledButton(
                            onPressed: _retry,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
