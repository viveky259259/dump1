import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/analyzer_service.dart';
import '../widgets/url_input_field.dart';
import '../widgets/token_input_field.dart';
import 'analysis_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _urlController = TextEditingController();
  final _tokenController = TextEditingController();
  final _outputPathController = TextEditingController();
  final _aiApiKeyController = TextEditingController();
  String? _urlError;
  bool _includeIssues = true;
  bool _includePrs = true;
  bool _enableAiAnalysis = false;
  AIProvider _aiProvider = AIProvider.claude;

  @override
  void initState() {
    super.initState();
    _urlController.addListener(_validateUrl);
    _initOutputPath();
    _loadSavedAiApiKey();
  }

  @override
  void dispose() {
    _urlController.dispose();
    _tokenController.dispose();
    _outputPathController.dispose();
    _aiApiKeyController.dispose();
    super.dispose();
  }

  Future<void> _loadSavedAiApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    final savedKey = prefs.getString('ai_api_key');
    final savedProvider = prefs.getString('ai_provider');
    final savedEnabled = prefs.getBool('ai_enabled');

    // Use post-frame callback to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (savedKey != null && savedKey.isNotEmpty) {
        _aiApiKeyController.text = savedKey;
      }
      setState(() {
        if (savedProvider != null) {
          _aiProvider = savedProvider == 'openai' ? AIProvider.openai : AIProvider.claude;
        }
        if (savedEnabled != null) {
          _enableAiAnalysis = savedEnabled;
        }
      });
    });
  }

  Future<void> _saveAiSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ai_api_key', _aiApiKeyController.text);
    await prefs.setString('ai_provider', _aiProvider == AIProvider.openai ? 'openai' : 'claude');
    await prefs.setBool('ai_enabled', _enableAiAnalysis);
  }

  Future<void> _initOutputPath() async {
    final service = context.read<AnalyzerService>();
    final path = await service.getDefaultOutputPath('repository');
    _outputPathController.text = path;
  }

  void _validateUrl() {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() => _urlError = null);
      return;
    }

    final service = context.read<AnalyzerService>();
    if (!service.validateUrl(url)) {
      setState(() => _urlError = 'Invalid GitHub URL format');
    } else {
      setState(() => _urlError = null);
      _updateOutputPath(url);
    }
  }

  Future<void> _updateOutputPath(String url) async {
    final service = context.read<AnalyzerService>();
    final parsed = service.parseUrl(url);
    if (parsed != null) {
      final (_, repo) = parsed;
      final path = await service.getDefaultOutputPath(repo);
      _outputPathController.text = path;
    }
  }

  Future<void> _selectOutputPath() async {
    final result = await FilePicker.platform.saveFile(
      dialogTitle: 'Save Analysis Report',
      fileName: 'analysis_report.md',
      type: FileType.custom,
      allowedExtensions: ['md'],
    );

    if (result != null) {
      _outputPathController.text = result;
    }
  }

  Future<void> _startAnalysis() async {
    final url = _urlController.text.trim();
    if (url.isEmpty || _urlError != null) {
      return;
    }

    // Save AI settings
    await _saveAiSettings();

    if (!mounted) return;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AnalysisScreen(
          repoUrl: url,
          token: _tokenController.text.isNotEmpty ? _tokenController.text : null,
          outputPath: _outputPathController.text,
          includeIssues: _includeIssues,
          includePrs: _includePrs,
          enableAiAnalysis: _enableAiAnalysis,
          aiApiKey: _enableAiAnalysis ? _aiApiKeyController.text : null,
          aiProvider: _aiProvider,
        ),
      ),
    );
  }

  void _selectRecentUrl(String url) {
    _urlController.text = url;
    _validateUrl();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('GitHub Repository Analyzer'),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header
                Icon(
                  Icons.analytics_outlined,
                  size: 64,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(height: 16),
                Text(
                  'Analyze GitHub Repositories',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Get detailed insights about code structure, quality, and activity',
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),

                // URL Input
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Repository',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        UrlInputField(
                          controller: _urlController,
                          errorText: _urlError,
                          onSubmitted: _startAnalysis,
                        ),
                        const SizedBox(height: 16),
                        TokenInputField(controller: _tokenController),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Output Path
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Output',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _outputPathController,
                          decoration: InputDecoration(
                            labelText: 'Output Path',
                            prefixIcon: const Icon(Icons.folder_outlined),
                            suffixIcon: IconButton(
                              icon: const Icon(Icons.folder_open),
                              onPressed: _selectOutputPath,
                              tooltip: 'Browse',
                            ),
                          ),
                          readOnly: true,
                          onTap: _selectOutputPath,
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Options
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Options',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        SwitchListTile(
                          title: const Text('Include Issues Analysis'),
                          subtitle: const Text('Analyze open and closed issues'),
                          value: _includeIssues,
                          onChanged: (v) => setState(() => _includeIssues = v),
                        ),
                        SwitchListTile(
                          title: const Text('Include Pull Requests Analysis'),
                          subtitle: const Text('Analyze PRs and contributors'),
                          value: _includePrs,
                          onChanged: (v) => setState(() => _includePrs = v),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // AI Analysis
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.auto_awesome,
                              color: theme.colorScheme.primary,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'AI-Powered Analysis',
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        SwitchListTile(
                          title: const Text('Enable AI Analysis'),
                          subtitle: const Text('Get AI insights on PRs and issues'),
                          value: _enableAiAnalysis,
                          onChanged: (v) => setState(() => _enableAiAnalysis = v),
                        ),
                        if (_enableAiAnalysis) ...[
                          const SizedBox(height: 12),
                          SegmentedButton<AIProvider>(
                            segments: const [
                              ButtonSegment(
                                value: AIProvider.claude,
                                label: Text('Claude'),
                                icon: Icon(Icons.smart_toy),
                              ),
                              ButtonSegment(
                                value: AIProvider.openai,
                                label: Text('OpenAI'),
                                icon: Icon(Icons.psychology),
                              ),
                            ],
                            selected: {_aiProvider},
                            onSelectionChanged: (Set<AIProvider> selected) {
                              setState(() => _aiProvider = selected.first);
                            },
                          ),
                          const SizedBox(height: 16),
                          TextField(
                            controller: _aiApiKeyController,
                            decoration: InputDecoration(
                              labelText: _aiProvider == AIProvider.claude
                                  ? 'Claude API Key'
                                  : 'OpenAI API Key',
                              hintText: _aiProvider == AIProvider.claude
                                  ? 'sk-ant-...'
                                  : 'sk-...',
                              prefixIcon: const Icon(Icons.key),
                              helperText: _aiProvider == AIProvider.claude
                                  ? 'Get your key at console.anthropic.com'
                                  : 'Get your key at platform.openai.com',
                            ),
                            obscureText: true,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'AI will analyze:\n• Improvements from merged PRs (last 3 months)\n• Upcoming changes in latest 50 PRs\n• User complaints from recent issues',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // Analyze Button
                FilledButton.icon(
                  onPressed: _urlController.text.isNotEmpty && _urlError == null
                      ? _startAnalysis
                      : null,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Analyze Repository'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),

                const SizedBox(height: 32),

                // Recent URLs
                Consumer<AnalyzerService>(
                  builder: (context, service, child) {
                    if (service.recentUrls.isEmpty) return const SizedBox();

                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Recent',
                                  style: theme.textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                TextButton(
                                  onPressed: service.clearRecentUrls,
                                  child: const Text('Clear'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            ...service.recentUrls.map((url) => ListTile(
                              dense: true,
                              leading: const Icon(Icons.history),
                              title: Text(
                                url,
                                overflow: TextOverflow.ellipsis,
                              ),
                              onTap: () => _selectRecentUrl(url),
                            )),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
