import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/analysis_result.dart';
import '../widgets/markdown_viewer.dart';
import 'home_screen.dart';

class ReportScreen extends StatefulWidget {
  final AnalysisResult result;

  const ReportScreen({
    super.key,
    required this.result,
  });

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  late String _reportContent;

  @override
  void initState() {
    super.initState();
    _loadReport();
  }

  Future<void> _loadReport() async {
    if (widget.result.reportContent != null) {
      setState(() {
        _reportContent = widget.result.reportContent!;
      });
    } else if (widget.result.reportPath != null) {
      try {
        final file = File(widget.result.reportPath!);
        final content = await file.readAsString();
        setState(() {
          _reportContent = content;
        });
      } catch (e) {
        setState(() {
          _reportContent = '# Error\n\nCould not load report: $e';
        });
      }
    } else {
      setState(() {
        _reportContent = '# Error\n\nNo report content available';
      });
    }
  }

  Future<void> _openInFinder() async {
    if (widget.result.reportPath != null) {
      final file = File(widget.result.reportPath!);
      final uri = Uri.file(file.parent.path);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      }
    }
  }

  Future<void> _copyPath() async {
    if (widget.result.reportPath != null) {
      await Clipboard.setData(ClipboardData(text: widget.result.reportPath!));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Path copied to clipboard'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> _openInBrowser() async {
    final uri = Uri.parse(widget.result.htmlUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  void _analyzeAnother() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const HomeScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.result.repoFullName),
        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: _analyzeAnother,
          tooltip: 'Home',
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.open_in_browser),
            onPressed: _openInBrowser,
            tooltip: 'Open on GitHub',
          ),
        ],
      ),
      body: Row(
        children: [
          // Sidebar with summary
          SizedBox(
            width: 300,
            child: Card(
              margin: EdgeInsets.zero,
              shape: const RoundedRectangleBorder(),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Repository summary
                    _SummarySection(
                      title: 'Repository',
                      children: [
                        _SummaryItem(
                          icon: Icons.star_outline,
                          label: 'Stars',
                          value: _formatNumber(widget.result.stars),
                        ),
                        _SummaryItem(
                          icon: Icons.fork_right,
                          label: 'Forks',
                          value: _formatNumber(widget.result.forks),
                        ),
                        _SummaryItem(
                          icon: Icons.bug_report_outlined,
                          label: 'Issues',
                          value: _formatNumber(widget.result.openIssues),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Quality scores
                    _SummarySection(
                      title: 'Quality Score',
                      children: [
                        _ScoreIndicator(
                          label: 'Overall',
                          score: widget.result.quality.overallScore,
                        ),
                        const SizedBox(height: 8),
                        _ScoreBar(
                          label: 'Documentation',
                          score: widget.result.quality.documentationScore,
                        ),
                        _ScoreBar(
                          label: 'Testing',
                          score: widget.result.quality.testCoverageScore,
                        ),
                        _ScoreBar(
                          label: 'Maintenance',
                          score: widget.result.quality.maintenanceScore,
                        ),
                        _ScoreBar(
                          label: 'Security',
                          score: widget.result.quality.securityScore,
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Tech stack
                    if (widget.result.frameworks.isNotEmpty ||
                        widget.result.primaryLanguage != null)
                      _SummarySection(
                        title: 'Tech Stack',
                        children: [
                          if (widget.result.primaryLanguage != null)
                            _SummaryItem(
                              icon: Icons.code,
                              label: 'Language',
                              value: widget.result.primaryLanguage!,
                            ),
                          if (widget.result.frameworks.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: widget.result.frameworks
                                  .map((f) => Chip(
                                        label: Text(f),
                                        visualDensity: VisualDensity.compact,
                                      ))
                                  .toList(),
                            ),
                          ],
                        ],
                      ),

                    const SizedBox(height: 24),

                    // Actions
                    _SummarySection(
                      title: 'Report',
                      children: [
                        if (widget.result.reportPath != null) ...[
                          Text(
                            widget.result.reportPath!,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _openInFinder,
                                  icon: const Icon(Icons.folder_open, size: 18),
                                  label: const Text('Open'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _copyPath,
                                  icon: const Icon(Icons.copy, size: 18),
                                  label: const Text('Copy'),
                                ),
                              ),
                            ],
                          ),
                        ],
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          onPressed: _analyzeAnother,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Analyze Another'),
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(44),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Main content - Markdown report
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    color: theme.colorScheme.outlineVariant,
                  ),
                ),
              ),
              child: MarkdownViewer(data: _reportContent),
            ),
          ),
        ],
      ),
    );
  }

  String _formatNumber(int n) {
    if (n >= 1000000) {
      return '${(n / 1000000).toStringAsFixed(1)}M';
    } else if (n >= 1000) {
      return '${(n / 1000).toStringAsFixed(1)}K';
    }
    return n.toString();
  }
}

class _SummarySection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _SummarySection({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        ...children,
      ],
    );
  }
}

class _SummaryItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _SummaryItem({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.onSurfaceVariant),
          const SizedBox(width: 8),
          Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _ScoreIndicator extends StatelessWidget {
  final String label;
  final double score;

  const _ScoreIndicator({
    required this.label,
    required this.score,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = _getScoreColor(score);

    return Row(
      children: [
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            '${score.toInt()}/100',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ),
      ],
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.orange;
    return Colors.red;
  }
}

class _ScoreBar extends StatelessWidget {
  final String label;
  final double score;

  const _ScoreBar({
    required this.label,
    required this.score,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = _getScoreColor(score);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const Spacer(),
              Text(
                '${score.toInt()}',
                style: theme.textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: score / 100,
              minHeight: 6,
              backgroundColor: theme.colorScheme.surfaceContainerHighest,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.orange;
    return Colors.red;
  }
}
