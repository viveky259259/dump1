import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/app.dart';
import 'src/services/analyzer_service.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => AnalyzerService(),
      child: const GitHubAnalyzerApp(),
    ),
  );
}
