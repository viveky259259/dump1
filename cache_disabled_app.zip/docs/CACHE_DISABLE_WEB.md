# Cache Disable Implementation for Web Applications

## Overview

This document describes the cache disabling techniques implemented in `web/index.html` to ensure that web applications always load the latest version of resources and prevent browser caching issues.

## Implementation

The cache disabling strategy uses two complementary approaches:

### 1. HTML Meta Tags (HTTP Cache Headers)

Located in the `<head>` section of the HTML document:

```html
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
```

#### How It Works

- **`Cache-Control: no-cache, no-store, must-revalidate`**
  - `no-cache`: Forces the browser to revalidate with the server before using cached content
  - `no-store`: Prevents storing any cached version of the response
  - `must-revalidate`: Ensures stale cache entries are not used

- **`Pragma: no-cache`**
  - HTTP/1.0 backward compatibility header
  - Prevents caching in older browsers

- **`Expires: 0`**
  - Sets expiration date to the past
  - Ensures cached content is immediately considered stale

#### Browser Support

These meta tags are equivalent to HTTP response headers and work across all modern browsers. They instruct the browser to:
- Not cache the HTML document
- Always fetch fresh content from the server
- Revalidate cached resources before use

### 2. JavaScript Cache Clearing and Dynamic Script Loading

Located in the `<body>` section:

```javascript
// Unregister Service Workers
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(function(registrations) {
    for(let registration of registrations) {
      registration.unregister();
    }
  });
  
  // Clear all caches
  if ('caches' in window) {
    caches.keys().then(function(names) {
      for (let name of names) {
        caches.delete(name);
      }
    });
  }
}

// Force reload with timestamp
var scriptElement = document.createElement('script');
scriptElement.src = "flutter_bootstrap.js?v=" + new Date().getTime();
scriptElement.async = true;
document.body.appendChild(scriptElement);
```

#### How It Works

**Service Worker Unregistration:**
- Checks if Service Workers are supported
- Retrieves all registered service workers
- Unregisters each service worker to prevent cached content from being served

**Cache API Clearing:**
- Checks if the Cache API is available
- Retrieves all cache names
- Deletes each cache to remove stored resources

**Dynamic Script Loading with Timestamp:**
- Creates a new `<script>` element dynamically
- Appends a timestamp query parameter (`?v=<timestamp>`) to the script URL
- Forces the browser to treat it as a new resource, bypassing cache
- Loads the script asynchronously to avoid blocking page rendering

#### Why This Approach Works

1. **Service Workers**: Can intercept network requests and serve cached content even when HTTP headers say not to cache. Unregistering them removes this layer.

2. **Cache API**: Modern browsers use the Cache API for programmatic caching. Clearing it removes all stored resources.

3. **Timestamp Query Parameter**: Adding a unique timestamp to the URL makes each request unique, forcing the browser to fetch a fresh copy instead of using cached versions.

## Use Cases

This implementation is ideal for:

- **Development environments**: Ensuring developers always see the latest code changes
- **Frequent deployments**: Preventing users from seeing stale versions after updates
- **Debugging**: Eliminating cache-related issues during troubleshooting
- **Progressive Web Apps (PWAs)**: Ensuring service workers don't serve outdated content

## Limitations

1. **Performance Impact**: Disabling cache increases server load and slows page loads
2. **Bandwidth Usage**: Resources are re-downloaded on every page load
3. **Service Worker Persistence**: Service workers may take time to fully unregister
4. **Browser Differences**: Some browsers may handle cache headers differently

## Best Practices

1. **Use selectively**: Only disable cache when necessary (development, critical updates)
2. **Server-side headers**: Complement HTML meta tags with proper HTTP response headers
3. **Version control**: Consider using version numbers instead of timestamps for production
4. **Monitor performance**: Track the impact of cache disabling on user experience

## Testing

To verify cache disabling is working:

1. Open browser DevTools (F12)
2. Go to Network tab
3. Check "Disable cache" option
4. Reload the page
5. Verify resources show status 200 (not 304 Not Modified)
6. Check Response Headers for cache-control directives

## Related Files

- `web/index.html` - Main implementation file
- `local_serve.py` - Server-side cache control configuration
- `docs/CACHING_IMPLEMENTATION.md` - Comprehensive caching documentation

## References

- [MDN: Cache-Control](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control)
- [MDN: Service Worker API](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API)
- [MDN: Cache API](https://developer.mozilla.org/en-US/docs/Web/API/Cache)

