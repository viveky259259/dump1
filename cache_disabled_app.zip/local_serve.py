#!/usr/bin/env python3
"""
Simple HTTP server to serve Flutter web build on port 8090 with optional caching
Usage: python3 local_serve.py [--cache-enable]
"""

import http.server
import socketserver
import os
import sys
import hashlib
import argparse
from pathlib import Path
from email.utils import formatdate

PORT = 8092
BUILD_DIR = Path(__file__).parent / "build" / "web"

# Cache durations (in seconds) when caching is enabled
CACHE_DURATIONS_ENABLED = {
    '.html': 0,           # No cache for HTML (always fresh)
    '.js': 31536000,      # 1 year for JS files
    '.css': 31536000,     # 1 year for CSS files
    '.wasm': 31536000,    # 1 year for WASM files
    '.json': 0,           # No cache for JSON files
    '.png': 31536000,     # 1 year for images
    '.jpg': 31536000,
    '.jpeg': 31536000,
    '.gif': 31536000,
    '.svg': 31536000,
    '.ico': 31536000,
    '.woff': 31536000,    # 1 year for fonts
    '.woff2': 31536000,
    '.ttf': 31536000,
    '.eot': 31536000,
    '.otf': 31536000,
}

# Cache durations (in seconds) when caching is disabled - all 0
CACHE_DURATIONS_DISABLED = {
    '.html': 0,
    '.js': 0,
    '.css': 0,
    '.wasm': 0,
    '.json': 0,
    '.png': 0,
    '.jpg': 0,
    '.jpeg': 0,
    '.gif': 0,
    '.svg': 0,
    '.ico': 0,
    '.woff': 0,
    '.woff2': 0,
    '.ttf': 0,
    '.eot': 0,
    '.otf': 0,
}

class CachingHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP request handler with caching support"""
    
    cache_enabled = False  # Class variable to store cache state
    
    def end_headers(self):
        # Add CORS headers for development
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        super().end_headers()
    
    def do_GET(self):
        """Handle GET requests with caching"""
        # Parse the path
        path = self.translate_path(self.path)
        
        # Handle directory requests - serve index.html
        if os.path.isdir(path):
            # Check for index.html in the directory
            index_path = os.path.join(path, 'index.html')
            if os.path.exists(index_path) and os.path.isfile(index_path):
                path = index_path
            else:
                self.send_error(404, "File not found")
                return
        
        # Check if file exists
        if not os.path.exists(path) or not os.path.isfile(path):
            self.send_error(404, "File not found")
            return
        
        # Get file stats
        stat = os.stat(path)
        file_size = stat.st_size
        modified_time = stat.st_mtime
        
        # Determine content type and cache duration
        ext = os.path.splitext(path)[1].lower()
        content_type = self.guess_type(path)
        
        # Select cache durations based on cache_enabled flag
        cache_durations = CACHE_DURATIONS_ENABLED if self.cache_enabled else CACHE_DURATIONS_DISABLED
        cache_duration = cache_durations.get(ext, 0)
        
        # Handle ETag and conditional requests only if caching is enabled
        if self.cache_enabled:
            etag = hashlib.md5(f"{path}{modified_time}".encode()).hexdigest()
            if_none_match = self.headers.get('If-None-Match')
            if if_none_match == f'"{etag}"':
                self.send_response(304)  # Not Modified
                self.end_headers()
                return
        
        # Read file
        try:
            with open(path, 'rb') as f:
                content = f.read()
        except IOError:
            self.send_error(500, "Error reading file")
            return
        
        # Send response
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(file_size))
        self.send_header('Last-Modified', formatdate(modified_time, usegmt=True))
        
        # Set cache headers based on cache_enabled flag
        if self.cache_enabled:
            if cache_duration > 0:
                # Send ETag for cacheable resources
                etag = hashlib.md5(f"{path}{modified_time}".encode()).hexdigest()
                self.send_header('ETag', f'"{etag}"')
                # Set cache headers with duration
                self.send_header('Cache-Control', f'public, max-age={cache_duration}')
                expires_time = modified_time + cache_duration
                self.send_header('Expires', formatdate(expires_time, usegmt=True))
            else:
                # No cache for specific file types (e.g., HTML, JSON)
                self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
                self.send_header('Pragma', 'no-cache')
                self.send_header('Expires', '0')
        else:
            # Always set no-cache headers when caching is disabled
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
        
        self.end_headers()
        self.wfile.write(content)
    
    def do_HEAD(self):
        """Handle HEAD requests with caching"""
        path = self.translate_path(self.path)
        
        # Handle directory requests - serve index.html
        if os.path.isdir(path):
            # Check for index.html in the directory
            index_path = os.path.join(path, 'index.html')
            if os.path.exists(index_path) and os.path.isfile(index_path):
                path = index_path
            else:
                self.send_error(404, "File not found")
                return
        
        if not os.path.exists(path) or not os.path.isfile(path):
            self.send_error(404, "File not found")
            return
        
        stat = os.stat(path)
        modified_time = stat.st_mtime
        
        ext = os.path.splitext(path)[1].lower()
        cache_durations = CACHE_DURATIONS_ENABLED if self.cache_enabled else CACHE_DURATIONS_DISABLED
        cache_duration = cache_durations.get(ext, 0)
        
        # Handle ETag and conditional requests only if caching is enabled
        if self.cache_enabled:
            etag = hashlib.md5(f"{path}{modified_time}".encode()).hexdigest()
            if_none_match = self.headers.get('If-None-Match')
            if if_none_match == f'"{etag}"':
                self.send_response(304)
                self.end_headers()
                return
        
        self.send_response(200)
        self.send_header('Content-Type', self.guess_type(path))
        self.send_header('Content-Length', str(stat.st_size))
        self.send_header('Last-Modified', formatdate(modified_time, usegmt=True))
        
        # Set cache headers based on cache_enabled flag
        if self.cache_enabled:
            if cache_duration > 0:
                # Send ETag for cacheable resources
                etag = hashlib.md5(f"{path}{modified_time}".encode()).hexdigest()
                self.send_header('ETag', f'"{etag}"')
                # Set cache headers with duration
                self.send_header('Cache-Control', f'public, max-age={cache_duration}')
                expires_time = modified_time + cache_duration
                self.send_header('Expires', formatdate(expires_time, usegmt=True))
            else:
                # No cache for specific file types (e.g., HTML, JSON)
                self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
                self.send_header('Pragma', 'no-cache')
                self.send_header('Expires', '0')
        else:
            # Always set no-cache headers when caching is disabled
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
        
        self.end_headers()
    
    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS"""
        self.send_response(200)
        self.end_headers()

def kill_port(port):
    """Kill any process using the specified port"""
    import subprocess
    import platform
    import time
    
    system = platform.system()
    killed_any = False
    
    try:
        if system == 'Darwin' or system == 'Linux':
            # Try multiple methods to find and kill processes on the port
            methods = [
                # Method 1: lsof with port number
                ['lsof', '-ti', f':{port}'],
                # Method 2: lsof with explicit IPv4
                ['lsof', '-ti', f'TCP:{port}'],
                # Method 3: netstat (Linux) or lsof alternative
            ]
            
            pids_found = set()
            
            # Try lsof methods
            for cmd in methods[:2]:
                try:
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        for pid in result.stdout.strip().split('\n'):
                            pid = pid.strip()
                            if pid and pid.isdigit():
                                pids_found.add(pid)
                except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                    pass
            
            # On Linux, also try netstat + fuser
            if system == 'Linux':
                try:
                    # Try netstat to find PIDs
                    result = subprocess.run(
                        ['netstat', '-tlnp'],
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    if result.returncode == 0:
                        for line in result.stdout.split('\n'):
                            if f':{port}' in line and 'LISTEN' in line:
                                parts = line.split()
                                for i, part in enumerate(parts):
                                    if '/' in part and part.split('/')[0].isdigit():
                                        pid = part.split('/')[0]
                                        if pid.isdigit():
                                            pids_found.add(pid)
                except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                    pass
                
                # Try fuser as a last resort
                try:
                    result = subprocess.run(
                        ['fuser', f'{port}/tcp'],
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        for pid in result.stdout.strip().split():
                            pid = pid.strip()
                            if pid.isdigit():
                                pids_found.add(pid)
                except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                    pass
            
            # Kill all found PIDs
            for pid in pids_found:
                try:
                    # Try graceful kill first
                    subprocess.run(['kill', pid], check=True, timeout=2, capture_output=True)
                    time.sleep(0.2)
                    # Force kill if still running
                    subprocess.run(['kill', '-9', pid], check=True, timeout=2, capture_output=True)
                    print(f"✓ Stopped process {pid} on port {port}")
                    killed_any = True
                except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
                    # Process might already be dead, try force kill anyway
                    try:
                        subprocess.run(['kill', '-9', pid], check=True, timeout=2, capture_output=True)
                        print(f"✓ Force stopped process {pid} on port {port}")
                        killed_any = True
                    except:
                        print(f"Warning: Could not kill process {pid}")
            
            # Wait for port to be released
            if killed_any:
                time.sleep(1.5)
                
        elif system == 'Windows':
            # Windows: use netstat and taskkill
            try:
                result = subprocess.run(
                    ['netstat', '-ano'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    pids_found = set()
                    for line in result.stdout.split('\n'):
                        if f':{port}' in line and 'LISTENING' in line:
                            parts = line.split()
                            if len(parts) > 0:
                                pid = parts[-1]
                                if pid.isdigit():
                                    pids_found.add(pid)
                    
                    for pid in pids_found:
                        try:
                            subprocess.run(
                                ['taskkill', '/F', '/PID', pid],
                                check=True,
                                timeout=5,
                                capture_output=True
                            )
                            print(f"✓ Stopped process {pid} on port {port}")
                            killed_any = True
                        except subprocess.CalledProcessError as e:
                            print(f"Warning: Could not kill process {pid}: {e}")
                    
                    # Wait for port to be released
                    if killed_any:
                        time.sleep(1.5)
            except Exception as e:
                print(f"Warning: Error checking port on Windows: {e}")
                
    except Exception as e:
        print(f"Warning: Could not stop process on port {port}: {e}")
    
    return killed_any

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(
        description='Serve Flutter web build with optional caching',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python3 local_serve.py              # Start server with caching DISABLED (default)
  python3 local_serve.py --cache-enable  # Start server with caching ENABLED
        '''
    )
    parser.add_argument(
        '--cache-enable',
        action='store_true',
        default=False,
        help='Enable caching for static assets (default: disabled)'
    )
    args = parser.parse_args()
    
    # Check if build directory exists
    if not BUILD_DIR.exists():
        print(f"Error: Build directory '{BUILD_DIR}' not found!")
        print("Please run 'flutter build web' first.")
        sys.exit(1)
    
    # Always check and kill any process using the port
    import subprocess
    import platform
    import time
    
    system = platform.system()
    
    def is_port_in_use(port):
        """Check if port is in use"""
        try:
            if system == 'Darwin' or system == 'Linux':
                # Try lsof first
                result = subprocess.run(
                    ['lsof', '-ti', f':{port}'],
                    capture_output=True,
                    text=True,
                    timeout=3
                )
                if result.returncode == 0 and result.stdout.strip():
                    return True
                # Try TCP specific
                result = subprocess.run(
                    ['lsof', '-ti', f'TCP:{port}'],
                    capture_output=True,
                    text=True,
                    timeout=3
                )
                if result.returncode == 0 and result.stdout.strip():
                    return True
                return False
            elif system == 'Windows':
                result = subprocess.run(
                    ['netstat', '-ano'],
                    capture_output=True,
                    text=True,
                    timeout=3
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if f':{port}' in line and 'LISTENING' in line:
                            return True
                return False
        except Exception:
            return False
    
    # Check and kill port with retries
    max_retries = 3
    for attempt in range(max_retries):
        if is_port_in_use(PORT):
            if attempt == 0:
                print(f"Port {PORT} is already in use. Stopping existing process...")
            else:
                print(f"Port {PORT} still in use. Retrying (attempt {attempt + 1}/{max_retries})...")
            
            killed = kill_port(PORT)
            if killed:
                time.sleep(1)
            else:
                time.sleep(0.5)
        else:
            break
    else:
        # Final check after all retries
        if is_port_in_use(PORT):
            print(f"Warning: Port {PORT} may still be in use after {max_retries} attempts.")
            print("The server will attempt to start anyway...")
    
    # Change to build directory
    os.chdir(BUILD_DIR)
    
    # Set cache_enabled on the handler class
    CachingHTTPRequestHandler.cache_enabled = args.cache_enable
    
    # Create server with caching handler
    Handler = CachingHTTPRequestHandler
    
    try:
        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            print(f"Starting server on http://localhost:{PORT}")
            print(f"Serving directory: {BUILD_DIR.absolute()}")
            print(f"Caching: {'ENABLED' if args.cache_enable else 'DISABLED'}")
            print("Press Ctrl+C to stop the server")
            print("")
            httpd.serve_forever()
    except OSError as e:
        if e.errno == 48:  # Address already in use
            print(f"\n✗ Error: Port {PORT} is still in use after attempting to stop it.")
            print(f"Please manually stop the process using port {PORT}.")
            if system == 'Darwin' or system == 'Linux':
                print(f"   You can run: lsof -ti :{PORT} | xargs kill -9")
            elif system == 'Windows':
                print(f"   You can run: netstat -ano | findstr :{PORT}")
        else:
            print(f"\n✗ Error: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\nServer stopped.")
        sys.exit(0)

if __name__ == "__main__":
    main()

