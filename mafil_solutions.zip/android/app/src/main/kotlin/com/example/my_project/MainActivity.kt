package com.mycompany.mafilsolutions

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
