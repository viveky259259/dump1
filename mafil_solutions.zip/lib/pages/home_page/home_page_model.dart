import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/custom_code/advancedController.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  List<String> autoCompleteOptions = [
    'Option 1',
    'Option 2',
    'Option 3',
    'Option 4',
    'Option 5',
    'Option 6'
  ];
  void addToAutoCompleteOptions(String item) => autoCompleteOptions.add(item);
  void removeFromAutoCompleteOptions(String item) =>
      autoCompleteOptions.remove(item);
  void removeAtIndexFromAutoCompleteOptions(int index) =>
      autoCompleteOptions.removeAt(index);
  void insertAtIndexInAutoCompleteOptions(int index, String item) =>
      autoCompleteOptions.insert(index, item);
  void updateAutoCompleteOptionsAtIndex(int index, Function(String) updateFn) =>
      autoCompleteOptions[index] = updateFn(autoCompleteOptions[index]);

  String? onChangeText;

  AdvancedTextEditingController? textFieldController;

  ///  State fields for stateful widgets in this page.

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // Stores action output result for [Custom Class Method - AdvancedTextEditingController.clear] action in Button widget.
  bool? hasCleared;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
