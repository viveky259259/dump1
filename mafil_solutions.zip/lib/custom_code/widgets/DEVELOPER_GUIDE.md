# Flutter Autocomplete - External Controller Management Guide

## How to Control Autocomplete from Outside the Widget

This guide explains how to programmatically control the `Autocomplete` widget's text field from outside the widget (e.g., from your page, a button, or other widgets).

---

## Overview

Flutter's `Autocomplete` widget doesn't expose its internal `TextEditingController` directly. To control it from outside (clearing text, setting values, listening to changes), you need to:

1. Use the `fieldViewBuilder` parameter to access the internal controller
2. Store a reference to that controller externally
3. Use a wrapper class (`AdvancedTextEditingController`) to safely manage the controller reference

---

## The Challenge

The Flutter `Autocomplete` widget provides the `TextEditingController` through the `fieldViewBuilder` callback:

```dart
Autocomplete<String>(
  fieldViewBuilder: (context, textEditingController, focusNode, onFieldSubmitted) {
    // ❌ Problem: How do we access 'textEditingController' from outside?
    return TextField(controller: textEditingController);
  },
)
```

**The controller is scoped inside the callback**, making it inaccessible from outside the widget.

---

## Solution: AdvancedTextEditingController Wrapper

Create a wrapper class that holds a reference to the controller:

```dart
class AdvancedTextEditingController {
  TextEditingController? _controller;

  bool clear() {
    if (_controller == null) return false;
    _controller?.clear();
    return true;
  }

  void set(TextEditingController value) {
    _controller = value;
  }

  TextEditingController? get() => _controller;
}
```

---

## Implementation Steps

### 1. Create Controller Instance in Your Page

In your page's state or model, create an instance:

**Example: HomePage (can be any page)**

```dart
class _YourPageState extends State<YourPage> {
  late YourPageModel _model;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => YourPageModel());

    // Initialize the wrapper controller
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.autocompleteController = AdvancedTextEditingController();
      setState(() {});
    });
  }
}
```

**⚠️ Important:** Initialize in `addPostFrameCallback` to ensure the widget tree is built first.

---

### 2. Connect Controller in fieldViewBuilder

Capture the internal controller and store it in your wrapper:

```dart
Autocomplete<String>(
  optionsBuilder: (textEditingValue) {
    return ['Option 1', 'Option 2', 'Option 3']
        .where((option) => option.toLowerCase().contains(textEditingValue.text.toLowerCase()));
  },
  fieldViewBuilder: (context, textEditingController, focusNode, onFieldSubmitted) {
    // ✅ Store the internal controller in your wrapper
    _model.autocompleteController?.set(textEditingController);
    
    return TextField(
      controller: textEditingController,
      focusNode: focusNode,
      decoration: InputDecoration(
        hintText: 'Search...',
      ),
      onSubmitted: (value) => onFieldSubmitted(),
    );
  },
  onSelected: (selection) {
    print('Selected: $selection');
  },
)
```

---

### 3. Control from Outside the Autocomplete

Now you can control the Autocomplete from anywhere in your page:

```dart
// Clear button (can be anywhere on your page)
ElevatedButton(
  onPressed: () {
    bool? hasCleared = _model.autocompleteController?.clear();
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          hasCleared == true
              ? 'Text field cleared!'
              : 'Failed to clear',
        ),
      ),
    );
    
    setState(() {});
  },
  child: Text('Clear Autocomplete'),
)
```

---

## API Reference

### AdvancedTextEditingController

A wrapper class that provides controlled access to the Autocomplete widget's internal `TextEditingController`.

#### Methods

| Method | Return Type | Description |
|--------|-------------|-------------|
| `clear()` | `bool` | Clears the Autocomplete text field. Returns `true` if successful, `false` if controller is null. |
| `get()` | `TextEditingController?` | Returns the underlying `TextEditingController` for advanced operations (reading text, adding listeners, etc.). |
| `set(TextEditingController)` | `void` | Stores the internal controller reference (called within `fieldViewBuilder`). |

---

## Complete Example

Here's a full working example showing how to use the pattern:

```dart
class _MyPageState extends State<MyPage> {
  late MyPageModel _model;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyPageModel());

    // Step 1: Initialize the wrapper controller
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.autocompleteController = AdvancedTextEditingController();
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Step 2: Use Autocomplete with fieldViewBuilder
        Autocomplete<String>(
          optionsBuilder: (textEditingValue) {
            if (textEditingValue.text.isEmpty) {
              return const Iterable<String>.empty();
            }
            return ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry']
                .where((fruit) => fruit.toLowerCase()
                    .contains(textEditingValue.text.toLowerCase()));
          },
          fieldViewBuilder: (context, textEditingController, focusNode, onFieldSubmitted) {
            // Store the internal controller
            _model.autocompleteController?.set(textEditingController);
            
            return TextField(
              controller: textEditingController,
              focusNode: focusNode,
              decoration: InputDecoration(
                hintText: 'Search fruits...',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (value) => onFieldSubmitted(),
            );
          },
          onSelected: (selection) {
            print('Selected: $selection');
          },
        ),
        
        SizedBox(height: 20),
        
        // Step 3: Control from outside - Clear button
        ElevatedButton(
          onPressed: () {
            _model.autocompleteController?.clear();
            setState(() {});
          },
          child: Text('Clear Autocomplete'),
        ),
      ],
    );
  }
}
```

---

## Common Use Cases

### 1. Clear on Selection Change (e.g., Dropdown, Radio Button)

Clear the Autocomplete when user changes another form field:

```dart
DropdownButton<String>(
  items: ['Category A', 'Category B'].map((value) {
    return DropdownMenuItem(value: value, child: Text(value));
  }).toList(),
  onChanged: (value) {
    // Clear Autocomplete when dropdown changes
    _model.autocompleteController?.clear();
    setState(() {});
  },
)
```

### 2. Clear After Successful Form Submission

```dart
ElevatedButton(
  onPressed: () async {
    // Submit form data
    bool success = await submitForm();
    
    if (success) {
      // Clear Autocomplete after successful submission
      _model.autocompleteController?.clear();
      setState(() {});
    }
  },
  child: Text('Submit'),
)
```

### 3. Read Current Text Value

Access the current text from outside the Autocomplete:

```dart
void printCurrentValue() {
  String? currentText = _model.autocompleteController?.get()?.text;
  print('Current Autocomplete text: $currentText');
}
```

### 4. Set Text Programmatically

Set the Autocomplete text from outside:

```dart
void setDefaultValue() {
  _model.autocompleteController?.get()?.text = 'Default Value';
  setState(() {});
}
```

### 5. Listen to Text Changes

Add a listener to respond to text changes:

```dart
@override
void initState() {
  super.initState();
  
  SchedulerBinding.instance.addPostFrameCallback((_) async {
    _model.autocompleteController = AdvancedTextEditingController();
    
    // Add listener once controller is available
    _model.autocompleteController?.get()?.addListener(() {
      String text = _model.autocompleteController?.get()?.text ?? '';
      print('Text changed to: $text');
      // Perform actions based on text changes
    });
    
    setState(() {});
  });
}
```

### 6. Clear Multiple Autocompletes at Once

If you have multiple Autocomplete widgets on the same page:

```dart
ElevatedButton(
  onPressed: () {
    // Clear all autocomplete fields
    _model.autocompleteController1?.clear();
    _model.autocompleteController2?.clear();
    _model.autocompleteController3?.clear();
    setState(() {});
  },
  child: Text('Clear All'),
)
```

---

## Troubleshooting

### ❌ "Controller is null" Error

**Problem:** Attempting to call `clear()` or `get()` before the wrapper controller is initialized.

**Solution:** 
- Ensure the wrapper is initialized in `addPostFrameCallback` within `initState`
- Always use null-safe operator: `_model.autocompleteController?.clear()`
- Check that the `fieldViewBuilder` has been called (i.e., the Autocomplete widget has been built)

### ❌ Text Doesn't Clear When Calling `clear()`

**Problem:** The internal controller reference isn't properly stored in the wrapper.

**Solution:**
- Verify you're calling `set(textEditingController)` inside the `fieldViewBuilder`
- Ensure the `fieldViewBuilder` is actually being used (not null)
- Make sure you're not recreating new Autocomplete instances on each rebuild

### ❌ `clear()` Returns `false`

**Problem:** The internal `TextEditingController` hasn't been captured yet.

**Solution:**
- The `fieldViewBuilder` must be called at least once before the controller is available
- Wait until after the first build - the controller won't be available in `initState` immediately
- Ensure the Autocomplete widget is visible and rendered on screen

### ❌ Listener Added Multiple Times

**Problem:** Adding listeners in `fieldViewBuilder` causes duplicate listener registrations on rebuilds.

**Solution:**
- Add listeners in `initState` (after initialization) instead of in `fieldViewBuilder`
- Or check if listener already exists before adding: store a flag to track listener registration

```dart
bool _listenerAdded = false;

fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
  _model.autocompleteController?.set(controller);
  
  if (!_listenerAdded) {
    controller.addListener(() {
      // Your listener logic
    });
    _listenerAdded = true;
  }
  
  return TextField(controller: controller);
}
```

---

## Important Notes

### 1. Controller Lifecycle
The `AdvancedTextEditingController` is a **wrapper** around the internal `TextEditingController` provided by Flutter's `Autocomplete` widget via `fieldViewBuilder`. It doesn't own the controller, it just holds a reference.

### 2. Timing Matters
The internal controller only becomes available **after** the `fieldViewBuilder` is called for the first time. This happens during the initial build of the Autocomplete widget.

### 3. State Management
Always call `setState()` (or `safeSetState()` in FlutterFlow) after operations that should trigger UI updates.

### 4. Null Safety
Always use null-safe operators (`?.`) when calling methods on the wrapper, as the internal controller may not be available yet.

### 5. Memory Management
The internal `TextEditingController` is managed by the `Autocomplete` widget and will be disposed automatically. You don't need to manually dispose of it.

### 6. Custom Widget Wrapper
This pattern is already implemented in the `CustomAutoCompleteTextFieldWidget` for easier reuse. You can use that widget directly or implement this pattern in your own custom widgets.

---

## Real-World Example: HomePage Implementation

This repository includes a working example in HomePage that demonstrates:

- Initializing `AdvancedTextEditingController` in `initState`
- Passing the controller to `CustomAutoCompleteTextFieldWidget` (which uses this pattern internally)
- Clearing the Autocomplete text field via a button click
- Displaying success/failure feedback to the user

**See:** `lib/pages/home_page/home_page_widget.dart` for the complete implementation.

---

## Related Files

- `lib/custom_code/advancedController.dart` - `AdvancedTextEditingController` wrapper class
- `lib/custom_code/widgets/custom_auto_complete_text_field_widget.dart` - Pre-built widget using this pattern
- `lib/pages/home_page/home_page_widget.dart` - Working example implementation

---

## Additional Resources

- [Flutter Autocomplete Documentation](https://api.flutter.dev/flutter/material/Autocomplete-class.html)
- [RawAutocomplete Documentation](https://api.flutter.dev/flutter/widgets/RawAutocomplete-class.html) - Lower-level widget with more examples
- [TextEditingController Documentation](https://api.flutter.dev/flutter/widgets/TextEditingController-class.html)

---

## Questions or Issues?

If you encounter any issues or have questions about this pattern, please:
1. Check the troubleshooting section above
2. Review the working example in HomePage
3. Consult the Flutter Autocomplete documentation
4. Ensure you're following the initialization timing correctly

