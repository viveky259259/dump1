// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom widgets

import 'package:google_fonts/google_fonts.dart';

import 'package:substring_highlight/substring_highlight.dart';
import 'package:flutter/scheduler.dart';
import 'package:mafil_solutions/custom_code/advancedController.dart';

class CustomAutoCompleteTextFieldWidget extends StatefulWidget {
  const CustomAutoCompleteTextFieldWidget({
    super.key,
    this.width,
    this.height,
    required this.options,
    this.textEditingController,
    required this.onSelected,
    this.hintText,
    this.initialValue,
    this.onChanged,
    this.onFocusChange,
  });

  final double? width;
  final double? height;
  final List<String> options;
  final String? hintText;
  final String? initialValue;
  final Future Function(String value) onSelected;
  final Future Function(String value)? onChanged;
  final Future Function(bool value)? onFocusChange;
  final AdvancedTextEditingController? textEditingController;

  @override
  State<CustomAutoCompleteTextFieldWidget> createState() =>
      _CustomAutoCompleteTextFieldWidgetState();
}

class _CustomAutoCompleteTextFieldWidgetState
    extends State<CustomAutoCompleteTextFieldWidget> {
  FocusNode? _focusNode;
  final _textFieldKey = GlobalKey();

  @override
  void initState() {
    super.initState();
  }

  Future<void> _handleFocusChange() async {
    if (widget.onFocusChange != null && _focusNode != null) {
      await widget.onFocusChange!(_focusNode!.hasFocus);
    }
  }

  @override
  void dispose() {
    _focusNode?.removeListener(_handleFocusChange);
    super.dispose();
  }

  void listenToController() {
    widget.textEditingController?.get()?.addListener(() {
      widget.onChanged?.call(widget.textEditingController?.get()?.text ?? '');
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: Autocomplete<String>(
        initialValue: TextEditingValue(text: widget.initialValue ?? ''),
        optionsBuilder: (textEditingValue) {
          if (textEditingValue.text == '') {
            return const Iterable<String>.empty();
          }
          return widget.options.where((option) {
            final lowercaseOption = option.toLowerCase();
            return lowercaseOption
                .contains(textEditingValue.text.toLowerCase());
          });
        },
        optionsViewBuilder: (context, onSelected, options) {
          if (widget.textEditingController?.get() == null) {
            return const SizedBox.shrink();
          }
          return AutocompleteOptionsList(
            textFieldKey: _textFieldKey,
            textController:
                widget.textEditingController?.get() ?? TextEditingController(),
            options: options.toList(),
            onSelected: onSelected,
            textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: FlutterFlowTheme.of(context).bodyMediumFamily,
                  letterSpacing: 0.0,
                  useGoogleFonts: GoogleFonts.asMap().containsKey(
                      FlutterFlowTheme.of(context).bodyMediumFamily),
                ),
            textHighlightStyle: TextStyle(),
            elevation: 4.0,
            optionBackgroundColor:
                FlutterFlowTheme.of(context).primaryBackground,
            optionHighlightColor:
                FlutterFlowTheme.of(context).secondaryBackground,
            maxHeight: 200.0,
          );
        },
        onSelected: (String selection) async {
          await widget.onSelected(selection);
          FocusScope.of(context).unfocus();
        },
        fieldViewBuilder: (
          context,
          textEditingController,
          focusNode,
          onEditingComplete,
        ) {
          if (_focusNode != focusNode) {
            _focusNode?.removeListener(_handleFocusChange);
            _focusNode = focusNode;
            _focusNode?.addListener(_handleFocusChange);
          }
          widget.textEditingController?.set(textEditingController);
          if (widget.textEditingController?.get() != null) {
            listenToController();
          }
          return TextFormField(
            key: _textFieldKey,
            controller: textEditingController,
            focusNode: focusNode,
            onEditingComplete: onEditingComplete,
            autofocus: false,
            obscureText: false,
            decoration: InputDecoration(
              isDense: true,
              labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
                    fontFamily: FlutterFlowTheme.of(context).labelMediumFamily,
                    letterSpacing: 0.0,
                    useGoogleFonts: GoogleFonts.asMap().containsKey(
                        FlutterFlowTheme.of(context).labelMediumFamily),
                  ),
              hintText: widget.hintText ?? 'Search...',
              hintStyle: FlutterFlowTheme.of(context).labelMedium.override(
                    fontFamily: FlutterFlowTheme.of(context).labelMediumFamily,
                    letterSpacing: 0.0,
                    useGoogleFonts: GoogleFonts.asMap().containsKey(
                        FlutterFlowTheme.of(context).labelMediumFamily),
                  ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Color(0x00000000),
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Color(0x00000000),
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              errorBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).error,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).error,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              filled: true,
              fillColor: FlutterFlowTheme.of(context).secondaryBackground,
            ),
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: FlutterFlowTheme.of(context).bodyMediumFamily,
                  letterSpacing: 0.0,
                  useGoogleFonts: GoogleFonts.asMap().containsKey(
                      FlutterFlowTheme.of(context).bodyMediumFamily),
                ),
            cursorColor: FlutterFlowTheme.of(context).primaryText,
            enableInteractiveSelection: true,
          );
        },
      ),
    );
  }
}

class AutocompleteOptionsList extends StatelessWidget {
  const AutocompleteOptionsList({
    Key? key,
    required this.textFieldKey,
    required this.textController,
    required this.options,
    required this.onSelected,
    required this.textStyle,
    this.textAlign = TextAlign.start,
    this.optionBackgroundColor,
    this.optionHighlightColor,
    this.textHighlightStyle,
    this.maxHeight,
    this.elevation = 4.0,
  }) : super(key: key);

  final GlobalKey textFieldKey;
  final TextEditingController textController;
  final List<String> options;
  final Function(String) onSelected;
  final Color? optionHighlightColor;
  final Color? optionBackgroundColor;
  final TextStyle textStyle;
  final TextStyle? textHighlightStyle;
  final TextAlign textAlign;
  final double? maxHeight;
  final double elevation;

  @override
  Widget build(BuildContext context) {
    final textFieldBox =
        textFieldKey.currentContext!.findRenderObject() as RenderBox;
    final textFieldWidth = textFieldBox.size.width;
    return Align(
      alignment: Directionality.of(context) == TextDirection.RTL
          ? Alignment.topRight
          : Alignment.topLeft,
      child: Material(
        elevation: elevation,
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: textFieldWidth,
            maxHeight: maxHeight ?? 200,
          ),
          child: ListView.builder(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            itemCount: options.length,
            itemBuilder: (context, index) {
              final option = options.elementAt(index);
              return InkWell(
                onTap: () => onSelected(option),
                child: Builder(builder: (context) {
                  final bool highlight =
                      AutocompleteHighlightedOption.of(context) == index;
                  if (highlight) {
                    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
                      Scrollable.ensureVisible(context, alignment: 0.5);
                    });
                  }
                  return Container(
                    color: highlight
                        ? optionHighlightColor ?? Theme.of(context).focusColor
                        : optionBackgroundColor,
                    padding: const EdgeInsets.all(16.0),
                    child: SubstringHighlight(
                      text: option,
                      term: textController.text,
                      textStyle: textStyle,
                      textAlign: textAlign,
                      textStyleHighlight: textHighlightStyle ?? textStyle,
                    ),
                  );
                }),
              );
            },
          ),
        ),
      ),
    );
  }
}
