import 'package:flutter/material.dart';

class AdvancedTextEditingController {
  TextEditingController? _controller;

  AdvancedTextEditingController() : _controller = TextEditingController();

  bool clear() {
    if (_controller == null) {
      return false;
    }

    _controller?.clear();

    return true;
  }

  void set(TextEditingController value) {
    _controller = value;
  }

  TextEditingController? get() => _controller;
}
