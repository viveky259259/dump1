import '/flutter_flow/flutter_flow_util.dart';
import 'package:watson_l1_app_configuration_ctuwb2/app_constants.dart'
    as watson_l1_app_configuration_ctuwb2_app_constant;
import 'package:watson_l1_auth_logic_z87ikn/app_constants.dart'
    as watson_l1_auth_logic_z87ikn_app_constant;
import 'package:watson_l1_language_support_vlu7e3/app_constants.dart'
    as watson_l1_language_support_vlu7e3_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'create_support_ticket_form_model.dart';
export 'create_support_ticket_form_model.dart';

class CreateSupportTicketFormWidget extends StatefulWidget {
  const CreateSupportTicketFormWidget({super.key});

  @override
  State<CreateSupportTicketFormWidget> createState() =>
      _CreateSupportTicketFormWidgetState();
}

class _CreateSupportTicketFormWidgetState
    extends State<CreateSupportTicketFormWidget> {
  late CreateSupportTicketFormModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CreateSupportTicketFormModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100.0,
      height: 100.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
    );
  }
}
