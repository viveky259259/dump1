import '/flutter_flow/flutter_flow_util.dart';
import 'create_support_ticket_form_widget.dart'
    show CreateSupportTicketFormWidget;
import 'package:watson_l1_app_configuration_ctuwb2/app_constants.dart'
    as watson_l1_app_configuration_ctuwb2_app_constant;
import 'package:watson_l1_auth_logic_z87ikn/app_constants.dart'
    as watson_l1_auth_logic_z87ikn_app_constant;
import 'package:watson_l1_language_support_vlu7e3/app_constants.dart'
    as watson_l1_language_support_vlu7e3_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreateSupportTicketFormModel
    extends FlutterFlowModel<CreateSupportTicketFormWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
