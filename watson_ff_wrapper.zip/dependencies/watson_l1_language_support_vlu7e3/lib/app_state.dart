import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      if (prefs.containsKey('ff_currentLanguage')) {
        try {
          final serializedData = prefs.getString('ff_currentLanguage') ?? '{}';
          _currentLanguage =
              LanguageStruct.fromSerializableMap(jsonDecode(serializedData));
        } catch (e) {
          print("Can't decode persisted data type. Error: $e.");
        }
      }
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  dynamic _translations = jsonDecode('null');
  dynamic get translations => _translations;
  set translations(dynamic value) {
    _translations = value;
  }

  List<LanguageStruct> _supportedLanguages = [
    LanguageStruct.fromSerializableMap(
        jsonDecode('{\"code\":\"en\",\"name\":\"English\"}')),
    LanguageStruct.fromSerializableMap(
        jsonDecode('{\"code\":\"hi\",\"name\":\"Hindi\"}'))
  ];
  List<LanguageStruct> get supportedLanguages => _supportedLanguages;
  set supportedLanguages(List<LanguageStruct> value) {
    _supportedLanguages = value;
  }

  void addToSupportedLanguages(LanguageStruct value) {
    supportedLanguages.add(value);
  }

  void removeFromSupportedLanguages(LanguageStruct value) {
    supportedLanguages.remove(value);
  }

  void removeAtIndexFromSupportedLanguages(int index) {
    supportedLanguages.removeAt(index);
  }

  void updateSupportedLanguagesAtIndex(
    int index,
    LanguageStruct Function(LanguageStruct) updateFn,
  ) {
    supportedLanguages[index] = updateFn(_supportedLanguages[index]);
  }

  void insertAtIndexInSupportedLanguages(int index, LanguageStruct value) {
    supportedLanguages.insert(index, value);
  }

  LanguageStruct _currentLanguage = LanguageStruct();
  LanguageStruct get currentLanguage => _currentLanguage;
  set currentLanguage(LanguageStruct value) {
    _currentLanguage = value;
    prefs.setString('ff_currentLanguage', value.serialize());
  }

  void updateCurrentLanguageStruct(Function(LanguageStruct) updateFn) {
    updateFn(_currentLanguage);
    prefs.setString('ff_currentLanguage', _currentLanguage.serialize());
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
