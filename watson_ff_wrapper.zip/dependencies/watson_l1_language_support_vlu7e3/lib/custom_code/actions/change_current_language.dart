// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:watson_l1_logger_qd3zlg/custom_code/actions/log_error_information.dart'
    as logErrorInformation;

Future changeCurrentLanguage(LanguageStruct languageToSet) async {
  final appState = FFAppState();

  final supportedLanguages = FFAppState().supportedLanguages;

  // Check if the supplied language is supported
  if (!supportedLanguages.contains(languageToSet)) {
    // Log error
    logErrorInformation.logErrorInformation(
      'L1LanguageSupport.changeCurrentLanguage',
      'Supplied language with code ${languageToSet.code} and name ${languageToSet.name} is not supported',
    );
    return;
  }

  // Set the new language in the app state
  appState.update(() {
    appState.currentLanguage = languageToSet;
  });
  // Load translations for the new language
  await loadCurrentLanguageTranslations();
}
