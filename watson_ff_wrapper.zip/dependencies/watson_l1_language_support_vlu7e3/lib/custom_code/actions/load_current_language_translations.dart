// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:watson_l1_logger_qd3zlg/custom_code/actions/log_information.dart'
    as logger;

Future loadCurrentLanguageTranslations() async {
  try {
    final appState = FFAppState();
    // Get the current language code
    final currentLanguageCode = appState.currentLanguage.code;

    final jsonString =
        await rootBundle.loadString('assets/i18n/$currentLanguageCode.json');
    if (jsonString.isNotEmpty) {
      final Map<String, dynamic> jsonMap = json.decode(jsonString);
      appState.update(() {
        appState.translations = {
          ...jsonMap,
        };
      });
    }
  } catch (error, stacktrace) {
    // Log error
    logger.Logger.error(
      'L1LanguageSupport.loadCurrentLanguageTranslations',
      error: error,
      stackTrace: stacktrace,
    );
  }
}
