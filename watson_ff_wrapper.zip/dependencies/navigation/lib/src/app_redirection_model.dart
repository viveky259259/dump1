import 'package:equatable/equatable.dart';

typedef RedirectFunction = Future<dynamic> Function({
  bool replaceRoute,
  bool clearNavigationStack,
});

abstract class AppRedirectionModel extends Equatable {
  String get redirectionPath;
  bool get requiresAuthentication;

  RedirectFunction get redirectFunction;

  const AppRedirectionModel();

  factory AppRedirectionModel.fromJson(Map<String, dynamic> json) {
    throw UnimplementedError('This must be overridden in subclasses');
  }

  Map<String, dynamic> toJson();

  @override
  List<Object?> get props => [
        redirectionPath,
        requiresAuthentication,
      ];
}
