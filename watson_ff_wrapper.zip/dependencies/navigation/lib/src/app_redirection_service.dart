import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import './app_redirection_model.dart';

/// Global navigator key used for routing throughout the app
final GlobalKey<NavigatorState> kAppNavigatorKey = GlobalKey<NavigatorState>();

/// Service class that handles app navigation and redirection
class AppRedirectionService {
  /// Map of registered redirection model factories, keyed by type string
  static final Map<String, AppRedirectionModel Function(Map<String, dynamic>)>
      _redirectionModelFactories = {};

  /// Registers a redirection model factory for a given path
  ///
  /// [redirectionPath] - String identifier for the redirection path
  /// [constructor] - Factory function to create instances of the redirection model
  static void registerRedirectionModel(
    String redirectionPath,
    AppRedirectionModel Function(Map<String, dynamic>) constructor,
  ) {
    _redirectionModelFactories[redirectionPath] = constructor;
  }

  /// Creates a redirection model instance from JSON data
  ///
  /// [json] - Map containing serialized redirection model data
  /// Returns an [AppRedirectionModel] instance
  /// Throws [UnsupportedError] if type is not registered
  static AppRedirectionModel getRedirectModelFromJson(
      Map<String, dynamic> json) {
    final String redirectionPath = json['redirectionPath'];
    if (_redirectionModelFactories.containsKey(redirectionPath)) {
      return _redirectionModelFactories[redirectionPath]!(json);
    } else {
      // TODO: log this error
      throw UnsupportedError(
          'Unknown redirection model path: $redirectionPath');
    }
  }

  /// Pushes a new path onto the navigation stack
  ///
  /// [routePath] - Path of the route to push
  /// [queryParams] - Optional query parameters to pass to the route
  static Future<dynamic> pushPath(
    String routePath, {
    Map<String, dynamic>? queryParams,
  }) async {
    return GoRouter.of(kAppNavigatorKey.currentContext!).push(
      Uri(
        path: routePath,
        queryParameters: queryParams,
      ).toString(),
    );
  }

  /// Pushes a new route path that replaces the current route
  ///
  /// [routePath] - Path of the route to push
  /// [queryParams] - Optional query parameters to pass to the route
  static Future<dynamic> pushPathAndReplace(
    String routePath, {
    Map<String, dynamic>? queryParams,
  }) async {
    return GoRouter.of(kAppNavigatorKey.currentContext!).pushReplacement(
      Uri(
        path: routePath,
        queryParameters: queryParams,
      ).toString(),
    );
  }

  /// Clears the navigation stack and pushes a new route path
  ///
  /// [routePath] - Path of the route to push
  /// [queryParams] - Optional query parameters to pass to the route
  static Future<dynamic> clearStackAndPushPath(
    String routePath, {
    Map<String, dynamic>? queryParams,
  }) async {
    return GoRouter.of(kAppNavigatorKey.currentContext!).go(
      Uri(
        path: routePath,
        queryParameters: queryParams,
      ).toString(),
    );
  }

  /// Handles redirection using the provided redirection model
  ///
  /// [redirectModel] - Model containing redirection logic and data
  /// [replaceRoute] - Whether to replace the current route
  /// [clearNavigationStack] - Whether to clear the navigation stack before redirecting
  static Future<dynamic> redirect(
    AppRedirectionModel redirectModel, {
    bool replaceRoute = false,
    bool clearNavigationStack = false,
  }) async {
    // Handle the redirect for auth guarded redirections

    // Call the handler function for this model
    return redirectModel.redirectFunction(
      replaceRoute: replaceRoute,
      clearNavigationStack: clearNavigationStack,
    );
  }
}
