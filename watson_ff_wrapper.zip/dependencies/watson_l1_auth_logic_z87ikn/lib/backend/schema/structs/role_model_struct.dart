// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RoleModelStruct extends BaseStruct {
  RoleModelStruct({
    int? id,
    String? name,
    List<String>? permissions,
  })  : _id = id,
        _name = name,
        _permissions = permissions;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "permissions" field.
  List<String>? _permissions;
  List<String> get permissions => _permissions ?? const [];
  set permissions(List<String>? val) => _permissions = val;

  void updatePermissions(Function(List<String>) updateFn) {
    updateFn(_permissions ??= []);
  }

  bool hasPermissions() => _permissions != null;

  static RoleModelStruct fromMap(Map<String, dynamic> data) => RoleModelStruct(
        id: castToType<int>(data['id']),
        name: data['name'] as String?,
        permissions: getDataList(data['permissions']),
      );

  static RoleModelStruct? maybeFromMap(dynamic data) => data is Map
      ? RoleModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'name': _name,
        'permissions': _permissions,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'permissions': serializeParam(
          _permissions,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static RoleModelStruct fromSerializableMap(Map<String, dynamic> data) =>
      RoleModelStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        permissions: deserializeParam<String>(
          data['permissions'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'RoleModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is RoleModelStruct &&
        id == other.id &&
        name == other.name &&
        listEquality.equals(permissions, other.permissions);
  }

  @override
  int get hashCode => const ListEquality().hash([id, name, permissions]);
}

RoleModelStruct createRoleModelStruct({
  int? id,
  String? name,
}) =>
    RoleModelStruct(
      id: id,
      name: name,
    );
