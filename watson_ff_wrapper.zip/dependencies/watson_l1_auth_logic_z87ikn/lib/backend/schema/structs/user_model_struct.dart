// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserModelStruct extends BaseStruct {
  UserModelStruct({
    int? id,
    String? name,
    String? email,
    RoleModelStruct? role,
    TeamModelStruct? team,
  })  : _id = id,
        _name = name,
        _email = email,
        _role = role,
        _team = team;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;

  bool hasEmail() => _email != null;

  // "role" field.
  RoleModelStruct? _role;
  RoleModelStruct get role => _role ?? RoleModelStruct();
  set role(RoleModelStruct? val) => _role = val;

  void updateRole(Function(RoleModelStruct) updateFn) {
    updateFn(_role ??= RoleModelStruct());
  }

  bool hasRole() => _role != null;

  // "team" field.
  TeamModelStruct? _team;
  TeamModelStruct get team => _team ?? TeamModelStruct();
  set team(TeamModelStruct? val) => _team = val;

  void updateTeam(Function(TeamModelStruct) updateFn) {
    updateFn(_team ??= TeamModelStruct());
  }

  bool hasTeam() => _team != null;

  static UserModelStruct fromMap(Map<String, dynamic> data) => UserModelStruct(
        id: castToType<int>(data['id']),
        name: data['name'] as String?,
        email: data['email'] as String?,
        role: data['role'] is RoleModelStruct
            ? data['role']
            : RoleModelStruct.maybeFromMap(data['role']),
        team: data['team'] is TeamModelStruct
            ? data['team']
            : TeamModelStruct.maybeFromMap(data['team']),
      );

  static UserModelStruct? maybeFromMap(dynamic data) => data is Map
      ? UserModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'name': _name,
        'email': _email,
        'role': _role?.toMap(),
        'team': _team?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'role': serializeParam(
          _role,
          ParamType.DataStruct,
        ),
        'team': serializeParam(
          _team,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static UserModelStruct fromSerializableMap(Map<String, dynamic> data) =>
      UserModelStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        role: deserializeStructParam(
          data['role'],
          ParamType.DataStruct,
          false,
          structBuilder: RoleModelStruct.fromSerializableMap,
        ),
        team: deserializeStructParam(
          data['team'],
          ParamType.DataStruct,
          false,
          structBuilder: TeamModelStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'UserModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UserModelStruct &&
        id == other.id &&
        name == other.name &&
        email == other.email &&
        role == other.role &&
        team == other.team;
  }

  @override
  int get hashCode => const ListEquality().hash([id, name, email, role, team]);
}

UserModelStruct createUserModelStruct({
  int? id,
  String? name,
  String? email,
  RoleModelStruct? role,
  TeamModelStruct? team,
}) =>
    UserModelStruct(
      id: id,
      name: name,
      email: email,
      role: role ?? RoleModelStruct(),
      team: team ?? TeamModelStruct(),
    );
