// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LoginEventModelStruct extends BaseStruct {
  LoginEventModelStruct({
    bool? success,
  }) : _success = success;

  // "success" field.
  bool? _success;
  bool get success => _success ?? true;
  set success(bool? val) => _success = val;

  bool hasSuccess() => _success != null;

  static LoginEventModelStruct fromMap(Map<String, dynamic> data) =>
      LoginEventModelStruct(
        success: data['success'] as bool?,
      );

  static LoginEventModelStruct? maybeFromMap(dynamic data) => data is Map
      ? LoginEventModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'success': _success,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'success': serializeParam(
          _success,
          ParamType.bool,
        ),
      }.withoutNulls;

  static LoginEventModelStruct fromSerializableMap(Map<String, dynamic> data) =>
      LoginEventModelStruct(
        success: deserializeParam(
          data['success'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'LoginEventModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is LoginEventModelStruct && success == other.success;
  }

  @override
  int get hashCode => const ListEquality().hash([success]);
}

LoginEventModelStruct createLoginEventModelStruct({
  bool? success,
}) =>
    LoginEventModelStruct(
      success: success,
    );
