// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LogoutEventModelStruct extends BaseStruct {
  LogoutEventModelStruct({
    String? message,
  }) : _message = message;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  static LogoutEventModelStruct fromMap(Map<String, dynamic> data) =>
      LogoutEventModelStruct(
        message: data['message'] as String?,
      );

  static LogoutEventModelStruct? maybeFromMap(dynamic data) => data is Map
      ? LogoutEventModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'message': _message,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
      }.withoutNulls;

  static LogoutEventModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      LogoutEventModelStruct(
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'LogoutEventModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is LogoutEventModelStruct && message == other.message;
  }

  @override
  int get hashCode => const ListEquality().hash([message]);
}

LogoutEventModelStruct createLogoutEventModelStruct({
  String? message,
}) =>
    LogoutEventModelStruct(
      message: message,
    );
