package com.mycompany.portfoliocommonlogic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
