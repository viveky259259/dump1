import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';

String generateL1KeyValue(
  String keyPrefix,
  String componentName,
  String widget,
) {
  return '${keyPrefix}_${componentName}_${widget}';
}

String generateL3KeyValuePrefix(
  String moduleName,
  String routeName,
) {
  return '${moduleName}_${routeName}';
}

String generateL2KeyValuePrefix(
  String keyPrefix,
  String componentName,
  String useCase,
) {
  return '${keyPrefix}_${componentName}_${useCase}';
}
