// Automatic FlutterFlow imports
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/init_sentry_reporting.dart';
import "package:watson_l1_app_configuration_ctuwb2/app_state.dart"
    as app_configuration_app_state;

Future logInformation(String? message) async {
  Logger.info(message ?? '');
}

class Logger {
  // Get the report errors flag from environment variables
  static bool get reportError =>
      app_configuration_app_state.FFAppState().appConfiguration.reportError;

  static void info(String message) {
    debugPrint('ℹ️ INFO: $message');
  }

  static void debug(String message) {
    debugPrint('🐛 DEBUG: $message');
  }

  static void warning(String message) {
    debugPrint('⚠️ WARNING: $message');
  }

  static void error(
    String errorTitle, {
    Object? error,
    StackTrace? stackTrace,
  }) {
    debugPrint('❌ ERROR: $errorTitle');
    if (error != null) {
      debugPrint('Error details: $error');
    }
    if (stackTrace != null) {
      debugPrint('Stack trace: $stackTrace');
    }

    if (reportError) {
      // Capture the error with the Sentry SDK
      SentryService().captureError(
        error: error,
        stackTrace: stackTrace,
        errorTitle: errorTitle,
      );
    }
  }

  static void errorInformation(
    String errorTitle,
    String errorBody,
  ) {
    debugPrint('❌ ERROR: $errorTitle');
    debugPrint('Error details: $errorBody');

    if (reportError) {
      // Capture the error with the Sentry SDK
      SentryService().captureError(
        errorTitle: errorTitle,
        errorBody: errorBody,
      );
    }
  }

  static void success(String message) {
    debugPrint('✅ SUCCESS: $message');
  }

  static void network(String message) {
    debugPrint('🌐 NETWORK: $message');
  }

  static void analyticsEvent(
    String event, {
    Map<String, dynamic>? parameters,
  }) {
    debugPrint('📊 ANALYTICS - Event: $event');
    if (parameters != null) {
      debugPrint('Parameters: $parameters');
    }
  }
}
