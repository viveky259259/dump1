// Automatic FlutterFlow imports
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import "package:watson_l1_auth_logic_z87ikn/app_state.dart"
    as auth_logic_app_state;
import "package:watson_l1_app_configuration_ctuwb2/app_state.dart"
    as app_configuration_app_state;

// import 'package:sentry_flutter/sentry_flutter.dart';

Future initSentryReporting() async {
  await SentryService().init();
}

class SentryService {
  static final SentryService _instance = SentryService._internal();

  factory SentryService() {
    return _instance;
  }

  SentryService._internal();

  SentryService get instance => _instance;

  Future<void> init() async {
    // Get the Sentry DSN from the environment variables
    final appConfig = app_configuration_app_state.FFAppState().appConfiguration;
    final sentryDsn = appConfig.sentryDSN;

    // await SentryFlutter.init(
    //   (SentryFlutterOptions options) {
    //     options.dsn = sentryDsn;
    //   },
    // );
  }

  void captureError({
    Object? error,
    StackTrace? stackTrace,
    String? errorTitle,
    String? errorBody,
  }) {
    // Get the app version the global app information
    final appInfo = app_configuration_app_state.FFAppState().appInformation;
    final appVersion = appInfo.version;

    // Get the logged in user data from the global auth information
    final userData = auth_logic_app_state.FFAppState().userProfile;

    final loggedInUserId = userData.id;
    final loggedInUserEmail = userData.email;

    // // Capture the error with the Sentry SDK
    // Sentry.captureException(
    //   error ?? '$errorTitle \n $errorBody',
    //   stackTrace: stackTrace,
    //   withScope: (Scope scope) {
    //     scope.setTag('app.version', appVersion);
    //     scope.setTag('error_title', errorTitle ?? '');
    //     scope.setUser(
    //       SentryUser(
    //         id: loggedInUserId.toString(),
    //         email: loggedInUserEmail,
    //       ),
    //     );
    //   },
    // );
  }
}
