// Automatic FlutterFlow imports
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/log_information.dart';

Future logWarning(String message) async {
  Logger.warning(message);
}
