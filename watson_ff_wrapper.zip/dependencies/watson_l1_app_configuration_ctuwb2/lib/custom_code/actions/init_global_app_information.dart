// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:package_info_plus/package_info_plus.dart';

Future initGlobalAppInformation() async {
  // PackageInfo packageInfo = await PackageInfo.fromPlatform();

  // String appName = packageInfo.appName;
  // String version = packageInfo.version;
  // String buildNumber = packageInfo.buildNumber;

  // FFAppState().appInformation = AppInformationStruct(
  //   name: appName,
  //   version: version,
  //   buildNumber: buildNumber,
  // );
}
