// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import "package:watson_l1_auth_logic_z87ikn/flutter_flow/nav/serialization_util.dart"
    as watson_l1_auth_logic_z87ikn_serialization_util;

class LoginResponseModelStruct extends BaseStruct {
  LoginResponseModelStruct({
    String? token,
    watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct? user,
  })  : _token = token,
        _user = user;

  // "token" field.
  String? _token;
  String get token => _token ?? '';
  set token(String? val) => _token = val;

  bool hasToken() => _token != null;

  // "user" field.
  watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct? _user;
  watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct get user =>
      _user ?? watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct();
  set user(watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct? val) =>
      _user = val;

  void updateUser(
      Function(watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct)
          updateFn) {
    updateFn(
        _user ??= watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct());
  }

  bool hasUser() => _user != null;

  static LoginResponseModelStruct fromMap(Map<String, dynamic> data) =>
      LoginResponseModelStruct(
        token: data['token'] as String?,
        user: data['user']
                is watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct
            ? data['user']
            : watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct
                .maybeFromMap(data['user']),
      );

  static LoginResponseModelStruct? maybeFromMap(dynamic data) => data is Map
      ? LoginResponseModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'token': _token,
        'user': _user?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'token': serializeParam(
          _token,
          ParamType.String,
        ),
        'user': watson_l1_auth_logic_z87ikn_serialization_util.serializeParam(
          _user,
          watson_l1_auth_logic_z87ikn_serialization_util.ParamType.DataStruct,
        ),
      }.withoutNulls;

  static LoginResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      LoginResponseModelStruct(
        token: deserializeParam(
          data['token'],
          ParamType.String,
          false,
        ),
        user: deserializeStructParam(
          data['user'],
          ParamType.DataStruct,
          false,
          structBuilder: watson_l1_auth_logic_z87ikn_data_schema
              .UserModelStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'LoginResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is LoginResponseModelStruct &&
        token == other.token &&
        user == other.user;
  }

  @override
  int get hashCode => const ListEquality().hash([token, user]);
}

LoginResponseModelStruct createLoginResponseModelStruct({
  String? token,
  watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct? user,
}) =>
    LoginResponseModelStruct(
      token: token,
      user: user ?? watson_l1_auth_logic_z87ikn_data_schema.UserModelStruct(),
    );
