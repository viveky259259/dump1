import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import "package:watson_l1_language_support_vlu7e3/backend/schema/structs/index.dart"
    as watson_l1_language_support_vlu7e3_data_schema;
import 'package:watson_l1_app_configuration_ctuwb2/app_constants.dart'
    as watson_l1_app_configuration_ctuwb2_app_constant;
import 'package:watson_l1_auth_logic_z87ikn/app_constants.dart'
    as watson_l1_auth_logic_z87ikn_app_constant;
import 'package:watson_l1_language_support_vlu7e3/app_constants.dart'
    as watson_l1_language_support_vlu7e3_app_constant;
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_commons/api_requests/api_manager.dart';

import 'package:watson_l1_app_configuration_ctuwb2/backend/api_requests/interceptors.dart'
    as watson_l1_app_configuration_ctuwb2_api_interceptors;
import 'package:watson_l1_auth_logic_z87ikn/backend/api_requests/interceptors.dart'
    as watson_l1_auth_logic_z87ikn_api_interceptors;
import 'package:ff_commons/api_requests/api_interceptor.dart';

import 'package:ff_commons/api_requests/api_paging_params.dart';

export 'package:ff_commons/api_requests/api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start Auth API Calls Group Code

class AuthAPICallsGroup {
  static String getBaseUrl({
    String? apiBaseUrl,
  }) {
    apiBaseUrl ??= watson_l1_app_configuration_ctuwb2_app_constant
        .FFAppConstants.apiBaseUrlPlaceholder;
    return '${apiBaseUrl}/auth';
  }

  static Map<String, String> headers = {};
  static LoginWithEmailAndPasswordCall loginWithEmailAndPasswordCall =
      LoginWithEmailAndPasswordCall();

  static final interceptors = [
    watson_l1_app_configuration_ctuwb2_api_interceptors
        .APIConfigFromEnvironmentInterceptor(),
  ];
}

class LoginWithEmailAndPasswordCall {
  Future<ApiCallResponse> call({
    String? email = '',
    String? password = '',
    String? apiBaseUrl,
  }) async {
    apiBaseUrl ??= watson_l1_app_configuration_ctuwb2_app_constant
        .FFAppConstants.apiBaseUrlPlaceholder;
    final baseUrl = AuthAPICallsGroup.getBaseUrl(
      apiBaseUrl: apiBaseUrl,
    );

    final ffApiRequestBody = '''
{
  "email": "${escapeStringForJson(email)}",
  "password": "${escapeStringForJson(password)}"
}''';
    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Login with Email and Password',
        apiUrl: '${baseUrl}/login',
        callType: ApiCallType.POST,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},
        body: ffApiRequestBody,
        bodyType: BodyType.JSON,
        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      AuthAPICallsGroup.interceptors,
    );
  }
}

/// End Auth API Calls Group Code

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
