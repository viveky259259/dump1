import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import "package:watson_l1_language_support_vlu7e3/backend/schema/structs/index.dart"
    as watson_l1_language_support_vlu7e3_data_schema;
import '/backend/schema/structs/index.dart';
import 'login_section_widget.dart' show LoginSectionWidget;
import 'package:watson_l1_app_configuration_ctuwb2/app_constants.dart'
    as watson_l1_app_configuration_ctuwb2_app_constant;
import 'package:watson_l1_app_configuration_ctuwb2/app_state.dart'
    as watson_l1_app_configuration_ctuwb2_app_state;
import 'package:watson_l1_app_configuration_ctuwb2/backend/api_requests/api_calls.dart'
    as watson_l1_app_configuration_ctuwb2_api_calls_util;
import 'package:watson_l1_auth_logic_z87ikn/app_constants.dart'
    as watson_l1_auth_logic_z87ikn_app_constant;
import 'package:watson_l1_auth_logic_z87ikn/app_state.dart'
    as watson_l1_auth_logic_z87ikn_app_state;
import 'package:watson_l1_auth_logic_z87ikn/backend/api_requests/api_calls.dart'
    as watson_l1_auth_logic_z87ikn_api_calls_util;
import 'package:watson_l1_events_dymv6z/custom_code/actions/index.dart'
    as watson_l1_events_dymv6z_actions;
import 'package:watson_l1_input_g46t3x/components/email_text_field/email_text_field_widget.dart'
    as watson_l1_input_g46t3x;
import 'package:watson_l1_input_g46t3x/components/password_text_field/password_text_field_widget.dart'
    as watson_l1_input_g46t3x;
import 'package:watson_l1_input_g46t3x/flutter_flow/flutter_flow_util.dart'
    as watson_l1_input_g46t3x_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:watson_l1_language_support_vlu7e3/app_constants.dart'
    as watson_l1_language_support_vlu7e3_app_constant;
import 'package:watson_l1_language_support_vlu7e3/app_state.dart'
    as watson_l1_language_support_vlu7e3_app_state;
import 'package:watson_l1_presentation_iqq8vq/components/primary_button/primary_button_widget.dart'
    as watson_l1_presentation_iqq8vq;
import 'package:watson_l1_presentation_iqq8vq/flutter_flow/flutter_flow_util.dart'
    as watson_l1_presentation_iqq8vq_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoginSectionModel extends FlutterFlowModel<LoginSectionWidget> {
  ///  Local state fields for this component.

  String? email;

  String? password;

  bool isInputValid = false;

  watson_l1_auth_logic_z87ikn_data_schema.LoginEventModelStruct?
      loginEventObject;
  void updateLoginEventObjectStruct(
      Function(watson_l1_auth_logic_z87ikn_data_schema.LoginEventModelStruct)
          updateFn) {
    updateFn(loginEventObject ??=
        watson_l1_auth_logic_z87ikn_data_schema.LoginEventModelStruct());
  }

  ///  State fields for stateful widgets in this component.

  // Model for emailField.
  late watson_l1_input_g46t3x.EmailTextFieldModel emailFieldModel;
  // Model for passwordField.
  late watson_l1_input_g46t3x.PasswordTextFieldModel passwordFieldModel;
  // Model for loginButton.
  late watson_l1_presentation_iqq8vq.PrimaryButtonModel loginButtonModel;
  // Stores action output result for [Backend Call - API (Login with Email and Password)] action in loginButton widget.
  ApiCallResponse? loginResponse;

  @override
  void initState(BuildContext context) {
    emailFieldModel = watson_l1_input_g46t3x_util.createModel(
        context, () => watson_l1_input_g46t3x.EmailTextFieldModel());
    passwordFieldModel = watson_l1_input_g46t3x_util.createModel(
        context, () => watson_l1_input_g46t3x.PasswordTextFieldModel());
    loginButtonModel = watson_l1_presentation_iqq8vq_util.createModel(
        context, () => watson_l1_presentation_iqq8vq.PrimaryButtonModel());
  }

  @override
  void dispose() {
    emailFieldModel.dispose();
    passwordFieldModel.dispose();
    loginButtonModel.dispose();
  }
}
