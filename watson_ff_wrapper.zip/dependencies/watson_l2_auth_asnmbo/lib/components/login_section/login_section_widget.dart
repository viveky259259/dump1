import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import "package:watson_l1_language_support_vlu7e3/backend/schema/structs/index.dart"
    as watson_l1_language_support_vlu7e3_data_schema;
import '/backend/schema/structs/index.dart';
import 'package:watson_l1_app_configuration_ctuwb2/app_constants.dart'
    as watson_l1_app_configuration_ctuwb2_app_constant;
import 'package:watson_l1_app_configuration_ctuwb2/app_state.dart'
    as watson_l1_app_configuration_ctuwb2_app_state;
import 'package:watson_l1_app_configuration_ctuwb2/backend/api_requests/api_calls.dart'
    as watson_l1_app_configuration_ctuwb2_api_calls_util;
import 'package:watson_l1_auth_logic_z87ikn/app_constants.dart'
    as watson_l1_auth_logic_z87ikn_app_constant;
import 'package:watson_l1_auth_logic_z87ikn/app_state.dart'
    as watson_l1_auth_logic_z87ikn_app_state;
import 'package:watson_l1_auth_logic_z87ikn/backend/api_requests/api_calls.dart'
    as watson_l1_auth_logic_z87ikn_api_calls_util;
import 'package:watson_l1_events_dymv6z/custom_code/actions/index.dart'
    as watson_l1_events_dymv6z_actions;
import 'package:watson_l1_input_g46t3x/components/email_text_field/email_text_field_widget.dart'
    as watson_l1_input_g46t3x;
import 'package:watson_l1_input_g46t3x/components/password_text_field/password_text_field_widget.dart'
    as watson_l1_input_g46t3x;
import 'package:watson_l1_input_g46t3x/flutter_flow/flutter_flow_util.dart'
    as watson_l1_input_g46t3x_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:watson_l1_language_support_vlu7e3/app_constants.dart'
    as watson_l1_language_support_vlu7e3_app_constant;
import 'package:watson_l1_language_support_vlu7e3/app_state.dart'
    as watson_l1_language_support_vlu7e3_app_state;
import 'package:watson_l1_presentation_iqq8vq/components/primary_button/primary_button_widget.dart'
    as watson_l1_presentation_iqq8vq;
import 'package:watson_l1_presentation_iqq8vq/flutter_flow/flutter_flow_util.dart'
    as watson_l1_presentation_iqq8vq_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:portfolio_common_logic/flutter_flow/custom_functions.dart'
    as key_generator;
import 'login_section_model.dart';
export 'login_section_model.dart';

class LoginSectionWidget extends StatefulWidget {
  const LoginSectionWidget({super.key});

  @override
  State<LoginSectionWidget> createState() => _LoginSectionWidgetState();
}

class _LoginSectionWidgetState extends State<LoginSectionWidget> {
  late LoginSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LoginSectionModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<watson_l1_app_configuration_ctuwb2_app_state.FFAppState>();
    context.watch<watson_l1_auth_logic_z87ikn_app_state.FFAppState>();
    context.watch<watson_l1_language_support_vlu7e3_app_state.FFAppState>();

    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primaryBackground,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: Container(
              height: double.infinity,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).primaryBackground,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(32.0, 32.0, 0.0, 0.0),
                    child: Container(
                      decoration: BoxDecoration(),
                      child: Text(
                        valueOrDefault<String>(
                          getJsonField(
                            watson_l1_language_support_vlu7e3_app_state
                                    .FFAppState()
                                .translations,
                            r'''$.appTitle''',
                          )?.toString(),
                          'Watson',
                        ),
                        key: ValueKey(key_generator.generateL1KeyValue(
                            'LoginScreen', 'appTitle', 'text')),
                        style:
                            FlutterFlowTheme.of(context).displaySmall.override(
                                  fontFamily: 'Plus Jakarta Sans',
                                  letterSpacing: 0.0,
                                ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          watson_l1_input_g46t3x_util.wrapWithModel(
                            model: _model.emailFieldModel,
                            updateCallback: () => safeSetState(() {}),
                            child: watson_l1_input_g46t3x.EmailTextFieldWidget(
                              key: ValueKey(key_generator.generateL1KeyValue(
                                  'LoginScreen', 'emailField', 'text')),
                              autofocus: true,
                              onValueChange: (value) async {
                                // email
                                _model.email = value;
                                safeSetState(() {});
                              },
                              onValidate: (isValid) async {
                                // update form validity
                                _model.isInputValid =
                                    isValid && _model.isInputValid;
                                safeSetState(() {});
                              },
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 32.0, 0.0, 0.0),
                            child: watson_l1_input_g46t3x_util.wrapWithModel(
                              model: _model.passwordFieldModel,
                              updateCallback: () => safeSetState(() {}),
                              child: watson_l1_input_g46t3x
                                  .PasswordTextFieldWidget(
                                key: ValueKey(key_generator.generateL1KeyValue(
                                    'LoginScreen', 'passwordField', 'text')),
                                autofocus: false,
                                onValidate: (isValid) async {
                                  // update login form input validity
                                  _model.isInputValid =
                                      isValid && _model.isInputValid;
                                  safeSetState(() {});
                                },
                                onValueChange: (value) async {
                                  // update password
                                  _model.password = value;
                                  safeSetState(() {});
                                },
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 16.0, 0.0, 0.0),
                            child: watson_l1_presentation_iqq8vq_util
                                .wrapWithModel(
                              model: _model.loginButtonModel,
                              updateCallback: () => safeSetState(() {}),
                              child: watson_l1_presentation_iqq8vq
                                  .PrimaryButtonWidget(
                                key: ValueKey(key_generator.generateL1KeyValue(
                                    'LoginScreen', 'loginButton', 'button')),
                                label: valueOrDefault<String>(
                                  getJsonField(
                                    watson_l1_language_support_vlu7e3_app_state
                                            .FFAppState()
                                        .translations,
                                    r'''$.loginLabel''',
                                  )?.toString(),
                                  'Login',
                                ),
                                onTap: () async {
                                  var _shouldSetState = false;
                                  if (_model.isInputValid) {
                                    // make login api call
                                    _model.loginResponse =
                                        await AuthAPICallsGroup
                                            .loginWithEmailAndPasswordCall
                                            .call(
                                      email: _model.email,
                                      password: _model.password,
                                    );

                                    _shouldSetState = true;
                                    if ((_model.loginResponse?.succeeded ??
                                        true)) {
                                      // set login creds in login logic library
                                      watson_l1_auth_logic_z87ikn_app_state
                                                  .FFAppState()
                                              .authToken =
                                          LoginResponseModelStruct.maybeFromMap(
                                                  (_model.loginResponse
                                                          ?.jsonBody ??
                                                      ''))!
                                              .token;
                                      watson_l1_auth_logic_z87ikn_app_state
                                                  .FFAppState()
                                              .userProfile =
                                          LoginResponseModelStruct.maybeFromMap(
                                                  (_model.loginResponse
                                                          ?.jsonBody ??
                                                      ''))!
                                              .user;
                                      // update the login event model
                                      _model.updateLoginEventObjectStruct(
                                        (e) => e..success = true,
                                      );
                                      // trigger login event
                                      await watson_l1_events_dymv6z_actions
                                          .triggerEvent(
                                        watson_l1_auth_logic_z87ikn_app_constant
                                            .FFAppConstants.loginEventType,
                                        _model.loginEventObject!.toMap(),
                                      );
                                      if (_shouldSetState) safeSetState(() {});
                                      return;
                                    } else {
                                      // prompt user
                                      await showDialog(
                                        context: context,
                                        builder: (alertDialogContext) {
                                          return AlertDialog(
                                            title: Text('Login failed'),
                                            content: Text(
                                                'We are unable to log you in right now. Please check your credentials or try again.'),
                                            actions: [
                                              TextButton(
                                                onPressed: () => Navigator.pop(
                                                    alertDialogContext),
                                                child: Text('Okay'),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                      if (_shouldSetState) safeSetState(() {});
                                      return;
                                    }
                                  } else {
                                    // prompt user
                                    await showDialog(
                                      context: context,
                                      builder: (alertDialogContext) {
                                        return AlertDialog(
                                          title: Text('Credentials required'),
                                          content: Text(
                                              'Please enter a valid email and password to continue.'),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.pop(
                                                  alertDialogContext),
                                              child: Text('Okay'),
                                            ),
                                          ],
                                        );
                                      },
                                    );
                                    if (_shouldSetState) safeSetState(() {});
                                    return;
                                  }

                                  if (_shouldSetState) safeSetState(() {});
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (responsiveVisibility(
            context: context,
            phone: false,
            tablet: false,
          ))
            Expanded(
              child: Container(
                height: double.infinity,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: Image.asset(
                      'packages/watson_l2_auth_asnmbo/assets/images/watson_landing_graphic.webp',
                    ).image,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
