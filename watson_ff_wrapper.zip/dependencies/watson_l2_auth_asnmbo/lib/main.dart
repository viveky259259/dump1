import 'package:provider/provider.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'package:flutter_localizations/flutter_localizations.dart';

import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'flutter_flow/nav/nav.dart';
import 'index.dart';

import 'package:watson_l1_app_configuration_ctuwb2/app_state.dart'
    as watson_l1_app_configuration_ctuwb2_app_state;
import 'package:watson_l1_auth_logic_z87ikn/app_state.dart'
    as watson_l1_auth_logic_z87ikn_app_state;
import 'package:watson_l1_language_support_vlu7e3/app_state.dart'
    as watson_l1_language_support_vlu7e3_app_state;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  GoRouter.optionURLReflectsImperativeAPIs = true;
  // usePathUrlStrategy();

  final watson_l1_app_configuration_ctuwb2AppState =
      watson_l1_app_configuration_ctuwb2_app_state.FFAppState();
  await watson_l1_app_configuration_ctuwb2AppState.initializePersistedState();

  final watson_l1_auth_logic_z87iknAppState =
      watson_l1_auth_logic_z87ikn_app_state.FFAppState();
  await watson_l1_auth_logic_z87iknAppState.initializePersistedState();

  final watson_l1_language_support_vlu7e3AppState =
      watson_l1_language_support_vlu7e3_app_state.FFAppState();
  await watson_l1_language_support_vlu7e3AppState.initializePersistedState();

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(
        create: (context) => watson_l1_app_configuration_ctuwb2AppState,
      ),
      ChangeNotifierProvider(
        create: (context) => watson_l1_auth_logic_z87iknAppState,
      ),
      ChangeNotifierProvider(
        create: (context) => watson_l1_language_support_vlu7e3AppState,
      ),
    ],
    child: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  State<MyApp> createState() => _MyAppState();

  static _MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>()!;
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.system;

  late AppStateNotifier _appStateNotifier;
  late GoRouter _router;
  String getRoute([RouteMatch? routeMatch]) {
    final RouteMatch lastMatch =
        routeMatch ?? _router.routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : _router.routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }

  @override
  void initState() {
    super.initState();

    _appStateNotifier = AppStateNotifier.instance;
    _router = createRouter(_appStateNotifier);
  }

  void setThemeMode(ThemeMode mode) => safeSetState(() {
        _themeMode = mode;
      });

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Watson L2 Auth',
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('en', '')],
      theme: ThemeData(
        brightness: Brightness.light,
        useMaterial3: false,
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: false,
      ),
      themeMode: _themeMode,
      routerConfig: _router,
    );
  }
}
