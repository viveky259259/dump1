import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _icomoonFamily = 'Icomoon';

  // icomoon
  static const IconData kiconsXLS24px =
      IconData(0xe900, fontFamily: _icomoonFamily);
  static const IconData kiconsPDF24px =
      IconData(0xe905, fontFamily: _icomoonFamily);
}
