import '/components/generic_text_field/generic_text_field_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'password_text_field_model.dart';
export 'password_text_field_model.dart';

class PasswordTextFieldWidget extends StatefulWidget {
  const PasswordTextFieldWidget({
    super.key,
    required this.onValidate,
    required this.onValueChange,
    bool? autofocus,
  }) : this.autofocus = autofocus ?? false;

  final Future Function(bool isValid)? onValidate;
  final Future Function(String? value)? onValueChange;
  final bool autofocus;

  @override
  State<PasswordTextFieldWidget> createState() =>
      _PasswordTextFieldWidgetState();
}

class _PasswordTextFieldWidgetState extends State<PasswordTextFieldWidget> {
  late PasswordTextFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PasswordTextFieldModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return wrapWithModel(
      model: _model.genericTextFieldModel,
      updateCallback: () => safeSetState(() {}),
      child: GenericTextFieldWidget(
        label: 'Password',
        obscureText: true,
        validationRegex: '^(?=.*\\d).{6,}\$',
        errorText: 'Password must have atleast 6 characters and 1 number.',
        hintText: 'Enter password...',
        autofocus: widget!.autofocus,
        onFocusChange: (hasFocus) async {},
        onValueChange: (value) async {
          // on value change
          await widget.onValueChange?.call(
            value,
          );
        },
        onValidate: (isValid) async {
          // on validate callback
          await widget.onValidate?.call(
            isValid,
          );
        },
      ),
    );
  }
}
