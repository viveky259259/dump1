import '/components/generic_text_field/generic_text_field_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'email_text_field_model.dart';
export 'email_text_field_model.dart';

class EmailTextFieldWidget extends StatefulWidget {
  const EmailTextFieldWidget({
    super.key,
    required this.onValueChange,
    required this.onValidate,
    bool? autofocus,
  }) : this.autofocus = autofocus ?? false;

  final Future Function(String? value)? onValueChange;
  final Future Function(bool isValid)? onValidate;
  final bool autofocus;

  @override
  State<EmailTextFieldWidget> createState() => _EmailTextFieldWidgetState();
}

class _EmailTextFieldWidgetState extends State<EmailTextFieldWidget> {
  late EmailTextFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmailTextFieldModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return wrapWithModel(
      model: _model.genericTextFieldModel,
      updateCallback: () => safeSetState(() {}),
      child: GenericTextFieldWidget(
        label: 'Email',
        obscureText: false,
        validationRegex: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}\$',
        errorText: 'Please enter a valid email.',
        hintText: 'abc@example.com',
        autofocus: widget!.autofocus,
        onFocusChange: (hasFocus) async {},
        onValueChange: (value) async {
          // on value change callback
          await widget.onValueChange?.call(
            value,
          );
        },
        onValidate: (isValid) async {
          // on validate callback
          await widget.onValidate?.call(
            isValid,
          );
        },
      ),
    );
  }
}
