import '/components/generic_text_field/generic_text_field_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'email_text_field_widget.dart' show EmailTextFieldWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EmailTextFieldModel extends FlutterFlowModel<EmailTextFieldWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for GenericTextField component.
  late GenericTextFieldModel genericTextFieldModel;

  @override
  void initState(BuildContext context) {
    genericTextFieldModel = createModel(context, () => GenericTextFieldModel());
  }

  @override
  void dispose() {
    genericTextFieldModel.dispose();
  }
}
