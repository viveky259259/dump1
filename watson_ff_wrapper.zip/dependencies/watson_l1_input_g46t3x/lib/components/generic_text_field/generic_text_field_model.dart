import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'generic_text_field_widget.dart' show GenericTextFieldWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericTextFieldModel extends FlutterFlowModel<GenericTextFieldWidget> {
  ///  Local state fields for this component.

  bool isInputValid = true;

  bool showError = false;

  bool hasBeenFocussed = false;

  String? errorMessage;

  ///  State fields for stateful widgets in this component.

  // State field(s) for inputField widget.
  FocusNode? inputFieldFocusNode;
  TextEditingController? inputFieldTextController;
  String? Function(BuildContext, String?)? inputFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputFieldFocusNode?.dispose();
    inputFieldTextController?.dispose();
  }

  /// Action blocks.
  Future validateTextField(BuildContext context) async {
    if ((widget!.validationRegex != null && widget!.validationRegex != '') &&
        (inputFieldTextController.text != null &&
            inputFieldTextController.text != '')) {
      // update state to reflect validity
      isInputValid = functions.isInputValueValid(
          inputFieldTextController.text, widget!.validationRegex!);
      showError = true;
      errorMessage = isInputValid ? null : widget!.errorText;
      return;
    } else {
      return;
    }
  }
}
