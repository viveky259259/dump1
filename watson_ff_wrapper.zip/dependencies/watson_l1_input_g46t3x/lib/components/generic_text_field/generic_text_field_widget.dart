import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_text_field_model.dart';
export 'generic_text_field_model.dart';

class GenericTextFieldWidget extends StatefulWidget {
  const GenericTextFieldWidget({
    super.key,
    required this.label,
    this.initialValue,
    bool? obscureText,
    this.validationRegex,
    this.errorText,
    this.hintText,
    this.onFocusChange,
    this.onValueChange,
    this.onValidate,
    bool? autofocus,
  })  : this.obscureText = obscureText ?? false,
        this.autofocus = autofocus ?? false;

  final String? label;
  final String? initialValue;
  final bool obscureText;
  final String? validationRegex;
  final String? errorText;
  final String? hintText;
  final Future Function(bool hasFocus)? onFocusChange;
  final Future Function(String? value)? onValueChange;
  final Future Function(bool isValid)? onValidate;
  final bool autofocus;

  @override
  State<GenericTextFieldWidget> createState() => _GenericTextFieldWidgetState();
}

class _GenericTextFieldWidgetState extends State<GenericTextFieldWidget> {
  late GenericTextFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericTextFieldModel());

    _model.inputFieldTextController ??=
        TextEditingController(text: widget!.initialValue);
    _model.inputFieldFocusNode ??= FocusNode();
    _model.inputFieldFocusNode!.addListener(
      () async {
        // on focus change callback
        await widget.onFocusChange?.call(
          (_model.inputFieldFocusNode?.hasFocus ?? false),
        );
        if (!(_model.inputFieldFocusNode?.hasFocus ?? false) &&
            _model.hasBeenFocussed) {
          // run validation
          await _model.validateTextField(context);
          safeSetState(() {});
          // execute on validate callback
          await widget.onValidate?.call(
            _model.isInputValid,
          );
          return;
        } else {
          if ((_model.inputFieldFocusNode?.hasFocus ?? false)) {
            _model.hasBeenFocussed = true;
            safeSetState(() {});
            return;
          } else {
            return;
          }
        }
      },
    );
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: 300.0,
      ),
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget!.label!,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  fontSize: 16.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
            child: TextFormField(
              controller: _model.inputFieldTextController,
              focusNode: _model.inputFieldFocusNode,
              onChanged: (_) => EasyDebounce.debounce(
                '_model.inputFieldTextController',
                Duration(milliseconds: 100),
                () async {
                  // execute onValueChange callback
                  await widget.onValueChange?.call(
                    _model.inputFieldTextController.text,
                  );
                  if (_model.hasBeenFocussed && _model.showError) {
                    // run validation
                    await _model.validateTextField(context);
                    safeSetState(() {});
                    // execute onValidate callback
                    await widget.onValidate?.call(
                      _model.isInputValid,
                    );
                    return;
                  } else {
                    return;
                  }
                },
              ),
              autofocus: widget!.autofocus,
              obscureText: false,
              decoration: InputDecoration(
                isDense: false,
                labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
                hintText: widget!.hintText,
                hintStyle: FlutterFlowTheme.of(context).labelMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Color(0x00000000),
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Color(0x00000000),
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: FlutterFlowTheme.of(context).error,
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: FlutterFlowTheme.of(context).error,
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                filled: true,
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
              ),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
              cursorColor: FlutterFlowTheme.of(context).primaryText,
              validator:
                  _model.inputFieldTextControllerValidator.asValidator(context),
            ),
          ),
          if (_model.showError &&
              (_model.errorMessage != null && _model.errorMessage != ''))
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
              child: Text(
                widget!.errorText!,
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).error,
                      letterSpacing: 0.0,
                    ),
              ),
            ),
        ],
      ),
    );
  }
}
