// Automatic FlutterFlow imports
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:mixpanel_flutter/mixpanel_flutter.dart';
import 'package:watson_l1_app_configuration_ctuwb2/app_state.dart'
    as app_config_app_state;
import 'package:watson_l1_logger_qd3zlg/custom_code/actions/log_information.dart'
    as logger;

Future initMixpanelService() async {
  await MixpanelService.instance.init();
}

class MixpanelService {
  static final MixpanelService _instance = MixpanelService._internal();

  // Private constructor
  MixpanelService._internal();

  // Singleton instance getter
  static MixpanelService get instance => _instance;

  Mixpanel? _mixpanel;

  // Initialize Mixpanel
  Future<void> init() async {
    try {
      // Get the token from the environment
      final token = app_config_app_state.FFAppState()
          .appConfiguration
          .mixpanelProjectToken;

      // Initialize Mixpanel with the token
      _mixpanel = await Mixpanel.init(
        token,
        optOutTrackingDefault: false,
        trackAutomaticEvents: true,
      );
    } catch (error, stacktrace) {
      logger.Logger.error(
        'MixpanelService.init',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  // Flush all events to Mixpanel
  void flush() {
    try {
      _mixpanel?.flush();
    } catch (error, stacktrace) {
      logger.Logger.error(
        'MixpanelService.flush',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  // Track an event
  void captureEvent(
    String eventName, {
    Map<String, dynamic>? properties,
  }) {
    try {
      _mixpanel?.track(
        eventName,
        properties: properties,
      );
    } catch (error, stacktrace) {
      logger.Logger.error(
        'MixpanelService.captureEvent',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  // Set user properties
  void identifyUser({
    required String userId,
    required Map<String, dynamic> userProperties,
  }) {
    try {
      // Identify the user
      _mixpanel?.identify(userId);
      // Set user properties
      final people = _mixpanel?.getPeople();
      if (userProperties.isNotEmpty) {
        userProperties.forEach((key, value) {
          people?.set(
            key,
            value,
          );
        });
      }
      // Flush all events to Mixpanel
      flush();
    } catch (error, stacktrace) {
      logger.Logger.error(
        'MixpanelService.identifyUser',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  void reset() {
    try {
      flush();
      _mixpanel?.reset();
    } catch (error, stacktrace) {
      logger.Logger.error(
        'MixpanelService.reset',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }
}
