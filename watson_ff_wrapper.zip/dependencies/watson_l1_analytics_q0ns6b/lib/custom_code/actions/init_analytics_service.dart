// Automatic FlutterFlow imports
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/init_mixpanel_service.dart';
import 'package:watson_l1_app_configuration_ctuwb2/app_state.dart'
    as app_config_app_state;
import 'package:watson_l1_logger_qd3zlg/custom_code/actions/log_information.dart'
    as logger;

Future initAnalyticsService() async {
  // Initialize the analytics service
  await AnalyticsService.instance.init();
}

class AnalyticsService {
  static final AnalyticsService _instance = AnalyticsService._internal();

  AnalyticsService._internal();

  static AnalyticsService get instance => _instance;

  // Get whether analytics reporting is enabled in the environment
  bool get reportAnalytics =>
      app_config_app_state.FFAppState().appConfiguration.reportAnalytics;

  Future<void> init() async {
    // Initialize Mixpanel
    try {
      if (reportAnalytics) {
        await MixpanelService.instance.init();
      }
    } catch (error, stacktrace) {
      logger.Logger.error(
        'AnalyticsService.init',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  void captureEvent(String eventName, {Map<String, dynamic>? properties}) {
    try {
      if (reportAnalytics) {
        MixpanelService.instance.captureEvent(
          eventName,
          properties: properties,
        );
      }
    } catch (error, stacktrace) {
      logger.Logger.error(
        'AnalyticsService.captureEvent',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  void identifyUser(String userId, {Map<String, dynamic>? properties}) {
    try {
      if (reportAnalytics) {
        MixpanelService.instance.identifyUser(
          userId: userId,
          userProperties: properties ?? {},
        );
      }
    } catch (error, stacktrace) {
      logger.Logger.error(
        'AnalyticsService.identifyUser',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }

  void reset() {
    try {
      if (reportAnalytics) {
        MixpanelService.instance.reset();
      }
    } catch (error, stacktrace) {
      logger.Logger.error(
        'AnalyticsService.reset',
        error: error,
        stackTrace: stacktrace,
      );
    }
  }
}
