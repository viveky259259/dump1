// Automatic FlutterFlow imports
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:event_bus/event_bus.dart';

Future initEventManager() async {
  final eventManager = EventManager();
  eventManager.initialize();
}

class EventManager {
  // Private static instance
  static final EventManager _instance = EventManager._internal();

  // Public getter to access the singleton instance
  factory EventManager() {
    return _instance;
  }

  // Private constructor
  EventManager._internal();

  // EventBus instance
  final EventBus _eventBus = EventBus();

  // Map to hold event handlers by type string
  final Map<String, List<Function>> _eventHandlers = {};

  // Add an event handler for a specific type string
  void addEventHandler(String eventType, Function handler) {
    _eventHandlers.putIfAbsent(eventType, () => []).add(handler);
  }

  // Emit an event with a type string
  void triggerEvent(String eventType, dynamic event) {
    _eventBus.fire(_TypedEvent(eventType, event));
  }

  // Initialize the global listener
  void initialize() {
    _eventBus.on().listen((event) {
      if (event is _TypedEvent) {
        final handlers = _eventHandlers[event.type];
        if (handlers != null) {
          for (var handler in handlers) {
            handler(event.data);
          }
        }
      }
    });
  }
}

// Helper class to wrap event type and data
class _TypedEvent {
  final String type;
  final dynamic data;

  _TypedEvent(this.type, this.data);
}
