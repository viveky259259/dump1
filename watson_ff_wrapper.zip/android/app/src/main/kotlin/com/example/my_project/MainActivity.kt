package com.mycompany.watsonffwrapper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
