import 'dart:convert';
import 'dart:typed_data';
import "package:watson_l1_language_support_vlu7e3/backend/schema/structs/index.dart"
    as watson_l1_language_support_vlu7e3_data_schema;
import "package:watson_l1_app_configuration_ctuwb2/backend/schema/structs/index.dart"
    as watson_l1_app_configuration_ctuwb2_data_schema;
import "package:watson_l1_auth_logic_z87ikn/backend/schema/structs/index.dart"
    as watson_l1_auth_logic_z87ikn_data_schema;
import "package:watson_l2_auth_asnmbo/backend/schema/structs/index.dart"
    as watson_l2_auth_asnmbo_data_schema;
import 'package:watson_l1_language_support_vlu7e3/app_constants.dart'
    as watson_l1_language_support_vlu7e3_app_constant;
import 'package:watson_l1_app_configuration_ctuwb2/app_constants.dart'
    as watson_l1_app_configuration_ctuwb2_app_constant;
import 'package:watson_l1_auth_logic_z87ikn/app_constants.dart'
    as watson_l1_auth_logic_z87ikn_app_constant;
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_commons/api_requests/api_manager.dart';

import 'package:watson_l1_app_configuration_ctuwb2/backend/api_requests/interceptors.dart'
    as watson_l1_app_configuration_ctuwb2_api_interceptors;
import 'package:watson_l1_auth_logic_z87ikn/backend/api_requests/interceptors.dart'
    as watson_l1_auth_logic_z87ikn_api_interceptors;
import 'package:ff_commons/api_requests/api_interceptor.dart';

import 'package:ff_commons/api_requests/api_paging_params.dart';

export 'package:ff_commons/api_requests/api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GetPostsCall {
  static Future<ApiCallResponse> call() async {
    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Get Posts',
        apiUrl: 'https://jsonplaceholder.typicode.com/posts',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      interceptors,
    );
  }

  static final interceptors = [
    watson_l1_app_configuration_ctuwb2_api_interceptors
        .APIConfigFromEnvironmentInterceptor(),
    watson_l1_auth_logic_z87ikn_api_interceptors.TokenValidityInterceptor(),
  ];
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
