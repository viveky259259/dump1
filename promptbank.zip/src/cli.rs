use clap::{Parser, Subcommand};
use colored::*;
use dialoguer::{Editor, Input, Select};
use std::path::PathBuf;

use crate::claude::{ClaudeIntegration, InstallType};
use crate::community::Community;
use crate::error::{PromptBankError, Result};
use crate::prompt::{Prompt, PromptBank, PromptCategory};
use crate::storage::Storage;

#[derive(Parser)]
#[command(name = "promptbank")]
#[command(author, version, about = "Manage and apply prompts for Claude AI")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,
}

#[derive(Subcommand)]
pub enum Commands {
    /// Add a new prompt
    Add {
        /// Name of the prompt
        #[arg(short, long)]
        name: Option<String>,

        /// Category (system, skill, agent, role, task, template)
        #[arg(short, long)]
        category: Option<String>,

        /// Description of the prompt
        #[arg(short, long)]
        description: Option<String>,

        /// Tags (comma-separated)
        #[arg(short, long)]
        tags: Option<String>,

        /// Content of the prompt (opens editor if not provided)
        #[arg(long)]
        content: Option<String>,

        /// Read content from a file
        #[arg(short, long)]
        file: Option<PathBuf>,
    },

    /// List all prompts
    List {
        /// Filter by category
        #[arg(short, long)]
        category: Option<String>,

        /// Show full content
        #[arg(long)]
        full: bool,
    },

    /// Get a specific prompt by ID or name
    Get {
        /// ID or name of the prompt
        id: String,

        /// Copy to clipboard
        #[arg(short, long)]
        copy: bool,

        /// Only output the content (for piping)
        #[arg(short, long)]
        raw: bool,
    },

    /// Apply a prompt (render with variables)
    Apply {
        /// ID or name of the prompt
        id: String,

        /// Variable substitutions (format: key=value)
        #[arg(short, long)]
        var: Vec<String>,

        /// Copy to clipboard
        #[arg(short, long)]
        copy: bool,

        /// Interactive mode for variables
        #[arg(short, long)]
        interactive: bool,
    },

    /// Edit an existing prompt
    Edit {
        /// ID or name of the prompt
        id: String,
    },

    /// Delete a prompt
    Delete {
        /// ID or name of the prompt
        id: String,

        /// Skip confirmation
        #[arg(short, long)]
        force: bool,
    },

    /// Search prompts
    Search {
        /// Search query
        query: String,
    },

    /// Export prompts to a file
    Export {
        /// Output file path
        output: PathBuf,
    },

    /// Import prompts from a file
    Import {
        /// Input file path
        input: PathBuf,

        /// Merge with existing prompts
        #[arg(short, long)]
        merge: bool,
    },

    /// Show storage info
    Info,

    /// Update promptbank to the latest version
    Update,

    /// Community prompts - browse, install, and share
    #[command(subcommand)]
    Community(CommunityCommands),

    /// Claude integration - install prompts as skills/commands
    #[command(subcommand)]
    Claude(ClaudeCommands),
}

#[derive(Subcommand)]
pub enum CommunityCommands {
    /// Browse available community prompts
    Browse {
        /// Filter by category
        #[arg(short, long)]
        category: Option<String>,
    },

    /// Install a prompt from the community
    Install {
        /// Name of the prompt to install
        name: String,

        /// Apply (output) the prompt after installing
        #[arg(short, long)]
        apply: bool,

        /// Copy to clipboard after installing
        #[arg(short, long)]
        copy: bool,
    },

    /// Search community prompts
    Search {
        /// Search query
        query: String,
    },

    /// Show info about contributing
    Contribute,
}

#[derive(Subcommand)]
pub enum ClaudeCommands {
    /// Install a prompt as a Claude skill or command
    Install {
        /// ID or name of the prompt to install
        id: String,

        /// Install as skill (default) or command
        #[arg(long, value_parser = ["skill", "command"], default_value = "skill")]
        as_type: String,
    },

    /// List prompts installed in Claude
    List,

    /// Remove a prompt from Claude
    Remove {
        /// Name of the skill/command to remove
        name: String,
    },
}

pub struct App {
    storage: Storage,
    bank: PromptBank,
}

impl App {
    pub fn new() -> Result<Self> {
        let storage = Storage::new()?;
        let bank = storage.load()?;
        Ok(Self { storage, bank })
    }

    pub fn run(&mut self, cli: Cli) -> Result<()> {
        match cli.command {
            Commands::Add {
                name,
                category,
                description,
                tags,
                content,
                file,
            } => self.add_prompt(name, category, description, tags, content, file),

            Commands::List { category, full } => self.list_prompts(category, full),

            Commands::Get { id, copy, raw } => self.get_prompt(&id, copy, raw),

            Commands::Apply {
                id,
                var,
                copy,
                interactive,
            } => self.apply_prompt(&id, var, copy, interactive),

            Commands::Edit { id } => self.edit_prompt(&id),

            Commands::Delete { id, force } => self.delete_prompt(&id, force),

            Commands::Search { query } => self.search_prompts(&query),

            Commands::Export { output } => self.export_prompts(&output),

            Commands::Import { input, merge } => self.import_prompts(&input, merge),

            Commands::Info => self.show_info(),

            Commands::Update => self.update_self(),

            Commands::Community(cmd) => self.run_community(cmd),

            Commands::Claude(cmd) => self.run_claude(cmd),
        }
    }

    fn run_claude(&mut self, cmd: ClaudeCommands) -> Result<()> {
        match cmd {
            ClaudeCommands::Install { id, as_type } => self.claude_install(&id, &as_type),
            ClaudeCommands::List => self.claude_list(),
            ClaudeCommands::Remove { name } => self.claude_remove(&name),
        }
    }

    fn claude_install(&self, id: &str, as_type: &str) -> Result<()> {
        let prompt = self
            .bank
            .get(id)
            .ok_or_else(|| PromptBankError::PromptNotFound(id.to_string()))?;

        let install_type = match as_type {
            "command" => InstallType::Command,
            _ => InstallType::Skill,
        };

        let claude = ClaudeIntegration::new()?;
        let path = claude.install(prompt, install_type)?;

        let type_name = match install_type {
            InstallType::Skill => "skill",
            InstallType::Command => "command",
        };

        println!(
            "{} Installed '{}' as Claude {}",
            "✓".green(),
            prompt.name.cyan(),
            type_name
        );
        println!("  Path: {:?}", path);
        println!(
            "\n  Use with: {}{}",
            "/".cyan(),
            prompt.name
        );

        Ok(())
    }

    fn claude_list(&self) -> Result<()> {
        let claude = ClaudeIntegration::new()?;
        let (skills, commands) = claude.list_installed()?;

        println!("\n{}", "Claude Integrations".bold().underline());
        println!("  Directory: {:?}", claude.claude_dir());

        if skills.is_empty() && commands.is_empty() {
            println!("\n  No prompts installed in Claude.");
        } else {
            if !skills.is_empty() {
                println!("\n  {}:", "Skills".yellow());
                for skill in skills {
                    println!("    /{}", skill);
                }
            }

            if !commands.is_empty() {
                println!("\n  {}:", "Commands".yellow());
                for cmd in commands {
                    println!("    /{}", cmd);
                }
            }
        }

        println!();
        Ok(())
    }

    fn claude_remove(&self, name: &str) -> Result<()> {
        let claude = ClaudeIntegration::new()?;
        let removed = claude.remove(name)?;

        if removed {
            println!("{} Removed '{}' from Claude", "✓".green(), name);
        } else {
            println!("{} '{}' not found in Claude", "→".yellow(), name);
        }

        Ok(())
    }

    fn run_community(&mut self, cmd: CommunityCommands) -> Result<()> {
        match cmd {
            CommunityCommands::Browse { category } => self.community_browse(category),
            CommunityCommands::Install { name, apply, copy } => self.community_install(&name, apply, copy),
            CommunityCommands::Search { query } => self.community_search(&query),
            CommunityCommands::Contribute => self.community_contribute(),
        }
    }

    fn community_browse(&self, category: Option<String>) -> Result<()> {
        println!("{}", "Fetching community prompts...".dimmed());

        let index = Community::fetch_index()?;

        let prompts: Vec<_> = if let Some(cat) = category {
            index
                .prompts
                .iter()
                .filter(|p| p.category.to_lowercase() == cat.to_lowercase())
                .collect()
        } else {
            index.prompts.iter().collect()
        };

        if prompts.is_empty() {
            println!("{}", "No community prompts found.".yellow());
            return Ok(());
        }

        println!(
            "\n{} {} community prompt(s) available:\n",
            "→".blue(),
            prompts.len().to_string().cyan()
        );

        for prompt in prompts {
            println!(
                "  {} [{}] by {}",
                prompt.name.bold(),
                prompt.category.yellow(),
                prompt.author.dimmed()
            );
            println!("    {}", prompt.description);
            if !prompt.tags.is_empty() {
                println!("    Tags: {}", prompt.tags.join(", ").blue());
            }
            println!();
        }

        println!(
            "Install with: {} <name>",
            "promptbank community install".cyan()
        );

        Ok(())
    }

    fn community_install(&mut self, name: &str, apply: bool, copy: bool) -> Result<()> {
        println!("{}", "Fetching community index...".dimmed());

        let index = Community::fetch_index()?;

        let entry = index
            .prompts
            .iter()
            .find(|p| p.name.to_lowercase() == name.to_lowercase())
            .ok_or_else(|| PromptBankError::PromptNotFound(name.to_string()))?;

        println!("Installing '{}'...", entry.name);

        let community_prompt = Community::fetch_prompt(&entry.path)?;
        let prompt = Community::to_local_prompt(community_prompt)?;
        let prompt_name = prompt.name.clone();
        let prompt_id = prompt.id.clone();
        let prompt_content = prompt.content.clone();

        // Save to local promptbank
        self.bank.add(prompt.clone());
        self.storage.save(&self.bank)?;

        println!(
            "{} Saved to promptbank with ID: {}",
            "✓".green(),
            prompt_id.cyan()
        );

        // Install to Claude as skill
        match ClaudeIntegration::new() {
            Ok(claude) => {
                match claude.install(&prompt, InstallType::Skill) {
                    Ok(_) => {
                        println!(
                            "{} Installed as Claude skill: {}",
                            "✓".green(),
                            format!("/{}", prompt_name).cyan()
                        );
                    }
                    Err(e) => {
                        println!(
                            "{} Could not install to Claude: {}",
                            "⚠".yellow(),
                            e
                        );
                    }
                }
            }
            Err(_) => {
                println!(
                    "{} Claude not found - skipping skill installation",
                    "⚠".yellow()
                );
            }
        }

        if apply {
            println!("\n{}", "═".repeat(60).dimmed());
            println!("{}", prompt_content);
            println!("{}", "═".repeat(60).dimmed());
        }

        if copy {
            self.copy_to_clipboard(&prompt_content)?;
            println!("\n{} Copied to clipboard!", "✓".green());
        }

        Ok(())
    }

    fn community_search(&self, query: &str) -> Result<()> {
        println!("{}", "Searching community prompts...".dimmed());

        let index = Community::fetch_index()?;
        let results = Community::search(&index, query);

        if results.is_empty() {
            println!("{} No community prompts matching '{}'", "→".yellow(), query);
            return Ok(());
        }

        println!(
            "\n{} {} result(s) for '{}':\n",
            "→".blue(),
            results.len().to_string().cyan(),
            query
        );

        for prompt in results {
            println!(
                "  {} [{}] by {}",
                prompt.name.bold(),
                prompt.category.yellow(),
                prompt.author.dimmed()
            );
            println!("    {}", prompt.description);
            println!();
        }

        Ok(())
    }

    fn community_contribute(&self) -> Result<()> {
        println!("\n{}", "Contributing to PromptBank Community".bold().underline());
        println!();
        println!("To share your prompts with the community:");
        println!();
        println!("  1. Fork the repository:");
        println!("     {}", Community::repo_url().cyan());
        println!();
        println!("  2. Add your prompt file to the appropriate category folder:");
        println!("     prompts/{{category}}/{{your-prompt-name}}.json");
        println!();
        println!("  3. Update index.json with your prompt entry");
        println!();
        println!("  4. Submit a Pull Request");
        println!();
        println!("See the README for detailed contribution guidelines.");
        println!();

        Ok(())
    }

    fn add_prompt(
        &mut self,
        name: Option<String>,
        category: Option<String>,
        description: Option<String>,
        tags: Option<String>,
        content: Option<String>,
        file: Option<PathBuf>,
    ) -> Result<()> {
        // Get name interactively if not provided
        let name = match name {
            Some(n) => n,
            None => Input::new()
                .with_prompt("Prompt name")
                .interact_text()
                .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?,
        };

        // Get category interactively if not provided
        let category = match category {
            Some(c) => c.parse()?,
            None => {
                let categories = vec!["system", "skill", "agent", "role", "task", "template"];
                let selection = Select::new()
                    .with_prompt("Select category")
                    .items(&categories)
                    .default(0)
                    .interact()
                    .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?;
                categories[selection].parse()?
            }
        };

        // Get description
        let description = match description {
            Some(d) => d,
            None => Input::new()
                .with_prompt("Description")
                .interact_text()
                .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?,
        };

        // Get tags
        let tags: Vec<String> = match tags {
            Some(t) => t.split(',').map(|s| s.trim().to_string()).collect(),
            None => {
                let tags_str: String = Input::new()
                    .with_prompt("Tags (comma-separated, optional)")
                    .allow_empty(true)
                    .interact_text()
                    .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?;
                if tags_str.is_empty() {
                    Vec::new()
                } else {
                    tags_str.split(',').map(|s| s.trim().to_string()).collect()
                }
            }
        };

        // Get content
        let content = if let Some(path) = file {
            std::fs::read_to_string(&path)?
        } else if let Some(c) = content {
            c
        } else {
            Editor::new()
                .edit("# Enter your prompt content here\n")
                .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?
                .ok_or_else(|| PromptBankError::InvalidInput("No content provided".to_string()))?
        };

        let prompt = Prompt::new(name.clone(), category, description, content, tags);
        let id = prompt.id.clone();
        self.bank.add(prompt);
        self.storage.save(&self.bank)?;

        println!("{} Prompt '{}' added with ID: {}", "✓".green(), name, id.cyan());
        Ok(())
    }

    fn list_prompts(&self, category: Option<String>, full: bool) -> Result<()> {
        let prompts: Vec<&Prompt> = if let Some(cat) = category {
            let cat: PromptCategory = cat.parse()?;
            self.bank.list_by_category(&cat)
        } else {
            self.bank.prompts.iter().collect()
        };

        if prompts.is_empty() {
            println!("{}", "No prompts found.".yellow());
            return Ok(());
        }

        println!(
            "\n{} {} prompt(s) found:\n",
            "→".blue(),
            prompts.len().to_string().cyan()
        );

        for prompt in prompts {
            self.print_prompt_summary(prompt, full);
        }

        Ok(())
    }

    fn get_prompt(&self, id: &str, copy: bool, raw: bool) -> Result<()> {
        let prompt = self
            .bank
            .get(id)
            .ok_or_else(|| PromptBankError::PromptNotFound(id.to_string()))?;

        if raw {
            println!("{}", prompt.content);
        } else {
            self.print_prompt_full(prompt);
        }

        if copy {
            self.copy_to_clipboard(&prompt.content)?;
            if !raw {
                println!("\n{} Copied to clipboard!", "✓".green());
            }
        }

        Ok(())
    }

    fn apply_prompt(
        &mut self,
        id: &str,
        vars: Vec<String>,
        copy: bool,
        interactive: bool,
    ) -> Result<()> {
        let prompt = self
            .bank
            .get(id)
            .ok_or_else(|| PromptBankError::PromptNotFound(id.to_string()))?;

        let mut substitutions: Vec<(String, String)> = Vec::new();

        // Parse provided variables
        for var in vars {
            let parts: Vec<&str> = var.splitn(2, '=').collect();
            if parts.len() == 2 {
                substitutions.push((parts[0].to_string(), parts[1].to_string()));
            }
        }

        // Interactive mode for remaining variables
        if interactive && !prompt.variables.is_empty() {
            println!(
                "\n{} This prompt has {} variable(s):\n",
                "→".blue(),
                prompt.variables.len()
            );

            for var in &prompt.variables {
                let existing = substitutions.iter().find(|(k, _)| k == var);
                if existing.is_none() {
                    let value: String = Input::new()
                        .with_prompt(format!("  {}", var))
                        .interact_text()
                        .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?;
                    substitutions.push((var.clone(), value));
                }
            }
        }

        let rendered = prompt.render(&substitutions);

        println!("\n{}", "═".repeat(60).dimmed());
        println!("{}", rendered);
        println!("{}", "═".repeat(60).dimmed());

        if copy {
            self.copy_to_clipboard(&rendered)?;
            println!("\n{} Copied to clipboard!", "✓".green());
        }

        Ok(())
    }

    fn edit_prompt(&mut self, id: &str) -> Result<()> {
        let prompt = self
            .bank
            .get(id)
            .ok_or_else(|| PromptBankError::PromptNotFound(id.to_string()))?;

        let current_content = prompt.content.clone();

        let new_content = Editor::new()
            .edit(&current_content)
            .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?
            .ok_or_else(|| PromptBankError::InvalidInput("No content provided".to_string()))?;

        if new_content == current_content {
            println!("{}", "No changes made.".yellow());
            return Ok(());
        }

        let prompt = self
            .bank
            .get_mut(id)
            .ok_or_else(|| PromptBankError::PromptNotFound(id.to_string()))?;
        prompt.update_content(new_content);
        self.storage.save(&self.bank)?;

        println!("{} Prompt '{}' updated.", "✓".green(), id);
        Ok(())
    }

    fn delete_prompt(&mut self, id: &str, force: bool) -> Result<()> {
        let prompt = self
            .bank
            .get(id)
            .ok_or_else(|| PromptBankError::PromptNotFound(id.to_string()))?;

        let name = prompt.name.clone();

        if !force {
            let confirm = Select::new()
                .with_prompt(format!("Delete prompt '{}'?", name))
                .items(&["No", "Yes"])
                .default(0)
                .interact()
                .map_err(|e| PromptBankError::InvalidInput(e.to_string()))?;

            if confirm == 0 {
                println!("{}", "Cancelled.".yellow());
                return Ok(());
            }
        }

        self.bank.delete(id);
        self.storage.save(&self.bank)?;

        println!("{} Prompt '{}' deleted.", "✓".green(), name);
        Ok(())
    }

    fn search_prompts(&self, query: &str) -> Result<()> {
        let prompts = self.bank.search(query);

        if prompts.is_empty() {
            println!("{} No prompts matching '{}'", "→".yellow(), query);
            return Ok(());
        }

        println!(
            "\n{} {} result(s) for '{}':\n",
            "→".blue(),
            prompts.len().to_string().cyan(),
            query
        );

        for prompt in prompts {
            self.print_prompt_summary(prompt, false);
        }

        Ok(())
    }

    fn export_prompts(&self, output: &PathBuf) -> Result<()> {
        self.storage.export(&self.bank, output)?;
        println!(
            "{} Exported {} prompts to {:?}",
            "✓".green(),
            self.bank.prompts.len(),
            output
        );
        Ok(())
    }

    fn import_prompts(&mut self, input: &PathBuf, merge: bool) -> Result<()> {
        let imported = self.storage.import(input)?;
        let count = imported.prompts.len();

        if merge {
            for prompt in imported.prompts {
                if self.bank.get(&prompt.id).is_none() {
                    self.bank.add(prompt);
                }
            }
        } else {
            self.bank = imported;
        }

        self.storage.save(&self.bank)?;
        println!(
            "{} Imported {} prompts from {:?}",
            "✓".green(),
            count,
            input
        );
        Ok(())
    }

    fn show_info(&self) -> Result<()> {
        println!("\n{}", "Promptbank Info".bold().underline());
        println!("  Data file: {:?}", self.storage.data_file_path());
        println!("  Total prompts: {}", self.bank.prompts.len());

        // Count by category
        let mut counts: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        for prompt in &self.bank.prompts {
            *counts.entry(prompt.category.to_string()).or_insert(0) += 1;
        }

        if !counts.is_empty() {
            println!("\n  {}:", "By category".dimmed());
            for (cat, count) in counts {
                println!("    {}: {}", cat, count);
            }
        }

        println!();
        Ok(())
    }

    fn update_self(&self) -> Result<()> {
        println!("{}", "Checking for updates...".dimmed());

        let current_version = env!("CARGO_PKG_VERSION");
        println!("  Current version: v{}", current_version.cyan());

        // Fetch latest release from GitHub
        let release_url = "https://api.github.com/repos/ff-vivek/promptbank/releases/latest";
        let response = match ureq::get(release_url)
            .set("User-Agent", "promptbank")
            .call() {
                Ok(r) => r,
                Err(_) => {
                    println!("  No binary releases found, using cargo install...\n");
                    return self.update_via_cargo();
                }
            };

        let release: serde_json::Value = response
            .into_json()
            .map_err(|e| PromptBankError::Storage(format!("Failed to parse release info: {}", e)))?;

        let latest_version = release["tag_name"]
            .as_str()
            .unwrap_or("unknown")
            .trim_start_matches('v');

        println!("  Latest version:  v{}", latest_version.cyan());

        if current_version == latest_version {
            println!("\n{} Already up to date!", "✓".green());
            return Ok(());
        }

        println!("\n{}", "Downloading update...".yellow());

        // Determine platform binary name
        let binary_name = self.get_platform_binary_name()?;

        // Find the download URL for our platform
        let assets = release["assets"].as_array()
            .ok_or_else(|| PromptBankError::Storage("No release assets found".to_string()))?;

        let asset = match assets
            .iter()
            .find(|a| a["name"].as_str().map_or(false, |n| n.contains(&binary_name))) {
                Some(a) => a,
                None => {
                    println!("  No binary for {}, using cargo install...\n", binary_name);
                    return self.update_via_cargo();
                }
            };

        let download_url = asset["browser_download_url"]
            .as_str()
            .ok_or_else(|| PromptBankError::Storage("No download URL found".to_string()))?;

        // Download the binary
        let response = ureq::get(download_url)
            .call()
            .map_err(|e| PromptBankError::Storage(format!("Failed to download: {}", e)))?;

        // Save to temp file
        let temp_dir = std::env::temp_dir();
        let tar_path = temp_dir.join(format!("{}.tar.gz", binary_name));
        let mut file = std::fs::File::create(&tar_path)?;
        std::io::copy(&mut response.into_reader(), &mut file)?;

        // Extract and install
        let current_exe = std::env::current_exe()
            .map_err(|e| PromptBankError::Storage(format!("Failed to get current exe path: {}", e)))?;

        // Extract using tar
        let status = std::process::Command::new("tar")
            .args(["-xzf", tar_path.to_str().unwrap(), "-C", temp_dir.to_str().unwrap()])
            .status()
            .map_err(|e| PromptBankError::Storage(format!("Failed to extract: {}", e)))?;

        if !status.success() {
            return Err(PromptBankError::Storage("Failed to extract archive".to_string()));
        }

        // Replace current binary
        let new_binary = temp_dir.join(&binary_name);

        // Make executable
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&new_binary, std::fs::Permissions::from_mode(0o755))?;
        }

        // Replace the binary
        std::fs::rename(&new_binary, &current_exe)
            .or_else(|_| {
                // If rename fails (cross-device), try copy
                std::fs::copy(&new_binary, &current_exe)?;
                std::fs::remove_file(&new_binary)?;
                Ok::<(), std::io::Error>(())
            })
            .map_err(|e| PromptBankError::Storage(format!("Failed to install: {}", e)))?;

        // Cleanup
        let _ = std::fs::remove_file(&tar_path);

        println!("\n{} Updated to v{}!", "✓".green(), latest_version);
        println!("  Restart your terminal to use the new version.");

        Ok(())
    }

    fn update_via_cargo(&self) -> Result<()> {
        println!("{}", "Updating via cargo install...".yellow());

        let status = std::process::Command::new("cargo")
            .args(["install", "promptbank", "--force"])
            .status()
            .map_err(|e| PromptBankError::Storage(format!("Failed to run cargo: {}", e)))?;

        if status.success() {
            println!("\n{} promptbank updated successfully!", "✓".green());
            println!("  Restart your terminal to use the new version.");
        } else {
            println!("\n{} Update failed. Try manually:", "✗".red());
            println!("  cargo install promptbank --force");
        }

        Ok(())
    }

    fn get_platform_binary_name(&self) -> Result<String> {
        let os = std::env::consts::OS;
        let arch = std::env::consts::ARCH;

        let name = match (os, arch) {
            ("macos", "x86_64") => "promptbank-macos-x86_64",
            ("macos", "aarch64") => "promptbank-macos-aarch64",
            ("linux", "x86_64") => "promptbank-linux-x86_64",
            ("linux", "aarch64") => "promptbank-linux-aarch64",
            _ => {
                return Err(PromptBankError::Storage(format!(
                    "Unsupported platform: {}-{}. Use 'cargo install promptbank' instead.",
                    os, arch
                )));
            }
        };

        Ok(name.to_string())
    }

    fn print_prompt_summary(&self, prompt: &Prompt, full: bool) {
        println!(
            "  {} {} [{}]",
            prompt.id.cyan(),
            prompt.name.bold(),
            prompt.category.to_string().yellow()
        );
        println!("    {}", prompt.description.dimmed());

        if !prompt.tags.is_empty() {
            println!("    Tags: {}", prompt.tags.join(", ").blue());
        }

        if !prompt.variables.is_empty() {
            println!(
                "    Variables: {}",
                prompt.variables.join(", ").magenta()
            );
        }

        if full {
            println!("\n{}", "─".repeat(50).dimmed());
            println!("{}", prompt.content);
            println!("{}\n", "─".repeat(50).dimmed());
        } else {
            println!();
        }
    }

    fn print_prompt_full(&self, prompt: &Prompt) {
        println!("\n{}", "═".repeat(60).dimmed());
        println!(
            "{}: {} ({})",
            "ID".bold(),
            prompt.id.cyan(),
            prompt.category.to_string().yellow()
        );
        println!("{}: {}", "Name".bold(), prompt.name);
        println!("{}: {}", "Description".bold(), prompt.description);

        if !prompt.tags.is_empty() {
            println!("{}: {}", "Tags".bold(), prompt.tags.join(", ").blue());
        }

        if !prompt.variables.is_empty() {
            println!(
                "{}: {}",
                "Variables".bold(),
                prompt.variables.join(", ").magenta()
            );
        }

        println!("{}: {}", "Created".bold(), prompt.created_at.format("%Y-%m-%d %H:%M"));
        println!("{}: {}", "Updated".bold(), prompt.updated_at.format("%Y-%m-%d %H:%M"));

        println!("\n{}", "Content:".bold().underline());
        println!("{}", "─".repeat(60).dimmed());
        println!("{}", prompt.content);
        println!("{}", "═".repeat(60).dimmed());
    }

    fn copy_to_clipboard(&self, text: &str) -> Result<()> {
        use arboard::Clipboard;

        let mut clipboard =
            Clipboard::new().map_err(|e| PromptBankError::Clipboard(e.to_string()))?;
        clipboard
            .set_text(text)
            .map_err(|e| PromptBankError::Clipboard(e.to_string()))?;
        Ok(())
    }
}
