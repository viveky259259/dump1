#!/bin/bash

# Netlify Deployment Script for Quill Web Editor Example
# This script builds the Flutter web app from the example folder and deploys it to Netlify
# Usage: ./deploy_netlify.sh [--prod|--draft]

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Netlify configuration
NETLIFY_SITE_ID="b2917f97-88da-4a33-9e24-16896fc29baa"
NETLIFY_SITE_NAME="quill-editor-demo"
NETLIFY_URL="https://quill-editor-demo.netlify.app"

# Script directory (root of Flutter project)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXAMPLE_DIR="${SCRIPT_DIR}/example"
BUILD_DIR="${EXAMPLE_DIR}/build/web"

# Parse command-line arguments
DEPLOY_TYPE="--prod"
if [ "$1" == "--draft" ]; then
    DEPLOY_TYPE="--draft"
fi

# Helper functions
info() {
    echo -e "${GREEN}✓${NC} $1"
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

error() {
    echo -e "${RED}❌${NC} $1"
}

step() {
    echo -e "${BLUE}→${NC} $1"
}

echo -e "${GREEN}🚀 Netlify Deployment Script${NC}"
echo "=========================================="
echo ""
echo "Site: ${NETLIFY_SITE_NAME}"
echo "URL:  ${NETLIFY_URL}"
echo "Type: ${DEPLOY_TYPE#--}"
echo ""

# Check 1: Verify we're in the correct directory
PUBSPEC_FILE="${SCRIPT_DIR}/pubspec.yaml"
if [ ! -f "$PUBSPEC_FILE" ]; then
    error "pubspec.yaml not found!"
    error "Expected: ${PUBSPEC_FILE}"
    echo ""
    echo "Please run this script from the root of your Flutter project"
    exit 1
fi

info "Project root verified"

# Check 2: Verify example directory exists
if [ ! -d "$EXAMPLE_DIR" ]; then
    error "Example directory not found!"
    error "Expected: ${EXAMPLE_DIR}"
    exit 1
fi

info "Example directory found"

# Check 3: Verify Flutter is installed
if ! command -v flutter &> /dev/null; then
    error "Flutter is not installed or not in PATH"
    echo "Please install Flutter: https://flutter.dev/docs/get-started/install"
    exit 1
fi

FLUTTER_VERSION=$(flutter --version | head -n 1)
info "Flutter found: ${FLUTTER_VERSION}"

# Check 4: Verify Netlify CLI is installed
if ! command -v netlify &> /dev/null; then
    error "Netlify CLI is not installed"
    echo ""
    echo "Please install Netlify CLI:"
    echo "  npm install -g netlify-cli"
    echo ""
    echo "Or using Homebrew (macOS):"
    echo "  brew install netlify-cli"
    exit 1
fi

NETLIFY_VERSION=$(netlify --version)
info "Netlify CLI found: ${NETLIFY_VERSION}"
echo ""

# Step 1: Navigate to example directory
step "Navigating to example directory..."
cd "${EXAMPLE_DIR}"

# Step 2: Get dependencies
step "Getting Flutter dependencies..."
flutter pub get
info "Dependencies retrieved"
echo ""

# Step 3: Clean previous build
step "Cleaning previous build..."
flutter clean
info "Build cleaned"
echo ""

# Step 4: Build for web
step "Building Flutter web app..."
flutter build web --release --pwa-strategy none
info "Build completed successfully"
echo ""

# Step 5: Verify build directory exists
if [ ! -d "$BUILD_DIR" ]; then
    error "Build directory not found!"
    error "Expected: ${BUILD_DIR}"
    exit 1
fi

# Verify index.html exists
if [ ! -f "${BUILD_DIR}/index.html" ]; then
    error "index.html not found in build directory!"
    exit 1
fi

info "Build artifacts verified"
echo ""

# Step 6: Deploy to Netlify
step "Deploying to Netlify..."
echo ""

# Use netlify deploy with the site ID
if [ "$DEPLOY_TYPE" == "--prod" ]; then
    netlify deploy --prod --dir="${BUILD_DIR}" --site="${NETLIFY_SITE_ID}"
else
    netlify deploy --dir="${BUILD_DIR}" --site="${NETLIFY_SITE_ID}"
fi

echo ""
info "Deployment completed successfully!"
echo ""
echo -e "${GREEN}✅ Your app is live at: ${NETLIFY_URL}${NC}"
echo ""
echo "To deploy a draft instead of production, use:"
echo "  ./deploy_netlify.sh --draft"
echo ""

exit 0


