import '/dk/form15_c_basic_details/form15_c_basic_details_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Form15C_BasicDetails component.
  late Form15CBasicDetailsModel form15CBasicDetailsModel;

  @override
  void initState(BuildContext context) {
    form15CBasicDetailsModel =
        createModel(context, () => Form15CBasicDetailsModel());
  }

  @override
  void dispose() {
    form15CBasicDetailsModel.dispose();
  }
}
