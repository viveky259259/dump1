import '/chetan/form_15_c_preview_and_download_wrap/form15_c_preview_and_download_wrap_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'demo_widget.dart' show DemoWidget;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_state.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_state;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DemoModel extends FlutterFlowModel<DemoWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Form_15C_Preview_and_Download_Wrap component.
  late Form15CPreviewAndDownloadWrapModel form15CPreviewAndDownloadWrapModel;

  @override
  void initState(BuildContext context) {
    form15CPreviewAndDownloadWrapModel =
        createModel(context, () => Form15CPreviewAndDownloadWrapModel());
  }

  @override
  void dispose() {
    form15CPreviewAndDownloadWrapModel.dispose();
  }
}
