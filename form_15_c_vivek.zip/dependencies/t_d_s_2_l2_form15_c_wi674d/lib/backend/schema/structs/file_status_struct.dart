// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums
    hide FFEnumExtensions, FFEnumListExtensions;

class FileStatusStruct extends BaseStruct {
  FileStatusStruct({
    String? fileName,
    String? keyPrefix,
    bool? isFileUploaded,
    String? uploadFailureMsg,
    t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus? status,
    double? height,
    double? width,
    String? fileSize,
    String? uploadSuccesMsg,
  })  : _fileName = fileName,
        _keyPrefix = keyPrefix,
        _isFileUploaded = isFileUploaded,
        _uploadFailureMsg = uploadFailureMsg,
        _status = status,
        _height = height,
        _width = width,
        _fileSize = fileSize,
        _uploadSuccesMsg = uploadSuccesMsg;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "keyPrefix" field.
  String? _keyPrefix;
  String get keyPrefix => _keyPrefix ?? '';
  set keyPrefix(String? val) => _keyPrefix = val;

  bool hasKeyPrefix() => _keyPrefix != null;

  // "isFileUploaded" field.
  bool? _isFileUploaded;
  bool get isFileUploaded => _isFileUploaded ?? false;
  set isFileUploaded(bool? val) => _isFileUploaded = val;

  bool hasIsFileUploaded() => _isFileUploaded != null;

  // "uploadFailureMsg" field.
  String? _uploadFailureMsg;
  String get uploadFailureMsg => _uploadFailureMsg ?? '';
  set uploadFailureMsg(String? val) => _uploadFailureMsg = val;

  bool hasUploadFailureMsg() => _uploadFailureMsg != null;

  // "status" field.
  t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus? _status;
  t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus? get status =>
      _status;
  set status(t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus? val) =>
      _status = val;

  bool hasStatus() => _status != null;

  // "height" field.
  double? _height;
  double get height => _height ?? 0.0;
  set height(double? val) => _height = val;

  void incrementHeight(double amount) => height = height + amount;

  bool hasHeight() => _height != null;

  // "width" field.
  double? _width;
  double get width => _width ?? 0.0;
  set width(double? val) => _width = val;

  void incrementWidth(double amount) => width = width + amount;

  bool hasWidth() => _width != null;

  // "fileSize" field.
  String? _fileSize;
  String get fileSize => _fileSize ?? '';
  set fileSize(String? val) => _fileSize = val;

  bool hasFileSize() => _fileSize != null;

  // "uploadSuccesMsg" field.
  String? _uploadSuccesMsg;
  String get uploadSuccesMsg => _uploadSuccesMsg ?? '';
  set uploadSuccesMsg(String? val) => _uploadSuccesMsg = val;

  bool hasUploadSuccesMsg() => _uploadSuccesMsg != null;

  static FileStatusStruct fromMap(Map<String, dynamic> data) =>
      FileStatusStruct(
        fileName: data['fileName'] as String?,
        keyPrefix: data['keyPrefix'] as String?,
        isFileUploaded: data['isFileUploaded'] as bool?,
        uploadFailureMsg: data['uploadFailureMsg'] as String?,
        status: data['status']
                is t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus
            ? data['status']
            : deserializeEnum<
                t_d_s_login_module_l1_input_vo62wv_enums
                .FileUploadStatus>(data['status']),
        height: castToType<double>(data['height']),
        width: castToType<double>(data['width']),
        fileSize: data['fileSize'] as String?,
        uploadSuccesMsg: data['uploadSuccesMsg'] as String?,
      );

  static FileStatusStruct? maybeFromMap(dynamic data) => data is Map
      ? FileStatusStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
        'keyPrefix': _keyPrefix,
        'isFileUploaded': _isFileUploaded,
        'uploadFailureMsg': _uploadFailureMsg,
        'status': _status?.serialize(),
        'height': _height,
        'width': _width,
        'fileSize': _fileSize,
        'uploadSuccesMsg': _uploadSuccesMsg,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'keyPrefix': serializeParam(
          _keyPrefix,
          ParamType.String,
        ),
        'isFileUploaded': serializeParam(
          _isFileUploaded,
          ParamType.bool,
        ),
        'uploadFailureMsg': serializeParam(
          _uploadFailureMsg,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.Enum,
        ),
        'height': serializeParam(
          _height,
          ParamType.double,
        ),
        'width': serializeParam(
          _width,
          ParamType.double,
        ),
        'fileSize': serializeParam(
          _fileSize,
          ParamType.String,
        ),
        'uploadSuccesMsg': serializeParam(
          _uploadSuccesMsg,
          ParamType.String,
        ),
      }.withoutNulls;

  static FileStatusStruct fromSerializableMap(Map<String, dynamic> data) =>
      FileStatusStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        keyPrefix: deserializeParam(
          data['keyPrefix'],
          ParamType.String,
          false,
        ),
        isFileUploaded: deserializeParam(
          data['isFileUploaded'],
          ParamType.bool,
          false,
        ),
        uploadFailureMsg: deserializeParam(
          data['uploadFailureMsg'],
          ParamType.String,
          false,
        ),
        status: deserializeParam<
            t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus>(
          data['status'],
          ParamType.Enum,
          false,
        ),
        height: deserializeParam(
          data['height'],
          ParamType.double,
          false,
        ),
        width: deserializeParam(
          data['width'],
          ParamType.double,
          false,
        ),
        fileSize: deserializeParam(
          data['fileSize'],
          ParamType.String,
          false,
        ),
        uploadSuccesMsg: deserializeParam(
          data['uploadSuccesMsg'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FileStatusStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FileStatusStruct &&
        fileName == other.fileName &&
        keyPrefix == other.keyPrefix &&
        isFileUploaded == other.isFileUploaded &&
        uploadFailureMsg == other.uploadFailureMsg &&
        status == other.status &&
        height == other.height &&
        width == other.width &&
        fileSize == other.fileSize &&
        uploadSuccesMsg == other.uploadSuccesMsg;
  }

  @override
  int get hashCode => const ListEquality().hash([
        fileName,
        keyPrefix,
        isFileUploaded,
        uploadFailureMsg,
        status,
        height,
        width,
        fileSize,
        uploadSuccesMsg
      ]);
}

FileStatusStruct createFileStatusStruct({
  String? fileName,
  String? keyPrefix,
  bool? isFileUploaded,
  String? uploadFailureMsg,
  t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus? status,
  double? height,
  double? width,
  String? fileSize,
  String? uploadSuccesMsg,
}) =>
    FileStatusStruct(
      fileName: fileName,
      keyPrefix: keyPrefix,
      isFileUploaded: isFileUploaded,
      uploadFailureMsg: uploadFailureMsg,
      status: status,
      height: height,
      width: width,
      fileSize: fileSize,
      uploadSuccesMsg: uploadSuccesMsg,
    );
