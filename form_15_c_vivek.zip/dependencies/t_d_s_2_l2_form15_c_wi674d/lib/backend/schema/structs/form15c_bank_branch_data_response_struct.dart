// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cBankBranchDataResponseStruct extends BaseStruct {
  Form15cBankBranchDataResponseStruct({
    String? message,
    String? status,
    List<Form15cBankBranchDataStruct>? data,
  })  : _message = message,
        _status = status,
        _data = data;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "data" field.
  List<Form15cBankBranchDataStruct>? _data;
  List<Form15cBankBranchDataStruct> get data => _data ?? const [];
  set data(List<Form15cBankBranchDataStruct>? val) => _data = val;

  void updateData(Function(List<Form15cBankBranchDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  static Form15cBankBranchDataResponseStruct fromMap(
          Map<String, dynamic> data) =>
      Form15cBankBranchDataResponseStruct(
        message: data['message'] as String?,
        status: data['status'] as String?,
        data: getStructList(
          data['data'],
          Form15cBankBranchDataStruct.fromMap,
        ),
      );

  static Form15cBankBranchDataResponseStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? Form15cBankBranchDataResponseStruct.fromMap(
              data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'message': _message,
        'status': _status,
        'data': _data?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static Form15cBankBranchDataResponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cBankBranchDataResponseStruct(
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
        data: deserializeStructParam<Form15cBankBranchDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: Form15cBankBranchDataStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'Form15cBankBranchDataResponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is Form15cBankBranchDataResponseStruct &&
        message == other.message &&
        status == other.status &&
        listEquality.equals(data, other.data);
  }

  @override
  int get hashCode => const ListEquality().hash([message, status, data]);
}

Form15cBankBranchDataResponseStruct createForm15cBankBranchDataResponseStruct({
  String? message,
  String? status,
}) =>
    Form15cBankBranchDataResponseStruct(
      message: message,
      status: status,
    );
