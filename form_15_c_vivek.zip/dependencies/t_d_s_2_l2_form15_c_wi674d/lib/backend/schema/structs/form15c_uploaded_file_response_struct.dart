// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cUploadedFileResponseStruct extends BaseStruct {
  Form15cUploadedFileResponseStruct({
    List<Form15cUploadedFilesDataStruct>? files,
  }) : _files = files;

  // "files" field.
  List<Form15cUploadedFilesDataStruct>? _files;
  List<Form15cUploadedFilesDataStruct> get files => _files ?? const [];
  set files(List<Form15cUploadedFilesDataStruct>? val) => _files = val;

  void updateFiles(Function(List<Form15cUploadedFilesDataStruct>) updateFn) {
    updateFn(_files ??= []);
  }

  bool hasFiles() => _files != null;

  static Form15cUploadedFileResponseStruct fromMap(Map<String, dynamic> data) =>
      Form15cUploadedFileResponseStruct(
        files: getStructList(
          data['files'],
          Form15cUploadedFilesDataStruct.fromMap,
        ),
      );

  static Form15cUploadedFileResponseStruct? maybeFromMap(dynamic data) => data
          is Map
      ? Form15cUploadedFileResponseStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'files': _files?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'files': serializeParam(
          _files,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static Form15cUploadedFileResponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cUploadedFileResponseStruct(
        files: deserializeStructParam<Form15cUploadedFilesDataStruct>(
          data['files'],
          ParamType.DataStruct,
          true,
          structBuilder: Form15cUploadedFilesDataStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'Form15cUploadedFileResponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is Form15cUploadedFileResponseStruct &&
        listEquality.equals(files, other.files);
  }

  @override
  int get hashCode => const ListEquality().hash([files]);
}

Form15cUploadedFileResponseStruct createForm15cUploadedFileResponseStruct() =>
    Form15cUploadedFileResponseStruct();
