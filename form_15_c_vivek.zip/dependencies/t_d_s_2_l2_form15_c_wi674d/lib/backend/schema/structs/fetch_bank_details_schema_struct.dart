// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FetchBankDetailsSchemaStruct extends BaseStruct {
  FetchBankDetailsSchemaStruct({
    int? id,
    String? country,
    String? flat,
    String? block,
    String? pincode,
    String? postOffice,
    String? areaLocality,
    String? district,
    String? state,
    String? panNumber,
    bool? isCurrentlyEditing,
  })  : _id = id,
        _country = country,
        _flat = flat,
        _block = block,
        _pincode = pincode,
        _postOffice = postOffice,
        _areaLocality = areaLocality,
        _district = district,
        _state = state,
        _panNumber = panNumber,
        _isCurrentlyEditing = isCurrentlyEditing;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  set country(String? val) => _country = val;

  bool hasCountry() => _country != null;

  // "flat" field.
  String? _flat;
  String get flat => _flat ?? '';
  set flat(String? val) => _flat = val;

  bool hasFlat() => _flat != null;

  // "block" field.
  String? _block;
  String get block => _block ?? '';
  set block(String? val) => _block = val;

  bool hasBlock() => _block != null;

  // "pincode" field.
  String? _pincode;
  String get pincode => _pincode ?? '';
  set pincode(String? val) => _pincode = val;

  bool hasPincode() => _pincode != null;

  // "postOffice" field.
  String? _postOffice;
  String get postOffice => _postOffice ?? '';
  set postOffice(String? val) => _postOffice = val;

  bool hasPostOffice() => _postOffice != null;

  // "areaLocality" field.
  String? _areaLocality;
  String get areaLocality => _areaLocality ?? '';
  set areaLocality(String? val) => _areaLocality = val;

  bool hasAreaLocality() => _areaLocality != null;

  // "district" field.
  String? _district;
  String get district => _district ?? '';
  set district(String? val) => _district = val;

  bool hasDistrict() => _district != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "panNumber" field.
  String? _panNumber;
  String get panNumber => _panNumber ?? '';
  set panNumber(String? val) => _panNumber = val;

  bool hasPanNumber() => _panNumber != null;

  // "isCurrentlyEditing" field.
  bool? _isCurrentlyEditing;
  bool get isCurrentlyEditing => _isCurrentlyEditing ?? false;
  set isCurrentlyEditing(bool? val) => _isCurrentlyEditing = val;

  bool hasIsCurrentlyEditing() => _isCurrentlyEditing != null;

  static FetchBankDetailsSchemaStruct fromMap(Map<String, dynamic> data) =>
      FetchBankDetailsSchemaStruct(
        id: castToType<int>(data['id']),
        country: data['country'] as String?,
        flat: data['flat'] as String?,
        block: data['block'] as String?,
        pincode: data['pincode'] as String?,
        postOffice: data['postOffice'] as String?,
        areaLocality: data['areaLocality'] as String?,
        district: data['district'] as String?,
        state: data['state'] as String?,
        panNumber: data['panNumber'] as String?,
        isCurrentlyEditing: data['isCurrentlyEditing'] as bool?,
      );

  static FetchBankDetailsSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? FetchBankDetailsSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'country': _country,
        'flat': _flat,
        'block': _block,
        'pincode': _pincode,
        'postOffice': _postOffice,
        'areaLocality': _areaLocality,
        'district': _district,
        'state': _state,
        'panNumber': _panNumber,
        'isCurrentlyEditing': _isCurrentlyEditing,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'country': serializeParam(
          _country,
          ParamType.String,
        ),
        'flat': serializeParam(
          _flat,
          ParamType.String,
        ),
        'block': serializeParam(
          _block,
          ParamType.String,
        ),
        'pincode': serializeParam(
          _pincode,
          ParamType.String,
        ),
        'postOffice': serializeParam(
          _postOffice,
          ParamType.String,
        ),
        'areaLocality': serializeParam(
          _areaLocality,
          ParamType.String,
        ),
        'district': serializeParam(
          _district,
          ParamType.String,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'panNumber': serializeParam(
          _panNumber,
          ParamType.String,
        ),
        'isCurrentlyEditing': serializeParam(
          _isCurrentlyEditing,
          ParamType.bool,
        ),
      }.withoutNulls;

  static FetchBankDetailsSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FetchBankDetailsSchemaStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        country: deserializeParam(
          data['country'],
          ParamType.String,
          false,
        ),
        flat: deserializeParam(
          data['flat'],
          ParamType.String,
          false,
        ),
        block: deserializeParam(
          data['block'],
          ParamType.String,
          false,
        ),
        pincode: deserializeParam(
          data['pincode'],
          ParamType.String,
          false,
        ),
        postOffice: deserializeParam(
          data['postOffice'],
          ParamType.String,
          false,
        ),
        areaLocality: deserializeParam(
          data['areaLocality'],
          ParamType.String,
          false,
        ),
        district: deserializeParam(
          data['district'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        panNumber: deserializeParam(
          data['panNumber'],
          ParamType.String,
          false,
        ),
        isCurrentlyEditing: deserializeParam(
          data['isCurrentlyEditing'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'FetchBankDetailsSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FetchBankDetailsSchemaStruct &&
        id == other.id &&
        country == other.country &&
        flat == other.flat &&
        block == other.block &&
        pincode == other.pincode &&
        postOffice == other.postOffice &&
        areaLocality == other.areaLocality &&
        district == other.district &&
        state == other.state &&
        panNumber == other.panNumber &&
        isCurrentlyEditing == other.isCurrentlyEditing;
  }

  @override
  int get hashCode => const ListEquality().hash([
        id,
        country,
        flat,
        block,
        pincode,
        postOffice,
        areaLocality,
        district,
        state,
        panNumber,
        isCurrentlyEditing
      ]);
}

FetchBankDetailsSchemaStruct createFetchBankDetailsSchemaStruct({
  int? id,
  String? country,
  String? flat,
  String? block,
  String? pincode,
  String? postOffice,
  String? areaLocality,
  String? district,
  String? state,
  String? panNumber,
  bool? isCurrentlyEditing,
}) =>
    FetchBankDetailsSchemaStruct(
      id: id,
      country: country,
      flat: flat,
      block: block,
      pincode: pincode,
      postOffice: postOffice,
      areaLocality: areaLocality,
      district: district,
      state: state,
      panNumber: panNumber,
      isCurrentlyEditing: isCurrentlyEditing,
    );
