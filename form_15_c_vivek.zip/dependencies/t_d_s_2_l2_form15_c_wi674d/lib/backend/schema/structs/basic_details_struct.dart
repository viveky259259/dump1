// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BasicDetailsStruct extends BaseStruct {
  BasicDetailsStruct({
    String? pANNumber,
    String? natureOfBusiness,
    String? nameOfBankingCompany,
    String? permanentEstablishmentInIndia,
    String? emailID,
    String? mobNo,
    String? altEmailID,
    String? altMobNo,
    String? state,
    String? district,
    String? headOfficeOfAplplicantOutsideIndia,
    int? noOfBranches,
  })  : _pANNumber = pANNumber,
        _natureOfBusiness = natureOfBusiness,
        _nameOfBankingCompany = nameOfBankingCompany,
        _permanentEstablishmentInIndia = permanentEstablishmentInIndia,
        _emailID = emailID,
        _mobNo = mobNo,
        _altEmailID = altEmailID,
        _altMobNo = altMobNo,
        _state = state,
        _district = district,
        _headOfficeOfAplplicantOutsideIndia =
            headOfficeOfAplplicantOutsideIndia,
        _noOfBranches = noOfBranches;

  // "PAN_number" field.
  String? _pANNumber;
  String get pANNumber => _pANNumber ?? '';
  set pANNumber(String? val) => _pANNumber = val;

  bool hasPANNumber() => _pANNumber != null;

  // "nature_of_business" field.
  String? _natureOfBusiness;
  String get natureOfBusiness => _natureOfBusiness ?? '';
  set natureOfBusiness(String? val) => _natureOfBusiness = val;

  bool hasNatureOfBusiness() => _natureOfBusiness != null;

  // "name_of_banking_company" field.
  String? _nameOfBankingCompany;
  String get nameOfBankingCompany => _nameOfBankingCompany ?? '';
  set nameOfBankingCompany(String? val) => _nameOfBankingCompany = val;

  bool hasNameOfBankingCompany() => _nameOfBankingCompany != null;

  // "permanent_establishment_in_india" field.
  String? _permanentEstablishmentInIndia;
  String get permanentEstablishmentInIndia =>
      _permanentEstablishmentInIndia ?? '';
  set permanentEstablishmentInIndia(String? val) =>
      _permanentEstablishmentInIndia = val;

  bool hasPermanentEstablishmentInIndia() =>
      _permanentEstablishmentInIndia != null;

  // "emailID" field.
  String? _emailID;
  String get emailID => _emailID ?? '';
  set emailID(String? val) => _emailID = val;

  bool hasEmailID() => _emailID != null;

  // "mob_no" field.
  String? _mobNo;
  String get mobNo => _mobNo ?? '';
  set mobNo(String? val) => _mobNo = val;

  bool hasMobNo() => _mobNo != null;

  // "alt_emailID" field.
  String? _altEmailID;
  String get altEmailID => _altEmailID ?? '';
  set altEmailID(String? val) => _altEmailID = val;

  bool hasAltEmailID() => _altEmailID != null;

  // "alt_mob_no" field.
  String? _altMobNo;
  String get altMobNo => _altMobNo ?? '';
  set altMobNo(String? val) => _altMobNo = val;

  bool hasAltMobNo() => _altMobNo != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "district" field.
  String? _district;
  String get district => _district ?? '';
  set district(String? val) => _district = val;

  bool hasDistrict() => _district != null;

  // "head_office_of_aplplicant_outside_india" field.
  String? _headOfficeOfAplplicantOutsideIndia;
  String get headOfficeOfAplplicantOutsideIndia =>
      _headOfficeOfAplplicantOutsideIndia ?? '';
  set headOfficeOfAplplicantOutsideIndia(String? val) =>
      _headOfficeOfAplplicantOutsideIndia = val;

  bool hasHeadOfficeOfAplplicantOutsideIndia() =>
      _headOfficeOfAplplicantOutsideIndia != null;

  // "no_of_branches" field.
  int? _noOfBranches;
  int get noOfBranches => _noOfBranches ?? 0;
  set noOfBranches(int? val) => _noOfBranches = val;

  void incrementNoOfBranches(int amount) =>
      noOfBranches = noOfBranches + amount;

  bool hasNoOfBranches() => _noOfBranches != null;

  static BasicDetailsStruct fromMap(Map<String, dynamic> data) =>
      BasicDetailsStruct(
        pANNumber: data['PAN_number'] as String?,
        natureOfBusiness: data['nature_of_business'] as String?,
        nameOfBankingCompany: data['name_of_banking_company'] as String?,
        permanentEstablishmentInIndia:
            data['permanent_establishment_in_india'] as String?,
        emailID: data['emailID'] as String?,
        mobNo: data['mob_no'] as String?,
        altEmailID: data['alt_emailID'] as String?,
        altMobNo: data['alt_mob_no'] as String?,
        state: data['state'] as String?,
        district: data['district'] as String?,
        headOfficeOfAplplicantOutsideIndia:
            data['head_office_of_aplplicant_outside_india'] as String?,
        noOfBranches: castToType<int>(data['no_of_branches']),
      );

  static BasicDetailsStruct? maybeFromMap(dynamic data) => data is Map
      ? BasicDetailsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'PAN_number': _pANNumber,
        'nature_of_business': _natureOfBusiness,
        'name_of_banking_company': _nameOfBankingCompany,
        'permanent_establishment_in_india': _permanentEstablishmentInIndia,
        'emailID': _emailID,
        'mob_no': _mobNo,
        'alt_emailID': _altEmailID,
        'alt_mob_no': _altMobNo,
        'state': _state,
        'district': _district,
        'head_office_of_aplplicant_outside_india':
            _headOfficeOfAplplicantOutsideIndia,
        'no_of_branches': _noOfBranches,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'PAN_number': serializeParam(
          _pANNumber,
          ParamType.String,
        ),
        'nature_of_business': serializeParam(
          _natureOfBusiness,
          ParamType.String,
        ),
        'name_of_banking_company': serializeParam(
          _nameOfBankingCompany,
          ParamType.String,
        ),
        'permanent_establishment_in_india': serializeParam(
          _permanentEstablishmentInIndia,
          ParamType.String,
        ),
        'emailID': serializeParam(
          _emailID,
          ParamType.String,
        ),
        'mob_no': serializeParam(
          _mobNo,
          ParamType.String,
        ),
        'alt_emailID': serializeParam(
          _altEmailID,
          ParamType.String,
        ),
        'alt_mob_no': serializeParam(
          _altMobNo,
          ParamType.String,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'district': serializeParam(
          _district,
          ParamType.String,
        ),
        'head_office_of_aplplicant_outside_india': serializeParam(
          _headOfficeOfAplplicantOutsideIndia,
          ParamType.String,
        ),
        'no_of_branches': serializeParam(
          _noOfBranches,
          ParamType.int,
        ),
      }.withoutNulls;

  static BasicDetailsStruct fromSerializableMap(Map<String, dynamic> data) =>
      BasicDetailsStruct(
        pANNumber: deserializeParam(
          data['PAN_number'],
          ParamType.String,
          false,
        ),
        natureOfBusiness: deserializeParam(
          data['nature_of_business'],
          ParamType.String,
          false,
        ),
        nameOfBankingCompany: deserializeParam(
          data['name_of_banking_company'],
          ParamType.String,
          false,
        ),
        permanentEstablishmentInIndia: deserializeParam(
          data['permanent_establishment_in_india'],
          ParamType.String,
          false,
        ),
        emailID: deserializeParam(
          data['emailID'],
          ParamType.String,
          false,
        ),
        mobNo: deserializeParam(
          data['mob_no'],
          ParamType.String,
          false,
        ),
        altEmailID: deserializeParam(
          data['alt_emailID'],
          ParamType.String,
          false,
        ),
        altMobNo: deserializeParam(
          data['alt_mob_no'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        district: deserializeParam(
          data['district'],
          ParamType.String,
          false,
        ),
        headOfficeOfAplplicantOutsideIndia: deserializeParam(
          data['head_office_of_aplplicant_outside_india'],
          ParamType.String,
          false,
        ),
        noOfBranches: deserializeParam(
          data['no_of_branches'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'BasicDetailsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is BasicDetailsStruct &&
        pANNumber == other.pANNumber &&
        natureOfBusiness == other.natureOfBusiness &&
        nameOfBankingCompany == other.nameOfBankingCompany &&
        permanentEstablishmentInIndia == other.permanentEstablishmentInIndia &&
        emailID == other.emailID &&
        mobNo == other.mobNo &&
        altEmailID == other.altEmailID &&
        altMobNo == other.altMobNo &&
        state == other.state &&
        district == other.district &&
        headOfficeOfAplplicantOutsideIndia ==
            other.headOfficeOfAplplicantOutsideIndia &&
        noOfBranches == other.noOfBranches;
  }

  @override
  int get hashCode => const ListEquality().hash([
        pANNumber,
        natureOfBusiness,
        nameOfBankingCompany,
        permanentEstablishmentInIndia,
        emailID,
        mobNo,
        altEmailID,
        altMobNo,
        state,
        district,
        headOfficeOfAplplicantOutsideIndia,
        noOfBranches
      ]);
}

BasicDetailsStruct createBasicDetailsStruct({
  String? pANNumber,
  String? natureOfBusiness,
  String? nameOfBankingCompany,
  String? permanentEstablishmentInIndia,
  String? emailID,
  String? mobNo,
  String? altEmailID,
  String? altMobNo,
  String? state,
  String? district,
  String? headOfficeOfAplplicantOutsideIndia,
  int? noOfBranches,
}) =>
    BasicDetailsStruct(
      pANNumber: pANNumber,
      natureOfBusiness: natureOfBusiness,
      nameOfBankingCompany: nameOfBankingCompany,
      permanentEstablishmentInIndia: permanentEstablishmentInIndia,
      emailID: emailID,
      mobNo: mobNo,
      altEmailID: altEmailID,
      altMobNo: altMobNo,
      state: state,
      district: district,
      headOfficeOfAplplicantOutsideIndia: headOfficeOfAplplicantOutsideIndia,
      noOfBranches: noOfBranches,
    );
