// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cUploadedFilesDataStruct extends BaseStruct {
  Form15cUploadedFilesDataStruct({
    int? id,
    String? panNumber,
    String? serviceName,
    String? fileName,
    String? fileType,
    String? documentDescription,
    int? size,
    String? fileData,
    String? uploadTime,
  })  : _id = id,
        _panNumber = panNumber,
        _serviceName = serviceName,
        _fileName = fileName,
        _fileType = fileType,
        _documentDescription = documentDescription,
        _size = size,
        _fileData = fileData,
        _uploadTime = uploadTime;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "panNumber" field.
  String? _panNumber;
  String get panNumber => _panNumber ?? '';
  set panNumber(String? val) => _panNumber = val;

  bool hasPanNumber() => _panNumber != null;

  // "serviceName" field.
  String? _serviceName;
  String get serviceName => _serviceName ?? '';
  set serviceName(String? val) => _serviceName = val;

  bool hasServiceName() => _serviceName != null;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "fileType" field.
  String? _fileType;
  String get fileType => _fileType ?? '';
  set fileType(String? val) => _fileType = val;

  bool hasFileType() => _fileType != null;

  // "documentDescription" field.
  String? _documentDescription;
  String get documentDescription => _documentDescription ?? '';
  set documentDescription(String? val) => _documentDescription = val;

  bool hasDocumentDescription() => _documentDescription != null;

  // "size" field.
  int? _size;
  int get size => _size ?? 0;
  set size(int? val) => _size = val;

  void incrementSize(int amount) => size = size + amount;

  bool hasSize() => _size != null;

  // "fileData" field.
  String? _fileData;
  String get fileData => _fileData ?? '';
  set fileData(String? val) => _fileData = val;

  bool hasFileData() => _fileData != null;

  // "uploadTime" field.
  String? _uploadTime;
  String get uploadTime => _uploadTime ?? '';
  set uploadTime(String? val) => _uploadTime = val;

  bool hasUploadTime() => _uploadTime != null;

  static Form15cUploadedFilesDataStruct fromMap(Map<String, dynamic> data) =>
      Form15cUploadedFilesDataStruct(
        id: castToType<int>(data['id']),
        panNumber: data['panNumber'] as String?,
        serviceName: data['serviceName'] as String?,
        fileName: data['fileName'] as String?,
        fileType: data['fileType'] as String?,
        documentDescription: data['documentDescription'] as String?,
        size: castToType<int>(data['size']),
        fileData: data['fileData'] as String?,
        uploadTime: data['uploadTime'] as String?,
      );

  static Form15cUploadedFilesDataStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? Form15cUploadedFilesDataStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'panNumber': _panNumber,
        'serviceName': _serviceName,
        'fileName': _fileName,
        'fileType': _fileType,
        'documentDescription': _documentDescription,
        'size': _size,
        'fileData': _fileData,
        'uploadTime': _uploadTime,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'panNumber': serializeParam(
          _panNumber,
          ParamType.String,
        ),
        'serviceName': serializeParam(
          _serviceName,
          ParamType.String,
        ),
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'fileType': serializeParam(
          _fileType,
          ParamType.String,
        ),
        'documentDescription': serializeParam(
          _documentDescription,
          ParamType.String,
        ),
        'size': serializeParam(
          _size,
          ParamType.int,
        ),
        'fileData': serializeParam(
          _fileData,
          ParamType.String,
        ),
        'uploadTime': serializeParam(
          _uploadTime,
          ParamType.String,
        ),
      }.withoutNulls;

  static Form15cUploadedFilesDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cUploadedFilesDataStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        panNumber: deserializeParam(
          data['panNumber'],
          ParamType.String,
          false,
        ),
        serviceName: deserializeParam(
          data['serviceName'],
          ParamType.String,
          false,
        ),
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        fileType: deserializeParam(
          data['fileType'],
          ParamType.String,
          false,
        ),
        documentDescription: deserializeParam(
          data['documentDescription'],
          ParamType.String,
          false,
        ),
        size: deserializeParam(
          data['size'],
          ParamType.int,
          false,
        ),
        fileData: deserializeParam(
          data['fileData'],
          ParamType.String,
          false,
        ),
        uploadTime: deserializeParam(
          data['uploadTime'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Form15cUploadedFilesDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Form15cUploadedFilesDataStruct &&
        id == other.id &&
        panNumber == other.panNumber &&
        serviceName == other.serviceName &&
        fileName == other.fileName &&
        fileType == other.fileType &&
        documentDescription == other.documentDescription &&
        size == other.size &&
        fileData == other.fileData &&
        uploadTime == other.uploadTime;
  }

  @override
  int get hashCode => const ListEquality().hash([
        id,
        panNumber,
        serviceName,
        fileName,
        fileType,
        documentDescription,
        size,
        fileData,
        uploadTime
      ]);
}

Form15cUploadedFilesDataStruct createForm15cUploadedFilesDataStruct({
  int? id,
  String? panNumber,
  String? serviceName,
  String? fileName,
  String? fileType,
  String? documentDescription,
  int? size,
  String? fileData,
  String? uploadTime,
}) =>
    Form15cUploadedFilesDataStruct(
      id: id,
      panNumber: panNumber,
      serviceName: serviceName,
      fileName: fileName,
      fileType: fileType,
      documentDescription: documentDescription,
      size: size,
      fileData: fileData,
      uploadTime: uploadTime,
    );
