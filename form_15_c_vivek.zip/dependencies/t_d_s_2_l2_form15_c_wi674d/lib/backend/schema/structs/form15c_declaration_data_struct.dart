// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cDeclarationDataStruct extends BaseStruct {
  Form15cDeclarationDataStruct({
    String? date,
    String? applicationType,
    String? phoneNumber,
    String? residentialStatus,
    String? ipAddress,
    List<String>? fiscalyears,
    String? emailId,
    String? panNumber,
    String? state,
    String? submissionMode,
    String? place,
  })  : _date = date,
        _applicationType = applicationType,
        _phoneNumber = phoneNumber,
        _residentialStatus = residentialStatus,
        _ipAddress = ipAddress,
        _fiscalyears = fiscalyears,
        _emailId = emailId,
        _panNumber = panNumber,
        _state = state,
        _submissionMode = submissionMode,
        _place = place;

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  set date(String? val) => _date = val;

  bool hasDate() => _date != null;

  // "applicationType" field.
  String? _applicationType;
  String get applicationType => _applicationType ?? '';
  set applicationType(String? val) => _applicationType = val;

  bool hasApplicationType() => _applicationType != null;

  // "phoneNumber" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  set phoneNumber(String? val) => _phoneNumber = val;

  bool hasPhoneNumber() => _phoneNumber != null;

  // "residentialStatus" field.
  String? _residentialStatus;
  String get residentialStatus => _residentialStatus ?? '';
  set residentialStatus(String? val) => _residentialStatus = val;

  bool hasResidentialStatus() => _residentialStatus != null;

  // "ipAddress" field.
  String? _ipAddress;
  String get ipAddress => _ipAddress ?? '';
  set ipAddress(String? val) => _ipAddress = val;

  bool hasIpAddress() => _ipAddress != null;

  // "fiscalyears" field.
  List<String>? _fiscalyears;
  List<String> get fiscalyears => _fiscalyears ?? const [];
  set fiscalyears(List<String>? val) => _fiscalyears = val;

  void updateFiscalyears(Function(List<String>) updateFn) {
    updateFn(_fiscalyears ??= []);
  }

  bool hasFiscalyears() => _fiscalyears != null;

  // "emailId" field.
  String? _emailId;
  String get emailId => _emailId ?? '';
  set emailId(String? val) => _emailId = val;

  bool hasEmailId() => _emailId != null;

  // "panNumber" field.
  String? _panNumber;
  String get panNumber => _panNumber ?? '';
  set panNumber(String? val) => _panNumber = val;

  bool hasPanNumber() => _panNumber != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "submissionMode" field.
  String? _submissionMode;
  String get submissionMode => _submissionMode ?? '';
  set submissionMode(String? val) => _submissionMode = val;

  bool hasSubmissionMode() => _submissionMode != null;

  // "place" field.
  String? _place;
  String get place => _place ?? '';
  set place(String? val) => _place = val;

  bool hasPlace() => _place != null;

  static Form15cDeclarationDataStruct fromMap(Map<String, dynamic> data) =>
      Form15cDeclarationDataStruct(
        date: data['date'] as String?,
        applicationType: data['applicationType'] as String?,
        phoneNumber: data['phoneNumber'] as String?,
        residentialStatus: data['residentialStatus'] as String?,
        ipAddress: data['ipAddress'] as String?,
        fiscalyears: getDataList(data['fiscalyears']),
        emailId: data['emailId'] as String?,
        panNumber: data['panNumber'] as String?,
        state: data['state'] as String?,
        submissionMode: data['submissionMode'] as String?,
        place: data['place'] as String?,
      );

  static Form15cDeclarationDataStruct? maybeFromMap(dynamic data) => data is Map
      ? Form15cDeclarationDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'date': _date,
        'applicationType': _applicationType,
        'phoneNumber': _phoneNumber,
        'residentialStatus': _residentialStatus,
        'ipAddress': _ipAddress,
        'fiscalyears': _fiscalyears,
        'emailId': _emailId,
        'panNumber': _panNumber,
        'state': _state,
        'submissionMode': _submissionMode,
        'place': _place,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'date': serializeParam(
          _date,
          ParamType.String,
        ),
        'applicationType': serializeParam(
          _applicationType,
          ParamType.String,
        ),
        'phoneNumber': serializeParam(
          _phoneNumber,
          ParamType.String,
        ),
        'residentialStatus': serializeParam(
          _residentialStatus,
          ParamType.String,
        ),
        'ipAddress': serializeParam(
          _ipAddress,
          ParamType.String,
        ),
        'fiscalyears': serializeParam(
          _fiscalyears,
          ParamType.String,
          isList: true,
        ),
        'emailId': serializeParam(
          _emailId,
          ParamType.String,
        ),
        'panNumber': serializeParam(
          _panNumber,
          ParamType.String,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'submissionMode': serializeParam(
          _submissionMode,
          ParamType.String,
        ),
        'place': serializeParam(
          _place,
          ParamType.String,
        ),
      }.withoutNulls;

  static Form15cDeclarationDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cDeclarationDataStruct(
        date: deserializeParam(
          data['date'],
          ParamType.String,
          false,
        ),
        applicationType: deserializeParam(
          data['applicationType'],
          ParamType.String,
          false,
        ),
        phoneNumber: deserializeParam(
          data['phoneNumber'],
          ParamType.String,
          false,
        ),
        residentialStatus: deserializeParam(
          data['residentialStatus'],
          ParamType.String,
          false,
        ),
        ipAddress: deserializeParam(
          data['ipAddress'],
          ParamType.String,
          false,
        ),
        fiscalyears: deserializeParam<String>(
          data['fiscalyears'],
          ParamType.String,
          true,
        ),
        emailId: deserializeParam(
          data['emailId'],
          ParamType.String,
          false,
        ),
        panNumber: deserializeParam(
          data['panNumber'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        submissionMode: deserializeParam(
          data['submissionMode'],
          ParamType.String,
          false,
        ),
        place: deserializeParam(
          data['place'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Form15cDeclarationDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is Form15cDeclarationDataStruct &&
        date == other.date &&
        applicationType == other.applicationType &&
        phoneNumber == other.phoneNumber &&
        residentialStatus == other.residentialStatus &&
        ipAddress == other.ipAddress &&
        listEquality.equals(fiscalyears, other.fiscalyears) &&
        emailId == other.emailId &&
        panNumber == other.panNumber &&
        state == other.state &&
        submissionMode == other.submissionMode &&
        place == other.place;
  }

  @override
  int get hashCode => const ListEquality().hash([
        date,
        applicationType,
        phoneNumber,
        residentialStatus,
        ipAddress,
        fiscalyears,
        emailId,
        panNumber,
        state,
        submissionMode,
        place
      ]);
}

Form15cDeclarationDataStruct createForm15cDeclarationDataStruct({
  String? date,
  String? applicationType,
  String? phoneNumber,
  String? residentialStatus,
  String? ipAddress,
  String? emailId,
  String? panNumber,
  String? state,
  String? submissionMode,
  String? place,
}) =>
    Form15cDeclarationDataStruct(
      date: date,
      applicationType: applicationType,
      phoneNumber: phoneNumber,
      residentialStatus: residentialStatus,
      ipAddress: ipAddress,
      emailId: emailId,
      panNumber: panNumber,
      state: state,
      submissionMode: submissionMode,
      place: place,
    );
