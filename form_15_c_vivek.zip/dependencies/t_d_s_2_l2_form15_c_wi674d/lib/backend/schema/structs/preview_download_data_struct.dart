// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PreviewDownloadDataStruct extends BaseStruct {
  PreviewDownloadDataStruct({
    String? submisstionMode,
    String? applicationType,
    String? residentialStatus,
    String? financialYear,
    String? panNumber,
    String? natureOfBusiness,
    String? bankingCompanyName,
    String? permanentEstablishement,
    String? emailID,
    int? mobNumber,
    String? alternateEmailID,
    int? alternateMobNumber,
    String? state,
    String? district,
    String? headOffice,
    int? numberOfBranches,
    String? status,
    String? place,
    String? date,
    String? ipAddress,
  })  : _submisstionMode = submisstionMode,
        _applicationType = applicationType,
        _residentialStatus = residentialStatus,
        _financialYear = financialYear,
        _panNumber = panNumber,
        _natureOfBusiness = natureOfBusiness,
        _bankingCompanyName = bankingCompanyName,
        _permanentEstablishement = permanentEstablishement,
        _emailID = emailID,
        _mobNumber = mobNumber,
        _alternateEmailID = alternateEmailID,
        _alternateMobNumber = alternateMobNumber,
        _state = state,
        _district = district,
        _headOffice = headOffice,
        _numberOfBranches = numberOfBranches,
        _status = status,
        _place = place,
        _date = date,
        _ipAddress = ipAddress;

  // "submisstionMode" field.
  String? _submisstionMode;
  String get submisstionMode => _submisstionMode ?? '';
  set submisstionMode(String? val) => _submisstionMode = val;

  bool hasSubmisstionMode() => _submisstionMode != null;

  // "applicationType" field.
  String? _applicationType;
  String get applicationType => _applicationType ?? '';
  set applicationType(String? val) => _applicationType = val;

  bool hasApplicationType() => _applicationType != null;

  // "residentialStatus" field.
  String? _residentialStatus;
  String get residentialStatus => _residentialStatus ?? '';
  set residentialStatus(String? val) => _residentialStatus = val;

  bool hasResidentialStatus() => _residentialStatus != null;

  // "financialYear" field.
  String? _financialYear;
  String get financialYear => _financialYear ?? '';
  set financialYear(String? val) => _financialYear = val;

  bool hasFinancialYear() => _financialYear != null;

  // "panNumber" field.
  String? _panNumber;
  String get panNumber => _panNumber ?? '';
  set panNumber(String? val) => _panNumber = val;

  bool hasPanNumber() => _panNumber != null;

  // "natureOfBusiness" field.
  String? _natureOfBusiness;
  String get natureOfBusiness => _natureOfBusiness ?? '';
  set natureOfBusiness(String? val) => _natureOfBusiness = val;

  bool hasNatureOfBusiness() => _natureOfBusiness != null;

  // "banking_company_name" field.
  String? _bankingCompanyName;
  String get bankingCompanyName => _bankingCompanyName ?? '';
  set bankingCompanyName(String? val) => _bankingCompanyName = val;

  bool hasBankingCompanyName() => _bankingCompanyName != null;

  // "permanent_establishement" field.
  String? _permanentEstablishement;
  String get permanentEstablishement => _permanentEstablishement ?? '';
  set permanentEstablishement(String? val) => _permanentEstablishement = val;

  bool hasPermanentEstablishement() => _permanentEstablishement != null;

  // "emailID" field.
  String? _emailID;
  String get emailID => _emailID ?? '';
  set emailID(String? val) => _emailID = val;

  bool hasEmailID() => _emailID != null;

  // "mobNumber" field.
  int? _mobNumber;
  int get mobNumber => _mobNumber ?? 0;
  set mobNumber(int? val) => _mobNumber = val;

  void incrementMobNumber(int amount) => mobNumber = mobNumber + amount;

  bool hasMobNumber() => _mobNumber != null;

  // "alternateEmailID" field.
  String? _alternateEmailID;
  String get alternateEmailID => _alternateEmailID ?? '';
  set alternateEmailID(String? val) => _alternateEmailID = val;

  bool hasAlternateEmailID() => _alternateEmailID != null;

  // "alternateMobNumber" field.
  int? _alternateMobNumber;
  int get alternateMobNumber => _alternateMobNumber ?? 0;
  set alternateMobNumber(int? val) => _alternateMobNumber = val;

  void incrementAlternateMobNumber(int amount) =>
      alternateMobNumber = alternateMobNumber + amount;

  bool hasAlternateMobNumber() => _alternateMobNumber != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "district" field.
  String? _district;
  String get district => _district ?? '';
  set district(String? val) => _district = val;

  bool hasDistrict() => _district != null;

  // "headOffice" field.
  String? _headOffice;
  String get headOffice => _headOffice ?? '';
  set headOffice(String? val) => _headOffice = val;

  bool hasHeadOffice() => _headOffice != null;

  // "numberOfBranches" field.
  int? _numberOfBranches;
  int get numberOfBranches => _numberOfBranches ?? 0;
  set numberOfBranches(int? val) => _numberOfBranches = val;

  void incrementNumberOfBranches(int amount) =>
      numberOfBranches = numberOfBranches + amount;

  bool hasNumberOfBranches() => _numberOfBranches != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "place" field.
  String? _place;
  String get place => _place ?? '';
  set place(String? val) => _place = val;

  bool hasPlace() => _place != null;

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  set date(String? val) => _date = val;

  bool hasDate() => _date != null;

  // "ip_address" field.
  String? _ipAddress;
  String get ipAddress => _ipAddress ?? '';
  set ipAddress(String? val) => _ipAddress = val;

  bool hasIpAddress() => _ipAddress != null;

  static PreviewDownloadDataStruct fromMap(Map<String, dynamic> data) =>
      PreviewDownloadDataStruct(
        submisstionMode: data['submisstionMode'] as String?,
        applicationType: data['applicationType'] as String?,
        residentialStatus: data['residentialStatus'] as String?,
        financialYear: data['financialYear'] as String?,
        panNumber: data['panNumber'] as String?,
        natureOfBusiness: data['natureOfBusiness'] as String?,
        bankingCompanyName: data['banking_company_name'] as String?,
        permanentEstablishement: data['permanent_establishement'] as String?,
        emailID: data['emailID'] as String?,
        mobNumber: castToType<int>(data['mobNumber']),
        alternateEmailID: data['alternateEmailID'] as String?,
        alternateMobNumber: castToType<int>(data['alternateMobNumber']),
        state: data['state'] as String?,
        district: data['district'] as String?,
        headOffice: data['headOffice'] as String?,
        numberOfBranches: castToType<int>(data['numberOfBranches']),
        status: data['status'] as String?,
        place: data['place'] as String?,
        date: data['date'] as String?,
        ipAddress: data['ip_address'] as String?,
      );

  static PreviewDownloadDataStruct? maybeFromMap(dynamic data) => data is Map
      ? PreviewDownloadDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'submisstionMode': _submisstionMode,
        'applicationType': _applicationType,
        'residentialStatus': _residentialStatus,
        'financialYear': _financialYear,
        'panNumber': _panNumber,
        'natureOfBusiness': _natureOfBusiness,
        'banking_company_name': _bankingCompanyName,
        'permanent_establishement': _permanentEstablishement,
        'emailID': _emailID,
        'mobNumber': _mobNumber,
        'alternateEmailID': _alternateEmailID,
        'alternateMobNumber': _alternateMobNumber,
        'state': _state,
        'district': _district,
        'headOffice': _headOffice,
        'numberOfBranches': _numberOfBranches,
        'status': _status,
        'place': _place,
        'date': _date,
        'ip_address': _ipAddress,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'submisstionMode': serializeParam(
          _submisstionMode,
          ParamType.String,
        ),
        'applicationType': serializeParam(
          _applicationType,
          ParamType.String,
        ),
        'residentialStatus': serializeParam(
          _residentialStatus,
          ParamType.String,
        ),
        'financialYear': serializeParam(
          _financialYear,
          ParamType.String,
        ),
        'panNumber': serializeParam(
          _panNumber,
          ParamType.String,
        ),
        'natureOfBusiness': serializeParam(
          _natureOfBusiness,
          ParamType.String,
        ),
        'banking_company_name': serializeParam(
          _bankingCompanyName,
          ParamType.String,
        ),
        'permanent_establishement': serializeParam(
          _permanentEstablishement,
          ParamType.String,
        ),
        'emailID': serializeParam(
          _emailID,
          ParamType.String,
        ),
        'mobNumber': serializeParam(
          _mobNumber,
          ParamType.int,
        ),
        'alternateEmailID': serializeParam(
          _alternateEmailID,
          ParamType.String,
        ),
        'alternateMobNumber': serializeParam(
          _alternateMobNumber,
          ParamType.int,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'district': serializeParam(
          _district,
          ParamType.String,
        ),
        'headOffice': serializeParam(
          _headOffice,
          ParamType.String,
        ),
        'numberOfBranches': serializeParam(
          _numberOfBranches,
          ParamType.int,
        ),
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
        'place': serializeParam(
          _place,
          ParamType.String,
        ),
        'date': serializeParam(
          _date,
          ParamType.String,
        ),
        'ip_address': serializeParam(
          _ipAddress,
          ParamType.String,
        ),
      }.withoutNulls;

  static PreviewDownloadDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      PreviewDownloadDataStruct(
        submisstionMode: deserializeParam(
          data['submisstionMode'],
          ParamType.String,
          false,
        ),
        applicationType: deserializeParam(
          data['applicationType'],
          ParamType.String,
          false,
        ),
        residentialStatus: deserializeParam(
          data['residentialStatus'],
          ParamType.String,
          false,
        ),
        financialYear: deserializeParam(
          data['financialYear'],
          ParamType.String,
          false,
        ),
        panNumber: deserializeParam(
          data['panNumber'],
          ParamType.String,
          false,
        ),
        natureOfBusiness: deserializeParam(
          data['natureOfBusiness'],
          ParamType.String,
          false,
        ),
        bankingCompanyName: deserializeParam(
          data['banking_company_name'],
          ParamType.String,
          false,
        ),
        permanentEstablishement: deserializeParam(
          data['permanent_establishement'],
          ParamType.String,
          false,
        ),
        emailID: deserializeParam(
          data['emailID'],
          ParamType.String,
          false,
        ),
        mobNumber: deserializeParam(
          data['mobNumber'],
          ParamType.int,
          false,
        ),
        alternateEmailID: deserializeParam(
          data['alternateEmailID'],
          ParamType.String,
          false,
        ),
        alternateMobNumber: deserializeParam(
          data['alternateMobNumber'],
          ParamType.int,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        district: deserializeParam(
          data['district'],
          ParamType.String,
          false,
        ),
        headOffice: deserializeParam(
          data['headOffice'],
          ParamType.String,
          false,
        ),
        numberOfBranches: deserializeParam(
          data['numberOfBranches'],
          ParamType.int,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
        place: deserializeParam(
          data['place'],
          ParamType.String,
          false,
        ),
        date: deserializeParam(
          data['date'],
          ParamType.String,
          false,
        ),
        ipAddress: deserializeParam(
          data['ip_address'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'PreviewDownloadDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is PreviewDownloadDataStruct &&
        submisstionMode == other.submisstionMode &&
        applicationType == other.applicationType &&
        residentialStatus == other.residentialStatus &&
        financialYear == other.financialYear &&
        panNumber == other.panNumber &&
        natureOfBusiness == other.natureOfBusiness &&
        bankingCompanyName == other.bankingCompanyName &&
        permanentEstablishement == other.permanentEstablishement &&
        emailID == other.emailID &&
        mobNumber == other.mobNumber &&
        alternateEmailID == other.alternateEmailID &&
        alternateMobNumber == other.alternateMobNumber &&
        state == other.state &&
        district == other.district &&
        headOffice == other.headOffice &&
        numberOfBranches == other.numberOfBranches &&
        status == other.status &&
        place == other.place &&
        date == other.date &&
        ipAddress == other.ipAddress;
  }

  @override
  int get hashCode => const ListEquality().hash([
        submisstionMode,
        applicationType,
        residentialStatus,
        financialYear,
        panNumber,
        natureOfBusiness,
        bankingCompanyName,
        permanentEstablishement,
        emailID,
        mobNumber,
        alternateEmailID,
        alternateMobNumber,
        state,
        district,
        headOffice,
        numberOfBranches,
        status,
        place,
        date,
        ipAddress
      ]);
}

PreviewDownloadDataStruct createPreviewDownloadDataStruct({
  String? submisstionMode,
  String? applicationType,
  String? residentialStatus,
  String? financialYear,
  String? panNumber,
  String? natureOfBusiness,
  String? bankingCompanyName,
  String? permanentEstablishement,
  String? emailID,
  int? mobNumber,
  String? alternateEmailID,
  int? alternateMobNumber,
  String? state,
  String? district,
  String? headOffice,
  int? numberOfBranches,
  String? status,
  String? place,
  String? date,
  String? ipAddress,
}) =>
    PreviewDownloadDataStruct(
      submisstionMode: submisstionMode,
      applicationType: applicationType,
      residentialStatus: residentialStatus,
      financialYear: financialYear,
      panNumber: panNumber,
      natureOfBusiness: natureOfBusiness,
      bankingCompanyName: bankingCompanyName,
      permanentEstablishement: permanentEstablishement,
      emailID: emailID,
      mobNumber: mobNumber,
      alternateEmailID: alternateEmailID,
      alternateMobNumber: alternateMobNumber,
      state: state,
      district: district,
      headOffice: headOffice,
      numberOfBranches: numberOfBranches,
      status: status,
      place: place,
      date: date,
      ipAddress: ipAddress,
    );
