// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CompleteUploadFileInfoStruct extends BaseStruct {
  CompleteUploadFileInfoStruct({
    String? fileName,
  }) : _fileName = fileName;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  static CompleteUploadFileInfoStruct fromMap(Map<String, dynamic> data) =>
      CompleteUploadFileInfoStruct(
        fileName: data['fileName'] as String?,
      );

  static CompleteUploadFileInfoStruct? maybeFromMap(dynamic data) => data is Map
      ? CompleteUploadFileInfoStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
      }.withoutNulls;

  static CompleteUploadFileInfoStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      CompleteUploadFileInfoStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'CompleteUploadFileInfoStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is CompleteUploadFileInfoStruct && fileName == other.fileName;
  }

  @override
  int get hashCode => const ListEquality().hash([fileName]);
}

CompleteUploadFileInfoStruct createCompleteUploadFileInfoStruct({
  String? fileName,
}) =>
    CompleteUploadFileInfoStruct(
      fileName: fileName,
    );
