// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ApplicationDetailsStruct extends BaseStruct {
  ApplicationDetailsStruct({
    String? submissionMode,
    String? applicationType,
    String? residentialStatus,
    String? financialYear,
  })  : _submissionMode = submissionMode,
        _applicationType = applicationType,
        _residentialStatus = residentialStatus,
        _financialYear = financialYear;

  // "submission_mode" field.
  String? _submissionMode;
  String get submissionMode => _submissionMode ?? '';
  set submissionMode(String? val) => _submissionMode = val;

  bool hasSubmissionMode() => _submissionMode != null;

  // "application_type" field.
  String? _applicationType;
  String get applicationType => _applicationType ?? '';
  set applicationType(String? val) => _applicationType = val;

  bool hasApplicationType() => _applicationType != null;

  // "residential_status" field.
  String? _residentialStatus;
  String get residentialStatus => _residentialStatus ?? '';
  set residentialStatus(String? val) => _residentialStatus = val;

  bool hasResidentialStatus() => _residentialStatus != null;

  // "financial_year" field.
  String? _financialYear;
  String get financialYear => _financialYear ?? '';
  set financialYear(String? val) => _financialYear = val;

  bool hasFinancialYear() => _financialYear != null;

  static ApplicationDetailsStruct fromMap(Map<String, dynamic> data) =>
      ApplicationDetailsStruct(
        submissionMode: data['submission_mode'] as String?,
        applicationType: data['application_type'] as String?,
        residentialStatus: data['residential_status'] as String?,
        financialYear: data['financial_year'] as String?,
      );

  static ApplicationDetailsStruct? maybeFromMap(dynamic data) => data is Map
      ? ApplicationDetailsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'submission_mode': _submissionMode,
        'application_type': _applicationType,
        'residential_status': _residentialStatus,
        'financial_year': _financialYear,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'submission_mode': serializeParam(
          _submissionMode,
          ParamType.String,
        ),
        'application_type': serializeParam(
          _applicationType,
          ParamType.String,
        ),
        'residential_status': serializeParam(
          _residentialStatus,
          ParamType.String,
        ),
        'financial_year': serializeParam(
          _financialYear,
          ParamType.String,
        ),
      }.withoutNulls;

  static ApplicationDetailsStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      ApplicationDetailsStruct(
        submissionMode: deserializeParam(
          data['submission_mode'],
          ParamType.String,
          false,
        ),
        applicationType: deserializeParam(
          data['application_type'],
          ParamType.String,
          false,
        ),
        residentialStatus: deserializeParam(
          data['residential_status'],
          ParamType.String,
          false,
        ),
        financialYear: deserializeParam(
          data['financial_year'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'ApplicationDetailsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ApplicationDetailsStruct &&
        submissionMode == other.submissionMode &&
        applicationType == other.applicationType &&
        residentialStatus == other.residentialStatus &&
        financialYear == other.financialYear;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [submissionMode, applicationType, residentialStatus, financialYear]);
}

ApplicationDetailsStruct createApplicationDetailsStruct({
  String? submissionMode,
  String? applicationType,
  String? residentialStatus,
  String? financialYear,
}) =>
    ApplicationDetailsStruct(
      submissionMode: submissionMode,
      applicationType: applicationType,
      residentialStatus: residentialStatus,
      financialYear: financialYear,
    );
