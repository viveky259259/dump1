// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cPreviewDataResponseStruct extends BaseStruct {
  Form15cPreviewDataResponseStruct({
    String? message,
    Form15cPreviewDataStruct? data,
  })  : _message = message,
        _data = data;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "data" field.
  Form15cPreviewDataStruct? _data;
  Form15cPreviewDataStruct get data => _data ?? Form15cPreviewDataStruct();
  set data(Form15cPreviewDataStruct? val) => _data = val;

  void updateData(Function(Form15cPreviewDataStruct) updateFn) {
    updateFn(_data ??= Form15cPreviewDataStruct());
  }

  bool hasData() => _data != null;

  static Form15cPreviewDataResponseStruct fromMap(Map<String, dynamic> data) =>
      Form15cPreviewDataResponseStruct(
        message: data['message'] as String?,
        data: data['data'] is Form15cPreviewDataStruct
            ? data['data']
            : Form15cPreviewDataStruct.maybeFromMap(data['data']),
      );

  static Form15cPreviewDataResponseStruct? maybeFromMap(dynamic data) => data
          is Map
      ? Form15cPreviewDataResponseStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'message': _message,
        'data': _data?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static Form15cPreviewDataResponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cPreviewDataResponseStruct(
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        data: deserializeStructParam(
          data['data'],
          ParamType.DataStruct,
          false,
          structBuilder: Form15cPreviewDataStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'Form15cPreviewDataResponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Form15cPreviewDataResponseStruct &&
        message == other.message &&
        data == other.data;
  }

  @override
  int get hashCode => const ListEquality().hash([message, data]);
}

Form15cPreviewDataResponseStruct createForm15cPreviewDataResponseStruct({
  String? message,
  Form15cPreviewDataStruct? data,
}) =>
    Form15cPreviewDataResponseStruct(
      message: message,
      data: data ?? Form15cPreviewDataStruct(),
    );
