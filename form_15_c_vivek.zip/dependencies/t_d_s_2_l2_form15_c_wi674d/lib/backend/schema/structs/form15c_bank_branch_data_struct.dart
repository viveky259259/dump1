// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cBankBranchDataStruct extends BaseStruct {
  Form15cBankBranchDataStruct({
    int? id,
    String? panNumber,
    String? country,
    String? flat,
    String? block,
    String? pincode,
    String? postoffice,
    String? areaLocality,
    String? district,
    String? state,
  })  : _id = id,
        _panNumber = panNumber,
        _country = country,
        _flat = flat,
        _block = block,
        _pincode = pincode,
        _postoffice = postoffice,
        _areaLocality = areaLocality,
        _district = district,
        _state = state;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  // "panNumber" field.
  String? _panNumber;
  String get panNumber => _panNumber ?? '';
  set panNumber(String? val) => _panNumber = val;

  bool hasPanNumber() => _panNumber != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  set country(String? val) => _country = val;

  bool hasCountry() => _country != null;

  // "flat" field.
  String? _flat;
  String get flat => _flat ?? '';
  set flat(String? val) => _flat = val;

  bool hasFlat() => _flat != null;

  // "block" field.
  String? _block;
  String get block => _block ?? '';
  set block(String? val) => _block = val;

  bool hasBlock() => _block != null;

  // "pincode" field.
  String? _pincode;
  String get pincode => _pincode ?? '';
  set pincode(String? val) => _pincode = val;

  bool hasPincode() => _pincode != null;

  // "postoffice" field.
  String? _postoffice;
  String get postoffice => _postoffice ?? '';
  set postoffice(String? val) => _postoffice = val;

  bool hasPostoffice() => _postoffice != null;

  // "areaLocality" field.
  String? _areaLocality;
  String get areaLocality => _areaLocality ?? '';
  set areaLocality(String? val) => _areaLocality = val;

  bool hasAreaLocality() => _areaLocality != null;

  // "district" field.
  String? _district;
  String get district => _district ?? '';
  set district(String? val) => _district = val;

  bool hasDistrict() => _district != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  static Form15cBankBranchDataStruct fromMap(Map<String, dynamic> data) =>
      Form15cBankBranchDataStruct(
        id: castToType<int>(data['id']),
        panNumber: data['panNumber'] as String?,
        country: data['country'] as String?,
        flat: data['flat'] as String?,
        block: data['block'] as String?,
        pincode: data['pincode'] as String?,
        postoffice: data['postoffice'] as String?,
        areaLocality: data['areaLocality'] as String?,
        district: data['district'] as String?,
        state: data['state'] as String?,
      );

  static Form15cBankBranchDataStruct? maybeFromMap(dynamic data) => data is Map
      ? Form15cBankBranchDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'panNumber': _panNumber,
        'country': _country,
        'flat': _flat,
        'block': _block,
        'pincode': _pincode,
        'postoffice': _postoffice,
        'areaLocality': _areaLocality,
        'district': _district,
        'state': _state,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
        'panNumber': serializeParam(
          _panNumber,
          ParamType.String,
        ),
        'country': serializeParam(
          _country,
          ParamType.String,
        ),
        'flat': serializeParam(
          _flat,
          ParamType.String,
        ),
        'block': serializeParam(
          _block,
          ParamType.String,
        ),
        'pincode': serializeParam(
          _pincode,
          ParamType.String,
        ),
        'postoffice': serializeParam(
          _postoffice,
          ParamType.String,
        ),
        'areaLocality': serializeParam(
          _areaLocality,
          ParamType.String,
        ),
        'district': serializeParam(
          _district,
          ParamType.String,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
      }.withoutNulls;

  static Form15cBankBranchDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cBankBranchDataStruct(
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
        panNumber: deserializeParam(
          data['panNumber'],
          ParamType.String,
          false,
        ),
        country: deserializeParam(
          data['country'],
          ParamType.String,
          false,
        ),
        flat: deserializeParam(
          data['flat'],
          ParamType.String,
          false,
        ),
        block: deserializeParam(
          data['block'],
          ParamType.String,
          false,
        ),
        pincode: deserializeParam(
          data['pincode'],
          ParamType.String,
          false,
        ),
        postoffice: deserializeParam(
          data['postoffice'],
          ParamType.String,
          false,
        ),
        areaLocality: deserializeParam(
          data['areaLocality'],
          ParamType.String,
          false,
        ),
        district: deserializeParam(
          data['district'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Form15cBankBranchDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Form15cBankBranchDataStruct &&
        id == other.id &&
        panNumber == other.panNumber &&
        country == other.country &&
        flat == other.flat &&
        block == other.block &&
        pincode == other.pincode &&
        postoffice == other.postoffice &&
        areaLocality == other.areaLocality &&
        district == other.district &&
        state == other.state;
  }

  @override
  int get hashCode => const ListEquality().hash([
        id,
        panNumber,
        country,
        flat,
        block,
        pincode,
        postoffice,
        areaLocality,
        district,
        state
      ]);
}

Form15cBankBranchDataStruct createForm15cBankBranchDataStruct({
  int? id,
  String? panNumber,
  String? country,
  String? flat,
  String? block,
  String? pincode,
  String? postoffice,
  String? areaLocality,
  String? district,
  String? state,
}) =>
    Form15cBankBranchDataStruct(
      id: id,
      panNumber: panNumber,
      country: country,
      flat: flat,
      block: block,
      pincode: pincode,
      postoffice: postoffice,
      areaLocality: areaLocality,
      district: district,
      state: state,
    );
