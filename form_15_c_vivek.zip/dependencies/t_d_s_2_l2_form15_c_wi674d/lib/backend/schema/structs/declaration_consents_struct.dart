// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DeclarationConsentsStruct extends BaseStruct {
  DeclarationConsentsStruct({
    String? place,
    String? date,
    String? ipAddress,
    bool? firstConsentGiven,
    bool? secondConsentGiven,
    bool? thirdConsentGiven,
  })  : _place = place,
        _date = date,
        _ipAddress = ipAddress,
        _firstConsentGiven = firstConsentGiven,
        _secondConsentGiven = secondConsentGiven,
        _thirdConsentGiven = thirdConsentGiven;

  // "place" field.
  String? _place;
  String get place => _place ?? '';
  set place(String? val) => _place = val;

  bool hasPlace() => _place != null;

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  set date(String? val) => _date = val;

  bool hasDate() => _date != null;

  // "ip_address" field.
  String? _ipAddress;
  String get ipAddress => _ipAddress ?? '';
  set ipAddress(String? val) => _ipAddress = val;

  bool hasIpAddress() => _ipAddress != null;

  // "firstConsentGiven" field.
  bool? _firstConsentGiven;
  bool get firstConsentGiven => _firstConsentGiven ?? false;
  set firstConsentGiven(bool? val) => _firstConsentGiven = val;

  bool hasFirstConsentGiven() => _firstConsentGiven != null;

  // "secondConsentGiven" field.
  bool? _secondConsentGiven;
  bool get secondConsentGiven => _secondConsentGiven ?? false;
  set secondConsentGiven(bool? val) => _secondConsentGiven = val;

  bool hasSecondConsentGiven() => _secondConsentGiven != null;

  // "thirdConsentGiven" field.
  bool? _thirdConsentGiven;
  bool get thirdConsentGiven => _thirdConsentGiven ?? false;
  set thirdConsentGiven(bool? val) => _thirdConsentGiven = val;

  bool hasThirdConsentGiven() => _thirdConsentGiven != null;

  static DeclarationConsentsStruct fromMap(Map<String, dynamic> data) =>
      DeclarationConsentsStruct(
        place: data['place'] as String?,
        date: data['date'] as String?,
        ipAddress: data['ip_address'] as String?,
        firstConsentGiven: data['firstConsentGiven'] as bool?,
        secondConsentGiven: data['secondConsentGiven'] as bool?,
        thirdConsentGiven: data['thirdConsentGiven'] as bool?,
      );

  static DeclarationConsentsStruct? maybeFromMap(dynamic data) => data is Map
      ? DeclarationConsentsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'place': _place,
        'date': _date,
        'ip_address': _ipAddress,
        'firstConsentGiven': _firstConsentGiven,
        'secondConsentGiven': _secondConsentGiven,
        'thirdConsentGiven': _thirdConsentGiven,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'place': serializeParam(
          _place,
          ParamType.String,
        ),
        'date': serializeParam(
          _date,
          ParamType.String,
        ),
        'ip_address': serializeParam(
          _ipAddress,
          ParamType.String,
        ),
        'firstConsentGiven': serializeParam(
          _firstConsentGiven,
          ParamType.bool,
        ),
        'secondConsentGiven': serializeParam(
          _secondConsentGiven,
          ParamType.bool,
        ),
        'thirdConsentGiven': serializeParam(
          _thirdConsentGiven,
          ParamType.bool,
        ),
      }.withoutNulls;

  static DeclarationConsentsStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      DeclarationConsentsStruct(
        place: deserializeParam(
          data['place'],
          ParamType.String,
          false,
        ),
        date: deserializeParam(
          data['date'],
          ParamType.String,
          false,
        ),
        ipAddress: deserializeParam(
          data['ip_address'],
          ParamType.String,
          false,
        ),
        firstConsentGiven: deserializeParam(
          data['firstConsentGiven'],
          ParamType.bool,
          false,
        ),
        secondConsentGiven: deserializeParam(
          data['secondConsentGiven'],
          ParamType.bool,
          false,
        ),
        thirdConsentGiven: deserializeParam(
          data['thirdConsentGiven'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'DeclarationConsentsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is DeclarationConsentsStruct &&
        place == other.place &&
        date == other.date &&
        ipAddress == other.ipAddress &&
        firstConsentGiven == other.firstConsentGiven &&
        secondConsentGiven == other.secondConsentGiven &&
        thirdConsentGiven == other.thirdConsentGiven;
  }

  @override
  int get hashCode => const ListEquality().hash([
        place,
        date,
        ipAddress,
        firstConsentGiven,
        secondConsentGiven,
        thirdConsentGiven
      ]);
}

DeclarationConsentsStruct createDeclarationConsentsStruct({
  String? place,
  String? date,
  String? ipAddress,
  bool? firstConsentGiven,
  bool? secondConsentGiven,
  bool? thirdConsentGiven,
}) =>
    DeclarationConsentsStruct(
      place: place,
      date: date,
      ipAddress: ipAddress,
      firstConsentGiven: firstConsentGiven,
      secondConsentGiven: secondConsentGiven,
      thirdConsentGiven: thirdConsentGiven,
    );
