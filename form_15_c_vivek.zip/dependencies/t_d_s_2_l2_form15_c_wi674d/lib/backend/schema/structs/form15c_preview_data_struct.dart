// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cPreviewDataStruct extends BaseStruct {
  Form15cPreviewDataStruct({
    String? panNumber,
    String? natureOfBussiness,
    String? permanentEstablishment,
    String? state,
    String? district,
    String? bankingCompanyName,
    String? emailId,
    String? alternateEmailId,
    int? mobileNumber,
    int? alternatemobileNumber,
    String? financialYear,
    String? residentialStatus,
    String? applicationType,
    String? submissionMode,
    String? status,
    String? headOffice,
    int? numberOfBranch,
    String? declaration,
    String? place,
    String? date,
    String? ipAddress,
    String? bankingCompany,
  })  : _panNumber = panNumber,
        _natureOfBussiness = natureOfBussiness,
        _permanentEstablishment = permanentEstablishment,
        _state = state,
        _district = district,
        _bankingCompanyName = bankingCompanyName,
        _emailId = emailId,
        _alternateEmailId = alternateEmailId,
        _mobileNumber = mobileNumber,
        _alternatemobileNumber = alternatemobileNumber,
        _financialYear = financialYear,
        _residentialStatus = residentialStatus,
        _applicationType = applicationType,
        _submissionMode = submissionMode,
        _status = status,
        _headOffice = headOffice,
        _numberOfBranch = numberOfBranch,
        _declaration = declaration,
        _place = place,
        _date = date,
        _ipAddress = ipAddress,
        _bankingCompany = bankingCompany;

  // "panNumber" field.
  String? _panNumber;
  String get panNumber => _panNumber ?? '';
  set panNumber(String? val) => _panNumber = val;

  bool hasPanNumber() => _panNumber != null;

  // "natureOfBussiness" field.
  String? _natureOfBussiness;
  String get natureOfBussiness => _natureOfBussiness ?? '';
  set natureOfBussiness(String? val) => _natureOfBussiness = val;

  bool hasNatureOfBussiness() => _natureOfBussiness != null;

  // "permanentEstablishment" field.
  String? _permanentEstablishment;
  String get permanentEstablishment => _permanentEstablishment ?? '';
  set permanentEstablishment(String? val) => _permanentEstablishment = val;

  bool hasPermanentEstablishment() => _permanentEstablishment != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "district" field.
  String? _district;
  String get district => _district ?? '';
  set district(String? val) => _district = val;

  bool hasDistrict() => _district != null;

  // "bankingCompanyName" field.
  String? _bankingCompanyName;
  String get bankingCompanyName => _bankingCompanyName ?? '';
  set bankingCompanyName(String? val) => _bankingCompanyName = val;

  bool hasBankingCompanyName() => _bankingCompanyName != null;

  // "emailId" field.
  String? _emailId;
  String get emailId => _emailId ?? '';
  set emailId(String? val) => _emailId = val;

  bool hasEmailId() => _emailId != null;

  // "alternateEmailId" field.
  String? _alternateEmailId;
  String get alternateEmailId => _alternateEmailId ?? '';
  set alternateEmailId(String? val) => _alternateEmailId = val;

  bool hasAlternateEmailId() => _alternateEmailId != null;

  // "mobileNumber" field.
  int? _mobileNumber;
  int get mobileNumber => _mobileNumber ?? 0;
  set mobileNumber(int? val) => _mobileNumber = val;

  void incrementMobileNumber(int amount) =>
      mobileNumber = mobileNumber + amount;

  bool hasMobileNumber() => _mobileNumber != null;

  // "alternatemobileNumber" field.
  int? _alternatemobileNumber;
  int get alternatemobileNumber => _alternatemobileNumber ?? 0;
  set alternatemobileNumber(int? val) => _alternatemobileNumber = val;

  void incrementAlternatemobileNumber(int amount) =>
      alternatemobileNumber = alternatemobileNumber + amount;

  bool hasAlternatemobileNumber() => _alternatemobileNumber != null;

  // "financialYear" field.
  String? _financialYear;
  String get financialYear => _financialYear ?? '';
  set financialYear(String? val) => _financialYear = val;

  bool hasFinancialYear() => _financialYear != null;

  // "residentialStatus" field.
  String? _residentialStatus;
  String get residentialStatus => _residentialStatus ?? '';
  set residentialStatus(String? val) => _residentialStatus = val;

  bool hasResidentialStatus() => _residentialStatus != null;

  // "applicationType" field.
  String? _applicationType;
  String get applicationType => _applicationType ?? '';
  set applicationType(String? val) => _applicationType = val;

  bool hasApplicationType() => _applicationType != null;

  // "submissionMode" field.
  String? _submissionMode;
  String get submissionMode => _submissionMode ?? '';
  set submissionMode(String? val) => _submissionMode = val;

  bool hasSubmissionMode() => _submissionMode != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "headOffice" field.
  String? _headOffice;
  String get headOffice => _headOffice ?? '';
  set headOffice(String? val) => _headOffice = val;

  bool hasHeadOffice() => _headOffice != null;

  // "numberOfBranch" field.
  int? _numberOfBranch;
  int get numberOfBranch => _numberOfBranch ?? 0;
  set numberOfBranch(int? val) => _numberOfBranch = val;

  void incrementNumberOfBranch(int amount) =>
      numberOfBranch = numberOfBranch + amount;

  bool hasNumberOfBranch() => _numberOfBranch != null;

  // "declaration" field.
  String? _declaration;
  String get declaration => _declaration ?? '';
  set declaration(String? val) => _declaration = val;

  bool hasDeclaration() => _declaration != null;

  // "place" field.
  String? _place;
  String get place => _place ?? '';
  set place(String? val) => _place = val;

  bool hasPlace() => _place != null;

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  set date(String? val) => _date = val;

  bool hasDate() => _date != null;

  // "ipAddress" field.
  String? _ipAddress;
  String get ipAddress => _ipAddress ?? '';
  set ipAddress(String? val) => _ipAddress = val;

  bool hasIpAddress() => _ipAddress != null;

  // "bankingCompany" field.
  String? _bankingCompany;
  String get bankingCompany => _bankingCompany ?? '';
  set bankingCompany(String? val) => _bankingCompany = val;

  bool hasBankingCompany() => _bankingCompany != null;

  static Form15cPreviewDataStruct fromMap(Map<String, dynamic> data) =>
      Form15cPreviewDataStruct(
        panNumber: data['panNumber'] as String?,
        natureOfBussiness: data['natureOfBussiness'] as String?,
        permanentEstablishment: data['permanentEstablishment'] as String?,
        state: data['state'] as String?,
        district: data['district'] as String?,
        bankingCompanyName: data['bankingCompanyName'] as String?,
        emailId: data['emailId'] as String?,
        alternateEmailId: data['alternateEmailId'] as String?,
        mobileNumber: castToType<int>(data['mobileNumber']),
        alternatemobileNumber: castToType<int>(data['alternatemobileNumber']),
        financialYear: data['financialYear'] as String?,
        residentialStatus: data['residentialStatus'] as String?,
        applicationType: data['applicationType'] as String?,
        submissionMode: data['submissionMode'] as String?,
        status: data['status'] as String?,
        headOffice: data['headOffice'] as String?,
        numberOfBranch: castToType<int>(data['numberOfBranch']),
        declaration: data['declaration'] as String?,
        place: data['place'] as String?,
        date: data['date'] as String?,
        ipAddress: data['ipAddress'] as String?,
        bankingCompany: data['bankingCompany'] as String?,
      );

  static Form15cPreviewDataStruct? maybeFromMap(dynamic data) => data is Map
      ? Form15cPreviewDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'panNumber': _panNumber,
        'natureOfBussiness': _natureOfBussiness,
        'permanentEstablishment': _permanentEstablishment,
        'state': _state,
        'district': _district,
        'bankingCompanyName': _bankingCompanyName,
        'emailId': _emailId,
        'alternateEmailId': _alternateEmailId,
        'mobileNumber': _mobileNumber,
        'alternatemobileNumber': _alternatemobileNumber,
        'financialYear': _financialYear,
        'residentialStatus': _residentialStatus,
        'applicationType': _applicationType,
        'submissionMode': _submissionMode,
        'status': _status,
        'headOffice': _headOffice,
        'numberOfBranch': _numberOfBranch,
        'declaration': _declaration,
        'place': _place,
        'date': _date,
        'ipAddress': _ipAddress,
        'bankingCompany': _bankingCompany,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'panNumber': serializeParam(
          _panNumber,
          ParamType.String,
        ),
        'natureOfBussiness': serializeParam(
          _natureOfBussiness,
          ParamType.String,
        ),
        'permanentEstablishment': serializeParam(
          _permanentEstablishment,
          ParamType.String,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'district': serializeParam(
          _district,
          ParamType.String,
        ),
        'bankingCompanyName': serializeParam(
          _bankingCompanyName,
          ParamType.String,
        ),
        'emailId': serializeParam(
          _emailId,
          ParamType.String,
        ),
        'alternateEmailId': serializeParam(
          _alternateEmailId,
          ParamType.String,
        ),
        'mobileNumber': serializeParam(
          _mobileNumber,
          ParamType.int,
        ),
        'alternatemobileNumber': serializeParam(
          _alternatemobileNumber,
          ParamType.int,
        ),
        'financialYear': serializeParam(
          _financialYear,
          ParamType.String,
        ),
        'residentialStatus': serializeParam(
          _residentialStatus,
          ParamType.String,
        ),
        'applicationType': serializeParam(
          _applicationType,
          ParamType.String,
        ),
        'submissionMode': serializeParam(
          _submissionMode,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
        'headOffice': serializeParam(
          _headOffice,
          ParamType.String,
        ),
        'numberOfBranch': serializeParam(
          _numberOfBranch,
          ParamType.int,
        ),
        'declaration': serializeParam(
          _declaration,
          ParamType.String,
        ),
        'place': serializeParam(
          _place,
          ParamType.String,
        ),
        'date': serializeParam(
          _date,
          ParamType.String,
        ),
        'ipAddress': serializeParam(
          _ipAddress,
          ParamType.String,
        ),
        'bankingCompany': serializeParam(
          _bankingCompany,
          ParamType.String,
        ),
      }.withoutNulls;

  static Form15cPreviewDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cPreviewDataStruct(
        panNumber: deserializeParam(
          data['panNumber'],
          ParamType.String,
          false,
        ),
        natureOfBussiness: deserializeParam(
          data['natureOfBussiness'],
          ParamType.String,
          false,
        ),
        permanentEstablishment: deserializeParam(
          data['permanentEstablishment'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        district: deserializeParam(
          data['district'],
          ParamType.String,
          false,
        ),
        bankingCompanyName: deserializeParam(
          data['bankingCompanyName'],
          ParamType.String,
          false,
        ),
        emailId: deserializeParam(
          data['emailId'],
          ParamType.String,
          false,
        ),
        alternateEmailId: deserializeParam(
          data['alternateEmailId'],
          ParamType.String,
          false,
        ),
        mobileNumber: deserializeParam(
          data['mobileNumber'],
          ParamType.int,
          false,
        ),
        alternatemobileNumber: deserializeParam(
          data['alternatemobileNumber'],
          ParamType.int,
          false,
        ),
        financialYear: deserializeParam(
          data['financialYear'],
          ParamType.String,
          false,
        ),
        residentialStatus: deserializeParam(
          data['residentialStatus'],
          ParamType.String,
          false,
        ),
        applicationType: deserializeParam(
          data['applicationType'],
          ParamType.String,
          false,
        ),
        submissionMode: deserializeParam(
          data['submissionMode'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
        headOffice: deserializeParam(
          data['headOffice'],
          ParamType.String,
          false,
        ),
        numberOfBranch: deserializeParam(
          data['numberOfBranch'],
          ParamType.int,
          false,
        ),
        declaration: deserializeParam(
          data['declaration'],
          ParamType.String,
          false,
        ),
        place: deserializeParam(
          data['place'],
          ParamType.String,
          false,
        ),
        date: deserializeParam(
          data['date'],
          ParamType.String,
          false,
        ),
        ipAddress: deserializeParam(
          data['ipAddress'],
          ParamType.String,
          false,
        ),
        bankingCompany: deserializeParam(
          data['bankingCompany'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Form15cPreviewDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Form15cPreviewDataStruct &&
        panNumber == other.panNumber &&
        natureOfBussiness == other.natureOfBussiness &&
        permanentEstablishment == other.permanentEstablishment &&
        state == other.state &&
        district == other.district &&
        bankingCompanyName == other.bankingCompanyName &&
        emailId == other.emailId &&
        alternateEmailId == other.alternateEmailId &&
        mobileNumber == other.mobileNumber &&
        alternatemobileNumber == other.alternatemobileNumber &&
        financialYear == other.financialYear &&
        residentialStatus == other.residentialStatus &&
        applicationType == other.applicationType &&
        submissionMode == other.submissionMode &&
        status == other.status &&
        headOffice == other.headOffice &&
        numberOfBranch == other.numberOfBranch &&
        declaration == other.declaration &&
        place == other.place &&
        date == other.date &&
        ipAddress == other.ipAddress &&
        bankingCompany == other.bankingCompany;
  }

  @override
  int get hashCode => const ListEquality().hash([
        panNumber,
        natureOfBussiness,
        permanentEstablishment,
        state,
        district,
        bankingCompanyName,
        emailId,
        alternateEmailId,
        mobileNumber,
        alternatemobileNumber,
        financialYear,
        residentialStatus,
        applicationType,
        submissionMode,
        status,
        headOffice,
        numberOfBranch,
        declaration,
        place,
        date,
        ipAddress,
        bankingCompany
      ]);
}

Form15cPreviewDataStruct createForm15cPreviewDataStruct({
  String? panNumber,
  String? natureOfBussiness,
  String? permanentEstablishment,
  String? state,
  String? district,
  String? bankingCompanyName,
  String? emailId,
  String? alternateEmailId,
  int? mobileNumber,
  int? alternatemobileNumber,
  String? financialYear,
  String? residentialStatus,
  String? applicationType,
  String? submissionMode,
  String? status,
  String? headOffice,
  int? numberOfBranch,
  String? declaration,
  String? place,
  String? date,
  String? ipAddress,
  String? bankingCompany,
}) =>
    Form15cPreviewDataStruct(
      panNumber: panNumber,
      natureOfBussiness: natureOfBussiness,
      permanentEstablishment: permanentEstablishment,
      state: state,
      district: district,
      bankingCompanyName: bankingCompanyName,
      emailId: emailId,
      alternateEmailId: alternateEmailId,
      mobileNumber: mobileNumber,
      alternatemobileNumber: alternatemobileNumber,
      financialYear: financialYear,
      residentialStatus: residentialStatus,
      applicationType: applicationType,
      submissionMode: submissionMode,
      status: status,
      headOffice: headOffice,
      numberOfBranch: numberOfBranch,
      declaration: declaration,
      place: place,
      date: date,
      ipAddress: ipAddress,
      bankingCompany: bankingCompany,
    );
