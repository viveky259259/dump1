// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetIndianDIstrictsSchemaStruct extends BaseStruct {
  GetIndianDIstrictsSchemaStruct({
    String? state,
    List<String>? districts,
  })  : _state = state,
        _districts = districts;

  // "State" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "districts" field.
  List<String>? _districts;
  List<String> get districts => _districts ?? const [];
  set districts(List<String>? val) => _districts = val;

  void updateDistricts(Function(List<String>) updateFn) {
    updateFn(_districts ??= []);
  }

  bool hasDistricts() => _districts != null;

  static GetIndianDIstrictsSchemaStruct fromMap(Map<String, dynamic> data) =>
      GetIndianDIstrictsSchemaStruct(
        state: data['State'] as String?,
        districts: getDataList(data['districts']),
      );

  static GetIndianDIstrictsSchemaStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? GetIndianDIstrictsSchemaStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'State': _state,
        'districts': _districts,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'State': serializeParam(
          _state,
          ParamType.String,
        ),
        'districts': serializeParam(
          _districts,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static GetIndianDIstrictsSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      GetIndianDIstrictsSchemaStruct(
        state: deserializeParam(
          data['State'],
          ParamType.String,
          false,
        ),
        districts: deserializeParam<String>(
          data['districts'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'GetIndianDIstrictsSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GetIndianDIstrictsSchemaStruct &&
        state == other.state &&
        listEquality.equals(districts, other.districts);
  }

  @override
  int get hashCode => const ListEquality().hash([state, districts]);
}

GetIndianDIstrictsSchemaStruct createGetIndianDIstrictsSchemaStruct({
  String? state,
}) =>
    GetIndianDIstrictsSchemaStruct(
      state: state,
    );
