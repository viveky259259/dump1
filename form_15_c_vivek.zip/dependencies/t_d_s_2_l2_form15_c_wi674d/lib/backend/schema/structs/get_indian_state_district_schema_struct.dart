// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetIndianStateDistrictSchemaStruct extends BaseStruct {
  GetIndianStateDistrictSchemaStruct({
    List<GetIndianDIstrictsSchemaStruct>? states,
  }) : _states = states;

  // "states" field.
  List<GetIndianDIstrictsSchemaStruct>? _states;
  List<GetIndianDIstrictsSchemaStruct> get states => _states ?? const [];
  set states(List<GetIndianDIstrictsSchemaStruct>? val) => _states = val;

  void updateStates(Function(List<GetIndianDIstrictsSchemaStruct>) updateFn) {
    updateFn(_states ??= []);
  }

  bool hasStates() => _states != null;

  static GetIndianStateDistrictSchemaStruct fromMap(
          Map<String, dynamic> data) =>
      GetIndianStateDistrictSchemaStruct(
        states: getStructList(
          data['states'],
          GetIndianDIstrictsSchemaStruct.fromMap,
        ),
      );

  static GetIndianStateDistrictSchemaStruct? maybeFromMap(dynamic data) => data
          is Map
      ? GetIndianStateDistrictSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'states': _states?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'states': serializeParam(
          _states,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static GetIndianStateDistrictSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      GetIndianStateDistrictSchemaStruct(
        states: deserializeStructParam<GetIndianDIstrictsSchemaStruct>(
          data['states'],
          ParamType.DataStruct,
          true,
          structBuilder: GetIndianDIstrictsSchemaStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'GetIndianStateDistrictSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GetIndianStateDistrictSchemaStruct &&
        listEquality.equals(states, other.states);
  }

  @override
  int get hashCode => const ListEquality().hash([states]);
}

GetIndianStateDistrictSchemaStruct createGetIndianStateDistrictSchemaStruct() =>
    GetIndianStateDistrictSchemaStruct();
