// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cSubmitDataStruct extends BaseStruct {
  Form15cSubmitDataStruct({
    String? applPanTan,
    int? status,
    String? formSubmtDate,
    String? requestTmstmp,
  })  : _applPanTan = applPanTan,
        _status = status,
        _formSubmtDate = formSubmtDate,
        _requestTmstmp = requestTmstmp;

  // "applPanTan" field.
  String? _applPanTan;
  String get applPanTan => _applPanTan ?? '';
  set applPanTan(String? val) => _applPanTan = val;

  bool hasApplPanTan() => _applPanTan != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  // "formSubmtDate" field.
  String? _formSubmtDate;
  String get formSubmtDate => _formSubmtDate ?? '';
  set formSubmtDate(String? val) => _formSubmtDate = val;

  bool hasFormSubmtDate() => _formSubmtDate != null;

  // "requestTmstmp" field.
  String? _requestTmstmp;
  String get requestTmstmp => _requestTmstmp ?? '';
  set requestTmstmp(String? val) => _requestTmstmp = val;

  bool hasRequestTmstmp() => _requestTmstmp != null;

  static Form15cSubmitDataStruct fromMap(Map<String, dynamic> data) =>
      Form15cSubmitDataStruct(
        applPanTan: data['applPanTan'] as String?,
        status: castToType<int>(data['status']),
        formSubmtDate: data['formSubmtDate'] as String?,
        requestTmstmp: data['requestTmstmp'] as String?,
      );

  static Form15cSubmitDataStruct? maybeFromMap(dynamic data) => data is Map
      ? Form15cSubmitDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'applPanTan': _applPanTan,
        'status': _status,
        'formSubmtDate': _formSubmtDate,
        'requestTmstmp': _requestTmstmp,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'applPanTan': serializeParam(
          _applPanTan,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
        'formSubmtDate': serializeParam(
          _formSubmtDate,
          ParamType.String,
        ),
        'requestTmstmp': serializeParam(
          _requestTmstmp,
          ParamType.String,
        ),
      }.withoutNulls;

  static Form15cSubmitDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cSubmitDataStruct(
        applPanTan: deserializeParam(
          data['applPanTan'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
        formSubmtDate: deserializeParam(
          data['formSubmtDate'],
          ParamType.String,
          false,
        ),
        requestTmstmp: deserializeParam(
          data['requestTmstmp'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Form15cSubmitDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Form15cSubmitDataStruct &&
        applPanTan == other.applPanTan &&
        status == other.status &&
        formSubmtDate == other.formSubmtDate &&
        requestTmstmp == other.requestTmstmp;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([applPanTan, status, formSubmtDate, requestTmstmp]);
}

Form15cSubmitDataStruct createForm15cSubmitDataStruct({
  String? applPanTan,
  int? status,
  String? formSubmtDate,
  String? requestTmstmp,
}) =>
    Form15cSubmitDataStruct(
      applPanTan: applPanTan,
      status: status,
      formSubmtDate: formSubmtDate,
      requestTmstmp: requestTmstmp,
    );
