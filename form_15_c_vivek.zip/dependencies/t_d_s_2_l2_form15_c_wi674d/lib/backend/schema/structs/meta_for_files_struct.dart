// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MetaForFilesStruct extends BaseStruct {
  MetaForFilesStruct({
    String? fileName,
    String? format,
    String? error,
    int? sizeInKB,
    int? sizeInMB,
    double? height,
    double? width,
  })  : _fileName = fileName,
        _format = format,
        _error = error,
        _sizeInKB = sizeInKB,
        _sizeInMB = sizeInMB,
        _height = height,
        _width = width;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "format" field.
  String? _format;
  String get format => _format ?? '';
  set format(String? val) => _format = val;

  bool hasFormat() => _format != null;

  // "error" field.
  String? _error;
  String get error => _error ?? '';
  set error(String? val) => _error = val;

  bool hasError() => _error != null;

  // "sizeInKB" field.
  int? _sizeInKB;
  int get sizeInKB => _sizeInKB ?? 0;
  set sizeInKB(int? val) => _sizeInKB = val;

  void incrementSizeInKB(int amount) => sizeInKB = sizeInKB + amount;

  bool hasSizeInKB() => _sizeInKB != null;

  // "sizeInMB" field.
  int? _sizeInMB;
  int get sizeInMB => _sizeInMB ?? 0;
  set sizeInMB(int? val) => _sizeInMB = val;

  void incrementSizeInMB(int amount) => sizeInMB = sizeInMB + amount;

  bool hasSizeInMB() => _sizeInMB != null;

  // "height" field.
  double? _height;
  double get height => _height ?? 0.0;
  set height(double? val) => _height = val;

  void incrementHeight(double amount) => height = height + amount;

  bool hasHeight() => _height != null;

  // "width" field.
  double? _width;
  double get width => _width ?? 0.0;
  set width(double? val) => _width = val;

  void incrementWidth(double amount) => width = width + amount;

  bool hasWidth() => _width != null;

  static MetaForFilesStruct fromMap(Map<String, dynamic> data) =>
      MetaForFilesStruct(
        fileName: data['fileName'] as String?,
        format: data['format'] as String?,
        error: data['error'] as String?,
        sizeInKB: castToType<int>(data['sizeInKB']),
        sizeInMB: castToType<int>(data['sizeInMB']),
        height: castToType<double>(data['height']),
        width: castToType<double>(data['width']),
      );

  static MetaForFilesStruct? maybeFromMap(dynamic data) => data is Map
      ? MetaForFilesStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
        'format': _format,
        'error': _error,
        'sizeInKB': _sizeInKB,
        'sizeInMB': _sizeInMB,
        'height': _height,
        'width': _width,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'format': serializeParam(
          _format,
          ParamType.String,
        ),
        'error': serializeParam(
          _error,
          ParamType.String,
        ),
        'sizeInKB': serializeParam(
          _sizeInKB,
          ParamType.int,
        ),
        'sizeInMB': serializeParam(
          _sizeInMB,
          ParamType.int,
        ),
        'height': serializeParam(
          _height,
          ParamType.double,
        ),
        'width': serializeParam(
          _width,
          ParamType.double,
        ),
      }.withoutNulls;

  static MetaForFilesStruct fromSerializableMap(Map<String, dynamic> data) =>
      MetaForFilesStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        format: deserializeParam(
          data['format'],
          ParamType.String,
          false,
        ),
        error: deserializeParam(
          data['error'],
          ParamType.String,
          false,
        ),
        sizeInKB: deserializeParam(
          data['sizeInKB'],
          ParamType.int,
          false,
        ),
        sizeInMB: deserializeParam(
          data['sizeInMB'],
          ParamType.int,
          false,
        ),
        height: deserializeParam(
          data['height'],
          ParamType.double,
          false,
        ),
        width: deserializeParam(
          data['width'],
          ParamType.double,
          false,
        ),
      );

  @override
  String toString() => 'MetaForFilesStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is MetaForFilesStruct &&
        fileName == other.fileName &&
        format == other.format &&
        error == other.error &&
        sizeInKB == other.sizeInKB &&
        sizeInMB == other.sizeInMB &&
        height == other.height &&
        width == other.width;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([fileName, format, error, sizeInKB, sizeInMB, height, width]);
}

MetaForFilesStruct createMetaForFilesStruct({
  String? fileName,
  String? format,
  String? error,
  int? sizeInKB,
  int? sizeInMB,
  double? height,
  double? width,
}) =>
    MetaForFilesStruct(
      fileName: fileName,
      format: format,
      error: error,
      sizeInKB: sizeInKB,
      sizeInMB: sizeInMB,
      height: height,
      width: width,
    );
