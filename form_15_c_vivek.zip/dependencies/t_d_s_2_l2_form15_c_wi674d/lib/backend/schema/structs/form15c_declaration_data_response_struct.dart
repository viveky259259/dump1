// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15cDeclarationDataResponseStruct extends BaseStruct {
  Form15cDeclarationDataResponseStruct({
    String? message,
    String? status,
    List<Form15cDeclarationDataStruct>? data,
  })  : _message = message,
        _status = status,
        _data = data;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "data" field.
  List<Form15cDeclarationDataStruct>? _data;
  List<Form15cDeclarationDataStruct> get data => _data ?? const [];
  set data(List<Form15cDeclarationDataStruct>? val) => _data = val;

  void updateData(Function(List<Form15cDeclarationDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  static Form15cDeclarationDataResponseStruct fromMap(
          Map<String, dynamic> data) =>
      Form15cDeclarationDataResponseStruct(
        message: data['message'] as String?,
        status: data['status'] as String?,
        data: getStructList(
          data['data'],
          Form15cDeclarationDataStruct.fromMap,
        ),
      );

  static Form15cDeclarationDataResponseStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? Form15cDeclarationDataResponseStruct.fromMap(
              data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'message': _message,
        'status': _status,
        'data': _data?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static Form15cDeclarationDataResponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15cDeclarationDataResponseStruct(
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
        data: deserializeStructParam<Form15cDeclarationDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: Form15cDeclarationDataStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'Form15cDeclarationDataResponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is Form15cDeclarationDataResponseStruct &&
        message == other.message &&
        status == other.status &&
        listEquality.equals(data, other.data);
  }

  @override
  int get hashCode => const ListEquality().hash([message, status, data]);
}

Form15cDeclarationDataResponseStruct
    createForm15cDeclarationDataResponseStruct({
  String? message,
  String? status,
}) =>
        Form15cDeclarationDataResponseStruct(
          message: message,
          status: status,
        );
