import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_commons/api_requests/api_manager.dart';
import 'interceptors.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/backend/api_requests/interceptors.dart'
    as t_d_s_2_l1_logic_2wrus1_api_interceptors;
import 'package:t_d_s_2_l1_logic_2wrus1/backend/api_requests/interceptors.dart'
    as t_d_s_2_l1_logic_2wrus1_api_interceptors;
import 'package:ff_commons/api_requests/api_interceptor.dart';

import 'package:ff_commons/api_requests/api_paging_params.dart';

export 'package:ff_commons/api_requests/api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class UploadFilesCall {
  static Future<ApiCallResponse> call({
    List<FFUploadedFile>? filesList,
  }) async {
    final files = filesList ?? [];

    return ApiManager.instance.makeApiCall(
      callName: 'UploadFiles',
      apiUrl: 'http://192.168.31.191:8082/files/upload',
      callType: ApiCallType.POST,
      headers: {},
      params: {
        'files': files,
        'panNumber': "VPGSX9897X",
        'serviceName': "asdasd",
      },
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: true,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetFormFifteenCPreviewDataAPICallCall {
  static Future<ApiCallResponse> call({
    String? panNumber = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Form Fifteen C Preview Data API Call',
      apiUrl: 'http://localhost:8082/api/forms-details/fetch/panNumber',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'panNumber': panNumber,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class BankDetailsCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'Bank Details',
      apiUrl: 'http://localhost:8090/api/form15C/bankDetails/all',
      callType: ApiCallType.GET,
      headers: {
        'Content-Type': 'application/json',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetUploadedFilesAPICallCall {
  static Future<ApiCallResponse> call({
    String? panNumber = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Uploaded Files API Call',
      apiUrl: 'http://localhost:8082/files/fetch/panNumber',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'panNumber': panNumber,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetPreviewBankBranchDataAPICallCall {
  static Future<ApiCallResponse> call({
    String? panNumber = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Preview Bank Branch Data API Call',
      apiUrl: 'http://localhost:8082/api/form15c/bankDetails/${panNumber}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetDeclarationDataAPICallCall {
  static Future<ApiCallResponse> call({
    String? panNumber = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Declaration Data API Call',
      apiUrl: 'http://localhost:8090/api/form15c/usersDetails/${panNumber}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DeclarationProceedButtonAPICallCall {
  static Future<ApiCallResponse> call() async {
    final ffApiRequestBody = '''
{
  "panNumber": "ABCDE1234F",
  "emailId": "example@example.com",
  "state": "State",
  "residentialStatus": "Status",
  "phoneNumber": "1234567890",
  "ipAddress": "192.168.1.1",
  "date": "2023-10-10T00:00:00.000Z",
  "place": "Place"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Declaration Proceed Button API Call',
      apiUrl: 'http://localhost:8090/api/form15c/usersDetails/save',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SubmitFormFifteenCAPICallCall {
  static Future<ApiCallResponse> call() async {
    final ffApiRequestBody = '''
{
  "applPanTan": "ABCDE1234F",
  "reqType": "1",
  "status": "5",
  "formSubmtDate": "2023-01-01",
  "requestTmstmp": "2023-01-01T10:00:00"
}''';
    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Submit Form Fifteen c API Call',
        apiUrl: 'http://localhost:8090/api/form15c/saved',
        callType: ApiCallType.POST,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},
        body: ffApiRequestBody,
        bodyType: BodyType.JSON,
        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      interceptors,
    );
  }

  static final interceptors = [
    t_d_s_2_l1_logic_2wrus1_api_interceptors.EncryptionInterceptor(),
  ];
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
