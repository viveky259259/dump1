import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/components/confirmation_alert_dialog_form15_c_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_upload_files_save_proceed_dialog_box_model.dart';
export 'presentation_upload_files_save_proceed_dialog_box_model.dart';

class PresentationUploadFilesSaveProceedDialogBoxWidget extends StatefulWidget {
  const PresentationUploadFilesSaveProceedDialogBoxWidget({
    super.key,
    this.files,
  });

  final List<FFUploadedFile>? files;

  @override
  State<PresentationUploadFilesSaveProceedDialogBoxWidget> createState() =>
      _PresentationUploadFilesSaveProceedDialogBoxWidgetState();
}

class _PresentationUploadFilesSaveProceedDialogBoxWidgetState
    extends State<PresentationUploadFilesSaveProceedDialogBoxWidget> {
  late PresentationUploadFilesSaveProceedDialogBoxModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => PresentationUploadFilesSaveProceedDialogBoxModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: 520.0,
      ),
      decoration: BoxDecoration(),
      child: t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
        model: _model.confirmationAlertDialogForm15CModel,
        updateCallback: () => safeSetState(() {}),
        child: t_d_s_login_module_l1_navigation_3he2k0
            .ConfirmationAlertDialogForm15CWidget(
          alertBoxTitle: 'Please confirm if you want to proceed.',
          keyPrefix: 'hgkukl',
          alertBoxContent:
              'You have files uploaded in this section. If you choose to proceed, all the uploaded files will be removed permanently.',
          isIconVisible: false,
          showCancelAndConfirmButton: true,
          onTapExit: () async {},
          onTapSave: () async {},
          onTapCancel: () async {
            Navigator.pop(context, false);
          },
          onTapConfirm: () async {
            Navigator.pop(context, true);
          },
        ),
      ),
    );
  }
}
