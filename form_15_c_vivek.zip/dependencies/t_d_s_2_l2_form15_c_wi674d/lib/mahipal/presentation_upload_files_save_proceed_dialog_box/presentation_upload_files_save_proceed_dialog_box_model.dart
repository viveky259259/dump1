import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/components/confirmation_alert_dialog_form15_c_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'presentation_upload_files_save_proceed_dialog_box_widget.dart'
    show PresentationUploadFilesSaveProceedDialogBoxWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationUploadFilesSaveProceedDialogBoxModel extends FlutterFlowModel<
    PresentationUploadFilesSaveProceedDialogBoxWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Confirmation_Alert_Dialog_Form15C component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .ConfirmationAlertDialogForm15CModel confirmationAlertDialogForm15CModel;

  @override
  void initState(BuildContext context) {
    confirmationAlertDialogForm15CModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .ConfirmationAlertDialogForm15CModel());
  }

  @override
  void dispose() {
    confirmationAlertDialogForm15CModel.dispose();
  }
}
