import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/form15_c/view_as_option/view_as_option_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_website/form_content_card/form_content_card_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'file_new_form_section_model.dart';
export 'file_new_form_section_model.dart';

class FileNewFormSectionWidget extends StatefulWidget {
  const FileNewFormSectionWidget({
    super.key,
    required this.keyPrefix,
    required this.form15CFileNowAction,
    required this.form15DFileNowAction,
    required this.form13FileNowAction,
  });

  final String? keyPrefix;
  final Future Function()? form15CFileNowAction;
  final Future Function()? form15DFileNowAction;
  final Future Function()? form13FileNowAction;

  @override
  State<FileNewFormSectionWidget> createState() =>
      _FileNewFormSectionWidgetState();
}

class _FileNewFormSectionWidgetState extends State<FileNewFormSectionWidget> {
  late FileNewFormSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FileNewFormSectionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            decoration: BoxDecoration(),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'File New Form',
                  style: GoogleFonts.getFont(
                    'Inter',
                    color: FlutterFlowTheme.of(context).textBasic,
                    fontWeight: FontWeight.w500,
                    fontSize: 16.0,
                  ),
                ),
                t_d_s_2_l1_presentation_0l6uwx_util.wrapWithModel(
                  model: _model.viewAsOptionModel,
                  updateCallback: () => safeSetState(() {}),
                  child: t_d_s_2_l1_presentation_0l6uwx.ViewAsOptionWidget(
                    activeIndex: 0,
                    label: 'View As',
                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                        .generateL2KeyValuePrefix(widget!.keyPrefix!,
                            'File_New_Form_section', 'View_As_option'),
                    onClick: (index) async {
                      _model.isGridView =
                          _model.viewAsOptionModel.activeState == 0;
                      _model.updatePage(() {});
                    },
                  ),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).neutralBGStroke10,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Builder(
                  builder: (context) {
                    if (!_model.isGridView) {
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 24.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.formContentCardModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .FormContentCardWidget(
                                labelText: 'Form 15C',
                                formDetails:
                                    'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'File_New_Form_Section',
                                        'Form_ContentCard_15C_ListView'),
                                isGridView: _model.isGridView,
                                onFileNow: () async {
                                  await widget.form15CFileNowAction?.call();
                                },
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 24.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.formContentCardModel2,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .FormContentCardWidget(
                                labelText: 'Form 15D',
                                formDetails:
                                    'Application by a person other than a banking company for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of sums other than interest and dividends without deduction of tax.',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'File_New_Form_Section',
                                        'Form_ContentCard_15D_ListView'),
                                isGridView: _model.isGridView,
                                onFileNow: () async {
                                  await widget.form15DFileNowAction?.call();
                                },
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 24.0, 24.0, 14.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.formContentCardModel3,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .FormContentCardWidget(
                                labelText: 'Form 13',
                                formDetails:
                                    'Application by a person for a certificate under Section 197 and/or sub-section (9) of Section 206C of the Income-tax Act, 1961, for no deduction of tax or deduction or collection of tax at a lower rate',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'File_New_Form_Section',
                                        'Form_ContentCard_15_ListView'),
                                isGridView: _model.isGridView,
                                onFileNow: () async {
                                  await widget.form13FileNowAction?.call();
                                },
                              ),
                            ),
                          ),
                        ],
                      );
                    } else {
                      return Wrap(
                        spacing: 0.0,
                        runSpacing: 0.0,
                        alignment: WrapAlignment.start,
                        crossAxisAlignment: WrapCrossAlignment.start,
                        direction: Axis.horizontal,
                        runAlignment: WrapAlignment.start,
                        verticalDirection: VerticalDirection.down,
                        clipBehavior: Clip.none,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 24.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.formContentCardModel4,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .FormContentCardWidget(
                                labelText: 'Form 15C',
                                formDetails:
                                    'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'File_New_Form_Section',
                                        'Form_ContentCard_15C_GridView'),
                                isGridView: _model.isGridView,
                                onFileNow: () async {
                                  await widget.form15CFileNowAction?.call();
                                },
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 24.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.formContentCardModel5,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .FormContentCardWidget(
                                labelText: 'Form 15D',
                                formDetails:
                                    'Application by a person other than a banking company for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of sums other than interest and dividends without deduction of tax.',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'File_New_Form_Section',
                                        'Form_ContentCard_15D_GridView'),
                                isGridView: _model.isGridView,
                                onFileNow: () async {
                                  await widget.form15DFileNowAction?.call();
                                },
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 24.0, 24.0, 24.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.formContentCardModel6,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .FormContentCardWidget(
                                labelText: 'Form 13',
                                formDetails:
                                    'Application by a person for a certificate under Section 197 and/or sub-section (9) of Section 206C of the Income-tax Act, 1961, for no deduction of tax or deduction or collection of tax at a lower rate',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'File_New_Form_Section',
                                        'Form_ContentCard_15_GridView'),
                                isGridView: _model.isGridView,
                                onFileNow: () async {
                                  await widget.form13FileNowAction?.call();
                                },
                              ),
                            ),
                          ),
                        ],
                      );
                    }
                  },
                ),
              ],
            ),
          ),
        ].divide(SizedBox(height: 12.0)),
      ),
    );
  }
}
