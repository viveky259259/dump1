import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'file_new_form_section_widget.dart' show FileNewFormSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/form15_c/view_as_option/view_as_option_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_website/form_content_card/form_content_card_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FileNewFormSectionModel
    extends FlutterFlowModel<FileNewFormSectionWidget> {
  ///  Local state fields for this component.

  bool isGridView = true;

  ///  State fields for stateful widgets in this component.

  // Model for View_As_Option component.
  late t_d_s_2_l1_presentation_0l6uwx.ViewAsOptionModel viewAsOptionModel;
  // Model for Form_ContentCard component.
  late t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel
      formContentCardModel1;
  // Model for Form_ContentCard component.
  late t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel
      formContentCardModel2;
  // Model for Form_ContentCard component.
  late t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel
      formContentCardModel3;
  // Model for Form_ContentCard component.
  late t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel
      formContentCardModel4;
  // Model for Form_ContentCard component.
  late t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel
      formContentCardModel5;
  // Model for Form_ContentCard component.
  late t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel
      formContentCardModel6;

  @override
  void initState(BuildContext context) {
    viewAsOptionModel = t_d_s_2_l1_presentation_0l6uwx_util.createModel(
        context, () => t_d_s_2_l1_presentation_0l6uwx.ViewAsOptionModel());
    formContentCardModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel());
    formContentCardModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel());
    formContentCardModel3 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel());
    formContentCardModel4 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel());
    formContentCardModel5 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel());
    formContentCardModel6 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.FormContentCardModel());
  }

  @override
  void dispose() {
    viewAsOptionModel.dispose();
    formContentCardModel1.dispose();
    formContentCardModel2.dispose();
    formContentCardModel3.dispose();
    formContentCardModel4.dispose();
    formContentCardModel5.dispose();
    formContentCardModel6.dispose();
  }
}
