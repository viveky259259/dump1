import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/presentation_upload_files_save_proceed_dialog_box/presentation_upload_files_save_proceed_dialog_box_widget.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:t_d_s_2_l1_logic_2wrus1/custom_code/actions/index.dart'
    as t_d_s_2_l1_logic_2wrus1_actions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/file_attachment/file_attachment_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/radio_buttons/input_field_generic_radio_buttton/input_field_generic_radio_buttton_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_upload_files_section_model.dart';
export 'presentation_upload_files_section_model.dart';

class PresentationUploadFilesSectionWidget extends StatefulWidget {
  const PresentationUploadFilesSectionWidget({
    super.key,
    required this.keyPrefix,
    required this.radioButtonHeader,
  });

  final String? keyPrefix;
  final String? radioButtonHeader;

  @override
  State<PresentationUploadFilesSectionWidget> createState() =>
      _PresentationUploadFilesSectionWidgetState();
}

class _PresentationUploadFilesSectionWidgetState
    extends State<PresentationUploadFilesSectionWidget> {
  late PresentationUploadFilesSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationUploadFilesSectionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Builder(
            builder: (context) =>
                t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
              model: _model.radioButtonUploadDocumentModel,
              updateCallback: () => safeSetState(() {}),
              child: t_d_s_login_module_l1_input_vo62wv
                  .InputFieldGenericRadioButttonWidget(
                labelText: widget!.radioButtonHeader!,
                keyPrefix: 'sds',
                isMandatory: false,
                isVertical: false,
                options: ["Yes", "No"],
                onClickAction: (selectedOption) async {
                  var _shouldSetState = false;
                  if (selectedOption == 'Yes') {
                    _model.uploadEnabled = true;
                    _model.updatePage(() {});
                    if (_shouldSetState) safeSetState(() {});
                    return;
                  } else {
                    if (_model.noOfFiles! > 0) {
                      await showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (dialogContext) {
                          return Dialog(
                            elevation: 0,
                            insetPadding: EdgeInsets.zero,
                            backgroundColor: Colors.transparent,
                            alignment: AlignmentDirectional(0.0, 0.0)
                                .resolve(Directionality.of(context)),
                            child:
                                PresentationUploadFilesSaveProceedDialogBoxWidget(),
                          );
                        },
                      ).then((value) =>
                          safeSetState(() => _model.isConfirm = value));

                      _shouldSetState = true;
                      if (_model.isConfirm == true) {
                        _model.noOfFiles = 0;
                        _model.uploadedFilesFromAction = [];
                        _model.metaDataOfFiles = [];
                        _model.updatePage(() {});
                      } else {
                        safeSetState(() {
                          _model
                              .radioButtonUploadDocumentModel
                              .horizontalRadioButtonValueController
                              ?.value = 'Yes';
                        });
                        if (_shouldSetState) safeSetState(() {});
                        return;
                      }

                      _model.uploadEnabled = false;
                      _model.updatePage(() {});
                    } else {
                      _model.uploadEnabled = false;
                      _model.updatePage(() {});
                      if (_shouldSetState) safeSetState(() {});
                      return;
                    }

                    if (_shouldSetState) safeSetState(() {});
                    return;
                  }

                  if (_shouldSetState) safeSetState(() {});
                },
              ),
            ),
          ),
          if (_model.uploadEnabled == true)
            t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
              model: _model.inputfieldFileUploadBrowseFilesModel,
              updateCallback: () => safeSetState(() {}),
              child: t_d_s_login_module_l1_input_vo62wv
                  .InputfieldFileUploadBrowseFilesWidget(
                width: 320.0,
                keyPrefix:
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'UploadFilesForm_Form15C',
                        'ReturnFilesUploadBox'),
                isDisable: _model.noOfFiles! > 5,
                onTapBrowseFiles: () async {
                  _model.deviceFileList = await t_d_s_2_l1_logic_2wrus1_actions
                      .selectFilesToUploadWithName(
                    (<String>[]).toList(),
                  );
                  _model.uploadedFilesFromAction = functions
                      .addUploadList(_model.deviceFileList!.toList(),
                          _model.uploadedFilesFromAction.toList())
                      .toList()
                      .cast<FFUploadedFile>();
                  _model.metaDataOfFiles = t_d_s_2_l1_logic_2wrus1_functions
                      .getMetadataForUploadedFiles(
                          _model.uploadedFilesFromAction.toList())
                      .toList()
                      .cast<
                          t_d_s_2_l1_logic_2wrus1_data_schema
                          .FileMetadataStruct>();
                  _model.noOfFiles = _model.uploadedFilesFromAction.length;
                  _model.completeMeta = [].toList().cast<MetaForFilesStruct>();
                  _model.updatePage(() {});

                  safeSetState(() {});
                },
              ),
            ),
          Builder(
            builder: (context) {
              final filesListItem = _model.completeMeta.toList();

              return Wrap(
                spacing: 0.0,
                runSpacing: 0.0,
                alignment: WrapAlignment.start,
                crossAxisAlignment: WrapCrossAlignment.start,
                direction: Axis.horizontal,
                runAlignment: WrapAlignment.start,
                verticalDirection: VerticalDirection.down,
                clipBehavior: Clip.none,
                children:
                    List.generate(filesListItem.length, (filesListItemIndex) {
                  final filesListItemItem = filesListItem[filesListItemIndex];
                  return Container(
                    constraints: BoxConstraints(
                      maxWidth:
                          MediaQuery.sizeOf(context).width < kBreakpointSmall
                              ? FFAppConstants.FileAttchmentSmallerMaxWidth
                                  .toDouble()
                              : FFAppConstants.FileAttachementNonSmallMaxWidth
                                  .toDouble(),
                    ),
                    decoration: BoxDecoration(),
                    child: Visibility(
                      visible: _model.uploadEnabled == true,
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 24.0, 0.0),
                        child: t_d_s_login_module_l1_input_vo62wv_util
                            .wrapWithModel(
                          model: _model.fileAttachmentModels.getModel(
                            'File${filesListItemIndex.toString()}',
                            filesListItemIndex,
                          ),
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_input_vo62wv
                              .FileAttachmentWidget(
                            key: Key(
                              'Keyim0_${'File${filesListItemIndex.toString()}'}',
                            ),
                            fileName: '',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'UploadFilesForm_Form15C',
                                    'UploadedReturnFiles_${filesListItemIndex.toString()}'),
                            isFileUploaded: false,
                            errorMsg: filesListItemItem.fileName,
                            fileSize: filesListItemItem.sizeInMB.toString(),
                            uploadSuccesMsg: '',
                            uploadFailedError: false,
                            deleteAction: () async {
                              _model.removeAtIndexFromMetaDataOfFiles(
                                  filesListItemIndex);
                              _model.removeAtIndexFromUploadedFilesFromAction(
                                  filesListItemIndex);
                              _model.noOfFiles = _model.noOfFiles! + -1;
                              _model.updatePage(() {});
                            },
                            onView: () async {},
                            onReload: () async {},
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              );
            },
          ),
        ].divide(SizedBox(height: 24.0)),
      ),
    );
  }
}
