import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/presentation_upload_files_save_proceed_dialog_box/presentation_upload_files_save_proceed_dialog_box_widget.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:t_d_s_2_l1_logic_2wrus1/custom_code/actions/index.dart'
    as t_d_s_2_l1_logic_2wrus1_actions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/file_attachment/file_attachment_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/radio_buttons/input_field_generic_radio_buttton/input_field_generic_radio_buttton_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'presentation_upload_files_section_widget.dart'
    show PresentationUploadFilesSectionWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationUploadFilesSectionModel
    extends FlutterFlowModel<PresentationUploadFilesSectionWidget> {
  ///  Local state fields for this component.

  bool dragBoxIsEnabled = true;

  int? noOfFiles = 0;

  bool uploadEnabled = false;

  int? noOfCorrectFiles = 1;

  List<FFUploadedFile> uploadedFilesFromAction = [];
  void addToUploadedFilesFromAction(FFUploadedFile item) =>
      uploadedFilesFromAction.add(item);
  void removeFromUploadedFilesFromAction(FFUploadedFile item) =>
      uploadedFilesFromAction.remove(item);
  void removeAtIndexFromUploadedFilesFromAction(int index) =>
      uploadedFilesFromAction.removeAt(index);
  void insertAtIndexInUploadedFilesFromAction(int index, FFUploadedFile item) =>
      uploadedFilesFromAction.insert(index, item);
  void updateUploadedFilesFromActionAtIndex(
          int index, Function(FFUploadedFile) updateFn) =>
      uploadedFilesFromAction[index] = updateFn(uploadedFilesFromAction[index]);

  List<t_d_s_2_l1_logic_2wrus1_data_schema.FileMetadataStruct> metaDataOfFiles =
      [];
  void addToMetaDataOfFiles(
          t_d_s_2_l1_logic_2wrus1_data_schema.FileMetadataStruct item) =>
      metaDataOfFiles.add(item);
  void removeFromMetaDataOfFiles(
          t_d_s_2_l1_logic_2wrus1_data_schema.FileMetadataStruct item) =>
      metaDataOfFiles.remove(item);
  void removeAtIndexFromMetaDataOfFiles(int index) =>
      metaDataOfFiles.removeAt(index);
  void insertAtIndexInMetaDataOfFiles(int index,
          t_d_s_2_l1_logic_2wrus1_data_schema.FileMetadataStruct item) =>
      metaDataOfFiles.insert(index, item);
  void updateMetaDataOfFilesAtIndex(
          int index,
          Function(t_d_s_2_l1_logic_2wrus1_data_schema.FileMetadataStruct)
              updateFn) =>
      metaDataOfFiles[index] = updateFn(metaDataOfFiles[index]);

  List<MetaForFilesStruct> completeMeta = [];
  void addToCompleteMeta(MetaForFilesStruct item) => completeMeta.add(item);
  void removeFromCompleteMeta(MetaForFilesStruct item) =>
      completeMeta.remove(item);
  void removeAtIndexFromCompleteMeta(int index) => completeMeta.removeAt(index);
  void insertAtIndexInCompleteMeta(int index, MetaForFilesStruct item) =>
      completeMeta.insert(index, item);
  void updateCompleteMetaAtIndex(
          int index, Function(MetaForFilesStruct) updateFn) =>
      completeMeta[index] = updateFn(completeMeta[index]);

  ///  State fields for stateful widgets in this component.

  // Model for RadioButton_UploadDocument.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericRadioButttonModel
      radioButtonUploadDocumentModel;
  // Stores action output result for [Alert Dialog - Custom Dialog] action in RadioButton_UploadDocument widget.
  bool? isConfirm;
  // Model for Inputfield_File_Upload_BrowseFiles component.
  late t_d_s_login_module_l1_input_vo62wv.InputfieldFileUploadBrowseFilesModel
      inputfieldFileUploadBrowseFilesModel;
  // Stores action output result for [Custom Action - selectFilesToUploadWithName] action in Inputfield_File_Upload_BrowseFiles widget.
  List<FFUploadedFile>? deviceFileList;
  // Models for File_Attachment dynamic component.
  late t_d_s_login_module_l1_input_vo62wv_util.FlutterFlowDynamicModels<
          t_d_s_login_module_l1_input_vo62wv.FileAttachmentModel>
      fileAttachmentModels;

  @override
  void initState(BuildContext context) {
    radioButtonUploadDocumentModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericRadioButttonModel());
    inputfieldFileUploadBrowseFilesModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldFileUploadBrowseFilesModel());
    fileAttachmentModels =
        t_d_s_login_module_l1_input_vo62wv_util.FlutterFlowDynamicModels(
            () => t_d_s_login_module_l1_input_vo62wv.FileAttachmentModel());
  }

  @override
  void dispose() {
    radioButtonUploadDocumentModel.dispose();
    inputfieldFileUploadBrowseFilesModel.dispose();
    fileAttachmentModels.dispose();
  }
}
