import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/presentation_upload_files_section/presentation_upload_files_section_widget.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/form15_c/info_alert/info_alert_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_upload_files_model.dart';
export 'presentation_upload_files_model.dart';

class PresentationUploadFilesWidget extends StatefulWidget {
  const PresentationUploadFilesWidget({
    super.key,
    required this.keyPrefix,
    this.backButtonActn,
    required this.saveProceedBtnActn,
  });

  final String? keyPrefix;
  final Future Function()? backButtonActn;
  final Future Function()? saveProceedBtnActn;

  @override
  State<PresentationUploadFilesWidget> createState() =>
      _PresentationUploadFilesWidgetState();
}

class _PresentationUploadFilesWidgetState
    extends State<PresentationUploadFilesWidget> {
  late PresentationUploadFilesModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationUploadFilesModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Upload Files',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).textPrimary,
                        fontSize: 24.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                Divider(
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).tertiary,
                ),
              ],
            ),
          ),
          t_d_s_2_l1_presentation_0l6uwx_util.wrapWithModel(
            model: _model.infoAlertModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_2_l1_presentation_0l6uwx.InfoAlertWidget(
              description: 'Alert',
              keyPrifix: 'dvdv',
              status: t_d_s_2_l1_presentation_0l6uwx_enums
                  .AlertTextStatus.Information,
              noofPoints: [
                "For upload, attachments in .tiff, .pdf, .zip, .JPEG formats only are allowed.",
                "You can click on 'Browse' to select the relevant files or you can use Drag/Drop for upload.",
                "Maximum of six (6) number of files can be uploaded separately. In case you wish to attach more than 6 files, please upload in .zip format.",
                "Maximum size of single file for upload is 5MB.",
                "Password protected files cannot be uploaded. Please make sure to attach password-free files."
              ],
            ),
          ),
          Divider(
            thickness: 3.0,
            color: FlutterFlowTheme.of(context).neutral300,
          ),
          wrapWithModel(
            model: _model.presentationUploadFilesSectionModel,
            updateCallback: () => safeSetState(() {}),
            child: PresentationUploadFilesSectionWidget(
              keyPrefix: 'sl,dsdsvc',
              radioButtonHeader: 'Did you file any returns in paper form?',
            ),
          ),
          Divider(
            thickness: 3.0,
            color: FlutterFlowTheme.of(context).neutral300,
          ),
          wrapWithModel(
            model: _model.presentationSupportingUploadFilesSectionModel,
            updateCallback: () => safeSetState(() {}),
            child: PresentationUploadFilesSectionWidget(
              keyPrefix: 'sl,dsdsvcscsc',
              radioButtonHeader: 'Upload supporting documents (if any)',
            ),
          ),
          Builder(
            builder: (context) {
              if (() {
                if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                  return true;
                } else if (MediaQuery.sizeOf(context).width <
                    kBreakpointMedium) {
                  return false;
                } else if (MediaQuery.sizeOf(context).width <
                    kBreakpointLarge) {
                  return false;
                } else {
                  return false;
                }
              }()) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                      model: _model.navigationGenericSecondaryButtonModel1,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NavigationGenericSecondaryButtonWidget(
                        labelText: 'Back',
                        keyPrefix: 'LSFLEMF',
                        leftIcon: Icon(
                          Icons.chevron_left_rounded,
                        ),
                        states: t_d_s_login_module_l1_navigation_3he2k0_enums
                            .ButtonState.byDefault,
                        onTap: () async {
                          context.safePop();
                        },
                      ),
                    ),
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                      model: _model.navigationGenericPrimaryButtonModel1,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NavigationGenericPrimaryButtonWidget(
                        labeltext: 'Save & Proceed',
                        keyPrefix: 'SKFMELKFM',
                        states: () {
                          if (_model.presentationUploadFilesSectionModel
                                  .noOfFiles! >
                              0) {
                            return t_d_s_login_module_l1_navigation_3he2k0_enums
                                .ButtonState.byDefault;
                          } else if (_model
                                  .presentationSupportingUploadFilesSectionModel
                                  .noOfFiles! >
                              0) {
                            return t_d_s_login_module_l1_navigation_3he2k0_enums
                                .ButtonState.byDefault;
                          } else {
                            return t_d_s_login_module_l1_navigation_3he2k0_enums
                                .ButtonState.disabled;
                          }
                        }(),
                        onTap: () async {
                          _model.apiResulttin = await UploadFilesCall.call(
                            filesList: _model
                                .presentationUploadFilesSectionModel
                                .uploadedFilesFromAction,
                          );

                          if ((_model.apiResulttin?.succeeded ?? true)) {
                            context.pushNamed('demo');
                          }

                          safeSetState(() {});
                        },
                      ),
                    ),
                  ],
                );
              } else {
                return Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                      model: _model.navigationGenericSecondaryButtonModel2,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NavigationGenericSecondaryButtonWidget(
                        labelText: 'Back',
                        keyPrefix: 'vfdrvec',
                        leftIcon: Icon(
                          Icons.chevron_left_rounded,
                        ),
                        states: t_d_s_login_module_l1_navigation_3he2k0_enums
                            .ButtonState.byDefault,
                        onTap: () async {
                          context.safePop();
                        },
                      ),
                    ),
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                      model: _model.navigationGenericPrimaryButtonModel2,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NavigationGenericPrimaryButtonWidget(
                        labeltext: 'Save & Proceed',
                        keyPrefix: 'lokdoejf',
                        states: () {
                          if (_model.presentationUploadFilesSectionModel
                                  .noOfFiles! >
                              0) {
                            return t_d_s_login_module_l1_navigation_3he2k0_enums
                                .ButtonState.byDefault;
                          } else if (_model
                                  .presentationSupportingUploadFilesSectionModel
                                  .noOfFiles! >
                              0) {
                            return t_d_s_login_module_l1_navigation_3he2k0_enums
                                .ButtonState.byDefault;
                          } else {
                            return t_d_s_login_module_l1_navigation_3he2k0_enums
                                .ButtonState.disabled;
                          }
                        }(),
                        onTap: () async {
                          _model.apiResult47c = await UploadFilesCall.call(
                            filesList: _model
                                .presentationUploadFilesSectionModel
                                .uploadedFilesFromAction,
                          );

                          if ((_model.apiResult47c?.succeeded ?? true)) {
                            context.pushNamed('demo2');
                          }

                          safeSetState(() {});
                        },
                      ),
                    ),
                  ],
                );
              }
            },
          ),
        ].divide(SizedBox(height: 32.0)),
      ),
    );
  }
}
