import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/presentation_upload_files_section/presentation_upload_files_section_widget.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/form15_c/info_alert/info_alert_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'presentation_upload_files_widget.dart'
    show PresentationUploadFilesWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationUploadFilesModel
    extends FlutterFlowModel<PresentationUploadFilesWidget> {
  ///  Local state fields for this component.

  bool uploadEnable = false;

  ///  State fields for stateful widgets in this component.

  // Model for InfoAlert component.
  late t_d_s_2_l1_presentation_0l6uwx.InfoAlertModel infoAlertModel;
  // Model for Presentation_uploadFiles_section component.
  late PresentationUploadFilesSectionModel presentationUploadFilesSectionModel;
  // Model for Presentation_supportingUploadFiles_section.
  late PresentationUploadFilesSectionModel
      presentationSupportingUploadFilesSectionModel;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Stores action output result for [Backend Call - API (UploadFiles)] action in Navigation_Generic_Primary_Button widget.
  ApiCallResponse? apiResulttin;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;
  // Stores action output result for [Backend Call - API (UploadFiles)] action in Navigation_Generic_Primary_Button widget.
  ApiCallResponse? apiResult47c;

  @override
  void initState(BuildContext context) {
    infoAlertModel = t_d_s_2_l1_presentation_0l6uwx_util.createModel(
        context, () => t_d_s_2_l1_presentation_0l6uwx.InfoAlertModel());
    presentationUploadFilesSectionModel =
        createModel(context, () => PresentationUploadFilesSectionModel());
    presentationSupportingUploadFilesSectionModel =
        createModel(context, () => PresentationUploadFilesSectionModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    infoAlertModel.dispose();
    presentationUploadFilesSectionModel.dispose();
    presentationSupportingUploadFilesSectionModel.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
  }
}
