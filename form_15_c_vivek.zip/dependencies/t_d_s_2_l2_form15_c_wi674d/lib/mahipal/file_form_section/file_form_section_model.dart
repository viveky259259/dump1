import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/file_new_form_section/file_new_form_section_widget.dart';
import '/mahipal/in_progress_form_section/in_progress_form_section_widget.dart';
import 'dart:ui';
import 'file_form_section_widget.dart' show FileFormSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_breadcrumbs/navigation_generic_breadcrumbs_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FileFormSectionModel extends FlutterFlowModel<FileFormSectionWidget> {
  ///  Local state fields for this component.

  int? isGrid = 0;

  ///  State fields for stateful widgets in this component.

  // Model for Navigation_Generic_Breadcrumbs component.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationGenericBreadcrumbsModel
      navigationGenericBreadcrumbsModel;
  // Model for In_Progress_Form_Section component.
  late InProgressFormSectionModel inProgressFormSectionModel;
  // Model for File_New_Form_Section component.
  late FileNewFormSectionModel fileNewFormSectionModel;

  @override
  void initState(BuildContext context) {
    navigationGenericBreadcrumbsModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericBreadcrumbsModel());
    inProgressFormSectionModel =
        createModel(context, () => InProgressFormSectionModel());
    fileNewFormSectionModel =
        createModel(context, () => FileNewFormSectionModel());
  }

  @override
  void dispose() {
    navigationGenericBreadcrumbsModel.dispose();
    inProgressFormSectionModel.dispose();
    fileNewFormSectionModel.dispose();
  }
}
