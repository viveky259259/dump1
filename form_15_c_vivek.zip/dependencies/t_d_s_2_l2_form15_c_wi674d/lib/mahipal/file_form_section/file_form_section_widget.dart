import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/file_new_form_section/file_new_form_section_widget.dart';
import '/mahipal/in_progress_form_section/in_progress_form_section_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_breadcrumbs/navigation_generic_breadcrumbs_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'file_form_section_model.dart';
export 'file_form_section_model.dart';

/// This Form Info Template component utilizes a generic component named Form
/// Content Card to display the different tax-related forms like Form 15C,
/// Form 15D, Form 13.
///
///
/// Dynamic View State: The overall layout of the cards(grid or list view) is
/// controlled by a component state(isGridView) which determines how the card
/// are arranged and displayed.
/// State and Behavior
/// 1. Initial State:
/// isGridView = true
/// The forms are displayed in a grid layout. This is the default view which
/// is already mentioned in the generic Form Content Card with the cards
/// appearing side by side.
/// 2. Toggle Behavior
/// On Grid View icon click the state isGridView is set as "True".
/// On List View icon click state isGridView changes to false so the component
/// adjusts its layout switching to a list view where the forms are displayed
/// in a vertical single column format for list like appearance.
class FileFormSectionWidget extends StatefulWidget {
  const FileFormSectionWidget({
    super.key,
    required this.keyPrefix,
    this.onShowDraft,
    this.onDeleteDraft,
    this.onResumeForm,
    this.onViewAsButton,
    required this.onBreadCrumbTap,
    required this.breadcrumbs,
  });

  final String? keyPrefix;
  final Future Function()? onShowDraft;
  final Future Function()? onDeleteDraft;
  final Future Function()? onResumeForm;
  final Future Function()? onViewAsButton;
  final Future Function(String breadcrumbName)? onBreadCrumbTap;
  final List<String>? breadcrumbs;

  @override
  State<FileFormSectionWidget> createState() => _FileFormSectionWidgetState();
}

class _FileFormSectionWidgetState extends State<FileFormSectionWidget> {
  late FileFormSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FileFormSectionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
            child: t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
              model: _model.navigationGenericBreadcrumbsModel,
              updateCallback: () => safeSetState(() {}),
              child: t_d_s_login_module_l1_navigation_3he2k0
                  .NavigationGenericBreadcrumbsWidget(
                keyPrefix:
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'File_Form_section',
                        'To_Show_Navigation'),
                listItems: widget!.breadcrumbs!,
                onItemTap: (index) async {
                  context.safePop();
                },
              ),
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
            child: wrapWithModel(
              model: _model.inProgressFormSectionModel,
              updateCallback: () => safeSetState(() {}),
              child: InProgressFormSectionWidget(
                keyPrefix:
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'Form_Form_section',
                        'In_Progress_Form_Section'),
                deleteDraftButtonAction: () async {},
                resumeButtonAction: () async {},
                showAllDraftButtonAction: () async {},
              ),
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 32.0, 0.0, 0.0),
            child: wrapWithModel(
              model: _model.fileNewFormSectionModel,
              updateCallback: () => safeSetState(() {}),
              child: FileNewFormSectionWidget(
                keyPrefix:
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'File_Form_Section',
                        'File_New_Form_Section'),
                form15CFileNowAction: () async {},
                form15DFileNowAction: () async {},
                form13FileNowAction: () async {},
              ),
            ),
          ),
        ],
      ),
    );
  }
}
