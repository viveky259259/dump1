import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/components/icon_text_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'in_progress_form_section_model.dart';
export 'in_progress_form_section_model.dart';

class InProgressFormSectionWidget extends StatefulWidget {
  const InProgressFormSectionWidget({
    super.key,
    required this.keyPrefix,
    required this.deleteDraftButtonAction,
    required this.resumeButtonAction,
    required this.showAllDraftButtonAction,
  });

  final String? keyPrefix;
  final Future Function()? deleteDraftButtonAction;
  final Future Function()? resumeButtonAction;
  final Future Function()? showAllDraftButtonAction;

  @override
  State<InProgressFormSectionWidget> createState() =>
      _InProgressFormSectionWidgetState();
}

class _InProgressFormSectionWidgetState
    extends State<InProgressFormSectionWidget> {
  late InProgressFormSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InProgressFormSectionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 16.0),
            child: Container(
              decoration: BoxDecoration(),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'In-Progress Forms',
                    style: GoogleFonts.getFont(
                      'Inter',
                      color: FlutterFlowTheme.of(context).textBasic,
                      fontWeight: FontWeight.w500,
                      fontSize: 16.0,
                    ),
                  ),
                  t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                    model: _model.iconTextButtonModel,
                    updateCallback: () => safeSetState(() {}),
                    child: t_d_s_login_module_l1_navigation_3he2k0
                        .IconTextButtonWidget(
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(widget!.keyPrefix!,
                              'In_Progress_Form_Section', 'IconTextButton'),
                      buttonText: 'Show All Draft Forms',
                      icon: Icon(
                        Icons.add_circle_outline_outlined,
                        color: FlutterFlowTheme.of(context).secondary,
                      ),
                      onClickAction: () async {
                        await widget.showAllDraftButtonAction?.call();
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Builder(
                  builder: (context) {
                    if (() {
                      if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                        return false;
                      } else if (MediaQuery.sizeOf(context).width <
                          kBreakpointMedium) {
                        return true;
                      } else if (MediaQuery.sizeOf(context).width <
                          kBreakpointLarge) {
                        return true;
                      } else {
                        return true;
                      }
                    }()) {
                      return Container(
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    24.0, 16.0, 128.0, 16.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Form 15C',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            fontSize: 16.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                    Text(
                                      'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                                      maxLines: 4,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    Wrap(
                                      spacing: 40.0,
                                      runSpacing: 0.0,
                                      alignment: WrapAlignment.start,
                                      crossAxisAlignment:
                                          WrapCrossAlignment.start,
                                      direction: Axis.horizontal,
                                      runAlignment: WrapAlignment.start,
                                      verticalDirection: VerticalDirection.down,
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'F.Y. 2023-24',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                        Text(
                                          'PAN: BUXPR809JG',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                        Text(
                                          'Last Modified: 07 Oct 2024',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                        Text(
                                          'Time: 15:02:35',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ].divide(SizedBox(height: 8.0)),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 24.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  t_d_s_login_module_l1_navigation_3he2k0_util
                                      .wrapWithModel(
                                    model: _model
                                        .navigationGenericSecondaryButtonModel1,
                                    updateCallback: () => safeSetState(() {}),
                                    child: t_d_s_login_module_l1_navigation_3he2k0
                                        .NavigationGenericSecondaryButtonWidget(
                                      labelText: 'Delete Draft',
                                      keyPrefix: '',
                                      states:
                                          t_d_s_login_module_l1_navigation_3he2k0_enums
                                              .ButtonState.byDefault,
                                      onTap: () async {
                                        await widget.deleteDraftButtonAction
                                            ?.call();
                                      },
                                    ),
                                  ),
                                  t_d_s_login_module_l1_navigation_3he2k0_util
                                      .wrapWithModel(
                                    model: _model
                                        .navigationGenericPrimaryButtonModel1,
                                    updateCallback: () => safeSetState(() {}),
                                    child: t_d_s_login_module_l1_navigation_3he2k0
                                        .NavigationGenericPrimaryButtonWidget(
                                      labeltext: 'Resume',
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL2KeyValuePrefix(
                                              widget!.keyPrefix!,
                                              'In_Progress_Form_Section',
                                              'Navigation_Generic_Primary_Button_BigScreen'),
                                      states:
                                          t_d_s_login_module_l1_navigation_3he2k0_enums
                                              .ButtonState.byDefault,
                                      onTap: () async {
                                        await widget.resumeButtonAction?.call();
                                      },
                                    ),
                                  ),
                                ].divide(SizedBox(width: 16.0)),
                              ),
                            ),
                          ],
                        ),
                      );
                    } else {
                      return Container(
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                'Form 15C',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      fontSize: 16.0,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 8.0, 0.0, 8.0),
                                child: Text(
                                  'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        flex: 1,
                                        child: Text(
                                          'F.Y. 2023-24',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Text(
                                          'PAN: BUXPR809JG',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        flex: 1,
                                        child: Text(
                                          'Last Modified: 07 Oct 2024',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Text(
                                          'Time: 15:02:35',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 16.0, 0.0, 16.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                      model: _model
                                          .navigationGenericSecondaryButtonModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_navigation_3he2k0
                                          .NavigationGenericSecondaryButtonWidget(
                                        labelText: 'Delete Draft',
                                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL2KeyValuePrefix(
                                                widget!.keyPrefix!,
                                                'In_Progress_Form_Section',
                                                'Navigation_Generic_Secondary_Button_SmallScreen'),
                                        states:
                                            t_d_s_login_module_l1_navigation_3he2k0_enums
                                                .ButtonState.byDefault,
                                        onTap: () async {
                                          await widget.deleteDraftButtonAction
                                              ?.call();
                                        },
                                      ),
                                    ),
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                      model: _model
                                          .navigationGenericPrimaryButtonModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_navigation_3he2k0
                                          .NavigationGenericPrimaryButtonWidget(
                                        labeltext: 'Resume',
                                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL2KeyValuePrefix(
                                                widget!.keyPrefix!,
                                                'In_Progress_Form_Section',
                                                'Navigation_Generic_Primary_Button_SmallScreen'),
                                        states:
                                            t_d_s_login_module_l1_navigation_3he2k0_enums
                                                .ButtonState.byDefault,
                                        onTap: () async {
                                          await widget.resumeButtonAction
                                              ?.call();
                                        },
                                      ),
                                    ),
                                  ].divide(SizedBox(height: 12.0)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
