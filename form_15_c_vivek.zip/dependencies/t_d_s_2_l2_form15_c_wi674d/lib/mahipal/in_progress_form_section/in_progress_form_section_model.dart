import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'in_progress_form_section_widget.dart' show InProgressFormSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/components/icon_text_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InProgressFormSectionModel
    extends FlutterFlowModel<InProgressFormSectionWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for IconTextButton component.
  late t_d_s_login_module_l1_navigation_3he2k0.IconTextButtonModel
      iconTextButtonModel;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;

  @override
  void initState(BuildContext context) {
    iconTextButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_navigation_3he2k0.IconTextButtonModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    iconTextButtonModel.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
  }
}
