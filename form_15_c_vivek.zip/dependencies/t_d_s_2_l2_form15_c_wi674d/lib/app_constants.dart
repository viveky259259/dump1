import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String Form15CStepperTitle = 'Filling Form 15C';
  static const List<String> Form15CFormSteps = [
    'Basic Details',
    'Upload Files',
    'Declaration',
    'Preview & Download',
    'Validation'
  ];
  static const double breakpointsmall = 479.0;
  static const double breakpointMedium = 767.0;
  static const double breakpointLarge = 991.0;
  static const List<String> ResidentialStatus = [
    'Resident',
    'Non-Resident',
    'Non-Ordinarily Resident'
  ];
  static const List<String> ThingsToKnowForFillingForm15C = [
    'Form 15C can be filed for the Current Financial Year and for the upcoming Financial Year during the period of January to March of the existing Financial Year.',
    'Form 15C can be filed using any of these e-verification options - Digital Signature (DSC), e-verification through Netbanking, Aadhaar OTP or Mobile OTP. In case you wish to submit Form 15C using DSC, please register your DSC first on TRACES portal if not already registered.',
    'The application shall be assigned to the Jurisdictional Assessing Officer on the basis of the State and District details furnished in filed Form 15C.',
    'In case Return of Income for any of the six (6) previous years have been filed in paper form, copies of the same shall be required to be attached along with the submission of Form 15C application'
  ];
  static const List<String> BreadCrumConstantForFileForm = [
    'Home',
    'File Form'
  ];
  static const int FileAttchmentSmallerMaxWidth = 343;
  static const int FileAttachementNonSmallMaxWidth = 407;
}
