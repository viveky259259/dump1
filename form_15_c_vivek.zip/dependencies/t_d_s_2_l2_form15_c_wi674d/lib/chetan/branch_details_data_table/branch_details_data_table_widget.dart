import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'branch_details_data_table_model.dart';
export 'branch_details_data_table_model.dart';

class BranchDetailsDataTableWidget extends StatefulWidget {
  const BranchDetailsDataTableWidget({
    super.key,
    required this.branchDetailsDataList,
    this.tableMinWidth,
    this.tableMaxWidth,
    this.tableMaxHeight,
  });

  final List<Form15cBankBranchDataStruct>? branchDetailsDataList;
  final double? tableMinWidth;
  final double? tableMaxWidth;
  final double? tableMaxHeight;

  @override
  State<BranchDetailsDataTableWidget> createState() =>
      _BranchDetailsDataTableWidgetState();
}

class _BranchDetailsDataTableWidgetState
    extends State<BranchDetailsDataTableWidget> {
  late BranchDetailsDataTableModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BranchDetailsDataTableModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: valueOrDefault<double>(
          widget!.tableMaxWidth,
          1008.0,
        ),
        maxHeight: valueOrDefault<double>(
          widget!.tableMaxHeight,
          320.0,
        ),
      ),
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            child: Builder(
              builder: (context) {
                final branchDetailsDataDynamicList =
                    widget!.branchDetailsDataList!.toList();

                return FlutterFlowDataTable<Form15cBankBranchDataStruct>(
                  controller: _model.paginatedDataTableController,
                  data: branchDetailsDataDynamicList,
                  columnsBuilder: (onSortChanged) => [
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          ' ',
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'Country',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'State',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'District',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'Flat/Door/Building',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'Road/Street/Block/Sector',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'PIN Code',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'Post Office',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                    DataColumn2(
                      label: DefaultTextStyle.merge(
                        softWrap: true,
                        child: Text(
                          'Area/Locality',
                          style: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                                lineHeight: 1.5,
                              ),
                        ),
                      ),
                    ),
                  ],
                  dataRowBuilder: (branchDetailsDataDynamicListItem,
                          branchDetailsDataDynamicListIndex,
                          selected,
                          onSelectChanged) =>
                      DataRow(
                    color: MaterialStateProperty.all(
                      branchDetailsDataDynamicListIndex % 2 == 0
                          ? FlutterFlowTheme.of(context).neutral100
                          : FlutterFlowTheme.of(context).primaryBGStroke5,
                    ),
                    cells: [
                      Text(
                        (branchDetailsDataDynamicListIndex + 1).toString(),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.country,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.state,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.district,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.flat,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.block,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.pincode,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.postoffice,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                      Text(
                        branchDetailsDataDynamicListItem.areaLocality,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                    ].map((c) => DataCell(c)).toList(),
                  ),
                  paginated: false,
                  selectable: false,
                  minWidth: valueOrDefault<double>(
                    widget!.tableMinWidth,
                    1008.0,
                  ),
                  headingRowHeight: 60.0,
                  dataRowHeight: 58.0,
                  columnSpacing: 24.0,
                  headingRowColor:
                      FlutterFlowTheme.of(context).primaryBGStroke5,
                  borderRadius: BorderRadius.circular(4.0),
                  addHorizontalDivider: true,
                  addTopAndBottomDivider: true,
                  hideDefaultHorizontalDivider: true,
                  horizontalDividerColor:
                      FlutterFlowTheme.of(context).neutral300,
                  horizontalDividerThickness: 1.0,
                  addVerticalDivider: false,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
