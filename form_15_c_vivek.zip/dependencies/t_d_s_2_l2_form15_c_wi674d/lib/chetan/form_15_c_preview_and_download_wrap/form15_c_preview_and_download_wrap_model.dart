import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/chetan/branch_details_data_table/branch_details_data_table_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import '/flutter_flow/custom_functions.dart' as functions;
import 'form15_c_preview_and_download_wrap_widget.dart'
    show Form15CPreviewAndDownloadWrapWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/registration_components/input_genric_heading_text/input_genric_heading_text_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/naviation_generic_file_upload_list/naviation_generic_file_upload_list_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_hyper_link_button_with_icon/navigation_generic_hyper_link_button_with_icon_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CPreviewAndDownloadWrapModel
    extends FlutterFlowModel<Form15CPreviewAndDownloadWrapWidget> {
  ///  Local state fields for this component.

  Form15cPreviewDataStruct? previewDataCompState;
  void updatePreviewDataCompStateStruct(
      Function(Form15cPreviewDataStruct) updateFn) {
    updateFn(previewDataCompState ??= Form15cPreviewDataStruct());
  }

  List<t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct>
      uploadedFileListCompState = [];
  void addToUploadedFileListCompState(
          t_d_s_login_module_l1_navigation_3he2k0_data_schema
              .FileUploadInfoStruct
              item) =>
      uploadedFileListCompState.add(item);
  void removeFromUploadedFileListCompState(
          t_d_s_login_module_l1_navigation_3he2k0_data_schema
              .FileUploadInfoStruct
              item) =>
      uploadedFileListCompState.remove(item);
  void removeAtIndexFromUploadedFileListCompState(int index) =>
      uploadedFileListCompState.removeAt(index);
  void insertAtIndexInUploadedFileListCompState(
          int index,
          t_d_s_login_module_l1_navigation_3he2k0_data_schema
              .FileUploadInfoStruct
              item) =>
      uploadedFileListCompState.insert(index, item);
  void updateUploadedFileListCompStateAtIndex(
          int index,
          Function(
                  t_d_s_login_module_l1_navigation_3he2k0_data_schema
                      .FileUploadInfoStruct)
              updateFn) =>
      uploadedFileListCompState[index] =
          updateFn(uploadedFileListCompState[index]);

  List<Form15cBankBranchDataStruct> bankBranchDataListCompState = [];
  void addToBankBranchDataListCompState(Form15cBankBranchDataStruct item) =>
      bankBranchDataListCompState.add(item);
  void removeFromBankBranchDataListCompState(
          Form15cBankBranchDataStruct item) =>
      bankBranchDataListCompState.remove(item);
  void removeAtIndexFromBankBranchDataListCompState(int index) =>
      bankBranchDataListCompState.removeAt(index);
  void insertAtIndexInBankBranchDataListCompState(
          int index, Form15cBankBranchDataStruct item) =>
      bankBranchDataListCompState.insert(index, item);
  void updateBankBranchDataListCompStateAtIndex(
          int index, Function(Form15cBankBranchDataStruct) updateFn) =>
      bankBranchDataListCompState[index] =
          updateFn(bankBranchDataListCompState[index]);

  Form15cSubmitDataStruct? form15cSubmitData;
  void updateForm15cSubmitDataStruct(
      Function(Form15cSubmitDataStruct) updateFn) {
    updateFn(form15cSubmitData ??= Form15cSubmitDataStruct());
  }

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Backend Call - API (Get Form Fifteen C Preview Data API Call)] action in Form_15C_Preview_and_Download_Wrap widget.
  ApiCallResponse? previewDataAPIResponseVar;
  // Stores action output result for [Backend Call - API (Get Preview Bank Branch Data API Call)] action in Form_15C_Preview_and_Download_Wrap widget.
  ApiCallResponse? bankBranchDataResponseVar;
  // Stores action output result for [Backend Call - API (Get Uploaded Files API Call)] action in Form_15C_Preview_and_Download_Wrap widget.
  ApiCallResponse? uploadedFilesDataResponseVar;
  // Model for Input_Genric_HeadingText component.
  late t_d_s_login_module_l1_input_vo62wv.InputGenricHeadingTextModel
      inputGenricHeadingTextModel;
  // Model for ApplicationDetailsEditButton.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericHyperLinkButtonWithIconModel
      applicationDetailsEditButtonModel;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel1;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel2;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel3;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel4;
  // Model for BasicDetailsEditButton.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericHyperLinkButtonWithIconModel
      basicDetailsEditButtonModel;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel5;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel6;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel7;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel8;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel9;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel10;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel11;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel12;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel13;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel14;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel15;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel16;
  // Model for BranchDetailsDataTable component.
  late BranchDetailsDataTableModel branchDetailsDataTableModel;
  // Model for Naviation_Generic_FileUploadList component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NaviationGenericFileUploadListModel naviationGenericFileUploadListModel;
  // Model for DeclarationEditButton.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericHyperLinkButtonWithIconModel declarationEditButtonModel;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel17;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel18;
  // Model for InputField_Generic_TextField component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      inputFieldGenericTextFieldModel19;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Stores action output result for [Backend Call - API (Submit Form Fifteen c API Call)] action in Navigation_Generic_Primary_Button widget.
  ApiCallResponse? form15cSubmitResponseVar;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel3;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel4;

  @override
  void initState(BuildContext context) {
    inputGenricHeadingTextModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputGenricHeadingTextModel());
    applicationDetailsEditButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericHyperLinkButtonWithIconModel());
    inputFieldGenericTextFieldModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel3 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel4 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    basicDetailsEditButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericHyperLinkButtonWithIconModel());
    inputFieldGenericTextFieldModel5 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel6 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel7 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel8 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel9 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel10 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel11 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel12 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel13 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel14 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel15 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel16 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    branchDetailsDataTableModel =
        createModel(context, () => BranchDetailsDataTableModel());
    naviationGenericFileUploadListModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NaviationGenericFileUploadListModel());
    declarationEditButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericHyperLinkButtonWithIconModel());
    inputFieldGenericTextFieldModel17 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel18 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    inputFieldGenericTextFieldModel19 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    navigationGenericPrimaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel3 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericSecondaryButtonModel4 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
  }

  @override
  void dispose() {
    inputGenricHeadingTextModel.dispose();
    applicationDetailsEditButtonModel.dispose();
    inputFieldGenericTextFieldModel1.dispose();
    inputFieldGenericTextFieldModel2.dispose();
    inputFieldGenericTextFieldModel3.dispose();
    inputFieldGenericTextFieldModel4.dispose();
    basicDetailsEditButtonModel.dispose();
    inputFieldGenericTextFieldModel5.dispose();
    inputFieldGenericTextFieldModel6.dispose();
    inputFieldGenericTextFieldModel7.dispose();
    inputFieldGenericTextFieldModel8.dispose();
    inputFieldGenericTextFieldModel9.dispose();
    inputFieldGenericTextFieldModel10.dispose();
    inputFieldGenericTextFieldModel11.dispose();
    inputFieldGenericTextFieldModel12.dispose();
    inputFieldGenericTextFieldModel13.dispose();
    inputFieldGenericTextFieldModel14.dispose();
    inputFieldGenericTextFieldModel15.dispose();
    inputFieldGenericTextFieldModel16.dispose();
    branchDetailsDataTableModel.dispose();
    naviationGenericFileUploadListModel.dispose();
    declarationEditButtonModel.dispose();
    inputFieldGenericTextFieldModel17.dispose();
    inputFieldGenericTextFieldModel18.dispose();
    inputFieldGenericTextFieldModel19.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
    navigationGenericSecondaryButtonModel3.dispose();
    navigationGenericSecondaryButtonModel4.dispose();
  }
}
