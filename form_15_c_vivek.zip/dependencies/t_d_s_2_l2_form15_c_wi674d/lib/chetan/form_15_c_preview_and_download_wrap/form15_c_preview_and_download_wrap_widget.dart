import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/chetan/branch_details_data_table/branch_details_data_table_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/registration_components/input_genric_heading_text/input_genric_heading_text_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/naviation_generic_file_upload_list/naviation_generic_file_upload_list_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_hyper_link_button_with_icon/navigation_generic_hyper_link_button_with_icon_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_preview_and_download_wrap_model.dart';
export 'form15_c_preview_and_download_wrap_model.dart';

class Form15CPreviewAndDownloadWrapWidget extends StatefulWidget {
  const Form15CPreviewAndDownloadWrapWidget({
    super.key,
    required this.keyPrefix,
    this.onModifyUploadFile,
    this.onModifyDeclaration,
    this.onBack,
    this.onSubmit,
    this.onDownload,
    required this.panNumber,
    this.onModifyBasicDetails,
  });

  final String? keyPrefix;
  final Future Function()? onModifyUploadFile;
  final Future Function()? onModifyDeclaration;
  final Future Function()? onBack;
  final Future Function()? onSubmit;
  final Future Function()? onDownload;
  final String? panNumber;
  final Future Function()? onModifyBasicDetails;

  @override
  State<Form15CPreviewAndDownloadWrapWidget> createState() =>
      _Form15CPreviewAndDownloadWrapWidgetState();
}

class _Form15CPreviewAndDownloadWrapWidgetState
    extends State<Form15CPreviewAndDownloadWrapWidget> {
  late Form15CPreviewAndDownloadWrapModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CPreviewAndDownloadWrapModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.wait([
        Future(() async {
          // Action 1
          _model.previewDataAPIResponseVar =
              await GetFormFifteenCPreviewDataAPICallCall.call(
            panNumber: 'ABCDE1234F',
          );

          if ((_model.previewDataAPIResponseVar?.succeeded ?? true)) {
            _model.previewDataCompState =
                Form15cPreviewDataResponseStruct.maybeFromMap(
                        (_model.previewDataAPIResponseVar?.jsonBody ?? ''))
                    ?.data;
            safeSetState(() {});
            return;
          } else {
            return;
          }
        }),
        Future(() async {
          _model.bankBranchDataResponseVar =
              await GetPreviewBankBranchDataAPICallCall.call(
            panNumber: 'ABCDE1234F',
          );

          if ((_model.bankBranchDataResponseVar?.succeeded ?? true)) {
            _model.bankBranchDataListCompState = (getJsonField(
              (_model.bankBranchDataResponseVar?.jsonBody ?? ''),
              r'''$.data''',
              true,
            )!
                    .toList()
                    .map<Form15cBankBranchDataStruct?>(
                        Form15cBankBranchDataStruct.maybeFromMap)
                    .toList() as Iterable<Form15cBankBranchDataStruct?>)
                .withoutNulls
                .toList()
                .cast<Form15cBankBranchDataStruct>();
            safeSetState(() {});
            return;
          } else {
            return;
          }
        }),
        Future(() async {
          _model.uploadedFilesDataResponseVar =
              await GetUploadedFilesAPICallCall.call();

          if ((_model.uploadedFilesDataResponseVar?.succeeded ?? true)) {
            safeSetState(() {});
            return;
          } else {
            return;
          }
        }),
        Future(() async {
          _model.updateForm15cSubmitDataStruct(
            (e) => e..applPanTan = widget!.panNumber,
          );
          safeSetState(() {});
        }),
      ]);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 8.0),
              child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                model: _model.inputGenricHeadingTextModel,
                updateCallback: () => safeSetState(() {}),
                child: t_d_s_login_module_l1_input_vo62wv
                    .InputGenricHeadingTextWidget(
                  inputText: 'Preview & Download',
                  headingFontSize: 24.0,
                  headingTextColor: FlutterFlowTheme.of(context).textPrimary,
                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(
                          widget!.keyPrefix!,
                          'Form_15C_Preview_and_Download_Wrap',
                          'Input_Genric_HeadingText'),
                  dividerVisibility: false,
                  iconRequired: false,
                ),
              ),
            ),
            Divider(
              height: 1.0,
              thickness: 1.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 24.0),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'FORM NO. 15C',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).textBasic,
                                    fontSize: 20.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.bold,
                                    lineHeight: 1.5,
                                  ),
                            ),
                            Text(
                              '[See Rule 29B]',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).textBasic,
                                    fontSize: 16.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.bold,
                                    lineHeight: 1.5,
                                  ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Text(
                              'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                              textAlign: TextAlign.center,
                              style: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).textBasic,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                    lineHeight: 1.5,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              height: 1.0,
              thickness: 1.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Application Details',
                          style: FlutterFlowTheme.of(context)
                              .headlineMedium
                              .override(
                                fontFamily: 'Inter',
                                fontSize: 16.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.applicationDetailsEditButtonModel,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericHyperLinkButtonWithIconWidget(
                            label: 'Edit Details',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15C_Preview_and_Download_Wrap',
                                    'ApplicationDetailsEditButton'),
                            buttonDisable: false,
                            isIconRequired: Icon(
                              Icons.edit_outlined,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryInfo500Default,
                              size: 15.0,
                            ),
                            onTap: () async {
                              ScaffoldMessenger.of(context).clearSnackBars();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Modify',
                                    style: TextStyle(
                                      color: FlutterFlowTheme.of(context)
                                          .primaryText,
                                      fontSize: 20.0,
                                    ),
                                  ),
                                  duration: Duration(milliseconds: 4000),
                                  backgroundColor:
                                      FlutterFlowTheme.of(context).secondary,
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).primaryBGStroke2,
                          borderRadius: BorderRadius.circular(4.0),
                          border: Border.all(
                            color: FlutterFlowTheme.of(context).neutral300,
                            width: 1.0,
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              valueOrDefault<double>(
                                MediaQuery.sizeOf(context).width <=
                                        FFAppConstants.breakpointMedium
                                    ? 16.0
                                    : 24.0,
                                0.0,
                              ),
                              16.0,
                              valueOrDefault<double>(
                                MediaQuery.sizeOf(context).width <=
                                        FFAppConstants.breakpointMedium
                                    ? 16.0
                                    : 24.0,
                                0.0,
                              ),
                              16.0),
                          child: Wrap(
                            spacing: MediaQuery.sizeOf(context).width <=
                                    FFAppConstants.breakpointMedium
                                ? 16.0
                                : 24.0,
                            runSpacing: MediaQuery.sizeOf(context).width <=
                                    FFAppConstants.breakpointMedium
                                ? 20.0
                                : 24.0,
                            alignment: WrapAlignment.start,
                            crossAxisAlignment: WrapCrossAlignment.start,
                            direction: Axis.horizontal,
                            runAlignment: WrapAlignment.start,
                            verticalDirection: VerticalDirection.down,
                            clipBehavior: Clip.none,
                            children: [
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel1,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.submissionMode,
                                    labelText: 'Submission Mode',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.applicationType,
                                    labelText: 'Application Type',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel3,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model.previewDataCompState
                                        ?.residentialStatus,
                                    labelText: 'Residential Status',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel4,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.financialYear,
                                    labelText: 'Financial Year',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Basic Details',
                          style: FlutterFlowTheme.of(context)
                              .headlineMedium
                              .override(
                                fontFamily: 'Inter',
                                fontSize: 16.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.basicDetailsEditButtonModel,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericHyperLinkButtonWithIconWidget(
                            label: 'Edit Details',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15C_Preview_and_Download_Wrap',
                                    'BasicDetailsEditButton'),
                            buttonDisable: false,
                            isIconRequired: Icon(
                              Icons.edit_outlined,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryInfo500Default,
                              size: 15.0,
                            ),
                            onTap: () async {
                              await widget.onModifyBasicDetails?.call();
                            },
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).primaryBGStroke2,
                          borderRadius: BorderRadius.circular(4.0),
                          border: Border.all(
                            color: FlutterFlowTheme.of(context).neutral300,
                            width: 1.0,
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              valueOrDefault<double>(
                                MediaQuery.sizeOf(context).width <=
                                        FFAppConstants.breakpointMedium
                                    ? 16.0
                                    : 24.0,
                                0.0,
                              ),
                              16.0,
                              valueOrDefault<double>(
                                MediaQuery.sizeOf(context).width <=
                                        FFAppConstants.breakpointMedium
                                    ? 16.0
                                    : 24.0,
                                0.0,
                              ),
                              16.0),
                          child: Wrap(
                            spacing: MediaQuery.sizeOf(context).width <=
                                    FFAppConstants.breakpointMedium
                                ? 16.0
                                : 24.0,
                            runSpacing: MediaQuery.sizeOf(context).width <=
                                    FFAppConstants.breakpointMedium
                                ? 20.0
                                : 24.0,
                            alignment: WrapAlignment.start,
                            crossAxisAlignment: WrapCrossAlignment.start,
                            direction: Axis.horizontal,
                            runAlignment: WrapAlignment.start,
                            verticalDirection: VerticalDirection.down,
                            clipBehavior: Clip.none,
                            children: [
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel5,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: widget!.panNumber,
                                    labelText: 'Permanent Account Number',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel6,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model.previewDataCompState
                                        ?.natureOfBussiness,
                                    labelText: 'Nature of Business',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel7,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.bankingCompany,
                                    labelText: 'Name of Banking Company',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel8,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model.previewDataCompState
                                        ?.permanentEstablishment,
                                    labelText:
                                        'Permanent Establishment in India',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel9,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue:
                                        _model.previewDataCompState?.emailId,
                                    labelText: 'Email ID',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel10,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.mobileNumber
                                        ?.toString(),
                                    labelText: 'Mobile Number',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel11,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.alternateEmailId,
                                    labelText: 'Alternate Email ID',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel12,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model.previewDataCompState
                                        ?.alternatemobileNumber
                                        ?.toString(),
                                    labelText: 'Alternate Mobile Number',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel13,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue:
                                        _model.previewDataCompState?.state,
                                    labelText: 'State',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel14,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue:
                                        _model.previewDataCompState?.district,
                                    labelText: 'District',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 304.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel15,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue:
                                        _model.previewDataCompState?.headOffice,
                                    labelText:
                                        'Head office of the Applicant outside India ',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                              Container(
                                constraints: BoxConstraints(
                                  minWidth: 140.0,
                                  maxWidth: 440.0,
                                ),
                                decoration: BoxDecoration(),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model:
                                      _model.inputFieldGenericTextFieldModel16,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldGenericTextFieldWidget(
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'InputField_Generic_TextField'),
                                    isDisable: false,
                                    isMandatory: false,
                                    initialValue: _model
                                        .previewDataCompState?.numberOfBranch
                                        ?.toString(),
                                    labelText:
                                        'Number of Branch(es) in India through which operations are being carried out',
                                    isViewOnly: true,
                                    showExternalErrorMessage: false,
                                    onSubmitAction: () async {},
                                    onInputValueChangeCallback:
                                        (value) async {},
                                    onFocusChangeCallback: (hasFocus) async {},
                                    onInputValidationCallback:
                                        (isValid) async {},
                                    onTapLabelTrailingButton: () async {},
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: Container(
                        decoration: BoxDecoration(),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Text(
                                    'Details of Branch(es) in India through which operations are being carried out ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .textBasic,
                                      fontSize: 12.0,
                                      height: 1.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 12.0, 0.0, 0.0),
                              child: Container(
                                decoration: BoxDecoration(),
                                child: wrapWithModel(
                                  model: _model.branchDetailsDataTableModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: BranchDetailsDataTableWidget(
                                    tableMinWidth: 1008.0,
                                    tableMaxWidth: double.infinity,
                                    tableMaxHeight: 350.0,
                                    branchDetailsDataList:
                                        _model.bankBranchDataListCompState,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 24.0),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                      model: _model.naviationGenericFileUploadListModel,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NaviationGenericFileUploadListWidget(
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL2KeyValuePrefix(
                                widget!.keyPrefix!,
                                'Form_15C_Preview_and_Download_Wrap',
                                'Naviation_Generic_FileUploadList'),
                        fileInfo: functions.mapFileItem(
                            Form15cUploadedFileResponseStruct.maybeFromMap(
                                    (_model.uploadedFilesDataResponseVar
                                            ?.jsonBody ??
                                        ''))!
                                .files
                                .toList()),
                        onModifyAttachmentClickAction: () async {
                          await widget.onModifyUploadFile?.call();
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              height: 1.0,
              thickness: 1.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Declaration',
                          style: FlutterFlowTheme.of(context)
                              .headlineMedium
                              .override(
                                fontFamily: 'Inter',
                                fontSize: 16.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.declarationEditButtonModel,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericHyperLinkButtonWithIconWidget(
                            label: 'Edit Details',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15C_Preview_and_Download_Wrap',
                                    'DeclarationEditButton'),
                            buttonDisable: false,
                            isIconRequired: Icon(
                              Icons.edit_outlined,
                              color: FlutterFlowTheme.of(context)
                                  .secondaryInfo500Default,
                              size: 15.0,
                            ),
                            onTap: () async {
                              await widget.onModifyDeclaration?.call();
                            },
                          ),
                        ),
                      ],
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '1. ',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                      lineHeight: 1.5,
                                    ),
                              ),
                              Expanded(
                                child: Text(
                                  'It is hereby declared that, the assessee has been regularly assessed to income-tax in India and has furnished the returns of income for all assessment years for which such returns became due on or before the date on which the application under sub-rule (1) of Rule 29B is made.',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        letterSpacing: 0.0,
                                        lineHeight: 1.5,
                                      ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '2. ',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                      lineHeight: 1.5,
                                    ),
                              ),
                              Expanded(
                                child: Text(
                                  'It is hereby declared that, the assessee is not in default or deemed to be in default in respect of any tax (including advance tax and tax payable under Section 140A), interest, penalty, fine, or any other sum payable under the Act.',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        letterSpacing: 0.0,
                                        lineHeight: 1.5,
                                      ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '3. ',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                      lineHeight: 1.5,
                                    ),
                              ),
                              Expanded(
                                child: Text(
                                  'I, therefore, request that a certificate may be issued authorizing the said company/insurer to receive interest other than Interest on securities (other than interest payable on securities referred to in proviso to Section 193) and other sums not being dividends, without deduction of tax under sub-section (1) of Section 195 of the Income-tax Act, 1961, during the financial year ${_model.previewDataCompState?.financialYear}. I hereby declare that what is stated in this application is correct.  ',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        letterSpacing: 0.0,
                                        lineHeight: 1.5,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ]
                            .divide(SizedBox(height: 12.0))
                            .addToStart(SizedBox(height: 16.0))
                            .addToEnd(SizedBox(height: 16.0)),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).primaryBGStroke2,
                        borderRadius: BorderRadius.circular(4.0),
                        border: Border.all(
                          color: FlutterFlowTheme.of(context).neutral300,
                          width: 1.0,
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            valueOrDefault<double>(
                              MediaQuery.sizeOf(context).width <=
                                      FFAppConstants.breakpointMedium
                                  ? 16.0
                                  : 24.0,
                              0.0,
                            ),
                            16.0,
                            valueOrDefault<double>(
                              MediaQuery.sizeOf(context).width <=
                                      FFAppConstants.breakpointMedium
                                  ? 16.0
                                  : 24.0,
                              0.0,
                            ),
                            16.0),
                        child: Wrap(
                          spacing: MediaQuery.sizeOf(context).width <=
                                  FFAppConstants.breakpointMedium
                              ? 16.0
                              : 24.0,
                          runSpacing: MediaQuery.sizeOf(context).width <=
                                  FFAppConstants.breakpointMedium
                              ? 20.0
                              : 24.0,
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.start,
                          direction: Axis.horizontal,
                          runAlignment: WrapAlignment.start,
                          verticalDirection: VerticalDirection.down,
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              constraints: BoxConstraints(
                                minWidth: 140.0,
                                maxWidth: 304.0,
                              ),
                              decoration: BoxDecoration(),
                              child: t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model: _model.inputFieldGenericTextFieldModel17,
                                updateCallback: () => safeSetState(() {}),
                                updateOnChange: true,
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericTextFieldWidget(
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Preview_and_Download_Wrap',
                                          'InputField_Generic_TextField'),
                                  isDisable: false,
                                  isMandatory: false,
                                  initialValue:
                                      _model.previewDataCompState?.place,
                                  labelText: 'Place',
                                  isViewOnly: true,
                                  showExternalErrorMessage: false,
                                  onSubmitAction: () async {},
                                  onInputValueChangeCallback: (value) async {},
                                  onFocusChangeCallback: (hasFocus) async {},
                                  onInputValidationCallback: (isValid) async {},
                                  onTapLabelTrailingButton: () async {},
                                ),
                              ),
                            ),
                            Container(
                              constraints: BoxConstraints(
                                minWidth: 140.0,
                                maxWidth: 304.0,
                              ),
                              decoration: BoxDecoration(),
                              child: t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model: _model.inputFieldGenericTextFieldModel18,
                                updateCallback: () => safeSetState(() {}),
                                updateOnChange: true,
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericTextFieldWidget(
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Preview_and_Download_Wrap',
                                          'InputField_Generic_TextField'),
                                  isDisable: false,
                                  isMandatory: false,
                                  initialValue:
                                      _model.previewDataCompState?.date,
                                  labelText: 'Date',
                                  isViewOnly: true,
                                  showExternalErrorMessage: false,
                                  onSubmitAction: () async {},
                                  onInputValueChangeCallback: (value) async {},
                                  onFocusChangeCallback: (hasFocus) async {},
                                  onInputValidationCallback: (isValid) async {},
                                  onTapLabelTrailingButton: () async {},
                                ),
                              ),
                            ),
                            Container(
                              constraints: BoxConstraints(
                                minWidth: 140.0,
                                maxWidth: 304.0,
                              ),
                              decoration: BoxDecoration(),
                              child: t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model: _model.inputFieldGenericTextFieldModel19,
                                updateCallback: () => safeSetState(() {}),
                                updateOnChange: true,
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericTextFieldWidget(
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Preview_and_Download_Wrap',
                                          'InputField_Generic_TextField'),
                                  isDisable: false,
                                  isMandatory: false,
                                  initialValue:
                                      _model.previewDataCompState?.ipAddress,
                                  labelText: 'I.P. Address',
                                  isViewOnly: true,
                                  showExternalErrorMessage: false,
                                  onSubmitAction: () async {},
                                  onInputValueChangeCallback: (value) async {},
                                  onFocusChangeCallback: (hasFocus) async {},
                                  onInputValidationCallback: (isValid) async {},
                                  onTapLabelTrailingButton: () async {},
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(),
              child: Builder(
                builder: (context) {
                  if (MediaQuery.sizeOf(context).width >=
                      FFAppConstants.breakpointsmall) {
                    return Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 34.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              t_d_s_login_module_l1_navigation_3he2k0_util
                                  .wrapWithModel(
                                model: _model
                                    .navigationGenericSecondaryButtonModel1,
                                updateCallback: () => safeSetState(() {}),
                                child: t_d_s_login_module_l1_navigation_3he2k0
                                    .NavigationGenericSecondaryButtonWidget(
                                  labelText: 'Back',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Preview_and_Download_Wrap',
                                          'Navigation_Generic_Secondary_Button'),
                                  leftIcon: Icon(
                                    Icons.chevron_left,
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    size: 20.0,
                                  ),
                                  states:
                                      t_d_s_login_module_l1_navigation_3he2k0_enums
                                          .ButtonState.byDefault,
                                  onTap: () async {
                                    await widget.onBack?.call();
                                  },
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              t_d_s_login_module_l1_navigation_3he2k0_util
                                  .wrapWithModel(
                                model: _model
                                    .navigationGenericSecondaryButtonModel2,
                                updateCallback: () => safeSetState(() {}),
                                child: t_d_s_login_module_l1_navigation_3he2k0
                                    .NavigationGenericSecondaryButtonWidget(
                                  labelText: 'Download',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Preview_and_Download_Wrap',
                                          'Navigation_Generic_Secondary_Button'),
                                  leftIcon: Icon(
                                    Icons.file_download_outlined,
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    size: 20.0,
                                  ),
                                  states:
                                      t_d_s_login_module_l1_navigation_3he2k0_enums
                                          .ButtonState.byDefault,
                                  onTap: () async {
                                    await widget.onDownload?.call();
                                  },
                                ),
                              ),
                              t_d_s_login_module_l1_navigation_3he2k0_util
                                  .wrapWithModel(
                                model:
                                    _model.navigationGenericPrimaryButtonModel1,
                                updateCallback: () => safeSetState(() {}),
                                child: t_d_s_login_module_l1_navigation_3he2k0
                                    .NavigationGenericPrimaryButtonWidget(
                                  labeltext: 'Submit',
                                  rightIcon: Icon(
                                    Icons.chevron_right,
                                    color:
                                        FlutterFlowTheme.of(context).neutral100,
                                    size: 20.0,
                                  ),
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Preview_and_Download_Wrap',
                                          'Navigation_Generic_Primary_Button'),
                                  states:
                                      t_d_s_login_module_l1_navigation_3he2k0_enums
                                          .ButtonState.byDefault,
                                  onTap: () async {
                                    _model.form15cSubmitResponseVar =
                                        await SubmitFormFifteenCAPICallCall
                                            .call();

                                    await widget.onSubmit?.call();

                                    safeSetState(() {});
                                  },
                                ),
                              ),
                            ].divide(SizedBox(width: 16.0)),
                          ),
                        ],
                      ),
                    );
                  } else {
                    return Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model
                                      .navigationGenericPrimaryButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericPrimaryButtonWidget(
                                    labeltext: 'Submit',
                                    rightIcon: Icon(
                                      Icons.chevron_right,
                                      color: FlutterFlowTheme.of(context)
                                          .neutral100,
                                      size: 20.0,
                                    ),
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'Input_Genric_HeadingText'),
                                    states:
                                        t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.byDefault,
                                    onTap: () async {
                                      await widget.onSubmit?.call();
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model
                                      .navigationGenericSecondaryButtonModel3,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericSecondaryButtonWidget(
                                    labelText: 'Download',
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'Input_Genric_HeadingText'),
                                    leftIcon: Icon(
                                      Icons.file_download_outlined,
                                      color: FlutterFlowTheme.of(context)
                                          .primary600Default,
                                      size: 20.0,
                                    ),
                                    states:
                                        t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.byDefault,
                                    onTap: () async {
                                      await widget.onDownload?.call();
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model
                                      .navigationGenericSecondaryButtonModel4,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericSecondaryButtonWidget(
                                    labelText: 'Back',
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Preview_and_Download_Wrap',
                                            'Input_Genric_HeadingText'),
                                    leftIcon: Icon(
                                      Icons.chevron_left,
                                      color: FlutterFlowTheme.of(context)
                                          .primary600Default,
                                      size: 20.0,
                                    ),
                                    states:
                                        t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.byDefault,
                                    onTap: () async {
                                      await widget.onBack?.call();
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ].divide(SizedBox(height: 12.0)),
                      ),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
