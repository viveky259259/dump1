import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import 'form15_c_declaration_section_widget.dart'
    show Form15CDeclarationSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/inputfield_generic_checkboxwith_label/inputfield_generic_checkboxwith_label_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/registration_components/input_genric_heading_text/input_genric_heading_text_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CDeclarationSectionModel
    extends FlutterFlowModel<Form15CDeclarationSectionWidget> {
  ///  Local state fields for this component.

  DeclarationConsentsStruct? declarationConsentCompState;
  void updateDeclarationConsentCompStateStruct(
      Function(DeclarationConsentsStruct) updateFn) {
    updateFn(declarationConsentCompState ??= DeclarationConsentsStruct());
  }

  bool proceedEnabled = false;

  Form15cDeclarationDataStruct? declarationDataCompState;
  void updateDeclarationDataCompStateStruct(
      Function(Form15cDeclarationDataStruct) updateFn) {
    updateFn(declarationDataCompState ??= Form15cDeclarationDataStruct());
  }

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Backend Call - API (Get Declaration Data API Call)] action in Form_15C_Declaration_Section widget.
  ApiCallResponse? declarationDataResponseVar;
  // Model for Input_Genric_HeadingText component.
  late t_d_s_login_module_l1_input_vo62wv.InputGenricHeadingTextModel
      inputGenricHeadingTextModel1;
  // Model for firstConsent_d_Inputfield_Generic_CheckboxwithLabel.
  late t_d_s_login_module_l1_input_vo62wv
      .InputfieldGenericCheckboxwithLabelModel
      firstConsentDInputfieldGenericCheckboxwithLabelModel;
  // Model for secondConsent_d_Inputfield_Generic_CheckboxwithLabel.
  late t_d_s_login_module_l1_input_vo62wv
      .InputfieldGenericCheckboxwithLabelModel
      secondConsentDInputfieldGenericCheckboxwithLabelModel;
  // Model for thirdConsent_d_Inputfield_Generic_CheckboxwithLabel.
  late t_d_s_login_module_l1_input_vo62wv
      .InputfieldGenericCheckboxwithLabelModel
      thirdConsentDInputfieldGenericCheckboxwithLabelModel;
  // Model for Place_d_InputField_Generic_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      placeDInputFieldGenericTextFieldModel;
  // Model for Date_d_InputField_Generic_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      dateDInputFieldGenericTextFieldModel;
  // Model for IP_Address_d_InputField_Generic_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      iPAddressDInputFieldGenericTextFieldModel;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Stores action output result for [Backend Call - API (Declaration Proceed Button API Call)] action in Navigation_Generic_Primary_Button widget.
  ApiCallResponse? declarationProceedResponseVar;
  // Model for Input_Genric_HeadingText component.
  late t_d_s_login_module_l1_input_vo62wv.InputGenricHeadingTextModel
      inputGenricHeadingTextModel2;
  // Model for firstConsent_m_Inputfield_Generic_CheckboxwithLabel.
  late t_d_s_login_module_l1_input_vo62wv
      .InputfieldGenericCheckboxwithLabelModel
      firstConsentMInputfieldGenericCheckboxwithLabelModel;
  // Model for secondConsent_m_Inputfield_Generic_CheckboxwithLabel.
  late t_d_s_login_module_l1_input_vo62wv
      .InputfieldGenericCheckboxwithLabelModel
      secondConsentMInputfieldGenericCheckboxwithLabelModel;
  // Model for thirdConsent_m_Inputfield_Generic_CheckboxwithLabel.
  late t_d_s_login_module_l1_input_vo62wv
      .InputfieldGenericCheckboxwithLabelModel
      thirdConsentMInputfieldGenericCheckboxwithLabelModel;
  // Model for Place_m_InputField_Generic_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      placeMInputFieldGenericTextFieldModel;
  // Model for Date_m_InputField_Generic_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      dateMInputFieldGenericTextFieldModel;
  // Model for IP_Address_m_InputField_Generic_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      iPAddressMInputFieldGenericTextFieldModel;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;
  // Stores action output result for [Backend Call - API (Declaration Proceed Button API Call)] action in Navigation_Generic_Primary_Button widget.
  ApiCallResponse? declarationProceedResponseVar1;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;

  @override
  void initState(BuildContext context) {
    inputGenricHeadingTextModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputGenricHeadingTextModel());
    firstConsentDInputfieldGenericCheckboxwithLabelModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldGenericCheckboxwithLabelModel());
    secondConsentDInputfieldGenericCheckboxwithLabelModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldGenericCheckboxwithLabelModel());
    thirdConsentDInputfieldGenericCheckboxwithLabelModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldGenericCheckboxwithLabelModel());
    placeDInputFieldGenericTextFieldModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    dateDInputFieldGenericTextFieldModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    iPAddressDInputFieldGenericTextFieldModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    inputGenricHeadingTextModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputGenricHeadingTextModel());
    firstConsentMInputfieldGenericCheckboxwithLabelModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldGenericCheckboxwithLabelModel());
    secondConsentMInputfieldGenericCheckboxwithLabelModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldGenericCheckboxwithLabelModel());
    thirdConsentMInputfieldGenericCheckboxwithLabelModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldGenericCheckboxwithLabelModel());
    placeMInputFieldGenericTextFieldModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    dateMInputFieldGenericTextFieldModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    iPAddressMInputFieldGenericTextFieldModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    navigationGenericPrimaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
  }

  @override
  void dispose() {
    inputGenricHeadingTextModel1.dispose();
    firstConsentDInputfieldGenericCheckboxwithLabelModel.dispose();
    secondConsentDInputfieldGenericCheckboxwithLabelModel.dispose();
    thirdConsentDInputfieldGenericCheckboxwithLabelModel.dispose();
    placeDInputFieldGenericTextFieldModel.dispose();
    dateDInputFieldGenericTextFieldModel.dispose();
    iPAddressDInputFieldGenericTextFieldModel.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    inputGenricHeadingTextModel2.dispose();
    firstConsentMInputfieldGenericCheckboxwithLabelModel.dispose();
    secondConsentMInputfieldGenericCheckboxwithLabelModel.dispose();
    thirdConsentMInputfieldGenericCheckboxwithLabelModel.dispose();
    placeMInputFieldGenericTextFieldModel.dispose();
    dateMInputFieldGenericTextFieldModel.dispose();
    iPAddressMInputFieldGenericTextFieldModel.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
  }
}
