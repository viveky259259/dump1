import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/inputfield_generic_checkboxwith_label/inputfield_generic_checkboxwith_label_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/registration_components/input_genric_heading_text/input_genric_heading_text_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_declaration_section_model.dart';
export 'form15_c_declaration_section_model.dart';

class Form15CDeclarationSectionWidget extends StatefulWidget {
  const Form15CDeclarationSectionWidget({
    super.key,
    required this.keyPrefix,
    this.width,
    this.height,
    required this.backButtonAction,
    required this.proceedButtonAction,
  });

  final String? keyPrefix;
  final double? width;
  final double? height;
  final Future Function()? backButtonAction;
  final Future Function()? proceedButtonAction;

  @override
  State<Form15CDeclarationSectionWidget> createState() =>
      _Form15CDeclarationSectionWidgetState();
}

class _Form15CDeclarationSectionWidgetState
    extends State<Form15CDeclarationSectionWidget> {
  late Form15CDeclarationSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CDeclarationSectionModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.wait([
        Future(() async {
          _model.declarationDataResponseVar =
              await GetDeclarationDataAPICallCall.call(
            panNumber: 'ABCDE1234F',
          );

          if ((_model.declarationDataResponseVar?.succeeded ?? true)) {
            _model.declarationDataCompState =
                Form15cDeclarationDataResponseStruct.maybeFromMap(
                        (_model.declarationDataResponseVar?.jsonBody ?? ''))
                    ?.data
                    ?.firstOrNull;
            safeSetState(() {});
            return;
          } else {
            return;
          }
        }),
        Future(() async {
          _model.updateDeclarationConsentCompStateStruct(
            (e) => e
              ..firstConsentGiven = false
              ..secondConsentGiven = false
              ..thirdConsentGiven = false,
          );
          safeSetState(() {});
        }),
      ]);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Builder(
        builder: (context) {
          if (MediaQuery.sizeOf(context).width >
              FFAppConstants.breakpointMedium) {
            return Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 8.0),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.inputGenricHeadingTextModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputGenricHeadingTextWidget(
                              inputText: 'Declaration',
                              headingFontSize: 24.0,
                              headingTextColor:
                                  FlutterFlowTheme.of(context).textPrimary,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'Input_Genric_HeadingText'),
                              dividerVisibility: false,
                              iconRequired: false,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 18.0, 0.0, 0.0),
                        child: RichText(
                          textScaler: MediaQuery.of(context).textScaler,
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: '* ',
                                style: FlutterFlowTheme.of(context)
                                    .bodySmall
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .danger500Default,
                                      letterSpacing: 0.0,
                                      fontStyle: FontStyle.italic,
                                      lineHeight: 1.5,
                                    ),
                              ),
                              TextSpan(
                                text: 'Indicates mandatory fields',
                                style: FlutterFlowTheme.of(context)
                                    .bodySmall
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .neutral900,
                                      letterSpacing: 0.0,
                                      fontStyle: FontStyle.italic,
                                      lineHeight: 1.5,
                                    ),
                              )
                            ],
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(
                  height: 1.0,
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).neutral300,
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                            model: _model
                                .firstConsentDInputfieldGenericCheckboxwithLabelModel,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputfieldGenericCheckboxwithLabelWidget(
                              isMandatory: true,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'firstConsent_Inputfield_Generic_CheckboxwithLabel'),
                              checkBoxInitialValue: _model
                                  .declarationConsentCompState
                                  ?.firstConsentGiven,
                              labelText:
                                  'It is hereby declared that, the assessee has been regularly assessed to income-tax in India and has furnished the returns of income for all assessment years for which such returns became due on or before the date on which the application under sub-rule (1) of Rule 29B is made.',
                              checkBoxAction: () async {
                                _model.updateDeclarationConsentCompStateStruct(
                                  (e) => e
                                    ..firstConsentGiven = _model
                                        .firstConsentDInputfieldGenericCheckboxwithLabelModel
                                        .checkboxValue,
                                );
                                safeSetState(() {});
                                _model.proceedEnabled = _model
                                            .declarationConsentCompState!
                                            .firstConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .secondConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .thirdConsentGiven &&
                                        (_model.declarationDataCompState
                                                    ?.place !=
                                                null &&
                                            _model.declarationDataCompState
                                                    ?.place !=
                                                '')
                                    ? true
                                    : false;
                                safeSetState(() {});
                              },
                            ),
                          ),
                          t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                            model: _model
                                .secondConsentDInputfieldGenericCheckboxwithLabelModel,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputfieldGenericCheckboxwithLabelWidget(
                              isMandatory: true,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'secondConsent_Inputfield_Generic_CheckboxwithLabel'),
                              checkBoxInitialValue: _model
                                  .declarationConsentCompState
                                  ?.secondConsentGiven,
                              labelText:
                                  'It is hereby declared that, the assessee is not in default or deemed to be in default in respect of any tax (including advance tax and tax payable under Section 140A), interest, penalty, fine, or any other sum payable under the Act.',
                              checkBoxAction: () async {
                                _model.updateDeclarationConsentCompStateStruct(
                                  (e) => e
                                    ..secondConsentGiven = _model
                                        .secondConsentDInputfieldGenericCheckboxwithLabelModel
                                        .checkboxValue,
                                );
                                safeSetState(() {});
                                _model.proceedEnabled = _model
                                            .declarationConsentCompState!
                                            .firstConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .secondConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .thirdConsentGiven &&
                                        (_model.declarationDataCompState
                                                    ?.place !=
                                                null &&
                                            _model.declarationDataCompState
                                                    ?.place !=
                                                '')
                                    ? true
                                    : false;
                                safeSetState(() {});
                              },
                            ),
                          ),
                          t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                            model: _model
                                .thirdConsentDInputfieldGenericCheckboxwithLabelModel,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputfieldGenericCheckboxwithLabelWidget(
                              isMandatory: true,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'thirdConsent_Inputfield_Generic_CheckboxwithLabel'),
                              checkBoxInitialValue: _model
                                  .declarationConsentCompState
                                  ?.thirdConsentGiven,
                              labelText:
                                  'I, therefore, request that a certificate may be issued authorizing the said company/insurer to receive interest other than Interest on securities (other than interest payable on securities referred to in proviso to Section 193) and other sums not being dividends, without deduction of tax under sub-section (1) of Section 195 of the Income-tax Act, 1961, during the financial year 2024-25. I hereby declare that what is stated in this application is correct.',
                              checkBoxAction: () async {
                                _model.updateDeclarationConsentCompStateStruct(
                                  (e) => e
                                    ..thirdConsentGiven = _model
                                        .thirdConsentDInputfieldGenericCheckboxwithLabelModel
                                        .checkboxValue,
                                );
                                safeSetState(() {});
                                _model.proceedEnabled = _model
                                            .declarationConsentCompState!
                                            .firstConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .secondConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .thirdConsentGiven &&
                                        (_model.declarationDataCompState
                                                    ?.place !=
                                                null &&
                                            _model.declarationDataCompState
                                                    ?.place !=
                                                '')
                                    ? true
                                    : false;
                                safeSetState(() {});
                              },
                            ),
                          ),
                        ]
                            .divide(SizedBox(height: 16.0))
                            .addToStart(SizedBox(height: 24.0))
                            .addToEnd(SizedBox(height: 24.0)),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Wrap(
                          spacing: 24.0,
                          runSpacing: 24.0,
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.start,
                          direction: Axis.horizontal,
                          runAlignment: WrapAlignment.start,
                          verticalDirection: VerticalDirection.down,
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              constraints: BoxConstraints(
                                maxWidth: 320.0,
                              ),
                              decoration: BoxDecoration(),
                              child: t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model: _model
                                    .placeDInputFieldGenericTextFieldModel,
                                updateCallback: () => safeSetState(() {}),
                                updateOnChange: true,
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericTextFieldWidget(
                                  hintText: 'Enter Place',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Declaration_Section',
                                          'Place_InputField_Generic_TextField'),
                                  isDisable: false,
                                  isMandatory: true,
                                  initialValue:
                                      _model.declarationDataCompState?.place,
                                  labelText: 'Place',
                                  isViewOnly: false,
                                  showExternalErrorMessage: false,
                                  onSubmitAction: () async {},
                                  onInputValueChangeCallback: (value) async {
                                    _model.updateDeclarationDataCompStateStruct(
                                      (e) => e
                                        ..place = _model
                                            .placeDInputFieldGenericTextFieldModel
                                            .genericTextFieldTextController
                                            .text,
                                    );
                                    safeSetState(() {});
                                    _model.proceedEnabled = _model
                                                .declarationConsentCompState!
                                                .firstConsentGiven &&
                                            _model.declarationConsentCompState!
                                                .secondConsentGiven &&
                                            _model.declarationConsentCompState!
                                                .thirdConsentGiven &&
                                            (_model.declarationDataCompState
                                                        ?.place !=
                                                    null &&
                                                _model.declarationDataCompState
                                                        ?.place !=
                                                    '')
                                        ? true
                                        : false;
                                    safeSetState(() {});
                                  },
                                  onFocusChangeCallback: (hasFocus) async {},
                                  onInputValidationCallback: (isValid) async {},
                                  onTapLabelTrailingButton: () async {},
                                ),
                              ),
                            ),
                            Container(
                              constraints: BoxConstraints(
                                maxWidth: 320.0,
                              ),
                              decoration: BoxDecoration(),
                              child: t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model:
                                    _model.dateDInputFieldGenericTextFieldModel,
                                updateCallback: () => safeSetState(() {}),
                                updateOnChange: true,
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericTextFieldWidget(
                                  hintText: '',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Declaration_Section',
                                          'Date_InputField_Generic_TextField'),
                                  isDisable: true,
                                  isMandatory: false,
                                  initialValue:
                                      _model.declarationDataCompState?.date,
                                  labelText: 'Date',
                                  isViewOnly: false,
                                  showExternalErrorMessage: false,
                                  onSubmitAction: () async {},
                                  onInputValueChangeCallback: (value) async {},
                                  onFocusChangeCallback: (hasFocus) async {},
                                  onInputValidationCallback: (isValid) async {},
                                  onTapLabelTrailingButton: () async {},
                                ),
                              ),
                            ),
                            Container(
                              constraints: BoxConstraints(
                                maxWidth: 320.0,
                              ),
                              decoration: BoxDecoration(),
                              child: t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model: _model
                                    .iPAddressDInputFieldGenericTextFieldModel,
                                updateCallback: () => safeSetState(() {}),
                                updateOnChange: true,
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericTextFieldWidget(
                                  hintText: '',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form_15C_Declaration_Section',
                                          'IP_Address_InputField_Generic_TextField'),
                                  isDisable: true,
                                  isMandatory: false,
                                  initialValue: _model
                                      .declarationDataCompState?.ipAddress,
                                  labelText: 'I.P. Address',
                                  isViewOnly: false,
                                  showExternalErrorMessage: false,
                                  onSubmitAction: () async {},
                                  onInputValueChangeCallback: (value) async {},
                                  onFocusChangeCallback: (hasFocus) async {},
                                  onInputValidationCallback: (isValid) async {},
                                  onTapLabelTrailingButton: () async {},
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 40.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model:
                                _model.navigationGenericSecondaryButtonModel1,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericSecondaryButtonWidget(
                              labelText: 'Back',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'Navigation_Generic_Secondary_Button'),
                              leftIcon: Icon(
                                Icons.chevron_left,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 20.0,
                              ),
                              states:
                                  t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.byDefault,
                              onTap: () async {
                                await widget.backButtonAction?.call();
                              },
                            ),
                          ),
                          t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model: _model.navigationGenericPrimaryButtonModel1,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericPrimaryButtonWidget(
                              labeltext: 'Proceed',
                              rightIcon: Icon(
                                Icons.chevron_right,
                                color: FlutterFlowTheme.of(context).neutral100,
                                size: 20.0,
                              ),
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'Navigation_Generic_Primary_Button'),
                              states: _model.proceedEnabled
                                  ? t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.byDefault
                                  : t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.disabled,
                              onTap: () async {
                                _model.declarationProceedResponseVar =
                                    await DeclarationProceedButtonAPICallCall
                                        .call();

                                await widget.proceedButtonAction?.call();

                                safeSetState(() {});
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      valueOrDefault<String>(
                        Form15cDeclarationDataResponseStruct.maybeFromMap(
                                (_model.declarationDataResponseVar?.jsonBody ??
                                    ''))
                            ?.data
                            ?.firstOrNull
                            ?.ipAddress,
                        '1212',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            letterSpacing: 0.0,
                          ),
                    ),
                    Text(
                      valueOrDefault<String>(
                        _model.declarationDataCompState?.phoneNumber,
                        '1232',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ],
                ),
              ],
            );
          } else {
            return Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 8.0),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.inputGenricHeadingTextModel2,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputGenricHeadingTextWidget(
                              inputText: 'Declaration',
                              headingFontSize: 24.0,
                              headingTextColor:
                                  FlutterFlowTheme.of(context).textPrimary,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'Input_Genric_HeadingText'),
                              dividerVisibility: false,
                              iconRequired: false,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 18.0, 0.0, 0.0),
                        child: RichText(
                          textScaler: MediaQuery.of(context).textScaler,
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: '* ',
                                style: FlutterFlowTheme.of(context)
                                    .bodySmall
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .danger500Default,
                                      letterSpacing: 0.0,
                                      fontStyle: FontStyle.italic,
                                      lineHeight: 1.5,
                                    ),
                              ),
                              TextSpan(
                                text: 'Indicates mandatory fields',
                                style: FlutterFlowTheme.of(context)
                                    .bodySmall
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .neutral900,
                                      letterSpacing: 0.0,
                                      fontStyle: FontStyle.italic,
                                      lineHeight: 1.5,
                                    ),
                              )
                            ],
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(
                  height: 1.0,
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).neutral300,
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                            model: _model
                                .firstConsentMInputfieldGenericCheckboxwithLabelModel,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputfieldGenericCheckboxwithLabelWidget(
                              isMandatory: true,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'firstConsent_Inputfield_Generic_CheckboxwithLabel'),
                              checkBoxInitialValue: _model
                                  .declarationConsentCompState
                                  ?.firstConsentGiven,
                              labelText:
                                  'It is hereby declared that, the assessee has been regularly assessed to income-tax in India and has furnished the returns of income for all assessment years for which such returns became due on or before the date on which the application under sub-rule (1) of Rule 29B is made.',
                              checkBoxAction: () async {
                                _model.updateDeclarationConsentCompStateStruct(
                                  (e) => e
                                    ..firstConsentGiven = _model
                                        .firstConsentMInputfieldGenericCheckboxwithLabelModel
                                        .checkboxValue,
                                );
                                safeSetState(() {});
                                _model.proceedEnabled = _model
                                            .declarationConsentCompState!
                                            .firstConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .secondConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .thirdConsentGiven &&
                                        (_model.declarationDataCompState
                                                    ?.place !=
                                                null &&
                                            _model.declarationDataCompState
                                                    ?.place !=
                                                '')
                                    ? true
                                    : false;
                                safeSetState(() {});
                              },
                            ),
                          ),
                          t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                            model: _model
                                .secondConsentMInputfieldGenericCheckboxwithLabelModel,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputfieldGenericCheckboxwithLabelWidget(
                              isMandatory: true,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'secondConsent_Inputfield_Generic_CheckboxwithLabel'),
                              checkBoxInitialValue: _model
                                  .declarationConsentCompState
                                  ?.secondConsentGiven,
                              labelText:
                                  'It is hereby declared that, the assessee is not in default or deemed to be in default in respect of any tax (including advance tax and tax payable under Section 140A), interest, penalty, fine, or any other sum payable under the Act.',
                              checkBoxAction: () async {
                                _model.updateDeclarationConsentCompStateStruct(
                                  (e) => e
                                    ..secondConsentGiven = _model
                                        .secondConsentMInputfieldGenericCheckboxwithLabelModel
                                        .checkboxValue,
                                );
                                safeSetState(() {});
                                _model.proceedEnabled = _model
                                            .declarationConsentCompState!
                                            .firstConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .secondConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .thirdConsentGiven &&
                                        (_model.declarationDataCompState
                                                    ?.place !=
                                                null &&
                                            _model.declarationDataCompState
                                                    ?.place !=
                                                '')
                                    ? true
                                    : false;
                                safeSetState(() {});
                              },
                            ),
                          ),
                          t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                            model: _model
                                .thirdConsentMInputfieldGenericCheckboxwithLabelModel,
                            updateCallback: () => safeSetState(() {}),
                            updateOnChange: true,
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputfieldGenericCheckboxwithLabelWidget(
                              isMandatory: true,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15C_Declaration_Section',
                                      'thirdConsent_Inputfield_Generic_CheckboxwithLabel'),
                              checkBoxInitialValue: _model
                                  .declarationConsentCompState
                                  ?.thirdConsentGiven,
                              labelText:
                                  'I, therefore, request that a certificate may be issued authorizing the said company/insurer to receive interest other than Interest on securities (other than interest payable on securities referred to in proviso to Section 193) and other sums not being dividends, without deduction of tax under sub-section (1) of Section 195 of the Income-tax Act, 1961, during the financial year 2024-25. I hereby declare that what is stated in this application is correct.',
                              checkBoxAction: () async {
                                _model.updateDeclarationConsentCompStateStruct(
                                  (e) => e
                                    ..thirdConsentGiven = _model
                                        .thirdConsentMInputfieldGenericCheckboxwithLabelModel
                                        .checkboxValue,
                                );
                                safeSetState(() {});
                                _model.proceedEnabled = _model
                                            .declarationConsentCompState!
                                            .firstConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .secondConsentGiven &&
                                        _model.declarationConsentCompState!
                                            .thirdConsentGiven &&
                                        (_model.declarationDataCompState
                                                    ?.place !=
                                                null &&
                                            _model.declarationDataCompState
                                                    ?.place !=
                                                '')
                                    ? true
                                    : false;
                                safeSetState(() {});
                              },
                            ),
                          ),
                        ]
                            .divide(SizedBox(height: 16.0))
                            .addToStart(SizedBox(height: 24.0))
                            .addToEnd(SizedBox(height: 24.0)),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Wrap(
                          spacing: 24.0,
                          runSpacing: 24.0,
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.start,
                          direction: Axis.horizontal,
                          runAlignment: WrapAlignment.start,
                          verticalDirection: VerticalDirection.down,
                          clipBehavior: Clip.none,
                          children: [
                            t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model:
                                  _model.placeMInputFieldGenericTextFieldModel,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericTextFieldWidget(
                                hintText: 'Enter Place',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form_15C_Declaration_Section',
                                        'Place_InputField_Generic_TextField'),
                                isDisable: false,
                                isMandatory: true,
                                initialValue:
                                    _model.declarationDataCompState?.place,
                                labelText: 'Place',
                                isViewOnly: false,
                                showExternalErrorMessage: false,
                                onSubmitAction: () async {},
                                onInputValueChangeCallback: (value) async {
                                  _model.updateDeclarationDataCompStateStruct(
                                    (e) => e
                                      ..place = _model
                                          .placeMInputFieldGenericTextFieldModel
                                          .genericTextFieldTextController
                                          .text,
                                  );
                                  safeSetState(() {});
                                  _model.proceedEnabled = _model
                                              .declarationConsentCompState!
                                              .firstConsentGiven &&
                                          _model.declarationConsentCompState!
                                              .secondConsentGiven &&
                                          _model.declarationConsentCompState!
                                              .thirdConsentGiven &&
                                          (_model.declarationDataCompState
                                                      ?.place !=
                                                  null &&
                                              _model.declarationDataCompState
                                                      ?.place !=
                                                  '')
                                      ? true
                                      : false;
                                  safeSetState(() {});
                                },
                                onFocusChangeCallback: (hasFocus) async {},
                                onInputValidationCallback: (isValid) async {},
                                onTapLabelTrailingButton: () async {},
                              ),
                            ),
                            t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model:
                                  _model.dateMInputFieldGenericTextFieldModel,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericTextFieldWidget(
                                hintText: '',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form_15C_Declaration_Section',
                                        'Date_InputField_Generic_TextField'),
                                isDisable: true,
                                isMandatory: false,
                                initialValue:
                                    _model.declarationDataCompState?.date,
                                labelText: 'Date',
                                isViewOnly: false,
                                showExternalErrorMessage: false,
                                onSubmitAction: () async {},
                                onInputValueChangeCallback: (value) async {},
                                onFocusChangeCallback: (hasFocus) async {},
                                onInputValidationCallback: (isValid) async {},
                                onTapLabelTrailingButton: () async {},
                              ),
                            ),
                            t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model
                                  .iPAddressMInputFieldGenericTextFieldModel,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericTextFieldWidget(
                                hintText: '',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form_15C_Declaration_Section',
                                        'IP_Address_InputField_Generic_TextField'),
                                isDisable: true,
                                isMandatory: false,
                                initialValue:
                                    _model.declarationDataCompState?.ipAddress,
                                labelText: 'I.P. Address',
                                isViewOnly: false,
                                showExternalErrorMessage: false,
                                onSubmitAction: () async {},
                                onInputValueChangeCallback: (value) async {},
                                onFocusChangeCallback: (hasFocus) async {},
                                onInputValidationCallback: (isValid) async {},
                                onTapLabelTrailingButton: () async {},
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model
                                      .navigationGenericPrimaryButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericPrimaryButtonWidget(
                                    labeltext: 'Proceed',
                                    rightIcon: Icon(
                                      Icons.chevron_right,
                                      color: FlutterFlowTheme.of(context)
                                          .neutral100,
                                      size: 20.0,
                                    ),
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Declaration_Section',
                                            'Navigation_Generic_Primary_Button'),
                                    states: _model.proceedEnabled
                                        ? t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.byDefault
                                        : t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.disabled,
                                    onTap: () async {
                                      _model.declarationProceedResponseVar1 =
                                          await DeclarationProceedButtonAPICallCall
                                              .call();

                                      await widget.proceedButtonAction?.call();

                                      safeSetState(() {});
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model
                                      .navigationGenericSecondaryButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericSecondaryButtonWidget(
                                    labelText: 'Back',
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15C_Declaration_Section',
                                            'Navigation_Generic_Secondary_Button'),
                                    leftIcon: Icon(
                                      Icons.chevron_left,
                                      color: FlutterFlowTheme.of(context)
                                          .primary600Default,
                                      size: 20.0,
                                    ),
                                    states:
                                        t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.byDefault,
                                    onTap: () async {
                                      await widget.backButtonAction?.call();
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ].divide(SizedBox(height: 12.0)),
                      ),
                    ),
                  ],
                ),
              ],
            );
          }
        },
      ),
    );
  }
}
