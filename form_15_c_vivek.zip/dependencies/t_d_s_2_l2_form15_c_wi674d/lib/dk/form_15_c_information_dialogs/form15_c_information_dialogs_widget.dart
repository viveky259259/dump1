import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:styled_divider/styled_divider.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/components/alert_content_form15_c_traces_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_information_dialogs_model.dart';
export 'form15_c_information_dialogs_model.dart';

class Form15CInformationDialogsWidget extends StatefulWidget {
  const Form15CInformationDialogsWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<Form15CInformationDialogsWidget> createState() =>
      _Form15CInformationDialogsWidgetState();
}

class _Form15CInformationDialogsWidgetState
    extends State<Form15CInformationDialogsWidget> {
  late Form15CInformationDialogsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CInformationDialogsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: AlignmentDirectional(-1.0, -1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                  child: Text(
                    'What is Form 15C?',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).primary,
                          fontSize: 18.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ),
              StyledDivider(
                thickness: 1.0,
                indent: 24.0,
                endIndent: 10.0,
                color: FlutterFlowTheme.of(context).neutral300,
                lineStyle: DividerLineStyle.dotted,
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                child:
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                  model: _model.alertContentForm15CTracesModel,
                  updateCallback: () => safeSetState(() {}),
                  child: t_d_s_login_module_l1_navigation_3he2k0
                      .AlertContentForm15CTracesWidget(
                    bulletPoints: [
                      "This Form is relevant to a person concerned, which is a banking company or Insurer which is neither an Indian Company nor a company which has made the prescribed arrangements for the declaration and payment of dividends.",
                      "If such person concerned desires to receive any income by way of interest (other than Interest on securities) or any other sum (not being dividends) without deduction of tax at source under Section 195(1) of the Act, the person concerned must make an application in this Form to its Assessing Officer.",
                      "The person concerned making such an application must ensure that the conditions prescribed in clauses (i) and (ii) of Rule 29B(2) are fulfilled.",
                      "The Assessing officer will issue the certificate if he is satisfied that the relevant conditions prescribed in the Rule 29B(2) are fulfilled and the issue of any such certificate will not be prejudicial to the interests of revenue.",
                      "Certificate issued by Assessing Officer will be valid for the financial year specified therein. The person concerned can, however, make another application for a fresh certificate after the expiry of the period of validity of the earlier certificate or within three months before the expiry thereof."
                    ],
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(1.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(
                      0.0,
                      24.0,
                      valueOrDefault<double>(
                        MediaQuery.sizeOf(context).width < kBreakpointSmall
                            ? 0.0
                            : 24.0,
                        0.0,
                      ),
                      24.0),
                  child: Container(
                    width: MediaQuery.sizeOf(context).width < kBreakpointSmall
                        ? double.infinity
                        : null,
                    constraints: BoxConstraints(
                      maxWidth: double.infinity,
                    ),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: t_d_s_login_module_l1_navigation_3he2k0_util
                        .wrapWithModel(
                      model: _model.okButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NavigationGenericPrimaryButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                'Form_15_C_Information_Dialogs', 'Ok_Button')),
                        labeltext: 'Ok',
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                'Form_15_C_Information_Dialogs', 'Ok_Button'),
                        states: t_d_s_login_module_l1_navigation_3he2k0_enums
                            .ButtonState.selected,
                        onTap: () async {},
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
