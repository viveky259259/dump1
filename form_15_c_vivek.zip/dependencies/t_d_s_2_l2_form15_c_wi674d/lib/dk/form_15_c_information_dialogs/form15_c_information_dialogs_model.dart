import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'form15_c_information_dialogs_widget.dart'
    show Form15CInformationDialogsWidget;
import 'package:styled_divider/styled_divider.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/components/alert_content_form15_c_traces_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CInformationDialogsModel
    extends FlutterFlowModel<Form15CInformationDialogsWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for AlertContent_Form15C_Traces component.
  late t_d_s_login_module_l1_navigation_3he2k0.AlertContentForm15CTracesModel
      alertContentForm15CTracesModel;
  // Model for Ok_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel okButtonModel;

  @override
  void initState(BuildContext context) {
    alertContentForm15CTracesModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .AlertContentForm15CTracesModel());
    okButtonModel = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    alertContentForm15CTracesModel.dispose();
    okButtonModel.dispose();
  }
}
