import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'form15_c_form_section_widget.dart' show Form15CFormSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/website/presentation_alert_box_2/presentation_alert_box2_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_a_o_portal/navigation_generic_back_button/navigation_generic_back_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CFormSectionModel
    extends FlutterFlowModel<Form15CFormSectionWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Resident_Alert_Notification.
  late t_d_s_2_l1_presentation_0l6uwx.PresentationAlertBox2Model
      residentAlertNotificationModel;
  // Model for Residential_Status_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      residentialStatusDropdownModel;
  // Model for Submission_Mode_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      submissionModeDropdownModel;
  // Model for Application_Type_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      applicationTypeDropdownModel;
  // Model for Financial_Year_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      financialYearDropdownModel;
  // Model for Proceed_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel proceedButtonModel1;
  // Model for Back_Button.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationGenericBackButtonModel
      backButtonModel1;
  // Model for Back_Button.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationGenericBackButtonModel
      backButtonModel2;
  // Model for Proceed_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel proceedButtonModel2;

  @override
  void initState(BuildContext context) {
    residentAlertNotificationModel =
        t_d_s_2_l1_presentation_0l6uwx_util.createModel(context,
            () => t_d_s_2_l1_presentation_0l6uwx.PresentationAlertBox2Model());
    residentialStatusDropdownModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    submissionModeDropdownModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    applicationTypeDropdownModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    financialYearDropdownModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    proceedButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    backButtonModel1 = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericBackButtonModel());
    backButtonModel2 = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericBackButtonModel());
    proceedButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    residentAlertNotificationModel.dispose();
    residentialStatusDropdownModel.dispose();
    submissionModeDropdownModel.dispose();
    applicationTypeDropdownModel.dispose();
    financialYearDropdownModel.dispose();
    proceedButtonModel1.dispose();
    backButtonModel1.dispose();
    backButtonModel2.dispose();
    proceedButtonModel2.dispose();
  }
}
