import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/website/presentation_alert_box_2/presentation_alert_box2_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_a_o_portal/navigation_generic_back_button/navigation_generic_back_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_form_section_model.dart';
export 'form15_c_form_section_model.dart';

class Form15CFormSectionWidget extends StatefulWidget {
  const Form15CFormSectionWidget({
    super.key,
    required this.keyPrefix,
    required this.onProceed,
    required this.onBack,
  });

  final String? keyPrefix;
  final Future Function()? onProceed;
  final Future Function()? onBack;

  @override
  State<Form15CFormSectionWidget> createState() =>
      _Form15CFormSectionWidgetState();
}

class _Form15CFormSectionWidgetState extends State<Form15CFormSectionWidget> {
  late Form15CFormSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CFormSectionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: 407.0,
      ),
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
              ),
              child: Align(
                alignment: AlignmentDirectional(-1.0, 0.0),
                child: Text(
                  'Form 15C',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: Color(0xFF2A3A8D),
                        fontSize: 24.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ),
            Divider(
              thickness: 1.0,
              color: Color(0xFFDFE0E2),
            ),
            Container(
              decoration: BoxDecoration(),
              child: Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'Form_15C_Filling',
                        'form_description')),
                'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                maxLines: 4,
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).textBasic,
                      fontSize: 12.0,
                      letterSpacing: 0.0,
                    ),
              ),
            ),
            if ((_model.residentialStatusDropdownModel.dropDownValue ==
                    'Resident') ||
                (_model.residentialStatusDropdownModel.dropDownValue ==
                    'Non-Ordinarily Resident'))
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                child: t_d_s_2_l1_presentation_0l6uwx_util.wrapWithModel(
                  model: _model.residentAlertNotificationModel,
                  updateCallback: () => safeSetState(() {}),
                  child: t_d_s_2_l1_presentation_0l6uwx
                      .PresentationAlertBox2Widget(
                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                        .generateL2KeyValuePrefix(widget!.keyPrefix!,
                            'Form_15C_Filling', 'Presentation_AlertBox_2')),
                    hintText1: 'Alert : ',
                    hintText2:
                        'The form is applicable to Non-Resident taxpayers only. Please make sure the residential status selected in My Profile is correct.',
                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                        .generateL2KeyValuePrefix(widget!.keyPrefix!,
                            'Form_15C_Filling', 'Resident_Alert_Notification'),
                    status: t_d_s_2_l1_presentation_0l6uwx_enums.Status.error,
                  ),
                ),
              ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                model: _model.residentialStatusDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: t_d_s_login_module_l1_input_vo62wv
                    .InputFieldGenericDropdownWidget(
                  key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(
                          widget!.keyPrefix!,
                          'Form_15_C_Form_Section',
                          'Residential_Status_Dropdown')),
                  hintText: 'Non-Resident',
                  initialOption: '',
                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(
                          widget!.keyPrefix!,
                          'Form_15_C_Form_Section',
                          'Residential_Status_Dropdown'),
                  isDropdownDisable: false,
                  showErrorMessage: false,
                  labelText: 'Residential Status',
                  isMandatory: false,
                  dropDownList: FFAppConstants.ResidentialStatus,
                  onDropDownSelection: (selectedVlaue) async {},
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                model: _model.submissionModeDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: t_d_s_login_module_l1_input_vo62wv
                    .InputFieldGenericDropdownWidget(
                  key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(
                          widget!.keyPrefix!,
                          'Form_15_C_Form_Section',
                          'Submission_Mode_Dropdown')),
                  hintText: 'Online',
                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(widget!.keyPrefix!,
                          'Form_15_C_Form_Section', 'Submission_Mode_Dropdown'),
                  isDropdownDisable: false,
                  showErrorMessage: false,
                  labelText: 'Submission Mode',
                  isMandatory: false,
                  dropDownList: ["Online", "Offline"],
                  onDropDownSelection: (selectedVlaue) async {},
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                model: _model.applicationTypeDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: t_d_s_login_module_l1_input_vo62wv
                    .InputFieldGenericDropdownWidget(
                  key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(
                          widget!.keyPrefix!,
                          'Form_15_C_Form_Section',
                          'Application_Type_Dropdown')),
                  hintText: 'Original',
                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(
                          widget!.keyPrefix!,
                          'Form_15_C_Form_Section',
                          'Application_Type_Dropdown'),
                  isDropdownDisable: false,
                  showErrorMessage: false,
                  labelText: 'Application Type',
                  isMandatory: false,
                  dropDownList: ["Original"],
                  onDropDownSelection: (selectedVlaue) async {},
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                model: _model.financialYearDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: t_d_s_login_module_l1_input_vo62wv
                    .InputFieldGenericDropdownWidget(
                  hintText: '2024-25',
                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                      .generateL2KeyValuePrefix(widget!.keyPrefix!,
                          'Form_15_C_Form_Section', 'Financial_Year_Dropdown'),
                  isDropdownDisable: false,
                  showErrorMessage: false,
                  labelText: 'Financial Year',
                  isMandatory: true,
                  dropDownList: ["2024-25", "2025-26", "2026-27", "2027-28"],
                  onDropDownSelection: (selectedVlaue) async {},
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(
                  0.0,
                  valueOrDefault<double>(
                    MediaQuery.sizeOf(context).width < kBreakpointSmall
                        ? 24.0
                        : 40.0,
                    0.0,
                  ),
                  0.0,
                  0.0),
              child: Builder(
                builder: (context) {
                  if (MediaQuery.sizeOf(context).width <=
                      FFAppConstants.breakpointsmall) {
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(),
                          child: t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model: _model.proceedButtonModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericPrimaryButtonWidget(
                              labeltext: 'Proceed',
                              rightIcon: Icon(
                                Icons.navigate_next_rounded,
                              ),
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15_C_Form_Section',
                                      'Proceed_Button'),
                              states: (_model.residentialStatusDropdownModel
                                                  .dropDownValue ==
                                              null ||
                                          _model.residentialStatusDropdownModel
                                                  .dropDownValue ==
                                              '') ||
                                      (_model.submissionModeDropdownModel.dropDownValue == null ||
                                          _model.submissionModeDropdownModel
                                                  .dropDownValue ==
                                              '') ||
                                      (_model.applicationTypeDropdownModel.dropDownValue == null ||
                                          _model.applicationTypeDropdownModel
                                                  .dropDownValue ==
                                              '') ||
                                      (_model.financialYearDropdownModel.dropDownValue ==
                                              null ||
                                          _model.financialYearDropdownModel
                                                  .dropDownValue ==
                                              '')
                                  ? t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.disabled
                                  : t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.byDefault,
                              onTap: () async {
                                await widget.onProceed?.call();
                              },
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await widget.onBack?.call();
                            },
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.backButtonModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .NavigationGenericBackButtonWidget(
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form_15_C_Form_Section',
                                        'Back_Button'),
                                onTapAction: () async {},
                              ),
                            ),
                          ),
                        ),
                      ].divide(SizedBox(height: 12.0)),
                    );
                  } else {
                    return Container(
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  await widget.onBack?.call();
                                },
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model.backButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericBackButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL2KeyValuePrefix(
                                                widget!.keyPrefix!,
                                                'Form_15_C_Form_Section',
                                                'Back_Button')),
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15_C_Form_Section',
                                            'Back_Button'),
                                    onTapAction: () async {},
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  await widget.onProceed?.call();
                                },
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model.proceedButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericPrimaryButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL2KeyValuePrefix(
                                                widget!.keyPrefix!,
                                                'Form_15_C_Form_Section',
                                                'Proceed_Button')),
                                    labeltext: 'Proceed',
                                    rightIcon: Icon(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL2KeyValuePrefix(
                                                  widget!.keyPrefix!,
                                                  'Form_15_C_Form_Section',
                                                  'Proceed_Button')),
                                      Icons.navigate_next_rounded,
                                    ),
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form_15_C_Form_Section',
                                            'Proceed_Button'),
                                    states:
                                        (_model.residentialStatusDropdownModel
                                                            .dropDownValue ==
                                                        null ||
                                                    _model
                                                            .residentialStatusDropdownModel
                                                            .dropDownValue ==
                                                        '') ||
                                                (_model.submissionModeDropdownModel.dropDownValue == null ||
                                                    _model
                                                            .submissionModeDropdownModel
                                                            .dropDownValue ==
                                                        '') ||
                                                (_model.applicationTypeDropdownModel
                                                            .dropDownValue ==
                                                        null ||
                                                    _model.applicationTypeDropdownModel
                                                            .dropDownValue ==
                                                        '') ||
                                                (_model.financialYearDropdownModel
                                                            .dropDownValue ==
                                                        null ||
                                                    _model
                                                            .financialYearDropdownModel
                                                            .dropDownValue ==
                                                        '')
                                            ? t_d_s_login_module_l1_navigation_3he2k0_enums
                                                .ButtonState.disabled
                                            : t_d_s_login_module_l1_navigation_3he2k0_enums
                                                .ButtonState.byDefault,
                                    onTap: () async {},
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ].divide(SizedBox(width: 16.0)),
                      ),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
