import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'form15_c_basic_details_widget.dart' show Form15CBasicDetailsWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/website/presentation_alert_box_2/presentation_alert_box2_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/not_in_used/input_email_field/input_email_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/not_in_used/input_field_generic_text_field_with_label/input_field_generic_text_field_with_label_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/not_in_used/input_field_p_a_n_field/input_field_p_a_n_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/specific_components/input_field_mobile/input_field_mobile_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_a_o_portal/navigation_generic_back_button/navigation_generic_back_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_hyper_link_button_with_icon/navigation_generic_hyper_link_button_with_icon_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CBasicDetailsModel
    extends FlutterFlowModel<Form15CBasicDetailsWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Information_Alert.
  late t_d_s_2_l1_presentation_0l6uwx.PresentationAlertBox2Model
      informationAlertModel1;
  // Model for PANField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldPANFieldModel
      pANFieldModel1;
  // Model for NatureofBusiness_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      natureofBusinessDropdownModel1;
  // Model for EstablishmentinIndia_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      establishmentinIndiaDropdownModel1;
  // Model for NameofApplicant.
  late t_d_s_login_module_l1_input_vo62wv
      .InputFieldGenericTextFieldWithLabelModel nameofApplicantModel1;
  // Model for InputField_Mobile component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel
      inputFieldMobileModel1;
  // Model for EmailField.
  late t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel emailFieldModel1;
  // Model for Input_AlternateEmailField.
  late t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel
      inputAlternateEmailFieldModel1;
  // Model for InputField_AlternateMobile.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel
      inputFieldAlternateMobileModel1;
  // Model for District_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      districtTextFieldModel1;
  // Model for State_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      stateTextFieldModel1;
  // Model for NoOfBranch_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      noOfBranchTextFieldModel1;
  // Model for HeadOffice_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      headOfficeDropdownModel1;
  // Model for Add_Update_Branch_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericHyperLinkButtonWithIconModel
      addUpdateBranchButtonModel1;
  // Model for Back_Button.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationGenericBackButtonModel
      backButtonModel1;
  // Model for Save_Proceed_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel saveProceedButtonModel1;
  // Model for Information_Alert.
  late t_d_s_2_l1_presentation_0l6uwx.PresentationAlertBox2Model
      informationAlertModel2;
  // Model for PANField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldPANFieldModel
      pANFieldModel2;
  // Model for NatureofBusiness_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      natureofBusinessDropdownModel2;
  // Model for NameofApplicant.
  late t_d_s_login_module_l1_input_vo62wv
      .InputFieldGenericTextFieldWithLabelModel nameofApplicantModel2;
  // Model for EstablishmentinIndia_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      establishmentinIndiaDropdownModel2;
  // Model for EmailField.
  late t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel emailFieldModel2;
  // Model for InputField_Mobile component.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel
      inputFieldMobileModel2;
  // Model for Input_AlternateEmailField.
  late t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel
      inputAlternateEmailFieldModel2;
  // Model for InputField_AlternateMobile.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel
      inputFieldAlternateMobileModel2;
  // Model for State_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      stateTextFieldModel2;
  // Model for District_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      districtTextFieldModel2;
  // Model for HeadOffice_Dropdown.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      headOfficeDropdownModel2;
  // Model for NoOfBranch_TextField.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      noOfBranchTextFieldModel2;
  // Model for Add_Update_Branch_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericHyperLinkButtonWithIconModel
      addUpdateBranchButtonModel2;
  // Model for Back_Button.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationGenericBackButtonModel
      backButtonModel2;
  // Model for Save_Proceed_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel saveProceedButtonModel2;

  @override
  void initState(BuildContext context) {
    informationAlertModel1 = t_d_s_2_l1_presentation_0l6uwx_util.createModel(
        context,
        () => t_d_s_2_l1_presentation_0l6uwx.PresentationAlertBox2Model());
    pANFieldModel1 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv.InputFieldPANFieldModel());
    natureofBusinessDropdownModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    establishmentinIndiaDropdownModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    nameofApplicantModel1 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldWithLabelModel());
    inputFieldMobileModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(context,
            () => t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel());
    emailFieldModel1 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel());
    inputAlternateEmailFieldModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(context,
            () => t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel());
    inputFieldAlternateMobileModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(context,
            () => t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel());
    districtTextFieldModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    stateTextFieldModel1 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    noOfBranchTextFieldModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    headOfficeDropdownModel1 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    addUpdateBranchButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericHyperLinkButtonWithIconModel());
    backButtonModel1 = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericBackButtonModel());
    saveProceedButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    informationAlertModel2 = t_d_s_2_l1_presentation_0l6uwx_util.createModel(
        context,
        () => t_d_s_2_l1_presentation_0l6uwx.PresentationAlertBox2Model());
    pANFieldModel2 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv.InputFieldPANFieldModel());
    natureofBusinessDropdownModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    nameofApplicantModel2 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldWithLabelModel());
    establishmentinIndiaDropdownModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    emailFieldModel2 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel());
    inputFieldMobileModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(context,
            () => t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel());
    inputAlternateEmailFieldModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(context,
            () => t_d_s_login_module_l1_input_vo62wv.InputEmailFieldModel());
    inputFieldAlternateMobileModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(context,
            () => t_d_s_login_module_l1_input_vo62wv.InputFieldMobileModel());
    stateTextFieldModel2 = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    districtTextFieldModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    headOfficeDropdownModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    noOfBranchTextFieldModel2 =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    addUpdateBranchButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericHyperLinkButtonWithIconModel());
    backButtonModel2 = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericBackButtonModel());
    saveProceedButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    informationAlertModel1.dispose();
    pANFieldModel1.dispose();
    natureofBusinessDropdownModel1.dispose();
    establishmentinIndiaDropdownModel1.dispose();
    nameofApplicantModel1.dispose();
    inputFieldMobileModel1.dispose();
    emailFieldModel1.dispose();
    inputAlternateEmailFieldModel1.dispose();
    inputFieldAlternateMobileModel1.dispose();
    districtTextFieldModel1.dispose();
    stateTextFieldModel1.dispose();
    noOfBranchTextFieldModel1.dispose();
    headOfficeDropdownModel1.dispose();
    addUpdateBranchButtonModel1.dispose();
    backButtonModel1.dispose();
    saveProceedButtonModel1.dispose();
    informationAlertModel2.dispose();
    pANFieldModel2.dispose();
    natureofBusinessDropdownModel2.dispose();
    nameofApplicantModel2.dispose();
    establishmentinIndiaDropdownModel2.dispose();
    emailFieldModel2.dispose();
    inputFieldMobileModel2.dispose();
    inputAlternateEmailFieldModel2.dispose();
    inputFieldAlternateMobileModel2.dispose();
    stateTextFieldModel2.dispose();
    districtTextFieldModel2.dispose();
    headOfficeDropdownModel2.dispose();
    noOfBranchTextFieldModel2.dispose();
    addUpdateBranchButtonModel2.dispose();
    backButtonModel2.dispose();
    saveProceedButtonModel2.dispose();
  }
}
