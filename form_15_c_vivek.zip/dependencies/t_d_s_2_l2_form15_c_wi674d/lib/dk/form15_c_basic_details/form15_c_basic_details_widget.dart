import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_2_l1_presentation_0l6uwx/website/presentation_alert_box_2/presentation_alert_box2_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/not_in_used/input_email_field/input_email_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/not_in_used/input_field_generic_text_field_with_label/input_field_generic_text_field_with_label_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/not_in_used/input_field_p_a_n_field/input_field_p_a_n_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/specific_components/input_field_mobile/input_field_mobile_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_a_o_portal/navigation_generic_back_button/navigation_generic_back_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_hyper_link_button_with_icon/navigation_generic_hyper_link_button_with_icon_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_basic_details_model.dart';
export 'form15_c_basic_details_model.dart';

class Form15CBasicDetailsWidget extends StatefulWidget {
  const Form15CBasicDetailsWidget({
    super.key,
    required this.keyPrefix,
    required this.onSave,
    required this.onBack,
  });

  final String? keyPrefix;

  /// Action callback when save and proceed is called.
  final Future Function()? onSave;

  /// Action callback when back button is tapped
  final Future Function()? onBack;

  @override
  State<Form15CBasicDetailsWidget> createState() =>
      _Form15CBasicDetailsWidgetState();
}

class _Form15CBasicDetailsWidgetState extends State<Form15CBasicDetailsWidget> {
  late Form15CBasicDetailsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CBasicDetailsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Builder(
        builder: (context) {
          if (MediaQuery.sizeOf(context).width >
              FFAppConstants.breakpointMedium) {
            return Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 48.0, 0.0),
                      child: Text(
                        'Basic Details ',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textPrimary,
                              fontSize: 24.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                    RichText(
                      textScaler: MediaQuery.of(context).textScaler,
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '*',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context)
                                      .danger500Default,
                                  letterSpacing: 0.0,
                                ),
                          ),
                          TextSpan(
                            text: ' Indicates mandatory fields',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color:
                                      FlutterFlowTheme.of(context).neutral900,
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          )
                        ],
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ],
                ),
                Divider(
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).neutral300,
                ),
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 48.0, 0.0),
                  child: t_d_s_2_l1_presentation_0l6uwx_util.wrapWithModel(
                    model: _model.informationAlertModel1,
                    updateCallback: () => safeSetState(() {}),
                    child: t_d_s_2_l1_presentation_0l6uwx
                        .PresentationAlertBox2Widget(
                      hintText1: '',
                      hintText2:
                          '1.Jurisdictional A.O will be assigned on the basis of State & District furnished by Taxpayer in Form 15C.\n2.Please make sure the count of branches as provided in \"Number of Branch(es) in India through which operations are being carried out\" matches the details as provided in \"Details of Branch(es)/ Office(s) in India through which operations are being carried out\". \n3.Details are pre-filled as available in ‘My Profile’. If you wish to update details, please Click here',
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix('Form15C_BasicDetails',
                              'Form15C_BasicDetails', 'Information_Alert'),
                      status: t_d_s_2_l1_presentation_0l6uwx_enums
                          .Status.information,
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Wrap(
                      spacing: 0.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 0.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.pANFieldModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldPANFieldWidget(
                                validationRegex: '[A-Z]{5}[0-9]{4}[A-Z]{1}',
                                errorText: 'Invalid PAN ',
                                width: 407.0,
                                isReadOnly: false,
                                initialValue: 'PDES03028F',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'PANField'),
                                labelText: 'Permanent Account Number',
                                hintText: 'Permanent Account Number',
                                isMandatory: false,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 0.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.natureofBusinessDropdownModel1,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericDropdownWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'NatureofBusiness_Dropdown')),
                                hintText: 'Select',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'NatureofBusiness_Dropdown'),
                                isDropdownDisable: false,
                                showErrorMessage: false,
                                labelText: 'Nature of Business',
                                isMandatory: true,
                                dropDownList: ['Banking Company', 'Insurer'],
                                onDropDownSelection: (selectedVlaue) async {},
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 48.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.establishmentinIndiaDropdownModel1,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericDropdownWidget(
                                hintText: 'Yes',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'EstablishmentinIndia_Dropdown'),
                                isDropdownDisable: false,
                                showErrorMessage: false,
                                labelText: 'Permanent Establishment in India ',
                                isMandatory: true,
                                dropDownList: ['Yes', 'No'],
                                onDropDownSelection: (selectedVlaue) async {},
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 0.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.nameofApplicantModel1,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericTextFieldWithLabelWidget(
                                labelText: 'Name of Applicant',
                                hintText: 'HSBC Bank',
                                isMandatory: false,
                                width: 492.0,
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'NameofApplicant'),
                                isMandatoryErrorText: false,
                                isReadOnly: false,
                                shouldObscureText: false,
                                textFieldAction: () async {},
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 0.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.inputFieldMobileModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldMobileWidget(
                                labelText: 'Mobile Number',
                                hintTextInputField: '9999900000',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'InputField_Mobile'),
                                listDropDown: ['91', '68'],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 0.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.emailFieldModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputEmailFieldWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'EmailField')),
                                isReadOnly: false,
                                isMandatory: false,
                                labelText: 'Email ID',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'EmailField'),
                                hintText: 'abc@gmail.com',
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 0.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.inputAlternateEmailFieldModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputEmailFieldWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'Input_AlternateEmailField')),
                                isReadOnly: false,
                                isMandatory: false,
                                labelText: 'Alternate Email ID',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'Input_AlternateEmailField'),
                                hintText: 'xyz@mail.in',
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.inputFieldAlternateMobileModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldMobileWidget(
                                labelText: 'Alternate Mobile Number',
                                hintTextInputField: '9999911111',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'InputField_AlternateMobile'),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.districtTextFieldModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericTextFieldWidget(
                                hintText: 'Nanded',
                                keyPrefix: 'key',
                                isDisable: true,
                                isMandatory: false,
                                labelText: 'District',
                                isViewOnly: false,
                                showExternalErrorMessage: false,
                                onSubmitAction: () async {},
                                onInputValueChangeCallback: (value) async {},
                                onFocusChangeCallback: (hasFocus) async {},
                                onInputValidationCallback: (isValid) async {},
                                onTapLabelTrailingButton: () async {},
                              ),
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 320.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.stateTextFieldModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              hintText: 'Maharashtra',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form15C_BasicDetails',
                                      'State_TextField'),
                              isDisable: true,
                              isMandatory: false,
                              labelText: 'State',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 24.0, 0.0),
                            child: t_d_s_login_module_l1_input_vo62wv_util
                                .wrapWithModel(
                              model: _model.noOfBranchTextFieldModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_input_vo62wv
                                  .InputFieldGenericTextFieldWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'NoOfBranch_TextField')),
                                hintText: 'Enter no. of branches',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'NoOfBranch_TextField'),
                                isDisable: true,
                                isMandatory: true,
                                labelText:
                                    'Number of Branch(es) in India through which operations are being carried out',
                                isViewOnly: false,
                                showExternalErrorMessage: false,
                                onSubmitAction: () async {},
                                onInputValueChangeCallback: (value) async {},
                                onFocusChangeCallback: (hasFocus) async {},
                                onInputValidationCallback: (isValid) async {},
                                onTapLabelTrailingButton: () async {},
                              ),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.headOfficeDropdownModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDropdownWidget(
                              hintText: 'Select Country',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form15C_Basic_Details',
                                      'HeadOffice_Dropdown'),
                              isDropdownDisable: false,
                              showErrorMessage: false,
                              labelText:
                                  'Head office of the Applicant outside India ',
                              isMandatory: false,
                              dropDownList: ['Banking Company', 'Insurer'],
                              onDropDownSelection: (selectedVlaue) async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 48.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 48.0, 0.0),
                            child: RichText(
                              textScaler: MediaQuery.of(context).textScaler,
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text:
                                        'Details of Branch(es)/ Office(s) in India through which operations are being carried out',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  TextSpan(
                                    text: ' *',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .danger500Default,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                        ),
                                  )
                                ],
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await widget.onSave?.call();
                            },
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.addUpdateBranchButtonModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .NavigationGenericHyperLinkButtonWithIconWidget(
                                label: 'Add/Update Branch',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'Add_Update_Branch_Button'),
                                buttonDisable: false,
                                onTap: () async {},
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 40.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          height: 52.0,
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).primaryBGStroke5,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Country',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'State',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'District',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Flat/Door/Building',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Road/Street/Block/Sector',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Pincode',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Post Office',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Area/Localty',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 21.0, 0.0, 21.0),
                              child: Text(
                                'No Branch Added',
                                textAlign: TextAlign.center,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      fontSize: 12.0,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(24.0, 40.0, 48.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onSave?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.backButtonModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericBackButtonWidget(
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                    'Form15C_BasicDetails', 'Back_Button'),
                            onTapAction: () async {},
                          ),
                        ),
                      ),
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onSave?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.saveProceedButtonModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericPrimaryButtonWidget(
                            labeltext: 'Save & Proceed',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form15C_BasicDetails',
                                    'Save_Proceed_Button'),
                            states:
                                t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.selected,
                            onTap: () async {},
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          } else {
            return Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 48.0, 0.0),
                      child: Text(
                        'Basic Details ',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textPrimary,
                              fontSize: 24.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                    RichText(
                      textScaler: MediaQuery.of(context).textScaler,
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '*',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context)
                                      .danger500Default,
                                  letterSpacing: 0.0,
                                ),
                          ),
                          TextSpan(
                            text: ' Indicates mandatory fields',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color:
                                      FlutterFlowTheme.of(context).neutral900,
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          )
                        ],
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ],
                ),
                Divider(
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).neutral300,
                ),
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 48.0, 0.0),
                  child: t_d_s_2_l1_presentation_0l6uwx_util.wrapWithModel(
                    model: _model.informationAlertModel2,
                    updateCallback: () => safeSetState(() {}),
                    child: t_d_s_2_l1_presentation_0l6uwx
                        .PresentationAlertBox2Widget(
                      hintText1: '',
                      hintText2:
                          '1.Jurisdictional A.O will be assigned on the basis of State & District furnished by Taxpayer in Form 15C.\n2.Please make sure the count of branches as provided in \"Number of Branch(es) in India through which operations are being carried out\" matches the details as provided in \"Details of Branch(es)/ Office(s) in India through which operations are being carried out\". \n3.Details are pre-filled as available in ‘My Profile’. If you wish to update details, please Click here',
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix('Form15C_BasicDetails',
                              'Form15C_BasicDetails', 'Information_Alert'),
                      status: t_d_s_2_l1_presentation_0l6uwx_enums
                          .Status.information,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Wrap(
                      spacing: 0.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          decoration: BoxDecoration(),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    24.0, 0.0, 0.0, 0.0),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model: _model.pANFieldModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputFieldPANFieldWidget(
                                    validationRegex: '[A-Z]{5}[0-9]{4}[A-Z]{1}',
                                    errorText: 'Invalid PAN ',
                                    width: 492.0,
                                    isReadOnly: false,
                                    initialValue: 'PDES03028F',
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Form15C_BasicDetails',
                                            'PANField'),
                                    labelText: 'Permanent Account Number',
                                    hintText: 'Permanent Account Number',
                                    isMandatory: false,
                                  ),
                                ),
                              ),
                              t_d_s_login_module_l1_input_vo62wv_util
                                  .wrapWithModel(
                                model: _model.natureofBusinessDropdownModel2,
                                updateCallback: () => safeSetState(() {}),
                                child: t_d_s_login_module_l1_input_vo62wv
                                    .InputFieldGenericDropdownWidget(
                                  hintText: 'Select',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Form15C_BasicDetails',
                                          'NatureofBusiness_Dropdown'),
                                  isDropdownDisable: false,
                                  showErrorMessage: false,
                                  labelText: 'Nature of Business',
                                  isMandatory: true,
                                  dropDownList: ['Banking Company', 'Insurer'],
                                  onDropDownSelection: (selectedVlaue) async {},
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 24.0, 0.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 0.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.nameofApplicantModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      updateOnChange: true,
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldGenericTextFieldWithLabelWidget(
                                        labelText: 'Name of Applicant',
                                        hintText: 'HSBC Bank',
                                        isMandatory: false,
                                        width: 492.0,
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'NameofApplicant'),
                                        isMandatoryErrorText: false,
                                        isReadOnly: false,
                                        shouldObscureText: false,
                                        textFieldAction: () async {},
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 48.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model
                                          .establishmentinIndiaDropdownModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      updateOnChange: true,
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldGenericDropdownWidget(
                                        hintText: 'Yes',
                                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL2KeyValuePrefix(
                                                widget!.keyPrefix!,
                                                'Form15C_BasicDetails',
                                                'EstablishmentinIndia_Dropdown'),
                                        isDropdownDisable: false,
                                        showErrorMessage: false,
                                        labelText:
                                            'Permanent Establishment in India ',
                                        isMandatory: true,
                                        dropDownList: ['Yes', 'No'],
                                        onDropDownSelection:
                                            (selectedVlaue) async {},
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 24.0, 0.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 0.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.emailFieldModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputEmailFieldWidget(
                                        width: 492.0,
                                        isReadOnly: false,
                                        initialVlaue: 'abc@gmail.com',
                                        isMandatory: false,
                                        labelText: 'Email ID',
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'EmailField'),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 0.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.inputFieldMobileModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldMobileWidget(
                                        labelText: 'Mobile Number',
                                        hintTextInputField: '9999900000',
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'InputField_Mobile'),
                                        listDropDown: ['91', '68'],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 24.0, 0.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 0.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model:
                                          _model.inputAlternateEmailFieldModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputEmailFieldWidget(
                                        width: 492.0,
                                        isReadOnly: false,
                                        initialVlaue: 'abc@gmail.com',
                                        isMandatory: false,
                                        labelText: 'Alternate Email ID',
                                        keyPrefix: 'key',
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 24.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model
                                          .inputFieldAlternateMobileModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldMobileWidget(
                                        labelText: 'Alternate Mobile Number',
                                        hintTextInputField: '9999911111',
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'InputField_AlternateMobile'),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 24.0, 0.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 0.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.stateTextFieldModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldGenericTextFieldWidget(
                                        hintText: 'Maharashtra',
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'State_TextField'),
                                        isDisable: true,
                                        isMandatory: false,
                                        labelText: 'State',
                                        isViewOnly: false,
                                        showExternalErrorMessage: false,
                                        onSubmitAction: () async {},
                                        onInputValueChangeCallback:
                                            (value) async {},
                                        onFocusChangeCallback:
                                            (hasFocus) async {},
                                        onInputValidationCallback:
                                            (isValid) async {},
                                        onTapLabelTrailingButton: () async {},
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 24.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.districtTextFieldModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldGenericTextFieldWidget(
                                        hintText: 'Nanded',
                                        keyPrefix: 'key',
                                        isDisable: true,
                                        isMandatory: false,
                                        labelText: 'District',
                                        isViewOnly: false,
                                        showExternalErrorMessage: false,
                                        onSubmitAction: () async {},
                                        onInputValueChangeCallback:
                                            (value) async {},
                                        onFocusChangeCallback:
                                            (hasFocus) async {},
                                        onInputValidationCallback:
                                            (isValid) async {},
                                        onTapLabelTrailingButton: () async {},
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 24.0, 0.0, 0.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 0.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.headOfficeDropdownModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      updateOnChange: true,
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldGenericDropdownWidget(
                                        hintText: 'Select Country',
                                        keyPrefix: 'key',
                                        isDropdownDisable: false,
                                        showErrorMessage: false,
                                        labelText:
                                            'Head office of the Applicant outside India ',
                                        isMandatory: false,
                                        dropDownList: [
                                          'Banking Company',
                                          'Insurer'
                                        ],
                                        onDropDownSelection:
                                            (selectedVlaue) async {},
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 0.0, 24.0, 0.0),
                                    child:
                                        t_d_s_login_module_l1_input_vo62wv_util
                                            .wrapWithModel(
                                      model: _model.noOfBranchTextFieldModel2,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_input_vo62wv
                                          .InputFieldGenericTextFieldWidget(
                                        key: ValueKey(
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'NoOfBranch_TextField')),
                                        hintText: 'Enter no. of branches',
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Form15C_BasicDetails',
                                                    'NoOfBranch_TextField'),
                                        isDisable: true,
                                        isMandatory: true,
                                        labelText:
                                            'Number of Branch(es) in India through which operations are being carried out',
                                        isViewOnly: false,
                                        showExternalErrorMessage: false,
                                        onSubmitAction: () async {},
                                        onInputValueChangeCallback:
                                            (value) async {},
                                        onFocusChangeCallback:
                                            (hasFocus) async {},
                                        onInputValidationCallback:
                                            (isValid) async {},
                                        onTapLabelTrailingButton: () async {},
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 48.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 48.0, 0.0),
                            child: RichText(
                              textScaler: MediaQuery.of(context).textScaler,
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text:
                                        'Details of Branch(es)/ Office(s) in India through which operations are being carried out',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  TextSpan(
                                    text: ' *',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .danger500Default,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                        ),
                                  )
                                ],
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ),
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await widget.onSave?.call();
                            },
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.addUpdateBranchButtonModel2,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .NavigationGenericHyperLinkButtonWithIconWidget(
                                label: 'Add/Update Branch',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL2KeyValuePrefix(
                                        widget!.keyPrefix!,
                                        'Form15C_BasicDetails',
                                        'Add_Update_Branch_Button'),
                                buttonDisable: false,
                                onTap: () async {},
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 40.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          height: 52.0,
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).primaryBGStroke5,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Country',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'State',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'District',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Flat/Door/Building',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Road/Street/Block/Sector',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Pincode',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Post Office',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    25.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Text(
                                    'Area/Localty',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textBasic,
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 21.0, 0.0, 21.0),
                              child: Text(
                                'No Branch Added',
                                textAlign: TextAlign.center,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      fontSize: 12.0,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(24.0, 40.0, 48.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onSave?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.backButtonModel2,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericBackButtonWidget(
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                    'Form15C_BasicDetails', 'Back_Button'),
                            onTapAction: () async {},
                          ),
                        ),
                      ),
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onSave?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.saveProceedButtonModel2,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericPrimaryButtonWidget(
                            labeltext: 'Save & Proceed',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form15C_BasicDetails',
                                    'Save_Proceed_Button'),
                            states:
                                t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.selected,
                            onTap: () async {},
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }
        },
      ),
    );
  }
}
