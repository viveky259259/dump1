import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'things_to_know_for_filling_form15_c_model.dart';
export 'things_to_know_for_filling_form15_c_model.dart';

class ThingsToKnowForFillingForm15CWidget extends StatefulWidget {
  const ThingsToKnowForFillingForm15CWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<ThingsToKnowForFillingForm15CWidget> createState() =>
      _ThingsToKnowForFillingForm15CWidgetState();
}

class _ThingsToKnowForFillingForm15CWidgetState
    extends State<ThingsToKnowForFillingForm15CWidget> {
  late ThingsToKnowForFillingForm15CModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ThingsToKnowForFillingForm15CModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 0.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Align(
              alignment: AlignmentDirectional(-1.0, -1.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 0.0, 0.0),
                child: Text(
                  'Things to know for filing form 15C',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).primary,
                        fontSize: 18.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ),
            Divider(
              thickness: 1.0,
              indent: 24.0,
              endIndent: 10.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Builder(
              builder: (context) {
                final thingsToKnowDynamicList =
                    FFAppConstants.ThingsToKnowForFillingForm15C.toList();

                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(thingsToKnowDynamicList.length,
                      (thingsToKnowDynamicListIndex) {
                    final thingsToKnowDynamicListItem =
                        thingsToKnowDynamicList[thingsToKnowDynamicListIndex];
                    return Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 0.0, 0.0),
                      child: Text(
                        '${(thingsToKnowDynamicListIndex + 1).toString()}. ${thingsToKnowDynamicListItem}',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).neutral900,
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                      ),
                    );
                  }),
                );
              },
            ),
            Builder(
              builder: (context) {
                if (MediaQuery.sizeOf(context).width <= kBreakpointSmall
                    ? true
                    : false) {
                  return Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                    child: Container(
                      width: 838.0,
                      height: 64.0,
                      decoration: BoxDecoration(
                        color:
                            FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 12.0, 0.0, 16.0),
                              child:
                                  t_d_s_login_module_l1_navigation_3he2k0_util
                                      .wrapWithModel(
                                model: _model.okPrimaryButtonModel1,
                                updateCallback: () => safeSetState(() {}),
                                child: t_d_s_login_module_l1_navigation_3he2k0
                                    .NavigationGenericPrimaryButtonWidget(
                                  key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Things_to_know_for_filling_form_15C',
                                          'Ok_Primary_Button')),
                                  labeltext: 'Ok',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL2KeyValuePrefix(
                                          widget!.keyPrefix!,
                                          'Things_to_know_for_filling_form_15C',
                                          'Ok_Primary_Button'),
                                  states:
                                      t_d_s_login_module_l1_navigation_3he2k0_enums
                                          .ButtonState.selected,
                                  onTap: () async {},
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                } else {
                  return Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                    child: Container(
                      width: 838.0,
                      height: 64.0,
                      decoration: BoxDecoration(
                        color:
                            FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Align(
                              alignment: AlignmentDirectional(1.0, 0.0),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 12.0, 34.0, 16.0),
                                child:
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                  model: _model.okPrimaryButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_navigation_3he2k0
                                      .NavigationGenericPrimaryButtonWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Things_to_know_for_filling_form_15C',
                                            'Ok_Primary_Button')),
                                    labeltext: 'Ok',
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Things_to_know_for_filling_form_15C',
                                            'Ok_Primary_Button'),
                                    states:
                                        t_d_s_login_module_l1_navigation_3he2k0_enums
                                            .ButtonState.selected,
                                    onTap: () async {},
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
