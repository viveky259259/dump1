import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'things_to_know_for_filling_form15_c_widget.dart'
    show ThingsToKnowForFillingForm15CWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ThingsToKnowForFillingForm15CModel
    extends FlutterFlowModel<ThingsToKnowForFillingForm15CWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Ok_Primary_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel okPrimaryButtonModel1;
  // Model for Ok_Primary_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel okPrimaryButtonModel2;

  @override
  void initState(BuildContext context) {
    okPrimaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    okPrimaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    okPrimaryButtonModel1.dispose();
    okPrimaryButtonModel2.dispose();
  }
}
