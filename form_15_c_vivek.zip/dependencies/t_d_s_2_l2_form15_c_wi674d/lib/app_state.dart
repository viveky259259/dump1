import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:ff_commons/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<
      t_d_s_login_module_l1_input_vo62wv_data_schema
      .RegisterTypeRadioButtonSchemaStruct> _optionList = [
    t_d_s_login_module_l1_input_vo62wv_data_schema
            .RegisterTypeRadioButtonSchemaStruct
        .fromSerializableMap(jsonDecode(
            '{\"option\":\"Digital Signature Certificate (DSC)\",\"IconName\":\"signature\"}')),
    t_d_s_login_module_l1_input_vo62wv_data_schema
            .RegisterTypeRadioButtonSchemaStruct
        .fromSerializableMap(jsonDecode(
            '{\"option\":\"Registered Mobile OTP Verification\",\"IconName\":\"mobile_friendly\"}')),
    t_d_s_login_module_l1_input_vo62wv_data_schema
            .RegisterTypeRadioButtonSchemaStruct
        .fromSerializableMap(jsonDecode(
            '{\"option\":\"Aadhaar OTP Verification\",\"IconName\":\"fingerprint\"}')),
    t_d_s_login_module_l1_input_vo62wv_data_schema
            .RegisterTypeRadioButtonSchemaStruct
        .fromSerializableMap(jsonDecode(
            '{\"option\":\"e-verification through Netbanking\",\"IconName\":\"account_balance\"}'))
  ];
  List<
      t_d_s_login_module_l1_input_vo62wv_data_schema
      .RegisterTypeRadioButtonSchemaStruct> get optionList => _optionList;
  set optionList(
      List<
              t_d_s_login_module_l1_input_vo62wv_data_schema
              .RegisterTypeRadioButtonSchemaStruct>
          value) {
    _optionList = value;
  }

  void addToOptionList(
      t_d_s_login_module_l1_input_vo62wv_data_schema
          .RegisterTypeRadioButtonSchemaStruct
          value) {
    optionList.add(value);
  }

  void removeFromOptionList(
      t_d_s_login_module_l1_input_vo62wv_data_schema
          .RegisterTypeRadioButtonSchemaStruct
          value) {
    optionList.remove(value);
  }

  void removeAtIndexFromOptionList(int index) {
    optionList.removeAt(index);
  }

  void updateOptionListAtIndex(
    int index,
    t_d_s_login_module_l1_input_vo62wv_data_schema.RegisterTypeRadioButtonSchemaStruct Function(
            t_d_s_login_module_l1_input_vo62wv_data_schema
                .RegisterTypeRadioButtonSchemaStruct)
        updateFn,
  ) {
    optionList[index] = updateFn(_optionList[index]);
  }

  void insertAtIndexInOptionList(
      int index,
      t_d_s_login_module_l1_input_vo62wv_data_schema
          .RegisterTypeRadioButtonSchemaStruct
          value) {
    optionList.insert(index, value);
  }

  DeclarationConsentsStruct _declarationDetailsAppState =
      DeclarationConsentsStruct.fromSerializableMap(jsonDecode(
          '{\"place\":\"New York\",\"date\":\"12/10/2023\",\"ip_address\":\"1.11.111.1\",\"secondConsentGiven\":\"true\"}'));
  DeclarationConsentsStruct get declarationDetailsAppState =>
      _declarationDetailsAppState;
  set declarationDetailsAppState(DeclarationConsentsStruct value) {
    _declarationDetailsAppState = value;
  }

  void updateDeclarationDetailsAppStateStruct(
      Function(DeclarationConsentsStruct) updateFn) {
    updateFn(_declarationDetailsAppState);
  }

  ApplicationDetailsStruct _appDetailsAppState =
      ApplicationDetailsStruct.fromSerializableMap(jsonDecode(
          '{\"submission_mode\":\"Online\",\"application_type\":\"Original\",\"residential_status\":\"Non-Resident\",\"financial_year\":\"2024-25\"}'));
  ApplicationDetailsStruct get appDetailsAppState => _appDetailsAppState;
  set appDetailsAppState(ApplicationDetailsStruct value) {
    _appDetailsAppState = value;
  }

  void updateAppDetailsAppStateStruct(
      Function(ApplicationDetailsStruct) updateFn) {
    updateFn(_appDetailsAppState);
  }

  BasicDetailsStruct _basicDetailsAppDetails =
      BasicDetailsStruct.fromSerializableMap(jsonDecode(
          '{\"PAN_number\":\"PDES03028F\",\"nature_of_business\":\"Insurer\",\"name_of_banking_company\":\"HSBC Bank\",\"permanent_establishment_in_india\":\"Yes\",\"emailID\":\"abc@gamil.com\",\"mob_no\":\"+913883488385\",\"alt_emailID\":\"xyz@gamil.com\",\"alt_mob_no\":\"+9188495495\",\"state\":\"Maharastra\",\"district\":\"Nanded\",\"head_office_of_aplplicant_outside_india\":\"New York\",\"no_of_branches\":\"5\"}'));
  BasicDetailsStruct get basicDetailsAppDetails => _basicDetailsAppDetails;
  set basicDetailsAppDetails(BasicDetailsStruct value) {
    _basicDetailsAppDetails = value;
  }

  void updateBasicDetailsAppDetailsStruct(
      Function(BasicDetailsStruct) updateFn) {
    updateFn(_basicDetailsAppDetails);
  }

  List<t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct>
      _branchDetailsAppState = [
    t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct
        .fromSerializableMap(jsonDecode(
            '{\"Sno\":\"0\",\"Country\":\"Hello World\",\"State\":\"Hello World\",\"District\":\"Hello World\",\"Flat\":\"Hello World\",\"Road\":\"Hello World\",\"PinCode\":\"0\",\"PostOffice\":\"Hello World\",\"Area\":\"Hello World\"}')),
    t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct
        .fromSerializableMap(jsonDecode(
            '{\"Sno\":\"0\",\"Country\":\"Hello World\",\"State\":\"Hello World\",\"District\":\"Hello World\",\"Flat\":\"Hello World\",\"Road\":\"Hello World\",\"PinCode\":\"0\",\"PostOffice\":\"Hello World\",\"Area\":\"Hello World\"}')),
    t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct
        .fromSerializableMap(jsonDecode(
            '{\"Sno\":\"0\",\"Country\":\"Hello World\",\"State\":\"Hello World\",\"District\":\"Hello World\",\"Flat\":\"Hello World\",\"Road\":\"Hello World\",\"PinCode\":\"0\",\"PostOffice\":\"Hello World\",\"Area\":\"Hello World\"}')),
    t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct
        .fromSerializableMap(jsonDecode(
            '{\"Sno\":\"0\",\"Country\":\"Hello World\",\"State\":\"Hello World\",\"District\":\"Hello World\",\"Flat\":\"Hello World\",\"Road\":\"Hello World\",\"PinCode\":\"0\",\"PostOffice\":\"Hello World\",\"Area\":\"Hello World\"}'))
  ];
  List<t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct>
      get branchDetailsAppState => _branchDetailsAppState;
  set branchDetailsAppState(
      List<t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct>
          value) {
    _branchDetailsAppState = value;
  }

  void addToBranchDetailsAppState(
      t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct value) {
    branchDetailsAppState.add(value);
  }

  void removeFromBranchDetailsAppState(
      t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct value) {
    branchDetailsAppState.remove(value);
  }

  void removeAtIndexFromBranchDetailsAppState(int index) {
    branchDetailsAppState.removeAt(index);
  }

  void updateBranchDetailsAppStateAtIndex(
    int index,
    t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct Function(
            t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct)
        updateFn,
  ) {
    branchDetailsAppState[index] = updateFn(_branchDetailsAppState[index]);
  }

  void insertAtIndexInBranchDetailsAppState(int index,
      t_d_s_2_l1_presentation_0l6uwx_data_schema.Form15BranchDataStruct value) {
    branchDetailsAppState.insert(index, value);
  }

  List<t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct>
      _uploadedFileList = [
    t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct
        .fromSerializableMap(jsonDecode(
            '{\"heading\":\"Return of Income in paper form\",\"fileDetails\":\"[\\\"{\\\\\\\"fileName\\\\\\\":\\\\\\\"file1.pdf\\\\\\\",\\\\\\\"fileUrl\\\\\\\":\\\\\\\"https://www.google.com/\\\\\\\"}\\\",\\\"{\\\\\\\"fileName\\\\\\\":\\\\\\\"file2.pdf\\\\\\\",\\\\\\\"fileUrl\\\\\\\":\\\\\\\"https://www.google.com/\\\\\\\"}\\\",\\\"{\\\\\\\"fileName\\\\\\\":\\\\\\\"file3.pdf\\\\\\\",\\\\\\\"fileUrl\\\\\\\":\\\\\\\"https://www.google.com/\\\\\\\"}\\\",\\\"{\\\\\\\"fileName\\\\\\\":\\\\\\\"file4.pdf\\\\\\\",\\\\\\\"fileUrl\\\\\\\":\\\\\\\"https://www.google.com/\\\\\\\"}\\\"]\"}')),
    t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct
        .fromSerializableMap(jsonDecode(
            '{\"heading\":\"Supporting documents\",\"fileDetails\":\"[\\\"{\\\\\\\"fileName\\\\\\\":\\\\\\\"file1.pdf\\\\\\\",\\\\\\\"fileUrl\\\\\\\":\\\\\\\"https://www.google.com/\\\\\\\"}\\\",\\\"{\\\\\\\"fileName\\\\\\\":\\\\\\\"file2.pdf\\\\\\\",\\\\\\\"fileUrl\\\\\\\":\\\\\\\"https://www.google.com/\\\\\\\"}\\\"]\"}'))
  ];
  List<t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct>
      get uploadedFileList => _uploadedFileList;
  set uploadedFileList(
      List<
              t_d_s_login_module_l1_navigation_3he2k0_data_schema
              .FileUploadInfoStruct>
          value) {
    _uploadedFileList = value;
  }

  void addToUploadedFileList(
      t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct
          value) {
    uploadedFileList.add(value);
  }

  void removeFromUploadedFileList(
      t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct
          value) {
    uploadedFileList.remove(value);
  }

  void removeAtIndexFromUploadedFileList(int index) {
    uploadedFileList.removeAt(index);
  }

  void updateUploadedFileListAtIndex(
    int index,
    t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct Function(
            t_d_s_login_module_l1_navigation_3he2k0_data_schema
                .FileUploadInfoStruct)
        updateFn,
  ) {
    uploadedFileList[index] = updateFn(_uploadedFileList[index]);
  }

  void insertAtIndexInUploadedFileList(
      int index,
      t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct
          value) {
    uploadedFileList.insert(index, value);
  }

  PreviewDownloadDataStruct _previewDownloadDataAppState =
      PreviewDownloadDataStruct.fromSerializableMap(jsonDecode(
          '{\"submisstionMode\":\"Online\",\"applicationType\":\"Original\",\"residentialStatus\":\"Non-Resident\",\"financialYear\":\"2025-26\",\"panNumber\":\"GHIJK1234L\",\"natureOfBusiness\":\"Insurer\",\"banking_company_name\":\"HSBC Bank\",\"permanent_establishement\":\"Yes\",\"emailID\":\"abc@gamil.com\",\"mobNumber\":\"8893434905\",\"alternateEmailID\":\"xyz@gmail.com\",\"alternateMobNumber\":\"53543425\",\"state\":\"Maharastra\",\"district\":\"Nanded\",\"headOffice\":\"New York\",\"numberOfBranches\":\"6\",\"status\":\"completed\",\"place\":\"New Delhi\",\"date\":\"21/08/2015\",\"ip_address\":\"1.12.2.1.2\"}'));
  PreviewDownloadDataStruct get previewDownloadDataAppState =>
      _previewDownloadDataAppState;
  set previewDownloadDataAppState(PreviewDownloadDataStruct value) {
    _previewDownloadDataAppState = value;
  }

  void updatePreviewDownloadDataAppStateStruct(
      Function(PreviewDownloadDataStruct) updateFn) {
    updateFn(_previewDownloadDataAppState);
  }

  List<Form15cBankBranchDataStruct> _newBankBranchDataList = [
    Form15cBankBranchDataStruct.fromSerializableMap(jsonDecode(
        '{\"id\":\"0\",\"panNumber\":\"Hello World\",\"country\":\"Hello World\",\"flat\":\"Hello World\",\"block\":\"Hello World\",\"pincode\":\"Hello World\",\"postoffice\":\"Hello World\",\"areaLocality\":\"Hello World\",\"district\":\"Hello World\",\"state\":\"Hello World\"}')),
    Form15cBankBranchDataStruct.fromSerializableMap(jsonDecode(
        '{\"id\":\"0\",\"panNumber\":\"Hello World\",\"country\":\"Hello World\",\"flat\":\"Hello World\",\"block\":\"Hello World\",\"pincode\":\"Hello World\",\"postoffice\":\"Hello World\",\"areaLocality\":\"Hello World\",\"district\":\"Hello World\",\"state\":\"Hello World\"}')),
    Form15cBankBranchDataStruct.fromSerializableMap(jsonDecode(
        '{\"id\":\"0\",\"panNumber\":\"Hello World\",\"country\":\"Hello World\",\"flat\":\"Hello World\",\"block\":\"Hello World\",\"pincode\":\"Hello World\",\"postoffice\":\"Hello World\",\"areaLocality\":\"Hello World\",\"district\":\"Hello World\",\"state\":\"Hello World\"}')),
    Form15cBankBranchDataStruct.fromSerializableMap(jsonDecode(
        '{\"id\":\"0\",\"panNumber\":\"Hello World\",\"country\":\"Hello World\",\"flat\":\"Hello World\",\"block\":\"Hello World\",\"pincode\":\"Hello World\",\"postoffice\":\"Hello World\",\"areaLocality\":\"Hello World\",\"district\":\"Hello World\",\"state\":\"Hello World\"}')),
    Form15cBankBranchDataStruct.fromSerializableMap(jsonDecode(
        '{\"id\":\"0\",\"panNumber\":\"Hello World\",\"country\":\"Hello World\",\"flat\":\"Hello World\",\"block\":\"Hello World\",\"pincode\":\"Hello World\",\"postoffice\":\"Hello World\",\"areaLocality\":\"Hello World\",\"district\":\"Hello World\",\"state\":\"Hello World\"}')),
    Form15cBankBranchDataStruct.fromSerializableMap(jsonDecode(
        '{\"id\":\"0\",\"panNumber\":\"Hello World\",\"country\":\"Hello World\",\"flat\":\"Hello World\",\"block\":\"Hello World\",\"pincode\":\"Hello World\",\"postoffice\":\"Hello World\",\"areaLocality\":\"Hello World\",\"district\":\"Hello World\",\"state\":\"Hello World\"}'))
  ];
  List<Form15cBankBranchDataStruct> get newBankBranchDataList =>
      _newBankBranchDataList;
  set newBankBranchDataList(List<Form15cBankBranchDataStruct> value) {
    _newBankBranchDataList = value;
  }

  void addToNewBankBranchDataList(Form15cBankBranchDataStruct value) {
    newBankBranchDataList.add(value);
  }

  void removeFromNewBankBranchDataList(Form15cBankBranchDataStruct value) {
    newBankBranchDataList.remove(value);
  }

  void removeAtIndexFromNewBankBranchDataList(int index) {
    newBankBranchDataList.removeAt(index);
  }

  void updateNewBankBranchDataListAtIndex(
    int index,
    Form15cBankBranchDataStruct Function(Form15cBankBranchDataStruct) updateFn,
  ) {
    newBankBranchDataList[index] = updateFn(_newBankBranchDataList[index]);
  }

  void insertAtIndexInNewBankBranchDataList(
      int index, Form15cBankBranchDataStruct value) {
    newBankBranchDataList.insert(index, value);
  }
}
