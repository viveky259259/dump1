import '/chetan/form_15_c_declaration_section/form15_c_declaration_section_widget.dart';
import '/chetan/form_15_c_preview_and_download_wrap/form15_c_preview_and_download_wrap_widget.dart';
import '/dk/form15_c_basic_details/form15_c_basic_details_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/presentation_upload_files/presentation_upload_files_widget.dart';
import '/pooja/form_15_c_validation_section/form15_c_validation_section_widget.dart';
import 'dart:ui';
import 'form15_c_body_widget.dart' show Form15CBodyWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_website/navigation_generic_stepper_vertical/navigation_generic_stepper_vertical_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CBodyModel extends FlutterFlowModel<Form15CBodyWidget> {
  ///  Local state fields for this component.

  int currentFormStep = 0;

  ///  State fields for stateful widgets in this component.

  // Model for Stepper.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericStepperVerticalModel stepperModel;
  // Model for Form15C_BasicDetails component.
  late Form15CBasicDetailsModel form15CBasicDetailsModel;
  // Model for Presentation_Upload_Files component.
  late PresentationUploadFilesModel presentationUploadFilesModel;
  // Model for Form_15C_Declaration_Section component.
  late Form15CDeclarationSectionModel form15CDeclarationSectionModel;
  // Model for Form_15C_Preview_and_Download_Wrap component.
  late Form15CPreviewAndDownloadWrapModel form15CPreviewAndDownloadWrapModel;
  // Model for Form_15_C_Validation_Section component.
  late Form15CValidationSectionModel form15CValidationSectionModel;

  @override
  void initState(BuildContext context) {
    stepperModel = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericStepperVerticalModel());
    form15CBasicDetailsModel =
        createModel(context, () => Form15CBasicDetailsModel());
    presentationUploadFilesModel =
        createModel(context, () => PresentationUploadFilesModel());
    form15CDeclarationSectionModel =
        createModel(context, () => Form15CDeclarationSectionModel());
    form15CPreviewAndDownloadWrapModel =
        createModel(context, () => Form15CPreviewAndDownloadWrapModel());
    form15CValidationSectionModel =
        createModel(context, () => Form15CValidationSectionModel());
  }

  @override
  void dispose() {
    stepperModel.dispose();
    form15CBasicDetailsModel.dispose();
    presentationUploadFilesModel.dispose();
    form15CDeclarationSectionModel.dispose();
    form15CPreviewAndDownloadWrapModel.dispose();
    form15CValidationSectionModel.dispose();
  }
}
