import '/chetan/form_15_c_declaration_section/form15_c_declaration_section_widget.dart';
import '/chetan/form_15_c_preview_and_download_wrap/form15_c_preview_and_download_wrap_widget.dart';
import '/dk/form15_c_basic_details/form15_c_basic_details_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/mahipal/presentation_upload_files/presentation_upload_files_widget.dart';
import '/pooja/form_15_c_validation_section/form15_c_validation_section_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_website/navigation_generic_stepper_vertical/navigation_generic_stepper_vertical_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_body_model.dart';
export 'form15_c_body_model.dart';

class Form15CBodyWidget extends StatefulWidget {
  const Form15CBodyWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<Form15CBodyWidget> createState() => _Form15CBodyWidgetState();
}

class _Form15CBodyWidgetState extends State<Form15CBodyWidget> {
  late Form15CBodyModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CBodyModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
          model: _model.stepperModel,
          updateCallback: () => safeSetState(() {}),
          child: t_d_s_login_module_l1_navigation_3he2k0
              .NavigationGenericStepperVerticalWidget(
            stepperHeading: FFAppConstants.Form15CStepperTitle,
            currentStep: _model.currentFormStep,
            keyPrefix:
                t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                    widget!.keyPrefix!, 'Form_15C_Stepper', 'Form_Stepper'),
            showVerticalLine: true,
            hideTrailingIcon: false,
            showHeading: false,
            stepsList: FFAppConstants.Form15CFormSteps,
            onTap: (selectedIndex) async {},
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 0.0, 0.0),
            child: Builder(
              builder: (context) {
                if (_model.currentFormStep == 0) {
                  return wrapWithModel(
                    model: _model.form15CBasicDetailsModel,
                    updateCallback: () => safeSetState(() {}),
                    child: Form15CBasicDetailsWidget(
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(widget!.keyPrefix!,
                              'Form_15C_Body', 'Basic_Details_Section'),
                      onSave: () async {
                        _model.currentFormStep = 1;
                        safeSetState(() {});
                      },
                      onBack: () async {},
                    ),
                  );
                } else if (_model.currentFormStep == 1) {
                  return wrapWithModel(
                    model: _model.presentationUploadFilesModel,
                    updateCallback: () => safeSetState(() {}),
                    child: PresentationUploadFilesWidget(
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(widget!.keyPrefix!,
                              'Form_15C_Body', 'Upload_Files_Section'),
                      backButtonActn: () async {},
                      saveProceedBtnActn: () async {},
                    ),
                  );
                } else if (_model.currentFormStep == 2) {
                  return wrapWithModel(
                    model: _model.form15CDeclarationSectionModel,
                    updateCallback: () => safeSetState(() {}),
                    child: Form15CDeclarationSectionWidget(
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(widget!.keyPrefix!,
                              'Form_15C_Body', 'Declaration_Section'),
                      backButtonAction: () async {},
                      proceedButtonAction: () async {},
                    ),
                  );
                } else if (_model.currentFormStep == 3) {
                  return wrapWithModel(
                    model: _model.form15CPreviewAndDownloadWrapModel,
                    updateCallback: () => safeSetState(() {}),
                    child: Form15CPreviewAndDownloadWrapWidget(
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(widget!.keyPrefix!,
                              'Form_15C_Body', 'Preview_And_Download_Section'),
                      panNumber: 'ABCYP1234P',
                      onModifyUploadFile: () async {},
                      onModifyDeclaration: () async {},
                      onBack: () async {},
                      onSubmit: () async {},
                      onDownload: () async {},
                      onModifyBasicDetails: () async {},
                    ),
                  );
                } else if (_model.currentFormStep == 4) {
                  return wrapWithModel(
                    model: _model.form15CValidationSectionModel,
                    updateCallback: () => safeSetState(() {}),
                    child: Form15CValidationSectionWidget(
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(widget!.keyPrefix!,
                              'Form_15C_Body', 'Validation_Section'),
                      onBack: () async {},
                      onSubmit: () async {},
                      onValidationRequestSelection: () async {},
                    ),
                  );
                } else {
                  return Container(
                    width: 100.0,
                    height: 100.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                  );
                }
              },
            ),
          ),
        ),
      ],
    );
  }
}
