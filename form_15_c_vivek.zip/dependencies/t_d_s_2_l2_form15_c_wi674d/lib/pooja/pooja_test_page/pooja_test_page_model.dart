import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pooja/form_15_c_validation_section/form15_c_validation_section_widget.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'pooja_test_page_widget.dart' show PoojaTestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PoojaTestPageModel extends FlutterFlowModel<PoojaTestPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Form_15_C_Validation_Section component.
  late Form15CValidationSectionModel form15CValidationSectionModel;

  @override
  void initState(BuildContext context) {
    form15CValidationSectionModel =
        createModel(context, () => Form15CValidationSectionModel());
  }

  @override
  void dispose() {
    form15CValidationSectionModel.dispose();
  }
}
