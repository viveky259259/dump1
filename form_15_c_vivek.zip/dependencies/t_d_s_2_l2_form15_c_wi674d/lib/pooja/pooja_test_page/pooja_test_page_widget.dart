import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pooja/form_15_c_validation_section/form15_c_validation_section_widget.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'pooja_test_page_model.dart';
export 'pooja_test_page_model.dart';

class PoojaTestPageWidget extends StatefulWidget {
  const PoojaTestPageWidget({super.key});

  @override
  State<PoojaTestPageWidget> createState() => _PoojaTestPageWidgetState();
}

class _PoojaTestPageWidgetState extends State<PoojaTestPageWidget> {
  late PoojaTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PoojaTestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: wrapWithModel(
            model: _model.form15CValidationSectionModel,
            updateCallback: () => safeSetState(() {}),
            child: Form15CValidationSectionWidget(
              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                  .generateL3KeyValuePrefix('Pooja_testPage', 'Pooja_testPage'),
              onBack: () async {
                context.safePop();
              },
              onSubmit: () async {
                context.pushNamed('Pooja_testPage');
              },
              onValidationRequestSelection: () async {
                context.pushNamed('Pooja_testPage');
              },
            ),
          ),
        ),
      ),
    );
  }
}
