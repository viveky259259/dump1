import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'form15_c_validation_section_widget.dart'
    show Form15CValidationSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_state.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_state;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/radio_buttons/input_field_generic_radio_button_with_icon/input_field_generic_radio_button_with_icon_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CValidationSectionModel
    extends FlutterFlowModel<Form15CValidationSectionWidget> {
  ///  Local state fields for this component.

  int? radioButtonSelectedIndex = -1;

  List<
      t_d_s_login_module_l1_input_vo62wv_data_schema
      .RegisterTypeRadioButtonSchemaStruct> validationOptions = [];
  void addToValidationOptions(
          t_d_s_login_module_l1_input_vo62wv_data_schema
              .RegisterTypeRadioButtonSchemaStruct
              item) =>
      validationOptions.add(item);
  void removeFromValidationOptions(
          t_d_s_login_module_l1_input_vo62wv_data_schema
              .RegisterTypeRadioButtonSchemaStruct
              item) =>
      validationOptions.remove(item);
  void removeAtIndexFromValidationOptions(int index) =>
      validationOptions.removeAt(index);
  void insertAtIndexInValidationOptions(
          int index,
          t_d_s_login_module_l1_input_vo62wv_data_schema
              .RegisterTypeRadioButtonSchemaStruct
              item) =>
      validationOptions.insert(index, item);
  void updateValidationOptionsAtIndex(
          int index,
          Function(
                  t_d_s_login_module_l1_input_vo62wv_data_schema
                      .RegisterTypeRadioButtonSchemaStruct)
              updateFn) =>
      validationOptions[index] = updateFn(validationOptions[index]);

  bool isRadioButtonSelected = false;

  ///  State fields for stateful widgets in this component.

  // Model for InputField_Generic_RadioButton_with_Icon component.
  late t_d_s_login_module_l1_input_vo62wv
      .InputFieldGenericRadioButtonWithIconModel
      inputFieldGenericRadioButtonWithIconModel;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;

  @override
  void initState(BuildContext context) {
    inputFieldGenericRadioButtonWithIconModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericRadioButtonWithIconModel());
    navigationGenericPrimaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    inputFieldGenericRadioButtonWithIconModel.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
  }
}
