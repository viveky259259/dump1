import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_state.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_state;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/radio_buttons/input_field_generic_radio_button_with_icon/input_field_generic_radio_button_with_icon_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_validation_section_model.dart';
export 'form15_c_validation_section_model.dart';

/// A versatile component designed to show different options for the
/// validation
///
///
class Form15CValidationSectionWidget extends StatefulWidget {
  const Form15CValidationSectionWidget({
    super.key,
    required this.keyPrefix,
    required this.onBack,
    required this.onSubmit,
    required this.onValidationRequestSelection,
  });

  final String? keyPrefix;
  final Future Function()? onBack;
  final Future Function()? onSubmit;
  final Future Function()? onValidationRequestSelection;

  @override
  State<Form15CValidationSectionWidget> createState() =>
      _Form15CValidationSectionWidgetState();
}

class _Form15CValidationSectionWidgetState
    extends State<Form15CValidationSectionWidget> {
  late Form15CValidationSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CValidationSectionModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.validationOptions = FFAppState().optionList.toList().cast<
          t_d_s_login_module_l1_input_vo62wv_data_schema
          .RegisterTypeRadioButtonSchemaStruct>();
      safeSetState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();
    context.watch<t_d_s_2_l1_presentation_0l6uwx_app_state.FFAppState>();

    return Container(
      decoration: BoxDecoration(),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Align(
              alignment: AlignmentDirectional(-1.0, -1.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 3.0),
                child: Text(
                  'Validation',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).primary,
                        fontSize: 24.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ),
            Divider(
              thickness: 1.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Align(
              alignment: AlignmentDirectional(-1.0, -1.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                child: Text(
                  'Do you want to validate the form request through:',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).textBasic,
                        fontSize: 18.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ),
            Align(
              alignment: AlignmentDirectional(-1.0, -1.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
                  model: _model.inputFieldGenericRadioButtonWithIconModel,
                  updateCallback: () => safeSetState(() {}),
                  child: t_d_s_login_module_l1_input_vo62wv
                      .InputFieldGenericRadioButtonWithIconWidget(
                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                        .generateL2KeyValuePrefix(
                            widget!.keyPrefix!,
                            'Form_15_C_Validation_Section',
                            'InputField_Generic_RadioButton_with_Icon')),
                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                        .generateL2KeyValuePrefix(
                            widget!.keyPrefix!,
                            'Form_15_C_Validation_Section',
                            'InputField_Generic_RadioButton_with_Icon'),
                    listOfObject: _model.validationOptions,
                    callBackAction: (selectedIndexParam) async {
                      _model.radioButtonSelectedIndex = selectedIndexParam;
                      safeSetState(() {});
                      _model.isRadioButtonSelected = true;
                      safeSetState(() {});
                    },
                  ),
                ),
              ),
            ),
            Spacer(),
            Builder(
              builder: (context) {
                if (() {
                  if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                    return true;
                  } else if (MediaQuery.sizeOf(context).width <
                      kBreakpointMedium) {
                    return true;
                  } else if (MediaQuery.sizeOf(context).width <
                      kBreakpointLarge) {
                    return true;
                  } else {
                    return false;
                  }
                }()) {
                  return Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onSubmit?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.navigationGenericPrimaryButtonModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericPrimaryButtonWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Primary_Button')),
                            labeltext: 'Proceed',
                            rightIcon: Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15_C_Validation_Section',
                                      'Navigation_Generic_Primary_Button')),
                              Icons.chevron_right,
                            ),
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Primary_Button'),
                            states: _model.isRadioButtonSelected == true
                                ? t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.selected
                                : t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.disabled,
                            onTap: () async {},
                          ),
                        ),
                      ),
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onBack?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.navigationGenericSecondaryButtonModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericSecondaryButtonWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Secondary_Button')),
                            labelText: 'Back',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Secondary_Button'),
                            leftIcon: Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15_C_Validation_Section',
                                      'Navigation_Generic_Secondary_Button')),
                              Icons.chevron_left,
                            ),
                            states:
                                t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.focused,
                            onTap: () async {},
                          ),
                        ),
                      ),
                    ].divide(SizedBox(height: 12.0)),
                  );
                } else {
                  return Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onBack?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.navigationGenericSecondaryButtonModel2,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericSecondaryButtonWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Secondary_Button')),
                            labelText: 'Back',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Secondary_Button'),
                            leftIcon: Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15_C_Validation_Section',
                                      'Navigation_Generic_Secondary_Button')),
                              Icons.chevron_left,
                            ),
                            states:
                                t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.focused,
                            onTap: () async {},
                          ),
                        ),
                      ),
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          await widget.onSubmit?.call();
                        },
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.navigationGenericPrimaryButtonModel2,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericPrimaryButtonWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Primary_Button')),
                            labeltext: 'Proceed',
                            rightIcon: Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Form_15_C_Validation_Section',
                                      'Navigation_Generic_Primary_Button')),
                              Icons.chevron_right,
                            ),
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Form_15_C_Validation_Section',
                                    'Navigation_Generic_Primary_Button'),
                            states: _model.isRadioButtonSelected == true
                                ? t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.selected
                                : t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.disabled,
                            onTap: () async {},
                          ),
                        ),
                      ),
                    ],
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
