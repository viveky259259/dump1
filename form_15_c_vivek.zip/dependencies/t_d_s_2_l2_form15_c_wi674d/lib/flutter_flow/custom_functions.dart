import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:ff_commons/flutter_flow/lat_lng.dart';
import 'package:ff_commons/flutter_flow/place.dart';
import 'package:ff_commons/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/custom_functions.dart'
    as t_d_s_login_module_l1_input_vo62wv_functions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;

List<FFUploadedFile> addUploadList(
  List<FFUploadedFile> newList,
  List<FFUploadedFile> oldList,
) {
  return <FFUploadedFile>[...newList, ...oldList];
}

List<t_d_s_login_module_l1_navigation_3he2k0_data_schema.FileUploadInfoStruct>
    mapFileItem(List<Form15cUploadedFilesDataStruct> fileResponse) {
  final Map<String, List<Form15cUploadedFilesDataStruct>> groupedFiles = {};
  for (var file in fileResponse) {
    if (!groupedFiles.containsKey(file.documentDescription)) {
      groupedFiles[file.documentDescription] = [];
    }
    groupedFiles[file.documentDescription]!.add(file);
  }

  // Create FileUploadInfoStruct list
  return groupedFiles.entries.map((entry) {
    return t_d_s_login_module_l1_navigation_3he2k0_data_schema
        .FileUploadInfoStruct(
      heading: entry.key,
      fileDetails: entry.value
          .map((file) => t_d_s_login_module_l1_navigation_3he2k0_data_schema
                  .FileDetailStruct(
                fileName: file.fileName,
              ))
          .toList(),
    );
  }).toList();
}

List<MetaForFilesStruct>? completeMetaDataWithError(
    List<FFUploadedFile> uploadedFiles) {
  final Set<String> fileNames = {};
  final Set<String> supportedFormats = {'tiff', 'pdf', 'zip', 'jpeg'};
  final metadataForFiles = uploadedFiles.map((FFUploadedFile uploadedFile) {
    int fileSizeInBytes = uploadedFile.bytes?.lengthInBytes ?? 0;
    int fileSizeInKB = fileSizeInBytes ~/ 1024;
    int fileSizeInMB = fileSizeInBytes ~/ (1024 * 1024);

    String? error;
    const int sizeLimitMB = 10; // Example size limit in MB

    // Check for file size limit
    if (fileSizeInMB > sizeLimitMB) {
      error = 'File size exceeds $sizeLimitMB MB limit';
    }

    // Check for duplicate files
    if (fileNames.contains(uploadedFile.name)) {
      error = 'Duplicate File';
    } else {
      fileNames.add(uploadedFile.name!);
    }

    // Check for unsupported file formats
    String fileFormat = uploadedFile.name?.split('.').last.toLowerCase() ?? '';
    if (!supportedFormats.contains(fileFormat)) {
      error = 'File format not supported';
    }

    return MetaForFilesStruct(
      fileName: uploadedFile.name,
      height: uploadedFile.height,
      width: uploadedFile.width,
      sizeInMB: fileSizeInMB,
      sizeInKB: fileSizeInKB,
      format: fileFormat,
      error: error,
    );
  }).toList();
}
