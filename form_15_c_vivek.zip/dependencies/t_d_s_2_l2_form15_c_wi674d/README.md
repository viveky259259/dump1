# TDS 2 - L2 - Form15C

A new Flutter project.

## Getting Started

FlutterFlow projects are built to run on the Flutter _stable_ release.
