// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:encrypt/encrypt.dart' as encrypt;
import 'dart:convert';

Future<String> decryptText(String base64Encrypted) async {
  final keyString = "TDSFlutterFlowPO";
  final key = encrypt.Key.fromUtf8(keyString);

  final ivAndEncryptedBytes = base64.decode(base64Encrypted);

  final ivBytes = ivAndEncryptedBytes.sublist(0, 16);
  final encryptedBytes = ivAndEncryptedBytes.sublist(16);

  final iv = encrypt.IV(ivBytes);

  final encrypter =
      encrypt.Encrypter(encrypt.AES(key, mode: encrypt.AESMode.cbc));

  final decrypted =
      encrypter.decrypt(encrypt.Encrypted(encryptedBytes), iv: iv);

  return decrypted;
}
