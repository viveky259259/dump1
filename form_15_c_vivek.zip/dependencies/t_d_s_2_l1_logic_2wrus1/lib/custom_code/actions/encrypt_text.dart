// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';

import 'package:encrypt/encrypt.dart' as encrypt;

Future<String> encryptText(String plainText) async {
  final keyString = "TDSFlutterFlowPO";
  final key = encrypt.Key.fromUtf8(keyString);
  final iv = encrypt.IV.fromUtf8(keyString);
  final encrypter =
      encrypt.Encrypter(encrypt.AES(key, mode: encrypt.AESMode.cbc));

  final encrypted = encrypter.encrypt(plainText, iv: iv);

  final ivAndEncrypted = Uint8List.fromList(iv.bytes + encrypted.bytes);

  return base64.encode(ivAndEncrypted);
}
