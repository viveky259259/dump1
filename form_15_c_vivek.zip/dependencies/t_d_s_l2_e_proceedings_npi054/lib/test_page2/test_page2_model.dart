import '/components/notice_writting_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'test_page2_widget.dart' show TestPage2Widget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TestPage2Model extends FlutterFlowModel<TestPage2Widget> {
  ///  State fields for stateful widgets in this page.

  // Model for NoticeWritting component.
  late NoticeWrittingModel noticeWrittingModel;

  @override
  void initState(BuildContext context) {
    noticeWrittingModel = createModel(context, () => NoticeWrittingModel());
  }

  @override
  void dispose() {
    noticeWrittingModel.dispose();
  }
}
