import '/components/notice_writting_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'vaishali_test_page_model.dart';
export 'vaishali_test_page_model.dart';

class VaishaliTestPageWidget extends StatefulWidget {
  const VaishaliTestPageWidget({super.key});

  @override
  State<VaishaliTestPageWidget> createState() => _VaishaliTestPageWidgetState();
}

class _VaishaliTestPageWidgetState extends State<VaishaliTestPageWidget> {
  late VaishaliTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VaishaliTestPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              wrapWithModel(
                model: _model.noticeWrittingModel,
                updateCallback: () => safeSetState(() {}),
                child: NoticeWrittingWidget(
                  keyPrefix: 'K',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
