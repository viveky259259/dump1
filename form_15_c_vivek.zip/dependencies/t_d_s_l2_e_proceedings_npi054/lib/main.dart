import 'package:provider/provider.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'flutter_flow/internationalization.dart';
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/internationalization.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_internationalization;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/internationalization.dart'
    as t_d_s_2_l1_presentation_0l6uwx_internationalization;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/internationalization.dart'
    as t_d_s_login_module_l1_input_vo62wv_internationalization;
import 'flutter_flow/nav/nav.dart';
import 'index.dart';

import 'package:t_d_s_2_l1_presentation_0l6uwx/app_state.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_state;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  GoRouter.optionURLReflectsImperativeAPIs = true;
  usePathUrlStrategy();

  final t_d_s_2_l1_presentation_0l6uwxAppState =
      t_d_s_2_l1_presentation_0l6uwx_app_state.FFAppState();
  await t_d_s_2_l1_presentation_0l6uwxAppState.initializePersistedState();

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(
        create: (context) => t_d_s_2_l1_presentation_0l6uwxAppState,
      ),
    ],
    child: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  State<MyApp> createState() => _MyAppState();

  static _MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>()!;
}

class _MyAppState extends State<MyApp> {
  Locale? _locale;

  ThemeMode _themeMode = ThemeMode.system;

  late AppStateNotifier _appStateNotifier;
  late GoRouter _router;
  String getRoute([RouteMatch? routeMatch]) {
    final RouteMatch lastMatch =
        routeMatch ?? _router.routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : _router.routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }

  @override
  void initState() {
    super.initState();

    _appStateNotifier = AppStateNotifier.instance;
    _router = createRouter(_appStateNotifier);
  }

  void setLocale(String language) {
    safeSetState(() => _locale = createLocale(language));
  }

  void setThemeMode(ThemeMode mode) => safeSetState(() {
        _themeMode = mode;
      });

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'TDS 2 L2- E-Proceedings',
      localizationsDelegates: [
        FFLocalizationsDelegate(),
        t_d_s_login_module_l1_navigation_3he2k0_internationalization
            .FFLocalizationsDelegate(),
        t_d_s_2_l1_presentation_0l6uwx_internationalization
            .FFLocalizationsDelegate(),
        t_d_s_login_module_l1_input_vo62wv_internationalization
            .FFLocalizationsDelegate(),
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        FallbackMaterialLocalizationDelegate(),
        FallbackCupertinoLocalizationDelegate(),
      ],
      locale: _locale,
      supportedLocales: const [
        Locale('en'),
      ],
      theme: ThemeData(
        brightness: Brightness.light,
        useMaterial3: false,
      ),
      themeMode: _themeMode,
      routerConfig: _router,
    );
  }
}
