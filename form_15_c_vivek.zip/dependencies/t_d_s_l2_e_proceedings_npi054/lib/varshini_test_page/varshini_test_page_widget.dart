import '/components/initiate_notice_form_section_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'varshini_test_page_model.dart';
export 'varshini_test_page_model.dart';

class VarshiniTestPageWidget extends StatefulWidget {
  const VarshiniTestPageWidget({super.key});

  @override
  State<VarshiniTestPageWidget> createState() => _VarshiniTestPageWidgetState();
}

class _VarshiniTestPageWidgetState extends State<VarshiniTestPageWidget> {
  late VarshiniTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VarshiniTestPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).alternate,
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                wrapWithModel(
                  model: _model.initiateNoticeFormSectionModel,
                  updateCallback: () => safeSetState(() {}),
                  child: InitiateNoticeFormSectionWidget(
                    keyPrefix: 'key',
                    navigationPath: ["axc", "dcs"],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
