import '/components/initiate_notice_form_section_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'varshini_test_page_widget.dart' show VarshiniTestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VarshiniTestPageModel extends FlutterFlowModel<VarshiniTestPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Initiate_Notice_Form_Section component.
  late InitiateNoticeFormSectionModel initiateNoticeFormSectionModel;

  @override
  void initState(BuildContext context) {
    initiateNoticeFormSectionModel =
        createModel(context, () => InitiateNoticeFormSectionModel());
  }

  @override
  void dispose() {
    initiateNoticeFormSectionModel.dispose();
  }
}
