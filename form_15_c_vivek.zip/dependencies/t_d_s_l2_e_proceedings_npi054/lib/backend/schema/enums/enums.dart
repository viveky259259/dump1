import 'package:collection/collection.dart';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums
    hide FFEnumExtensions, FFEnumListExtensions;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums
    hide FFEnumExtensions, FFEnumListExtensions;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums
    hide FFEnumExtensions, FFEnumListExtensions;

enum TransactionType {
  Online_Entries,
  Offline_Entries,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (TransactionType):
      return TransactionType.values.deserialize(value) as T?;
    case (t_d_s_login_module_l1_navigation_3he2k0_enums.ButtonState):
      return t_d_s_login_module_l1_navigation_3he2k0_enums.ButtonState.values
          .deserialize(value) as T?;
    case (t_d_s_2_l1_presentation_0l6uwx_enums.Status):
      return t_d_s_2_l1_presentation_0l6uwx_enums.Status.values
          .deserialize(value) as T?;
    case (t_d_s_2_l1_presentation_0l6uwx_enums.ToastMessage):
      return t_d_s_2_l1_presentation_0l6uwx_enums.ToastMessage.values
          .deserialize(value) as T?;
    case (t_d_s_2_l1_presentation_0l6uwx_enums.AlertTextStatus):
      return t_d_s_2_l1_presentation_0l6uwx_enums.AlertTextStatus.values
          .deserialize(value) as T?;
    case (t_d_s_2_l1_presentation_0l6uwx_enums.BadgeStatus):
      return t_d_s_2_l1_presentation_0l6uwx_enums.BadgeStatus.values
          .deserialize(value) as T?;
    case (t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus):
      return t_d_s_login_module_l1_input_vo62wv_enums.FileUploadStatus.values
          .deserialize(value) as T?;
    case (t_d_s_login_module_l1_input_vo62wv_enums.RadioButtonIconEnum):
      return t_d_s_login_module_l1_input_vo62wv_enums.RadioButtonIconEnum.values
          .deserialize(value) as T?;
    case (t_d_s_login_module_l1_input_vo62wv_enums.ErrorType):
      return t_d_s_login_module_l1_input_vo62wv_enums.ErrorType.values
          .deserialize(value) as T?;
    default:
      return null;
  }
}
