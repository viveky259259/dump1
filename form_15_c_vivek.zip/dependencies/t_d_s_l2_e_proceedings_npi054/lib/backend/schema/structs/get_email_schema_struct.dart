// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetEmailSchemaStruct extends BaseStruct {
  GetEmailSchemaStruct({
    List<EmailDataStruct>? data,
    List<EmailAndNameErrorsStruct>? errors,
  })  : _data = data,
        _errors = errors;

  // "data" field.
  List<EmailDataStruct>? _data;
  List<EmailDataStruct> get data => _data ?? const [];
  set data(List<EmailDataStruct>? val) => _data = val;

  void updateData(Function(List<EmailDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "errors" field.
  List<EmailAndNameErrorsStruct>? _errors;
  List<EmailAndNameErrorsStruct> get errors => _errors ?? const [];
  set errors(List<EmailAndNameErrorsStruct>? val) => _errors = val;

  void updateErrors(Function(List<EmailAndNameErrorsStruct>) updateFn) {
    updateFn(_errors ??= []);
  }

  bool hasErrors() => _errors != null;

  static GetEmailSchemaStruct fromMap(Map<String, dynamic> data) =>
      GetEmailSchemaStruct(
        data: getStructList(
          data['data'],
          EmailDataStruct.fromMap,
        ),
        errors: getStructList(
          data['errors'],
          EmailAndNameErrorsStruct.fromMap,
        ),
      );

  static GetEmailSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? GetEmailSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'errors': _errors?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'errors': serializeParam(
          _errors,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static GetEmailSchemaStruct fromSerializableMap(Map<String, dynamic> data) =>
      GetEmailSchemaStruct(
        data: deserializeStructParam<EmailDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: EmailDataStruct.fromSerializableMap,
        ),
        errors: deserializeStructParam<EmailAndNameErrorsStruct>(
          data['errors'],
          ParamType.DataStruct,
          true,
          structBuilder: EmailAndNameErrorsStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'GetEmailSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GetEmailSchemaStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(errors, other.errors);
  }

  @override
  int get hashCode => const ListEquality().hash([data, errors]);
}

GetEmailSchemaStruct createGetEmailSchemaStruct() => GetEmailSchemaStruct();
