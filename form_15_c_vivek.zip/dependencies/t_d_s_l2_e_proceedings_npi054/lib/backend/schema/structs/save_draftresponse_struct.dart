// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SaveDraftresponseStruct extends BaseStruct {
  SaveDraftresponseStruct({
    String? tanPan,
    int? financialYear,
    String? tanName,
    String? noticeUs,
    String? updatedAt,
  })  : _tanPan = tanPan,
        _financialYear = financialYear,
        _tanName = tanName,
        _noticeUs = noticeUs,
        _updatedAt = updatedAt;

  // "tanPan" field.
  String? _tanPan;
  String get tanPan => _tanPan ?? '';
  set tanPan(String? val) => _tanPan = val;

  bool hasTanPan() => _tanPan != null;

  // "financialYear" field.
  int? _financialYear;
  int get financialYear => _financialYear ?? 0;
  set financialYear(int? val) => _financialYear = val;

  void incrementFinancialYear(int amount) =>
      financialYear = financialYear + amount;

  bool hasFinancialYear() => _financialYear != null;

  // "tanName" field.
  String? _tanName;
  String get tanName => _tanName ?? '';
  set tanName(String? val) => _tanName = val;

  bool hasTanName() => _tanName != null;

  // "noticeUs" field.
  String? _noticeUs;
  String get noticeUs => _noticeUs ?? '';
  set noticeUs(String? val) => _noticeUs = val;

  bool hasNoticeUs() => _noticeUs != null;

  // "updatedAt" field.
  String? _updatedAt;
  String get updatedAt => _updatedAt ?? '';
  set updatedAt(String? val) => _updatedAt = val;

  bool hasUpdatedAt() => _updatedAt != null;

  static SaveDraftresponseStruct fromMap(Map<String, dynamic> data) =>
      SaveDraftresponseStruct(
        tanPan: data['tanPan'] as String?,
        financialYear: castToType<int>(data['financialYear']),
        tanName: data['tanName'] as String?,
        noticeUs: data['noticeUs'] as String?,
        updatedAt: data['updatedAt'] as String?,
      );

  static SaveDraftresponseStruct? maybeFromMap(dynamic data) => data is Map
      ? SaveDraftresponseStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'tanPan': _tanPan,
        'financialYear': _financialYear,
        'tanName': _tanName,
        'noticeUs': _noticeUs,
        'updatedAt': _updatedAt,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'tanPan': serializeParam(
          _tanPan,
          ParamType.String,
        ),
        'financialYear': serializeParam(
          _financialYear,
          ParamType.int,
        ),
        'tanName': serializeParam(
          _tanName,
          ParamType.String,
        ),
        'noticeUs': serializeParam(
          _noticeUs,
          ParamType.String,
        ),
        'updatedAt': serializeParam(
          _updatedAt,
          ParamType.String,
        ),
      }.withoutNulls;

  static SaveDraftresponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      SaveDraftresponseStruct(
        tanPan: deserializeParam(
          data['tanPan'],
          ParamType.String,
          false,
        ),
        financialYear: deserializeParam(
          data['financialYear'],
          ParamType.int,
          false,
        ),
        tanName: deserializeParam(
          data['tanName'],
          ParamType.String,
          false,
        ),
        noticeUs: deserializeParam(
          data['noticeUs'],
          ParamType.String,
          false,
        ),
        updatedAt: deserializeParam(
          data['updatedAt'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SaveDraftresponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SaveDraftresponseStruct &&
        tanPan == other.tanPan &&
        financialYear == other.financialYear &&
        tanName == other.tanName &&
        noticeUs == other.noticeUs &&
        updatedAt == other.updatedAt;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([tanPan, financialYear, tanName, noticeUs, updatedAt]);
}

SaveDraftresponseStruct createSaveDraftresponseStruct({
  String? tanPan,
  int? financialYear,
  String? tanName,
  String? noticeUs,
  String? updatedAt,
}) =>
    SaveDraftresponseStruct(
      tanPan: tanPan,
      financialYear: financialYear,
      tanName: tanName,
      noticeUs: noticeUs,
      updatedAt: updatedAt,
    );
