// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DownloadExcelSchemaStruct extends BaseStruct {
  DownloadExcelSchemaStruct({
    List<DownloadExcelDataStruct>? data,
    List<ErrorSchemaStruct>? error,
  })  : _data = data,
        _error = error;

  // "data" field.
  List<DownloadExcelDataStruct>? _data;
  List<DownloadExcelDataStruct> get data => _data ?? const [];
  set data(List<DownloadExcelDataStruct>? val) => _data = val;

  void updateData(Function(List<DownloadExcelDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "error" field.
  List<ErrorSchemaStruct>? _error;
  List<ErrorSchemaStruct> get error => _error ?? const [];
  set error(List<ErrorSchemaStruct>? val) => _error = val;

  void updateError(Function(List<ErrorSchemaStruct>) updateFn) {
    updateFn(_error ??= []);
  }

  bool hasError() => _error != null;

  static DownloadExcelSchemaStruct fromMap(Map<String, dynamic> data) =>
      DownloadExcelSchemaStruct(
        data: getStructList(
          data['data'],
          DownloadExcelDataStruct.fromMap,
        ),
        error: getStructList(
          data['error'],
          ErrorSchemaStruct.fromMap,
        ),
      );

  static DownloadExcelSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? DownloadExcelSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'error': _error?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'error': serializeParam(
          _error,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static DownloadExcelSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      DownloadExcelSchemaStruct(
        data: deserializeStructParam<DownloadExcelDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: DownloadExcelDataStruct.fromSerializableMap,
        ),
        error: deserializeStructParam<ErrorSchemaStruct>(
          data['error'],
          ParamType.DataStruct,
          true,
          structBuilder: ErrorSchemaStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'DownloadExcelSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is DownloadExcelSchemaStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(error, other.error);
  }

  @override
  int get hashCode => const ListEquality().hash([data, error]);
}

DownloadExcelSchemaStruct createDownloadExcelSchemaStruct() =>
    DownloadExcelSchemaStruct();
