// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UploadFileSchemaStruct extends BaseStruct {
  UploadFileSchemaStruct({
    List<FileDataSchemaStruct>? data,
    EmailAndNameErrorsStruct? error,
  })  : _data = data,
        _error = error;

  // "data" field.
  List<FileDataSchemaStruct>? _data;
  List<FileDataSchemaStruct> get data => _data ?? const [];
  set data(List<FileDataSchemaStruct>? val) => _data = val;

  void updateData(Function(List<FileDataSchemaStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "error" field.
  EmailAndNameErrorsStruct? _error;
  EmailAndNameErrorsStruct get error => _error ?? EmailAndNameErrorsStruct();
  set error(EmailAndNameErrorsStruct? val) => _error = val;

  void updateError(Function(EmailAndNameErrorsStruct) updateFn) {
    updateFn(_error ??= EmailAndNameErrorsStruct());
  }

  bool hasError() => _error != null;

  static UploadFileSchemaStruct fromMap(Map<String, dynamic> data) =>
      UploadFileSchemaStruct(
        data: getStructList(
          data['data'],
          FileDataSchemaStruct.fromMap,
        ),
        error: data['error'] is EmailAndNameErrorsStruct
            ? data['error']
            : EmailAndNameErrorsStruct.maybeFromMap(data['error']),
      );

  static UploadFileSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? UploadFileSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'error': _error?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'error': serializeParam(
          _error,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static UploadFileSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      UploadFileSchemaStruct(
        data: deserializeStructParam<FileDataSchemaStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: FileDataSchemaStruct.fromSerializableMap,
        ),
        error: deserializeStructParam(
          data['error'],
          ParamType.DataStruct,
          false,
          structBuilder: EmailAndNameErrorsStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'UploadFileSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is UploadFileSchemaStruct &&
        listEquality.equals(data, other.data) &&
        error == other.error;
  }

  @override
  int get hashCode => const ListEquality().hash([data, error]);
}

UploadFileSchemaStruct createUploadFileSchemaStruct({
  EmailAndNameErrorsStruct? error,
}) =>
    UploadFileSchemaStruct(
      error: error ?? EmailAndNameErrorsStruct(),
    );
