// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetAddressSchemaStruct extends BaseStruct {
  GetAddressSchemaStruct({
    List<AddressDataStruct>? data,
    List<ErrorSchemaStruct>? errors,
  })  : _data = data,
        _errors = errors;

  // "data" field.
  List<AddressDataStruct>? _data;
  List<AddressDataStruct> get data => _data ?? const [];
  set data(List<AddressDataStruct>? val) => _data = val;

  void updateData(Function(List<AddressDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "errors" field.
  List<ErrorSchemaStruct>? _errors;
  List<ErrorSchemaStruct> get errors => _errors ?? const [];
  set errors(List<ErrorSchemaStruct>? val) => _errors = val;

  void updateErrors(Function(List<ErrorSchemaStruct>) updateFn) {
    updateFn(_errors ??= []);
  }

  bool hasErrors() => _errors != null;

  static GetAddressSchemaStruct fromMap(Map<String, dynamic> data) =>
      GetAddressSchemaStruct(
        data: getStructList(
          data['data'],
          AddressDataStruct.fromMap,
        ),
        errors: getStructList(
          data['errors'],
          ErrorSchemaStruct.fromMap,
        ),
      );

  static GetAddressSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? GetAddressSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'errors': _errors?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'errors': serializeParam(
          _errors,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static GetAddressSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      GetAddressSchemaStruct(
        data: deserializeStructParam<AddressDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: AddressDataStruct.fromSerializableMap,
        ),
        errors: deserializeStructParam<ErrorSchemaStruct>(
          data['errors'],
          ParamType.DataStruct,
          true,
          structBuilder: ErrorSchemaStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'GetAddressSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GetAddressSchemaStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(errors, other.errors);
  }

  @override
  int get hashCode => const ListEquality().hash([data, errors]);
}

GetAddressSchemaStruct createGetAddressSchemaStruct() =>
    GetAddressSchemaStruct();
