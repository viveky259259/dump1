// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TestingStruct extends BaseStruct {
  TestingStruct({
    String? tan,
    String? tanName,
    int? financialYear,
    String? state,
    String? sectionCode,
    String? natureOfDefault,
  })  : _tan = tan,
        _tanName = tanName,
        _financialYear = financialYear,
        _state = state,
        _sectionCode = sectionCode,
        _natureOfDefault = natureOfDefault;

  // "tan" field.
  String? _tan;
  String get tan => _tan ?? '';
  set tan(String? val) => _tan = val;

  bool hasTan() => _tan != null;

  // "tanName" field.
  String? _tanName;
  String get tanName => _tanName ?? '';
  set tanName(String? val) => _tanName = val;

  bool hasTanName() => _tanName != null;

  // "financialYear" field.
  int? _financialYear;
  int get financialYear => _financialYear ?? 0;
  set financialYear(int? val) => _financialYear = val;

  void incrementFinancialYear(int amount) =>
      financialYear = financialYear + amount;

  bool hasFinancialYear() => _financialYear != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "sectionCode" field.
  String? _sectionCode;
  String get sectionCode => _sectionCode ?? '';
  set sectionCode(String? val) => _sectionCode = val;

  bool hasSectionCode() => _sectionCode != null;

  // "natureOfDefault" field.
  String? _natureOfDefault;
  String get natureOfDefault => _natureOfDefault ?? '';
  set natureOfDefault(String? val) => _natureOfDefault = val;

  bool hasNatureOfDefault() => _natureOfDefault != null;

  static TestingStruct fromMap(Map<String, dynamic> data) => TestingStruct(
        tan: data['tan'] as String?,
        tanName: data['tanName'] as String?,
        financialYear: castToType<int>(data['financialYear']),
        state: data['state'] as String?,
        sectionCode: data['sectionCode'] as String?,
        natureOfDefault: data['natureOfDefault'] as String?,
      );

  static TestingStruct? maybeFromMap(dynamic data) =>
      data is Map ? TestingStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'tan': _tan,
        'tanName': _tanName,
        'financialYear': _financialYear,
        'state': _state,
        'sectionCode': _sectionCode,
        'natureOfDefault': _natureOfDefault,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'tan': serializeParam(
          _tan,
          ParamType.String,
        ),
        'tanName': serializeParam(
          _tanName,
          ParamType.String,
        ),
        'financialYear': serializeParam(
          _financialYear,
          ParamType.int,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'sectionCode': serializeParam(
          _sectionCode,
          ParamType.String,
        ),
        'natureOfDefault': serializeParam(
          _natureOfDefault,
          ParamType.String,
        ),
      }.withoutNulls;

  static TestingStruct fromSerializableMap(Map<String, dynamic> data) =>
      TestingStruct(
        tan: deserializeParam(
          data['tan'],
          ParamType.String,
          false,
        ),
        tanName: deserializeParam(
          data['tanName'],
          ParamType.String,
          false,
        ),
        financialYear: deserializeParam(
          data['financialYear'],
          ParamType.int,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        sectionCode: deserializeParam(
          data['sectionCode'],
          ParamType.String,
          false,
        ),
        natureOfDefault: deserializeParam(
          data['natureOfDefault'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'TestingStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is TestingStruct &&
        tan == other.tan &&
        tanName == other.tanName &&
        financialYear == other.financialYear &&
        state == other.state &&
        sectionCode == other.sectionCode &&
        natureOfDefault == other.natureOfDefault;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([tan, tanName, financialYear, state, sectionCode, natureOfDefault]);
}

TestingStruct createTestingStruct({
  String? tan,
  String? tanName,
  int? financialYear,
  String? state,
  String? sectionCode,
  String? natureOfDefault,
}) =>
    TestingStruct(
      tan: tan,
      tanName: tanName,
      financialYear: financialYear,
      state: state,
      sectionCode: sectionCode,
      natureOfDefault: natureOfDefault,
    );
