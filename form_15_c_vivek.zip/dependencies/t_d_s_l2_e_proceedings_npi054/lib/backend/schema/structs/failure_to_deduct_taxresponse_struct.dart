// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FailureToDeductTaxresponseStruct extends BaseStruct {
  FailureToDeductTaxresponseStruct({
    String? section,
    String? natureOfPayment,
    int? totalAmountPaid,
    int? totalTaxAmountDeductible,
    int? totalTaxDeducted,
    int? amountSd,
  })  : _section = section,
        _natureOfPayment = natureOfPayment,
        _totalAmountPaid = totalAmountPaid,
        _totalTaxAmountDeductible = totalTaxAmountDeductible,
        _totalTaxDeducted = totalTaxDeducted,
        _amountSd = amountSd;

  // "section" field.
  String? _section;
  String get section => _section ?? '';
  set section(String? val) => _section = val;

  bool hasSection() => _section != null;

  // "natureOfPayment" field.
  String? _natureOfPayment;
  String get natureOfPayment => _natureOfPayment ?? '';
  set natureOfPayment(String? val) => _natureOfPayment = val;

  bool hasNatureOfPayment() => _natureOfPayment != null;

  // "totalAmountPaid" field.
  int? _totalAmountPaid;
  int get totalAmountPaid => _totalAmountPaid ?? 0;
  set totalAmountPaid(int? val) => _totalAmountPaid = val;

  void incrementTotalAmountPaid(int amount) =>
      totalAmountPaid = totalAmountPaid + amount;

  bool hasTotalAmountPaid() => _totalAmountPaid != null;

  // "totalTaxAmountDeductible" field.
  int? _totalTaxAmountDeductible;
  int get totalTaxAmountDeductible => _totalTaxAmountDeductible ?? 0;
  set totalTaxAmountDeductible(int? val) => _totalTaxAmountDeductible = val;

  void incrementTotalTaxAmountDeductible(int amount) =>
      totalTaxAmountDeductible = totalTaxAmountDeductible + amount;

  bool hasTotalTaxAmountDeductible() => _totalTaxAmountDeductible != null;

  // "totalTaxDeducted" field.
  int? _totalTaxDeducted;
  int get totalTaxDeducted => _totalTaxDeducted ?? 0;
  set totalTaxDeducted(int? val) => _totalTaxDeducted = val;

  void incrementTotalTaxDeducted(int amount) =>
      totalTaxDeducted = totalTaxDeducted + amount;

  bool hasTotalTaxDeducted() => _totalTaxDeducted != null;

  // "amountSd" field.
  int? _amountSd;
  int get amountSd => _amountSd ?? 0;
  set amountSd(int? val) => _amountSd = val;

  void incrementAmountSd(int amount) => amountSd = amountSd + amount;

  bool hasAmountSd() => _amountSd != null;

  static FailureToDeductTaxresponseStruct fromMap(Map<String, dynamic> data) =>
      FailureToDeductTaxresponseStruct(
        section: data['section'] as String?,
        natureOfPayment: data['natureOfPayment'] as String?,
        totalAmountPaid: castToType<int>(data['totalAmountPaid']),
        totalTaxAmountDeductible:
            castToType<int>(data['totalTaxAmountDeductible']),
        totalTaxDeducted: castToType<int>(data['totalTaxDeducted']),
        amountSd: castToType<int>(data['amountSd']),
      );

  static FailureToDeductTaxresponseStruct? maybeFromMap(dynamic data) => data
          is Map
      ? FailureToDeductTaxresponseStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'section': _section,
        'natureOfPayment': _natureOfPayment,
        'totalAmountPaid': _totalAmountPaid,
        'totalTaxAmountDeductible': _totalTaxAmountDeductible,
        'totalTaxDeducted': _totalTaxDeducted,
        'amountSd': _amountSd,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'section': serializeParam(
          _section,
          ParamType.String,
        ),
        'natureOfPayment': serializeParam(
          _natureOfPayment,
          ParamType.String,
        ),
        'totalAmountPaid': serializeParam(
          _totalAmountPaid,
          ParamType.int,
        ),
        'totalTaxAmountDeductible': serializeParam(
          _totalTaxAmountDeductible,
          ParamType.int,
        ),
        'totalTaxDeducted': serializeParam(
          _totalTaxDeducted,
          ParamType.int,
        ),
        'amountSd': serializeParam(
          _amountSd,
          ParamType.int,
        ),
      }.withoutNulls;

  static FailureToDeductTaxresponseStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FailureToDeductTaxresponseStruct(
        section: deserializeParam(
          data['section'],
          ParamType.String,
          false,
        ),
        natureOfPayment: deserializeParam(
          data['natureOfPayment'],
          ParamType.String,
          false,
        ),
        totalAmountPaid: deserializeParam(
          data['totalAmountPaid'],
          ParamType.int,
          false,
        ),
        totalTaxAmountDeductible: deserializeParam(
          data['totalTaxAmountDeductible'],
          ParamType.int,
          false,
        ),
        totalTaxDeducted: deserializeParam(
          data['totalTaxDeducted'],
          ParamType.int,
          false,
        ),
        amountSd: deserializeParam(
          data['amountSd'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'FailureToDeductTaxresponseStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FailureToDeductTaxresponseStruct &&
        section == other.section &&
        natureOfPayment == other.natureOfPayment &&
        totalAmountPaid == other.totalAmountPaid &&
        totalTaxAmountDeductible == other.totalTaxAmountDeductible &&
        totalTaxDeducted == other.totalTaxDeducted &&
        amountSd == other.amountSd;
  }

  @override
  int get hashCode => const ListEquality().hash([
        section,
        natureOfPayment,
        totalAmountPaid,
        totalTaxAmountDeductible,
        totalTaxDeducted,
        amountSd
      ]);
}

FailureToDeductTaxresponseStruct createFailureToDeductTaxresponseStruct({
  String? section,
  String? natureOfPayment,
  int? totalAmountPaid,
  int? totalTaxAmountDeductible,
  int? totalTaxDeducted,
  int? amountSd,
}) =>
    FailureToDeductTaxresponseStruct(
      section: section,
      natureOfPayment: natureOfPayment,
      totalAmountPaid: totalAmountPaid,
      totalTaxAmountDeductible: totalTaxAmountDeductible,
      totalTaxDeducted: totalTaxDeducted,
      amountSd: amountSd,
    );
