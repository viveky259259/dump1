// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UploadFileDetailsStruct extends BaseStruct {
  UploadFileDetailsStruct({
    String? fileName,
    String? filePath,
    int? status,
    String? message,
  })  : _fileName = fileName,
        _filePath = filePath,
        _status = status,
        _message = message;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "filePath" field.
  String? _filePath;
  String get filePath => _filePath ?? '';
  set filePath(String? val) => _filePath = val;

  bool hasFilePath() => _filePath != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  static UploadFileDetailsStruct fromMap(Map<String, dynamic> data) =>
      UploadFileDetailsStruct(
        fileName: data['fileName'] as String?,
        filePath: data['filePath'] as String?,
        status: castToType<int>(data['status']),
        message: data['message'] as String?,
      );

  static UploadFileDetailsStruct? maybeFromMap(dynamic data) => data is Map
      ? UploadFileDetailsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
        'filePath': _filePath,
        'status': _status,
        'message': _message,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'filePath': serializeParam(
          _filePath,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
      }.withoutNulls;

  static UploadFileDetailsStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      UploadFileDetailsStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        filePath: deserializeParam(
          data['filePath'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'UploadFileDetailsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UploadFileDetailsStruct &&
        fileName == other.fileName &&
        filePath == other.filePath &&
        status == other.status &&
        message == other.message;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([fileName, filePath, status, message]);
}

UploadFileDetailsStruct createUploadFileDetailsStruct({
  String? fileName,
  String? filePath,
  int? status,
  String? message,
}) =>
    UploadFileDetailsStruct(
      fileName: fileName,
      filePath: filePath,
      status: status,
      message: message,
    );
