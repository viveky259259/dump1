// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SectionDataStruct extends BaseStruct {
  SectionDataStruct({
    String? code,
    List<SectionDetailStruct>? detail,
    String? title,
    int? status,
  })  : _code = code,
        _detail = detail,
        _title = title,
        _status = status;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "detail" field.
  List<SectionDetailStruct>? _detail;
  List<SectionDetailStruct> get detail => _detail ?? const [];
  set detail(List<SectionDetailStruct>? val) => _detail = val;

  void updateDetail(Function(List<SectionDetailStruct>) updateFn) {
    updateFn(_detail ??= []);
  }

  bool hasDetail() => _detail != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  static SectionDataStruct fromMap(Map<String, dynamic> data) =>
      SectionDataStruct(
        code: data['code'] as String?,
        detail: getStructList(
          data['detail'],
          SectionDetailStruct.fromMap,
        ),
        title: data['title'] as String?,
        status: castToType<int>(data['status']),
      );

  static SectionDataStruct? maybeFromMap(dynamic data) => data is Map
      ? SectionDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'code': _code,
        'detail': _detail?.map((e) => e.toMap()).toList(),
        'title': _title,
        'status': _status,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'detail': serializeParam(
          _detail,
          ParamType.DataStruct,
          isList: true,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
      }.withoutNulls;

  static SectionDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      SectionDataStruct(
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        detail: deserializeStructParam<SectionDetailStruct>(
          data['detail'],
          ParamType.DataStruct,
          true,
          structBuilder: SectionDetailStruct.fromSerializableMap,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'SectionDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is SectionDataStruct &&
        code == other.code &&
        listEquality.equals(detail, other.detail) &&
        title == other.title &&
        status == other.status;
  }

  @override
  int get hashCode => const ListEquality().hash([code, detail, title, status]);
}

SectionDataStruct createSectionDataStruct({
  String? code,
  String? title,
  int? status,
}) =>
    SectionDataStruct(
      code: code,
      title: title,
      status: status,
    );
