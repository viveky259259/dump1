// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AddressDetailsStruct extends BaseStruct {
  AddressDetailsStruct({
    String? addressLine,
    String? state,
    String? pinCode,
  })  : _addressLine = addressLine,
        _state = state,
        _pinCode = pinCode;

  // "addressLine" field.
  String? _addressLine;
  String get addressLine => _addressLine ?? '';
  set addressLine(String? val) => _addressLine = val;

  bool hasAddressLine() => _addressLine != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "pinCode" field.
  String? _pinCode;
  String get pinCode => _pinCode ?? '';
  set pinCode(String? val) => _pinCode = val;

  bool hasPinCode() => _pinCode != null;

  static AddressDetailsStruct fromMap(Map<String, dynamic> data) =>
      AddressDetailsStruct(
        addressLine: data['addressLine'] as String?,
        state: data['state'] as String?,
        pinCode: data['pinCode'] as String?,
      );

  static AddressDetailsStruct? maybeFromMap(dynamic data) => data is Map
      ? AddressDetailsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'addressLine': _addressLine,
        'state': _state,
        'pinCode': _pinCode,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'addressLine': serializeParam(
          _addressLine,
          ParamType.String,
        ),
        'state': serializeParam(
          _state,
          ParamType.String,
        ),
        'pinCode': serializeParam(
          _pinCode,
          ParamType.String,
        ),
      }.withoutNulls;

  static AddressDetailsStruct fromSerializableMap(Map<String, dynamic> data) =>
      AddressDetailsStruct(
        addressLine: deserializeParam(
          data['addressLine'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['state'],
          ParamType.String,
          false,
        ),
        pinCode: deserializeParam(
          data['pinCode'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'AddressDetailsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AddressDetailsStruct &&
        addressLine == other.addressLine &&
        state == other.state &&
        pinCode == other.pinCode;
  }

  @override
  int get hashCode => const ListEquality().hash([addressLine, state, pinCode]);
}

AddressDetailsStruct createAddressDetailsStruct({
  String? addressLine,
  String? state,
  String? pinCode,
}) =>
    AddressDetailsStruct(
      addressLine: addressLine,
      state: state,
      pinCode: pinCode,
    );
