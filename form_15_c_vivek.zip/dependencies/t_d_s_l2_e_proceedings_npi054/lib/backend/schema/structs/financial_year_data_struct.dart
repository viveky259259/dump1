// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FinancialYearDataStruct extends BaseStruct {
  FinancialYearDataStruct({
    String? code,
    String? id,
    List<FinancialYearDetailStruct>? detail,
    String? title,
    int? status,
  })  : _code = code,
        _id = id,
        _detail = detail,
        _title = title,
        _status = status;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  set id(String? val) => _id = val;

  bool hasId() => _id != null;

  // "detail" field.
  List<FinancialYearDetailStruct>? _detail;
  List<FinancialYearDetailStruct> get detail => _detail ?? const [];
  set detail(List<FinancialYearDetailStruct>? val) => _detail = val;

  void updateDetail(Function(List<FinancialYearDetailStruct>) updateFn) {
    updateFn(_detail ??= []);
  }

  bool hasDetail() => _detail != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  static FinancialYearDataStruct fromMap(Map<String, dynamic> data) =>
      FinancialYearDataStruct(
        code: data['code'] as String?,
        id: data['id'] as String?,
        detail: getStructList(
          data['detail'],
          FinancialYearDetailStruct.fromMap,
        ),
        title: data['title'] as String?,
        status: castToType<int>(data['status']),
      );

  static FinancialYearDataStruct? maybeFromMap(dynamic data) => data is Map
      ? FinancialYearDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'code': _code,
        'id': _id,
        'detail': _detail?.map((e) => e.toMap()).toList(),
        'title': _title,
        'status': _status,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'id': serializeParam(
          _id,
          ParamType.String,
        ),
        'detail': serializeParam(
          _detail,
          ParamType.DataStruct,
          isList: true,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
      }.withoutNulls;

  static FinancialYearDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FinancialYearDataStruct(
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        id: deserializeParam(
          data['id'],
          ParamType.String,
          false,
        ),
        detail: deserializeStructParam<FinancialYearDetailStruct>(
          data['detail'],
          ParamType.DataStruct,
          true,
          structBuilder: FinancialYearDetailStruct.fromSerializableMap,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'FinancialYearDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FinancialYearDataStruct &&
        code == other.code &&
        id == other.id &&
        listEquality.equals(detail, other.detail) &&
        title == other.title &&
        status == other.status;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([code, id, detail, title, status]);
}

FinancialYearDataStruct createFinancialYearDataStruct({
  String? code,
  String? id,
  String? title,
  int? status,
}) =>
    FinancialYearDataStruct(
      code: code,
      id: id,
      title: title,
      status: status,
    );
