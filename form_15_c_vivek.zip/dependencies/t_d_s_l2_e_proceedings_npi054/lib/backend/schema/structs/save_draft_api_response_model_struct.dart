// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SaveDraftApiResponseModelStruct extends BaseStruct {
  SaveDraftApiResponseModelStruct({
    List<SaveDraftdataStruct>? data,
    List<String>? error,
  })  : _data = data,
        _error = error;

  // "data" field.
  List<SaveDraftdataStruct>? _data;
  List<SaveDraftdataStruct> get data => _data ?? const [];
  set data(List<SaveDraftdataStruct>? val) => _data = val;

  void updateData(Function(List<SaveDraftdataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "error" field.
  List<String>? _error;
  List<String> get error => _error ?? const [];
  set error(List<String>? val) => _error = val;

  void updateError(Function(List<String>) updateFn) {
    updateFn(_error ??= []);
  }

  bool hasError() => _error != null;

  static SaveDraftApiResponseModelStruct fromMap(Map<String, dynamic> data) =>
      SaveDraftApiResponseModelStruct(
        data: getStructList(
          data['data'],
          SaveDraftdataStruct.fromMap,
        ),
        error: getDataList(data['error']),
      );

  static SaveDraftApiResponseModelStruct? maybeFromMap(dynamic data) => data
          is Map
      ? SaveDraftApiResponseModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'error': _error,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'error': serializeParam(
          _error,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static SaveDraftApiResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      SaveDraftApiResponseModelStruct(
        data: deserializeStructParam<SaveDraftdataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: SaveDraftdataStruct.fromSerializableMap,
        ),
        error: deserializeParam<String>(
          data['error'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'SaveDraftApiResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is SaveDraftApiResponseModelStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(error, other.error);
  }

  @override
  int get hashCode => const ListEquality().hash([data, error]);
}

SaveDraftApiResponseModelStruct createSaveDraftApiResponseModelStruct() =>
    SaveDraftApiResponseModelStruct();
