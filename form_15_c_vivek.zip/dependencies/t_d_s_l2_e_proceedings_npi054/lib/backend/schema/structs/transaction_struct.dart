// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TransactionStruct extends BaseStruct {
  TransactionStruct({
    String? deducteePan,
    String? deducteeName,
    double? amtPaidCredited,
    DateTime? dateOfPaymentCredit,
    String? section,
    String? natureOfPayment,
    double? taxAmtDeductibleCollectible,
    double? taxAmtDeductedCollected,
    DateTime? dateOfDeduction,
    double? shortNonDeductionCollection,
    double? tdsTcsDeposited,
    DateTime? dateOfDeposit,
    double? shortNonPaymentTdsTcs,
  })  : _deducteePan = deducteePan,
        _deducteeName = deducteeName,
        _amtPaidCredited = amtPaidCredited,
        _dateOfPaymentCredit = dateOfPaymentCredit,
        _section = section,
        _natureOfPayment = natureOfPayment,
        _taxAmtDeductibleCollectible = taxAmtDeductibleCollectible,
        _taxAmtDeductedCollected = taxAmtDeductedCollected,
        _dateOfDeduction = dateOfDeduction,
        _shortNonDeductionCollection = shortNonDeductionCollection,
        _tdsTcsDeposited = tdsTcsDeposited,
        _dateOfDeposit = dateOfDeposit,
        _shortNonPaymentTdsTcs = shortNonPaymentTdsTcs;

  // "deducteePan" field.
  String? _deducteePan;
  String get deducteePan => _deducteePan ?? '';
  set deducteePan(String? val) => _deducteePan = val;

  bool hasDeducteePan() => _deducteePan != null;

  // "deducteeName" field.
  String? _deducteeName;
  String get deducteeName => _deducteeName ?? '';
  set deducteeName(String? val) => _deducteeName = val;

  bool hasDeducteeName() => _deducteeName != null;

  // "amtPaidCredited" field.
  double? _amtPaidCredited;
  double get amtPaidCredited => _amtPaidCredited ?? 0.0;
  set amtPaidCredited(double? val) => _amtPaidCredited = val;

  void incrementAmtPaidCredited(double amount) =>
      amtPaidCredited = amtPaidCredited + amount;

  bool hasAmtPaidCredited() => _amtPaidCredited != null;

  // "dateOfPaymentCredit" field.
  DateTime? _dateOfPaymentCredit;
  DateTime? get dateOfPaymentCredit => _dateOfPaymentCredit;
  set dateOfPaymentCredit(DateTime? val) => _dateOfPaymentCredit = val;

  bool hasDateOfPaymentCredit() => _dateOfPaymentCredit != null;

  // "section" field.
  String? _section;
  String get section => _section ?? '';
  set section(String? val) => _section = val;

  bool hasSection() => _section != null;

  // "natureOfPayment" field.
  String? _natureOfPayment;
  String get natureOfPayment => _natureOfPayment ?? '';
  set natureOfPayment(String? val) => _natureOfPayment = val;

  bool hasNatureOfPayment() => _natureOfPayment != null;

  // "taxAmtDeductibleCollectible" field.
  double? _taxAmtDeductibleCollectible;
  double get taxAmtDeductibleCollectible => _taxAmtDeductibleCollectible ?? 0.0;
  set taxAmtDeductibleCollectible(double? val) =>
      _taxAmtDeductibleCollectible = val;

  void incrementTaxAmtDeductibleCollectible(double amount) =>
      taxAmtDeductibleCollectible = taxAmtDeductibleCollectible + amount;

  bool hasTaxAmtDeductibleCollectible() => _taxAmtDeductibleCollectible != null;

  // "taxAmtDeductedCollected" field.
  double? _taxAmtDeductedCollected;
  double get taxAmtDeductedCollected => _taxAmtDeductedCollected ?? 0.0;
  set taxAmtDeductedCollected(double? val) => _taxAmtDeductedCollected = val;

  void incrementTaxAmtDeductedCollected(double amount) =>
      taxAmtDeductedCollected = taxAmtDeductedCollected + amount;

  bool hasTaxAmtDeductedCollected() => _taxAmtDeductedCollected != null;

  // "dateOfDeduction" field.
  DateTime? _dateOfDeduction;
  DateTime? get dateOfDeduction => _dateOfDeduction;
  set dateOfDeduction(DateTime? val) => _dateOfDeduction = val;

  bool hasDateOfDeduction() => _dateOfDeduction != null;

  // "shortNonDeductionCollection" field.
  double? _shortNonDeductionCollection;
  double get shortNonDeductionCollection => _shortNonDeductionCollection ?? 0.0;
  set shortNonDeductionCollection(double? val) =>
      _shortNonDeductionCollection = val;

  void incrementShortNonDeductionCollection(double amount) =>
      shortNonDeductionCollection = shortNonDeductionCollection + amount;

  bool hasShortNonDeductionCollection() => _shortNonDeductionCollection != null;

  // "tdsTcsDeposited" field.
  double? _tdsTcsDeposited;
  double get tdsTcsDeposited => _tdsTcsDeposited ?? 0.0;
  set tdsTcsDeposited(double? val) => _tdsTcsDeposited = val;

  void incrementTdsTcsDeposited(double amount) =>
      tdsTcsDeposited = tdsTcsDeposited + amount;

  bool hasTdsTcsDeposited() => _tdsTcsDeposited != null;

  // "dateOfDeposit" field.
  DateTime? _dateOfDeposit;
  DateTime? get dateOfDeposit => _dateOfDeposit;
  set dateOfDeposit(DateTime? val) => _dateOfDeposit = val;

  bool hasDateOfDeposit() => _dateOfDeposit != null;

  // "shortNonPaymentTdsTcs" field.
  double? _shortNonPaymentTdsTcs;
  double get shortNonPaymentTdsTcs => _shortNonPaymentTdsTcs ?? 0.0;
  set shortNonPaymentTdsTcs(double? val) => _shortNonPaymentTdsTcs = val;

  void incrementShortNonPaymentTdsTcs(double amount) =>
      shortNonPaymentTdsTcs = shortNonPaymentTdsTcs + amount;

  bool hasShortNonPaymentTdsTcs() => _shortNonPaymentTdsTcs != null;

  static TransactionStruct fromMap(Map<String, dynamic> data) =>
      TransactionStruct(
        deducteePan: data['deducteePan'] as String?,
        deducteeName: data['deducteeName'] as String?,
        amtPaidCredited: castToType<double>(data['amtPaidCredited']),
        dateOfPaymentCredit: data['dateOfPaymentCredit'] as DateTime?,
        section: data['section'] as String?,
        natureOfPayment: data['natureOfPayment'] as String?,
        taxAmtDeductibleCollectible:
            castToType<double>(data['taxAmtDeductibleCollectible']),
        taxAmtDeductedCollected:
            castToType<double>(data['taxAmtDeductedCollected']),
        dateOfDeduction: data['dateOfDeduction'] as DateTime?,
        shortNonDeductionCollection:
            castToType<double>(data['shortNonDeductionCollection']),
        tdsTcsDeposited: castToType<double>(data['tdsTcsDeposited']),
        dateOfDeposit: data['dateOfDeposit'] as DateTime?,
        shortNonPaymentTdsTcs:
            castToType<double>(data['shortNonPaymentTdsTcs']),
      );

  static TransactionStruct? maybeFromMap(dynamic data) => data is Map
      ? TransactionStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'deducteePan': _deducteePan,
        'deducteeName': _deducteeName,
        'amtPaidCredited': _amtPaidCredited,
        'dateOfPaymentCredit': _dateOfPaymentCredit,
        'section': _section,
        'natureOfPayment': _natureOfPayment,
        'taxAmtDeductibleCollectible': _taxAmtDeductibleCollectible,
        'taxAmtDeductedCollected': _taxAmtDeductedCollected,
        'dateOfDeduction': _dateOfDeduction,
        'shortNonDeductionCollection': _shortNonDeductionCollection,
        'tdsTcsDeposited': _tdsTcsDeposited,
        'dateOfDeposit': _dateOfDeposit,
        'shortNonPaymentTdsTcs': _shortNonPaymentTdsTcs,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'deducteePan': serializeParam(
          _deducteePan,
          ParamType.String,
        ),
        'deducteeName': serializeParam(
          _deducteeName,
          ParamType.String,
        ),
        'amtPaidCredited': serializeParam(
          _amtPaidCredited,
          ParamType.double,
        ),
        'dateOfPaymentCredit': serializeParam(
          _dateOfPaymentCredit,
          ParamType.DateTime,
        ),
        'section': serializeParam(
          _section,
          ParamType.String,
        ),
        'natureOfPayment': serializeParam(
          _natureOfPayment,
          ParamType.String,
        ),
        'taxAmtDeductibleCollectible': serializeParam(
          _taxAmtDeductibleCollectible,
          ParamType.double,
        ),
        'taxAmtDeductedCollected': serializeParam(
          _taxAmtDeductedCollected,
          ParamType.double,
        ),
        'dateOfDeduction': serializeParam(
          _dateOfDeduction,
          ParamType.DateTime,
        ),
        'shortNonDeductionCollection': serializeParam(
          _shortNonDeductionCollection,
          ParamType.double,
        ),
        'tdsTcsDeposited': serializeParam(
          _tdsTcsDeposited,
          ParamType.double,
        ),
        'dateOfDeposit': serializeParam(
          _dateOfDeposit,
          ParamType.DateTime,
        ),
        'shortNonPaymentTdsTcs': serializeParam(
          _shortNonPaymentTdsTcs,
          ParamType.double,
        ),
      }.withoutNulls;

  static TransactionStruct fromSerializableMap(Map<String, dynamic> data) =>
      TransactionStruct(
        deducteePan: deserializeParam(
          data['deducteePan'],
          ParamType.String,
          false,
        ),
        deducteeName: deserializeParam(
          data['deducteeName'],
          ParamType.String,
          false,
        ),
        amtPaidCredited: deserializeParam(
          data['amtPaidCredited'],
          ParamType.double,
          false,
        ),
        dateOfPaymentCredit: deserializeParam(
          data['dateOfPaymentCredit'],
          ParamType.DateTime,
          false,
        ),
        section: deserializeParam(
          data['section'],
          ParamType.String,
          false,
        ),
        natureOfPayment: deserializeParam(
          data['natureOfPayment'],
          ParamType.String,
          false,
        ),
        taxAmtDeductibleCollectible: deserializeParam(
          data['taxAmtDeductibleCollectible'],
          ParamType.double,
          false,
        ),
        taxAmtDeductedCollected: deserializeParam(
          data['taxAmtDeductedCollected'],
          ParamType.double,
          false,
        ),
        dateOfDeduction: deserializeParam(
          data['dateOfDeduction'],
          ParamType.DateTime,
          false,
        ),
        shortNonDeductionCollection: deserializeParam(
          data['shortNonDeductionCollection'],
          ParamType.double,
          false,
        ),
        tdsTcsDeposited: deserializeParam(
          data['tdsTcsDeposited'],
          ParamType.double,
          false,
        ),
        dateOfDeposit: deserializeParam(
          data['dateOfDeposit'],
          ParamType.DateTime,
          false,
        ),
        shortNonPaymentTdsTcs: deserializeParam(
          data['shortNonPaymentTdsTcs'],
          ParamType.double,
          false,
        ),
      );

  @override
  String toString() => 'TransactionStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is TransactionStruct &&
        deducteePan == other.deducteePan &&
        deducteeName == other.deducteeName &&
        amtPaidCredited == other.amtPaidCredited &&
        dateOfPaymentCredit == other.dateOfPaymentCredit &&
        section == other.section &&
        natureOfPayment == other.natureOfPayment &&
        taxAmtDeductibleCollectible == other.taxAmtDeductibleCollectible &&
        taxAmtDeductedCollected == other.taxAmtDeductedCollected &&
        dateOfDeduction == other.dateOfDeduction &&
        shortNonDeductionCollection == other.shortNonDeductionCollection &&
        tdsTcsDeposited == other.tdsTcsDeposited &&
        dateOfDeposit == other.dateOfDeposit &&
        shortNonPaymentTdsTcs == other.shortNonPaymentTdsTcs;
  }

  @override
  int get hashCode => const ListEquality().hash([
        deducteePan,
        deducteeName,
        amtPaidCredited,
        dateOfPaymentCredit,
        section,
        natureOfPayment,
        taxAmtDeductibleCollectible,
        taxAmtDeductedCollected,
        dateOfDeduction,
        shortNonDeductionCollection,
        tdsTcsDeposited,
        dateOfDeposit,
        shortNonPaymentTdsTcs
      ]);
}

TransactionStruct createTransactionStruct({
  String? deducteePan,
  String? deducteeName,
  double? amtPaidCredited,
  DateTime? dateOfPaymentCredit,
  String? section,
  String? natureOfPayment,
  double? taxAmtDeductibleCollectible,
  double? taxAmtDeductedCollected,
  DateTime? dateOfDeduction,
  double? shortNonDeductionCollection,
  double? tdsTcsDeposited,
  DateTime? dateOfDeposit,
  double? shortNonPaymentTdsTcs,
}) =>
    TransactionStruct(
      deducteePan: deducteePan,
      deducteeName: deducteeName,
      amtPaidCredited: amtPaidCredited,
      dateOfPaymentCredit: dateOfPaymentCredit,
      section: section,
      natureOfPayment: natureOfPayment,
      taxAmtDeductibleCollectible: taxAmtDeductibleCollectible,
      taxAmtDeductedCollected: taxAmtDeductedCollected,
      dateOfDeduction: dateOfDeduction,
      shortNonDeductionCollection: shortNonDeductionCollection,
      tdsTcsDeposited: tdsTcsDeposited,
      dateOfDeposit: dateOfDeposit,
      shortNonPaymentTdsTcs: shortNonPaymentTdsTcs,
    );
