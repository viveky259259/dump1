// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SearchCriteriaStruct extends BaseStruct {
  SearchCriteriaStruct({
    String? tanPan,
    String? name,
    String? financialYear,
  })  : _tanPan = tanPan,
        _name = name,
        _financialYear = financialYear;

  // "tanPan" field.
  String? _tanPan;
  String get tanPan => _tanPan ?? '';
  set tanPan(String? val) => _tanPan = val;

  bool hasTanPan() => _tanPan != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "financialYear" field.
  String? _financialYear;
  String get financialYear => _financialYear ?? '';
  set financialYear(String? val) => _financialYear = val;

  bool hasFinancialYear() => _financialYear != null;

  static SearchCriteriaStruct fromMap(Map<String, dynamic> data) =>
      SearchCriteriaStruct(
        tanPan: data['tanPan'] as String?,
        name: data['name'] as String?,
        financialYear: data['financialYear'] as String?,
      );

  static SearchCriteriaStruct? maybeFromMap(dynamic data) => data is Map
      ? SearchCriteriaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'tanPan': _tanPan,
        'name': _name,
        'financialYear': _financialYear,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'tanPan': serializeParam(
          _tanPan,
          ParamType.String,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'financialYear': serializeParam(
          _financialYear,
          ParamType.String,
        ),
      }.withoutNulls;

  static SearchCriteriaStruct fromSerializableMap(Map<String, dynamic> data) =>
      SearchCriteriaStruct(
        tanPan: deserializeParam(
          data['tanPan'],
          ParamType.String,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        financialYear: deserializeParam(
          data['financialYear'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SearchCriteriaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SearchCriteriaStruct &&
        tanPan == other.tanPan &&
        name == other.name &&
        financialYear == other.financialYear;
  }

  @override
  int get hashCode => const ListEquality().hash([tanPan, name, financialYear]);
}

SearchCriteriaStruct createSearchCriteriaStruct({
  String? tanPan,
  String? name,
  String? financialYear,
}) =>
    SearchCriteriaStruct(
      tanPan: tanPan,
      name: name,
      financialYear: financialYear,
    );
