// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FailureToDeductApiResponseModelStruct extends BaseStruct {
  FailureToDeductApiResponseModelStruct({
    List<FailureToDeductdataStruct>? data,
    List<String>? error,
  })  : _data = data,
        _error = error;

  // "data" field.
  List<FailureToDeductdataStruct>? _data;
  List<FailureToDeductdataStruct> get data => _data ?? const [];
  set data(List<FailureToDeductdataStruct>? val) => _data = val;

  void updateData(Function(List<FailureToDeductdataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "error" field.
  List<String>? _error;
  List<String> get error => _error ?? const [];
  set error(List<String>? val) => _error = val;

  void updateError(Function(List<String>) updateFn) {
    updateFn(_error ??= []);
  }

  bool hasError() => _error != null;

  static FailureToDeductApiResponseModelStruct fromMap(
          Map<String, dynamic> data) =>
      FailureToDeductApiResponseModelStruct(
        data: getStructList(
          data['data'],
          FailureToDeductdataStruct.fromMap,
        ),
        error: getDataList(data['error']),
      );

  static FailureToDeductApiResponseModelStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? FailureToDeductApiResponseModelStruct.fromMap(
              data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'error': _error,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'error': serializeParam(
          _error,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static FailureToDeductApiResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FailureToDeductApiResponseModelStruct(
        data: deserializeStructParam<FailureToDeductdataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: FailureToDeductdataStruct.fromSerializableMap,
        ),
        error: deserializeParam<String>(
          data['error'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'FailureToDeductApiResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FailureToDeductApiResponseModelStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(error, other.error);
  }

  @override
  int get hashCode => const ListEquality().hash([data, error]);
}

FailureToDeductApiResponseModelStruct
    createFailureToDeductApiResponseModelStruct() =>
        FailureToDeductApiResponseModelStruct();
