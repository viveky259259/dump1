// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ErrorSchemaStruct extends BaseStruct {
  ErrorSchemaStruct({
    int? status,
    String? code,
    String? title,
    String? detail,
  })  : _status = status,
        _code = code,
        _title = title,
        _detail = detail;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "detail" field.
  String? _detail;
  String get detail => _detail ?? '';
  set detail(String? val) => _detail = val;

  bool hasDetail() => _detail != null;

  static ErrorSchemaStruct fromMap(Map<String, dynamic> data) =>
      ErrorSchemaStruct(
        status: castToType<int>(data['status']),
        code: data['code'] as String?,
        title: data['title'] as String?,
        detail: data['detail'] as String?,
      );

  static ErrorSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? ErrorSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'status': _status,
        'code': _code,
        'title': _title,
        'detail': _detail,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'detail': serializeParam(
          _detail,
          ParamType.String,
        ),
      }.withoutNulls;

  static ErrorSchemaStruct fromSerializableMap(Map<String, dynamic> data) =>
      ErrorSchemaStruct(
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        detail: deserializeParam(
          data['detail'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'ErrorSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ErrorSchemaStruct &&
        status == other.status &&
        code == other.code &&
        title == other.title &&
        detail == other.detail;
  }

  @override
  int get hashCode => const ListEquality().hash([status, code, title, detail]);
}

ErrorSchemaStruct createErrorSchemaStruct({
  int? status,
  String? code,
  String? title,
  String? detail,
}) =>
    ErrorSchemaStruct(
      status: status,
      code: code,
      title: title,
      detail: detail,
    );
