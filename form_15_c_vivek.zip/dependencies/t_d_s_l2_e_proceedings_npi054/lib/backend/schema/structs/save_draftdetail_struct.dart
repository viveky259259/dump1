// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SaveDraftdetailStruct extends BaseStruct {
  SaveDraftdetailStruct({
    List<SaveDraftresponseStruct>? response,
  }) : _response = response;

  // "response" field.
  List<SaveDraftresponseStruct>? _response;
  List<SaveDraftresponseStruct> get response => _response ?? const [];
  set response(List<SaveDraftresponseStruct>? val) => _response = val;

  void updateResponse(Function(List<SaveDraftresponseStruct>) updateFn) {
    updateFn(_response ??= []);
  }

  bool hasResponse() => _response != null;

  static SaveDraftdetailStruct fromMap(Map<String, dynamic> data) =>
      SaveDraftdetailStruct(
        response: getStructList(
          data['response'],
          SaveDraftresponseStruct.fromMap,
        ),
      );

  static SaveDraftdetailStruct? maybeFromMap(dynamic data) => data is Map
      ? SaveDraftdetailStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'response': _response?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'response': serializeParam(
          _response,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static SaveDraftdetailStruct fromSerializableMap(Map<String, dynamic> data) =>
      SaveDraftdetailStruct(
        response: deserializeStructParam<SaveDraftresponseStruct>(
          data['response'],
          ParamType.DataStruct,
          true,
          structBuilder: SaveDraftresponseStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'SaveDraftdetailStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is SaveDraftdetailStruct &&
        listEquality.equals(response, other.response);
  }

  @override
  int get hashCode => const ListEquality().hash([response]);
}

SaveDraftdetailStruct createSaveDraftdetailStruct() => SaveDraftdetailStruct();
