// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetSectionSchemaStruct extends BaseStruct {
  GetSectionSchemaStruct({
    List<SectionDataStruct>? data,
    List<ErrorSchemaStruct>? errors,
  })  : _data = data,
        _errors = errors;

  // "data" field.
  List<SectionDataStruct>? _data;
  List<SectionDataStruct> get data => _data ?? const [];
  set data(List<SectionDataStruct>? val) => _data = val;

  void updateData(Function(List<SectionDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "errors" field.
  List<ErrorSchemaStruct>? _errors;
  List<ErrorSchemaStruct> get errors => _errors ?? const [];
  set errors(List<ErrorSchemaStruct>? val) => _errors = val;

  void updateErrors(Function(List<ErrorSchemaStruct>) updateFn) {
    updateFn(_errors ??= []);
  }

  bool hasErrors() => _errors != null;

  static GetSectionSchemaStruct fromMap(Map<String, dynamic> data) =>
      GetSectionSchemaStruct(
        data: getStructList(
          data['data'],
          SectionDataStruct.fromMap,
        ),
        errors: getStructList(
          data['errors'],
          ErrorSchemaStruct.fromMap,
        ),
      );

  static GetSectionSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? GetSectionSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'errors': _errors?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'errors': serializeParam(
          _errors,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static GetSectionSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      GetSectionSchemaStruct(
        data: deserializeStructParam<SectionDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: SectionDataStruct.fromSerializableMap,
        ),
        errors: deserializeStructParam<ErrorSchemaStruct>(
          data['errors'],
          ParamType.DataStruct,
          true,
          structBuilder: ErrorSchemaStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'GetSectionSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GetSectionSchemaStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(errors, other.errors);
  }

  @override
  int get hashCode => const ListEquality().hash([data, errors]);
}

GetSectionSchemaStruct createGetSectionSchemaStruct() =>
    GetSectionSchemaStruct();
