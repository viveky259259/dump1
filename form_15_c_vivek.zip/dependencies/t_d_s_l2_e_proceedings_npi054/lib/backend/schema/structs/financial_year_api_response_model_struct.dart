// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FinancialYearApiResponseModelStruct extends BaseStruct {
  FinancialYearApiResponseModelStruct({
    List<FinancialYearDataStruct>? data,
    List<String>? errors,
  })  : _data = data,
        _errors = errors;

  // "data" field.
  List<FinancialYearDataStruct>? _data;
  List<FinancialYearDataStruct> get data => _data ?? const [];
  set data(List<FinancialYearDataStruct>? val) => _data = val;

  void updateData(Function(List<FinancialYearDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "errors" field.
  List<String>? _errors;
  List<String> get errors => _errors ?? const [];
  set errors(List<String>? val) => _errors = val;

  void updateErrors(Function(List<String>) updateFn) {
    updateFn(_errors ??= []);
  }

  bool hasErrors() => _errors != null;

  static FinancialYearApiResponseModelStruct fromMap(
          Map<String, dynamic> data) =>
      FinancialYearApiResponseModelStruct(
        data: getStructList(
          data['data'],
          FinancialYearDataStruct.fromMap,
        ),
        errors: getDataList(data['errors']),
      );

  static FinancialYearApiResponseModelStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? FinancialYearApiResponseModelStruct.fromMap(
              data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'errors': _errors,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'errors': serializeParam(
          _errors,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static FinancialYearApiResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FinancialYearApiResponseModelStruct(
        data: deserializeStructParam<FinancialYearDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: FinancialYearDataStruct.fromSerializableMap,
        ),
        errors: deserializeParam<String>(
          data['errors'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'FinancialYearApiResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FinancialYearApiResponseModelStruct &&
        listEquality.equals(data, other.data) &&
        listEquality.equals(errors, other.errors);
  }

  @override
  int get hashCode => const ListEquality().hash([data, errors]);
}

FinancialYearApiResponseModelStruct
    createFinancialYearApiResponseModelStruct() =>
        FinancialYearApiResponseModelStruct();
