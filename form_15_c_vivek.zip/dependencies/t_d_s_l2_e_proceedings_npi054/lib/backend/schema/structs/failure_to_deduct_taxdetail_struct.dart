// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FailureToDeductTaxdetailStruct extends BaseStruct {
  FailureToDeductTaxdetailStruct({
    List<FailureToDeductTaxresponseStruct>? response,
  }) : _response = response;

  // "response" field.
  List<FailureToDeductTaxresponseStruct>? _response;
  List<FailureToDeductTaxresponseStruct> get response => _response ?? const [];
  set response(List<FailureToDeductTaxresponseStruct>? val) => _response = val;

  void updateResponse(
      Function(List<FailureToDeductTaxresponseStruct>) updateFn) {
    updateFn(_response ??= []);
  }

  bool hasResponse() => _response != null;

  static FailureToDeductTaxdetailStruct fromMap(Map<String, dynamic> data) =>
      FailureToDeductTaxdetailStruct(
        response: getStructList(
          data['response'],
          FailureToDeductTaxresponseStruct.fromMap,
        ),
      );

  static FailureToDeductTaxdetailStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? FailureToDeductTaxdetailStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'response': _response?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'response': serializeParam(
          _response,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static FailureToDeductTaxdetailStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FailureToDeductTaxdetailStruct(
        response: deserializeStructParam<FailureToDeductTaxresponseStruct>(
          data['response'],
          ParamType.DataStruct,
          true,
          structBuilder: FailureToDeductTaxresponseStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'FailureToDeductTaxdetailStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FailureToDeductTaxdetailStruct &&
        listEquality.equals(response, other.response);
  }

  @override
  int get hashCode => const ListEquality().hash([response]);
}

FailureToDeductTaxdetailStruct createFailureToDeductTaxdetailStruct() =>
    FailureToDeductTaxdetailStruct();
