// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AllFileDataStruct extends BaseStruct {
  AllFileDataStruct({
    FileDataStruct? data,
  }) : _data = data;

  // "data" field.
  FileDataStruct? _data;
  FileDataStruct get data => _data ?? FileDataStruct();
  set data(FileDataStruct? val) => _data = val;

  void updateData(Function(FileDataStruct) updateFn) {
    updateFn(_data ??= FileDataStruct());
  }

  bool hasData() => _data != null;

  static AllFileDataStruct fromMap(Map<String, dynamic> data) =>
      AllFileDataStruct(
        data: data['data'] is FileDataStruct
            ? data['data']
            : FileDataStruct.maybeFromMap(data['data']),
      );

  static AllFileDataStruct? maybeFromMap(dynamic data) => data is Map
      ? AllFileDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static AllFileDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      AllFileDataStruct(
        data: deserializeStructParam(
          data['data'],
          ParamType.DataStruct,
          false,
          structBuilder: FileDataStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'AllFileDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AllFileDataStruct && data == other.data;
  }

  @override
  int get hashCode => const ListEquality().hash([data]);
}

AllFileDataStruct createAllFileDataStruct({
  FileDataStruct? data,
}) =>
    AllFileDataStruct(
      data: data ?? FileDataStruct(),
    );
