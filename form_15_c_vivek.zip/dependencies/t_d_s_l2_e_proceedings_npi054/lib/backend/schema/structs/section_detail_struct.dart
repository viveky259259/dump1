// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SectionDetailStruct extends BaseStruct {
  SectionDetailStruct({
    String? sectionCode,
    String? natureOfPayment,
  })  : _sectionCode = sectionCode,
        _natureOfPayment = natureOfPayment;

  // "sectionCode" field.
  String? _sectionCode;
  String get sectionCode => _sectionCode ?? '';
  set sectionCode(String? val) => _sectionCode = val;

  bool hasSectionCode() => _sectionCode != null;

  // "natureOfPayment" field.
  String? _natureOfPayment;
  String get natureOfPayment => _natureOfPayment ?? '';
  set natureOfPayment(String? val) => _natureOfPayment = val;

  bool hasNatureOfPayment() => _natureOfPayment != null;

  static SectionDetailStruct fromMap(Map<String, dynamic> data) =>
      SectionDetailStruct(
        sectionCode: data['sectionCode'] as String?,
        natureOfPayment: data['natureOfPayment'] as String?,
      );

  static SectionDetailStruct? maybeFromMap(dynamic data) => data is Map
      ? SectionDetailStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'sectionCode': _sectionCode,
        'natureOfPayment': _natureOfPayment,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'sectionCode': serializeParam(
          _sectionCode,
          ParamType.String,
        ),
        'natureOfPayment': serializeParam(
          _natureOfPayment,
          ParamType.String,
        ),
      }.withoutNulls;

  static SectionDetailStruct fromSerializableMap(Map<String, dynamic> data) =>
      SectionDetailStruct(
        sectionCode: deserializeParam(
          data['sectionCode'],
          ParamType.String,
          false,
        ),
        natureOfPayment: deserializeParam(
          data['natureOfPayment'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SectionDetailStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SectionDetailStruct &&
        sectionCode == other.sectionCode &&
        natureOfPayment == other.natureOfPayment;
  }

  @override
  int get hashCode => const ListEquality().hash([sectionCode, natureOfPayment]);
}

SectionDetailStruct createSectionDetailStruct({
  String? sectionCode,
  String? natureOfPayment,
}) =>
    SectionDetailStruct(
      sectionCode: sectionCode,
      natureOfPayment: natureOfPayment,
    );
