// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetNameSchemaStruct extends BaseStruct {
  GetNameSchemaStruct({
    List<NameDataStruct>? data,
    EmailAndNameErrorsStruct? error,
  })  : _data = data,
        _error = error;

  // "data" field.
  List<NameDataStruct>? _data;
  List<NameDataStruct> get data => _data ?? const [];
  set data(List<NameDataStruct>? val) => _data = val;

  void updateData(Function(List<NameDataStruct>) updateFn) {
    updateFn(_data ??= []);
  }

  bool hasData() => _data != null;

  // "error" field.
  EmailAndNameErrorsStruct? _error;
  EmailAndNameErrorsStruct get error => _error ?? EmailAndNameErrorsStruct();
  set error(EmailAndNameErrorsStruct? val) => _error = val;

  void updateError(Function(EmailAndNameErrorsStruct) updateFn) {
    updateFn(_error ??= EmailAndNameErrorsStruct());
  }

  bool hasError() => _error != null;

  static GetNameSchemaStruct fromMap(Map<String, dynamic> data) =>
      GetNameSchemaStruct(
        data: getStructList(
          data['data'],
          NameDataStruct.fromMap,
        ),
        error: data['error'] is EmailAndNameErrorsStruct
            ? data['error']
            : EmailAndNameErrorsStruct.maybeFromMap(data['error']),
      );

  static GetNameSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? GetNameSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'data': _data?.map((e) => e.toMap()).toList(),
        'error': _error?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
          isList: true,
        ),
        'error': serializeParam(
          _error,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static GetNameSchemaStruct fromSerializableMap(Map<String, dynamic> data) =>
      GetNameSchemaStruct(
        data: deserializeStructParam<NameDataStruct>(
          data['data'],
          ParamType.DataStruct,
          true,
          structBuilder: NameDataStruct.fromSerializableMap,
        ),
        error: deserializeStructParam(
          data['error'],
          ParamType.DataStruct,
          false,
          structBuilder: EmailAndNameErrorsStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'GetNameSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GetNameSchemaStruct &&
        listEquality.equals(data, other.data) &&
        error == other.error;
  }

  @override
  int get hashCode => const ListEquality().hash([data, error]);
}

GetNameSchemaStruct createGetNameSchemaStruct({
  EmailAndNameErrorsStruct? error,
}) =>
    GetNameSchemaStruct(
      error: error ?? EmailAndNameErrorsStruct(),
    );
