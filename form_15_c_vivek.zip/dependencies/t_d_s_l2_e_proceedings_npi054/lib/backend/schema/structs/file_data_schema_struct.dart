// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FileDataSchemaStruct extends BaseStruct {
  FileDataSchemaStruct({
    String? code,
    List<FileDataStruct>? detail,
    String? id,
    String? title,
    String? status,
  })  : _code = code,
        _detail = detail,
        _id = id,
        _title = title,
        _status = status;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "detail" field.
  List<FileDataStruct>? _detail;
  List<FileDataStruct> get detail => _detail ?? const [];
  set detail(List<FileDataStruct>? val) => _detail = val;

  void updateDetail(Function(List<FileDataStruct>) updateFn) {
    updateFn(_detail ??= []);
  }

  bool hasDetail() => _detail != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  set id(String? val) => _id = val;

  bool hasId() => _id != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  static FileDataSchemaStruct fromMap(Map<String, dynamic> data) =>
      FileDataSchemaStruct(
        code: data['code'] as String?,
        detail: getStructList(
          data['detail'],
          FileDataStruct.fromMap,
        ),
        id: data['id'] as String?,
        title: data['title'] as String?,
        status: data['status'] as String?,
      );

  static FileDataSchemaStruct? maybeFromMap(dynamic data) => data is Map
      ? FileDataSchemaStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'code': _code,
        'detail': _detail?.map((e) => e.toMap()).toList(),
        'id': _id,
        'title': _title,
        'status': _status,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'detail': serializeParam(
          _detail,
          ParamType.DataStruct,
          isList: true,
        ),
        'id': serializeParam(
          _id,
          ParamType.String,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
      }.withoutNulls;

  static FileDataSchemaStruct fromSerializableMap(Map<String, dynamic> data) =>
      FileDataSchemaStruct(
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        detail: deserializeStructParam<FileDataStruct>(
          data['detail'],
          ParamType.DataStruct,
          true,
          structBuilder: FileDataStruct.fromSerializableMap,
        ),
        id: deserializeParam(
          data['id'],
          ParamType.String,
          false,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FileDataSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FileDataSchemaStruct &&
        code == other.code &&
        listEquality.equals(detail, other.detail) &&
        id == other.id &&
        title == other.title &&
        status == other.status;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([code, detail, id, title, status]);
}

FileDataSchemaStruct createFileDataSchemaStruct({
  String? code,
  String? id,
  String? title,
  String? status,
}) =>
    FileDataSchemaStruct(
      code: code,
      id: id,
      title: title,
      status: status,
    );
