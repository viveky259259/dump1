// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SaveDataStruct extends BaseStruct {
  SaveDataStruct({
    String? code,
    String? id,
    String? detail,
    String? title,
    int? status,
  })  : _code = code,
        _id = id,
        _detail = detail,
        _title = title,
        _status = status;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  set id(String? val) => _id = val;

  bool hasId() => _id != null;

  // "detail" field.
  String? _detail;
  String get detail => _detail ?? '';
  set detail(String? val) => _detail = val;

  bool hasDetail() => _detail != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  static SaveDataStruct fromMap(Map<String, dynamic> data) => SaveDataStruct(
        code: data['code'] as String?,
        id: data['id'] as String?,
        detail: data['detail'] as String?,
        title: data['title'] as String?,
        status: castToType<int>(data['status']),
      );

  static SaveDataStruct? maybeFromMap(dynamic data) =>
      data is Map ? SaveDataStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'code': _code,
        'id': _id,
        'detail': _detail,
        'title': _title,
        'status': _status,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'id': serializeParam(
          _id,
          ParamType.String,
        ),
        'detail': serializeParam(
          _detail,
          ParamType.String,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
      }.withoutNulls;

  static SaveDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      SaveDataStruct(
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        id: deserializeParam(
          data['id'],
          ParamType.String,
          false,
        ),
        detail: deserializeParam(
          data['detail'],
          ParamType.String,
          false,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'SaveDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SaveDataStruct &&
        code == other.code &&
        id == other.id &&
        detail == other.detail &&
        title == other.title &&
        status == other.status;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([code, id, detail, title, status]);
}

SaveDataStruct createSaveDataStruct({
  String? code,
  String? id,
  String? detail,
  String? title,
  int? status,
}) =>
    SaveDataStruct(
      code: code,
      id: id,
      detail: detail,
      title: title,
      status: status,
    );
