// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NameDetailStruct extends BaseStruct {
  NameDetailStruct({
    String? name,
  }) : _name = name;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  static NameDetailStruct fromMap(Map<String, dynamic> data) =>
      NameDetailStruct(
        name: data['name'] as String?,
      );

  static NameDetailStruct? maybeFromMap(dynamic data) => data is Map
      ? NameDetailStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
      }.withoutNulls;

  static NameDetailStruct fromSerializableMap(Map<String, dynamic> data) =>
      NameDetailStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'NameDetailStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is NameDetailStruct && name == other.name;
  }

  @override
  int get hashCode => const ListEquality().hash([name]);
}

NameDetailStruct createNameDetailStruct({
  String? name,
}) =>
    NameDetailStruct(
      name: name,
    );
