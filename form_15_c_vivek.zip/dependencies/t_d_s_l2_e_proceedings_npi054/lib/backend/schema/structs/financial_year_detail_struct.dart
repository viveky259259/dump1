// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FinancialYearDetailStruct extends BaseStruct {
  FinancialYearDetailStruct({
    String? financialYear,
    String? year,
  })  : _financialYear = financialYear,
        _year = year;

  // "financialYear" field.
  String? _financialYear;
  String get financialYear => _financialYear ?? '';
  set financialYear(String? val) => _financialYear = val;

  bool hasFinancialYear() => _financialYear != null;

  // "year" field.
  String? _year;
  String get year => _year ?? '';
  set year(String? val) => _year = val;

  bool hasYear() => _year != null;

  static FinancialYearDetailStruct fromMap(Map<String, dynamic> data) =>
      FinancialYearDetailStruct(
        financialYear: data['financialYear'] as String?,
        year: data['year'] as String?,
      );

  static FinancialYearDetailStruct? maybeFromMap(dynamic data) => data is Map
      ? FinancialYearDetailStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'financialYear': _financialYear,
        'year': _year,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'financialYear': serializeParam(
          _financialYear,
          ParamType.String,
        ),
        'year': serializeParam(
          _year,
          ParamType.String,
        ),
      }.withoutNulls;

  static FinancialYearDetailStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FinancialYearDetailStruct(
        financialYear: deserializeParam(
          data['financialYear'],
          ParamType.String,
          false,
        ),
        year: deserializeParam(
          data['year'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FinancialYearDetailStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FinancialYearDetailStruct &&
        financialYear == other.financialYear &&
        year == other.year;
  }

  @override
  int get hashCode => const ListEquality().hash([financialYear, year]);
}

FinancialYearDetailStruct createFinancialYearDetailStruct({
  String? financialYear,
  String? year,
}) =>
    FinancialYearDetailStruct(
      financialYear: financialYear,
      year: year,
    );
