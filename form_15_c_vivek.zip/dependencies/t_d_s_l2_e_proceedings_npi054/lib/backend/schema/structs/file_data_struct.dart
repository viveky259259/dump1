// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FileDataStruct extends BaseStruct {
  FileDataStruct({
    String? fileName,
    int? status,
    String? message,
    String? filePath,
  })  : _fileName = fileName,
        _status = status,
        _message = message,
        _filePath = filePath;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "filePath" field.
  String? _filePath;
  String get filePath => _filePath ?? '';
  set filePath(String? val) => _filePath = val;

  bool hasFilePath() => _filePath != null;

  static FileDataStruct fromMap(Map<String, dynamic> data) => FileDataStruct(
        fileName: data['fileName'] as String?,
        status: castToType<int>(data['status']),
        message: data['message'] as String?,
        filePath: data['filePath'] as String?,
      );

  static FileDataStruct? maybeFromMap(dynamic data) =>
      data is Map ? FileDataStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
        'status': _status,
        'message': _message,
        'filePath': _filePath,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'filePath': serializeParam(
          _filePath,
          ParamType.String,
        ),
      }.withoutNulls;

  static FileDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      FileDataStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        filePath: deserializeParam(
          data['filePath'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FileDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FileDataStruct &&
        fileName == other.fileName &&
        status == other.status &&
        message == other.message &&
        filePath == other.filePath;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([fileName, status, message, filePath]);
}

FileDataStruct createFileDataStruct({
  String? fileName,
  int? status,
  String? message,
  String? filePath,
}) =>
    FileDataStruct(
      fileName: fileName,
      status: status,
      message: message,
      filePath: filePath,
    );
