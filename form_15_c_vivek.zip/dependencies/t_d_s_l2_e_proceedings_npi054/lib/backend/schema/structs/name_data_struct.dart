// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NameDataStruct extends BaseStruct {
  NameDataStruct({
    String? code,
    NameDetailStruct? detail,
    String? id,
    String? title,
    int? status,
  })  : _code = code,
        _detail = detail,
        _id = id,
        _title = title,
        _status = status;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "detail" field.
  NameDetailStruct? _detail;
  NameDetailStruct get detail => _detail ?? NameDetailStruct();
  set detail(NameDetailStruct? val) => _detail = val;

  void updateDetail(Function(NameDetailStruct) updateFn) {
    updateFn(_detail ??= NameDetailStruct());
  }

  bool hasDetail() => _detail != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  set id(String? val) => _id = val;

  bool hasId() => _id != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "status" field.
  int? _status;
  int get status => _status ?? 0;
  set status(int? val) => _status = val;

  void incrementStatus(int amount) => status = status + amount;

  bool hasStatus() => _status != null;

  static NameDataStruct fromMap(Map<String, dynamic> data) => NameDataStruct(
        code: data['code'] as String?,
        detail: data['detail'] is NameDetailStruct
            ? data['detail']
            : NameDetailStruct.maybeFromMap(data['detail']),
        id: data['id'] as String?,
        title: data['title'] as String?,
        status: castToType<int>(data['status']),
      );

  static NameDataStruct? maybeFromMap(dynamic data) =>
      data is Map ? NameDataStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'code': _code,
        'detail': _detail?.toMap(),
        'id': _id,
        'title': _title,
        'status': _status,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'detail': serializeParam(
          _detail,
          ParamType.DataStruct,
        ),
        'id': serializeParam(
          _id,
          ParamType.String,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'status': serializeParam(
          _status,
          ParamType.int,
        ),
      }.withoutNulls;

  static NameDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      NameDataStruct(
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        detail: deserializeStructParam(
          data['detail'],
          ParamType.DataStruct,
          false,
          structBuilder: NameDetailStruct.fromSerializableMap,
        ),
        id: deserializeParam(
          data['id'],
          ParamType.String,
          false,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'NameDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is NameDataStruct &&
        code == other.code &&
        detail == other.detail &&
        id == other.id &&
        title == other.title &&
        status == other.status;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([code, detail, id, title, status]);
}

NameDataStruct createNameDataStruct({
  String? code,
  NameDetailStruct? detail,
  String? id,
  String? title,
  int? status,
}) =>
    NameDataStruct(
      code: code,
      detail: detail ?? NameDetailStruct(),
      id: id,
      title: title,
      status: status,
    );
