import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_commons/api_requests/api_manager.dart';

import 'package:t_d_s_2_l1_logic_2wrus1/backend/api_requests/interceptors.dart'
    as t_d_s_2_l1_logic_2wrus1_api_interceptors;
import 'package:t_d_s_2_l1_logic_2wrus1/backend/api_requests/interceptors.dart'
    as t_d_s_2_l1_logic_2wrus1_api_interceptors;
import 'package:ff_commons/api_requests/api_interceptor.dart';

import 'package:ff_commons/api_requests/api_paging_params.dart';

export 'package:ff_commons/api_requests/api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start SavedHistory Group Code

class SavedHistoryGroup {
  static String getBaseUrl() => 'http://localhost:8081';
  static Map<String, String> headers = {};
  static SaveDraftCall saveDraftCall = SaveDraftCall();
}

class SaveDraftCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = SavedHistoryGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'saveDraft',
      apiUrl: '${baseUrl}/api/searchDraft',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End SavedHistory Group Code

/// Start FinancialYear Group Code

class FinancialYearGroup {
  static String getBaseUrl() => 'http://localhost:8081';
  static Map<String, String> headers = {};
  static FinYearCall finYearCall = FinYearCall();
}

class FinYearCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = FinancialYearGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'finYear',
      apiUrl: '${baseUrl}/api/v1/initiate/getFinancialYear',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End FinancialYear Group Code

/// Start FailureToDeduct Group Code

class FailureToDeductGroup {
  static String getBaseUrl() => 'http://localhost:8081';
  static Map<String, String> headers = {};
  static FailureToDeductTaxCall failureToDeductTaxCall =
      FailureToDeductTaxCall();
}

class FailureToDeductTaxCall {
  Future<ApiCallResponse> call({
    String? caseId = '',
  }) async {
    final baseUrl = FailureToDeductGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'FailureToDeductTax',
      apiUrl: '${baseUrl}/api/v1/actionitem/get-failure-to-deduct',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'caseId': caseId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End FailureToDeduct Group Code

/// Start ApplicantNameAddress Group Code

class ApplicantNameAddressGroup {
  static String getBaseUrl() => 'http://localhost:8081';
  static Map<String, String> headers = {};
  static ApplicantNameAddressCall applicantNameAddressCall =
      ApplicantNameAddressCall();
}

class ApplicantNameAddressCall {
  Future<ApiCallResponse> call({
    String? caseId = '',
  }) async {
    final baseUrl = ApplicantNameAddressGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'ApplicantNameAddress',
      apiUrl: '${baseUrl}/api/getOrderDetails',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'CaseId': caseId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End ApplicantNameAddress Group Code

class GetNameCall {
  static Future<ApiCallResponse> call({
    String? deductorType = '',
    String? tanPanNumber = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getName',
      apiUrl: 'http://localhost:8081/api/getName',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'deductorType': deductorType,
        'tanPanNumber': tanPanNumber,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetAddressCall {
  static Future<ApiCallResponse> call({
    String? addressAsPer = '',
    String? deductorType = '',
    String? tanPanNumber = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getAddress',
      apiUrl: 'http://localhost:8081/api/v1/initiate/getAddress',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'addressAsPer': addressAsPer,
        'deductorType': deductorType,
        'tanPanNumber': tanPanNumber,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEmailCall {
  static Future<ApiCallResponse> call({
    String? emailIdAsPer = '',
    String? tanPanNumber = '',
    String? deductorType = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getEmail',
      apiUrl: 'http://localhost:8081/api/v1/initiate/getEmailId',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'emailIdAsPer': emailIdAsPer,
        'deductorType': deductorType,
        'tanPanNumber': tanPanNumber,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class UploadFileCall {
  static Future<ApiCallResponse> call({
    List<FFUploadedFile>? fileList,
  }) async {
    final file = fileList ?? [];

    return ApiManager.instance.makeApiCall(
      callName: 'uploadFile',
      apiUrl: 'http://localhost:8081/api/annexure-upload',
      callType: ApiCallType.POST,
      headers: {},
      params: {
        'file': file,
      },
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SaveNoticeApiCall {
  static Future<ApiCallResponse> call({
    int? orderDetail201DraftId,
    bool? active,
    String? addressAsPer = '',
    String? addressLine1 = '',
    String? comments = '',
    String? createdAt = '',
    String? dcrNumber = '',
    String? deductorType = '',
    String? defaultAmt = '',
    String? defaultType = '',
    String? demandId = '',
    String? emailId = '',
    String? emailIdAsPer = '',
    String? financialYear = '',
    String? formType = '',
    String? internalComments = '',
    String? natureOfDefault = '',
    String? noticeHearingDate = '',
    String? noticeHearingTime = '',
    String? noticeIntSDef = '',
    String? noticeInt220Def = '',
    String? noticeIntLpDef = '',
    String? noticeIntSpDef = '',
    String? noticeSdDef = '',
    String? noticeSpDef = '',
    String? oraCopiedFlag = '',
    String? pin = '',
    String? reasonOfProceeding = '',
    String? sectionCode = '',
    String? state = '',
    String? surveyConducted = '',
    String? surveyDate = '',
    String? tan = '',
    String? tanName = '',
    String? tokeNo = '',
    int? totalDefault201,
    bool? transactionAnnexure,
    bool? transactionLevelEntry,
    String? updatedAt = '',
    String? updatedBy = '',
    String? uploadDocsFilepath = '',
    int? orderDeducteeId,
    double? amountCredited,
    String? dateOfCredit = '',
    String? dateOfDeposit = '',
    dynamic? deducteeDetailsJson,
    String? deducteeName = '',
    double? rateOfTds,
    double? scCollection,
    double? scPaymentTdsTcs,
    String? section = '',
    double? taxAmountDeducted,
    double? taxAmountDeductible,
    double? tdsTcsDeposited,
    String? deducteePan = '',
    String? createdBy = '',
  }) async {
    final deducteeDetails = _serializeJson(deducteeDetailsJson, true);
    final ffApiRequestBody = '''
{
  "addressAsPer": "${escapeStringForJson(addressAsPer)}",
  "addressLine1": "${escapeStringForJson(addressLine1)}",
  "deductorType": "${escapeStringForJson(deductorType)}",
  "emailID": "${escapeStringForJson(emailId)}",
  "emailIdAsPer": "${escapeStringForJson(emailIdAsPer)}",
  "financialYear": "${escapeStringForJson(financialYear)}",
  "internalComments": "${escapeStringForJson(internalComments)}",
  "natureOfDefault": "${escapeStringForJson(natureOfDefault)}",
  "noticeHearingDate": "${escapeStringForJson(noticeHearingDate)}",
  "noticeHearingTime": "${escapeStringForJson(noticeHearingTime)}",
  "pin": "${escapeStringForJson(pin)}",
  "reasonOfProceeding": "${escapeStringForJson(reasonOfProceeding)}",
  "sectionCode": "${escapeStringForJson(sectionCode)}",
  "state": "${escapeStringForJson(state)}",
  "surveyDate": "${escapeStringForJson(surveyDate)}",
  "uploadDocsFilepath": "${escapeStringForJson(uploadDocsFilepath)}",
  "amountCredited": ${amountCredited},
  "dateOfCredit": "${escapeStringForJson(dateOfCredit)}",
  "dateOfDeposit": "${escapeStringForJson(dateOfDeposit)}",
  "deducteeDetails": [
    {
      "deducteeName": "${escapeStringForJson(deducteeName)}",
      "deducteePan": "${escapeStringForJson(deducteePan)}",
      "rateOfTds": ${rateOfTds},
      "scCollection": ${scCollection},
      "scPaymentTdsTcs": ${scPaymentTdsTcs},
      "section": "${escapeStringForJson(section)}",
      "taxAmountDeducted": ${taxAmountDeducted},
      "taxAmountDeductible": ${taxAmountDeductible},
      "tdsTcsDeposited": ${tdsTcsDeposited}
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'saveNoticeApi',
      apiUrl: 'http://localhost:8081/api/v1/initiate/save',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetFinancialYearApiCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'getFinancialYearApi',
      apiUrl: 'http://localhost:8081/api/v1/initiate/getFinancialYear',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetSectionsApiCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'getSectionsApi',
      apiUrl: 'http://localhost:8081/api/v1/initiate/getListOfSection',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DownloadExcelCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'downloadExcel',
      apiUrl: 'http://localhost:8081/api/v1/worklist/export',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
