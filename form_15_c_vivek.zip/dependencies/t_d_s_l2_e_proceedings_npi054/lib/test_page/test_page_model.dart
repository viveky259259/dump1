import '/components/add_edit_transaction_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'test_page_widget.dart' show TestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TestPageModel extends FlutterFlowModel<TestPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Add_Edit_Transaction component.
  late AddEditTransactionModel addEditTransactionModel;

  @override
  void initState(BuildContext context) {
    addEditTransactionModel =
        createModel(context, () => AddEditTransactionModel());
  }

  @override
  void dispose() {
    addEditTransactionModel.dispose();
  }
}
