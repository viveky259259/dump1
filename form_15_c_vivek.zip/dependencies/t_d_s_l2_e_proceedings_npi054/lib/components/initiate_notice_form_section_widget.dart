import '/backend/api_requests/api_calls.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/add_edit_transaction_widget.dart';
import '/components/details_documents_text_field_widget.dart';
import '/components/tan_information_box_initiate_notice_widget.dart';
import '/components/transaction_details_initiate_notice_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/custom_code/widgets/index.dart'
    as t_d_s_login_module_l1_input_vo62wv_custom_widgets;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_breadcrumbs/navigation_generic_breadcrumbs_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_destructive_button/navigation_generic_destructive_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'initiate_notice_form_section_model.dart';
export 'initiate_notice_form_section_model.dart';

class InitiateNoticeFormSectionWidget extends StatefulWidget {
  const InitiateNoticeFormSectionWidget({
    super.key,
    required this.keyPrefix,
    this.navigationPath,
  });

  final String? keyPrefix;
  final List<String>? navigationPath;

  @override
  State<InitiateNoticeFormSectionWidget> createState() =>
      _InitiateNoticeFormSectionWidgetState();
}

class _InitiateNoticeFormSectionWidgetState
    extends State<InitiateNoticeFormSectionWidget> {
  late InitiateNoticeFormSectionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InitiateNoticeFormSectionModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.financialYear = await FinancialYearGroup.finYearCall.call();

      if ((_model.financialYear?.succeeded ?? true)) {
        _model.financialYearDropDownResult =
            FinancialYearApiResponseModelStruct.maybeFromMap(
                (_model.financialYear?.jsonBody ?? ''));
        safeSetState(() {});
      }
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(47.0, 0.0, 47.0, 0.0),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
              model: _model.navigationGenericBreadcrumbsModel,
              updateCallback: () => safeSetState(() {}),
              child: t_d_s_login_module_l1_navigation_3he2k0
                  .NavigationGenericBreadcrumbsWidget(
                keyPrefix: 'key',
                listItems: widget!.navigationPath!,
                onItemTap: (index) async {},
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Notice u/s 201 or 206C',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).textPrimary,
                        fontSize: 24.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                  model: _model.navigationGenericSecondaryButtonModel,
                  updateCallback: () => safeSetState(() {}),
                  child: t_d_s_login_module_l1_navigation_3he2k0
                      .NavigationGenericSecondaryButtonWidget(
                    labelText: 'Show All Saved Drafts',
                    keyPrefix: 'key',
                    states: t_d_s_login_module_l1_navigation_3he2k0_enums
                        .ButtonState.byDefault,
                    onTap: () async {},
                  ),
                ),
              ],
            ),
            Divider(
              thickness: 2.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 24.0,
                    runSpacing: 0.0,
                    alignment: WrapAlignment.start,
                    crossAxisAlignment: WrapCrossAlignment.start,
                    direction: Axis.horizontal,
                    runAlignment: WrapAlignment.start,
                    verticalDirection: VerticalDirection.down,
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        constraints: BoxConstraints(
                          maxWidth: 407.0,
                        ),
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: t_d_s_login_module_l1_input_vo62wv_util
                            .wrapWithModel(
                          model: _model.deductorTypeModel,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_input_vo62wv
                              .InputFieldGenericDropdownWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Initiate_Notice_Form_Section',
                                    'Deductor_Type')),
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Initiate_Notice_Form_Section',
                                    'Deductor_Type'),
                            isDropdownDisable: false,
                            showErrorMessage: false,
                            labelText: 'Deductor Type',
                            isMandatory: true,
                            dropDownList: ["PAN", "TAN"],
                            onDropDownSelection: (selectedVlaue) async {},
                          ),
                        ),
                      ),
                      Container(
                        constraints: BoxConstraints(
                          maxWidth: 407.0,
                        ),
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: t_d_s_login_module_l1_input_vo62wv_util
                            .wrapWithModel(
                          model: _model.noticeUsModel,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_input_vo62wv
                              .InputFieldGenericDropdownWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Initiate_Notice_Form_Section',
                                    'Notice_Us')),
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Initiate_Notice_Form_Section',
                                    'Notice_Us'),
                            isDropdownDisable: false,
                            showErrorMessage: false,
                            labelText: 'Notice u/s',
                            isMandatory: false,
                            dropDownList: () {
                              if (_model.deductorTypeModel.dropDownValue ==
                                  'TAN') {
                                return (["205(A)", "206(F)"]);
                              } else if (_model
                                      .deductorTypeModel.dropDownValue ==
                                  'PAN') {
                                return (["201(A)"]);
                              } else {
                                return (["Select tan or pan"]);
                              }
                            }(),
                            onDropDownSelection: (selectedVlaue) async {},
                          ),
                        ),
                      ),
                      Container(
                        constraints: BoxConstraints(
                          maxWidth: 407.0,
                        ),
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: t_d_s_login_module_l1_input_vo62wv_util
                            .wrapWithModel(
                          model: _model.financialYearModel,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_input_vo62wv
                              .InputFieldGenericDropdownWidget(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Initiate_Notice_Form_Section',
                                    'Financial_Year')),
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'Initiate_Notice_Form_Section',
                                    'Financial_Year'),
                            isDropdownDisable: false,
                            showErrorMessage: false,
                            labelText: 'Financial Year',
                            isMandatory: false,
                            dropDownList:
                                _model.financialYearDropDownResult != null
                                    ? _model.financialYearDropDownResult?.data
                                        ?.firstOrNull?.detail
                                        ?.map((e) => e.financialYear)
                                        .toList()
                                    : ([]),
                            onDropDownSelection: (selectedVlaue) async {},
                          ),
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                    child: Wrap(
                      spacing: 0.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 407.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.natureOfDefaultModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDropdownWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Nature_Of_Default')),
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Nature_Of_Default'),
                              isDropdownDisable: false,
                              showErrorMessage: false,
                              labelText: 'Nature of Default',
                              isMandatory: false,
                              dropDownList: [
                                "Failure to deduct",
                                "Failure to deposit",
                                "Delay in Deduction",
                                "Delay in Deposition"
                              ],
                              onDropDownSelection: (selectedVlaue) async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  wrapWithModel(
                    model: _model.tanInformationBoxInitiateNoticeModel,
                    updateCallback: () => safeSetState(() {}),
                    child: TanInformationBoxInitiateNoticeWidget(
                      key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(
                              widget!.keyPrefix!,
                              'Initiate_Notice_Form_Section',
                              'Tan_Information_Box_Initiate_Notice')),
                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                          .generateL2KeyValuePrefix(
                              widget!.keyPrefix!,
                              'Initiate_Notice_Form_Section',
                              'Tan_Information_Box_Initiate_Notice'),
                      reasonForInitiationProceeding: '',
                      dateOfSurvey: random_data.randomDate(),
                      dateOfHearing: random_data.randomDate(),
                      dateOfBearing: random_data.randomDate(),
                      tanPanAction: () async {
                        _model.getNameApiResult = await GetNameCall.call(
                          deductorType: _model.deductorTypeModel.dropDownValue,
                          tanPanNumber: _model
                              .tanInformationBoxInitiateNoticeModel
                              .tanPanModel
                              .genericTextFieldTextController
                              .text,
                        );

                        if ((_model.getNameApiResult?.succeeded ?? true)) {
                          safeSetState(() {
                            _model
                                .tanInformationBoxInitiateNoticeModel
                                .nameModel
                                .genericTextFieldTextController
                                ?.text = GetNameSchemaStruct.maybeFromMap(
                                    (_model.getNameApiResult?.jsonBody ?? ''))!
                                .data
                                .firstOrNull!
                                .detail
                                .name;
                          });
                        }

                        safeSetState(() {});
                      },
                      addressAsPerAction: () async {
                        var _shouldSetState = false;
                        _model.getAddressApiResult = await GetAddressCall.call(
                          addressAsPer: _model
                              .tanInformationBoxInitiateNoticeModel
                              .addressAsPerModel
                              .dropDownValue,
                          tanPanNumber: _model
                              .tanInformationBoxInitiateNoticeModel
                              .tanPanModel
                              .genericTextFieldTextController
                              .text,
                          deductorType: _model.deductorTypeModel.dropDownValue,
                        );

                        _shouldSetState = true;
                        if ((_model.getAddressApiResult?.succeeded ?? true)) {
                          if (_model.tanInformationBoxInitiateNoticeModel
                                  .addressAsPerModel.dropDownValue !=
                              'New Address') {
                            await Future.wait([
                              Future(() async {
                                safeSetState(() {
                                  _model
                                          .tanInformationBoxInitiateNoticeModel
                                          .addressModel
                                          .genericTextFieldTextController
                                          ?.text =
                                      GetAddressSchemaStruct.maybeFromMap(
                                              (_model.getAddressApiResult
                                                      ?.jsonBody ??
                                                  ''))!
                                          .data
                                          .firstOrNull!
                                          .detail
                                          .addressLine;
                                });
                              }),
                              Future(() async {
                                safeSetState(() {
                                  _model
                                          .tanInformationBoxInitiateNoticeModel
                                          .stateModel
                                          .genericTextFieldTextController
                                          ?.text =
                                      GetAddressSchemaStruct.maybeFromMap(
                                              (_model.getAddressApiResult
                                                      ?.jsonBody ??
                                                  ''))!
                                          .data
                                          .firstOrNull!
                                          .detail
                                          .state;
                                });
                              }),
                              Future(() async {
                                safeSetState(() {
                                  _model
                                          .tanInformationBoxInitiateNoticeModel
                                          .pinModel
                                          .genericTextFieldTextController
                                          ?.text =
                                      GetAddressSchemaStruct.maybeFromMap(
                                              (_model.getAddressApiResult
                                                      ?.jsonBody ??
                                                  ''))!
                                          .data
                                          .firstOrNull!
                                          .detail
                                          .pinCode;
                                });
                              }),
                            ]);
                            if (_shouldSetState) safeSetState(() {});
                            return;
                          } else {
                            await Future.wait([
                              Future(() async {
                                safeSetState(() {
                                  _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .addressModel
                                      .genericTextFieldTextController
                                      ?.text = ' ';
                                });
                              }),
                              Future(() async {
                                safeSetState(() {
                                  _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .stateModel
                                      .genericTextFieldTextController
                                      ?.text = ' ';
                                });
                              }),
                              Future(() async {
                                safeSetState(() {
                                  _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .pinModel
                                      .genericTextFieldTextController
                                      ?.text = '';
                                });
                              }),
                            ]);
                          }
                        }
                        if (_shouldSetState) safeSetState(() {});
                      },
                      emailAsPerAction: () async {
                        var _shouldSetState = false;
                        _model.getEmailAsPerResult = await GetEmailCall.call(
                          emailIdAsPer: _model
                              .tanInformationBoxInitiateNoticeModel
                              .emailAsPerModel
                              .dropDownValue,
                          tanPanNumber: _model
                              .tanInformationBoxInitiateNoticeModel
                              .tanPanModel
                              .genericTextFieldTextController
                              .text,
                          deductorType: _model.deductorTypeModel.dropDownValue,
                        );

                        _shouldSetState = true;
                        if ((_model.getEmailAsPerResult?.succeeded ?? true)) {
                          if (_model.tanInformationBoxInitiateNoticeModel
                                  .emailAsPerModel.dropDownValue !=
                              'New Address') {
                            if (_model.tanInformationBoxInitiateNoticeModel
                                    .emailAsPerModel.dropDownValue !=
                                'New Address') {
                              safeSetState(() {
                                _model
                                    .tanInformationBoxInitiateNoticeModel
                                    .emailIdModel
                                    .genericTextFieldTextController
                                    ?.text = GetEmailSchemaStruct.maybeFromMap(
                                        (_model.getEmailAsPerResult?.jsonBody ??
                                            ''))!
                                    .data
                                    .firstOrNull!
                                    .detail;
                              });
                            } else {
                              safeSetState(() {
                                _model
                                    .tanInformationBoxInitiateNoticeModel
                                    .emailIdModel
                                    .genericTextFieldTextController
                                    ?.text = ' ';
                              });
                            }

                            if (_shouldSetState) safeSetState(() {});
                            return;
                          } else {
                            if (_shouldSetState) safeSetState(() {});
                            return;
                          }
                        } else {
                          if (_shouldSetState) safeSetState(() {});
                          return;
                        }

                        if (_shouldSetState) safeSetState(() {});
                      },
                    ),
                  ),
                  Builder(
                    builder: (context) => wrapWithModel(
                      model: _model.transactionDetailsInitiateNoticeModel,
                      updateCallback: () => safeSetState(() {}),
                      child: TransactionDetailsInitiateNoticeWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL2KeyValuePrefix(
                                widget!.keyPrefix!,
                                'Initiate_Notice_Form_Section',
                                'Transaction_Details_Initiate_Notice')),
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL2KeyValuePrefix(
                                widget!.keyPrefix!,
                                'Initiate_Notice_Form_Section',
                                'Transaction_Details_Initiate_Notice'),
                        transactionType: TransactionType.Online_Entries,
                        offlineUploadedFile: _model.uploadedFiles,
                        transactionList: _model.transactions,
                        onAddTransaction: () async {
                          await showAlignedDialog(
                            context: context,
                            isGlobal: false,
                            avoidOverflow: false,
                            targetAnchor: AlignmentDirectional(0.0, 0.0)
                                .resolve(Directionality.of(context)),
                            followerAnchor: AlignmentDirectional(0.0, 0.0)
                                .resolve(Directionality.of(context)),
                            builder: (dialogContext) {
                              return Material(
                                color: Colors.transparent,
                                child: AddEditTransactionWidget(
                                  keyPrefix: 'key',
                                  dialogLabelText: 'Add New Transaction',
                                  cancelAction: () async {},
                                  saveAction: (transactionData,
                                      transactionIndex) async {
                                    _model.addToTransactions(transactionData);
                                    safeSetState(() {});
                                  },
                                ),
                              );
                            },
                          );
                        },
                        onEditTransaction:
                            (transaction, transactionIndex) async {
                          await showDialog(
                            context: context,
                            builder: (dialogContext) {
                              return Dialog(
                                elevation: 0,
                                insetPadding: EdgeInsets.zero,
                                backgroundColor: Colors.transparent,
                                alignment: AlignmentDirectional(0.0, 0.0)
                                    .resolve(Directionality.of(context)),
                                child: AddEditTransactionWidget(
                                  keyPrefix: 'key',
                                  editTransactionData: transaction,
                                  dialogLabelText: 'Edit',
                                  transactionIndex: transactionIndex,
                                  cancelAction: () async {},
                                  saveAction: (transactionData,
                                      transactionIndex) async {
                                    _model.updateTransactionsAtIndex(
                                      transactionIndex,
                                      (_) => transactionData,
                                    );
                                    safeSetState(() {});
                                  },
                                ),
                              );
                            },
                          );
                        },
                        onDeleteTransaction: (transaction) async {
                          _model.removeFromTransactions(transaction);
                          safeSetState(() {});
                        },
                        onDownloadExcel: () async {},
                        onDeleteOfflineUploadedFile: () async {},
                        onViewOfflineUploadedFile: () async {},
                        onBrowseFile: () async {
                          _model.apiResult8lw = await UploadFileCall.call(
                            fileList: _model.uploadedFiles,
                          );

                          if ((_model.apiResult8lw?.succeeded ?? true)) {
                            _model.addToUploadedFilesNamesList(
                                UploadFileSchemaStruct.maybeFromMap(
                                        (_model.apiResult8lw?.jsonBody ?? ''))!
                                    .data
                                    .firstOrNull!
                                    .detail
                                    .firstOrNull!
                                    .fileName);
                            safeSetState(() {});
                          }

                          safeSetState(() {});
                        },
                        onRefresH: () async {},
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 0.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 839.0,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: FlutterFlowTheme.of(context).neutral300,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    12.0, 16.0, 12.0, 16.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'List of details/documents/information required',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.w500,
                                          ),
                                    ),
                                    t_d_s_login_module_l1_navigation_3he2k0_util
                                        .wrapWithModel(
                                      model: _model.addButtonModel,
                                      updateCallback: () => safeSetState(() {}),
                                      child: t_d_s_login_module_l1_navigation_3he2k0
                                          .NavigationGenericSecondaryButtonWidget(
                                        key: ValueKey(
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Initiate_Notice_Form_Section',
                                                    'Add_Button')),
                                        labelText: 'Add',
                                        keyPrefix:
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL2KeyValuePrefix(
                                                    widget!.keyPrefix!,
                                                    'Initiate_Notice_Form_Section',
                                                    'Add_Button'),
                                        height: 28.0,
                                        leftIcon: Icon(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL2KeyValuePrefix(
                                                      widget!.keyPrefix!,
                                                      'Initiate_Notice_Form_Section',
                                                      'Add_Button')),
                                          Icons.add,
                                        ),
                                        states:
                                            t_d_s_login_module_l1_navigation_3he2k0_enums
                                                .ButtonState.byDefault,
                                        onTap: () async {
                                          _model.addToDocuments('');
                                          safeSetState(() {});
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(
                                thickness: 1.0,
                                color: FlutterFlowTheme.of(context).neutral300,
                              ),
                              Builder(
                                builder: (context) {
                                  final data = _model.documents.toList();

                                  return ListView.builder(
                                    padding: EdgeInsets.zero,
                                    shrinkWrap: true,
                                    scrollDirection: Axis.vertical,
                                    itemCount: data.length,
                                    itemBuilder: (context, dataIndex) {
                                      final dataItem = data[dataIndex];
                                      return Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            12.0, 16.0, 0.0, 16.0),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              'I',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(),
                                              child:
                                                  DetailsDocumentsTextFieldWidget(
                                                key: Key(
                                                    'Keype5_${dataIndex}_of_${data.length}'),
                                                keyPrefix: 'key',
                                                onChangeTextField:
                                                    (updatedValue) async {
                                                  _model.updateDocumentsAtIndex(
                                                    dataIndex,
                                                    (_) => updatedValue,
                                                  );
                                                  safeSetState(() {});
                                                },
                                              ),
                                            ),
                                            t_d_s_login_module_l1_navigation_3he2k0
                                                .NavigationGenericDestructiveButtonWidget(
                                              key: Key(
                                                  'Keyvvo_${dataIndex}_of_${data.length}'),
                                              keyPrefix:
                                                  t_d_s_2_l1_logic_2wrus1_functions
                                                      .generateL2KeyValuePrefix(
                                                          widget!.keyPrefix!,
                                                          'Initiate_Notice_Form_Section',
                                                          ' Delete_Button'),
                                              height: 28.0,
                                              labelText: 'Delete',
                                              icon: Icon(
                                                key: ValueKey(
                                                    t_d_s_2_l1_logic_2wrus1_functions
                                                        .generateL2KeyValuePrefix(
                                                            widget!.keyPrefix!,
                                                            'Initiate_Notice_Form_Section',
                                                            ' Delete_Button')),
                                                Icons.auto_delete,
                                              ),
                                              state:
                                                  t_d_s_login_module_l1_navigation_3he2k0_enums
                                                      .ButtonState.byDefault,
                                              onTap: () async {
                                                _model.removeFromDocuments(
                                                    dataItem);
                                                safeSetState(() {});
                                              },
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 0.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          width: 840.0,
                          height: 200.0,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: FlutterFlowTheme.of(context).neutral300,
                            ),
                          ),
                          child: Container(
                            width: 100.0,
                            height: 100.0,
                            child:
                                t_d_s_login_module_l1_input_vo62wv_custom_widgets
                                    .WordEditor(
                              width: 100.0,
                              height: 100.0,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (_model.transactionDetailsInitiateNoticeModel
                          .navigationChoiceChipModel.choiceChipsValue ==
                      'Online Entries')
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 40.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Upload File',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              Container(
                                width: 407.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                ),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model: _model
                                      .inputfieldFileUploadBrowseFilesModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .InputfieldFileUploadBrowseFilesWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Initiate_Notice_Form_Section',
                                            'Inputfield_File_Upload_BrowseFiles')),
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL2KeyValuePrefix(
                                            widget!.keyPrefix!,
                                            'Initiate_Notice_Form_Section',
                                            'Inputfield_File_Upload_BrowseFiles'),
                                    isDisable: false,
                                    onTapBrowseFiles: () async {
                                      _model.apiResult5yw =
                                          await UploadFileCall.call(
                                        fileList: _model.uploadedFiles,
                                      );

                                      if ((_model.apiResult5yw?.succeeded ??
                                          true)) {
                                        _model.addToUploadedFilesNamesList(
                                            UploadFileSchemaStruct.maybeFromMap(
                                                    (_model.apiResult5yw
                                                            ?.jsonBody ??
                                                        ''))!
                                                .data
                                                .firstOrNull!
                                                .detail
                                                .firstOrNull!
                                                .fileName);
                                        safeSetState(() {});
                                      }

                                      safeSetState(() {});
                                    },
                                  ),
                                ),
                              ),
                            ].divide(SizedBox(height: 8.0)),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            Divider(
              thickness: 2.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                      model: _model.backButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      child: t_d_s_login_module_l1_navigation_3he2k0
                          .NavigationGenericSecondaryButtonWidget(
                        labelText: 'Back',
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                'Initiate_Notice_Form_Section', 'Back_Button'),
                        states: t_d_s_login_module_l1_navigation_3he2k0_enums
                            .ButtonState.byDefault,
                        onTap: () async {},
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model: _model.saveButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericSecondaryButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Save_Button')),
                              labelText: 'Save',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Save_Button'),
                              states:
                                  t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.byDefault,
                              onTap: () async {
                                _model.saveApiResult =
                                    await SaveNoticeApiCall.call(
                                  addressAsPer: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .addressAsPerModel
                                      .dropDownValue,
                                  addressLine1: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .addressModel
                                      .genericTextFieldTextController
                                      .text,
                                  deductorType:
                                      _model.deductorTypeModel.dropDownValue,
                                  emailId: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .emailIdModel
                                      .genericTextFieldTextController
                                      .text,
                                  emailIdAsPer: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .emailAsPerModel
                                      .dropDownValue,
                                  financialYear:
                                      _model.financialYearModel.dropDownValue,
                                  natureOfDefault:
                                      _model.natureOfDefaultModel.dropDownValue,
                                  noticeHearingDate: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .hearingDateAndTimeModel
                                      .datePicked
                                      ?.toString(),
                                  noticeHearingTime: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .hearingDateAndTimeModel
                                      .datePicked
                                      ?.toString(),
                                  pin: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .pinModel
                                      .genericTextFieldTextController
                                      .text,
                                  reasonOfProceeding: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .reasonForInitiationOfProceedingModel
                                      .dropDownValue,
                                  state: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .stateModel
                                      .genericTextFieldTextController
                                      .text,
                                  surveyDate: _model
                                      .tanInformationBoxInitiateNoticeModel
                                      .dateOfSurveyModel
                                      .datePicked
                                      ?.toString(),
                                  amountCredited: _model.transactions
                                      .firstOrNull?.amtPaidCredited,
                                  dateOfCredit: _model.transactions.firstOrNull
                                      ?.dateOfPaymentCredit
                                      ?.toString(),
                                  dateOfDeposit: _model
                                      .transactions.firstOrNull?.dateOfDeposit
                                      ?.toString(),
                                  sectionCode:
                                      _model.transactions.firstOrNull?.section,
                                );

                                if ((_model.saveApiResult?.succeeded ?? true)) {
                                  _model.proceedButtonState =
                                      t_d_s_login_module_l1_navigation_3he2k0_enums
                                          .ButtonState.byDefault;
                                  safeSetState(() {});
                                }

                                safeSetState(() {});
                              },
                            ),
                          ),
                          t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model: _model.resetButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericSecondaryButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Reset_Button')),
                              labelText: 'Reset',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Reset_Button'),
                              states:
                                  t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.byDefault,
                              onTap: () async {},
                            ),
                          ),
                          t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model: _model.proceedButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericPrimaryButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Proceed_Button')),
                              labeltext: 'Proceed',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Initiate_Notice_Form_Section',
                                      'Proceed_Button'),
                              states: _model.proceedButtonState!,
                              onTap: () async {},
                            ),
                          ),
                        ].divide(SizedBox(width: 20.0)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
