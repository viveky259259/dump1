import '/backend/schema/structs/index.dart';
import '/components/deduct_tax_parent_container/deduct_tax_parent_container_widget.dart';
import '/components/tan_pan_information_box/tan_pan_information_box_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_state.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_state;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/custom_code/widgets/index.dart'
    as t_d_s_login_module_l1_input_vo62wv_custom_widgets;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/radio_buttons/toggle_button_with_list/toggle_button_with_list_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'notice_writting_model.dart';
export 'notice_writting_model.dart';

class NoticeWrittingWidget extends StatefulWidget {
  const NoticeWrittingWidget({
    super.key,
    required this.keyPrefix,
    this.tan,
    this.financialYear,
    this.datedInformation,
    this.documentIdentificationNumber,
    this.applicantName,
    this.applicantAddress,
  });

  final String? keyPrefix;
  final String? tan;
  final String? financialYear;
  final String? datedInformation;
  final String? documentIdentificationNumber;
  final String? applicantName;
  final String? applicantAddress;

  @override
  State<NoticeWrittingWidget> createState() => _NoticeWrittingWidgetState();
}

class _NoticeWrittingWidgetState extends State<NoticeWrittingWidget> {
  late NoticeWrittingModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NoticeWrittingModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Notice u/s 201 or 206C',
              style: GoogleFonts.getFont(
                'Inter',
                color: FlutterFlowTheme.of(context).textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 24.0,
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                child: Container(
                  constraints: BoxConstraints(
                    maxHeight: 136.0,
                  ),
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 260.0, 0.0),
                          child: Container(
                            decoration: BoxDecoration(),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8.0),
                              child: Image.asset(
                                'dependencies/t_d_s_l2_e_proceedings_npi054/assets/images/Income_Tax_Logo.png',
                                width: 98.0,
                                height: 67.0,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Government of India                                                                 ',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).textBasic,
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            'Ministry of Finance                                                                                               ',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).textBasic,
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            'Income Tax Department                            ',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).textBasic,
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            'Office of the Income Tax Officer- Ward-78(2), Delhi',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).textBasic,
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'To,',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            letterSpacing: 0.0,
                          ),
                    ),
                    Text(
                      widget!.applicantName!,
                      style: GoogleFonts.getFont(
                        'Inter',
                        color: FlutterFlowTheme.of(context).textBasic,
                        fontWeight: FontWeight.w500,
                        fontSize: 14.0,
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                      child: RichText(
                        textScaler: MediaQuery.of(context).textScaler,
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: widget!.applicantAddress!,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                            )
                          ],
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                    child: Container(
                      height: 74.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        border: Border.all(
                          color: FlutterFlowTheme.of(context).neutral400,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          wrapWithModel(
                            model: _model.tanPanInformationBoxModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: TanPanInformationBoxWidget(
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'TanPanInformationBox',
                                      'Notice Writting'),
                              heading: 'Tan',
                              detail: widget!.tan,
                            ),
                          ),
                          SizedBox(
                            height: 100.0,
                            child: VerticalDivider(
                              thickness: 2.0,
                              color: FlutterFlowTheme.of(context).neutral400,
                            ),
                          ),
                          wrapWithModel(
                            model: _model.tanPanInformationBoxModel2,
                            updateCallback: () => safeSetState(() {}),
                            child: TanPanInformationBoxWidget(
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'TanPanInformationBox',
                                      'Notice Writting'),
                            ),
                          ),
                          SizedBox(
                            height: 100.0,
                            child: VerticalDivider(
                              thickness: 2.0,
                              color: FlutterFlowTheme.of(context).neutral400,
                            ),
                          ),
                          wrapWithModel(
                            model: _model.tanPanInformationBoxModel3,
                            updateCallback: () => safeSetState(() {}),
                            child: TanPanInformationBoxWidget(
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'TanPanInformationBox',
                                      'Notice Writting'),
                            ),
                          ),
                          SizedBox(
                            height: 100.0,
                            child: VerticalDivider(
                              thickness: 2.0,
                              color: FlutterFlowTheme.of(context).neutral400,
                            ),
                          ),
                          wrapWithModel(
                            model: _model.tanPanInformationBoxModel4,
                            updateCallback: () => safeSetState(() {}),
                            child: TanPanInformationBoxWidget(
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'TanPanInformationBox',
                                      'Notice Writting'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Align(
                alignment: AlignmentDirectional(-1.0, -1.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                    child: Text(
                      'Sir/ Madam/ M/s,',
                      style: GoogleFonts.getFont(
                        'Inter',
                        color: FlutterFlowTheme.of(context).textBasic,
                        fontWeight: FontWeight.w500,
                        fontSize: 16.0,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                child: Container(
                  decoration: BoxDecoration(),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 8.0),
                        child: Container(
                          height: 18.0,
                          decoration: BoxDecoration(),
                          child: Text(
                            'Subject',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(),
                        child: Container(
                          width: 1272.0,
                          height: 95.0,
                          child:
                              t_d_s_login_module_l1_input_vo62wv_custom_widgets
                                  .WordEditor(
                            width: 1272.0,
                            height: 95.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: AlignmentDirectional(-1.0, -1.0),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 8.0),
                        child: Container(
                          decoration: BoxDecoration(),
                          child: Text(
                            'Description',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Align(
                        alignment: AlignmentDirectional(-1.0, -1.0),
                        child: Container(
                          decoration: BoxDecoration(),
                          child: Container(
                            width: 1270.0,
                            height: 208.0,
                            child:
                                t_d_s_login_module_l1_input_vo62wv_custom_widgets
                                    .WordEditor(
                              width: 1270.0,
                              height: 208.0,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Container(
                height: 200.0,
                child: wrapWithModel(
                  model: _model.deductTaxParentContainerModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: DeductTaxParentContainerWidget(
                    section: _model.failureToDeductTax?.data?.firstOrNull
                        ?.detail?.response?.firstOrNull?.section,
                    natureOfPayment: _model
                        .failureToDeductTax
                        ?.data
                        ?.firstOrNull
                        ?.detail
                        ?.response
                        ?.firstOrNull
                        ?.natureOfPayment,
                    amountPaidCredited: _model
                        .failureToDeductTax
                        ?.data
                        ?.firstOrNull
                        ?.detail
                        ?.response
                        ?.firstOrNull
                        ?.totalAmountPaid
                        ?.toString(),
                    taxDeductibleTaxDeductibleon: _model
                        .failureToDeductTax
                        ?.data
                        ?.firstOrNull
                        ?.detail
                        ?.response
                        ?.firstOrNull
                        ?.totalTaxAmountDeductible
                        ?.toString(),
                    taxDeductedTaxDeductedOnTaxDepositedTaxDepositedOn: _model
                        .failureToDeductTax
                        ?.data
                        ?.firstOrNull
                        ?.detail
                        ?.response
                        ?.firstOrNull
                        ?.totalTaxDeducted
                        ?.toString(),
                    amountofShortNonDeductionDelayInMonths: _model
                        .failureToDeductTax
                        ?.data
                        ?.firstOrNull
                        ?.detail
                        ?.response
                        ?.firstOrNull
                        ?.amountSd
                        ?.toString(),
                  ),
                ),
              ),
            ),
            Container(
              height: 200.0,
              child: wrapWithModel(
                model: _model.deductTaxParentContainerModel2,
                updateCallback: () => safeSetState(() {}),
                child: DeductTaxParentContainerWidget(
                  tableHeading:
                      '(ii) Failure to deposit tax to the credit of the Government of India:',
                  taxDeductibleTaxDeductibleon: 'Tax Deducted',
                  taxDeductedTaxDeductedOnTaxDepositedTaxDepositedOn:
                      'Tax Deposited',
                  amountofShortNonDeductionDelayInMonths:
                      'Amount of Short/Non-Deposition',
                ),
              ),
            ),
            Container(
              height: 200.0,
              child: wrapWithModel(
                model: _model.deductTaxParentContainerModel3,
                updateCallback: () => safeSetState(() {}),
                child: DeductTaxParentContainerWidget(
                  tableHeading: '(iii) Delay in deduction of tax:',
                ),
              ),
            ),
            Container(
              height: 200.0,
              child: wrapWithModel(
                model: _model.deductTaxParentContainerModel4,
                updateCallback: () => safeSetState(() {}),
                child: DeductTaxParentContainerWidget(
                  tableHeading:
                      '(iv) Delay in deposition of tax to the credit of the Government of India:',
                ),
              ),
            ),
            Align(
              alignment: AlignmentDirectional(-1.0, -1.0),
              child: Container(
                constraints: BoxConstraints(
                  maxHeight: 52.0,
                ),
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Divider(
                      thickness: 2.0,
                      color: FlutterFlowTheme.of(context).neutral300,
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Text(
                          'Do you want to send the transaction level details entered as an Annexure with the notice ?',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            _model.selectedIndexCompState = 1;
                            safeSetState(() {});
                          },
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.toggleButtonWithListModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .ToggleButtonWithListWidget(
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'ToggleButton_With_List',
                                      'NoticeWritting'),
                              listOfToggle: ["Yes", "No"],
                              callBackAction: (selectedIndex) async {
                                safeSetState(() {});
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Container(
                  width: 1270.0,
                  height: 502.0,
                  child: t_d_s_login_module_l1_input_vo62wv_custom_widgets
                      .WordEditor(
                    width: 1270.0,
                    height: 502.0,
                  ),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Divider(
                    thickness: 2.0,
                    color: FlutterFlowTheme.of(context).alternate,
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 0.0, 994.0, 0.0),
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.navigationGenericSecondaryButtonModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericSecondaryButtonWidget(
                            labelText: 'Back',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'NavigationGenericSecondaryButton',
                                    'Notice Writting'),
                            states:
                                t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.byDefault,
                            onTap: () async {},
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 20.0, 0.0),
                        child: t_d_s_login_module_l1_navigation_3he2k0_util
                            .wrapWithModel(
                          model: _model.navigationGenericSecondaryButtonModel2,
                          updateCallback: () => safeSetState(() {}),
                          child: t_d_s_login_module_l1_navigation_3he2k0
                              .NavigationGenericSecondaryButtonWidget(
                            labelText: 'Save',
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL2KeyValuePrefix(
                                    widget!.keyPrefix!,
                                    'NavigationGenericSecondaryButton',
                                    'Notice Writting'),
                            states:
                                t_d_s_login_module_l1_navigation_3he2k0_enums
                                    .ButtonState.byDefault,
                            onTap: () async {},
                          ),
                        ),
                      ),
                      t_d_s_login_module_l1_navigation_3he2k0_util
                          .wrapWithModel(
                        model: _model.navigationGenericPrimaryButtonModel,
                        updateCallback: () => safeSetState(() {}),
                        child: t_d_s_login_module_l1_navigation_3he2k0
                            .NavigationGenericPrimaryButtonWidget(
                          labeltext: 'Proceed',
                          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                              .generateL2KeyValuePrefix(
                                  widget!.keyPrefix!,
                                  'NavigationGenericPrimaryButton',
                                  'Notice Writting'),
                          states: t_d_s_login_module_l1_navigation_3he2k0_enums
                              .ButtonState.byDefault,
                          onTap: () async {},
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
