import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/input_field_generic_date_picker/input_field_generic_date_picker_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'tan_information_box_initiate_notice_model.dart';
export 'tan_information_box_initiate_notice_model.dart';

class TanInformationBoxInitiateNoticeWidget extends StatefulWidget {
  const TanInformationBoxInitiateNoticeWidget({
    super.key,
    required this.keyPrefix,
    this.tanPan,
    this.name,
    this.addressAsPer,
    this.address,
    this.state,
    this.pin,
    this.emailIdAsPer,
    this.emailId,
    this.reasonForInitiationProceeding,
    this.dateOfSurvey,
    this.dateOfHearing,
    this.dateOfBearing,
    this.tanPanAction,
    this.addressAsPerAction,
    this.emailAsPerAction,
  });

  final String? keyPrefix;
  final String? tanPan;
  final String? name;
  final String? addressAsPer;
  final String? address;
  final String? state;
  final String? pin;
  final String? emailIdAsPer;
  final String? emailId;
  final String? reasonForInitiationProceeding;
  final DateTime? dateOfSurvey;
  final DateTime? dateOfHearing;
  final DateTime? dateOfBearing;
  final Future Function()? tanPanAction;
  final Future Function()? addressAsPerAction;
  final Future Function()? emailAsPerAction;

  @override
  State<TanInformationBoxInitiateNoticeWidget> createState() =>
      _TanInformationBoxInitiateNoticeWidgetState();
}

class _TanInformationBoxInitiateNoticeWidgetState
    extends State<TanInformationBoxInitiateNoticeWidget> {
  late TanInformationBoxInitiateNoticeModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TanInformationBoxInitiateNoticeModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 24.0,
      runSpacing: 24.0,
      alignment: WrapAlignment.start,
      crossAxisAlignment: WrapCrossAlignment.start,
      direction: Axis.horizontal,
      runAlignment: WrapAlignment.start,
      verticalDirection: VerticalDirection.down,
      clipBehavior: Clip.none,
      children: [
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.tanPanModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Tan_Pan')),
              hintText: 'Enter TAN/PAN',
              errorText: 'Please enter valid TAN/PAN',
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Tan_Pan'),
              validationRegex:
                  '([A-Z]{5}[0-9]{4}[A-Z])|([A-Z]{4}[0-9]{5}[A-Z])',
              isDisable: false,
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'TAN/PAN',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {
                await widget.tanPanAction?.call();
              },
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.nameModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Name')),
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Name'),
              isDisable: true,
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'Name',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.addressAsPerModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Address_As_Per')),
              initialOption: '',
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Address_As_Per'),
              isDropdownDisable: false,
              showErrorMessage: false,
              labelText: 'Address as Per',
              isMandatory: false,
              dropDownList: [
                "Latest communication made",
                "Latest statement filed",
                "TRACES Profile",
                "TAN/PAN database",
                "E-filing Profile",
                "Latest ITR filed",
                "New Address"
              ],
              onDropDownSelection: (selectedVlaue) async {
                await widget.addressAsPerAction?.call();
              },
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.addressModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Address')),
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Address'),
              isDisable:
                  _model.addressAsPerModel.dropDownValue != 'New Address',
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'Address',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.stateModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'State')),
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'State'),
              isDisable:
                  _model.addressAsPerModel.dropDownValue != 'New Address',
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'State',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.pinModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Pin')),
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Pin'),
              isDisable:
                  _model.addressAsPerModel.dropDownValue != 'New Address',
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'Pin',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.emailAsPerModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Email_As_Per')),
              initialOption: '',
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Email_As_Per'),
              isDropdownDisable: false,
              showErrorMessage: false,
              labelText: 'Email Id as per',
              isMandatory: false,
              dropDownList: [
                "Latest communication made",
                "Latest statement filed",
                "TRACES Profile",
                "TAN/PAN database",
                "E-filing Profile",
                "Latest ITR filed",
                "New Address"
              ],
              onDropDownSelection: (selectedVlaue) async {
                await widget.emailAsPerAction?.call();
              },
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.emailIdModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'EmailId')),
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'EmailId'),
              isDisable: _model.emailAsPerModel.dropDownValue != 'New Address',
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'E-mail ID',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.reasonForInitiationOfProceedingModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Reason_For_Initiation_Of_Proceeding')),
              hintText: 'Select Reason',
              initialOption: '',
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Reason_For_Initiation_Of_Proceeding'),
              isDropdownDisable: false,
              showErrorMessage: false,
              labelText: 'Reason for initiation of Proceeding',
              isMandatory: false,
              dropDownList: [
                "Complaint/Grievance",
                "Survey Case",
                "Tax Audit Report",
                "TEP",
                "Recommendation from other authority"
              ],
              onDropDownSelection: (selectedVlaue) async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: Visibility(
            visible:
                _model.reasonForInitiationOfProceedingModel.dropDownValue ==
                    'Survey Case',
            child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
              model: _model.dateOfSurveyModel,
              updateCallback: () => safeSetState(() {}),
              child: t_d_s_login_module_l1_input_vo62wv
                  .InputFieldGenericDatePickerWidget(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'Tan_Information_Box_Initiate_Notice',
                        'Date_Of_Survey')),
                hintText: 'Select Date of Survey',
                labelText: 'Date of Survey',
                height: 65.0,
                keyPrefix:
                    t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                        widget!.keyPrefix!,
                        'Tan_Information_Box_Initiate_Notice',
                        'Date_Of_Survey'),
                showTooltip: false,
                isMandatory: false,
                showErrorMessage: false,
                onInputValueChangeAction: () async {},
              ),
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.hearingDateAndTimeModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDatePickerWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Hearing_Date_And_Time')),
              hintText: 'Select Hearing Date and Time',
              labelText: 'Hearing Date and Time',
              height: 65.0,
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Hearing_Date_And_Time'),
              showTooltip: false,
              isMandatory: false,
              showErrorMessage: false,
              onInputValueChangeAction: () async {},
            ),
          ),
        ),
        Container(
          constraints: BoxConstraints(
            maxWidth: 407.0,
          ),
          decoration: BoxDecoration(),
          child: t_d_s_login_module_l1_input_vo62wv_util.wrapWithModel(
            model: _model.timeBarringDateModel,
            updateCallback: () => safeSetState(() {}),
            child: t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Time_Barring_Date')),
              keyPrefix:
                  t_d_s_2_l1_logic_2wrus1_functions.generateL2KeyValuePrefix(
                      widget!.keyPrefix!,
                      'Tan_Information_Box_Initiate_Notice',
                      'Time_Barring_Date'),
              isDisable: true,
              isMandatory: false,
              textFieldHeight: 37.0,
              labelText: 'Time Barring Date',
              isViewOnly: false,
              showExternalErrorMessage: false,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ),
      ],
    );
  }
}
