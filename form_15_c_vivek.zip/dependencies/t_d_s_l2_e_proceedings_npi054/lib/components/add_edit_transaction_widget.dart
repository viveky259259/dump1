import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/input_field_generic_date_picker/input_field_generic_date_picker_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_tertiary_button/navigation_generic_tertiary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'add_edit_transaction_model.dart';
export 'add_edit_transaction_model.dart';

class AddEditTransactionWidget extends StatefulWidget {
  const AddEditTransactionWidget({
    super.key,
    required this.keyPrefix,
    this.deducteePan,
    this.deducteeName,
    this.amtPaidCredited,
    this.dateOfPaymentCredit,
    this.section,
    this.natureOfPayment,
    this.taxAmtDeductibleCollectible,
    this.taxAmtDeductedCollected,
    this.dateOfDeduction,
    this.shortNonDeductionCollection,
    this.tdsTcsDeposited,
    this.dateOfDeposit,
    this.shortNonPaymentTdsTcs,
    this.cancelAction,
    this.saveAction,
    this.dialogLabelText,
    this.editTransactionData,
    int? transactionIndex,
  }) : this.transactionIndex = transactionIndex ?? 0;

  final String? keyPrefix;
  final String? deducteePan;
  final String? deducteeName;
  final double? amtPaidCredited;
  final DateTime? dateOfPaymentCredit;
  final String? section;
  final String? natureOfPayment;
  final double? taxAmtDeductibleCollectible;
  final double? taxAmtDeductedCollected;
  final DateTime? dateOfDeduction;
  final double? shortNonDeductionCollection;
  final double? tdsTcsDeposited;
  final DateTime? dateOfDeposit;
  final double? shortNonPaymentTdsTcs;
  final Future Function()? cancelAction;
  final Future Function(
      TransactionStruct transactionData, int transactionIndex)? saveAction;
  final String? dialogLabelText;
  final TransactionStruct? editTransactionData;
  final int transactionIndex;

  @override
  State<AddEditTransactionWidget> createState() =>
      _AddEditTransactionWidgetState();
}

class _AddEditTransactionWidgetState extends State<AddEditTransactionWidget> {
  late AddEditTransactionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddEditTransactionModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.sectionApiResult = await GetSectionsApiCall.call();

      if ((_model.sectionApiResult?.succeeded ?? true)) {
        _model.selctionDropdownList = GetSectionSchemaStruct.maybeFromMap(
            (_model.sectionApiResult?.jsonBody ?? ''));
        safeSetState(() {});
      }
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(50.0, 50.0, 50.0, 50.0),
      child: Container(
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).neutral100,
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 0.0, 0.0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                      child: Text(
                        widget!.dialogLabelText!,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textPrimary,
                              fontSize: 18.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                  ].divide(SizedBox(width: 14.0)),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Divider(
                      thickness: 2.0,
                      color: FlutterFlowTheme.of(context).neutral300,
                    ),
                    Wrap(
                      spacing: 24.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.deducteePanModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                      'Add_Edit_Transaction', 'Deductee_Pan')),
                              hintText: 'Enter Deductee PAN',
                              errorText: 'Please enter valid PAN',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                      'Add_Edit_Transaction', 'Deductee_Pan'),
                              validationRegex: '^[A-Z]{5}[0-9]{4}[A-Z]{1}\$',
                              isDisable: false,
                              isMandatory: false,
                              initialValue:
                                  widget!.editTransactionData?.deducteePan,
                              labelText: 'Deductee PAN',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.deducteeNameModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                      'Add_Edit_Transaction', 'Deductee_Name')),
                              hintText: 'Enter Deductee Name',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                      'Add_Edit_Transaction', 'Deductee_Name'),
                              isDisable: false,
                              isMandatory: false,
                              initialValue:
                                  widget!.editTransactionData?.deducteeName,
                              labelText: 'Deductee Name',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.amtPaidCreditedModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Amt_Paid_Credited')),
                              hintText: 'Enter Amount Paid/Credited',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Amt_Paid_Credited'),
                              isDisable: false,
                              isMandatory: true,
                              initialValue: widget!
                                  .editTransactionData?.amtPaidCredited
                                  ?.toString(),
                              labelText: 'Amount Paid/Credited',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                    Wrap(
                      spacing: 24.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.datePaymentCreditModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDatePickerWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Date_Payment_Credit')),
                              hintText: 'Enter Date of Payment/Credit ',
                              labelText: 'Date of Payment/Credit ',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Date_Payment_Credit'),
                              showTooltip: false,
                              isMandatory: false,
                              showErrorMessage: false,
                              onInputValueChangeAction: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.sectionModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDropdownWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                      'Add_Edit_Transaction', 'Section')),
                              initialOption: '',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(widget!.keyPrefix!,
                                      'Add_Edit_Transaction', 'Section'),
                              isDropdownDisable: false,
                              showErrorMessage: false,
                              labelText: 'Section',
                              isMandatory: true,
                              dropDownList: _model.selctionDropdownList != null
                                  ? _model.selctionDropdownList?.data
                                      ?.firstOrNull?.detail
                                      ?.map((e) => e.sectionCode)
                                      .toList()
                                  : ([]),
                              onDropDownSelection: (selectedVlaue) async {
                                safeSetState(() {
                                  _model.natureOfPaymentModel
                                          .dropDownValueController?.value =
                                      (_model.selctionDropdownList != null
                                              ? _model.selctionDropdownList!
                                                  .data.firstOrNull!.detail
                                                  .where((e) =>
                                                      e.sectionCode ==
                                                      _model.sectionModel
                                                          .dropDownValue)
                                                  .toList()
                                                  .map((e) => e.natureOfPayment)
                                                  .toList()
                                              : ([]))
                                          .firstOrNull!;
                                });
                              },
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.natureOfPaymentModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDropdownWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Nature_Of_Payment')),
                              initialOption: '',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Nature_Of_Payment'),
                              isDropdownDisable: false,
                              showErrorMessage: false,
                              labelText: 'Nature of Payment',
                              isMandatory: false,
                              dropDownList: _model.selctionDropdownList != null
                                  ? _model.selctionDropdownList?.data
                                      ?.firstOrNull?.detail
                                      ?.where((e) =>
                                          e.sectionCode ==
                                          _model.sectionModel.dropDownValue)
                                      .toList()
                                      ?.map((e) => e.natureOfPayment)
                                      .toList()
                                  : ([]),
                              onDropDownSelection: (selectedVlaue) async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                    Wrap(
                      spacing: 24.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.taxAmtDeductibleCollectibleModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Tax_Amt_Deductible_Collectible')),
                              hintText:
                                  'Enter Tax Amount Deductible/Collectible',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Tax_Amt_Deductible_Collectible'),
                              isDisable: false,
                              isMandatory: true,
                              labelText: 'Tax Amount Deductible/Collectible',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.taxAmtDeductedCollectedModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Tax_Amt_Deducted_Collected')),
                              hintText: 'Enter Tax Amount Deducted/Collected',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Tax_Amt_Deducted_Collected'),
                              isDisable: false,
                              isMandatory: true,
                              labelText: 'Tax Amount Deducted/Collected',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.dateOfDeductionModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDatePickerWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Date_Of_Deduction')),
                              hintText: 'Enter Date of Deduction',
                              labelText: 'Date of Deduction',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Date_Of_Deduction'),
                              showTooltip: false,
                              isMandatory: false,
                              showErrorMessage: false,
                              onInputValueChangeAction: () async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                    Wrap(
                      spacing: 24.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.shortNonDeductionCollectionModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Short_Non_Deduction_Collection')),
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Short_Non_Deduction_Collection'),
                              isDisable: true,
                              isMandatory: false,
                              initialValue: functions
                                  .calculateShortNonDeductionTaxAmount(
                                      _model.taxAmtDeductibleCollectibleModel
                                          .genericTextFieldTextController.text,
                                      _model.taxAmtDeductedCollectedModel
                                          .genericTextFieldTextController.text)
                                  .toString(),
                              labelText: 'Short/Non-Deduction/Collection',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.tdsTcsDepositedModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Tds_Tcs_Deposited')),
                              hintText: 'Enter TDS/TCS deposited',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Tds_Tcs_Deposited'),
                              isDisable: false,
                              isMandatory: true,
                              initialValue: widget!
                                  .editTransactionData?.tdsTcsDeposited
                                  ?.toString(),
                              labelText: 'TDS/TCS Deposited',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.dateOfDepositModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericDatePickerWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Date_Of_Deposit')),
                              hintText: 'Enter Date of Deposit',
                              labelText: 'Date of Deposit',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Date_Of_Deposit'),
                              showTooltip: false,
                              isMandatory: false,
                              showErrorMessage: false,
                              onInputValueChangeAction: () async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                    Wrap(
                      spacing: 0.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          constraints: BoxConstraints(
                            maxWidth: 391.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: t_d_s_login_module_l1_input_vo62wv_util
                              .wrapWithModel(
                            model: _model.shortNonPaymentTdsTcsModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_input_vo62wv
                                .InputFieldGenericTextFieldWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Short_Non_Payment_Tds_Tcs')),
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL2KeyValuePrefix(
                                      widget!.keyPrefix!,
                                      'Add_Edit_Transaction',
                                      'Short_Non_Payment_Tds_Tcs'),
                              isDisable: true,
                              isMandatory: false,
                              labelText: 'Short/Non-Payment of TDS/TCS',
                              isViewOnly: false,
                              showExternalErrorMessage: false,
                              onSubmitAction: () async {},
                              onInputValueChangeCallback: (value) async {},
                              onFocusChangeCallback: (hasFocus) async {},
                              onInputValidationCallback: (isValid) async {},
                              onTapLabelTrailingButton: () async {},
                            ),
                          ),
                        ),
                      ],
                    ),
                  ].divide(SizedBox(height: 24.0)),
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Container(
                      height: 64.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).primaryBGStroke5,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(8.0),
                          bottomRight: Radius.circular(8.0),
                          topLeft: Radius.circular(0.0),
                          topRight: Radius.circular(0.0),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          t_d_s_login_module_l1_navigation_3he2k0_util
                              .wrapWithModel(
                            model: _model.navigationGenericTertiaryButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: t_d_s_login_module_l1_navigation_3he2k0
                                .NavigationGenericTertiaryButtonWidget(
                              labelText: 'Cancel',
                              keyPrefix: 'key',
                              states:
                                  t_d_s_login_module_l1_navigation_3he2k0_enums
                                      .ButtonState.byDefault,
                              onTap: () async {
                                Navigator.pop(context);
                              },
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 12.0, 24.0, 16.0),
                            child: t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model: _model.navigationGenericPrimaryButtonModel,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .NavigationGenericPrimaryButtonWidget(
                                labeltext: 'Save',
                                keyPrefix: 'key',
                                states:
                                    t_d_s_login_module_l1_navigation_3he2k0_enums
                                        .ButtonState.byDefault,
                                onTap: () async {
                                  await widget.saveAction?.call(
                                    TransactionStruct(
                                      deducteePan: _model.deducteePanModel
                                          .genericTextFieldTextController.text,
                                      deducteeName: _model.deducteeNameModel
                                          .genericTextFieldTextController.text,
                                      amtPaidCredited: double.tryParse(_model
                                          .amtPaidCreditedModel
                                          .genericTextFieldTextController
                                          .text),
                                      dateOfPaymentCredit: _model
                                          .datePaymentCreditModel.datePicked,
                                      section:
                                          _model.sectionModel.dropDownValue,
                                      natureOfPayment: _model
                                          .natureOfPaymentModel.dropDownValue,
                                      taxAmtDeductibleCollectible:
                                          double.tryParse(_model
                                              .taxAmtDeductibleCollectibleModel
                                              .genericTextFieldTextController
                                              .text),
                                      taxAmtDeductedCollected: double.tryParse(
                                          _model
                                              .taxAmtDeductedCollectedModel
                                              .genericTextFieldTextController
                                              .text),
                                      dateOfDeduction: _model
                                          .dateOfDeductionModel.datePicked,
                                      shortNonDeductionCollection:
                                          double.tryParse(_model
                                              .shortNonDeductionCollectionModel
                                              .genericTextFieldTextController
                                              .text),
                                      tdsTcsDeposited: double.tryParse(_model
                                          .tdsTcsDepositedModel
                                          .genericTextFieldTextController
                                          .text),
                                      dateOfDeposit:
                                          _model.dateOfDepositModel.datePicked,
                                      shortNonPaymentTdsTcs: double.tryParse(
                                          _model
                                              .shortNonPaymentTdsTcsModel
                                              .genericTextFieldTextController
                                              .text),
                                    ),
                                    widget!.transactionIndex,
                                  );
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
