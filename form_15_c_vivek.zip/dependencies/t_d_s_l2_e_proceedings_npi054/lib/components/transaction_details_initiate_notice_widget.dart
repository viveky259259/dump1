import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_presentation_0l6uwx/ao_portal/in_page_notification/in_page_notification_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/file_attachment/file_attachment_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_choice_chip/navigation_choice_chip_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'transaction_details_initiate_notice_model.dart';
export 'transaction_details_initiate_notice_model.dart';

class TransactionDetailsInitiateNoticeWidget extends StatefulWidget {
  const TransactionDetailsInitiateNoticeWidget({
    super.key,
    required this.keyPrefix,
    this.onAddTransaction,
    this.onEditTransaction,
    this.onDeleteTransaction,
    this.offlineUploadedFile,
    this.transactionType,
    this.onDownloadExcel,
    this.onDeleteOfflineUploadedFile,
    this.onViewOfflineUploadedFile,
    this.onBrowseFile,
    this.onRefresH,
    this.transactionList,
  });

  final String? keyPrefix;
  final Future Function()? onAddTransaction;
  final Future Function(TransactionStruct transaction, int transactionIndex)?
      onEditTransaction;
  final Future Function(TransactionStruct transaction)? onDeleteTransaction;
  final List<FFUploadedFile>? offlineUploadedFile;
  final TransactionType? transactionType;
  final Future Function()? onDownloadExcel;
  final Future Function()? onDeleteOfflineUploadedFile;
  final Future Function()? onViewOfflineUploadedFile;
  final Future Function()? onBrowseFile;
  final Future Function()? onRefresH;
  final List<TransactionStruct>? transactionList;

  @override
  State<TransactionDetailsInitiateNoticeWidget> createState() =>
      _TransactionDetailsInitiateNoticeWidgetState();
}

class _TransactionDetailsInitiateNoticeWidgetState
    extends State<TransactionDetailsInitiateNoticeWidget> {
  late TransactionDetailsInitiateNoticeModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => TransactionDetailsInitiateNoticeModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: FlutterFlowTheme.of(context).neutral300,
        ),
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(8.0, 20.0, 8.0, 16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Expanded(
                  child: t_d_s_2_l1_presentation_0l6uwx_util.wrapWithModel(
                    model: _model.inPageNotificationModel,
                    updateCallback: () => safeSetState(() {}),
                    child:
                        t_d_s_2_l1_presentation_0l6uwx.InPageNotificationWidget(
                      keyPrefix: 'key',
                      description:
                          ' 1. To add up to 10 entries, use the Online Entries option. For more than 10 entries, use the Offline Entries option.\n                   2. If deductee level details are not available, please enter section-wise details in the mandatory fields.',
                      states: t_d_s_2_l1_presentation_0l6uwx_enums
                          .AlertTextStatus.Alert,
                    ),
                  ),
                ),
              ],
            ),
            Divider(
              height: 30.0,
              thickness: 1.0,
              indent: 10.0,
              endIndent: 10.0,
              color: FlutterFlowTheme.of(context).neutral300,
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 2.0, 0.0, 2.0),
                  child: Text(
                    'Enter Transactions Details',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).textBasic,
                          fontSize: 16.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
                t_d_s_login_module_l1_navigation_3he2k0_util.wrapWithModel(
                  model: _model.navigationChoiceChipModel,
                  updateCallback: () => safeSetState(() {}),
                  child: t_d_s_login_module_l1_navigation_3he2k0
                      .NavigationChoiceChipWidget(
                    keyPrefix: 'key',
                    options: ["Online Entries", "Offline Entries"],
                  ),
                ),
              ].divide(SizedBox(width: 36.0)),
            ),
            Builder(
              builder: (context) {
                if (_model.navigationChoiceChipModel.choiceChipsValue ==
                    'Online Entries') {
                  return Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 27.0, 0.0, 20.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Transaction Row Summary',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).textBasic,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                            t_d_s_login_module_l1_navigation_3he2k0_util
                                .wrapWithModel(
                              model:
                                  _model.navigationGenericSecondaryButtonModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: t_d_s_login_module_l1_navigation_3he2k0
                                  .NavigationGenericSecondaryButtonWidget(
                                labelText: 'Add Transaction',
                                keyPrefix: 'key',
                                height: 28.0,
                                leftIcon: Icon(
                                  Icons.add,
                                ),
                                states:
                                    t_d_s_login_module_l1_navigation_3he2k0_enums
                                        .ButtonState.byDefault,
                                onTap: () async {
                                  await widget.onAddTransaction?.call();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: double.infinity,
                        child: Builder(
                          builder: (context) {
                            final items =
                                widget!.transactionList?.toList() ?? [];

                            return FlutterFlowDataTable<TransactionStruct>(
                              controller: _model.paginatedDataTableController,
                              data: items,
                              columnsBuilder: (onSortChanged) => [
                                DataColumn2(
                                  label: DefaultTextStyle.merge(
                                    softWrap: true,
                                    child: Text(
                                      'Section',
                                      style: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .override(
                                            fontFamily: 'Inter',
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ),
                                  fixedWidth:
                                      MediaQuery.sizeOf(context).width * 0.2,
                                ),
                                DataColumn2(
                                  label: DefaultTextStyle.merge(
                                    softWrap: true,
                                    child: Text(
                                      'Tax Amount Deductible/Collectible',
                                      style: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .override(
                                            fontFamily: 'Inter',
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ),
                                  fixedWidth:
                                      MediaQuery.sizeOf(context).width * 0.2,
                                ),
                                DataColumn2(
                                  label: DefaultTextStyle.merge(
                                    softWrap: true,
                                    child: Text(
                                      'Tax Amount Deducted/Collected',
                                      style: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .override(
                                            fontFamily: 'Inter',
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ),
                                  fixedWidth:
                                      MediaQuery.sizeOf(context).width * 0.2,
                                ),
                                DataColumn2(
                                  label: DefaultTextStyle.merge(
                                    softWrap: true,
                                    child: Text(
                                      'TDS/TCS Deposited',
                                      style: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .override(
                                            fontFamily: 'Inter',
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ),
                                  fixedWidth:
                                      MediaQuery.sizeOf(context).width * 0.2,
                                ),
                                DataColumn2(
                                  label: DefaultTextStyle.merge(
                                    softWrap: true,
                                    child: Text(
                                      'Action',
                                      style: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .override(
                                            fontFamily: 'Inter',
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ),
                                  fixedWidth:
                                      MediaQuery.sizeOf(context).width * 0.2,
                                ),
                              ],
                              dataRowBuilder: (itemsItem, itemsIndex, selected,
                                      onSelectChanged) =>
                                  DataRow(
                                color: MaterialStateProperty.all(
                                  itemsIndex % 2 == 0
                                      ? FlutterFlowTheme.of(context).neutral100
                                      : FlutterFlowTheme.of(context)
                                          .primaryBGStroke5,
                                ),
                                cells: [
                                  Text(
                                    itemsItem.section,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  Text(
                                    itemsItem.taxAmtDeductibleCollectible
                                        .toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  Text(
                                    itemsItem.taxAmtDeductedCollected
                                        .toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  Text(
                                    itemsItem.tdsTcsDeposited.toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      FlutterFlowIconButton(
                                        borderRadius: 8.0,
                                        buttonSize: 40.0,
                                        hoverColor: FlutterFlowTheme.of(context)
                                            .neutral300,
                                        icon: Icon(
                                          Icons.edit_outlined,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral700,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onEditTransaction?.call(
                                            itemsItem,
                                            itemsIndex,
                                          );
                                        },
                                      ),
                                      FlutterFlowIconButton(
                                        borderRadius: 8.0,
                                        buttonSize: 40.0,
                                        hoverColor: FlutterFlowTheme.of(context)
                                            .neutral300,
                                        icon: Icon(
                                          Icons.auto_delete_outlined,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral800,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onDeleteTransaction
                                              ?.call(
                                            itemsItem,
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ].map((c) => DataCell(c)).toList(),
                              ),
                              paginated: true,
                              selectable: false,
                              hidePaginator: true,
                              showFirstLastButtons: false,
                              width: double.infinity,
                              height: (56 + 48 * (items.length + 1)).toDouble(),
                              headingRowHeight: 56.0,
                              dataRowHeight: 48.0,
                              columnSpacing: 20.0,
                              headingRowColor:
                                  FlutterFlowTheme.of(context).primaryBGStroke5,
                              borderRadius: BorderRadius.circular(0.0),
                              addHorizontalDivider: true,
                              addTopAndBottomDivider: false,
                              hideDefaultHorizontalDivider: true,
                              horizontalDividerColor:
                                  FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                              horizontalDividerThickness: 1.0,
                              addVerticalDivider: false,
                            );
                          },
                        ),
                      ),
                    ],
                  );
                } else {
                  return Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 822.0,
                        child: Divider(
                          height: 24.0,
                          thickness: 1.0,
                          color: FlutterFlowTheme.of(context).neutral300,
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            'Download Excel Utility',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).textBasic,
                                  letterSpacing: 0.0,
                                ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                539.0, 0.0, 0.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                await widget.onDownloadExcel?.call();
                              },
                              child:
                                  t_d_s_login_module_l1_navigation_3he2k0_util
                                      .wrapWithModel(
                                model: _model
                                    .navigationGenericSecondaryButtonModel2,
                                updateCallback: () => safeSetState(() {}),
                                child: t_d_s_login_module_l1_navigation_3he2k0
                                    .NavigationGenericSecondaryButtonWidget(
                                  labelText: 'Excel Utility',
                                  keyPrefix: 'key',
                                  leftIcon: Icon(
                                    Icons.download_outlined,
                                  ),
                                  states:
                                      t_d_s_login_module_l1_navigation_3he2k0_enums
                                          .ButtonState.byDefault,
                                  onTap: () async {},
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        width: 822.0,
                        child: Divider(
                          height: 24.0,
                          thickness: 1.0,
                          color: FlutterFlowTheme.of(context).neutral300,
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Container(
                              width: 399.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Upload File',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  t_d_s_login_module_l1_input_vo62wv_util
                                      .wrapWithModel(
                                    model: _model
                                        .inputfieldFileUploadBrowseFilesModel,
                                    updateCallback: () => safeSetState(() {}),
                                    child: t_d_s_login_module_l1_input_vo62wv
                                        .InputfieldFileUploadBrowseFilesWidget(
                                      height: 56.0,
                                      keyPrefix: 'key',
                                      isDisable: false,
                                      onTapBrowseFiles: () async {
                                        await widget.onBrowseFile?.call();
                                      },
                                    ),
                                  ),
                                ].divide(SizedBox(height: 8.0)),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 25.0, 0.0, 0.0),
                              child: Container(
                                width: 399.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                ),
                                child: t_d_s_login_module_l1_input_vo62wv_util
                                    .wrapWithModel(
                                  model: _model.fileAttachmentModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: t_d_s_login_module_l1_input_vo62wv
                                      .FileAttachmentWidget(
                                    fileName: 'name',
                                    keyPrefix: 'key',
                                    isFileUploaded: false,
                                    height: 48.0,
                                    fileSize: '5',
                                    uploadFailedError: false,
                                    deleteAction: () async {
                                      await widget.onDeleteOfflineUploadedFile
                                          ?.call();
                                    },
                                    onView: () async {
                                      await widget.onViewOfflineUploadedFile
                                          ?.call();
                                    },
                                    onReload: () async {
                                      await widget.onRefresH?.call();
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ].divide(SizedBox(width: 24.0)),
                        ),
                      ),
                    ],
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
