import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'tan_pan_information_box_model.dart';
export 'tan_pan_information_box_model.dart';

class TanPanInformationBoxWidget extends StatefulWidget {
  const TanPanInformationBoxWidget({
    super.key,
    required this.keyPrefix,
    this.heading,
    this.detail,
    this.height,
    this.width,
  });

  final String? keyPrefix;
  final String? heading;
  final String? detail;
  final int? height;
  final int? width;

  @override
  State<TanPanInformationBoxWidget> createState() =>
      _TanPanInformationBoxWidgetState();
}

class _TanPanInformationBoxWidgetState
    extends State<TanPanInformationBoxWidget> {
  late TanPanInformationBoxModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TanPanInformationBoxModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Container(
        decoration: BoxDecoration(),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Text(
              widget!.heading!,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
            ),
            Text(
              widget!.detail!,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
