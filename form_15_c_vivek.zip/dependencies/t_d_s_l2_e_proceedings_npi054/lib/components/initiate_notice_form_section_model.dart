import '/backend/api_requests/api_calls.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/add_edit_transaction_widget.dart';
import '/components/details_documents_text_field_widget.dart';
import '/components/tan_information_box_initiate_notice_widget.dart';
import '/components/transaction_details_initiate_notice_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import '/flutter_flow/random_data_util.dart' as random_data;
import 'initiate_notice_form_section_widget.dart'
    show InitiateNoticeFormSectionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/custom_code/widgets/index.dart'
    as t_d_s_login_module_l1_input_vo62wv_custom_widgets;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_breadcrumbs/navigation_generic_breadcrumbs_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_destructive_button/navigation_generic_destructive_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InitiateNoticeFormSectionModel
    extends FlutterFlowModel<InitiateNoticeFormSectionWidget> {
  ///  Local state fields for this component.

  List<TransactionStruct> transactions = [];
  void addToTransactions(TransactionStruct item) => transactions.add(item);
  void removeFromTransactions(TransactionStruct item) =>
      transactions.remove(item);
  void removeAtIndexFromTransactions(int index) => transactions.removeAt(index);
  void insertAtIndexInTransactions(int index, TransactionStruct item) =>
      transactions.insert(index, item);
  void updateTransactionsAtIndex(
          int index, Function(TransactionStruct) updateFn) =>
      transactions[index] = updateFn(transactions[index]);

  List<String> documents = [];
  void addToDocuments(String item) => documents.add(item);
  void removeFromDocuments(String item) => documents.remove(item);
  void removeAtIndexFromDocuments(int index) => documents.removeAt(index);
  void insertAtIndexInDocuments(int index, String item) =>
      documents.insert(index, item);
  void updateDocumentsAtIndex(int index, Function(String) updateFn) =>
      documents[index] = updateFn(documents[index]);

  List<FFUploadedFile> uploadedFiles = [];
  void addToUploadedFiles(FFUploadedFile item) => uploadedFiles.add(item);
  void removeFromUploadedFiles(FFUploadedFile item) =>
      uploadedFiles.remove(item);
  void removeAtIndexFromUploadedFiles(int index) =>
      uploadedFiles.removeAt(index);
  void insertAtIndexInUploadedFiles(int index, FFUploadedFile item) =>
      uploadedFiles.insert(index, item);
  void updateUploadedFilesAtIndex(
          int index, Function(FFUploadedFile) updateFn) =>
      uploadedFiles[index] = updateFn(uploadedFiles[index]);

  String selectedFinancialYear = 'Select Financial Year';

  FinancialYearApiResponseModelStruct? financialYearDropDownResult;
  void updateFinancialYearDropDownResultStruct(
      Function(FinancialYearApiResponseModelStruct) updateFn) {
    updateFn(
        financialYearDropDownResult ??= FinancialYearApiResponseModelStruct());
  }

  List<String> uploadedFilesNamesList = [];
  void addToUploadedFilesNamesList(String item) =>
      uploadedFilesNamesList.add(item);
  void removeFromUploadedFilesNamesList(String item) =>
      uploadedFilesNamesList.remove(item);
  void removeAtIndexFromUploadedFilesNamesList(int index) =>
      uploadedFilesNamesList.removeAt(index);
  void insertAtIndexInUploadedFilesNamesList(int index, String item) =>
      uploadedFilesNamesList.insert(index, item);
  void updateUploadedFilesNamesListAtIndex(
          int index, Function(String) updateFn) =>
      uploadedFilesNamesList[index] = updateFn(uploadedFilesNamesList[index]);

  t_d_s_login_module_l1_navigation_3he2k0_enums.ButtonState?
      proceedButtonState =
      t_d_s_login_module_l1_navigation_3he2k0_enums.ButtonState.disabled;

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Backend Call - API (finYear)] action in Initiate_Notice_Form_Section widget.
  ApiCallResponse? financialYear;
  // Model for Navigation_Generic_Breadcrumbs component.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationGenericBreadcrumbsModel
      navigationGenericBreadcrumbsModel;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel;
  // Model for Deductor_Type.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      deductorTypeModel;
  // Model for Notice_Us.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      noticeUsModel;
  // Model for Financial_Year.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      financialYearModel;
  // Model for Nature_Of_Default.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      natureOfDefaultModel;
  // Model for Tan_Information_Box_Initiate_Notice component.
  late TanInformationBoxInitiateNoticeModel
      tanInformationBoxInitiateNoticeModel;
  // Stores action output result for [Backend Call - API (getName)] action in Tan_Information_Box_Initiate_Notice widget.
  ApiCallResponse? getNameApiResult;
  // Stores action output result for [Backend Call - API (getAddress)] action in Tan_Information_Box_Initiate_Notice widget.
  ApiCallResponse? getAddressApiResult;
  // Stores action output result for [Backend Call - API (getEmail)] action in Tan_Information_Box_Initiate_Notice widget.
  ApiCallResponse? getEmailAsPerResult;
  // Model for Transaction_Details_Initiate_Notice component.
  late TransactionDetailsInitiateNoticeModel
      transactionDetailsInitiateNoticeModel;
  // Stores action output result for [Backend Call - API (uploadFile)] action in Transaction_Details_Initiate_Notice widget.
  ApiCallResponse? apiResult8lw;
  // Model for Add_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel addButtonModel;
  // Model for Inputfield_File_Upload_BrowseFiles component.
  late t_d_s_login_module_l1_input_vo62wv.InputfieldFileUploadBrowseFilesModel
      inputfieldFileUploadBrowseFilesModel;
  // Stores action output result for [Backend Call - API (uploadFile)] action in Inputfield_File_Upload_BrowseFiles widget.
  ApiCallResponse? apiResult5yw;
  // Model for Back_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel backButtonModel;
  // Model for Save_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel saveButtonModel;
  // Stores action output result for [Backend Call - API (saveNoticeApi)] action in Save_Button widget.
  ApiCallResponse? saveApiResult;
  // Model for Reset_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel resetButtonModel;
  // Model for Proceed_Button.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel proceedButtonModel;

  @override
  void initState(BuildContext context) {
    navigationGenericBreadcrumbsModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericBreadcrumbsModel());
    navigationGenericSecondaryButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    deductorTypeModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    noticeUsModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    financialYearModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    natureOfDefaultModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    tanInformationBoxInitiateNoticeModel =
        createModel(context, () => TanInformationBoxInitiateNoticeModel());
    transactionDetailsInitiateNoticeModel =
        createModel(context, () => TransactionDetailsInitiateNoticeModel());
    addButtonModel = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericSecondaryButtonModel());
    inputfieldFileUploadBrowseFilesModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldFileUploadBrowseFilesModel());
    backButtonModel = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericSecondaryButtonModel());
    saveButtonModel = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericSecondaryButtonModel());
    resetButtonModel = t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
        context,
        () => t_d_s_login_module_l1_navigation_3he2k0
            .NavigationGenericSecondaryButtonModel());
    proceedButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    navigationGenericBreadcrumbsModel.dispose();
    navigationGenericSecondaryButtonModel.dispose();
    deductorTypeModel.dispose();
    noticeUsModel.dispose();
    financialYearModel.dispose();
    natureOfDefaultModel.dispose();
    tanInformationBoxInitiateNoticeModel.dispose();
    transactionDetailsInitiateNoticeModel.dispose();
    addButtonModel.dispose();
    inputfieldFileUploadBrowseFilesModel.dispose();
    backButtonModel.dispose();
    saveButtonModel.dispose();
    resetButtonModel.dispose();
    proceedButtonModel.dispose();
  }
}
