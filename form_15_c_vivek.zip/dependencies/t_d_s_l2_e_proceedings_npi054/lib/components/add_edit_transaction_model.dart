import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:convert';
import 'dart:ui';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/structs/index.dart"
    as t_d_s_2_l1_presentation_0l6uwx_data_schema;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_input_vo62wv_data_schema;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/structs/index.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_data_schema;
import '/flutter_flow/custom_functions.dart' as functions;
import 'add_edit_transaction_widget.dart' show AddEditTransactionWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/input_field_generic_date_picker/input_field_generic_date_picker_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_tertiary_button/navigation_generic_tertiary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddEditTransactionModel
    extends FlutterFlowModel<AddEditTransactionWidget> {
  ///  Local state fields for this component.

  TransactionStruct? transactionDataNew;
  void updateTransactionDataNewStruct(Function(TransactionStruct) updateFn) {
    updateFn(transactionDataNew ??= TransactionStruct());
  }

  String selectedSection = 'Select Section';

  GetSectionSchemaStruct? selctionDropdownList;
  void updateSelctionDropdownListStruct(
      Function(GetSectionSchemaStruct) updateFn) {
    updateFn(selctionDropdownList ??= GetSectionSchemaStruct());
  }

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Backend Call - API (getSectionsApi)] action in Add_Edit_Transaction widget.
  ApiCallResponse? sectionApiResult;
  // Model for Deductee_Pan.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      deducteePanModel;
  // Model for Deductee_Name.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      deducteeNameModel;
  // Model for Amt_Paid_Credited.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      amtPaidCreditedModel;
  // Model for Date_Payment_Credit.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDatePickerModel
      datePaymentCreditModel;
  // Model for Section.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      sectionModel;
  // Model for Nature_Of_Payment.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      natureOfPaymentModel;
  // Model for Tax_Amt_Deductible_Collectible.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      taxAmtDeductibleCollectibleModel;
  // Model for Tax_Amt_Deducted_Collected.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      taxAmtDeductedCollectedModel;
  // Model for Date_Of_Deduction.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDatePickerModel
      dateOfDeductionModel;
  // Model for Short_Non_Deduction_Collection.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      shortNonDeductionCollectionModel;
  // Model for Tds_Tcs_Deposited.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      tdsTcsDepositedModel;
  // Model for Date_Of_Deposit.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDatePickerModel
      dateOfDepositModel;
  // Model for Short_Non_Payment_Tds_Tcs.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      shortNonPaymentTdsTcsModel;
  // Model for Navigation_Generic_Tertiary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericTertiaryButtonModel
      navigationGenericTertiaryButtonModel;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel;

  @override
  void initState(BuildContext context) {
    deducteePanModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    deducteeNameModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    amtPaidCreditedModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    datePaymentCreditModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDatePickerModel());
    sectionModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    natureOfPaymentModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    taxAmtDeductibleCollectibleModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    taxAmtDeductedCollectedModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    dateOfDeductionModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDatePickerModel());
    shortNonDeductionCollectionModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    tdsTcsDepositedModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    dateOfDepositModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDatePickerModel());
    shortNonPaymentTdsTcsModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericTextFieldModel());
    navigationGenericTertiaryButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericTertiaryButtonModel());
    navigationGenericPrimaryButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    deducteePanModel.dispose();
    deducteeNameModel.dispose();
    amtPaidCreditedModel.dispose();
    datePaymentCreditModel.dispose();
    sectionModel.dispose();
    natureOfPaymentModel.dispose();
    taxAmtDeductibleCollectibleModel.dispose();
    taxAmtDeductedCollectedModel.dispose();
    dateOfDeductionModel.dispose();
    shortNonDeductionCollectionModel.dispose();
    tdsTcsDepositedModel.dispose();
    dateOfDepositModel.dispose();
    shortNonPaymentTdsTcsModel.dispose();
    navigationGenericTertiaryButtonModel.dispose();
    navigationGenericPrimaryButtonModel.dispose();
  }
}
