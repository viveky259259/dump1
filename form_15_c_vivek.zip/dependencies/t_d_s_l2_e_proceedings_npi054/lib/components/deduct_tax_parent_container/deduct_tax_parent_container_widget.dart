import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'deduct_tax_parent_container_model.dart';
export 'deduct_tax_parent_container_model.dart';

class DeductTaxParentContainerWidget extends StatefulWidget {
  const DeductTaxParentContainerWidget({
    super.key,
    this.tableHeading,
    String? serialNo,
    this.section,
    this.natureOfPayment,
    this.amountPaidCredited,
    this.taxDeductibleTaxDeductibleon,
    this.taxDeductedTaxDeductedOnTaxDepositedTaxDepositedOn,
    this.amountofShortNonDeductionDelayInMonths,
    this.dynamicChildren,
  }) : this.serialNo = serialNo ?? '';

  final String? tableHeading;
  final String serialNo;
  final String? section;
  final String? natureOfPayment;
  final String? amountPaidCredited;
  final String? taxDeductibleTaxDeductibleon;
  final String? taxDeductedTaxDeductedOnTaxDepositedTaxDepositedOn;
  final String? amountofShortNonDeductionDelayInMonths;
  final String? dynamicChildren;

  @override
  State<DeductTaxParentContainerWidget> createState() =>
      _DeductTaxParentContainerWidgetState();
}

class _DeductTaxParentContainerWidgetState
    extends State<DeductTaxParentContainerWidget> {
  late DeductTaxParentContainerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DeductTaxParentContainerModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Align(
            alignment: AlignmentDirectional(-1.0, -1.0),
            child: Text(
              widget!.tableHeading!,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
            child: Container(
              width: MediaQuery.sizeOf(context).width * 1.0,
              height: MediaQuery.sizeOf(context).height * 5.0,
              decoration: BoxDecoration(
                border: Border.all(
                  color: FlutterFlowTheme.of(context).neutral400,
                ),
              ),
              child: Builder(
                builder: (context) {
                  final hvh = List.generate(random_data.randomInteger(5, 5),
                      (index) => random_data.randomInteger(0, 10)).toList();

                  return FlutterFlowDataTable<int>(
                    controller: _model.paginatedDataTableController,
                    data: hvh,
                    columnsBuilder: (onSortChanged) => [
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!.serialNo,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!.section!,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!.natureOfPayment!,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!.amountPaidCredited!,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!.taxDeductibleTaxDeductibleon!,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!
                                .taxDeductedTaxDeductedOnTaxDepositedTaxDepositedOn!,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            widget!.amountofShortNonDeductionDelayInMonths!,
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                    ],
                    dataRowBuilder:
                        (hvhItem, hvhIndex, selected, onSelectChanged) =>
                            DataRow(
                      color: MaterialStateProperty.all(
                          FlutterFlowTheme.of(context).secondaryBackground),
                      cells: [
                        Text(
                          hvhIndex.toString(),
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        Text(
                          widget!.section!,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        Text(
                          valueOrDefault<String>(
                            widget!.natureOfPayment,
                            'natureOfPayment',
                          ),
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        Text(
                          valueOrDefault<String>(
                            widget!.amountPaidCredited,
                            ' amountPaid',
                          ),
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        Text(
                          valueOrDefault<String>(
                            widget!.taxDeductibleTaxDeductibleon,
                            'taxDeductible',
                          ),
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        Text(
                          valueOrDefault<String>(
                            widget!
                                .taxDeductedTaxDeductedOnTaxDepositedTaxDepositedOn,
                            ' taxDeducted',
                          ),
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                        Text(
                          valueOrDefault<String>(
                            widget!.amountofShortNonDeductionDelayInMonths,
                            ' amountOfShort',
                          ),
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].map((c) => DataCell(c)).toList(),
                    ),
                    paginated: false,
                    selectable: false,
                    columnSpacing: 20.0,
                    headingRowColor:
                        FlutterFlowTheme.of(context).secondaryBackground,
                    borderRadius: BorderRadius.circular(8.0),
                    addHorizontalDivider: true,
                    addTopAndBottomDivider: true,
                    hideDefaultHorizontalDivider: true,
                    horizontalDividerColor:
                        FlutterFlowTheme.of(context).neutral400,
                    horizontalDividerThickness: 1.0,
                    addVerticalDivider: true,
                    verticalDividerColor:
                        FlutterFlowTheme.of(context).neutral400,
                    verticalDividerThickness: 1.0,
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
