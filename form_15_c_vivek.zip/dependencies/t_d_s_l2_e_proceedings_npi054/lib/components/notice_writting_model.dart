import '/backend/schema/structs/index.dart';
import '/components/deduct_tax_parent_container/deduct_tax_parent_container_widget.dart';
import '/components/tan_pan_information_box/tan_pan_information_box_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'notice_writting_widget.dart' show NoticeWrittingWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_state.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_state;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/custom_code/widgets/index.dart'
    as t_d_s_login_module_l1_input_vo62wv_custom_widgets;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/radio_buttons/toggle_button_with_list/toggle_button_with_list_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NoticeWrittingModel extends FlutterFlowModel<NoticeWrittingWidget> {
  ///  Local state fields for this component.

  int? selectedIndexCompState = 0;

  FailureToDeductApiResponseModelStruct? failureToDeductTax;
  void updateFailureToDeductTaxStruct(
      Function(FailureToDeductApiResponseModelStruct) updateFn) {
    updateFn(failureToDeductTax ??= FailureToDeductApiResponseModelStruct());
  }

  ///  State fields for stateful widgets in this component.

  // Model for TanPanInformationBox component.
  late TanPanInformationBoxModel tanPanInformationBoxModel1;
  // Model for TanPanInformationBox component.
  late TanPanInformationBoxModel tanPanInformationBoxModel2;
  // Model for TanPanInformationBox component.
  late TanPanInformationBoxModel tanPanInformationBoxModel3;
  // Model for TanPanInformationBox component.
  late TanPanInformationBoxModel tanPanInformationBoxModel4;
  // Model for DeductTax_Parent_Container component.
  late DeductTaxParentContainerModel deductTaxParentContainerModel1;
  // Model for DeductTax_Parent_Container component.
  late DeductTaxParentContainerModel deductTaxParentContainerModel2;
  // Model for DeductTax_Parent_Container component.
  late DeductTaxParentContainerModel deductTaxParentContainerModel3;
  // Model for DeductTax_Parent_Container component.
  late DeductTaxParentContainerModel deductTaxParentContainerModel4;
  // Model for ToggleButton_With_List component.
  late t_d_s_login_module_l1_input_vo62wv.ToggleButtonWithListModel
      toggleButtonWithListModel;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel;

  @override
  void initState(BuildContext context) {
    tanPanInformationBoxModel1 =
        createModel(context, () => TanPanInformationBoxModel());
    tanPanInformationBoxModel2 =
        createModel(context, () => TanPanInformationBoxModel());
    tanPanInformationBoxModel3 =
        createModel(context, () => TanPanInformationBoxModel());
    tanPanInformationBoxModel4 =
        createModel(context, () => TanPanInformationBoxModel());
    deductTaxParentContainerModel1 =
        createModel(context, () => DeductTaxParentContainerModel());
    deductTaxParentContainerModel2 =
        createModel(context, () => DeductTaxParentContainerModel());
    deductTaxParentContainerModel3 =
        createModel(context, () => DeductTaxParentContainerModel());
    deductTaxParentContainerModel4 =
        createModel(context, () => DeductTaxParentContainerModel());
    toggleButtonWithListModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () =>
                t_d_s_login_module_l1_input_vo62wv.ToggleButtonWithListModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    tanPanInformationBoxModel1.dispose();
    tanPanInformationBoxModel2.dispose();
    tanPanInformationBoxModel3.dispose();
    tanPanInformationBoxModel4.dispose();
    deductTaxParentContainerModel1.dispose();
    deductTaxParentContainerModel2.dispose();
    deductTaxParentContainerModel3.dispose();
    deductTaxParentContainerModel4.dispose();
    toggleButtonWithListModel.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel.dispose();
  }
}
