import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/input_field_generic_date_picker/input_field_generic_date_picker_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'tan_information_box_initiate_notice_widget.dart'
    show TanInformationBoxInitiateNoticeWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TanInformationBoxInitiateNoticeModel
    extends FlutterFlowModel<TanInformationBoxInitiateNoticeWidget> {
  ///  Local state fields for this component.

  String addressAsPer = 'Latest Correspondance';

  String emailAsPer = 'Latest Correspondance';

  String address = ' ';

  String state = ' ';

  String pin = ' ';

  String emailId = ' ';

  String name = '  ';

  ///  State fields for stateful widgets in this component.

  // Model for Tan_Pan.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      tanPanModel;
  // Model for Name.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      nameModel;
  // Model for Address_As_Per.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      addressAsPerModel;
  // Model for Address.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      addressModel;
  // Model for State.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      stateModel;
  // Model for Pin.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      pinModel;
  // Model for Email_As_Per.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      emailAsPerModel;
  // Model for EmailId.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      emailIdModel;
  // Model for Reason_For_Initiation_Of_Proceeding.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDropdownModel
      reasonForInitiationOfProceedingModel;
  // Model for Date_Of_Survey.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDatePickerModel
      dateOfSurveyModel;
  // Model for Hearing_Date_And_Time.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericDatePickerModel
      hearingDateAndTimeModel;
  // Model for Time_Barring_Date.
  late t_d_s_login_module_l1_input_vo62wv.InputFieldGenericTextFieldModel
      timeBarringDateModel;

  @override
  void initState(BuildContext context) {
    tanPanModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    nameModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    addressAsPerModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    addressModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    stateModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    pinModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    emailAsPerModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDropdownModel());
    emailIdModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
    reasonForInitiationOfProceedingModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDropdownModel());
    dateOfSurveyModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericDatePickerModel());
    hearingDateAndTimeModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputFieldGenericDatePickerModel());
    timeBarringDateModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv
            .InputFieldGenericTextFieldModel());
  }

  @override
  void dispose() {
    tanPanModel.dispose();
    nameModel.dispose();
    addressAsPerModel.dispose();
    addressModel.dispose();
    stateModel.dispose();
    pinModel.dispose();
    emailAsPerModel.dispose();
    emailIdModel.dispose();
    reasonForInitiationOfProceedingModel.dispose();
    dateOfSurveyModel.dispose();
    hearingDateAndTimeModel.dispose();
    timeBarringDateModel.dispose();
  }
}
