import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import "package:t_d_s_2_l1_presentation_0l6uwx/backend/schema/enums/enums.dart"
    as t_d_s_2_l1_presentation_0l6uwx_enums;
import "package:t_d_s_login_module_l1_input_vo62wv/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_input_vo62wv_enums;
import "package:t_d_s_login_module_l1_navigation_3he2k0/backend/schema/enums/enums.dart"
    as t_d_s_login_module_l1_navigation_3he2k0_enums;
import 'package:t_d_s_2_l1_presentation_0l6uwx/ao_portal/in_page_notification/in_page_notification_widget.dart'
    as t_d_s_2_l1_presentation_0l6uwx;
import 'package:t_d_s_2_l1_presentation_0l6uwx/app_constants.dart'
    as t_d_s_2_l1_presentation_0l6uwx_app_constant;
import 'package:t_d_s_2_l1_presentation_0l6uwx/flutter_flow/flutter_flow_util.dart'
    as t_d_s_2_l1_presentation_0l6uwx_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/app_constants.dart'
    as t_d_s_login_module_l1_input_vo62wv_app_constant;
import 'package:t_d_s_login_module_l1_input_vo62wv/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_input_vo62wv_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/file_attachment/file_attachment_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_input_vo62wv/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart'
    as t_d_s_login_module_l1_input_vo62wv;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_choice_chip/navigation_choice_chip_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart'
    as t_d_s_login_module_l1_navigation_3he2k0;
import 'package:t_d_s_login_module_l1_navigation_3he2k0/flutter_flow/flutter_flow_util.dart'
    as t_d_s_login_module_l1_navigation_3he2k0_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'transaction_details_initiate_notice_widget.dart'
    show TransactionDetailsInitiateNoticeWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TransactionDetailsInitiateNoticeModel
    extends FlutterFlowModel<TransactionDetailsInitiateNoticeWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for In_Page_Notification component.
  late t_d_s_2_l1_presentation_0l6uwx.InPageNotificationModel
      inPageNotificationModel;
  // Model for Navigation_ChoiceChip component.
  late t_d_s_login_module_l1_navigation_3he2k0.NavigationChoiceChipModel
      navigationChoiceChipModel;
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // State field(s) for PaginatedDataTable widget.
  final paginatedDataTableController =
      FlutterFlowDataTableController<TransactionStruct>();
  // Model for Navigation_Generic_Secondary_Button component.
  late t_d_s_login_module_l1_navigation_3he2k0
      .NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Inputfield_File_Upload_BrowseFiles component.
  late t_d_s_login_module_l1_input_vo62wv.InputfieldFileUploadBrowseFilesModel
      inputfieldFileUploadBrowseFilesModel;
  // Model for File_Attachment component.
  late t_d_s_login_module_l1_input_vo62wv.FileAttachmentModel
      fileAttachmentModel;

  @override
  void initState(BuildContext context) {
    inPageNotificationModel = t_d_s_2_l1_presentation_0l6uwx_util.createModel(
        context,
        () => t_d_s_2_l1_presentation_0l6uwx.InPageNotificationModel());
    navigationChoiceChipModel =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationChoiceChipModel());
    navigationGenericSecondaryButtonModel1 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        t_d_s_login_module_l1_navigation_3he2k0_util.createModel(
            context,
            () => t_d_s_login_module_l1_navigation_3he2k0
                .NavigationGenericSecondaryButtonModel());
    inputfieldFileUploadBrowseFilesModel =
        t_d_s_login_module_l1_input_vo62wv_util.createModel(
            context,
            () => t_d_s_login_module_l1_input_vo62wv
                .InputfieldFileUploadBrowseFilesModel());
    fileAttachmentModel = t_d_s_login_module_l1_input_vo62wv_util.createModel(
        context,
        () => t_d_s_login_module_l1_input_vo62wv.FileAttachmentModel());
  }

  @override
  void dispose() {
    inPageNotificationModel.dispose();
    navigationChoiceChipModel.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    paginatedDataTableController.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    inputfieldFileUploadBrowseFilesModel.dispose();
    fileAttachmentModel.dispose();
  }
}
