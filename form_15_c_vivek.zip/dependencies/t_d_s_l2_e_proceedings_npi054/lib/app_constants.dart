import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const List<String> noticeUnderSectionOptionsForTan = [
    '201(1A)',
    '206C(6A)',
    '206C(7)'
  ];
  static const List<String> noticeUnderSectionOptionsForPan = ['201(1A)'];
  static const double tableRowHeight = 44.0;
}
