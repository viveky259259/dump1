import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'input_field_generic_radio_buttton_widget.dart'
    show InputFieldGenericRadioButttonWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericRadioButttonModel
    extends FlutterFlowModel<InputFieldGenericRadioButttonWidget> {
  ///  Local state fields for this component.

  String? selectedOption;

  ///  State fields for stateful widgets in this component.

  // Model for InputField_Generic_LabelText component.
  late InputFieldGenericLabelTextModel inputFieldGenericLabelTextModel;
  // State field(s) for VerticalRadioButton widget.
  FormFieldController<String>? verticalRadioButtonValueController;
  // State field(s) for HorizontalRadioButton widget.
  FormFieldController<String>? horizontalRadioButtonValueController;

  @override
  void initState(BuildContext context) {
    inputFieldGenericLabelTextModel =
        createModel(context, () => InputFieldGenericLabelTextModel());
  }

  @override
  void dispose() {
    inputFieldGenericLabelTextModel.dispose();
  }

  /// Additional helper methods.
  String? get verticalRadioButtonValue =>
      verticalRadioButtonValueController?.value;
  String? get horizontalRadioButtonValue =>
      horizontalRadioButtonValueController?.value;
}
