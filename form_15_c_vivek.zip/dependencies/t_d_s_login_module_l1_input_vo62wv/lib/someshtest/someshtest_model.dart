import '/components/chip_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'someshtest_widget.dart' show SomeshtestWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SomeshtestModel extends FlutterFlowModel<SomeshtestWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for ChipDropdown component.
  late ChipDropdownModel chipDropdownModel;

  @override
  void initState(BuildContext context) {
    chipDropdownModel = createModel(context, () => ChipDropdownModel());
  }

  @override
  void dispose() {
    chipDropdownModel.dispose();
  }
}
