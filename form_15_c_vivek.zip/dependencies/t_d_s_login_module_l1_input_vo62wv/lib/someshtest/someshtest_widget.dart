import '/components/chip_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'someshtest_model.dart';
export 'someshtest_model.dart';

class SomeshtestWidget extends StatefulWidget {
  const SomeshtestWidget({super.key});

  @override
  State<SomeshtestWidget> createState() => _SomeshtestWidgetState();
}

class _SomeshtestWidgetState extends State<SomeshtestWidget> {
  late SomeshtestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SomeshtestModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.chipDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: ChipDropdownWidget(
                  keyPrefix: 'ntg2',
                  labelName: 'Hello',
                  optionList: ["hi", "hello"],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
