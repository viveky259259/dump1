import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_button/text_button_widget.dart';
import 'dart:ui';
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_text_field_model.dart';
export 'input_field_generic_text_field_model.dart';

/// "A versatile input field component without LabelText designed for various
/// text entry needs.
///
///
///
/// ### Parameters:
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText**: `String`
///   Displays an error message if validation fails.
///
/// - **validationRegex**: `String`
///   A regular expression pattern used to validate the input, allowing for
/// specific format constraints.
///
/// - **minLines**: `int`
///   Sets the minimum number of lines for the text field.
///
/// - **maxLines**: `int`
///   Sets the maximum number of lines for the text field.
///
/// ### State Variables:
/// - **isValid**: `bool`
///   Indicates input validity based on the applied regex and mandatory
/// status.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   hintText: 'Full name',
///   errorText: 'Name cannot be empty',
///   validationRegex: r'^[a-zA-Z ]+$',
///   minLines: 1,
///   maxLines: 3,
/// )"
class InputFieldGenericTextFieldWidget extends StatefulWidget {
  const InputFieldGenericTextFieldWidget({
    super.key,
    this.hintText,
    String? errorText,
    this.minLines,
    this.maxLines,
    this.width,
    required this.keyPrefix,
    this.validationRegex,
    bool? isDisable,
    bool? isMandatory,
    this.onSubmitAction,
    this.onInputValueChangeCallback,
    this.onFocusChangeCallback,
    this.trailingIcon,
    this.textFieldHeight,
    this.onInputValidationCallback,
    String? initialValue,
    required this.labelText,
    this.toolTipMessage,
    this.labelTrailingButtonText,
    this.onTapLabelTrailingButton,
    Color? textColourTrailingButtonText,
    bool? isViewOnly,
    bool? showExternalErrorMessage,
    this.maxLength,
  })  : this.errorText = errorText ?? ' ',
        this.isDisable = isDisable ?? false,
        this.isMandatory = isMandatory ?? false,
        this.initialValue = initialValue ?? '',
        this.textColourTrailingButtonText =
            textColourTrailingButtonText ?? const Color(0xFF076BCF),
        this.isViewOnly = isViewOnly ?? false,
        this.showExternalErrorMessage = showExternalErrorMessage ?? false;

  final String? hintText;
  final String errorText;
  final int? minLines;
  final int? maxLines;
  final double? width;
  final String? keyPrefix;
  final String? validationRegex;
  final bool isDisable;
  final bool isMandatory;
  final Future Function()? onSubmitAction;
  final Future Function(String? value)? onInputValueChangeCallback;
  final Future Function(bool hasFocus)? onFocusChangeCallback;
  final Widget? trailingIcon;
  final double? textFieldHeight;
  final Future Function(bool isValid)? onInputValidationCallback;
  final String initialValue;
  final String? labelText;
  final String? toolTipMessage;
  final String? labelTrailingButtonText;
  final Future Function()? onTapLabelTrailingButton;
  final Color textColourTrailingButtonText;
  final bool isViewOnly;
  final bool showExternalErrorMessage;
  final int? maxLength;

  @override
  State<InputFieldGenericTextFieldWidget> createState() =>
      _InputFieldGenericTextFieldWidgetState();
}

class _InputFieldGenericTextFieldWidgetState
    extends State<InputFieldGenericTextFieldWidget> {
  late InputFieldGenericTextFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericTextFieldModel());

    _model.genericTextFieldTextController ??=
        TextEditingController(text: widget!.initialValue);
    _model.genericTextFieldFocusNode ??= FocusNode();
    _model.genericTextFieldFocusNode!.addListener(
      () async {
        await Future.wait([
          Future(() async {
            if ((_model.genericTextFieldFocusNode?.hasFocus ?? false)) {
              return;
            }

            _model.hasBeenFocussed = true;
            safeSetState(() {});
            return;
          }),
          Future(() async {
            // Execute focus change callback
            await widget.onFocusChangeCallback?.call(
              (_model.genericTextFieldFocusNode?.hasFocus ?? false),
            );
            if (!(_model.genericTextFieldFocusNode?.hasFocus ?? false) &&
                _model.hasBeenFocussed) {
              await _model.validateTextField(context);
              // execute onValid Callback
              await widget.onInputValidationCallback?.call(
                _model.isInputValid,
              );
              return;
            }
          }),
        ]);
      },
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      constraints: BoxConstraints(
        maxWidth: 406.0,
      ),
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Builder(
            builder: (context) {
              if (widget!.isViewOnly) {
                return Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  RichText(
                                    textScaler:
                                        MediaQuery.of(context).textScaler,
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: widget!.labelText!,
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .textBasic,
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                        TextSpan(
                                          text: widget!.isMandatory ? '*' : ' ',
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Inter',
                                                color: Color(0xFFB3261D),
                                                letterSpacing: 0.0,
                                              ),
                                        )
                                      ],
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: FlutterFlowTheme.of(context)
                                                .textBasic,
                                            fontSize: 12.0,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                  ),
                                  if (widget!.toolTipMessage != null &&
                                      widget!.toolTipMessage != '')
                                    AlignedTooltip(
                                      content: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Text(
                                          widget!.toolTipMessage!,
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .alternate,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      offset: 4.0,
                                      preferredDirection: AxisDirection.up,
                                      borderRadius: BorderRadius.circular(8.0),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context)
                                              .neutral1000,
                                      elevation: 4.0,
                                      tailBaseWidth: 24.0,
                                      tailLength: 12.0,
                                      waitDuration: Duration(milliseconds: 100),
                                      showDuration:
                                          Duration(milliseconds: 1500),
                                      triggerMode: TooltipTriggerMode.tap,
                                      child: Icon(
                                        Icons.info_outline,
                                        color: FlutterFlowTheme.of(context)
                                            .neutral800,
                                        size: 15.0,
                                      ),
                                    ),
                                ],
                              ),
                              if (widget!.labelTrailingButtonText != null &&
                                  widget!.labelTrailingButtonText != '')
                                wrapWithModel(
                                  model: _model.textButtonModel1,
                                  updateCallback: () => safeSetState(() {}),
                                  child: TextButtonWidget(
                                    label: widget!.labelTrailingButtonText,
                                    textColour:
                                        widget!.textColourTrailingButtonText,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'InputField_Generic_TextField',
                                            'Text_Button'),
                                    onTap: () async {
                                      await widget.onTapLabelTrailingButton
                                          ?.call();
                                    },
                                  ),
                                ),
                            ].divide(SizedBox(width: 2.0)),
                          ),
                          Text(
                            widget!.initialValue,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).textBasic,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ].divide(SizedBox(height: 8.0)),
                      ),
                    ),
                  ],
                );
              } else {
                return Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  RichText(
                                    textScaler:
                                        MediaQuery.of(context).textScaler,
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: widget!.labelText!,
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .textBasic,
                                                fontSize: 12.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                        TextSpan(
                                          text: widget!.isMandatory ? '*' : ' ',
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Inter',
                                                color: Color(0xFFB3261D),
                                                letterSpacing: 0.0,
                                              ),
                                        )
                                      ],
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: FlutterFlowTheme.of(context)
                                                .textBasic,
                                            fontSize: 12.0,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                  ),
                                  if (widget!.toolTipMessage != null &&
                                      widget!.toolTipMessage != '')
                                    AlignedTooltip(
                                      content: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Text(
                                          widget!.toolTipMessage!,
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .alternate,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      offset: 4.0,
                                      preferredDirection: AxisDirection.up,
                                      borderRadius: BorderRadius.circular(8.0),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context)
                                              .neutral1000,
                                      elevation: 4.0,
                                      tailBaseWidth: 24.0,
                                      tailLength: 12.0,
                                      waitDuration: Duration(milliseconds: 100),
                                      showDuration:
                                          Duration(milliseconds: 1500),
                                      triggerMode: TooltipTriggerMode.tap,
                                      child: Icon(
                                        Icons.info_outline,
                                        color: FlutterFlowTheme.of(context)
                                            .neutral800,
                                        size: 15.0,
                                      ),
                                    ),
                                ],
                              ),
                              if (widget!.labelTrailingButtonText != null &&
                                  widget!.labelTrailingButtonText != '')
                                wrapWithModel(
                                  model: _model.textButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: TextButtonWidget(
                                    label: widget!.labelTrailingButtonText,
                                    textColour:
                                        widget!.textColourTrailingButtonText,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'InputField_Generic_TextField',
                                            'Text_Button'),
                                    onTap: () async {
                                      await widget.onTapLabelTrailingButton
                                          ?.call();
                                    },
                                  ),
                                ),
                            ].divide(SizedBox(width: 2.0)),
                          ),
                          Container(
                            height: widget!.textFieldHeight,
                            decoration: BoxDecoration(),
                            child: Semantics(
                              label:
                                  'This is the textField to enter the Input.',
                              child: TextFormField(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_TextField',
                                        'Generic_TextField')),
                                controller:
                                    _model.genericTextFieldTextController,
                                focusNode: _model.genericTextFieldFocusNode,
                                onChanged: (_) => EasyDebounce.debounce(
                                  '_model.genericTextFieldTextController',
                                  Duration(milliseconds: 200),
                                  () async {
                                    // Execute callback
                                    await widget.onInputValueChangeCallback
                                        ?.call(
                                      _model
                                          .genericTextFieldTextController.text,
                                    );
                                    if (_model.hasBeenFocussed) {
                                      // run Validation
                                      await _model.validateTextField(context);
                                      safeSetState(() {});
                                      // execute onValidation callback
                                      await widget.onInputValidationCallback
                                          ?.call(
                                        _model.isInputValid,
                                      );
                                      return;
                                    } else {
                                      return;
                                    }
                                  },
                                ),
                                onFieldSubmitted: (_) async {
                                  await widget.onSubmitAction?.call();
                                },
                                autofocus: false,
                                readOnly: widget!.isDisable,
                                obscureText: false,
                                decoration: InputDecoration(
                                  isDense: true,
                                  labelStyle: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        letterSpacing: 0.0,
                                      ),
                                  hintText: widget!.hintText,
                                  hintStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .neutral600,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: _model.showError &&
                                              (_model.errorMessage != null &&
                                                  _model.errorMessage != '')
                                          ? FlutterFlowTheme.of(context)
                                              .danger500Default
                                          : FlutterFlowTheme.of(context)
                                              .neutral400,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: _model.showError &&
                                              (_model.errorMessage != null &&
                                                  _model.errorMessage != '')
                                          ? FlutterFlowTheme.of(context)
                                              .danger500Default
                                          : FlutterFlowTheme.of(context)
                                              .secondaryInfo500Default,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: FlutterFlowTheme.of(context)
                                          .danger500Default,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  focusedErrorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: FlutterFlowTheme.of(context)
                                          .danger500Default,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  filled: true,
                                  fillColor: valueOrDefault<Color>(
                                    widget!.isDisable
                                        ? FlutterFlowTheme.of(context)
                                            .neutralBGStroke10
                                        : FlutterFlowTheme.of(context)
                                            .neutral100,
                                    FlutterFlowTheme.of(context).neutral100,
                                  ),
                                  suffixIcon: widget!.trailingIcon,
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: valueOrDefault<Color>(
                                        widget!.isDisable
                                            ? FlutterFlowTheme.of(context)
                                                .neutral700
                                            : FlutterFlowTheme.of(context)
                                                .textBasic,
                                        FlutterFlowTheme.of(context).textBasic,
                                      ),
                                      letterSpacing: 0.0,
                                    ),
                                maxLines: widget!.maxLines,
                                minLines: widget!.minLines,
                                maxLength: widget!.maxLength,
                                maxLengthEnforcement:
                                    MaxLengthEnforcement.enforced,
                                buildCounter: (context,
                                        {required currentLength,
                                        required isFocused,
                                        maxLength}) =>
                                    null,
                                cursorColor:
                                    FlutterFlowTheme.of(context).primaryText,
                                validator: _model
                                    .genericTextFieldTextControllerValidator
                                    .asValidator(context),
                              ),
                            ),
                          ),
                          if ((_model.showError &&
                                  (_model.errorMessage != null &&
                                      _model.errorMessage != '')) ||
                              widget!.showExternalErrorMessage)
                            Semantics(
                              label:
                                  'This is the text which will be displayed as error message.',
                              child: Text(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_TextField',
                                        'errorText')),
                                widget!.errorText,
                                style: FlutterFlowTheme.of(context)
                                    .bodySmall
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .danger500Default,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ),
                        ].divide(SizedBox(height: 8.0)),
                      ),
                    ),
                  ],
                );
              }
            },
          ),
        ],
      ),
    );
  }
}
