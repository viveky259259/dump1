import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_dropdown_model.dart';
export 'input_field_generic_dropdown_model.dart';

/// "A versatile Dropdown component without LabelText designed for various
/// dropdown needs.
///
///
///
/// ### Parameters:
/// - **dropdownOptions**: 'List<String>'
///   List of options present in dropdown
///
/// - **initialSelectedField** : 'String'
///    specific initial value which is their in dropdown
///
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText**: `String`
///   Displays an error message if validation fails.
///
/// - **isSearchable**: `bool`
///   specific whether the dropdown is searchable or not.
///
/// - **isMultiSelect**: 'bool'
///   specific whether the dropdown is multiSelectable or not.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   dropdownOptions: ['Delhi', 'Mumbai'],
///   initialSelectedvalue : Delhi
///   hintText: 'Select state',
///   errorText: 'State is mandatory',
///   isSearchable: ,
///   isMultiSelect:
/// )"
class InputFieldGenericDropdownWidget extends StatefulWidget {
  const InputFieldGenericDropdownWidget({
    super.key,
    this.hintText,
    this.initialOption,
    required this.keyPrefix,
    this.dropDownList,
    bool? isDropdownDisable,
    this.onDropDownSelection,
    this.errorMessgae,
    bool? showErrorMessage,
    required this.labelText,
    this.isMandatory,
  })  : this.isDropdownDisable = isDropdownDisable ?? false,
        this.showErrorMessage = showErrorMessage ?? true;

  final String? hintText;
  final String? initialOption;
  final String? keyPrefix;
  final List<String>? dropDownList;
  final bool isDropdownDisable;
  final Future Function(String selectedVlaue)? onDropDownSelection;
  final String? errorMessgae;
  final bool showErrorMessage;
  final String? labelText;
  final bool? isMandatory;

  @override
  State<InputFieldGenericDropdownWidget> createState() =>
      _InputFieldGenericDropdownWidgetState();
}

class _InputFieldGenericDropdownWidgetState
    extends State<InputFieldGenericDropdownWidget> {
  late InputFieldGenericDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericDropdownModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          wrapWithModel(
            model: _model.inputFieldGenericLabelTextModel,
            updateCallback: () => safeSetState(() {}),
            child: InputFieldGenericLabelTextWidget(
              labelText: widget!.labelText!,
              isMandatory: widget!.isMandatory,
              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                  widget!.keyPrefix!,
                  'InputField_Generic_DropDown',
                  'DropDown'),
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              _model.hasTapped = false;
              safeSetState(() {});
            },
            child: Container(
              height: 37.0,
              decoration: BoxDecoration(),
              child: Semantics(
                label: 'This is the dropdown component.',
                child: FlutterFlowDropDown<String>(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'InputField_Generic_Dropdown',
                          'DropDown')),
                  controller: _model.dropDownValueController ??=
                      FormFieldController<String>(null),
                  options: widget!.dropDownList!,
                  onChanged: (val) async {
                    safeSetState(() => _model.dropDownValue = val);
                    await widget.onDropDownSelection?.call(
                      _model.dropDownValue!,
                    );
                  },
                  textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).secondaryText,
                        letterSpacing: 0.0,
                      ),
                  hintText: widget!.hintText,
                  icon: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: FlutterFlowTheme.of(context).neutral800,
                    size: 20.0,
                  ),
                  fillColor: widget!.isDropdownDisable
                      ? Color(0xFFE7E8EA)
                      : FlutterFlowTheme.of(context).neutral100,
                  elevation: 1.0,
                  borderColor: FlutterFlowTheme.of(context).neutral400,
                  borderWidth: 1.0,
                  borderRadius: 4.0,
                  margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                  hidesUnderline: true,
                  disabled: widget!.isDropdownDisable,
                  isOverButton: false,
                  isSearchable: false,
                  isMultiSelect: false,
                ),
              ),
            ),
          ),
          if (widget!.showErrorMessage &&
              (_model.dropDownValue == null || _model.dropDownValue == '') &&
              _model.hasTapped)
            Semantics(
              label:
                  'This is the text which will be displayed as error message.',
              child: Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'InputField_Generic_TextField',
                        'errorText')),
                widget!.errorMessgae!,
                style: FlutterFlowTheme.of(context).bodySmall.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).danger500Default,
                      letterSpacing: 0.0,
                      fontWeight: FontWeight.w500,
                    ),
              ),
            ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
