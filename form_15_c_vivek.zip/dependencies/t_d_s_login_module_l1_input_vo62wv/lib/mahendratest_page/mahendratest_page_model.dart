import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart';
import 'dart:ui';
import 'mahendratest_page_widget.dart' show MahendratestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MahendratestPageModel extends FlutterFlowModel<MahendratestPageWidget> {
  ///  Local state fields for this page.

  String dropDownSelectedValue = 'Delhi';

  ///  State fields for stateful widgets in this page.

  // Model for InputField_Generic_Dropdown component.
  late InputFieldGenericDropdownModel inputFieldGenericDropdownModel;

  @override
  void initState(BuildContext context) {
    inputFieldGenericDropdownModel =
        createModel(context, () => InputFieldGenericDropdownModel());
  }

  @override
  void dispose() {
    inputFieldGenericDropdownModel.dispose();
  }
}
