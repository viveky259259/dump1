export 'init_app_config_from_environment.dart'
    show initAppConfigFromEnvironment;
export 'init_global_app_information.dart' show initGlobalAppInformation;
