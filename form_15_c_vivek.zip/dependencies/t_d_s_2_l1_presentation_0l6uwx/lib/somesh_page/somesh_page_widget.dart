import '/backend/schema/structs/index.dart';
import '/components/expandtable_c_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'somesh_page_model.dart';
export 'somesh_page_model.dart';

class SomeshPageWidget extends StatefulWidget {
  const SomeshPageWidget({super.key});

  @override
  State<SomeshPageWidget> createState() => _SomeshPageWidgetState();
}

class _SomeshPageWidgetState extends State<SomeshPageWidget> {
  late SomeshPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SomeshPageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.addToDemo(TableExpandViewStruct(
        dateTime: DateTime.fromMicrosecondsSinceEpoch(1740648600000000),
        description: 'ntg',
        status: 'Reply Received from Deductor',
        dispatchDetails: 'hello',
        isExpanded: false,
      ));
      safeSetState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.expandtableCModel,
                updateCallback: () => safeSetState(() {}),
                child: ExpandtableCWidget(
                  tableExpandDataList: _model.demo,
                  keyPrefix: 'ntg',
                  prevIcon: () async {},
                  downIcon: () async {},
                ),
              ),
              Text(
                'Hello World',
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
