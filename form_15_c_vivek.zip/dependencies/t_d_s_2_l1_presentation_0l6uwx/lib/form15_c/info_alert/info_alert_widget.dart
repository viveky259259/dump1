import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'info_alert_model.dart';
export 'info_alert_model.dart';

class InfoAlertWidget extends StatefulWidget {
  const InfoAlertWidget({
    super.key,
    required this.description,
    required this.status,
    required this.keyPrifix,
    required this.noofPoints,
  });

  final String? description;
  final AlertTextStatus? status;
  final String? keyPrifix;
  final List<String>? noofPoints;

  @override
  State<InfoAlertWidget> createState() => _InfoAlertWidgetState();
}

class _InfoAlertWidgetState extends State<InfoAlertWidget> {
  late InfoAlertModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InfoAlertModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: () {
          if (widget!.status == AlertTextStatus.Warning) {
            return FlutterFlowTheme.of(context).warning100;
          } else if (widget!.status == AlertTextStatus.Information) {
            return FlutterFlowTheme.of(context).secondaryInfo100;
          } else if (widget!.status == AlertTextStatus.Success) {
            return FlutterFlowTheme.of(context).success100;
          } else if (widget!.status == AlertTextStatus.Error) {
            return FlutterFlowTheme.of(context).danger100;
          } else {
            return FlutterFlowTheme.of(context).danger100;
          }
        }(),
        borderRadius: BorderRadius.circular(1.0),
        border: Border.all(
          color: () {
            if (widget!.status == AlertTextStatus.Warning) {
              return FlutterFlowTheme.of(context).warning500Default;
            } else if (widget!.status == AlertTextStatus.Information) {
              return FlutterFlowTheme.of(context).secondaryInfo500Default;
            } else if (widget!.status == AlertTextStatus.Success) {
              return FlutterFlowTheme.of(context).success500Default;
            } else if (widget!.status == AlertTextStatus.Error) {
              return FlutterFlowTheme.of(context).danger500Default;
            } else {
              return FlutterFlowTheme.of(context).danger500Default;
            }
          }(),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
              child: Builder(
                builder: (context) {
                  if (widget!.status == AlertTextStatus.Warning) {
                    return Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrifix!, 'infoAlert', 'W_icon')),
                      Icons.warning_amber,
                      color: FlutterFlowTheme.of(context).warning,
                      size: 18.0,
                    );
                  } else if (widget!.status == AlertTextStatus.Information) {
                    return Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrifix!, 'infoAlert', 'I_icon')),
                      Icons.info_outline,
                      color: FlutterFlowTheme.of(context).info,
                      size: 18.0,
                    );
                  } else if (widget!.status == AlertTextStatus.Success) {
                    return Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrifix!, 'infoAlert', 'S_icon')),
                      Icons.check_circle_outline,
                      color: FlutterFlowTheme.of(context).success,
                      size: 18.0,
                    );
                  } else if (widget!.status == AlertTextStatus.Error) {
                    return Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrifix!, 'infoAlert', 'E_icon')),
                      Icons.arrow_back,
                      color: FlutterFlowTheme.of(context).danger500Default,
                      size: 18.0,
                    );
                  } else {
                    return Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrifix!, 'infoAlert', 'A_icon')),
                      Icons.report_outlined,
                      color: FlutterFlowTheme.of(context).danger500Default,
                      size: 24.0,
                    );
                  }
                },
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
              child: Builder(
                builder: (context) {
                  final infotext = widget!.noofPoints!.toList();

                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.generate(infotext.length, (infotextIndex) {
                      final infotextItem = infotext[infotextIndex];
                      return Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrifix!,
                                    'infoAlert', 'bulletPoint')),
                            '${(infotextIndex + 1).toString()}. ',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: () {
                                    if (widget!.status ==
                                        AlertTextStatus.Warning) {
                                      return FlutterFlowTheme.of(context)
                                          .warning500Default;
                                    } else if (widget!.status ==
                                        AlertTextStatus.Information) {
                                      return FlutterFlowTheme.of(context)
                                          .secondaryInfo500Default;
                                    } else if (widget!.status ==
                                        AlertTextStatus.Success) {
                                      return FlutterFlowTheme.of(context)
                                          .success500Default;
                                    } else if (widget!.status ==
                                        AlertTextStatus.Error) {
                                      return FlutterFlowTheme.of(context)
                                          .danger500Default;
                                    } else {
                                      return FlutterFlowTheme.of(context)
                                          .danger500Default;
                                    }
                                  }(),
                                  letterSpacing: 0.0,
                                ),
                          ),
                          Expanded(
                            child: Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrifix!,
                                      'infoAlert', 'description')),
                              widget!.description!,
                              textAlign: TextAlign.start,
                              style: GoogleFonts.getFont(
                                'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 14.0,
                              ),
                            ),
                          ),
                        ],
                      );
                    }),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
