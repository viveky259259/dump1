import 'dart:io';

void main(List<String> args) async {
  // Default path is 'lib'
  String folderPath = '';
  bool autoDelete = args.contains('--auto-delete'); // Flag to auto-delete files

  // Check if a --path argument is passed
  for (var arg in args) {
    if (arg.startsWith('--path=')) {
      folderPath = arg.split('=')[1];
      break;
    }
  }

  print("🔍 Running DCM Analyzer for path: $folderPath...\n");

  // Ensure dcm is installed
  ProcessResult checkDcm = await Process.run('dcm', ['--version'], runInShell: true);
  if (checkDcm.exitCode != 0) {
    print("❌ Error: 'dcm' is not installed. Install it using:\n   dart pub global activate dcm");
    exit(1);
  }

  // Run dcm check-unused-files
  ProcessResult result = await Process.run('dcm', ['check-unused-files', folderPath], runInShell: true);
  String output = result.stdout.trim();

  // Using the working regex to extract file paths
  RegExp unusedFilePattern = RegExp(r"⚠ unused file\s*\n\s*(.+)");
  List<String> unusedFiles = [];

  for (var match in unusedFilePattern.allMatches(output)) {
    unusedFiles.add(match.group(1)!.trim());
  }

  // Show unused files
  if (unusedFiles.isNotEmpty) {
    print("\n📁 Unused Files Found in '$folderPath':");
    for (var file in unusedFiles) {
      print(" - $file");
    }

    // Auto-delete if flag is set
    if (autoDelete) {
      print("\n⚡ Auto-deleting unused files...\n");
      deleteFiles(unusedFiles);
    } else {
      // Ask user for confirmation before deletion
      print("\n⚠️ Do you want to delete these files? (yes/no)");
      String? response = stdin.readLineSync();

      if (response?.toLowerCase() == 'yes') {
        deleteFiles(unusedFiles);
      } else {
        print("\n❌ Deletion cancelled.");
      }
    }
  } else {
    print("\n✅ No unused files found in '$folderPath'.");
  }
}

/// Function to delete files and handle errors
void deleteFiles(List<String> files) {
  for (var file in files) {
    File f = File(file);
    if (f.existsSync()) {
      try {
        f.deleteSync();
        print("✅ Deleted: $file");
      } catch (e) {
        print("❌ Failed to delete: $file. Error: $e");
      }
    } else {
      print("⚠️ File not found: $file");
    }
  }
  print("\n✅ Cleanup completed successfully.");
}