# Sub Zero Example App

This example demonstrates how to use the Sub Zero 2.0 Design System package.

## Setup

Before running the example, create a `pubspec.yaml` file in this directory:

```yaml
name: sub_zero_example
description: Example app demonstrating Sub Zero 2.0 Design System components.
publish_to: 'none'
version: 1.0.0

environment:
  sdk: ^3.6.0
  flutter: ">=3.22.0"

dependencies:
  flutter:
    sdk: flutter
  sub_zero:
    path: ../

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0

flutter:
  uses-material-design: true
```

## Running the Example

```bash
cd example
flutter pub get
flutter run
```

## What's Included

The example showcases:

- **Buttons** - Primary, Secondary, Tertiary variants
- **Badges** - Success, Warning, Error, Info variants  
- **Tags** - With optional remove functionality
- **Avatars** - Small, Medium, Large sizes
- **Form Controls** - Switch, Checkbox, Radio, Slider
- **Search** - Search input component
- **Cards** - Content container with elevation
- **Dividers** - With optional label
- **Dialog** - Modal dialog component
- **Toast** - Toast notification component
