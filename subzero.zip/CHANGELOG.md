# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-02-22

### Changed

- **Colors**: Aligned all color tokens with the official Subzero design system spec
  - Updated action colors: primary (#97144D), secondary (#ED1164), tertiary (#12877F)
  - Updated surface colors: background (#FFFFFF), secondary (#F9F9F9), tertiary (#404040)
  - Updated typography colors: primary (#282828), secondary (#6E6E6E), tertiary (#9D9D9D)
  - Updated support/semantic colors: negative (#EB0000), positive (#278829), warning (#D84008)
  - Updated stroke colors: default (#E2E2E2), active (#404040), selected (#F14687)
  - Replaced hardcoded hex values in toast and tabs components with token references

### Added

- **New color token classes** in `tokens.dart`:
  - `SubzeroActionColors` — primary/secondary/tertiary action colors
  - `SubzeroSurfaceColors` — background surface colors
  - `SubzeroTypographyColors` — text colors for standard, action, and edge cases
  - `SubzeroIconColors` — icon colors for standard, action, support, and edge cases
  - `SubzeroStrokeColors` — border/stroke colors (default, active, disabled, selected, hover)
  - `SubzeroOverlayStateColors` — overlay, selected, unselected, and disabled states
  - `SubzeroNeutralAccentColors` — 6 tinted neutral backgrounds
- **New properties** in `SubZeroColors`: actionSecondary, actionTertiary, surfaceTertiary, textDisabled, textOnSurface, textTypical, iconDefault, strokeSelected, strokeHover, overlay, selectedHover, visitedLink, neutral1-6, and more
- Tertiary color added to Material 3 ColorScheme in `SubZeroTheme`

### Removed

- Deleted unused `lib/theme.dart` (unrelated blue-gray palette)

## [1.0.0] - 2025-01-01

### Added

- Initial release of Sub Zero 2.0 Design System
- **Design Tokens**
  - Color palette with brand, semantic, and neutral colors
  - Typography scale with Inter font family
  - Spacing system based on 8px grid
  - Border radius tokens
  - Elevation/shadow tokens
  - Data visualization color palettes
- **Theme**
  - `SubZeroTheme.lightTheme` - Complete Material 3 theme
- **Components**
  - `SubZeroAccordion` - Expandable/collapsible sections
  - `SubZeroAddItem` - Add item action button
  - `SubZeroAvatar` - User avatar with image/initials
  - `SubZeroBadge` - Status badges and labels
  - `SubZeroBottomSheet` - Modal bottom sheets
  - `SubZeroButton` - Primary, secondary, tertiary, and icon buttons
  - `SubZeroCard` - Content container cards
  - `SubZeroCarousel` - Image/content carousel
  - `SubZeroCheckbox` - Checkbox input
  - `SubZeroDialog` - Modal dialogs
  - `SubZeroDivider` - Content dividers
  - `SubZeroHeader` - Page/section headers
  - `SubZeroOnboarding` - Onboarding flow screens
  - `SubZeroProgressTracker` - Step progress indicator
  - `SubZeroRadio` - Radio button input
  - `SubZeroSearch` - Search input field
  - `SubZeroSlider` - Range slider input
  - `SubZeroSwitch` - Toggle switch
  - `SubZeroTabs` - Tab navigation
  - `SubZeroTag` - Categorization tags
  - `SubZeroToast` - Toast notifications
  - `SubZeroToggle` - Button group toggle

### Security

- WCAG AA compliant color contrasts for accessibility
