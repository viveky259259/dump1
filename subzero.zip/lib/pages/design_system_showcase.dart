import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/sub_zero_design_system.dart';

class DesignSystemShowcase extends StatelessWidget {
  const DesignSystemShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sub Zero 2.0 Design System'),
        backgroundColor: SubZeroColors.surface,
        elevation: 0,
        titleTextStyle: SubZeroTypography.textTheme.titleLarge?.copyWith(
          color: SubZeroColors.primary,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: SubZeroSpacing.containerMaxWidth),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSectionHeader('Colors'),
                const SizedBox(height: SubZeroSpacing.md),
                _buildColorSection(),
                
                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Typography'),
                const SizedBox(height: SubZeroSpacing.md),
                _buildTypographySection(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Radius & Elevation'),
                const SizedBox(height: SubZeroSpacing.md),
                _buildRadiusElevationSection(),
                
                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Spacing'),
                const SizedBox(height: SubZeroSpacing.md),
                _buildSpacingSection(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Accordion'),
                const SizedBox(height: SubZeroSpacing.md),
                _buildAccordionSection(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Add Item'),
                const SizedBox(height: SubZeroSpacing.md),
                const AddItemShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Avatar'),
                const SizedBox(height: SubZeroSpacing.md),
                const AvatarShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Badge'),
                const SizedBox(height: SubZeroSpacing.md),
                const BadgeShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Bottom Sheet'),
                const SizedBox(height: SubZeroSpacing.md),
                const BottomSheetShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Buttons'),
                const SizedBox(height: SubZeroSpacing.md),
                const ButtonShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Cards'),
                const SizedBox(height: SubZeroSpacing.md),
                const CardShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Carousel'),
                const SizedBox(height: SubZeroSpacing.md),
                const CarouselShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Checkbox & Multiselect'),
                const SizedBox(height: SubZeroSpacing.md),
                const CheckboxShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Dialog'),
                const SizedBox(height: SubZeroSpacing.md),
                const DialogShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Divider'),
                const SizedBox(height: SubZeroSpacing.md),
                const DividerShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Header'),
                const SizedBox(height: SubZeroSpacing.md),
                const HeaderShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Onboarding & Coachmarks'),
                const SizedBox(height: SubZeroSpacing.md),
                const OnboardingShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Progress Tracker'),
                const SizedBox(height: SubZeroSpacing.md),
                const ProgressTrackerShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Radio Button'),
                const SizedBox(height: SubZeroSpacing.md),
                const RadioButtonShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Search'),
                const SizedBox(height: SubZeroSpacing.md),
                const SearchShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Slider'),
                const SizedBox(height: SubZeroSpacing.md),
                const SliderShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Switch / Toggle'),
                const SizedBox(height: SubZeroSpacing.md),
                const SwitchShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Tabs'),
                const SizedBox(height: SubZeroSpacing.md),
                const TabsShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Tags / Chips'),
                const SizedBox(height: SubZeroSpacing.md),
                const TagShowcase(),

                const SizedBox(height: SubZeroSpacing.xxl),
                _buildSectionHeader('Toast'),
                const SizedBox(height: SubZeroSpacing.md),
                const ToastShowcase(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAccordionSection() {
    return SubZeroAccordion(
      sections: const [
        SubZeroAccordionSection(
          title: 'Add your title text here',
          leadingIcon: Icons.lightbulb_outline,
          content: Text(
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In utopianlandia, unicorns play poker with leprechauns every Tuesday.\n\nMeanwhile, a group of rebellious squirrels is plotting to steal all the world\'s acorns.',
          ),
        ),
        SubZeroAccordionSection(
          title: 'Add your title text here',
          leadingIcon: Icons.lightbulb_outline,
          content: Text('This is the expanded content area. Replace with any widget.'),
        ),
        SubZeroAccordionSection(
          title: 'Add your title text here',
          leadingIcon: Icons.lightbulb_outline,
          content: Text('You can put rich layouts here, including buttons and lists.'),
        ),
        SubZeroAccordionSection(
          title: 'Add your title text here',
          leadingIcon: Icons.lightbulb_outline,
          content: Text('Only one section stays open at a time (single-expand).'),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: SubZeroTypography.textTheme.headlineMedium?.copyWith(
        color: SubZeroColors.primary,
      ),
    );
  }

  Widget _buildColorSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildColorGroup('Brand', [
          _ColorItem('Primary', SubZeroColors.primary),
          _ColorItem('Primary Dark', SubZeroColors.primaryDark),
          _ColorItem('Primary Light', SubZeroColors.primaryLight),
          _ColorItem('Secondary', SubZeroColors.secondary),
          _ColorItem('Accent', SubZeroColors.accent),
        ]),
        const SizedBox(height: SubZeroSpacing.lg),
        _buildColorGroup('Status', [
          _ColorItem('Success', SubZeroColors.success),
          _ColorItem('Warning', SubZeroColors.warning),
          _ColorItem('Error', SubZeroColors.error),
          _ColorItem('Info', SubZeroColors.info),
        ]),
        const SizedBox(height: SubZeroSpacing.lg),
        _buildColorGroup('Neutral', [
          _ColorItem('Background', SubZeroColors.background),
          _ColorItem('Surface', SubZeroColors.surface),
          _ColorItem('Surface Variant', SubZeroColors.surfaceVariant),
          _ColorItem('Border', SubZeroColors.border),
        ]),
        const SizedBox(height: SubZeroSpacing.lg),
        Text('Data Visualization', style: SubZeroTypography.textTheme.titleMedium),
        const SizedBox(height: SubZeroSpacing.sm),
        Wrap(
          spacing: SubZeroSpacing.sm,
          runSpacing: SubZeroSpacing.sm,
          children: SubZeroColors.dataVis.map((c) => Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: c,
              borderRadius: SubZeroRadius.small,
            ),
          )).toList(),
        ),
      ],
    );
  }

  Widget _buildColorGroup(String title, List<_ColorItem> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: SubZeroTypography.textTheme.titleMedium),
        const SizedBox(height: SubZeroSpacing.sm),
        Wrap(
          spacing: SubZeroSpacing.md,
          runSpacing: SubZeroSpacing.md,
          children: items.map((item) => _buildColorCard(item)).toList(),
        ),
      ],
    );
  }

  Widget _buildColorCard(_ColorItem item) {
    return Container(
      width: 160,
      padding: const EdgeInsets.all(SubZeroSpacing.sm),
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: SubZeroRadius.medium,
        border: Border.all(color: SubZeroColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 80,
            decoration: BoxDecoration(
              color: item.color,
              borderRadius: SubZeroRadius.small,
              border: Border.all(color: SubZeroColors.border.withValues(alpha: 0.5)),
            ),
          ),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(item.name, style: SubZeroTypography.textTheme.labelMedium),
          Text(
            '#${item.color.value.toRadixString(16).toUpperCase().substring(2)}',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  Widget _buildTypographySection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Display Large', style: SubZeroTypography.textTheme.displayLarge),
            Text('Display Medium', style: SubZeroTypography.textTheme.displayMedium),
            Text('Display Small', style: SubZeroTypography.textTheme.displaySmall),
            const Divider(height: 32),
            Text('Headline Large', style: SubZeroTypography.textTheme.headlineLarge),
            Text('Headline Medium', style: SubZeroTypography.textTheme.headlineMedium),
            Text('Headline Small', style: SubZeroTypography.textTheme.headlineSmall),
            const Divider(height: 32),
            Text('Title Large', style: SubZeroTypography.textTheme.titleLarge),
            Text('Title Medium', style: SubZeroTypography.textTheme.titleMedium),
            Text('Title Small', style: SubZeroTypography.textTheme.titleSmall),
            const Divider(height: 32),
            Text('Body Large - The quick brown fox jumps over the lazy dog.', style: SubZeroTypography.textTheme.bodyLarge),
            Text('Body Medium - The quick brown fox jumps over the lazy dog.', style: SubZeroTypography.textTheme.bodyMedium),
            Text('Body Small - The quick brown fox jumps over the lazy dog.', style: SubZeroTypography.textTheme.bodySmall),
            const Divider(height: 32),
            Text('Label Large', style: SubZeroTypography.textTheme.labelLarge),
            Text('Label Medium', style: SubZeroTypography.textTheme.labelMedium),
            Text('Label Small', style: SubZeroTypography.textTheme.labelSmall),
          ],
        ),
      ),
    );
  }

  Widget _buildRadiusElevationSection() {
    return Wrap(
      spacing: SubZeroSpacing.xl,
      runSpacing: SubZeroSpacing.xl,
      children: [
        _buildRadiusCard('Small Radius', SubZeroRadius.small),
        _buildRadiusCard('Medium Radius', SubZeroRadius.medium),
        _buildRadiusCard('Large Radius', SubZeroRadius.large),
        _buildRadiusCard('Pill Radius', SubZeroRadius.rounded),
        
        _buildElevationCard('Level 1', SubZeroElevation.level1),
        _buildElevationCard('Level 2', SubZeroElevation.level2),
        _buildElevationCard('Level 3', SubZeroElevation.level3),
        _buildElevationCard('Level 4', SubZeroElevation.level4),
      ],
    );
  }

  Widget _buildRadiusCard(String label, BorderRadius radius) {
    return Container(
      width: 120,
      height: 120,
      decoration: BoxDecoration(
        color: SubZeroColors.primary.withValues(alpha: 0.1),
        borderRadius: radius,
        border: Border.all(color: SubZeroColors.primary),
      ),
      alignment: Alignment.center,
      child: Text(label, style: SubZeroTypography.textTheme.labelSmall, textAlign: TextAlign.center),
    );
  }

  Widget _buildElevationCard(String label, List<BoxShadow> shadows) {
    return Container(
      width: 120,
      height: 120,
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: SubZeroRadius.medium,
        boxShadow: shadows,
      ),
      alignment: Alignment.center,
      child: Text(label, style: SubZeroTypography.textTheme.labelSmall),
    );
  }

  Widget _buildSpacingSection() {
    return Wrap(
      spacing: SubZeroSpacing.md,
      runSpacing: SubZeroSpacing.md,
      children: [
        _buildSpacingItem('XS', SubZeroSpacing.xs),
        _buildSpacingItem('SM', SubZeroSpacing.sm),
        _buildSpacingItem('MD', SubZeroSpacing.md),
        _buildSpacingItem('LG', SubZeroSpacing.lg),
        _buildSpacingItem('XL', SubZeroSpacing.xl),
        _buildSpacingItem('XXL', SubZeroSpacing.xxl),
      ],
    );
  }

  Widget _buildSpacingItem(String label, double size) {
    return Column(
      children: [
        Container(
          width: size,
          height: size,
          color: SubZeroColors.secondary,
        ),
        const SizedBox(height: 4),
        Text('$label ($size)', style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

class _ColorItem {
  final String name;
  final Color color;
  _ColorItem(this.name, this.color);
}

/// Showcase widget for SubZeroAvatar component.
class AvatarShowcase extends StatelessWidget {
  const AvatarShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Variants section
            Text('Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Icon, Text (Initials), and Image representations',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Row(
              children: [
                _AvatarVariantCard(
                  label: 'Icon',
                  child: SubZeroAvatar(size: SubZeroAvatarSize.l),
                ),
                const SizedBox(width: SubZeroSpacing.xl),
                _AvatarVariantCard(
                  label: 'Text',
                  child: SubZeroAvatar(
                    initials: 'V',
                    size: SubZeroAvatarSize.l,
                  ),
                ),
                const SizedBox(width: SubZeroSpacing.xl),
                _AvatarVariantCard(
                  label: 'Image',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'Profile photo',
                    size: SubZeroAvatarSize.l,
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Sizes section
            Text('Sizes', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'S (24px), M (32px), L (40px), XL (48px), XXL (64px), 3XL (80px)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.lg,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.end,
              children: [
                _AvatarSizeCard(
                  label: 'S',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'User avatar small',
                    size: SubZeroAvatarSize.s,
                  ),
                ),
                _AvatarSizeCard(
                  label: 'M',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'User avatar medium',
                    size: SubZeroAvatarSize.m,
                  ),
                ),
                _AvatarSizeCard(
                  label: 'L',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'User avatar large',
                    size: SubZeroAvatarSize.l,
                  ),
                ),
                _AvatarSizeCard(
                  label: 'XL',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'User avatar extra large',
                    size: SubZeroAvatarSize.xl,
                  ),
                ),
                _AvatarSizeCard(
                  label: 'XXL',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'User avatar double extra large',
                    size: SubZeroAvatarSize.xxl,
                  ),
                ),
                _AvatarSizeCard(
                  label: '3XL',
                  child: SubZeroAvatar(
                    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                    semanticLabel: 'User avatar triple extra large',
                    size: SubZeroAvatarSize.threeXL,
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Initials Examples
            Text('Initials Generation', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Use the .toAvatarInitials() extension for automatic initials',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.lg,
              runSpacing: SubZeroSpacing.md,
              children: [
                _AvatarVariantCard(
                  label: '"Jane Doe"',
                  child: SubZeroAvatar(
                    initials: 'Jane Doe'.toAvatarInitials(),
                    size: SubZeroAvatarSize.l,
                  ),
                ),
                _AvatarVariantCard(
                  label: '"Alice"',
                  child: SubZeroAvatar(
                    initials: 'Alice'.toAvatarInitials(),
                    size: SubZeroAvatarSize.l,
                  ),
                ),
                _AvatarVariantCard(
                  label: '"Robert Smith Jr"',
                  child: SubZeroAvatar(
                    initials: 'Robert Smith Jr'.toAvatarInitials(),
                    size: SubZeroAvatarSize.l,
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Custom Icon
            Text('Custom Icons', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Use any IconData for organization or entity avatars',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.lg,
              runSpacing: SubZeroSpacing.md,
              children: [
                _AvatarVariantCard(
                  label: 'Business',
                  child: SubZeroAvatar(
                    icon: Icons.business,
                    size: SubZeroAvatarSize.l,
                  ),
                ),
                _AvatarVariantCard(
                  label: 'Group',
                  child: SubZeroAvatar(
                    icon: Icons.group,
                    size: SubZeroAvatarSize.l,
                  ),
                ),
                _AvatarVariantCard(
                  label: 'Support',
                  child: SubZeroAvatar(
                    icon: Icons.support_agent,
                    size: SubZeroAvatarSize.l,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AvatarVariantCard extends StatelessWidget {
  const _AvatarVariantCard({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        child,
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

class _AvatarSizeCard extends StatelessWidget {
  const _AvatarSizeCard({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        child,
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for SubZeroAddItem component.
class AddItemShowcase extends StatefulWidget {
  const AddItemShowcase({super.key});

  @override
  State<AddItemShowcase> createState() => _AddItemShowcaseState();
}

class _AddItemShowcaseState extends State<AddItemShowcase> {
  int _basicQuantity = 0;
  int _moreQuantity = 0;
  int _controlledQuantity = 5;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Basic Add Item
            Text('Basic Add Item', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tap "ADD" to transition to quantity stepper. Current: $_basicQuantity',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            SubZeroAddItem(
              onQuantityChanged: (qty) => setState(() => _basicQuantity = qty),
              onItemAdded: () => debugPrint('Item added!'),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // With "More" Option
            Text('With "More" Option', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Shows a bottom sheet for quick quantity selection. Current: $_moreQuantity',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            SubZeroAddItem(
              config: const SubZeroAddItemConfig(
                showMoreOption: true,
                initialQuantity: 1,
              ),
              startInQuantityMode: true,
              onQuantityChanged: (qty) => setState(() => _moreQuantity = qty),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Controlled Mode with Custom Config
            Text('Controlled with Custom Range', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Min: 1, Max: 20, Current: $_controlledQuantity',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            SubZeroAddItem(
              config: const SubZeroAddItemConfig(
                minQuantity: 1,
                maxQuantity: 20,
              ),
              quantity: _controlledQuantity,
              startInQuantityMode: true,
              onQuantityChanged: (qty) => setState(() => _controlledQuantity = qty),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // All States Side by Side
            Text('All States', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.lg,
              runSpacing: SubZeroSpacing.md,
              children: [
                Column(
                  children: [
                    const SubZeroAddItem(),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Add Button', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
                Column(
                  children: [
                    SubZeroAddItem(
                      startInQuantityMode: true,
                      config: const SubZeroAddItemConfig(initialQuantity: 20),
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Stepper', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
                Column(
                  children: [
                    SubZeroAddItem(
                      startInQuantityMode: true,
                      config: const SubZeroAddItemConfig(
                        showMoreOption: true,
                        initialQuantity: 1,
                      ),
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('More Button', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Showcase widget for SubZeroBadge component.
class BadgeShowcase extends StatelessWidget {
  const BadgeShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Badge Variants - matching Figma exactly
            Text('Badge Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Dot and Count variants with Filled, Outlined, and Muted styles',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Header row for styles
            Row(
              children: [
                const SizedBox(width: 100),
                Expanded(child: Text('Filled', style: SubZeroTypography.textTheme.labelMedium, textAlign: TextAlign.center)),
                Expanded(child: Text('Outlined', style: SubZeroTypography.textTheme.labelMedium, textAlign: TextAlign.center)),
                Expanded(child: Text('Muted', style: SubZeroTypography.textTheme.labelMedium, textAlign: TextAlign.center)),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.md),

            // Default (Dot)
            _BadgeRow(
              label: 'Default',
              badges: [
                SubZeroBadge.dot(style: SubZeroBadgeStyle.filled),
                SubZeroBadge.dot(style: SubZeroBadgeStyle.outlined),
                SubZeroBadge.dot(style: SubZeroBadgeStyle.muted),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Single digit
            _BadgeRow(
              label: 'Single digit',
              badges: [
                SubZeroBadge.count(count: 3, style: SubZeroBadgeStyle.filled),
                SubZeroBadge.count(count: 3, style: SubZeroBadgeStyle.outlined),
                SubZeroBadge.count(count: 3, style: SubZeroBadgeStyle.muted),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Double digit
            _BadgeRow(
              label: 'Double digit',
              badges: [
                SubZeroBadge.count(count: 32, style: SubZeroBadgeStyle.filled),
                SubZeroBadge.count(count: 32, style: SubZeroBadgeStyle.outlined),
                SubZeroBadge.count(count: 32, style: SubZeroBadgeStyle.muted),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Overflow
            _BadgeRow(
              label: 'Overflow',
              badges: [
                SubZeroBadge.count(count: 150, style: SubZeroBadgeStyle.filled),
                SubZeroBadge.count(count: 150, style: SubZeroBadgeStyle.outlined),
                SubZeroBadge.count(count: 150, style: SubZeroBadgeStyle.muted),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Sizes section
            Text('Sizes', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Small, Medium (default), and Large',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                _BadgeSizeCard(
                  label: 'Small',
                  children: [
                    SubZeroBadge.dot(size: SubZeroBadgeSize.small),
                    const SizedBox(width: SubZeroSpacing.sm),
                    SubZeroBadge.count(count: 5, size: SubZeroBadgeSize.small),
                  ],
                ),
                _BadgeSizeCard(
                  label: 'Medium',
                  children: [
                    SubZeroBadge.dot(size: SubZeroBadgeSize.medium),
                    const SizedBox(width: SubZeroSpacing.sm),
                    SubZeroBadge.count(count: 5, size: SubZeroBadgeSize.medium),
                  ],
                ),
                _BadgeSizeCard(
                  label: 'Large',
                  children: [
                    SubZeroBadge.dot(size: SubZeroBadgeSize.large),
                    const SizedBox(width: SubZeroSpacing.sm),
                    SubZeroBadge.count(count: 5, size: SubZeroBadgeSize.large),
                  ],
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Attached to widgets
            Text('Attached to Widgets', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Easily position badges on icons, avatars, or any widget',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.lg,
              children: [
                _BadgeAttachedCard(
                  label: 'Icon + Dot',
                  child: SubZeroBadge.dot(
                    child: Icon(Icons.notifications_outlined, size: 32, color: SubZeroColors.textPrimary),
                  ),
                ),
                _BadgeAttachedCard(
                  label: 'Icon + Count',
                  child: SubZeroBadge.count(
                    count: 5,
                    child: Icon(Icons.mail_outline, size: 32, color: SubZeroColors.textPrimary),
                  ),
                ),
                _BadgeAttachedCard(
                  label: 'Avatar + Dot',
                  child: SubZeroBadge.dot(
                    child: SubZeroAvatar(
                      initials: 'JD',
                      size: SubZeroAvatarSize.l,
                    ),
                  ),
                ),
                _BadgeAttachedCard(
                  label: 'Avatar + Count',
                  child: SubZeroBadge.count(
                    count: 12,
                    child: SubZeroAvatar(
                      imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200',
                      size: SubZeroAvatarSize.l,
                    ),
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Extension API
            Text('Extension API', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Use .withDotBadge() or .withCountBadge() for cleaner code',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.lg,
              children: [
                _BadgeAttachedCard(
                  label: '.withDotBadge()',
                  child: Icon(Icons.shopping_cart_outlined, size: 32, color: SubZeroColors.textPrimary)
                      .withDotBadge(),
                ),
                _BadgeAttachedCard(
                  label: '.withCountBadge()',
                  child: Icon(Icons.chat_bubble_outline, size: 32, color: SubZeroColors.textPrimary)
                      .withCountBadge(count: 99),
                ),
                _BadgeAttachedCard(
                  label: 'Overflow (150)',
                  child: Icon(Icons.inbox_outlined, size: 32, color: SubZeroColors.textPrimary)
                      .withCountBadge(count: 150),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Positioning
            Text('Positioning', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Configure badge position: top-right, top-left, bottom-right, bottom-left',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.lg,
              children: [
                _BadgeAttachedCard(
                  label: 'Top Right',
                  child: SubZeroBadge.count(
                    count: 3,
                    alignment: const SubZeroBadgeAlignment(position: SubZeroBadgePosition.topRight),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: SubZeroColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.folder_outlined),
                    ),
                  ),
                ),
                _BadgeAttachedCard(
                  label: 'Top Left',
                  child: SubZeroBadge.count(
                    count: 3,
                    alignment: const SubZeroBadgeAlignment(position: SubZeroBadgePosition.topLeft),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: SubZeroColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.folder_outlined),
                    ),
                  ),
                ),
                _BadgeAttachedCard(
                  label: 'Bottom Right',
                  child: SubZeroBadge.dot(
                    alignment: const SubZeroBadgeAlignment(position: SubZeroBadgePosition.bottomRight),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: SubZeroColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.folder_outlined),
                    ),
                  ),
                ),
                _BadgeAttachedCard(
                  label: 'Bottom Left',
                  child: SubZeroBadge.dot(
                    alignment: const SubZeroBadgeAlignment(position: SubZeroBadgePosition.bottomLeft),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: SubZeroColors.surfaceVariant,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.folder_outlined),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BadgeRow extends StatelessWidget {
  const _BadgeRow({required this.label, required this.badges});

  final String label;
  final List<Widget> badges;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 100,
          child: Text(label, style: SubZeroTypography.textTheme.bodyMedium),
        ),
        ...badges.map((badge) => Expanded(child: Center(child: badge))),
      ],
    );
  }
}

class _BadgeSizeCard extends StatelessWidget {
  const _BadgeSizeCard({required this.label, required this.children});

  final String label;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(mainAxisSize: MainAxisSize.min, children: children),
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

class _BadgeAttachedCard extends StatelessWidget {
  const _BadgeAttachedCard({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 56, width: 56, child: Center(child: child)),
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for SubZeroBottomSheet component.
class BottomSheetShowcase extends StatelessWidget {
  const BottomSheetShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Bottom Sheet', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Modal sheets that slide up from the bottom (mobile) or appear as centered dialogs (desktop)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Basic Bottom Sheet
            Text('Basic Usage', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _BottomSheetTriggerButton(
                  label: 'Simple Sheet',
                  onPressed: () => _showSimpleSheet(context),
                ),
                _BottomSheetTriggerButton(
                  label: 'With Content Structure',
                  onPressed: () => _showStructuredSheet(context),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // With Illustration
            Text('With Top Content', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Include illustrations, animations, or images in the top area',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            _BottomSheetTriggerButton(
              label: 'With Illustration',
              onPressed: () => _showIllustrationSheet(context),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Dual Buttons
            Text('Dual Buttons (Desktop Style)', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Side-by-side buttons for confirmation dialogs',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            _BottomSheetTriggerButton(
              label: 'Dual Buttons',
              onPressed: () => _showDualButtonSheet(context),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Custom Content
            Text('Custom Content', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Pass any widget as content for maximum flexibility',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            _BottomSheetTriggerButton(
              label: 'Custom Form',
              onPressed: () => _showCustomFormSheet(context),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Configuration Options
            Text('Configuration', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Customize behavior with SubZeroBottomSheetConfig',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _BottomSheetTriggerButton(
                  label: 'No Close Button',
                  onPressed: () => _showNoCloseButtonSheet(context),
                ),
                _BottomSheetTriggerButton(
                  label: 'No Drag Handle',
                  onPressed: () => _showNoDragHandleSheet(context),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showSimpleSheet(BuildContext context) {
    showSubZeroBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.md),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Simple Bottom Sheet',
              style: SubZeroTypography.textTheme.titleLarge,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Text(
              'This is a basic bottom sheet with custom content. You can put any widget here.',
              style: SubZeroTypography.textTheme.bodyMedium,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: SubZeroColors.primary,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Got it'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showStructuredSheet(BuildContext context) {
    context.showSubZeroContentSheet(
      kicker: 'Step 1 of 3',
      title: 'Add your recommendation',
      description: 'Select a recommendation to add to your L0 Journey. This will help personalize your experience.',
      primaryButtonLabel: 'Continue',
      onPrimaryPressed: () => Navigator.pop(context),
    );
  }

  void _showIllustrationSheet(BuildContext context) {
    showSubZeroBottomSheet(
      context: context,
      builder: (context) => SubZeroBottomSheetContent(
        topContent: Container(
          height: 160,
          decoration: BoxDecoration(
            color: SubZeroColors.surfaceVariant,
            borderRadius: BorderRadius.circular(SubZeroRadius.md),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  size: 48,
                  color: SubZeroColors.primary,
                ),
                const SizedBox(height: SubZeroSpacing.sm),
                Text(
                  'Illustration Area',
                  style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                    color: SubZeroColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
        kicker: 'Recommendation',
        title: 'Self Recommendation',
        description: 'Add a self recommendation to track your personal goals and milestones.',
        primaryButtonLabel: 'Add Recommendation',
        onPrimaryPressed: () => Navigator.pop(context),
      ),
    );
  }

  void _showDualButtonSheet(BuildContext context) {
    context.showSubZeroContentSheet(
      kicker: 'Confirmation',
      title: 'Delete this item?',
      description: 'This action cannot be undone. Are you sure you want to proceed?',
      showDualButtons: true,
      secondaryButtonLabel: 'Cancel',
      onSecondaryPressed: () => Navigator.pop(context),
      primaryButtonLabel: 'Delete',
      onPrimaryPressed: () => Navigator.pop(context),
    );
  }

  void _showCustomFormSheet(BuildContext context) {
    showSubZeroBottomSheet(
      context: context,
      builder: (context) => SubZeroBottomSheetContent(
        kicker: 'Feedback',
        title: 'Share your thoughts',
        description: 'Help us improve by sharing your feedback.',
        bodyContent: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: TextField(
                decoration: InputDecoration(
                  labelText: 'Your feedback',
                  hintText: 'Tell us what you think...',
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: const EdgeInsets.all(SubZeroSpacing.md),
                ),
                maxLines: 4,
              ),
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Row(
              children: [
                Text('Rating:', style: SubZeroTypography.textTheme.bodyMedium),
                const SizedBox(width: SubZeroSpacing.sm),
                ...List.generate(5, (index) => Icon(
                  index < 4 ? Icons.star : Icons.star_border,
                  color: SubZeroColors.warning,
                  size: 24,
                )),
              ],
            ),
          ],
        ),
        primaryButtonLabel: 'Submit Feedback',
        onPrimaryPressed: () => Navigator.pop(context),
      ),
    );
  }

  void _showNoCloseButtonSheet(BuildContext context) {
    showSubZeroBottomSheet(
      context: context,
      config: const SubZeroBottomSheetConfig(showCloseButton: false),
      builder: (context) => SubZeroBottomSheetContent(
        title: 'No Close Button',
        description: 'This sheet has no close button. Tap outside or swipe down to dismiss.',
        primaryButtonLabel: 'Dismiss',
        onPrimaryPressed: () => Navigator.pop(context),
      ),
    );
  }

  void _showNoDragHandleSheet(BuildContext context) {
    showSubZeroBottomSheet(
      context: context,
      config: const SubZeroBottomSheetConfig(showDragHandle: false),
      builder: (context) => SubZeroBottomSheetContent(
        title: 'No Drag Handle',
        description: 'This sheet has no visible drag handle, but can still be dismissed by swiping.',
        primaryButtonLabel: 'Close',
        onPrimaryPressed: () => Navigator.pop(context),
      ),
    );
  }
}

class _BottomSheetTriggerButton extends StatelessWidget {
  const _BottomSheetTriggerButton({
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: SubZeroColors.primary,
        side: const BorderSide(color: SubZeroColors.primary),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(SubZeroRadius.sm),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: SubZeroSpacing.lg,
          vertical: SubZeroSpacing.md,
        ),
      ),
      child: Text(label),
    );
  }
}

/// Showcase widget for SubZeroButton and SubZeroButtonGroup components.
class ButtonShowcase extends StatefulWidget {
  const ButtonShowcase({super.key});

  @override
  State<ButtonShowcase> createState() => _ButtonShowcaseState();
}

class _ButtonShowcaseState extends State<ButtonShowcase> {
  bool _isLoading = false;

  void _simulateLoading() {
    setState(() => _isLoading = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _isLoading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Button Variants
            Text('Button Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Primary (solid), Secondary (outlined), Tertiary (text), Icon-only, and Flushed styles',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Primary Buttons Row
            Text('Primary (High Emphasis)', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SubZeroButton(
                  label: 'Primary button',
                  variant: SubZeroButtonVariant.primary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'With Icon',
                  leadingIcon: Icons.add,
                  variant: SubZeroButtonVariant.primary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Disabled',
                  variant: SubZeroButtonVariant.primary,
                  onPressed: null,
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Secondary Buttons Row
            Text('Secondary (Medium Emphasis)', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SubZeroButton(
                  label: 'Close',
                  variant: SubZeroButtonVariant.secondary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Cancel',
                  leadingIcon: Icons.close,
                  variant: SubZeroButtonVariant.secondary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Disabled',
                  variant: SubZeroButtonVariant.secondary,
                  onPressed: null,
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Tertiary Buttons Row
            Text('Tertiary (Low Emphasis)', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SubZeroButton(
                  label: 'TEXT BUTTON',
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Learn More',
                  trailingIcon: Icons.arrow_forward,
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Disabled',
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: null,
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Icon-Only & Flushed
            Text('Special Variants', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Column(
                  children: [
                    SubZeroButton(
                      icon: Icons.add,
                      variant: SubZeroButtonVariant.iconOnly,
                      onPressed: () {},
                      semanticLabel: 'Add item',
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Icon Only', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
                Column(
                  children: [
                    SubZeroButton(
                      label: 'Flushed button',
                      variant: SubZeroButtonVariant.flushed,
                      onPressed: () {},
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Flushed', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Button Sizes
            Text('Button Sizes', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Small (36px), Medium (44px), and Large (52px) - all maintain 48px minimum touch target',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Column(
                  children: [
                    SubZeroButton(
                      label: 'Small',
                      size: SubZeroButtonSize.small,
                      onPressed: () {},
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Small', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
                Column(
                  children: [
                    SubZeroButton(
                      label: 'Medium',
                      size: SubZeroButtonSize.medium,
                      onPressed: () {},
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Medium', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
                Column(
                  children: [
                    SubZeroButton(
                      label: 'Large',
                      size: SubZeroButtonSize.large,
                      onPressed: () {},
                    ),
                    const SizedBox(height: SubZeroSpacing.xs),
                    Text('Large', style: SubZeroTypography.textTheme.labelSmall),
                  ],
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Loading State
            Text('Loading State', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Shows a spinner while processing - tap to see loading animation',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                SubZeroButton(
                  label: 'Submit',
                  isLoading: _isLoading,
                  onPressed: _simulateLoading,
                ),
                SubZeroButton(
                  label: 'Loading...',
                  variant: SubZeroButtonVariant.secondary,
                  isLoading: true,
                  onPressed: () {},
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Button Groups
            Text('Button Groups', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Arrange related buttons horizontally with consistent spacing',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Standard Button Group
            Text('Standard Group', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            SubZeroButtonGroup(
              children: [
                SubZeroButton(
                  label: 'Cancel',
                  variant: SubZeroButtonVariant.secondary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Save',
                  variant: SubZeroButtonVariant.primary,
                  onPressed: () {},
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Centered Group
            Text('Centered Alignment', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            SizedBox(
              width: double.infinity,
              child: SubZeroButtonGroup(
                alignment: MainAxisAlignment.center,
                fullWidth: true,
                children: [
                  SubZeroButton(
                    label: 'No',
                    variant: SubZeroButtonVariant.secondary,
                    onPressed: () {},
                  ),
                  SubZeroButton(
                    label: 'Yes',
                    variant: SubZeroButtonVariant.primary,
                    onPressed: () {},
                  ),
                ],
              ),
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Icon Button Group
            Text('Icon Button Group', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            SubZeroButtonGroup(
              children: [
                SubZeroButton(
                  icon: Icons.format_bold,
                  variant: SubZeroButtonVariant.iconOnly,
                  onPressed: () {},
                  semanticLabel: 'Bold',
                ),
                SubZeroButton(
                  icon: Icons.format_italic,
                  variant: SubZeroButtonVariant.iconOnly,
                  onPressed: () {},
                  semanticLabel: 'Italic',
                ),
                SubZeroButton(
                  icon: Icons.format_underline,
                  variant: SubZeroButtonVariant.iconOnly,
                  onPressed: () {},
                  semanticLabel: 'Underline',
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Wrapping Group
            Text('Responsive Wrapping', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            SubZeroButtonGroup(
              wrap: true,
              children: [
                SubZeroButton(
                  label: 'Action 1',
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Action 2',
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Action 3',
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: () {},
                ),
                SubZeroButton(
                  label: 'Action 4',
                  variant: SubZeroButtonVariant.tertiary,
                  onPressed: () {},
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Accessibility
            Text('Accessibility', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tab to focus, Enter/Space to activate. All buttons have semantic labels.',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SubZeroButtonGroup(
              children: [
                SubZeroButton(
                  label: 'Tab Focus',
                  variant: SubZeroButtonVariant.secondary,
                  onPressed: () {},
                  semanticLabel: 'Demo button with tab focus',
                ),
                SubZeroButton(
                  icon: Icons.accessibility_new,
                  variant: SubZeroButtonVariant.iconOnly,
                  onPressed: () {},
                  semanticLabel: 'Accessibility icon button',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Showcase widget for SubZeroCard component.
class CardShowcase extends StatelessWidget {
  const CardShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Basic Cards
            Text('Card Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Static and interactive cards with customizable content sections',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Static Card with Header Only
            Text('Header Only', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            SubZeroCard(
              header: const SubZeroCardHeader(
                title: 'Card Title',
                subtitle: 'Supporting text for the card',
                leading: Icon(Icons.folder_outlined, color: SubZeroColors.primary),
                trailing: Icon(Icons.more_vert, color: SubZeroColors.textSecondary),
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Card with Media
            Text('Media Aspect Ratios', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              '1:0.5 (wide), 1:1 (square), 4:3 (standard), 1:1.5 (portrait)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _MediaRatioCard(
                    label: '1:0.5 Wide',
                    ratio: SubZeroCardMediaRatio.wide,
                  ),
                  const SizedBox(width: SubZeroSpacing.md),
                  _MediaRatioCard(
                    label: '1:1 Square',
                    ratio: SubZeroCardMediaRatio.square,
                  ),
                  const SizedBox(width: SubZeroSpacing.md),
                  _MediaRatioCard(
                    label: '4:3 Standard',
                    ratio: SubZeroCardMediaRatio.standard,
                  ),
                  const SizedBox(width: SubZeroSpacing.md),
                  _MediaRatioCard(
                    label: '1:1.5 Portrait',
                    ratio: SubZeroCardMediaRatio.portrait,
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Full Featured Card
            Text('Full Featured Card', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Header + Media + Body + Actions',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SizedBox(
              width: 320,
              child: SubZeroCard(
                media: SubZeroCardMedia(
                  child: Container(
                    color: SubZeroColors.surfaceVariant,
                    child: const Center(
                      child: Icon(Icons.image_outlined, size: 64, color: SubZeroColors.textTertiary),
                    ),
                  ),
                  aspectRatio: SubZeroCardMediaRatio.standard,
                  semanticLabel: 'Placeholder image',
                ),
                header: const SubZeroCardHeader(
                  title: 'Featured Article',
                  subtitle: 'Published Jan 15, 2025',
                ),
                body: Text(
                  'This is the body content of the card. It can contain any widget including text, images, or custom layouts.',
                  style: SubZeroTypography.textTheme.bodyMedium,
                ),
                actions: [
                  SubZeroButton(
                    label: 'Learn More',
                    variant: SubZeroButtonVariant.primary,
                    size: SubZeroButtonSize.small,
                    onPressed: () {},
                  ),
                  SubZeroButton(
                    label: 'Share',
                    variant: SubZeroButtonVariant.tertiary,
                    size: SubZeroButtonSize.small,
                    onPressed: () {},
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Interactive Card
            Text('Interactive Cards', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tappable cards with hover/focus states',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                SizedBox(
                  width: 240,
                  child: SubZeroCard(
                    onTap: () => debugPrint('Card tapped!'),
                    header: const SubZeroCardHeader(
                      title: 'Tappable Card',
                      subtitle: 'Tap or hover over me',
                      leading: Icon(Icons.touch_app_outlined, color: SubZeroColors.accent),
                    ),
                    body: Text(
                      'This card responds to tap, hover, and focus.',
                      style: SubZeroTypography.textTheme.bodySmall,
                    ),
                    semanticLabel: 'Interactive card example',
                  ),
                ),
                SizedBox(
                  width: 240,
                  child: SubZeroCard(
                    onTap: () {},
                    showBorder: true,
                    elevation: SubZeroCardElevation.none,
                    header: const SubZeroCardHeader(
                      title: 'Bordered Card',
                      subtitle: 'No shadow, with border',
                      leading: Icon(Icons.crop_square, color: SubZeroColors.primary),
                    ),
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Elevation Levels
            Text('Elevation Levels', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'None, Low, Medium (default), and High elevation',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _ElevationCard(label: 'None', elevation: SubZeroCardElevation.none),
                  const SizedBox(width: SubZeroSpacing.md),
                  _ElevationCard(label: 'Low', elevation: SubZeroCardElevation.low),
                  const SizedBox(width: SubZeroSpacing.md),
                  _ElevationCard(label: 'Medium', elevation: SubZeroCardElevation.medium),
                  const SizedBox(width: SubZeroSpacing.md),
                  _ElevationCard(label: 'High', elevation: SubZeroCardElevation.high),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Horizontal Card
            Text('Horizontal Card', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Side-by-side layout for list items',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SubZeroCardGroup(
              children: [
                SubZeroHorizontalCard(
                  leading: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: SubZeroColors.surfaceVariant,
                      borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                    ),
                    child: const Icon(Icons.article_outlined, color: SubZeroColors.primary),
                  ),
                  title: 'Document Title',
                  subtitle: 'Last modified 2 hours ago',
                  trailing: const Icon(Icons.chevron_right, color: SubZeroColors.textTertiary),
                  onTap: () => debugPrint('Horizontal card tapped'),
                ),
                SubZeroHorizontalCard(
                  leading: const SubZeroAvatar(
                    initials: 'JD',
                    size: SubZeroAvatarSize.l,
                  ),
                  title: 'John Doe',
                  subtitle: 'Product Designer • Online',
                  trailing: SubZeroButton(
                    label: 'Follow',
                    variant: SubZeroButtonVariant.secondary,
                    size: SubZeroButtonSize.small,
                    onPressed: () {},
                  ),
                  onTap: () {},
                ),
                SubZeroHorizontalCard(
                  leading: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: SubZeroColors.success.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                    ),
                    child: const Icon(Icons.check_circle_outline, color: SubZeroColors.success),
                  ),
                  title: 'Task Completed',
                  subtitle: 'Review design mockups',
                  showBorder: true,
                  elevation: SubZeroCardElevation.none,
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Card Group
            Text('Card Group', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Multiple cards with consistent spacing',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SubZeroCardGroup(
              direction: Axis.horizontal,
              children: [
                SizedBox(
                  width: 180,
                  child: SubZeroCard(
                    onTap: () {},
                    header: const SubZeroCardHeader(
                      title: 'Card 1',
                      leading: Icon(Icons.looks_one, color: SubZeroColors.accent),
                    ),
                  ),
                ),
                SizedBox(
                  width: 180,
                  child: SubZeroCard(
                    onTap: () {},
                    header: const SubZeroCardHeader(
                      title: 'Card 2',
                      leading: Icon(Icons.looks_two, color: SubZeroColors.primary),
                    ),
                  ),
                ),
                SizedBox(
                  width: 180,
                  child: SubZeroCard(
                    onTap: () {},
                    header: const SubZeroCardHeader(
                      title: 'Card 3',
                      leading: Icon(Icons.looks_3, color: SubZeroColors.success),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MediaRatioCard extends StatelessWidget {
  const _MediaRatioCard({required this.label, required this.ratio});

  final String label;
  final SubZeroCardMediaRatio ratio;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: 120,
          child: SubZeroCard(
            elevation: SubZeroCardElevation.low,
            media: SubZeroCardMedia(
              child: Container(
                color: SubZeroColors.surfaceVariant,
                child: const Center(
                  child: Icon(Icons.image_outlined, color: SubZeroColors.textTertiary),
                ),
              ),
              aspectRatio: ratio,
            ),
          ),
        ),
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

class _ElevationCard extends StatelessWidget {
  const _ElevationCard({required this.label, required this.elevation});

  final String label;
  final SubZeroCardElevation elevation;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SubZeroCard(
          elevation: elevation,
          width: 100,
          height: 80,
          padding: const EdgeInsets.all(SubZeroSpacing.sm),
          body: Center(
            child: Text(label, style: SubZeroTypography.textTheme.labelMedium),
          ),
        ),
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for the SubZeroCarousel component.
class CarouselShowcase extends StatefulWidget {
  const CarouselShowcase({super.key});

  @override
  State<CarouselShowcase> createState() => _CarouselShowcaseState();
}

class _CarouselShowcaseState extends State<CarouselShowcase> {
  final SubZeroCarouselController _controller = SubZeroCarouselController();
  bool _autoPlay = false;

  // Sample carousel items
  final List<_CarouselSampleItem> _sampleItems = const [
    _CarouselSampleItem(
      title: 'Welcome to SubZero',
      subtitle: 'A modern design system for Flutter',
      color: SubZeroColors.primary,
      icon: Icons.design_services,
    ),
    _CarouselSampleItem(
      title: 'Beautiful Components',
      subtitle: 'Pre-built widgets following design guidelines',
      color: SubZeroColors.accent,
      icon: Icons.widgets_outlined,
    ),
    _CarouselSampleItem(
      title: 'Responsive Design',
      subtitle: 'Works perfectly on all screen sizes',
      color: SubZeroColors.success,
      icon: Icons.devices,
    ),
    _CarouselSampleItem(
      title: 'Accessible by Default',
      subtitle: 'Built with WCAG compliance in mind',
      color: SubZeroColors.info,
      icon: Icons.accessibility_new,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(SubZeroSpacing.md),
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: BorderRadius.circular(SubZeroRadius.md),
        border: Border.all(color: SubZeroColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Basic Carousel
          Text('Basic Carousel', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Swipe or use arrows to navigate. Dots indicate current position.',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),
          SubZeroCarousel(
            controller: _controller,
            config: SubZeroCarouselConfig(
              enableAutoPlay: _autoPlay,
              autoPlayInterval: const Duration(seconds: 3),
              aspectRatio: 16 / 9,
            ),
            children: _sampleItems.map((item) => _buildCarouselItem(item)).toList(),
            onPageChanged: (index) {
              debugPrint('Carousel page changed to: $index');
            },
          ),

          const SizedBox(height: SubZeroSpacing.lg),

          // Controls
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Auto-play:', style: SubZeroTypography.textTheme.labelMedium),
              const SizedBox(width: SubZeroSpacing.sm),
              Switch(
                value: _autoPlay,
                onChanged: (value) {
                  setState(() => _autoPlay = value);
                  if (value) {
                    _controller.startAutoPlay();
                  } else {
                    _controller.stopAutoPlay();
                  }
                },
                activeColor: SubZeroColors.accent,
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Peek Carousel
          Text('Peek Carousel', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Shows a preview of adjacent items using viewportFraction',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),
          SubZeroCarousel(
            config: const SubZeroCarouselConfig(
              viewportFraction: 0.85,
              itemGap: 12,
              aspectRatio: 2.5,
              showNavigationArrows: false,
            ),
            children: _sampleItems.map((item) => _buildCompactItem(item)).toList(),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Image Cards Carousel
          Text('Image Cards', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Using SubZeroCarouselCard for image content with overlay text',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),
          SubZeroCarousel(
            config: const SubZeroCarouselConfig(
              aspectRatio: 16 / 9,
              enableInfiniteScroll: true,
            ),
            children: [
              SubZeroCarouselCard(
                imageUrl: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800',
                title: 'Mountain Adventure',
                subtitle: 'Discover breathtaking views',
                onTap: () => debugPrint('Mountain card tapped'),
              ),
              SubZeroCarouselCard(
                imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800',
                title: 'Ocean Escape',
                subtitle: 'Relax by the seaside',
                onTap: () => debugPrint('Ocean card tapped'),
              ),
              SubZeroCarouselCard(
                imageUrl: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800',
                title: 'Forest Trail',
                subtitle: 'Explore nature\'s beauty',
                onTap: () => debugPrint('Forest card tapped'),
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Banner Carousel
          Text('Banner Style', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Using SubZeroCarouselBanner for promotional content',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),
          SubZeroCarousel(
            config: const SubZeroCarouselConfig(
              height: 120,
              enableInfiniteScroll: true,
            ),
            children: [
              SubZeroCarouselBanner(
                gradient: const LinearGradient(
                  colors: [SubZeroColors.primary, SubZeroColors.primaryLight],
                ),
                onTap: () => debugPrint('Banner 1 tapped'),
                child: Padding(
                  padding: const EdgeInsets.all(SubZeroSpacing.md),
                  child: Row(
                    children: [
                      const Icon(Icons.local_offer, color: Colors.white, size: 40),
                      const SizedBox(width: SubZeroSpacing.md),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              '50% OFF',
                              style: SubZeroTypography.textTheme.headlineSmall?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Limited time offer on all premium plans',
                              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                                color: Colors.white.withValues(alpha: 0.9),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SubZeroCarouselBanner(
                gradient: const LinearGradient(
                  colors: [SubZeroColors.accent, Color(0xFFFF6B6B)],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(SubZeroSpacing.md),
                  child: Row(
                    children: [
                      const Icon(Icons.rocket_launch, color: Colors.white, size: 40),
                      const SizedBox(width: SubZeroSpacing.md),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'New Feature',
                              style: SubZeroTypography.textTheme.headlineSmall?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Try our new AI-powered recommendations',
                              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                                color: Colors.white.withValues(alpha: 0.9),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Configuration options
          Text('Configuration', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SubZeroCarouselConfig options:',
                  style: SubZeroTypography.textTheme.labelLarge,
                ),
                const SizedBox(height: SubZeroSpacing.sm),
                _ConfigOption('showIndicators', 'Show dot indicators (default: true)'),
                _ConfigOption('showNavigationArrows', 'Show arrow buttons (default: true)'),
                _ConfigOption('enableAutoPlay', 'Auto-rotate items (default: false)'),
                _ConfigOption('autoPlayInterval', 'Time between rotations (default: 4s)'),
                _ConfigOption('enableInfiniteScroll', 'Loop back to start (default: true)'),
                _ConfigOption('viewportFraction', 'Item width ratio (default: 1.0)'),
                _ConfigOption('aspectRatio', 'Width/height ratio (default: 16/9)'),
                _ConfigOption('height', 'Fixed height (overrides aspectRatio)'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCarouselItem(_CarouselSampleItem item) {
    return Container(
      decoration: BoxDecoration(
        color: item.color,
        borderRadius: BorderRadius.circular(SubZeroRadius.md),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(item.icon, size: 48, color: Colors.white),
            const SizedBox(height: SubZeroSpacing.md),
            Text(
              item.title,
              style: SubZeroTypography.textTheme.headlineSmall?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: SubZeroSpacing.xs),
            Text(
              item.subtitle,
              style: SubZeroTypography.textTheme.bodyMedium?.copyWith(
                color: Colors.white.withValues(alpha: 0.9),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompactItem(_CarouselSampleItem item) {
    return Container(
      decoration: BoxDecoration(
        color: item.color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(SubZeroRadius.md),
        border: Border.all(color: item.color.withValues(alpha: 0.3)),
      ),
      padding: const EdgeInsets.all(SubZeroSpacing.md),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: item.color,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: Icon(item.icon, color: Colors.white, size: 24),
          ),
          const SizedBox(width: SubZeroSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  item.title,
                  style: SubZeroTypography.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  item.subtitle,
                  style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                    color: SubZeroColors.textSecondary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CarouselSampleItem {
  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;

  const _CarouselSampleItem({
    required this.title,
    required this.subtitle,
    required this.color,
    required this.icon,
  });
}

class _ConfigOption extends StatelessWidget {
  final String name;
  final String description;

  const _ConfigOption(this.name, this.description);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '• $name: ',
            style: SubZeroTypography.textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: SubZeroColors.accent,
            ),
          ),
          Expanded(
            child: Text(
              description,
              style: SubZeroTypography.textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}

/// Showcase widget for SubZeroCheckbox and SubZeroMultiselectList components.
class CheckboxShowcase extends StatefulWidget {
  const CheckboxShowcase({super.key});

  @override
  State<CheckboxShowcase> createState() => _CheckboxShowcaseState();
}

class _CheckboxShowcaseState extends State<CheckboxShowcase> {
  // Single checkbox states
  bool _basicChecked = false;
  bool _labelChecked = true;
  bool? _tristateValue = null;

  // Multiselect state
  List<String> _selectedFruits = ['apple', 'orange'];

  // Checkbox group state
  List<String> _selectedFeatures = ['dark_mode'];

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Checkbox States
            Text('Checkbox States', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Unchecked, Checked, and Indeterminate (tristate) states',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Row of states matching Figma design
            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.md,
              children: [
                _CheckboxStateCard(
                  label: 'Unchecked',
                  child: SubZeroCheckbox(
                    value: false,
                    onChanged: (_) {},
                  ),
                ),
                _CheckboxStateCard(
                  label: 'Checked',
                  child: SubZeroCheckbox(
                    value: true,
                    onChanged: (_) {},
                  ),
                ),
                _CheckboxStateCard(
                  label: 'Indeterminate',
                  child: SubZeroCheckbox(
                    value: null,
                    tristate: true,
                    onChanged: (_) {},
                  ),
                ),
                _CheckboxStateCard(
                  label: 'Disabled',
                  child: SubZeroCheckbox(
                    value: true,
                    enabled: false,
                    onChanged: (_) {},
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Interactive Checkboxes
            Text('Interactive Examples', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tap checkbox or label to toggle state',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroCheckbox(
              value: _basicChecked,
              onChanged: (value) => setState(() => _basicChecked = value ?? false),
              label: 'Basic checkbox',
            ),
            const SizedBox(height: SubZeroSpacing.md),
            SubZeroCheckbox(
              value: _labelChecked,
              onChanged: (value) => setState(() => _labelChecked = value ?? false),
              label: 'Checkbox item',
            ),
            const SizedBox(height: SubZeroSpacing.md),
            SubZeroCheckbox(
              value: _tristateValue,
              tristate: true,
              onChanged: (value) => setState(() => _tristateValue = value),
              label: 'Tristate checkbox (cycles: unchecked → checked → indeterminate)',
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Checkbox Sizes
            Text('Checkbox Sizes', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Small (16px), Medium (20px), and Large (24px)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                _CheckboxStateCard(
                  label: 'Small',
                  child: SubZeroCheckbox(
                    value: true,
                    size: SubZeroCheckboxSize.small,
                    onChanged: (_) {},
                    label: 'Small',
                  ),
                ),
                _CheckboxStateCard(
                  label: 'Medium',
                  child: SubZeroCheckbox(
                    value: true,
                    size: SubZeroCheckboxSize.medium,
                    onChanged: (_) {},
                    label: 'Medium',
                  ),
                ),
                _CheckboxStateCard(
                  label: 'Large',
                  child: SubZeroCheckbox(
                    value: true,
                    size: SubZeroCheckboxSize.large,
                    onChanged: (_) {},
                    label: 'Large',
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Multiselect List (matching Figma exactly)
            Text('Multiselect List', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'List of checkboxes with "Select All" functionality',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: SubZeroMultiselectList<String>(
                options: const [
                  SubZeroMultiselectOption(value: 'apple', label: 'Checkbox item'),
                  SubZeroMultiselectOption(value: 'banana', label: 'Checkbox item'),
                  SubZeroMultiselectOption(value: 'orange', label: 'Checkbox item'),
                  SubZeroMultiselectOption(value: 'grape', label: 'Checkbox item'),
                ],
                selectedValues: _selectedFruits,
                onChanged: (values) => setState(() => _selectedFruits = values),
                config: const SubZeroMultiselectConfig(
                  showSelectAll: true,
                  selectAllLabel: 'All',
                ),
              ),
            ),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Selected: ${_selectedFruits.isEmpty ? "None" : _selectedFruits.join(", ")}',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Checkbox Group (horizontal)
            Text('Checkbox Group (Horizontal)', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Horizontal layout for inline multi-selection',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroCheckboxGroup<String>(
              options: const [
                SubZeroMultiselectOption(value: 'dark_mode', label: 'Dark Mode'),
                SubZeroMultiselectOption(value: 'notifications', label: 'Notifications'),
                SubZeroMultiselectOption(value: 'auto_save', label: 'Auto Save'),
              ],
              selectedValues: _selectedFeatures,
              onChanged: (values) => setState(() => _selectedFeatures = values),
              wrap: true,
            ),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Selected: ${_selectedFeatures.isEmpty ? "None" : _selectedFeatures.join(", ")}',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Accessibility
            Text('Accessibility', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tab to focus, Enter/Space to toggle. All checkboxes have semantic labels.',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.md,
              children: [
                SubZeroCheckbox(
                  value: true,
                  onChanged: (_) {},
                  label: 'Tab to focus me',
                  semanticLabel: 'Accessible checkbox example',
                ),
                SubZeroCheckbox(
                  value: false,
                  enabled: false,
                  onChanged: null,
                  label: 'Disabled state',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CheckboxStateCard extends StatelessWidget {
  const _CheckboxStateCard({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        child,
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for SubZeroDialog component.
class DialogShowcase extends StatelessWidget {
  const DialogShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dialog Types
            Text('Dialog Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Modal dialogs for interruptions, confirmations, and focused tasks',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Basic Dialogs Row
            Text('Basic Dialogs', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _DialogTriggerButton(
                  label: 'Two Buttons',
                  onPressed: () => _showTwoButtonDialog(context),
                ),
                _DialogTriggerButton(
                  label: 'Flushed Button',
                  onPressed: () => _showFlushedButtonDialog(context),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Dialogs with Content Area
            Text('With Content Area', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Include custom content like images, forms, or media',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _DialogTriggerButton(
                  label: 'Content + Two Buttons',
                  onPressed: () => _showContentTwoButtonDialog(context),
                ),
                _DialogTriggerButton(
                  label: 'Content + Flushed',
                  onPressed: () => _showContentFlushedDialog(context),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Helper Functions
            Text('Helper Functions', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Convenient wrappers for common dialog patterns',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _DialogTriggerButton(
                  label: 'Confirm Dialog',
                  onPressed: () => _showConfirmDialog(context),
                ),
                _DialogTriggerButton(
                  label: 'Alert Dialog',
                  onPressed: () => _showAlertDialog(context),
                ),
                _DialogTriggerButton(
                  label: 'Alert (Flushed)',
                  onPressed: () => _showAlertFlushedDialog(context),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Custom Content
            Text('Custom Content', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Pass any widget as dialog content for maximum flexibility',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),
            _DialogTriggerButton(
              label: 'Custom Form',
              onPressed: () => _showCustomFormDialog(context),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'showSubZeroDialog() parameters:',
                    style: SubZeroTypography.textTheme.labelMedium,
                  ),
                  const SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('title', 'Dialog header text (required)'),
                  _ApiItem('subtitle', 'Optional kicker/subtitle text'),
                  _ApiItem('body', 'Main body text content'),
                  _ApiItem('content', 'Custom widget for content area'),
                  _ApiItem('actions', 'SubZeroDialogActions configuration'),
                  _ApiItem('actionLayout', 'sideBySide, flushed, or custom'),
                  _ApiItem('barrierDismissible', 'Allow tap outside to dismiss'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTwoButtonDialog(BuildContext context) {
    showSubZeroDialog(
      context: context,
      title: 'Header',
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Auctor nulla leo rutrum nisl in. Ac vitae tempor diam maecenas eget at quam. Neque orci arcu amet.',
      actions: SubZeroDialogActions(
        primaryLabel: 'Button',
        onPrimary: () => Navigator.of(context).pop(),
        secondaryLabel: 'Close',
        onSecondary: () => Navigator.of(context).pop(),
      ),
    );
  }

  void _showFlushedButtonDialog(BuildContext context) {
    showSubZeroDialog(
      context: context,
      title: 'Header',
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Auctor nulla leo rutrum nisl in. Ac vitae tempor diam maecenas eget at quam. Neque orci arcu amet.',
      actionLayout: SubZeroDialogActionLayout.flushed,
      actions: SubZeroDialogActions(
        primaryLabel: 'Flushed button',
        onPrimary: () => Navigator.of(context).pop(),
        primaryTrailingIcon: Icons.add,
      ),
    );
  }

  void _showContentTwoButtonDialog(BuildContext context) {
    showSubZeroDialog(
      context: context,
      title: 'Header',
      content: const SubZeroDialogContentArea(
        height: 120,
      ),
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Auctor nulla leo rutrum nisl in. Ac vitae tempor diam maecenas eget at quam. Neque orci arcu amet.',
      actions: SubZeroDialogActions(
        primaryLabel: 'Button',
        onPrimary: () => Navigator.of(context).pop(),
        secondaryLabel: 'Close',
        onSecondary: () => Navigator.of(context).pop(),
      ),
    );
  }

  void _showContentFlushedDialog(BuildContext context) {
    showSubZeroDialog(
      context: context,
      title: 'Header',
      content: const SubZeroDialogContentArea(
        height: 120,
      ),
      body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Auctor nulla leo rutrum nisl in. Ac vitae tempor diam maecenas eget at quam. Neque orci arcu amet.',
      actionLayout: SubZeroDialogActionLayout.flushed,
      actions: SubZeroDialogActions(
        primaryLabel: 'Flushed button',
        onPrimary: () => Navigator.of(context).pop(),
        primaryTrailingIcon: Icons.add,
      ),
    );
  }

  void _showConfirmDialog(BuildContext context) async {
    final confirmed = await showSubZeroConfirmDialog(
      context: context,
      title: 'Delete Item?',
      body: 'This action cannot be undone. Are you sure you want to proceed?',
      confirmLabel: 'Delete',
      cancelLabel: 'Cancel',
    );
    if (context.mounted) {
      debugPrint('Confirm dialog result: $confirmed');
    }
  }

  void _showAlertDialog(BuildContext context) {
    showSubZeroAlertDialog(
      context: context,
      title: 'Success',
      body: 'Your profile has been updated successfully.',
      dismissLabel: 'OK',
    );
  }

  void _showAlertFlushedDialog(BuildContext context) {
    showSubZeroAlertDialog(
      context: context,
      title: 'Welcome!',
      body: 'Thanks for joining us. Get started by exploring the app.',
      dismissLabel: 'Get Started',
      useFlushedButton: true,
      trailingIcon: Icons.arrow_forward,
    );
  }

  void _showCustomFormDialog(BuildContext context) {
    showSubZeroDialog(
      context: context,
      title: 'Add Feedback',
      content: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Your feedback',
                hintText: 'Tell us what you think...',
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding: const EdgeInsets.all(SubZeroSpacing.md),
              ),
              maxLines: 3,
            ),
          ),
          const SizedBox(height: SubZeroSpacing.md),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              5,
              (index) => Icon(
                index < 4 ? Icons.star : Icons.star_border,
                color: SubZeroColors.warning,
                size: 28,
              ),
            ),
          ),
        ],
      ),
      body: 'Rate your experience below.',
      actions: SubZeroDialogActions(
        primaryLabel: 'Submit',
        onPrimary: () => Navigator.of(context).pop(),
        secondaryLabel: 'Cancel',
        onSecondary: () => Navigator.of(context).pop(),
      ),
    );
  }
}

class _DialogTriggerButton extends StatelessWidget {
  const _DialogTriggerButton({
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: SubZeroColors.primary,
        side: const BorderSide(color: SubZeroColors.primary),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(SubZeroRadius.sm),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: SubZeroSpacing.lg,
          vertical: SubZeroSpacing.md,
        ),
      ),
      child: Text(label),
    );
  }
}

class _ApiItem extends StatelessWidget {
  final String name;
  final String description;

  const _ApiItem(this.name, this.description);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '• $name: ',
            style: SubZeroTypography.textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: SubZeroColors.accent,
            ),
          ),
          Expanded(
            child: Text(
              description,
              style: SubZeroTypography.textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}

/// Showcase widget for SubZeroDivider component.
class DividerShowcase extends StatelessWidget {
  const DividerShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Horizontal Dividers
            Text('Horizontal Dividers', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Line and Section variants for separating horizontal content',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Line divider
            Text('Line Divider (1px)', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.symmetric(vertical: SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: const Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Text('Content above'),
                  ),
                  SubZeroDivider(),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Text('Content below'),
                  ),
                ],
              ),
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Section divider
            Text('Section Divider (8px)', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.symmetric(vertical: SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: const Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Text('Section 1'),
                  ),
                  SubZeroDivider(variant: SubZeroDividerVariant.section),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Text('Section 2'),
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Vertical Dividers
            Text('Vertical Dividers', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Line and Section variants for separating vertical content',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Vertical dividers in a row
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: IntrinsicHeight(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Line'),
                        SizedBox(height: SubZeroSpacing.sm),
                        SubZeroVerticalDivider(length: 48),
                      ],
                    ),
                    const SizedBox(width: SubZeroSpacing.xxl),
                    const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Section'),
                        SizedBox(height: SubZeroSpacing.sm),
                        SubZeroVerticalDivider(
                          variant: SubZeroDividerVariant.section,
                          length: 48,
                        ),
                      ],
                    ),
                    const SizedBox(width: SubZeroSpacing.xxl),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('Custom'),
                        const SizedBox(height: SubZeroSpacing.sm),
                        SubZeroVerticalDivider(
                          thickness: 3,
                          length: 48,
                          color: SubZeroColors.primary,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Customization options
            Text('Customization', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Custom thickness, color, indent, and margin',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Indented divider
            Text('Indented Divider', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.symmetric(vertical: SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Row(
                      children: [
                        Icon(Icons.person, size: 20),
                        SizedBox(width: SubZeroSpacing.sm),
                        Text('List Item 1'),
                      ],
                    ),
                  ),
                  SubZeroDivider(indent: 40),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Row(
                      children: [
                        Icon(Icons.settings, size: 20),
                        SizedBox(width: SubZeroSpacing.sm),
                        Text('List Item 2'),
                      ],
                    ),
                  ),
                  SubZeroDivider(indent: 40),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.md),
                    child: Row(
                      children: [
                        Icon(Icons.info, size: 20),
                        SizedBox(width: SubZeroSpacing.sm),
                        Text('List Item 3'),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Custom color divider
            Text('Custom Colors', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            const Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _ColorDividerSample(label: 'Primary', color: SubZeroColors.primary),
                _ColorDividerSample(label: 'Success', color: SubZeroColors.success),
                _ColorDividerSample(label: 'Warning', color: SubZeroColors.warning),
                _ColorDividerSample(label: 'Error', color: SubZeroColors.error),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _ApiItem('orientation', 'horizontal | vertical'),
                  _ApiItem('variant', 'line (1px) | section (8px)'),
                  _ApiItem('thickness', 'Custom thickness override'),
                  _ApiItem('length', 'Extent in main axis direction'),
                  _ApiItem('color', 'Custom color override'),
                  _ApiItem('indent', 'Start indentation'),
                  _ApiItem('endIndent', 'End indentation'),
                  _ApiItem('margin', 'Custom margin around divider'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ColorDividerSample extends StatelessWidget {
  const _ColorDividerSample({required this.label, required this.color});
  
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 80,
          child: SubZeroDivider(thickness: 2, color: color, margin: EdgeInsets.zero),
        ),
        const SizedBox(height: SubZeroSpacing.xs),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for SubZeroHeader component.
class HeaderShowcase extends StatefulWidget {
  const HeaderShowcase({super.key});

  @override
  State<HeaderShowcase> createState() => _HeaderShowcaseState();
}

class _HeaderShowcaseState extends State<HeaderShowcase> {
  bool _isScrolled = false;
  int _activeNavIndex = 0;

  final List<SubZeroHeaderNavItem> _navItems = [];

  @override
  void initState() {
    super.initState();
    _navItems.addAll([
      SubZeroHeaderNavItem(
        label: 'Home',
        onTap: () => setState(() => _activeNavIndex = 0),
        isActive: _activeNavIndex == 0,
      ),
      SubZeroHeaderNavItem(
        label: 'Products',
        onTap: () => setState(() => _activeNavIndex = 1),
        isActive: _activeNavIndex == 1,
      ),
      SubZeroHeaderNavItem(
        label: 'Services',
        onTap: () => setState(() => _activeNavIndex = 2),
        isActive: _activeNavIndex == 2,
      ),
      SubZeroHeaderNavItem(
        label: 'Contact',
        onTap: () => setState(() => _activeNavIndex = 3),
        isActive: _activeNavIndex == 3,
      ),
    ]);
  }

  List<SubZeroHeaderNavItem> get _updatedNavItems => [
    SubZeroHeaderNavItem(
      label: 'Home',
      onTap: () => setState(() => _activeNavIndex = 0),
      isActive: _activeNavIndex == 0,
    ),
    SubZeroHeaderNavItem(
      label: 'Products',
      onTap: () => setState(() => _activeNavIndex = 1),
      isActive: _activeNavIndex == 1,
    ),
    SubZeroHeaderNavItem(
      label: 'Services',
      onTap: () => setState(() => _activeNavIndex = 2),
      isActive: _activeNavIndex == 2,
    ),
    SubZeroHeaderNavItem(
      label: 'Contact',
      onTap: () => setState(() => _activeNavIndex = 3),
      isActive: _activeNavIndex == 3,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Primary Header
            Text('Primary Header', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Burgundy branded header with navigation and actions',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            ClipRRect(
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              child: SubZeroHeader(
                variant: SubZeroHeaderVariant.primary,
                brandName: 'AXIS BANK',
                logo: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(SubZeroRadius.xs),
                  ),
                  child: const Icon(Icons.account_balance, color: Colors.white, size: 24),
                ),
                navigationItems: _updatedNavItems,
                isScrolled: _isScrolled,
                actions: [
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined),
                    onPressed: () {},
                    tooltip: 'Notifications',
                  ),
                  IconButton(
                    icon: const Icon(Icons.person_outline),
                    onPressed: () {},
                    tooltip: 'Profile',
                  ),
                ],
              ),
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // Surface Header
            Text('Surface Header (Product Branding)', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'White header with "open | PRODUCT NAME" sub-branding pattern',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            ClipRRect(
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              child: SubZeroHeader(
                variant: SubZeroHeaderVariant.surface,
                productName: 'PRODUCT NAME',
                logo: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: SubZeroColors.primary,
                    borderRadius: BorderRadius.circular(SubZeroRadius.xs),
                  ),
                  child: const Icon(Icons.account_balance, color: Colors.white, size: 18),
                ),
                navigationItems: _updatedNavItems,
                isScrolled: _isScrolled,
                actions: [
                  IconButton(
                    icon: const Icon(Icons.search),
                    onPressed: () {},
                    tooltip: 'Search',
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Scroll State Toggle
            Text('Scroll State', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Toggle to simulate scrolled appearance (adds drop shadow)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.md),

            Row(
              children: [
                Text('Scrolled:', style: SubZeroTypography.textTheme.labelMedium),
                const SizedBox(width: SubZeroSpacing.sm),
                Switch(
                  value: _isScrolled,
                  onChanged: (value) => setState(() => _isScrolled = value),
                  activeColor: SubZeroColors.primary,
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Header without Navigation
            Text('Minimal Header', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Header with only branding and actions (no navigation)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            ClipRRect(
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              child: SubZeroHeader(
                variant: SubZeroHeaderVariant.primary,
                brandName: 'AXIS BANK',
                logo: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(SubZeroRadius.xs),
                  ),
                  child: const Icon(Icons.account_balance, color: Colors.white, size: 24),
                ),
                showAngledEdge: false,
                isScrolled: _isScrolled,
                actions: [
                  IconButton(
                    icon: const Icon(Icons.menu),
                    onPressed: () {},
                    tooltip: 'Menu',
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _ApiItem('variant', 'primary (burgundy) | surface (white)'),
                  _ApiItem('logo', 'Widget for brand logo'),
                  _ApiItem('brandName', 'Main brand text (primary variant)'),
                  _ApiItem('productName', 'Product name for "open | NAME" pattern'),
                  _ApiItem('navigationItems', 'List of SubZeroHeaderNavItem'),
                  _ApiItem('actions', 'List of action widgets (icons, etc.)'),
                  _ApiItem('isScrolled', 'Adds elevation when true'),
                  _ApiItem('showAngledEdge', 'Show/hide angled corner clip'),
                  _ApiItem('onLogoTap', 'Callback for logo/brand tap'),
                  _ApiItem('onMenuPressed', 'Callback for mobile menu button'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Showcase widget for SubZeroOnboarding and SubZeroCoachMark components.
class OnboardingShowcase extends StatefulWidget {
  const OnboardingShowcase({super.key});

  @override
  State<OnboardingShowcase> createState() => _OnboardingShowcaseState();
}

class _OnboardingShowcaseState extends State<OnboardingShowcase> {
  // GlobalKeys for coachmark targets
  final _targetKey1 = GlobalKey();
  final _targetKey2 = GlobalKey();
  final _targetKey3 = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Coachmark Section
            Text('Coachmark Tooltip', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Spotlight overlay that points to specific UI elements',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Demo targets with trigger button
            Wrap(
              spacing: SubZeroSpacing.lg,
              runSpacing: SubZeroSpacing.lg,
              children: [
                _DemoTarget(
                  key: _targetKey1,
                  label: 'Target 1',
                  icon: Icons.star_outline,
                ),
                _DemoTarget(
                  key: _targetKey2,
                  label: 'Target 2',
                  icon: Icons.favorite_outline,
                ),
                _DemoTarget(
                  key: _targetKey3,
                  label: 'Target 3',
                  icon: Icons.bookmark_outline,
                ),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _DialogTriggerButton(
                  label: 'Show Single Coachmark',
                  onPressed: () => _showSingleCoachmark(),
                ),
                _DialogTriggerButton(
                  label: 'Show Coachmark Tour',
                  onPressed: () => _showCoachmarkTour(),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Onboarding Card Section
            Text('Onboarding Card', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Card-style feature introduction with media area and action buttons',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Center(
              child: SubZeroOnboardingCard(
                title: 'New feature',
                description: 'Something about this feature and what it does.',
                mediaWidget: const Icon(
                  Icons.play_circle_outline,
                  size: 48,
                  color: SubZeroColors.textSecondary,
                ),
                primaryButtonLabel: 'Show me more',
                secondaryButtonLabel: 'Not interested',
                onPrimaryPressed: () => _showSnackbar('Show me more pressed'),
                onSecondaryPressed: () => _showSnackbar('Not interested pressed'),
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Onboarding Dialog Section
            Text('Onboarding Dialog', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Multi-step modal onboarding with progress indicators',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _DialogTriggerButton(
                  label: 'Show Onboarding Dialog',
                  onPressed: () => _showOnboardingDialog(),
                ),
                _DialogTriggerButton(
                  label: 'Show Single Step',
                  onPressed: () => _showSingleStepDialog(),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.sm),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _ApiItem('SubZeroCoachMark.show()', 'Show single coachmark tooltip'),
                  _ApiItem('SubZeroCoachMark.showTour()', 'Show sequential coachmark steps'),
                  _ApiItem('SubZeroOnboardingCard', 'Card-style feature introduction'),
                  _ApiItem('showSubZeroOnboardingDialog()', 'Multi-step modal onboarding'),
                  _ApiItem('SubZeroOnboardingService', 'Persistence manager for "show once" logic'),
                  _ApiItem('SubZeroFeatureTourController', 'Controller for complex feature tours'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 1)),
    );
  }

  void _showSingleCoachmark() {
    SubZeroCoachMark.show(
      context: context,
      targetKey: _targetKey1,
      title: 'New feature',
      description: 'Something about this feature and what it does.',
      position: SubZeroCoachMarkPosition.bottom,
      onDismiss: () => _showSnackbar('Coachmark dismissed'),
    );
  }

  void _showCoachmarkTour() {
    SubZeroCoachMark.showTour(
      context: context,
      steps: [
        SubZeroCoachMarkStep(
          targetKey: _targetKey1,
          title: 'Step 1: Favorites',
          description: 'Tap the star to mark items as favorites.',
          position: SubZeroCoachMarkPosition.bottom,
        ),
        SubZeroCoachMarkStep(
          targetKey: _targetKey2,
          title: 'Step 2: Like',
          description: 'Show appreciation by tapping the heart.',
          position: SubZeroCoachMarkPosition.bottom,
        ),
        SubZeroCoachMarkStep(
          targetKey: _targetKey3,
          title: 'Step 3: Bookmark',
          description: 'Save items for later with the bookmark.',
          position: SubZeroCoachMarkPosition.bottom,
        ),
      ],
      onComplete: () => _showSnackbar('Tour completed!'),
    );
  }

  Future<void> _showOnboardingDialog() async {
    final completed = await showSubZeroOnboardingDialog(
      context: context,
      badgeLabel: 'Quick tip',
      steps: [
        const SubZeroOnboardingStep(
          title: 'New feature',
          description: 'Something about this feature and what it does.',
        ),
        const SubZeroOnboardingStep(
          title: 'Another feature',
          description: 'Learn how to use this powerful capability in your workflow.',
        ),
        const SubZeroOnboardingStep(
          title: 'Final tip',
          description: 'You\'re all set! Start exploring and enjoy the app.',
        ),
      ],
      onComplete: () => debugPrint('Onboarding completed'),
      onSkip: () => debugPrint('Onboarding skipped'),
    );
    _showSnackbar(completed ? 'Onboarding completed!' : 'Onboarding skipped');
  }

  Future<void> _showSingleStepDialog() async {
    await showSubZeroOnboardingDialog(
      context: context,
      badgeLabel: 'Quick tip',
      steps: [
        const SubZeroOnboardingStep(
          title: 'New feature',
          description: 'Something about this feature and what it does.',
        ),
      ],
    );
  }
}

class _DemoTarget extends StatelessWidget {
  final String label;
  final IconData icon;

  const _DemoTarget({
    super.key,
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(SubZeroSpacing.md),
      decoration: BoxDecoration(
        color: SubZeroColors.surfaceVariant,
        borderRadius: BorderRadius.circular(SubZeroRadius.sm),
        border: Border.all(color: SubZeroColors.border),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 32, color: SubZeroColors.primary),
          const SizedBox(height: SubZeroSpacing.xs),
          Text(
            label,
            style: SubZeroTypography.textTheme.labelMedium,
          ),
        ],
      ),
    );
  }
}

/// Showcase widget for SubZeroProgressTracker component.
class ProgressTrackerShowcase extends StatefulWidget {
  const ProgressTrackerShowcase({super.key});

  @override
  State<ProgressTrackerShowcase> createState() => _ProgressTrackerShowcaseState();
}

class _ProgressTrackerShowcaseState extends State<ProgressTrackerShowcase> {
  int _currentStep = 2;

  final List<SubZeroProgressStep> _steps = const [
    SubZeroProgressStep(title: 'Verification'),
    SubZeroProgressStep(title: 'Profile information'),
    SubZeroProgressStep(title: 'Add fund'),
    SubZeroProgressStep(title: 'Video verification'),
  ];

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Vertical Progress Tracker with Header (Figma Design)
            Text('Vertical Progress Tracker', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Displays steps vertically with optional header showing progress ring',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.lg),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: SubZeroProgressTracker(
                steps: _steps,
                currentStep: _currentStep,
                showHeader: true,
                orientation: SubZeroProgressTrackerOrientation.vertical,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Interactive Controls
            Text('Interactive Demo', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tap steps to navigate (when interactive mode is enabled)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Row(
              children: [
                Text('Current Step: ', style: SubZeroTypography.textTheme.labelMedium),
                Text(
                  '${_currentStep + 1} of ${_steps.length}',
                  style: SubZeroTypography.textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: SubZeroColors.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.md),

            // Step navigation buttons
            Wrap(
              spacing: SubZeroSpacing.sm,
              runSpacing: SubZeroSpacing.sm,
              children: [
                ElevatedButton(
                  onPressed: _currentStep > 0 ? () => setState(() => _currentStep--) : null,
                  child: const Text('Previous'),
                ),
                ElevatedButton(
                  onPressed: _currentStep < _steps.length - 1 ? () => setState(() => _currentStep++) : null,
                  child: const Text('Next'),
                ),
                OutlinedButton(
                  onPressed: () => setState(() => _currentStep = 0),
                  child: const Text('Reset'),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Horizontal Progress Tracker
            Text('Horizontal Layout', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Use horizontal orientation for wizards and forms',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.lg),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: SubZeroProgressTracker(
                steps: _steps,
                currentStep: _currentStep,
                orientation: SubZeroProgressTrackerOrientation.horizontal,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Compact Progress Tracker
            Text('Compact Tracker', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Minimal indicators for space-constrained layouts',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.lg),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: SubZeroCompactProgressTracker(
                totalSteps: 4,
                currentStep: _currentStep,
                interactive: true,
                onStepTapped: (index) {
                  setState(() => _currentStep = index);
                },
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Linear Progress Tracker
            Text('Linear Progress Bar', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Continuous progress bar with step markers',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.lg),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: SubZeroLinearProgressTracker(
                totalSteps: 4,
                currentProgress: _currentStep.toDouble(),
                labels: const ['Start', 'Profile', 'Fund', 'Verify'],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Interactive Vertical Tracker
            Text('Interactive Steps', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tap on any step to navigate (useful for non-linear flows)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.lg),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: SubZeroProgressTracker(
                steps: _steps,
                currentStep: _currentStep,
                orientation: SubZeroProgressTrackerOrientation.vertical,
                interactive: true,
                onStepTapped: (index) {
                  setState(() => _currentStep = index);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Navigated to: ${_steps[index].title}'),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Step States
            Text('Step States', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Completed (green checkmark), Current (pink play icon), Pending (numbered outline)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.lg),
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _StateDemo(
                    label: 'Completed',
                    state: SubZeroStepState.completed,
                  ),
                  _StateDemo(
                    label: 'Current',
                    state: SubZeroStepState.current,
                  ),
                  _StateDemo(
                    label: 'Pending',
                    state: SubZeroStepState.pending,
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Accessibility
            Text('Accessibility', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tab to focus steps, Enter/Space to navigate (when interactive)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

/// Helper widget to demonstrate step states
class _StateDemo extends StatelessWidget {
  final String label;
  final SubZeroStepState state;

  const _StateDemo({
    required this.label,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    Color bgColor;
    Color borderColor;
    Color contentColor;
    Widget content;

    switch (state) {
      case SubZeroStepState.completed:
        bgColor = SubZeroColors.success;
        borderColor = SubZeroColors.success;
        contentColor = Colors.white;
        content = Icon(Icons.check, size: 18, color: contentColor);
        break;
      case SubZeroStepState.current:
        bgColor = SubZeroColors.primary;
        borderColor = SubZeroColors.primary;
        contentColor = Colors.white;
        content = Icon(Icons.play_arrow, size: 18, color: contentColor);
        break;
      case SubZeroStepState.pending:
        bgColor = Colors.white;
        borderColor = SubZeroColors.textTertiary;
        contentColor = SubZeroColors.textSecondary;
        content = Text(
          '1',
          style: SubZeroTypography.textTheme.bodySmall?.copyWith(
            color: contentColor,
            fontWeight: FontWeight.w500,
          ),
        );
        break;
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: bgColor,
            border: Border.all(color: borderColor, width: 2),
          ),
          child: Center(child: content),
        ),
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for SubZeroRadio and SubZeroRadioGroup components.
class RadioButtonShowcase extends StatefulWidget {
  const RadioButtonShowcase({super.key});

  @override
  State<RadioButtonShowcase> createState() => _RadioButtonShowcaseState();
}

class _RadioButtonShowcaseState extends State<RadioButtonShowcase> {
  String? _singleSelection;
  String? _groupSelection = 'option1';
  String? _horizontalSelection = 'apple';

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Radio States
            Text('Radio Button States', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Selected and Unselected states (matching Figma design)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Row of states matching Figma design
            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.md,
              children: [
                _RadioStateCard(
                  label: 'Selected',
                  child: SubZeroRadio<String>(
                    value: 'selected',
                    groupValue: 'selected',
                    onChanged: (_) {},
                    label: 'Radio button item',
                  ),
                ),
                _RadioStateCard(
                  label: 'Unselected',
                  child: SubZeroRadio<String>(
                    value: 'option',
                    groupValue: null,
                    onChanged: (_) {},
                    label: 'Radio button item',
                  ),
                ),
                _RadioStateCard(
                  label: 'Disabled',
                  child: SubZeroRadio<String>(
                    value: 'disabled',
                    groupValue: 'disabled',
                    enabled: false,
                    onChanged: null,
                    label: 'Radio button item',
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Size Variants
            Text('Size Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Small (16px), Medium (20px - default), Large (24px)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.xl,
              runSpacing: SubZeroSpacing.md,
              children: [
                _RadioStateCard(
                  label: 'Small',
                  child: SubZeroRadio<String>(
                    value: 'small',
                    groupValue: 'small',
                    size: SubZeroRadioSize.small,
                    onChanged: (_) {},
                    label: 'Small radio',
                  ),
                ),
                _RadioStateCard(
                  label: 'Medium',
                  child: SubZeroRadio<String>(
                    value: 'medium',
                    groupValue: 'medium',
                    size: SubZeroRadioSize.medium,
                    onChanged: (_) {},
                    label: 'Medium radio',
                  ),
                ),
                _RadioStateCard(
                  label: 'Large',
                  child: SubZeroRadio<String>(
                    value: 'large',
                    groupValue: 'large',
                    size: SubZeroRadioSize.large,
                    onChanged: (_) {},
                    label: 'Large radio',
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Interactive Example
            Text('Interactive Example', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tap radio buttons to toggle selection',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SubZeroRadio<String>(
                        value: 'opt1',
                        groupValue: _singleSelection,
                        onChanged: (v) => setState(() => _singleSelection = v),
                        label: 'Option 1',
                      ),
                      const SizedBox(height: SubZeroSpacing.md),
                      SubZeroRadio<String>(
                        value: 'opt2',
                        groupValue: _singleSelection,
                        onChanged: (v) => setState(() => _singleSelection = v),
                        label: 'Option 2',
                      ),
                      const SizedBox(height: SubZeroSpacing.md),
                      SubZeroRadio<String>(
                        value: 'opt3',
                        groupValue: _singleSelection,
                        onChanged: (v) => setState(() => _singleSelection = v),
                        label: 'Option 3',
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(SubZeroSpacing.md),
                    decoration: BoxDecoration(
                      color: SubZeroColors.surfaceVariant,
                      borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                    ),
                    child: Text(
                      'Selected: ${_singleSelection ?? 'None'}',
                      style: SubZeroTypography.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Radio Group (Vertical)
            Text('Radio Group (Vertical)', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'SubZeroRadioGroup manages selection state automatically',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Row(
              children: [
                Expanded(
                  child: SubZeroRadioGroup<String>(
                    items: const ['option1', 'option2', 'option3', 'option4'],
                    initialValue: _groupSelection,
                    onChanged: (v) => setState(() => _groupSelection = v),
                    labelBuilder: (item) => 'Option ${item.replaceAll('option', '')}',
                  ),
                ),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(SubZeroSpacing.md),
                    decoration: BoxDecoration(
                      color: SubZeroColors.surfaceVariant,
                      borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                    ),
                    child: Text(
                      'Group value: $_groupSelection',
                      style: SubZeroTypography.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Radio Group (Horizontal)
            Text('Radio Group (Horizontal)', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Horizontal layout using direction: Axis.horizontal',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroRadioGroup<String>(
              items: const ['apple', 'banana', 'orange', 'grape'],
              initialValue: _horizontalSelection,
              direction: Axis.horizontal,
              spacing: SubZeroSpacing.xl,
              onChanged: (v) => setState(() => _horizontalSelection = v),
              labelBuilder: (item) => item[0].toUpperCase() + item.substring(1),
            ),
            const SizedBox(height: SubZeroSpacing.md),
            Text(
              'Selected fruit: ${_horizontalSelection ?? 'None'}',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Radio Group with Items
            Text('Radio Group with Items', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'SubZeroRadioGroupWithItems allows per-item enabled states',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroRadioGroupWithItems<int>(
              items: const [
                SubZeroRadioItem(value: 1, label: 'Standard shipping (3-5 days)'),
                SubZeroRadioItem(value: 2, label: 'Express shipping (1-2 days)'),
                SubZeroRadioItem(value: 3, label: 'Same day delivery', enabled: false),
                SubZeroRadioItem(value: 4, label: 'Pickup in store'),
              ],
              initialValue: 1,
              onChanged: (v) {},
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SubZeroRadio<T>', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('value', 'The value represented by this radio'),
                  _ApiItem('groupValue', 'Currently selected value'),
                  _ApiItem('onChanged', 'Callback when selected'),
                  _ApiItem('label', 'Optional text label'),
                  _ApiItem('size', 'small | medium | large'),
                  _ApiItem('enabled', 'Enable/disable the radio'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('SubZeroRadioGroup<T>', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('items', 'List of values'),
                  _ApiItem('onChanged', 'Callback with selected value'),
                  _ApiItem('direction', 'vertical | horizontal'),
                  _ApiItem('spacing', 'Spacing between items'),
                  _ApiItem('labelBuilder', 'Custom label function'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RadioStateCard extends StatelessWidget {
  const _RadioStateCard({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: SubZeroTypography.textTheme.labelSmall?.copyWith(
            color: SubZeroColors.textSecondary,
          ),
        ),
        const SizedBox(height: SubZeroSpacing.sm),
        child,
      ],
    );
  }
}

/// Showcase widget for SubZeroSearch component.
class SearchShowcase extends StatefulWidget {
  const SearchShowcase({super.key});

  @override
  State<SearchShowcase> createState() => _SearchShowcaseState();
}

class _SearchShowcaseState extends State<SearchShowcase> {
  String _searchText = '';
  final List<String> _recentSearches = [
    'iPhone 15 Pro',
    'MacBook Air',
    'AirPods Pro',
    'iPad Mini',
    'Apple Watch',
  ];

  List<SubZeroSearchSuggestion> _getSuggestions() {
    if (_searchText.isEmpty) return [];
    return _recentSearches
        .where((s) => s.toLowerCase().contains(_searchText.toLowerCase()))
        .map((s) => SubZeroSearchSuggestion(text: s))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Basic Search Field
            Text('Basic Search Field', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Search input with leading icon, clear button, and optional microphone',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroSearchField(
              hintText: 'Search here',
              onChanged: (text) => setState(() => _searchText = text),
              onSubmitted: (query) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Searching for: $query')),
                );
              },
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Size Variants
            Text('Size Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Small, Medium (default), and Large sizes',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            _SearchSizeDemo(
              label: 'Small (40px)',
              child: SubZeroSearchField(
                hintText: 'Search',
                size: SubZeroSearchSize.small,
                showMicrophone: false,
              ),
            ),
            const SizedBox(height: SubZeroSpacing.md),
            _SearchSizeDemo(
              label: 'Medium (48px)',
              child: SubZeroSearchField(
                hintText: 'Search here',
                size: SubZeroSearchSize.medium,
              ),
            ),
            const SizedBox(height: SubZeroSpacing.md),
            _SearchSizeDemo(
              label: 'Large (56px)',
              child: SubZeroSearchField(
                hintText: 'Search products...',
                size: SubZeroSearchSize.large,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // With Suggestions Dropdown
            Text('With Suggestions', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Search field with autocomplete dropdown (type to see suggestions)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroSearchWithSuggestions(
              hintText: 'Search products...',
              suggestions: _getSuggestions(),
              onChanged: (text) => setState(() => _searchText = text),
              onSuggestionSelected: (suggestion) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Selected: ${suggestion.text}')),
                );
              },
              onSubmitted: (query) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Searching for: $query')),
                );
              },
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Inline Search
            Text('Inline Search', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Compact version for headers/navigation bars',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: Row(
                children: [
                  Text('Header', style: SubZeroTypography.textTheme.titleSmall),
                  const Spacer(),
                  SubZeroInlineSearch(
                    hintText: 'Search',
                    onTap: () => _showFullScreenSearch(context),
                  ),
                  const SizedBox(width: SubZeroSpacing.sm),
                  IconButton(
                    icon: const Icon(Icons.notifications_outlined),
                    onPressed: () {},
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Full Screen Search
            Text('Full Screen Search', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Modal search experience with recent searches and results',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            _DialogTriggerButton(
              label: 'Open Full Screen Search',
              onPressed: () => _showFullScreenSearch(context),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Suggestion Item States
            Text('Suggestion Item', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Individual suggestion items with history icon',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Container(
              decoration: BoxDecoration(
                color: SubZeroColors.surface,
                borderRadius: BorderRadius.circular(SubZeroRadius.md),
                border: Border.all(color: SubZeroColors.border),
              ),
              child: Column(
                children: [
                  SubZeroSearchSuggestionItem(
                    suggestion: const SubZeroSearchSuggestion(text: 'Suggestion item'),
                    onTap: () {},
                  ),
                  SubZeroSearchSuggestionItem(
                    suggestion: const SubZeroSearchSuggestion(text: 'Suggestion item'),
                    onTap: () {},
                  ),
                  SubZeroSearchSuggestionItem(
                    suggestion: const SubZeroSearchSuggestion(text: 'Suggestion item'),
                    onTap: () {},
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SubZeroSearchField', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('hintText', 'Placeholder text'),
                  _ApiItem('onSubmitted', 'Callback when Enter pressed'),
                  _ApiItem('onChanged', 'Callback on text change'),
                  _ApiItem('showMicrophone', 'Show voice search icon'),
                  _ApiItem('size', 'small | medium | large'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('SubZeroSearchWithSuggestions', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('suggestions', 'List of SubZeroSearchSuggestion'),
                  _ApiItem('onSuggestionSelected', 'Callback when suggestion tapped'),
                  _ApiItem('maxSuggestions', 'Max items to display (default: 5)'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('showSubZeroFullScreenSearch()', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('recentSearches', 'List of recent search strings'),
                  _ApiItem('onSearch', 'Async function returning suggestions'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showFullScreenSearch(BuildContext context) async {
    final result = await showSubZeroFullScreenSearch(
      context: context,
      hintText: 'Search products...',
      recentSearches: _recentSearches,
      onSearch: (query) async {
        // Simulate search delay
        await Future.delayed(const Duration(milliseconds: 300));
        return _recentSearches
            .where((s) => s.toLowerCase().contains(query.toLowerCase()))
            .map((s) => SubZeroSearchSuggestion(text: s, icon: Icons.search))
            .toList();
      },
    );
    
    if (result != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('You searched for: $result')),
      );
    }
  }
}

class _SearchSizeDemo extends StatelessWidget {
  final String label;
  final Widget child;

  const _SearchSizeDemo({
    required this.label,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 120,
          child: Text(label, style: SubZeroTypography.textTheme.labelSmall),
        ),
        Expanded(child: child),
      ],
    );
  }
}

/// Showcase widget for SubZeroSlider component.
class SliderShowcase extends StatefulWidget {
  const SliderShowcase({super.key});

  @override
  State<SliderShowcase> createState() => _SliderShowcaseState();
}

class _SliderShowcaseState extends State<SliderShowcase> {
  double _basicValue = 50;
  double _discreteValue = 3;
  double _volumeValue = 70;
  double _brightnessValue = 50;
  RangeValues _priceRange = const RangeValues(200, 800);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Continuous Slider
            Text('Continuous Slider', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Allows selecting any value within the range',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroSlider(
              value: _basicValue,
              min: 0,
              max: 100,
              minLabel: 'xxxx',
              maxLabel: 'xxxx',
              onChanged: (value) => setState(() => _basicValue = value),
              valueFormatter: (v) => v.toStringAsFixed(0),
            ),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Value: ${_basicValue.toStringAsFixed(1)}',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Discrete Slider
            Text('Discrete Slider', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Snaps to fixed division points (steps) along the track',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroSlider(
              value: _discreteValue,
              min: 1,
              max: 5,
              divisions: 4,
              minLabel: '1',
              maxLabel: '5',
              onChanged: (value) => setState(() => _discreteValue = value),
              showTickMarks: true,
            ),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Rating: ${_discreteValue.round()} stars',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Labeled Slider
            Text('Labeled Slider', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Slider with label and value display',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroLabeledSlider(
              label: 'Volume',
              value: _volumeValue,
              min: 0,
              max: 100,
              suffix: '%',
              onChanged: (value) => setState(() => _volumeValue = value),
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            SubZeroLabeledSlider(
              label: 'Brightness',
              value: _brightnessValue,
              min: 0,
              max: 100,
              divisions: 10,
              suffix: '%',
              onChanged: (value) => setState(() => _brightnessValue = value),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Range Slider
            Text('Range Slider', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Select a range between two values',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroRangeSlider(
              values: _priceRange,
              min: 0,
              max: 1000,
              divisions: 20,
              minLabel: '\$0',
              maxLabel: '\$1000',
              onChanged: (values) => setState(() => _priceRange = values),
              valueFormatter: (v) => '\$${v.round()}',
            ),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Price Range: \$${_priceRange.start.round()} - \$${_priceRange.end.round()}',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // States
            Text('States', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Enabled and disabled states',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Enabled', style: SubZeroTypography.textTheme.labelMedium),
                      const SizedBox(height: SubZeroSpacing.sm),
                      SubZeroSlider(
                        value: 60,
                        min: 0,
                        max: 100,
                        onChanged: (_) {},
                        showTooltip: false,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: SubZeroSpacing.lg),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Disabled', style: SubZeroTypography.textTheme.labelMedium),
                      const SizedBox(height: SubZeroSpacing.sm),
                      SubZeroSlider(
                        value: 40,
                        min: 0,
                        max: 100,
                        enabled: false,
                        onChanged: null,
                        showTooltip: false,
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Accessibility
            Text('Accessibility', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tab to focus, use arrow keys to adjust value, Home/End to jump to min/max',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroSlider(
              value: 50,
              min: 0,
              max: 100,
              divisions: 10,
              minLabel: 'Min',
              maxLabel: 'Max',
              onChanged: (_) {},
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SubZeroSlider', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('value', 'Current slider value'),
                  _ApiItem('min / max', 'Value range boundaries'),
                  _ApiItem('divisions', 'Number of discrete steps (null for continuous)'),
                  _ApiItem('onChanged', 'Callback when value changes'),
                  _ApiItem('showTooltip', 'Show value tooltip when dragging'),
                  _ApiItem('showTickMarks', 'Show tick marks for discrete mode'),
                  _ApiItem('minLabel / maxLabel', 'Labels at slider ends'),
                  _ApiItem('valueFormatter', 'Custom value formatting function'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('SubZeroLabeledSlider', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('label', 'Title displayed above slider'),
                  _ApiItem('prefix / suffix', 'Value display formatting'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('SubZeroRangeSlider', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('values', 'RangeValues for start/end'),
                  _ApiItem('onChanged', 'Callback with new RangeValues'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Showcase widget for SubZeroSwitch component.
class SwitchShowcase extends StatefulWidget {
  const SwitchShowcase({super.key});

  @override
  State<SwitchShowcase> createState() => _SwitchShowcaseState();
}

class _SwitchShowcaseState extends State<SwitchShowcase> {
  bool _yesNoValue = true;
  bool _lightDarkValue = false;
  bool _enableNotifications = true;
  bool _darkMode = false;
  bool _toggleValue = true;
  bool _toggleWithLabel = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(SubZeroSpacing.md),
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: BorderRadius.circular(SubZeroRadius.md),
        border: Border.all(color: SubZeroColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Segmented Switch (YES/NO)
          Text('Segmented Switch (YES/NO)', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Binary toggle with visible text labels matching Figma design',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          Wrap(
            spacing: SubZeroSpacing.xl,
            runSpacing: SubZeroSpacing.md,
            children: [
              _SwitchStateCard(
                label: 'Yes Selected',
                child: SubZeroSwitch(
                  value: _yesNoValue,
                  onChanged: (value) => setState(() => _yesNoValue = value),
                ),
              ),
              _SwitchStateCard(
                label: 'No Selected',
                child: SubZeroSwitch(
                  value: false,
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'Disabled',
                child: SubZeroSwitch(
                  value: true,
                  enabled: false,
                  onChanged: null,
                ),
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Custom Labels
          Text('Custom Labels', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Use activeLabel and inactiveLabel to customize text',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          Wrap(
            spacing: SubZeroSpacing.xl,
            runSpacing: SubZeroSpacing.md,
            children: [
              _SwitchStateCard(
                label: 'LIGHT/DARK',
                child: SubZeroSwitch(
                  value: _lightDarkValue,
                  activeLabel: 'LIGHT',
                  inactiveLabel: 'DARK',
                  onChanged: (value) => setState(() => _lightDarkValue = value),
                ),
              ),
              _SwitchStateCard(
                label: 'ON/OFF',
                child: SubZeroSwitch(
                  value: true,
                  activeLabel: 'ON',
                  inactiveLabel: 'OFF',
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'TRUE/FALSE',
                child: SubZeroSwitch(
                  value: false,
                  activeLabel: 'TRUE',
                  inactiveLabel: 'FALSE',
                  onChanged: (_) {},
                ),
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Size Variants
          Text('Size Variants', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Small (32px), Medium (40px - default), Large (48px)',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          Wrap(
            spacing: SubZeroSpacing.xl,
            runSpacing: SubZeroSpacing.md,
            children: [
              _SwitchStateCard(
                label: 'Small',
                child: SubZeroSwitch(
                  value: true,
                  size: SubZeroSwitchSize.small,
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'Medium',
                child: SubZeroSwitch(
                  value: true,
                  size: SubZeroSwitchSize.medium,
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'Large',
                child: SubZeroSwitch(
                  value: true,
                  size: SubZeroSwitchSize.large,
                  onChanged: (_) {},
                ),
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Labeled Switch
          Text('Labeled Switch', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Switch with label and optional description text',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: Column(
              children: [
                SubZeroLabeledSwitch(
                  label: 'Enable Notifications',
                  description: 'Receive push notifications for updates',
                  value: _enableNotifications,
                  onChanged: (value) => setState(() => _enableNotifications = value),
                ),
                const SizedBox(height: SubZeroSpacing.lg),
                SubZeroLabeledSwitch(
                  label: 'Dark Mode',
                  description: 'Switch between light and dark themes',
                  value: _darkMode,
                  activeLabel: 'ON',
                  inactiveLabel: 'OFF',
                  onChanged: (value) => setState(() => _darkMode = value),
                ),
              ],
            ),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Traditional Toggle
          Text('Traditional Toggle', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'iOS-style toggle switch for compact spaces',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          Wrap(
            spacing: SubZeroSpacing.xl,
            runSpacing: SubZeroSpacing.md,
            children: [
              _SwitchStateCard(
                label: 'On',
                child: SubZeroToggle(
                  value: _toggleValue,
                  onChanged: (value) => setState(() => _toggleValue = value),
                ),
              ),
              _SwitchStateCard(
                label: 'Off',
                child: SubZeroToggle(
                  value: false,
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'Disabled',
                child: SubZeroToggle(
                  value: true,
                  enabled: false,
                  onChanged: null,
                ),
              ),
            ],
          ),

          const SizedBox(height: SubZeroSpacing.lg),

          // Toggle sizes
          Wrap(
            spacing: SubZeroSpacing.xl,
            runSpacing: SubZeroSpacing.md,
            children: [
              _SwitchStateCard(
                label: 'Small',
                child: SubZeroToggle(
                  value: true,
                  size: SubZeroSwitchSize.small,
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'Medium',
                child: SubZeroToggle(
                  value: true,
                  size: SubZeroSwitchSize.medium,
                  onChanged: (_) {},
                ),
              ),
              _SwitchStateCard(
                label: 'Large',
                child: SubZeroToggle(
                  value: true,
                  size: SubZeroSwitchSize.large,
                  onChanged: (_) {},
                ),
              ),
            ],
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Labeled Toggle
          Text('Labeled Toggle', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Traditional toggle with label - more compact option',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: SubZeroLabeledToggle(
              label: 'Auto-save documents',
              description: 'Automatically save changes every 30 seconds',
              value: _toggleWithLabel,
              onChanged: (value) => setState(() => _toggleWithLabel = value),
            ),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Accessibility
          Text('Accessibility', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Tab to focus, Enter/Space to toggle, Arrow keys to switch options',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          SubZeroSwitch(
            value: true,
            semanticLabel: 'Enable feature toggle',
            onChanged: (_) {},
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // API Reference
          Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.md),
          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SubZeroSwitch', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: SubZeroSpacing.sm),
                _ApiItem('value', 'Current boolean state (true = active option)'),
                _ApiItem('onChanged', 'Callback when value changes'),
                _ApiItem('activeLabel', 'Text for true state (default: YES)'),
                _ApiItem('inactiveLabel', 'Text for false state (default: NO)'),
                _ApiItem('size', 'small / medium / large'),
                _ApiItem('enabled', 'Whether the switch is interactive'),
                _ApiItem('semanticLabel', 'Accessibility label'),
                SizedBox(height: SubZeroSpacing.md),
                Text('SubZeroToggle', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: SubZeroSpacing.sm),
                _ApiItem('value', 'Current boolean state'),
                _ApiItem('onChanged', 'Callback when value changes'),
                _ApiItem('activeColor', 'Custom track color when on'),
                SizedBox(height: SubZeroSpacing.md),
                Text('SubZeroLabeledSwitch / SubZeroLabeledToggle', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: SubZeroSpacing.sm),
                _ApiItem('label', 'Main label text'),
                _ApiItem('description', 'Optional description below label'),
                _ApiItem('labelPosition', 'start / end'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SwitchStateCard extends StatelessWidget {
  const _SwitchStateCard({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        child,
        const SizedBox(height: SubZeroSpacing.sm),
        Text(label, style: SubZeroTypography.textTheme.labelSmall),
      ],
    );
  }
}

/// Showcase widget for SubZeroTabs component.
class TabsShowcase extends StatefulWidget {
  const TabsShowcase({super.key});

  @override
  State<TabsShowcase> createState() => _TabsShowcaseState();
}

class _TabsShowcaseState extends State<TabsShowcase>
    with SingleTickerProviderStateMixin {
  int _selectedPrimaryIndex = 0;
  int _selectedSecondaryIndex = 0;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(SubZeroSpacing.md),
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: BorderRadius.circular(SubZeroRadius.md),
        border: Border.all(color: SubZeroColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Tabs', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Organize content into separate, navigable categories',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          // Primary Tabs
          Text('Primary Tabs (Underline)', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Classic tab style with underline indicator for selected state',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Overview'),
              SubZeroTabItem(label: 'Details'),
              SubZeroTabItem(label: 'Reviews'),
              SubZeroTabItem(label: 'Settings'),
            ],
            selectedIndex: _selectedPrimaryIndex,
            onTabChanged: (index) => setState(() => _selectedPrimaryIndex = index),
            variant: SubZeroTabVariant.primary,
          ),
          const SizedBox(height: SubZeroSpacing.md),
          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: Text(
              'Selected: Tab ${_selectedPrimaryIndex + 1}',
              style: SubZeroTypography.textTheme.bodyMedium,
            ),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Secondary Tabs (Pill Style)
          Text('Secondary Tabs (Pill Style)', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Pill/chip style with filled background for selected state',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'All'),
              SubZeroTabItem(label: 'Active'),
              SubZeroTabItem(label: 'Archived'),
            ],
            selectedIndex: _selectedSecondaryIndex,
            onTabChanged: (index) => setState(() => _selectedSecondaryIndex = index),
            variant: SubZeroTabVariant.secondary,
          ),
          const SizedBox(height: SubZeroSpacing.md),
          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: Text(
              'Selected: Tab ${_selectedSecondaryIndex + 1}',
              style: SubZeroTypography.textTheme.bodyMedium,
            ),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // With Icons and Badges
          Text('With Icons & Badges', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Tabs can include leading icons and notification badges',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Inbox', icon: Icons.inbox_outlined, badgeCount: 5),
              SubZeroTabItem(label: 'Sent', icon: Icons.send_outlined),
              SubZeroTabItem(label: 'Drafts', icon: Icons.drafts_outlined, badgeCount: 2),
              SubZeroTabItem(label: 'Trash', icon: Icons.delete_outline),
            ],
            variant: SubZeroTabVariant.primary,
          ),

          const SizedBox(height: SubZeroSpacing.lg),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Messages', badgeCount: 12),
              SubZeroTabItem(label: 'Notifications', badgeCount: 3),
              SubZeroTabItem(label: 'Updates'),
            ],
            variant: SubZeroTabVariant.secondary,
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Sizes
          Text('Sizes', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Available in small, medium, and large sizes',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          _TabSizeRow(
            label: 'Small',
            child: SubZeroTabs(
              tabs: const [
                SubZeroTabItem(label: 'Tab 1'),
                SubZeroTabItem(label: 'Tab 2'),
                SubZeroTabItem(label: 'Tab 3'),
              ],
              size: SubZeroTabSize.small,
            ),
          ),
          const SizedBox(height: SubZeroSpacing.md),

          _TabSizeRow(
            label: 'Medium',
            child: SubZeroTabs(
              tabs: const [
                SubZeroTabItem(label: 'Tab 1'),
                SubZeroTabItem(label: 'Tab 2'),
                SubZeroTabItem(label: 'Tab 3'),
              ],
              size: SubZeroTabSize.medium,
            ),
          ),
          const SizedBox(height: SubZeroSpacing.md),

          _TabSizeRow(
            label: 'Large',
            child: SubZeroTabs(
              tabs: const [
                SubZeroTabItem(label: 'Tab 1'),
                SubZeroTabItem(label: 'Tab 2'),
                SubZeroTabItem(label: 'Tab 3'),
              ],
              size: SubZeroTabSize.large,
            ),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Expanded Tabs
          Text('Expanded Tabs', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Tabs can expand to fill available width',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Day'),
              SubZeroTabItem(label: 'Week'),
              SubZeroTabItem(label: 'Month'),
              SubZeroTabItem(label: 'Year'),
            ],
            isExpanded: true,
            variant: SubZeroTabVariant.primary,
          ),

          const SizedBox(height: SubZeroSpacing.lg),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Day'),
              SubZeroTabItem(label: 'Week'),
              SubZeroTabItem(label: 'Month'),
            ],
            isExpanded: true,
            variant: SubZeroTabVariant.secondary,
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // Disabled State
          Text('Disabled Tabs', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Individual tabs can be disabled',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Active'),
              SubZeroTabItem(label: 'Disabled', isDisabled: true),
              SubZeroTabItem(label: 'Available'),
            ],
            variant: SubZeroTabVariant.primary,
          ),

          const SizedBox(height: SubZeroSpacing.lg),

          SubZeroTabs(
            tabs: const [
              SubZeroTabItem(label: 'Active'),
              SubZeroTabItem(label: 'Disabled', isDisabled: true),
              SubZeroTabItem(label: 'Available'),
            ],
            variant: SubZeroTabVariant.secondary,
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // TabBar integration
          Text('TabBar Integration', style: SubZeroTypography.textTheme.labelLarge),
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            'Use SubZeroTabBar with Flutter\'s TabController for animated content switching',
            style: SubZeroTypography.textTheme.bodySmall,
          ),
          const SizedBox(height: SubZeroSpacing.md),

          SubZeroTabBar(
            controller: _tabController,
            tabs: const ['Home', 'Search', 'Favorites', 'Profile'],
          ),
          const SizedBox(height: SubZeroSpacing.md),
          SizedBox(
            height: 100,
            child: TabBarView(
              controller: _tabController,
              children: [
                _TabContent(label: 'Home Content', color: SubZeroColors.primary),
                _TabContent(label: 'Search Content', color: SubZeroColors.info),
                _TabContent(label: 'Favorites Content', color: SubZeroColors.warning),
                _TabContent(label: 'Profile Content', color: SubZeroColors.success),
              ],
            ),
          ),

          const Divider(height: SubZeroSpacing.xxl),

          // API Reference
          Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
          const SizedBox(height: SubZeroSpacing.md),
          Container(
            padding: const EdgeInsets.all(SubZeroSpacing.md),
            decoration: BoxDecoration(
              color: SubZeroColors.surfaceVariant,
              borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SubZeroTabs', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: SubZeroSpacing.sm),
                _ApiItem('tabs', 'List<SubZeroTabItem> - Tab configurations'),
                _ApiItem('selectedIndex', 'Currently selected tab index'),
                _ApiItem('onTabChanged', 'Callback when tab selection changes'),
                _ApiItem('variant', 'primary (underline) / secondary (pill)'),
                _ApiItem('size', 'small / medium / large'),
                _ApiItem('isExpanded', 'Whether tabs fill available width'),
                _ApiItem('isScrollable', 'Allow horizontal scrolling'),
                _ApiItem('tabContents', 'Optional content widgets for each tab'),
                SizedBox(height: SubZeroSpacing.md),
                Text('SubZeroTabItem', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: SubZeroSpacing.sm),
                _ApiItem('label', 'Tab label text'),
                _ApiItem('icon', 'Optional leading icon'),
                _ApiItem('badgeCount', 'Optional notification badge count'),
                _ApiItem('isDisabled', 'Whether tab is disabled'),
                SizedBox(height: SubZeroSpacing.md),
                Text('SubZeroTabBar', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: SubZeroSpacing.sm),
                _ApiItem('controller', 'TabController for state management'),
                _ApiItem('tabs', 'List<String> - Tab labels'),
                _ApiItem('variant', 'primary / secondary'),
                _ApiItem('isScrollable', 'Allow horizontal scrolling'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TabSizeRow extends StatelessWidget {
  const _TabSizeRow({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text(label, style: SubZeroTypography.textTheme.labelMedium),
        ),
        Expanded(child: child),
      ],
    );
  }
}

class _TabContent extends StatelessWidget {
  const _TabContent({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(SubZeroRadius.sm),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Center(
        child: Text(
          label,
          style: SubZeroTypography.textTheme.titleMedium?.copyWith(color: color),
        ),
      ),
    );
  }
}

/// Showcase widget for the SubZeroTag component.
class TagShowcase extends StatefulWidget {
  const TagShowcase({super.key});

  @override
  State<TagShowcase> createState() => _TagShowcaseState();
}

class _TagShowcaseState extends State<TagShowcase> {
  Set<String> _selectedCategories = {'design'};
  final List<String> _inputTags = ['Flutter', 'Dart', 'Mobile'];

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tag Variants (Matching Figma)
            Text('Tag Variants', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Three visual states: outlined (default), filled (selected), and disabled',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: const [
                SubZeroTag(label: 'Label', variant: SubZeroTagVariant.outlined),
                SubZeroTag(label: 'Label', variant: SubZeroTagVariant.filled),
                SubZeroTag(label: 'Label', variant: SubZeroTagVariant.disabled),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Display/Status Tags
            Text('Status Tags', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Non-interactive tags for showing status with semantic colors',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: const [
                SubZeroStatusTag.success(label: 'Completed', icon: Icons.check_circle_outline),
                SubZeroStatusTag.warning(label: 'Pending', icon: Icons.schedule),
                SubZeroStatusTag.error(label: 'Failed', icon: Icons.error_outline),
                SubZeroStatusTag.info(label: 'In Progress', icon: Icons.info_outline),
              ],
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Outlined status tags
            Text('Outlined Status Tags', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.md),
            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: const [
                SubZeroStatusTag.success(label: 'Completed', filled: false),
                SubZeroStatusTag.warning(label: 'Pending', filled: false),
                SubZeroStatusTag.error(label: 'Failed', filled: false),
                SubZeroStatusTag.info(label: 'In Progress', filled: false),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Filter Tags
            Text('Filter Tags', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Interactive tags for filtering - tap to toggle selection',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroTagGroup<String>(
              tags: const ['design', 'development', 'marketing', 'sales'],
              selectedTags: _selectedCategories,
              onSelectionChanged: (selected) => setState(() => _selectedCategories = selected),
              labelBuilder: (tag) => tag[0].toUpperCase() + tag.substring(1),
            ),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Selected: ${_selectedCategories.isEmpty ? "None" : _selectedCategories.join(", ")}',
              style: SubZeroTypography.textTheme.bodySmall?.copyWith(
                color: SubZeroColors.textSecondary,
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Removable Tags
            Text('Removable Tags', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tags with dismiss (X) icon for removal',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.sm,
              runSpacing: SubZeroSpacing.sm,
              children: _inputTags.map((tag) {
                return SubZeroTag(
                  label: tag,
                  type: SubZeroTagType.filter,
                  isSelected: true,
                  removable: true,
                  onRemove: () => setState(() => _inputTags.remove(tag)),
                );
              }).toList(),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Tag Input
            Text('Tag Input Field', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Type and press Enter to add tags, click X to remove',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            SubZeroRemovableTagInput(
              tags: _inputTags,
              onTagAdded: (tag) => setState(() => _inputTags.add(tag)),
              onTagRemoved: (tag) => setState(() => _inputTags.remove(tag)),
              hintText: 'Add tag...',
              maxTags: 8,
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Sizes
            Text('Sizes', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Available in small (24px), medium (32px), and large (40px)',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: const [
                SubZeroTag(label: 'Small', size: SubZeroTagSize.small, variant: SubZeroTagVariant.filled),
                SubZeroTag(label: 'Medium', size: SubZeroTagSize.medium, variant: SubZeroTagVariant.filled),
                SubZeroTag(label: 'Large', size: SubZeroTagSize.large, variant: SubZeroTagVariant.filled),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // With Leading Icons
            Text('With Leading Icons', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tags can include optional leading icons',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: const [
                SubZeroTag(label: 'Design', leadingIcon: Icons.palette_outlined),
                SubZeroTag(label: 'Code', leadingIcon: Icons.code, variant: SubZeroTagVariant.filled),
                SubZeroTag(label: 'Settings', leadingIcon: Icons.settings_outlined),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SubZeroTag', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('label', 'Tag label text'),
                  _ApiItem('type', 'display (non-interactive) / filter (interactive)'),
                  _ApiItem('variant', 'outlined / filled / disabled'),
                  _ApiItem('status', 'neutral / success / warning / error / info'),
                  _ApiItem('size', 'small / medium / large'),
                  _ApiItem('isSelected', 'Selection state for filter tags'),
                  _ApiItem('removable', 'Show dismiss icon'),
                  _ApiItem('leadingIcon', 'Optional icon before label'),
                  _ApiItem('onTap', 'Callback when tag is tapped'),
                  _ApiItem('onRemove', 'Callback when dismiss icon is tapped'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('SubZeroTagGroup<T>', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('tags', 'List of tag values'),
                  _ApiItem('selectedTags', 'Set of selected values'),
                  _ApiItem('onSelectionChanged', 'Callback when selection changes'),
                  _ApiItem('labelBuilder', 'Function to convert value to label'),
                  _ApiItem('multiSelect', 'Allow multiple selections'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('SubZeroStatusTag', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('.success()', 'Green success status'),
                  _ApiItem('.warning()', 'Orange warning status'),
                  _ApiItem('.error()', 'Red error status'),
                  _ApiItem('.info()', 'Blue info status'),
                  _ApiItem('filled', 'Use filled (true) or outlined (false) style'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Showcase widget for SubZeroToast component.
class ToastShowcase extends StatelessWidget {
  const ToastShowcase({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Toast Types Preview
            Text('Toast Types', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Non-intrusive feedback messages with status-specific colors',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            // Icon Variants (left column in Figma)
            Text('Icon Variant', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.md),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: const [
                SubZeroToastPreview(
                  message: 'This is a toast for default',
                  type: SubZeroToastType.defaultType,
                  actionMode: SubZeroToastActionMode.icon,
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for info',
                  type: SubZeroToastType.info,
                  actionMode: SubZeroToastActionMode.icon,
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for success',
                  type: SubZeroToastType.success,
                  actionMode: SubZeroToastActionMode.icon,
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for error',
                  type: SubZeroToastType.error,
                  actionMode: SubZeroToastActionMode.icon,
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for warning',
                  type: SubZeroToastType.warning,
                  actionMode: SubZeroToastActionMode.icon,
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.xl),

            // Text Variants (right column in Figma)
            Text('Text Action Variant', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.md),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: const [
                SubZeroToastPreview(
                  message: 'This is a toast for default',
                  type: SubZeroToastType.defaultType,
                  actionMode: SubZeroToastActionMode.text,
                  actionLabel: 'ACTION',
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for info',
                  type: SubZeroToastType.info,
                  actionMode: SubZeroToastActionMode.text,
                  actionLabel: 'ACTION',
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for success',
                  type: SubZeroToastType.success,
                  actionMode: SubZeroToastActionMode.text,
                  actionLabel: 'ACTION',
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for error',
                  type: SubZeroToastType.error,
                  actionMode: SubZeroToastActionMode.text,
                  actionLabel: 'ACTION',
                ),
                SubZeroToastPreview(
                  message: 'This is a toast for warning',
                  type: SubZeroToastType.warning,
                  actionMode: SubZeroToastActionMode.text,
                  actionLabel: 'ACTION',
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Interactive Demo
            Text('Interactive Demo', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.sm),
            Text(
              'Tap buttons to trigger actual toast overlays',
              style: SubZeroTypography.textTheme.bodySmall,
            ),
            const SizedBox(height: SubZeroSpacing.lg),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _ToastTriggerButton(
                  label: 'Default',
                  color: const Color(0xFF3D3D3D),
                  onPressed: () => SubZeroToast.defaultToast(
                    context,
                    message: 'Self recommendation completed',
                  ),
                ),
                _ToastTriggerButton(
                  label: 'Info',
                  color: const Color(0xFF0D5A65),
                  onPressed: () => SubZeroToast.info(
                    context,
                    message: 'Your session will expire in 5 minutes',
                  ),
                ),
                _ToastTriggerButton(
                  label: 'Success',
                  color: const Color(0xFF008A2E),
                  onPressed: () => SubZeroToast.success(
                    context,
                    message: 'Item saved successfully!',
                  ),
                ),
                _ToastTriggerButton(
                  label: 'Error',
                  color: const Color(0xFFDC3545),
                  onPressed: () => SubZeroToast.error(
                    context,
                    message: 'Failed to save changes',
                  ),
                ),
                _ToastTriggerButton(
                  label: 'Warning',
                  color: const Color(0xFFD84A05),
                  onPressed: () => SubZeroToast.warning(
                    context,
                    message: 'Your storage is almost full',
                  ),
                ),
              ],
            ),

            const SizedBox(height: SubZeroSpacing.lg),

            // With Action Button
            Text('With Action Button', style: SubZeroTypography.textTheme.labelLarge),
            const SizedBox(height: SubZeroSpacing.md),

            Wrap(
              spacing: SubZeroSpacing.md,
              runSpacing: SubZeroSpacing.md,
              children: [
                _ToastTriggerButton(
                  label: 'With UNDO',
                  color: SubZeroColors.secondary,
                  onPressed: () => SubZeroToast.show(
                    context,
                    message: 'Item deleted',
                    type: SubZeroToastType.defaultType,
                    actionMode: SubZeroToastActionMode.text,
                    actionLabel: 'UNDO',
                    onAction: () {},
                  ),
                ),
                _ToastTriggerButton(
                  label: 'Top Position',
                  color: SubZeroColors.info,
                  onPressed: () => SubZeroToast.info(
                    context,
                    message: 'Message at top of screen',
                    position: SubZeroToastPosition.top,
                  ),
                ),
                _ToastTriggerButton(
                  label: 'Short Duration',
                  color: SubZeroColors.success,
                  onPressed: () => SubZeroToast.success(
                    context,
                    message: 'Quick notification (2s)',
                    duration: const Duration(seconds: 2),
                  ),
                ),
              ],
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // Usage Example
            Text('Usage', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '// Simple toast\n'
                    'SubZeroToast.success(context, message: \'Saved!\');\n\n'
                    '// With action\n'
                    'SubZeroToast.show(\n'
                    '  context,\n'
                    '  message: \'Item deleted\',\n'
                    '  actionMode: SubZeroToastActionMode.text,\n'
                    '  actionLabel: \'UNDO\',\n'
                    '  onAction: () => undoDelete(),\n'
                    ');',
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),

            const Divider(height: SubZeroSpacing.xxl),

            // API Reference
            Text('API Reference', style: SubZeroTypography.textTheme.titleMedium),
            const SizedBox(height: SubZeroSpacing.md),
            Container(
              padding: const EdgeInsets.all(SubZeroSpacing.md),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: BorderRadius.circular(SubZeroRadius.sm),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SubZeroToast', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('.show()', 'Full configuration toast'),
                  _ApiItem('.defaultToast()', 'Dark gray default toast'),
                  _ApiItem('.info()', 'Teal info toast'),
                  _ApiItem('.success()', 'Green success toast'),
                  _ApiItem('.error()', 'Red error toast'),
                  _ApiItem('.warning()', 'Orange warning toast'),
                  _ApiItem('.dismiss()', 'Manually dismiss current toast'),
                  SizedBox(height: SubZeroSpacing.md),
                  Text('Parameters', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: SubZeroSpacing.sm),
                  _ApiItem('message', 'Toast message text'),
                  _ApiItem('type', 'defaultType / info / success / error / warning'),
                  _ApiItem('position', 'top / bottom'),
                  _ApiItem('actionMode', 'icon (X button) / text (ACTION button)'),
                  _ApiItem('duration', 'Auto-dismiss duration (default 4s)'),
                  _ApiItem('actionLabel', 'Custom action button text'),
                  _ApiItem('onAction', 'Callback when action is tapped'),
                  _ApiItem('leadingIcon', 'Optional icon before message'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ToastTriggerButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onPressed;

  const _ToastTriggerButton({
    required this.label,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(
          horizontal: SubZeroSpacing.md,
          vertical: SubZeroSpacing.sm,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(SubZeroRadius.sm),
        ),
      ),
      child: Text(label),
    );
  }
}
