import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';
import 'package:sub_zero_design_system/design_system/theme/elevation.dart';
import 'package:sub_zero_design_system/components/subzero_button.dart';

/// Action button layout for SubZeroDialog
enum SubZeroDialogActionLayout {
  /// Two buttons side-by-side (secondary on left, primary on right)
  sideBySide,

  /// Single full-width flushed button at bottom
  flushed,

  /// Custom layout - use [actions] widget directly
  custom,
}

/// Configuration for dialog actions
class SubZeroDialogActions {
  /// Primary action button label (right side or flushed)
  final String primaryLabel;

  /// Primary action callback
  final VoidCallback? onPrimary;

  /// Secondary action button label (left side, only for sideBySide layout)
  final String? secondaryLabel;

  /// Secondary action callback
  final VoidCallback? onSecondary;

  /// Whether primary button shows loading state
  final bool primaryLoading;

  /// Optional trailing icon for flushed button
  final IconData? primaryTrailingIcon;

  const SubZeroDialogActions({
    required this.primaryLabel,
    this.onPrimary,
    this.secondaryLabel,
    this.onSecondary,
    this.primaryLoading = false,
    this.primaryTrailingIcon,
  });
}

/// Shows a SubZero-styled modal dialog.
///
/// This function displays a modal dialog that interrupts the user's workflow
/// to convey critical information, request a decision, or initiate a focused task.
///
/// Returns a [Future] that completes when the dialog is dismissed.
///
/// Example usage:
/// ```dart
/// // Simple dialog with two buttons
/// showSubZeroDialog(
///   context: context,
///   title: 'Confirm Action',
///   body: 'Are you sure you want to proceed?',
///   actions: SubZeroDialogActions(
///     primaryLabel: 'Confirm',
///     onPrimary: () => Navigator.of(context).pop(true),
///     secondaryLabel: 'Cancel',
///     onSecondary: () => Navigator.of(context).pop(false),
///   ),
/// );
///
/// // Dialog with flushed button
/// showSubZeroDialog(
///   context: context,
///   title: 'Success',
///   body: 'Your changes have been saved.',
///   actionLayout: SubZeroDialogActionLayout.flushed,
///   actions: SubZeroDialogActions(
///     primaryLabel: 'Continue',
///     onPrimary: () => Navigator.of(context).pop(),
///     primaryTrailingIcon: Icons.add,
///   ),
/// );
/// ```
Future<T?> showSubZeroDialog<T>({
  required BuildContext context,
  required String title,
  String? subtitle,
  String? body,
  Widget? content,
  SubZeroDialogActions? actions,
  SubZeroDialogActionLayout actionLayout = SubZeroDialogActionLayout.sideBySide,
  Widget? customActions,
  bool barrierDismissible = true,
  double? maxWidth,
  EdgeInsets? contentPadding,
}) {
  return showGeneralDialog<T>(
    context: context,
    barrierDismissible: barrierDismissible,
    barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
    barrierColor: Colors.black.withValues(alpha: 0.6),
    transitionDuration: const Duration(milliseconds: 200),
    pageBuilder: (context, animation, secondaryAnimation) {
      return SubZeroDialog(
        title: title,
        subtitle: subtitle,
        body: body,
        content: content,
        actions: actions,
        actionLayout: actionLayout,
        customActions: customActions,
        maxWidth: maxWidth,
        contentPadding: contentPadding,
      );
    },
    transitionBuilder: (context, animation, secondaryAnimation, child) {
      return ScaleTransition(
        scale: CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
        ),
        child: FadeTransition(
          opacity: animation,
          child: child,
        ),
      );
    },
  );
}

/// A modal dialog widget following the SubZero 2.0 Design System.
///
/// This widget is typically shown using [showSubZeroDialog].
/// It provides a temporary, non-blocking interruption for user attention
/// with a clear title, optional content area, and action buttons.
class SubZeroDialog extends StatelessWidget {
  /// The dialog title (required, displayed prominently)
  final String title;

  /// Optional subtitle/kicker displayed above or below the title
  final String? subtitle;

  /// The main body text content
  final String? body;

  /// Optional custom content widget (displayed between title and body)
  final Widget? content;

  /// Configuration for action buttons
  final SubZeroDialogActions? actions;

  /// Layout style for action buttons
  final SubZeroDialogActionLayout actionLayout;

  /// Custom actions widget (overrides [actions] when [actionLayout] is custom)
  final Widget? customActions;

  /// Maximum width of the dialog
  final double? maxWidth;

  /// Custom content padding
  final EdgeInsets? contentPadding;

  const SubZeroDialog({
    super.key,
    required this.title,
    this.subtitle,
    this.body,
    this.content,
    this.actions,
    this.actionLayout = SubZeroDialogActionLayout.sideBySide,
    this.customActions,
    this.maxWidth,
    this.contentPadding,
  });

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final dialogMaxWidth = maxWidth ?? 340.0;
    final dialogWidth = screenSize.width > dialogMaxWidth + 48
        ? dialogMaxWidth
        : screenSize.width - 48;

    return Center(
      child: Material(
        color: Colors.transparent,
        child: Semantics(
          label: 'Dialog: $title',
          child: Container(
            width: dialogWidth,
            constraints: BoxConstraints(
              maxHeight: screenSize.height * 0.85,
            ),
            decoration: BoxDecoration(
              color: SubZeroColors.surface,
              borderRadius: SubZeroRadius.large,
              boxShadow: SubZeroElevation.level4,
            ),
            child: ClipRRect(
              borderRadius: SubZeroRadius.large,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Content area
                  Flexible(
                    child: SingleChildScrollView(
                      padding: contentPadding ??
                          const EdgeInsets.fromLTRB(
                            SubZeroSpacing.lg,
                            SubZeroSpacing.lg,
                            SubZeroSpacing.lg,
                            SubZeroSpacing.md,
                          ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Title
                          Text(
                            title,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: SubZeroColors.textPrimary,
                              height: 1.3,
                            ),
                          ),

                          // Subtitle (if provided)
                          if (subtitle != null) ...[
                            const SizedBox(height: SubZeroSpacing.xs),
                            Text(
                              subtitle!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: SubZeroColors.textSecondary,
                                height: 1.4,
                              ),
                            ),
                          ],

                          // Custom content slot (e.g., images, forms)
                          if (content != null) ...[
                            const SizedBox(height: SubZeroSpacing.md),
                            content!,
                          ],

                          // Body text
                          if (body != null) ...[
                            const SizedBox(height: SubZeroSpacing.md),
                            Text(
                              body!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                color: SubZeroColors.textSecondary,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),

                  // Actions
                  _buildActions(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActions(BuildContext context) {
    if (actionLayout == SubZeroDialogActionLayout.custom && customActions != null) {
      return customActions!;
    }

    if (actions == null) return const SizedBox.shrink();

    if (actionLayout == SubZeroDialogActionLayout.flushed) {
      return _buildFlushedAction(context);
    }

    return _buildSideBySideActions(context);
  }

  Widget _buildFlushedAction(BuildContext context) {
    return SubZeroButton(
      label: actions!.primaryLabel,
      variant: SubZeroButtonVariant.flushed,
      trailingIcon: actions!.primaryTrailingIcon,
      isLoading: actions!.primaryLoading,
      fullWidth: true,
      onPressed: actions!.onPrimary ?? () => Navigator.of(context).pop(),
    );
  }

  Widget _buildSideBySideActions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        SubZeroSpacing.md,
        SubZeroSpacing.sm,
        SubZeroSpacing.md,
        SubZeroSpacing.md,
      ),
      child: Row(
        children: [
          // Secondary button (Cancel/Close)
          if (actions!.secondaryLabel != null)
            Expanded(
              child: SubZeroButton(
                label: actions!.secondaryLabel!,
                variant: SubZeroButtonVariant.secondary,
                fullWidth: true,
                onPressed: actions!.onSecondary ?? () => Navigator.of(context).pop(),
              ),
            ),

          if (actions!.secondaryLabel != null)
            const SizedBox(width: SubZeroSpacing.sm),

          // Primary button
          Expanded(
            child: SubZeroButton(
              label: actions!.primaryLabel,
              variant: SubZeroButtonVariant.primary,
              isLoading: actions!.primaryLoading,
              fullWidth: true,
              onPressed: actions!.onPrimary ?? () => Navigator.of(context).pop(),
            ),
          ),
        ],
      ),
    );
  }
}

/// A pre-built content widget for dialogs with placeholder content area.
///
/// This widget provides a consistent structure matching the Figma design
/// with a gray content placeholder area that can hold images, forms, etc.
///
/// Example usage:
/// ```dart
/// showSubZeroDialog(
///   context: context,
///   title: 'Upload Image',
///   content: SubZeroDialogContentArea(
///     height: 120,
///     child: Icon(Icons.cloud_upload, size: 48, color: SubZeroColors.textTertiary),
///   ),
///   body: 'Drag and drop an image or click to browse.',
///   actions: SubZeroDialogActions(
///     primaryLabel: 'Upload',
///     secondaryLabel: 'Cancel',
///   ),
/// );
/// ```
class SubZeroDialogContentArea extends StatelessWidget {
  /// Child widget to display inside the content area
  final Widget? child;

  /// Height of the content area
  final double height;

  /// Background color of the content area
  final Color? backgroundColor;

  /// Border radius of the content area
  final BorderRadius? borderRadius;

  const SubZeroDialogContentArea({
    super.key,
    this.child,
    this.height = 100,
    this.backgroundColor,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: height,
      decoration: BoxDecoration(
        color: backgroundColor ?? SubZeroColors.surfaceVariant,
        borderRadius: borderRadius ?? SubZeroRadius.small,
      ),
      child: child != null
          ? Center(child: child)
          : null,
    );
  }
}

/// A confirmation dialog helper that returns true/false.
///
/// This is a convenience wrapper around [showSubZeroDialog] for common
/// confirmation scenarios.
///
/// Example usage:
/// ```dart
/// final confirmed = await showSubZeroConfirmDialog(
///   context: context,
///   title: 'Delete Item?',
///   body: 'This action cannot be undone.',
///   confirmLabel: 'Delete',
///   cancelLabel: 'Cancel',
/// );
/// if (confirmed == true) {
///   // Proceed with deletion
/// }
/// ```
Future<bool?> showSubZeroConfirmDialog({
  required BuildContext context,
  required String title,
  String? body,
  String confirmLabel = 'Confirm',
  String cancelLabel = 'Cancel',
  bool barrierDismissible = true,
}) {
  return showSubZeroDialog<bool>(
    context: context,
    title: title,
    body: body,
    barrierDismissible: barrierDismissible,
    actions: SubZeroDialogActions(
      primaryLabel: confirmLabel,
      onPrimary: () => Navigator.of(context).pop(true),
      secondaryLabel: cancelLabel,
      onSecondary: () => Navigator.of(context).pop(false),
    ),
  );
}

/// An alert dialog helper for informational messages.
///
/// This is a convenience wrapper around [showSubZeroDialog] for simple
/// alert/info scenarios with a single dismiss button.
///
/// Example usage:
/// ```dart
/// await showSubZeroAlertDialog(
///   context: context,
///   title: 'Success',
///   body: 'Your profile has been updated.',
///   dismissLabel: 'OK',
/// );
/// ```
Future<void> showSubZeroAlertDialog({
  required BuildContext context,
  required String title,
  String? body,
  String dismissLabel = 'OK',
  bool useFlushedButton = false,
  IconData? trailingIcon,
}) {
  return showSubZeroDialog(
    context: context,
    title: title,
    body: body,
    actionLayout: useFlushedButton
        ? SubZeroDialogActionLayout.flushed
        : SubZeroDialogActionLayout.sideBySide,
    actions: SubZeroDialogActions(
      primaryLabel: dismissLabel,
      onPrimary: () => Navigator.of(context).pop(),
      primaryTrailingIcon: trailingIcon,
    ),
  );
}
