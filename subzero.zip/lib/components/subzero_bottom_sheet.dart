import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/typography.dart';
import 'package:sub_zero_design_system/design_system/theme/elevation.dart';

/// Configuration for the SubZero Bottom Sheet component.
class SubZeroBottomSheetConfig {
  /// Whether the sheet can be dismissed by tapping the scrim.
  final bool barrierDismissible;

  /// Whether to show the drag handle on mobile.
  final bool showDragHandle;

  /// Whether to show the close button.
  final bool showCloseButton;

  /// Whether the sheet is draggable on mobile.
  final bool enableDrag;

  /// Maximum width for desktop/web dialog mode.
  final double maxDialogWidth;

  /// Breakpoint for switching between mobile and desktop layouts.
  final double desktopBreakpoint;

  /// Background color of the sheet.
  final Color? backgroundColor;

  /// Color of the scrim overlay.
  final Color? scrimColor;

  /// Whether to use scrollable content (wrap content in DraggableScrollableSheet).
  final bool useScrollableSheet;

  /// Initial height fraction for scrollable sheet (0.0 to 1.0).
  final double initialHeightFraction;

  const SubZeroBottomSheetConfig({
    this.barrierDismissible = true,
    this.showDragHandle = true,
    this.showCloseButton = true,
    this.enableDrag = true,
    this.maxDialogWidth = 520,
    this.desktopBreakpoint = 600,
    this.backgroundColor,
    this.scrimColor,
    this.useScrollableSheet = false,
    this.initialHeightFraction = 0.5,
  });
}

/// Pre-built content structure matching the SubZero design system.
/// Use this for consistent bottom sheet layouts.
class SubZeroBottomSheetContent extends StatelessWidget {
  /// Optional widget for the top illustration/animation area.
  final Widget? topContent;

  /// Whether the top content should overflow outside the sheet (mobile only).
  final bool topContentOverflows;

  /// Optional kicker text (small label above title).
  final String? kicker;

  /// Title text.
  final String title;

  /// Optional supporting description text.
  final String? description;

  /// Main content area widget.
  final Widget? bodyContent;

  /// Primary action button label.
  final String? primaryButtonLabel;

  /// Primary action button callback.
  final VoidCallback? onPrimaryPressed;

  /// Secondary action button label (for desktop layout).
  final String? secondaryButtonLabel;

  /// Secondary action button callback.
  final VoidCallback? onSecondaryPressed;

  /// Whether to show two buttons side by side (desktop style).
  final bool showDualButtons;

  const SubZeroBottomSheetContent({
    super.key,
    this.topContent,
    this.topContentOverflows = false,
    this.kicker,
    required this.title,
    this.description,
    this.bodyContent,
    this.primaryButtonLabel,
    this.onPrimaryPressed,
    this.secondaryButtonLabel,
    this.onSecondaryPressed,
    this.showDualButtons = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Top content area (illustration/animation)
        if (topContent != null) ...[
          topContent!,
          const SizedBox(height: SubZeroSpacing.lg),
        ],

        // Kicker text
        if (kicker != null) ...[
          Text(
            kicker!.toUpperCase(),
            style: SubZeroTypography.textTheme.labelSmall?.copyWith(
              color: SubZeroColors.textSecondary,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: SubZeroSpacing.xs),
        ],

        // Title
        Text(
          title,
          style: SubZeroTypography.textTheme.titleLarge?.copyWith(
            color: SubZeroColors.textPrimary,
          ),
        ),

        // Description
        if (description != null) ...[
          const SizedBox(height: SubZeroSpacing.sm),
          Text(
            description!,
            style: SubZeroTypography.textTheme.bodyMedium?.copyWith(
              color: SubZeroColors.textSecondary,
            ),
          ),
        ],

        // Body content
        if (bodyContent != null) ...[
          const SizedBox(height: SubZeroSpacing.lg),
          bodyContent!,
        ],

        // Action buttons
        if (primaryButtonLabel != null) ...[
          const SizedBox(height: SubZeroSpacing.lg),
          if (showDualButtons && secondaryButtonLabel != null)
            _buildDualButtons(context)
          else
            _buildPrimaryButton(context),
        ],
      ],
    );
  }

  Widget _buildPrimaryButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton(
        onPressed: onPrimaryPressed ?? () => Navigator.of(context).pop(),
        style: ElevatedButton.styleFrom(
          backgroundColor: SubZeroColors.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(SubZeroRadius.sm),
          ),
          elevation: 0,
        ),
        child: Text(
          primaryButtonLabel!,
          style: SubZeroTypography.textTheme.labelLarge?.copyWith(
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildDualButtons(BuildContext context) {
    return Row(
      children: [
        // Secondary button (outlined)
        Expanded(
          child: SizedBox(
            height: 48,
            child: OutlinedButton(
              onPressed: onSecondaryPressed ?? () => Navigator.of(context).pop(),
              style: OutlinedButton.styleFrom(
                foregroundColor: SubZeroColors.primary,
                side: const BorderSide(color: SubZeroColors.primary),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                ),
              ),
              child: Text(
                secondaryButtonLabel!,
                style: SubZeroTypography.textTheme.labelLarge?.copyWith(
                  color: SubZeroColors.primary,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: SubZeroSpacing.md),
        // Primary button
        Expanded(
          child: SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: onPrimaryPressed ?? () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                backgroundColor: SubZeroColors.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(SubZeroRadius.sm),
                ),
                elevation: 0,
              ),
              child: Text(
                primaryButtonLabel!,
                style: SubZeroTypography.textTheme.labelLarge?.copyWith(
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// Shows a SubZero styled modal bottom sheet (mobile) or dialog (desktop).
///
/// The sheet automatically adapts to screen size:
/// - On mobile: Shows as a modal bottom sheet with floating close button
/// - On desktop: Shows as a centered modal dialog
///
/// Example:
/// ```dart
/// showSubZeroBottomSheet(
///   context: context,
///   builder: (context) => SubZeroBottomSheetContent(
///     kicker: 'Step 1',
///     title: 'Add your recommendation',
///     description: 'Select a recommendation to add to your journey.',
///     primaryButtonLabel: 'Continue',
///     onPrimaryPressed: () => Navigator.pop(context),
///   ),
/// );
/// ```
Future<T?> showSubZeroBottomSheet<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  SubZeroBottomSheetConfig config = const SubZeroBottomSheetConfig(),
}) {
  final screenWidth = MediaQuery.of(context).size.width;
  final isDesktop = screenWidth >= config.desktopBreakpoint;

  if (isDesktop) {
    return _showDesktopDialog<T>(
      context: context,
      builder: builder,
      config: config,
    );
  } else {
    return _showMobileModalBottomSheet<T>(
      context: context,
      builder: builder,
      config: config,
    );
  }
}

Future<T?> _showMobileModalBottomSheet<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  required SubZeroBottomSheetConfig config,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    isDismissible: config.barrierDismissible,
    enableDrag: config.enableDrag,
    backgroundColor: Colors.transparent,
    barrierColor: config.scrimColor ?? Colors.black.withValues(alpha: 0.5),
    useSafeArea: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(SubZeroRadius.xl),
      ),
    ),
    builder: (sheetContext) => _SubZeroMobileModalSheet(
      config: config,
      content: builder(sheetContext),
    ),
  );
}

Future<T?> _showDesktopDialog<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  required SubZeroBottomSheetConfig config,
}) {
  return showDialog<T>(
    context: context,
    barrierDismissible: config.barrierDismissible,
    barrierColor: config.scrimColor ?? Colors.black.withValues(alpha: 0.5),
    builder: (dialogContext) => _SubZeroDesktopDialog(
      config: config,
      content: builder(dialogContext),
    ),
  );
}

/// Mobile modal bottom sheet implementation with floating close button on scrim.
class _SubZeroMobileModalSheet extends StatelessWidget {
  final SubZeroBottomSheetConfig config;
  final Widget content;

  const _SubZeroMobileModalSheet({
    required this.config,
    required this.content,
  });

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).viewPadding.bottom;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Floating close button above the sheet (on scrim)
        if (config.showCloseButton)
          Padding(
            padding: const EdgeInsets.only(bottom: SubZeroSpacing.md),
            child: Semantics(
              button: true,
              label: 'Close bottom sheet',
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => Navigator.of(context).pop(),
                  customBorder: const CircleBorder(),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: SubZeroColors.secondary.withValues(alpha: 0.85),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.close,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ),
          ),

        // The actual bottom sheet content
        Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          decoration: BoxDecoration(
            color: config.backgroundColor ?? SubZeroColors.surface,
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(SubZeroRadius.xl),
            ),
            boxShadow: SubZeroElevation.level4,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Drag handle
              if (config.showDragHandle) const _DragHandle(),

              // Scrollable content
              Flexible(
                child: SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(
                    SubZeroSpacing.lg,
                    config.showDragHandle ? SubZeroSpacing.sm : SubZeroSpacing.lg,
                    SubZeroSpacing.lg,
                    SubZeroSpacing.lg + bottomPadding,
                  ),
                  child: content,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Desktop dialog implementation with close button in top-right corner.
class _SubZeroDesktopDialog extends StatelessWidget {
  final SubZeroBottomSheetConfig config;
  final Widget content;

  const _SubZeroDesktopDialog({
    required this.config,
    required this.content,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          constraints: BoxConstraints(
            maxWidth: config.maxDialogWidth,
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          margin: const EdgeInsets.all(SubZeroSpacing.lg),
          decoration: BoxDecoration(
            color: config.backgroundColor ?? SubZeroColors.surface,
            borderRadius: BorderRadius.circular(SubZeroRadius.lg),
            boxShadow: SubZeroElevation.level4,
          ),
          child: Stack(
            children: [
              // Content
              SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  SubZeroSpacing.xl,
                  config.showCloseButton ? SubZeroSpacing.xl + 24 : SubZeroSpacing.xl,
                  SubZeroSpacing.xl,
                  SubZeroSpacing.xl,
                ),
                child: content,
              ),

              // Close button positioned at top-right
              if (config.showCloseButton)
                Positioned(
                  top: SubZeroSpacing.sm,
                  right: SubZeroSpacing.sm,
                  child: Semantics(
                    button: true,
                    label: 'Close dialog',
                    child: IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close),
                      iconSize: 24,
                      color: SubZeroColors.textSecondary,
                      splashRadius: 20,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Drag handle widget for mobile bottom sheet.
class _DragHandle extends StatelessWidget {
  const _DragHandle();

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Drag handle. Swipe down to close.',
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: SubZeroSpacing.md),
        child: Center(
          child: Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: SubZeroColors.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      ),
    );
  }
}

/// Extension to easily show SubZero bottom sheet from any widget.
extension SubZeroBottomSheetExtension on BuildContext {
  /// Shows a SubZero styled modal bottom sheet.
  Future<T?> showSubZeroSheet<T>({
    required WidgetBuilder builder,
    SubZeroBottomSheetConfig config = const SubZeroBottomSheetConfig(),
  }) =>
      showSubZeroBottomSheet<T>(
        context: this,
        builder: builder,
        config: config,
      );

  /// Shows a SubZero styled modal bottom sheet with pre-built content structure.
  Future<T?> showSubZeroContentSheet<T>({
    Widget? topContent,
    bool topContentOverflows = false,
    String? kicker,
    required String title,
    String? description,
    Widget? bodyContent,
    String? primaryButtonLabel,
    VoidCallback? onPrimaryPressed,
    String? secondaryButtonLabel,
    VoidCallback? onSecondaryPressed,
    bool showDualButtons = false,
    SubZeroBottomSheetConfig config = const SubZeroBottomSheetConfig(),
  }) =>
      showSubZeroBottomSheet<T>(
        context: this,
        config: config,
        builder: (context) => SubZeroBottomSheetContent(
          topContent: topContent,
          topContentOverflows: topContentOverflows,
          kicker: kicker,
          title: title,
          description: description,
          bodyContent: bodyContent,
          primaryButtonLabel: primaryButtonLabel,
          onPrimaryPressed: onPrimaryPressed,
          secondaryButtonLabel: secondaryButtonLabel,
          onSecondaryPressed: onSecondaryPressed,
          showDualButtons: showDualButtons,
        ),
      );
}
