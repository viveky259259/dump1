import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/design_system/tokens.dart';

/// Size variants for [SubZeroAvatar].
///
/// Based on SubZero 2.0 Design System specifications.
enum SubZeroAvatarSize {
  /// Small: 24px diameter
  s(24),

  /// Medium: 32px diameter
  m(32),

  /// Large: 40px diameter
  l(40),

  /// Extra Large: 48px diameter
  xl(48),

  /// Double Extra Large: 64px diameter
  xxl(64),

  /// Triple Extra Large: 80px diameter
  threeXL(80);

  /// The diameter in logical pixels.
  final double diameter;

  const SubZeroAvatarSize(this.diameter);

  /// Returns the icon size proportional to the avatar size.
  double get iconSize => diameter * 0.5;

  /// Returns the font size proportional to the avatar size.
  double get fontSize => diameter * 0.4;
}

/// A display-only avatar component following the SubZero 2.0 Design System.
///
/// Represents a user or organization with three display modes:
/// 1. **Image**: When [imageUrl] is provided, displays a circular photo.
/// 2. **Initials**: When [initials] is provided (and no image), displays text.
/// 3. **Icon**: Falls back to a person icon when neither is available.
///
/// Example usage:
/// ```dart
/// // With image
/// SubZeroAvatar(
///   imageUrl: 'https://example.com/photo.jpg',
///   semanticLabel: 'Jane Doe profile picture',
///   size: SubZeroAvatarSize.xl,
/// )
///
/// // With initials
/// SubZeroAvatar(
///   initials: 'JD',
///   size: SubZeroAvatarSize.m,
/// )
///
/// // With custom icon
/// SubZeroAvatar(
///   icon: Icons.business,
///   size: SubZeroAvatarSize.l,
/// )
/// ```
class SubZeroAvatar extends StatelessWidget {
  /// Creates a SubZero avatar component.
  ///
  /// Priority order for display:
  /// 1. [imageUrl] (if provided and loads successfully)
  /// 2. [initials] (if provided)
  /// 3. [icon] or default person icon
  const SubZeroAvatar({
    super.key,
    this.imageUrl,
    this.initials,
    this.icon,
    this.size = SubZeroAvatarSize.m,
    this.semanticLabel,
    this.backgroundColor,
    this.foregroundColor,
  });

  /// URL of the image to display. Takes priority over initials and icon.
  final String? imageUrl;

  /// Initials to display when image is not available (e.g., "JD" for "Jane Doe").
  /// Only the first 2 characters will be displayed.
  final String? initials;

  /// Custom icon to display when neither image nor initials are available.
  /// Defaults to [Icons.person] if not specified.
  final IconData? icon;

  /// Size variant of the avatar.
  final SubZeroAvatarSize size;

  /// Semantic label for accessibility (required when image is displayed).
  ///
  /// This text is read by screen readers to describe the avatar image.
  final String? semanticLabel;

  /// Optional background color override.
  /// Defaults to a neutral gray for icon/initials mode.
  final Color? backgroundColor;

  /// Optional foreground color override (icon/text color).
  /// Defaults to contrasting color based on background.
  final Color? foregroundColor;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: semanticLabel ?? _defaultSemanticLabel,
      image: imageUrl != null,
      child: Container(
        width: size.diameter,
        height: size.diameter,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _effectiveBackgroundColor,
        ),
        clipBehavior: Clip.antiAlias,
        child: _buildContent(),
      ),
    );
  }

  /// Builds the appropriate content based on available data.
  Widget _buildContent() {
    // Priority 1: Image (if URL provided)
    if (imageUrl != null && imageUrl!.isNotEmpty) {
      return _buildImageContent();
    }

    // Priority 2: Initials
    if (initials != null && initials!.isNotEmpty) {
      return _buildInitialsContent();
    }

    // Priority 3: Icon (custom or default)
    return _buildIconContent();
  }

  /// Builds the image avatar with error handling fallback.
  Widget _buildImageContent() {
    return Image.network(
      imageUrl!,
      width: size.diameter,
      height: size.diameter,
      fit: BoxFit.cover,
      semanticLabel: semanticLabel,
      errorBuilder: (context, error, stackTrace) {
        // Fallback to initials or icon on image load error
        if (initials != null && initials!.isNotEmpty) {
          return _buildInitialsFallback();
        }
        return _buildIconFallback();
      },
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) return child;
        return _buildLoadingIndicator(loadingProgress);
      },
    );
  }

  /// Builds the initials avatar.
  Widget _buildInitialsContent() {
    final displayText = _formatInitials(initials!);
    return Center(
      child: Text(
        displayText,
        style: TextStyle(
          fontFamily: tokens.typography.fontFamily.primary,
          fontFamilyFallback: tokens.typography.fontFamily.fallbacks,
          fontSize: size.fontSize,
          fontWeight: tokens.typography.weight.semibold,
          color: _effectiveForegroundColor,
          height: 1,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  /// Builds the icon avatar.
  Widget _buildIconContent() {
    return Center(
      child: Icon(
        icon ?? Icons.person,
        size: size.iconSize,
        color: _effectiveForegroundColor,
      ),
    );
  }

  /// Builds initials fallback when image fails to load.
  Widget _buildInitialsFallback() {
    return Container(
      color: _effectiveBackgroundColor,
      child: _buildInitialsContent(),
    );
  }

  /// Builds icon fallback when image fails to load.
  Widget _buildIconFallback() {
    return Container(
      color: _effectiveBackgroundColor,
      child: _buildIconContent(),
    );
  }

  /// Builds a subtle loading indicator while image loads.
  Widget _buildLoadingIndicator(ImageChunkEvent loadingProgress) {
    final progress = loadingProgress.expectedTotalBytes != null
        ? loadingProgress.cumulativeBytesLoaded /
            loadingProgress.expectedTotalBytes!
        : null;

    return Container(
      color: colors.neutral.n200,
      child: Center(
        child: SizedBox(
          width: size.diameter * 0.4,
          height: size.diameter * 0.4,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            value: progress,
            color: colors.primary[400],
          ),
        ),
      ),
    );
  }

  /// Formats initials to display (max 2 characters, uppercase).
  String _formatInitials(String text) {
    final cleaned = text.trim().toUpperCase();
    return cleaned.length > 2 ? cleaned.substring(0, 2) : cleaned;
  }

  /// Gets the effective background color.
  Color get _effectiveBackgroundColor {
    if (backgroundColor != null) return backgroundColor!;

    // For images, use a neutral placeholder background
    if (imageUrl != null && imageUrl!.isNotEmpty) {
      return colors.neutral.n200;
    }

    // For initials/icon, use a branded light background
    return colors.neutral.n200;
  }

  /// Gets the effective foreground color (ensures WCAG AA contrast).
  Color get _effectiveForegroundColor {
    if (foregroundColor != null) return foregroundColor!;
    return colors.neutral.n600;
  }

  /// Default semantic label when not provided.
  String get _defaultSemanticLabel {
    if (imageUrl != null) return 'Avatar image';
    if (initials != null) return 'Avatar with initials $initials';
    return 'Default avatar';
  }
}

/// Extension for generating initials from a full name.
extension AvatarInitialsExtension on String {
  /// Extracts initials from a name (e.g., "Jane Doe" → "JD").
  ///
  /// Takes the first letter of the first two words.
  String toAvatarInitials() {
    final words = trim().split(RegExp(r'\s+'));
    if (words.isEmpty) return '';
    if (words.length == 1) {
      return words.first.isNotEmpty ? words.first[0].toUpperCase() : '';
    }
    return '${words.first[0]}${words.last[0]}'.toUpperCase();
  }
}
