import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/typography.dart';

/// A single section inside [SubZeroAccordion].
///
/// Each section has:
/// - [title]: header text.
/// - [content]: widget rendered when expanded.
/// - [leadingIcon]: optional icon rendered at the start of the header.
class SubZeroAccordionSection {
  final String title;
  final Widget content;
  final IconData? leadingIcon;

  const SubZeroAccordionSection({
    required this.title,
    required this.content,
    this.leadingIcon,
  });
}

/// SubZero 2.0 Accordion component.
///
/// Key behaviors:
/// - **Single-expandable**: at most one section is expanded at a time.
/// - Tap/click anywhere on the header toggles that section.
/// - Keyboard accessible: Tab focuses headers; Enter/Space toggles.
/// - Smooth motion: animated chevron rotation + animated size reveal.
///
/// Typical use cases: FAQs, grouped content, settings explanations.
class SubZeroAccordion extends StatefulWidget {
  final List<SubZeroAccordionSection> sections;

  /// Which section starts expanded. Use `null` to start fully collapsed.
  final int? initialExpandedIndex;

  /// Called whenever the expanded section changes.
  ///
  /// Value is `null` when everything is collapsed.
  final ValueChanged<int?>? onExpandedIndexChanged;

  /// Optional padding for the expanded content area.
  final EdgeInsetsGeometry contentPadding;

  /// Optional outer margin.
  final EdgeInsetsGeometry margin;

  /// When true, the accordion stretches to the full available width.
  ///
  /// When false, it sizes itself to its child constraints.
  final bool fullWidth;

  const SubZeroAccordion({
    super.key,
    required this.sections,
    this.initialExpandedIndex,
    this.onExpandedIndexChanged,
    this.contentPadding = const EdgeInsets.fromLTRB(
      SubZeroSpacing.lg,
      0,
      SubZeroSpacing.lg,
      SubZeroSpacing.lg,
    ),
    this.margin = EdgeInsets.zero,
    this.fullWidth = true,
  });

  @override
  State<SubZeroAccordion> createState() => _SubZeroAccordionState();
}

class _SubZeroAccordionState extends State<SubZeroAccordion> {
  int? _expandedIndex;

  @override
  void initState() {
    super.initState();
    _expandedIndex = _sanitizeIndex(widget.initialExpandedIndex);
  }

  @override
  void didUpdateWidget(covariant SubZeroAccordion oldWidget) {
    super.didUpdateWidget(oldWidget);

    // If the sections list changed length, ensure expanded index still valid.
    if (oldWidget.sections.length != widget.sections.length) {
      final next = _sanitizeIndex(_expandedIndex);
      if (next != _expandedIndex) setState(() => _expandedIndex = next);
    }
  }

  int? _sanitizeIndex(int? index) {
    if (index == null) return null;
    if (index < 0 || index >= widget.sections.length) {
      debugPrint('SubZeroAccordion: initialExpandedIndex out of range: $index');
      return null;
    }
    return index;
  }

  void _toggle(int index) {
    setState(() {
      _expandedIndex = (_expandedIndex == index) ? null : index;
    });
    widget.onExpandedIndexChanged?.call(_expandedIndex);
  }

  @override
  Widget build(BuildContext context) {
    final child = Container(
      margin: widget.margin,
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: SubZeroRadius.medium,
        border: Border.all(color: SubZeroColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(widget.sections.length, (i) {
          final section = widget.sections[i];
          final expanded = _expandedIndex == i;
          return _AccordionRow(
            key: ValueKey('accordion_section_$i'),
            title: section.title,
            leadingIcon: section.leadingIcon,
            expanded: expanded,
            isFirst: i == 0,
            showDivider: i != widget.sections.length - 1,
            contentPadding: widget.contentPadding,
            onToggle: () => _toggle(i),
            child: section.content,
          );
        }),
      ),
    );

    if (!widget.fullWidth) return child;
    return SizedBox(width: double.infinity, child: child);
  }
}

class _AccordionRow extends StatefulWidget {
  final String title;
  final IconData? leadingIcon;
  final bool expanded;
  final bool isFirst;
  final bool showDivider;
  final EdgeInsetsGeometry contentPadding;
  final VoidCallback onToggle;
  final Widget child;

  const _AccordionRow({
    super.key,
    required this.title,
    required this.leadingIcon,
    required this.expanded,
    required this.isFirst,
    required this.showDivider,
    required this.contentPadding,
    required this.onToggle,
    required this.child,
  });

  @override
  State<_AccordionRow> createState() => _AccordionRowState();
}

class _AccordionRowState extends State<_AccordionRow> {
  bool _hovered = false;
  bool _focused = false;

  static const _kAnimFast = Duration(milliseconds: 160);
  static const _kAnimMed = Duration(milliseconds: 220);

  @override
  Widget build(BuildContext context) {
    final headerBg = (_hovered || _focused) ? SubZeroColors.surfaceVariant : SubZeroColors.surface;
    final focusBorder = _focused ? SubZeroColors.primary.withValues(alpha: 0.35) : Colors.transparent;

    final header = FocusableActionDetector(
      onShowFocusHighlight: (v) => setState(() => _focused = v),
      onShowHoverHighlight: (v) => setState(() => _hovered = v),
      shortcuts: const <ShortcutActivator, Intent>{
        SingleActivator(LogicalKeyboardKey.enter): ActivateIntent(),
        SingleActivator(LogicalKeyboardKey.space): ActivateIntent(),
      },
      actions: <Type, Action<Intent>>{
        ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (intent) {
          widget.onToggle();
          return null;
        }),
      },
      child: Semantics(
        button: true,
        focusable: true,
        focused: _focused,
        expanded: widget.expanded,
        label: widget.title,
        onTap: widget.onToggle,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: widget.onToggle,
          child: AnimatedContainer(
            duration: _kAnimFast,
            curve: Curves.easeOut,
            decoration: BoxDecoration(
              color: headerBg,
              border: Border(
                top: widget.isFirst ? BorderSide.none : const BorderSide(color: SubZeroColors.divider),
                bottom: widget.showDivider && !widget.expanded ? const BorderSide(color: SubZeroColors.divider) : BorderSide.none,
              ),
              boxShadow: const [],
            ),
            child: AnimatedContainer(
              duration: _kAnimFast,
              curve: Curves.easeOut,
              decoration: BoxDecoration(
                border: Border.all(color: focusBorder, width: 2),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: SubZeroSpacing.lg, vertical: SubZeroSpacing.lg),
                child: Row(
                  children: [
                    if (widget.leadingIcon != null) ...[
                      Icon(widget.leadingIcon, color: SubZeroColors.secondary, size: 22),
                      const SizedBox(width: SubZeroSpacing.md),
                    ],
                    Expanded(
                      child: Text(
                        widget.title,
                        style: SubZeroTypography.textTheme.titleMedium?.copyWith(color: SubZeroColors.textPrimary),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: SubZeroSpacing.md),
                    AnimatedRotation(
                      duration: _kAnimMed,
                      curve: Curves.easeOut,
                      turns: widget.expanded ? 0.5 : 0.0,
                      child: const Icon(Icons.keyboard_arrow_down, color: SubZeroColors.textSecondary, size: 24),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );

    final content = AnimatedCrossFade(
      duration: _kAnimMed,
      firstCurve: Curves.easeOut,
      secondCurve: Curves.easeOut,
      sizeCurve: Curves.easeOut,
      crossFadeState: widget.expanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
      firstChild: const SizedBox(width: double.infinity, height: 0),
      secondChild: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: SubZeroColors.divider)),
        ),
        padding: widget.contentPadding,
        child: DefaultTextStyle.merge(
          style: SubZeroTypography.textTheme.bodyLarge?.copyWith(color: SubZeroColors.textSecondary, height: 1.55),
          child: widget.child,
        ),
      ),
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        header,
        content,
      ],
    );
  }
}
