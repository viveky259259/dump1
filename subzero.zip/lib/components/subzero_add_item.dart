import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';

/// Configuration for the SubZeroAddItem component.
class SubZeroAddItemConfig {
  /// Initial quantity when transitioning to quantity mode.
  final int initialQuantity;

  /// Minimum allowed quantity (typically 0 or 1).
  final int minQuantity;

  /// Maximum allowed quantity (capped at 99 for 2-digit display).
  final int maxQuantity;

  /// Text displayed on the add button.
  final String addButtonText;

  /// Text displayed on the "more" button (if enabled).
  final String moreButtonText;

  /// Whether to show the "More" button with dropdown.
  final bool showMoreOption;

  const SubZeroAddItemConfig({
    this.initialQuantity = 1,
    this.minQuantity = 0,
    this.maxQuantity = 99,
    this.addButtonText = 'ADD',
    this.moreButtonText = 'MORE',
    this.showMoreOption = false,
  }) : assert(maxQuantity <= 99, 'Max quantity must be 99 or less for 2-digit display'),
       assert(minQuantity >= 0, 'Min quantity must be 0 or greater'),
       assert(initialQuantity >= minQuantity && initialQuantity <= maxQuantity,
           'Initial quantity must be within min/max bounds');
}

/// A reusable Add Item component following the SubZero 2.0 Design System.
///
/// This component allows users to add an item and manage its quantity via
/// a stepper interface. It transitions from an "Add" button to a quantity
/// stepper with plus/minus controls.
///
/// Features:
/// - Initial "Add" button state
/// - Quantity stepper mode with +/- controls
/// - Optional "More" button that triggers a bottom sheet
/// - Keyboard accessibility with Tab navigation
/// - Visual feedback for min/max bounds
/// - Animated transitions between states
class SubZeroAddItem extends StatefulWidget {
  /// Configuration for the component behavior.
  final SubZeroAddItemConfig config;

  /// Callback fired when quantity changes.
  final ValueChanged<int>? onQuantityChanged;

  /// Callback fired when the "More" button is tapped.
  final VoidCallback? onMoreTapped;

  /// Callback fired when transitioning from Add to Quantity mode.
  final VoidCallback? onItemAdded;

  /// External quantity value for controlled mode.
  final int? quantity;

  /// Whether to start in quantity mode.
  final bool startInQuantityMode;

  const SubZeroAddItem({
    super.key,
    this.config = const SubZeroAddItemConfig(),
    this.onQuantityChanged,
    this.onMoreTapped,
    this.onItemAdded,
    this.quantity,
    this.startInQuantityMode = false,
  });

  @override
  State<SubZeroAddItem> createState() => _SubZeroAddItemState();
}

class _SubZeroAddItemState extends State<SubZeroAddItem>
    with SingleTickerProviderStateMixin {
  late bool _isQuantityMode;
  late int _quantity;
  late AnimationController _animationController;

  // Focus nodes for keyboard navigation
  final FocusNode _addButtonFocus = FocusNode();
  final FocusNode _minusFocus = FocusNode();
  final FocusNode _plusFocus = FocusNode();
  final FocusNode _moreFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    _isQuantityMode = widget.startInQuantityMode;
    _quantity = widget.quantity ?? widget.config.initialQuantity;

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    if (_isQuantityMode) {
      _animationController.value = 1.0;
    }
  }

  @override
  void didUpdateWidget(SubZeroAddItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.quantity != null && widget.quantity != _quantity) {
      setState(() => _quantity = widget.quantity!);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _addButtonFocus.dispose();
    _minusFocus.dispose();
    _plusFocus.dispose();
    _moreFocus.dispose();
    super.dispose();
  }

  void _transitionToQuantityMode() {
    setState(() {
      _isQuantityMode = true;
      _quantity = widget.config.initialQuantity;
    });
    _animationController.forward();
    widget.onItemAdded?.call();
    widget.onQuantityChanged?.call(_quantity);
  }

  void _increment() {
    if (_quantity < widget.config.maxQuantity) {
      setState(() => _quantity++);
      widget.onQuantityChanged?.call(_quantity);
      HapticFeedback.lightImpact();
    }
  }

  void _decrement() {
    if (_quantity > widget.config.minQuantity) {
      setState(() => _quantity--);
      widget.onQuantityChanged?.call(_quantity);
      HapticFeedback.lightImpact();
      
      // Optionally transition back to Add mode when quantity reaches 0
      if (_quantity == 0 && widget.config.minQuantity == 0) {
        _animationController.reverse().then((_) {
          if (mounted) {
            setState(() => _isQuantityMode = false);
          }
        });
      }
    }
  }

  void _handleMoreTap() {
    widget.onMoreTapped?.call();
    // Default bottom sheet if no callback provided
    if (widget.onMoreTapped == null) {
      _showDefaultBottomSheet();
    }
  }

  void _showDefaultBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: SubZeroColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(SubZeroRadius.lg)),
      ),
      builder: (context) => _DefaultMoreBottomSheet(
        currentQuantity: _quantity,
        maxQuantity: widget.config.maxQuantity,
        onQuantitySelected: (qty) {
          Navigator.pop(context);
          setState(() => _quantity = qty);
          widget.onQuantityChanged?.call(_quantity);
        },
      ),
    );
  }

  bool get _canIncrement => _quantity < widget.config.maxQuantity;
  bool get _canDecrement => _quantity > widget.config.minQuantity;

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      transitionBuilder: (child, animation) => FadeTransition(
        opacity: animation,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.95, end: 1.0).animate(animation),
          child: child,
        ),
      ),
      child: _isQuantityMode
          ? widget.config.showMoreOption
              ? _buildMoreButton()
              : _buildQuantityStepper()
          : _buildAddButton(),
    );
  }

  /// Builds the initial "ADD" button.
  Widget _buildAddButton() {
    return Semantics(
      button: true,
      label: 'Add item to cart',
      child: Focus(
        focusNode: _addButtonFocus,
        onKeyEvent: (node, event) {
          if (event is KeyDownEvent &&
              (event.logicalKey == LogicalKeyboardKey.enter ||
               event.logicalKey == LogicalKeyboardKey.space)) {
            _transitionToQuantityMode();
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: GestureDetector(
          onTap: _transitionToQuantityMode,
          child: Container(
            key: const ValueKey('add-button'),
            padding: const EdgeInsets.symmetric(
              horizontal: SubZeroSpacing.lg,
              vertical: SubZeroSpacing.md,
            ),
            decoration: BoxDecoration(
              color: SubZeroColors.surface,
              borderRadius: SubZeroRadius.rounded,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              widget.config.addButtonText,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: SubZeroColors.primary,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the "MORE" button with dropdown indicator.
  Widget _buildMoreButton() {
    return Semantics(
      button: true,
      label: 'Show more options, current quantity $_quantity',
      child: Focus(
        focusNode: _moreFocus,
        onKeyEvent: (node, event) {
          if (event is KeyDownEvent &&
              (event.logicalKey == LogicalKeyboardKey.enter ||
               event.logicalKey == LogicalKeyboardKey.space)) {
            _handleMoreTap();
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: GestureDetector(
          onTap: _handleMoreTap,
          child: Container(
            key: const ValueKey('more-button'),
            padding: const EdgeInsets.symmetric(
              horizontal: SubZeroSpacing.lg,
              vertical: SubZeroSpacing.md,
            ),
            decoration: BoxDecoration(
              color: SubZeroColors.surface,
              borderRadius: SubZeroRadius.rounded,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.config.moreButtonText,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: SubZeroColors.primary,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(width: SubZeroSpacing.sm),
                const Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: SubZeroColors.primary,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the quantity stepper with +/- controls.
  Widget _buildQuantityStepper() {
    return Container(
      key: const ValueKey('quantity-stepper'),
      padding: const EdgeInsets.symmetric(
        horizontal: SubZeroSpacing.md,
        vertical: SubZeroSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: SubZeroRadius.rounded,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Minus button
          _StepperButton(
            icon: Icons.remove,
            onTap: _canDecrement ? _decrement : null,
            enabled: _canDecrement,
            focusNode: _minusFocus,
            semanticLabel: 'Decrease quantity${!_canDecrement ? ', minimum reached' : ''}',
          ),
          
          // Quantity display
          Semantics(
            label: 'Current quantity: $_quantity',
            child: Container(
              constraints: const BoxConstraints(minWidth: 40),
              padding: const EdgeInsets.symmetric(horizontal: SubZeroSpacing.sm),
              alignment: Alignment.center,
              child: Text(
                _quantity.toString().padLeft(1, '0'),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: SubZeroColors.textPrimary,
                ),
              ),
            ),
          ),
          
          // Plus button
          _StepperButton(
            icon: Icons.add,
            onTap: _canIncrement ? _increment : null,
            enabled: _canIncrement,
            focusNode: _plusFocus,
            semanticLabel: 'Increase quantity${!_canIncrement ? ', maximum reached' : ''}',
          ),
        ],
      ),
    );
  }
}

/// Individual stepper button (+/-)
class _StepperButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final bool enabled;
  final FocusNode focusNode;
  final String semanticLabel;

  const _StepperButton({
    required this.icon,
    this.onTap,
    required this.enabled,
    required this.focusNode,
    required this.semanticLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      enabled: enabled,
      label: semanticLabel,
      child: Focus(
        focusNode: focusNode,
        onKeyEvent: (node, event) {
          if (enabled &&
              event is KeyDownEvent &&
              (event.logicalKey == LogicalKeyboardKey.enter ||
               event.logicalKey == LogicalKeyboardKey.space)) {
            onTap?.call();
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: GestureDetector(
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            padding: const EdgeInsets.all(SubZeroSpacing.sm),
            child: Icon(
              icon,
              size: 20,
              color: enabled
                  ? SubZeroColors.primary
                  : SubZeroColors.textTertiary,
            ),
          ),
        ),
      ),
    );
  }
}

/// Default bottom sheet for "More" option.
class _DefaultMoreBottomSheet extends StatelessWidget {
  final int currentQuantity;
  final int maxQuantity;
  final ValueChanged<int> onQuantitySelected;

  const _DefaultMoreBottomSheet({
    required this.currentQuantity,
    required this.maxQuantity,
    required this.onQuantitySelected,
  });

  @override
  Widget build(BuildContext context) {
    final quickSelects = [5, 10, 15, 20, 25].where((q) => q <= maxQuantity).toList();

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(SubZeroSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Handle bar
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: SubZeroColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: SubZeroSpacing.lg),
            
            // Title
            const Text(
              'Select Quantity',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: SubZeroColors.textPrimary,
              ),
            ),
            const SizedBox(height: SubZeroSpacing.md),
            
            // Quick select buttons
            Wrap(
              spacing: SubZeroSpacing.sm,
              runSpacing: SubZeroSpacing.sm,
              children: quickSelects.map((qty) {
                final isSelected = qty == currentQuantity;
                return GestureDetector(
                  onTap: () => onQuantitySelected(qty),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: SubZeroSpacing.lg,
                      vertical: SubZeroSpacing.md,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected ? SubZeroColors.primary : SubZeroColors.surfaceVariant,
                      borderRadius: SubZeroRadius.medium,
                    ),
                    child: Text(
                      qty.toString(),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: isSelected ? Colors.white : SubZeroColors.textPrimary,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: SubZeroSpacing.lg),
          ],
        ),
      ),
    );
  }
}
