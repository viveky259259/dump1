import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';

// ============================================================================
// ONBOARDING SERVICE - Manages display logic and local storage
// ============================================================================

/// A service that manages onboarding and coachmark display logic with persistence.
///
/// Use this service to:
/// - Track which onboarding flows have been completed
/// - Ensure onboarding is only shown once per version/feature
/// - Reset onboarding state for testing or new app versions
///
/// Example usage:
/// ```dart
/// final service = SubZeroOnboardingService();
/// await service.init();
///
/// if (!await service.hasCompleted('welcome_tour_v1')) {
///   // Show onboarding
///   await service.markCompleted('welcome_tour_v1');
/// }
/// ```
class SubZeroOnboardingService {
  static final SubZeroOnboardingService _instance =
      SubZeroOnboardingService._internal();
  factory SubZeroOnboardingService() => _instance;
  SubZeroOnboardingService._internal();

  static const String _keyPrefix = 'subzero_onboarding_';
  SharedPreferences? _prefs;
  bool _isInitialized = false;

  /// Initialize the service. Must be called before using other methods.
  Future<void> init() async {
    if (_isInitialized) return;
    try {
      _prefs = await SharedPreferences.getInstance();
      _isInitialized = true;
    } catch (e) {
      debugPrint('SubZeroOnboardingService: Failed to initialize: $e');
      _isInitialized = true; // Still mark as initialized to prevent retries
    }
  }

  /// Check if a specific onboarding flow has been completed.
  Future<bool> hasCompleted(String onboardingId) async {
    await init();
    return _prefs?.getBool('$_keyPrefix$onboardingId') ?? false;
  }

  /// Mark a specific onboarding flow as completed.
  Future<void> markCompleted(String onboardingId) async {
    await init();
    await _prefs?.setBool('$_keyPrefix$onboardingId', true);
  }

  /// Reset a specific onboarding flow (show again).
  Future<void> reset(String onboardingId) async {
    await init();
    await _prefs?.remove('$_keyPrefix$onboardingId');
  }

  /// Reset all onboarding states (useful for testing or new app versions).
  Future<void> resetAll() async {
    await init();
    if (_prefs == null) return;
    final keys = _prefs!.getKeys().where((k) => k.startsWith(_keyPrefix));
    for (final key in keys) {
      await _prefs!.remove(key);
    }
  }

  /// Check and show onboarding if not completed.
  /// Returns true if onboarding was shown, false if already completed.
  Future<bool> showIfNotCompleted({
    required String onboardingId,
    required Future<void> Function() showOnboarding,
  }) async {
    if (await hasCompleted(onboardingId)) {
      return false;
    }
    await showOnboarding();
    await markCompleted(onboardingId);
    return true;
  }
}

// ============================================================================
// COACHMARK COMPONENT - Spotlight tooltip pointing to UI elements
// ============================================================================

/// Position of the coachmark tooltip relative to the target element.
enum SubZeroCoachMarkPosition {
  top,
  bottom,
  left,
  right,
}

/// Configuration for a coachmark step.
class SubZeroCoachMarkStep {
  /// The GlobalKey of the target widget to highlight
  final GlobalKey targetKey;

  /// The title text
  final String title;

  /// The description text
  final String description;

  /// Optional leading icon/widget
  final Widget? leadingWidget;

  /// Position of the tooltip relative to target
  final SubZeroCoachMarkPosition position;

  const SubZeroCoachMarkStep({
    required this.targetKey,
    required this.title,
    required this.description,
    this.leadingWidget,
    this.position = SubZeroCoachMarkPosition.bottom,
  });
}

/// A tooltip-style coachmark that highlights a specific UI element.
///
/// Example usage:
/// ```dart
/// final targetKey = GlobalKey();
///
/// // In your widget tree
/// Container(key: targetKey, child: YourTargetWidget())
///
/// // To show coachmark
/// SubZeroCoachMark.show(
///   context: context,
///   targetKey: targetKey,
///   title: 'New feature',
///   description: 'Something about this feature and what it does.',
///   position: SubZeroCoachMarkPosition.bottom,
/// );
/// ```
class SubZeroCoachMark {
  static OverlayEntry? _currentOverlay;
  static VoidCallback? _onDismiss;

  /// Show a single coachmark tooltip pointing to a target widget.
  static void show({
    required BuildContext context,
    required GlobalKey targetKey,
    required String title,
    required String description,
    Widget? leadingWidget,
    SubZeroCoachMarkPosition position = SubZeroCoachMarkPosition.bottom,
    VoidCallback? onDismiss,
  }) {
    dismiss();
    _onDismiss = onDismiss;

    final overlay = Overlay.of(context);
    _currentOverlay = OverlayEntry(
      builder: (context) => _CoachMarkOverlay(
        targetKey: targetKey,
        title: title,
        description: description,
        leadingWidget: leadingWidget,
        position: position,
        onDismiss: () {
          dismiss();
          _onDismiss?.call();
        },
      ),
    );

    overlay.insert(_currentOverlay!);
  }

  /// Dismiss the currently shown coachmark.
  static void dismiss() {
    _currentOverlay?.remove();
    _currentOverlay = null;
  }

  /// Show a series of coachmark steps sequentially.
  static Future<void> showTour({
    required BuildContext context,
    required List<SubZeroCoachMarkStep> steps,
    VoidCallback? onComplete,
  }) async {
    for (int i = 0; i < steps.length; i++) {
      final step = steps[i];
      final completer = Completer<void>();

      show(
        context: context,
        targetKey: step.targetKey,
        title: step.title,
        description: step.description,
        leadingWidget: step.leadingWidget,
        position: step.position,
        onDismiss: () => completer.complete(),
      );

      await completer.future;
      await Future.delayed(const Duration(milliseconds: 200));
    }

    onComplete?.call();
  }
}

class _CoachMarkOverlay extends StatefulWidget {
  final GlobalKey targetKey;
  final String title;
  final String description;
  final Widget? leadingWidget;
  final SubZeroCoachMarkPosition position;
  final VoidCallback onDismiss;

  const _CoachMarkOverlay({
    required this.targetKey,
    required this.title,
    required this.description,
    this.leadingWidget,
    required this.position,
    required this.onDismiss,
  });

  @override
  State<_CoachMarkOverlay> createState() => _CoachMarkOverlayState();
}

class _CoachMarkOverlayState extends State<_CoachMarkOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  Rect? _targetRect;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeOut);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _calculateTargetRect();
      _controller.forward();
    });
  }

  void _calculateTargetRect() {
    final renderBox =
        widget.targetKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox != null) {
      final position = renderBox.localToGlobal(Offset.zero);
      setState(() {
        _targetRect = Rect.fromLTWH(
          position.dx,
          position.dy,
          renderBox.size.width,
          renderBox.size.height,
        );
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onDismiss,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Stack(
          children: [
            // Semi-transparent scrim
            Container(color: Colors.black.withValues(alpha: 0.5)),

            // Spotlight cutout (if target found)
            if (_targetRect != null) _buildSpotlight(),

            // Tooltip
            if (_targetRect != null) _buildTooltip(),
          ],
        ),
      ),
    );
  }

  Widget _buildSpotlight() {
    return CustomPaint(
      size: MediaQuery.of(context).size,
      painter: _SpotlightPainter(
        targetRect: _targetRect!.inflate(8),
        scrimColor: Colors.black.withValues(alpha: 0.5),
      ),
    );
  }

  Widget _buildTooltip() {
    const tooltipMaxWidth = 300.0;
    const arrowSize = 12.0;
    const spacing = 16.0;

    double left = 0;
    double top = 0;

    switch (widget.position) {
      case SubZeroCoachMarkPosition.bottom:
        left = (_targetRect!.left + _targetRect!.right) / 2 - tooltipMaxWidth / 2;
        top = _targetRect!.bottom + arrowSize + spacing;
        break;
      case SubZeroCoachMarkPosition.top:
        left = (_targetRect!.left + _targetRect!.right) / 2 - tooltipMaxWidth / 2;
        top = _targetRect!.top - arrowSize - spacing - 100;
        break;
      case SubZeroCoachMarkPosition.left:
        left = _targetRect!.left - tooltipMaxWidth - arrowSize - spacing;
        top = (_targetRect!.top + _targetRect!.bottom) / 2 - 50;
        break;
      case SubZeroCoachMarkPosition.right:
        left = _targetRect!.right + arrowSize + spacing;
        top = (_targetRect!.top + _targetRect!.bottom) / 2 - 50;
        break;
    }

    // Clamp to screen bounds
    final screenSize = MediaQuery.of(context).size;
    left = left.clamp(16.0, screenSize.width - tooltipMaxWidth - 16);
    top = top.clamp(16.0, screenSize.height - 150);

    return Positioned(
      left: left,
      top: top,
      child: _CoachMarkTooltip(
        title: widget.title,
        description: widget.description,
        leadingWidget: widget.leadingWidget,
        maxWidth: tooltipMaxWidth,
      ),
    );
  }
}

class _SpotlightPainter extends CustomPainter {
  final Rect targetRect;
  final Color scrimColor;

  _SpotlightPainter({required this.targetRect, required this.scrimColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = scrimColor;

    // Draw scrim with spotlight cutout
    final path = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRRect(RRect.fromRectAndRadius(targetRect, const Radius.circular(8)))
      ..fillType = PathFillType.evenOdd;

    canvas.drawPath(path, paint);

    // Draw highlight border around target
    final borderPaint = Paint()
      ..color = SubZeroColors.primary.withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawRRect(
      RRect.fromRectAndRadius(targetRect, const Radius.circular(8)),
      borderPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _SpotlightPainter oldDelegate) =>
      targetRect != oldDelegate.targetRect;
}

class _CoachMarkTooltip extends StatelessWidget {
  final String title;
  final String description;
  final Widget? leadingWidget;
  final double maxWidth;

  const _CoachMarkTooltip({
    required this.title,
    required this.description,
    this.leadingWidget,
    required this.maxWidth,
  });

  @override
  Widget build(BuildContext context) {
    final defaultLeading = Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: SubZeroColors.border, width: 1.5),
      ),
      child: const Icon(
        Icons.play_circle_outline,
        color: SubZeroColors.textPrimary,
        size: 20,
      ),
    );

    return Material(
      color: Colors.transparent,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxWidth),
        padding: const EdgeInsets.all(SubZeroSpacing.md),
        decoration: BoxDecoration(
          color: SubZeroColors.surface,
          borderRadius: SubZeroRadius.medium,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.15),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            leadingWidget ?? defaultLeading,
            const SizedBox(width: SubZeroSpacing.md),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: SubZeroColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: SubZeroSpacing.xs),
                  Text(
                    description,
                    style: const TextStyle(
                      fontSize: 14,
                      color: SubZeroColors.textSecondary,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================================
// ONBOARDING CARD - Card-style feature introduction with media area
// ============================================================================

/// A card-style onboarding component with media area, title, description, and action buttons.
///
/// Example usage:
/// ```dart
/// SubZeroOnboardingCard(
///   title: 'New feature',
///   description: 'Something about this feature and what it does.',
///   mediaWidget: Icon(Icons.play_circle_outline, size: 48),
///   primaryButtonLabel: 'Show me more',
///   secondaryButtonLabel: 'Not interested',
///   onPrimaryPressed: () => print('Show more'),
///   onSecondaryPressed: () => print('Dismiss'),
/// )
/// ```
class SubZeroOnboardingCard extends StatelessWidget {
  /// The title text
  final String title;

  /// The description text
  final String description;

  /// Optional media widget (icon, image, video placeholder)
  final Widget? mediaWidget;

  /// Primary action button label
  final String? primaryButtonLabel;

  /// Secondary action button label
  final String? secondaryButtonLabel;

  /// Callback when primary button is pressed
  final VoidCallback? onPrimaryPressed;

  /// Callback when secondary button is pressed
  final VoidCallback? onSecondaryPressed;

  /// Whether to show trailing icon on primary button
  final bool showPrimaryTrailingIcon;

  /// Whether to show trailing icon on secondary button
  final bool showSecondaryTrailingIcon;

  /// Card width constraint
  final double? width;

  const SubZeroOnboardingCard({
    super.key,
    required this.title,
    required this.description,
    this.mediaWidget,
    this.primaryButtonLabel,
    this.secondaryButtonLabel,
    this.onPrimaryPressed,
    this.onSecondaryPressed,
    this.showPrimaryTrailingIcon = true,
    this.showSecondaryTrailingIcon = true,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width ?? 340,
      padding: const EdgeInsets.all(SubZeroSpacing.md),
      decoration: BoxDecoration(
        color: SubZeroColors.surface,
        borderRadius: SubZeroRadius.medium,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Media area
          if (mediaWidget != null) ...[
            Container(
              width: double.infinity,
              height: 120,
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: SubZeroRadius.small,
              ),
              child: Center(child: mediaWidget),
            ),
            const SizedBox(height: SubZeroSpacing.md),
          ],

          // Title
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: SubZeroColors.textPrimary,
            ),
          ),
          const SizedBox(height: SubZeroSpacing.xs),

          // Description
          Text(
            description,
            style: const TextStyle(
              fontSize: 14,
              color: SubZeroColors.textSecondary,
              height: 1.4,
            ),
          ),
          const SizedBox(height: SubZeroSpacing.lg),

          // Action buttons
          if (primaryButtonLabel != null || secondaryButtonLabel != null)
            Row(
              children: [
                if (secondaryButtonLabel != null)
                  _OnboardingSecondaryButton(
                    label: secondaryButtonLabel!,
                    onPressed: onSecondaryPressed,
                    showTrailingIcon: showSecondaryTrailingIcon,
                  ),
                if (secondaryButtonLabel != null && primaryButtonLabel != null)
                  const SizedBox(width: SubZeroSpacing.sm),
                if (primaryButtonLabel != null)
                  _OnboardingPrimaryButton(
                    label: primaryButtonLabel!,
                    onPressed: onPrimaryPressed,
                    showTrailingIcon: showPrimaryTrailingIcon,
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

// ============================================================================
// ONBOARDING DIALOG - Multi-step modal onboarding
// ============================================================================

/// Configuration for an onboarding step.
class SubZeroOnboardingStep {
  /// The title text
  final String title;

  /// The description text
  final String description;

  /// Optional content widget (image, video, illustration)
  final Widget? contentWidget;

  const SubZeroOnboardingStep({
    required this.title,
    required this.description,
    this.contentWidget,
  });
}

/// Shows a multi-step onboarding dialog.
///
/// Example usage:
/// ```dart
/// await showSubZeroOnboardingDialog(
///   context: context,
///   badgeLabel: 'Quick tip',
///   steps: [
///     SubZeroOnboardingStep(
///       title: 'New feature',
///       description: 'Something about this feature and what it does.',
///     ),
///     SubZeroOnboardingStep(
///       title: 'Another feature',
///       description: 'More information here.',
///     ),
///   ],
///   onComplete: () => print('Completed!'),
///   onSkip: () => print('Skipped!'),
/// );
/// ```
Future<bool> showSubZeroOnboardingDialog({
  required BuildContext context,
  required List<SubZeroOnboardingStep> steps,
  String? badgeLabel,
  VoidCallback? onComplete,
  VoidCallback? onSkip,
  bool barrierDismissible = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    barrierDismissible: barrierDismissible,
    barrierColor: Colors.black.withValues(alpha: 0.5),
    builder: (context) => _SubZeroOnboardingDialog(
      steps: steps,
      badgeLabel: badgeLabel,
      onComplete: onComplete,
      onSkip: onSkip,
    ),
  );

  return result ?? false;
}

class _SubZeroOnboardingDialog extends StatefulWidget {
  final List<SubZeroOnboardingStep> steps;
  final String? badgeLabel;
  final VoidCallback? onComplete;
  final VoidCallback? onSkip;

  const _SubZeroOnboardingDialog({
    required this.steps,
    this.badgeLabel,
    this.onComplete,
    this.onSkip,
  });

  @override
  State<_SubZeroOnboardingDialog> createState() =>
      _SubZeroOnboardingDialogState();
}

class _SubZeroOnboardingDialogState extends State<_SubZeroOnboardingDialog> {
  int _currentStep = 0;
  bool _isFocused = false;

  bool get _isFirstStep => _currentStep == 0;
  bool get _isLastStep => _currentStep == widget.steps.length - 1;

  void _nextStep() {
    if (_isLastStep) {
      Navigator.of(context).pop(true);
      widget.onComplete?.call();
    } else {
      setState(() => _currentStep++);
    }
  }

  void _previousStep() {
    if (!_isFirstStep) {
      setState(() => _currentStep--);
    }
  }

  void _skip() {
    Navigator.of(context).pop(false);
    widget.onSkip?.call();
  }

  void _close() {
    Navigator.of(context).pop(false);
  }

  @override
  Widget build(BuildContext context) {
    final currentStep = widget.steps[_currentStep];
    final screenWidth = MediaQuery.of(context).size.width;
    final dialogWidth = screenWidth > 500 ? 440.0 : screenWidth * 0.9;

    return Focus(
      autofocus: true,
      onFocusChange: (focused) => setState(() => _isFocused = focused),
      onKeyEvent: (node, event) {
        if (event is KeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.escape) {
            _close();
            return KeyEventResult.handled;
          }
          if (event.logicalKey == LogicalKeyboardKey.arrowRight ||
              event.logicalKey == LogicalKeyboardKey.enter) {
            _nextStep();
            return KeyEventResult.handled;
          }
          if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
            _previousStep();
            return KeyEventResult.handled;
          }
        }
        return KeyEventResult.ignored;
      },
      child: Center(
        child: Material(
          color: Colors.transparent,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: dialogWidth,
            decoration: BoxDecoration(
              color: SubZeroColors.surface,
              borderRadius: SubZeroRadius.large,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
              border: _isFocused
                  ? Border.all(
                      color: SubZeroColors.primary.withValues(alpha: 0.3),
                      width: 2,
                    )
                  : null,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with badge and close button
                _buildHeader(),

                // Content
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                    SubZeroSpacing.lg,
                    SubZeroSpacing.sm,
                    SubZeroSpacing.lg,
                    SubZeroSpacing.md,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Text(
                        currentStep.title,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: SubZeroColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: SubZeroSpacing.sm),

                      // Description
                      Text(
                        currentStep.description,
                        style: const TextStyle(
                          fontSize: 14,
                          color: SubZeroColors.textSecondary,
                          height: 1.5,
                        ),
                      ),

                      // Optional content widget
                      if (currentStep.contentWidget != null) ...[
                        const SizedBox(height: SubZeroSpacing.md),
                        currentStep.contentWidget!,
                      ],
                    ],
                  ),
                ),

                // Progress indicators
                if (widget.steps.length > 1) ...[
                  const SizedBox(height: SubZeroSpacing.sm),
                  _buildProgressIndicators(),
                ],

                // Footer with navigation buttons
                const SizedBox(height: SubZeroSpacing.md),
                _buildFooter(),
                const SizedBox(height: SubZeroSpacing.lg),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        SubZeroSpacing.lg,
        SubZeroSpacing.lg,
        SubZeroSpacing.md,
        SubZeroSpacing.sm,
      ),
      child: Row(
        children: [
          // Badge with step indicator
          if (widget.badgeLabel != null)
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: SubZeroSpacing.sm,
                vertical: SubZeroSpacing.xs,
              ),
              decoration: BoxDecoration(
                color: SubZeroColors.surfaceVariant,
                borderRadius: SubZeroRadius.rounded,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.lightbulb_outline,
                    size: 14,
                    color: SubZeroColors.textSecondary,
                  ),
                  const SizedBox(width: SubZeroSpacing.xs),
                  Text(
                    '${widget.badgeLabel} ${_currentStep + 1}/${widget.steps.length}',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: SubZeroColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          const Spacer(),
          // Close button
          _CloseButton(onPressed: _close),
        ],
      ),
    );
  }

  Widget _buildProgressIndicators() {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(widget.steps.length, (index) {
          final isActive = index == _currentStep;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: isActive ? 20 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: isActive
                  ? SubZeroColors.primary
                  : SubZeroColors.textTertiary.withValues(alpha: 0.4),
              borderRadius: BorderRadius.circular(4),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: SubZeroSpacing.lg),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Left button: Skip (first step) or Previous (other steps)
          if (_isFirstStep)
            _TextButton(
              label: 'SKIP',
              onPressed: _skip,
              showLeadingIcon: false,
              showTrailingIcon: false,
            )
          else
            _TextButton(
              label: 'PREVIOUS',
              onPressed: _previousStep,
              showLeadingIcon: true,
              showTrailingIcon: false,
            ),

          // Right button: Next or Done
          if (_isLastStep)
            _TextButton(
              label: 'DONE',
              onPressed: _nextStep,
              showLeadingIcon: false,
              showTrailingIcon: false,
              trailingWidget: const Icon(
                Icons.check,
                size: 18,
                color: SubZeroColors.primary,
              ),
            )
          else
            _TextButton(
              label: 'NEXT',
              onPressed: _nextStep,
              showLeadingIcon: false,
              showTrailingIcon: true,
            ),
        ],
      ),
    );
  }
}

// ============================================================================
// HELPER WIDGETS
// ============================================================================

class _CloseButton extends StatefulWidget {
  final VoidCallback onPressed;

  const _CloseButton({required this.onPressed});

  @override
  State<_CloseButton> createState() => _CloseButtonState();
}

class _CloseButtonState extends State<_CloseButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTap: widget.onPressed,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: _isHovered
                ? SubZeroColors.surfaceVariant
                : Colors.transparent,
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.close,
            size: 20,
            color: SubZeroColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _TextButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool showLeadingIcon;
  final bool showTrailingIcon;
  final Widget? trailingWidget;

  const _TextButton({
    required this.label,
    this.onPressed,
    this.showLeadingIcon = false,
    this.showTrailingIcon = false,
    this.trailingWidget,
  });

  @override
  State<_TextButton> createState() => _TextButtonState();
}

class _TextButtonState extends State<_TextButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTap: widget.onPressed,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.sm,
            vertical: SubZeroSpacing.xs,
          ),
          decoration: BoxDecoration(
            color: _isHovered
                ? SubZeroColors.primary.withValues(alpha: 0.08)
                : Colors.transparent,
            borderRadius: SubZeroRadius.small,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.showLeadingIcon) ...[
                const Icon(
                  Icons.chevron_left,
                  size: 18,
                  color: SubZeroColors.primary,
                ),
                const SizedBox(width: SubZeroSpacing.xs),
              ],
              Text(
                widget.label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: SubZeroColors.primary,
                  letterSpacing: 0.5,
                ),
              ),
              if (widget.showTrailingIcon) ...[
                const SizedBox(width: SubZeroSpacing.xs),
                const Icon(
                  Icons.chevron_right,
                  size: 18,
                  color: SubZeroColors.primary,
                ),
              ],
              if (widget.trailingWidget != null) ...[
                const SizedBox(width: SubZeroSpacing.xs),
                widget.trailingWidget!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _OnboardingPrimaryButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool showTrailingIcon;

  const _OnboardingPrimaryButton({
    required this.label,
    this.onPressed,
    this.showTrailingIcon = true,
  });

  @override
  State<_OnboardingPrimaryButton> createState() =>
      _OnboardingPrimaryButtonState();
}

class _OnboardingPrimaryButtonState extends State<_OnboardingPrimaryButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTap: widget.onPressed,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.md,
            vertical: SubZeroSpacing.sm + 2,
          ),
          decoration: BoxDecoration(
            color: _isHovered ? SubZeroColors.primaryDark : SubZeroColors.primary,
            borderRadius: SubZeroRadius.small,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              if (widget.showTrailingIcon) ...[
                const SizedBox(width: SubZeroSpacing.sm),
                const Icon(
                  Icons.arrow_forward,
                  size: 16,
                  color: Colors.white,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _OnboardingSecondaryButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool showTrailingIcon;

  const _OnboardingSecondaryButton({
    required this.label,
    this.onPressed,
    this.showTrailingIcon = true,
  });

  @override
  State<_OnboardingSecondaryButton> createState() =>
      _OnboardingSecondaryButtonState();
}

class _OnboardingSecondaryButtonState
    extends State<_OnboardingSecondaryButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTap: widget.onPressed,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.md,
            vertical: SubZeroSpacing.sm + 2,
          ),
          decoration: BoxDecoration(
            color: _isHovered
                ? SubZeroColors.surfaceVariant
                : SubZeroColors.surface,
            borderRadius: SubZeroRadius.small,
            border: Border.all(
              color: _isHovered ? SubZeroColors.primary : SubZeroColors.border,
              width: 1.5,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: _isHovered
                      ? SubZeroColors.primary
                      : SubZeroColors.textPrimary,
                ),
              ),
              if (widget.showTrailingIcon) ...[
                const SizedBox(width: SubZeroSpacing.sm),
                Icon(
                  Icons.add,
                  size: 16,
                  color: _isHovered
                      ? SubZeroColors.primary
                      : SubZeroColors.textPrimary,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// FEATURE TOUR CONTROLLER - For complex onboarding flows
// ============================================================================

/// A controller for managing complex feature tours with multiple steps.
///
/// Example usage:
/// ```dart
/// final controller = SubZeroFeatureTourController(
///   tourId: 'main_tour_v1',
///   steps: [
///     SubZeroCoachMarkStep(targetKey: key1, title: 'Step 1', description: '...'),
///     SubZeroCoachMarkStep(targetKey: key2, title: 'Step 2', description: '...'),
///   ],
/// );
///
/// // Start the tour if not completed
/// await controller.startIfNotCompleted(context);
/// ```
class SubZeroFeatureTourController {
  final String tourId;
  final List<SubZeroCoachMarkStep> steps;
  final VoidCallback? onComplete;
  final VoidCallback? onSkip;

  final _service = SubZeroOnboardingService();

  SubZeroFeatureTourController({
    required this.tourId,
    required this.steps,
    this.onComplete,
    this.onSkip,
  });

  /// Check if the tour has been completed.
  Future<bool> hasCompleted() async {
    return await _service.hasCompleted(tourId);
  }

  /// Start the tour regardless of completion status.
  Future<void> start(BuildContext context) async {
    await SubZeroCoachMark.showTour(
      context: context,
      steps: steps,
      onComplete: () async {
        await _service.markCompleted(tourId);
        onComplete?.call();
      },
    );
  }

  /// Start the tour only if it hasn't been completed.
  Future<bool> startIfNotCompleted(BuildContext context) async {
    return await _service.showIfNotCompleted(
      onboardingId: tourId,
      showOnboarding: () => start(context),
    );
  }

  /// Reset the tour so it can be shown again.
  Future<void> reset() async {
    await _service.reset(tourId);
  }
}
