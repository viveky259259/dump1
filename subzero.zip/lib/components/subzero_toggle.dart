import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/tokens.dart';

/// Size variants for the SubZeroBinaryToggle component
enum SubZeroToggleSize { small, medium, large }

/// State variants for visual representation
enum SubZeroToggleState { normal, hover, focus, disabled }

/// A binary toggle switch following SubZero 2.0 Design System.
///
/// Displays a classic iOS-style toggle with:
/// - **Selected**: Pink filled track with white circular thumb on the right
/// - **Unselected**: Gray outlined track with gray thumb on the left
/// - **Focus/Hover**: Pink glow ring effect
/// - **Disabled**: Muted colors with reduced opacity
///
/// Example usage:
/// ```dart
/// SubZeroBinaryToggle(
///   value: _isEnabled,
///   onChanged: (value) => setState(() => _isEnabled = value),
/// )
/// ```
class SubZeroBinaryToggle extends StatefulWidget {
  const SubZeroBinaryToggle({
    super.key,
    required this.value,
    required this.onChanged,
    this.size = SubZeroToggleSize.medium,
    this.enabled = true,
    this.semanticLabel,
    this.activeColor,
    this.inactiveTrackColor,
    this.inactiveThumbColor,
  });

  /// Current toggle value (true = on/selected, false = off/unselected)
  final bool value;

  /// Callback when the toggle value changes
  final ValueChanged<bool>? onChanged;

  /// Size variant of the toggle
  final SubZeroToggleSize size;

  /// Whether the toggle is enabled for interaction
  final bool enabled;

  /// Semantic label for screen readers
  final String? semanticLabel;

  /// Custom color for the active/selected track (defaults to primary pink)
  final Color? activeColor;

  /// Custom color for inactive track border (defaults to neutral gray)
  final Color? inactiveTrackColor;

  /// Custom color for inactive thumb (defaults to neutral gray)
  final Color? inactiveThumbColor;

  @override
  State<SubZeroBinaryToggle> createState() => _SubZeroBinaryToggleState();
}

class _SubZeroBinaryToggleState extends State<SubZeroBinaryToggle>
    with SingleTickerProviderStateMixin {
  bool _isHovering = false;
  bool _isFocused = false;
  late AnimationController _animationController;
  late Animation<double> _thumbAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
      value: widget.value ? 1.0 : 0.0,
    );
    _setupAnimations();
  }

  void _setupAnimations() {
    _thumbAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(SubZeroBinaryToggle oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.value != oldWidget.value) {
      if (widget.value) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    }
    if (widget.activeColor != oldWidget.activeColor) {
      _setupAnimations();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  /// Track width based on size
  double get _trackWidth {
    switch (widget.size) {
      case SubZeroToggleSize.small:
        return 36.0;
      case SubZeroToggleSize.medium:
        return 44.0;
      case SubZeroToggleSize.large:
        return 52.0;
    }
  }

  /// Track height based on size
  double get _trackHeight {
    switch (widget.size) {
      case SubZeroToggleSize.small:
        return 20.0;
      case SubZeroToggleSize.medium:
        return 24.0;
      case SubZeroToggleSize.large:
        return 28.0;
    }
  }

  /// Thumb diameter based on size
  double get _thumbSize {
    switch (widget.size) {
      case SubZeroToggleSize.small:
        return 14.0;
      case SubZeroToggleSize.medium:
        return 18.0;
      case SubZeroToggleSize.large:
        return 22.0;
    }
  }

  /// Track border width
  double get _borderWidth => 2.0;

  /// Active track color (filled pink)
  Color get _activeColor => widget.activeColor ?? colors.primary[500];

  /// Inactive track border color (gray outline)
  Color get _inactiveTrackColor =>
      widget.inactiveTrackColor ?? colors.neutral.n400;

  /// Inactive thumb color (gray)
  Color get _inactiveThumbColor =>
      widget.inactiveThumbColor ?? colors.neutral.n400;

  /// Handle toggle tap
  void _handleTap() {
    if (!widget.enabled || widget.onChanged == null) return;
    widget.onChanged!(!widget.value);
  }

  /// Handle keyboard events
  void _handleKeyEvent(KeyEvent event) {
    if (!widget.enabled || widget.onChanged == null) return;
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.enter ||
          event.logicalKey == LogicalKeyboardKey.space) {
        widget.onChanged!(!widget.value);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEnabled = widget.enabled && widget.onChanged != null;
    final showGlow = (_isHovering || _isFocused) && isEnabled;

    return Semantics(
      label: widget.semanticLabel ?? (widget.value ? 'On' : 'Off'),
      toggled: widget.value,
      enabled: isEnabled,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          _handleKeyEvent(event);
          return KeyEventResult.handled;
        },
        child: MouseRegion(
          cursor: isEnabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
          onEnter: (_) => setState(() => _isHovering = true),
          onExit: (_) => setState(() => _isHovering = false),
          child: GestureDetector(
            onTap: isEnabled ? _handleTap : null,
            child: Opacity(
              opacity: isEnabled ? 1.0 : 0.5,
              child: AnimatedBuilder(
                animation: _animationController,
                builder: (context, child) => _buildToggle(showGlow),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildToggle(bool showGlow) {
    final thumbPadding = (_trackHeight - _thumbSize) / 2;
    final thumbStartX = thumbPadding;
    final thumbEndX = _trackWidth - _thumbSize - thumbPadding;
    final thumbX = thumbStartX + (_thumbAnimation.value * (thumbEndX - thumbStartX));

    // Track appearance
    final isSelected = _thumbAnimation.value > 0.5;
    final trackColor = isSelected ? _activeColor : Colors.transparent;
    final borderColor = isSelected ? _activeColor : _inactiveTrackColor;
    final thumbColor = isSelected ? colors.neutral.n0 : _inactiveThumbColor;

    return Container(
      width: _trackWidth,
      height: _trackHeight,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius.full),
        // Glow effect for hover/focus
        boxShadow: showGlow
            ? [
                BoxShadow(
                  color: _activeColor.withValues(alpha: 0.35),
                  blurRadius: 8,
                  spreadRadius: 2,
                ),
              ]
            : null,
      ),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          color: trackColor,
          borderRadius: BorderRadius.circular(radius.full),
          border: Border.all(
            color: borderColor,
            width: _borderWidth,
          ),
        ),
        child: Stack(
          children: [
            // Animated thumb
            Positioned(
              left: thumbX,
              top: thumbPadding - _borderWidth,
              child: Container(
                width: _thumbSize,
                height: _thumbSize,
                decoration: BoxDecoration(
                  color: thumbColor,
                  shape: BoxShape.circle,
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.15),
                            blurRadius: 3,
                            offset: const Offset(0, 1),
                          ),
                        ]
                      : null,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// A labeled binary toggle with optional description.
///
/// Example usage:
/// ```dart
/// SubZeroLabeledBinaryToggle(
///   label: 'Dark Mode',
///   description: 'Enable dark theme for the app',
///   value: _isDarkMode,
///   onChanged: (value) => setState(() => _isDarkMode = value),
/// )
/// ```
class SubZeroLabeledBinaryToggle extends StatelessWidget {
  const SubZeroLabeledBinaryToggle({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.description,
    this.size = SubZeroToggleSize.medium,
    this.enabled = true,
    this.labelPosition = SubZeroToggleLabelPosition.start,
    this.activeColor,
  });

  /// Main label text
  final String label;

  /// Optional description text below the label
  final String? description;

  /// Current toggle value
  final bool value;

  /// Callback when value changes
  final ValueChanged<bool>? onChanged;

  /// Size variant
  final SubZeroToggleSize size;

  /// Whether the toggle is enabled
  final bool enabled;

  /// Position of the label relative to the toggle
  final SubZeroToggleLabelPosition labelPosition;

  /// Custom active track color
  final Color? activeColor;

  @override
  Widget build(BuildContext context) {
    final labelWidget = Expanded(
      child: GestureDetector(
        onTap: enabled && onChanged != null ? () => onChanged!(!value) : null,
        child: MouseRegion(
          cursor: enabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: enabled ? colors.text.primary : colors.text.disabled,
                ),
              ),
              if (description != null) ...[
                SizedBox(height: spacing.xs),
                Text(
                  description!,
                  style: TextStyle(
                    fontSize: 12,
                    color: enabled ? colors.text.secondary : colors.text.disabled,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );

    final toggleWidget = SubZeroBinaryToggle(
      value: value,
      onChanged: onChanged,
      size: size,
      enabled: enabled,
      semanticLabel: label,
      activeColor: activeColor,
    );

    final children = labelPosition == SubZeroToggleLabelPosition.start
        ? [labelWidget, SizedBox(width: spacing.md), toggleWidget]
        : [toggleWidget, SizedBox(width: spacing.md), labelWidget];

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: children,
    );
  }
}

/// Position of label relative to toggle
enum SubZeroToggleLabelPosition { start, end }

/// A group of toggles for managing multiple boolean settings.
///
/// Example usage:
/// ```dart
/// SubZeroToggleGroup(
///   items: [
///     SubZeroToggleItem(label: 'Notifications', value: _notifications),
///     SubZeroToggleItem(label: 'Dark Mode', value: _darkMode),
///     SubZeroToggleItem(label: 'Auto-save', value: _autoSave),
///   ],
///   onChanged: (index, value) {
///     setState(() {
///       if (index == 0) _notifications = value;
///       if (index == 1) _darkMode = value;
///       if (index == 2) _autoSave = value;
///     });
///   },
/// )
/// ```
class SubZeroToggleGroup extends StatelessWidget {
  const SubZeroToggleGroup({
    super.key,
    required this.items,
    required this.onChanged,
    this.size = SubZeroToggleSize.medium,
    this.spacing = 16.0,
    this.showDividers = true,
  });

  /// List of toggle items
  final List<SubZeroToggleItem> items;

  /// Callback when any toggle value changes
  final void Function(int index, bool value) onChanged;

  /// Size variant for all toggles
  final SubZeroToggleSize size;

  /// Spacing between items
  final double spacing;

  /// Whether to show dividers between items
  final bool showDividers;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < items.length; i++) ...[
          SubZeroLabeledBinaryToggle(
            label: items[i].label,
            description: items[i].description,
            value: items[i].value,
            onChanged: items[i].enabled
                ? (value) => onChanged(i, value)
                : null,
            size: size,
            enabled: items[i].enabled,
          ),
          if (i < items.length - 1) ...[
            if (showDividers)
              Padding(
                padding: EdgeInsets.symmetric(vertical: spacing / 2),
                child: Divider(
                  height: 1,
                  color: colors.neutral.n200,
                ),
              )
            else
              SizedBox(height: spacing),
          ],
        ],
      ],
    );
  }
}

/// Data model for toggle group items
class SubZeroToggleItem {
  const SubZeroToggleItem({
    required this.label,
    required this.value,
    this.description,
    this.enabled = true,
  });

  /// Label text for the toggle
  final String label;

  /// Current value of the toggle
  final bool value;

  /// Optional description text
  final String? description;

  /// Whether this toggle is enabled
  final bool enabled;
}

/// A showcase widget demonstrating all toggle variants and states.
///
/// Use this for design system documentation and testing.
class SubZeroToggleShowcase extends StatefulWidget {
  const SubZeroToggleShowcase({super.key});

  @override
  State<SubZeroToggleShowcase> createState() => _SubZeroToggleShowcaseState();
}

class _SubZeroToggleShowcaseState extends State<SubZeroToggleShowcase> {
  bool _toggle1 = true;
  bool _toggle2 = false;
  bool _toggle3 = true;
  bool _toggle4 = false;
  bool _notifications = true;
  bool _darkMode = false;
  bool _autoSave = true;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(spacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section: States
          _buildSectionHeader('Toggle States'),
          SizedBox(height: spacing.md),
          Row(
            children: [
              // Selected column
              Expanded(
                child: Column(
                  children: [
                    Text(
                      'Selected',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: colors.text.secondary,
                      ),
                    ),
                    SizedBox(height: spacing.lg),
                    // Normal selected
                    SubZeroBinaryToggle(
                      value: true,
                      onChanged: (_) {},
                      size: SubZeroToggleSize.medium,
                    ),
                    SizedBox(height: spacing.lg),
                    // Hover selected (simulated with glow)
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(radius.full),
                        boxShadow: [
                          BoxShadow(
                            color: colors.primary[500].withValues(alpha: 0.35),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: SubZeroBinaryToggle(
                        value: true,
                        onChanged: (_) {},
                        size: SubZeroToggleSize.medium,
                      ),
                    ),
                    SizedBox(height: spacing.lg),
                    // Focus selected (simulated with glow)
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(radius.full),
                        boxShadow: [
                          BoxShadow(
                            color: colors.primary[500].withValues(alpha: 0.35),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: SubZeroBinaryToggle(
                        value: true,
                        onChanged: (_) {},
                        size: SubZeroToggleSize.medium,
                      ),
                    ),
                    SizedBox(height: spacing.lg),
                    // Disabled selected
                    SubZeroBinaryToggle(
                      value: true,
                      onChanged: null,
                      size: SubZeroToggleSize.medium,
                      enabled: false,
                    ),
                  ],
                ),
              ),
              // Unselected column
              Expanded(
                child: Column(
                  children: [
                    Text(
                      'Unselected',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: colors.text.secondary,
                      ),
                    ),
                    SizedBox(height: spacing.lg),
                    // Normal unselected
                    SubZeroBinaryToggle(
                      value: false,
                      onChanged: (_) {},
                      size: SubZeroToggleSize.medium,
                    ),
                    SizedBox(height: spacing.lg),
                    // Hover unselected
                    SubZeroBinaryToggle(
                      value: false,
                      onChanged: (_) {},
                      size: SubZeroToggleSize.medium,
                    ),
                    SizedBox(height: spacing.lg),
                    // Focus unselected
                    SubZeroBinaryToggle(
                      value: false,
                      onChanged: (_) {},
                      size: SubZeroToggleSize.medium,
                    ),
                    SizedBox(height: spacing.lg),
                    // Disabled unselected
                    SubZeroBinaryToggle(
                      value: false,
                      onChanged: null,
                      size: SubZeroToggleSize.medium,
                      enabled: false,
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: spacing.x2l),

          // Section: Sizes
          _buildSectionHeader('Toggle Sizes'),
          SizedBox(height: spacing.md),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Text('Small', style: TextStyle(color: colors.text.secondary, fontSize: 12)),
                  SizedBox(height: spacing.sm),
                  SubZeroBinaryToggle(
                    value: _toggle1,
                    onChanged: (v) => setState(() => _toggle1 = v),
                    size: SubZeroToggleSize.small,
                  ),
                ],
              ),
              Column(
                children: [
                  Text('Medium', style: TextStyle(color: colors.text.secondary, fontSize: 12)),
                  SizedBox(height: spacing.sm),
                  SubZeroBinaryToggle(
                    value: _toggle2,
                    onChanged: (v) => setState(() => _toggle2 = v),
                    size: SubZeroToggleSize.medium,
                  ),
                ],
              ),
              Column(
                children: [
                  Text('Large', style: TextStyle(color: colors.text.secondary, fontSize: 12)),
                  SizedBox(height: spacing.sm),
                  SubZeroBinaryToggle(
                    value: _toggle3,
                    onChanged: (v) => setState(() => _toggle3 = v),
                    size: SubZeroToggleSize.large,
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: spacing.x2l),

          // Section: Labeled Toggles
          _buildSectionHeader('Labeled Toggles'),
          SizedBox(height: spacing.md),
          SubZeroLabeledBinaryToggle(
            label: 'Enable Notifications',
            description: 'Receive push notifications for updates',
            value: _toggle4,
            onChanged: (v) => setState(() => _toggle4 = v),
          ),

          SizedBox(height: spacing.x2l),

          // Section: Toggle Group
          _buildSectionHeader('Toggle Group'),
          SizedBox(height: spacing.md),
          Container(
            padding: EdgeInsets.all(spacing.md),
            decoration: BoxDecoration(
              color: colors.bg.defaultBg,
              borderRadius: BorderRadius.circular(radius.lg),
              border: Border.all(color: colors.neutral.n200),
            ),
            child: SubZeroToggleGroup(
              items: [
                SubZeroToggleItem(
                  label: 'Notifications',
                  description: 'Receive push notifications',
                  value: _notifications,
                ),
                SubZeroToggleItem(
                  label: 'Dark Mode',
                  description: 'Enable dark theme',
                  value: _darkMode,
                ),
                SubZeroToggleItem(
                  label: 'Auto-save',
                  description: 'Automatically save changes',
                  value: _autoSave,
                ),
                SubZeroToggleItem(
                  label: 'Premium Feature',
                  description: 'Requires subscription',
                  value: false,
                  enabled: false,
                ),
              ],
              onChanged: (index, value) {
                setState(() {
                  if (index == 0) _notifications = value;
                  if (index == 1) _darkMode = value;
                  if (index == 2) _autoSave = value;
                });
              },
            ),
          ),

          SizedBox(height: spacing.x2l),

          // Section: Custom Colors
          _buildSectionHeader('Custom Colors'),
          SizedBox(height: spacing.md),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Text('Success', style: TextStyle(color: colors.text.secondary, fontSize: 12)),
                  SizedBox(height: spacing.sm),
                  SubZeroBinaryToggle(
                    value: true,
                    onChanged: (_) {},
                    activeColor: colors.semantic.success[500],
                  ),
                ],
              ),
              Column(
                children: [
                  Text('Error', style: TextStyle(color: colors.text.secondary, fontSize: 12)),
                  SizedBox(height: spacing.sm),
                  SubZeroBinaryToggle(
                    value: true,
                    onChanged: (_) {},
                    activeColor: colors.semantic.error[500],
                  ),
                ],
              ),
              Column(
                children: [
                  Text('Info', style: TextStyle(color: colors.text.secondary, fontSize: 12)),
                  SizedBox(height: spacing.sm),
                  SubZeroBinaryToggle(
                    value: true,
                    onChanged: (_) {},
                    activeColor: colors.semantic.info[500],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: colors.text.primary,
      ),
    );
  }
}
