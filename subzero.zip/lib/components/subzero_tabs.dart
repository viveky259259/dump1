import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';

/// Tab variant styles matching SubZero 2.0 Design System
enum SubZeroTabVariant {
  /// Primary tabs with underline indicator (pink underline for selected)
  primary,

  /// Secondary tabs with pill/chip style (filled background for selected)
  secondary,
}

/// Tab size options
enum SubZeroTabSize {
  small,
  medium,
  large,
}

/// Configuration for a single tab
class SubZeroTabItem {
  /// The label text for the tab
  final String label;

  /// Optional leading icon
  final IconData? icon;

  /// Optional badge count
  final int? badgeCount;

  /// Whether the tab is disabled
  final bool isDisabled;

  const SubZeroTabItem({
    required this.label,
    this.icon,
    this.badgeCount,
    this.isDisabled = false,
  });
}

/// A comprehensive tab component following SubZero 2.0 Design System.
///
/// Supports two variants:
/// - **Primary**: Underline indicator style with pink accent
/// - **Secondary**: Pill/chip style with teal fill for selected state
///
/// Example usage:
/// ```dart
/// SubZeroTabs(
///   tabs: [
///     SubZeroTabItem(label: 'Overview'),
///     SubZeroTabItem(label: 'Details', icon: Icons.info),
///     SubZeroTabItem(label: 'Reviews', badgeCount: 5),
///   ],
///   onTabChanged: (index) => print('Selected: $index'),
/// )
/// ```
class SubZeroTabs extends StatefulWidget {
  /// List of tab items to display
  final List<SubZeroTabItem> tabs;

  /// Currently selected tab index
  final int selectedIndex;

  /// Callback when tab selection changes
  final ValueChanged<int>? onTabChanged;

  /// Tab variant style
  final SubZeroTabVariant variant;

  /// Tab size
  final SubZeroTabSize size;

  /// Whether tabs should expand to fill available width
  final bool isExpanded;

  /// Whether tabs should be scrollable when they overflow
  final bool isScrollable;

  /// Optional content widgets corresponding to each tab
  final List<Widget>? tabContents;

  /// Custom indicator color (defaults to variant-specific color)
  final Color? indicatorColor;

  /// Custom selected text color
  final Color? selectedTextColor;

  /// Custom unselected text color
  final Color? unselectedTextColor;

  const SubZeroTabs({
    super.key,
    required this.tabs,
    this.selectedIndex = 0,
    this.onTabChanged,
    this.variant = SubZeroTabVariant.primary,
    this.size = SubZeroTabSize.medium,
    this.isExpanded = false,
    this.isScrollable = false,
    this.tabContents,
    this.indicatorColor,
    this.selectedTextColor,
    this.unselectedTextColor,
  });

  @override
  State<SubZeroTabs> createState() => _SubZeroTabsState();
}

class _SubZeroTabsState extends State<SubZeroTabs>
    with SingleTickerProviderStateMixin {
  late int _selectedIndex;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.selectedIndex;
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
  }

  @override
  void didUpdateWidget(SubZeroTabs oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.selectedIndex != oldWidget.selectedIndex) {
      _selectedIndex = widget.selectedIndex;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _selectTab(int index) {
    if (widget.tabs[index].isDisabled) return;
    if (index == _selectedIndex) return;

    setState(() => _selectedIndex = index);
    widget.onTabChanged?.call(index);
  }

  @override
  Widget build(BuildContext context) {
    final tabBar = widget.isScrollable
        ? SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: _buildTabRow(),
          )
        : _buildTabRow();

    if (widget.tabContents != null && widget.tabContents!.isNotEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          tabBar,
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: widget.tabContents![_selectedIndex],
            ),
          ),
        ],
      );
    }

    return tabBar;
  }

  Widget _buildTabRow() {
    final children = List.generate(widget.tabs.length, (index) {
      final tab = widget.tabs[index];
      final isSelected = index == _selectedIndex;

      return widget.isExpanded
          ? Expanded(child: _buildTab(tab, index, isSelected))
          : _buildTab(tab, index, isSelected);
    });

    return widget.variant == SubZeroTabVariant.primary
        ? Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: SubZeroColors.border,
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisSize:
                  widget.isExpanded ? MainAxisSize.max : MainAxisSize.min,
              children: children,
            ),
          )
        : Row(
            mainAxisSize:
                widget.isExpanded ? MainAxisSize.max : MainAxisSize.min,
            children: [
              for (int i = 0; i < children.length; i++) ...[
                children[i],
                if (i < children.length - 1) SizedBox(width: SubZeroSpacing.sm),
              ],
            ],
          );
  }

  Widget _buildTab(SubZeroTabItem tab, int index, bool isSelected) {
    return widget.variant == SubZeroTabVariant.primary
        ? _PrimaryTab(
            tab: tab,
            isSelected: isSelected,
            size: widget.size,
            indicatorColor: widget.indicatorColor,
            selectedTextColor: widget.selectedTextColor,
            unselectedTextColor: widget.unselectedTextColor,
            onTap: () => _selectTab(index),
          )
        : _SecondaryTab(
            tab: tab,
            isSelected: isSelected,
            size: widget.size,
            indicatorColor: widget.indicatorColor,
            selectedTextColor: widget.selectedTextColor,
            unselectedTextColor: widget.unselectedTextColor,
            onTap: () => _selectTab(index),
          );
  }
}

/// Primary tab with underline indicator
class _PrimaryTab extends StatefulWidget {
  final SubZeroTabItem tab;
  final bool isSelected;
  final SubZeroTabSize size;
  final Color? indicatorColor;
  final Color? selectedTextColor;
  final Color? unselectedTextColor;
  final VoidCallback onTap;

  const _PrimaryTab({
    required this.tab,
    required this.isSelected,
    required this.size,
    this.indicatorColor,
    this.selectedTextColor,
    this.unselectedTextColor,
    required this.onTap,
  });

  @override
  State<_PrimaryTab> createState() => _PrimaryTabState();
}

class _PrimaryTabState extends State<_PrimaryTab> {
  bool _isHovered = false;
  bool _isFocused = false;

  double get _fontSize {
    switch (widget.size) {
      case SubZeroTabSize.small:
        return 12;
      case SubZeroTabSize.medium:
        return 14;
      case SubZeroTabSize.large:
        return 16;
    }
  }

  double get _verticalPadding {
    switch (widget.size) {
      case SubZeroTabSize.small:
        return 8;
      case SubZeroTabSize.medium:
        return 12;
      case SubZeroTabSize.large:
        return 16;
    }
  }

  double get _horizontalPadding {
    switch (widget.size) {
      case SubZeroTabSize.small:
        return 12;
      case SubZeroTabSize.medium:
        return 16;
      case SubZeroTabSize.large:
        return 24;
    }
  }

  Color get _indicatorColor =>
      widget.indicatorColor ?? SubZeroColors.primary;

  Color get _textColor {
    if (widget.tab.isDisabled) return SubZeroColors.textTertiary;
    if (widget.isSelected) {
      return widget.selectedTextColor ?? SubZeroColors.primary;
    }
    return widget.unselectedTextColor ?? SubZeroColors.textSecondary;
  }

  @override
  Widget build(BuildContext context) {
    final showIndicator = widget.isSelected || _isHovered;

    return Semantics(
      selected: widget.isSelected,
      button: true,
      label: widget.tab.label,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          if (event is KeyDownEvent &&
              (event.logicalKey == LogicalKeyboardKey.enter ||
                  event.logicalKey == LogicalKeyboardKey.space)) {
            widget.onTap();
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: MouseRegion(
          cursor: widget.tab.isDisabled
              ? SystemMouseCursors.forbidden
              : SystemMouseCursors.click,
          onEnter: (_) => setState(() => _isHovered = true),
          onExit: (_) => setState(() => _isHovered = false),
          child: GestureDetector(
            onTap: widget.tab.isDisabled ? null : widget.onTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: EdgeInsets.symmetric(
                horizontal: _horizontalPadding,
                vertical: _verticalPadding,
              ),
              decoration: BoxDecoration(
                color: _isFocused
                    ? SubZeroColors.primary.withValues(alpha: 0.05)
                    : Colors.transparent,
                border: Border(
                  bottom: BorderSide(
                    color: showIndicator ? _indicatorColor : Colors.transparent,
                    width: 2,
                  ),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.tab.icon != null) ...[
                    Icon(
                      widget.tab.icon,
                      size: _fontSize + 4,
                      color: _textColor,
                    ),
                    SizedBox(width: SubZeroSpacing.xs),
                  ],
                  Text(
                    widget.tab.label,
                    style: TextStyle(
                      fontSize: _fontSize,
                      fontWeight: widget.isSelected
                          ? FontWeight.w600
                          : FontWeight.w500,
                      color: _textColor,
                    ),
                  ),
                  if (widget.tab.badgeCount != null) ...[
                    SizedBox(width: SubZeroSpacing.xs),
                    _Badge(count: widget.tab.badgeCount!),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Secondary tab with pill/chip style
class _SecondaryTab extends StatefulWidget {
  final SubZeroTabItem tab;
  final bool isSelected;
  final SubZeroTabSize size;
  final Color? indicatorColor;
  final Color? selectedTextColor;
  final Color? unselectedTextColor;
  final VoidCallback onTap;

  const _SecondaryTab({
    required this.tab,
    required this.isSelected,
    required this.size,
    this.indicatorColor,
    this.selectedTextColor,
    this.unselectedTextColor,
    required this.onTap,
  });

  @override
  State<_SecondaryTab> createState() => _SecondaryTabState();
}

class _SecondaryTabState extends State<_SecondaryTab> {
  bool _isHovered = false;
  bool _isFocused = false;

  // Action Tertiary from Subzero spec for secondary selected state
  static const Color _tealColor = SubZeroColors.actionTertiary;

  double get _fontSize {
    switch (widget.size) {
      case SubZeroTabSize.small:
        return 12;
      case SubZeroTabSize.medium:
        return 14;
      case SubZeroTabSize.large:
        return 16;
    }
  }

  double get _verticalPadding {
    switch (widget.size) {
      case SubZeroTabSize.small:
        return 6;
      case SubZeroTabSize.medium:
        return 8;
      case SubZeroTabSize.large:
        return 12;
    }
  }

  double get _horizontalPadding {
    switch (widget.size) {
      case SubZeroTabSize.small:
        return 12;
      case SubZeroTabSize.medium:
        return 16;
      case SubZeroTabSize.large:
        return 24;
    }
  }

  Color get _fillColor => widget.indicatorColor ?? _tealColor;

  Color get _backgroundColor {
    if (widget.tab.isDisabled) {
      return SubZeroColors.surfaceVariant;
    }
    if (widget.isSelected) {
      return _fillColor;
    }
    if (_isHovered) {
      return SubZeroColors.surfaceVariant;
    }
    return Colors.transparent;
  }

  Color get _borderColor {
    if (widget.tab.isDisabled) {
      return SubZeroColors.border;
    }
    if (widget.isSelected) {
      return _fillColor;
    }
    if (_isHovered) {
      return _fillColor;
    }
    return SubZeroColors.border;
  }

  Color get _textColor {
    if (widget.tab.isDisabled) {
      return SubZeroColors.textTertiary;
    }
    if (widget.isSelected) {
      return widget.selectedTextColor ?? Colors.white;
    }
    return widget.unselectedTextColor ?? SubZeroColors.textPrimary;
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      selected: widget.isSelected,
      button: true,
      label: widget.tab.label,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          if (event is KeyDownEvent &&
              (event.logicalKey == LogicalKeyboardKey.enter ||
                  event.logicalKey == LogicalKeyboardKey.space)) {
            widget.onTap();
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: MouseRegion(
          cursor: widget.tab.isDisabled
              ? SystemMouseCursors.forbidden
              : SystemMouseCursors.click,
          onEnter: (_) => setState(() => _isHovered = true),
          onExit: (_) => setState(() => _isHovered = false),
          child: GestureDetector(
            onTap: widget.tab.isDisabled ? null : widget.onTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: EdgeInsets.symmetric(
                horizontal: _horizontalPadding,
                vertical: _verticalPadding,
              ),
              decoration: BoxDecoration(
                color: _backgroundColor,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: _borderColor,
                  width: _isFocused ? 2 : 1,
                ),
                boxShadow: _isFocused
                    ? [
                        BoxShadow(
                          color: _fillColor.withValues(alpha: 0.25),
                          blurRadius: 0,
                          spreadRadius: 2,
                        ),
                      ]
                    : null,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (widget.tab.icon != null) ...[
                    Icon(
                      widget.tab.icon,
                      size: _fontSize + 4,
                      color: _textColor,
                    ),
                    SizedBox(width: SubZeroSpacing.xs),
                  ],
                  Text(
                    widget.tab.label,
                    style: TextStyle(
                      fontSize: _fontSize,
                      fontWeight: FontWeight.w600,
                      color: _textColor,
                    ),
                  ),
                  if (widget.tab.badgeCount != null) ...[
                    SizedBox(width: SubZeroSpacing.xs),
                    _Badge(
                      count: widget.tab.badgeCount!,
                      isOnDark: widget.isSelected,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Small badge for notification counts
class _Badge extends StatelessWidget {
  final int count;
  final bool isOnDark;

  const _Badge({required this.count, this.isOnDark = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: isOnDark
            ? Colors.white.withValues(alpha: 0.2)
            : SubZeroColors.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        count > 99 ? '99+' : count.toString(),
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: isOnDark ? Colors.white : SubZeroColors.primary,
        ),
      ),
    );
  }
}

/// A simple tabs widget using Flutter's built-in TabBar with SubZero styling
class SubZeroTabBar extends StatelessWidget {
  /// Tab controller for managing tab state
  final TabController controller;

  /// List of tab labels
  final List<String> tabs;

  /// Tab variant style
  final SubZeroTabVariant variant;

  /// Whether tabs should be scrollable
  final bool isScrollable;

  /// Callback when tab is tapped
  final ValueChanged<int>? onTap;

  const SubZeroTabBar({
    super.key,
    required this.controller,
    required this.tabs,
    this.variant = SubZeroTabVariant.primary,
    this.isScrollable = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    if (variant == SubZeroTabVariant.secondary) {
      return _SecondaryTabBar(
        controller: controller,
        tabs: tabs,
        isScrollable: isScrollable,
        onTap: onTap,
      );
    }

    return TabBar(
      controller: controller,
      isScrollable: isScrollable,
      onTap: onTap,
      labelColor: SubZeroColors.primary,
      unselectedLabelColor: SubZeroColors.textSecondary,
      labelStyle: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
      unselectedLabelStyle: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
      indicatorColor: SubZeroColors.primary,
      indicatorWeight: 2,
      dividerColor: SubZeroColors.border,
      tabs: tabs.map((label) => Tab(text: label)).toList(),
    );
  }
}

/// Secondary variant tab bar using custom implementation
class _SecondaryTabBar extends StatelessWidget {
  final TabController controller;
  final List<String> tabs;
  final bool isScrollable;
  final ValueChanged<int>? onTap;

  const _SecondaryTabBar({
    required this.controller,
    required this.tabs,
    this.isScrollable = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final content = Row(
          mainAxisSize: isScrollable ? MainAxisSize.min : MainAxisSize.max,
          children: [
            for (int i = 0; i < tabs.length; i++) ...[
              if (isScrollable)
                _buildTab(i)
              else
                Expanded(child: _buildTab(i)),
              if (i < tabs.length - 1) SizedBox(width: SubZeroSpacing.sm),
            ],
          ],
        );

        return isScrollable
            ? SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: content,
              )
            : content;
      },
    );
  }

  Widget _buildTab(int index) {
    final isSelected = controller.index == index;
    const tealColor = SubZeroColors.actionTertiary;

    return GestureDetector(
      onTap: () {
        controller.animateTo(index);
        onTap?.call(index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? tealColor : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isSelected ? tealColor : SubZeroColors.border,
          ),
        ),
        child: Text(
          tabs[index],
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: isSelected ? Colors.white : SubZeroColors.textPrimary,
          ),
        ),
      ),
    );
  }
}

/// Convenience widget that combines SubZeroTabBar with TabBarView
class SubZeroTabBarView extends StatefulWidget {
  /// List of tab labels
  final List<String> tabs;

  /// List of content widgets for each tab
  final List<Widget> children;

  /// Tab variant style
  final SubZeroTabVariant variant;

  /// Whether tabs should be scrollable
  final bool isScrollable;

  /// Initial tab index
  final int initialIndex;

  /// Callback when tab changes
  final ValueChanged<int>? onTabChanged;

  const SubZeroTabBarView({
    super.key,
    required this.tabs,
    required this.children,
    this.variant = SubZeroTabVariant.primary,
    this.isScrollable = false,
    this.initialIndex = 0,
    this.onTabChanged,
  }) : assert(tabs.length == children.length);

  @override
  State<SubZeroTabBarView> createState() => _SubZeroTabBarViewState();
}

class _SubZeroTabBarViewState extends State<SubZeroTabBarView>
    with SingleTickerProviderStateMixin {
  late TabController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TabController(
      length: widget.tabs.length,
      vsync: this,
      initialIndex: widget.initialIndex,
    );
    _controller.addListener(_handleTabChange);
  }

  @override
  void dispose() {
    _controller.removeListener(_handleTabChange);
    _controller.dispose();
    super.dispose();
  }

  void _handleTabChange() {
    if (!_controller.indexIsChanging) {
      widget.onTabChanged?.call(_controller.index);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SubZeroTabBar(
          controller: _controller,
          tabs: widget.tabs,
          variant: widget.variant,
          isScrollable: widget.isScrollable,
        ),
        Expanded(
          child: TabBarView(
            controller: _controller,
            children: widget.children,
          ),
        ),
      ],
    );
  }
}
