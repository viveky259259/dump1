import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';

/// Search field size presets
enum SubZeroSearchSize {
  /// Small: height 40px
  small,

  /// Medium: height 48px (default)
  medium,

  /// Large: height 56px
  large,
}

/// A search suggestion item data model
class SubZeroSearchSuggestion {
  /// The suggestion text to display
  final String text;

  /// Optional leading icon (defaults to history clock icon)
  final IconData? icon;

  /// Optional subtitle for additional context
  final String? subtitle;

  const SubZeroSearchSuggestion({
    required this.text,
    this.icon,
    this.subtitle,
  });
}

/// A robust, accessible search input field following the SubZero 2.0 Design System.
///
/// Features:
/// - Leading search icon (magnifying glass)
/// - Clear 'X' icon that appears when text is entered
/// - Optional trailing microphone icon for voice search
/// - Rounded pill shape with light gray background
/// - Callbacks for query submission and text changes
///
/// Example usage:
/// ```dart
/// SubZeroSearchField(
///   hintText: 'Search here',
///   onSubmitted: (query) => performSearch(query),
///   onChanged: (text) => updateSuggestions(text),
/// )
/// ```
class SubZeroSearchField extends StatefulWidget {
  /// Placeholder text when the field is empty
  final String hintText;

  /// Callback when user submits the query (presses Enter)
  final ValueChanged<String>? onSubmitted;

  /// Callback when text changes
  final ValueChanged<String>? onChanged;

  /// Callback when the field gains focus
  final VoidCallback? onFocused;

  /// Callback when clear button is tapped
  final VoidCallback? onCleared;

  /// Callback when microphone button is tapped (voice search)
  final VoidCallback? onMicrophoneTap;

  /// Whether to show the microphone icon
  final bool showMicrophone;

  /// Initial text value
  final String? initialValue;

  /// External controller (if not provided, internal one is used)
  final TextEditingController? controller;

  /// External focus node (if not provided, internal one is used)
  final FocusNode? focusNode;

  /// Size preset for the search field
  final SubZeroSearchSize size;

  /// Whether the field is enabled
  final bool enabled;

  /// Whether to autofocus on mount
  final bool autofocus;

  /// Background color override
  final Color? backgroundColor;

  /// Border color when focused
  final Color? focusedBorderColor;

  const SubZeroSearchField({
    super.key,
    this.hintText = 'Search here',
    this.onSubmitted,
    this.onChanged,
    this.onFocused,
    this.onCleared,
    this.onMicrophoneTap,
    this.showMicrophone = true,
    this.initialValue,
    this.controller,
    this.focusNode,
    this.size = SubZeroSearchSize.medium,
    this.enabled = true,
    this.autofocus = false,
    this.backgroundColor,
    this.focusedBorderColor,
  });

  @override
  State<SubZeroSearchField> createState() => _SubZeroSearchFieldState();
}

class _SubZeroSearchFieldState extends State<SubZeroSearchField> {
  late TextEditingController _controller;
  late FocusNode _focusNode;
  bool _hasText = false;
  bool _isFocused = false;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _controller = widget.controller ?? TextEditingController(text: widget.initialValue);
    _focusNode = widget.focusNode ?? FocusNode();
    _hasText = _controller.text.isNotEmpty;

    _controller.addListener(_onTextChanged);
    _focusNode.addListener(_onFocusChanged);
  }

  @override
  void dispose() {
    if (widget.controller == null) {
      _controller.dispose();
    } else {
      _controller.removeListener(_onTextChanged);
    }
    if (widget.focusNode == null) {
      _focusNode.dispose();
    } else {
      _focusNode.removeListener(_onFocusChanged);
    }
    super.dispose();
  }

  void _onTextChanged() {
    final hasText = _controller.text.isNotEmpty;
    if (hasText != _hasText) {
      setState(() => _hasText = hasText);
    }
    widget.onChanged?.call(_controller.text);
  }

  void _onFocusChanged() {
    setState(() => _isFocused = _focusNode.hasFocus);
    if (_focusNode.hasFocus) {
      widget.onFocused?.call();
    }
  }

  void _clearText() {
    _controller.clear();
    widget.onCleared?.call();
    _focusNode.requestFocus();
  }

  void _handleSubmitted(String value) {
    widget.onSubmitted?.call(value.trim());
  }

  double get _height {
    switch (widget.size) {
      case SubZeroSearchSize.small:
        return 40;
      case SubZeroSearchSize.medium:
        return 48;
      case SubZeroSearchSize.large:
        return 56;
    }
  }

  double get _iconSize {
    switch (widget.size) {
      case SubZeroSearchSize.small:
        return 18;
      case SubZeroSearchSize.medium:
        return 20;
      case SubZeroSearchSize.large:
        return 24;
    }
  }

  double get _fontSize {
    switch (widget.size) {
      case SubZeroSearchSize.small:
        return 14;
      case SubZeroSearchSize.medium:
        return 16;
      case SubZeroSearchSize.large:
        return 18;
    }
  }

  @override
  Widget build(BuildContext context) {
    final backgroundColor = widget.backgroundColor ?? SubZeroColors.surfaceVariant;
    final focusedBorderColor = widget.focusedBorderColor ?? SubZeroColors.border;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: widget.enabled ? SystemMouseCursors.text : SystemMouseCursors.forbidden,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: _height,
        decoration: BoxDecoration(
          color: widget.enabled
              ? (_isFocused || _isHovered
                  ? SubZeroColors.surface
                  : backgroundColor)
              : backgroundColor.withValues(alpha: 0.5),
          borderRadius: SubZeroRadius.rounded,
          border: Border.all(
            color: _isFocused
                ? focusedBorderColor
                : (_isHovered ? SubZeroColors.border : Colors.transparent),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            // Leading search icon
            Padding(
              padding: EdgeInsets.only(
                left: SubZeroSpacing.md,
                right: SubZeroSpacing.sm,
              ),
              child: Icon(
                Icons.search,
                size: _iconSize,
                color: _isFocused
                    ? SubZeroColors.textSecondary
                    : SubZeroColors.textTertiary,
              ),
            ),

            // Text input field
            Expanded(
              child: TextField(
                controller: _controller,
                focusNode: _focusNode,
                enabled: widget.enabled,
                autofocus: widget.autofocus,
                textInputAction: TextInputAction.search,
                onSubmitted: _handleSubmitted,
                style: TextStyle(
                  fontSize: _fontSize,
                  color: SubZeroColors.textPrimary,
                  fontWeight: FontWeight.w400,
                ),
                decoration: InputDecoration(
                  hintText: widget.hintText,
                  hintStyle: TextStyle(
                    fontSize: _fontSize,
                    color: SubZeroColors.textTertiary,
                    fontWeight: FontWeight.w400,
                  ),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                ),
              ),
            ),

            // Clear button (visible when text is entered)
            if (_hasText)
              _SearchIconButton(
                icon: Icons.close,
                iconSize: _iconSize,
                onTap: _clearText,
                tooltip: 'Clear search',
              ),

            // Microphone button (optional)
            if (widget.showMicrophone)
              _SearchIconButton(
                icon: Icons.mic_none_outlined,
                iconSize: _iconSize,
                onTap: widget.onMicrophoneTap,
                tooltip: 'Voice search',
              ),

            SizedBox(width: SubZeroSpacing.sm),
          ],
        ),
      ),
    );
  }
}

/// Internal icon button for search field actions
class _SearchIconButton extends StatefulWidget {
  final IconData icon;
  final double iconSize;
  final VoidCallback? onTap;
  final String tooltip;

  const _SearchIconButton({
    required this.icon,
    required this.iconSize,
    this.onTap,
    required this.tooltip,
  });

  @override
  State<_SearchIconButton> createState() => _SearchIconButtonState();
}

class _SearchIconButtonState extends State<_SearchIconButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.tooltip,
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTap: widget.onTap,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.xs),
            child: Icon(
              widget.icon,
              size: widget.iconSize,
              color: _isHovered
                  ? SubZeroColors.textPrimary
                  : SubZeroColors.textSecondary,
            ),
          ),
        ),
      ),
    );
  }
}

/// A search suggestion list item following SubZero 2.0 Design System.
///
/// Displays a suggestion with optional leading icon (defaults to history clock).
class SubZeroSearchSuggestionItem extends StatefulWidget {
  /// The suggestion data
  final SubZeroSearchSuggestion suggestion;

  /// Callback when the suggestion is tapped
  final VoidCallback? onTap;

  /// Whether this item is currently highlighted (keyboard navigation)
  final bool isHighlighted;

  const SubZeroSearchSuggestionItem({
    super.key,
    required this.suggestion,
    this.onTap,
    this.isHighlighted = false,
  });

  @override
  State<SubZeroSearchSuggestionItem> createState() =>
      _SubZeroSearchSuggestionItemState();
}

class _SubZeroSearchSuggestionItemState
    extends State<SubZeroSearchSuggestionItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final isActive = _isHovered || widget.isHighlighted;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          padding: EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.md,
            vertical: SubZeroSpacing.sm + 4,
          ),
          color: isActive ? SubZeroColors.surfaceVariant : Colors.transparent,
          child: Row(
            children: [
              // Leading icon (history clock by default)
              Icon(
                widget.suggestion.icon ?? Icons.history,
                size: 20,
                color: SubZeroColors.textTertiary,
              ),
              SizedBox(width: SubZeroSpacing.sm + 4),

              // Suggestion text
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.suggestion.text,
                      style: TextStyle(
                        fontSize: 16,
                        color: SubZeroColors.textPrimary,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    if (widget.suggestion.subtitle != null) ...[
                      SizedBox(height: 2),
                      Text(
                        widget.suggestion.subtitle!,
                        style: TextStyle(
                          fontSize: 12,
                          color: SubZeroColors.textTertiary,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// A search field with integrated suggestions dropdown.
///
/// Combines [SubZeroSearchField] with a dropdown list of suggestions
/// that appears when the field is focused and has matching suggestions.
///
/// Example usage:
/// ```dart
/// SubZeroSearchWithSuggestions(
///   hintText: 'Search products...',
///   suggestions: recentSearches,
///   onSuggestionSelected: (suggestion) => performSearch(suggestion.text),
///   onSubmitted: (query) => performSearch(query),
/// )
/// ```
class SubZeroSearchWithSuggestions extends StatefulWidget {
  /// Placeholder text for the search field
  final String hintText;

  /// List of suggestions to display
  final List<SubZeroSearchSuggestion> suggestions;

  /// Callback when a suggestion is selected
  final ValueChanged<SubZeroSearchSuggestion>? onSuggestionSelected;

  /// Callback when the query is submitted
  final ValueChanged<String>? onSubmitted;

  /// Callback when text changes (for filtering suggestions)
  final ValueChanged<String>? onChanged;

  /// Callback when microphone is tapped
  final VoidCallback? onMicrophoneTap;

  /// Whether to show the microphone icon
  final bool showMicrophone;

  /// Size preset for the search field
  final SubZeroSearchSize size;

  /// Maximum number of suggestions to display
  final int maxSuggestions;

  const SubZeroSearchWithSuggestions({
    super.key,
    this.hintText = 'Search here',
    this.suggestions = const [],
    this.onSuggestionSelected,
    this.onSubmitted,
    this.onChanged,
    this.onMicrophoneTap,
    this.showMicrophone = true,
    this.size = SubZeroSearchSize.medium,
    this.maxSuggestions = 5,
  });

  @override
  State<SubZeroSearchWithSuggestions> createState() =>
      _SubZeroSearchWithSuggestionsState();
}

class _SubZeroSearchWithSuggestionsState
    extends State<SubZeroSearchWithSuggestions> {
  final LayerLink _layerLink = LayerLink();
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  OverlayEntry? _overlayEntry;
  int _highlightedIndex = -1;
  bool _showSuggestions = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(_onFocusChanged);
  }

  @override
  void dispose() {
    _removeOverlay();
    _focusNode.removeListener(_onFocusChanged);
    _focusNode.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _onFocusChanged() {
    if (_focusNode.hasFocus) {
      _showOverlay();
    } else {
      _removeOverlay();
    }
  }

  void _showOverlay() {
    if (_overlayEntry != null) return;
    if (widget.suggestions.isEmpty) return;

    setState(() => _showSuggestions = true);
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeOverlay() {
    setState(() {
      _showSuggestions = false;
      _highlightedIndex = -1;
    });
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  void _updateOverlay() {
    _overlayEntry?.markNeedsBuild();
  }

  OverlayEntry _createOverlayEntry() {
    final renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Positioned(
        width: size.width,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, size.height + 4),
          child: Material(
            elevation: 4,
            borderRadius: SubZeroRadius.medium,
            color: SubZeroColors.surface,
            child: _buildSuggestionsList(),
          ),
        ),
      ),
    );
  }

  Widget _buildSuggestionsList() {
    final displayedSuggestions = widget.suggestions.take(widget.maxSuggestions).toList();

    return ClipRRect(
      borderRadius: SubZeroRadius.medium,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(displayedSuggestions.length, (index) {
          final suggestion = displayedSuggestions[index];
          return SubZeroSearchSuggestionItem(
            suggestion: suggestion,
            isHighlighted: index == _highlightedIndex,
            onTap: () => _selectSuggestion(suggestion),
          );
        }),
      ),
    );
  }

  void _selectSuggestion(SubZeroSearchSuggestion suggestion) {
    _controller.text = suggestion.text;
    _controller.selection = TextSelection.fromPosition(
      TextPosition(offset: suggestion.text.length),
    );
    widget.onSuggestionSelected?.call(suggestion);
    _removeOverlay();
  }

  void _handleKeyEvent(KeyEvent event) {
    if (event is! KeyDownEvent) return;
    if (!_showSuggestions || widget.suggestions.isEmpty) return;

    final maxIndex = widget.suggestions.length.clamp(0, widget.maxSuggestions) - 1;

    if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
      setState(() {
        _highlightedIndex = (_highlightedIndex + 1).clamp(-1, maxIndex);
      });
      _updateOverlay();
    } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
      setState(() {
        _highlightedIndex = (_highlightedIndex - 1).clamp(-1, maxIndex);
      });
      _updateOverlay();
    } else if (event.logicalKey == LogicalKeyboardKey.enter && _highlightedIndex >= 0) {
      _selectSuggestion(widget.suggestions[_highlightedIndex]);
    } else if (event.logicalKey == LogicalKeyboardKey.escape) {
      _removeOverlay();
    }
  }

  @override
  Widget build(BuildContext context) {
    return KeyboardListener(
      focusNode: FocusNode(),
      onKeyEvent: _handleKeyEvent,
      child: CompositedTransformTarget(
        link: _layerLink,
        child: SubZeroSearchField(
          controller: _controller,
          focusNode: _focusNode,
          hintText: widget.hintText,
          showMicrophone: widget.showMicrophone,
          size: widget.size,
          onMicrophoneTap: widget.onMicrophoneTap,
          onChanged: (text) {
            widget.onChanged?.call(text);
            if (text.isNotEmpty && widget.suggestions.isNotEmpty) {
              _showOverlay();
            }
            _updateOverlay();
          },
          onSubmitted: (query) {
            _removeOverlay();
            widget.onSubmitted?.call(query);
          },
          onCleared: _removeOverlay,
        ),
      ),
    );
  }
}

/// Shows a full-screen search modal following SubZero 2.0 Design System.
///
/// Provides a focused search experience with recent searches and results.
///
/// Example usage:
/// ```dart
/// final result = await showSubZeroFullScreenSearch(
///   context: context,
///   recentSearches: ['iPhone', 'MacBook', 'AirPods'],
///   onSearch: (query) async => await searchProducts(query),
/// );
/// if (result != null) {
///   navigateToProduct(result);
/// }
/// ```
Future<String?> showSubZeroFullScreenSearch({
  required BuildContext context,
  String hintText = 'Search here',
  List<String> recentSearches = const [],
  Future<List<SubZeroSearchSuggestion>> Function(String query)? onSearch,
  bool showMicrophone = true,
  VoidCallback? onMicrophoneTap,
}) {
  return Navigator.of(context).push<String>(
    PageRouteBuilder(
      opaque: false,
      pageBuilder: (context, animation, secondaryAnimation) =>
          _FullScreenSearchModal(
        hintText: hintText,
        recentSearches: recentSearches,
        onSearch: onSearch,
        showMicrophone: showMicrophone,
        onMicrophoneTap: onMicrophoneTap,
      ),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, -0.02),
              end: Offset.zero,
            ).animate(CurvedAnimation(
              parent: animation,
              curve: Curves.easeOut,
            )),
            child: child,
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 200),
      reverseTransitionDuration: const Duration(milliseconds: 150),
    ),
  );
}

class _FullScreenSearchModal extends StatefulWidget {
  final String hintText;
  final List<String> recentSearches;
  final Future<List<SubZeroSearchSuggestion>> Function(String query)? onSearch;
  final bool showMicrophone;
  final VoidCallback? onMicrophoneTap;

  const _FullScreenSearchModal({
    required this.hintText,
    required this.recentSearches,
    this.onSearch,
    required this.showMicrophone,
    this.onMicrophoneTap,
  });

  @override
  State<_FullScreenSearchModal> createState() => _FullScreenSearchModalState();
}

class _FullScreenSearchModalState extends State<_FullScreenSearchModal> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  List<SubZeroSearchSuggestion> _results = [];
  bool _isLoading = false;
  String _currentQuery = '';

  @override
  void initState() {
    super.initState();
    // Autofocus after modal opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _performSearch(String query) async {
    if (query.isEmpty) {
      setState(() {
        _results = [];
        _currentQuery = '';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _currentQuery = query;
    });

    if (widget.onSearch != null) {
      final results = await widget.onSearch!(query);
      if (mounted && _currentQuery == query) {
        setState(() {
          _results = results;
          _isLoading = false;
        });
      }
    } else {
      setState(() => _isLoading = false);
    }
  }

  void _selectResult(String text) {
    Navigator.of(context).pop(text);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Material(
        color: SubZeroColors.surface,
        child: GestureDetector(
          onTap: () {}, // Prevent tap from bubbling
          child: SafeArea(
            child: Column(
              children: [
                // Header with search field and back button
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: SubZeroSpacing.md,
                    vertical: SubZeroSpacing.sm,
                  ),
                  decoration: BoxDecoration(
                    color: SubZeroColors.surface,
                    border: Border(
                      bottom: BorderSide(
                        color: SubZeroColors.divider,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      // Back button
                      IconButton(
                        icon: Icon(Icons.arrow_back),
                        color: SubZeroColors.textSecondary,
                        onPressed: () => Navigator.of(context).pop(),
                        tooltip: 'Close search',
                      ),
                      SizedBox(width: SubZeroSpacing.sm),

                      // Search field
                      Expanded(
                        child: SubZeroSearchField(
                          controller: _controller,
                          focusNode: _focusNode,
                          hintText: widget.hintText,
                          showMicrophone: widget.showMicrophone,
                          onMicrophoneTap: widget.onMicrophoneTap,
                          autofocus: true,
                          onChanged: _performSearch,
                          onSubmitted: (query) {
                            if (query.isNotEmpty) {
                              _selectResult(query);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),

                // Content area
                Expanded(
                  child: _isLoading
                      ? Center(
                          child: CircularProgressIndicator(
                            color: SubZeroColors.primary,
                          ),
                        )
                      : _currentQuery.isEmpty
                          ? _buildRecentSearches()
                          : _buildSearchResults(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRecentSearches() {
    if (widget.recentSearches.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.search,
              size: 64,
              color: SubZeroColors.textTertiary,
            ),
            SizedBox(height: SubZeroSpacing.md),
            Text(
              'Start typing to search',
              style: TextStyle(
                fontSize: 16,
                color: SubZeroColors.textSecondary,
              ),
            ),
          ],
        ),
      );
    }

    return ListView(
      padding: EdgeInsets.symmetric(vertical: SubZeroSpacing.sm),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.md,
            vertical: SubZeroSpacing.sm,
          ),
          child: Text(
            'Recent Searches',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: SubZeroColors.textTertiary,
              letterSpacing: 0.5,
            ),
          ),
        ),
        ...widget.recentSearches.map((search) => SubZeroSearchSuggestionItem(
              suggestion: SubZeroSearchSuggestion(text: search),
              onTap: () => _selectResult(search),
            )),
      ],
    );
  }

  Widget _buildSearchResults() {
    if (_results.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.search_off,
              size: 64,
              color: SubZeroColors.textTertiary,
            ),
            SizedBox(height: SubZeroSpacing.md),
            Text(
              'No results found for "$_currentQuery"',
              style: TextStyle(
                fontSize: 16,
                color: SubZeroColors.textSecondary,
              ),
            ),
          ],
        ),
      );
    }

    return ListView(
      padding: EdgeInsets.symmetric(vertical: SubZeroSpacing.sm),
      children: _results
          .map((result) => SubZeroSearchSuggestionItem(
                suggestion: result,
                onTap: () => _selectResult(result.text),
              ))
          .toList(),
    );
  }
}

/// An inline search field designed for use within headers/app bars.
///
/// More compact with transparent background, suitable for embedding
/// in navigation areas.
///
/// Example usage:
/// ```dart
/// SubZeroInlineSearch(
///   onTap: () => showSubZeroFullScreenSearch(context: context),
/// )
/// ```
class SubZeroInlineSearch extends StatefulWidget {
  /// Placeholder text
  final String hintText;

  /// Callback when the field is tapped (typically opens full search)
  final VoidCallback? onTap;

  /// Whether the search is expanded (shows full input) or collapsed (icon only)
  final bool expanded;

  /// Width when expanded
  final double expandedWidth;

  const SubZeroInlineSearch({
    super.key,
    this.hintText = 'Search',
    this.onTap,
    this.expanded = true,
    this.expandedWidth = 240,
  });

  @override
  State<SubZeroInlineSearch> createState() => _SubZeroInlineSearchState();
}

class _SubZeroInlineSearchState extends State<SubZeroInlineSearch> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    if (!widget.expanded) {
      // Collapsed: icon-only button
      return IconButton(
        icon: Icon(Icons.search),
        color: SubZeroColors.textSecondary,
        onPressed: widget.onTap,
        tooltip: 'Search',
      );
    }

    // Expanded: full search bar appearance
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: widget.expandedWidth,
          height: 40,
          decoration: BoxDecoration(
            color: _isHovered
                ? SubZeroColors.surface
                : SubZeroColors.surfaceVariant,
            borderRadius: SubZeroRadius.rounded,
            border: Border.all(
              color: _isHovered ? SubZeroColors.border : Colors.transparent,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Padding(
                padding: EdgeInsets.only(
                  left: SubZeroSpacing.md,
                  right: SubZeroSpacing.sm,
                ),
                child: Icon(
                  Icons.search,
                  size: 18,
                  color: SubZeroColors.textTertiary,
                ),
              ),
              Expanded(
                child: Text(
                  widget.hintText,
                  style: TextStyle(
                    fontSize: 14,
                    color: SubZeroColors.textTertiary,
                  ),
                ),
              ),
              SizedBox(width: SubZeroSpacing.md),
            ],
          ),
        ),
      ),
    );
  }
}
