import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';

/// Checkbox state for tristate support
enum SubZeroCheckboxState {
  unchecked,
  checked,
  indeterminate,
}

/// Size options for checkbox
enum SubZeroCheckboxSize {
  small,  // 16px
  medium, // 20px
  large,  // 24px
}

/// A customizable checkbox widget following SubZero 2.0 Design System.
///
/// Supports unchecked, checked, and indeterminate (tristate) states.
/// The label is tappable and toggles the checkbox state.
class SubZeroCheckbox extends StatefulWidget {
  const SubZeroCheckbox({
    super.key,
    required this.value,
    required this.onChanged,
    this.label,
    this.tristate = false,
    this.enabled = true,
    this.size = SubZeroCheckboxSize.medium,
    this.semanticLabel,
    this.labelStyle,
    this.activeColor,
    this.checkColor,
    this.borderColor,
  });

  /// Current checkbox state: true (checked), false (unchecked), or null (indeterminate)
  final bool? value;

  /// Callback when checkbox state changes
  final ValueChanged<bool?>? onChanged;

  /// Optional text label displayed next to the checkbox
  final String? label;

  /// Whether to support indeterminate (null) state
  final bool tristate;

  /// Whether the checkbox is enabled
  final bool enabled;

  /// Size of the checkbox
  final SubZeroCheckboxSize size;

  /// Semantic label for accessibility
  final String? semanticLabel;

  /// Custom label text style
  final TextStyle? labelStyle;

  /// Custom active (checked/indeterminate) background color
  final Color? activeColor;

  /// Custom checkmark/minus icon color
  final Color? checkColor;

  /// Custom border color for unchecked state
  final Color? borderColor;

  @override
  State<SubZeroCheckbox> createState() => _SubZeroCheckboxState();
}

class _SubZeroCheckboxState extends State<SubZeroCheckbox>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  bool _isFocused = false;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.9).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  double get _boxSize {
    switch (widget.size) {
      case SubZeroCheckboxSize.small:
        return 16.0;
      case SubZeroCheckboxSize.medium:
        return 20.0;
      case SubZeroCheckboxSize.large:
        return 24.0;
    }
  }

  double get _iconSize {
    switch (widget.size) {
      case SubZeroCheckboxSize.small:
        return 12.0;
      case SubZeroCheckboxSize.medium:
        return 14.0;
      case SubZeroCheckboxSize.large:
        return 18.0;
    }
  }

  double get _borderWidth {
    switch (widget.size) {
      case SubZeroCheckboxSize.small:
        return 1.5;
      case SubZeroCheckboxSize.medium:
        return 2.0;
      case SubZeroCheckboxSize.large:
        return 2.0;
    }
  }

  SubZeroCheckboxState get _currentState {
    if (widget.value == null) return SubZeroCheckboxState.indeterminate;
    return widget.value! ? SubZeroCheckboxState.checked : SubZeroCheckboxState.unchecked;
  }

  void _handleTap() {
    if (!widget.enabled || widget.onChanged == null) return;

    // Animate tap
    _animationController.forward().then((_) {
      _animationController.reverse();
    });

    // Cycle through states
    bool? newValue;
    if (widget.tristate) {
      // Tristate: unchecked -> checked -> indeterminate -> unchecked
      switch (_currentState) {
        case SubZeroCheckboxState.unchecked:
          newValue = true;
          break;
        case SubZeroCheckboxState.checked:
          newValue = null;
          break;
        case SubZeroCheckboxState.indeterminate:
          newValue = false;
          break;
      }
    } else {
      // Binary: toggle between checked and unchecked
      newValue = !(widget.value ?? false);
    }

    widget.onChanged!(newValue);
  }

  void _handleKeyEvent(KeyEvent event) {
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.enter ||
          event.logicalKey == LogicalKeyboardKey.space) {
        _handleTap();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = widget.activeColor ?? SubZeroColors.accent;
    final checkColor = widget.checkColor ?? SubZeroColors.surface;
    final borderColor = widget.borderColor ?? SubZeroColors.textPrimary;
    final disabledColor = SubZeroColors.textTertiary;

    final isActive = _currentState != SubZeroCheckboxState.unchecked;
    final effectiveActiveColor = widget.enabled ? activeColor : disabledColor;
    final effectiveBorderColor = widget.enabled ? borderColor : disabledColor;

    final String semanticLabel = widget.semanticLabel ??
        widget.label ??
        (_currentState == SubZeroCheckboxState.checked
            ? 'Checked'
            : _currentState == SubZeroCheckboxState.indeterminate
                ? 'Partially checked'
                : 'Unchecked');

    return Semantics(
      checked: widget.value,
      enabled: widget.enabled,
      label: semanticLabel,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          _handleKeyEvent(event);
          return KeyEventResult.handled;
        },
        child: MouseRegion(
          cursor: widget.enabled
              ? SystemMouseCursors.click
              : SystemMouseCursors.forbidden,
          onEnter: (_) => setState(() => _isHovered = true),
          onExit: (_) => setState(() => _isHovered = false),
          child: GestureDetector(
            onTap: _handleTap,
            behavior: HitTestBehavior.opaque,
            child: AnimatedBuilder(
              animation: _scaleAnimation,
              builder: (context, child) => Transform.scale(
                scale: _scaleAnimation.value,
                child: child,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildCheckbox(
                    isActive: isActive,
                    activeColor: effectiveActiveColor,
                    checkColor: checkColor,
                    borderColor: effectiveBorderColor,
                  ),
                  if (widget.label != null) ...[
                    SizedBox(width: SubZeroSpacing.sm),
                    Flexible(
                      child: Text(
                        widget.label!,
                        style: widget.labelStyle ??
                            TextStyle(
                              fontSize: _getLabelFontSize(),
                              fontWeight: isActive
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                              color: widget.enabled
                                  ? SubZeroColors.textPrimary
                                  : SubZeroColors.textTertiary,
                            ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  double _getLabelFontSize() {
    switch (widget.size) {
      case SubZeroCheckboxSize.small:
        return 12.0;
      case SubZeroCheckboxSize.medium:
        return 14.0;
      case SubZeroCheckboxSize.large:
        return 16.0;
    }
  }

  Widget _buildCheckbox({
    required bool isActive,
    required Color activeColor,
    required Color checkColor,
    required Color borderColor,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
      width: _boxSize,
      height: _boxSize,
      decoration: BoxDecoration(
        color: isActive ? activeColor : SubZeroColors.surface,
        borderRadius: BorderRadius.circular(SubZeroRadius.xs),
        border: isActive
            ? null
            : Border.all(
                color: _isHovered || _isFocused
                    ? SubZeroColors.accent
                    : borderColor,
                width: _borderWidth,
              ),
        boxShadow: _isFocused
            ? [
                BoxShadow(
                  color: SubZeroColors.accent.withValues(alpha: 0.3),
                  blurRadius: 4,
                  spreadRadius: 1,
                ),
              ]
            : null,
      ),
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 150),
        child: isActive
            ? Icon(
                _currentState == SubZeroCheckboxState.indeterminate
                    ? Icons.remove
                    : Icons.check,
                size: _iconSize,
                color: checkColor,
                key: ValueKey(_currentState),
              )
            : const SizedBox.shrink(),
      ),
    );
  }
}

/// Data model for a multiselect option
class SubZeroMultiselectOption<T> {
  const SubZeroMultiselectOption({
    required this.value,
    required this.label,
    this.enabled = true,
    this.semanticLabel,
  });

  /// The value associated with this option
  final T value;

  /// Display label for the option
  final String label;

  /// Whether this option is enabled
  final bool enabled;

  /// Semantic label for accessibility
  final String? semanticLabel;
}

/// Configuration for SubZeroMultiselectList
class SubZeroMultiselectConfig {
  const SubZeroMultiselectConfig({
    this.showSelectAll = true,
    this.selectAllLabel = 'All',
    this.size = SubZeroCheckboxSize.medium,
    this.spacing = SubZeroSpacing.md,
    this.activeColor,
    this.scrollable = false,
    this.maxHeight,
  });

  /// Whether to show "Select All" checkbox at the top
  final bool showSelectAll;

  /// Label for the "Select All" checkbox
  final String selectAllLabel;

  /// Size of checkboxes
  final SubZeroCheckboxSize size;

  /// Vertical spacing between items
  final double spacing;

  /// Custom active color for checkboxes
  final Color? activeColor;

  /// Whether the list is scrollable
  final bool scrollable;

  /// Maximum height when scrollable
  final double? maxHeight;
}

/// A stateful multiselect list component that manages multiple checkbox selections.
///
/// Supports "Select All" functionality with indeterminate state when partially selected.
class SubZeroMultiselectList<T> extends StatefulWidget {
  const SubZeroMultiselectList({
    super.key,
    required this.options,
    required this.selectedValues,
    required this.onChanged,
    this.config = const SubZeroMultiselectConfig(),
    this.enabled = true,
    this.semanticLabel,
  });

  /// List of available options
  final List<SubZeroMultiselectOption<T>> options;

  /// Currently selected values
  final List<T> selectedValues;

  /// Callback when selection changes
  final ValueChanged<List<T>> onChanged;

  /// Configuration for the multiselect list
  final SubZeroMultiselectConfig config;

  /// Whether the entire list is enabled
  final bool enabled;

  /// Semantic label for the group
  final String? semanticLabel;

  @override
  State<SubZeroMultiselectList<T>> createState() =>
      _SubZeroMultiselectListState<T>();
}

class _SubZeroMultiselectListState<T> extends State<SubZeroMultiselectList<T>> {
  List<T> get _selectedValues => widget.selectedValues;

  List<SubZeroMultiselectOption<T>> get _enabledOptions =>
      widget.options.where((o) => o.enabled).toList();

  bool? get _selectAllState {
    final enabledSelected =
        _enabledOptions.where((o) => _selectedValues.contains(o.value)).length;
    if (enabledSelected == 0) return false;
    if (enabledSelected == _enabledOptions.length) return true;
    return null; // Indeterminate
  }

  void _handleSelectAll(bool? value) {
    if (!widget.enabled) return;

    List<T> newSelection;
    if (value == true || value == null) {
      // Select all enabled options
      newSelection = [
        ..._selectedValues.where(
            (v) => !_enabledOptions.any((o) => o.value == v)), // Keep disabled selections
        ..._enabledOptions.map((o) => o.value),
      ];
    } else {
      // Deselect all enabled options
      newSelection = _selectedValues
          .where((v) => !_enabledOptions.any((o) => o.value == v))
          .toList();
    }
    widget.onChanged(newSelection);
  }

  void _handleOptionChanged(T value, bool? checked) {
    if (!widget.enabled) return;

    List<T> newSelection;
    if (checked == true) {
      newSelection = [..._selectedValues, value];
    } else {
      newSelection = _selectedValues.where((v) => v != value).toList();
    }
    widget.onChanged(newSelection);
  }

  @override
  Widget build(BuildContext context) {
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.config.showSelectAll) ...[
          SubZeroCheckbox(
            value: _selectAllState,
            onChanged: _handleSelectAll,
            label: widget.config.selectAllLabel,
            tristate: true,
            enabled: widget.enabled && _enabledOptions.isNotEmpty,
            size: widget.config.size,
            activeColor: widget.config.activeColor,
            semanticLabel: 'Select all options',
          ),
          SizedBox(height: widget.config.spacing),
        ],
        ...widget.options.asMap().entries.map((entry) {
          final index = entry.key;
          final option = entry.value;
          final isLast = index == widget.options.length - 1;

          return Padding(
            padding: EdgeInsets.only(
              bottom: isLast ? 0 : widget.config.spacing,
            ),
            child: SubZeroCheckbox(
              value: _selectedValues.contains(option.value),
              onChanged: (checked) =>
                  _handleOptionChanged(option.value, checked),
              label: option.label,
              enabled: widget.enabled && option.enabled,
              size: widget.config.size,
              activeColor: widget.config.activeColor,
              semanticLabel: option.semanticLabel,
            ),
          );
        }),
      ],
    );

    Widget result = Semantics(
      label: widget.semanticLabel ?? 'Multiselect list',
      child: content,
    );

    if (widget.config.scrollable) {
      result = ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: widget.config.maxHeight ?? 300,
        ),
        child: SingleChildScrollView(child: result),
      );
    }

    return result;
  }
}

/// A horizontal checkbox group for displaying checkboxes in a row
class SubZeroCheckboxGroup<T> extends StatelessWidget {
  const SubZeroCheckboxGroup({
    super.key,
    required this.options,
    required this.selectedValues,
    required this.onChanged,
    this.spacing = SubZeroSpacing.lg,
    this.size = SubZeroCheckboxSize.medium,
    this.enabled = true,
    this.wrap = false,
    this.runSpacing = SubZeroSpacing.sm,
    this.activeColor,
  });

  /// List of available options
  final List<SubZeroMultiselectOption<T>> options;

  /// Currently selected values
  final List<T> selectedValues;

  /// Callback when selection changes
  final ValueChanged<List<T>> onChanged;

  /// Horizontal spacing between checkboxes
  final double spacing;

  /// Size of checkboxes
  final SubZeroCheckboxSize size;

  /// Whether all checkboxes are enabled
  final bool enabled;

  /// Whether to wrap to next line
  final bool wrap;

  /// Vertical spacing when wrapped
  final double runSpacing;

  /// Custom active color
  final Color? activeColor;

  void _handleOptionChanged(T value, bool? checked) {
    List<T> newSelection;
    if (checked == true) {
      newSelection = [...selectedValues, value];
    } else {
      newSelection = selectedValues.where((v) => v != value).toList();
    }
    onChanged(newSelection);
  }

  @override
  Widget build(BuildContext context) {
    final checkboxes = options.map((option) {
      return SubZeroCheckbox(
        value: selectedValues.contains(option.value),
        onChanged: (checked) => _handleOptionChanged(option.value, checked),
        label: option.label,
        enabled: enabled && option.enabled,
        size: size,
        activeColor: activeColor,
        semanticLabel: option.semanticLabel,
      );
    }).toList();

    if (wrap) {
      return Wrap(
        spacing: spacing,
        runSpacing: runSpacing,
        children: checkboxes,
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: checkboxes
          .expand((checkbox) => [checkbox, SizedBox(width: spacing)])
          .toList()
        ..removeLast(),
    );
  }
}
