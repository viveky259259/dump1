import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';

/// Button variant types following SubZero 2.0 Design System
enum SubZeroButtonVariant {
  /// Solid background, high emphasis (primary action)
  primary,

  /// Bordered, medium emphasis (secondary action)
  secondary,

  /// Minimal/text only, low emphasis (tertiary action)
  tertiary,

  /// Icon-only button (square)
  iconOnly,

  /// Flushed: same as primary but with zero border radius
  flushed,
}

/// Button size presets
enum SubZeroButtonSize {
  /// Small: height 36px, padding 12px horizontal
  small,

  /// Medium: height 44px, padding 16px horizontal (default)
  medium,

  /// Large: height 52px, padding 24px horizontal
  large,
}

/// A flexible, accessible button widget following the SubZero 2.0 Design System.
///
/// Supports Primary (solid), Secondary (outlined), Tertiary (text), IconOnly,
/// and Flushed variants with states for default, hover, focus, disabled, and loading.
///
/// Example usage:
/// ```dart
/// SubZeroButton(
///   label: 'Submit',
///   variant: SubZeroButtonVariant.primary,
///   onPressed: () => print('Pressed!'),
/// )
/// ```
class SubZeroButton extends StatefulWidget {
  /// The button's text label (required for non-icon-only buttons)
  final String? label;

  /// Optional leading icon displayed before the label
  final IconData? leadingIcon;

  /// Optional trailing icon displayed after the label
  final IconData? trailingIcon;

  /// Icon for icon-only variant
  final IconData? icon;

  /// The button variant/style
  final SubZeroButtonVariant variant;

  /// The button size
  final SubZeroButtonSize size;

  /// Callback when button is pressed (null = disabled)
  final VoidCallback? onPressed;

  /// Whether the button shows a loading spinner
  final bool isLoading;

  /// Whether the button takes full width
  final bool fullWidth;

  /// Custom background color (overrides variant color)
  final Color? backgroundColor;

  /// Custom foreground/text color (overrides variant color)
  final Color? foregroundColor;

  /// Semantic label for accessibility
  final String? semanticLabel;

  const SubZeroButton({
    super.key,
    this.label,
    this.leadingIcon,
    this.trailingIcon,
    this.icon,
    this.variant = SubZeroButtonVariant.primary,
    this.size = SubZeroButtonSize.medium,
    this.onPressed,
    this.isLoading = false,
    this.fullWidth = false,
    this.backgroundColor,
    this.foregroundColor,
    this.semanticLabel,
  }) : assert(
          variant == SubZeroButtonVariant.iconOnly
              ? icon != null
              : label != null || icon != null,
          'Label is required for non-icon-only buttons',
        );

  @override
  State<SubZeroButton> createState() => _SubZeroButtonState();
}

class _SubZeroButtonState extends State<SubZeroButton> {
  bool _isHovered = false;
  bool _isFocused = false;

  bool get _isDisabled => widget.onPressed == null || widget.isLoading;

  // Size configurations
  double get _height {
    switch (widget.size) {
      case SubZeroButtonSize.small:
        return 36.0;
      case SubZeroButtonSize.medium:
        return 44.0;
      case SubZeroButtonSize.large:
        return 52.0;
    }
  }

  double get _minWidth {
    // Ensure minimum touch target of 48x48
    return widget.variant == SubZeroButtonVariant.iconOnly ? 48.0 : 48.0;
  }

  EdgeInsets get _padding {
    if (widget.variant == SubZeroButtonVariant.iconOnly) {
      return EdgeInsets.zero;
    }
    switch (widget.size) {
      case SubZeroButtonSize.small:
        return const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0);
      case SubZeroButtonSize.medium:
        return const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0);
      case SubZeroButtonSize.large:
        return const EdgeInsets.symmetric(horizontal: 24.0, vertical: 14.0);
    }
  }

  double get _iconSize {
    switch (widget.size) {
      case SubZeroButtonSize.small:
        return 16.0;
      case SubZeroButtonSize.medium:
        return 20.0;
      case SubZeroButtonSize.large:
        return 24.0;
    }
  }

  double get _fontSize {
    switch (widget.size) {
      case SubZeroButtonSize.small:
        return 13.0;
      case SubZeroButtonSize.medium:
        return 14.0;
      case SubZeroButtonSize.large:
        return 16.0;
    }
  }

  // Color getters based on variant and state
  Color get _backgroundColor {
    if (widget.backgroundColor != null) return widget.backgroundColor!;

    switch (widget.variant) {
      case SubZeroButtonVariant.primary:
        if (_isDisabled) return SubZeroColors.primary.withValues(alpha: 0.5);
        if (_isHovered || _isFocused) return SubZeroColors.primaryDark;
        return SubZeroColors.primary;

      case SubZeroButtonVariant.secondary:
        if (_isDisabled) return SubZeroColors.surface;
        if (_isHovered || _isFocused) return SubZeroColors.surfaceVariant;
        return SubZeroColors.surface;

      case SubZeroButtonVariant.tertiary:
        if (_isHovered || _isFocused) {
          return SubZeroColors.primary.withValues(alpha: 0.08);
        }
        return Colors.transparent;

      case SubZeroButtonVariant.iconOnly:
        if (_isDisabled) return SubZeroColors.primary.withValues(alpha: 0.5);
        if (_isHovered || _isFocused) return SubZeroColors.primaryDark;
        return SubZeroColors.primary;

      case SubZeroButtonVariant.flushed:
        if (_isDisabled) return SubZeroColors.primary.withValues(alpha: 0.5);
        if (_isHovered || _isFocused) return SubZeroColors.primaryDark;
        return SubZeroColors.primary;
    }
  }

  Color get _foregroundColor {
    if (widget.foregroundColor != null) return widget.foregroundColor!;

    switch (widget.variant) {
      case SubZeroButtonVariant.primary:
      case SubZeroButtonVariant.iconOnly:
      case SubZeroButtonVariant.flushed:
        if (_isDisabled) return Colors.white.withValues(alpha: 0.7);
        return Colors.white;

      case SubZeroButtonVariant.secondary:
        if (_isDisabled) return SubZeroColors.primary.withValues(alpha: 0.5);
        return SubZeroColors.primary;

      case SubZeroButtonVariant.tertiary:
        if (_isDisabled) return SubZeroColors.primary.withValues(alpha: 0.5);
        return SubZeroColors.primary;
    }
  }

  Color? get _borderColor {
    if (widget.variant == SubZeroButtonVariant.secondary) {
      if (_isDisabled) return SubZeroColors.border;
      if (_isHovered || _isFocused) return SubZeroColors.primary;
      return SubZeroColors.border;
    }
    return null;
  }

  BorderRadius get _borderRadius {
    if (widget.variant == SubZeroButtonVariant.flushed) {
      return BorderRadius.zero;
    }
    return SubZeroRadius.small;
  }

  void _handleTap() {
    if (!_isDisabled) {
      HapticFeedback.lightImpact();
      widget.onPressed?.call();
    }
  }

  @override
  Widget build(BuildContext context) {
    final semanticLabel = widget.semanticLabel ??
        widget.label ??
        (widget.icon != null ? 'Button' : null);

    return Semantics(
      button: true,
      enabled: !_isDisabled,
      label: semanticLabel,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          if (event is KeyDownEvent &&
              (event.logicalKey == LogicalKeyboardKey.enter ||
                  event.logicalKey == LogicalKeyboardKey.space)) {
            _handleTap();
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: MouseRegion(
          cursor:
              _isDisabled ? SystemMouseCursors.forbidden : SystemMouseCursors.click,
          onEnter: (_) => setState(() => _isHovered = true),
          onExit: (_) => setState(() => _isHovered = false),
          child: GestureDetector(
            onTap: _handleTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeInOut,
              constraints: BoxConstraints(
                minHeight: _height.clamp(48.0, double.infinity),
                minWidth: _minWidth,
              ),
              child: _buildStandardButton(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStandardButton() {
    return Container(
      height: _height,
      constraints: BoxConstraints(minWidth: _minWidth),
      decoration: BoxDecoration(
        color: _backgroundColor,
        borderRadius: _borderRadius,
        border: _borderColor != null
            ? Border.all(color: _borderColor!, width: 1.5)
            : null,
        boxShadow: _isFocused
            ? [
                BoxShadow(
                  color: SubZeroColors.primary.withValues(alpha: 0.3),
                  blurRadius: 0,
                  spreadRadius: 2,
                ),
              ]
            : null,
      ),
      padding: _padding,
      child: widget.fullWidth
          ? Center(child: _buildButtonContent())
          : _buildButtonContent(),
    );
  }

  Widget _buildButtonContent() {
    if (widget.isLoading) {
      return SizedBox(
        width: _iconSize,
        height: _iconSize,
        child: CircularProgressIndicator(
          strokeWidth: 2.0,
          valueColor: AlwaysStoppedAnimation<Color>(_foregroundColor),
        ),
      );
    }

    if (widget.variant == SubZeroButtonVariant.iconOnly) {
      return Icon(
        widget.icon,
        size: _iconSize,
        color: _foregroundColor,
      );
    }

    final children = <Widget>[];

    if (widget.leadingIcon != null) {
      children.add(Icon(
        widget.leadingIcon,
        size: _iconSize,
        color: _foregroundColor,
      ));
      children.add(const SizedBox(width: SubZeroSpacing.sm));
    }

    if (widget.label != null) {
      children.add(Text(
        widget.label!,
        style: TextStyle(
          fontSize: _fontSize,
          fontWeight: FontWeight.w600,
          color: _foregroundColor,
          letterSpacing: 0.3,
        ),
      ));
    }

    if (widget.trailingIcon != null) {
      children.add(const SizedBox(width: SubZeroSpacing.sm));
      children.add(Icon(
        widget.trailingIcon,
        size: _iconSize,
        color: _foregroundColor,
      ));
    }

    return Row(
      mainAxisSize: widget.fullWidth ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: children,
    );
  }
}

/// A container widget that arranges a set of related buttons in a horizontal row.
///
/// Implements correct spacing between buttons and handles overflow gracefully
/// by wrapping on smaller screens.
///
/// Example usage:
/// ```dart
/// SubZeroButtonGroup(
///   children: [
///     SubZeroButton(label: 'Cancel', variant: SubZeroButtonVariant.secondary, onPressed: () {}),
///     SubZeroButton(label: 'Save', variant: SubZeroButtonVariant.primary, onPressed: () {}),
///   ],
/// )
/// ```
class SubZeroButtonGroup extends StatelessWidget {
  /// The list of button widgets to display
  final List<Widget> children;

  /// Spacing between buttons
  final double spacing;

  /// Whether buttons should be aligned at the start, center, or end
  final MainAxisAlignment alignment;

  /// Whether the button group should take full width
  final bool fullWidth;

  /// Whether to wrap buttons on overflow (responsive)
  final bool wrap;

  /// Vertical spacing when buttons wrap to new line
  final double runSpacing;

  const SubZeroButtonGroup({
    super.key,
    required this.children,
    this.spacing = SubZeroSpacing.sm,
    this.alignment = MainAxisAlignment.start,
    this.fullWidth = false,
    this.wrap = true,
    this.runSpacing = SubZeroSpacing.sm,
  });

  @override
  Widget build(BuildContext context) {
    if (wrap) {
      return Wrap(
        spacing: spacing,
        runSpacing: runSpacing,
        alignment: _wrapAlignment,
        children: children,
      );
    }

    return Row(
      mainAxisSize: fullWidth ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: alignment,
      children: _buildRowChildren(),
    );
  }

  WrapAlignment get _wrapAlignment {
    switch (alignment) {
      case MainAxisAlignment.start:
        return WrapAlignment.start;
      case MainAxisAlignment.center:
        return WrapAlignment.center;
      case MainAxisAlignment.end:
        return WrapAlignment.end;
      case MainAxisAlignment.spaceBetween:
        return WrapAlignment.spaceBetween;
      case MainAxisAlignment.spaceAround:
        return WrapAlignment.spaceAround;
      case MainAxisAlignment.spaceEvenly:
        return WrapAlignment.spaceEvenly;
    }
  }

  List<Widget> _buildRowChildren() {
    final result = <Widget>[];
    for (int i = 0; i < children.length; i++) {
      result.add(children[i]);
      if (i < children.length - 1) {
        result.add(SizedBox(width: spacing));
      }
    }
    return result;
  }
}

/// A connected button group where buttons are visually joined together.
///
/// Useful for toggle groups or segmented controls.
class SubZeroConnectedButtonGroup extends StatelessWidget {
  /// The list of button widgets to display
  final List<Widget> children;

  /// Border radius for the group container
  final BorderRadius? borderRadius;

  const SubZeroConnectedButtonGroup({
    super.key,
    required this.children,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: borderRadius ?? SubZeroRadius.small,
        border: Border.all(color: SubZeroColors.border, width: 1),
      ),
      child: ClipRRect(
        borderRadius: borderRadius ?? SubZeroRadius.small,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: _buildConnectedChildren(),
        ),
      ),
    );
  }

  List<Widget> _buildConnectedChildren() {
    final result = <Widget>[];
    for (int i = 0; i < children.length; i++) {
      result.add(children[i]);
      if (i < children.length - 1) {
        result.add(Container(
          width: 1,
          color: SubZeroColors.border,
        ));
      }
    }
    return result;
  }
}
