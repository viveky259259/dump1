import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/elevation.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';

/// Media aspect ratio presets following Figma specifications.
/// All ratios are width:height (x:y).
enum SubZeroCardMediaRatio {
  /// 1:0.5 - Wide landscape (width is 2x height)
  wide(2.0),

  /// 1:1 - Square
  square(1.0),

  /// 4:3 - Standard landscape
  standard(4 / 3),

  /// 1:1.5 - Portrait (height is 1.5x width)
  portrait(1 / 1.5);

  const SubZeroCardMediaRatio(this.value);
  final double value;
}

/// Card elevation presets using SubZero elevation tokens.
enum SubZeroCardElevation {
  /// No shadow
  none,

  /// Subtle shadow (level1)
  low,

  /// Medium shadow (level2) - Default
  medium,

  /// Pronounced shadow (level3)
  high,
}

/// Header configuration for SubZeroCard.
class SubZeroCardHeader {
  const SubZeroCardHeader({
    required this.title,
    this.subtitle,
    this.leading,
    this.trailing,
    this.titleMaxLines = 2,
    this.subtitleMaxLines = 1,
  });

  /// Primary title text
  final String title;

  /// Optional subtitle text
  final String? subtitle;

  /// Optional leading widget (e.g., icon or avatar)
  final Widget? leading;

  /// Optional trailing widget (e.g., icon button or badge)
  final Widget? trailing;

  /// Maximum lines for title before ellipsis
  final int titleMaxLines;

  /// Maximum lines for subtitle before ellipsis
  final int subtitleMaxLines;
}

/// Media configuration for SubZeroCard.
class SubZeroCardMedia {
  const SubZeroCardMedia({
    this.image,
    this.imageUrl,
    this.child,
    this.aspectRatio = SubZeroCardMediaRatio.standard,
    this.fit = BoxFit.cover,
    this.semanticLabel,
  }) : assert(
          image != null || imageUrl != null || child != null,
          'At least one of image, imageUrl, or child must be provided',
        );

  /// Asset image path
  final String? image;

  /// Network image URL
  final String? imageUrl;

  /// Custom widget (e.g., chart, video player)
  final Widget? child;

  /// Aspect ratio preset
  final SubZeroCardMediaRatio aspectRatio;

  /// How the image should fit within the container
  final BoxFit fit;

  /// Accessibility label for the media
  final String? semanticLabel;
}

/// A versatile, self-contained card surface following the SubZero 2.0 Design System.
///
/// Supports static (display-only) and interactive (tappable) modes with
/// customizable content areas: header, media, body, and actions.
///
/// Example usage:
/// ```dart
/// SubZeroCard(
///   header: SubZeroCardHeader(
///     title: 'Card Title',
///     subtitle: 'Supporting text',
///     leading: Icon(Icons.star),
///   ),
///   media: SubZeroCardMedia(
///     imageUrl: 'https://example.com/image.jpg',
///     aspectRatio: SubZeroCardMediaRatio.standard,
///   ),
///   body: Text('Card body content goes here.'),
///   actions: [
///     SubZeroButton(label: 'Action 1', onPressed: () {}),
///   ],
///   onTap: () => print('Card tapped'),
/// )
/// ```
class SubZeroCard extends StatefulWidget {
  const SubZeroCard({
    super.key,
    this.header,
    this.media,
    this.body,
    this.actions,
    this.onTap,
    this.onLongPress,
    this.elevation = SubZeroCardElevation.medium,
    this.borderRadius,
    this.backgroundColor,
    this.borderColor,
    this.showBorder = false,
    this.padding,
    this.width,
    this.height,
    this.semanticLabel,
    this.clipBehavior = Clip.antiAlias,
  });

  /// Header section configuration
  final SubZeroCardHeader? header;

  /// Media section configuration
  final SubZeroCardMedia? media;

  /// Body content widget
  final Widget? body;

  /// Action widgets (typically buttons or icon buttons)
  final List<Widget>? actions;

  /// Callback when the card is tapped (makes card interactive)
  final VoidCallback? onTap;

  /// Callback when the card is long-pressed
  final VoidCallback? onLongPress;

  /// Elevation level for the card shadow
  final SubZeroCardElevation elevation;

  /// Custom border radius (defaults to SubZeroRadius.medium)
  final BorderRadius? borderRadius;

  /// Custom background color (defaults to SubZeroColors.surface)
  final Color? backgroundColor;

  /// Custom border color when showBorder is true
  final Color? borderColor;

  /// Whether to show a border around the card
  final bool showBorder;

  /// Custom internal padding (defaults to SubZeroSpacing.md)
  final EdgeInsets? padding;

  /// Fixed width (defaults to intrinsic width)
  final double? width;

  /// Fixed height (defaults to intrinsic height)
  final double? height;

  /// Accessibility label for the entire card
  final String? semanticLabel;

  /// How to clip the card content
  final Clip clipBehavior;

  /// Whether the card is interactive (has onTap callback)
  bool get isInteractive => onTap != null || onLongPress != null;

  @override
  State<SubZeroCard> createState() => _SubZeroCardState();
}

class _SubZeroCardState extends State<SubZeroCard> {
  bool _isHovered = false;
  bool _isFocused = false;
  bool _isPressed = false;

  List<BoxShadow> get _elevation {
    // Elevate slightly on hover/focus for interactive cards
    if (widget.isInteractive && (_isHovered || _isFocused)) {
      switch (widget.elevation) {
        case SubZeroCardElevation.none:
          return SubZeroElevation.level1;
        case SubZeroCardElevation.low:
          return SubZeroElevation.level2;
        case SubZeroCardElevation.medium:
          return SubZeroElevation.level3;
        case SubZeroCardElevation.high:
          return SubZeroElevation.level4;
      }
    }

    switch (widget.elevation) {
      case SubZeroCardElevation.none:
        return SubZeroElevation.none;
      case SubZeroCardElevation.low:
        return SubZeroElevation.level1;
      case SubZeroCardElevation.medium:
        return SubZeroElevation.level2;
      case SubZeroCardElevation.high:
        return SubZeroElevation.level3;
    }
  }

  Color get _backgroundColor {
    final baseColor = widget.backgroundColor ?? SubZeroColors.surface;
    if (_isPressed) {
      return Color.lerp(baseColor, SubZeroColors.secondary, 0.05)!;
    }
    return baseColor;
  }

  void _handleTap() {
    HapticFeedback.lightImpact();
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    final borderRadius = widget.borderRadius ?? SubZeroRadius.medium;
    final contentPadding = widget.padding ?? SubZeroSpacing.cardPadding;

    Widget cardContent = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Media section (no padding, full-bleed)
        if (widget.media != null) _buildMedia(widget.media!),

        // Header section
        if (widget.header != null)
          Padding(
            padding: EdgeInsets.fromLTRB(
              contentPadding.left,
              widget.media != null ? contentPadding.top : contentPadding.top,
              contentPadding.right,
              0,
            ),
            child: _buildHeader(widget.header!),
          ),

        // Body section
        if (widget.body != null)
          Padding(
            padding: EdgeInsets.fromLTRB(
              contentPadding.left,
              widget.header != null ? SubZeroSpacing.sm : contentPadding.top,
              contentPadding.right,
              0,
            ),
            child: widget.body,
          ),

        // Actions section
        if (widget.actions != null && widget.actions!.isNotEmpty)
          Padding(
            padding: EdgeInsets.fromLTRB(
              contentPadding.left,
              SubZeroSpacing.md,
              contentPadding.right,
              contentPadding.bottom,
            ),
            child: _buildActions(widget.actions!),
          )
        else if (widget.header != null || widget.body != null)
          SizedBox(height: contentPadding.bottom),
      ],
    );

    // Wrap in container with styling
    Widget card = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        color: _backgroundColor,
        borderRadius: borderRadius,
        boxShadow: _elevation,
        border: widget.showBorder
            ? Border.all(
                color: widget.borderColor ?? SubZeroColors.border,
                width: 1,
              )
            : (_isFocused && widget.isInteractive
                ? Border.all(color: SubZeroColors.accent, width: 2)
                : null),
      ),
      clipBehavior: widget.clipBehavior,
      child: cardContent,
    );

    // Make interactive if needed
    if (widget.isInteractive) {
      card = MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        cursor: SystemMouseCursors.click,
        child: Focus(
          onFocusChange: (focused) => setState(() => _isFocused = focused),
          onKeyEvent: (node, event) {
            if (event is KeyDownEvent &&
                (event.logicalKey == LogicalKeyboardKey.enter ||
                    event.logicalKey == LogicalKeyboardKey.space)) {
              _handleTap();
              return KeyEventResult.handled;
            }
            return KeyEventResult.ignored;
          },
          child: GestureDetector(
            onTap: _handleTap,
            onLongPress: widget.onLongPress,
            onTapDown: (_) => setState(() => _isPressed = true),
            onTapUp: (_) => setState(() => _isPressed = false),
            onTapCancel: () => setState(() => _isPressed = false),
            child: card,
          ),
        ),
      );
    }

    // Wrap with semantics
    return Semantics(
      label: widget.semanticLabel,
      button: widget.isInteractive,
      enabled: true,
      child: card,
    );
  }

  Widget _buildHeader(SubZeroCardHeader header) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Leading widget
        if (header.leading != null) ...[
          header.leading!,
          const SizedBox(width: SubZeroSpacing.sm),
        ],

        // Title and subtitle
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                header.title,
                style: theme.textTheme.titleMedium?.copyWith(
                  color: SubZeroColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: header.titleMaxLines,
                overflow: TextOverflow.ellipsis,
              ),
              if (header.subtitle != null) ...[
                const SizedBox(height: SubZeroSpacing.xs),
                Text(
                  header.subtitle!,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: SubZeroColors.textSecondary,
                  ),
                  maxLines: header.subtitleMaxLines,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),

        // Trailing widget
        if (header.trailing != null) ...[
          const SizedBox(width: SubZeroSpacing.sm),
          header.trailing!,
        ],
      ],
    );
  }

  Widget _buildMedia(SubZeroCardMedia media) {
    Widget mediaContent;

    if (media.child != null) {
      mediaContent = media.child!;
    } else if (media.imageUrl != null) {
      mediaContent = Image.network(
        media.imageUrl!,
        fit: media.fit,
        semanticLabel: media.semanticLabel,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Container(
            color: SubZeroColors.surfaceVariant,
            child: Center(
              child: CircularProgressIndicator(
                value: loadingProgress.expectedTotalBytes != null
                    ? loadingProgress.cumulativeBytesLoaded /
                        loadingProgress.expectedTotalBytes!
                    : null,
                color: SubZeroColors.accent,
                strokeWidth: 2,
              ),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) => Container(
          color: SubZeroColors.surfaceVariant,
          child: const Center(
            child: Icon(
              Icons.broken_image_outlined,
              color: SubZeroColors.textTertiary,
              size: 48,
            ),
          ),
        ),
      );
    } else if (media.image != null) {
      mediaContent = Image.asset(
        media.image!,
        fit: media.fit,
        semanticLabel: media.semanticLabel,
        errorBuilder: (context, error, stackTrace) => Container(
          color: SubZeroColors.surfaceVariant,
          child: const Center(
            child: Icon(
              Icons.broken_image_outlined,
              color: SubZeroColors.textTertiary,
              size: 48,
            ),
          ),
        ),
      );
    } else {
      mediaContent = Container(color: SubZeroColors.surfaceVariant);
    }

    return AspectRatio(
      aspectRatio: media.aspectRatio.value,
      child: mediaContent,
    );
  }

  Widget _buildActions(List<Widget> actions) {
    return Wrap(
      spacing: SubZeroSpacing.sm,
      runSpacing: SubZeroSpacing.sm,
      alignment: WrapAlignment.start,
      children: actions,
    );
  }
}

/// A horizontal card variant that displays content side-by-side.
///
/// Useful for list items or compact card layouts.
class SubZeroHorizontalCard extends StatefulWidget {
  const SubZeroHorizontalCard({
    super.key,
    this.leading,
    this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.onLongPress,
    this.elevation = SubZeroCardElevation.low,
    this.backgroundColor,
    this.showBorder = false,
    this.padding,
    this.semanticLabel,
  });

  /// Leading widget (e.g., image, avatar, icon)
  final Widget? leading;

  /// Primary title text
  final String? title;

  /// Secondary subtitle text
  final String? subtitle;

  /// Trailing widget (e.g., icon, badge, button)
  final Widget? trailing;

  /// Callback when the card is tapped
  final VoidCallback? onTap;

  /// Callback when the card is long-pressed
  final VoidCallback? onLongPress;

  /// Elevation level for the card shadow
  final SubZeroCardElevation elevation;

  /// Custom background color
  final Color? backgroundColor;

  /// Whether to show a border
  final bool showBorder;

  /// Custom internal padding
  final EdgeInsets? padding;

  /// Accessibility label
  final String? semanticLabel;

  bool get isInteractive => onTap != null || onLongPress != null;

  @override
  State<SubZeroHorizontalCard> createState() => _SubZeroHorizontalCardState();
}

class _SubZeroHorizontalCardState extends State<SubZeroHorizontalCard> {
  bool _isHovered = false;
  bool _isFocused = false;
  bool _isPressed = false;

  List<BoxShadow> get _elevation {
    if (widget.isInteractive && (_isHovered || _isFocused)) {
      switch (widget.elevation) {
        case SubZeroCardElevation.none:
          return SubZeroElevation.level1;
        case SubZeroCardElevation.low:
          return SubZeroElevation.level2;
        case SubZeroCardElevation.medium:
          return SubZeroElevation.level3;
        case SubZeroCardElevation.high:
          return SubZeroElevation.level4;
      }
    }

    switch (widget.elevation) {
      case SubZeroCardElevation.none:
        return SubZeroElevation.none;
      case SubZeroCardElevation.low:
        return SubZeroElevation.level1;
      case SubZeroCardElevation.medium:
        return SubZeroElevation.level2;
      case SubZeroCardElevation.high:
        return SubZeroElevation.level3;
    }
  }

  Color get _backgroundColor {
    final baseColor = widget.backgroundColor ?? SubZeroColors.surface;
    if (_isPressed) {
      return Color.lerp(baseColor, SubZeroColors.secondary, 0.05)!;
    }
    return baseColor;
  }

  void _handleTap() {
    HapticFeedback.lightImpact();
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final contentPadding =
        widget.padding ?? const EdgeInsets.all(SubZeroSpacing.md);

    Widget cardContent = Padding(
      padding: contentPadding,
      child: Row(
        children: [
          // Leading widget
          if (widget.leading != null) ...[
            widget.leading!,
            const SizedBox(width: SubZeroSpacing.md),
          ],

          // Title and subtitle
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (widget.title != null)
                  Text(
                    widget.title!,
                    style: theme.textTheme.titleSmall?.copyWith(
                      color: SubZeroColors.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                if (widget.subtitle != null) ...[
                  const SizedBox(height: SubZeroSpacing.xs),
                  Text(
                    widget.subtitle!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: SubZeroColors.textSecondary,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),

          // Trailing widget
          if (widget.trailing != null) ...[
            const SizedBox(width: SubZeroSpacing.sm),
            widget.trailing!,
          ],
        ],
      ),
    );

    Widget card = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      decoration: BoxDecoration(
        color: _backgroundColor,
        borderRadius: SubZeroRadius.medium,
        boxShadow: _elevation,
        border: widget.showBorder
            ? Border.all(color: SubZeroColors.border, width: 1)
            : (_isFocused && widget.isInteractive
                ? Border.all(color: SubZeroColors.accent, width: 2)
                : null),
      ),
      child: cardContent,
    );

    if (widget.isInteractive) {
      card = MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        cursor: SystemMouseCursors.click,
        child: Focus(
          onFocusChange: (focused) => setState(() => _isFocused = focused),
          onKeyEvent: (node, event) {
            if (event is KeyDownEvent &&
                (event.logicalKey == LogicalKeyboardKey.enter ||
                    event.logicalKey == LogicalKeyboardKey.space)) {
              _handleTap();
              return KeyEventResult.handled;
            }
            return KeyEventResult.ignored;
          },
          child: GestureDetector(
            onTap: _handleTap,
            onLongPress: widget.onLongPress,
            onTapDown: (_) => setState(() => _isPressed = true),
            onTapUp: (_) => setState(() => _isPressed = false),
            onTapCancel: () => setState(() => _isPressed = false),
            child: card,
          ),
        ),
      );
    }

    return Semantics(
      label: widget.semanticLabel,
      button: widget.isInteractive,
      enabled: true,
      child: card,
    );
  }
}

/// A card group that displays multiple cards with consistent spacing.
class SubZeroCardGroup extends StatelessWidget {
  const SubZeroCardGroup({
    super.key,
    required this.children,
    this.spacing = SubZeroSpacing.md,
    this.crossAxisAlignment = CrossAxisAlignment.stretch,
    this.direction = Axis.vertical,
  });

  /// List of card widgets
  final List<Widget> children;

  /// Spacing between cards
  final double spacing;

  /// Cross-axis alignment of cards
  final CrossAxisAlignment crossAxisAlignment;

  /// Layout direction (vertical or horizontal)
  final Axis direction;

  @override
  Widget build(BuildContext context) {
    if (direction == Axis.vertical) {
      return Column(
        crossAxisAlignment: crossAxisAlignment,
        mainAxisSize: MainAxisSize.min,
        children: _buildSpacedChildren(),
      );
    }

    final row = Row(
      crossAxisAlignment: crossAxisAlignment,
      mainAxisSize: MainAxisSize.min,
      children: _buildSpacedChildren(),
    );
    
    // Wrap in IntrinsicHeight when using stretch to avoid infinite height constraints
    if (crossAxisAlignment == CrossAxisAlignment.stretch) {
      return IntrinsicHeight(child: row);
    }
    return row;
  }

  List<Widget> _buildSpacedChildren() {
    final List<Widget> spacedChildren = [];
    for (int i = 0; i < children.length; i++) {
      spacedChildren.add(children[i]);
      if (i < children.length - 1) {
        spacedChildren.add(
          direction == Axis.vertical
              ? SizedBox(height: spacing)
              : SizedBox(width: spacing),
        );
      }
    }
    return spacedChildren;
  }
}
