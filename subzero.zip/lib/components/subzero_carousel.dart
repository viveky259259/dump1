import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';

/// Configuration for the SubZeroCarousel component.
class SubZeroCarouselConfig {
  /// Whether to show dot indicators at the bottom.
  final bool showIndicators;

  /// Whether to show navigation arrow buttons.
  final bool showNavigationArrows;

  /// Whether to enable auto-play rotation.
  final bool enableAutoPlay;

  /// Duration between auto-play transitions.
  final Duration autoPlayInterval;

  /// Duration of the slide animation.
  final Duration animationDuration;

  /// Animation curve for transitions.
  final Curve animationCurve;

  /// Whether to loop back to the start after reaching the end.
  final bool enableInfiniteScroll;

  /// Viewport fraction for each item (1.0 = full width, 0.8 = 80% with peek).
  final double viewportFraction;

  /// Height of the carousel. If null, uses aspect ratio.
  final double? height;

  /// Aspect ratio of the carousel (width / height). Used when height is null.
  final double aspectRatio;

  /// Padding around the entire carousel.
  final EdgeInsets padding;

  /// Gap between items when viewportFraction < 1.0.
  final double itemGap;

  const SubZeroCarouselConfig({
    this.showIndicators = true,
    this.showNavigationArrows = true,
    this.enableAutoPlay = false,
    this.autoPlayInterval = const Duration(seconds: 4),
    this.animationDuration = const Duration(milliseconds: 350),
    this.animationCurve = Curves.easeInOut,
    this.enableInfiniteScroll = true,
    this.viewportFraction = 1.0,
    this.height,
    this.aspectRatio = 16 / 9,
    this.padding = EdgeInsets.zero,
    this.itemGap = 16.0,
  });

  SubZeroCarouselConfig copyWith({
    bool? showIndicators,
    bool? showNavigationArrows,
    bool? enableAutoPlay,
    Duration? autoPlayInterval,
    Duration? animationDuration,
    Curve? animationCurve,
    bool? enableInfiniteScroll,
    double? viewportFraction,
    double? height,
    double? aspectRatio,
    EdgeInsets? padding,
    double? itemGap,
  }) {
    return SubZeroCarouselConfig(
      showIndicators: showIndicators ?? this.showIndicators,
      showNavigationArrows: showNavigationArrows ?? this.showNavigationArrows,
      enableAutoPlay: enableAutoPlay ?? this.enableAutoPlay,
      autoPlayInterval: autoPlayInterval ?? this.autoPlayInterval,
      animationDuration: animationDuration ?? this.animationDuration,
      animationCurve: animationCurve ?? this.animationCurve,
      enableInfiniteScroll: enableInfiniteScroll ?? this.enableInfiniteScroll,
      viewportFraction: viewportFraction ?? this.viewportFraction,
      height: height ?? this.height,
      aspectRatio: aspectRatio ?? this.aspectRatio,
      padding: padding ?? this.padding,
      itemGap: itemGap ?? this.itemGap,
    );
  }
}

/// A carousel/slider component that displays a series of content items
/// with navigation controls and indicators following SubZero 2.0 Design System.
///
/// Features:
/// - Swipe/drag gesture navigation
/// - Arrow button navigation
/// - Dot indicators showing current position
/// - Optional auto-play with configurable interval
/// - Responsive viewport fraction for peek effect
/// - Keyboard navigation support
/// - Full accessibility support
class SubZeroCarousel extends StatefulWidget {
  /// The list of child widgets to display in the carousel.
  final List<Widget> children;

  /// Configuration for the carousel behavior and appearance.
  final SubZeroCarouselConfig config;

  /// Called when the current page changes.
  final ValueChanged<int>? onPageChanged;

  /// Initial page index to display.
  final int initialPage;

  /// Optional controller for external control of the carousel.
  final SubZeroCarouselController? controller;

  const SubZeroCarousel({
    super.key,
    required this.children,
    this.config = const SubZeroCarouselConfig(),
    this.onPageChanged,
    this.initialPage = 0,
    this.controller,
  });

  @override
  State<SubZeroCarousel> createState() => _SubZeroCarouselState();
}

class _SubZeroCarouselState extends State<SubZeroCarousel> {
  late PageController _pageController;
  late int _currentPage;
  Timer? _autoPlayTimer;
  bool _isHovering = false;
  final FocusNode _focusNode = FocusNode();

  int get _itemCount => widget.children.length;
  bool get _canGoBack => widget.config.enableInfiniteScroll || _currentPage > 0;
  bool get _canGoForward =>
      widget.config.enableInfiniteScroll || _currentPage < _itemCount - 1;

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage.clamp(0, _itemCount - 1);
    _pageController = PageController(
      initialPage: _currentPage,
      viewportFraction: widget.config.viewportFraction,
    );
    widget.controller?._attach(this);
    _startAutoPlayIfEnabled();
  }

  @override
  void didUpdateWidget(SubZeroCarousel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.config.viewportFraction != widget.config.viewportFraction) {
      _pageController.dispose();
      _pageController = PageController(
        initialPage: _currentPage,
        viewportFraction: widget.config.viewportFraction,
      );
    }
    if (oldWidget.config.enableAutoPlay != widget.config.enableAutoPlay) {
      if (widget.config.enableAutoPlay) {
        _startAutoPlayIfEnabled();
      } else {
        _stopAutoPlay();
      }
    }
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller?._detach();
      widget.controller?._attach(this);
    }
  }

  @override
  void dispose() {
    widget.controller?._detach();
    _stopAutoPlay();
    _pageController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _startAutoPlayIfEnabled() {
    if (widget.config.enableAutoPlay && _itemCount > 1) {
      _autoPlayTimer?.cancel();
      _autoPlayTimer = Timer.periodic(widget.config.autoPlayInterval, (_) {
        if (!_isHovering && mounted) {
          _goToNextPage();
        }
      });
    }
  }

  void _stopAutoPlay() {
    _autoPlayTimer?.cancel();
    _autoPlayTimer = null;
  }

  void _goToNextPage() {
    if (_itemCount <= 1) return;
    int nextPage = _currentPage + 1;
    if (nextPage >= _itemCount) {
      nextPage = widget.config.enableInfiniteScroll ? 0 : _itemCount - 1;
    }
    _animateToPage(nextPage);
  }

  void _goToPreviousPage() {
    if (_itemCount <= 1) return;
    int prevPage = _currentPage - 1;
    if (prevPage < 0) {
      prevPage = widget.config.enableInfiniteScroll ? _itemCount - 1 : 0;
    }
    _animateToPage(prevPage);
  }

  void _animateToPage(int page) {
    if (!mounted) return;
    _pageController.animateToPage(
      page,
      duration: widget.config.animationDuration,
      curve: widget.config.animationCurve,
    );
  }

  void _goToPage(int page) {
    if (page >= 0 && page < _itemCount) {
      _animateToPage(page);
    }
  }

  void _onPageChanged(int page) {
    setState(() => _currentPage = page);
    widget.onPageChanged?.call(page);
  }

  KeyEventResult _handleKeyEvent(FocusNode node, KeyEvent event) {
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
        _goToPreviousPage();
        return KeyEventResult.handled;
      } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
        _goToNextPage();
        return KeyEventResult.handled;
      }
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.children.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: widget.config.padding,
      child: Focus(
        focusNode: _focusNode,
        onKeyEvent: _handleKeyEvent,
        child: MouseRegion(
          onEnter: (_) => setState(() => _isHovering = true),
          onExit: (_) => setState(() => _isHovering = false),
          child: Semantics(
            label: 'Carousel with ${_itemCount} items, currently showing item ${_currentPage + 1}',
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildCarouselContent(),
                if (widget.config.showIndicators && _itemCount > 1)
                  Padding(
                    padding: const EdgeInsets.only(top: SubZeroSpacing.md),
                    child: _SubZeroCarouselIndicators(
                      itemCount: _itemCount,
                      currentIndex: _currentPage,
                      onTap: _goToPage,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCarouselContent() {
    final carouselView = widget.config.height != null
        ? SizedBox(height: widget.config.height, child: _buildPageView())
        : AspectRatio(
            aspectRatio: widget.config.aspectRatio,
            child: _buildPageView(),
          );

    if (!widget.config.showNavigationArrows || _itemCount <= 1) {
      return carouselView;
    }

    return Stack(
      alignment: Alignment.center,
      children: [
        carouselView,
        Positioned(
          left: SubZeroSpacing.sm,
          child: _SubZeroCarouselArrowButton(
            direction: _ArrowDirection.left,
            onPressed: _canGoBack ? _goToPreviousPage : null,
            isVisible: _isHovering || _focusNode.hasFocus,
          ),
        ),
        Positioned(
          right: SubZeroSpacing.sm,
          child: _SubZeroCarouselArrowButton(
            direction: _ArrowDirection.right,
            onPressed: _canGoForward ? _goToNextPage : null,
            isVisible: _isHovering || _focusNode.hasFocus,
          ),
        ),
      ],
    );
  }

  Widget _buildPageView() {
    return PageView.builder(
      controller: _pageController,
      itemCount: _itemCount,
      onPageChanged: _onPageChanged,
      physics: const BouncingScrollPhysics(),
      itemBuilder: (context, index) {
        return Padding(
          padding: EdgeInsets.symmetric(
            horizontal: widget.config.viewportFraction < 1.0
                ? widget.config.itemGap / 2
                : 0,
          ),
          child: widget.children[index],
        );
      },
    );
  }
}

/// Direction for navigation arrows.
enum _ArrowDirection { left, right }

/// Navigation arrow button for the carousel.
class _SubZeroCarouselArrowButton extends StatefulWidget {
  final _ArrowDirection direction;
  final VoidCallback? onPressed;
  final bool isVisible;

  const _SubZeroCarouselArrowButton({
    required this.direction,
    this.onPressed,
    this.isVisible = true,
  });

  @override
  State<_SubZeroCarouselArrowButton> createState() =>
      _SubZeroCarouselArrowButtonState();
}

class _SubZeroCarouselArrowButtonState
    extends State<_SubZeroCarouselArrowButton> {
  bool _isHovered = false;
  bool _isFocused = false;

  bool get _isEnabled => widget.onPressed != null;
  bool get _isInteracting => _isHovered || _isFocused;

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 200),
      opacity: widget.isVisible ? 1.0 : 0.0,
      child: IgnorePointer(
        ignoring: !widget.isVisible,
        child: Semantics(
          button: true,
          enabled: _isEnabled,
          label: widget.direction == _ArrowDirection.left
              ? 'Previous slide'
              : 'Next slide',
          child: Focus(
            onFocusChange: (focused) => setState(() => _isFocused = focused),
            child: MouseRegion(
              cursor:
                  _isEnabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
              onEnter: (_) => setState(() => _isHovered = true),
              onExit: (_) => setState(() => _isHovered = false),
              child: GestureDetector(
                onTap: widget.onPressed,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: _isInteracting && _isEnabled
                        ? SubZeroColors.surface
                        : SubZeroColors.surface.withValues(alpha: 0.9),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _isFocused
                          ? SubZeroColors.accent
                          : SubZeroColors.border,
                      width: _isFocused ? 2 : 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: SubZeroColors.textPrimary.withValues(alpha: 0.1),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(
                    widget.direction == _ArrowDirection.left
                        ? Icons.chevron_left
                        : Icons.chevron_right,
                    size: 24,
                    color: _isEnabled
                        ? (_isInteracting
                            ? SubZeroColors.accent
                            : SubZeroColors.textSecondary)
                        : SubZeroColors.textTertiary,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Dot indicators for the carousel.
class _SubZeroCarouselIndicators extends StatelessWidget {
  final int itemCount;
  final int currentIndex;
  final ValueChanged<int>? onTap;

  const _SubZeroCarouselIndicators({
    required this.itemCount,
    required this.currentIndex,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Slide ${currentIndex + 1} of $itemCount',
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: List.generate(
          itemCount,
          (index) => _SubZeroCarouselDot(
            isActive: index == currentIndex,
            onTap: () => onTap?.call(index),
            index: index,
          ),
        ),
      ),
    );
  }
}

/// Individual dot indicator.
class _SubZeroCarouselDot extends StatefulWidget {
  final bool isActive;
  final VoidCallback? onTap;
  final int index;

  const _SubZeroCarouselDot({
    required this.isActive,
    this.onTap,
    required this.index,
  });

  @override
  State<_SubZeroCarouselDot> createState() => _SubZeroCarouselDotState();
}

class _SubZeroCarouselDotState extends State<_SubZeroCarouselDot> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'Go to slide ${widget.index + 1}',
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTap: widget.onTap,
          behavior: HitTestBehavior.opaque,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: widget.isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                color: widget.isActive
                    ? SubZeroColors.accent
                    : (_isHovered
                        ? SubZeroColors.textSecondary
                        : SubZeroColors.textTertiary),
                borderRadius: BorderRadius.circular(SubZeroRadius.pill),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Controller for external control of the SubZeroCarousel.
class SubZeroCarouselController {
  _SubZeroCarouselState? _state;

  void _attach(_SubZeroCarouselState state) => _state = state;
  void _detach() => _state = null;

  /// Navigate to the next slide.
  void nextPage() => _state?._goToNextPage();

  /// Navigate to the previous slide.
  void previousPage() => _state?._goToPreviousPage();

  /// Navigate to a specific page index.
  void goToPage(int page) => _state?._goToPage(page);

  /// Get the current page index.
  int? get currentPage => _state?._currentPage;

  /// Start auto-play if enabled in config.
  void startAutoPlay() => _state?._startAutoPlayIfEnabled();

  /// Stop auto-play.
  void stopAutoPlay() => _state?._stopAutoPlay();
}

/// A pre-built carousel item card with image, title, and description.
class SubZeroCarouselCard extends StatelessWidget {
  final String? imageUrl;
  final Widget? imageWidget;
  final String? title;
  final String? subtitle;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final Widget? overlay;

  const SubZeroCarouselCard({
    super.key,
    this.imageUrl,
    this.imageWidget,
    this.title,
    this.subtitle,
    this.onTap,
    this.backgroundColor,
    this.overlay,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: backgroundColor ?? SubZeroColors.surfaceVariant,
          borderRadius: SubZeroRadius.medium,
          boxShadow: [
            BoxShadow(
              color: SubZeroColors.textPrimary.withValues(alpha: 0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Image layer
            if (imageWidget != null)
              imageWidget!
            else if (imageUrl != null)
              Image.network(
                imageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _buildPlaceholder(),
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return _buildLoadingIndicator(loadingProgress);
                },
              )
            else
              _buildPlaceholder(),

            // Gradient overlay for text readability
            if (title != null || subtitle != null)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.7),
                        Colors.transparent,
                      ],
                    ),
                  ),
                  padding: const EdgeInsets.all(SubZeroSpacing.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (title != null)
                        Text(
                          title!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      if (subtitle != null) ...[
                        const SizedBox(height: SubZeroSpacing.xs),
                        Text(
                          subtitle!,
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.85),
                            fontSize: 14,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
              ),

            // Custom overlay
            if (overlay != null) overlay!,
          ],
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      color: SubZeroColors.surfaceVariant,
      child: const Center(
        child: Icon(
          Icons.image_outlined,
          size: 48,
          color: SubZeroColors.textTertiary,
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator(ImageChunkEvent loadingProgress) {
    return Container(
      color: SubZeroColors.surfaceVariant,
      child: Center(
        child: CircularProgressIndicator(
          value: loadingProgress.expectedTotalBytes != null
              ? loadingProgress.cumulativeBytesLoaded /
                  loadingProgress.expectedTotalBytes!
              : null,
          color: SubZeroColors.accent,
          strokeWidth: 2,
        ),
      ),
    );
  }
}

/// A banner-style carousel item with full-bleed content.
class SubZeroCarouselBanner extends StatelessWidget {
  final Widget child;
  final Color? backgroundColor;
  final Gradient? gradient;
  final VoidCallback? onTap;

  const SubZeroCarouselBanner({
    super.key,
    required this.child,
    this.backgroundColor,
    this.gradient,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: gradient == null
              ? (backgroundColor ?? SubZeroColors.primary)
              : null,
          gradient: gradient,
          borderRadius: SubZeroRadius.medium,
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      ),
    );
  }
}
