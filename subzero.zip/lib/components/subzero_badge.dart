import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';

/// Badge variant types
enum SubZeroBadgeVariant {
  /// A simple dot indicator without a count
  dot,

  /// Displays a numeric count
  count,
}

/// Badge style/color variants matching the SubZero Design System
enum SubZeroBadgeStyle {
  /// Primary filled style - accent background with white text
  filled,

  /// Outlined style - white background with accent text and border
  outlined,

  /// Muted/disabled style - gray background with gray text
  muted,
}

/// Badge size presets
enum SubZeroBadgeSize {
  /// Small badge (16px height for count, 8px for dot)
  small,

  /// Medium badge (20px height for count, 10px for dot) - default
  medium,

  /// Large badge (24px height for count, 12px for dot)
  large,
}

/// Badge position when attached to a child widget
enum SubZeroBadgePosition {
  /// Top-right corner (default)
  topRight,

  /// Top-left corner
  topLeft,

  /// Bottom-right corner
  bottomRight,

  /// Bottom-left corner
  bottomLeft,
}

/// Configuration for SubZeroBadge positioning and offset
class SubZeroBadgeAlignment {
  final SubZeroBadgePosition position;
  final Offset offset;

  const SubZeroBadgeAlignment({
    this.position = SubZeroBadgePosition.topRight,
    this.offset = Offset.zero,
  });

  /// Get the alignment based on position
  AlignmentGeometry get alignment {
    switch (position) {
      case SubZeroBadgePosition.topRight:
        return Alignment.topRight;
      case SubZeroBadgePosition.topLeft:
        return Alignment.topLeft;
      case SubZeroBadgePosition.bottomRight:
        return Alignment.bottomRight;
      case SubZeroBadgePosition.bottomLeft:
        return Alignment.bottomLeft;
    }
  }
}

/// A versatile badge component following the SubZero 2.0 Design System.
///
/// Supports two variants:
/// - **Dot**: A simple indicator without count
/// - **Count**: Displays a numeric value with overflow handling (99+)
///
/// Can be used standalone or attached to a child widget (e.g., Avatar, Icon).
///
/// Example usage:
/// ```dart
/// // Standalone count badge
/// SubZeroBadge(
///   variant: SubZeroBadgeVariant.count,
///   count: 5,
/// )
///
/// // Badge attached to an icon
/// SubZeroBadge(
///   variant: SubZeroBadgeVariant.dot,
///   child: Icon(Icons.notifications),
/// )
///
/// // Count badge with custom style
/// SubZeroBadge(
///   variant: SubZeroBadgeVariant.count,
///   count: 150,
///   maxCount: 99,
///   style: SubZeroBadgeStyle.outlined,
///   child: SubZeroAvatar(name: 'John'),
/// )
/// ```
class SubZeroBadge extends StatelessWidget {
  /// The badge variant (dot or count)
  final SubZeroBadgeVariant variant;

  /// The count to display (only used when variant is [SubZeroBadgeVariant.count])
  final int count;

  /// Maximum count before showing overflow (e.g., 99+)
  final int maxCount;

  /// The visual style of the badge
  final SubZeroBadgeStyle style;

  /// The size preset for the badge
  final SubZeroBadgeSize size;

  /// The widget to attach the badge to (optional)
  final Widget? child;

  /// Badge alignment configuration when attached to a child
  final SubZeroBadgeAlignment alignment;

  /// Whether to show the badge (useful for conditionally hiding)
  final bool showBadge;

  /// Custom background color (overrides style)
  final Color? backgroundColor;

  /// Custom text/border color (overrides style)
  final Color? foregroundColor;

  /// Semantic label for accessibility
  final String? semanticLabel;

  const SubZeroBadge({
    super.key,
    this.variant = SubZeroBadgeVariant.dot,
    this.count = 0,
    this.maxCount = 99,
    this.style = SubZeroBadgeStyle.filled,
    this.size = SubZeroBadgeSize.medium,
    this.child,
    this.alignment = const SubZeroBadgeAlignment(),
    this.showBadge = true,
    this.backgroundColor,
    this.foregroundColor,
    this.semanticLabel,
  });

  /// Factory constructor for a dot badge
  factory SubZeroBadge.dot({
    Key? key,
    SubZeroBadgeStyle style = SubZeroBadgeStyle.filled,
    SubZeroBadgeSize size = SubZeroBadgeSize.medium,
    Widget? child,
    SubZeroBadgeAlignment alignment = const SubZeroBadgeAlignment(),
    bool showBadge = true,
    Color? backgroundColor,
    String? semanticLabel,
  }) =>
      SubZeroBadge(
        key: key,
        variant: SubZeroBadgeVariant.dot,
        style: style,
        size: size,
        child: child,
        alignment: alignment,
        showBadge: showBadge,
        backgroundColor: backgroundColor,
        semanticLabel: semanticLabel ?? 'New notification',
      );

  /// Factory constructor for a count badge
  factory SubZeroBadge.count({
    Key? key,
    required int count,
    int maxCount = 99,
    SubZeroBadgeStyle style = SubZeroBadgeStyle.filled,
    SubZeroBadgeSize size = SubZeroBadgeSize.medium,
    Widget? child,
    SubZeroBadgeAlignment alignment = const SubZeroBadgeAlignment(),
    bool showBadge = true,
    Color? backgroundColor,
    Color? foregroundColor,
    String? semanticLabel,
  }) =>
      SubZeroBadge(
        key: key,
        variant: SubZeroBadgeVariant.count,
        count: count,
        maxCount: maxCount,
        style: style,
        size: size,
        child: child,
        alignment: alignment,
        showBadge: showBadge,
        backgroundColor: backgroundColor,
        foregroundColor: foregroundColor,
        semanticLabel: semanticLabel,
      );

  @override
  Widget build(BuildContext context) {
    if (!showBadge && child != null) return child!;
    if (!showBadge) return const SizedBox.shrink();

    final badge = _buildBadge();

    // If no child, return standalone badge
    if (child == null) {
      return Semantics(
        label: _getSemanticLabel(),
        child: badge,
      );
    }

    // Position badge relative to child
    return Semantics(
      label: _getSemanticLabel(),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          child!,
          Positioned(
            top: _getTopPosition(),
            bottom: _getBottomPosition(),
            left: _getLeftPosition(),
            right: _getRightPosition(),
            child: badge,
          ),
        ],
      ),
    );
  }

  Widget _buildBadge() {
    final colors = _getColors();
    final dimensions = _getDimensions();

    if (variant == SubZeroBadgeVariant.dot) {
      return _buildDotBadge(colors, dimensions);
    }
    return _buildCountBadge(colors, dimensions);
  }

  Widget _buildDotBadge(_BadgeColors colors, _BadgeDimensions dimensions) {
    return Container(
      width: dimensions.dotSize,
      height: dimensions.dotSize,
      decoration: BoxDecoration(
        color: colors.background,
        shape: BoxShape.circle,
        border: style == SubZeroBadgeStyle.outlined
            ? Border.all(color: colors.border, width: 1.5)
            : null,
        boxShadow: style == SubZeroBadgeStyle.filled
            ? [
                BoxShadow(
                  color: colors.background.withValues(alpha: 0.3),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
    );
  }

  Widget _buildCountBadge(_BadgeColors colors, _BadgeDimensions dimensions) {
    final displayText = _getDisplayText();
    final isOverflow = count > maxCount;
    final isSingleDigit = count < 10 && !isOverflow;

    return Container(
      constraints: BoxConstraints(
        minWidth: dimensions.height,
        minHeight: dimensions.height,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: isSingleDigit ? 0 : dimensions.horizontalPadding,
      ),
      decoration: BoxDecoration(
        color: colors.background,
        borderRadius: BorderRadius.circular(dimensions.height / 2),
        border: style == SubZeroBadgeStyle.outlined
            ? Border.all(color: colors.border, width: 1.5)
            : null,
        boxShadow: style == SubZeroBadgeStyle.filled
            ? [
                BoxShadow(
                  color: colors.background.withValues(alpha: 0.3),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: Center(
        child: Text(
          displayText,
          style: GoogleFonts.inter(
            fontSize: dimensions.fontSize,
            fontWeight: FontWeight.w600,
            color: colors.text,
            height: 1.0,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  String _getDisplayText() {
    if (count > maxCount) return '$maxCount+';
    return count.toString();
  }

  _BadgeColors _getColors() {
    // Custom colors take precedence
    if (backgroundColor != null || foregroundColor != null) {
      final bg = backgroundColor ?? _getDefaultBackgroundColor();
      final fg = foregroundColor ?? _getDefaultForegroundColor();
      return _BadgeColors(
        background: bg,
        text: fg,
        border: fg,
      );
    }

    switch (style) {
      case SubZeroBadgeStyle.filled:
        return _BadgeColors(
          background: SubZeroColors.accent,
          text: Colors.white,
          border: SubZeroColors.accent,
        );
      case SubZeroBadgeStyle.outlined:
        return _BadgeColors(
          background: SubZeroColors.surface,
          text: SubZeroColors.accent,
          border: SubZeroColors.accent,
        );
      case SubZeroBadgeStyle.muted:
        return _BadgeColors(
          background: SubZeroColors.surfaceVariant,
          text: SubZeroColors.textSecondary,
          border: SubZeroColors.border,
        );
    }
  }

  Color _getDefaultBackgroundColor() {
    switch (style) {
      case SubZeroBadgeStyle.filled:
        return SubZeroColors.accent;
      case SubZeroBadgeStyle.outlined:
        return SubZeroColors.surface;
      case SubZeroBadgeStyle.muted:
        return SubZeroColors.surfaceVariant;
    }
  }

  Color _getDefaultForegroundColor() {
    switch (style) {
      case SubZeroBadgeStyle.filled:
        return Colors.white;
      case SubZeroBadgeStyle.outlined:
        return SubZeroColors.accent;
      case SubZeroBadgeStyle.muted:
        return SubZeroColors.textSecondary;
    }
  }

  _BadgeDimensions _getDimensions() {
    switch (size) {
      case SubZeroBadgeSize.small:
        return _BadgeDimensions(
          height: 16,
          dotSize: 8,
          fontSize: 10,
          horizontalPadding: 4,
        );
      case SubZeroBadgeSize.medium:
        return _BadgeDimensions(
          height: 20,
          dotSize: 10,
          fontSize: 11,
          horizontalPadding: 6,
        );
      case SubZeroBadgeSize.large:
        return _BadgeDimensions(
          height: 24,
          dotSize: 12,
          fontSize: 12,
          horizontalPadding: 8,
        );
    }
  }

  double? _getTopPosition() {
    final dims = _getDimensions();
    final offset = alignment.offset.dy;
    switch (alignment.position) {
      case SubZeroBadgePosition.topRight:
      case SubZeroBadgePosition.topLeft:
        return -(dims.height / 3) + offset;
      case SubZeroBadgePosition.bottomRight:
      case SubZeroBadgePosition.bottomLeft:
        return null;
    }
  }

  double? _getBottomPosition() {
    final dims = _getDimensions();
    final offset = alignment.offset.dy;
    switch (alignment.position) {
      case SubZeroBadgePosition.topRight:
      case SubZeroBadgePosition.topLeft:
        return null;
      case SubZeroBadgePosition.bottomRight:
      case SubZeroBadgePosition.bottomLeft:
        return -(dims.height / 3) + offset;
    }
  }

  double? _getRightPosition() {
    final dims = _getDimensions();
    final offset = alignment.offset.dx;
    switch (alignment.position) {
      case SubZeroBadgePosition.topRight:
      case SubZeroBadgePosition.bottomRight:
        return -(dims.height / 3) + offset;
      case SubZeroBadgePosition.topLeft:
      case SubZeroBadgePosition.bottomLeft:
        return null;
    }
  }

  double? _getLeftPosition() {
    final dims = _getDimensions();
    final offset = alignment.offset.dx;
    switch (alignment.position) {
      case SubZeroBadgePosition.topRight:
      case SubZeroBadgePosition.bottomRight:
        return null;
      case SubZeroBadgePosition.topLeft:
      case SubZeroBadgePosition.bottomLeft:
        return -(dims.height / 3) + offset;
    }
  }

  String _getSemanticLabel() {
    if (semanticLabel != null) return semanticLabel!;

    if (variant == SubZeroBadgeVariant.dot) {
      return 'New notification indicator';
    }

    if (count > maxCount) {
      return 'More than $maxCount notifications';
    }
    return '$count notifications';
  }
}

/// Internal class for badge colors
class _BadgeColors {
  final Color background;
  final Color text;
  final Color border;

  const _BadgeColors({
    required this.background,
    required this.text,
    required this.border,
  });
}

/// Internal class for badge dimensions
class _BadgeDimensions {
  final double height;
  final double dotSize;
  final double fontSize;
  final double horizontalPadding;

  const _BadgeDimensions({
    required this.height,
    required this.dotSize,
    required this.fontSize,
    required this.horizontalPadding,
  });
}

/// Extension to easily wrap any widget with a badge
extension SubZeroBadgeExtension on Widget {
  /// Wrap this widget with a dot badge
  Widget withDotBadge({
    SubZeroBadgeStyle style = SubZeroBadgeStyle.filled,
    SubZeroBadgeSize size = SubZeroBadgeSize.medium,
    SubZeroBadgeAlignment alignment = const SubZeroBadgeAlignment(),
    bool show = true,
  }) =>
      SubZeroBadge.dot(
        style: style,
        size: size,
        alignment: alignment,
        showBadge: show,
        child: this,
      );

  /// Wrap this widget with a count badge
  Widget withCountBadge({
    required int count,
    int maxCount = 99,
    SubZeroBadgeStyle style = SubZeroBadgeStyle.filled,
    SubZeroBadgeSize size = SubZeroBadgeSize.medium,
    SubZeroBadgeAlignment alignment = const SubZeroBadgeAlignment(),
    bool show = true,
  }) =>
      SubZeroBadge.count(
        count: count,
        maxCount: maxCount,
        style: style,
        size: size,
        alignment: alignment,
        showBadge: show && count > 0,
        child: this,
      );
}
