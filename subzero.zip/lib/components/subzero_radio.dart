import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';

/// Size options for radio button
enum SubZeroRadioSize {
  small,  // 16px
  medium, // 20px
  large,  // 24px
}

/// A customizable radio button widget following SubZero 2.0 Design System.
///
/// This is a stateless widget that displays selected/unselected states.
/// Use [SubZeroRadioGroup] to manage a group of radio buttons.
class SubZeroRadio<T> extends StatefulWidget {
  const SubZeroRadio({
    super.key,
    required this.value,
    required this.groupValue,
    required this.onChanged,
    this.label,
    this.enabled = true,
    this.size = SubZeroRadioSize.medium,
    this.semanticLabel,
    this.labelStyle,
    this.activeColor,
    this.borderColor,
  });

  /// The value represented by this radio button
  final T value;

  /// The currently selected value for the group
  final T? groupValue;

  /// Callback when this radio button is selected
  final ValueChanged<T?>? onChanged;

  /// Optional text label displayed next to the radio button
  final String? label;

  /// Whether the radio button is enabled
  final bool enabled;

  /// Size of the radio button
  final SubZeroRadioSize size;

  /// Semantic label for accessibility
  final String? semanticLabel;

  /// Custom label text style
  final TextStyle? labelStyle;

  /// Custom active (selected) color
  final Color? activeColor;

  /// Custom border color for unselected state
  final Color? borderColor;

  /// Whether this radio button is currently selected
  bool get isSelected => value == groupValue;

  @override
  State<SubZeroRadio<T>> createState() => _SubZeroRadioState<T>();
}

class _SubZeroRadioState<T> extends State<SubZeroRadio<T>>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  bool _isFocused = false;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.9).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  double get _outerSize {
    switch (widget.size) {
      case SubZeroRadioSize.small:
        return 16.0;
      case SubZeroRadioSize.medium:
        return 20.0;
      case SubZeroRadioSize.large:
        return 24.0;
    }
  }

  double get _innerDotSize {
    switch (widget.size) {
      case SubZeroRadioSize.small:
        return 8.0;
      case SubZeroRadioSize.medium:
        return 10.0;
      case SubZeroRadioSize.large:
        return 12.0;
    }
  }

  double get _borderWidth {
    switch (widget.size) {
      case SubZeroRadioSize.small:
        return 1.5;
      case SubZeroRadioSize.medium:
        return 2.0;
      case SubZeroRadioSize.large:
        return 2.0;
    }
  }

  double get _labelFontSize {
    switch (widget.size) {
      case SubZeroRadioSize.small:
        return 12.0;
      case SubZeroRadioSize.medium:
        return 14.0;
      case SubZeroRadioSize.large:
        return 16.0;
    }
  }

  void _handleTap() {
    if (!widget.enabled || widget.onChanged == null) return;

    // Animate tap
    _animationController.forward().then((_) {
      _animationController.reverse();
    });

    widget.onChanged!(widget.value);
  }

  void _handleKeyEvent(KeyEvent event) {
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.enter ||
          event.logicalKey == LogicalKeyboardKey.space) {
        _handleTap();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = widget.activeColor ?? SubZeroColors.accent;
    final borderColor = widget.borderColor ?? SubZeroColors.textPrimary;
    final disabledColor = SubZeroColors.textTertiary;

    final effectiveActiveColor = widget.enabled ? activeColor : disabledColor;
    final effectiveBorderColor = widget.enabled ? borderColor : disabledColor;

    final String semanticLabel = widget.semanticLabel ??
        widget.label ??
        (widget.isSelected ? 'Selected' : 'Not selected');

    return Semantics(
      selected: widget.isSelected,
      enabled: widget.enabled,
      label: semanticLabel,
      inMutuallyExclusiveGroup: true,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          _handleKeyEvent(event);
          return KeyEventResult.handled;
        },
        child: MouseRegion(
          cursor: widget.enabled
              ? SystemMouseCursors.click
              : SystemMouseCursors.forbidden,
          onEnter: (_) => setState(() => _isHovered = true),
          onExit: (_) => setState(() => _isHovered = false),
          child: GestureDetector(
            onTap: _handleTap,
            behavior: HitTestBehavior.opaque,
            child: AnimatedBuilder(
              animation: _scaleAnimation,
              builder: (context, child) => Transform.scale(
                scale: _scaleAnimation.value,
                child: child,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildRadioButton(
                    activeColor: effectiveActiveColor,
                    borderColor: effectiveBorderColor,
                  ),
                  if (widget.label != null) ...[
                    SizedBox(width: SubZeroSpacing.sm),
                    Flexible(
                      child: Text(
                        widget.label!,
                        style: widget.labelStyle ??
                            TextStyle(
                              fontSize: _labelFontSize,
                              fontWeight: widget.isSelected
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                              color: widget.enabled
                                  ? SubZeroColors.textPrimary
                                  : SubZeroColors.textTertiary,
                            ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRadioButton({
    required Color activeColor,
    required Color borderColor,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeInOut,
      width: _outerSize,
      height: _outerSize,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: widget.isSelected ? activeColor : borderColor,
          width: _borderWidth,
        ),
        color: SubZeroColors.surface,
        boxShadow: _isFocused
            ? [
                BoxShadow(
                  color: activeColor.withValues(alpha: 0.3),
                  blurRadius: 4,
                  spreadRadius: 1,
                ),
              ]
            : (_isHovered && widget.enabled)
                ? [
                    BoxShadow(
                      color: SubZeroColors.textTertiary.withValues(alpha: 0.2),
                      blurRadius: 2,
                      spreadRadius: 0,
                    ),
                  ]
                : null,
      ),
      child: Center(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeInOut,
          width: widget.isSelected ? _innerDotSize : 0,
          height: widget.isSelected ? _innerDotSize : 0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.isSelected ? activeColor : Colors.transparent,
          ),
        ),
      ),
    );
  }
}

/// A group of radio buttons that manages selection state.
///
/// Ensures only one option is selected at a time.
class SubZeroRadioGroup<T> extends StatefulWidget {
  const SubZeroRadioGroup({
    super.key,
    required this.items,
    required this.onChanged,
    this.initialValue,
    this.enabled = true,
    this.size = SubZeroRadioSize.medium,
    this.direction = Axis.vertical,
    this.spacing,
    this.activeColor,
    this.borderColor,
    this.labelBuilder,
  });

  /// List of values for each radio button
  final List<T> items;

  /// Callback when selection changes
  final ValueChanged<T?> onChanged;

  /// Initial selected value
  final T? initialValue;

  /// Whether the entire group is enabled
  final bool enabled;

  /// Size of all radio buttons in the group
  final SubZeroRadioSize size;

  /// Layout direction (vertical or horizontal)
  final Axis direction;

  /// Spacing between radio buttons
  final double? spacing;

  /// Custom active color for all radio buttons
  final Color? activeColor;

  /// Custom border color for all radio buttons
  final Color? borderColor;

  /// Optional custom label builder for each item
  final String Function(T item)? labelBuilder;

  @override
  State<SubZeroRadioGroup<T>> createState() => _SubZeroRadioGroupState<T>();
}

class _SubZeroRadioGroupState<T> extends State<SubZeroRadioGroup<T>> {
  late T? _selectedValue;

  @override
  void initState() {
    super.initState();
    _selectedValue = widget.initialValue;
  }

  @override
  void didUpdateWidget(SubZeroRadioGroup<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initialValue != oldWidget.initialValue) {
      _selectedValue = widget.initialValue;
    }
  }

  void _handleChange(T? value) {
    if (!widget.enabled) return;
    setState(() => _selectedValue = value);
    widget.onChanged(value);
  }

  String _getLabel(T item) {
    if (widget.labelBuilder != null) {
      return widget.labelBuilder!(item);
    }
    return item.toString();
  }

  double get _defaultSpacing {
    switch (widget.size) {
      case SubZeroRadioSize.small:
        return SubZeroSpacing.sm;
      case SubZeroRadioSize.medium:
        return SubZeroSpacing.md;
      case SubZeroRadioSize.large:
        return SubZeroSpacing.lg;
    }
  }

  @override
  Widget build(BuildContext context) {
    final spacing = widget.spacing ?? _defaultSpacing;

    final children = widget.items.map((item) {
      return SubZeroRadio<T>(
        value: item,
        groupValue: _selectedValue,
        onChanged: _handleChange,
        label: _getLabel(item),
        enabled: widget.enabled,
        size: widget.size,
        activeColor: widget.activeColor,
        borderColor: widget.borderColor,
      );
    }).toList();

    if (widget.direction == Axis.vertical) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (int i = 0; i < children.length; i++) ...[
            children[i],
            if (i < children.length - 1) SizedBox(height: spacing),
          ],
        ],
      );
    }

    return Wrap(
      direction: Axis.horizontal,
      spacing: spacing,
      runSpacing: spacing,
      children: children,
    );
  }
}

/// A radio group item definition with value and label
class SubZeroRadioItem<T> {
  const SubZeroRadioItem({
    required this.value,
    required this.label,
    this.enabled = true,
  });

  final T value;
  final String label;
  final bool enabled;
}

/// A more feature-rich radio group that accepts [SubZeroRadioItem] definitions.
///
/// Allows per-item enabled states and explicit labels.
class SubZeroRadioGroupWithItems<T> extends StatefulWidget {
  const SubZeroRadioGroupWithItems({
    super.key,
    required this.items,
    required this.onChanged,
    this.initialValue,
    this.enabled = true,
    this.size = SubZeroRadioSize.medium,
    this.direction = Axis.vertical,
    this.spacing,
    this.activeColor,
    this.borderColor,
  });

  /// List of radio item definitions
  final List<SubZeroRadioItem<T>> items;

  /// Callback when selection changes
  final ValueChanged<T?> onChanged;

  /// Initial selected value
  final T? initialValue;

  /// Whether the entire group is enabled
  final bool enabled;

  /// Size of all radio buttons in the group
  final SubZeroRadioSize size;

  /// Layout direction (vertical or horizontal)
  final Axis direction;

  /// Spacing between radio buttons
  final double? spacing;

  /// Custom active color for all radio buttons
  final Color? activeColor;

  /// Custom border color for all radio buttons
  final Color? borderColor;

  @override
  State<SubZeroRadioGroupWithItems<T>> createState() =>
      _SubZeroRadioGroupWithItemsState<T>();
}

class _SubZeroRadioGroupWithItemsState<T>
    extends State<SubZeroRadioGroupWithItems<T>> {
  late T? _selectedValue;

  @override
  void initState() {
    super.initState();
    _selectedValue = widget.initialValue;
  }

  @override
  void didUpdateWidget(SubZeroRadioGroupWithItems<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initialValue != oldWidget.initialValue) {
      _selectedValue = widget.initialValue;
    }
  }

  void _handleChange(T? value) {
    if (!widget.enabled) return;
    setState(() => _selectedValue = value);
    widget.onChanged(value);
  }

  double get _defaultSpacing {
    switch (widget.size) {
      case SubZeroRadioSize.small:
        return SubZeroSpacing.sm;
      case SubZeroRadioSize.medium:
        return SubZeroSpacing.md;
      case SubZeroRadioSize.large:
        return SubZeroSpacing.lg;
    }
  }

  @override
  Widget build(BuildContext context) {
    final spacing = widget.spacing ?? _defaultSpacing;

    final children = widget.items.map((item) {
      return SubZeroRadio<T>(
        value: item.value,
        groupValue: _selectedValue,
        onChanged: _handleChange,
        label: item.label,
        enabled: widget.enabled && item.enabled,
        size: widget.size,
        activeColor: widget.activeColor,
        borderColor: widget.borderColor,
      );
    }).toList();

    if (widget.direction == Axis.vertical) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (int i = 0; i < children.length; i++) ...[
            children[i],
            if (i < children.length - 1) SizedBox(height: spacing),
          ],
        ],
      );
    }

    return Wrap(
      direction: Axis.horizontal,
      spacing: spacing,
      runSpacing: spacing,
      children: children,
    );
  }
}
