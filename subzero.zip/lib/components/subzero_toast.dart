import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';
import 'package:sub_zero_design_system/design_system/theme/radius.dart';
import 'package:sub_zero_design_system/design_system/theme/typography.dart';

/// Toast status types
enum SubZeroToastType {
  /// Dark gray default toast
  defaultType,

  /// Teal/cyan info toast
  info,

  /// Green success toast
  success,

  /// Red error toast
  error,

  /// Orange warning toast
  warning,
}

/// Toast position on screen
enum SubZeroToastPosition {
  top,
  bottom,
}

/// Toast action mode - icon (X button) or text (ACTION button)
enum SubZeroToastActionMode {
  /// Shows X close icon on the right
  icon,

  /// Shows text action button on the right
  text,
}

/// Configuration for toast display
class SubZeroToastConfig {
  final String message;
  final SubZeroToastType type;
  final SubZeroToastPosition position;
  final SubZeroToastActionMode actionMode;
  final Duration duration;
  final String? actionLabel;
  final VoidCallback? onAction;
  final IconData? leadingIcon;
  final bool showCloseButton;
  final double? maxWidth;

  const SubZeroToastConfig({
    required this.message,
    this.type = SubZeroToastType.defaultType,
    this.position = SubZeroToastPosition.bottom,
    this.actionMode = SubZeroToastActionMode.icon,
    this.duration = const Duration(seconds: 4),
    this.actionLabel,
    this.onAction,
    this.leadingIcon,
    this.showCloseButton = true,
    this.maxWidth,
  });
}

/// Toast utility class for showing overlay-based toast messages
///
/// Usage:
/// ```dart
/// // Simple toast
/// SubZeroToast.show(context, message: 'Self recommendation completed');
///
/// // Success toast with action
/// SubZeroToast.success(context, message: 'Item saved!');
///
/// // Toast with custom action
/// SubZeroToast.show(
///   context,
///   message: 'Item deleted',
///   actionLabel: 'UNDO',
///   onAction: () => undoDelete(),
/// );
/// ```
class SubZeroToast {
  static OverlayEntry? _currentOverlay;
  static Timer? _dismissTimer;

  /// Shows a toast with full configuration
  static void show(
    BuildContext context, {
    required String message,
    SubZeroToastType type = SubZeroToastType.defaultType,
    SubZeroToastPosition position = SubZeroToastPosition.bottom,
    SubZeroToastActionMode actionMode = SubZeroToastActionMode.icon,
    Duration duration = const Duration(seconds: 4),
    String? actionLabel,
    VoidCallback? onAction,
    IconData? leadingIcon,
    bool showCloseButton = true,
    double? maxWidth,
  }) {
    _dismiss();

    final config = SubZeroToastConfig(
      message: message,
      type: type,
      position: position,
      actionMode: actionMode,
      duration: duration,
      actionLabel: actionLabel,
      onAction: onAction,
      leadingIcon: leadingIcon,
      showCloseButton: showCloseButton,
      maxWidth: maxWidth,
    );

    final overlay = Overlay.of(context);
    _currentOverlay = OverlayEntry(
      builder: (context) => _SubZeroToastOverlay(
        config: config,
        onDismiss: _dismiss,
      ),
    );

    overlay.insert(_currentOverlay!);

    _dismissTimer = Timer(duration, _dismiss);
  }

  /// Shows a default (dark) toast
  static void defaultToast(
    BuildContext context, {
    required String message,
    SubZeroToastPosition position = SubZeroToastPosition.bottom,
    SubZeroToastActionMode actionMode = SubZeroToastActionMode.icon,
    Duration duration = const Duration(seconds: 4),
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    show(
      context,
      message: message,
      type: SubZeroToastType.defaultType,
      position: position,
      actionMode: actionMode,
      duration: duration,
      actionLabel: actionLabel,
      onAction: onAction,
    );
  }

  /// Shows an info toast
  static void info(
    BuildContext context, {
    required String message,
    SubZeroToastPosition position = SubZeroToastPosition.bottom,
    SubZeroToastActionMode actionMode = SubZeroToastActionMode.icon,
    Duration duration = const Duration(seconds: 4),
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    show(
      context,
      message: message,
      type: SubZeroToastType.info,
      position: position,
      actionMode: actionMode,
      duration: duration,
      actionLabel: actionLabel,
      onAction: onAction,
    );
  }

  /// Shows a success toast
  static void success(
    BuildContext context, {
    required String message,
    SubZeroToastPosition position = SubZeroToastPosition.bottom,
    SubZeroToastActionMode actionMode = SubZeroToastActionMode.icon,
    Duration duration = const Duration(seconds: 4),
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    show(
      context,
      message: message,
      type: SubZeroToastType.success,
      position: position,
      actionMode: actionMode,
      duration: duration,
      actionLabel: actionLabel,
      onAction: onAction,
    );
  }

  /// Shows an error toast
  static void error(
    BuildContext context, {
    required String message,
    SubZeroToastPosition position = SubZeroToastPosition.bottom,
    SubZeroToastActionMode actionMode = SubZeroToastActionMode.icon,
    Duration duration = const Duration(seconds: 4),
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    show(
      context,
      message: message,
      type: SubZeroToastType.error,
      position: position,
      actionMode: actionMode,
      duration: duration,
      actionLabel: actionLabel,
      onAction: onAction,
    );
  }

  /// Shows a warning toast
  static void warning(
    BuildContext context, {
    required String message,
    SubZeroToastPosition position = SubZeroToastPosition.bottom,
    SubZeroToastActionMode actionMode = SubZeroToastActionMode.icon,
    Duration duration = const Duration(seconds: 4),
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    show(
      context,
      message: message,
      type: SubZeroToastType.warning,
      position: position,
      actionMode: actionMode,
      duration: duration,
      actionLabel: actionLabel,
      onAction: onAction,
    );
  }

  /// Manually dismiss the current toast
  static void dismiss() => _dismiss();

  static void _dismiss() {
    _dismissTimer?.cancel();
    _dismissTimer = null;
    _currentOverlay?.remove();
    _currentOverlay = null;
  }
}

/// Internal overlay widget for toast display
class _SubZeroToastOverlay extends StatefulWidget {
  final SubZeroToastConfig config;
  final VoidCallback onDismiss;

  const _SubZeroToastOverlay({
    required this.config,
    required this.onDismiss,
  });

  @override
  State<_SubZeroToastOverlay> createState() => _SubZeroToastOverlayState();
}

class _SubZeroToastOverlayState extends State<_SubZeroToastOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    final isTop = widget.config.position == SubZeroToastPosition.top;
    _slideAnimation = Tween<Offset>(
      begin: Offset(0, isTop ? -1 : 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));

    _animationController.forward();

    // Schedule dismiss animation
    final dismissDelay = widget.config.duration - const Duration(milliseconds: 300);
    if (dismissDelay.isNegative == false) {
      Future.delayed(dismissDelay, () {
        if (mounted) {
          _animationController.reverse();
        }
      });
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _handleDismiss() {
    _animationController.reverse().then((_) {
      widget.onDismiss();
    });
  }

  void _handleAction() {
    widget.config.onAction?.call();
    _handleDismiss();
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final isTop = widget.config.position == SubZeroToastPosition.top;

    return Positioned(
      top: isTop ? mediaQuery.padding.top + SubZeroSpacing.lg : null,
      bottom: isTop ? null : mediaQuery.padding.bottom + SubZeroSpacing.lg,
      left: SubZeroSpacing.md,
      right: SubZeroSpacing.md,
      child: SlideTransition(
        position: _slideAnimation,
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: widget.config.maxWidth ?? 400,
              ),
              child: _SubZeroToastWidget(
                config: widget.config,
                onDismiss: _handleDismiss,
                onAction: _handleAction,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// The actual toast widget with styling
class _SubZeroToastWidget extends StatelessWidget {
  final SubZeroToastConfig config;
  final VoidCallback onDismiss;
  final VoidCallback onAction;

  const _SubZeroToastWidget({
    required this.config,
    required this.onDismiss,
    required this.onAction,
  });

  Color _getBackgroundColor() {
    switch (config.type) {
      case SubZeroToastType.defaultType:
        return SubZeroColors.surfaceTertiary;
      case SubZeroToastType.info:
        return SubZeroColors.typical;
      case SubZeroToastType.success:
        return SubZeroColors.success;
      case SubZeroToastType.error:
        return SubZeroColors.error;
      case SubZeroToastType.warning:
        return SubZeroColors.warning;
    }
  }

  @override
  Widget build(BuildContext context) {
    final backgroundColor = _getBackgroundColor();

    return Material(
      color: Colors.transparent,
      child: Semantics(
        label: config.message,
        liveRegion: true,
        child: Container(
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(SubZeroRadius.sm),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.2),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: SubZeroSpacing.md,
              vertical: 10,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Leading icon (optional)
                if (config.leadingIcon != null) ...[
                  Icon(
                    config.leadingIcon,
                    color: Colors.white,
                    size: 20,
                  ),
                  const SizedBox(width: SubZeroSpacing.sm),
                ],

                // Message text
                Flexible(
                  child: Text(
                    config.message,
                    style: SubZeroTypography.textTheme.bodyMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w400,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),

                const SizedBox(width: SubZeroSpacing.md),

                // Action area
                if (config.actionMode == SubZeroToastActionMode.text &&
                    config.actionLabel != null)
                  _buildTextAction()
                else if (config.showCloseButton)
                  _buildIconAction(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextAction() => GestureDetector(
        onTap: onAction,
        child: MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Semantics(
            button: true,
            label: config.actionLabel,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: SubZeroSpacing.xs,
                vertical: 2,
              ),
              child: Text(
                config.actionLabel ?? 'ACTION',
                style: SubZeroTypography.textTheme.labelMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ),
      );

  Widget _buildIconAction() => GestureDetector(
        onTap: onDismiss,
        child: MouseRegion(
          cursor: SystemMouseCursors.click,
          child: Semantics(
            button: true,
            label: 'Dismiss toast',
            child: const Padding(
              padding: EdgeInsets.all(2),
              child: Icon(
                Icons.close,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ),
      );
}

/// Standalone toast widget for use in widget trees (non-overlay)
/// Useful for showcasing or embedding in custom layouts
class SubZeroToastPreview extends StatelessWidget {
  final String message;
  final SubZeroToastType type;
  final SubZeroToastActionMode actionMode;
  final String? actionLabel;
  final VoidCallback? onAction;
  final VoidCallback? onDismiss;
  final IconData? leadingIcon;

  const SubZeroToastPreview({
    super.key,
    required this.message,
    this.type = SubZeroToastType.defaultType,
    this.actionMode = SubZeroToastActionMode.icon,
    this.actionLabel,
    this.onAction,
    this.onDismiss,
    this.leadingIcon,
  });

  Color _getBackgroundColor() {
    switch (type) {
      case SubZeroToastType.defaultType:
        return SubZeroColors.surfaceTertiary;
      case SubZeroToastType.info:
        return SubZeroColors.typical;
      case SubZeroToastType.success:
        return SubZeroColors.success;
      case SubZeroToastType.error:
        return SubZeroColors.error;
      case SubZeroToastType.warning:
        return SubZeroColors.warning;
    }
  }

  @override
  Widget build(BuildContext context) {
    final backgroundColor = _getBackgroundColor();

    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(SubZeroRadius.sm),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: SubZeroSpacing.md,
          vertical: 10,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (leadingIcon != null) ...[
              Icon(leadingIcon, color: Colors.white, size: 20),
              const SizedBox(width: SubZeroSpacing.sm),
            ],
            Flexible(
              child: Text(
                message,
                style: SubZeroTypography.textTheme.bodyMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w400,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: SubZeroSpacing.md),
            if (actionMode == SubZeroToastActionMode.text && actionLabel != null)
              GestureDetector(
                onTap: onAction,
                child: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Text(
                    actionLabel!,
                    style: SubZeroTypography.textTheme.labelMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              )
            else
              GestureDetector(
                onTap: onDismiss,
                child: const MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Icon(Icons.close, color: Colors.white, size: 20),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
