import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/tokens.dart';

/// State of a progress tracker step.
enum SubZeroStepState {
  /// Step has been completed.
  completed,

  /// Step is currently active.
  current,

  /// Step is pending/incomplete.
  pending,
}

/// Data model for a single step in the progress tracker.
class SubZeroProgressStep {
  /// The title/label of the step.
  final String title;

  /// Optional icon to display instead of step number.
  final IconData? icon;

  /// Optional subtitle or description.
  final String? subtitle;

  const SubZeroProgressStep({
    required this.title,
    this.icon,
    this.subtitle,
  });
}

/// Orientation of the progress tracker.
enum SubZeroProgressTrackerOrientation {
  horizontal,
  vertical,
}

/// A circular progress header that displays the current step progress.
///
/// Shows a circular progress indicator with the step count (e.g., "1/4"),
/// the current step title, and optionally the next step preview.
class SubZeroProgressTrackerHeader extends StatelessWidget {
  /// Current step index (0-based).
  final int currentStep;

  /// Total number of steps.
  final int totalSteps;

  /// Title of the current step.
  final String currentStepTitle;

  /// Title of the next step (optional).
  final String? nextStepTitle;

  /// Size of the circular progress indicator.
  final double circleSize;

  const SubZeroProgressTrackerHeader({
    super.key,
    required this.currentStep,
    required this.totalSteps,
    required this.currentStepTitle,
    this.nextStepTitle,
    this.circleSize = 64,
  });

  @override
  Widget build(BuildContext context) {
    final progress = (currentStep + 1) / totalSteps;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Circular progress indicator
        SizedBox(
          width: circleSize,
          height: circleSize,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Background circle
              CustomPaint(
                size: Size(circleSize, circleSize),
                painter: _CircleProgressPainter(
                  progress: progress,
                  backgroundColor: colors.neutral.n200,
                  progressColor: colors.primary[500],
                  strokeWidth: 4,
                ),
              ),
              // Step count text
              Text(
                '${currentStep + 1}/$totalSteps',
                style: typography.bodyMedium.style.copyWith(
                  color: colors.text.primary,
                  fontWeight: typography.weight.semibold,
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: spacing.md),
        // Step info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                currentStepTitle,
                style: typography.h6.style.copyWith(
                  color: colors.primary[500],
                  fontWeight: typography.weight.bold,
                ),
                textAlign: TextAlign.end,
              ),
              if (nextStepTitle != null) ...[
                SizedBox(height: spacing.xs),
                Text(
                  'NEXT: ${nextStepTitle!.toUpperCase()}',
                  style: typography.caption.style.copyWith(
                    color: colors.text.secondary,
                    fontWeight: typography.weight.medium,
                    letterSpacing: 0.5,
                  ),
                  textAlign: TextAlign.end,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

/// A progress tracker component that displays a series of steps.
///
/// Supports both horizontal and vertical layouts, with three step states:
/// completed, current, and pending. Each step can optionally be interactive.
class SubZeroProgressTracker extends StatelessWidget {
  /// List of steps to display.
  final List<SubZeroProgressStep> steps;

  /// Current active step index (0-based).
  final int currentStep;

  /// Orientation of the tracker (horizontal or vertical).
  final SubZeroProgressTrackerOrientation orientation;

  /// Whether steps are interactive (can be tapped).
  final bool interactive;

  /// Callback when a step is tapped. Only called if [interactive] is true.
  /// The callback receives the step index.
  final ValueChanged<int>? onStepTapped;

  /// Whether to show the header with circular progress.
  final bool showHeader;

  /// Spacing between steps in vertical layout.
  final double verticalStepSpacing;

  /// Connector line thickness.
  final double connectorThickness;

  const SubZeroProgressTracker({
    super.key,
    required this.steps,
    required this.currentStep,
    this.orientation = SubZeroProgressTrackerOrientation.vertical,
    this.interactive = false,
    this.onStepTapped,
    this.showHeader = false,
    this.verticalStepSpacing = 24,
    this.connectorThickness = 2,
  });

  SubZeroStepState _getStepState(int index) {
    if (index < currentStep) return SubZeroStepState.completed;
    if (index == currentStep) return SubZeroStepState.current;
    return SubZeroStepState.pending;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Optional header
        if (showHeader) ...[
          SubZeroProgressTrackerHeader(
            currentStep: currentStep,
            totalSteps: steps.length,
            currentStepTitle: steps[currentStep].title,
            nextStepTitle:
                currentStep < steps.length - 1 ? steps[currentStep + 1].title : null,
          ),
          SizedBox(height: spacing.lg),
          Divider(color: colors.neutral.n200, height: 1),
          SizedBox(height: spacing.lg),
        ],
        // Steps
        orientation == SubZeroProgressTrackerOrientation.vertical
            ? _buildVerticalLayout()
            : _buildHorizontalLayout(),
      ],
    );
  }

  Widget _buildVerticalLayout() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(steps.length, (index) {
        final isLast = index == steps.length - 1;
        return _VerticalStepItem(
          step: steps[index],
          stepIndex: index,
          state: _getStepState(index),
          isLast: isLast,
          interactive: interactive,
          onTap: interactive ? () => onStepTapped?.call(index) : null,
          spacing: verticalStepSpacing,
          connectorThickness: connectorThickness,
        );
      }),
    );
  }

  Widget _buildHorizontalLayout() {
    return Row(
      children: List.generate(steps.length * 2 - 1, (index) {
        if (index.isOdd) {
          // Connector line
          final stepIndex = index ~/ 2;
          final isCompleted = stepIndex < currentStep;
          return Expanded(
            child: Container(
              height: connectorThickness,
              color: isCompleted ? colors.semantic.success[500] : colors.neutral.n300,
            ),
          );
        }
        // Step indicator
        final stepIndex = index ~/ 2;
        return _HorizontalStepItem(
          step: steps[stepIndex],
          stepIndex: stepIndex,
          state: _getStepState(stepIndex),
          interactive: interactive,
          onTap: interactive ? () => onStepTapped?.call(stepIndex) : null,
        );
      }),
    );
  }
}

/// Internal widget for a vertical step item.
class _VerticalStepItem extends StatefulWidget {
  final SubZeroProgressStep step;
  final int stepIndex;
  final SubZeroStepState state;
  final bool isLast;
  final bool interactive;
  final VoidCallback? onTap;
  final double spacing;
  final double connectorThickness;

  const _VerticalStepItem({
    required this.step,
    required this.stepIndex,
    required this.state,
    required this.isLast,
    required this.interactive,
    this.onTap,
    required this.spacing,
    required this.connectorThickness,
  });

  @override
  State<_VerticalStepItem> createState() => _VerticalStepItemState();
}

class _VerticalStepItemState extends State<_VerticalStepItem> {
  bool _isHovered = false;
  bool _isFocused = false;

  @override
  Widget build(BuildContext context) {
    final indicatorSize = 28.0;
    final connectorHeight = widget.spacing;

    return Focus(
      onFocusChange: (focused) => setState(() => _isFocused = focused),
      onKeyEvent: (node, event) {
        if (widget.interactive &&
            event is KeyDownEvent &&
            (event.logicalKey == LogicalKeyboardKey.enter ||
                event.logicalKey == LogicalKeyboardKey.space)) {
          widget.onTap?.call();
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        cursor: widget.interactive ? SystemMouseCursors.click : SystemMouseCursors.basic,
        child: GestureDetector(
          onTap: widget.onTap,
          behavior: HitTestBehavior.opaque,
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Indicator column with connector
                SizedBox(
                  width: indicatorSize,
                  child: Column(
                    children: [
                      // Step indicator
                      _StepIndicator(
                        state: widget.state,
                        stepNumber: widget.stepIndex + 1,
                        icon: widget.step.icon,
                        size: indicatorSize,
                        isHovered: _isHovered && widget.interactive,
                        isFocused: _isFocused,
                      ),
                      // Connector line
                      if (!widget.isLast)
                        Expanded(
                          child: Container(
                            width: widget.connectorThickness,
                            constraints: BoxConstraints(minHeight: connectorHeight),
                            color: widget.state == SubZeroStepState.completed
                                ? colors.semantic.success[500]
                                : colors.neutral.n300,
                          ),
                        ),
                    ],
                  ),
                ),
                SizedBox(width: spacing.md),
                // Step content
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(
                      bottom: widget.isLast ? 0 : connectorHeight,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          widget.step.title,
                          style: typography.bodyLarge.style.copyWith(
                            color: widget.state == SubZeroStepState.pending
                                ? colors.text.secondary
                                : colors.text.primary,
                            fontWeight: widget.state == SubZeroStepState.current
                                ? typography.weight.semibold
                                : typography.weight.regular,
                          ),
                        ),
                        if (widget.step.subtitle != null) ...[
                          SizedBox(height: spacing.xs),
                          Text(
                            widget.step.subtitle!,
                            style: typography.bodySmall.style.copyWith(
                              color: colors.text.secondary,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Internal widget for a horizontal step item.
class _HorizontalStepItem extends StatefulWidget {
  final SubZeroProgressStep step;
  final int stepIndex;
  final SubZeroStepState state;
  final bool interactive;
  final VoidCallback? onTap;

  const _HorizontalStepItem({
    required this.step,
    required this.stepIndex,
    required this.state,
    required this.interactive,
    this.onTap,
  });

  @override
  State<_HorizontalStepItem> createState() => _HorizontalStepItemState();
}

class _HorizontalStepItemState extends State<_HorizontalStepItem> {
  bool _isHovered = false;
  bool _isFocused = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (focused) => setState(() => _isFocused = focused),
      onKeyEvent: (node, event) {
        if (widget.interactive &&
            event is KeyDownEvent &&
            (event.logicalKey == LogicalKeyboardKey.enter ||
                event.logicalKey == LogicalKeyboardKey.space)) {
          widget.onTap?.call();
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        cursor: widget.interactive ? SystemMouseCursors.click : SystemMouseCursors.basic,
        child: GestureDetector(
          onTap: widget.onTap,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _StepIndicator(
                state: widget.state,
                stepNumber: widget.stepIndex + 1,
                icon: widget.step.icon,
                size: 32,
                isHovered: _isHovered && widget.interactive,
                isFocused: _isFocused,
              ),
              SizedBox(height: spacing.sm),
              SizedBox(
                width: 80,
                child: Text(
                  widget.step.title,
                  style: typography.caption.style.copyWith(
                    color: widget.state == SubZeroStepState.pending
                        ? colors.text.secondary
                        : colors.text.primary,
                    fontWeight: widget.state == SubZeroStepState.current
                        ? typography.weight.semibold
                        : typography.weight.regular,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Internal widget for the step indicator (circle with icon/number).
class _StepIndicator extends StatelessWidget {
  final SubZeroStepState state;
  final int stepNumber;
  final IconData? icon;
  final double size;
  final bool isHovered;
  final bool isFocused;

  const _StepIndicator({
    required this.state,
    required this.stepNumber,
    this.icon,
    required this.size,
    this.isHovered = false,
    this.isFocused = false,
  });

  @override
  Widget build(BuildContext context) {
    Color backgroundColor;
    Color borderColor;
    Color contentColor;
    Widget content;

    switch (state) {
      case SubZeroStepState.completed:
        backgroundColor = colors.semantic.success[500];
        borderColor = colors.semantic.success[500];
        contentColor = colors.neutral.n0;
        content = Icon(Icons.check, size: size * 0.6, color: contentColor);
        break;
      case SubZeroStepState.current:
        backgroundColor = colors.primary[500];
        borderColor = colors.primary[500];
        contentColor = colors.neutral.n0;
        content = Icon(
          icon ?? Icons.play_arrow,
          size: size * 0.6,
          color: contentColor,
        );
        break;
      case SubZeroStepState.pending:
        backgroundColor = colors.neutral.n0;
        borderColor = colors.neutral.n400;
        contentColor = colors.text.secondary;
        content = Text(
          '$stepNumber',
          style: typography.bodySmall.style.copyWith(
            color: contentColor,
            fontWeight: typography.weight.medium,
          ),
        );
        break;
    }

    // Apply hover/focus effects
    if (isHovered || isFocused) {
      if (state == SubZeroStepState.completed) {
        backgroundColor = colors.semantic.success[700];
        borderColor = colors.semantic.success[700];
      } else if (state == SubZeroStepState.current) {
        backgroundColor = colors.primary[600];
        borderColor = colors.primary[600];
      } else {
        borderColor = colors.primary[500];
      }
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: backgroundColor,
        border: Border.all(color: borderColor, width: 2),
        boxShadow: isFocused
            ? [
                BoxShadow(
                  color: colors.primary[500].withValues(alpha: 0.3),
                  blurRadius: 0,
                  spreadRadius: 2,
                ),
              ]
            : null,
      ),
      child: Center(child: content),
    );
  }
}

/// Custom painter for the circular progress indicator.
class _CircleProgressPainter extends CustomPainter {
  final double progress;
  final Color backgroundColor;
  final Color progressColor;
  final double strokeWidth;

  _CircleProgressPainter({
    required this.progress,
    required this.backgroundColor,
    required this.progressColor,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;

    // Background circle
    final bgPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, bgPaint);

    // Progress arc
    final progressPaint = Paint()
      ..color = progressColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    final sweepAngle = 2 * math.pi * progress;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2, // Start from top
      sweepAngle,
      false,
      progressPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _CircleProgressPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.backgroundColor != backgroundColor ||
      oldDelegate.progressColor != progressColor ||
      oldDelegate.strokeWidth != strokeWidth;
}

/// A compact progress tracker that shows only indicators and connectors.
///
/// Useful for wizards and forms where space is limited.
class SubZeroCompactProgressTracker extends StatelessWidget {
  /// Total number of steps.
  final int totalSteps;

  /// Current active step index (0-based).
  final int currentStep;

  /// Size of each step indicator.
  final double indicatorSize;

  /// Whether steps are interactive.
  final bool interactive;

  /// Callback when a step is tapped.
  final ValueChanged<int>? onStepTapped;

  const SubZeroCompactProgressTracker({
    super.key,
    required this.totalSteps,
    required this.currentStep,
    this.indicatorSize = 24,
    this.interactive = false,
    this.onStepTapped,
  });

  SubZeroStepState _getStepState(int index) {
    if (index < currentStep) return SubZeroStepState.completed;
    if (index == currentStep) return SubZeroStepState.current;
    return SubZeroStepState.pending;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(totalSteps * 2 - 1, (index) {
        if (index.isOdd) {
          // Connector
          final stepIndex = index ~/ 2;
          final isCompleted = stepIndex < currentStep;
          return Container(
            width: 32,
            height: 2,
            color: isCompleted ? colors.semantic.success[500] : colors.neutral.n300,
          );
        }
        // Indicator
        final stepIndex = index ~/ 2;
        final state = _getStepState(stepIndex);
        return GestureDetector(
          onTap: interactive ? () => onStepTapped?.call(stepIndex) : null,
          child: MouseRegion(
            cursor: interactive ? SystemMouseCursors.click : SystemMouseCursors.basic,
            child: _StepIndicator(
              state: state,
              stepNumber: stepIndex + 1,
              size: indicatorSize,
            ),
          ),
        );
      }),
    );
  }
}

/// A linear progress bar alternative for progress tracking.
///
/// Shows progress as a continuous bar with step markers.
class SubZeroLinearProgressTracker extends StatelessWidget {
  /// Total number of steps.
  final int totalSteps;

  /// Current step (can be fractional for animated transitions).
  final double currentProgress;

  /// Height of the progress bar.
  final double height;

  /// Whether to show step labels.
  final bool showLabels;

  /// Step labels (optional).
  final List<String>? labels;

  const SubZeroLinearProgressTracker({
    super.key,
    required this.totalSteps,
    required this.currentProgress,
    this.height = 8,
    this.showLabels = true,
    this.labels,
  });

  @override
  Widget build(BuildContext context) {
    final progress = currentProgress / (totalSteps - 1);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Progress bar
        Container(
          height: height,
          decoration: BoxDecoration(
            color: colors.neutral.n200,
            borderRadius: BorderRadius.circular(height / 2),
          ),
          child: Stack(
            children: [
              // Progress fill
              FractionallySizedBox(
                widthFactor: progress.clamp(0.0, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: colors.primary[500],
                    borderRadius: BorderRadius.circular(height / 2),
                  ),
                ),
              ),
              // Step markers
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(totalSteps, (index) {
                  final isCompleted = index <= currentProgress;
                  return Container(
                    width: height + 4,
                    height: height,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isCompleted ? colors.primary[500] : colors.neutral.n300,
                      border: Border.all(
                        color: colors.neutral.n0,
                        width: 2,
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
        // Labels
        if (showLabels && labels != null && labels!.isNotEmpty) ...[
          SizedBox(height: spacing.sm),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: labels!.map((label) {
              return SizedBox(
                width: 60,
                child: Text(
                  label,
                  style: typography.caption.style.copyWith(
                    color: colors.text.secondary,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }
}
