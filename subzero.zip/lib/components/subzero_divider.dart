import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';

/// Orientation for the divider
enum SubZeroDividerOrientation { horizontal, vertical }

/// Visual variant of the divider
enum SubZeroDividerVariant {
  /// Thin line divider (1px default)
  line,
  /// Thick section divider/block (8px default)
  section,
}

/// A simple, standardized divider component for the SubZero Design System.
///
/// Used to visually separate content and establish clear sections in lists,
/// forms, and between UI sections.
///
/// Example usage:
/// ```dart
/// // Simple horizontal line divider
/// SubZeroDivider()
///
/// // Horizontal section divider (thicker)
/// SubZeroDivider(variant: SubZeroDividerVariant.section)
///
/// // Vertical line divider with custom height
/// SubZeroDivider(
///   orientation: SubZeroDividerOrientation.vertical,
///   length: 48,
/// )
///
/// // Custom color and thickness
/// SubZeroDivider(
///   thickness: 2,
///   color: Colors.red,
/// )
/// ```
class SubZeroDivider extends StatelessWidget {
  const SubZeroDivider({
    super.key,
    this.orientation = SubZeroDividerOrientation.horizontal,
    this.variant = SubZeroDividerVariant.line,
    this.thickness,
    this.length,
    this.color,
    this.indent = 0,
    this.endIndent = 0,
    this.margin,
  });

  /// The orientation of the divider (horizontal or vertical).
  final SubZeroDividerOrientation orientation;

  /// The visual variant of the divider.
  /// - [SubZeroDividerVariant.line]: Thin line (1px default)
  /// - [SubZeroDividerVariant.section]: Thick block (8px default)
  final SubZeroDividerVariant variant;

  /// The thickness of the divider. If null, defaults based on variant:
  /// - line: 1.0
  /// - section: 8.0
  final double? thickness;

  /// The extent of the divider in the main axis direction.
  /// - For horizontal: the width (defaults to double.infinity)
  /// - For vertical: the height (required for vertical dividers)
  final double? length;

  /// The color of the divider. Defaults to [SubZeroColors.divider] for line
  /// variant and [SubZeroColors.surfaceVariant] for section variant.
  final Color? color;

  /// The amount of empty space at the start of the divider (left for horizontal,
  /// top for vertical).
  final double indent;

  /// The amount of empty space at the end of the divider (right for horizontal,
  /// bottom for vertical).
  final double endIndent;

  /// Optional margin around the divider. If null, defaults based on orientation:
  /// - Horizontal: vertical margin of [SubZeroSpacing.xs] (4px)
  /// - Vertical: horizontal margin of [SubZeroSpacing.xs] (4px)
  final EdgeInsetsGeometry? margin;

  /// Returns the effective thickness based on variant
  double get _effectiveThickness {
    if (thickness != null) return thickness!;
    return switch (variant) {
      SubZeroDividerVariant.line => 1.0,
      SubZeroDividerVariant.section => 8.0,
    };
  }

  /// Returns the effective color based on variant
  Color get _effectiveColor {
    if (color != null) return color!;
    return switch (variant) {
      SubZeroDividerVariant.line => SubZeroColors.divider,
      SubZeroDividerVariant.section => SubZeroColors.surfaceVariant,
    };
  }

  /// Returns the effective margin based on orientation
  EdgeInsetsGeometry get _effectiveMargin {
    if (margin != null) return margin!;
    return switch (orientation) {
      SubZeroDividerOrientation.horizontal => const EdgeInsets.symmetric(
        vertical: SubZeroSpacing.xs,
      ),
      SubZeroDividerOrientation.vertical => const EdgeInsets.symmetric(
        horizontal: SubZeroSpacing.xs,
      ),
    };
  }

  @override
  Widget build(BuildContext context) {
    final dividerWidget = switch (orientation) {
      SubZeroDividerOrientation.horizontal => _buildHorizontalDivider(),
      SubZeroDividerOrientation.vertical => _buildVerticalDivider(),
    };

    return Padding(padding: _effectiveMargin, child: dividerWidget);
  }

  Widget _buildHorizontalDivider() {
    return Row(
      children: [
        if (indent > 0) SizedBox(width: indent),
        Expanded(
          child: Container(
            width: length,
            height: _effectiveThickness,
            decoration: BoxDecoration(
              color: _effectiveColor,
              borderRadius: variant == SubZeroDividerVariant.section
                  ? BorderRadius.circular(2)
                  : null,
            ),
          ),
        ),
        if (endIndent > 0) SizedBox(width: endIndent),
      ],
    );
  }

  Widget _buildVerticalDivider() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (indent > 0) SizedBox(height: indent),
        Container(
          width: _effectiveThickness,
          height: length ?? 24, // Default height for vertical divider
          decoration: BoxDecoration(
            color: _effectiveColor,
            borderRadius: variant == SubZeroDividerVariant.section
                ? BorderRadius.circular(2)
                : null,
          ),
        ),
        if (endIndent > 0) SizedBox(height: endIndent),
      ],
    );
  }
}

/// A convenience widget for creating horizontal line dividers.
class SubZeroHorizontalDivider extends StatelessWidget {
  const SubZeroHorizontalDivider({
    super.key,
    this.variant = SubZeroDividerVariant.line,
    this.thickness,
    this.color,
    this.indent = 0,
    this.endIndent = 0,
    this.margin,
  });

  final SubZeroDividerVariant variant;
  final double? thickness;
  final Color? color;
  final double indent;
  final double endIndent;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) => SubZeroDivider(
    orientation: SubZeroDividerOrientation.horizontal,
    variant: variant,
    thickness: thickness,
    color: color,
    indent: indent,
    endIndent: endIndent,
    margin: margin,
  );
}

/// A convenience widget for creating vertical line dividers.
class SubZeroVerticalDivider extends StatelessWidget {
  const SubZeroVerticalDivider({
    super.key,
    this.variant = SubZeroDividerVariant.line,
    this.thickness,
    this.length,
    this.color,
    this.indent = 0,
    this.endIndent = 0,
    this.margin,
  });

  final SubZeroDividerVariant variant;
  final double? thickness;
  final double? length;
  final Color? color;
  final double indent;
  final double endIndent;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) => SubZeroDivider(
    orientation: SubZeroDividerOrientation.vertical,
    variant: variant,
    thickness: thickness,
    length: length,
    color: color,
    indent: indent,
    endIndent: endIndent,
    margin: margin,
  );
}
