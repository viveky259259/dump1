import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/tokens.dart';

/// Tag type determines the behavior and visual style of the tag.
enum SubZeroTagType {
  /// Non-interactive tag for displaying status or labels.
  display,

  /// Interactive tag that can be selected/unselected for filtering.
  filter,
}

/// Tag variant determines the visual appearance based on state.
enum SubZeroTagVariant {
  /// Default outlined style - white background with border.
  outlined,

  /// Filled/selected style - primary color background.
  filled,

  /// Disabled style - light gray background, non-interactive.
  disabled,
}

/// Status-based color options for semantic tagging.
enum SubZeroTagStatus {
  /// Default/neutral status using primary colors.
  neutral,

  /// Success status - green tones.
  success,

  /// Warning status - orange/amber tones.
  warning,

  /// Error status - red tones.
  error,

  /// Info status - blue tones.
  info,
}

/// Size variants for the tag component.
enum SubZeroTagSize {
  /// Small tag (24px height).
  small,

  /// Medium tag (32px height) - default.
  medium,

  /// Large tag (40px height).
  large,
}

/// {@template subzero_tag}
/// A pill-shaped tag/chip component following SubZero 2.0 Design System.
///
/// Tags are used for categorization, filtering, or displaying status information.
/// They come in two primary types:
/// - **Display/Status Tag**: Non-interactive, for labeling or showing status.
/// - **Input/Filter Tag**: Interactive, can be selected/unselected or dismissed.
///
/// ## Example
/// ```dart
/// // Simple display tag
/// SubZeroTag(label: 'Completed', status: SubZeroTagStatus.success)
///
/// // Selectable filter tag
/// SubZeroTag(
///   label: 'Category',
///   type: SubZeroTagType.filter,
///   isSelected: _isSelected,
///   onTap: () => setState(() => _isSelected = !_isSelected),
/// )
///
/// // Removable tag
/// SubZeroTag(
///   label: 'Tag Name',
///   type: SubZeroTagType.filter,
///   removable: true,
///   onRemove: () => _removeTag(),
/// )
/// ```
/// {@endtemplate}
class SubZeroTag extends StatefulWidget {
  /// {@macro subzero_tag}
  const SubZeroTag({
    super.key,
    required this.label,
    this.type = SubZeroTagType.display,
    this.variant,
    this.status = SubZeroTagStatus.neutral,
    this.size = SubZeroTagSize.medium,
    this.isSelected = false,
    this.isEnabled = true,
    this.removable = false,
    this.leadingIcon,
    this.onTap,
    this.onRemove,
  });

  /// The text label displayed inside the tag.
  final String label;

  /// The type of tag - display (non-interactive) or filter (interactive).
  final SubZeroTagType type;

  /// Explicit variant override. If null, variant is derived from state.
  final SubZeroTagVariant? variant;

  /// Status-based coloring for semantic meaning.
  final SubZeroTagStatus status;

  /// Size of the tag (small, medium, large).
  final SubZeroTagSize size;

  /// Whether the tag is currently selected (for filter tags).
  final bool isSelected;

  /// Whether the tag is enabled for interaction.
  final bool isEnabled;

  /// Whether the tag shows a remove/dismiss icon.
  final bool removable;

  /// Optional leading icon displayed before the label.
  final IconData? leadingIcon;

  /// Callback when the tag is tapped (for filter tags).
  final VoidCallback? onTap;

  /// Callback when the remove icon is tapped.
  final VoidCallback? onRemove;

  @override
  State<SubZeroTag> createState() => _SubZeroTagState();
}

class _SubZeroTagState extends State<SubZeroTag> {
  bool _isHovered = false;
  bool _isFocused = false;
  bool _isPressed = false;

  SubZeroTagVariant get _effectiveVariant {
    if (widget.variant != null) return widget.variant!;
    if (!widget.isEnabled) return SubZeroTagVariant.disabled;
    if (widget.isSelected) return SubZeroTagVariant.filled;
    return SubZeroTagVariant.outlined;
  }

  bool get _isInteractive =>
      widget.type == SubZeroTagType.filter && widget.isEnabled;

  // Size configurations
  double get _height => switch (widget.size) {
        SubZeroTagSize.small => 24.0,
        SubZeroTagSize.medium => 32.0,
        SubZeroTagSize.large => 40.0,
      };

  double get _horizontalPadding => switch (widget.size) {
        SubZeroTagSize.small => spacing.sm,
        SubZeroTagSize.medium => spacing.md,
        SubZeroTagSize.large => spacing.lg,
      };

  double get _fontSize => switch (widget.size) {
        SubZeroTagSize.small => 11.0,
        SubZeroTagSize.medium => 13.0,
        SubZeroTagSize.large => 15.0,
      };

  double get _iconSize => switch (widget.size) {
        SubZeroTagSize.small => 14.0,
        SubZeroTagSize.medium => 16.0,
        SubZeroTagSize.large => 18.0,
      };

  // Status-based colors
  Color get _statusColor => switch (widget.status) {
        SubZeroTagStatus.neutral => colors.primary[500],
        SubZeroTagStatus.success => colors.semantic.success[500],
        SubZeroTagStatus.warning => colors.semantic.warning[500],
        SubZeroTagStatus.error => colors.semantic.error[500],
        SubZeroTagStatus.info => colors.semantic.info[500],
      };

  // Variant-based styling
  Color get _backgroundColor {
    final variant = _effectiveVariant;
    switch (variant) {
      case SubZeroTagVariant.outlined:
        if (_isPressed) return colors.neutral.n100;
        if (_isHovered) return colors.neutral.n50;
        return colors.neutral.n0;
      case SubZeroTagVariant.filled:
        if (_isPressed) {
          return widget.status == SubZeroTagStatus.neutral
              ? colors.primary[700]
              : _statusColor.withValues(alpha: 0.8);
        }
        if (_isHovered) {
          return widget.status == SubZeroTagStatus.neutral
              ? colors.primary[600]
              : _statusColor.withValues(alpha: 0.9);
        }
        return _statusColor;
      case SubZeroTagVariant.disabled:
        return colors.neutral.n200;
    }
  }

  Color get _textColor {
    final variant = _effectiveVariant;
    switch (variant) {
      case SubZeroTagVariant.outlined:
        return colors.text.primary;
      case SubZeroTagVariant.filled:
        return colors.text.inverse;
      case SubZeroTagVariant.disabled:
        return colors.text.disabled;
    }
  }

  Color get _borderColor {
    final variant = _effectiveVariant;
    switch (variant) {
      case SubZeroTagVariant.outlined:
        if (_isFocused) return _statusColor;
        if (_isHovered) return colors.neutral.n400;
        return colors.neutral.n300;
      case SubZeroTagVariant.filled:
        return Colors.transparent;
      case SubZeroTagVariant.disabled:
        return colors.neutral.n300;
    }
  }

  void _handleTap() {
    if (!_isInteractive) return;
    widget.onTap?.call();
  }

  void _handleRemove() {
    if (!widget.isEnabled) return;
    widget.onRemove?.call();
  }

  @override
  Widget build(BuildContext context) {
    final tagContent = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      height: _height,
      padding: EdgeInsets.symmetric(horizontal: _horizontalPadding),
      decoration: BoxDecoration(
        color: _backgroundColor,
        borderRadius: BorderRadius.circular(radius.full),
        border: Border.all(color: _borderColor, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Leading icon
          if (widget.leadingIcon != null) ...[
            Icon(
              widget.leadingIcon,
              size: _iconSize,
              color: _textColor,
            ),
            SizedBox(width: spacing.xs),
          ],
          // Label
          Text(
            widget.label,
            style: TextStyle(
              fontFamily: typography.fontFamily.primary,
              fontSize: _fontSize,
              fontWeight: typography.weight.medium,
              color: _textColor,
              height: 1.2,
            ),
          ),
          // Remove icon
          if (widget.removable && widget.isEnabled) ...[
            SizedBox(width: spacing.xs),
            GestureDetector(
              onTap: _handleRemove,
              child: MouseRegion(
                cursor: SystemMouseCursors.click,
                child: Icon(
                  Icons.close,
                  size: _iconSize,
                  color: _textColor.withValues(alpha: 0.7),
                ),
              ),
            ),
          ],
        ],
      ),
    );

    // Non-interactive display tag
    if (!_isInteractive && !widget.removable) {
      return tagContent;
    }

    // Interactive filter tag
    return Focus(
      onFocusChange: (focused) => setState(() => _isFocused = focused),
      onKeyEvent: (node, event) {
        if (event is KeyDownEvent &&
            (event.logicalKey == LogicalKeyboardKey.enter ||
                event.logicalKey == LogicalKeyboardKey.space)) {
          _handleTap();
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: MouseRegion(
        cursor:
            _isInteractive ? SystemMouseCursors.click : SystemMouseCursors.basic,
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTapDown: (_) => setState(() => _isPressed = true),
          onTapUp: (_) => setState(() => _isPressed = false),
          onTapCancel: () => setState(() => _isPressed = false),
          onTap: _handleTap,
          child: tagContent,
        ),
      ),
    );
  }
}

/// {@template subzero_tag_group}
/// A container for managing a group of filter tags with single or multi-select behavior.
///
/// ## Example
/// ```dart
/// SubZeroTagGroup<String>(
///   tags: ['Option 1', 'Option 2', 'Option 3'],
///   selectedTags: _selectedTags,
///   onSelectionChanged: (selected) => setState(() => _selectedTags = selected),
///   labelBuilder: (tag) => tag,
/// )
/// ```
/// {@endtemplate}
class SubZeroTagGroup<T> extends StatelessWidget {
  /// {@macro subzero_tag_group}
  const SubZeroTagGroup({
    super.key,
    required this.tags,
    required this.selectedTags,
    required this.onSelectionChanged,
    required this.labelBuilder,
    this.multiSelect = true,
    this.size = SubZeroTagSize.medium,
    this.status = SubZeroTagStatus.neutral,
    this.removable = false,
    this.onRemove,
    this.spacing = 8.0,
    this.runSpacing = 8.0,
  });

  /// List of all available tag values.
  final List<T> tags;

  /// Set of currently selected tag values.
  final Set<T> selectedTags;

  /// Callback when selection changes.
  final ValueChanged<Set<T>> onSelectionChanged;

  /// Builder function to convert tag value to display label.
  final String Function(T tag) labelBuilder;

  /// Whether multiple tags can be selected simultaneously.
  final bool multiSelect;

  /// Size of all tags in the group.
  final SubZeroTagSize size;

  /// Status coloring for all tags.
  final SubZeroTagStatus status;

  /// Whether tags can be removed from the group.
  final bool removable;

  /// Callback when a tag is removed.
  final ValueChanged<T>? onRemove;

  /// Horizontal spacing between tags.
  final double spacing;

  /// Vertical spacing between tag rows.
  final double runSpacing;

  void _handleTagTap(T tag) {
    final newSelection = Set<T>.from(selectedTags);
    if (multiSelect) {
      if (newSelection.contains(tag)) {
        newSelection.remove(tag);
      } else {
        newSelection.add(tag);
      }
    } else {
      if (newSelection.contains(tag)) {
        newSelection.clear();
      } else {
        newSelection
          ..clear()
          ..add(tag);
      }
    }
    onSelectionChanged(newSelection);
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: spacing,
      runSpacing: runSpacing,
      children: tags.map((tag) {
        final isSelected = selectedTags.contains(tag);
        return SubZeroTag(
          label: labelBuilder(tag),
          type: SubZeroTagType.filter,
          size: size,
          status: status,
          isSelected: isSelected,
          removable: removable,
          onTap: () => _handleTagTap(tag),
          onRemove: removable ? () => onRemove?.call(tag) : null,
        );
      }).toList(),
    );
  }
}

/// {@template subzero_status_tag}
/// A specialized display tag for showing status with predefined styling.
///
/// ## Example
/// ```dart
/// SubZeroStatusTag.success(label: 'Completed')
/// SubZeroStatusTag.error(label: 'Failed')
/// SubZeroStatusTag.warning(label: 'Pending')
/// SubZeroStatusTag.info(label: 'In Progress')
/// ```
/// {@endtemplate}
class SubZeroStatusTag extends StatelessWidget {
  /// {@macro subzero_status_tag}
  const SubZeroStatusTag({
    super.key,
    required this.label,
    required this.status,
    this.size = SubZeroTagSize.medium,
    this.icon,
    this.filled = true,
  });

  /// Creates a success status tag.
  const SubZeroStatusTag.success({
    super.key,
    required this.label,
    this.size = SubZeroTagSize.medium,
    this.icon,
    this.filled = true,
  }) : status = SubZeroTagStatus.success;

  /// Creates a warning status tag.
  const SubZeroStatusTag.warning({
    super.key,
    required this.label,
    this.size = SubZeroTagSize.medium,
    this.icon,
    this.filled = true,
  }) : status = SubZeroTagStatus.warning;

  /// Creates an error status tag.
  const SubZeroStatusTag.error({
    super.key,
    required this.label,
    this.size = SubZeroTagSize.medium,
    this.icon,
    this.filled = true,
  }) : status = SubZeroTagStatus.error;

  /// Creates an info status tag.
  const SubZeroStatusTag.info({
    super.key,
    required this.label,
    this.size = SubZeroTagSize.medium,
    this.icon,
    this.filled = true,
  }) : status = SubZeroTagStatus.info;

  /// The label text.
  final String label;

  /// The status type.
  final SubZeroTagStatus status;

  /// Size of the tag.
  final SubZeroTagSize size;

  /// Optional leading icon.
  final IconData? icon;

  /// Whether to use filled style (true) or outlined style (false).
  final bool filled;

  @override
  Widget build(BuildContext context) => SubZeroTag(
        label: label,
        type: SubZeroTagType.display,
        variant: filled ? SubZeroTagVariant.filled : SubZeroTagVariant.outlined,
        status: status,
        size: size,
        leadingIcon: icon,
      );
}

/// {@template subzero_removable_tag_input}
/// An input field with removable tags, commonly used for multi-value inputs like email recipients.
///
/// ## Example
/// ```dart
/// SubZeroRemovableTagInput(
///   tags: _tags,
///   onTagAdded: (tag) => setState(() => _tags.add(tag)),
///   onTagRemoved: (tag) => setState(() => _tags.remove(tag)),
///   hintText: 'Add tags...',
/// )
/// ```
/// {@endtemplate}
class SubZeroRemovableTagInput extends StatefulWidget {
  /// {@macro subzero_removable_tag_input}
  const SubZeroRemovableTagInput({
    super.key,
    required this.tags,
    required this.onTagAdded,
    required this.onTagRemoved,
    this.hintText = 'Add tag...',
    this.size = SubZeroTagSize.medium,
    this.status = SubZeroTagStatus.neutral,
    this.validator,
    this.maxTags,
  });

  /// Current list of tags.
  final List<String> tags;

  /// Callback when a new tag is added.
  final ValueChanged<String> onTagAdded;

  /// Callback when a tag is removed.
  final ValueChanged<String> onTagRemoved;

  /// Placeholder text for the input field.
  final String hintText;

  /// Size of the tags.
  final SubZeroTagSize size;

  /// Status coloring for tags.
  final SubZeroTagStatus status;

  /// Optional validator for new tags.
  final String? Function(String)? validator;

  /// Maximum number of tags allowed.
  final int? maxTags;

  @override
  State<SubZeroRemovableTagInput> createState() =>
      _SubZeroRemovableTagInputState();
}

class _SubZeroRemovableTagInputState extends State<SubZeroRemovableTagInput> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  String? _errorText;

  bool get _canAddMore =>
      widget.maxTags == null || widget.tags.length < widget.maxTags!;

  void _addTag(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return;

    // Validate
    if (widget.validator != null) {
      final error = widget.validator!(trimmed);
      if (error != null) {
        setState(() => _errorText = error);
        return;
      }
    }

    // Check for duplicates
    if (widget.tags.contains(trimmed)) {
      setState(() => _errorText = 'Tag already exists');
      return;
    }

    // Check max tags
    if (!_canAddMore) {
      setState(() => _errorText = 'Maximum tags reached');
      return;
    }

    setState(() => _errorText = null);
    widget.onTagAdded(trimmed);
    _controller.clear();
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: EdgeInsets.all(spacing.sm),
          decoration: BoxDecoration(
            color: colors.neutral.n0,
            borderRadius: radius.mdCircular,
            border: Border.all(
              color: _errorText != null
                  ? colors.semantic.error[500]
                  : colors.neutral.n300,
            ),
          ),
          child: Wrap(
            spacing: spacing.xs,
            runSpacing: spacing.xs,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              // Existing tags
              ...widget.tags.map(
                (tag) => SubZeroTag(
                  label: tag,
                  type: SubZeroTagType.filter,
                  size: widget.size,
                  status: widget.status,
                  isSelected: true,
                  removable: true,
                  onRemove: () => widget.onTagRemoved(tag),
                ),
              ),
              // Input field
              if (_canAddMore)
                SizedBox(
                  width: 120,
                  child: TextField(
                    controller: _controller,
                    focusNode: _focusNode,
                    style: TextStyle(
                      fontSize: 13,
                      fontFamily: typography.fontFamily.primary,
                      color: colors.text.primary,
                    ),
                    decoration: InputDecoration(
                      hintText: widget.hintText,
                      hintStyle: TextStyle(color: colors.text.disabled),
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(
                        vertical: spacing.xs,
                        horizontal: spacing.xs,
                      ),
                    ),
                    onSubmitted: _addTag,
                    onChanged: (_) {
                      if (_errorText != null) {
                        setState(() => _errorText = null);
                      }
                    },
                  ),
                ),
            ],
          ),
        ),
        // Error message
        if (_errorText != null)
          Padding(
            padding: EdgeInsets.only(top: spacing.xs, left: spacing.xs),
            child: Text(
              _errorText!,
              style: TextStyle(
                fontSize: 12,
                color: colors.semantic.error[500],
                fontFamily: typography.fontFamily.primary,
              ),
            ),
          ),
      ],
    );
  }
}
