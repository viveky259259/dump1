import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/tokens.dart';

/// SubZero Slider Component
///
/// A customizable slider that allows users to select a value from a continuous
/// or discrete range by moving a thumb along a track.
///
/// Features:
/// - Continuous and discrete (stepped) modes
/// - Value tooltip that appears when dragging
/// - Optional min/max labels
/// - Keyboard accessibility (arrow keys, Home/End)
/// - Follows SubZero 2.0 Design System
///
/// Example:
/// ```dart
/// SubZeroSlider(
///   value: _currentValue,
///   min: 0,
///   max: 100,
///   onChanged: (value) => setState(() => _currentValue = value),
/// )
/// ```
class SubZeroSlider extends StatefulWidget {
  /// The current value of the slider.
  final double value;

  /// The minimum value the user can select.
  final double min;

  /// The maximum value the user can select.
  final double max;

  /// The number of discrete divisions. If null, the slider is continuous.
  final int? divisions;

  /// Called when the user changes the slider value.
  final ValueChanged<double>? onChanged;

  /// Called when the user starts dragging the slider.
  final ValueChanged<double>? onChangeStart;

  /// Called when the user stops dragging the slider.
  final ValueChanged<double>? onChangeEnd;

  /// Whether to show the value tooltip when dragging.
  final bool showTooltip;

  /// Whether to show tick marks for discrete sliders.
  final bool showTickMarks;

  /// Custom formatter for the tooltip value.
  final String Function(double)? valueFormatter;

  /// Label displayed at the minimum end of the slider.
  final String? minLabel;

  /// Label displayed at the maximum end of the slider.
  final String? maxLabel;

  /// Whether the slider is enabled.
  final bool enabled;

  /// Color of the active (filled) portion of the track.
  final Color? activeTrackColor;

  /// Color of the inactive (unfilled) portion of the track.
  final Color? inactiveTrackColor;

  /// Color of the thumb.
  final Color? thumbColor;

  /// Height of the track.
  final double trackHeight;

  /// Radius of the thumb.
  final double thumbRadius;

  const SubZeroSlider({
    super.key,
    required this.value,
    this.min = 0.0,
    this.max = 1.0,
    this.divisions,
    this.onChanged,
    this.onChangeStart,
    this.onChangeEnd,
    this.showTooltip = true,
    this.showTickMarks = false,
    this.valueFormatter,
    this.minLabel,
    this.maxLabel,
    this.enabled = true,
    this.activeTrackColor,
    this.inactiveTrackColor,
    this.thumbColor,
    this.trackHeight = 4.0,
    this.thumbRadius = 12.0,
  }) : assert(min <= max, 'min must be less than or equal to max'),
       assert(value >= min && value <= max, 'value must be between min and max');

  @override
  State<SubZeroSlider> createState() => _SubZeroSliderState();
}

class _SubZeroSliderState extends State<SubZeroSlider>
    with SingleTickerProviderStateMixin {
  late AnimationController _tooltipController;
  late Animation<double> _tooltipAnimation;
  bool _isDragging = false;
  bool _isFocused = false;
  bool _isHovered = false;
  double _currentValue = 0;

  final FocusNode _focusNode = FocusNode();
  final GlobalKey _sliderKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _currentValue = widget.value;
    _tooltipController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _tooltipAnimation = CurvedAnimation(
      parent: _tooltipController,
      curve: Curves.easeOut,
    );
    _focusNode.addListener(_handleFocusChange);
  }

  @override
  void didUpdateWidget(SubZeroSlider oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.value != oldWidget.value && !_isDragging) {
      _currentValue = widget.value;
    }
  }

  @override
  void dispose() {
    _tooltipController.dispose();
    _focusNode.removeListener(_handleFocusChange);
    _focusNode.dispose();
    super.dispose();
  }

  void _handleFocusChange() {
    setState(() => _isFocused = _focusNode.hasFocus);
  }

  double get _normalizedValue => (_currentValue - widget.min) / (widget.max - widget.min);

  Color get _activeColor => widget.activeTrackColor ?? colors.primary[500];
  Color get _inactiveColor => widget.inactiveTrackColor ?? colors.neutral.n300;
  Color get _effectiveThumbColor => widget.thumbColor ?? colors.primary[500];

  String _formatValue(double value) {
    if (widget.valueFormatter != null) {
      return widget.valueFormatter!(value);
    }
    if (widget.divisions != null) {
      return value.round().toString();
    }
    return value.toStringAsFixed(1);
  }

  double _snapToStep(double value) {
    if (widget.divisions == null) return value;
    final step = (widget.max - widget.min) / widget.divisions!;
    final snapped = (value / step).round() * step;
    return snapped.clamp(widget.min, widget.max);
  }

  void _updateValue(double localX, double width) {
    if (!widget.enabled || widget.onChanged == null) return;

    final trackWidth = width - widget.thumbRadius * 2;
    final thumbPosition = localX - widget.thumbRadius;
    final normalized = (thumbPosition / trackWidth).clamp(0.0, 1.0);
    var newValue = widget.min + normalized * (widget.max - widget.min);
    newValue = _snapToStep(newValue);

    if (newValue != _currentValue) {
      setState(() => _currentValue = newValue);
      widget.onChanged?.call(newValue);
    }
  }

  void _handleKeyEvent(KeyEvent event) {
    if (!widget.enabled || widget.onChanged == null) return;
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) return;

    double step = widget.divisions != null
        ? (widget.max - widget.min) / widget.divisions!
        : (widget.max - widget.min) / 100;

    double newValue = _currentValue;

    if (event.logicalKey == LogicalKeyboardKey.arrowRight ||
        event.logicalKey == LogicalKeyboardKey.arrowUp) {
      newValue = (_currentValue + step).clamp(widget.min, widget.max);
    } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft ||
        event.logicalKey == LogicalKeyboardKey.arrowDown) {
      newValue = (_currentValue - step).clamp(widget.min, widget.max);
    } else if (event.logicalKey == LogicalKeyboardKey.home) {
      newValue = widget.min;
    } else if (event.logicalKey == LogicalKeyboardKey.end) {
      newValue = widget.max;
    }

    if (newValue != _currentValue) {
      setState(() => _currentValue = newValue);
      widget.onChanged?.call(newValue);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasLabels = widget.minLabel != null || widget.maxLabel != null;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        KeyboardListener(
          focusNode: _focusNode,
          onKeyEvent: _handleKeyEvent,
          child: MouseRegion(
            onEnter: (_) => setState(() => _isHovered = true),
            onExit: (_) => setState(() => _isHovered = false),
            cursor: widget.enabled
                ? SystemMouseCursors.grab
                : SystemMouseCursors.forbidden,
            child: GestureDetector(
              onHorizontalDragStart: widget.enabled ? _onDragStart : null,
              onHorizontalDragUpdate: widget.enabled ? _onDragUpdate : null,
              onHorizontalDragEnd: widget.enabled ? _onDragEnd : null,
              onTapDown: widget.enabled ? _onTapDown : null,
              child: Semantics(
                slider: true,
                value: _formatValue(_currentValue),
                increasedValue: _formatValue(
                  (_currentValue + (widget.max - widget.min) / 10)
                      .clamp(widget.min, widget.max),
                ),
                decreasedValue: _formatValue(
                  (_currentValue - (widget.max - widget.min) / 10)
                      .clamp(widget.min, widget.max),
                ),
                enabled: widget.enabled,
                child: LayoutBuilder(
                  key: _sliderKey,
                  builder: (context, constraints) {
                    final width = constraints.maxWidth;
                    return SizedBox(
                      height: widget.thumbRadius * 2 + 40, // Extra space for tooltip
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          // Track
                          Positioned(
                            left: widget.thumbRadius,
                            right: widget.thumbRadius,
                            top: widget.thumbRadius - widget.trackHeight / 2 + 20,
                            child: _buildTrack(width - widget.thumbRadius * 2),
                          ),
                          // Tick marks (for discrete mode)
                          if (widget.showTickMarks && widget.divisions != null)
                            Positioned(
                              left: widget.thumbRadius,
                              right: widget.thumbRadius,
                              top: widget.thumbRadius - widget.trackHeight / 2 + 20,
                              child: _buildTickMarks(width - widget.thumbRadius * 2),
                            ),
                          // Thumb
                          Positioned(
                            left: widget.thumbRadius +
                                _normalizedValue * (width - widget.thumbRadius * 2) -
                                widget.thumbRadius,
                            top: 20,
                            child: _buildThumb(),
                          ),
                          // Tooltip
                          if (widget.showTooltip)
                            Positioned(
                              left: widget.thumbRadius +
                                  _normalizedValue * (width - widget.thumbRadius * 2) -
                                  30, // Half of tooltip width
                              top: 0,
                              child: FadeTransition(
                                opacity: _tooltipAnimation,
                                child: _buildTooltip(),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ),
        // Min/Max labels
        if (hasLabels)
          Padding(
            padding: EdgeInsets.only(
              left: widget.thumbRadius,
              right: widget.thumbRadius,
              top: spacing.xs,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (widget.minLabel != null)
                  Text(
                    widget.minLabel!,
                    style: typography.bodySmall.style.copyWith(
                      color: widget.enabled
                          ? colors.text.secondary
                          : colors.text.disabled,
                    ),
                  )
                else
                  const SizedBox.shrink(),
                if (widget.maxLabel != null)
                  Text(
                    widget.maxLabel!,
                    style: typography.bodySmall.style.copyWith(
                      color: widget.enabled
                          ? colors.text.secondary
                          : colors.text.disabled,
                    ),
                  )
                else
                  const SizedBox.shrink(),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildTrack(double trackWidth) {
    final activeWidth = _normalizedValue * trackWidth;

    return SizedBox(
      height: widget.trackHeight,
      child: Stack(
        children: [
          // Inactive track (full width)
          Container(
            width: trackWidth,
            height: widget.trackHeight,
            decoration: BoxDecoration(
              color: widget.enabled
                  ? _inactiveColor
                  : _inactiveColor.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(widget.trackHeight / 2),
            ),
          ),
          // Active track
          Container(
            width: activeWidth,
            height: widget.trackHeight,
            decoration: BoxDecoration(
              color: widget.enabled
                  ? _activeColor
                  : _activeColor.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(widget.trackHeight / 2),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTickMarks(double trackWidth) {
    if (widget.divisions == null) return const SizedBox.shrink();

    return SizedBox(
      height: widget.trackHeight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(widget.divisions! + 1, (index) {
          final tickNormalized = index / widget.divisions!;
          final isActive = tickNormalized <= _normalizedValue;
          return Container(
            width: 2,
            height: widget.trackHeight + 4,
            decoration: BoxDecoration(
              color: isActive
                  ? _activeColor.withValues(alpha: 0.7)
                  : _inactiveColor.withValues(alpha: 0.7),
              borderRadius: BorderRadius.circular(1),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildThumb() {
    final showGlow = _isDragging || _isFocused || _isHovered;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 100),
      width: widget.thumbRadius * 2,
      height: widget.thumbRadius * 2,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: colors.neutral.n0,
        border: Border.all(
          color: widget.enabled
              ? _effectiveThumbColor
              : _effectiveThumbColor.withValues(alpha: 0.5),
          width: 2,
        ),
        boxShadow: [
          // Outer glow when active (matching Figma)
          if (showGlow && widget.enabled)
            BoxShadow(
              color: _effectiveThumbColor.withValues(alpha: 0.25),
              blurRadius: 12,
              spreadRadius: 4,
            ),
          // Base shadow
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          width: widget.thumbRadius - 4,
          height: widget.thumbRadius - 4,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.enabled
                ? _effectiveThumbColor
                : _effectiveThumbColor.withValues(alpha: 0.5),
          ),
        ),
      ),
    );
  }

  Widget _buildTooltip() {
    return Container(
      width: 60,
      padding: EdgeInsets.symmetric(
        horizontal: spacing.sm,
        vertical: spacing.xs,
      ),
      decoration: BoxDecoration(
        color: colors.neutral.n900,
        borderRadius: radius.smCircular,
        boxShadow: elevation.e2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            _formatValue(_currentValue),
            style: typography.bodySmall.style.copyWith(
              color: colors.text.inverse,
              fontWeight: typography.weight.medium,
            ),
            textAlign: TextAlign.center,
          ),
          // Arrow pointer
          CustomPaint(
            size: const Size(12, 6),
            painter: _TooltipArrowPainter(color: colors.neutral.n900),
          ),
        ],
      ),
    );
  }

  void _onDragStart(DragStartDetails details) {
    setState(() => _isDragging = true);
    _tooltipController.forward();
    widget.onChangeStart?.call(_currentValue);
  }

  void _onDragUpdate(DragUpdateDetails details) {
    final renderBox = _sliderKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox != null) {
      final localPosition = renderBox.globalToLocal(details.globalPosition);
      _updateValue(localPosition.dx, renderBox.size.width);
    }
  }

  void _onDragEnd(DragEndDetails details) {
    setState(() => _isDragging = false);
    _tooltipController.reverse();
    widget.onChangeEnd?.call(_currentValue);
  }

  void _onTapDown(TapDownDetails details) {
    final renderBox = _sliderKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox != null) {
      final localPosition = renderBox.globalToLocal(details.globalPosition);
      _updateValue(localPosition.dx, renderBox.size.width);
    }
    _focusNode.requestFocus();
  }
}

/// Custom painter for the tooltip arrow
class _TooltipArrowPainter extends CustomPainter {
  final Color color;

  _TooltipArrowPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width / 2, size.height)
      ..lineTo(size.width, 0)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _TooltipArrowPainter oldDelegate) =>
      color != oldDelegate.color;
}

/// A labeled slider with value display
///
/// Example:
/// ```dart
/// SubZeroLabeledSlider(
///   label: 'Volume',
///   value: _volume,
///   min: 0,
///   max: 100,
///   suffix: '%',
///   onChanged: (value) => setState(() => _volume = value),
/// )
/// ```
class SubZeroLabeledSlider extends StatelessWidget {
  /// The label displayed above the slider.
  final String label;

  /// The current value of the slider.
  final double value;

  /// The minimum value.
  final double min;

  /// The maximum value.
  final double max;

  /// The number of discrete divisions.
  final int? divisions;

  /// Called when the value changes.
  final ValueChanged<double>? onChanged;

  /// Suffix to append to the value display (e.g., '%', 'px').
  final String? suffix;

  /// Prefix to prepend to the value display (e.g., '$').
  final String? prefix;

  /// Custom formatter for the value.
  final String Function(double)? valueFormatter;

  /// Whether the slider is enabled.
  final bool enabled;

  const SubZeroLabeledSlider({
    super.key,
    required this.label,
    required this.value,
    this.min = 0.0,
    this.max = 1.0,
    this.divisions,
    this.onChanged,
    this.suffix,
    this.prefix,
    this.valueFormatter,
    this.enabled = true,
  });

  String _formatDisplayValue() {
    if (valueFormatter != null) return valueFormatter!(value);
    final valueStr = divisions != null ? value.round().toString() : value.toStringAsFixed(1);
    return '${prefix ?? ''}$valueStr${suffix ?? ''}';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: typography.bodyMedium.style.copyWith(
                color: enabled ? colors.text.primary : colors.text.disabled,
                fontWeight: typography.weight.medium,
              ),
            ),
            Text(
              _formatDisplayValue(),
              style: typography.bodyMedium.style.copyWith(
                color: enabled ? colors.primary[500] : colors.text.disabled,
                fontWeight: typography.weight.semibold,
              ),
            ),
          ],
        ),
        SizedBox(height: spacing.sm),
        SubZeroSlider(
          value: value,
          min: min,
          max: max,
          divisions: divisions,
          onChanged: onChanged,
          enabled: enabled,
          valueFormatter: valueFormatter,
          showTooltip: true,
        ),
      ],
    );
  }
}

/// A range slider that allows selecting a range between two values
///
/// Example:
/// ```dart
/// SubZeroRangeSlider(
///   values: RangeValues(_minPrice, _maxPrice),
///   min: 0,
///   max: 1000,
///   onChanged: (values) => setState(() {
///     _minPrice = values.start;
///     _maxPrice = values.end;
///   }),
/// )
/// ```
class SubZeroRangeSlider extends StatefulWidget {
  /// The current range values.
  final RangeValues values;

  /// The minimum value.
  final double min;

  /// The maximum value.
  final double max;

  /// The number of discrete divisions.
  final int? divisions;

  /// Called when the range changes.
  final ValueChanged<RangeValues>? onChanged;

  /// Called when the user starts dragging.
  final ValueChanged<RangeValues>? onChangeStart;

  /// Called when the user stops dragging.
  final ValueChanged<RangeValues>? onChangeEnd;

  /// Whether to show tooltips.
  final bool showTooltip;

  /// Custom formatter for the tooltip values.
  final String Function(double)? valueFormatter;

  /// Label for the minimum end.
  final String? minLabel;

  /// Label for the maximum end.
  final String? maxLabel;

  /// Whether the slider is enabled.
  final bool enabled;

  /// Height of the track.
  final double trackHeight;

  /// Radius of the thumb.
  final double thumbRadius;

  const SubZeroRangeSlider({
    super.key,
    required this.values,
    this.min = 0.0,
    this.max = 1.0,
    this.divisions,
    this.onChanged,
    this.onChangeStart,
    this.onChangeEnd,
    this.showTooltip = true,
    this.valueFormatter,
    this.minLabel,
    this.maxLabel,
    this.enabled = true,
    this.trackHeight = 4.0,
    this.thumbRadius = 12.0,
  });

  @override
  State<SubZeroRangeSlider> createState() => _SubZeroRangeSliderState();
}

class _SubZeroRangeSliderState extends State<SubZeroRangeSlider> {
  late RangeValues _currentValues;

  @override
  void initState() {
    super.initState();
    _currentValues = widget.values;
  }

  @override
  void didUpdateWidget(SubZeroRangeSlider oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.values != oldWidget.values) {
      _currentValues = widget.values;
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasLabels = widget.minLabel != null || widget.maxLabel != null;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            rangeTrackShape: _SubZeroRangeTrackShape(),
            rangeThumbShape: _SubZeroRangeThumbShape(
              thumbRadius: widget.thumbRadius,
            ),
            overlayShape: RoundSliderOverlayShape(overlayRadius: widget.thumbRadius + 8),
            activeTrackColor: widget.enabled
                ? colors.primary[500]
                : colors.primary[500].withValues(alpha: 0.5),
            inactiveTrackColor: widget.enabled
                ? colors.neutral.n300
                : colors.neutral.n300.withValues(alpha: 0.5),
            overlayColor: colors.primary[500].withValues(alpha: 0.2),
            rangeValueIndicatorShape: const PaddleRangeSliderValueIndicatorShape(),
            valueIndicatorColor: colors.neutral.n900,
            valueIndicatorTextStyle: typography.bodySmall.style.copyWith(
              color: colors.text.inverse,
            ),
            showValueIndicator: widget.showTooltip
                ? ShowValueIndicator.always
                : ShowValueIndicator.never,
          ),
          child: RangeSlider(
            values: _currentValues,
            min: widget.min,
            max: widget.max,
            divisions: widget.divisions,
            labels: widget.showTooltip
                ? RangeLabels(
                    _formatValue(_currentValues.start),
                    _formatValue(_currentValues.end),
                  )
                : null,
            onChanged: widget.enabled
                ? (values) {
                    setState(() => _currentValues = values);
                    widget.onChanged?.call(values);
                  }
                : null,
            onChangeStart: widget.onChangeStart,
            onChangeEnd: widget.onChangeEnd,
          ),
        ),
        // Min/Max labels
        if (hasLabels)
          Padding(
            padding: EdgeInsets.symmetric(horizontal: widget.thumbRadius),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (widget.minLabel != null)
                  Text(
                    widget.minLabel!,
                    style: typography.bodySmall.style.copyWith(
                      color: widget.enabled
                          ? colors.text.secondary
                          : colors.text.disabled,
                    ),
                  )
                else
                  const SizedBox.shrink(),
                if (widget.maxLabel != null)
                  Text(
                    widget.maxLabel!,
                    style: typography.bodySmall.style.copyWith(
                      color: widget.enabled
                          ? colors.text.secondary
                          : colors.text.disabled,
                    ),
                  )
                else
                  const SizedBox.shrink(),
              ],
            ),
          ),
      ],
    );
  }

  String _formatValue(double value) {
    if (widget.valueFormatter != null) return widget.valueFormatter!(value);
    if (widget.divisions != null) return value.round().toString();
    return value.toStringAsFixed(1);
  }
}

/// Custom range track shape
class _SubZeroRangeTrackShape extends RoundedRectRangeSliderTrackShape {
  @override
  void paint(
    PaintingContext context,
    Offset offset, {
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required Animation<double> enableAnimation,
    required Offset startThumbCenter,
    required Offset endThumbCenter,
    bool isEnabled = false,
    bool isDiscrete = false,
    required TextDirection textDirection,
    double additionalActiveTrackHeight = 2,
  }) {
    final canvas = context.canvas;
    final trackHeight = 4.0;
    final trackLeft = offset.dx + 12;
    final trackRight = offset.dx + parentBox.size.width - 12;
    final trackTop = offset.dy + (parentBox.size.height - trackHeight) / 2;

    // Inactive track (full)
    final inactivePaint = Paint()
      ..color = sliderTheme.inactiveTrackColor ?? colors.neutral.n300
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(trackLeft, trackTop, trackRight - trackLeft, trackHeight),
        Radius.circular(trackHeight / 2),
      ),
      inactivePaint,
    );

    // Active track (between thumbs)
    final activePaint = Paint()
      ..color = sliderTheme.activeTrackColor ?? colors.primary[500]
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          startThumbCenter.dx,
          trackTop,
          endThumbCenter.dx - startThumbCenter.dx,
          trackHeight,
        ),
        Radius.circular(trackHeight / 2),
      ),
      activePaint,
    );
  }
}

/// Custom range thumb shape
class _SubZeroRangeThumbShape extends RangeSliderThumbShape {
  final double thumbRadius;

  _SubZeroRangeThumbShape({required this.thumbRadius});

  @override
  Size getPreferredSize(bool isEnabled, bool isDiscrete) =>
      Size.fromRadius(thumbRadius);

  @override
  void paint(
    PaintingContext context,
    Offset center, {
    required Animation<double> activationAnimation,
    required Animation<double> enableAnimation,
    bool isDiscrete = false,
    bool isEnabled = true,
    bool? isOnTop,
    bool? isPressed,
    required SliderThemeData sliderTheme,
    TextDirection? textDirection,
    Thumb? thumb,
  }) {
    final canvas = context.canvas;

    // Outer glow when pressed
    if (isPressed == true) {
      final glowPaint = Paint()
        ..color = colors.primary[500].withValues(alpha: 0.25)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawCircle(center, thumbRadius + 4, glowPaint);
    }

    // White background
    final bgPaint = Paint()
      ..color = colors.neutral.n0
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, thumbRadius, bgPaint);

    // Border
    final borderPaint = Paint()
      ..color = isEnabled
          ? colors.primary[500]
          : colors.primary[500].withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(center, thumbRadius - 1, borderPaint);

    // Inner filled circle
    final innerPaint = Paint()
      ..color = isEnabled
          ? colors.primary[500]
          : colors.primary[500].withValues(alpha: 0.5)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, thumbRadius - 5, innerPaint);
  }
}
