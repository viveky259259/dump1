import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sub_zero_design_system/design_system/tokens.dart';

/// Size variants for the SubZeroSwitch component
enum SubZeroSwitchSize { small, medium, large }

/// A segmented toggle switch following SubZero 2.0 Design System.
/// 
/// Displays two options (default: YES/NO) in a pill-shaped container.
/// The selected option is highlighted with the primary color.
/// 
/// Example usage:
/// ```dart
/// SubZeroSwitch(
///   value: true,
///   onChanged: (value) => setState(() => _isEnabled = value),
/// )
/// ```
class SubZeroSwitch extends StatefulWidget {
  const SubZeroSwitch({
    super.key,
    required this.value,
    required this.onChanged,
    this.activeLabel = 'YES',
    this.inactiveLabel = 'NO',
    this.size = SubZeroSwitchSize.medium,
    this.enabled = true,
    this.semanticLabel,
  });

  /// Current value of the switch (true = active/left option selected)
  final bool value;

  /// Callback when value changes
  final ValueChanged<bool>? onChanged;

  /// Label for the active/true state (default: 'YES')
  final String activeLabel;

  /// Label for the inactive/false state (default: 'NO')
  final String inactiveLabel;

  /// Size variant of the switch
  final SubZeroSwitchSize size;

  /// Whether the switch is enabled
  final bool enabled;

  /// Semantic label for accessibility
  final String? semanticLabel;

  @override
  State<SubZeroSwitch> createState() => _SubZeroSwitchState();
}

class _SubZeroSwitchState extends State<SubZeroSwitch> {
  bool _isHoveringActive = false;
  bool _isHoveringInactive = false;
  bool _isFocused = false;

  double get _height {
    switch (widget.size) {
      case SubZeroSwitchSize.small:
        return 32.0;
      case SubZeroSwitchSize.medium:
        return 40.0;
      case SubZeroSwitchSize.large:
        return 48.0;
    }
  }

  double get _horizontalPadding {
    switch (widget.size) {
      case SubZeroSwitchSize.small:
        return spacing.sm;
      case SubZeroSwitchSize.medium:
        return spacing.md;
      case SubZeroSwitchSize.large:
        return spacing.lg;
    }
  }

  double get _fontSize {
    switch (widget.size) {
      case SubZeroSwitchSize.small:
        return 12.0;
      case SubZeroSwitchSize.medium:
        return 14.0;
      case SubZeroSwitchSize.large:
        return 16.0;
    }
  }

  void _handleTap(bool newValue) {
    if (!widget.enabled || widget.onChanged == null) return;
    if (newValue != widget.value) {
      widget.onChanged!(newValue);
    }
  }

  void _handleKeyEvent(KeyEvent event) {
    if (!widget.enabled || widget.onChanged == null) return;
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.enter ||
          event.logicalKey == LogicalKeyboardKey.space) {
        widget.onChanged!(!widget.value);
      } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
        if (!widget.value) widget.onChanged!(true);
      } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
        if (widget.value) widget.onChanged!(false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEnabled = widget.enabled && widget.onChanged != null;
    final effectiveOpacity = isEnabled ? 1.0 : 0.5;

    return Semantics(
      label: widget.semanticLabel ?? 
          '${widget.value ? widget.activeLabel : widget.inactiveLabel} selected. '
          'Toggle between ${widget.activeLabel} and ${widget.inactiveLabel}',
      toggled: widget.value,
      enabled: isEnabled,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          _handleKeyEvent(event);
          return KeyEventResult.handled;
        },
        child: Opacity(
          opacity: effectiveOpacity,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: _height,
            decoration: BoxDecoration(
              color: colors.bg.defaultBg,
              borderRadius: BorderRadius.circular(radius.full),
              border: Border.all(
                color: _isFocused ? colors.primary[500] : colors.neutral.n300,
                width: _isFocused ? 2.0 : 1.0,
              ),
              boxShadow: _isFocused
                  ? [
                      BoxShadow(
                        color: colors.primary[500].withValues(alpha: 0.2),
                        blurRadius: 4,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Active/YES option
                _buildSegment(
                  label: widget.activeLabel,
                  isSelected: widget.value,
                  isHovering: _isHoveringActive,
                  isEnabled: isEnabled,
                  onTap: () => _handleTap(true),
                  onHover: (hovering) => setState(() => _isHoveringActive = hovering),
                ),
                // Inactive/NO option
                _buildSegment(
                  label: widget.inactiveLabel,
                  isSelected: !widget.value,
                  isHovering: _isHoveringInactive,
                  isEnabled: isEnabled,
                  onTap: () => _handleTap(false),
                  onHover: (hovering) => setState(() => _isHoveringInactive = hovering),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSegment({
    required String label,
    required bool isSelected,
    required bool isHovering,
    required bool isEnabled,
    required VoidCallback onTap,
    required ValueChanged<bool> onHover,
  }) {
    final backgroundColor = isSelected
        ? (isHovering && isEnabled ? colors.primary[700] : colors.primary[500])
        : (isHovering && isEnabled ? colors.neutral.n100 : Colors.transparent);

    final textColor = isSelected
        ? colors.text.inverse
        : (isEnabled ? colors.text.primary : colors.text.disabled);

    return MouseRegion(
      cursor: isEnabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
      onEnter: (_) => onHover(true),
      onExit: (_) => onHover(false),
      child: GestureDetector(
        onTap: isEnabled ? onTap : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: _height - 2, // Account for border
          padding: EdgeInsets.symmetric(horizontal: _horizontalPadding),
          margin: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(radius.full),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontSize: _fontSize,
              fontWeight: FontWeight.w600,
              color: textColor,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ),
    );
  }
}

/// A labeled switch with optional description text.
/// 
/// Example usage:
/// ```dart
/// SubZeroLabeledSwitch(
///   label: 'Enable Notifications',
///   description: 'Receive push notifications for updates',
///   value: _notificationsEnabled,
///   onChanged: (value) => setState(() => _notificationsEnabled = value),
/// )
/// ```
class SubZeroLabeledSwitch extends StatelessWidget {
  const SubZeroLabeledSwitch({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.description,
    this.activeLabel = 'YES',
    this.inactiveLabel = 'NO',
    this.size = SubZeroSwitchSize.medium,
    this.enabled = true,
    this.labelPosition = SubZeroSwitchLabelPosition.start,
  });

  /// Main label text
  final String label;

  /// Optional description text
  final String? description;

  /// Current value
  final bool value;

  /// Callback when value changes
  final ValueChanged<bool>? onChanged;

  /// Label for active state
  final String activeLabel;

  /// Label for inactive state
  final String inactiveLabel;

  /// Size variant
  final SubZeroSwitchSize size;

  /// Whether the switch is enabled
  final bool enabled;

  /// Position of the label relative to the switch
  final SubZeroSwitchLabelPosition labelPosition;

  @override
  Widget build(BuildContext context) {
    final labelWidget = Expanded(
      child: GestureDetector(
        onTap: enabled && onChanged != null ? () => onChanged!(!value) : null,
        child: MouseRegion(
          cursor: enabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: enabled ? colors.text.primary : colors.text.disabled,
                ),
              ),
              if (description != null) ...[
                SizedBox(height: spacing.xs),
                Text(
                  description!,
                  style: TextStyle(
                    fontSize: 12,
                    color: enabled ? colors.text.secondary : colors.text.disabled,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );

    final switchWidget = SubZeroSwitch(
      value: value,
      onChanged: onChanged,
      activeLabel: activeLabel,
      inactiveLabel: inactiveLabel,
      size: size,
      enabled: enabled,
      semanticLabel: label,
    );

    final children = labelPosition == SubZeroSwitchLabelPosition.start
        ? [labelWidget, SizedBox(width: spacing.md), switchWidget]
        : [switchWidget, SizedBox(width: spacing.md), labelWidget];

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: children,
    );
  }
}

/// Position of label relative to switch
enum SubZeroSwitchLabelPosition { start, end }

/// A traditional iOS-style toggle switch following SubZero 2.0 Design System.
/// 
/// Use this when you need a more compact toggle without text labels.
/// 
/// Example usage:
/// ```dart
/// SubZeroToggle(
///   value: _isEnabled,
///   onChanged: (value) => setState(() => _isEnabled = value),
/// )
/// ```
class SubZeroToggle extends StatefulWidget {
  const SubZeroToggle({
    super.key,
    required this.value,
    required this.onChanged,
    this.size = SubZeroSwitchSize.medium,
    this.enabled = true,
    this.semanticLabel,
    this.activeColor,
  });

  /// Current value
  final bool value;

  /// Callback when value changes
  final ValueChanged<bool>? onChanged;

  /// Size variant
  final SubZeroSwitchSize size;

  /// Whether enabled
  final bool enabled;

  /// Semantic label for accessibility
  final String? semanticLabel;

  /// Custom active track color (defaults to primary)
  final Color? activeColor;

  @override
  State<SubZeroToggle> createState() => _SubZeroToggleState();
}

class _SubZeroToggleState extends State<SubZeroToggle>
    with SingleTickerProviderStateMixin {
  bool _isHovering = false;
  bool _isFocused = false;

  double get _width {
    switch (widget.size) {
      case SubZeroSwitchSize.small:
        return 40.0;
      case SubZeroSwitchSize.medium:
        return 48.0;
      case SubZeroSwitchSize.large:
        return 56.0;
    }
  }

  double get _height {
    switch (widget.size) {
      case SubZeroSwitchSize.small:
        return 22.0;
      case SubZeroSwitchSize.medium:
        return 26.0;
      case SubZeroSwitchSize.large:
        return 30.0;
    }
  }

  double get _thumbSize {
    switch (widget.size) {
      case SubZeroSwitchSize.small:
        return 18.0;
      case SubZeroSwitchSize.medium:
        return 22.0;
      case SubZeroSwitchSize.large:
        return 26.0;
    }
  }

  void _handleTap() {
    if (!widget.enabled || widget.onChanged == null) return;
    widget.onChanged!(!widget.value);
  }

  void _handleKeyEvent(KeyEvent event) {
    if (!widget.enabled || widget.onChanged == null) return;
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.enter ||
          event.logicalKey == LogicalKeyboardKey.space) {
        widget.onChanged!(!widget.value);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEnabled = widget.enabled && widget.onChanged != null;
    final activeColor = widget.activeColor ?? colors.primary[500];

    final trackColor = widget.value
        ? (_isHovering && isEnabled ? activeColor.withValues(alpha: 0.9) : activeColor)
        : (_isHovering && isEnabled ? colors.neutral.n400 : colors.neutral.n300);

    final thumbPosition = widget.value ? _width - _thumbSize - 4 : 2.0;

    return Semantics(
      label: widget.semanticLabel ?? (widget.value ? 'On' : 'Off'),
      toggled: widget.value,
      enabled: isEnabled,
      child: Focus(
        onFocusChange: (focused) => setState(() => _isFocused = focused),
        onKeyEvent: (node, event) {
          _handleKeyEvent(event);
          return KeyEventResult.handled;
        },
        child: MouseRegion(
          cursor: isEnabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
          onEnter: (_) => setState(() => _isHovering = true),
          onExit: (_) => setState(() => _isHovering = false),
          child: GestureDetector(
            onTap: isEnabled ? _handleTap : null,
            child: Opacity(
              opacity: isEnabled ? 1.0 : 0.5,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeInOut,
                width: _width,
                height: _height,
                decoration: BoxDecoration(
                  color: trackColor,
                  borderRadius: BorderRadius.circular(radius.full),
                  border: _isFocused
                      ? Border.all(color: colors.primary[500], width: 2)
                      : null,
                  boxShadow: _isFocused
                      ? [
                          BoxShadow(
                            color: colors.primary[500].withValues(alpha: 0.3),
                            blurRadius: 4,
                            spreadRadius: 1,
                          ),
                        ]
                      : null,
                ),
                child: Stack(
                  children: [
                    AnimatedPositioned(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeInOut,
                      left: thumbPosition,
                      top: (_height - _thumbSize) / 2,
                      child: Container(
                        width: _thumbSize,
                        height: _thumbSize,
                        decoration: BoxDecoration(
                          color: colors.neutral.n0,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.15),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// A labeled traditional toggle switch.
class SubZeroLabeledToggle extends StatelessWidget {
  const SubZeroLabeledToggle({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.description,
    this.size = SubZeroSwitchSize.medium,
    this.enabled = true,
    this.labelPosition = SubZeroSwitchLabelPosition.start,
    this.activeColor,
  });

  final String label;
  final String? description;
  final bool value;
  final ValueChanged<bool>? onChanged;
  final SubZeroSwitchSize size;
  final bool enabled;
  final SubZeroSwitchLabelPosition labelPosition;
  final Color? activeColor;

  @override
  Widget build(BuildContext context) {
    final labelWidget = Expanded(
      child: GestureDetector(
        onTap: enabled && onChanged != null ? () => onChanged!(!value) : null,
        child: MouseRegion(
          cursor: enabled ? SystemMouseCursors.click : SystemMouseCursors.basic,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: enabled ? colors.text.primary : colors.text.disabled,
                ),
              ),
              if (description != null) ...[
                SizedBox(height: spacing.xs),
                Text(
                  description!,
                  style: TextStyle(
                    fontSize: 12,
                    color: enabled ? colors.text.secondary : colors.text.disabled,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );

    final toggleWidget = SubZeroToggle(
      value: value,
      onChanged: onChanged,
      size: size,
      enabled: enabled,
      semanticLabel: label,
      activeColor: activeColor,
    );

    final children = labelPosition == SubZeroSwitchLabelPosition.start
        ? [labelWidget, SizedBox(width: spacing.md), toggleWidget]
        : [toggleWidget, SizedBox(width: spacing.md), labelWidget];

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: children,
    );
  }
}
