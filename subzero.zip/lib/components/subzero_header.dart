import 'package:flutter/material.dart';
import 'package:sub_zero_design_system/design_system/theme/colors.dart';
import 'package:sub_zero_design_system/design_system/theme/spacing.dart';

/// Header variants matching SubZero 2.0 Design System
enum SubZeroHeaderVariant {
  /// Primary burgundy header with brand logo
  primary,

  /// White/surface header with product branding
  surface,
}

/// Breakpoints for responsive behavior
class _HeaderBreakpoints {
  static const double mobile = 600;
  static const double tablet = 900;
}

/// A responsive header component following SubZero 2.0 Design System.
///
/// Features:
/// - Two variants: Primary (burgundy) and Surface (white)
/// - Distinctive angled/clipped corner design
/// - Responsive layout (mobile/tablet/desktop)
/// - Scrolled state with elevated shadow
/// - Flexible slots for branding, navigation, and actions
///
/// Example usage:
/// ```dart
/// SubZeroHeader(
///   variant: SubZeroHeaderVariant.primary,
///   brandName: 'AXIS BANK',
///   logo: Image.asset('assets/logo.png'),
///   isScrolled: _isScrolled,
///   navigationItems: [
///     SubZeroHeaderNavItem(label: 'Home', onTap: () {}),
///     SubZeroHeaderNavItem(label: 'Products', onTap: () {}),
///   ],
///   actions: [
///     IconButton(icon: Icon(Icons.notifications), onPressed: () {}),
///   ],
/// )
/// ```
class SubZeroHeader extends StatelessWidget {
  const SubZeroHeader({
    super.key,
    this.variant = SubZeroHeaderVariant.primary,
    this.logo,
    this.brandName,
    this.productName,
    this.navigationItems = const [],
    this.actions = const [],
    this.isScrolled = false,
    this.onMenuPressed,
    this.height,
    this.showAngledEdge = true,
    this.onLogoTap,
  });

  /// Header style variant
  final SubZeroHeaderVariant variant;

  /// Logo widget (typically an Image or Icon)
  final Widget? logo;

  /// Main brand name (e.g., "AXIS BANK")
  final String? brandName;

  /// Product/sub-brand name (e.g., "PRODUCT NAME" in "open | PRODUCT NAME")
  final String? productName;

  /// Navigation items for desktop view
  final List<SubZeroHeaderNavItem> navigationItems;

  /// Action widgets on the right (icons, avatar, etc.)
  final List<Widget> actions;

  /// Whether the page has been scrolled (adds elevation)
  final bool isScrolled;

  /// Callback for mobile menu button
  final VoidCallback? onMenuPressed;

  /// Custom height (defaults based on variant and screen size)
  final double? height;

  /// Whether to show the angled/clipped edge
  final bool showAngledEdge;

  /// Callback when logo/brand is tapped
  final VoidCallback? onLogoTap;

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < _HeaderBreakpoints.mobile;
    final isTablet = screenWidth >= _HeaderBreakpoints.mobile &&
        screenWidth < _HeaderBreakpoints.tablet;

    final effectiveHeight = height ?? _getDefaultHeight(isMobile, isTablet);
    final horizontalPadding = _getHorizontalPadding(isMobile, isTablet);

    final backgroundColor = variant == SubZeroHeaderVariant.primary
        ? SubZeroColors.primary
        : SubZeroColors.surface;

    final foregroundColor = variant == SubZeroHeaderVariant.primary
        ? Colors.white
        : SubZeroColors.textPrimary;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: backgroundColor,
        boxShadow: isScrolled
            ? [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: SafeArea(
        bottom: false,
        child: SizedBox(
          height: effectiveHeight,
          child: Stack(
            children: [
              // Main content
              Padding(
                padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
                child: Row(
                  children: [
                    // Left: Logo and Branding
                    _buildBranding(context, foregroundColor, isMobile),

                    // Center: Navigation (desktop/tablet only)
                    if (!isMobile && navigationItems.isNotEmpty)
                      Expanded(
                        child: _buildNavigation(context, foregroundColor),
                      )
                    else
                      const Spacer(),

                    // Right: Actions
                    _buildActions(context, foregroundColor, isMobile),
                  ],
                ),
              ),

              // Angled edge overlay (for primary variant)
              if (showAngledEdge && variant == SubZeroHeaderVariant.primary)
                Positioned(
                  right: 0,
                  top: 0,
                  bottom: 0,
                  child: _AngledEdgeClip(
                    height: effectiveHeight,
                    color: backgroundColor,
                  ),
                ),

              // Bottom border for surface variant
              if (variant == SubZeroHeaderVariant.surface)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    height: 1,
                    color: SubZeroColors.border,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  double _getDefaultHeight(bool isMobile, bool isTablet) {
    if (variant == SubZeroHeaderVariant.primary) {
      return isMobile ? 56 : 64;
    }
    return isMobile ? 48 : 56;
  }

  double _getHorizontalPadding(bool isMobile, bool isTablet) {
    if (isMobile) return SubZeroSpacing.sidePaddingMobile;
    if (isTablet) return SubZeroSpacing.sidePaddingTablet;
    return SubZeroSpacing.sidePaddingDesktop;
  }

  Widget _buildBranding(
      BuildContext context, Color foregroundColor, bool isMobile) {
    return GestureDetector(
      onTap: onLogoTap,
      behavior: HitTestBehavior.opaque,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Logo
          if (logo != null) ...[
            SizedBox(
              height: isMobile ? 32 : 40,
              child: logo,
            ),
            if (brandName != null || productName != null)
              SizedBox(width: SubZeroSpacing.sm),
          ],

          // Brand name or product branding
          if (variant == SubZeroHeaderVariant.primary && brandName != null)
            Text(
              brandName!,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: foregroundColor,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
            )
          else if (variant == SubZeroHeaderVariant.surface)
            _buildProductBranding(context, foregroundColor, isMobile),
        ],
      ),
    );
  }

  Widget _buildProductBranding(
      BuildContext context, Color foregroundColor, bool isMobile) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // "open" text in primary color
        Text(
          'open',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: SubZeroColors.primary,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                fontSize: isMobile ? 16 : 20,
              ),
        ),
        if (productName != null) ...[
          Padding(
            padding: EdgeInsets.symmetric(horizontal: SubZeroSpacing.sm),
            child: Text(
              '|',
              style: TextStyle(
                color: SubZeroColors.textTertiary,
                fontSize: isMobile ? 16 : 20,
              ),
            ),
          ),
          Text(
            productName!,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: foregroundColor,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                  fontSize: isMobile ? 12 : 14,
                ),
          ),
        ],
      ],
    );
  }

  Widget _buildNavigation(BuildContext context, Color foregroundColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: navigationItems.map((item) {
        return _HeaderNavButton(
          item: item,
          foregroundColor: foregroundColor,
          variant: variant,
        );
      }).toList(),
    );
  }

  Widget _buildActions(
      BuildContext context, Color foregroundColor, bool isMobile) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Action widgets
        ...actions.map((action) => IconTheme(
              data: IconThemeData(
                color: foregroundColor,
                size: isMobile ? 22 : 24,
              ),
              child: action,
            )),

        // Mobile menu button
        if (isMobile && navigationItems.isNotEmpty) ...[
          SizedBox(width: SubZeroSpacing.xs),
          IconButton(
            onPressed: onMenuPressed,
            icon: Icon(Icons.menu, color: foregroundColor),
            tooltip: 'Menu',
          ),
        ],
      ],
    );
  }
}

/// Navigation item data for header
class SubZeroHeaderNavItem {
  const SubZeroHeaderNavItem({
    required this.label,
    required this.onTap,
    this.isActive = false,
    this.icon,
  });

  final String label;
  final VoidCallback onTap;
  final bool isActive;
  final IconData? icon;
}

/// Internal nav button widget
class _HeaderNavButton extends StatefulWidget {
  const _HeaderNavButton({
    required this.item,
    required this.foregroundColor,
    required this.variant,
  });

  final SubZeroHeaderNavItem item;
  final Color foregroundColor;
  final SubZeroHeaderVariant variant;

  @override
  State<_HeaderNavButton> createState() => _HeaderNavButtonState();
}

class _HeaderNavButtonState extends State<_HeaderNavButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final isActive = widget.item.isActive;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTap: widget.item.onTap,
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.md,
            vertical: SubZeroSpacing.sm,
          ),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: isActive || _isHovered
                    ? (widget.variant == SubZeroHeaderVariant.primary
                        ? Colors.white
                        : SubZeroColors.primary)
                    : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.item.icon != null) ...[
                Icon(
                  widget.item.icon,
                  size: 18,
                  color: widget.foregroundColor
                      .withValues(alpha: isActive ? 1.0 : 0.8),
                ),
                SizedBox(width: SubZeroSpacing.xs),
              ],
              Text(
                widget.item.label,
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: widget.foregroundColor
                          .withValues(alpha: isActive ? 1.0 : 0.8),
                      fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Custom clipper for the angled edge effect
class _AngledEdgeClip extends StatelessWidget {
  const _AngledEdgeClip({
    required this.height,
    required this.color,
  });

  final double height;
  final Color color;

  @override
  Widget build(BuildContext context) {
    // The angled edge creates a diagonal cut on the right side
    return CustomPaint(
      size: Size(height * 0.5, height),
      painter: _AngledEdgePainter(color: color),
    );
  }
}

class _AngledEdgePainter extends CustomPainter {
  _AngledEdgePainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width, size.height)
      ..lineTo(size.width * 0.3, size.height)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// A navigation drawer for mobile view
class SubZeroHeaderDrawer extends StatelessWidget {
  const SubZeroHeaderDrawer({
    super.key,
    required this.navigationItems,
    this.header,
    this.footer,
  });

  final List<SubZeroHeaderNavItem> navigationItems;
  final Widget? header;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: SubZeroColors.surface,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header section
            if (header != null)
              Container(
                padding: EdgeInsets.all(SubZeroSpacing.md),
                decoration: BoxDecoration(
                  color: SubZeroColors.primary,
                ),
                child: header,
              )
            else
              SizedBox(height: SubZeroSpacing.md),

            // Close button
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: EdgeInsets.only(right: SubZeroSpacing.sm),
                child: IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                  tooltip: 'Close',
                ),
              ),
            ),

            // Navigation items
            Expanded(
              child: ListView.separated(
                padding: EdgeInsets.symmetric(vertical: SubZeroSpacing.md),
                itemCount: navigationItems.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final item = navigationItems[index];
                  return ListTile(
                    leading:
                        item.icon != null ? Icon(item.icon, size: 22) : null,
                    title: Text(
                      item.label,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: item.isActive
                                ? FontWeight.w600
                                : FontWeight.w500,
                            color: item.isActive
                                ? SubZeroColors.primary
                                : SubZeroColors.textPrimary,
                          ),
                    ),
                    selected: item.isActive,
                    selectedTileColor:
                        SubZeroColors.primary.withValues(alpha: 0.08),
                    onTap: () {
                      Navigator.of(context).pop();
                      item.onTap();
                    },
                  );
                },
              ),
            ),

            // Footer
            if (footer != null)
              Container(
                padding: EdgeInsets.all(SubZeroSpacing.md),
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(color: SubZeroColors.border),
                  ),
                ),
                child: footer,
              ),
          ],
        ),
      ),
    );
  }
}

/// A scrollable scaffold wrapper that manages header scroll state
class SubZeroHeaderScaffold extends StatefulWidget {
  const SubZeroHeaderScaffold({
    super.key,
    required this.header,
    required this.body,
    this.drawer,
    this.floatingActionButton,
    this.bottomNavigationBar,
    this.backgroundColor,
  });

  /// Header builder that receives scroll state
  final Widget Function(bool isScrolled) header;

  /// Body content
  final Widget body;

  /// Optional drawer for mobile navigation
  final Widget? drawer;

  /// Optional FAB
  final Widget? floatingActionButton;

  /// Optional bottom nav bar
  final Widget? bottomNavigationBar;

  /// Scaffold background color
  final Color? backgroundColor;

  @override
  State<SubZeroHeaderScaffold> createState() => _SubZeroHeaderScaffoldState();
}

class _SubZeroHeaderScaffoldState extends State<SubZeroHeaderScaffold> {
  bool _isScrolled = false;

  bool _handleScrollNotification(ScrollNotification notification) {
    if (notification is ScrollUpdateNotification) {
      final shouldBeScrolled = notification.metrics.pixels > 0;
      if (shouldBeScrolled != _isScrolled) {
        setState(() => _isScrolled = shouldBeScrolled);
      }
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.backgroundColor ?? SubZeroColors.background,
      drawer: widget.drawer,
      floatingActionButton: widget.floatingActionButton,
      bottomNavigationBar: widget.bottomNavigationBar,
      body: Column(
        children: [
          widget.header(_isScrolled),
          Expanded(
            child: NotificationListener<ScrollNotification>(
              onNotification: _handleScrollNotification,
              child: widget.body,
            ),
          ),
        ],
      ),
    );
  }
}
