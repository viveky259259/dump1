/// Sub Zero 2.0 Design System
///
/// A comprehensive Flutter design system package providing responsive
/// components, themes, tokens, and styles for building beautiful,
/// consistent, and accessible user interfaces.
///
/// ## Getting Started
///
/// Add Sub Zero to your project's `pubspec.yaml`:
///
/// ```yaml
/// dependencies:
///   sub_zero_design_system: ^1.0.0
/// ```
///
/// Then import and use it in your Flutter app:
///
/// ```dart
/// import 'package:sub_zero_design_system/sub_zero_design_system.dart';
///
/// void main() {
///   runApp(MaterialApp(
///     theme: SubZeroTheme.lightTheme,
///     home: MyHomePage(),
///   ));
/// }
/// ```
///
/// ## Design Tokens
///
/// Access design tokens for colors, typography, spacing, and more:
///
/// ```dart
/// // Using the tokens API
/// final primaryColor = tokens.color.primary[500];
/// final headingStyle = tokens.typography.h1.style;
/// final padding = tokens.spacing.md;
///
/// // Or use convenience exports
/// final color = colors.primary[500];
/// final space = spacing.lg;
/// ```
///
/// ## Components
///
/// Use pre-built components following the design system:
///
/// ```dart
/// SubZeroButton(
///   label: 'Submit',
///   variant: SubZeroButtonVariant.primary,
///   onPressed: () => print('Pressed!'),
/// )
/// ```

// Design System Theme
export 'design_system/sub_zero_theme.dart';

// Design Tokens
export 'design_system/tokens.dart';

// Theme Components
export 'design_system/theme/colors.dart';
export 'design_system/theme/typography.dart';
export 'design_system/theme/spacing.dart';
export 'design_system/theme/radius.dart';
export 'design_system/theme/elevation.dart';

// UI Components
export 'components/subzero_accordion.dart';
export 'components/subzero_add_item.dart';
export 'components/subzero_avatar.dart';
export 'components/subzero_badge.dart';
export 'components/subzero_bottom_sheet.dart';
export 'components/subzero_button.dart';
export 'components/subzero_card.dart';
export 'components/subzero_carousel.dart';
export 'components/subzero_checkbox.dart';
export 'components/subzero_dialog.dart';
export 'components/subzero_divider.dart';
export 'components/subzero_header.dart';
export 'components/subzero_onboarding.dart';
export 'components/subzero_progress_tracker.dart';
export 'components/subzero_radio.dart';
export 'components/subzero_search.dart';
export 'components/subzero_slider.dart';
export 'components/subzero_switch.dart';
export 'components/subzero_tabs.dart';
export 'components/subzero_tag.dart';
export 'components/subzero_toast.dart';
export 'components/subzero_toggle.dart';
