import 'package:flutter/material.dart';
import 'theme/colors.dart';
import 'theme/typography.dart';
import 'theme/spacing.dart';
import 'theme/radius.dart';

class SubZeroTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: SubZeroColors.background,
      primaryColor: SubZeroColors.primary,
      colorScheme: const ColorScheme.light(
        primary: SubZeroColors.primary,
        onPrimary: Colors.white,
        secondary: SubZeroColors.actionSecondary,
        onSecondary: Colors.white,
        tertiary: SubZeroColors.actionTertiary,
        onTertiary: Colors.white,
        error: SubZeroColors.error,
        surface: SubZeroColors.surface,
        onSurface: SubZeroColors.textPrimary,
        surfaceContainerHighest: SubZeroColors.surfaceVariant,
      ),
      textTheme: SubZeroTypography.textTheme,
      cardTheme: CardThemeData(
        color: SubZeroColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: SubZeroRadius.medium,
          side: BorderSide(color: SubZeroColors.border, width: 1),
        ),
        margin: EdgeInsets.zero,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: SubZeroColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.lg,
            vertical: SubZeroSpacing.md,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: SubZeroRadius.medium,
          ),
          elevation: 0,
          textStyle: SubZeroTypography.textTheme.labelLarge,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: SubZeroColors.primary,
          padding: const EdgeInsets.symmetric(
            horizontal: SubZeroSpacing.lg,
            vertical: SubZeroSpacing.md,
          ),
          side: const BorderSide(color: SubZeroColors.primary),
          shape: RoundedRectangleBorder(
            borderRadius: SubZeroRadius.medium,
          ),
          textStyle: SubZeroTypography.textTheme.labelLarge,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: SubZeroColors.surface,
        contentPadding: const EdgeInsets.all(SubZeroSpacing.md),
        border: OutlineInputBorder(
          borderRadius: SubZeroRadius.medium,
          borderSide: const BorderSide(color: SubZeroColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: SubZeroRadius.medium,
          borderSide: const BorderSide(color: SubZeroColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: SubZeroRadius.medium,
          borderSide: const BorderSide(color: SubZeroColors.primary, width: 2),
        ),
        labelStyle: SubZeroTypography.textTheme.bodyMedium,
      ),
      dividerTheme: const DividerThemeData(
        color: SubZeroColors.divider,
        thickness: 1,
        space: 1,
      ),
    );
  }
}
