import 'package:flutter/material.dart';
import 'colors.dart';

class SubZeroElevation {
  static List<BoxShadow> get none => [];
  
  static List<BoxShadow> get level1 => [
    BoxShadow(
      color: SubZeroColors.secondary.withValues(alpha: 0.05),
      blurRadius: 4,
      offset: const Offset(0, 2),
    ),
  ];
  
  static List<BoxShadow> get level2 => [
    BoxShadow(
      color: SubZeroColors.secondary.withValues(alpha: 0.08),
      blurRadius: 8,
      offset: const Offset(0, 4),
    ),
  ];
  
  static List<BoxShadow> get level3 => [
    BoxShadow(
      color: SubZeroColors.secondary.withValues(alpha: 0.1),
      blurRadius: 16,
      offset: const Offset(0, 8),
    ),
    BoxShadow(
      color: SubZeroColors.secondary.withValues(alpha: 0.05),
      blurRadius: 4,
      offset: const Offset(0, 2),
    ),
  ];
  
  static List<BoxShadow> get level4 => [
    BoxShadow(
      color: SubZeroColors.secondary.withValues(alpha: 0.12),
      blurRadius: 24,
      offset: const Offset(0, 12),
    ),
  ];
}
