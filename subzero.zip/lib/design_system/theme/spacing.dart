import 'package:flutter/material.dart';

class SubZeroSpacing {
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 32.0;
  static const double xxl = 48.0;
  static const double xxxl = 64.0;

  // Layout constants
  static const double containerMaxWidth = 1200.0;
  static const double sidePaddingMobile = 16.0;
  static const double sidePaddingTablet = 32.0;
  static const double sidePaddingDesktop = 64.0;
  
  static EdgeInsets get screenPadding => const EdgeInsets.all(md);
  static EdgeInsets get cardPadding => const EdgeInsets.all(md);
}
