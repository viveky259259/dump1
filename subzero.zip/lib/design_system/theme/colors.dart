import 'package:flutter/material.dart';

/// Subzero 2.0 (Axis Bank) Design System Colors
///
/// All color values are sourced from the official Subzero design system spec.
/// See: https://www.subzero.axis.bank.in/foundations/colours
class SubZeroColors {
  // ---------------------------------------------------------------------------
  // Action Colours — applied to clickable actions
  // ---------------------------------------------------------------------------

  /// Action Primary (#97144D) — key CTA buttons
  static const Color primary = Color(0xFF97144D);

  /// Action Primary Dark variant (derived)
  static const Color primaryDark = Color(0xFF680028);

  /// Action Primary Light variant (derived)
  static const Color primaryLight = Color(0xFFCD4C79);

  /// Action Secondary (#ED1164) — text buttons, radio, toggles
  static const Color actionSecondary = Color(0xFFED1164);

  /// Action Tertiary (#12877F) — upload buttons, least-important actions
  static const Color actionTertiary = Color(0xFF12877F);

  /// Legacy alias for [actionSecondary].
  static const Color accent = actionSecondary;

  // ---------------------------------------------------------------------------
  // Surface Colours — non-clickable backgrounds
  // ---------------------------------------------------------------------------

  /// Surface Background (#FFFFFF)
  static const Color background = Color(0xFFFFFFFF);

  /// Surface Primary (#FFFFFF)
  static const Color surface = Color(0xFFFFFFFF);

  /// Surface Secondary (#F9F9F9)
  static const Color surfaceVariant = Color(0xFFF9F9F9);

  /// Surface Tertiary (#404040)
  static const Color surfaceTertiary = Color(0xFF404040);

  /// Legacy alias — maps to Surface Tertiary.
  static const Color secondary = surfaceTertiary;

  /// Legacy alias
  static const Color secondaryLight = Color(0xFF575757);

  // ---------------------------------------------------------------------------
  // Typography Colours — Standard (non-clickable text)
  // ---------------------------------------------------------------------------

  /// Typo Primary (#282828)
  static const Color textPrimary = Color(0xFF282828);

  /// Typo Secondary (#6E6E6E)
  static const Color textSecondary = Color(0xFF6E6E6E);

  /// Typo Tertiary (#9D9D9D)
  static const Color textTertiary = Color(0xFF9D9D9D);

  /// Typo On-Surface (#FFFFFF)
  static const Color textOnSurface = Color(0xFFFFFFFF);

  /// Typo Disabled (#B4B4B4)
  static const Color textDisabled = Color(0xFFB4B4B4);

  /// Typo Typical (#165964)
  static const Color textTypical = Color(0xFF165964);

  // ---------------------------------------------------------------------------
  // Icon Colours
  // ---------------------------------------------------------------------------

  /// Icon Default (#404040)
  static const Color iconDefault = Color(0xFF404040);

  /// Icon On-Surface (#FFFFFF)
  static const Color iconOnSurface = Color(0xFFFFFFFF);

  /// Icon Disabled (#B4B4B4)
  static const Color iconDisabled = Color(0xFFB4B4B4);

  /// Icon Typical (#165964)
  static const Color iconTypical = Color(0xFF165964);

  // ---------------------------------------------------------------------------
  // Support / Semantic Colours
  // ---------------------------------------------------------------------------

  /// Support Negative (#EB0000)
  static const Color error = Color(0xFFEB0000);

  /// Support Positive (#278829)
  static const Color success = Color(0xFF278829);

  /// Support Warning (#D84008)
  static const Color warning = Color(0xFFD84008);

  /// Support Variable (#145599)
  static const Color info = Color(0xFF145599);

  /// Support Typical (#165964)
  static const Color typical = Color(0xFF165964);

  /// Support Negative Neutral (#F9EBEF)
  static const Color errorNeutral = Color(0xFFF9EBEF);

  /// Support Positive Neutral (#EFF9EB)
  static const Color successNeutral = Color(0xFFEFF9EB);

  /// Support Warning Neutral (#F9F1EB)
  static const Color warningNeutral = Color(0xFFF9F1EB);

  /// Support Typical Neutral (#E3F5F8)
  static const Color typicalNeutral = Color(0xFFE3F5F8);

  // ---------------------------------------------------------------------------
  // Neutral Colours — tinted surface backgrounds
  // ---------------------------------------------------------------------------

  /// Neutral-1 (#F1F4F7)
  static const Color neutral1 = Color(0xFFF1F4F7);

  /// Neutral-2 (#EBF9F8)
  static const Color neutral2 = Color(0xFFEBF9F8);

  /// Neutral-3 (#EBF0F9)
  static const Color neutral3 = Color(0xFFEBF0F9);

  /// Neutral-4 (#F4EBF9)
  static const Color neutral4 = Color(0xFFF4EBF9);

  /// Neutral-5 (#F9F6EB)
  static const Color neutral5 = Color(0xFFF9F6EB);

  /// Neutral-6 (#B8DDDB)
  static const Color neutral6 = Color(0xFFB8DDDB);

  // ---------------------------------------------------------------------------
  // Stroke Colours — component/UI element borders
  // ---------------------------------------------------------------------------

  /// Stroke Default (#E2E2E2)
  static const Color border = Color(0xFFE2E2E2);

  /// Stroke Default alias
  static const Color divider = border;

  /// Stroke Active (#404040)
  static const Color strokeActive = Color(0xFF404040);

  /// Stroke Disabled (#B4B4B4)
  static const Color strokeDisabled = Color(0xFFB4B4B4);

  /// Stroke Selected (#F14687)
  static const Color strokeSelected = Color(0xFFF14687);

  /// Stroke Secondary Selected (#81C1BD)
  static const Color strokeSecondarySelected = Color(0xFF81C1BD);

  /// Stroke Hover (#F9B0CC)
  static const Color strokeHover = Color(0xFFF9B0CC);

  // ---------------------------------------------------------------------------
  // Overlay & States
  // ---------------------------------------------------------------------------

  /// Overlay (#000000, 50%)
  static const Color overlay = Color(0x80000000);

  /// Selected Hover/Focus (#F14687, 8%)
  static const Color selectedHover = Color(0x14F14687);

  /// Selected Pressed (#F9B0CC)
  static const Color selectedPressed = Color(0xFFF9B0CC);

  /// Secondary Hover (#F3FBFB)
  static const Color secondaryHover = Color(0xFFF3FBFB);

  /// Selected Secondary Pressed (#E6F8F4)
  static const Color selectedSecondaryPressed = Color(0xFFE6F8F4);

  /// Visited Text Link (#9911ED)
  static const Color visitedLink = Color(0xFF9911ED);

  /// Unselected Default (#B4B4B4)
  static const Color unselectedDefault = Color(0xFFB4B4B4);

  /// Unselected Hover/Focus (#B4B4B4, 12%)
  static const Color unselectedHover = Color(0x1FB4B4B4);

  /// Unselected Pressed (#B4B4B4, 16%)
  static const Color unselectedPressed = Color(0x29B4B4B4);

  /// Disabled Surface (#F1F1F1)
  static const Color disabledSurface = Color(0xFFF1F1F1);

  /// General disabled color (#B4B4B4)
  static const Color disabled = Color(0xFFB4B4B4);

  // ---------------------------------------------------------------------------
  // Data Visualization
  // ---------------------------------------------------------------------------

  static const List<Color> dataVis = [
    Color(0xFF97144D), // Action Primary
    Color(0xFFED1164), // Action Secondary
    Color(0xFF12877F), // Action Tertiary
    Color(0xFF278829), // Support Positive
    Color(0xFFD84008), // Support Warning
    Color(0xFF145599), // Support Variable
    Color(0xFF165964), // Typical
    Color(0xFFB8DDDB), // Neutral-6
  ];
}
