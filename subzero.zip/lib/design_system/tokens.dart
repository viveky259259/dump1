import 'package:flutter/material.dart';

/// Subzero 2.0 (Axis Bank) Design Tokens
///
/// This file is the **single source of truth** for visual design values.
///
/// Usage:
/// - Prefer `tokens` (root) for maximum discoverability.
/// - Or use the convenience exports: `colors`, `typography`, `spacing`, `radius`, `elevation`, `dataviz`.
///
/// Rules:
/// - No component styling should hardcode values; consume tokens instead.
/// - All colors here are authored as hex literals and are intended to meet WCAG AA
///   contrast when used as specified (e.g., `text.*` on `bg.*`).
/// - Data-viz palettes are chosen to remain distinguishable under common
///   red/green color vision deficiencies.
/// Convenience export: color tokens.
const colors = SubzeroColorTokens._();

/// Convenience export: typography tokens.
const typography = SubzeroTypographyTokens._();

/// Convenience export: spacing tokens.
const spacing = SubzeroSpacingTokens._();

/// Convenience export: radius tokens.
const radius = SubzeroRadiusTokens._();

/// Convenience export: elevation/shadow tokens.
const elevation = SubzeroElevationTokens._();

/// Convenience export: data visualization tokens.
const dataviz = SubzeroDataVizTokens._();

/// Root token tree.
const tokens = SubzeroTokens._(
  color: colors,
  typography: typography,
  spacing: spacing,
  radius: radius,
  elevation: elevation,
  dataviz: dataviz,
);

/// Root token tree.
class SubzeroTokens {
  /// Color tokens: brand palette, neutrals, semantics, and aliases.
  final SubzeroColorTokens color;

  /// Typography tokens: type scale + weights.
  final SubzeroTypographyTokens typography;

  /// Spacing tokens: 8px base grid.
  final SubzeroSpacingTokens spacing;

  /// Radius tokens: corners and pill shapes.
  final SubzeroRadiusTokens radius;

  /// Elevation tokens: shadows.
  final SubzeroElevationTokens elevation;

  /// Data visualization tokens: categorical + gradients.
  final SubzeroDataVizTokens dataviz;

  const SubzeroTokens._({
    required this.color,
    required this.typography,
    required this.spacing,
    required this.radius,
    required this.elevation,
    required this.dataviz,
  });
}

/// Color tokens.
///
/// All values sourced from the official Subzero design system spec.
/// See: https://www.subzero.axis.bank.in/foundations/colours
///
/// Usage:
/// - Actions: `tokens.color.action.primary`
/// - Surfaces: `tokens.color.surface.background`
/// - Text: `tokens.color.text.primary`
/// - Icons: `tokens.color.icon.defaultColor`
/// - Semantics: `tokens.color.semantic.negative`
/// - Strokes: `tokens.color.stroke.defaultColor`
/// - States: `tokens.color.state.overlay`
class SubzeroColorTokens {
  /// Brand primary ramp (50 → 900), anchored at 500 (#97144D).
  final SubzeroColorRamp primary = const SubzeroColorRamp._primary();

  /// Action colors for clickable elements.
  final SubzeroActionColors action = const SubzeroActionColors._();

  /// Surface colors for backgrounds.
  final SubzeroSurfaceColors surface = const SubzeroSurfaceColors._();

  /// Gray-scale neutral palette (n0–n900).
  final SubzeroNeutralColors neutral = const SubzeroNeutralColors._();

  /// Tinted neutral accent backgrounds (Neutral-1 through Neutral-6).
  final SubzeroNeutralAccentColors neutralAccent = const SubzeroNeutralAccentColors._();

  /// Semantic/support colors (negative/positive/warning + neutrals + typical).
  final SubzeroSemanticColors semantic = const SubzeroSemanticColors._();

  /// Typography color tokens (standard, action, edge cases).
  final SubzeroTypographyColors typo = const SubzeroTypographyColors._();

  /// Alias tokens for text usage.
  final SubzeroTextAliasColors text = const SubzeroTextAliasColors._();

  /// Alias tokens for background usage.
  final SubzeroBackgroundAliasColors bg = const SubzeroBackgroundAliasColors._();

  /// Icon color tokens.
  final SubzeroIconColors icon = const SubzeroIconColors._();

  /// Stroke/border color tokens.
  final SubzeroStrokeColors stroke = const SubzeroStrokeColors._();

  /// Overlay and interaction state colors.
  final SubzeroOverlayStateColors state = const SubzeroOverlayStateColors._();

  /// @Deprecated Use [action.secondary] instead.
  Color get secondary500 => action.secondary;

  /// @Deprecated Use [action.tertiary] instead.
  Color get accent500 => action.tertiary;

  const SubzeroColorTokens._();
}

/// A typed color ramp with numeric steps.
///
/// Access with bracket notation: `tokens.color.primary[600]`.
class SubzeroColorRamp {
  final Color c50;
  final Color c100;
  final Color c200;
  final Color c300;
  final Color c400;
  final Color c500;
  final Color c600;
  final Color c700;
  final Color c800;
  final Color c900;

  const SubzeroColorRamp({
    required this.c50,
    required this.c100,
    required this.c200,
    required this.c300,
    required this.c400,
    required this.c500,
    required this.c600,
    required this.c700,
    required this.c800,
    required this.c900,
  });

  /// Primary tint/shade ramp, interpolated around the 500 anchor.
  ///
  /// Notes:
  /// - 50/200/300/500/700 align to the provided sequential stops.
  /// - 600/700 match the specified hover/active states.
  const SubzeroColorRamp._primary()
      : c50 = const Color(0xFFF8E6EC),
        c100 = const Color(0xFFF2D0DC),
        c200 = const Color(0xFFE4A9BE),
        c300 = const Color(0xFFC66A8F),
        c400 = const Color(0xFFAD3A69),
        c500 = const Color(0xFF97144D),
        c600 = const Color(0xFF7E103F),
        c700 = const Color(0xFF660D33),
        c800 = const Color(0xFF520A29),
        c900 = const Color(0xFF3A071D);

  /// Returns the color for the given step.
  ///
  /// Supported steps: 50, 100, 200, 300, 400, 500, 600, 700, 800, 900.
  Color operator [](int step) => switch (step) {
        50 => c50,
        100 => c100,
        200 => c200,
        300 => c300,
        400 => c400,
        500 => c500,
        600 => c600,
        700 => c700,
        800 => c800,
        900 => c900,
        _ => c500,
      };
}

/// Action colors — applied to clickable elements.
class SubzeroActionColors {
  /// Action Primary (#97144D) — key CTA buttons
  final Color primary = const Color(0xFF97144D);

  /// Action Secondary (#ED1164) — text buttons, radio, toggles
  final Color secondary = const Color(0xFFED1164);

  /// Action Tertiary (#12877F) — upload buttons, least-important actions
  final Color tertiary = const Color(0xFF12877F);

  const SubzeroActionColors._();
}

/// Surface colors — non-clickable backgrounds.
class SubzeroSurfaceColors {
  /// Surface Background (#FFFFFF)
  final Color background = const Color(0xFFFFFFFF);

  /// Surface Primary (#FFFFFF)
  final Color primary = const Color(0xFFFFFFFF);

  /// Surface Secondary (#F9F9F9)
  final Color secondary = const Color(0xFFF9F9F9);

  /// Surface Tertiary (#404040)
  final Color tertiary = const Color(0xFF404040);

  const SubzeroSurfaceColors._();
}

/// Gray-scale neutral palette.
class SubzeroNeutralColors {
  final Color n0 = const Color(0xFFFFFFFF);
  final Color n50 = const Color(0xFFFAFAFA);
  final Color n100 = const Color(0xFFF5F5F5);
  final Color n200 = const Color(0xFFEEEEEE);
  final Color n300 = const Color(0xFFE0E0E0);
  final Color n400 = const Color(0xFFBDBDBD);
  final Color n500 = const Color(0xFF9E9E9E);
  final Color n600 = const Color(0xFF757575);
  final Color n700 = const Color(0xFF616161);
  final Color n800 = const Color(0xFF424242);
  final Color n900 = const Color(0xFF212121);

  const SubzeroNeutralColors._();
}

/// Tinted neutral accent backgrounds from the official spec.
class SubzeroNeutralAccentColors {
  /// Neutral-1 (#F1F4F7)
  final Color n1 = const Color(0xFFF1F4F7);

  /// Neutral-2 (#EBF9F8)
  final Color n2 = const Color(0xFFEBF9F8);

  /// Neutral-3 (#EBF0F9)
  final Color n3 = const Color(0xFFEBF0F9);

  /// Neutral-4 (#F4EBF9)
  final Color n4 = const Color(0xFFF4EBF9);

  /// Neutral-5 (#F9F6EB)
  final Color n5 = const Color(0xFFF9F6EB);

  /// Neutral-6 (#B8DDDB)
  final Color n6 = const Color(0xFFB8DDDB);

  const SubzeroNeutralAccentColors._();
}

/// Typography color tokens (standard, action, edge cases).
class SubzeroTypographyColors {
  // Standard (non-clickable text)

  /// Typo Primary (#282828)
  final Color primary = const Color(0xFF282828);

  /// Typo Secondary (#6E6E6E)
  final Color secondary = const Color(0xFF6E6E6E);

  /// Typo Tertiary (#9D9D9D)
  final Color tertiary = const Color(0xFF9D9D9D);

  // Action (clickable text)

  /// Typo Primary Action (#97144D)
  final Color primaryAction = const Color(0xFF97144D);

  /// Typo Secondary Action (#ED1164)
  final Color secondaryAction = const Color(0xFFED1164);

  /// Typo Tertiary Action (#12877F)
  final Color tertiaryAction = const Color(0xFF12877F);

  // Edge Cases

  /// Typo On-Surface (#FFFFFF)
  final Color onSurface = const Color(0xFFFFFFFF);

  /// Typo Disabled (#B4B4B4)
  final Color disabled = const Color(0xFFB4B4B4);

  /// Typo Typical (#165964)
  final Color typical = const Color(0xFF165964);

  const SubzeroTypographyColors._();
}

/// Icon color tokens.
class SubzeroIconColors {
  // Standard

  /// Icon Default (#404040)
  final Color defaultColor = const Color(0xFF404040);

  // Action

  /// Icon Primary Action (#97144D)
  final Color primaryAction = const Color(0xFF97144D);

  /// Icon Secondary Action (#ED1164)
  final Color secondaryAction = const Color(0xFFED1164);

  /// Icon Tertiary Action (#12877F)
  final Color tertiaryAction = const Color(0xFF12877F);

  // Support

  /// Icon Support Negative (#EB0000)
  final Color supportNegative = const Color(0xFFEB0000);

  /// Icon Support Positive (#278829)
  final Color supportPositive = const Color(0xFF278829);

  /// Icon Support Warning (#D84008)
  final Color supportWarning = const Color(0xFFD84008);

  // Edge Cases

  /// Icon On-Surface (#FFFFFF)
  final Color onSurface = const Color(0xFFFFFFFF);

  /// Icon Disabled (#B4B4B4)
  final Color disabled = const Color(0xFFB4B4B4);

  /// Icon Typical (#165964)
  final Color typical = const Color(0xFF165964);

  const SubzeroIconColors._();
}

/// Stroke/border color tokens.
class SubzeroStrokeColors {
  /// Stroke Default (#E2E2E2)
  final Color defaultColor = const Color(0xFFE2E2E2);

  /// Stroke Active (#404040)
  final Color active = const Color(0xFF404040);

  /// Stroke Disabled (#B4B4B4)
  final Color disabled = const Color(0xFFB4B4B4);

  /// Stroke Selected (#F14687)
  final Color selected = const Color(0xFFF14687);

  /// Stroke Secondary Selected (#81C1BD)
  final Color secondarySelected = const Color(0xFF81C1BD);

  /// Stroke Hover (#F9B0CC)
  final Color hover = const Color(0xFFF9B0CC);

  const SubzeroStrokeColors._();
}

/// Overlay and interaction state color tokens.
class SubzeroOverlayStateColors {
  /// Overlay (#000000, 50%)
  final Color overlay = const Color(0x80000000);

  /// Selected Hover/Focus (#F14687, 8%)
  final Color selectedHover = const Color(0x14F14687);

  /// Selected Pressed (#F9B0CC)
  final Color selectedPressed = const Color(0xFFF9B0CC);

  /// Secondary Hover (#F3FBFB)
  final Color secondaryHover = const Color(0xFFF3FBFB);

  /// Selected Secondary Pressed (#E6F8F4)
  final Color selectedSecondaryPressed = const Color(0xFFE6F8F4);

  /// Visited Text Link (#9911ED)
  final Color visitedLink = const Color(0xFF9911ED);

  /// Unselected Default (#B4B4B4)
  final Color unselectedDefault = const Color(0xFFB4B4B4);

  /// Unselected Hover/Focus (#B4B4B4, 12%)
  final Color unselectedHover = const Color(0x1FB4B4B4);

  /// Unselected Pressed (#B4B4B4, 16%)
  final Color unselectedPressed = const Color(0x29B4B4B4);

  /// Disabled Surface (#F1F1F1)
  final Color disabledSurface = const Color(0xFFF1F1F1);

  const SubzeroOverlayStateColors._();
}

/// Semantic color group with 100/500/700 variants.
class SubzeroSemanticRamp {
  final Color c100;
  final Color c500;
  final Color c700;

  const SubzeroSemanticRamp({required this.c100, required this.c500, required this.c700});

  Color operator [](int step) => switch (step) {
        100 => c100,
        500 => c500,
        700 => c700,
        _ => c500,
      };
}

/// Support/semantic color tokens matching the official Subzero spec.
///
/// Provides both:
/// - Flat colors via spec names: `negative`, `positive`, `typical`, `variable`
/// - Ramp access via legacy names: `error[500]`, `success[500]`, `warning[500]`, `info[500]`
class SubzeroSemanticColors {
  /// Support Negative (#EB0000) — error/destructive
  final Color negative = const Color(0xFFEB0000);

  /// Support Positive (#278829) — success/confirmation
  final Color positive = const Color(0xFF278829);

  /// Support Variable (#145599) — info/neutral status
  final Color variable = const Color(0xFF145599);

  /// Support Typical (#165964) — default/standard
  final Color typical = const Color(0xFF165964);

  /// Support Negative Neutral (#F9EBEF)
  final Color negativeNeutral = const Color(0xFFF9EBEF);

  /// Support Positive Neutral (#EFF9EB)
  final Color positiveNeutral = const Color(0xFFEFF9EB);

  /// Support Warning Neutral (#F9F1EB)
  final Color warningNeutral = const Color(0xFFF9F1EB);

  /// Support Typical Neutral (#E3F5F8)
  final Color typicalNeutral = const Color(0xFFE3F5F8);

  // Ramp accessors — backward compatible with `semantic.error[500]` etc.

  /// Error/negative ramp: c100=#F9EBEF, c500=#EB0000
  SubzeroSemanticRamp get error => const SubzeroSemanticRamp(
        c100: Color(0xFFF9EBEF),
        c500: Color(0xFFEB0000),
        c700: Color(0xFFC00000),
      );

  /// Success/positive ramp: c100=#EFF9EB, c500=#278829
  SubzeroSemanticRamp get success => const SubzeroSemanticRamp(
        c100: Color(0xFFEFF9EB),
        c500: Color(0xFF278829),
        c700: Color(0xFF1A6B1C),
      );

  /// Warning ramp: c100=#F9F1EB, c500=#D84008
  SubzeroSemanticRamp get warning => const SubzeroSemanticRamp(
        c100: Color(0xFFF9F1EB),
        c500: Color(0xFFD84008),
        c700: Color(0xFFB03306),
      );

  /// Info/variable ramp: c100=#E3F5F8, c500=#145599
  SubzeroSemanticRamp get info => const SubzeroSemanticRamp(
        c100: Color(0xFFE3F5F8),
        c500: Color(0xFF145599),
        c700: Color(0xFF0E3D6E),
      );

  const SubzeroSemanticColors._();
}

/// Alias tokens for text colors — matches official Subzero typography spec.
///
/// Intended combinations (WCAG AA):
/// - `primary/secondary/disabled` on `bg.default/bg.surface/bg.subtle`
/// - `inverse` on `color.primary[500]` or dark surfaces
class SubzeroTextAliasColors {
  /// Typo Primary (#282828)
  final Color primary = const Color(0xFF282828);

  /// Typo Secondary (#6E6E6E)
  final Color secondary = const Color(0xFF6E6E6E);

  /// Typo Disabled (#B4B4B4)
  final Color disabled = const Color(0xFFB4B4B4);

  /// Typo On-Surface (#FFFFFF)
  final Color inverse = const Color(0xFFFFFFFF);

  const SubzeroTextAliasColors._();
}

/// Alias tokens for background colors — matches official Subzero surface spec.
class SubzeroBackgroundAliasColors {
  /// Surface Background (#FFFFFF)
  final Color defaultBg = const Color(0xFFFFFFFF);

  /// Surface Secondary (#F9F9F9)
  final Color surface = const Color(0xFFF9F9F9);

  /// Neutral-1 (#F1F4F7)
  final Color subtle = const Color(0xFFF1F4F7);

  /// Disabled Surface (#F1F1F1)
  final Color disabled = const Color(0xFFF1F1F1);

  const SubzeroBackgroundAliasColors._();
}

/// Typography tokens.
///
/// Notes:
/// - Font family stack is encoded using `fontFamily` + `fontFamilyFallback`.
/// - Overline includes uppercase intent + 1.5px letter spacing.
class SubzeroTypographyTokens {
  /// Font family stack.
  final SubzeroFontFamilyTokens fontFamily = const SubzeroFontFamilyTokens._();

  /// Font weight tokens.
  final SubzeroFontWeightTokens weight = const SubzeroFontWeightTokens._();

  /// Type scale tokens.
  final SubzeroTypeScaleTokens scale = const SubzeroTypeScaleTokens._();

  /// Convenience aliases.
  SubzeroTextToken get h1 => scale.h1;
  SubzeroTextToken get h2 => scale.h2;
  SubzeroTextToken get h3 => scale.h3;
  SubzeroTextToken get h4 => scale.h4;
  SubzeroTextToken get h5 => scale.h5;
  SubzeroTextToken get h6 => scale.h6;
  SubzeroTextToken get bodyLarge => scale.bodyLarge;
  SubzeroTextToken get bodyMedium => scale.bodyMedium;
  SubzeroTextToken get bodySmall => scale.bodySmall;
  SubzeroTextToken get caption => scale.caption;
  SubzeroTextToken get overline => scale.overline;

  const SubzeroTypographyTokens._();
}

/// Font family stack.
class SubzeroFontFamilyTokens {
  /// Primary family name used by Flutter.
  final String primary = 'Inter';

  /// Fallback stack.
  final List<String> fallbacks = const ['Roboto', 'Helvetica Neue', 'sans-serif'];

  const SubzeroFontFamilyTokens._();
}

/// Font weights.
class SubzeroFontWeightTokens {
  final FontWeight regular = FontWeight.w400;
  final FontWeight medium = FontWeight.w500;
  final FontWeight semibold = FontWeight.w600;
  final FontWeight bold = FontWeight.w700;

  const SubzeroFontWeightTokens._();
}

/// A text token with additional behavioral hints.
class SubzeroTextToken {
  /// The base style (color is intentionally not embedded).
  final TextStyle style;

  /// True when the consumer should render the text in uppercase.
  final bool uppercase;

  const SubzeroTextToken({required this.style, this.uppercase = false});
}

/// Type scale.
class SubzeroTypeScaleTokens {
  const SubzeroTypeScaleTokens._();

  TextStyle _base(FontWeight w, double sizePx, double lineHeightPx, {double? letterSpacing}) => TextStyle(
        fontFamily: tokens.typography.fontFamily.primary,
        fontFamilyFallback: tokens.typography.fontFamily.fallbacks,
        fontWeight: w,
        fontSize: sizePx,
        height: lineHeightPx / sizePx,
        letterSpacing: letterSpacing,
      );

  SubzeroTextToken get h1 => SubzeroTextToken(
        style: _base(tokens.typography.weight.bold, 40, 48),
      );

  SubzeroTextToken get h2 => SubzeroTextToken(
        style: _base(tokens.typography.weight.semibold, 32, 40),
      );

  SubzeroTextToken get h3 => SubzeroTextToken(
        style: _base(tokens.typography.weight.semibold, 28, 36),
      );

  SubzeroTextToken get h4 => SubzeroTextToken(
        style: _base(tokens.typography.weight.semibold, 24, 32),
      );

  SubzeroTextToken get h5 => SubzeroTextToken(
        style: _base(tokens.typography.weight.medium, 20, 28),
      );

  SubzeroTextToken get h6 => SubzeroTextToken(
        style: _base(tokens.typography.weight.medium, 18, 26),
      );

  SubzeroTextToken get bodyLarge => SubzeroTextToken(
        style: _base(tokens.typography.weight.regular, 16, 24),
      );

  SubzeroTextToken get bodyMedium => SubzeroTextToken(
        style: _base(tokens.typography.weight.regular, 14, 22),
      );

  SubzeroTextToken get bodySmall => SubzeroTextToken(
        style: _base(tokens.typography.weight.regular, 12, 18),
      );

  SubzeroTextToken get caption => SubzeroTextToken(
        style: _base(tokens.typography.weight.regular, 12, 16),
      );

  SubzeroTextToken get overline => SubzeroTextToken(
        style: _base(tokens.typography.weight.medium, 10, 14, letterSpacing: 1.5),
        uppercase: true,
      );
}

/// Spacing tokens (8px base grid).
///
/// Use these for padding, gaps, and layout dimensions.
class SubzeroSpacingTokens {
  final double xs = 4;
  final double sm = 8;
  final double md = 16;
  final double lg = 24;
  final double xl = 32;
  final double x2l = 40;
  final double x3l = 48;
  final double x4l = 64;

  const SubzeroSpacingTokens._();
}

/// Radius tokens.
///
/// Use these to create consistent corner rounding across components.
class SubzeroRadiusTokens {
  final double none = 0;
  final double sm = 4;
  final double md = 8;
  final double lg = 12;
  final double xl = 16;
  final double full = 9999;

  const SubzeroRadiusTokens._();

  BorderRadius circular(double r) => BorderRadius.circular(r);

  BorderRadius get smCircular => BorderRadius.circular(sm);
  BorderRadius get mdCircular => BorderRadius.circular(md);
  BorderRadius get lgCircular => BorderRadius.circular(lg);
  BorderRadius get xlCircular => BorderRadius.circular(xl);
}

/// Elevation / shadow tokens.
///
/// Avoid ad-hoc shadows; use one of the levels below.
class SubzeroElevationTokens {
  const SubzeroElevationTokens._();

  /// elevation.0 = none
  List<BoxShadow> get e0 => const [];

  /// elevation.1 = 0px 1px 3px rgba(0,0,0,0.12)
  List<BoxShadow> get e1 => const [
        BoxShadow(offset: Offset(0, 1), blurRadius: 3, spreadRadius: 0, color: Color(0x1F000000)),
      ];

  /// elevation.2 = 0px 3px 6px rgba(0,0,0,0.16)
  List<BoxShadow> get e2 => const [
        BoxShadow(offset: Offset(0, 3), blurRadius: 6, spreadRadius: 0, color: Color(0x29000000)),
      ];

  /// elevation.3 = 0px 6px 12px rgba(0,0,0,0.18)
  List<BoxShadow> get e3 => const [
        BoxShadow(offset: Offset(0, 6), blurRadius: 12, spreadRadius: 0, color: Color(0x2E000000)),
      ];

  /// elevation.4 = 0px 12px 24px rgba(0,0,0,0.22)
  List<BoxShadow> get e4 => const [
        BoxShadow(offset: Offset(0, 12), blurRadius: 24, spreadRadius: 0, color: Color(0x38000000)),
      ];

  /// elevation.5 = 0px 16px 32px rgba(0,0,0,0.24)
  List<BoxShadow> get e5 => const [
        BoxShadow(offset: Offset(0, 16), blurRadius: 32, spreadRadius: 0, color: Color(0x3D000000)),
      ];
}

/// Data visualization tokens.
///
/// - Categorical palette provides 6 distinct series colors.
/// - Sequential gradient is primary-based with 5 stops.
/// - Diverging palette supports negative → neutral → positive.
class SubzeroDataVizTokens {
  /// Categorical (6 series) — uses official Subzero action + support colors.
  final List<Color> categorical6 = const [
    Color(0xFF97144D), // Action Primary
    Color(0xFFED1164), // Action Secondary
    Color(0xFF12877F), // Action Tertiary
    Color(0xFF278829), // Support Positive
    Color(0xFFD84008), // Support Warning
    Color(0xFF145599), // Support Variable
  ];

  /// Sequential gradient stops (primary-based, 5 stops).
  final List<Color> sequentialPrimary5 = const [
    Color(0xFFF8E6EC),
    Color(0xFFE4A9BE),
    Color(0xFFC66A8F),
    Color(0xFF97144D),
    Color(0xFF660D33),
  ];

  /// Diverging (negative → neutral → positive) — uses official Subzero support colors.
  final List<Color> diverging3 = const [
    Color(0xFFEB0000), // Support Negative
    Color(0xFFF1F4F7), // Neutral-1
    Color(0xFF278829), // Support Positive
  ];

  const SubzeroDataVizTokens._();
}
