# Quill Customization & Enhancement Guide

This guide provides comprehensive documentation on customizing and enhancing Quill.js for your application.

---

## Table of Contents

1. [Quill Feature Enhancement](#1-quill-feature-enhancement)
2. [CSS Management for Quill](#2-css-management-for-quill)
3. [Toolbar Enhancement](#3-toolbar-enhancement)
4. [Editor Enhancement](#4-editor-enhancement)
5. [Best Practices](#5-best-practices)

---

## 1. Quill Feature Enhancement

### 1.1 Understanding Quill Architecture

Quill is built on a modular architecture with these core components:

| Component | Purpose |
|-----------|---------|
| **Quill** | Main entry point, coordinates all components |
| **Parchment** | Document model framework for custom content |
| **Blots** | Building blocks representing content (text, images, etc.) |
| **Delta** | JSON format representing document content and changes |
| **Modules** | Pluggable functionality (toolbar, clipboard, keyboard, etc.) |

### 1.2 Adding New Features

#### Method 1: Using Existing Modules

```javascript
const quill = new Quill('#editor', {
  modules: {
    toolbar: toolbarOptions,
    history: { delay: 2000, maxStack: 500 },
    clipboard: { matchVisual: false },
    keyboard: { bindings: customBindings }
  },
  theme: 'snow'
});
```

#### Method 2: Registering Custom Blots

Create custom content types by extending Parchment Blots:

```javascript
// Custom Blot for mentions
const Embed = Quill.import('blots/embed');

class MentionBlot extends Embed {
  static blotName = 'mention';
  static tagName = 'span';
  static className = 'mention';

  static create(data) {
    const node = super.create();
    node.setAttribute('data-id', data.id);
    node.setAttribute('data-value', data.value);
    node.textContent = `@${data.value}`;
    return node;
  }

  static value(node) {
    return {
      id: node.getAttribute('data-id'),
      value: node.getAttribute('data-value')
    };
  }
}

// Register the blot
Quill.register(MentionBlot);

// Use it
quill.insertEmbed(index, 'mention', { id: '123', value: 'John' });
```

#### Method 3: Creating Custom Modules

```javascript
class FormatPainter {
  constructor(quill, options) {
    this.quill = quill;
    this.options = options;
    this.storedFormat = null;
    this.isActive = false;
    
    // Add toolbar button handler
    const toolbar = quill.getModule('toolbar');
    toolbar.addHandler('format-painter', this.handleClick.bind(this));
    
    // Listen for selection changes
    quill.on('selection-change', this.onSelectionChange.bind(this));
  }

  copyFormat() {
    const range = this.quill.getSelection();
    if (range) {
      this.storedFormat = this.quill.getFormat(range);
      this.isActive = true;
    }
  }

  applyFormat(range) {
    if (this.storedFormat && range) {
      Object.keys(this.storedFormat).forEach(format => {
        this.quill.format(format, this.storedFormat[format]);
      });
      this.isActive = false;
    }
  }

  handleClick() {
    if (this.isActive) {
      this.isActive = false;
    } else {
      this.copyFormat();
    }
  }

  onSelectionChange(range) {
    if (this.isActive && range && range.length > 0) {
      this.applyFormat(range);
    }
  }
}

// Register the module
Quill.register('modules/formatPainter', FormatPainter);

// Use it
const quill = new Quill('#editor', {
  modules: {
    formatPainter: true
  }
});
```

#### Method 4: External Plugins

```html
<!-- Include plugin CSS/JS -->
<link href="quill-table-better.css" rel="stylesheet">
<script src="quill-table-better.js"></script>

<script>
  Quill.register({
    'modules/table-better': QuillTableBetter
  }, true);

  const quill = new Quill('#editor', {
    modules: {
      'table-better': {
        operationMenu: {
          items: {
            insertColumnLeft: { text: 'Insert Column Left' },
            insertColumnRight: { text: 'Insert Column Right' }
          }
        }
      }
    }
  });
</script>
```

### 1.3 Common Feature Enhancements

| Feature | Implementation Approach |
|---------|------------------------|
| Image Resize | Custom module with DOM manipulation |
| Mentions | Custom Embed Blot + dropdown UI |
| Emoji Picker | Toolbar handler + popup UI |
| Tables | quill-table-better plugin |
| Format Painter | Custom module tracking formats |
| Markdown Shortcuts | Keyboard bindings |
| Auto-link URLs | Text-change event listener |

---

## 2. CSS Management for Quill

### 2.1 CSS Loading Order

**Critical**: Load CSS in this exact order to prevent conflicts:

```html
<!-- 1. Quill base theme (REQUIRED) -->
<link href="quill.snow.css" rel="stylesheet">

<!-- 2. Plugin CSS (before custom styles) -->
<link href="quill-table-better.css" rel="stylesheet">

<!-- 3. Your custom styles (LAST - highest priority) -->
<style>
  /* Custom overrides here */
</style>
```

### 2.2 Using CSS Variables for Theming

Define CSS variables for consistent theming:

```css
:root {
  /* Colors */
  --ql-primary: #1a73e8;
  --ql-primary-hover: #1557b0;
  --ql-border: #dadce0;
  --ql-background: #ffffff;
  --ql-text: #202124;
  --ql-text-secondary: #5f6368;
  
  /* Spacing */
  --ql-toolbar-padding: 8px 12px;
  --ql-editor-padding: 16px 24px;
  
  /* Typography */
  --ql-font-family: 'Mulish', sans-serif;
  --ql-font-size: 14px;
  --ql-line-height: 1.6;
  
  /* Borders */
  --ql-border-radius: 4px;
  --ql-border-width: 1px;
}
```

### 2.3 Common CSS Overrides

#### Toolbar Styling

```css
/* Toolbar container */
.ql-toolbar.ql-snow {
  border: var(--ql-border-width) solid var(--ql-border);
  border-radius: var(--ql-border-radius) var(--ql-border-radius) 0 0;
  background: var(--ql-background);
  padding: var(--ql-toolbar-padding);
}

/* Toolbar buttons */
.ql-toolbar .ql-formats button {
  width: 32px;
  height: 32px;
  padding: 4px;
  border-radius: var(--ql-border-radius);
  transition: background-color 0.2s;
}

.ql-toolbar .ql-formats button:hover {
  background-color: rgba(0, 0, 0, 0.05);
}

.ql-toolbar .ql-formats button.ql-active {
  background-color: var(--ql-primary);
  color: white;
}

/* Toolbar dropdowns */
.ql-toolbar .ql-picker {
  height: 32px;
}

.ql-toolbar .ql-picker-label {
  border-radius: var(--ql-border-radius);
  padding: 4px 8px;
}
```

#### Editor Container

```css
/* Editor container */
.ql-container.ql-snow {
  border: var(--ql-border-width) solid var(--ql-border);
  border-top: none;
  border-radius: 0 0 var(--ql-border-radius) var(--ql-border-radius);
  font-family: var(--ql-font-family);
  font-size: var(--ql-font-size);
}

/* Editor content area */
.ql-editor {
  padding: var(--ql-editor-padding);
  min-height: 300px;
  max-height: 600px;
  overflow-y: auto;
  line-height: var(--ql-line-height);
  color: var(--ql-text);
}

/* Placeholder text */
.ql-editor.ql-blank::before {
  color: var(--ql-text-secondary);
  font-style: normal;
  left: var(--ql-editor-padding);
}
```

### 2.4 List Styling (Quill 2.0)

**Important**: Quill 2.0 uses pseudo-elements (`.ql-ui::before`) for bullets/numbers. Don't override these:

```css
/* ✅ Correct - Let Quill handle bullets */
.ql-editor ol,
.ql-editor ul {
  padding-left: 0;
  margin: 0 0 1em 0;
}

.ql-editor li {
  padding-left: 1.5em;
  margin-bottom: 0.25em;
}

/* ❌ Wrong - This causes double bullets */
.ql-editor ul li {
  list-style-type: disc; /* Don't do this! */
}

/* Nested list indentation */
.ql-editor li.ql-indent-1 { padding-left: 3em; }
.ql-editor li.ql-indent-2 { padding-left: 4.5em; }
.ql-editor li.ql-indent-3 { padding-left: 6em; }
```

### 2.5 Custom Font Families

```css
/* Register fonts in CSS */
.ql-font-mulish { font-family: 'Mulish', sans-serif; }
.ql-font-roboto { font-family: 'Roboto', sans-serif; }
.ql-font-montserrat { font-family: 'Montserrat', sans-serif; }

/* Add to Quill's font whitelist */
<script>
  const Font = Quill.import('formats/font');
  Font.whitelist = ['mulish', 'roboto', 'montserrat'];
  Quill.register(Font, true);
</script>
```

### 2.6 When to Add Custom CSS

| Scenario | Where to Add CSS |
|----------|------------------|
| Theming (colors, fonts) | CSS variables in `:root` |
| Toolbar appearance | `.ql-toolbar` selectors |
| Editor content styling | `.ql-editor` selectors |
| Custom blot styling | Blot's `className` selector |
| Plugin overrides | After plugin CSS, before closing `</style>` |
| Print styles | `@media print { }` block |

---

## 3. Toolbar Enhancement

### 3.1 Toolbar Configuration

#### Basic Configuration (Array Format)

```javascript
const toolbarOptions = [
  ['bold', 'italic', 'underline', 'strike'],
  ['blockquote', 'code-block'],
  [{ 'header': 1 }, { 'header': 2 }],
  [{ 'list': 'ordered' }, { 'list': 'bullet' }],
  [{ 'indent': '-1' }, { 'indent': '+1' }],
  [{ 'color': [] }, { 'background': [] }],
  [{ 'font': [] }],
  [{ 'align': [] }],
  ['link', 'image', 'video'],
  ['clean']
];
```

#### Advanced Configuration (Object Format)

```javascript
const toolbarOptions = {
  container: [
    ['bold', 'italic', 'underline'],
    [{ 'header': [1, 2, 3, false] }],
    ['link', 'image'],
    ['format-painter', 'emoji'], // Custom buttons
    ['clean']
  ],
  handlers: {
    'format-painter': function() {
      FormatPainter.handleClick();
    },
    'emoji': function() {
      toggleEmojiPicker();
    },
    'image': function() {
      // Custom image handler
      openImageUploadModal();
    }
  }
};
```

### 3.2 Adding Custom Toolbar Buttons

#### Step 1: Add Button to Container

```javascript
const toolbarOptions = {
  container: [
    // ... other options
    ['format-painter', 'html-insert', 'preview']
  ]
};
```

#### Step 2: Add Custom Handler

```javascript
const quill = new Quill('#editor', {
  modules: {
    toolbar: {
      container: toolbarOptions.container,
      handlers: {
        'format-painter': () => FormatPainter.handleClick(),
        'html-insert': () => openHtmlModal(),
        'preview': () => openPreviewModal()
      }
    }
  }
});
```

#### Step 3: Inject Custom Icons (After Initialization)

```javascript
// Wait for toolbar to render
setTimeout(() => {
  // Format Painter icon
  const formatPainterBtn = document.querySelector('.ql-format-painter');
  if (formatPainterBtn) {
    formatPainterBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="18" height="18">
        <path fill="currentColor" d="M18 4V3a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V6h1v4H9v11a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-9h8V4h-3z"/>
      </svg>
    `;
  }
  
  // HTML Insert icon
  const htmlBtn = document.querySelector('.ql-html-insert');
  if (htmlBtn) {
    htmlBtn.innerHTML = '<>'; // Or use SVG
    htmlBtn.title = 'Insert HTML';
  }
}, 0);
```

#### Step 4: Style Custom Buttons

```css
/* Base button style */
.ql-format-painter,
.ql-html-insert,
.ql-preview {
  width: 32px !important;
  height: 32px !important;
  display: flex !important;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: all 0.2s;
}

/* Active state */
.ql-format-painter.ql-active {
  background-color: #1a73e8 !important;
  color: white !important;
}

/* Visual indicator for active format painter */
.ql-format-painter.ql-active::after {
  content: '';
  position: absolute;
  bottom: 2px;
  left: 50%;
  transform: translateX(-50%);
  width: 4px;
  height: 4px;
  background: #ff9800;
  border-radius: 50%;
}
```

### 3.3 Adding Tooltips to Toolbar

```javascript
function addTooltipsToToolbar() {
  const tooltips = {
    '.ql-bold': 'Bold (Ctrl+B)',
    '.ql-italic': 'Italic (Ctrl+I)',
    '.ql-underline': 'Underline (Ctrl+U)',
    '.ql-strike': 'Strikethrough',
    '.ql-blockquote': 'Quote',
    '.ql-code-block': 'Code Block',
    '.ql-link': 'Insert Link (Ctrl+K)',
    '.ql-image': 'Insert Image',
    '.ql-video': 'Insert Video',
    '.ql-clean': 'Clear Formatting',
    '.ql-format-painter': 'Format Painter (Ctrl+Shift+F)',
    '.ql-emoji': 'Insert Emoji (Ctrl+Shift+E)',
    '.ql-preview': 'Preview (Ctrl+Shift+P)'
  };

  Object.entries(tooltips).forEach(([selector, title]) => {
    const element = document.querySelector(selector);
    if (element) {
      element.setAttribute('title', title);
    }
  });
}

// Call after Quill initialization
addTooltipsToToolbar();
```

### 3.4 Toolbar Button Groups

```css
/* Visual separation between button groups */
.ql-toolbar .ql-formats {
  margin-right: 12px;
  padding-right: 12px;
  border-right: 1px solid var(--ql-border);
}

.ql-toolbar .ql-formats:last-child {
  margin-right: 0;
  padding-right: 0;
  border-right: none;
}
```

---

## 4. Editor Enhancement

### 4.1 Keyboard Shortcuts

```javascript
const keyboardBindings = {
  // Save document
  save: {
    key: 'S',
    shortKey: true, // Ctrl/Cmd
    handler: function() {
      saveDocument();
      return false; // Prevent default
    }
  },
  
  // Custom formatting
  formatPainter: {
    key: 'F',
    shortKey: true,
    shiftKey: true,
    handler: function() {
      FormatPainter.handleClick();
      return false;
    }
  },
  
  // Insert horizontal rule
  horizontalRule: {
    key: '-',
    shortKey: true,
    handler: function(range) {
      this.quill.insertEmbed(range.index, 'divider', true, 'user');
      this.quill.setSelection(range.index + 1);
      return false;
    }
  },
  
  // Markdown-style shortcuts
  'header-1': {
    key: '1',
    shortKey: true,
    altKey: true,
    handler: function() {
      this.quill.format('header', 1);
    }
  }
};

const quill = new Quill('#editor', {
  modules: {
    keyboard: {
      bindings: keyboardBindings
    }
  }
});
```

### 4.2 Text Change Events

```javascript
// Debounced auto-save
let saveTimeout;
quill.on('text-change', (delta, oldDelta, source) => {
  if (source === 'user') {
    // Update word count
    updateWordCount();
    
    // Auto-save after 2 seconds of inactivity
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => {
      autoSave();
    }, 2000);
    
    // Auto-link URLs
    autoLinkUrls(delta);
  }
});

function updateWordCount() {
  const text = quill.getText().trim();
  const words = text ? text.split(/\s+/).length : 0;
  const chars = text.length;
  document.getElementById('word-count').textContent = 
    `${words} words, ${chars} characters`;
}

function autoLinkUrls(delta) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const text = quill.getText();
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    const url = match[0];
    const index = match.index;
    const format = quill.getFormat(index, url.length);
    
    if (!format.link) {
      quill.formatText(index, url.length, 'link', url, 'api');
    }
  }
}
```

### 4.3 Selection Change Events

```javascript
quill.on('selection-change', (range, oldRange, source) => {
  if (range) {
    // Update toolbar state
    const formats = quill.getFormat(range);
    updateToolbarState(formats);
    
    // Show/hide media resizer
    if (range.length === 0) {
      const [blot] = quill.getLeaf(range.index);
      if (blot && blot.domNode.tagName === 'IMG') {
        showMediaResizer(blot.domNode);
      } else {
        hideMediaResizer();
      }
    }
  } else {
    // Editor lost focus
    hideAllPopups();
  }
});
```

### 4.4 Image Handling

#### Drag & Drop Upload

```javascript
const editorContainer = document.querySelector('.ql-editor');

editorContainer.addEventListener('dragover', (e) => {
  e.preventDefault();
  editorContainer.classList.add('drag-over');
});

editorContainer.addEventListener('dragleave', () => {
  editorContainer.classList.remove('drag-over');
});

editorContainer.addEventListener('drop', (e) => {
  e.preventDefault();
  editorContainer.classList.remove('drag-over');
  
  const files = e.dataTransfer.files;
  for (const file of files) {
    if (file.type.startsWith('image/')) {
      uploadAndInsertImage(file);
    }
  }
});

async function uploadAndInsertImage(file) {
  // Option 1: Convert to base64 (for local/demo)
  const reader = new FileReader();
  reader.onload = () => {
    const range = quill.getSelection(true);
    quill.insertEmbed(range.index, 'image', reader.result);
  };
  reader.readAsDataURL(file);
  
  // Option 2: Upload to server
  // const formData = new FormData();
  // formData.append('image', file);
  // const response = await fetch('/api/upload', {
  //   method: 'POST',
  //   body: formData
  // });
  // const { url } = await response.json();
  // quill.insertEmbed(range.index, 'image', url);
}
```

#### Image Resize & Alignment

```javascript
let selectedMedia = null;

function selectMedia(img) {
  selectedMedia = img;
  positionResizer(img);
  showResizer();
}

function positionResizer(img) {
  const rect = img.getBoundingClientRect();
  const container = document.querySelector('.ql-container').getBoundingClientRect();
  
  const resizer = document.getElementById('media-resizer');
  resizer.style.left = `${rect.left - container.left}px`;
  resizer.style.top = `${rect.top - container.top}px`;
  resizer.style.width = `${rect.width}px`;
  resizer.style.height = `${rect.height}px`;
}

function setImageAlignment(alignment) {
  if (!selectedMedia) return;
  
  selectedMedia.style.display = 'block';
  switch (alignment) {
    case 'left':
      selectedMedia.style.float = 'left';
      selectedMedia.style.marginRight = '1em';
      break;
    case 'center':
      selectedMedia.style.float = 'none';
      selectedMedia.style.marginLeft = 'auto';
      selectedMedia.style.marginRight = 'auto';
      break;
    case 'right':
      selectedMedia.style.float = 'right';
      selectedMedia.style.marginLeft = '1em';
      break;
  }
}

function setImageSize(percent) {
  if (!selectedMedia) return;
  selectedMedia.style.width = `${percent}%`;
  selectedMedia.style.height = 'auto';
  positionResizer(selectedMedia);
}
```

### 4.5 Content Import/Export

```javascript
// Get content in different formats
function getContent(format = 'delta') {
  switch (format) {
    case 'delta':
      return quill.getContents();
    case 'html':
      return quill.root.innerHTML;
    case 'text':
      return quill.getText();
    case 'json':
      return JSON.stringify(quill.getContents());
  }
}

// Set content from different formats
function setContent(content, format = 'delta') {
  switch (format) {
    case 'delta':
      quill.setContents(content);
      break;
    case 'html':
      quill.root.innerHTML = content;
      break;
    case 'json':
      quill.setContents(JSON.parse(content));
      break;
  }
}

// Insert HTML at cursor
function insertHtml(html) {
  const range = quill.getSelection(true);
  const delta = quill.clipboard.convert({ html });
  quill.updateContents(
    new Delta().retain(range.index).concat(delta),
    'user'
  );
}
```

### 4.6 Zoom/Scale Support

```javascript
function setEditorZoom(scale) {
  const editor = document.querySelector('.ql-editor');
  editor.style.transform = `scale(${scale})`;
  editor.style.transformOrigin = 'top left';
  editor.style.width = `${100 / scale}%`;
}

// CSS for zoom
```css
.ql-container {
  overflow: auto;
}

.ql-editor {
  transition: transform 0.2s ease;
}
```

### 4.7 Flutter/WebView Integration

```javascript
// Send messages to Flutter
function sendToFlutter(type, data) {
  const message = JSON.stringify({ type, data });
  
  if (window.flutter_inappwebview) {
    window.flutter_inappwebview.callHandler('quillHandler', message);
  } else if (window.FlutterChannel) {
    window.FlutterChannel.postMessage(message);
  }
}

// Receive commands from Flutter
window.handleFlutterCommand = function(command, data) {
  switch (command) {
    case 'setContent':
      quill.setContents(JSON.parse(data));
      break;
    case 'getContent':
      sendToFlutter('content', quill.getContents());
      break;
    case 'getHtml':
      sendToFlutter('html', quill.root.innerHTML);
      break;
    case 'insertImage':
      const range = quill.getSelection(true);
      quill.insertEmbed(range.index, 'image', data);
      break;
    case 'setZoom':
      setEditorZoom(parseFloat(data));
      break;
    case 'focus':
      quill.focus();
      break;
    case 'clear':
      quill.setContents([]);
      break;
  }
};

// Notify Flutter of content changes
quill.on('text-change', () => {
  sendToFlutter('contentChanged', {
    delta: quill.getContents(),
    html: quill.root.innerHTML
  });
});
```

---

## 5. Best Practices

### 5.1 Performance

```javascript
// Debounce frequent operations
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// Use debounced handlers for expensive operations
const debouncedSave = debounce(saveDocument, 2000);
const debouncedAutoLink = debounce(autoLinkUrls, 500);

quill.on('text-change', (delta, oldDelta, source) => {
  if (source === 'user') {
    debouncedSave();
    debouncedAutoLink(delta);
  }
});
```

### 5.2 Error Handling

```javascript
// Wrap Quill operations in try-catch
function safeSetContent(content) {
  try {
    if (typeof content === 'string') {
      content = JSON.parse(content);
    }
    quill.setContents(content);
    return true;
  } catch (error) {
    console.error('Failed to set content:', error);
    showToast('Failed to load content', 'error');
    return false;
  }
}
```

### 5.3 Accessibility

```javascript
// Add ARIA labels
document.querySelector('.ql-toolbar').setAttribute('role', 'toolbar');
document.querySelector('.ql-toolbar').setAttribute('aria-label', 'Text formatting');
document.querySelector('.ql-editor').setAttribute('role', 'textbox');
document.querySelector('.ql-editor').setAttribute('aria-multiline', 'true');
document.querySelector('.ql-editor').setAttribute('aria-label', 'Rich text editor');
```

### 5.4 File Structure Recommendation

```
project/
├── quill/
│   ├── quill.snow.css      # Base Quill theme
│   └── quill.js            # Quill library
├── plugins/
│   ├── quill-table-better.css
│   └── quill-table-better.js
├── custom/
│   ├── quill-custom.css    # Your CSS overrides
│   ├── quill-modules.js    # Custom modules
│   └── quill-init.js       # Initialization code
└── editor.html             # Editor page
```

### 5.5 Debugging Tips

```javascript
// Enable debug mode
Quill.debug('warn'); // 'error', 'warn', 'log', or 'info'

// Inspect editor state
console.log('Delta:', quill.getContents());
console.log('HTML:', quill.root.innerHTML);
console.log('Selection:', quill.getSelection());
console.log('Format:', quill.getFormat());

// Monitor events
quill.on('text-change', (delta, old, source) => {
  console.log('Text change:', { delta, source });
});
```

---

## Quick Reference

### Common Quill API Methods

| Method | Description |
|--------|-------------|
| `getContents()` | Get Delta representation |
| `setContents(delta)` | Set content from Delta |
| `getText()` | Get plain text |
| `getHTML()` | Get HTML (use `quill.root.innerHTML`) |
| `getSelection()` | Get current selection range |
| `setSelection(index, length)` | Set selection |
| `getFormat(range)` | Get formats at range |
| `format(name, value)` | Apply format to selection |
| `formatText(index, length, formats)` | Format specific range |
| `insertText(index, text, formats)` | Insert formatted text |
| `insertEmbed(index, type, value)` | Insert embed (image, video) |
| `deleteText(index, length)` | Delete text |
| `on(event, handler)` | Listen to events |
| `off(event, handler)` | Remove event listener |
| `focus()` | Focus editor |
| `blur()` | Blur editor |
| `enable(enabled)` | Enable/disable editor |
| `getModule(name)` | Get registered module |

### Events

| Event | Arguments | Description |
|-------|-----------|-------------|
| `text-change` | `delta, oldDelta, source` | Content changed |
| `selection-change` | `range, oldRange, source` | Selection changed |
| `editor-change` | `eventName, ...args` | Any change |

---

*Last updated: December 2024*


