# Migration Plan: quill_web → icici_utacopy

## Objective

Incrementally improve the Quill editor in `icici_utacopy` by porting features from `quill_web` **without** wholesale replacement. The existing structure and FlutterFlow integration must be preserved.

---

## Guiding Principles

1. **Incremental Changes** - One feature at a time, each tested before the next
2. **Backward Compatible** - Existing functionality must not break
3. **Preserve Structure** - Keep the inline HTML/CSS/JS structure of icici_utacopy
4. **Minimal Disruption** - Changes should be additive, not replacive
5. **FlutterFlow Compatible** - Must work with existing `FlutterFlowWebView` usage

---

## Current State Analysis

### icici_utacopy Files
```
web/
├── test_quill.html      # Editor (1360 lines) - PRIMARY TARGET
├── delta_renderer.html  # Viewer (90 lines) - SECONDARY TARGET
```

### What Already Works in icici_utacopy
- ✅ Quill v2 with Snow theme
- ✅ quill-table-better integration
- ✅ Mulish font support
- ✅ Format Painter (custom feature)
- ✅ Image resize (basic)
- ✅ Base64 image support
- ✅ Toolbar tooltips
- ✅ Flutter ↔ JS messaging (basic)

---

## Migration Phases

## Phase 1: Foundation Improvements (Low Risk)
**Estimated Time: 1-2 days**

### 1.1 Add CSS Variables
Replace hardcoded colors with CSS custom properties for easier theming.

**Location:** `test_quill.html` - `<style>` section

```css
/* ADD at the top of <style> section */
:root {
  --ql-accent: #007bff;
  --ql-accent-hover: #0056b3;
  --ql-border: #e9ecef;
  --ql-text: #212529;
  --ql-text-muted: #6c757d;
  --ql-bg: #ffffff;
  --ql-bg-alt: #f8f9fa;
}

/* Then replace hardcoded values throughout */
/* Before: */ background: #007bff;
/* After:  */ background: var(--ql-accent);
```

**Impact:** None - purely cosmetic variables

---

### 1.2 Improve Message Protocol
Add structured JSON messaging for better Flutter integration.

**Location:** `test_quill.html` - `<script>` section

**Current:**
```javascript
function sendMessageToFlutter(message) {
  if (window.parent) {
    window.parent.postMessage(message, '*');
  }
}
```

**Improved:**
```javascript
// Message throttling
let lastMessageTime = 0;
const MESSAGE_THROTTLE = 100;

function sendToFlutter(data) {
  const now = Date.now();
  if (now - lastMessageTime < MESSAGE_THROTTLE) return;
  lastMessageTime = now;
  
  data.source = 'quill-editor';
  data.timestamp = Date.now();
  
  if (window.parent) {
    window.parent.postMessage(JSON.stringify(data), '*');
  }
}

// Update existing sendJsonToFlutter to use sendToFlutter
```

**Impact:** Low - additive change, existing messages still work

---

### 1.3 Add Keyboard Shortcuts
Add common keyboard shortcuts for power users.

**Location:** `test_quill.html` - end of `<script>` section

```javascript
// ADD before closing </script> tag
document.addEventListener('keydown', (e) => {
  // Cmd/Ctrl + S - trigger save
  if ((e.metaKey || e.ctrlKey) && e.key === 's') {
    e.preventDefault();
    sendToFlutter({
      type: 'action',
      action: 'save',
      html: getEditorHtml(),
      delta: editor.getContents()
    });
  }
  
  // Escape - deselect image
  if (e.key === 'Escape') {
    const selectedImages = document.querySelectorAll('img.ql-image-selected');
    selectedImages.forEach(img => {
      img.classList.remove('ql-image-selected');
      img.style.outline = '';
    });
  }
});
```

**Impact:** None - purely additive

---

## Phase 2: Enhanced Media Handling (Medium Risk)
**Estimated Time: 2-3 days**

### 2.1 Improve Image Resize with Size Presets
Add preset size buttons (25%, 50%, 75%, 100%).

**Location:** `test_quill.html`

**Add to CSS:**
```css
/* Image resize toolbar */
.ql-image-toolbar {
  position: fixed;
  display: none;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  padding: 8px;
  z-index: 10001;
  gap: 4px;
}

.ql-image-toolbar.visible {
  display: flex;
}

.ql-image-toolbar button {
  padding: 4px 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  font-size: 12px;
}

.ql-image-toolbar button:hover {
  background: #f0f0f0;
}

.ql-image-toolbar button.active {
  background: var(--ql-accent, #007bff);
  color: white;
  border-color: var(--ql-accent, #007bff);
}
```

**Add to HTML (after editor div):**
```html
<div class="ql-image-toolbar" id="imageToolbar">
  <button data-size="25">25%</button>
  <button data-size="50">50%</button>
  <button data-size="75">75%</button>
  <button data-size="100">100%</button>
  <button data-action="reset">Reset</button>
  <button data-action="delete" style="color: #dc3545;">Delete</button>
</div>
```

**Add to JavaScript:**
```javascript
// Image toolbar functionality
const imageToolbar = document.getElementById('imageToolbar');
let currentSelectedImage = null;

function showImageToolbar(img) {
  currentSelectedImage = img;
  const rect = img.getBoundingClientRect();
  imageToolbar.style.left = `${rect.left}px`;
  imageToolbar.style.top = `${rect.bottom + 8}px`;
  imageToolbar.classList.add('visible');
}

function hideImageToolbar() {
  imageToolbar.classList.remove('visible');
  currentSelectedImage = null;
}

imageToolbar.addEventListener('click', (e) => {
  if (!currentSelectedImage) return;
  const btn = e.target.closest('button');
  if (!btn) return;
  
  if (btn.dataset.size) {
    const percent = parseInt(btn.dataset.size);
    const editorWidth = document.querySelector('.ql-editor').clientWidth - 40;
    const newWidth = (editorWidth * percent) / 100;
    const aspectRatio = currentSelectedImage.naturalWidth / currentSelectedImage.naturalHeight;
    currentSelectedImage.style.width = `${newWidth}px`;
    currentSelectedImage.style.height = `${newWidth / aspectRatio}px`;
  }
  
  if (btn.dataset.action === 'reset') {
    currentSelectedImage.style.width = '';
    currentSelectedImage.style.height = '';
  }
  
  if (btn.dataset.action === 'delete') {
    currentSelectedImage.remove();
    hideImageToolbar();
  }
});
```

**Impact:** Medium - modifies existing image handling, but existing resize still works

---

### 2.2 Add Drag & Drop Image Upload

**Location:** `test_quill.html` - end of `<script>` section

```javascript
// Drag & Drop support
const editorElement = document.querySelector('.ql-editor');

editorElement.addEventListener('dragover', (e) => {
  e.preventDefault();
  editorElement.style.background = 'rgba(0,123,255,0.05)';
  editorElement.style.outline = '2px dashed var(--ql-accent, #007bff)';
});

editorElement.addEventListener('dragleave', (e) => {
  editorElement.style.background = '';
  editorElement.style.outline = '';
});

editorElement.addEventListener('drop', (e) => {
  e.preventDefault();
  editorElement.style.background = '';
  editorElement.style.outline = '';
  
  const files = e.dataTransfer.files;
  Array.from(files).forEach(file => {
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const range = editor.getSelection(true) || { index: editor.getLength() };
        editor.insertEmbed(range.index, 'image', event.target.result, Quill.sources.USER);
      };
      reader.readAsDataURL(file);
    }
  });
});
```

**Impact:** Low - purely additive feature

---

## Phase 3: New UI Features (Medium Risk)
**Estimated Time: 3-4 days**

### 3.1 Add Emoji Picker
Port the emoji picker from quill_web.

**Location:** `test_quill.html`

**Add to toolbar configuration:**
```javascript
// In toolbarOptions array, add:
['emoji'],  // Add this line
```

**Add to toolbar handlers:**
```javascript
handlers: {
  'format-painter': function() { FormatPainter.handleClick(); },
  'emoji': function() { toggleEmojiPicker(); }  // ADD this
}
```

**Add CSS:**
```css
/* Emoji Button */
.ql-emoji::after {
  content: '😀';
  font-size: 14px;
}

/* Emoji Picker */
.emoji-picker {
  position: fixed;
  width: 280px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.15);
  border: 1px solid #ddd;
  z-index: 10002;
  display: none;
}

.emoji-picker.show { display: block; }

.emoji-picker-header {
  padding: 8px;
  border-bottom: 1px solid #eee;
}

.emoji-tabs {
  display: flex;
  gap: 4px;
  margin-bottom: 8px;
}

.emoji-tab {
  flex: 1;
  padding: 4px;
  background: transparent;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.emoji-tab.active {
  background: rgba(0,123,255,0.1);
}

.emoji-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 2px;
  padding: 8px;
  max-height: 200px;
  overflow-y: auto;
}

.emoji-item {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 18px;
}

.emoji-item:hover {
  background: #f0f0f0;
}
```

**Add HTML (after editor):**
```html
<div class="emoji-picker" id="emojiPicker">
  <div class="emoji-picker-header">
    <div class="emoji-tabs">
      <button class="emoji-tab active" data-category="smileys">😀</button>
      <button class="emoji-tab" data-category="gestures">👋</button>
      <button class="emoji-tab" data-category="animals">🐶</button>
      <button class="emoji-tab" data-category="food">🍕</button>
      <button class="emoji-tab" data-category="symbols">❤️</button>
    </div>
  </div>
  <div class="emoji-grid" id="emojiGrid"></div>
</div>
```

**Add JavaScript:**
```javascript
// Emoji data and functions
const emojiData = {
  smileys: ['😀', '😃', '😄', '😁', '😅', '😂', '🤣', '😊', '😇', '🙂', '😉', '😍', '🥰', '😘', '😎', '🤔', '😴', '🥳'],
  gestures: ['👋', '🤚', '✋', '👌', '✌️', '🤞', '👍', '👎', '👏', '🙌', '🤝', '🙏', '💪'],
  animals: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸'],
  food: ['🍕', '🍔', '🍟', '🌭', '🍿', '🍩', '🍪', '🎂', '🍫', '🍬', '☕', '🍺', '🍷'],
  symbols: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '💔', '❣️', '💕', '💯', '✅', '❌', '⭐']
};

let currentEmojiCategory = 'smileys';
const emojiPicker = document.getElementById('emojiPicker');
const emojiGrid = document.getElementById('emojiGrid');

function toggleEmojiPicker() {
  if (emojiPicker.classList.contains('show')) {
    emojiPicker.classList.remove('show');
  } else {
    const btn = document.querySelector('.ql-emoji');
    const rect = btn.getBoundingClientRect();
    emojiPicker.style.left = `${rect.left}px`;
    emojiPicker.style.top = `${rect.bottom + 8}px`;
    emojiPicker.classList.add('show');
    renderEmojis(currentEmojiCategory);
  }
}

function renderEmojis(category) {
  emojiGrid.innerHTML = (emojiData[category] || []).map(emoji =>
    `<button class="emoji-item" data-emoji="${emoji}">${emoji}</button>`
  ).join('');
}

// Tab clicks
emojiPicker.querySelectorAll('.emoji-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    emojiPicker.querySelectorAll('.emoji-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentEmojiCategory = tab.dataset.category;
    renderEmojis(currentEmojiCategory);
  });
});

// Emoji clicks
emojiGrid.addEventListener('click', (e) => {
  if (e.target.classList.contains('emoji-item')) {
    const emoji = e.target.dataset.emoji;
    const range = editor.getSelection() || { index: editor.getLength() };
    editor.insertText(range.index, emoji, Quill.sources.USER);
    editor.setSelection(range.index + emoji.length);
    emojiPicker.classList.remove('show');
  }
});

// Close on outside click
document.addEventListener('click', (e) => {
  if (!e.target.closest('.emoji-picker') && !e.target.closest('.ql-emoji')) {
    emojiPicker.classList.remove('show');
  }
});
```

**Impact:** Medium - adds new toolbar button, but doesn't affect existing functionality

---

### 3.2 Add Zoom Controls
Allow users to zoom in/out of the editor.

**Location:** `test_quill.html`

**Add CSS:**
```css
.ql-editor {
  transition: transform 0.15s ease-out;
  transform-origin: top left;
}
```

**Add JavaScript command handler:**
```javascript
// In handleFlutterCommand function, add case:
case 'setZoom':
  if (data.zoom !== undefined) {
    const zoomLevel = Math.max(0.5, Math.min(3.0, data.zoom));
    const editorEl = document.querySelector('.ql-editor');
    if (editorEl) {
      editorEl.style.transform = `scale(${zoomLevel})`;
      editorEl.style.width = `${100 / zoomLevel}%`;
    }
    sendJsonToFlutter({
      type: 'response',
      action: 'setZoom',
      success: true,
      zoom: zoomLevel
    });
  }
  break;
```

**Impact:** Low - additive command handler

---

## Phase 4: Table Enhancements (Low Risk)
**Estimated Time: 1 day**

### 4.1 Add Table Header Toggle
Allow marking first row as header.

**Add CSS:**
```css
/* Table header styling */
.ql-editor table.table-with-header tr:first-child td {
  background: #f8f9fa;
  font-weight: 600;
  border-bottom: 2px solid #dee2e6;
}

.table-header-popup {
  position: fixed;
  background: white;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  padding: 8px 12px;
  z-index: 10003;
  display: none;
}

.table-header-popup.show { display: block; }

.table-header-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 13px;
}

.table-header-toggle input {
  width: 16px;
  height: 16px;
  accent-color: var(--ql-accent, #007bff);
}
```

**Add HTML:**
```html
<div class="table-header-popup" id="tableHeaderPopup">
  <label class="table-header-toggle">
    <input type="checkbox" id="tableHeaderCheckbox">
    <span>Mark first row as header</span>
  </label>
</div>
```

**Add JavaScript:**
```javascript
// Table header toggle
const tableHeaderPopup = document.getElementById('tableHeaderPopup');
const tableHeaderCheckbox = document.getElementById('tableHeaderCheckbox');
let currentTable = null;

function findParentTable(element) {
  let current = element;
  while (current && current !== document.body) {
    if (current.tagName === 'TABLE') return current;
    current = current.parentElement;
  }
  return null;
}

document.querySelector('.ql-editor').addEventListener('contextmenu', (e) => {
  const table = findParentTable(e.target);
  if (table) {
    e.preventDefault();
    currentTable = table;
    tableHeaderCheckbox.checked = table.classList.contains('table-with-header');
    tableHeaderPopup.style.left = `${e.clientX}px`;
    tableHeaderPopup.style.top = `${e.clientY}px`;
    tableHeaderPopup.classList.add('show');
  }
});

tableHeaderCheckbox.addEventListener('change', (e) => {
  if (currentTable) {
    if (e.target.checked) {
      currentTable.classList.add('table-with-header');
    } else {
      currentTable.classList.remove('table-with-header');
    }
  }
});

document.addEventListener('click', (e) => {
  if (!e.target.closest('.table-header-popup')) {
    tableHeaderPopup.classList.remove('show');
  }
});
```

**Impact:** Low - additive feature for tables

---

## Phase 5: Viewer Improvements (Low Risk)
**Estimated Time: 0.5 day**

### 5.1 Improve delta_renderer.html
Add zoom support and better styling.

**Location:** `delta_renderer.html`

**Improvements:**
```html
<style>
  /* Add CSS variables */
  :root {
    --ql-text: #212529;
    --ql-bg: #ffffff;
  }
  
  body {
    font-family: 'Mulish', sans-serif;
    line-height: 1.6;
    color: var(--ql-text);
    background: var(--ql-bg);
  }
  
  .ql-editor {
    transition: transform 0.15s ease-out;
    transform-origin: top left;
    padding: 16px;
  }
  
  /* Table header support */
  table.table-with-header tr:first-child td {
    background: #f8f9fa;
    font-weight: 600;
  }
</style>

<script>
  // Add zoom support
  window.addEventListener('message', function(event) {
    if (event.source !== window.parent) return;
    
    try {
      const data = JSON.parse(event.data);
      
      if (data.action === 'setHTML') {
        document.getElementById('viewer').innerHTML = data.html || '';
      }
      
      if (data.action === 'setZoom') {
        const zoom = Math.max(0.5, Math.min(3.0, data.zoom));
        const viewer = document.getElementById('viewer');
        viewer.style.transform = `scale(${zoom})`;
        viewer.style.width = `${100 / zoom}%`;
      }
    } catch (e) {
      // Plain HTML string fallback
      document.getElementById('viewer').innerHTML = event.data;
    }
  });
</script>
```

**Impact:** Low - backward compatible with existing usage

---

## Phase 6: Advanced Features (Optional, Higher Risk)
**Estimated Time: 3-5 days (if needed)**

### 6.1 @Mentions Support
Requires `quill-mention` library.

### 6.2 Markdown Shortcuts
Requires custom keyboard bindings.

### 6.3 Magic URL Auto-linking
Requires text-change listener.

**Note:** These can be added later if needed. They require more testing.

---

## Implementation Checklist

### Phase 1: Foundation ✅
- [ ] Add CSS variables to `test_quill.html`
- [ ] Improve message protocol with throttling
- [ ] Add keyboard shortcuts (Cmd+S, Escape)
- [ ] Test existing functionality still works

### Phase 2: Media Handling
- [ ] Add image size presets toolbar
- [ ] Add drag & drop image upload
- [ ] Test existing image resize still works
- [ ] Test Format Painter still works

### Phase 3: UI Features
- [ ] Add emoji picker
- [ ] Add zoom controls
- [ ] Test all toolbar buttons
- [ ] Test Flutter integration

### Phase 4: Tables
- [ ] Add table header toggle
- [ ] Test existing table functionality
- [ ] Test context menu

### Phase 5: Viewer
- [ ] Update `delta_renderer.html` with zoom
- [ ] Add table header styles
- [ ] Test viewer still works

### Phase 6: Optional
- [ ] @Mentions (if needed)
- [ ] Markdown shortcuts (if needed)
- [ ] Magic URL (if needed)

---

## Testing Strategy

### For Each Phase:
1. **Before changes:** Document current behavior with screenshots
2. **After changes:** Verify same behavior + new feature
3. **Regression tests:**
   - Text formatting (bold, italic, etc.)
   - Table operations
   - Image insert and resize
   - Format Painter
   - Flutter message passing
   - HTML export
   - Delta export

### Flutter Integration Tests:
```dart
// Test setHTML
quillWebView.postMessage('{"type":"command","action":"setHTML","html":"<p>Test</p>"}');

// Test getContents
quillWebView.postMessage('{"type":"command","action":"getContents"}');

// Test zoom
quillWebView.postMessage('{"type":"command","action":"setZoom","zoom":1.5}');
```

---

## Rollback Plan

Each phase should be committed separately. If issues arise:

1. **Git rollback:** `git revert <commit-hash>`
2. **Backup files:** Keep copies of original files before each phase
3. **Feature flags:** Consider adding feature flags for new functionality

```javascript
// Example feature flag
const FEATURES = {
  emojiPicker: true,
  imageToolbar: true,
  tableHeader: true
};

if (FEATURES.emojiPicker) {
  // emoji picker code
}
```

---

## File Backup Locations

Before starting, create backups:
```bash
cp web/test_quill.html web/test_quill.html.backup
cp web/delta_renderer.html web/delta_renderer.html.backup
```

---

## Timeline Summary

| Phase | Description | Time | Risk |
|-------|-------------|------|------|
| 1 | Foundation (CSS vars, messaging, shortcuts) | 1-2 days | Low |
| 2 | Media Handling (image toolbar, drag/drop) | 2-3 days | Medium |
| 3 | UI Features (emoji, zoom) | 3-4 days | Medium |
| 4 | Table Enhancements | 1 day | Low |
| 5 | Viewer Improvements | 0.5 day | Low |
| 6 | Advanced (optional) | 3-5 days | Higher |

**Total: ~8-10 days for Phases 1-5** (recommended)
**Total with Phase 6: ~13-15 days**

---

## Questions to Resolve Before Starting

1. **Priority order?** - Which features are most important?
2. **Testing environment?** - How to test FlutterFlow integration?
3. **Deployment process?** - How are changes deployed?
4. **Font requirements?** - Keep Mulish only or add more fonts?
5. **Zoom controls UI?** - Should we add visible zoom buttons in the editor, or only via Flutter commands?

---

## Next Steps

1. ✅ Review this plan
2. Create backups of existing files
3. Start with Phase 1 (lowest risk)
4. Test thoroughly after each phase
5. Commit after each successful phase

Would you like me to proceed with Phase 1 implementation?



