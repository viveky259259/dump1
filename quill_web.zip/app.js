/**
 * Quill Editor Application
 * Enhanced with: Mentions, Image Resize, Magic URL, Emoji, Markdown Shortcuts, Table Better
 */

// ============================================
// Register Quill Table Better Module
// ============================================
Quill.register({
    'modules/table-better': QuillTableBetter
}, true);

// ============================================
// Emoji Data
// ============================================
const emojiData = {
    smileys: ['😀', '😃', '😄', '😁', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '🤥', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '🥵', '🥶', '🥴', '😵', '🤯', '🤠', '🥳', '😎', '🤓', '🧐'],
    gestures: ['👋', '🤚', '🖐️', '✋', '🖖', '👌', '🤌', '🤏', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️', '👍', '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '✍️', '💪', '🦾', '🦿', '🦵', '🦶', '👂', '🦻', '👃', '🧠', '👀', '👁️', '👅', '👄'],
    animals: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🙈', '🙉', '🙊', '🐒', '🐔', '🐧', '🐦', '🐤', '🐣', '🐥', '🦆', '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🐛', '🦋', '🐌', '🐞', '🐜', '🦟', '🦗', '🕷️', '🦂', '🐢', '🐍', '🦎', '🦖', '🦕', '🐙', '🦑'],
    food: ['🍕', '🍔', '🍟', '🌭', '🍿', '🧂', '🥓', '🥚', '🍳', '🧇', '🥞', '🧈', '🍞', '🥐', '🥖', '🥨', '🧀', '🥗', '🥙', '🥪', '🌮', '🌯', '🫔', '🥫', '🍝', '🍜', '🍲', '🍛', '🍣', '🍱', '🥟', '🦪', '🍤', '🍙', '🍚', '🍘', '🍥', '🥠', '🥮', '🍢', '🍡', '🍧', '🍨', '🍦', '🥧', '🧁', '🍰', '🎂', '🍮', '🍭', '🍬', '🍫', '🍩', '🍪', '☕', '🍵', '🧃', '🥤', '🧋', '🍶', '🍺', '🍻', '🥂', '🍷'],
    activities: ['⚽', '🏀', '🏈', '⚾', '🥎', '🎾', '🏐', '🏉', '🥏', '🎱', '🪀', '🏓', '🏸', '🏒', '🏑', '🥍', '🏏', '🪃', '🥅', '⛳', '🪁', '🏹', '🎣', '🤿', '🥊', '🥋', '🎽', '🛹', '🛼', '🛷', '⛸️', '🥌', '🎿', '⛷️', '🏂', '🪂', '🏋️', '🤼', '🤸', '⛹️', '🤺', '🤾', '🏌️', '🏇', '⛹️', '🏊', '🚴', '🚵', '🎪', '🎭', '🎨', '🎬', '🎤', '🎧', '🎼', '🎹', '🥁', '🪘', '🎷', '🎺', '🪗', '🎸', '🪕', '🎻'],
    objects: ['💡', '🔦', '🏮', '🪔', '📱', '💻', '🖥️', '🖨️', '⌨️', '🖱️', '🖲️', '💾', '💿', '📀', '📼', '📷', '📸', '📹', '🎥', '📽️', '🎞️', '📞', '☎️', '📟', '📠', '📺', '📻', '🎙️', '🎚️', '🎛️', '🧭', '⏱️', '⏲️', '⏰', '🕰️', '⌛', '⏳', '📡', '🔋', '🔌', '💸', '💵', '💴', '💶', '💷', '🪙', '💰', '💳', '💎', '⚖️', '🪜', '🧰', '🪛', '🔧', '🔨', '⚒️', '🛠️', '⛏️', '🪚', '🔩', '⚙️', '🪤', '🧱', '⛓️', '🧲', '🔫', '💣', '🧨', '🪓', '🔪', '🗡️', '⚔️', '🛡️', '🚬', '⚰️', '🪦', '⚱️', '🏺', '🔮'],
    symbols: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉️', '☸️', '✡️', '🔯', '🕎', '☯️', '☦️', '🛐', '⛎', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '🆔', '⚛️', '🉑', '☢️', '☣️', '📴', '📳', '🈶', '🈚', '🈸', '🈺', '🈷️', '✴️', '🆚', '💮', '🉐', '㊙️', '㊗️', '🈴', '🈵', '🈹', '🈲', '🅰️', '🅱️', '🆎', '🆑', '🅾️', '🆘', '❌', '⭕', '🛑', '⛔', '📛', '🚫', '💯', '💢', '♨️', '🚷', '🚯', '🚳', '🚱', '🔞', '📵', '🚭', '❗', '❕', '❓', '❔', '‼️', '⁉️', '🔅', '🔆', '〽️', '⚠️', '🚸', '🔱', '⚜️', '🔰', '♻️', '✅', '🈯', '💹', '❇️', '✳️', '❎', '🌐', '💠', 'Ⓜ️', '🌀', '💤', '🏧', '🚾', '♿', '🅿️', '🛗', '🈳', '🈂️', '🛂', '🛃', '🛄', '🛅', '🚹', '🚺', '🚼', '⚧️', '🚻', '🚮', '🎦', '📶', '🈁', '🔣', 'ℹ️', '🔤', '🔡', '🔠', '🆖', '🆗', '🆙', '🆒', '🆕', '🆓', '0️⃣', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟', '🔢', '#️⃣', '*️⃣', '⏏️', '▶️', '⏸️', '⏯️', '⏹️', '⏺️', '⏭️', '⏮️', '⏩', '⏪', '⏫', '⏬', '◀️', '🔼', '🔽', '➡️', '⬅️', '⬆️', '⬇️', '↗️', '↘️', '↙️', '↖️', '↕️', '↔️', '↪️', '↩️', '⤴️', '⤵️', '🔀', '🔁', '🔂', '🔄', '🔃', '🎵', '🎶', '➕', '➖', '➗', '✖️', '🟰', '♾️', '💲', '💱', '™️', '©️', '®️', '👁️‍🗨️', '🔚', '🔙', '🔛', '🔝', '🔜', '〰️', '➰', '➿', '✔️', '☑️', '🔘', '🔴', '🟠', '🟡', '🟢', '🔵', '🟣', '⚫', '⚪', '🟤', '🔺', '🔻', '🔸', '🔹', '🔶', '🔷', '🔳', '🔲', '▪️', '▫️', '◾', '◽', '◼️', '◻️', '🟥', '🟧', '🟨', '🟩', '🟦', '🟪', '⬛', '⬜', '🟫', '🔈', '🔇', '🔉', '🔊', '🔔', '🔕', '📣', '📢']
};

// ============================================
// Sample users for @mentions
// ============================================
const mentionUsers = [
    { id: 1, value: 'John Smith', avatar: 'JS' },
    { id: 2, value: 'Jane Doe', avatar: 'JD' },
    { id: 3, value: 'Mike Johnson', avatar: 'MJ' },
    { id: 4, value: 'Sarah Williams', avatar: 'SW' },
    { id: 5, value: 'David Brown', avatar: 'DB' },
    { id: 6, value: 'Emily Davis', avatar: 'ED' },
    { id: 7, value: 'Chris Wilson', avatar: 'CW' },
    { id: 8, value: 'Lisa Anderson', avatar: 'LA' },
    { id: 9, value: 'Tom Taylor', avatar: 'TT' },
    { id: 10, value: 'Amy Martinez', avatar: 'AM' }
];

// ============================================
// Markdown Shortcuts Configuration
// ============================================
const markdownBindings = {
    // Headers
    'header1': {
        key: ' ',
        prefix: /^#$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'header', 1, 1);
            return false;
        }
    },
    'header2': {
        key: ' ',
        prefix: /^##$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'header', 2, 2);
            return false;
        }
    },
    'header3': {
        key: ' ',
        prefix: /^###$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'header', 3, 3);
            return false;
        }
    },
    // Bold with **text**
    'bold': {
        key: '*',
        collapsed: true,
        handler: function(range, context) {
            return handleInlineMarkdown(this.quill, range, '**', 'bold');
        }
    },
    // Italic with *text*
    'italic': {
        key: '*',
        collapsed: true,
        handler: function(range, context) {
            return handleInlineMarkdown(this.quill, range, '*', 'italic');
        }
    },
    // Strikethrough with ~~text~~
    'strike': {
        key: '~',
        collapsed: true,
        handler: function(range, context) {
            return handleInlineMarkdown(this.quill, range, '~~', 'strike');
        }
    },
    // Code with `text`
    'code': {
        key: '`',
        collapsed: true,
        handler: function(range, context) {
            return handleInlineMarkdown(this.quill, range, '`', 'code');
        }
    },
    // Blockquote
    'blockquote': {
        key: ' ',
        prefix: /^>$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'blockquote', true, 1);
            return false;
        }
    },
    // Ordered list
    'orderedList': {
        key: ' ',
        prefix: /^\d+\.$/,
        handler: function(range, context) {
            const match = context.prefix.match(/^(\d+)\.$/);
            const prefixLength = match ? match[0].length : 2;
            applyMarkdownFormat(this.quill, range, 'list', 'ordered', prefixLength);
            return false;
        }
    },
    // Unordered list with -
    'bulletList1': {
        key: ' ',
        prefix: /^-$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'list', 'bullet', 1);
            return false;
        }
    },
    // Unordered list with *
    'bulletList2': {
        key: ' ',
        prefix: /^\*$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'list', 'bullet', 1);
            return false;
        }
    },
    // Code block with ```
    'codeBlock': {
        key: 'Enter',
        prefix: /^```$/,
        handler: function(range, context) {
            applyMarkdownFormat(this.quill, range, 'code-block', true, 3);
            return false;
        }
    },
    // Horizontal rule with ---
    'horizontalRule': {
        key: '-',
        prefix: /^--$/,
        handler: function(range, context) {
            const [line] = this.editor.getLine(range.index);
            const lineStart = this.editor.getIndex(line);
            this.editor.deleteText(lineStart, 3);
            this.editor.insertEmbed(lineStart, 'divider', true);
            this.editor.insertText(lineStart + 1, '\n');
            return false;
        }
    }
};

/**
 * Apply markdown format to current line
 */
function applyMarkdownFormat(quill, range, format, value, prefixLength) {
    const [line] = editor.getLine(range.index);
    const lineStart = editor.getIndex(line);
    editor.deleteText(lineStart, prefixLength + 1);
    editor.formatLine(lineStart, 1, format, value);
}

/**
 * Handle inline markdown formatting
 */
function handleInlineMarkdown(quill, range, marker, format) {
    const text = editor.getText(0, range.index);
    const markerLen = marker.length;
    const lastMarkerIndex = text.lastIndexOf(marker);
    
    if (lastMarkerIndex !== -1 && lastMarkerIndex < range.index - 1) {
        const textBetween = text.substring(lastMarkerIndex + markerLen, range.index);
        if (textBetween.length > 0 && !textBetween.includes('\n')) {
            editor.deleteText(range.index, 0);
            editor.deleteText(lastMarkerIndex, markerLen);
            editor.formatText(lastMarkerIndex, textBetween.length, format, true);
            editor.setSelection(lastMarkerIndex + textBetween.length);
            return false;
        }
    }
    return true;
}

// ============================================
// Format Painter - Copy and apply formatting
// ============================================
const FormatPainter = {
    storedFormat: null,
    isActive: false,

    copyFormat() {
        const selection = editor.getSelection(true);
        if (!selection) {
            return false;
        }

        const format = editor.getFormat(selection);
        
        // Store the format (filter out attributes we don't want to copy)
        this.storedFormat = {};
        const attributesToCopy = [
            'bold', 'italic', 'underline', 'strike',
            'color', 'background',
            'font', 'size',
            'script', 'link',
            'header', 'align',
            'blockquote', 'code-block',
            'list', 'indent', 'direction'
        ];

        attributesToCopy.forEach(attr => {
            if (format[attr] !== undefined && format[attr] !== null && format[attr] !== '') {
                this.storedFormat[attr] = format[attr];
            }
        });

        // If we have any format to copy, activate
        if (Object.keys(this.storedFormat).length > 0) {
            this.isActive = true;
            this.updateButtonState();
            showToast('Format copied! Select text and click again to apply.');
            return true;
        }

        return false;
    },

    applyFormat() {
        if (!this.storedFormat || !this.isActive) {
            return false;
        }

        const selection = editor.getSelection(true);
        if (!selection || selection.length === 0) {
            return false;
        }

        // Apply the stored format to the current selection
        Object.keys(this.storedFormat).forEach(attr => {
            const value = this.storedFormat[attr];
            editor.formatText(selection.index, selection.length, attr, value, Quill.sources.USER);
        });

        // Deactivate after applying (single-use mode)
        this.isActive = false;
        this.updateButtonState();
        showToast('Format applied!');
        return true;
    },

    updateButtonState() {
        setTimeout(() => {
            const button = document.querySelector('.ql-format-painter');
            if (button) {
                if (this.isActive) {
                    button.classList.add('ql-active');
                    button.title = 'Format Painter Active - Select text and click to apply format';
                } else {
                    button.classList.remove('ql-active');
                    button.title = 'Format Painter - Select formatted text and click to copy format';
                }
            }
        }, 50);
    },

    handleClick() {
        const selection = editor.getSelection(true);

        if (this.isActive) {
            // Format painter is active - apply format to current selection
            if (selection && selection.length > 0) {
                this.applyFormat();
            } else {
                // No selection, deactivate
                this.isActive = false;
                this.updateButtonState();
                showToast('Format painter deactivated');
            }
        } else {
            // Format painter is not active - copy format from current selection
            if (selection && selection.length > 0) {
                this.copyFormat();
            } else if (selection) {
                // No text selected, try to get format at cursor position
                const format = editor.getFormat(selection);
                if (Object.keys(format).length > 0) {
                    this.storedFormat = {};
                    const attributesToCopy = [
                        'bold', 'italic', 'underline', 'strike',
                        'color', 'background', 'font', 'size',
                        'script', 'link', 'header', 'align',
                        'blockquote', 'code-block', 'list', 'indent', 'direction'
                    ];
                    attributesToCopy.forEach(attr => {
                        if (format[attr] !== undefined && format[attr] !== null && format[attr] !== '') {
                            this.storedFormat[attr] = format[attr];
                        }
                    });
                    if (Object.keys(this.storedFormat).length > 0) {
                        this.isActive = true;
                        this.updateButtonState();
                        showToast('Format copied! Select text and click again to apply.');
                    }
                }
            }
        }
    },

    // Deactivate format painter (can be called externally, e.g., on Escape)
    deactivate() {
        if (this.isActive) {
            this.isActive = false;
            this.storedFormat = null;
            this.updateButtonState();
        }
    }
};

// ============================================
// Custom toolbar configuration - All Quill Features
// ============================================
const toolbarOptions = {
    container: [
        // Text structure
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        [{ 'font': [] }],
        [{ 'size': ['small', false, 'large', 'huge'] }],
        
        // Text formatting
        ['bold', 'italic', 'underline', 'strike'],
        ['format-painter'],  // Format Painter
        [{ 'script': 'sub' }, { 'script': 'super' }],
        
        // Colors
        [{ 'color': [] }, { 'background': [] }],
        
        // Lists and indentation
        [{ 'list': 'ordered' }, { 'list': 'bullet' }, { 'list': 'check' }],
        [{ 'indent': '-1' }, { 'indent': '+1' }],
        
        // Text alignment and direction
        [{ 'align': [] }],
        [{ 'direction': 'rtl' }],
        
        // Block formats
        ['blockquote', 'code-block'],
        
        // Media and embeds
        ['link', 'image', 'video', 'formula'],
        
        // Custom features
        ['emoji'],
        
        // Clear formatting
        ['clean']
    ],
    handlers: {
        'emoji': function() {
            toggleEmojiPicker();
        },
        'format-painter': function() {
            FormatPainter.handleClick();
        }
    }
};

// ============================================
// Initialize Quill Editor
// ============================================
const editor = new Quill('#editor', {
    theme: 'snow',
    placeholder: 'Start writing your story... Use markdown shortcuts like # for headers, ** for bold, * for italic',
    modules: {
        toolbar: toolbarOptions,
        table: false, // Disable default table module
        'table-better': {
            language: 'en_US',
            menus: ['column', 'row', 'merge', 'table', 'cell', 'wrap', 'copy', 'delete'],
            toolbarTable: true
        },
        keyboard: {
            bindings: {
                ...QuillTableBetter.keyboardBindings,
                ...markdownBindings
            }
        },
        mention: {
            allowedChars: /^[A-Za-z\s]*$/,
            mentionDenotationChars: ['@'],
            source: function(searchTerm, renderList, mentionChar) {
                const values = mentionUsers;
                if (searchTerm.length === 0) {
                    renderList(values, searchTerm);
                } else {
                    const matches = values.filter(item => 
                        item.value.toLowerCase().includes(searchTerm.toLowerCase())
                    );
                    renderList(matches, searchTerm);
                }
            },
            renderItem: function(item, searchTerm) {
                return `
                    <div class="mention-item-content">
                        <span class="avatar">${item.avatar}</span>
                        <span class="name">${item.value}</span>
                    </div>
                `;
            }
        }
    }
});

// ============================================
// DOM Elements
// ============================================
const elements = {
    documentTitle: document.getElementById('documentTitle'),
    saveStatus: document.getElementById('saveStatus'),
    wordCount: document.getElementById('wordCount'),
    charCount: document.getElementById('charCount'),
    outputPreview: document.getElementById('outputPreview'),
    saveBtn: document.getElementById('saveBtn'),
    clearBtn: document.getElementById('clearBtn'),
    insertHtmlBtn: document.getElementById('insertHtmlBtn'),
    loadSampleBtn: document.getElementById('loadSampleBtn'),
    toast: document.getElementById('toast'),
    tabButtons: document.querySelectorAll('.tab-btn'),
    // HTML Modal elements
    htmlModal: document.getElementById('htmlModal'),
    htmlInput: document.getElementById('htmlInput'),
    replaceContent: document.getElementById('replaceContent'),
    modalClose: document.getElementById('modalClose'),
    cancelHtmlBtn: document.getElementById('cancelHtmlBtn'),
    confirmHtmlBtn: document.getElementById('confirmHtmlBtn'),
    // Table Modal elements
    tableModal: document.getElementById('tableModal'),
    tableRows: document.getElementById('tableRows'),
    tableCols: document.getElementById('tableCols'),
    tablePreview: document.getElementById('tablePreview'),
    tableModalClose: document.getElementById('tableModalClose'),
    cancelTableBtn: document.getElementById('cancelTableBtn'),
    confirmTableBtn: document.getElementById('confirmTableBtn'),
    // Emoji Picker elements
    emojiPicker: document.getElementById('emojiPicker'),
    emojiGrid: document.getElementById('emojiGrid'),
    emojiSearch: document.getElementById('emojiSearch'),
    emojiTabs: document.querySelectorAll('.emoji-tab'),
    // Media Resizer elements (images & videos)
    mediaResizer: document.getElementById('mediaResizer'),
    mediaSizeDisplay: document.getElementById('mediaSizeDisplay'),
    mediaAlignBtns: document.querySelectorAll('.media-align-btn'),
    mediaSizeBtns: document.querySelectorAll('.media-size-btn'),
    mediaResetBtn: document.getElementById('mediaResetBtn'),
    mediaDeleteBtn: document.getElementById('mediaDeleteBtn'),
    // Drop Overlay
    dropOverlay: document.getElementById('dropOverlay'),
    // Preview Modal elements
    previewBtn: document.getElementById('previewBtn'),
    previewModal: document.getElementById('previewModal'),
    previewContent: document.getElementById('previewContent'),
    previewModalClose: document.getElementById('previewModalClose'),
    printPreviewBtn: document.getElementById('printPreviewBtn'),
    copyHtmlBtn: document.getElementById('copyHtmlBtn')
};

// ============================================
// State
// ============================================
let currentOutputTab = 'html';
let currentEmojiCategory = 'smileys';
let selectedMedia = null;
let originalMediaWidth = 0;
let originalMediaHeight = 0;
let isResizing = false;
let resizeHandle = null;
let resizeStartX = 0;
let resizeStartY = 0;
let resizeStartWidth = 0;
let resizeStartHeight = 0;

// ============================================
// Utility Functions
// ============================================

/**
 * Show toast notification
 */
function showToast(message) {
    const toast = elements.toast;
    toast.querySelector('.toast-message').textContent = message;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

/**
 * Update save status indicator
 */
function updateSaveStatus(status) {
    const statusEl = elements.saveStatus;
    statusEl.classList.remove('saving', 'saved');
    
    switch(status) {
        case 'saving':
            statusEl.textContent = 'Saving...';
            statusEl.classList.add('saving');
            break;
        case 'saved':
            statusEl.textContent = 'Saved';
            statusEl.classList.add('saved');
            break;
        default:
            statusEl.textContent = 'Ready';
    }
}

/**
 * Count words in text
 */
function countWords(text) {
    return text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
}

/**
 * Update document statistics
 */
function updateStats() {
    const text = editor.getText();
    const wordCount = countWords(text);
    const charCount = text.length - 1;
    
    elements.wordCount.textContent = wordCount.toLocaleString();
    elements.charCount.textContent = Math.max(0, charCount).toLocaleString();
}

/**
 * Update output preview based on selected tab
 */
function updateOutputPreview() {
    const codeEl = elements.outputPreview.querySelector('code');
    
    switch(currentOutputTab) {
        case 'html':
            codeEl.textContent = editor.root.innerHTML;
            break;
        case 'delta':
            codeEl.textContent = JSON.stringify(editor.getContents(), null, 2);
            break;
        case 'text':
            codeEl.textContent = editor.getText();
            break;
    }
}

/**
 * Export document
 */
function saveDocument() {
    updateSaveStatus('saved');
    showToast('Document ready for export');
}

/**
 * Initialize document
 */
function loadDocument() {
    updateStats();
    updateOutputPreview();
}

/**
 * Clear the editor
 */
function clearEditor() {
    if (confirm('Are you sure you want to clear the editor? This action cannot be undone.')) {
        editor.setContents([]);
        elements.documentTitle.value = '';
        updateStats();
        updateOutputPreview();
        updateSaveStatus('ready');
        showToast('Editor cleared');
    }
}

/**
 * Auto-save handler
 */
function autoSave() {
    updateSaveStatus('ready');
}

/**
 * Load sample content
 */
async function loadSampleContent() {
    try {
        const response = await fetch('sample-content.html', {
            cache: 'no-store'
        });
        
        if (!response.ok) {
            throw new Error('Failed to load sample content');
        }
        
        const html = await response.text();
        
        elements.htmlModal.classList.add('show');
        elements.htmlInput.value = html;
        elements.replaceContent.checked = true;
        elements.htmlInput.focus();
        
        showToast('Sample content loaded - click Insert to apply');
    } catch (error) {
        console.error('Failed to load sample content:', error);
        showToast('Failed to load sample content. Make sure you\'re running from a server.');
    }
}

// ============================================
// Magic URL Auto-linking
// ============================================
const urlRegex = /https?:\/\/[^\s<]+[^<.,:;"')\]\s]/g;
const emailRegex = /[\w.-]+@[\w.-]+\.\w+/g;

/**
 * Auto-link URLs and emails in the editor
 */
function autoLinkUrls() {
    const text = editor.getText();
    const delta = editor.getContents();
    let hasChanges = false;
    
    // Find URLs
    let match;
    while ((match = urlRegex.exec(text)) !== null) {
        const url = match[0];
        const index = match.index;
        const format = editor.getFormat(index, url.length);
        
        if (!format.link) {
            editor.formatText(index, url.length, 'link', url, 'silent');
            hasChanges = true;
        }
    }
    
    // Find emails
    while ((match = emailRegex.exec(text)) !== null) {
        const email = match[0];
        const index = match.index;
        const format = editor.getFormat(index, email.length);
        
        if (!format.link) {
            editor.formatText(index, email.length, 'link', `mailto:${email}`, 'silent');
            hasChanges = true;
        }
    }
}

// Debounced URL auto-linking
let autoLinkTimeout;
function debouncedAutoLink() {
    clearTimeout(autoLinkTimeout);
    autoLinkTimeout = setTimeout(autoLinkUrls, 500);
}

// ============================================
// Insert HTML Modal Functions
// ============================================

function openHtmlModal() {
    elements.htmlModal.classList.add('show');
    elements.htmlInput.value = '';
    elements.replaceContent.checked = false;
    elements.htmlInput.focus();
}

function closeHtmlModal() {
    elements.htmlModal.classList.remove('show');
    elements.htmlInput.value = '';
}

function insertHtml() {
    const html = elements.htmlInput.value.trim();
    
    if (!html) {
        showToast('Please enter some HTML to insert');
        return;
    }
    
    try {
        if (elements.replaceContent.checked) {
            editor.setContents([]);
            editor.clipboard.dangerouslyPasteHTML(0, html, 'user');
        } else {
            const range = editor.getSelection();
            const index = range ? range.index : editor.getLength();
            editor.clipboard.dangerouslyPasteHTML(index, html, 'user');
        }
        
        closeHtmlModal();
        updateStats();
        updateOutputPreview();
        showToast('HTML inserted successfully');
    } catch (error) {
        console.error('Failed to insert HTML:', error);
        showToast('Failed to insert HTML. Please check your markup.');
    }
}

// ============================================
// Insert Table Modal Functions
// ============================================

function openTableModal() {
    elements.tableModal.classList.add('show');
    elements.tableRows.value = 3;
    elements.tableCols.value = 3;
    updateTablePreview();
}

function closeTableModal() {
    elements.tableModal.classList.remove('show');
}

function updateTablePreview() {
    const rows = parseInt(elements.tableRows.value) || 3;
    const cols = parseInt(elements.tableCols.value) || 3;
    
    const clampedRows = Math.min(Math.max(rows, 1), 20);
    const clampedCols = Math.min(Math.max(cols, 1), 10);
    
    let tableHtml = '<table>';
    for (let i = 0; i < clampedRows; i++) {
        tableHtml += '<tr>';
        for (let j = 0; j < clampedCols; j++) {
            tableHtml += '<td></td>';
        }
        tableHtml += '</tr>';
    }
    tableHtml += '</table>';
    
    elements.tablePreview.innerHTML = tableHtml;
}

function insertTable() {
    const rows = parseInt(elements.tableRows.value) || 3;
    const cols = parseInt(elements.tableCols.value) || 3;
    
    const clampedRows = Math.min(Math.max(rows, 1), 20);
    const clampedCols = Math.min(Math.max(cols, 1), 10);
    
    let tableHtml = '<table><tbody>';
    for (let i = 0; i < clampedRows; i++) {
        tableHtml += '<tr>';
        for (let j = 0; j < clampedCols; j++) {
            tableHtml += `<td>${i === 0 ? `Header ${j + 1}` : ''}</td>`;
        }
        tableHtml += '</tr>';
    }
    tableHtml += '</tbody></table>';
    
    try {
        const range = editor.getSelection();
        const index = range ? range.index : editor.getLength();
        editor.clipboard.dangerouslyPasteHTML(index, tableHtml, 'user');
        
        closeTableModal();
        updateStats();
        updateOutputPreview();
        showToast(`${clampedRows}x${clampedCols} table inserted`);
    } catch (error) {
        console.error('Failed to insert table:', error);
        showToast('Failed to insert table');
    }
}

// ============================================
// Table Better is now handling table operations
// ============================================
// quill-table-better provides its own context menu and table operations

// ============================================
// Preview Modal Functions
// ============================================

function openPreviewModal() {
    // Get the HTML content from Quill
    const htmlContent = editor.root.innerHTML;
    
    // Set the preview content
    elements.previewContent.innerHTML = htmlContent;
    
    // Show the modal
    elements.previewModal.classList.add('show');
}

function closePreviewModal() {
    elements.previewModal.classList.remove('show');
    elements.previewContent.innerHTML = '';
}

function printPreview() {
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    const htmlContent = editor.root.innerHTML;
    const title = elements.documentTitle.value || 'Untitled Document';
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>${title}</title>
            <link href="quill/packages/quill/dist/dist/quill.snow.css" rel="stylesheet">
            <link href="node_modules/quill-table-better/dist/quill-table-better.css" rel="stylesheet">
            <style>
                body {
                    font-family: 'Crimson Pro', Georgia, serif;
                    font-size: 16px;
                    line-height: 1.8;
                    color: #2c2825;
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 40px 20px;
                }
                h1, h2, h3 { font-weight: 600; margin-bottom: 0.5em; }
                h1 { font-size: 2rem; }
                h2 { font-size: 1.5rem; }
                h3 { font-size: 1.25rem; }
                p { margin-bottom: 1em; }
                blockquote {
                    border-left: 4px solid #c45d35;
                    padding-left: 16px;
                    margin: 24px 0;
                    color: #6b6560;
                    font-style: italic;
                }
                pre {
                    background: #f8f6f3;
                    border-radius: 6px;
                    padding: 16px;
                    font-family: 'SF Mono', monospace;
                    font-size: 14px;
                    overflow-x: auto;
                }
                a { color: #c45d35; }
                img { max-width: 100%; height: auto; }
                table { border-collapse: collapse; width: 100%; margin: 16px 0; }
                td, th { border: 1px solid #e5e0da; padding: 8px 16px; }
                tr:first-child td, th { background: #f8f6f3; font-weight: 500; }
                ul, ol { margin: 16px 0; padding-left: 32px; }
                @media print {
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="ql-editor">${htmlContent}</div>
            <script>
                window.onload = function() {
                    window.print();
                    window.onafterprint = function() { window.close(); };
                };
            </script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

function copyHtmlToClipboard() {
    const htmlContent = editor.root.innerHTML;
    
    navigator.clipboard.writeText(htmlContent).then(() => {
        showToast('HTML copied to clipboard');
    }).catch(err => {
        console.error('Failed to copy:', err);
        // Fallback for older browsers
        const textarea = document.createElement('textarea');
        textarea.value = htmlContent;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('HTML copied to clipboard');
    });
}

// ============================================
// Emoji Picker Functions
// ============================================

function toggleEmojiPicker() {
    const picker = elements.emojiPicker;
    const toolbar = document.querySelector('.ql-toolbar');
    const emojiBtn = toolbar.querySelector('.ql-emoji');
    
    if (picker.classList.contains('show')) {
        picker.classList.remove('show');
    } else {
        const rect = emojiBtn.getBoundingClientRect();
        picker.style.left = `${rect.left}px`;
        picker.style.top = `${rect.bottom + 8}px`;
        picker.classList.add('show');
        renderEmojis(currentEmojiCategory);
    }
}

function closeEmojiPicker() {
    elements.emojiPicker.classList.remove('show');
}

function renderEmojis(category, searchQuery = '') {
    let emojis = emojiData[category] || [];
    
    if (searchQuery) {
        // Search all categories
        emojis = Object.values(emojiData).flat();
    }
    
    elements.emojiGrid.innerHTML = emojis.map(emoji => 
        `<button class="emoji-item" data-emoji="${emoji}">${emoji}</button>`
    ).join('');
}

function insertEmoji(emoji) {
    const range = editor.getSelection() || { index: editor.getLength() };
    editor.insertText(range.index, emoji, 'user');
    editor.setSelection(range.index + emoji.length);
    closeEmojiPicker();
}

// ============================================
// Media Resize & Alignment Functions (Images & Videos)
// ============================================

/**
 * Check if element is a resizable media element
 */
function isResizableMedia(el) {
    if (!el) return false;
    const tagName = el.tagName.toUpperCase();
    return tagName === 'IMG' || tagName === 'IFRAME' || tagName === 'VIDEO';
}

/**
 * Select a media element for resizing
 */
function selectMedia(media) {
    // Deselect previous
    if (selectedMedia) {
        selectedMedia.classList.remove('selected');
    }
    
    selectedMedia = media;
    media.classList.add('selected');
    
    // Store original dimensions
    if (media.tagName === 'IMG') {
        originalMediaWidth = media.naturalWidth || media.width;
        originalMediaHeight = media.naturalHeight || media.height;
    } else {
        originalMediaWidth = media.offsetWidth;
        originalMediaHeight = media.offsetHeight;
    }
    
    positionMediaResizer(media);
    elements.mediaResizer.classList.add('active');
    
    // Update size display
    updateMediaSizeDisplay();
    
    // Update alignment buttons
    updateAlignmentButtons();
    
    // Update size percentage buttons
    updateSizeButtons();
}

/**
 * Deselect the current media element
 */
function deselectMedia() {
    if (selectedMedia) {
        selectedMedia.classList.remove('selected');
        selectedMedia = null;
    }
    elements.mediaResizer.classList.remove('active');
}

/**
 * Position the resizer overlay on the media element
 * Uses requestAnimationFrame for smooth updates
 */
function positionMediaResizer(media) {
    if (!media) return;
    const rect = media.getBoundingClientRect();
    
    // Ensure we have valid dimensions before positioning
    if (rect.width === 0 || rect.height === 0) return;
    
    elements.mediaResizer.style.left = `${rect.left}px`;
    elements.mediaResizer.style.top = `${rect.top}px`;
    elements.mediaResizer.style.width = `${rect.width}px`;
    elements.mediaResizer.style.height = `${rect.height}px`;
}

/**
 * Update the size display text
 */
function updateMediaSizeDisplay() {
    if (!selectedMedia) return;
    const width = selectedMedia.offsetWidth || selectedMedia.width;
    const height = selectedMedia.offsetHeight || selectedMedia.height;
    elements.mediaSizeDisplay.textContent = `${Math.round(width)} × ${Math.round(height)} px`;
}

/**
 * Update alignment button states
 */
function updateAlignmentButtons() {
    if (!selectedMedia) return;
    elements.mediaAlignBtns.forEach(btn => {
        const align = btn.dataset.align;
        btn.classList.toggle('active', selectedMedia.classList.contains(`align-${align}`));
    });
}

/**
 * Update size percentage button states
 */
function updateSizeButtons() {
    if (!selectedMedia) return;
    const editorWidth = editor.root.clientWidth - 64; // Account for padding
    const currentWidth = selectedMedia.offsetWidth || selectedMedia.width;
    const currentPercent = Math.round((currentWidth / editorWidth) * 100);
    
    elements.mediaSizeBtns.forEach(btn => {
        const size = parseInt(btn.dataset.size);
        btn.classList.toggle('active', Math.abs(currentPercent - size) < 5);
    });
}

/**
 * Handle mouse move during resize
 */
// Handle media resize with smooth updates
let resizeAnimationFrame = null;

function handleMediaResize(e) {
    if (!isResizing || !selectedMedia) return;
    
    // Cancel any pending animation frame for smoother updates
    if (resizeAnimationFrame) {
        cancelAnimationFrame(resizeAnimationFrame);
    }
    
    resizeAnimationFrame = requestAnimationFrame(() => {
        const dx = e.clientX - resizeStartX;
        const dy = e.clientY - resizeStartY;
        
        let newWidth = resizeStartWidth;
        let newHeight = resizeStartHeight;
        const aspectRatio = resizeStartWidth / resizeStartHeight;
        
        // Handle different resize handles
        switch (resizeHandle) {
            case 'se':
                newWidth = resizeStartWidth + dx;
                newHeight = newWidth / aspectRatio;
                break;
            case 'sw':
                newWidth = resizeStartWidth - dx;
                newHeight = newWidth / aspectRatio;
                break;
            case 'ne':
                newWidth = resizeStartWidth + dx;
                newHeight = newWidth / aspectRatio;
                break;
            case 'nw':
                newWidth = resizeStartWidth - dx;
                newHeight = newWidth / aspectRatio;
                break;
            case 'e':
                newWidth = resizeStartWidth + dx;
                newHeight = newWidth / aspectRatio;
                break;
            case 'w':
                newWidth = resizeStartWidth - dx;
                newHeight = newWidth / aspectRatio;
                break;
            case 'n':
                newHeight = resizeStartHeight - dy;
                newWidth = newHeight * aspectRatio;
                break;
            case 's':
                newHeight = resizeStartHeight + dy;
                newWidth = newHeight * aspectRatio;
                break;
        }
        
        // Minimum and maximum size
        const minSize = 50;
        const maxWidth = editor.root.clientWidth - 32;
        newWidth = Math.max(minSize, Math.min(maxWidth, newWidth));
        newHeight = Math.max(minSize, newWidth / aspectRatio);
        
        selectedMedia.style.width = `${newWidth}px`;
        selectedMedia.style.height = `${newHeight}px`;
        
        // Update resizer position after layout settles
        requestAnimationFrame(() => {
            positionMediaResizer(selectedMedia);
            updateMediaSizeDisplay();
        });
        
        updateSizeButtons();
    });
}

/**
 * Set media alignment with proper layout handling
 */
function setMediaAlignment(align) {
    if (!selectedMedia) return;
    
    // Remove existing alignment classes and inline styles
    selectedMedia.classList.remove('align-left', 'align-center', 'align-right');
    selectedMedia.style.float = '';
    selectedMedia.style.marginLeft = '';
    selectedMedia.style.marginRight = '';
    
    // Apply new alignment class
    selectedMedia.classList.add(`align-${align}`);
    
    // For centered images, ensure display block is set
    if (align === 'center') {
        selectedMedia.style.display = 'block';
    } else {
        selectedMedia.style.display = '';
    }
    
    // Update buttons
    updateAlignmentButtons();
    
    // Wait for layout to settle before repositioning
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            positionMediaResizer(selectedMedia);
        });
    });
}

/**
 * Set media size by percentage of editor width
 */
function setMediaSizePercent(percent) {
    if (!selectedMedia) return;
    
    const editorWidth = editor.root.clientWidth - 64;
    const newWidth = (editorWidth * percent) / 100;
    const aspectRatio = (selectedMedia.offsetWidth || selectedMedia.width) / 
                       (selectedMedia.offsetHeight || selectedMedia.height);
    const newHeight = newWidth / aspectRatio;
    
    selectedMedia.style.width = `${newWidth}px`;
    selectedMedia.style.height = `${newHeight}px`;
    
    // Wait for layout to settle before repositioning
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            positionMediaResizer(selectedMedia);
            updateMediaSizeDisplay();
        });
    });
    updateSizeButtons();
    
    showToast(`Resized to ${percent}%`);
}

/**
 * Reset media to original size
 */
function resetMediaSize() {
    if (!selectedMedia || !originalMediaWidth) return;
    
    const maxWidth = editor.root.clientWidth - 64;
    let newWidth = originalMediaWidth;
    let newHeight = originalMediaHeight;
    
    // Scale down if too large
    if (newWidth > maxWidth) {
        const scale = maxWidth / newWidth;
        newWidth = maxWidth;
        newHeight = originalMediaHeight * scale;
    }
    
    selectedMedia.style.width = `${newWidth}px`;
    selectedMedia.style.height = `${newHeight}px`;
    
    // Wait for layout to settle before repositioning
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            positionMediaResizer(selectedMedia);
            updateMediaSizeDisplay();
        });
    });
    updateSizeButtons();
    
    showToast('Size reset to original');
}

/**
 * Delete the selected media element
 */
function deleteSelectedMedia() {
    if (!selectedMedia) return;
    
    // Find the blot and delete it
    const blot = Quill.find(selectedMedia);
    if (blot) {
        const index = editor.getIndex(blot);
        editor.deleteText(index, 1, 'user');
    } else {
        // Fallback: remove from DOM
        selectedMedia.remove();
    }
    
    deselectMedia();
    updateStats();
    updateOutputPreview();
    showToast('Media deleted');
}

// ============================================
// Drag & Drop Image Upload
// ============================================

function handleDragEnter(e) {
    e.preventDefault();
    if (e.dataTransfer.types.includes('Files')) {
        elements.dropOverlay.classList.add('active');
    }
}

function handleDragLeave(e) {
    e.preventDefault();
    if (e.target === elements.dropOverlay) {
        elements.dropOverlay.classList.remove('active');
    }
}

function handleDragOver(e) {
    e.preventDefault();
}

function handleDrop(e) {
    e.preventDefault();
    elements.dropOverlay.classList.remove('active');
    
    const files = e.dataTransfer.files;
    if (files.length === 0) return;
    
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (event) => {
                const range = editor.getSelection() || { index: editor.getLength() };
                editor.insertEmbed(range.index, 'image', event.target.result, 'user');
            };
            reader.readAsDataURL(file);
        }
    });
    
    showToast('Image(s) added');
}

// ============================================
// Event Listeners
// ============================================

// Quill text change event
editor.on('text-change', () => {
    updateStats();
    updateOutputPreview();
    autoSave();
    debouncedAutoLink();
});

// Save button
elements.saveBtn.addEventListener('click', saveDocument);

// Clear button
elements.clearBtn.addEventListener('click', clearEditor);

// Tab buttons
elements.tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        elements.tabButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentOutputTab = btn.dataset.tab;
        updateOutputPreview();
    });
});

// Document title
elements.documentTitle.addEventListener('input', autoSave);

// Load sample content
elements.loadSampleBtn.addEventListener('click', loadSampleContent);

// Preview modal events
elements.previewBtn.addEventListener('click', openPreviewModal);
elements.previewModalClose.addEventListener('click', closePreviewModal);
elements.printPreviewBtn.addEventListener('click', printPreview);
elements.copyHtmlBtn.addEventListener('click', copyHtmlToClipboard);
elements.previewModal.addEventListener('click', (e) => {
    if (e.target === elements.previewModal) closePreviewModal();
});

// Insert HTML modal events
elements.insertHtmlBtn.addEventListener('click', openHtmlModal);
elements.modalClose.addEventListener('click', closeHtmlModal);
elements.cancelHtmlBtn.addEventListener('click', closeHtmlModal);
elements.confirmHtmlBtn.addEventListener('click', insertHtml);
elements.htmlModal.addEventListener('click', (e) => {
    if (e.target === elements.htmlModal) closeHtmlModal();
});

// Table modal events
elements.tableModalClose.addEventListener('click', closeTableModal);
elements.cancelTableBtn.addEventListener('click', closeTableModal);
elements.confirmTableBtn.addEventListener('click', insertTable);
elements.tableRows.addEventListener('input', updateTablePreview);
elements.tableCols.addEventListener('input', updateTablePreview);
elements.tableModal.addEventListener('click', (e) => {
    if (e.target === elements.tableModal) closeTableModal();
});

// Emoji picker events
elements.emojiTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        elements.emojiTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        currentEmojiCategory = tab.dataset.category;
        renderEmojis(currentEmojiCategory);
    });
});

elements.emojiGrid.addEventListener('click', (e) => {
    if (e.target.classList.contains('emoji-item')) {
        insertEmoji(e.target.dataset.emoji);
    }
});

elements.emojiSearch.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    if (query) {
        // Filter emojis (basic search)
        const allEmojis = Object.values(emojiData).flat();
        elements.emojiGrid.innerHTML = allEmojis.slice(0, 64).map(emoji => 
            `<button class="emoji-item" data-emoji="${emoji}">${emoji}</button>`
        ).join('');
    } else {
        renderEmojis(currentEmojiCategory);
    }
});

// Media selection in editor (images, videos, iframes)
editor.root.addEventListener('click', (e) => {
    if (isResizableMedia(e.target)) {
        e.preventDefault();
        e.stopPropagation();
        selectMedia(e.target);
    } else if (!e.target.closest('.media-resizer')) {
        deselectMedia();
    }
    
    // Close emoji picker when clicking elsewhere
    if (!e.target.closest('.emoji-picker') && !e.target.closest('.ql-emoji')) {
        closeEmojiPicker();
    }
});

// Prevent video from playing on click - use double-click to play
editor.root.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'VIDEO' || e.target.tagName === 'IFRAME') {
        e.preventDefault();
    }
});

// Double-click to play/pause video
editor.root.addEventListener('dblclick', (e) => {
    if (e.target.tagName === 'VIDEO') {
        if (e.target.paused) {
            e.target.play();
        } else {
            e.target.pause();
        }
    }
});

// Media resize handles
elements.mediaResizer.querySelectorAll('.resize-handle').forEach(handle => {
    handle.addEventListener('mousedown', (e) => {
        if (!selectedMedia) return;
        
        isResizing = true;
        resizeHandle = handle.dataset.handle;
        resizeStartX = e.clientX;
        resizeStartY = e.clientY;
        resizeStartWidth = selectedMedia.offsetWidth;
        resizeStartHeight = selectedMedia.offsetHeight;
        
        e.preventDefault();
        e.stopPropagation();
    });
});

// Media alignment buttons
elements.mediaAlignBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        setMediaAlignment(btn.dataset.align);
    });
});

// Media size percentage buttons
elements.mediaSizeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        setMediaSizePercent(parseInt(btn.dataset.size));
    });
});

// Media reset button
elements.mediaResetBtn.addEventListener('click', resetMediaSize);

// Media delete button
elements.mediaDeleteBtn.addEventListener('click', deleteSelectedMedia);

// Global mouse move/up for media resize
document.addEventListener('mousemove', handleMediaResize);
document.addEventListener('mouseup', () => {
    if (isResizing) {
        isResizing = false;
        resizeHandle = null;
    }
});

// Reposition resizer on scroll
editor.root.addEventListener('scroll', () => {
    if (selectedMedia) {
        positionMediaResizer(selectedMedia);
    }
});

// Reposition resizer on window resize
window.addEventListener('resize', () => {
    if (selectedMedia) {
        positionMediaResizer(selectedMedia);
        updateSizeButtons();
    }
});

// Drag and drop
document.addEventListener('dragenter', handleDragEnter);
elements.dropOverlay.addEventListener('dragleave', handleDragLeave);
elements.dropOverlay.addEventListener('dragover', handleDragOver);
elements.dropOverlay.addEventListener('drop', handleDrop);

// Also handle drop on the editor itself
editor.root.addEventListener('dragover', (e) => e.preventDefault());
editor.root.addEventListener('drop', handleDrop);

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Cmd/Ctrl + S to save
    if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        saveDocument();
    }
    
    // Escape to close modals/pickers and deactivate format painter
    if (e.key === 'Escape') {
        if (elements.previewModal.classList.contains('show')) {
            closePreviewModal();
        }
        if (elements.htmlModal.classList.contains('show')) {
            closeHtmlModal();
        }
        if (elements.tableModal.classList.contains('show')) {
            closeTableModal();
        }
        if (elements.emojiPicker.classList.contains('show')) {
            closeEmojiPicker();
        }
        FormatPainter.deactivate();
        deselectMedia();
    }
    
    // Cmd/Ctrl + Shift + H to open HTML modal
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'h') {
        e.preventDefault();
        openHtmlModal();
    }
    
    // Cmd/Ctrl + Shift + E for emoji picker
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'e') {
        e.preventDefault();
        toggleEmojiPicker();
    }
    
    // Cmd/Ctrl + Shift + P for preview
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'p') {
        e.preventDefault();
        openPreviewModal();
    }
    
    // Cmd/Ctrl + Shift + F for format painter
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'f') {
        e.preventDefault();
        FormatPainter.handleClick();
    }
});

// ============================================
// Initialize
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    loadDocument();
    updateStats();
    updateOutputPreview();
    renderEmojis(currentEmojiCategory);
    
    // Add Format Painter icon
    const formatPainterButton = document.querySelector('.ql-format-painter');
    if (formatPainterButton && !formatPainterButton.querySelector('svg')) {
        formatPainterButton.innerHTML = `
            <svg viewBox="0 0 18 18">
                <path d="M13.5 2.5L15.5 4.5L6.5 13.5L4.5 11.5L13.5 2.5Z" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M3.5 15.5L4.5 14.5L5.5 15.5L4.5 16.5L3.5 15.5Z" fill="currentColor" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M12.5 3.5L14.5 5.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
        `;
        formatPainterButton.title = 'Format Painter - Select formatted text and click to copy format';
    }
    
    editor.focus();
});

// Export editor instance for console access
window.editor = editor;
