/**
 * Simple HTTP server to serve Quill packages locally
 * Usage: node serve-quill.js
 * Server will run on http://localhost:3000
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

// MIME types for common file extensions
const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.map': 'application/json'
};

// Define routes for serving files
const routes = {
    // Quill core files - serve from local package
    '/quill/dist/quill.js': 'quill/packages/quill/dist/dist/quill.js',
    '/quill/dist/quill.snow.css': 'quill/packages/quill/dist/dist/quill.snow.css',
    '/quill/dist/quill.bubble.css': 'quill/packages/quill/dist/dist/quill.bubble.css',
    '/quill/dist/quill.core.css': 'quill/packages/quill/dist/dist/quill.core.css',
    '/quill/dist/quill.core.js': 'quill/packages/quill/dist/dist/quill.core.js',
    
    // Quill table better files - serve from node_modules
    '/quill-table-better/dist/quill-table-better.js': 'node_modules/quill-table-better/dist/quill-table-better.js',
    '/quill-table-better/dist/quill-table-better.css': 'node_modules/quill-table-better/dist/quill-table-better.css',
};

const server = http.createServer((req, res) => {
    // Enable CORS for all origins (needed for Flutter WebView)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    const requestUrl = req.url.split('?')[0]; // Remove query string
    
    // Check if we have a predefined route
    let filePath;
    if (routes[requestUrl]) {
        filePath = path.join(__dirname, routes[requestUrl]);
    } else {
        // Try to serve from root directory
        filePath = path.join(__dirname, requestUrl);
    }
    
    // Get file extension and MIME type
    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes[ext] || 'application/octet-stream';
    
    // Read and serve the file
    fs.readFile(filePath, (err, content) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // File not found
                console.log(`404 Not Found: ${requestUrl} -> ${filePath}`);
                res.writeHead(404, { 'Content-Type': 'text/plain' });
                res.end(`File not found: ${requestUrl}`);
            } else {
                // Server error
                console.error(`500 Error: ${err.message}`);
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end(`Server error: ${err.message}`);
            }
        } else {
            // Success
            console.log(`200 OK: ${requestUrl}`);
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content);
        }
    });
});

server.listen(PORT, () => {
    console.log(`\n🚀 Quill Server running at http://localhost:${PORT}\n`);
    console.log('Available routes:');
    console.log('  Quill JS:              http://localhost:' + PORT + '/quill/dist/quill.js');
    console.log('  Quill Snow CSS:        http://localhost:' + PORT + '/quill/dist/quill.snow.css');
    console.log('  Quill Table Better JS: http://localhost:' + PORT + '/quill-table-better/dist/quill-table-better.js');
    console.log('  Quill Table Better CSS:http://localhost:' + PORT + '/quill-table-better/dist/quill-table-better.css');
    console.log('\nPress Ctrl+C to stop the server.\n');
});


