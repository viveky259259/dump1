import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
// ignore: avoid_web_libraries_in_flutter
import 'dart:ui_web' as ui;
import 'package:pointer_interceptor/pointer_interceptor.dart';
import '../widgets/quill_editor.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

enum SaveStatus { saved, saving, unsaved }

class _HomePageState extends State<HomePage> {
  final GlobalKey<QuillEditorState> _editorKey = GlobalKey<QuillEditorState>();
  String _currentHtml = '';
  String _outputTab = 'html';
  int _wordCount = 0;
  int _charCount = 0;
  double _zoomLevel = 1.0;
  SaveStatus _saveStatus = SaveStatus.saved;
  Timer? _saveTimer;

  // Sample content to demonstrate the editor
  static const String _sampleHtml = '''
<h1>Nested Table Example</h1>
<p>This document demonstrates nested tables in Quill.</p>

<table>
  <tbody>
    <tr>
      <td data-row="row-abc1">Outer Table - Row 1, Cell 1</td>
      <td data-row="row-abc1">Outer Table - Row 1, Cell 2</td>
      <td data-row="row-abc1">Outer Table - Row 1, Cell 3</td>
    </tr>
    <tr>
      <td data-row="row-abc2">Outer Table - Row 2, Cell 1</td>
      <td data-row="row-abc2">
        <p>This cell contains a nested table:</p>
        <table>
          <tbody>
            <tr>
              <td data-row="row-nest1">Nested - A1</td>
              <td data-row="row-nest1">Nested - A2</td>
            </tr>
            <tr>
              <td data-row="row-nest2">Nested - B1</td>
              <td data-row="row-nest2">Nested - B2</td>
            </tr>
            <tr>
              <td data-row="row-nest3">Nested - C1</td>
              <td data-row="row-nest3">Nested - C2</td>
            </tr>
          </tbody>
        </table>
        <p>End of nested table</p>
      </td>
      <td data-row="row-abc2">Outer Table - Row 2, Cell 3</td>
    </tr>
    <tr>
      <td data-row="row-abc3">Outer Table - Row 3, Cell 1</td>
      <td data-row="row-abc3">Outer Table - Row 3, Cell 2</td>
      <td data-row="row-abc3">Outer Table - Row 3, Cell 3</td>
    </tr>
  </tbody>
</table>

<p>You can edit the nested table just like any other table in Quill!</p>
''';

  void _onContentChanged(String html, dynamic delta) {
    setState(() {
      _currentHtml = html;
      _updateStats(html);
      _saveStatus = SaveStatus.unsaved;
    });

    // Debounce: show "Saving..." after 500ms, then "Saved" after another 500ms
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _saveStatus = SaveStatus.saving;
        });
        // Simulate save completion after 500ms
        Timer(const Duration(milliseconds: 500), () {
          if (mounted) {
            setState(() {
              _saveStatus = SaveStatus.saved;
            });
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    super.dispose();
  }

  void _updateStats(String html) {
    // Simple text extraction for word count
    final tempDiv = html
        .replaceAll(RegExp(r'<[^>]*>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    final words = tempDiv.isEmpty ? 0 : tempDiv.split(' ').length;
    final chars = tempDiv.length;

    setState(() {
      _wordCount = words;
      _charCount = chars;
    });
  }

  void _loadSampleContent() {
    _editorKey.currentState?.setHTML(_sampleHtml);
    _showSnackBar('Sample content loaded');
  }

  void _clearEditor() {
    showDialog(
      context: context,
      builder: (context) => PointerInterceptor(
        child: AlertDialog(
          title: const Text('Clear Editor'),
          content: const Text('Are you sure you want to clear all content?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _editorKey.currentState?.clear();
                // Reset local state
                setState(() {
                  _currentHtml = '';
                  _wordCount = 0;
                  _charCount = 0;
                });
                _showSnackBar('Editor cleared');
              },
              child: const Text('Clear'),
            ),
          ],
        ),
      ),
    );
  }

  /// Cleans HTML by removing only editor artifacts while preserving user styles
  String _cleanHtmlForExport(String html) {
    // Remove <temporary> tags (quill-table-better artifacts)
    var cleaned = html.replaceAll(
        RegExp(r'<temporary[^>]*>.*?</temporary>', dotAll: true), '');
    cleaned =
        cleaned.replaceAll(RegExp(r'<temporary[^>]*><br></temporary>'), '');

    // Remove only specific editor selection classes (preserve user classes)
    // Using word boundaries to avoid partial matches
    final selectionClasses = [
      'ql-cell-focused',
      'ql-table-selected',
      'ql-cell-selected',
      'ql-table-better-selected-td',
      'ql-table-better-selection-line',
      'ql-table-better-selection-block',
    ];

    for (final cls in selectionClasses) {
      // Remove class from class attribute (with proper word boundaries)
      cleaned = cleaned.replaceAllMapped(
        RegExp(r'class="([^"]*)"'),
        (match) {
          final classes = match.group(1)!;
          final updatedClasses = classes
              .split(RegExp(r'\s+'))
              .where((c) => c != cls && c.isNotEmpty)
              .join(' ');
          return updatedClasses.isEmpty ? '' : 'class="$updatedClasses"';
        },
      );
    }

    // Clean up empty class attributes
    cleaned = cleaned.replaceAll(RegExp(r'\s*class="\s*"'), '');

    // Remove only editor-internal data attributes (keep data-checked for checklists)
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-row="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-cell="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-class="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*data-table-id="[^"]*"'), '');
    cleaned = cleaned.replaceAll(RegExp(r'\s*contenteditable="[^"]*"'), '');

    // Remove tool/UI elements injected by editor
    cleaned = cleaned.replaceAll(
        RegExp(r'<div[^>]*class="[^"]*ql-table-better-[^"]*"[^>]*>.*?</div>',
            dotAll: true),
        '');

    return cleaned;
  }

  void _downloadHtml() {
    if (_currentHtml.isEmpty) {
      _showSnackBar('No content to download');
      return;
    }

    // Clean the HTML before export
    final cleanedContent = _cleanHtmlForExport(_currentHtml);

    final fullHtml = '''


''';

    final bytes = utf8.encode(fullHtml);
    final blob = html.Blob([bytes], 'text/html');
    final url = html.Url.createObjectUrlFromBlob(blob);
    html.AnchorElement(href: url)
      ..setAttribute('download', 'document.html')
      ..click();
    html.Url.revokeObjectUrl(url);

    _showSnackBar('Document downloaded');
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showPreview() {
    if (_currentHtml.isEmpty) {
      _showSnackBar('No content to preview');
      return;
    }

    showDialog(
      context: context,
      builder: (context) => PointerInterceptor(
        child: _PreviewDialogContent(html: _currentHtml),
      ),
    );
  }

  void _showInsertHtmlDialog() {
    final textController = TextEditingController();
    bool replaceContent = false;

    showDialog(
      context: context,
      builder: (context) => PointerInterceptor(
        child: StatefulBuilder(
          builder: (context, setDialogState) => Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Container(
              width: 600,
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    children: [
                      const Icon(
                        Icons.code,
                        color: Color(0xFFC45D35),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        'Insert HTML',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF2C2825),
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                        tooltip: 'Close',
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // Label
                  const Text(
                    'Paste your HTML code below:',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF6B6560),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Text area
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8F6F3),
                      border: Border.all(color: const Color(0xFFE5E0DA)),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: TextField(
                      controller: textController,
                      maxLines: null,
                      expands: true,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 13,
                        color: Color(0xFF2C2825),
                      ),
                      decoration: const InputDecoration(
                        hintText: '<p>Your HTML content here...</p>',
                        hintStyle: TextStyle(
                          color: Color(0xFF9A948E),
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.all(16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Replace content checkbox
                  Row(
                    children: [
                      Checkbox(
                        value: replaceContent,
                        onChanged: (value) {
                          setDialogState(() {
                            replaceContent = value ?? false;
                          });
                        },
                        activeColor: const Color(0xFFC45D35),
                      ),
                      GestureDetector(
                        onTap: () {
                          setDialogState(() {
                            replaceContent = !replaceContent;
                          });
                        },
                        child: const Text(
                          'Replace existing content',
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFF6B6560),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Cancel'),
                      ),
                      const SizedBox(width: 12),
                      FilledButton.icon(
                        onPressed: () {
                          final htmlContent = textController.text.trim();
                          if (htmlContent.isEmpty) {
                            _showSnackBar('Please enter some HTML to insert');
                            return;
                          }
                          Navigator.pop(context);
                          // Use insertHtml which handles full HTML documents
                          // and properly extracts body content
                          _editorKey.currentState?.insertHtml(
                            htmlContent,
                            replace: replaceContent,
                          );
                          _showSnackBar('HTML inserted successfully');
                        },
                        icon: const Icon(Icons.add, size: 18),
                        label: const Text('Insert'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFC45D35).withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.edit_note,
                color: Color(0xFFC45D35),
              ),
            ),
            const SizedBox(width: 12),
            const Text('Quill Editor'),
          ],
        ),
        actions: [
          // Zoom controls
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 8),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: () {
                    _editorKey.currentState?.zoomOut();
                    setState(() {
                      _zoomLevel = (_zoomLevel - 0.1).clamp(0.5, 3.0);
                    });
                  },
                  icon: const Icon(Icons.remove, size: 18),
                  tooltip: 'Zoom Out',
                  constraints:
                      const BoxConstraints(minWidth: 32, minHeight: 32),
                  padding: EdgeInsets.zero,
                ),
                GestureDetector(
                  onTap: () {
                    _editorKey.currentState?.resetZoom();
                    setState(() {
                      _zoomLevel = 1.0;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      '${(_zoomLevel * 100).round()}%',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    _editorKey.currentState?.zoomIn();
                    setState(() {
                      _zoomLevel = (_zoomLevel + 0.1).clamp(0.5, 3.0);
                    });
                  },
                  icon: const Icon(Icons.add, size: 18),
                  tooltip: 'Zoom In',
                  constraints:
                      const BoxConstraints(minWidth: 32, minHeight: 32),
                  padding: EdgeInsets.zero,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          TextButton.icon(
            onPressed: _showInsertHtmlDialog,
            icon: const Icon(Icons.code),
            label: const Text('Insert HTML'),
          ),
          TextButton.icon(
            onPressed: _loadSampleContent,
            icon: const Icon(Icons.file_download_outlined),
            label: const Text('Sample'),
          ),
          TextButton.icon(
            onPressed: _showPreview,
            icon: const Icon(Icons.preview_outlined),
            label: const Text('Preview'),
          ),
          TextButton.icon(
            onPressed: _clearEditor,
            icon: const Icon(Icons.delete_outline),
            label: const Text('Clear'),
          ),
          const SizedBox(width: 8),
          // Save Status Indicator
          _buildSaveStatusIndicator(),
          const SizedBox(width: 8),
          FilledButton.icon(
            onPressed: _downloadHtml,
            icon: const Icon(Icons.save_alt),
            label: const Text('Save'),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Row(
        children: [
          // Editor
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 24,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: QuillEditor(
                  key: _editorKey,
                  onContentChanged: _onContentChanged,
                  initialHtml: _sampleHtml,
                ),
              ),
            ),
          ),
          // Sidebar
          SizedBox(
            width: 320,
            child: Container(
              margin: const EdgeInsets.only(top: 24, right: 24, bottom: 24),
              child: Column(
                children: [
                  // Stats Card
                  _buildCard(
                    title: 'Document Info',
                    child: Row(
                      children: [
                        _buildStatItem('Words', _wordCount.toString()),
                        const SizedBox(width: 16),
                        _buildStatItem('Characters', _charCount.toString()),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Output Preview Card (expanded)
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'OUTPUT PREVIEW',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.5,
                              color: Colors.grey.shade500,
                            ),
                          ),
                          const SizedBox(height: 16),
                          // Tabs
                          Row(
                            children: [
                              _buildTab('HTML', 'html'),
                              const SizedBox(width: 8),
                              _buildTab('Text', 'text'),
                            ],
                          ),
                          const SizedBox(height: 12),
                          // Content
                          Expanded(
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF8F6F3),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: SingleChildScrollView(
                                child: SelectableText(
                                  _outputTab == 'html'
                                      ? _currentHtml
                                      : _currentHtml
                                          .replaceAll(RegExp(r'<[^>]*>'), ' ')
                                          .replaceAll(RegExp(r'\s+'), ' ')
                                          .trim(),
                                  style: const TextStyle(
                                    fontFamily: 'monospace',
                                    fontSize: 12,
                                    color: Color(0xFF6B6560),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSaveStatusIndicator() {
    IconData icon;
    Color color;
    String text;

    switch (_saveStatus) {
      case SaveStatus.unsaved:
        icon = Icons.edit_outlined;
        color = const Color(0xFFE57C23);
        text = 'Unsaved';
        break;
      case SaveStatus.saving:
        icon = Icons.sync;
        color = const Color(0xFF6B6560);
        text = 'Saving...';
        break;
      case SaveStatus.saved:
        icon = Icons.check_circle_outline;
        color = const Color(0xFF22C55E);
        text = 'Saved';
        break;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _saveStatus == SaveStatus.saving
              ? SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                )
              : Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCard({required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
              color: Colors.grey.shade500,
            ),
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFFF8F6F3),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Color(0xFF2C2825),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String label, String value) {
    final isSelected = _outputTab == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _outputTab = value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color:
                isSelected ? const Color(0xFFC45D35) : const Color(0xFFF8F6F3),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: isSelected ? Colors.white : Colors.grey.shade600,
            ),
          ),
        ),
      ),
    );
  }
}

/// Preview dialog with zoom controls
class _PreviewDialogContent extends StatefulWidget {
  const _PreviewDialogContent({required this.html});

  final String html;

  @override
  State<_PreviewDialogContent> createState() => _PreviewDialogContentState();
}

class _PreviewDialogContentState extends State<_PreviewDialogContent> {
  final GlobalKey<HtmlPreviewWidgetState> _previewKey = GlobalKey();
  double _currentZoom = 1.0;

  void _zoomIn() {
    _previewKey.currentState?.zoomIn();
    setState(() {
      _currentZoom = _previewKey.currentState?.currentZoom ?? _currentZoom;
    });
  }

  void _zoomOut() {
    _previewKey.currentState?.zoomOut();
    setState(() {
      _currentZoom = _previewKey.currentState?.currentZoom ?? _currentZoom;
    });
  }

  void _resetZoom() {
    _previewKey.currentState?.resetZoom();
    setState(() {
      _currentZoom = 1.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8,
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            // Header with zoom controls
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Color(0xFFE5E0DA)),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.preview_outlined,
                    color: Color(0xFFC45D35),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'HTML Preview',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF2C2825),
                    ),
                  ),
                  const Spacer(),
                  // Zoom controls
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF8F6F3),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: _zoomOut,
                          icon: const Icon(Icons.remove, size: 18),
                          tooltip: 'Zoom out',
                          constraints: const BoxConstraints(
                            minWidth: 36,
                            minHeight: 36,
                          ),
                        ),
                        GestureDetector(
                          onTap: _resetZoom,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(
                              '${(_currentZoom * 100).round()}%',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF2C2825),
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: _zoomIn,
                          icon: const Icon(Icons.add, size: 18),
                          tooltip: 'Zoom in',
                          constraints: const BoxConstraints(
                            minWidth: 36,
                            minHeight: 36,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                    tooltip: 'Close',
                  ),
                ],
              ),
            ),
            // Preview content
            Expanded(
              child: _HtmlPreviewWidget(
                key: _previewKey,
                html: widget.html,
                onZoomChanged: (zoom) {
                  setState(() {
                    _currentZoom = zoom;
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Widget to display HTML preview in an iframe
class _HtmlPreviewWidget extends StatefulWidget {
  const _HtmlPreviewWidget({super.key, required this.html, this.onZoomChanged});

  final String html;
  final void Function(double zoom)? onZoomChanged;

  @override
  State<_HtmlPreviewWidget> createState() => HtmlPreviewWidgetState();
}

class HtmlPreviewWidgetState extends State<_HtmlPreviewWidget> {
  html.IFrameElement? _iframe;
  static int _viewIdCounter = 0;
  late int _viewId;
  double _currentZoom = 1.0;

  double get currentZoom => _currentZoom;

  @override
  void initState() {
    super.initState();
    _viewId = ++_viewIdCounter;
    _registerViewFactory();
  }

  void _registerViewFactory() {
    final previewHtml = '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <link href="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/quill-table-better@1/dist/quill-table-better.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@400;500;600&family=DM+Sans:wght@400;500;600&family=Roboto:wght@400;500&family=Open+Sans:wght@400;500&family=Lato:wght@400;700&family=Montserrat:wght@400;500;600&family=Source+Code+Pro:wght@400;500&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { 
      height: 100%; 
      font-family: 'Crimson Pro', Georgia, serif;
      font-size: 1.125rem;
      line-height: 1.8;
      color: #2c2825;
      background: #ffffff;
      overflow-x: hidden;
    }
    .ql-editor { 
      padding: 24px;
      transform-origin: top left;
      transition: transform 0.15s ease-out;
    }
    .ql-editor h1 { font-size: 2.25rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h2 { font-size: 1.75rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h3 { font-size: 1.375rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h4 { font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h5 { font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h6 { font-size: 0.75rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor p { margin-bottom: 1em; }
    .ql-editor blockquote { border-left: 4px solid #c45d35; padding-left: 16px; margin: 24px 0; color: #6b6560; font-style: italic; }
    .ql-editor pre { background: #f8f6f3; border-radius: 8px; padding: 16px; font-family: 'Source Code Pro', monospace; font-size: 0.875rem; }
    .ql-editor a { color: #c45d35; text-decoration: underline; }
    .ql-editor img { max-width: 100%; border-radius: 8px; }
    /* Table styles - preserve inline widths/colors */
    .ql-editor table { border-collapse: collapse; margin: 16px 0; }
    .ql-editor table td, .ql-editor table th { border: 1px solid #e5e0da; min-width: 50px; vertical-align: top; }
    .ql-editor table td:not([style*="padding"]), .ql-editor table th:not([style*="padding"]) { padding: 8px 16px; }
    .ql-editor table.table-with-header tr:first-child td:not([style*="background"]), .ql-editor table th:not([style*="background"]) { background: #f8f6f3; font-weight: 500; }
    .ql-editor table td[rowspan], .ql-editor table td[colspan] { vertical-align: middle; }
    .ql-editor table td p { margin: 0; }
    .ql-editor table colgroup, .ql-editor table col { display: table-column; }
    /* Hide editor UI elements only */
    .ql-table-better-selected-td, .ql-table-better-selection-line, .ql-table-better-selection-block, .ql-table-better-col-tool, .ql-table-better-row-tool, .ql-table-better-corner, [class*="ql-table-better-select"], [class*="ql-table-better-tool"] { display: none !important; }
    .ql-editor ul, .ql-editor ol { padding-left: 24px; margin-bottom: 1em; }
    .ql-editor li { margin-bottom: 0.5em; }
    .ql-editor iframe, .ql-editor video, .ql-editor .ql-video { display: block; max-width: 100%; aspect-ratio: 16/9; border-radius: 8px; margin: 16px 0; }
    /* Media & table alignment */
    .ql-editor img.align-left, .ql-editor iframe.align-left, .ql-editor video.align-left { float: left; margin-right: 16px; margin-bottom: 8px; }
    .ql-editor img.align-center, .ql-editor iframe.align-center, .ql-editor video.align-center { display: block; margin-left: auto; margin-right: auto; margin-top: 16px; margin-bottom: 16px; }
    .ql-editor img.align-right, .ql-editor iframe.align-right, .ql-editor video.align-right { float: right; margin-left: 16px; margin-bottom: 8px; }
    .ql-editor table.align-left { float: left; margin-right: 16px; margin-bottom: 8px; width: auto; }
    .ql-editor table.align-center { display: table; margin-left: auto; margin-right: auto; width: auto; }
    .ql-editor table.align-right { float: right; margin-left: 16px; margin-bottom: 8px; width: auto; }
    .ql-editor::after { content: ""; display: table; clear: both; }
    temporary { display: none !important; }
    .ql-font-roboto { font-family: 'Roboto', sans-serif; }
    .ql-font-open-sans { font-family: 'Open Sans', sans-serif; }
    .ql-font-lato { font-family: 'Lato', sans-serif; }
    .ql-font-montserrat { font-family: 'Montserrat', sans-serif; }
    .ql-font-source-code { font-family: 'Source Code Pro', monospace; }
    .ql-font-crimson { font-family: 'Crimson Pro', serif; }
    .ql-font-dm-sans { font-family: 'DM Sans', sans-serif; }
    .ql-size-small { font-size: 0.75em; }
    .ql-size-large { font-size: 1.5em; }
    .ql-size-huge { font-size: 2.5em; }
    /* Line height classes */
    .ql-line-height-1 { line-height: 1; }
    .ql-line-height-1-5 { line-height: 1.5; }
    .ql-line-height-2 { line-height: 2; }
    .ql-line-height-2-5 { line-height: 2.5; }
    .ql-line-height-3 { line-height: 3; }
    /* Text indent classes */
    .ql-indent-1 { padding-left: 3em; }
    .ql-indent-2 { padding-left: 6em; }
    .ql-indent-3 { padding-left: 9em; }
    .ql-indent-4 { padding-left: 12em; }
    .ql-indent-5 { padding-left: 15em; }
    .ql-indent-6 { padding-left: 18em; }
    .ql-indent-7 { padding-left: 21em; }
    .ql-indent-8 { padding-left: 24em; }
    /* Text alignment */
    .ql-align-center { text-align: center; }
    .ql-align-right { text-align: right; }
    .ql-align-justify { text-align: justify; }
    sub { vertical-align: sub; font-size: smaller; }
    sup { vertical-align: super; font-size: smaller; }
    .ql-direction-rtl { direction: rtl; text-align: inherit; }
    .ql-editor code { background: #f0f0f0; padding: 2px 4px; border-radius: 3px; font-family: 'Source Code Pro', monospace; }
  </style>
</head>
<body>
  <div id="viewer" class="ql-editor"></div>
  <script>
    // Clean HTML - remove only editor artifacts, preserve user styles
    function cleanHtmlForPreview(html) {
      const parser = new DOMParser();
      const doc = parser.parseFromString('<div>' + html + '</div>', 'text/html');
      const container = doc.body.firstChild;
      
      // Only specific editor selection classes to remove (preserve user classes)
      const selectionClasses = [
        'ql-cell-focused',
        'ql-table-selected', 
        'ql-cell-selected',
        'ql-table-better-selected-td',
        'ql-table-better-selection-line',
        'ql-table-better-selection-block'
      ];
      
      container.querySelectorAll('*').forEach(function(el) {
        // Remove only specific selection classes
        selectionClasses.forEach(function(cls) { el.classList.remove(cls); });
        
        // Remove editor-internal data attributes (keep data-checked for checklists)
        el.removeAttribute('data-row');
        el.removeAttribute('data-cell');
        el.removeAttribute('data-class');
        el.removeAttribute('data-table-id');
        el.removeAttribute('contenteditable');
      });
      
      // Remove temporary elements and tool elements
      container.querySelectorAll('temporary, [class*="ql-table-better-tool"], [class*="ql-table-better-col-tool"], [class*="ql-table-better-row-tool"], [class*="ql-table-better-corner"]').forEach(function(el) {
        el.remove();
      });
      
      return container.innerHTML;
    }
    
    // Clean and set initial content
    var initialHtml = '${widget.html.replaceAll("'", "\\'").replaceAll('\n', '\\n').replaceAll('\r', '')}';
    document.getElementById('viewer').innerHTML = cleanHtmlForPreview(initialHtml);
    
    window.addEventListener('message', function(event) {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'command' && data.action === 'setZoom') {
          const zoomLevel = Math.max(0.5, Math.min(3.0, data.zoom));
          const viewer = document.getElementById('viewer');
          if (viewer) {
            viewer.style.transform = 'scale(' + zoomLevel + ')';
            viewer.style.width = (100 / zoomLevel) + '%';
          }
        }
      } catch (e) {}
    });
  </script>
</body>
</html>
''';

    final blob = html.Blob([previewHtml], 'text/html');
    final url = html.Url.createObjectUrlFromBlob(blob);

    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory(
      'html-preview-$_viewId',
      (int viewId) {
        _iframe = html.IFrameElement()
          ..src = url
          ..style.border = '0'
          ..style.width = '100%'
          ..style.height = '100%';
        return _iframe!;
      },
    );
  }

  void zoomIn() {
    _currentZoom = (_currentZoom + 0.1).clamp(0.5, 3.0);
    _sendZoomCommand(_currentZoom);
    widget.onZoomChanged?.call(_currentZoom);
  }

  void zoomOut() {
    _currentZoom = (_currentZoom - 0.1).clamp(0.5, 3.0);
    _sendZoomCommand(_currentZoom);
    widget.onZoomChanged?.call(_currentZoom);
  }

  void resetZoom() {
    _currentZoom = 1.0;
    _sendZoomCommand(_currentZoom);
    widget.onZoomChanged?.call(_currentZoom);
  }

  void _sendZoomCommand(double zoom) {
    if (_iframe == null) return;
    final jsonString = '{"type":"command","action":"setZoom","zoom":$zoom}';
    _iframe?.contentWindow?.postMessage(jsonString, '*');
  }

  @override
  Widget build(BuildContext context) {
    return HtmlElementView(viewType: 'html-preview-$_viewId');
  }
}
