import 'package:flutter/material.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
// ignore: avoid_web_libraries_in_flutter
import 'dart:ui_web' as ui;
import 'dart:convert';

/// A Quill.js rich text editor widget for Flutter Web
///
/// This widget embeds a Quill.js editor via an iframe and provides
/// bidirectional communication between Flutter and the JavaScript editor.
class QuillEditor extends StatefulWidget {
  const QuillEditor({
    super.key,
    this.width,
    this.height,
    this.onContentChanged,
    this.readOnly = false,
    this.initialHtml,
    this.initialDelta,
    this.placeholder,
  });

  /// Width of the editor
  final double? width;

  /// Height of the editor
  final double? height;

  /// Callback when editor content changes
  final void Function(String html, dynamic delta)? onContentChanged;

  /// Whether the editor is read-only
  final bool readOnly;

  /// Initial HTML content to load
  final String? initialHtml;

  /// Initial Delta content to load (JSON)
  final dynamic initialDelta;

  /// Placeholder text when editor is empty
  final String? placeholder;

  @override
  State<QuillEditor> createState() => QuillEditorState();
}

class QuillEditorState extends State<QuillEditor> {
  html.IFrameElement? _iframe;
  static int _viewIdCounter = 0;
  late int _viewId;
  bool _hasInitializedContent = false;
  bool _isReady = false;
  double _currentZoom = 1.0;

  /// Current zoom level (1.0 = 100%)
  double get currentZoom => _currentZoom;

  @override
  void initState() {
    super.initState();
    _viewId = ++_viewIdCounter;
    _registerViewFactory();
  }

  void _registerViewFactory() {
    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory(
      'quill-editor-$_viewId',
      (int viewId) {
        _iframe = html.IFrameElement()
          ..src = widget.readOnly ? 'quill_viewer.html' : 'quill_editor.html'
          ..style.border = '0'
          ..style.width = '100%'
          ..style.height = '100%';

        // Listen for iframe load event
        _iframe!.onLoad.listen((_) {
          _isReady = true;
          _initializeContent();
        });

        // Listen for messages from the iframe
        html.window.addEventListener('message', _handleMessage);

        return _iframe!;
      },
    );
  }

  void _handleMessage(html.Event event) {
    final messageEvent = event as html.MessageEvent;
    if (messageEvent.data == null) return;

    try {
      final messageData = messageEvent.data is String
          ? messageEvent.data as String
          : messageEvent.data.toString();

      final data = jsonDecode(messageData);

      // Handle content change events
      if (data['type'] == 'contentChange') {
        widget.onContentChanged?.call(
          data['html'] ?? '',
          data['delta'],
        );
      }
    } catch (e) {
      // Handle plain string messages
      debugPrint('QuillEditor: Message parse error: $e');
    }
  }

  void _initializeContent() {
    if (_hasInitializedContent) return;
    _hasInitializedContent = true;

    Future.delayed(const Duration(milliseconds: 100), () {
      if (widget.initialDelta != null) {
        setContents(widget.initialDelta);
      } else if (widget.initialHtml != null && widget.initialHtml!.isNotEmpty) {
        setHTML(widget.initialHtml!);
      }
    });
  }

  /// Insert text at the current cursor position
  void insertText(String text) {
    _sendCommand({
      'action': 'insertText',
      'text': text,
    });
  }

  /// Set the editor contents from a Delta object
  void setContents(dynamic delta) {
    _sendCommand({
      'action': 'setContents',
      'delta': delta,
    });
  }

  /// Set the editor contents from HTML string
  /// If [replace] is true (default), replaces all content
  /// If [replace] is false, inserts at cursor position
  void setHTML(String html, {bool replace = true}) {
    _sendCommand({
      'action': 'setHTML',
      'html': html,
      'replace': replace,
    });
  }

  /// Insert HTML at cursor position
  /// If [replace] is true, replaces all existing content first
  void insertHtml(String html, {bool replace = false}) {
    _sendCommand({
      'action': 'insertHtml',
      'html': html,
      'replace': replace,
    });
  }

  /// Get the current editor contents
  void getContents() {
    _sendCommand({
      'action': 'getContents',
    });
  }

  /// Clear the editor
  void clear() {
    _sendCommand({
      'action': 'clear',
    });
  }

  /// Focus the editor
  void focus() {
    _sendCommand({
      'action': 'focus',
    });
  }

  /// Zoom in the editor (increase by 10%)
  void zoomIn() {
    _currentZoom = (_currentZoom + 0.1).clamp(0.5, 3.0);
    _sendCommand({
      'action': 'setZoom',
      'zoom': _currentZoom,
    });
  }

  /// Zoom out the editor (decrease by 10%)
  void zoomOut() {
    _currentZoom = (_currentZoom - 0.1).clamp(0.5, 3.0);
    _sendCommand({
      'action': 'setZoom',
      'zoom': _currentZoom,
    });
  }

  /// Reset zoom to 100%
  void resetZoom() {
    _currentZoom = 1.0;
    _sendCommand({
      'action': 'setZoom',
      'zoom': _currentZoom,
    });
  }

  /// Set zoom to specific level (0.5 to 3.0)
  void setZoom(double level) {
    _currentZoom = level.clamp(0.5, 3.0);
    _sendCommand({
      'action': 'setZoom',
      'zoom': _currentZoom,
    });
  }

  void _sendCommand(Map<String, dynamic> data) {
    if (!_isReady || _iframe == null) {
      debugPrint('QuillEditor: Not ready yet, queuing command');
      Future.delayed(const Duration(milliseconds: 200), () {
        _sendCommand(data);
      });
      return;
    }

    data['source'] = 'flutter';
    data['type'] = 'command';
    final jsonString = jsonEncode(data);
    _iframe?.contentWindow?.postMessage(jsonString, '*');
  }

  @override
  void dispose() {
    html.window.removeEventListener('message', _handleMessage);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: HtmlElementView(viewType: 'quill-editor-$_viewId'),
    );
  }
}
