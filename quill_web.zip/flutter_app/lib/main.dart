import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'pages/home_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QuillEditorApp());
}

class QuillEditorApp extends StatelessWidget {
  const QuillEditorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quill Editor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFC45D35),
          brightness: Brightness.light,
        ),
        textTheme: GoogleFonts.dmSansTextTheme(),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF2C2825),
          elevation: 0,
          titleTextStyle: GoogleFonts.crimsonPro(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF2C2825),
            ),
        ),
        scaffoldBackgroundColor: const Color(0xFFF8F6F3),
      ),
      home: const HomePage(),
    );
  }
}
