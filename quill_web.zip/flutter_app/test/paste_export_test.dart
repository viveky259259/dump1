import 'package:flutter_test/flutter_test.dart';

/// HTML Exporter - mirrors the logic used in home_page.dart for HTML export
class HtmlExporter {
  /// Generates a complete HTML document from editor content
  static String generateFullHtml(String editorContent) {
    return '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/quill@2.0.0/dist/quill.snow.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/quill-table-better@1/dist/quill-table-better.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@400;500;600&family=DM+Sans:wght@400;500;600&family=Roboto:wght@400;500&family=Open+Sans:wght@400;500&family=Lato:wght@400;700&family=Montserrat:wght@400;500;600&family=Source+Code+Pro:wght@400;500&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body { 
      font-family: 'Crimson Pro', Georgia, serif; 
      font-size: 1.125rem;
      line-height: 1.8;
      color: #2c2825;
      background: #ffffff;
      padding: 0;
      margin: 0;
    }
    
    .ql-editor { 
      padding: 24px;
      max-width: 100%;
    }
    
    /* Typography */
    .ql-editor h1 { font-size: 2.25rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h2 { font-size: 1.75rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h3 { font-size: 1.375rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h4 { font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h5 { font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor h6 { font-size: 0.75rem; font-weight: 600; margin-bottom: 0.5em; }
    .ql-editor p { margin-bottom: 1em; }
    .ql-editor blockquote { border-left: 4px solid #c45d35; padding-left: 16px; margin: 24px 0; color: #6b6560; font-style: italic; }
    .ql-editor pre { background: #f8f6f3; border-radius: 8px; padding: 16px; font-family: 'Source Code Pro', monospace; font-size: 0.875rem; overflow-x: auto; }
    .ql-editor a { color: #c45d35; text-decoration: underline; }
    .ql-editor code { background: #f0f0f0; padding: 2px 4px; border-radius: 3px; font-family: 'Source Code Pro', monospace; }
    
    /* Font family classes */
    .ql-font-roboto { font-family: 'Roboto', sans-serif; }
    .ql-font-open-sans { font-family: 'Open Sans', sans-serif; }
    .ql-font-lato { font-family: 'Lato', sans-serif; }
    .ql-font-montserrat { font-family: 'Montserrat', sans-serif; }
    .ql-font-source-code { font-family: 'Source Code Pro', monospace; }
    .ql-font-crimson { font-family: 'Crimson Pro', serif; }
    .ql-font-dm-sans { font-family: 'DM Sans', sans-serif; }
    
    /* Font size classes */
    .ql-size-small { font-size: 0.75em; }
    .ql-size-large { font-size: 1.5em; }
    .ql-size-huge { font-size: 2.5em; }
    
    /* Line height classes */
    .ql-line-height-1 { line-height: 1; }
    .ql-line-height-1-5 { line-height: 1.5; }
    .ql-line-height-2 { line-height: 2; }
    .ql-line-height-2-5 { line-height: 2.5; }
    .ql-line-height-3 { line-height: 3; }
    
    /* Text indent classes */
    .ql-indent-1 { padding-left: 3em; }
    .ql-indent-2 { padding-left: 6em; }
    .ql-indent-3 { padding-left: 9em; }
    .ql-indent-4 { padding-left: 12em; }
    .ql-indent-5 { padding-left: 15em; }
    .ql-indent-6 { padding-left: 18em; }
    .ql-indent-7 { padding-left: 21em; }
    .ql-indent-8 { padding-left: 24em; }
    
    /* Table styles */
    .ql-editor table { border-collapse: collapse; margin: 16px 0; box-sizing: border-box; }
    .ql-editor table td, .ql-editor table th { 
      border: 1px solid #e5e0da; 
      min-width: 50px;
      vertical-align: top;
    }
    .ql-editor table td:not([style*="padding"]), .ql-editor table th:not([style*="padding"]) { 
      padding: 8px 16px; 
    }
    .ql-editor table.table-with-header tr:first-child td:not([style*="background"]),
    .ql-editor table th:not([style*="background"]) { background: #f8f6f3; font-weight: 500; }
    .ql-editor table td p { margin: 0; }
    .ql-editor table colgroup, .ql-editor table col { display: table-column; }
    
    /* Table alignment */
    .ql-editor table.align-left { float: left; margin-right: 16px; margin-bottom: 8px; }
    .ql-editor table.align-center { display: table; margin-left: auto; margin-right: auto; }
    .ql-editor table.align-right { float: right; margin-left: 16px; margin-bottom: 8px; }
    
    /* List styles */
    .ql-editor ul, .ql-editor ol { padding-left: 24px; margin-bottom: 1em; }
    .ql-editor li { margin-bottom: 0.5em; }
    .ql-editor ul[data-checked="true"] > li::before { content: '☑'; margin-right: 8px; color: #c45d35; }
    .ql-editor ul[data-checked="false"] > li::before { content: '☐'; margin-right: 8px; color: #c45d35; }
    
    /* Media styles */
    .ql-editor img { max-width: 100%; border-radius: 8px; }
    .ql-editor iframe, .ql-editor video, .ql-editor .ql-video { 
      max-width: 100%; 
      display: block; 
      margin: 16px 0;
      border-radius: 8px;
    }
    
    /* Media alignment */
    .ql-editor img.align-left, .ql-editor iframe.align-left, .ql-editor video.align-left {
      float: left; margin-right: 16px; margin-bottom: 8px;
    }
    .ql-editor img.align-center, .ql-editor iframe.align-center, .ql-editor video.align-center {
      display: block; margin-left: auto; margin-right: auto; margin-top: 16px; margin-bottom: 16px;
    }
    .ql-editor img.align-right, .ql-editor iframe.align-right, .ql-editor video.align-right {
      float: right; margin-left: 16px; margin-bottom: 8px;
    }
    
    /* Text formatting */
    sub { vertical-align: sub; font-size: smaller; }
    sup { vertical-align: super; font-size: smaller; }
    .ql-direction-rtl { direction: rtl; text-align: inherit; }
    
    /* Text alignment */
    .ql-align-center { text-align: center; }
    .ql-align-right { text-align: right; }
    .ql-align-justify { text-align: justify; }
    
    /* Clear floats */
    .ql-editor::after { content: ""; display: table; clear: both; }
    .ql-editor p::after { content: ""; display: table; clear: both; }
    
    /* Hide editor artifacts */
    .ql-table-better-selected-td, .ql-table-better-selection-line, .ql-table-better-selection-block,
    .ql-table-better-col-tool, .ql-table-better-row-tool, .ql-table-better-corner,
    [class*="ql-table-better-select"], [class*="ql-table-better-tool"], temporary {
      display: none !important;
    }
  </style>
</head>
<body>
  <div class="ql-editor">$editorContent</div>
</body>
</html>
''';
  }

  /// List of all supported font classes
  static const List<String> supportedFonts = [
    'ql-font-roboto',
    'ql-font-open-sans',
    'ql-font-lato',
    'ql-font-montserrat',
    'ql-font-source-code',
    'ql-font-crimson',
    'ql-font-dm-sans',
  ];

  /// Map of font class to font-family value
  static const Map<String, String> fontFamilyMap = {
    'ql-font-roboto': "'Roboto', sans-serif",
    'ql-font-open-sans': "'Open Sans', sans-serif",
    'ql-font-lato': "'Lato', sans-serif",
    'ql-font-montserrat': "'Montserrat', sans-serif",
    'ql-font-source-code': "'Source Code Pro', monospace",
    'ql-font-crimson': "'Crimson Pro', serif",
    'ql-font-dm-sans': "'DM Sans', sans-serif",
  };

  /// List of all supported size classes
  static const List<String> supportedSizes = [
    'ql-size-small',
    'ql-size-large',
    'ql-size-huge',
  ];

  /// Map of size class to font-size value
  static const Map<String, String> sizeValueMap = {
    'ql-size-small': '0.75em',
    'ql-size-large': '1.5em',
    'ql-size-huge': '2.5em',
  };

  /// List of all supported indent classes
  static const List<String> supportedIndents = [
    'ql-indent-1',
    'ql-indent-2',
    'ql-indent-3',
    'ql-indent-4',
    'ql-indent-5',
    'ql-indent-6',
    'ql-indent-7',
    'ql-indent-8',
  ];

  /// List of all supported alignment classes
  static const List<String> supportedAlignments = [
    'ql-align-center',
    'ql-align-right',
    'ql-align-justify',
  ];

  /// List of all supported line height classes
  static const List<String> supportedLineHeights = [
    'ql-line-height-1',
    'ql-line-height-1-5',
    'ql-line-height-2',
    'ql-line-height-2-5',
    'ql-line-height-3',
  ];

  /// List of required Google Font names
  static const List<String> requiredGoogleFonts = [
    'Crimson+Pro',
    'DM+Sans',
    'Roboto',
    'Open+Sans',
    'Lato',
    'Montserrat',
    'Source+Code+Pro',
  ];
}

/// Paste HTML Preprocessor - simulates the preprocessing done in quill_editor.html
class PastePreprocessor {
  /// Map of common fonts to Quill font classes
  static const Map<String, String> fontFamilyMap = {
    'roboto': 'roboto',
    'open sans': 'open-sans',
    'opensans': 'open-sans',
    'lato': 'lato',
    'montserrat': 'montserrat',
    'source code pro': 'source-code',
    'sourcecodepro': 'source-code',
    'crimson pro': 'crimson',
    'crimsonpro': 'crimson',
    'crimson text': 'crimson',
    'dm sans': 'dm-sans',
    'dmsans': 'dm-sans',
    // Common fonts mapped to Quill fonts
    'arial': 'roboto',
    'helvetica': 'roboto',
    'verdana': 'open-sans',
    'tahoma': 'open-sans',
    'trebuchet ms': 'montserrat',
    'georgia': 'crimson',
    'times': 'crimson',
    'times new roman': 'crimson',
    'courier': 'source-code',
    'courier new': 'source-code',
    'consolas': 'source-code',
    'monaco': 'source-code',
    'menlo': 'source-code',
  };

  /// Maps a font family string to a Quill font class
  static String? mapFontFamily(String? fontFamily) {
    if (fontFamily == null || fontFamily.isEmpty) return null;

    // Clean and normalize font family
    final fonts = fontFamily
        .toLowerCase()
        .split(',')
        .map((f) => f.trim().replaceAll(RegExp('[\'"]'), ''))
        .toList();

    // Try to match each font in the stack
    for (final font in fonts) {
      if (fontFamilyMap.containsKey(font)) {
        return fontFamilyMap[font];
      }
      // Try partial match
      for (final entry in fontFamilyMap.entries) {
        if (font.contains(entry.key) || entry.key.contains(font)) {
          return entry.value;
        }
      }
    }

    return null; // default font
  }

  /// Maps a font size to a Quill size class
  static String? mapFontSize(String? size) {
    if (size == null || size.isEmpty) return null;

    final sizeStr = size.toLowerCase().trim();
    double? pxValue;

    // Handle px values
    if (sizeStr.endsWith('px')) {
      pxValue = double.tryParse(sizeStr.replaceAll('px', ''));
    } else if (sizeStr.endsWith('pt')) {
      final pt = double.tryParse(sizeStr.replaceAll('pt', ''));
      if (pt != null) pxValue = pt * 1.333;
    } else if (sizeStr.endsWith('em')) {
      final em = double.tryParse(sizeStr.replaceAll('em', ''));
      if (em != null) pxValue = em * 16;
    } else if (sizeStr.endsWith('rem')) {
      final rem = double.tryParse(sizeStr.replaceAll('rem', ''));
      if (rem != null) pxValue = rem * 16;
    } else {
      pxValue = double.tryParse(sizeStr);
    }

    // Handle keyword sizes
    if (sizeStr == 'small' || sizeStr == 'x-small' || sizeStr == 'xx-small') {
      return 'small';
    }
    if (sizeStr == 'large' || sizeStr == 'x-large') return 'large';
    if (sizeStr == 'xx-large' || sizeStr == 'xxx-large') return 'huge';

    // Map px values to Quill sizes
    if (pxValue != null) {
      if (pxValue <= 12) return 'small';
      if (pxValue <= 18) return null; // normal
      if (pxValue <= 24) return 'large';
      return 'huge';
    }

    return null; // normal size
  }

  /// Normalizes a color value to hex format
  static String? normalizeColor(String? color) {
    if (color == null || color.isEmpty) return null;

    color = color.trim();

    // Already hex
    if (color.startsWith('#')) return color;

    // Handle rgb/rgba
    final rgbMatch =
        RegExp(r'rgba?\((\d+),\s*(\d+),\s*(\d+)').firstMatch(color);
    if (rgbMatch != null) {
      final r = int.parse(rgbMatch.group(1)!).toRadixString(16).padLeft(2, '0');
      final g = int.parse(rgbMatch.group(2)!).toRadixString(16).padLeft(2, '0');
      final b = int.parse(rgbMatch.group(3)!).toRadixString(16).padLeft(2, '0');
      return '#$r$g$b';
    }

    return color;
  }
}

void main() {
  // ============================================
  // Export Tests - HTML Structure
  // ============================================
  group('Export HTML Structure Tests', () {
    test('Should include DOCTYPE declaration', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('<!DOCTYPE html>'), isTrue);
    });

    test('Should include UTF-8 charset meta tag', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('charset="UTF-8"'), isTrue);
    });

    test('Should include viewport meta tag', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('viewport'), isTrue);
    });

    test('Should include Quill CSS link', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('quill.snow.css'), isTrue);
    });

    test('Should include quill-table-better CSS link', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('quill-table-better.css'), isTrue);
    });

    test('Should include Google Fonts link', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('fonts.googleapis.com'), isTrue);
    });

    test('Should include ql-editor wrapper div', () {
      final html = HtmlExporter.generateFullHtml('<p>Test content</p>');
      expect(html.contains('<div class="ql-editor">'), isTrue);
    });

    test('Should preserve editor content in export', () {
      const content = '<p>My custom content here</p>';
      final html = HtmlExporter.generateFullHtml(content);
      expect(html.contains('My custom content here'), isTrue);
    });
  });

  // ============================================
  // Export Tests - Font CSS Classes
  // ============================================
  group('Export Font CSS Classes Tests', () {
    test('Should include all 7 font CSS classes', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final fontClass in HtmlExporter.supportedFonts) {
        expect(html.contains('.$fontClass'), isTrue,
            reason: 'Missing CSS class: $fontClass');
      }
    });

    test('Should include correct font-family values for each font class', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains(".ql-font-roboto { font-family: 'Roboto'"), isTrue);
      expect(
          html.contains(".ql-font-open-sans { font-family: 'Open Sans'"), isTrue);
      expect(html.contains(".ql-font-lato { font-family: 'Lato'"), isTrue);
      expect(
          html.contains(".ql-font-montserrat { font-family: 'Montserrat'"), isTrue);
      expect(html.contains(".ql-font-source-code { font-family: 'Source Code Pro'"),
          isTrue);
      expect(
          html.contains(".ql-font-crimson { font-family: 'Crimson Pro'"), isTrue);
      expect(html.contains(".ql-font-dm-sans { font-family: 'DM Sans'"), isTrue);
    });

    test('Should include all required Google Fonts in link', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final font in HtmlExporter.requiredGoogleFonts) {
        expect(html.contains(font), isTrue,
            reason: 'Missing Google Font: $font');
      }
    });
  });

  // ============================================
  // Export Tests - Size CSS Classes
  // ============================================
  group('Export Size CSS Classes Tests', () {
    test('Should include all size CSS classes', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final sizeClass in HtmlExporter.supportedSizes) {
        expect(html.contains('.$sizeClass'), isTrue,
            reason: 'Missing CSS class: $sizeClass');
      }
    });

    test('Should include correct font-size values', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('.ql-size-small { font-size: 0.75em; }'), isTrue);
      expect(html.contains('.ql-size-large { font-size: 1.5em; }'), isTrue);
      expect(html.contains('.ql-size-huge { font-size: 2.5em; }'), isTrue);
    });
  });

  // ============================================
  // Export Tests - Table CSS Styles
  // ============================================
  group('Export Table CSS Styles Tests', () {
    test('Should include table border-collapse style', () {
      final html = HtmlExporter.generateFullHtml('<table><tr><td>Cell</td></tr></table>');
      expect(html.contains('border-collapse: collapse'), isTrue);
    });

    test('Should include table cell border style', () {
      final html = HtmlExporter.generateFullHtml('<table><tr><td>Cell</td></tr></table>');
      expect(html.contains('.ql-editor table td'), isTrue);
      expect(html.contains('border: 1px solid'), isTrue);
    });

    test('Should include table cell padding style', () {
      final html = HtmlExporter.generateFullHtml('<table><tr><td>Cell</td></tr></table>');
      expect(html.contains('padding: 8px 16px'), isTrue);
    });

    test('Should include table header row style', () {
      final html = HtmlExporter.generateFullHtml('<table class="table-with-header"><tr><td>Header</td></tr></table>');
      expect(html.contains('table-with-header'), isTrue);
    });

    test('Should include table alignment classes', () {
      final html = HtmlExporter.generateFullHtml('<table class="align-center"><tr><td>Cell</td></tr></table>');
      expect(html.contains('table.align-left'), isTrue);
      expect(html.contains('table.align-center'), isTrue);
      expect(html.contains('table.align-right'), isTrue);
    });

    test('Should hide table selection artifacts', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('ql-table-better-selected-td'), isTrue);
      expect(html.contains('display: none'), isTrue);
    });
  });

  // ============================================
  // Export Tests - Typography Styles
  // ============================================
  group('Export Typography Styles Tests', () {
    test('Should include heading styles (h1-h6)', () {
      final html = HtmlExporter.generateFullHtml('<h1>Title</h1>');

      expect(html.contains('.ql-editor h1'), isTrue);
      expect(html.contains('.ql-editor h2'), isTrue);
      expect(html.contains('.ql-editor h3'), isTrue);
      expect(html.contains('.ql-editor h4'), isTrue);
      expect(html.contains('.ql-editor h5'), isTrue);
      expect(html.contains('.ql-editor h6'), isTrue);
    });

    test('Should include blockquote style with border-left', () {
      final html = HtmlExporter.generateFullHtml('<blockquote>Quote</blockquote>');
      expect(html.contains('.ql-editor blockquote'), isTrue);
      expect(html.contains('border-left'), isTrue);
    });

    test('Should include pre/code block style', () {
      final html = HtmlExporter.generateFullHtml('<pre>Code</pre>');
      expect(html.contains('.ql-editor pre'), isTrue);
    });

    test('Should include link style', () {
      final html = HtmlExporter.generateFullHtml('<a href="#">Link</a>');
      expect(html.contains('.ql-editor a'), isTrue);
    });

    test('Should include inline code style', () {
      final html = HtmlExporter.generateFullHtml('<code>inline code</code>');
      expect(html.contains('.ql-editor code'), isTrue);
    });
  });

  // ============================================
  // Export Tests - Alignment & Direction Styles
  // ============================================
  group('Export Alignment & Direction Styles Tests', () {
    test('Should include all alignment classes', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final alignClass in HtmlExporter.supportedAlignments) {
        expect(html.contains('.$alignClass'), isTrue,
            reason: 'Missing CSS class: $alignClass');
      }
    });

    test('Should include correct text-align values', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('.ql-align-center { text-align: center; }'), isTrue);
      expect(html.contains('.ql-align-right { text-align: right; }'), isTrue);
      expect(html.contains('.ql-align-justify { text-align: justify; }'), isTrue);
    });

    test('Should include RTL direction style', () {
      final html = HtmlExporter.generateFullHtml('<p class="ql-direction-rtl">RTL</p>');
      expect(html.contains('.ql-direction-rtl'), isTrue);
      expect(html.contains('direction: rtl'), isTrue);
    });
  });

  // ============================================
  // Export Tests - List Styles
  // ============================================
  group('Export List Styles Tests', () {
    test('Should include ul/ol list styles', () {
      final html = HtmlExporter.generateFullHtml('<ul><li>Item</li></ul>');
      expect(html.contains('.ql-editor ul'), isTrue);
      expect(html.contains('.ql-editor ol'), isTrue);
    });

    test('Should include list padding-left', () {
      final html = HtmlExporter.generateFullHtml('<ul><li>Item</li></ul>');
      expect(html.contains('padding-left: 24px'), isTrue);
    });

    test('Should include checklist styles', () {
      final html = HtmlExporter.generateFullHtml('<ul data-checked="true"><li>Done</li></ul>');
      expect(html.contains('data-checked="true"'), isTrue);
      expect(html.contains('data-checked="false"'), isTrue);
    });

    test('Should include all indent classes', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final indentClass in HtmlExporter.supportedIndents) {
        expect(html.contains('.$indentClass'), isTrue,
            reason: 'Missing CSS class: $indentClass');
      }
    });

    test('Should include correct padding-left values for indents', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('.ql-indent-1 { padding-left: 3em; }'), isTrue);
      expect(html.contains('.ql-indent-2 { padding-left: 6em; }'), isTrue);
      expect(html.contains('.ql-indent-3 { padding-left: 9em; }'), isTrue);
      expect(html.contains('.ql-indent-4 { padding-left: 12em; }'), isTrue);
    });
  });

  // ============================================
  // Export Tests - Media Styles
  // ============================================
  group('Export Media Styles Tests', () {
    test('Should include image max-width style', () {
      final html = HtmlExporter.generateFullHtml('<img src="test.jpg">');
      expect(html.contains('.ql-editor img'), isTrue);
      expect(html.contains('max-width: 100%'), isTrue);
    });

    test('Should include iframe/video styles', () {
      final html = HtmlExporter.generateFullHtml('<iframe src="test"></iframe>');
      expect(html.contains('.ql-editor iframe'), isTrue);
      expect(html.contains('.ql-editor video'), isTrue);
    });

    test('Should include media alignment classes', () {
      final html = HtmlExporter.generateFullHtml('<img class="align-center" src="test.jpg">');
      expect(html.contains('img.align-left'), isTrue);
      expect(html.contains('img.align-center'), isTrue);
      expect(html.contains('img.align-right'), isTrue);
    });
  });

  // ============================================
  // Export Tests - Text Formatting Styles
  // ============================================
  group('Export Text Formatting Styles Tests', () {
    test('Should include subscript (sub) style', () {
      final html = HtmlExporter.generateFullHtml('<sub>2</sub>');
      expect(html.contains('sub {'), isTrue);
      expect(html.contains('vertical-align: sub'), isTrue);
    });

    test('Should include superscript (sup) style', () {
      final html = HtmlExporter.generateFullHtml('<sup>2</sup>');
      expect(html.contains('sup {'), isTrue);
      expect(html.contains('vertical-align: super'), isTrue);
    });

    test('Should include clear floats style', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');
      expect(html.contains('clear: both'), isTrue);
    });
  });

  // ============================================
  // Paste Preprocessing Tests - Font Family Mapping
  // ============================================
  group('Paste Font Family Mapping Tests', () {
    test('Should map Roboto to roboto', () {
      expect(PastePreprocessor.mapFontFamily('Roboto'), equals('roboto'));
      expect(PastePreprocessor.mapFontFamily('Roboto, sans-serif'),
          equals('roboto'));
    });

    test('Should map Open Sans to open-sans', () {
      expect(PastePreprocessor.mapFontFamily('Open Sans'), equals('open-sans'));
      expect(PastePreprocessor.mapFontFamily("'Open Sans', sans-serif"),
          equals('open-sans'));
    });

    test('Should map Lato to lato', () {
      expect(PastePreprocessor.mapFontFamily('Lato'), equals('lato'));
    });

    test('Should map Montserrat to montserrat', () {
      expect(
          PastePreprocessor.mapFontFamily('Montserrat'), equals('montserrat'));
    });

    test('Should map Source Code Pro to source-code', () {
      expect(PastePreprocessor.mapFontFamily('Source Code Pro'),
          equals('source-code'));
    });

    test('Should map Crimson Pro to crimson', () {
      expect(PastePreprocessor.mapFontFamily('Crimson Pro'), equals('crimson'));
    });

    test('Should map DM Sans to dm-sans', () {
      expect(PastePreprocessor.mapFontFamily('DM Sans'), equals('dm-sans'));
    });

    test('Should map Arial to roboto', () {
      expect(PastePreprocessor.mapFontFamily('Arial'), equals('roboto'));
    });

    test('Should map Times New Roman to crimson', () {
      expect(PastePreprocessor.mapFontFamily('Times New Roman'),
          equals('crimson'));
    });

    test('Should map Courier New to source-code', () {
      expect(
          PastePreprocessor.mapFontFamily('Courier New'), equals('source-code'));
    });

    test('Should map Georgia to crimson', () {
      expect(PastePreprocessor.mapFontFamily('Georgia'), equals('crimson'));
    });

    test('Should return null for unknown fonts', () {
      expect(PastePreprocessor.mapFontFamily('UnknownFont'), isNull);
    });

    test('Should return null for empty string', () {
      expect(PastePreprocessor.mapFontFamily(''), isNull);
    });

    test('Should return null for null input', () {
      expect(PastePreprocessor.mapFontFamily(null), isNull);
    });

    test('Should handle font stack and return first match', () {
      expect(
          PastePreprocessor.mapFontFamily(
              'Arial, Helvetica, sans-serif'),
          equals('roboto'));
    });
  });

  // ============================================
  // Paste Preprocessing Tests - Font Size Mapping
  // ============================================
  group('Paste Font Size Mapping Tests', () {
    test('Should map small px values (10px) to small', () {
      expect(PastePreprocessor.mapFontSize('10px'), equals('small'));
      expect(PastePreprocessor.mapFontSize('12px'), equals('small'));
    });

    test('Should map normal px values (14-18px) to null', () {
      expect(PastePreprocessor.mapFontSize('14px'), isNull);
      expect(PastePreprocessor.mapFontSize('16px'), isNull);
      expect(PastePreprocessor.mapFontSize('18px'), isNull);
    });

    test('Should map large px values (20-24px) to large', () {
      expect(PastePreprocessor.mapFontSize('20px'), equals('large'));
      expect(PastePreprocessor.mapFontSize('24px'), equals('large'));
    });

    test('Should map huge px values (25px+) to huge', () {
      expect(PastePreprocessor.mapFontSize('30px'), equals('huge'));
      expect(PastePreprocessor.mapFontSize('48px'), equals('huge'));
    });

    test('Should map pt values correctly', () {
      expect(PastePreprocessor.mapFontSize('8pt'), equals('small'));
      expect(PastePreprocessor.mapFontSize('18pt'), equals('large'));
    });

    test('Should map em values correctly', () {
      expect(PastePreprocessor.mapFontSize('0.5em'), equals('small'));
      expect(PastePreprocessor.mapFontSize('1.5em'), equals('large'));
    });

    test('Should map keyword sizes correctly', () {
      expect(PastePreprocessor.mapFontSize('small'), equals('small'));
      expect(PastePreprocessor.mapFontSize('x-small'), equals('small'));
      expect(PastePreprocessor.mapFontSize('large'), equals('large'));
      expect(PastePreprocessor.mapFontSize('x-large'), equals('large'));
      expect(PastePreprocessor.mapFontSize('xx-large'), equals('huge'));
    });

    test('Should return null for empty string', () {
      expect(PastePreprocessor.mapFontSize(''), isNull);
    });

    test('Should return null for null input', () {
      expect(PastePreprocessor.mapFontSize(null), isNull);
    });
  });

  // ============================================
  // Paste Preprocessing Tests - Color Normalization
  // ============================================
  group('Paste Color Normalization Tests', () {
    test('Should preserve hex colors', () {
      expect(PastePreprocessor.normalizeColor('#ff0000'), equals('#ff0000'));
      expect(PastePreprocessor.normalizeColor('#00ff00'), equals('#00ff00'));
      expect(PastePreprocessor.normalizeColor('#0000ff'), equals('#0000ff'));
    });

    test('Should convert RGB to hex', () {
      expect(
          PastePreprocessor.normalizeColor('rgb(255, 0, 0)'), equals('#ff0000'));
      expect(
          PastePreprocessor.normalizeColor('rgb(0, 255, 0)'), equals('#00ff00'));
      expect(
          PastePreprocessor.normalizeColor('rgb(0, 0, 255)'), equals('#0000ff'));
    });

    test('Should convert RGBA to hex (ignoring alpha)', () {
      expect(PastePreprocessor.normalizeColor('rgba(255, 0, 0, 0.5)'),
          equals('#ff0000'));
      expect(PastePreprocessor.normalizeColor('rgba(0, 128, 255, 1)'),
          equals('#0080ff'));
    });

    test('Should handle RGB with different spacing', () {
      expect(
          PastePreprocessor.normalizeColor('rgb(255,0,0)'), equals('#ff0000'));
      expect(PastePreprocessor.normalizeColor('rgb(255,  0,  0)'),
          equals('#ff0000'));
    });

    test('Should return null for empty string', () {
      expect(PastePreprocessor.normalizeColor(''), isNull);
    });

    test('Should return null for null input', () {
      expect(PastePreprocessor.normalizeColor(null), isNull);
    });

    test('Should preserve named colors', () {
      expect(PastePreprocessor.normalizeColor('red'), equals('red'));
      expect(PastePreprocessor.normalizeColor('blue'), equals('blue'));
    });
  });

  // ============================================
  // Export Content Preservation Tests
  // ============================================
  group('Export Content Preservation Tests', () {
    test('Should preserve HTML content with fonts', () {
      const content =
          '<p><span class="ql-font-roboto">Roboto text</span></p>';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('ql-font-roboto'), isTrue);
      expect(html.contains('Roboto text'), isTrue);
    });

    test('Should preserve HTML content with multiple fonts', () {
      const content = '''
<p><span class="ql-font-roboto">Roboto</span></p>
<p><span class="ql-font-lato">Lato</span></p>
<p><span class="ql-font-montserrat">Montserrat</span></p>
''';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('ql-font-roboto'), isTrue);
      expect(html.contains('ql-font-lato'), isTrue);
      expect(html.contains('ql-font-montserrat'), isTrue);
    });

    test('Should preserve HTML content with sizes', () {
      const content = '''
<p><span class="ql-size-small">Small</span></p>
<p><span class="ql-size-large">Large</span></p>
<p><span class="ql-size-huge">Huge</span></p>
''';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('class="ql-size-small"'), isTrue);
      expect(html.contains('class="ql-size-large"'), isTrue);
      expect(html.contains('class="ql-size-huge"'), isTrue);
    });

    test('Should preserve table structure', () {
      const content = '''
<table>
  <tbody>
    <tr><td>Cell 1</td><td>Cell 2</td></tr>
    <tr><td>Cell 3</td><td>Cell 4</td></tr>
  </tbody>
</table>
''';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('<table>'), isTrue);
      expect(html.contains('<tbody>'), isTrue);
      expect(html.contains('<tr>'), isTrue);
      expect(html.contains('<td>'), isTrue);
      expect(html.contains('Cell 1'), isTrue);
    });

    test('Should preserve formatted text in tables', () {
      const content = '''
<table>
  <tbody>
    <tr><td><strong>Bold</strong></td><td><em>Italic</em></td></tr>
  </tbody>
</table>
''';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('<strong>Bold</strong>'), isTrue);
      expect(html.contains('<em>Italic</em>'), isTrue);
    });

    test('Should preserve list structure', () {
      const content = '''
<ul>
  <li>Item 1</li>
  <li>Item 2</li>
</ul>
''';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('<ul>'), isTrue);
      expect(html.contains('<li>'), isTrue);
      expect(html.contains('Item 1'), isTrue);
    });

    test('Should preserve alignment classes', () {
      const content =
          '<p class="ql-align-center">Centered text</p>';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('class="ql-align-center"'), isTrue);
      expect(html.contains('Centered text'), isTrue);
    });

    test('Should preserve combined font and size classes', () {
      const content =
          '<p><span class="ql-font-montserrat ql-size-large">Large Montserrat</span></p>';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('ql-font-montserrat'), isTrue);
      expect(html.contains('ql-size-large'), isTrue);
    });

    test('Should preserve inline styles', () {
      const content =
          '<span style="color: #ff0000; background-color: #ffff00;">Colored text</span>';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('color: #ff0000'), isTrue);
      expect(html.contains('background-color: #ffff00'), isTrue);
    });
  });

  // ============================================
  // Edge Cases Tests
  // ============================================
  group('Edge Cases Tests', () {
    test('Should handle empty content', () {
      final html = HtmlExporter.generateFullHtml('');

      expect(html.contains('<div class="ql-editor"></div>'), isTrue);
      // CSS should still be present
      expect(html.contains('.ql-font-roboto'), isTrue);
    });

    test('Should handle content with special characters', () {
      const content = '<p>Special: &amp; &lt; &gt; "quotes"</p>';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('&amp;'), isTrue);
      expect(html.contains('&lt;'), isTrue);
      expect(html.contains('&gt;'), isTrue);
    });

    test('Should handle deeply nested formatting', () {
      const content =
          '<p><strong><em><span class="ql-font-roboto">Bold Italic Roboto</span></em></strong></p>';
      final html = HtmlExporter.generateFullHtml(content);

      expect(html.contains('<strong>'), isTrue);
      expect(html.contains('<em>'), isTrue);
      expect(html.contains('ql-font-roboto'), isTrue);
    });

    test('Font class list should have exactly 7 fonts', () {
      expect(HtmlExporter.supportedFonts.length, equals(7));
    });

    test('Size class list should have exactly 3 sizes', () {
      expect(HtmlExporter.supportedSizes.length, equals(3));
    });

    test('Indent class list should have exactly 8 levels', () {
      expect(HtmlExporter.supportedIndents.length, equals(8));
    });

    test('Alignment class list should have exactly 3 alignments', () {
      expect(HtmlExporter.supportedAlignments.length, equals(3));
    });

    test('Line height class list should have exactly 5 heights', () {
      expect(HtmlExporter.supportedLineHeights.length, equals(5));
    });

    test('Google fonts list should have exactly 7 fonts', () {
      expect(HtmlExporter.requiredGoogleFonts.length, equals(7));
    });
  });
}

