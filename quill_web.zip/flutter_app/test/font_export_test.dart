import 'package:flutter_test/flutter_test.dart';

/// HTML Generator - mirrors the logic in home_page.dart _downloadHtml()
class HtmlExporter {
  /// Generates a complete HTML document from editor content
  static String generateFullHtml(String editorContent) {
    return '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <link href="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/quill-table-better@1/dist/quill-table-better.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@400;500;600&family=DM+Sans:wght@400;500;600&family=Roboto:wght@400;500&family=Open+Sans:wght@400;500&family=Lato:wght@400;700&family=Montserrat:wght@400;500;600&family=Source+Code+Pro:wght@400;500&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Georgia', serif; padding: 20px; max-width: 800px; margin: 0 auto; }
    .ql-editor { font-size: 16px; line-height: 1.8; }
    
    /* Font family classes */
    .ql-font-roboto { font-family: 'Roboto', sans-serif; }
    .ql-font-open-sans { font-family: 'Open Sans', sans-serif; }
    .ql-font-lato { font-family: 'Lato', sans-serif; }
    .ql-font-montserrat { font-family: 'Montserrat', sans-serif; }
    .ql-font-source-code { font-family: 'Source Code Pro', monospace; }
    .ql-font-crimson { font-family: 'Crimson Pro', serif; }
    .ql-font-dm-sans { font-family: 'DM Sans', sans-serif; }
    
    /* Font size classes */
    .ql-size-small { font-size: 0.75em; }
    .ql-size-large { font-size: 1.5em; }
    .ql-size-huge { font-size: 2.5em; }
    
    /* Additional styles for proper rendering */
    .ql-editor h1 { font-size: 2em; font-weight: bold; margin: 0.67em 0; }
    .ql-editor h2 { font-size: 1.5em; font-weight: bold; margin: 0.75em 0; }
    .ql-editor h3 { font-size: 1.17em; font-weight: bold; margin: 0.83em 0; }
    .ql-editor h4 { font-size: 1em; font-weight: bold; margin: 0.83em 0; }
    .ql-editor h5 { font-size: 0.83em; font-weight: bold; margin: 0.83em 0; }
    .ql-editor h6 { font-size: 0.67em; font-weight: bold; margin: 0.83em 0; }
    .ql-editor blockquote { border-left: 4px solid #ccc; padding-left: 16px; margin: 16px 0; }
    .ql-editor pre { background: #f5f5f5; padding: 16px; border-radius: 4px; overflow-x: auto; }
    .ql-editor a { color: #06c; text-decoration: underline; }
    .ql-editor img { max-width: 100%; }
    
    /* Table styles - comprehensive for quill-table-better */
    .ql-editor table { border-collapse: collapse; width: 100%; margin: 16px 0; table-layout: fixed; }
    .ql-editor table td, .ql-editor table th { border: 1px solid #ddd; padding: 8px 12px; min-width: 50px; vertical-align: top; }
    /* Header row styling - only when table has .table-with-header class */
    .ql-editor table.table-with-header tr:first-child td, .ql-editor table th { background: #f8f8f8; font-weight: 600; }
    .ql-editor table tbody tr:nth-child(even) { background: #fafafa; }
    .ql-editor table td[rowspan], .ql-editor table td[colspan] { vertical-align: middle; }
    .ql-editor table td p { margin: 0; }
    .ql-editor .ql-table-wrapper { overflow-x: auto; margin: 16px 0; }
    .ql-editor .ql-table { border-collapse: collapse; }
    .ql-editor .ql-table td { border: 1px solid #ddd; padding: 8px 12px; }
    
    /* Hide ALL table/cell selection colors in exported HTML */
    .ql-editor table td.ql-cell-selected,
    .ql-editor table td.selected,
    .ql-editor table.ql-table-selected,
    .ql-editor [class*="selected"],
    .ql-editor td[style*="background"],
    .ql-editor .ql-cell-focused {
      background-color: transparent !important;
      background: transparent !important;
      outline: none !important;
      box-shadow: none !important;
      border-color: #ddd !important;
    }
    .ql-editor table td { background-color: transparent !important; }
    .ql-editor table.table-with-header tr:first-child td { background-color: #f8f8f8 !important; }
    .ql-table-better-selected-td,
    .ql-table-better-selection-line,
    .ql-table-better-selection-block,
    .ql-table-better-col-tool,
    .ql-table-better-row-tool,
    [class*="ql-table-better-select"],
    [class*="ql-table-better-tool"] {
      display: none !important;
      visibility: hidden !important;
    }
    
    /* List styles */
    .ql-editor ul, .ql-editor ol { padding-left: 1.5em; margin: 16px 0; }
    .ql-editor li { margin: 4px 0; }
    
    /* Media styles */
    .ql-editor iframe, .ql-editor video { max-width: 100%; display: block; margin: 16px 0; }
    
    /* Text formatting */
    sub { vertical-align: sub; font-size: smaller; }
    sup { vertical-align: super; font-size: smaller; }
    .ql-direction-rtl { direction: rtl; text-align: right; }
    
    /* Code styles */
    .ql-editor code { background: #f0f0f0; padding: 2px 4px; border-radius: 3px; font-family: monospace; }
  </style>
</head>
<body>
  <div class="ql-editor">$editorContent</div>
</body>
</html>
''';
  }

  /// List of all supported font classes
  static const List<String> supportedFonts = [
    'ql-font-roboto',
    'ql-font-open-sans',
    'ql-font-lato',
    'ql-font-montserrat',
    'ql-font-source-code',
    'ql-font-crimson',
    'ql-font-dm-sans',
  ];

  /// List of all supported size classes
  static const List<String> supportedSizes = [
    'ql-size-small',
    'ql-size-large',
    'ql-size-huge',
  ];
}

/// Test cases for verifying multiple fonts are properly exported in HTML
void main() {
  group('Font Export Tests', () {
    // Sample HTML with multiple fonts as Quill would generate
    const sampleHtmlWithMultipleFonts = '''
<p>This is <span class="ql-font-roboto">Roboto text</span> and this is <span class="ql-font-lato">Lato text</span>.</p>
<p class="ql-font-montserrat">This entire paragraph is Montserrat.</p>
<p>Mixed: <span class="ql-font-dm-sans">DM Sans</span>, <span class="ql-font-crimson">Crimson Pro</span>, <span class="ql-font-source-code">Source Code</span></p>
''';

    test('HTML should contain font class names', () {
      expect(sampleHtmlWithMultipleFonts.contains('ql-font-roboto'), isTrue);
      expect(sampleHtmlWithMultipleFonts.contains('ql-font-lato'), isTrue);
      expect(
          sampleHtmlWithMultipleFonts.contains('ql-font-montserrat'), isTrue);
      expect(sampleHtmlWithMultipleFonts.contains('ql-font-dm-sans'), isTrue);
      expect(sampleHtmlWithMultipleFonts.contains('ql-font-crimson'), isTrue);
      expect(
          sampleHtmlWithMultipleFonts.contains('ql-font-source-code'), isTrue);
    });

    test('Exported HTML template should include all font CSS classes', () {
      // This is the CSS that should be in the exported HTML
      const exportedCss = '''
    .ql-font-roboto { font-family: 'Roboto', sans-serif; }
    .ql-font-open-sans { font-family: 'Open Sans', sans-serif; }
    .ql-font-lato { font-family: 'Lato', sans-serif; }
    .ql-font-montserrat { font-family: 'Montserrat', sans-serif; }
    .ql-font-source-code { font-family: 'Source Code Pro', monospace; }
    .ql-font-crimson { font-family: 'Crimson Pro', serif; }
    .ql-font-dm-sans { font-family: 'DM Sans', sans-serif; }
''';

      // Verify all font classes are defined
      expect(exportedCss.contains('.ql-font-roboto'), isTrue);
      expect(exportedCss.contains('.ql-font-open-sans'), isTrue);
      expect(exportedCss.contains('.ql-font-lato'), isTrue);
      expect(exportedCss.contains('.ql-font-montserrat'), isTrue);
      expect(exportedCss.contains('.ql-font-source-code'), isTrue);
      expect(exportedCss.contains('.ql-font-crimson'), isTrue);
      expect(exportedCss.contains('.ql-font-dm-sans'), isTrue);

      // Verify font-family values
      expect(exportedCss.contains("font-family: 'Roboto'"), isTrue);
      expect(exportedCss.contains("font-family: 'Open Sans'"), isTrue);
      expect(exportedCss.contains("font-family: 'Lato'"), isTrue);
      expect(exportedCss.contains("font-family: 'Montserrat'"), isTrue);
      expect(exportedCss.contains("font-family: 'Source Code Pro'"), isTrue);
      expect(exportedCss.contains("font-family: 'Crimson Pro'"), isTrue);
      expect(exportedCss.contains("font-family: 'DM Sans'"), isTrue);
    });

    test('Exported HTML should include Google Fonts link', () {
      const googleFontsLink =
          "https://fonts.googleapis.com/css2?family=Crimson+Pro";

      // This should be in the exported HTML <head>
      expect(googleFontsLink.contains('Crimson+Pro'), isTrue);
    });

    test('Font size classes should be included', () {
      const sizeCss = '''
    .ql-size-small { font-size: 0.75em; }
    .ql-size-large { font-size: 1.5em; }
    .ql-size-huge { font-size: 2.5em; }
''';

      expect(sizeCss.contains('.ql-size-small'), isTrue);
      expect(sizeCss.contains('.ql-size-large'), isTrue);
      expect(sizeCss.contains('.ql-size-huge'), isTrue);
      expect(sizeCss.contains('0.75em'), isTrue);
      expect(sizeCss.contains('1.5em'), isTrue);
      expect(sizeCss.contains('2.5em'), isTrue);
    });

    test('HTML with multiple fonts should render different font families', () {
      // Parse the HTML and verify structure
      final hasMultipleFontSpans =
          RegExp(r'ql-font-\w+').allMatches(sampleHtmlWithMultipleFonts).length;

      // Should have at least 5 different font applications
      expect(hasMultipleFontSpans, greaterThanOrEqualTo(5));
    });

    test('Font classes should not conflict with each other', () {
      // Each font class should be unique
      final fontClasses = [
        'ql-font-roboto',
        'ql-font-open-sans',
        'ql-font-lato',
        'ql-font-montserrat',
        'ql-font-source-code',
        'ql-font-crimson',
        'ql-font-dm-sans',
      ];

      // Verify all classes are unique
      expect(fontClasses.toSet().length, equals(fontClasses.length));
    });
  });

  group('Font Application Tests', () {
    test('Span elements should preserve font class on export', () {
      // When Quill applies a font to selected text, it wraps it in a span
      const inputHtml =
          '<p>Hello <span class="ql-font-roboto">World</span></p>';

      // The span with font class should be preserved
      expect(inputHtml.contains('<span class="ql-font-roboto">'), isTrue);
      expect(inputHtml.contains('World</span>'), isTrue);
    });

    test('Paragraph with font class should preserve on export', () {
      // When entire paragraph has a font
      const inputHtml = '<p class="ql-font-lato">Entire paragraph in Lato</p>';

      expect(inputHtml.contains('class="ql-font-lato"'), isTrue);
    });

    test('Nested formatting with fonts should be preserved', () {
      // Bold text with a specific font
      const inputHtml =
          '<p><strong><span class="ql-font-montserrat">Bold Montserrat</span></strong></p>';

      expect(inputHtml.contains('ql-font-montserrat'), isTrue);
      expect(inputHtml.contains('<strong>'), isTrue);
    });

    test('Multiple fonts in same paragraph should be preserved', () {
      const inputHtml = '''
<p><span class="ql-font-roboto">Roboto</span> normal <span class="ql-font-lato">Lato</span></p>
''';

      final robotoMatch = RegExp(r'ql-font-roboto').firstMatch(inputHtml);
      final latoMatch = RegExp(r'ql-font-lato').firstMatch(inputHtml);

      expect(robotoMatch, isNotNull);
      expect(latoMatch, isNotNull);

      // Roboto should appear before Lato in the HTML
      expect(robotoMatch!.start, lessThan(latoMatch!.start));
    });
  });

  group('Font Export Integration Tests', () {
    test('Full HTML document structure should be valid', () {
      const fullHtml = '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <link href="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Lato&display=swap" rel="stylesheet">
  <style>
    .ql-font-roboto { font-family: 'Roboto', sans-serif; }
    .ql-font-lato { font-family: 'Lato', sans-serif; }
  </style>
</head>
<body>
  <div class="ql-editor">
    <p><span class="ql-font-roboto">Hello</span> <span class="ql-font-lato">World</span></p>
  </div>
</body>
</html>
''';

      // Verify structure
      expect(fullHtml.contains('<!DOCTYPE html>'), isTrue);
      expect(fullHtml.contains('<html>'), isTrue);
      expect(fullHtml.contains('</html>'), isTrue);
      expect(fullHtml.contains('<head>'), isTrue);
      expect(fullHtml.contains('</head>'), isTrue);
      expect(fullHtml.contains('<body>'), isTrue);
      expect(fullHtml.contains('</body>'), isTrue);

      // Verify fonts are loaded
      expect(fullHtml.contains('fonts.googleapis.com'), isTrue);

      // Verify CSS definitions
      expect(fullHtml.contains('.ql-font-roboto'), isTrue);
      expect(fullHtml.contains('.ql-font-lato'), isTrue);

      // Verify content has font classes
      expect(fullHtml.contains('class="ql-font-roboto"'), isTrue);
      expect(fullHtml.contains('class="ql-font-lato"'), isTrue);
    });

    test('Exported HTML should be self-contained', () {
      // The exported HTML should work without any external dependencies
      // except for the CDN links (Google Fonts, Quill CSS)

      const requiredCdnLinks = [
        'cdn.jsdelivr.net/npm/quill',
        'fonts.googleapis.com',
      ];

      for (final link in requiredCdnLinks) {
        // These should be in the exported HTML
        expect(link.isNotEmpty, isTrue);
      }
    });
  });

  // ============================================
  // HTML Generation Tests
  // ============================================
  group('HTML Generation Tests', () {
    test('generateFullHtml should produce valid HTML document', () {
      const editorContent = '<p>Hello World</p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      // Check document structure
      expect(html.contains('<!DOCTYPE html>'), isTrue);
      expect(html.contains('<html>'), isTrue);
      expect(html.contains('</html>'), isTrue);
      expect(html.contains('<head>'), isTrue);
      expect(html.contains('</head>'), isTrue);
      expect(html.contains('<body>'), isTrue);
      expect(html.contains('</body>'), isTrue);
      expect(html.contains('<meta charset="UTF-8">'), isTrue);
    });

    test('generateFullHtml should include Quill CSS', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css'),
          isTrue);
    });

    test('generateFullHtml should include KaTeX CSS for formulas', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('cdn.jsdelivr.net/npm/katex'), isTrue);
    });

    test('generateFullHtml should include Google Fonts', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('fonts.googleapis.com'), isTrue);
      expect(html.contains('Crimson+Pro'), isTrue);
      expect(html.contains('DM+Sans'), isTrue);
      expect(html.contains('Roboto'), isTrue);
      expect(html.contains('Open+Sans'), isTrue);
      expect(html.contains('Lato'), isTrue);
      expect(html.contains('Montserrat'), isTrue);
      expect(html.contains('Source+Code+Pro'), isTrue);
    });

    test('generateFullHtml should include all font CSS classes', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final fontClass in HtmlExporter.supportedFonts) {
        expect(html.contains('.$fontClass'), isTrue,
            reason: 'Missing CSS class: $fontClass');
      }
    });

    test('generateFullHtml should include all size CSS classes', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      for (final sizeClass in HtmlExporter.supportedSizes) {
        expect(html.contains('.$sizeClass'), isTrue,
            reason: 'Missing CSS class: $sizeClass');
      }
    });

    test('generateFullHtml should preserve editor content with fonts', () {
      const editorContent = '''
<p><span class="ql-font-roboto">Roboto text</span></p>
<p><span class="ql-font-lato">Lato text</span></p>
<p><span class="ql-font-montserrat">Montserrat text</span></p>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      // Content should be embedded in .ql-editor div
      expect(html.contains('<div class="ql-editor">'), isTrue);
      expect(html.contains('ql-font-roboto'), isTrue);
      expect(html.contains('ql-font-lato'), isTrue);
      expect(html.contains('ql-font-montserrat'), isTrue);
      expect(html.contains('Roboto text'), isTrue);
      expect(html.contains('Lato text'), isTrue);
      expect(html.contains('Montserrat text'), isTrue);
    });

    test('generateFullHtml should preserve mixed font content', () {
      const editorContent =
          '<p><span class="ql-font-roboto">Hello</span> World <span class="ql-font-lato">!</span></p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      // Both font classes should be in content
      expect(html.contains('class="ql-font-roboto"'), isTrue);
      expect(html.contains('class="ql-font-lato"'), isTrue);

      // CSS definitions should also be present
      expect(html.contains(".ql-font-roboto { font-family: 'Roboto'"), isTrue);
      expect(html.contains(".ql-font-lato { font-family: 'Lato'"), isTrue);
    });

    test('generateFullHtml should preserve font sizes', () {
      const editorContent = '''
<p><span class="ql-size-small">Small</span></p>
<p><span class="ql-size-large">Large</span></p>
<p><span class="ql-size-huge">Huge</span></p>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('class="ql-size-small"'), isTrue);
      expect(html.contains('class="ql-size-large"'), isTrue);
      expect(html.contains('class="ql-size-huge"'), isTrue);
      expect(html.contains('.ql-size-small { font-size: 0.75em; }'), isTrue);
      expect(html.contains('.ql-size-large { font-size: 1.5em; }'), isTrue);
      expect(html.contains('.ql-size-huge { font-size: 2.5em; }'), isTrue);
    });

    test('generateFullHtml should preserve combined font and size', () {
      const editorContent =
          '<p><span class="ql-font-montserrat ql-size-large">Large Montserrat</span></p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('ql-font-montserrat'), isTrue);
      expect(html.contains('ql-size-large'), isTrue);
    });

    test('generateFullHtml should include header styles', () {
      final html = HtmlExporter.generateFullHtml('<h1>Title</h1>');

      expect(html.contains('.ql-editor h1'), isTrue);
      expect(html.contains('.ql-editor h2'), isTrue);
      expect(html.contains('.ql-editor h3'), isTrue);
    });

    test('generateFullHtml should include blockquote styles', () {
      final html =
          HtmlExporter.generateFullHtml('<blockquote>Quote</blockquote>');

      expect(html.contains('.ql-editor blockquote'), isTrue);
      expect(html.contains('border-left'), isTrue);
    });

    test('generateFullHtml should include table styles', () {
      final html = HtmlExporter.generateFullHtml(
          '<table><tr><td>Cell</td></tr></table>');

      expect(html.contains('.ql-editor table'), isTrue);
      expect(html.contains('border-collapse'), isTrue);
    });

    test('generateFullHtml should include RTL support', () {
      final html = HtmlExporter.generateFullHtml(
          '<p class="ql-direction-rtl">RTL text</p>');

      expect(html.contains('.ql-direction-rtl'), isTrue);
      expect(html.contains('direction: rtl'), isTrue);
    });

    test('generateFullHtml should include sub/sup styles', () {
      final html = HtmlExporter.generateFullHtml(
          '<p>H<sub>2</sub>O and x<sup>2</sup></p>');

      expect(html.contains('sub {'), isTrue);
      expect(html.contains('sup {'), isTrue);
      expect(html.contains('vertical-align: sub'), isTrue);
      expect(html.contains('vertical-align: super'), isTrue);
    });
  });

  group('HTML Generation Edge Cases', () {
    test('generateFullHtml should handle empty content', () {
      final html = HtmlExporter.generateFullHtml('');

      expect(html.contains('<div class="ql-editor"></div>'), isTrue);
      // CSS should still be present
      expect(html.contains('.ql-font-roboto'), isTrue);
    });

    test('generateFullHtml should handle content with special characters', () {
      const editorContent = '<p>Special: &amp; &lt; &gt; "quotes"</p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('&amp;'), isTrue);
      expect(html.contains('&lt;'), isTrue);
      expect(html.contains('&gt;'), isTrue);
    });

    test('generateFullHtml should handle nested formatting', () {
      const editorContent =
          '<p><strong><em><span class="ql-font-roboto">Bold Italic Roboto</span></em></strong></p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<strong>'), isTrue);
      expect(html.contains('<em>'), isTrue);
      expect(html.contains('ql-font-roboto'), isTrue);
    });

    test(
        'generateFullHtml should handle multiple paragraphs with different fonts',
        () {
      const editorContent = '''
<p class="ql-font-roboto">Paragraph 1 in Roboto</p>
<p class="ql-font-lato">Paragraph 2 in Lato</p>
<p class="ql-font-montserrat">Paragraph 3 in Montserrat</p>
<p class="ql-font-dm-sans">Paragraph 4 in DM Sans</p>
<p class="ql-font-crimson">Paragraph 5 in Crimson</p>
<p class="ql-font-source-code">Paragraph 6 in Source Code</p>
<p class="ql-font-open-sans">Paragraph 7 in Open Sans</p>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      // All 7 font classes should be in the content
      for (final fontClass in HtmlExporter.supportedFonts) {
        expect(html.contains('class="$fontClass"'), isTrue,
            reason: 'Content should contain: $fontClass');
      }

      // All 7 font CSS definitions should be present
      for (final fontClass in HtmlExporter.supportedFonts) {
        expect(html.contains('.$fontClass {'), isTrue,
            reason: 'CSS should define: $fontClass');
      }
    });

    test('generateFullHtml should handle images', () {
      const editorContent = '<p><img src="data:image/png;base64,abc123"></p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<img'), isTrue);
      expect(html.contains('.ql-editor img { max-width: 100%'), isTrue);
    });

    test('generateFullHtml should handle video/iframe', () {
      const editorContent =
          '<p><iframe src="https://www.youtube.com/embed/test"></iframe></p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<iframe'), isTrue);
      expect(html.contains('.ql-editor iframe'), isTrue);
    });

    test('generateFullHtml should handle links', () {
      const editorContent = '<p><a href="https://example.com">Link</a></p>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<a href="https://example.com">'), isTrue);
      expect(html.contains('.ql-editor a {'), isTrue);
    });

    test('generateFullHtml should handle lists', () {
      const editorContent = '''
<ul><li>Item 1</li><li>Item 2</li></ul>
<ol><li>First</li><li>Second</li></ol>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<ul>'), isTrue);
      expect(html.contains('<ol>'), isTrue);
      expect(html.contains('<li>'), isTrue);
      expect(html.contains('.ql-editor ul'), isTrue);
      expect(html.contains('.ql-editor ol'), isTrue);
    });

    test('generateFullHtml should handle code blocks', () {
      const editorContent = '<pre>const x = 1;</pre>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<pre>'), isTrue);
      expect(html.contains('.ql-editor pre {'), isTrue);
    });
  });

  group('Table Export Tests', () {
    test('generateFullHtml should include quill-table-better CSS link', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('quill-table-better@1/dist/quill-table-better.css'),
          isTrue);
    });

    test('generateFullHtml should include table border-collapse', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('border-collapse: collapse'), isTrue);
    });

    test('generateFullHtml should include table-layout fixed', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('table-layout: fixed'), isTrue);
    });

    test('generateFullHtml should include table cell styles', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('.ql-editor table td'), isTrue);
      expect(html.contains('.ql-editor table th'), isTrue);
      expect(html.contains('padding: 8px 12px'), isTrue);
      expect(html.contains('min-width: 50px'), isTrue);
    });

    test('generateFullHtml should include table header row styles', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(
          html.contains('.ql-editor table.table-with-header tr:first-child td'),
          isTrue);
      expect(html.contains('background: #f8f8f8'), isTrue);
      expect(html.contains('font-weight: 600'), isTrue);
    });

    test('generateFullHtml should include merged cell styles', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('td[rowspan]'), isTrue);
      expect(html.contains('td[colspan]'), isTrue);
      expect(html.contains('vertical-align: middle'), isTrue);
    });

    test('generateFullHtml should include ql-table-wrapper styles', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      expect(html.contains('.ql-table-wrapper'), isTrue);
      expect(html.contains('overflow-x: auto'), isTrue);
    });

    test('generateFullHtml should preserve table content', () {
      const editorContent = '''
<table>
  <tbody>
    <tr><td>Header 1</td><td>Header 2</td><td>Header 3</td></tr>
    <tr><td>Cell 1</td><td>Cell 2</td><td>Cell 3</td></tr>
    <tr><td>Cell 4</td><td>Cell 5</td><td>Cell 6</td></tr>
  </tbody>
</table>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<table>'), isTrue);
      expect(html.contains('<tbody>'), isTrue);
      expect(html.contains('<tr>'), isTrue);
      expect(html.contains('<td>'), isTrue);
      expect(html.contains('Header 1'), isTrue);
      expect(html.contains('Cell 1'), isTrue);
    });

    test('generateFullHtml should preserve merged cells', () {
      const editorContent = '''
<table>
  <tbody>
    <tr><td colspan="2">Merged Header</td><td>Header 3</td></tr>
    <tr><td rowspan="2">Merged Row</td><td>Cell 2</td><td>Cell 3</td></tr>
    <tr><td>Cell 5</td><td>Cell 6</td></tr>
  </tbody>
</table>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('colspan="2"'), isTrue);
      expect(html.contains('rowspan="2"'), isTrue);
      expect(html.contains('Merged Header'), isTrue);
      expect(html.contains('Merged Row'), isTrue);
    });

    test('generateFullHtml should handle table with text formatting', () {
      const editorContent = '''
<table>
  <tbody>
    <tr><td><strong>Bold Header</strong></td><td><em>Italic Header</em></td></tr>
    <tr><td><span class="ql-font-roboto">Roboto Cell</span></td><td>Normal</td></tr>
  </tbody>
</table>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<strong>Bold Header</strong>'), isTrue);
      expect(html.contains('<em>Italic Header</em>'), isTrue);
      expect(html.contains('ql-font-roboto'), isTrue);
    });

    test('generateFullHtml should handle ql-table class', () {
      const editorContent =
          '<table class="ql-table"><tbody><tr><td>Cell</td></tr></tbody></table>';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('class="ql-table"'), isTrue);
      expect(html.contains('.ql-editor .ql-table'), isTrue);
    });

    test('generateFullHtml should handle table with nested paragraphs', () {
      const editorContent = '''
<table>
  <tbody>
    <tr><td><p>Paragraph 1</p><p>Paragraph 2</p></td></tr>
  </tbody>
</table>
''';
      final html = HtmlExporter.generateFullHtml(editorContent);

      expect(html.contains('<p>Paragraph 1</p>'), isTrue);
      expect(html.contains('<p>Paragraph 2</p>'), isTrue);
      // Should have style to remove paragraph margins in cells
      expect(html.contains('.ql-editor table td p { margin: 0; }'), isTrue);
    });
  });

  group('Font Class Consistency Tests', () {
    test('All font classes should have corresponding CSS', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      final fontFamilyMap = {
        'ql-font-roboto': 'Roboto',
        'ql-font-open-sans': 'Open Sans',
        'ql-font-lato': 'Lato',
        'ql-font-montserrat': 'Montserrat',
        'ql-font-source-code': 'Source Code Pro',
        'ql-font-crimson': 'Crimson Pro',
        'ql-font-dm-sans': 'DM Sans',
      };

      for (final entry in fontFamilyMap.entries) {
        expect(html.contains('.${entry.key}'), isTrue,
            reason: 'Missing CSS class: ${entry.key}');
        expect(html.contains("font-family: '${entry.value}'"), isTrue,
            reason: 'Missing font-family for: ${entry.key}');
      }
    });

    test('All fonts should be loaded from Google Fonts', () {
      final html = HtmlExporter.generateFullHtml('<p>Test</p>');

      final googleFontNames = [
        'Crimson+Pro',
        'DM+Sans',
        'Roboto',
        'Open+Sans',
        'Lato',
        'Montserrat',
        'Source+Code+Pro',
      ];

      for (final fontName in googleFontNames) {
        expect(html.contains(fontName), isTrue,
            reason: 'Google Fonts should include: $fontName');
      }
    });
  });
}
