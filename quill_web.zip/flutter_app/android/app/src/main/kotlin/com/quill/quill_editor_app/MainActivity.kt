package com.quill.quill_editor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
