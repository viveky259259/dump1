# Quill Architecture Documentation

## 1. Overall Architecture

Quill is a modern rich text editor built with a modular architecture. Its core components work together to manage the document state, render it to the DOM, and handle user interactions.

### Core Components

*   **Quill**: The main entry point and controller class. It initializes the editor, manages the selection, and coordinates interactions between modules.
*   **Parchment**: The document model abstraction layer. It provides a tree structure of "Blots" that mirrors the DOM. Parchment allows Quill to work with a custom object model rather than raw DOM nodes, enabling structured document manipulation.
*   **Blots**: The building blocks of a Parchment document.
    *   **Scroll**: The root blot of the document.
    *   **Block**: Represents block-level elements (paragraphs, headers, lists).
    *   **Inline**: Represents inline formatting (bold, italic, links).
    *   **Embed**: Represents non-text content (images, videos, formulas).
*   **Delta**: A JSON-based data format used to represent the document content and changes. Deltas describe operations (insert, delete, retain) and attributes, making the document model simple, portable, and suitable for operational transformation (OT).
*   **Editor**: Manages the synchronization between the Delta representation and the Parchment/DOM structure. It handles applying Deltas to the document and converting DOM changes back to Deltas.
*   **Selection**: Manages the user's cursor position and selection range. It normalizes browser inconsistencies in selection handling.
*   **Emitter**: An event bus that handles communication between components. It emits events like `text-change`, `selection-change`, and `editor-change`.

### Data Flow

1.  **User Action**: The user types or interacts with the editor.
2.  **DOM Mutation**: The browser updates the DOM.
3.  **Mutation Observer**: Quill observes DOM changes.
4.  **Parchment Update**: Changes are reconciled with the Parchment blot tree.
5.  **Delta Generation**: A Delta describing the change is generated.
6.  **Event Emission**: A `text-change` event is emitted with the Delta.

Alternatively, via API:
1.  **API Call**: e.g., `quill.updateContents(delta)`.
2.  **Delta Application**: The Editor applies the Delta to the Parchment tree.
3.  **DOM Update**: Parchment updates the DOM to reflect the changes.

## 2. Plugin System

Quill uses a flexible plugin system based on **Modules**. Modules are classes that extend the functionality of the editor.

### Module Structure

*   **Base Class**: All modules typically extend the `Module` class (found in `core/module.ts`).
*   **Registration**: Modules must be registered with `Quill.register` before use.
*   **Initialization**: Modules are instantiated when Quill is initialized. The `constructor` receives the `Quill` instance and an options object.

### Common Modules

*   **Toolbar**: Manages the UI toolbar for formatting.
*   **Keyboard**: Handles key bindings and shortcuts.
*   **Clipboard**: Handles copy, cut, and paste operations, including HTML sanitization.
*   **History**: Manages undo and redo stacks.

### Usage

Modules are configured in the `modules` object passed to the Quill constructor:

```javascript
const quill = new Quill('#editor', {
  modules: {
    toolbar: true, // Enable default toolbar
    myCustomModule: {
      option1: 'value'
    }
  }
});
```

## 3. How to Add Features

Features in Quill are primarily added by creating custom **Blots** (for content types) or **Modules** (for functionality).

### Adding New Content Types (Formats)

To add a new format (e.g., a custom tag or style):

1.  **Define a Blot**: Create a class that extends `Block`, `Inline`, or `Embed` (from `Quill.import('parchment')`).
2.  **Specify Static Properties**:
    *   `blotName`: The name used in Deltas (e.g., 'bold').
    *   `tagName`: The HTML tag associated with the format (e.g., 'STRONG').
    *   `className`: (Optional) A CSS class for the format.
3.  **Implement Lifecycle Methods**:
    *   `create(value)`: Creates the DOM node.
    *   `formats(domNode)`: Extracts the format value from the DOM.
4.  **Register**: Use `Quill.register(NewBlot)`.

**Example (Custom Bold):**

```javascript
const Inline = Quill.import('blots/inline');

class CustomBold extends Inline {
  static blotName = 'custom-bold';
  static tagName = 'b';
}

Quill.register(CustomBold);
```

### Adding New Functionality (Modules)

1.  **Create a Module Class**:
    ```javascript
    class Counter {
      constructor(quill, options) {
        this.quill = quill;
        this.options = options;
        // Listen to events or modify editor behavior
        this.quill.on('text-change', this.updateCount.bind(this));
      }

      updateCount() {
        // ... logic
      }
    }
    ```
2.  **Register the Module**:
    ```javascript
    Quill.register('modules/counter', Counter);
    ```
3.  **Enable in Options**:
    ```javascript
    new Quill('#editor', {
      modules: {
        counter: true
      }
    });
    ```

### Adding External Plugins (e.g., quill-table-better)

Many enhanced features are available as community plugins. Here is how to add a complex plugin like `quill-table-better`.

1.  **Install the Plugin**:
    ```bash
    npm install quill-table-better
    ```

2.  **Import and Register**:
    You must register the module with Quill. If using a module bundler (Webpack/Rollup):
    ```javascript
    import Quill from 'quill';
    import QuillTableBetter from 'quill-table-better';
    import 'quill-table-better/dist/quill-table-better.css'; // Import plugin styles

    Quill.register({
      'modules/table-better': QuillTableBetter
    }, true);
    ```

3.  **Configure in Quill Options**:
    Add the module to your Quill configuration. You often need to disable conflicting default modules (like the default `table`).

    ```javascript
    const quill = new Quill('#editor', {
      theme: 'snow',
      modules: {
        table: false, // Disable default table module
        'table-better': {
          language: 'en_US',
          menus: ['column', 'row', 'merge', 'table', 'cell', 'wrap', 'copy', 'delete'],
          toolbarTable: true
        },
        keyboard: {
          bindings: QuillTableBetter.keyboardBindings // Register plugin keybindings
        },
        toolbar: [
          ['bold', 'italic', 'underline', 'strike'],
          ['table-better'] // Add plugin button to toolbar
        ]
      }
    });
    ```

## 5. Custom Table Features

### Table Header Toggle

Tables support a toggleable header row styling feature. This is implemented as a custom enhancement on top of `quill-table-better`.

**How it works:**
- Tables can have a `.table-with-header` CSS class that styles the first row as a header
- Default: No header styling (all cells look the same)
- When enabled: First row gets background color and bold text

**User Interaction:**
1. **Right-click on table** → Shows popup with "Mark first row as header" checkbox
2. **Keyboard shortcut**: `Ctrl/Cmd + Shift + H` when cursor is in table

**Implementation:**
```javascript
// Toggle header class on table
function toggleTableHeader(table, hasHeader) {
  if (hasHeader) {
    table.classList.add('table-with-header');
  } else {
    table.classList.remove('table-with-header');
  }
}

// CSS for header styling (only applied when class present)
.ql-editor table.table-with-header tr:first-child td {
  background: #f8f6f3;
  font-weight: 500;
}
```

### Preview Mode Selection Handling

When displaying table content in preview mode (viewer, HTML preview dialog, or exported HTML), selection colors must be hidden. The editor applies selection classes and inline styles that should not appear in read-only contexts.

**Problem:**
- `quill-table-better` adds selection classes like `ql-cell-selected`, `selected`
- Inline background styles are applied to selected cells
- These persist in the HTML and show in preview

**Solution:**
1. **JavaScript Cleaning**: Strip selection classes and inline styles from HTML before display
2. **Aggressive CSS Overrides**: Reset cell backgrounds and hide selection elements

```javascript
// Clean HTML by removing selection classes
function cleanHtmlForPreview(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  
  // Remove selection classes
  doc.querySelectorAll('*').forEach(el => {
    ['selected', 'ql-cell-selected', 'ql-table-selected'].forEach(cls => {
      el.classList.remove(cls);
    });
    
    // Remove inline background from cells (selection colors)
    if (el.tagName === 'TD') {
      el.style.removeProperty('background-color');
    }
  });
  
  return doc.body.innerHTML;
}
```

**CSS Overrides for Preview:**
```css
/* Reset all cell backgrounds */
.ql-editor table td { background-color: transparent !important; }

/* Only apply header if explicitly set */
.ql-editor table.table-with-header tr:first-child td { 
  background-color: #f8f6f3 !important; 
}

/* Hide quill-table-better selection elements */
.ql-table-better-selected-td,
[class*="ql-table-better-select"],
[class*="ql-table-better-tool"] {
  display: none !important;
}
```

## 4. How HTML and CSS Works

Quill does not treat HTML as a blob string. Instead, it maintains a strict mapping between its internal Delta format and the DOM via Parchment.

### Parchment & DOM Mapping

*   **Tags**: Blots define which HTML tags they represent via `tagName`. When a Delta insert has an attribute (e.g., `{ bold: true }`), Quill looks up the blot for 'bold' and wraps the text in its `tagName` (e.g., `<strong>`).
*   **Attributes**: Parchment supports **Attributors**, which map Delta attributes to either:
    *   **Classes**: `ClassAttributor` maps values to CSS class names (e.g., `{ align: 'center' }` -> class `ql-align-center`).
    *   **Inline Styles**: `StyleAttributor` maps values to inline CSS styles (e.g., `{ color: 'red' }` -> style `color: red`).

### CSS Handling

*   **Themes**: Quill comes with themes (Snow, Bubble) that provide base CSS.
*   **Classes vs. Styles**:
    *   By default, many formats use classes (e.g., `ql-size-large`). This requires a corresponding stylesheet to define what `.ql-size-large` looks like.
    *   You can configure Quill to use inline styles instead for certain attributes (like `align`, `color`, `font`, `size`) by registering the `StyleAttributor` version instead of the `ClassAttributor` version.

### Rendering

When `quill.root.innerHTML` is requested:
1.  Quill traverses the Parchment blot tree.
2.  Each blot renders its DOM node.
3.  The resulting DOM tree forms the HTML output.

When pasting HTML:
1.  The **Clipboard** module processes the HTML.
2.  It uses "Matchers" to find corresponding Blots for the HTML tags/styles.
3.  It converts the HTML into a Delta.
4.  The Delta is inserted into the document.
