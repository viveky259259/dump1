# Quill Editor Architecture Diagrams

## 1. Quill Editor Internal Architecture

This diagram illustrates the internal components of the Quill editor, how they interact, and how plugins and features fit into the system.

```mermaid
graph TD
    subgraph Core ["Quill Core"]
        Quill["Quill (Controller)"]
        Editor["Editor (Sync Manager)"]
        Selection["Selection Manager"]
        Emitter["Emitter (Event Bus)"]
        
        Quill --> Editor
        Quill --> Selection
        Quill --> Emitter
        Editor --> Emitter
        Selection --> Emitter
    end

    subgraph DataModel ["Data Model (Parchment & Delta)"]
        Parchment["Parchment (DOM Abstraction)"]
        Delta["Delta (JSON Content)"]
        Scroll["Scroll (Root Blot)"]
        Blots["Blots (Block, Inline, Embed)"]
        
        Editor <--> Parchment
        Editor <--> Delta
        Parchment --> Scroll
        Scroll --> Blots
    end

    subgraph Modules ["Built-in Modules"]
        Toolbar["Toolbar"]
        Keyboard["Keyboard"]
        Clipboard["Clipboard"]
        History["History"]
        Uploader["Uploader"]
        
        Quill --> Modules
        Toolbar --> Quill
        Keyboard --> Quill
        Clipboard --> Quill
        History --> Quill
        Uploader --> Quill
    end

    subgraph Plugins ["External Plugins"]
        TableBetter["quill-table-better"]
        Mention["quill-mention"]
        Katex["Formula (KaTeX)"]
        
        Quill -.-> Plugins
        TableBetter --> Modules
    end

    subgraph Features ["Formats & Features"]
        BlockFormats["Block Formats (Header, List, etc.)"]
        InlineFormats["Inline Formats (Bold, Italic, Color)"]
        Embeds["Embeds (Image, Video, Formula)"]
        Attributors["Attributors (Class/Style)"]
        
        Blots --> BlockFormats
        Blots --> InlineFormats
        Blots --> Embeds
        Parchment --> Attributors
    end

    DOM["DOM (Browser)"]
    User["User Input"]

    User --> DOM
    DOM <--> Parchment
    Parchment --> DOM
```

### Key Components:
- **Quill Core**: The central controller managing the editor lifecycle and events.
- **Parchment**: Abstraction layer over the DOM, organizing content into a tree of "Blots".
- **Delta**: Simple JSON-based representation of the document content and changes.
- **Modules**: Functional extensions like Toolbar, History, and Clipboard handling.
- **Plugins**: Third-party modules that extend functionality (e.g., Tables).

---

## 2. Flutter Integration Architecture

This diagram shows how the Quill editor (running in a Web context) is embedded and integrated within the Flutter application using `HtmlElementView` and `postMessage` communication.

```mermaid
sequenceDiagram
    participant FlutterApp as "Flutter App (QuillEditor Widget)"
    participant IFrame as "IFrame (HtmlElementView)"
    participant WebPage as "quill_editor.html (JS Context)"
    participant QuillInstance as "Quill Instance"

    Note over FlutterApp, IFrame: Initialization
    FlutterApp->>IFrame: Create IFrameElement
    IFrame->>WebPage: Load quill_editor.html
    WebPage->>QuillInstance: Initialize Quill (new Quill(...))
    WebPage-->>FlutterApp: postMessage({type: 'ready'})

    Note over FlutterApp, QuillInstance: Command Flow (Flutter -> Web)
    FlutterApp->>IFrame: _sendCommand({action: 'insertText', text: 'Hello'})
    IFrame->>WebPage: window.postMessage(JSON)
    WebPage->>WebPage: Handle 'command' message
    WebPage->>QuillInstance: quill.insertText(...)

    Note over QuillInstance, FlutterApp: Event Flow (Web -> Flutter)
    User->>QuillInstance: Types text
    QuillInstance->>WebPage: 'text-change' event
    WebPage->>FlutterApp: window.parent.postMessage({type: 'contentChange', ...})
    FlutterApp->>FlutterApp: _handleMessage() -> onContentChanged callback
```

### Integration Details:

```mermaid
graph LR
    subgraph Flutter ["Flutter Application"]
        Widget["QuillEditor Widget"]
        State["QuillEditorState"]
        Reg["PlatformViewRegistry"]
        
        Widget --> State
        State --> Reg
    end

    subgraph Bridge ["Communication Bridge"]
        FM["Flutter -> Web (postMessage)"]
        WM["Web -> Flutter (postMessage)"]
    end

    subgraph Web ["Web Environment (IFrame)"]
        HTML["quill_editor.html"]
        JS["Script Logic"]
        QLib["Quill Library"]
        DOM_Web["Editor DOM"]
        
        HTML --> JS
        JS --> QLib
        QLib --> DOM_Web
    end

    State --> FM
    FM --> JS
    JS --> WM
    WM --> State
    
    Reg -.-> HTML : "Renders via IFrame"
```

### Communication Protocol:

1.  **Flutter to Web**:
    *   **Mechanism**: `_iframe.contentWindow.postMessage(jsonString, '*')`
    *   **Payload**: `{ source: 'flutter', type: 'command', action: 'ACTION_NAME', ...args }`
    *   **Actions**: `setContents`, `setHTML`, `insertText`, `insertHtml`, `getContents`, `clear`, `focus`, `setZoom`.

2.  **Web to Flutter**:
    *   **Mechanism**: `window.parent.postMessage(jsonString, '*')`
    *   **Payload**: `{ source: 'quill-editor', type: 'EVENT_TYPE', ...data }`
    *   **Events**: `ready`, `contentChange`, `zoomChange`, `response`.

---

## 3. Table Features Architecture

This diagram shows the table header toggle and preview mode selection handling architecture.

```mermaid
graph TD
    subgraph Editor ["Editor Mode (quill_editor.html)"]
        Table["Table Element"]
        ContextMenu["Right-Click Context Menu"]
        KeyboardShortcut["Ctrl/Cmd + Shift + H"]
        HeaderToggle["toggleTableHeader()"]
        HeaderClass[".table-with-header CSS Class"]
        
        Table --> ContextMenu
        Table --> KeyboardShortcut
        ContextMenu --> HeaderToggle
        KeyboardShortcut --> HeaderToggle
        HeaderToggle --> HeaderClass
        HeaderClass --> Table
    end
    
    subgraph Selection ["Selection State"]
        CellSelect["Cell Selection"]
        TableBetterCSS["quill-table-better Styles"]
        InlineStyles["Inline Background Styles"]
        SelectClasses["Selection Classes"]
        
        CellSelect --> TableBetterCSS
        TableBetterCSS --> InlineStyles
        TableBetterCSS --> SelectClasses
    end
    
    subgraph Preview ["Preview Mode"]
        Viewer["quill_viewer.html"]
        InlinePreview["_HtmlPreviewWidget"]
        ExportedHTML["Downloaded HTML"]
        
        CleanFunction["cleanHtmlForPreview()"]
        CSSOverrides["CSS Overrides"]
        
        CleanFunction --> Viewer
        CleanFunction --> InlinePreview
        CSSOverrides --> Viewer
        CSSOverrides --> InlinePreview
        CSSOverrides --> ExportedHTML
    end
    
    Table -->|HTML Content| CleanFunction
    SelectClasses -->|Stripped| CleanFunction
    InlineStyles -->|Removed| CleanFunction
```

### Table Header Toggle Flow:

```mermaid
sequenceDiagram
    participant User
    participant Table as "Table Element"
    participant ContextMenu as "Context Menu Popup"
    participant CSS as "CSS Styling"
    participant Flutter as "Flutter (contentChange)"

    User->>Table: Right-click on table
    Table->>ContextMenu: Show popup with checkbox
    User->>ContextMenu: Toggle "Mark first row as header"
    ContextMenu->>Table: Add/Remove .table-with-header class
    Table->>CSS: Apply header styling (if class present)
    Table->>Flutter: postMessage({type: 'contentChange', ...})
```

### Preview Selection Cleaning Flow:

```mermaid
sequenceDiagram
    participant Editor as "Quill Editor"
    participant HTML as "Raw HTML (with selections)"
    participant Cleaner as "cleanHtmlForPreview()"
    participant Preview as "Preview/Viewer"

    Editor->>HTML: Get innerHTML (may have selection classes)
    HTML->>Cleaner: Pass to cleaning function
    
    Note over Cleaner: Strip selection classes
    Note over Cleaner: Remove inline bg styles
    Note over Cleaner: Remove tool elements
    
    Cleaner->>Preview: Clean HTML
    Preview->>Preview: Apply CSS overrides
    
    Note over Preview: Cells show transparent bg
    Note over Preview: Header shows only if .table-with-header
```

### Key CSS Classes:

| Class | Purpose | Context |
|-------|---------|---------|
| `.table-with-header` | Marks table to show header styling | Editor & Preview |
| `.ql-cell-selected` | Selected cell (from quill-table-better) | Editor only |
| `.selected` | Generic selection class | Editor only |
| `.ql-table-better-*-tool` | Table manipulation UI elements | Editor only (hidden in preview) |

### Implementation Files:

| Feature | File | Description |
|---------|------|-------------|
| Header Toggle UI | `quill_editor.html` | Context menu and keyboard handler |
| Header CSS | `quill_editor.html`, `quill_viewer.html`, `home_page.dart` | Conditional `.table-with-header` styling |
| Selection Cleaning JS | `quill_viewer.html`, `home_page.dart` | `cleanHtmlForPreview()` function |
| CSS Overrides | All viewer/preview files | Aggressive reset of selection styles |

