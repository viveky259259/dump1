## Problem Overview

When using Quill 2.0, bullet lists may exhibit two common issues:

### Issue 1: Double Bullets
Two bullets appear for each list item - one from Quill's pseudo-element and one from native CSS.


### Issue 2: Bullets Positioned at Container Edge
Bullets appear at the far left edge of the container instead of inline with the content.


---

## Root Cause Analysis

### How Quill 2.0 Renders Lists

Quill 2.0 uses a **pseudo-element approach** for rendering bullets and numbers:

```html
<!-- Quill 2.0 list structure -->
<ol>
  <li data-list="ordered">
    <span class="ql-ui" contenteditable="false"></span>
    First item
  </li>
  <li data-list="ordered">
    <span class="ql-ui" contenteditable="false"></span>
    Second item
  </li>
</ol>
```

The `.ql-ui` element uses `::before` pseudo-element to display bullets/numbers:

```css
/* Quill's internal CSS */
.ql-editor li[data-list="bullet"] > .ql-ui::before {
  content: '\2022'; /* Bullet character • */
}

.ql-editor li[data-list="ordered"] > .ql-ui::before {
  content: counter(list-0, decimal) '. ';
}
```

### What Causes Double Bullets

When custom CSS adds native list styling, you get two bullets:

```css
/* ❌ WRONG - This causes double bullets */
.ql-editor ul li {
  list-style-type: disc;  /* Native bullet */
}
```

**Result**: Native `disc` bullet + Quill's `::before` pseudo-element bullet = 2 bullets

### What Causes Edge-Aligned Bullets

When custom CSS uses absolute positioning for the `.ql-ui` element:

```css
/* ❌ WRONG - This positions bullets at container edge */
.ql-editor li {
  position: relative;
}

.ql-editor li > .ql-ui {
  position: absolute;
  left: -1.5em;  /* Positions relative to li, but li has no left offset */
}
```

**Result**: The bullet is positioned `-1.5em` from the `li` element, but if the `li` itself starts at the container edge, the bullet ends up at the far left instead of next to the content.

---

## The Solution

### Principle: Let Quill Handle List Rendering

The key insight is that **Quill 2.0 already handles bullet/number rendering correctly**. We just need to:

1. **NOT** override native list styles
2. **NOT** use absolute positioning for `.ql-ui`
3. Only adjust padding/margins for layout

### ✅ Correct CSS

```css
/* List Styling Fix for Quill 2.0 */
/* Let Quill's default list styling work - just minor adjustments */

.ql-editor ol,
.ql-editor ul {
  padding-left: 0;      /* Remove default padding */
  margin: 0 0 1em 0;    /* Add bottom margin for spacing */
}

.ql-editor li {
  padding-left: 1.5em;  /* Indent content, bullet stays in this space */
  margin-bottom: 0.25em;
}

/* Nested list indentation - add to base padding */
.ql-editor li.ql-indent-1 { padding-left: 3em; }
.ql-editor li.ql-indent-2 { padding-left: 4.5em; }
.ql-editor li.ql-indent-3 { padding-left: 6em; }
.ql-editor li.ql-indent-4 { padding-left: 7.5em; }
.ql-editor li.ql-indent-5 { padding-left: 9em; }
.ql-editor li.ql-indent-6 { padding-left: 10.5em; }
.ql-editor li.ql-indent-7 { padding-left: 12em; }
.ql-editor li.ql-indent-8 { padding-left: 13.5em; }

/* Checklist styling (optional customization) */
.ql-editor li[data-list="checked"] > .ql-ui::before {
  content: '☑';
  color: #28a745;
}

.ql-editor li[data-list="unchecked"] > .ql-ui::before {
  content: '☐';
  color: #6c757d;
}
```

### ❌ Incorrect CSS (Don't Do This)

```css
/* DON'T: Add native list styles */
.ql-editor ul {
  list-style: disc;           /* Causes double bullets */
}

.ql-editor ol {
  list-style: decimal;        /* Causes double numbers */
}

.ql-editor ul li {
  list-style-type: disc;      /* Causes double bullets */
}

/* DON'T: Use absolute positioning for .ql-ui */
.ql-editor li {
  position: relative;
}

.ql-editor li > .ql-ui {
  position: absolute;
  left: -1.5em;               /* Positions at container edge */
  width: 1.5em;
  text-align: right;
}

/* DON'T: Override bullet content */
.ql-editor li[data-list="bullet"] > .ql-ui::before {
  content: '•';               /* Redundant - Quill already does this */
  font-size: 1.2em;
}

/* DON'T: Add counter logic for ordered lists */
.ql-editor ol {
  counter-reset: list-0;      /* Redundant - Quill already handles this */
}
.ql-editor ol li[data-list="ordered"] {
  counter-increment: list-0;
}
.ql-editor li[data-list="ordered"] > .ql-ui::before {
  content: counter(list-0, decimal) '.';  /* Redundant */
}
```

---

## How Quill's List System Works

### The `.ql-ui` Element

Quill injects a `<span class="ql-ui">` inside each `<li>`:

```html
<li data-list="bullet">
  <span class="ql-ui" contenteditable="false"></span>
  Your list item text here
</li>
```

### Quill's Internal CSS for Lists

Quill's `quill.snow.css` includes:

```css
/* Bullet list */
.ql-editor li[data-list=bullet] > .ql-ui:before {
  content: '\2022';  /* • character */
}

/* Ordered list with counters */
.ql-editor li[data-list=ordered] {
  counter-increment: list-0;
}
.ql-editor li[data-list=ordered] > .ql-ui:before {
  content: counter(list-0, decimal) '. ';
}

/* Nested list styles */
.ql-editor li.ql-indent-1[data-list=ordered] {
  counter-increment: list-1;
}
.ql-editor li.ql-indent-1[data-list=ordered] > .ql-ui:before {
  content: counter(list-1, lower-alpha) '. ';
}
/* ... and so on for deeper nesting */
```

### The `data-list` Attribute

Quill uses the `data-list` attribute to identify list types:

| Value | List Type |
|-------|-----------|
| `bullet` | Unordered (bullet) list |
| `ordered` | Ordered (numbered) list |
| `checked` | Checked checkbox list |
| `unchecked` | Unchecked checkbox list |

---

## Debugging List Issues

### Step 1: Inspect the DOM

Open browser DevTools and inspect a list item:

```html
<!-- Expected structure -->
<li data-list="bullet">
  <span class="ql-ui" contenteditable="false"></span>
  Text content
</li>
```

### Step 2: Check Computed Styles

Select the `<li>` element and check:

| Property | Expected Value |
|----------|----------------|
| `list-style-type` | `none` (inherited or explicit) |
| `position` | `static` (not `relative`) |

Select the `.ql-ui` element and check:

| Property | Expected Value |
|----------|----------------|
| `position` | Not `absolute` |
| `::before content` | Should show bullet/number |

### Step 3: Look for Conflicting CSS

Search your CSS for these problematic patterns:

```bash
# In your CSS file, search for:
grep -E "list-style|list-style-type" your-styles.css
grep -E "\.ql-ui.*position.*absolute" your-styles.css
grep -E "content.*counter\(list" your-styles.css
```

### Step 4: Check CSS Load Order

Ensure your styles load AFTER Quill's CSS:

```html
<!-- 1. Quill CSS first -->
<link href="quill.snow.css" rel="stylesheet">

<!-- 2. Plugin CSS -->
<link href="quill-table-better.css" rel="stylesheet">

<!-- 3. Your custom CSS LAST -->
<style>
  /* Your overrides here */
</style>
```

---

## Complete Working Example

```html
<!DOCTYPE html>
<html>
<head>
  <!-- 1. Load Quill CSS -->
  <link href="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.snow.css" rel="stylesheet">
  
  <style>
    /* 2. Custom styles - minimal list adjustments only */
    .ql-editor ol,
    .ql-editor ul {
      padding-left: 0;
      margin: 0 0 1em 0;
    }

    .ql-editor li {
      padding-left: 1.5em;
      margin-bottom: 0.25em;
    }

    /* Nested indentation */
    .ql-editor li.ql-indent-1 { padding-left: 3em; }
    .ql-editor li.ql-indent-2 { padding-left: 4.5em; }
    .ql-editor li.ql-indent-3 { padding-left: 6em; }
  </style>
</head>
<body>
  <div id="editor">
    <ul>
      <li>First bullet item</li>
      <li>Second bullet item</li>
    </ul>
    <ol>
      <li>First numbered item</li>
      <li>Second numbered item</li>
    </ol>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/quill@2/dist/quill.js"></script>
  <script>
    const quill = new Quill('#editor', {
      theme: 'snow',
      modules: {
        toolbar: [
          [{ 'list': 'ordered' }, { 'list': 'bullet' }]
        ]
      }
    });
  </script>
</body>
</html>
```

---

## Summary

| Issue | Cause | Fix |
|-------|-------|-----|
| Double bullets | `list-style-type: disc` on `li` | Remove it, let Quill use `.ql-ui::before` |
| Edge-aligned bullets | `position: absolute` on `.ql-ui` | Remove it, use `padding-left` on `li` |
| Missing bullets | Missing Quill CSS | Ensure `quill.snow.css` loads first |
| Wrong bullet style | Custom `::before` content | Remove it, Quill handles this |
| Broken numbering | Custom counter CSS | Remove it, Quill handles this |

### Golden Rule

> **Don't try to style list bullets/numbers yourself. Quill 2.0 handles it via the `.ql-ui::before` pseudo-element. Just adjust padding and margins for layout.**

---

## Related Files Modified

During this fix, the following files were updated:

1. **`/icici_uta_1/web/test_quill.html`** - Editor CSS
2. **`/icici_uta_1/web/delta_render.html`** - Viewer CSS

Both files had their list CSS simplified to the correct minimal approach shown above.

---

*Last updated: December 2024*


