import type { LinkedList } from 'parchment';
import { EmbedBlot } from 'parchment';
import Block from '../blots/block.js';
import Break from '../blots/break.js';
import Container from '../blots/container.js';
import Inline from '../blots/inline.js';
import TextBlot from '../blots/text.js';

class TableCell extends Block {
  static blotName = 'table';
  static tagName = 'TD';

  static create(value: string) {
    const node = super.create() as HTMLElement;
    if (value) {
      node.setAttribute('data-row', value);
    } else {
      node.setAttribute('data-row', tableId());
    }
    return node;
  }

  static formats(domNode: HTMLElement) {
    if (domNode.hasAttribute('data-row')) {
      return domNode.getAttribute('data-row');
    }
    return undefined;
  }

  next: this | null;

  cellOffset() {
    if (this.parent) {
      const offset = this.parent.children.indexOf(this);
      console.log('[TableCell] cellOffset() - Cell offset:', offset);
      return offset;
    }
    console.log('[TableCell] cellOffset() - No parent, returning -1');
    return -1;
  }

  format(name: string, value: string) {
    if (name === TableCell.blotName && value) {
      this.domNode.setAttribute('data-row', value);
    } else {
      super.format(name, value);
    }
  }

  row(): TableRow {
    return this.parent as TableRow;
  }

  rowOffset() {
    if (this.row()) {
      return this.row().rowOffset();
    }
    return -1;
  }

  table() {
    return this.row() && this.row().table();
  }
}

class TableRow extends Container {
  static blotName = 'table-row';
  static tagName = 'TR';

  children: LinkedList<TableCell>;
  next: this | null;

  checkMerge() {
    // @ts-expect-error
    if (super.checkMerge() && this.next.children.head != null) {
      // @ts-expect-error
      const thisHead = this.children.head.formats();
      // @ts-expect-error
      const thisTail = this.children.tail.formats();
      // @ts-expect-error
      const nextHead = this.next.children.head.formats();
      // @ts-expect-error
      const nextTail = this.next.children.tail.formats();
      return (
        thisHead.table === thisTail.table &&
        thisHead.table === nextHead.table &&
        thisHead.table === nextTail.table
      );
    }
    return false;
  }

  optimize(context: { [key: string]: any }) {
    console.log('[TableRow] optimize() - Starting row optimization');
    super.optimize(context);
    let splitCount = 0;
    let index = 0;
    this.children.forEach((child) => {
      if (child.next == null) {
        index++;
        return;
      }
      const childFormats = child.formats();
      const nextFormats = child.next.formats();
      if (childFormats.table !== nextFormats.table) {
        console.log('[TableRow] optimize() - Table format mismatch detected at cell', index, '- child:', childFormats.table, 'next:', nextFormats.table);
        const next = this.splitAfter(child);
        if (next) {
          console.log('[TableRow] optimize() - Row split after cell', index);
          // @ts-expect-error TODO: parameters of optimize() should be a optional
          next.optimize();
          splitCount++;
        }
        // We might be able to merge with prev now
        if (this.prev) {
          // @ts-expect-error TODO: parameters of optimize() should be a optional
          this.prev.optimize();
        }
      }
    });
    if (splitCount > 0) {
      console.log('[TableRow] optimize() - Row optimization completed with', splitCount, 'split(s)');
    } else {
      console.log('[TableRow] optimize() - Row optimization completed, no splits needed');
    }
  }

  rowOffset() {
    if (this.parent) {
      const offset = this.parent.children.indexOf(this);
      console.log('[TableRow] rowOffset() - Row offset:', offset);
      return offset;
    }
    console.log('[TableRow] rowOffset() - No parent, returning -1');
    return -1;
  }

  table() {
    return this.parent && this.parent.parent;
  }
}

class TableBody extends Container {
  static blotName = 'table-body';
  static tagName = 'TBODY';

  children: LinkedList<TableRow>;
}

class TableContainer extends Container {
  static blotName = 'table-container';
  static tagName = 'TABLE';

  children: LinkedList<TableBody>;

  balanceCells() {
    console.log('[TableContainer] balanceCells() - Starting cell balancing');
    // Only balance rows directly in this table, not nested tables
    // Get rows from direct children (TableBody -> TableRow)
    const body = this.children.head;
    if (body == null) {
      console.log('[TableContainer] balanceCells() - No table body found, aborting');
      return;
    }
    
    const rows: TableRow[] = [];
    body.children.forEach((row) => {
      rows.push(row);
    });
    
    console.log('[TableContainer] balanceCells() - Found', rows.length, 'row(s)');
    const maxColumns = rows.reduce((max, row) => {
      return Math.max(row.children.length, max);
    }, 0);
    console.log('[TableContainer] balanceCells() - Maximum columns:', maxColumns);
    
    rows.forEach((row, rowIndex) => {
      const currentColumns = row.children.length;
      const missingColumns = maxColumns - currentColumns;
      if (missingColumns > 0) {
        console.log('[TableContainer] balanceCells() - Row', rowIndex, 'has', currentColumns, 'columns, adding', missingColumns, 'cell(s)');
        new Array(missingColumns).fill(0).forEach(() => {
          let value;
          if (row.children.head != null) {
            value = TableCell.formats(row.children.head.domNode);
          }
          const blot = this.scroll.create(TableCell.blotName, value);
          row.appendChild(blot);
          // @ts-expect-error TODO: parameters of optimize() should be a optional
          blot.optimize(); // Add break blot
        });
      }
    });
    console.log('[TableContainer] balanceCells() - Cell balancing completed');
  }

  cells(column: number) {
    return this.rows().map((row) => row.children.at(column));
  }

  deleteColumn(index: number) {
    console.log('[TableContainer] deleteColumn() - Deleting column at index', index);
    // @ts-expect-error
    const [body] = this.descendant(TableBody) as TableBody[];
    if (body == null || body.children.head == null) {
      console.log('[TableContainer] deleteColumn() - No table body or rows found, aborting');
      return;
    }
    let deletedCount = 0;
    let rowIndex = 0;
    body.children.forEach((row) => {
      const cell = row.children.at(index);
      if (cell != null) {
        console.log('[TableContainer] deleteColumn() - Removing cell from row', rowIndex);
        cell.remove();
        deletedCount++;
      }
      rowIndex++;
    });
    console.log('[TableContainer] deleteColumn() - Deleted', deletedCount, 'cell(s) from column', index);
  }

  insertColumn(index: number) {
    console.log('[TableContainer] insertColumn() - Inserting column at index', index);
    // @ts-expect-error
    const [body] = this.descendant(TableBody) as TableBody[];
    if (body == null || body.children.head == null) {
      console.log('[TableContainer] insertColumn() - No table body or rows found, aborting');
      return;
    }
    let insertedCount = 0;
    let rowIndex = 0;
    body.children.forEach((row) => {
      const ref = row.children.at(index);
      const headCell = row.children.head;
      const value = headCell ? TableCell.formats(headCell.domNode) : undefined;
      const cell = this.scroll.create(TableCell.blotName, value);
      console.log('[TableContainer] insertColumn() - Inserting cell into row', rowIndex, 'with value:', value);
      row.insertBefore(cell, ref);
      insertedCount++;
      rowIndex++;
    });
    console.log('[TableContainer] insertColumn() - Inserted', insertedCount, 'cell(s) at column index', index);
  }

  insertRow(index: number) {
    console.log('[TableContainer] insertRow() - Inserting row at index', index);
    // @ts-expect-error
    const [body] = this.descendant(TableBody) as TableBody[];
    if (body == null || body.children.head == null) {
      console.log('[TableContainer] insertRow() - No table body or rows found, aborting');
      return;
    }
    const id = tableId();
    console.log('[TableContainer] insertRow() - Creating row with table ID:', id);
    const row = this.scroll.create(TableRow.blotName) as TableRow;
    const columnCount = body.children.head.children.length;
    console.log('[TableContainer] insertRow() - Creating', columnCount, 'cells for new row');
    body.children.head.children.forEach(() => {
      const cell = this.scroll.create(TableCell.blotName, id);
      row.appendChild(cell);
    });
    const ref = body.children.at(index);
    body.insertBefore(row, ref);
    console.log('[TableContainer] insertRow() - Row inserted successfully at index', index);
  }

  rows() {
    const body = this.children.head;
    if (body == null) return [];
    return body.children.map((row) => row);
  }
}

TableContainer.allowedChildren = [TableBody];
TableBody.requiredContainer = TableContainer;

TableBody.allowedChildren = [TableRow];
TableRow.requiredContainer = TableBody;

TableRow.allowedChildren = [TableCell];
TableCell.requiredContainer = TableRow;

// Allow nested tables: TableCell can contain TableContainer
// Override TableCell.allowedChildren to include TableContainer for nesting
TableCell.allowedChildren = [Break, Inline, EmbedBlot, TextBlot, TableContainer];

function tableId() {
  const id = Math.random().toString(36).slice(2, 6);
  const tableIdValue = `row-${id}`;
  console.log('[Table] tableId() - Generated table ID:', tableIdValue);
  return tableIdValue;
}

export { TableCell, TableRow, TableBody, TableContainer, tableId };
