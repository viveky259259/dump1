import Delta from 'quill-delta';
import Quill from '../core/quill.js';
import Module from '../core/module.js';
import {
  TableCell,
  TableRow,
  TableBody,
  TableContainer,
  tableId,
} from '../formats/table.js';

class Table extends Module {
  static register() {
    Quill.register(TableCell);
    Quill.register(TableRow);
    Quill.register(TableBody);
    Quill.register(TableContainer);
  }

  constructor(...args: ConstructorParameters<typeof Module>) {
    super(...args);
    this.listenBalanceCells();
  }

  balanceTables() {
    console.log('[Table] balanceTables() - Starting to balance all tables');
    const tables = this.quill.scroll.descendants(TableContainer);
    console.log('[Table] balanceTables() - Found', tables.length, 'table(s)');
    tables.forEach((table, index) => {
      console.log('[Table] balanceTables() - Balancing table', index + 1);
      table.balanceCells();
    });
    console.log('[Table] balanceTables() - Completed balancing tables');
  }

  deleteColumn() {
    console.log('[Table] deleteColumn() - Starting column deletion');
    const [table, , cell] = this.getTable();
    if (cell == null) {
      console.log('[Table] deleteColumn() - No cell found, aborting');
      return;
    }
    const columnIndex = cell.cellOffset();
    console.log('[Table] deleteColumn() - Deleting column at index', columnIndex);
    // @ts-expect-error
    table.deleteColumn(columnIndex);
    this.quill.update(Quill.sources.USER);
    console.log('[Table] deleteColumn() - Column deleted successfully');
  }

  deleteRow() {
    console.log('[Table] deleteRow() - Starting row deletion');
    const [, row] = this.getTable();
    if (row == null) {
      console.log('[Table] deleteRow() - No row found, aborting');
      return;
    }
    const rowIndex = row.rowOffset();
    console.log('[Table] deleteRow() - Deleting row at index', rowIndex);
    row.remove();
    this.quill.update(Quill.sources.USER);
    console.log('[Table] deleteRow() - Row deleted successfully');
  }

  deleteTable() {
    console.log('[Table] deleteTable() - Starting table deletion');
    const [table] = this.getTable();
    if (table == null) {
      console.log('[Table] deleteTable() - No table found, aborting');
      return;
    }
    // @ts-expect-error
    const offset = table.offset();
    console.log('[Table] deleteTable() - Deleting table at offset', offset);
    // @ts-expect-error
    table.remove();
    this.quill.update(Quill.sources.USER);
    this.quill.setSelection(offset, Quill.sources.SILENT);
    console.log('[Table] deleteTable() - Table deleted successfully');
  }

  getTable(
    range = this.quill.getSelection(),
  ): [null, null, null, -1] | [Table, TableRow, TableCell, number] {
    if (range == null) {
      console.log('[Table] getTable() - No selection range, returning null');
      return [null, null, null, -1];
    }
    const [cell, offset] = this.quill.getLine(range.index);
    if (cell == null || cell.statics.blotName !== TableCell.blotName) {
      console.log('[Table] getTable() - Not in a table cell, returning null');
      return [null, null, null, -1];
    }
    const row = cell.parent;
    const table = row.parent.parent;
    console.log('[Table] getTable() - Found table context:', {
      cellOffset: (cell as TableCell).cellOffset(),
      rowOffset: (row as TableRow).rowOffset(),
      offset: offset
    });
    // @ts-expect-error
    return [table, row, cell, offset];
  }

  insertColumn(offset: number) {
    console.log('[Table] insertColumn() - Starting column insertion with offset', offset);
    const range = this.quill.getSelection();
    if (!range) {
      console.log('[Table] insertColumn() - No selection range, aborting');
      return;
    }
    const [table, row, cell] = this.getTable(range);
    if (cell == null) {
      console.log('[Table] insertColumn() - Not in a table cell, aborting');
      return;
    }
    const column = cell.cellOffset();
    const insertIndex = column + offset;
    console.log('[Table] insertColumn() - Inserting column at index', insertIndex, '(current column:', column, ')');
    table.insertColumn(insertIndex);
    this.quill.update(Quill.sources.USER);
    let shift = row.rowOffset();
    if (offset === 0) {
      shift += 1;
    }
    this.quill.setSelection(
      range.index + shift,
      range.length,
      Quill.sources.SILENT,
    );
    console.log('[Table] insertColumn() - Column inserted successfully');
  }

  insertColumnLeft() {
    this.insertColumn(0);
  }

  insertColumnRight() {
    this.insertColumn(1);
  }

  insertRow(offset: number) {
    console.log('[Table] insertRow() - Starting row insertion with offset', offset);
    const range = this.quill.getSelection();
    if (!range) {
      console.log('[Table] insertRow() - No selection range, aborting');
      return;
    }
    const [table, row, cell] = this.getTable(range);
    if (cell == null) {
      console.log('[Table] insertRow() - Not in a table cell, aborting');
      return;
    }
    const index = row.rowOffset();
    const insertIndex = index + offset;
    console.log('[Table] insertRow() - Inserting row at index', insertIndex, '(current row:', index, ')');
    table.insertRow(insertIndex);
    this.quill.update(Quill.sources.USER);
    if (offset > 0) {
      this.quill.setSelection(range, Quill.sources.SILENT);
    } else {
      this.quill.setSelection(
        range.index + row.children.length,
        range.length,
        Quill.sources.SILENT,
      );
    }
    console.log('[Table] insertRow() - Row inserted successfully');
  }

  insertRowAbove() {
    this.insertRow(0);
  }

  insertRowBelow() {
    this.insertRow(1);
  }

  insertTable(rows: number, columns: number) {
    console.log('[Table] insertTable() - Starting table insertion:', { rows, columns });
    const range = this.quill.getSelection();
    if (range == null) {
      console.log('[Table] insertTable() - No selection range, aborting');
      return;
    }
    console.log('[Table] insertTable() - Inserting at index', range.index);
    const delta = new Array(rows).fill(0).reduce((memo) => {
      const text = new Array(columns).fill('\n').join('');
      return memo.insert(text, { table: tableId() });
    }, new Delta().retain(range.index));
    this.quill.updateContents(delta, Quill.sources.USER);
    this.quill.setSelection(range.index, Quill.sources.SILENT);
    console.log('[Table] insertTable() - Table structure created, balancing tables');
    this.balanceTables();
    console.log('[Table] insertTable() - Table insertion completed');
  }

  insertNestedTable(rows: number, columns: number) {
    console.log('[Table] insertNestedTable() - Starting nested table insertion:', { rows, columns });
    const range = this.quill.getSelection();
    if (range == null) {
      console.log('[Table] insertNestedTable() - No selection range, aborting');
      return;
    }
    const [, , cell] = this.getTable(range);
    if (cell == null) {
      // Not in a table, insert regular table
      console.log('[Table] insertNestedTable() - Not in a table, falling back to regular table insertion');
      this.insertTable(rows, columns);
      return;
    }
    
    console.log('[Table] insertNestedTable() - Inside table cell, creating nested table');
    // Get the current cell blot
    const [cellBlot] = this.quill.getLine(range.index);
    if (cellBlot == null || cellBlot.statics.blotName !== TableCell.blotName) {
      console.log('[Table] insertNestedTable() - Invalid cell blot, aborting');
      return;
    }
    
    const targetCell = cellBlot as TableCell;
    console.log('[Table] insertNestedTable() - Target cell found, creating nested structure');
    
    // Create nested table structure
    const nestedTable = this.quill.scroll.create(TableContainer.blotName) as TableContainer;
    const nestedBody = this.quill.scroll.create(TableBody.blotName) as TableBody;
    nestedTable.appendChild(nestedBody);
    
    const id = tableId();
    console.log('[Table] insertNestedTable() - Creating', rows, 'rows and', columns, 'columns with table ID:', id);
    for (let i = 0; i < rows; i++) {
      const row = this.quill.scroll.create(TableRow.blotName) as TableRow;
      for (let j = 0; j < columns; j++) {
        const nestedCell = this.quill.scroll.create(TableCell.blotName, id);
        row.appendChild(nestedCell);
      }
      nestedBody.appendChild(row);
    }
    
    // Insert nested table into target cell
    // If cell only has a break, replace it; otherwise insert before the break
    const breakBlot = targetCell.children.head;
    const isCellEmpty = breakBlot && breakBlot.statics.blotName === 'break' && targetCell.children.length === 1;
    console.log('[Table] insertNestedTable() - Cell empty:', isCellEmpty, 'children count:', targetCell.children.length);
    
    if (isCellEmpty) {
      // Cell is empty (only has break), replace break with table
      console.log('[Table] insertNestedTable() - Replacing empty cell break with nested table');
      breakBlot.remove();
      targetCell.appendChild(nestedTable);
      // Add break after table for proper structure
      const newBreak = this.quill.scroll.create('break');
      targetCell.appendChild(newBreak);
    } else {
      // Cell has content, insert table before the break (if exists) or at end
      console.log('[Table] insertNestedTable() - Inserting nested table into cell with content');
      if (breakBlot && breakBlot.statics.blotName === 'break') {
        targetCell.insertBefore(nestedTable, breakBlot);
      } else {
        targetCell.appendChild(nestedTable);
        // Add break after table
        const newBreak = this.quill.scroll.create('break');
        targetCell.appendChild(newBreak);
      }
    }
    
    this.quill.update(Quill.sources.USER);
    // Set selection to first cell of nested table
    const firstCell = nestedTable.descendants(TableCell)[0];
    if (firstCell) {
      this.quill.setSelection(firstCell.offset() + 1, Quill.sources.SILENT);
      console.log('[Table] insertNestedTable() - Selection set to first cell of nested table');
    }
    console.log('[Table] insertNestedTable() - Balancing tables');
    this.balanceTables();
    console.log('[Table] insertNestedTable() - Nested table insertion completed');
  }

  listenBalanceCells() {
    console.log('[Table] listenBalanceCells() - Setting up mutation listener for table balancing');
    this.quill.on(
      Quill.events.SCROLL_OPTIMIZE,
      (mutations: MutationRecord[]) => {
        mutations.some((mutation) => {
          const tagName = (mutation.target as HTMLElement).tagName;
          if (
            ['TD', 'TR', 'TBODY', 'TABLE'].includes(tagName)
          ) {
            console.log('[Table] listenBalanceCells() - Table mutation detected:', tagName);
            this.quill.once(Quill.events.TEXT_CHANGE, (delta, old, source) => {
              if (source !== Quill.sources.USER) {
                console.log('[Table] listenBalanceCells() - Text change from non-user source, skipping balance');
                return;
              }
              console.log('[Table] listenBalanceCells() - User text change detected, triggering balance');
              this.balanceTables();
            });
            return true;
          }
          return false;
        });
      },
    );
  }
}

export default Table;
