import { describe, expect, test } from 'vitest';
import Quill from '../../../src/core.js';
import {
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
} from '../../../src/formats/table.js';
import { createRegistry } from '../__helpers__/factory.js';

describe('Clipboard - Nested Table Parsing', () => {
  const createClipboard = () => {
    const container = document.body.appendChild(
      document.createElement('div'),
    );
    const registry = createRegistry([TableCell, TableRow, TableBody, TableContainer]);
    const quill = new Quill(container, { registry });
    return quill.getModule('clipboard') as any;
  };

  describe('nested table parsing', () => {
    test('should parse simple nested table', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">Outer Cell 1</td>
              <td data-row="row-1">
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">Nested A1</td>
                      <td data-row="row-nest1">Nested A2</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify outer table row is processed
      expect(delta.ops).toBeDefined();
      
      // Verify nested table structure is preserved (not flattened)
      // Key test: nested cells should NOT be assigned to outer table row 1
      const nestedCellsInOuterRow1 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        (op.insert.includes('Nested A1') || op.insert.includes('Nested A2')) &&
        op.attributes?.table === 'row-1'
      );
      
      // Nested cells should NOT be in outer table row 1 (they should be handled separately)
      expect(nestedCellsInOuterRow1.length).toBe(0);
      
      // Verify nested content exists in delta
      const allText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');
      expect(allText).toContain('Nested A1');
      expect(allText).toContain('Nested A2');
    });

    test('should parse nested table with multiple rows', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">Outer Row 1, Cell 1</td>
              <td data-row="row-1">Outer Row 1, Cell 2</td>
            </tr>
            <tr>
              <td data-row="row-2">Outer Row 2, Cell 1</td>
              <td data-row="row-2">
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">Nested A1</td>
                      <td data-row="row-nest1">Nested A2</td>
                    </tr>
                    <tr>
                      <td data-row="row-nest2">Nested B1</td>
                      <td data-row="row-nest2">Nested B2</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <td data-row="row-3">Outer Row 3, Cell 1</td>
              <td data-row="row-3">Outer Row 3, Cell 2</td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify nested table rows are NOT assigned to outer table row 2
      // This is the key test - nested cells should not be flattened into outer row 2
      const nestedCellsInRow2 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        (op.insert.includes('Nested A1') || op.insert.includes('Nested A2') || 
         op.insert.includes('Nested B1') || op.insert.includes('Nested B2')) &&
        op.attributes?.table === 'row-2'
      );
      
      // Nested cells should NOT be in outer table row 2
      expect(nestedCellsInRow2.length).toBe(0);
      
      // Verify all nested content exists
      const allText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');
      expect(allText).toContain('Nested A1');
      expect(allText).toContain('Nested A2');
      expect(allText).toContain('Nested B1');
      expect(allText).toContain('Nested B2');
    });

    test('should parse nested table with content before and after', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">Outer Cell</td>
              <td data-row="row-1">
                <p>Text before nested table</p>
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">Nested Cell</td>
                    </tr>
                  </tbody>
                </table>
                <p>Text after nested table</p>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify nested table cells are NOT in outer table row 1
      const nestedInRow1 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.insert.includes('Nested Cell') &&
        op.attributes?.table === 'row-1'
      );
      expect(nestedInRow1.length).toBe(0);
      
      // Verify text before and after nested table is preserved
      const allText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');
      
      expect(allText).toContain('Text before nested table');
      expect(allText).toContain('Text after nested table');
      expect(allText).toContain('Nested Cell');
    });

    test('should handle multiple nested tables in same row', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">Nested Table 1</td>
                    </tr>
                  </tbody>
                </table>
              </td>
              <td data-row="row-1">
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest2">Nested Table 2</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify nested table cells are NOT in outer table row 1
      const nestedInRow1 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        (op.insert.includes('Nested Table 1') || op.insert.includes('Nested Table 2')) &&
        op.attributes?.table === 'row-1'
      );
      expect(nestedInRow1.length).toBe(0);
      
      // Verify both nested tables are preserved
      const allText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');
      
      expect(allText).toContain('Nested Table 1');
      expect(allText).toContain('Nested Table 2');
    });

    test('should not flatten nested table into outer table', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">Outer 1</td>
              <td data-row="row-1">
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">Nested A</td>
                      <td data-row="row-nest1">Nested B</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Key test: nested cells should NOT be in outer table row 1
      const nestedInRow1 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        (op.insert.includes('Nested A') || op.insert.includes('Nested B')) &&
        op.attributes?.table === 'row-1'
      );
      
      // Nested cells should NOT be flattened into outer row 1
      expect(nestedInRow1.length).toBe(0);
    });

    test('should handle deeply nested tables (table in table in table)', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">
                        <table>
                          <tbody>
                            <tr>
                              <td data-row="row-deep1">Deeply Nested</td>
                            </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify deeply nested content is preserved
      const allText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');
      
      expect(allText).toContain('Deeply Nested');
      
      // Verify deeply nested cell is NOT in outer table row 1
      const deeplyNestedInRow1 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.insert.includes('Deeply Nested') &&
        op.attributes?.table === 'row-1'
      );
      expect(deeplyNestedInRow1.length).toBe(0);
    });

    test('should handle regular table without nested tables (regression test)', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr>
              <td data-row="row-1">Cell 1</td>
              <td data-row="row-1">Cell 2</td>
            </tr>
            <tr>
              <td data-row="row-2">Cell 3</td>
              <td data-row="row-2">Cell 4</td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify all cells are present and have correct table attributes
      const allText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');
      
      expect(allText).toContain('Cell 1');
      expect(allText).toContain('Cell 2');
      expect(allText).toContain('Cell 3');
      expect(allText).toContain('Cell 4');
      
      // Verify rows are processed (cells should have table attributes)
      const hasTableOps = delta.ops.some((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table
      );
      expect(hasTableOps).toBe(true);
    });
  });

  describe('matchTable function', () => {
    test('should skip nested table rows', () => {
      // This test verifies that matchTable correctly identifies and skips nested table rows
      const html = `
        <table>
          <tbody>
            <tr>
              <td>
                <table>
                  <tbody>
                    <tr>
                      <td>Nested</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const clipboard = createClipboard();
      const delta = clipboard.convert({ html });
      
      // Nested table row should not be assigned to outer table row 1
      const nestedInRow1 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.insert.includes('Nested') &&
        op.attributes?.table === 'row-1'
      );
      
      // The nested cell should be handled separately, not as part of outer row 1
      expect(nestedInRow1.length).toBe(0);
    });
  });

  describe('matchTableElement function', () => {
    test('should detect nested tables and skip row processing', () => {
      const html = `
        <table>
          <tbody>
            <tr>
              <td>
                <table>
                  <tbody>
                    <tr>
                      <td>Nested</td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const clipboard = createClipboard();
      const delta = clipboard.convert({ html });
      
      // Key test: nested table row should NOT be assigned to outer table row 2
      // Nested tables use row indices 1000+ to avoid conflicts with outer tables
      const nestedInOuterRow2 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.insert.includes('Nested') &&
        op.attributes?.table === 'row-2'
      );
      
      // Nested cells should NOT be in outer table row 2
      expect(nestedInOuterRow2.length).toBe(0);
      
      // Verify nested table content exists with nested table row index (1000+)
      const nestedRows = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.insert.includes('Nested') &&
        op.attributes?.table &&
        typeof op.attributes.table === 'string' && op.attributes.table.startsWith('row-nest')
      );
      expect(nestedRows.length).toBeGreaterThan(0);
    });
  });

  describe('real-world nested table examples', () => {
    test('should parse nested table with inline styles and div wrapper', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr style="height: 0pt;">
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <br>
                <div dir="ltr" style="margin-left: 0pt;" align="left">
                  <table style="border: none; border-collapse: collapse; table-layout: fixed; width: 100%;">
                    <colgroup>
                      <col>
                      <col>
                    </colgroup>
                    <tbody>
                      <tr style="height: 0pt;">
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <br>
                        </td>
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <br>
                        </td>
                      </tr>
                      <tr style="height: 0pt;">
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <br>
                        </td>
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <br>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <br>
              </td>
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <br>
              </td>
            </tr>
            <tr style="height: 0pt;">
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <br>
              </td>
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <br>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });
      
      // Verify nested table rows are NOT assigned to outer table rows
      // Outer table has 2 rows, nested table has 2 rows
      // Nested table rows should have indices 1000+ (1001, 1002)
      // Outer table rows should have indices 1, 2
      
      // Verify structure:
      // - Outer table should have 2 rows (row-1, row-2)
      // - Nested table should have 2 rows (row-nest1, row-nest2)
      // - Nested rows should NOT be in outer table rows
      
      // Outer table row 1 should exist
      const outerRow1Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-1'
      );
      expect(outerRow1Ops.length).toBeGreaterThan(0);
      
      // Outer table row 2 should exist
      const outerRow2Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-2'
      );
      expect(outerRow2Ops.length).toBeGreaterThan(0);
      
      // Nested table rows should exist with indices row-nest1, row-nest2
      const nestedRow1Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-nest1'
      );
      const nestedRow2Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-nest2'
      );
      
      // Verify nested rows are processed (they should have table attributes row-nest1, row-nest2)
      expect(nestedRow1Ops.length).toBeGreaterThan(0);
      expect(nestedRow2Ops.length).toBeGreaterThan(0);
      
      // Critical test: nested table rows should NOT be in outer table row 1 or 2
      // Check that no operations with table: row-1 or table: row-2 also have nested table content
      // (This is verified by the fact that nested rows have row-nest prefix)
      
      // The key verification: nested table rows (row-nest1, row-nest2) should be separate from outer rows (row-1, row-2)
      const allTableIndices = new Set(
        delta.ops
          .filter((op: any) => op.attributes?.table)
          .map((op: any) => op.attributes.table)
      );
      
      // Should have outer table rows (row-1, row-2) and nested table rows (row-nest1, row-nest2)
      expect(allTableIndices.has('row-1')).toBe(true);
      expect(allTableIndices.has('row-2')).toBe(true);
      expect(allTableIndices.has('row-nest1')).toBe(true);
      expect(allTableIndices.has('row-nest2')).toBe(true);
      
      // Should NOT have row 3 or 4 (which would indicate nested rows were flattened)
      expect(allTableIndices.has('row-3')).toBe(false);
      expect(allTableIndices.has('row-4')).toBe(false);
    });

    test('should parse nested table with text content and complex inline styles', () => {
      const clipboard = createClipboard();
      const html = `
        <table>
          <tbody>
            <tr style="height: 0pt;">
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <br>
                <div dir="ltr" style="margin-left: 0pt;" align="left">
                  <table style="border: none; border-collapse: collapse; table-layout: fixed; width: 100%;">
                    <colgroup>
                      <col>
                      <col>
                    </colgroup>
                    <tbody>
                      <tr style="height: 0pt;">
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                            <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">Vivek</span>
                          </p>
                        </td>
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                            <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">Yadav</span>
                          </p>
                        </td>
                      </tr>
                      <tr style="height: 0pt;">
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                            <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">Hello</span>
                          </p>
                        </td>
                        <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                          <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                            <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">World</span>
                          </p>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <br>
              </td>
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                  <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">Ok Sir</span>
                </p>
              </td>
            </tr>
            <tr style="height: 0pt;">
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                  <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">Hahaha</span>
                </p>
              </td>
              <td style="border-width: 1pt; border-style: solid; border-color: rgb(0, 0, 0); vertical-align: top; padding: 5pt; overflow: hidden; overflow-wrap: break-word;">
                <p dir="ltr" style="line-height: 1.2; margin-top: 0pt; margin-bottom: 0pt;">
                  <span style="font-size: 11pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; font-variant-position: normal; font-variant-emoji: normal; vertical-align: baseline; white-space-collapse: preserve;">Bye</span>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      `;

      const delta = clipboard.convert({ html });

      // Verify structure:
      // - Outer table has 2 rows (indices 1, 2)
      // - Nested table has 2 rows (indices 1001, 1002)
      // - Text content is preserved

      // Check for outer table rows
      const outerRow1Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-1'
      );
      const outerRow2Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-2'
      );
      
      expect(outerRow1Ops.length).toBeGreaterThan(0);
      expect(outerRow2Ops.length).toBeGreaterThan(0);

      // Check for nested table rows
      const nestedRow1Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-nest1'
      );
      const nestedRow2Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && op.attributes?.table === 'row-nest2'
      );
      
      expect(nestedRow1Ops.length).toBeGreaterThan(0);
      expect(nestedRow2Ops.length).toBeGreaterThan(0);

      // Verify text content is preserved
      const deltaText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');

      // Check nested table text content
      expect(deltaText).toContain('Vivek');
      expect(deltaText).toContain('Yadav');
      expect(deltaText).toContain('Hello');
      expect(deltaText).toContain('World');

      // Check outer table text content
      expect(deltaText).toContain('Ok Sir');
      expect(deltaText).toContain('Hahaha');
      expect(deltaText).toContain('Bye');

      // Verify nested table text is in nested rows (1001, 1002)
      const nestedTextOps = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' &&
        (op.insert.includes('Vivek') || 
         op.insert.includes('Yadav') || 
         op.insert.includes('Hello') || 
         op.insert.includes('World')) &&
        op.attributes?.table &&
        typeof op.attributes.table === 'string' && op.attributes.table.startsWith('row-nest')
      );
      expect(nestedTextOps.length).toBeGreaterThan(0);

      // Verify outer table text is in outer rows (1, 2)
      const outerTextOps = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' &&
        (op.insert.includes('Ok Sir') || 
         op.insert.includes('Hahaha') || 
         op.insert.includes('Bye')) &&
        op.attributes?.table &&
        typeof op.attributes.table === 'string' && 
        (op.attributes.table === 'row-1' || op.attributes.table === 'row-2')
      );
      expect(outerTextOps.length).toBeGreaterThan(0);

      // Verify table indices are correct
      const allTableIndices = new Set(
        delta.ops
          .filter((op: any) => op.attributes?.table)
          .map((op: any) => op.attributes.table)
      );

      // Should have outer table rows (1, 2) and nested table rows (1001, 1002)
      expect(allTableIndices.has('row-1')).toBe(true);
      expect(allTableIndices.has('row-2')).toBe(true);
      expect(allTableIndices.has('row-nest1')).toBe(true);
      expect(allTableIndices.has('row-nest2')).toBe(true);

      // Should NOT have row 3 or 4 (which would indicate nested rows were flattened)
      expect(allTableIndices.has('row-3')).toBe(false);
      expect(allTableIndices.has('row-4')).toBe(false);
    });

    test('should parse sample HTML with nested table structure', () => {
      const clipboard = createClipboard();
      const html = `
        <h1>Nested Table Example</h1>
        <p>This document demonstrates nested tables in Quill.</p>
        <table>
          <tbody>
            <tr>
              <td data-row="row-abc1">Outer Table - Row 1, Cell 1</td>
              <td data-row="row-abc1">Outer Table - Row 1, Cell 2</td>
              <td data-row="row-abc1">Outer Table - Row 1, Cell 3</td>
            </tr>
            <tr>
              <td data-row="row-abc2">Outer Table - Row 2, Cell 1</td>
              <td data-row="row-abc2">
                <p>This cell contains a nested table:</p>
                <table>
                  <tbody>
                    <tr>
                      <td data-row="row-nest1">Nested - A1</td>
                      <td data-row="row-nest1">Nested - A2</td>
                    </tr>
                    <tr>
                      <td data-row="row-nest2">Nested - B1</td>
                      <td data-row="row-nest2">Nested - B2</td>
                    </tr>
                    <tr>
                      <td data-row="row-nest3">Nested - C1</td>
                      <td data-row="row-nest3">Nested - C2</td>
                    </tr>
                  </tbody>
                </table>
                <p>End of nested table</p>
              </td>
              <td data-row="row-abc2">Outer Table - Row 2, Cell 3</td>
            </tr>
            <tr>
              <td data-row="row-abc3">Outer Table - Row 3, Cell 1</td>
              <td data-row="row-abc3">Outer Table - Row 3, Cell 2</td>
              <td data-row="row-abc3">Outer Table - Row 3, Cell 3</td>
            </tr>
          </tbody>
        </table>
        <p>You can edit the nested table just like any other table in Quill!</p>
      `;

      const delta = clipboard.convert({ html });

      // Verify all text content is present
      const deltaText = delta.ops
        .filter((op: any) => typeof op.insert === 'string')
        .map((op: any) => op.insert)
        .join('');

      // Verify outer table content
      expect(deltaText).toContain('Outer Table - Row 1, Cell 1');
      expect(deltaText).toContain('Outer Table - Row 1, Cell 2');
      expect(deltaText).toContain('Outer Table - Row 1, Cell 3');
      expect(deltaText).toContain('Outer Table - Row 2, Cell 1');
      expect(deltaText).toContain('Outer Table - Row 2, Cell 3');
      expect(deltaText).toContain('Outer Table - Row 3, Cell 1');
      expect(deltaText).toContain('Outer Table - Row 3, Cell 2');
      expect(deltaText).toContain('Outer Table - Row 3, Cell 3');

      // Verify nested table content
      expect(deltaText).toContain('Nested - A1');
      expect(deltaText).toContain('Nested - A2');
      expect(deltaText).toContain('Nested - B1');
      expect(deltaText).toContain('Nested - B2');
      expect(deltaText).toContain('Nested - C1');
      expect(deltaText).toContain('Nested - C2');
      expect(deltaText).toContain('This cell contains a nested table:');
      expect(deltaText).toContain('End of nested table');

      // Verify outer table rows exist
      // Note: HTML already has data-row attributes, so we check for table attributes
      // The table attribute might be row-1, row-2, row-3 OR the original row-abc1, row-abc2, row-abc3
      const outerRow1Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table &&
        (op.attributes.table === 'row-1' || 
         (typeof op.insert === 'string' && op.insert.includes('Outer Table - Row 1')))
      );
      const outerRow2Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table &&
        (op.attributes.table === 'row-2' || 
         (typeof op.insert === 'string' && op.insert.includes('Outer Table - Row 2')))
      );
      const outerRow3Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table &&
        (op.attributes.table === 'row-3' || 
         (typeof op.insert === 'string' && op.insert.includes('Outer Table - Row 3')))
      );

      // At least some outer table operations should exist
      const allOuterTableOps = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table &&
        typeof op.attributes.table === 'string' &&
        !op.attributes.table.startsWith('row-nest') &&
        (op.insert.includes('Outer Table') || op.insert.includes('This cell contains'))
      );
      expect(allOuterTableOps.length).toBeGreaterThan(0);

      // Verify nested table rows exist (row-nest1, row-nest2, row-nest3)
      const nestedRow1Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table === 'row-nest1'
      );
      const nestedRow2Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table === 'row-nest2'
      );
      const nestedRow3Ops = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        op.attributes?.table === 'row-nest3'
      );

      expect(nestedRow1Ops.length).toBeGreaterThan(0);
      expect(nestedRow2Ops.length).toBeGreaterThan(0);
      expect(nestedRow3Ops.length).toBeGreaterThan(0);

      // CRITICAL TEST: Nested table cells should NOT be in outer table row 2
      // This is the key test - nested cells should not be flattened into outer row 2
      const nestedCellsInOuterRow2 = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        (op.insert.includes('Nested - A1') || 
         op.insert.includes('Nested - A2') || 
         op.insert.includes('Nested - B1') || 
         op.insert.includes('Nested - B2') || 
         op.insert.includes('Nested - C1') || 
         op.insert.includes('Nested - C2')) &&
        op.attributes?.table === 'row-2'
      );

      // Nested cells should NOT be in outer table row 2
      expect(nestedCellsInOuterRow2.length).toBe(0);

      // Verify nested table cells are in nested rows
      const nestedCellsInNestedRows = delta.ops.filter((op: any) => 
        typeof op.insert === 'string' && 
        (op.insert.includes('Nested - A1') || 
         op.insert.includes('Nested - A2') || 
         op.insert.includes('Nested - B1') || 
         op.insert.includes('Nested - B2') || 
         op.insert.includes('Nested - C1') || 
         op.insert.includes('Nested - C2')) &&
        op.attributes?.table &&
        typeof op.attributes.table === 'string' &&
        op.attributes.table.startsWith('row-nest')
      );

      // All nested cells should be in nested rows
      expect(nestedCellsInNestedRows.length).toBeGreaterThan(0);

      // CRITICAL: Verify nested table cells are NOT in outer table row 2
      // This is the most important test - nested cells should not be flattened
      expect(nestedCellsInOuterRow2.length).toBe(0);

      // Verify table indices are correct
      const allTableIndices = new Set(
        delta.ops
          .filter((op: any) => op.attributes?.table)
          .map((op: any) => op.attributes.table)
      );

      // Should have nested table rows (row-nest1, row-nest2, row-nest3)
      expect(allTableIndices.has('row-nest1')).toBe(true);
      expect(allTableIndices.has('row-nest2')).toBe(true);
      expect(allTableIndices.has('row-nest3')).toBe(true);

      // Should have some outer table rows (might be row-1/2/3 or original row-abc1/2/3)
      const hasOuterTableRows = Array.from(allTableIndices).some((idx: any) => 
        typeof idx === 'string' && 
        !idx.startsWith('row-nest') &&
        (idx.startsWith('row-') || idx.startsWith('row-abc'))
      );
      expect(hasOuterTableRows).toBe(true);

      // CRITICAL: Should NOT have row 4, 5, 6, 7, 8, 9 (which would indicate nested rows were flattened)
      // If nested rows were flattened, they would appear as row-4, row-5, etc. in the outer table
      expect(allTableIndices.has('row-4')).toBe(false);
      expect(allTableIndices.has('row-5')).toBe(false);
      expect(allTableIndices.has('row-6')).toBe(false);
      expect(allTableIndices.has('row-7')).toBe(false);
      expect(allTableIndices.has('row-8')).toBe(false);
      expect(allTableIndices.has('row-9')).toBe(false);
    });
  });
});

