# Nested Table Parsing Fix - Explanation

## Problem Analysis

### The Issue
When parsing HTML with nested tables, Quill was incorrectly flattening the nested table structure into the outer table. Nested table cells were being processed as part of the outer table rows instead of being preserved as a separate nested table structure.

### Root Cause

Quill uses a **post-order traversal** (children first, then parent) when converting HTML to Delta format. The matchers are applied in this order:

1. `['tr', matchTable]` - Matches table row elements
2. `['table', matchTableElement]` - Matches table elements
3. `[Node.ELEMENT_NODE, matchBlot]` - Matches any element as a blot

**Problem 1: `matchTable` function**
- When processing a `<tr>` from a nested table, it was finding the **outer table** as the parent
- It used `querySelectorAll('tr')` which finds ALL `<tr>` elements in the entire table subtree
- This caused nested table rows to be matched against the outer table with incorrect row indices

**Problem 2: `matchTableElement` function**
- When processing the outer `<table>`, it used `querySelectorAll('tr')` which included nested table rows
- This caused nested table rows to be processed as part of the outer table structure
- The nested table structure was lost

### Example of the Bug

**Input HTML:**
```html
<table>
  <tbody>
    <tr>
      <td>Outer Cell 1</td>
      <td>
        <table>
          <tbody>
            <tr><td>Nested A1</td><td>Nested A2</td></tr>
            <tr><td>Nested B1</td><td>Nested B2</td></tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>
```

**Before Fix:**
- Nested table rows were matched with outer table row indices
- Result: All cells appeared in the same outer table row
- Nested structure was lost

**After Fix:**
- Nested table rows are skipped by `matchTable`
- Nested table is handled by `matchBlot` as a TableContainer blot
- Result: Nested structure is preserved

## Solution

### Fix 1: `matchTable` Function (for `<tr>` elements)

**Changes:**
1. **Detect nested table rows**: Check if a `<tr>` is inside a nested table by finding the containing table and checking if that table is inside a `<TD>`
   - If the table containing this row is inside a `<TD>`, it's a nested table row
   - Process nested table rows with their own row indices (1000+ to avoid conflicts)
   - This ensures nested rows get table attributes and won't get outer table format applied

2. **Use scoped queries**: Use `:scope > tr` to only get direct child rows
   - Prevents matching nested table rows when processing outer tables

**Code:**
```typescript
// Find the table containing this row
const table = node.parentElement?.tagName === 'TABLE' 
  ? node.parentElement 
  : node.parentElement?.parentElement;

// Check if this table is inside a TD (nested table)
let parent = table.parentElement;
while (parent && parent.tagName !== 'TD' && parent.tagName !== 'BODY') {
  parent = parent.parentElement;
}

// If nested, process with nested table row indices (1000+)
if (parent?.tagName === 'TD') {
  const tbody = table.querySelector('tbody');
  const rows = Array.from(tbody.querySelectorAll(':scope > tr'));
  const row = rows.indexOf(node) + 1;
  // Use 1000+ to avoid conflicts with outer table rows
  return applyFormat(delta, 'table', 1000 + row, scroll);
}

// Regular table - process normally with row indices 1, 2, 3, etc.
```

### Fix 2: `matchTableElement` Function (for `<table>` elements)

**Changes:**
1. **Detect nested tables**: Check if a `<table>` is inside a `<TD>` element
   - If nested, return delta unchanged and let `matchBlot` handle it
   - `matchBlot` will create a TableContainer blot for nested tables

2. **Use scoped queries**: Use `:scope > tr` to only process direct child rows
   - Prevents nested table rows from being included in outer table processing

**Code:**
```typescript
// Check if this table is inside a TD (nested table)
let parent = node.parentElement;
while (parent && parent.tagName !== 'TD' && parent.tagName !== 'BODY') {
  parent = parent.parentElement;
}

if (parent?.tagName === 'TD') {
  // Nested table - let matchBlot handle it
  return delta;
}

// Regular table - only get direct child rows
const tbody = node.querySelector('tbody');
const rows = Array.from(tbody.querySelectorAll(':scope > tr'));
// Process only direct child rows
```

## How It Works Now

### Processing Flow

1. **Traverse HTML tree** (post-order: children → parent)
   - Process nested elements first
   - Then process parent elements

2. **For nested table rows (`<tr>` inside `<td>`):**
   - `matchTable` detects it's nested by checking if the containing table is inside a `<TD>`
   - Processes nested rows with row indices 1000+ (e.g., 1001, 1002, 1003)
   - This ensures nested rows get table attributes and won't get outer table format applied
   - `applyFormat` checks if operations already have table attributes, so nested rows (1000+) are protected

3. **For nested table elements (`<table>` inside `<td>`):**
   - `matchTableElement` detects it's nested and skips row processing
   - Returns delta unchanged
   - `matchBlot` creates a TableContainer blot

4. **For outer table rows:**
   - `matchTable` processes them normally
   - Applies correct row indices (1, 2, 3, etc.)
   - Uses scoped queries to avoid nested rows
   - `applyFormat` only applies to operations without table attributes, so nested rows (1000+) are safe

5. **For outer table elements:**
   - `matchTableElement` processes them normally
   - Only processes direct child rows using `:scope > tr`
   - Uses scoped queries to avoid nested rows

### Key Concepts

- **`:scope > tr` selector**: Only matches direct child `<tr>` elements, not nested ones
- **Post-order traversal**: Ensures nested structures are processed before parent structures
- **matchBlot fallback**: Handles complex nested structures that specific matchers skip
- **TableContainer blot**: The proper Quill blot type for nested tables

## Benefits

1. ✅ **Preserves nested structure**: Nested tables remain nested, not flattened
2. ✅ **Correct row indices**: Outer table rows get correct indices, nested rows are handled separately
3. ✅ **Backward compatible**: Regular (non-nested) tables work exactly as before
4. ✅ **Uses existing Quill architecture**: Leverages `matchBlot` and TableContainer blots

## Testing

See `test/unit/modules/clipboard-nested-table.spec.ts` for comprehensive test cases.

