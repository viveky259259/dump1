# Nested Table Parsing Fix - Summary

## Quick Explanation

### The Problem
When Quill parsed HTML with nested tables, it was **flattening** the nested structure. Nested table cells were being processed as part of the outer table rows instead of being preserved as a separate nested table.

### Why It Happened
1. **`matchTable` function** (processes `<tr>` elements):
   - Used `querySelectorAll('tr')` which found ALL `<tr>` elements including nested ones
   - Nested table rows were matched against the outer table with wrong row indices

2. **`matchTableElement` function** (processes `<table>` elements):
   - Also used `querySelectorAll('tr')` which included nested table rows
   - Nested rows were processed as part of the outer table structure

### The Fix

**Fix 1: `matchTable` function**
- ✅ Detects if a `<tr>` is inside a nested table (table is inside a TD)
- ✅ Processes nested table rows with row indices 1000+ to avoid conflicts
- ✅ Uses `:scope > tr` to only match direct child rows
- ✅ Ensures nested rows get table attributes so outer table format won't apply to them

**Fix 2: `matchTableElement` function**
- ✅ Detects if a `<table>` is inside a `<TD>` (nested table)
- ✅ Skips nested tables - lets `matchBlot` handle them as TableContainer blots
- ✅ Uses `:scope > tr` to only process direct child rows

### Key Changes

```typescript
// In matchTable - detect and process nested rows
// Find the table containing this row
const table = node.parentElement?.tagName === 'TABLE' 
  ? node.parentElement 
  : node.parentElement?.parentElement;

// Check if table is inside a TD (nested)
let parent = table.parentElement;
while (parent && parent.tagName !== 'TD' && parent.tagName !== 'BODY') {
  parent = parent.parentElement;
}

// If nested, process with 1000+ indices to avoid conflicts
if (parent?.tagName === 'TD') {
  const rows = Array.from(tbody.querySelectorAll(':scope > tr'));
  const row = rows.indexOf(node) + 1;
  return applyFormat(delta, 'table', 1000 + row, scroll);
}

// Use scoped queries for regular tables
const rows = Array.from(tbody.querySelectorAll(':scope > tr'));
```

```typescript
// In matchTableElement - detect nested tables
if (parent?.tagName === 'TD') {
  return delta; // Let matchBlot handle nested tables
}

// Use scoped queries
const rows = Array.from(tbody.querySelectorAll(':scope > tr'));
```

## Test Cases

Comprehensive test suite created in `test/unit/modules/clipboard-nested-table.spec.ts`:

1. ✅ Simple nested table parsing
2. ✅ Nested table with multiple rows
3. ✅ Nested table with content before/after
4. ✅ Multiple nested tables in same row
5. ✅ Prevention of flattening (regression test)
6. ✅ Deeply nested tables (3 levels)
7. ✅ Regular tables without nesting (backward compatibility)

## Files Modified

1. `quill/packages/quill/src/modules/clipboard.ts`
   - Fixed `matchTable` function
   - Fixed `matchTableElement` function

2. `quill/packages/quill/test/unit/modules/clipboard-nested-table.spec.ts`
   - New comprehensive test suite

3. `quill/NESTED_TABLE_FIX_EXPLANATION.md`
   - Detailed technical explanation

## How to Test

### Setup (First Time Only)
Install Playwright browsers:
```bash
cd quill/packages/quill
npx playwright install chromium
```

### Run Tests

Run the nested table test suite:
```bash
cd quill/packages/quill
npm run test:unit -- clipboard-nested-table.spec.ts
```

Or run all unit tests:
```bash
cd quill/packages/quill
npm run test:unit
```

Or run a specific test file with vitest directly:
```bash
cd quill/packages/quill
npx vitest --config test/unit/vitest.config.ts test/unit/modules/clipboard-nested-table.spec.ts
```

### Manual Testing
Load HTML with nested tables in the Quill editor and verify the structure is preserved (not flattened).

## Result

✅ Nested tables now parse correctly
✅ Structure is preserved (not flattened)
✅ Backward compatible with regular tables
✅ Uses existing Quill architecture (matchBlot, TableContainer)

