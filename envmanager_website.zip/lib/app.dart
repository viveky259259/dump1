import 'package:jaspr/dom.dart';
import 'package:jaspr/jaspr.dart';

import 'pages/home.dart';

class App extends StatelessComponent {
  const App({super.key});

  @override
  Component build(BuildContext context) {
    return div(classes: 'main', [
      const Home(),
    ]);
  }

  @css
  static List<StyleRule> get styles => [
    css('*', [
      css('&').styles(
        margin: .zero,
        padding: .zero,
        boxSizing: .borderBox,
      ),
    ]),
    css('html, body', [
      css('&').styles(
        margin: .zero,
        padding: .zero,
      ),
    ]),
    css('.main', [
      css('&').styles(
        minHeight: 100.vh,
      ),
    ]),
  ];
}
