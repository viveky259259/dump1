import 'package:jaspr/dom.dart';
import 'package:jaspr/jaspr.dart';

import '../constants/theme.dart';

@client
class Home extends StatelessComponent {
  const Home({super.key});

  @override
  Component build(BuildContext context) {
    return div(classes: 'landing', [
      // Hero Section
      section(classes: 'hero', [
        div(classes: 'hero-content', [
          img(src: 'images/app-icon.png', width: 150, classes: 'app-icon'),
          h1([text('EnvManager')]),
          p(classes: 'tagline', [
            text('A native macOS app for managing shell environment variables')
          ]),
          p(classes: 'subtitle', [
            text('Edit zsh, bash, and fish config files with ease')
          ]),
          div(classes: 'cta-buttons', [
            a(
              href: 'https://github.com/ff-vivek/EnvManager/releases/latest',
              classes: 'btn btn-primary',
              [text('Download')],
            ),
            a(
              href: 'https://github.com/ff-vivek/EnvManager',
              classes: 'btn btn-secondary',
              [text('View on GitHub')],
            ),
          ]),
          div(classes: 'install-command', [
            code([text('brew install --cask ff-vivek/tap/envmanager')]),
          ]),
        ]),
      ]),

      // Features Section
      section(classes: 'features', [
        h2([text('Features')]),
        div(classes: 'features-grid', [
          _featureCard(
            'Multi-Shell Support',
            'Manage environment variables for zsh, bash, and fish shells from one app.',
          ),
          _featureCard(
            'Easy Editing',
            'Add, edit, and delete environment variables with a clean, intuitive interface.',
          ),
          _featureCard(
            'PATH Editor',
            'Special drag-and-drop editor for PATH variables with path validation.',
          ),
          _featureCard(
            'Auto Backup',
            'Automatic backup of config files before any modifications.',
          ),
          _featureCard(
            'Preview Changes',
            'See exactly what will change before applying to your config files.',
          ),
          _featureCard(
            'Safe & Local',
            'All data stays on your machine. No cloud, no tracking.',
          ),
        ]),
      ]),

      // Installation Section
      section(classes: 'installation', [
        h2([text('Installation')]),
        div(classes: 'install-options', [
          div(classes: 'install-option', [
            h3([text('Homebrew (Recommended)')]),
            div(classes: 'code-block', [
              code([text('brew install --cask ff-vivek/tap/envmanager')]),
            ]),
          ]),
          div(classes: 'install-option', [
            h3([text('Direct Download')]),
            p([text('Download the latest release from GitHub:')]),
            a(
              href: 'https://github.com/ff-vivek/EnvManager/releases/latest',
              classes: 'btn btn-outline',
              [text('Download from GitHub')],
            ),
          ]),
        ]),
      ]),

      // Footer
      footer([
        p([
          text('Made with '),
          span(classes: 'heart', [text('love')]),
          text(' using SwiftUI'),
        ]),
        p(classes: 'links', [
          a(href: 'https://github.com/ff-vivek/EnvManager', [text('GitHub')]),
          text(' · '),
          a(href: 'https://github.com/ff-vivek/EnvManager/issues', [text('Report Issue')]),
        ]),
      ]),
    ]);
  }

  Component _featureCard(String title, String description) {
    return div(classes: 'feature-card', [
      h3([text(title)]),
      p([text(description)]),
    ]);
  }

  @css
  static List<StyleRule> get styles => [
    // Landing page styles
    css('.landing', [
      css('&').styles(
        fontFamily: FontFamilies.sansSerif,
        color: lightText,
        backgroundColor: darkBg,
        minHeight: 100.vh,
      ),
    ]),

    // Hero section
    css('.hero', [
      css('&').styles(
        padding: .symmetric(vertical: 80.px, horizontal: 20.px),
        textAlign: .center,
      ),
      css('.hero-content').styles(
        maxWidth: 800.px,
        margin: .symmetric(horizontal: Unit.auto),
      ),
      css('.app-icon').styles(
        radius: .circular(24.px),
        raw: {
          'box-shadow': '0 20px 40px rgba(0, 0, 0, 0.3)',
          'margin-bottom': '24px',
        },
      ),
      css('h1').styles(
        fontSize: 3.5.rem,
        fontWeight: .w700,
        margin: .only(bottom: 16.px),
        color: primaryColor,
      ),
      css('.tagline').styles(
        fontSize: 1.5.rem,
        color: lightText,
        margin: .only(bottom: 8.px),
      ),
      css('.subtitle').styles(
        fontSize: 1.1.rem,
        color: mutedText,
        margin: .only(bottom: 32.px),
      ),
    ]),

    // CTA Buttons
    css('.cta-buttons', [
      css('&').styles(
        display: .flex,
        justifyContent: .center,
        flexWrap: .wrap,
        margin: .only(bottom: 24.px),
        raw: {'gap': '16px'},
      ),
    ]),

    css('.btn', [
      css('&').styles(
        padding: .symmetric(vertical: 14.px, horizontal: 28.px),
        radius: .circular(8.px),
        fontSize: 1.rem,
        fontWeight: .w600,
        textDecoration: TextDecoration(line: .none),
        cursor: .pointer,
        raw: {'transition': 'all 0.2s'},
      ),
      css('&.btn-primary').styles(
        backgroundColor: primaryColor,
        color: lightText,
      ),
      css('&.btn-primary:hover').styles(
        backgroundColor: accentColor,
      ),
      css('&.btn-secondary').styles(
        backgroundColor: const Color('#0000'),
        color: lightText,
        border: Border.all(color: mutedText, width: 2.px),
      ),
      css('&.btn-secondary:hover').styles(
        border: Border.all(color: lightText, width: 2.px),
      ),
      css('&.btn-outline').styles(
        backgroundColor: const Color('#0000'),
        color: primaryColor,
        border: Border.all(color: primaryColor, width: 2.px),
      ),
      css('&.btn-outline:hover').styles(
        backgroundColor: primaryColor,
        color: lightText,
      ),
    ]),

    // Install command
    css('.install-command', [
      css('&').styles(
        backgroundColor: const Color('#0003'),
        padding: .symmetric(vertical: 12.px, horizontal: 20.px),
        radius: .circular(8.px),
        display: .inlineBlock,
      ),
      css('code').styles(
        fontFamily: FontFamilies.monospace,
        color: accentColor,
        fontSize: 0.95.rem,
      ),
    ]),

    // Features section
    css('.features', [
      css('&').styles(
        padding: .symmetric(vertical: 80.px, horizontal: 20.px),
        backgroundColor: const Color('#0002'),
      ),
      css('h2').styles(
        textAlign: .center,
        fontSize: 2.5.rem,
        margin: .only(bottom: 48.px),
      ),
      css('.features-grid').styles(
        display: .grid,
        maxWidth: 1000.px,
        margin: .symmetric(horizontal: Unit.auto),
        raw: {
          'gap': '24px',
          'grid-template-columns': 'repeat(auto-fit, minmax(280px, 1fr))',
        },
      ),
    ]),

    css('.feature-card', [
      css('&').styles(
        backgroundColor: const Color('#fff1'),
        padding: .all(24.px),
        radius: .circular(12.px),
        border: Border.all(color: const Color('#fff2')),
        raw: {'transition': 'all 0.2s'},
      ),
      css('&:hover').styles(
        backgroundColor: const Color('#fff2'),
        raw: {'transform': 'translateY(-4px)'},
      ),
      css('h3').styles(
        fontSize: 1.25.rem,
        margin: .only(bottom: 8.px),
      ),
      css('p').styles(
        color: mutedText,
        fontSize: 0.95.rem,
        lineHeight: 1.6.em,
      ),
    ]),

    // Installation section
    css('.installation', [
      css('&').styles(
        padding: .symmetric(vertical: 80.px, horizontal: 20.px),
        textAlign: .center,
      ),
      css('h2').styles(
        fontSize: 2.5.rem,
        margin: .only(bottom: 48.px),
      ),
      css('.install-options').styles(
        display: .flex,
        justifyContent: .center,
        flexWrap: .wrap,
        maxWidth: 800.px,
        margin: .symmetric(horizontal: Unit.auto),
        raw: {'gap': '40px'},
      ),
      css('.install-option').styles(
        raw: {'flex-basis': '300px'},
        textAlign: .center,
      ),
      css('.install-option h3').styles(
        margin: .only(bottom: 16.px),
        color: primaryColor,
      ),
      css('.install-option p').styles(
        color: mutedText,
        margin: .only(bottom: 16.px),
      ),
      css('.code-block').styles(
        backgroundColor: const Color('#0004'),
        padding: .all(16.px),
        radius: .circular(8.px),
      ),
      css('.code-block code').styles(
        fontFamily: FontFamilies.monospace,
        color: accentColor,
      ),
    ]),

    // Footer
    css('footer', [
      css('&').styles(
        padding: .symmetric(vertical: 40.px, horizontal: 20.px),
        textAlign: .center,
        raw: {'border-top': '1px solid rgba(255,255,255,0.1)'},
      ),
      css('p').styles(
        color: mutedText,
        margin: .only(bottom: 8.px),
      ),
      css('.heart').styles(
        color: const Color('#ef4444'),
      ),
      css('.links a').styles(
        color: primaryColor,
        textDecoration: TextDecoration(line: .none),
      ),
      css('.links a:hover').styles(
        textDecoration: TextDecoration(line: .underline),
      ),
    ]),
  ];
}
