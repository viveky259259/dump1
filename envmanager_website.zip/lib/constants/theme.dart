import 'package:jaspr/dom.dart';

// EnvManager brand colors
const primaryColor = Color('#0d9488');
const secondaryColor = Color('#1a365d');
const accentColor = Color('#10b981');
const darkBg = Color('#0f172a');
const lightText = Color('#f8fafc');
const mutedText = Color('#94a3b8');
