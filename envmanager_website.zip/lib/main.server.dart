/// The entrypoint for the **server** environment.
///
/// The [main] method will only be executed on the server during pre-rendering.
/// To run code on the client, check the `main.client.dart` file.
library;

import 'package:jaspr/dom.dart';
// Server-specific Jaspr import.
import 'package:jaspr/server.dart';

// Imports the [App] component.
import 'app.dart';

// This file is generated automatically by Jaspr, do not remove or edit.
import 'main.server.options.dart';

void main() {
  // Initializes the server environment with the generated default options.
  Jaspr.initializeApp(
    options: defaultServerOptions,
  );

  // Starts the app.
  //
  // [Document] renders the root document structure (<html>, <head> and <body>)
  // with the provided parameters and components.
  runApp(Document(
    title: 'EnvManager - macOS Environment Variables Manager',
    meta: {
      'description': 'A native macOS app for managing shell environment variables. Edit zsh, bash, and fish config files with ease.',
      'keywords': 'macos, environment variables, zsh, bash, fish, shell, config, PATH',
      'author': 'ff-vivek',
      'viewport': 'width=device-width, initial-scale=1.0',
      'theme-color': '#0d9488',
    },
    styles: [
      // Import Google Fonts
      css.import('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fira+Code&display=swap'),
      // Global styles
      css('html, body').styles(
        width: 100.percent,
        minHeight: 100.vh,
        padding: .zero,
        margin: .zero,
        fontFamily: const .list([FontFamily('Inter'), FontFamilies.sansSerif]),
      ),
    ],
    body: App(),
  ));
}
