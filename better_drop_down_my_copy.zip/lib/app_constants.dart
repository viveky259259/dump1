import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const List<String> ListOfProfiles = [
    'Deductor',
    'TaxPayer',
    'PAO',
    'DAO'
  ];
  static const List<String> ListOfToggles = [
    'LDC/NDC',
    'Demand',
    'Prosecution',
    'Collection'
  ];
  static const String ValidationPANregex = '^[A-Z]{5}\\d{4}[A-Z]\$';
  static const String ValidationTANregex = '^[A-Z]{4}\\d{5}[A-Z]\$';
  static const String AmountValidationRegex = '^\\d+(\\.\\d+)?\$';
  static const List<String> YearList = ['Q1', 'Q2', 'Q3', 'Q4'];
  static const List<String> listOfStates = [
    'MH',
    'GJ',
    'HR',
    'JK',
    'HP',
    'PJ',
    'DL',
    'UP',
    'UK',
    'BH',
    'MG',
    'AS',
    'NG',
    'OR',
    'KA',
    'KL',
    'TL',
    'AP'
  ];
}
