import 'package:collection/collection.dart';

enum FileUploadStatus {
  Uploaded,
  Uploading,
  Error,
}

enum RadioButtonIcon {
  signature,
  fingerprint,
  mobileFriendly,
  accountBalance,
  mail,
  factCheck,
  noIcon,
  verifiedUser,
}

enum ErrorType {
  PasswordProtectedFile,
  FormatNotSupported,
  DuplicateFile,
  FileSizeExceeded,
  uploadFailed,
}

enum IDatePickerType {
  multi,
  single,
  range,
}

enum TextInputFilter {
  None,
  EnglishLetters,
  Numbers,
  AlphaNumeric,
  CustomRegex,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (FileUploadStatus):
      return FileUploadStatus.values.deserialize(value) as T?;
    case (RadioButtonIcon):
      return RadioButtonIcon.values.deserialize(value) as T?;
    case (ErrorType):
      return ErrorType.values.deserialize(value) as T?;
    case (IDatePickerType):
      return IDatePickerType.values.deserialize(value) as T?;
    case (TextInputFilter):
      return TextInputFilter.values.deserialize(value) as T?;
    default:
      return null;
  }
}
