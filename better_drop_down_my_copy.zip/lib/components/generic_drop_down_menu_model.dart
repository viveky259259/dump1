import '/backend/schema/structs/index.dart';
import '/components/generic_drop_down_menu_item_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'generic_drop_down_menu_widget.dart' show GenericDropDownMenuWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericDropDownMenuModel
    extends FlutterFlowModel<GenericDropDownMenuWidget> {
  ///  State fields for stateful widgets in this component.

  final genericDropDownMenuShortcutsFocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    genericDropDownMenuShortcutsFocusNode.dispose();
  }
}
