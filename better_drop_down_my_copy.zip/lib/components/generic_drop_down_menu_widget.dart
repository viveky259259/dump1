import '/backend/schema/structs/index.dart';
import '/components/generic_drop_down_menu_item_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_drop_down_menu_model.dart';
export 'generic_drop_down_menu_model.dart';

class GenericDropDownMenuWidget extends StatefulWidget {
  const GenericDropDownMenuWidget({
    super.key,
    this.dropdownOptions,
    double? menuMaxWidth,
    this.menuMaxHeight,
    this.selectedOption,
    required this.keyPrefix,
  }) : this.menuMaxWidth = menuMaxWidth ?? 340.0;

  final List<DropDownItemStruct>? dropdownOptions;
  final double menuMaxWidth;
  final double? menuMaxHeight;
  final String? selectedOption;
  final String? keyPrefix;

  @override
  State<GenericDropDownMenuWidget> createState() =>
      _GenericDropDownMenuWidgetState();
}

class _GenericDropDownMenuWidgetState extends State<GenericDropDownMenuWidget> {
  late GenericDropDownMenuModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericDropDownMenuModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Shortcuts(
      shortcuts: {
        SingleActivator(
          LogicalKeyboardKey.arrowUp,
        ): VoidCallbackIntent(() async {
          FocusScope.of(context).previousFocus();
        }),
        SingleActivator(
          LogicalKeyboardKey.arrowDown,
        ): VoidCallbackIntent(() async {
          FocusScope.of(context).nextFocus();
        }),
      },
      child: Actions(
        actions: {
          VoidCallbackIntent: CallbackAction<VoidCallbackIntent>(
            onInvoke: (intent) => intent.callback(),
          ),
        },
        child: Focus(
          // autofocus: isShortcutsSupported,
          focusNode: _model.genericDropDownMenuShortcutsFocusNode,
          child: GestureDetector(
              onTap: () =>
                  _model.genericDropDownMenuShortcutsFocusNode!.canRequestFocus
                      ? FocusScope.of(context).requestFocus(
                          _model.genericDropDownMenuShortcutsFocusNode)
                      : FocusScope.of(context).unfocus(),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                child: FocusTraversalGroup(
                  policy: OrderedTraversalPolicy(),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4.0),
                    child: Container(
                      constraints: BoxConstraints(
                        maxWidth: widget!.menuMaxWidth,
                        maxHeight: widget!.menuMaxHeight!,
                      ),
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 12.0,
                            color: Colors.black,
                            offset: Offset(
                              0.0,
                              0.0,
                            ),
                            spreadRadius: 0.0,
                          )
                        ],
                        borderRadius: BorderRadius.circular(4.0),
                      ),
                      child: Builder(
                        builder: (context) {
                          final options =
                              widget!.dropdownOptions?.toList() ?? [];

                          return ListView.builder(
                            padding: EdgeInsets.zero,
                            scrollDirection: Axis.vertical,
                            itemCount: options.length,
                            itemBuilder: (context, optionsIndex) {
                              final optionsItem = options[optionsIndex];
                              return FFFocusIndicator(
                                onTap: () async {
                                  // close and return value
                                  Navigator.pop(context, optionsItem);
                                },
                                border: Border.all(
                                  color: FlutterFlowTheme.of(context).primary,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(4.0),
                                child: GenericDropDownMenuItemWidget(
                                  key: Key(
                                      'Keyvbp_${optionsIndex}_of_${options.length}'),
                                  keyPrefix: widget!.keyPrefix!,
                                  itemLabel: optionsItem.label,
                                  isSelected: optionsItem.label ==
                                      widget!.selectedOption,
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ),
                ),
              )),
        ),
      ),
    );
  }
}
