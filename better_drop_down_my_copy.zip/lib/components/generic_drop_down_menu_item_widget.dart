import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_drop_down_menu_item_model.dart';
export 'generic_drop_down_menu_item_model.dart';

class GenericDropDownMenuItemWidget extends StatefulWidget {
  const GenericDropDownMenuItemWidget({
    super.key,
    required this.keyPrefix,
    required this.itemLabel,
    bool? isSelected,
  }) : this.isSelected = isSelected ?? false;

  final String? keyPrefix;
  final String? itemLabel;
  final bool isSelected;

  @override
  State<GenericDropDownMenuItemWidget> createState() =>
      _GenericDropDownMenuItemWidgetState();
}

class _GenericDropDownMenuItemWidgetState
    extends State<GenericDropDownMenuItemWidget> {
  late GenericDropDownMenuItemModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericDropDownMenuItemModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: widget!.itemLabel != null && widget!.itemLabel != '',
      child: MouseRegion(
        opaque: false,
        cursor: MouseCursor.defer ?? MouseCursor.defer,
        child: Container(
          width: double.infinity,
          constraints: BoxConstraints(
            minHeight: 45.0,
          ),
          decoration: BoxDecoration(
            color: () {
              if (widget!.isSelected) {
                return FlutterFlowTheme.of(context).accent2;
              } else if (_model.mouseRegionHovered!) {
                return FlutterFlowTheme.of(context).accent1;
              } else {
                return FlutterFlowTheme.of(context).secondaryBackground;
              }
            }(),
          ),
          child: Align(
            alignment: AlignmentDirectional(-1.0, 0.0),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 12.0, 12.0, 12.0),
              child: Text(
                widget!.itemLabel!,
                style: GoogleFonts.notoSans(
                  color: FlutterFlowTheme.of(context).primaryText,
                  fontSize: 14.0,
                ),
              ),
            ),
          ),
        ),
        onEnter: ((event) async {
          safeSetState(() => _model.mouseRegionHovered = true);
        }),
        onExit: ((event) async {
          safeSetState(() => _model.mouseRegionHovered = false);
        }),
      ),
    );
  }
}
