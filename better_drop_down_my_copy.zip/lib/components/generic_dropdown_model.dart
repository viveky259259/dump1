import '/backend/schema/structs/index.dart';
import '/components/generic_drop_down_menu_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'generic_dropdown_widget.dart' show GenericDropdownWidget;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericDropdownModel extends FlutterFlowModel<GenericDropdownWidget> {
  ///  Local state fields for this component.

  DropDownItemStruct? selectedOptionValue;
  void updateSelectedOptionValueStruct(Function(DropDownItemStruct) updateFn) {
    updateFn(selectedOptionValue ??= DropDownItemStruct());
  }

  bool isMenuOpen = false;

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Alert Dialog - Custom Dialog] action in Dropdown widget.
  DropDownItemStruct? menuSelectedOption;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
