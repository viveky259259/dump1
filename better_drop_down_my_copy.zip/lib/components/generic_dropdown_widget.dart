import '/backend/schema/structs/index.dart';
import '/components/generic_drop_down_menu_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_dropdown_model.dart';
export 'generic_dropdown_model.dart';

class GenericDropdownWidget extends StatefulWidget {
  const GenericDropdownWidget({
    super.key,
    required this.keyPrefix,
    this.hintText,
    required this.dropdownLabels,
    required this.dropdownValues,
    this.initialOption,
    double? maxWidth,
    bool? isDisabled,
    double? dropdownMaxHeight,
    double? menuMaxHeight,
    this.onSelect,
    bool? showError,
    this.onClickDropdown,
  })  : this.maxWidth = maxWidth ?? 340.0,
        this.isDisabled = isDisabled ?? false,
        this.dropdownMaxHeight = dropdownMaxHeight ?? 400.0,
        this.menuMaxHeight = menuMaxHeight ?? 400.0,
        this.showError = showError ?? false;

  final String? keyPrefix;
  final String? hintText;
  final List<String>? dropdownLabels;
  final List<String>? dropdownValues;
  final String? initialOption;
  final double maxWidth;
  final bool isDisabled;
  final double dropdownMaxHeight;
  final double menuMaxHeight;
  final Future Function(DropDownItemStruct? selectedOption)? onSelect;
  final bool showError;
  final Future Function(bool onMenuOpend)? onClickDropdown;

  @override
  State<GenericDropdownWidget> createState() => _GenericDropdownWidgetState();
}

class _GenericDropdownWidgetState extends State<GenericDropdownWidget>
    with TickerProviderStateMixin {
  late GenericDropdownModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericDropdownModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (widget!.initialOption != null && widget!.initialOption != '') {
        _model.selectedOptionValue = DropDownItemStruct(
          label: widget!.initialOption,
          value: widget!.initialOption,
        );
        safeSetState(() {});
        return;
      } else {
        return;
      }
    });

    animationsMap.addAll({
      'iconOnActionTriggerAnimation': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          RotateEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 150.0.ms,
            begin: 0.0,
            end: -0.5,
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) => FFFocusIndicator(
        onTap: () async {
          var _shouldSetState = false;
          if (widget!.isDisabled) {
            if (_shouldSetState) safeSetState(() {});
            return;
          }

          // flip dropdown icon
          if (animationsMap['iconOnActionTriggerAnimation'] != null) {
            animationsMap['iconOnActionTriggerAnimation']!
                .controller
                .forward(from: 0.0);
          }
          // menu open state update
          _model.isMenuOpen = true;
          safeSetState(() {});
          // Show Dropdown Menu
          await showAlignedDialog(
            barrierColor: Colors.transparent,
            context: context,
            isGlobal: false,
            avoidOverflow: false,
            targetAnchor: AlignmentDirectional(-1.0, 1.0)
                .resolve(Directionality.of(context)),
            followerAnchor: AlignmentDirectional(-1.0, -1.0)
                .resolve(Directionality.of(context)),
            builder: (dialogContext) {
              return Material(
                color: Colors.transparent,
                child: GenericDropDownMenuWidget(
                  dropdownOptions: functions.combineDropDownOptions(
                      widget!.dropdownLabels?.toList(),
                      widget!.dropdownValues?.toList()),
                  menuMaxWidth: widget!.maxWidth,
                  menuMaxHeight: widget!.menuMaxHeight,
                  selectedOption: _model.selectedOptionValue?.label,
                  keyPrefix: widget!.keyPrefix!,
                ),
              );
            },
          ).then(
              (value) => safeSetState(() => _model.menuSelectedOption = value));

          _shouldSetState = true;
          // flip icon back
          if (animationsMap['iconOnActionTriggerAnimation'] != null) {
            animationsMap['iconOnActionTriggerAnimation']!.controller.reverse();
          }
          await widget.onClickDropdown?.call(
            true,
          );
          // menu close state update
          _model.isMenuOpen = false;
          safeSetState(() {});
          // update selected option
          _model.selectedOptionValue = _model.menuSelectedOption != null
              ? _model.menuSelectedOption
              : _model.selectedOptionValue;
          safeSetState(() {});
          // onSelection Callback
          await widget.onSelect?.call(
            _model.selectedOptionValue,
          );
          if (_shouldSetState) safeSetState(() {});
          return;
          if (_shouldSetState) safeSetState(() {});
        },
        border: Border.all(
          color: FlutterFlowTheme.of(context).primary,
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(4.0),
        child: Container(
          constraints: BoxConstraints(
            minHeight: 37.0,
            maxWidth: widget!.maxWidth,
            maxHeight: widget!.dropdownMaxHeight,
          ),
          decoration: BoxDecoration(
            color: valueOrDefault<Color>(
              widget!.isDisabled
                  ? FlutterFlowTheme.of(context).accent4
                  : FlutterFlowTheme.of(context).secondaryBackground,
              FlutterFlowTheme.of(context).secondaryBackground,
            ),
            borderRadius: BorderRadius.circular(4.0),
            border: Border.all(
              color: valueOrDefault<Color>(
                () {
                  if (_model.isMenuOpen) {
                    return FlutterFlowTheme.of(context).accent2;
                  } else if (widget!.showError) {
                    return FlutterFlowTheme.of(context).danger500Default;
                  } else if (widget!.isDisabled) {
                    return FlutterFlowTheme.of(context).secondaryText;
                  } else {
                    return FlutterFlowTheme.of(context).secondary;
                  }
                }(),
                FlutterFlowTheme.of(context).secondaryText,
              ),
              width: valueOrDefault<double>(
                (_model.isMenuOpen ? 1 : 1).toDouble(),
                1.0,
              ),
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(12.0, 8.0, 12.0, 8.0),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                    valueOrDefault<String>(
                      _model.selectedOptionValue?.label != null &&
                              _model.selectedOptionValue?.label != ''
                          ? _model.selectedOptionValue?.label
                          : widget!.hintText,
                      'Please Select',
                    ),
                    style: GoogleFonts.notoSans(
                      color: valueOrDefault<Color>(
                        () {
                          if (widget!.isDisabled) {
                            return FlutterFlowTheme.of(context).secondaryText;
                          } else if (widget!.hintText != null &&
                              widget!.hintText != '') {
                            return FlutterFlowTheme.of(context).primaryText;
                          } else {
                            return FlutterFlowTheme.of(context).primaryText;
                          }
                        }(),
                        FlutterFlowTheme.of(context).primaryText,
                      ),
                      fontSize: 14.0,
                    ),
                  ),
                ),
                Icon(
                  Icons.keyboard_arrow_down,
                  color: widget!.isDisabled
                      ? FlutterFlowTheme.of(context).secondaryText
                      : FlutterFlowTheme.of(context).primaryText,
                  size: 20.0,
                ).animateOnActionTrigger(
                  animationsMap['iconOnActionTriggerAnimation']!,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
