import '/components/generic_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'test_page_widget.dart' show TestPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TestPageModel extends FlutterFlowModel<TestPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Generic_Dropdown component.
  late GenericDropdownModel genericDropdownModel1;
  // Model for Generic_Dropdown component.
  late GenericDropdownModel genericDropdownModel2;

  @override
  void initState(BuildContext context) {
    genericDropdownModel1 = createModel(context, () => GenericDropdownModel());
    genericDropdownModel2 = createModel(context, () => GenericDropdownModel());
  }

  @override
  void dispose() {
    genericDropdownModel1.dispose();
    genericDropdownModel2.dispose();
  }
}
