import '/components/generic_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'test_page_model.dart';
export 'test_page_model.dart';

class TestPageWidget extends StatefulWidget {
  const TestPageWidget({super.key});

  static String routeName = 'TEST_PAGE';
  static String routePath = '/input-page';

  @override
  State<TestPageWidget> createState() => _TestPageWidgetState();
}

class _TestPageWidgetState extends State<TestPageWidget> {
  late TestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: wrapWithModel(
                  model: _model.genericDropdownModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: GenericDropdownWidget(
                    keyPrefix: 'key',
                    isDisabled: false,
                    showError: false,
                    dropdownLabels: ['John', 'Jane', 'Doe', 'Alice'],
                    dropdownValues: ['John', 'Jane', 'Doe', 'Alice'],
                    onSelect: (selectedOption) async {},
                    onClickDropdown: (onMenuOpend) async {},
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: wrapWithModel(
                  model: _model.genericDropdownModel2,
                  updateCallback: () => safeSetState(() {}),
                  child: GenericDropdownWidget(
                    keyPrefix: 'key',
                    isDisabled: false,
                    showError: false,
                    dropdownLabels: ['John', 'Jane', 'Doe', 'Alice'],
                    dropdownValues: ['John', 'Jane', 'Doe', 'Alice'],
                    onSelect: (selectedOption) async {},
                    onClickDropdown: (onMenuOpend) async {},
                  ),
                ),
              ),
            ].divide(SizedBox(height: 16.0)).around(SizedBox(height: 16.0)),
          ),
        ),
      ),
    );
  }
}
