package com.mycompany.betterdropdownmycopy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
