import '/backend/schema/enums/enums.dart';
import '/components/chip_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/file_upload/file_attachment/file_attachment_widget.dart';
import '/generic_components/inputfield_generic_checkboxwith_label/inputfield_generic_checkboxwith_label_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'someshtest_model.dart';
export 'someshtest_model.dart';

class SomeshtestWidget extends StatefulWidget {
  const SomeshtestWidget({super.key});

  @override
  State<SomeshtestWidget> createState() => _SomeshtestWidgetState();
}

class _SomeshtestWidgetState extends State<SomeshtestWidget> {
  late SomeshtestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SomeshtestModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              wrapWithModel(
                model: _model.fileAttachmentModel,
                updateCallback: () => safeSetState(() {}),
                updateOnChange: true,
                child: FileAttachmentWidget(
                  fileName: 'KapilKumarSehgalDelhiNCRNoida201301.pdf',
                  keyPrefix: 'keyprefix',
                  isFileUploaded: false,
                  errorMsg: 'file size exceeds',
                  fileSize: '5Mb',
                  uploadSuccesMsg: 'File uploaded',
                  uploadFailedError: true,
                  status: FileUploadStatus.Error,
                  deleteAction: () async {},
                  onView: () async {},
                  onReload: () async {},
                ),
              ),
              wrapWithModel(
                model: _model.chipDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: ChipDropdownWidget(
                  keyPrefix: 'ntg2',
                  labelName: 'Hello',
                  optionList: ["hi", "hello"],
                ),
              ),
              wrapWithModel(
                model: _model.inputfieldGenericCheckboxwithLabelModel,
                updateCallback: () => safeSetState(() {}),
                child: InputfieldGenericCheckboxwithLabelWidget(
                  isMandatory: true,
                  keyPrefix: 'test',
                  checkBoxInitialValue: false,
                  labelText: 'Male',
                  errorMessage: 'failed',
                  checkBoxAction: () async {},
                ),
              ),
              FFButtonWidget(
                onPressed: () {
                  print('Button pressed ...');
                },
                text: 'Button',
                options: FFButtonOptions(
                  height: 40.0,
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  iconPadding:
                      EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                  color: FlutterFlowTheme.of(context).primary,
                  textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                        fontFamily: 'Inter',
                        color: Colors.white,
                        letterSpacing: 0.0,
                      ),
                  elevation: 0.0,
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
