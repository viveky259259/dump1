import '/backend/schema/enums/enums.dart';
import '/components/chip_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/file_upload/file_attachment/file_attachment_widget.dart';
import '/generic_components/inputfield_generic_checkboxwith_label/inputfield_generic_checkboxwith_label_widget.dart';
import 'dart:ui';
import 'someshtest_widget.dart' show SomeshtestWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SomeshtestModel extends FlutterFlowModel<SomeshtestWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for File_Attachment component.
  late FileAttachmentModel fileAttachmentModel;
  // Model for ChipDropdown component.
  late ChipDropdownModel chipDropdownModel;
  // Model for Inputfield_Generic_CheckboxwithLabel component.
  late InputfieldGenericCheckboxwithLabelModel
      inputfieldGenericCheckboxwithLabelModel;

  @override
  void initState(BuildContext context) {
    fileAttachmentModel = createModel(context, () => FileAttachmentModel());
    chipDropdownModel = createModel(context, () => ChipDropdownModel());
    inputfieldGenericCheckboxwithLabelModel =
        createModel(context, () => InputfieldGenericCheckboxwithLabelModel());
  }

  @override
  void dispose() {
    fileAttachmentModel.dispose();
    chipDropdownModel.dispose();
    inputfieldGenericCheckboxwithLabelModel.dispose();
  }
}
