import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/not_in_used/input_field_generic_password/input_field_generic_password_widget.dart';
import 'dart:ui';
import 'entry_page_widget.dart' show EntryPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EntryPageModel extends FlutterFlowModel<EntryPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for InputField_Generic_Password component.
  late InputFieldGenericPasswordModel inputFieldGenericPasswordModel;

  @override
  void initState(BuildContext context) {
    inputFieldGenericPasswordModel =
        createModel(context, () => InputFieldGenericPasswordModel());
  }

  @override
  void dispose() {
    inputFieldGenericPasswordModel.dispose();
  }
}
