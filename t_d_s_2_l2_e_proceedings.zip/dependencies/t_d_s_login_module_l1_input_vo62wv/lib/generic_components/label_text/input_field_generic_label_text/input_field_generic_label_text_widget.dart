import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_label_text_model.dart';
export 'input_field_generic_label_text_model.dart';

/// "A versatile Label Text component designed for various text entry needs.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the input field, displayed at the top. Defaults to 'Label'.
///
/// - **isMandatory**: `bool`
///   Specifies whether the field is required. Displays an asterisk (*) next
/// to the label if true.
///
///
/// ### Example:
/// ```dart
/// InputField_Generic_LabelText(
///   labelText: 'Enter your name',
/// )"
class InputFieldGenericLabelTextWidget extends StatefulWidget {
  const InputFieldGenericLabelTextWidget({
    super.key,
    String? labelText,
    bool? isMandatory,
    required this.keyPrefix,
  })  : this.labelText = labelText ?? 'LableText',
        this.isMandatory = isMandatory ?? false;

  final String labelText;
  final bool isMandatory;
  final String? keyPrefix;

  @override
  State<InputFieldGenericLabelTextWidget> createState() =>
      _InputFieldGenericLabelTextWidgetState();
}

class _InputFieldGenericLabelTextWidgetState
    extends State<InputFieldGenericLabelTextWidget> {
  late InputFieldGenericLabelTextModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericLabelTextModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RichText(
      textScaler: MediaQuery.of(context).textScaler,
      key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
          widget!.keyPrefix!, 'InputField_Generic_LabelText', 'LabelText')),
      text: TextSpan(
        children: [
          TextSpan(
            text: widget!.labelText,
            style: FlutterFlowTheme.of(context).bodySmall.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).primaryTxtClr,
                  fontSize: 12.0,
                  letterSpacing: 0.0,
                ),
          ),
          TextSpan(
            text: widget!.isMandatory ? ' *' : '',
            style: FlutterFlowTheme.of(context).bodySmall.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).danger500Default,
                  fontSize: 12.0,
                  letterSpacing: 0.0,
                ),
          )
        ],
        style: FlutterFlowTheme.of(context).bodyMedium.override(
              fontFamily: 'Inter',
              color: FlutterFlowTheme.of(context).primaryText,
              fontSize: 12.0,
              letterSpacing: 0.0,
            ),
      ),
    );
  }
}
