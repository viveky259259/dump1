import '/flutter_flow/flutter_flow_util.dart';
import 'input_field_generic_label_text_widget.dart'
    show InputFieldGenericLabelTextWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericLabelTextModel
    extends FlutterFlowModel<InputFieldGenericLabelTextWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
