import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'text_label_with_tooltip_model.dart';
export 'text_label_with_tooltip_model.dart';

/// "A versatile Label Text component
///  with tooltip designed for various text entry needs.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the input field, displayed at the top. Defaults to 'Label'.
///
/// - **isMandatory**: `bool`
///   Specifies whether the field is required. Displays an asterisk (*) next
/// to the label if true.
///
///
/// ### Example:
/// ```dart
/// InputField_Generic_LabelText(
///   labelText: 'Enter your name',
/// )"
class TextLabelWithTooltipWidget extends StatefulWidget {
  const TextLabelWithTooltipWidget({
    super.key,
    this.labelText,
    this.isMandatory,
    this.fontSize,
    this.labelColor,
    this.toolTipIconColor,
    this.toolTipMessage,
    required this.keyPrefix,
    double? tooltipIconSize,
  }) : this.tooltipIconSize = tooltipIconSize ?? 15.0;

  final String? labelText;
  final bool? isMandatory;
  final double? fontSize;
  final Color? labelColor;
  final Color? toolTipIconColor;
  final String? toolTipMessage;
  final String? keyPrefix;
  final double tooltipIconSize;

  @override
  State<TextLabelWithTooltipWidget> createState() =>
      _TextLabelWithTooltipWidgetState();
}

class _TextLabelWithTooltipWidgetState
    extends State<TextLabelWithTooltipWidget> {
  late TextLabelWithTooltipModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TextLabelWithTooltipModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          RichText(
            textScaler: MediaQuery.of(context).textScaler,
            text: TextSpan(
              children: [
                TextSpan(
                  text: valueOrDefault<String>(
                    widget!.labelText,
                    'labelText',
                  ),
                  style: FlutterFlowTheme.of(context).bodySmall.override(
                        fontFamily: 'Inter',
                        color: widget!.labelColor,
                        fontSize: widget!.fontSize,
                        letterSpacing: 0.0,
                      ),
                ),
                TextSpan(
                  text: widget!.isMandatory! ? ' *' : '',
                  style: FlutterFlowTheme.of(context).bodySmall.override(
                        fontFamily: 'Inter',
                        color: Color(0xFFB3261D),
                        letterSpacing: 0.0,
                      ),
                )
              ],
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).primaryText,
                    fontSize: 12.0,
                    letterSpacing: 0.0,
                  ),
            ),
          ),
          if (widget!.toolTipMessage != null && widget!.toolTipMessage != '')
            AlignedTooltip(
              content: Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  widget!.toolTipMessage!,
                  style: FlutterFlowTheme.of(context).bodySmall.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).alternate,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              offset: 4.0,
              preferredDirection: AxisDirection.up,
              borderRadius: BorderRadius.circular(8.0),
              backgroundColor: FlutterFlowTheme.of(context).neutral1000,
              elevation: 4.0,
              tailBaseWidth: 24.0,
              tailLength: 12.0,
              waitDuration: Duration(milliseconds: 100),
              showDuration: Duration(milliseconds: 1500),
              triggerMode: TooltipTriggerMode.tap,
              child: Icon(
                Icons.info_outline,
                color: widget!.toolTipIconColor,
                size: valueOrDefault<double>(
                  widget!.tooltipIconSize,
                  15.0,
                ),
              ),
            ),
        ].divide(SizedBox(width: 2.0)),
      ),
    );
  }
}
