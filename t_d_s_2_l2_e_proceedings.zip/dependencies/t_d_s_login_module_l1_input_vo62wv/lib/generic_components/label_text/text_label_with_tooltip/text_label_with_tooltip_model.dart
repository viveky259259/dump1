import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'text_label_with_tooltip_widget.dart' show TextLabelWithTooltipWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TextLabelWithTooltipModel
    extends FlutterFlowModel<TextLabelWithTooltipWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
