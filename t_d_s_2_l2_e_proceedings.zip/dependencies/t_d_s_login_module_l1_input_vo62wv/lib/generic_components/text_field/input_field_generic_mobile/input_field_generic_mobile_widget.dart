import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_mobile_model.dart';
export 'input_field_generic_mobile_model.dart';

class InputFieldGenericMobileWidget extends StatefulWidget {
  const InputFieldGenericMobileWidget({
    super.key,
    this.dropDownWidth,
    this.dropDownHeight,
  });

  final double? dropDownWidth;
  final double? dropDownHeight;

  @override
  State<InputFieldGenericMobileWidget> createState() =>
      _InputFieldGenericMobileWidgetState();
}

class _InputFieldGenericMobileWidgetState
    extends State<InputFieldGenericMobileWidget> {
  late InputFieldGenericMobileModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericMobileModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        FlutterFlowDropDown<String>(
          controller: _model.dropDownValueController ??=
              FormFieldController<String>(null),
          options: ['Option 1', 'Option 2', 'Option 3'],
          onChanged: (val) => safeSetState(() => _model.dropDownValue = val),
          width: widget!.dropDownWidth,
          height: widget!.dropDownHeight,
          textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Inter',
                letterSpacing: 0.0,
              ),
          hintText: 'Select...',
          icon: Icon(
            Icons.keyboard_arrow_down_rounded,
            color: FlutterFlowTheme.of(context).secondaryText,
            size: 24.0,
          ),
          fillColor: FlutterFlowTheme.of(context).secondaryBackground,
          elevation: 2.0,
          borderColor: Colors.transparent,
          borderWidth: 0.0,
          borderRadius: 8.0,
          margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
          hidesUnderline: true,
          isOverButton: false,
          isSearchable: false,
          isMultiSelect: false,
        ),
        wrapWithModel(
          model: _model.inputFieldGenericTextFieldModel,
          updateCallback: () => safeSetState(() {}),
          child: InputFieldGenericTextFieldWidget(
            keyPrefix: 'Tesdst',
            isDisable: false,
            isMandatory: false,
            labelText: '  ',
            isViewOnly: false,
            showExternalErrorMessage: false,
            onSubmitAction: () async {},
            onInputValueChangeCallback: (value) async {},
            onFocusChangeCallback: (hasFocus) async {},
            onInputValidationCallback: (isValid) async {},
            onTapLabelTrailingButton: () async {},
          ),
        ),
      ],
    );
  }
}
