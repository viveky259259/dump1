import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_button/text_button_widget.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'input_field_password_widget.dart' show InputFieldPasswordWidget;
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldPasswordModel
    extends FlutterFlowModel<InputFieldPasswordWidget> {
  ///  Local state fields for this component.

  bool isInputValid = true;

  bool hasBeenFocussed = false;

  bool showError = false;

  String? errorMessage;

  ///  State fields for stateful widgets in this component.

  // Model for Text_Button component.
  late TextButtonModel textButtonModel1;
  // Model for Text_Button component.
  late TextButtonModel textButtonModel2;
  // State field(s) for Generic_TextField widget.
  FocusNode? genericTextFieldFocusNode;
  TextEditingController? genericTextFieldTextController;
  late bool genericTextFieldVisibility;
  String? Function(BuildContext, String?)?
      genericTextFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {
    textButtonModel1 = createModel(context, () => TextButtonModel());
    textButtonModel2 = createModel(context, () => TextButtonModel());
    genericTextFieldVisibility = false;
  }

  @override
  void dispose() {
    textButtonModel1.dispose();
    textButtonModel2.dispose();
    genericTextFieldFocusNode?.dispose();
    genericTextFieldTextController?.dispose();
  }

  /// Action blocks.
  Future validateTextField(BuildContext context) async {
    if ((widget!.validationRegex != null && widget!.validationRegex != '') &&
        (genericTextFieldTextController.text != null &&
            genericTextFieldTextController.text != '')) {
      isInputValid = functions.isInputValid(
          genericTextFieldTextController.text, widget!.validationRegex!);
      showError =
          widget!.validationRegex != null && widget!.validationRegex != ''
              ? true
              : false;
      errorMessage = isInputValid ? null : widget!.errorText;
      return;
    } else {
      return;
    }
  }
}
