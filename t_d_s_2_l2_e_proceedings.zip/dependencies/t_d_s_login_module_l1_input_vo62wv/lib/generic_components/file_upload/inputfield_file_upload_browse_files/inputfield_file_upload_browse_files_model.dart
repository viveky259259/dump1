import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'inputfield_file_upload_browse_files_widget.dart'
    show InputfieldFileUploadBrowseFilesWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputfieldFileUploadBrowseFilesModel
    extends FlutterFlowModel<InputfieldFileUploadBrowseFilesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
