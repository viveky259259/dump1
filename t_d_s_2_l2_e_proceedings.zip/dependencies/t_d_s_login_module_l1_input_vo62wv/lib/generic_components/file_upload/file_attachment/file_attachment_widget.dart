import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'file_attachment_model.dart';
export 'file_attachment_model.dart';

/// A versatile input component to view the attached document or to delete it
///
/// Parameters:
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
///
/// onView: Action
/// Define the action to be performed when the EyeIconButton is tapped it will
/// view the file.
/// onReload: Action
/// Define the action to be performed when the RefreshIconButton is tapped it
/// will reload the file upload
/// deleteAction: Action
/// Define the action to be performed when the DeleteIconButton is tapped it
/// will delete the file.
/// fileName: String
/// Defines the name of the file that is uploaded.
/// isFileUploaded:Boolean
/// it will check whether the file is uploaded if uploaded it will be set to
/// true or false
///
/// uploadFailureError:String
/// If the file upload fails then the error message should be displayed
class FileAttachmentWidget extends StatefulWidget {
  const FileAttachmentWidget({
    super.key,
    this.deleteAction,
    required this.fileName,
    required this.keyPrefix,
    this.onView,
    bool? isFileUploaded,
    this.errorMsg,
    this.status,
    this.onReload,
    this.height,
    this.width,
    required this.fileSize,
    this.uploadSuccesMsg,
    this.uploadFailedError,
  }) : this.isFileUploaded = isFileUploaded ?? true;

  final Future Function()? deleteAction;
  final String? fileName;
  final String? keyPrefix;
  final Future Function()? onView;
  final bool isFileUploaded;
  final String? errorMsg;
  final FileUploadStatus? status;
  final Future Function()? onReload;
  final double? height;
  final double? width;
  final String? fileSize;
  final String? uploadSuccesMsg;
  final bool? uploadFailedError;

  @override
  State<FileAttachmentWidget> createState() => _FileAttachmentWidgetState();
}

class _FileAttachmentWidgetState extends State<FileAttachmentWidget> {
  late FileAttachmentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FileAttachmentModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 0.0,
      runSpacing: 0.0,
      alignment: WrapAlignment.start,
      crossAxisAlignment: WrapCrossAlignment.start,
      direction: Axis.horizontal,
      runAlignment: WrapAlignment.start,
      verticalDirection: VerticalDirection.down,
      clipBehavior: Clip.none,
      children: [
        Container(
          decoration: BoxDecoration(),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: widget!.height,
                decoration: BoxDecoration(
                  color: () {
                    if (widget!.status == FileUploadStatus.Uploaded) {
                      return FlutterFlowTheme.of(context).successBGStroke5;
                    } else if (widget!.status == FileUploadStatus.Uploading) {
                      return FlutterFlowTheme.of(context)
                          .secondaryInfoBGStroke5;
                    } else if (widget!.status == FileUploadStatus.Error) {
                      return FlutterFlowTheme.of(context).dangerBGStroke5;
                    } else {
                      return Color(0x00000000);
                    }
                  }(),
                  borderRadius: BorderRadius.circular(4.0),
                  border: Border.all(
                    color: () {
                      if (widget!.status == FileUploadStatus.Uploaded) {
                        return FlutterFlowTheme.of(context).success700;
                      } else if (widget!.status == FileUploadStatus.Uploading) {
                        return FlutterFlowTheme.of(context).primary700;
                      } else if (widget!.status == FileUploadStatus.Error) {
                        return FlutterFlowTheme.of(context).danger700;
                      } else {
                        return Color(0x00000000);
                      }
                    }(),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                12.0, 0.0, 0.0, 0.0),
                            child: Container(
                              width: 32.0,
                              height: 32.0,
                              decoration: BoxDecoration(
                                color: () {
                                  if (widget!.status ==
                                      FileUploadStatus.Uploaded) {
                                    return FlutterFlowTheme.of(context)
                                        .successBGStroke20;
                                  } else if (widget!.status ==
                                      FileUploadStatus.Uploading) {
                                    return FlutterFlowTheme.of(context)
                                        .secondaryInfoBGStroke5;
                                  } else if (widget!.status ==
                                      FileUploadStatus.Error) {
                                    return FlutterFlowTheme.of(context)
                                        .dangerBGStroke15;
                                  } else {
                                    return Color(0x00000000);
                                  }
                                }(),
                                borderRadius: BorderRadius.circular(4.0),
                              ),
                              child: Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: FaIcon(
                                  key: ValueKey(
                                      t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'File_Attachment',
                                              'FileIcon')),
                                  FontAwesomeIcons.fileAlt,
                                  color: () {
                                    if (widget!.status ==
                                        FileUploadStatus.Uploaded) {
                                      return FlutterFlowTheme.of(context)
                                          .fileAttachmentBorder;
                                    } else if (widget!.status ==
                                        FileUploadStatus.Uploading) {
                                      return FlutterFlowTheme.of(context)
                                          .primary;
                                    } else if (widget!.status ==
                                        FileUploadStatus.Error) {
                                      return FlutterFlowTheme.of(context)
                                          .deleteIcon;
                                    } else {
                                      return Color(0x00000000);
                                    }
                                  }(),
                                  size: 20.0,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                8.0, 0.0, 0.0, 0.0),
                            child: Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrefix!,
                                      'File_Attachment', 'fileName_text')),
                              valueOrDefault<String>(
                                widget!.fileName,
                                'FileName',
                              ).maybeHandleOverflow(
                                maxChars: 15,
                                replacement: '…',
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: () {
                                      if (widget!.status ==
                                          FileUploadStatus.Uploaded) {
                                        return FlutterFlowTheme.of(context)
                                            .fileAttachmentBorder;
                                      } else if (widget!.status ==
                                          FileUploadStatus.Uploading) {
                                        return FlutterFlowTheme.of(context)
                                            .primary;
                                      } else if (widget!.status ==
                                          FileUploadStatus.Error) {
                                        return FlutterFlowTheme.of(context)
                                            .deleteIcon;
                                      } else {
                                        return Color(0x00000000);
                                      }
                                    }(),
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                8.0, 0.0, 0.0, 0.0),
                            child: Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrefix!,
                                      'File_Attachment', 'fileSize_Text')),
                              '(${widget!.fileSize})'.maybeHandleOverflow(
                                maxChars: 4,
                                replacement: '…',
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: () {
                                      if (widget!.status ==
                                          FileUploadStatus.Uploaded) {
                                        return FlutterFlowTheme.of(context)
                                            .fileAttachmentBorder;
                                      } else if (widget!.status ==
                                          FileUploadStatus.Uploading) {
                                        return FlutterFlowTheme.of(context)
                                            .primary;
                                      } else if (widget!.status ==
                                          FileUploadStatus.Error) {
                                        return FlutterFlowTheme.of(context)
                                            .deleteIcon;
                                      } else {
                                        return Color(0x00000000);
                                      }
                                    }(),
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Builder(
                          builder: (context) {
                            if (widget!.isFileUploaded) {
                              return Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Container(
                                      height: 32.0,
                                      decoration: BoxDecoration(),
                                      child: FlutterFlowIconButton(
                                        key: ValueKey(
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL1KeyValue(
                                                    widget!.keyPrefix!,
                                                    'File_Attachment',
                                                    'EyeIconButton')),
                                        icon: Icon(
                                          Icons.remove_red_eye_outlined,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral800,
                                          size: 20.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onView?.call();
                                        },
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 22.0,
                                    child: VerticalDivider(
                                      width: 0.5,
                                      color: FlutterFlowTheme.of(context)
                                          .neutral400,
                                    ),
                                  ),
                                ].divide(SizedBox(width: 5.0)),
                              );
                            } else if (widget!.uploadFailedError != null) {
                              return Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    height: 32.0,
                                    decoration: BoxDecoration(),
                                    child: FlutterFlowIconButton(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'File_Attachment',
                                                  'ReloadButton')),
                                      icon: FaIcon(
                                        FontAwesomeIcons.redo,
                                        color: FlutterFlowTheme.of(context)
                                            .neutral500Default,
                                        size: 20.0,
                                      ),
                                      onPressed: () async {
                                        await widget.onReload?.call();
                                      },
                                    ),
                                  ),
                                  SizedBox(
                                    height: 100.0,
                                    child: VerticalDivider(
                                      thickness: 1.0,
                                      indent: 11.0,
                                      endIndent: 11.0,
                                      color: Color(0xFFBFC1C5),
                                    ),
                                  ),
                                ],
                              );
                            } else {
                              return Container(
                                decoration: BoxDecoration(),
                              );
                            }
                          },
                        ),
                        FlutterFlowIconButton(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'File_Attachment', 'DeleteIconButton')),
                          icon: Icon(
                            Icons.delete_outline,
                            color:
                                FlutterFlowTheme.of(context).danger500Default,
                            size: 20.0,
                          ),
                          onPressed: () async {
                            await widget.deleteAction?.call();
                          },
                        ),
                      ].addToEnd(SizedBox(width: 12.0)),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                child: Container(
                  decoration: BoxDecoration(),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Builder(
                        builder: (context) {
                          if (widget!.isFileUploaded) {
                            return Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrefix!,
                                      'File_Attachment', 'FileUploadText')),
                              valueOrDefault<String>(
                                widget!.uploadSuccesMsg,
                                'File Uploaded',
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                  ),
                            );
                          } else {
                            return Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrefix!,
                                      'File_Attachment', 'ErrorText')),
                              valueOrDefault<String>(
                                widget!.errorMsg,
                                'ErrorMsg',
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).errorText,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                  ),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
