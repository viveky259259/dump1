import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_uploaded_file_box_model.dart';
export 'input_field_generic_uploaded_file_box_model.dart';

class InputFieldGenericUploadedFileBoxWidget extends StatefulWidget {
  const InputFieldGenericUploadedFileBoxWidget({
    super.key,
    this.fileName,
    String? sizeStatusOfFile,
    this.onView,
    this.onDelete,
    this.onReload,
    this.isFileUploaded,
    this.color,
    this.uploadFailuareMsg,
    required this.keyPrefix,
  }) : this.sizeStatusOfFile = sizeStatusOfFile ?? 'Size/Status';

  final String? fileName;
  final String sizeStatusOfFile;
  final Future Function()? onView;
  final Future Function()? onDelete;
  final Future Function()? onReload;
  final bool? isFileUploaded;
  final Color? color;
  final String? uploadFailuareMsg;
  final String? keyPrefix;

  @override
  State<InputFieldGenericUploadedFileBoxWidget> createState() =>
      _InputFieldGenericUploadedFileBoxWidgetState();
}

class _InputFieldGenericUploadedFileBoxWidgetState
    extends State<InputFieldGenericUploadedFileBoxWidget> {
  late InputFieldGenericUploadedFileBoxModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => InputFieldGenericUploadedFileBoxModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 320.0,
          height: 48.0,
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(8.0),
            border: Border.all(
              width: 1.0,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(12.0, 8.0, 0.0, 8.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 5.5, 0.0),
                      child: Container(
                        width: 32.0,
                        height: 32.0,
                        decoration: BoxDecoration(),
                        child: Icon(
                          Icons.text_snippet_outlined,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 24.0,
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Text(
                        valueOrDefault<String>(
                          widget!.fileName,
                          'File Name',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 2.0, 8.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Builder(
                      builder: (context) {
                        if (!widget!.isFileUploaded!) {
                          return Container(
                            width: 100.0,
                            height: 100.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                          );
                        } else if (widget!.isFileUploaded ?? false) {
                          return FlutterFlowIconButton(
                            borderRadius: 8.0,
                            buttonSize: 40.0,
                            fillColor: Colors.transparent,
                            icon: Icon(
                              Icons.remove_red_eye_outlined,
                              color: FlutterFlowTheme.of(context)
                                  .disbaleHyperlinkBtnTxtIconClr,
                              size: 24.0,
                            ),
                            onPressed: () {
                              print('EyeIconButton pressed ...');
                            },
                          );
                        } else {
                          return FlutterFlowIconButton(
                            borderRadius: 8.0,
                            fillColor: Colors.transparent,
                            icon: Icon(
                              Icons.replay,
                              color: FlutterFlowTheme.of(context)
                                  .disbaleHyperlinkBtnTxtIconClr,
                              size: 16.67,
                            ),
                            onPressed: () {
                              print('ReloadIconButton pressed ...');
                            },
                          );
                        }
                      },
                    ),
                    SizedBox(
                      height: 22.0,
                      child: VerticalDivider(
                        thickness: 2.0,
                        color: FlutterFlowTheme.of(context).alternate,
                      ),
                    ),
                    Builder(
                      builder: (context) {
                        if (widget!.isFileUploaded ?? false) {
                          return FlutterFlowIconButton(
                            borderRadius: 8.0,
                            fillColor: Colors.transparent,
                            icon: Icon(
                              Icons.delete_outline,
                              color:
                                  FlutterFlowTheme.of(context).deleteBtnBorder,
                              size: 20.0,
                            ),
                            showLoadingIndicator: true,
                            onPressed: () {
                              print('DeleteIconButton pressed ...');
                            },
                          );
                        } else {
                          return Icon(
                            Icons.timelapse_rounded,
                            color:
                                FlutterFlowTheme.of(context).activeIconBtnBgClr,
                            size: 16.67,
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          width: 320.0,
          decoration: BoxDecoration(
            color: Colors.transparent,
          ),
          child: Visibility(
            visible: !widget!.isFileUploaded!,
            child: Text(
              valueOrDefault<String>(
                widget!.uploadFailuareMsg,
                'Error Text',
              ),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).error,
                    letterSpacing: 0.0,
                  ),
            ),
          ),
        ),
      ].divide(SizedBox(height: 8.0)),
    );
  }
}
