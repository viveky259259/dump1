import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'input_field_generic_uploaded_file_box_widget.dart'
    show InputFieldGenericUploadedFileBoxWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericUploadedFileBoxModel
    extends FlutterFlowModel<InputFieldGenericUploadedFileBoxWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
