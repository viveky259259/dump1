import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'input_field_generic_upload_file_widget.dart'
    show InputFieldGenericUploadFileWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericUploadFileModel
    extends FlutterFlowModel<InputFieldGenericUploadFileWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
