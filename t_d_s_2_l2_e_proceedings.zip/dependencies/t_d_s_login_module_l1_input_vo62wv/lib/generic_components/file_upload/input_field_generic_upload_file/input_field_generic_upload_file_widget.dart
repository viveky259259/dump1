import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_upload_file_model.dart';
export 'input_field_generic_upload_file_model.dart';

class InputFieldGenericUploadFileWidget extends StatefulWidget {
  const InputFieldGenericUploadFileWidget({
    super.key,
    this.selectUploadFileLabel,
    this.onTapBrowseFilesAction,
  });

  final String? selectUploadFileLabel;
  final Future Function()? onTapBrowseFilesAction;

  @override
  State<InputFieldGenericUploadFileWidget> createState() =>
      _InputFieldGenericUploadFileWidgetState();
}

class _InputFieldGenericUploadFileWidgetState
    extends State<InputFieldGenericUploadFileWidget> {
  late InputFieldGenericUploadFileModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericUploadFileModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 404.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 72.0,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12.0),
              shape: BoxShape.rectangle,
              border: Border.all(
                color: Color(0xFFD6D6D6),
              ),
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    width: 48.0,
                    height: 48.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.upload_file_rounded,
                      color: Color(0xFF8F8F8F),
                      size: 32.0,
                    ),
                  ),
                  Expanded(
                    child: Semantics(
                      label: 'This is the file name of the document.',
                      child: Text(
                        valueOrDefault<String>(
                          widget!.selectUploadFileLabel,
                          'label',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Source Sans 3',
                              color: Color(0xFF8F8F8F),
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ),
                  Semantics(
                    label:
                        'This is a button for browsing your files to be uploaded.',
                    child: InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTapBrowseFilesAction?.call();
                      },
                      child: Container(
                        decoration: BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Browse Files ',
                              style: FlutterFlowTheme.of(context)
                                  .bodySmall
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).primary,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                            Icon(
                              Icons.file_upload_outlined,
                              color: FlutterFlowTheme.of(context).primary,
                              size: 20.0,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ].divide(SizedBox(width: 20.0)),
              ),
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 1,
                child: Semantics(
                  label:
                      'This is the description for the supported documents in this field.',
                  child: Text(
                    'Supported formats: .tiff, .pdf, .zip, .JPEG',
                    textAlign: TextAlign.start,
                    style: FlutterFlowTheme.of(context).bodySmall.override(
                          fontFamily: 'Source Sans 3',
                          color: Color(0xFF666666),
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Semantics(
                  label:
                      'This is the description for the maximum size of the document',
                  child: Text(
                    'Maximum Size: 5MB',
                    textAlign: TextAlign.end,
                    style: FlutterFlowTheme.of(context).bodySmall.override(
                          fontFamily: 'Source Sans 3',
                          color: Color(0xFF666666),
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ],
          ),
        ].divide(SizedBox(height: 4.0)),
      ),
    );
  }
}
