import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'file_download_widget.dart' show FileDownloadWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FileDownloadModel extends FlutterFlowModel<FileDownloadWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
