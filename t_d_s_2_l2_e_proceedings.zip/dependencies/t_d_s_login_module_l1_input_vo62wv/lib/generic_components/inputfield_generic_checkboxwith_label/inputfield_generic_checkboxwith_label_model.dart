import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'inputfield_generic_checkboxwith_label_widget.dart'
    show InputfieldGenericCheckboxwithLabelWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputfieldGenericCheckboxwithLabelModel
    extends FlutterFlowModel<InputfieldGenericCheckboxwithLabelWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Checkbox widget.
  bool? checkboxValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
