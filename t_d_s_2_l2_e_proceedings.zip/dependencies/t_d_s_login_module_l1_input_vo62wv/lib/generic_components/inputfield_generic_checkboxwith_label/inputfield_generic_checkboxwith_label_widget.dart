import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'inputfield_generic_checkboxwith_label_model.dart';
export 'inputfield_generic_checkboxwith_label_model.dart';

class InputfieldGenericCheckboxwithLabelWidget extends StatefulWidget {
  const InputfieldGenericCheckboxwithLabelWidget({
    super.key,
    required this.isMandatory,
    required this.keyPrefix,
    bool? checkBoxInitialValue,
    this.width,
    this.labelText,
    this.checkBoxAction,
    required this.errorMessage,
  }) : this.checkBoxInitialValue = checkBoxInitialValue ?? false;

  final bool? isMandatory;
  final String? keyPrefix;
  final bool checkBoxInitialValue;
  final double? width;
  final String? labelText;
  final Future Function()? checkBoxAction;
  final String? errorMessage;

  @override
  State<InputfieldGenericCheckboxwithLabelWidget> createState() =>
      _InputfieldGenericCheckboxwithLabelWidgetState();
}

class _InputfieldGenericCheckboxwithLabelWidgetState
    extends State<InputfieldGenericCheckboxwithLabelWidget> {
  late InputfieldGenericCheckboxwithLabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => InputfieldGenericCheckboxwithLabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 24.0,
                height: 24.0,
                decoration: BoxDecoration(),
                child: Theme(
                  data: ThemeData(
                    checkboxTheme: CheckboxThemeData(
                      visualDensity: VisualDensity.compact,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0),
                      ),
                    ),
                    unselectedWidgetColor:
                        FlutterFlowTheme.of(context).neutral700,
                  ),
                  child: Checkbox(
                    value: _model.checkboxValue ??=
                        widget!.checkBoxInitialValue,
                    onChanged: (newValue) async {
                      safeSetState(() => _model.checkboxValue = newValue!);
                      if (newValue!) {
                        await widget.checkBoxAction?.call();
                      } else {
                        await widget.checkBoxAction?.call();
                      }
                    },
                    side: BorderSide(
                      width: 2,
                      color: FlutterFlowTheme.of(context).neutral700,
                    ),
                    activeColor: FlutterFlowTheme.of(context).primary,
                    checkColor:
                        FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                ),
              ),
              Flexible(
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (widget!.isMandatory ?? true)
                      Text(
                        '* ',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color:
                                  FlutterFlowTheme.of(context).danger500Default,
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                    Flexible(
                      child: Text(
                        valueOrDefault<String>(
                          widget!.labelText,
                          'It is hereby declared that, the assessee has been regularly assessed to income-tax in India and has furnished the returns of income for all assessment years for which such returns became due on or before the date on which the application under sub-rule (1) of Rule 29B is made.',
                        ),
                        textAlign: TextAlign.start,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                              lineHeight: 1.5,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ].divide(SizedBox(width: 16.0)),
          ),
        ],
      ),
    );
  }
}
