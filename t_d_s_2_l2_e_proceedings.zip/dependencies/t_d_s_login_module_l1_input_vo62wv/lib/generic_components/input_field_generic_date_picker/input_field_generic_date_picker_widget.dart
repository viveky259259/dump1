import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/text_label_with_tooltip/text_label_with_tooltip_widget.dart';
import 'dart:ui';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_date_picker_model.dart';
export 'input_field_generic_date_picker_model.dart';

class InputFieldGenericDatePickerWidget extends StatefulWidget {
  const InputFieldGenericDatePickerWidget({
    super.key,
    this.hintText,
    this.labelText,
    this.width,
    this.maxLines,
    this.minLines,
    this.height,
    this.labelColor,
    this.hintColor,
    this.fontSize,
    required this.keyPrefix,
    this.showTooltip,
    this.tooltipMessage,
    bool? isMandatory,
    this.errorMessage,
    this.showErrorMessage,
    this.onInputValueChangeAction,
  }) : this.isMandatory = isMandatory ?? false;

  final String? hintText;
  final String? labelText;
  final double? width;
  final int? maxLines;
  final int? minLines;
  final double? height;
  final Color? labelColor;
  final Color? hintColor;
  final double? fontSize;
  final String? keyPrefix;
  final bool? showTooltip;
  final String? tooltipMessage;
  final bool isMandatory;
  final String? errorMessage;
  final bool? showErrorMessage;
  final Future Function()? onInputValueChangeAction;

  @override
  State<InputFieldGenericDatePickerWidget> createState() =>
      _InputFieldGenericDatePickerWidgetState();
}

class _InputFieldGenericDatePickerWidgetState
    extends State<InputFieldGenericDatePickerWidget> {
  late InputFieldGenericDatePickerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericDatePickerModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();
    _model.textFieldFocusNode!.addListener(() => safeSetState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          wrapWithModel(
            model: _model.textLabelWithTooltipModel,
            updateCallback: () => safeSetState(() {}),
            child: TextLabelWithTooltipWidget(
              labelText: widget!.labelText,
              isMandatory: widget!.isMandatory,
              fontSize: widget!.fontSize,
              labelColor: FlutterFlowTheme.of(context).primaryTxtClr,
              toolTipIconColor: FlutterFlowTheme.of(context).secondaryTxtClr,
              toolTipMessage: widget!.tooltipMessage,
              keyPrefix: widget!.keyPrefix!,
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await showModalBottomSheet<bool>(
                  context: context,
                  builder: (context) {
                    return ScrollConfiguration(
                      behavior: const MaterialScrollBehavior().copyWith(
                        dragDevices: {
                          PointerDeviceKind.mouse,
                          PointerDeviceKind.touch,
                          PointerDeviceKind.stylus,
                          PointerDeviceKind.unknown
                        },
                      ),
                      child: Container(
                        height: MediaQuery.of(context).size.height / 3,
                        width: MediaQuery.of(context).size.width,
                        child: CupertinoDatePicker(
                          mode: CupertinoDatePickerMode.date,
                          minimumDate: (DateTime.fromMicrosecondsSinceEpoch(
                                  943986600000000) ??
                              DateTime(1900)),
                          initialDateTime: getCurrentTimestamp,
                          maximumDate: (DateTime.fromMicrosecondsSinceEpoch(
                                  2240505000000000) ??
                              DateTime(2050)),
                          use24hFormat: false,
                          onDateTimeChanged: (newDateTime) => safeSetState(() {
                            _model.datePicked = newDateTime;
                          }),
                        ),
                      ),
                    );
                  });
            },
            child: Container(
              height: widget!.height,
              decoration: BoxDecoration(),
              child: Container(
                width: widget!.width,
                child: TextFormField(
                  controller: _model.textController,
                  focusNode: _model.textFieldFocusNode,
                  onChanged: (_) => EasyDebounce.debounce(
                    '_model.textController',
                    Duration(milliseconds: 500),
                    () => safeSetState(() {}),
                  ),
                  autofocus: false,
                  obscureText: false,
                  decoration: InputDecoration(
                    isDense: true,
                    labelStyle:
                        FlutterFlowTheme.of(context).labelMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                    hintText: widget!.hintText,
                    hintStyle:
                        FlutterFlowTheme.of(context).labelMedium.override(
                              fontFamily: 'Inter',
                              color: widget!.hintColor,
                              fontSize: widget!.fontSize,
                              letterSpacing: 0.0,
                            ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color:
                            FlutterFlowTheme.of(context).textFieldBorderColor,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Color(0x00000000),
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).error,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).error,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                    filled: true,
                    fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                    suffixIcon: Icon(
                      Icons.calendar_today_rounded,
                    ),
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: widget!.hintColor,
                        fontSize: widget!.fontSize,
                        letterSpacing: 0.0,
                      ),
                  keyboardType: TextInputType.datetime,
                  cursorColor: FlutterFlowTheme.of(context).primaryText,
                  validator:
                      _model.textControllerValidator.asValidator(context),
                ),
              ),
            ),
          ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
