import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/text_label_with_tooltip/text_label_with_tooltip_widget.dart';
import 'dart:ui';
import 'input_field_generic_date_picker_widget.dart'
    show InputFieldGenericDatePickerWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericDatePickerModel
    extends FlutterFlowModel<InputFieldGenericDatePickerWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Text_Label_With_Tooltip component.
  late TextLabelWithTooltipModel textLabelWithTooltipModel;
  DateTime? datePicked;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {
    textLabelWithTooltipModel =
        createModel(context, () => TextLabelWithTooltipModel());
  }

  @override
  void dispose() {
    textLabelWithTooltipModel.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
