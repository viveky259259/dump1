import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'input_field_generic_language_selector_dropdown_widget.dart'
    show InputFieldGenericLanguageSelectorDropdownWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericLanguageSelectorDropdownModel
    extends FlutterFlowModel<InputFieldGenericLanguageSelectorDropdownWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for LanguageDropDown widget.
  String? languageDropDownValue;
  FormFieldController<String>? languageDropDownValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
