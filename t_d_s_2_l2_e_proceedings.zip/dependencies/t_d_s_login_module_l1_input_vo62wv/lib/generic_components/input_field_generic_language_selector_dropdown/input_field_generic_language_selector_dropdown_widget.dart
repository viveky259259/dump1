import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_language_selector_dropdown_model.dart';
export 'input_field_generic_language_selector_dropdown_model.dart';

/// "A versatile Dropdown component designed for language Selector dropdown
/// needs.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the dropdown field, displayed at the top. Defaults to
/// 'Label'.
///
/// - **hintText**: `String`
///   Placeholder text shown inside the Dropdown field to guide the user.
///
/// - **dropdownOptions**: 'List<String>'
///   List of options present in dropdown
///
/// - **initialSelectedField** : 'String'
///    specific initial value which is their in dropdown
///
/// - **isSearchable**: `bool`
///   specific whether the dropdown is searchable or not.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   labelText: 'Select Language',
///   dropdownOptions: ['English', 'Hindi'],
///   initialSelectedvalue : English
///   hintText: 'Select Language',
///   isSearchable: true,
/// )"
class InputFieldGenericLanguageSelectorDropdownWidget extends StatefulWidget {
  const InputFieldGenericLanguageSelectorDropdownWidget({
    super.key,
    required this.keyPrefix,
    required this.onSelect,
    this.height,
    this.width,
    this.heightLanguageDropDown,
    this.widthLanguageDropDown,
    this.fontSizeText,
    this.iconSizeLanguageIcon,
    this.menuElevation,
    this.dropDownBorderRadius,
    this.iconSizeDropDown,
    this.dropDownBorderWidth,
  });

  final String? keyPrefix;
  final Future Function()? onSelect;
  final double? height;
  final double? width;
  final double? heightLanguageDropDown;
  final double? widthLanguageDropDown;
  final int? fontSizeText;
  final int? iconSizeLanguageIcon;
  final int? menuElevation;
  final double? dropDownBorderRadius;
  final double? iconSizeDropDown;
  final double? dropDownBorderWidth;

  @override
  State<InputFieldGenericLanguageSelectorDropdownWidget> createState() =>
      _InputFieldGenericLanguageSelectorDropdownWidgetState();
}

class _InputFieldGenericLanguageSelectorDropdownWidgetState
    extends State<InputFieldGenericLanguageSelectorDropdownWidget> {
  late InputFieldGenericLanguageSelectorDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => InputFieldGenericLanguageSelectorDropdownModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(),
      child: Semantics(
        label:
            'Language Selector: Dropdown to switch between different languages(e.g., \"English\",\"Hindi\")',
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'InputField_Generic_LanguageSelectorDropdown',
                      'LanguageIcon')),
              Icons.language,
              color: FlutterFlowTheme.of(context).primary,
              size: widget!.iconSizeLanguageIcon?.toDouble(),
            ),
            FlutterFlowDropDown<String>(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'InputField_Generic_LanguageSelectorDropdown',
                      'LanguageDropDown')),
              controller: _model.languageDropDownValueController ??=
                  FormFieldController<String>(
                _model.languageDropDownValue ??= 'English',
              ),
              options: ['English', 'Hindi'],
              onChanged: (val) async {
                safeSetState(() => _model.languageDropDownValue = val);
                await widget.onSelect?.call();
              },
              width: widget!.widthLanguageDropDown,
              height: widget!.heightLanguageDropDown,
              textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).primaryHyperlinkTxtClr,
                    fontSize: widget!.fontSizeText?.toDouble(),
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.w500,
                  ),
              hintText: 'Select',
              icon: Icon(
                Icons.keyboard_arrow_down_rounded,
                color: FlutterFlowTheme.of(context).primaryHyperlinkTxtClr,
                size: widget!.iconSizeDropDown,
              ),
              elevation: widget!.menuElevation!.toDouble(),
              borderColor: Colors.transparent,
              borderWidth: widget!.dropDownBorderWidth!,
              borderRadius: widget!.dropDownBorderRadius!,
              margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
              hidesUnderline: true,
              isOverButton: false,
              isSearchable: false,
              isMultiSelect: false,
            ),
          ],
        ),
      ),
    );
  }
}
