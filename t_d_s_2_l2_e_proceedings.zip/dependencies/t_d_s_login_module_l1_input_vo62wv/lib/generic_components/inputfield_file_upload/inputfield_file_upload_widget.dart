import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'inputfield_file_upload_model.dart';
export 'inputfield_file_upload_model.dart';

class InputfieldFileUploadWidget extends StatefulWidget {
  const InputfieldFileUploadWidget({
    super.key,
    this.supportedFormats,
    this.maxFileSize,
    this.height,
    this.width,
    this.onTapBrowseFiles,
    required this.keyPrefix,
  });

  final String? supportedFormats;
  final String? maxFileSize;
  final double? height;
  final double? width;
  final Future Function()? onTapBrowseFiles;
  final String? keyPrefix;

  @override
  State<InputfieldFileUploadWidget> createState() =>
      _InputfieldFileUploadWidgetState();
}

class _InputfieldFileUploadWidgetState
    extends State<InputfieldFileUploadWidget> {
  late InputfieldFileUploadModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputfieldFileUploadModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'A versatile input component for file upload',
      child: Container(
        decoration: BoxDecoration(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Upload File',
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).primaryText,
                    letterSpacing: 0.0,
                  ),
            ),
            Container(
              width: widget!.width,
              height: widget!.height,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
                borderRadius: BorderRadius.circular(4.0),
                border: Border.all(
                  color: FlutterFlowTheme.of(context).uploadFileContainerBorder,
                  width: 1.0,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.all(6.0),
                    child: Container(
                      width: 36.0,
                      height: 36.0,
                      decoration: BoxDecoration(
                        color: Color(0xFFF4F5F5),
                        borderRadius: BorderRadius.circular(4.0),
                      ),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Inputfield_File_Upload', 'Icon')),
                          Icons.cloud_upload_outlined,
                          color: FlutterFlowTheme.of(context).uploadIconClr,
                          size: 24.0,
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                    child: Text(
                      'Drag & Drop or ',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color:
                                FlutterFlowTheme.of(context).uploadFileTextClr,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                    child: InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTapBrowseFiles?.call();
                      },
                      child: Text(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Inputfield_File_Upload',
                                'Browse_File_Hyperlink')),
                        'Browse Files',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context)
                                  .hyperlinkBtnIconClr,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Wrap(
              spacing: 0.0,
              runSpacing: 0.0,
              alignment: WrapAlignment.start,
              crossAxisAlignment: WrapCrossAlignment.start,
              direction: Axis.horizontal,
              runAlignment: WrapAlignment.start,
              verticalDirection: VerticalDirection.down,
              clipBehavior: Clip.none,
              children: [
                RichText(
                  textScaler: MediaQuery.of(context).textScaler,
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Inputfield_File_Upload',
                          'RichText')),
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'Supported formats: ',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: Color(0xFF61646B),
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                      ),
                      TextSpan(
                        text: valueOrDefault<String>(
                          widget!.supportedFormats,
                          '.csv',
                        ),
                        style: TextStyle(),
                      )
                    ],
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).uploadFileTextClr,
                          fontSize: 12.0,
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
                RichText(
                  textScaler: MediaQuery.of(context).textScaler,
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Inputfield_File_Upload',
                          'RichText')),
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'Max. File Size: ',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: Color(0xFF61646B),
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                      ),
                      TextSpan(
                        text: valueOrDefault<String>(
                          widget!.maxFileSize,
                          '20MB',
                        ),
                        style: TextStyle(),
                      )
                    ],
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).uploadFileTextClr,
                          fontSize: 12.0,
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ],
            ),
          ].divide(SizedBox(height: 8.0)),
        ),
      ),
    );
  }
}
