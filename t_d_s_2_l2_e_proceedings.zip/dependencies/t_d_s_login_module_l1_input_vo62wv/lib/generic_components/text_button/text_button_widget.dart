import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'text_button_model.dart';
export 'text_button_model.dart';

class TextButtonWidget extends StatefulWidget {
  const TextButtonWidget({
    super.key,
    this.label,
    Color? textColour,
    this.onTap,
    required this.keyPrefix,
  }) : this.textColour = textColour ?? const Color(0xFF076BCF);

  final String? label;
  final Color textColour;
  final Future Function()? onTap;
  final String? keyPrefix;

  @override
  State<TextButtonWidget> createState() => _TextButtonWidgetState();
}

class _TextButtonWidgetState extends State<TextButtonWidget> {
  late TextButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TextButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        await widget.onTap?.call();
      },
      child: Text(
        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
            widget!.keyPrefix!, 'Text_Button', 'Text')),
        widget!.label!,
        style: FlutterFlowTheme.of(context).bodySmall.override(
              fontFamily: 'Inter',
              color: valueOrDefault<Color>(
                widget!.textColour,
                FlutterFlowTheme.of(context).secondaryInfo500Default,
              ),
              fontSize: 14.0,
              letterSpacing: 0.0,
            ),
      ),
    );
  }
}
