import '/components/chip_dropdownlist_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'chip_dropdown_model.dart';
export 'chip_dropdown_model.dart';

///  A custom widget that presents a dropdown-style selection with a chip UI.
///
///
///
/// This widget allows the user to select an option from a list of options.
/// The selected option is
///  displayed within a chip-like container, and upon tapping, a dropdown menu
/// is shown. The widget
///  supports customization through the `keyPrefix`, `labelName`, and
/// `optionList` properties.
///
///  State Variables:
///  - `_model`: An instance of `ChipDropdownModel` that manages the internal
/// state of the dropdown,
///    including tracking the selected option.
///
/// Properties:
///  - `keyPrefix`: A prefix key used for uniquely identifying widget
/// components (optional).
///  - `labelName`: A label that can be used for identifying the dropdown
/// widget (optional).
///  - `optionList`: A list of string options that are available for selection
/// in the dropdown (required).
///
/// When an option is selected, the widget updates the selected option and
/// closes the dropdown.
class ChipDropdownWidget extends StatefulWidget {
  const ChipDropdownWidget({
    super.key,
    required this.keyPrefix,
    required this.labelName,
    required this.optionList,
  });

  final String? keyPrefix;
  final String? labelName;
  final List<String>? optionList;

  @override
  State<ChipDropdownWidget> createState() => _ChipDropdownWidgetState();
}

class _ChipDropdownWidgetState extends State<ChipDropdownWidget> {
  late ChipDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChipDropdownModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.selectedOption = widget!.optionList!.firstOrNull!;
      safeSetState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32.0,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            blurRadius: 8.0,
            color: Color(0x0000000F),
            offset: Offset(
              0.0,
              4.0,
            ),
            spreadRadius: 0.0,
          )
        ],
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: Color(0xFFB6B6B6),
          width: 0.5,
        ),
      ),
      child: Builder(
        builder: (context) => InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            await showAlignedDialog(
              barrierColor: Colors.transparent,
              context: context,
              isGlobal: false,
              avoidOverflow: false,
              targetAnchor: AlignmentDirectional(1.0, 1.0)
                  .resolve(Directionality.of(context)),
              followerAnchor: AlignmentDirectional(1.0, -1.0)
                  .resolve(Directionality.of(context)),
              builder: (dialogContext) {
                return Material(
                  color: Colors.transparent,
                  child: ChipDropdownlistWidget(
                    keyPrefix: 'ntg',
                    noOfOptions: widget!.optionList!,
                    onSelect: (selectedVal) async {
                      _model.selectedOption = selectedVal;
                      safeSetState(() {});
                    },
                  ),
                );
              },
            );
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(12.0, 9.0, 0.0, 9.0),
                child: Text(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!, 'ChipDropdown', 'titleText')),
                  _model.selectedOption,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Roboto',
                        color: Color(0xFF080871),
                        fontSize: 12.0,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(4.0, 8.0, 8.0, 8.0),
                child: Icon(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!, 'ChipDropdown', 'icon')),
                  Icons.keyboard_arrow_down,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 16.0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
