import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'chip_dropdownlist_model.dart';
export 'chip_dropdownlist_model.dart';

/// A custom widget that displays a list of options as chips in a
/// dropdown-style interface.
///
///
/// This widget allows the user to select an option from a list of strings.
/// When an option is tapped,
///  the `onSelect` callback is invoked with the selected value. The widget
/// also supports customization
/// of the appearance and layout via parameters such as `keyPrefix` and
/// `noOfOptions`.
///
///  State Variables:
///  `_model`: An instance of `ChipDropdownlistModel` that manages the
/// internal state of the dropdown list.
///  Properties:
/// `keyPrefix`: A prefix key used for unique identification of widget
/// components (optional).
/// - `noOfOptions`: A list of string options displayed in the dropdown. Each
/// option is rendered as a chip (required).
/// `onSelect`: A callback function triggered when an option is selected from
/// the dropdown. It receives the selected.
/// value as a parameter and is expected to be an async function that handles
/// the selected value (optional).
class ChipDropdownlistWidget extends StatefulWidget {
  const ChipDropdownlistWidget({
    super.key,
    required this.keyPrefix,
    required this.noOfOptions,
    required this.onSelect,
  });

  final String? keyPrefix;
  final List<String>? noOfOptions;
  final Future Function(String selectedVal)? onSelect;

  @override
  State<ChipDropdownlistWidget> createState() => _ChipDropdownlistWidgetState();
}

class _ChipDropdownlistWidgetState extends State<ChipDropdownlistWidget> {
  late ChipDropdownlistModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChipDropdownlistModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(12.0, 9.0, 9.0, 9.0),
        child: Builder(
          builder: (context) {
            final dropDownList = widget!.noOfOptions!.toList();

            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: List.generate(dropDownList.length, (dropDownListIndex) {
                final dropDownListItem = dropDownList[dropDownListIndex];
                return InkWell(
                  splashColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () async {
                    await widget.onSelect?.call(
                      dropDownListItem,
                    );
                    Navigator.pop(context);
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'ChipDropdownlist', 'Text')),
                        dropDownListItem,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF080871),
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ],
                  ),
                );
              }).divide(SizedBox(height: 5.0)),
            );
          },
        ),
      ),
    );
  }
}
