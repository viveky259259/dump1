import '/flutter_flow/flutter_flow_util.dart';
import 'delete_this_comp_after_addding_widget.dart'
    show DeleteThisCompAfterAdddingWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DeleteThisCompAfterAdddingModel
    extends FlutterFlowModel<DeleteThisCompAfterAdddingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
