// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_quill/flutter_quill.dart';

/// NOTE: When you render this widget
/// You need to make sure that you add the FlutterQuillLocalizations.delegate, in the main.dar
/// If you don't do so you will see error screen

class WordEditor extends StatefulWidget {
  const WordEditor({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<WordEditor> createState() => _WordEditorState();
}

class _WordEditorState extends State<WordEditor> {
  final QuillController _controller = QuillController.basic();
  final FocusNode _editorFocusNode = FocusNode();
  final ValueNotifier<bool> _isToolbarUpdated = ValueNotifier<bool>(false);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _controller.changes.listen((event) {
      if (event.source == ChangeSource.local) {
        _isToolbarUpdated.value = !_isToolbarUpdated.value; // Trigger UI update
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  void toggleAttribute(Attribute attribute) {
    var currentStyle = _controller.getSelectionStyle();
    if (currentStyle.containsKey(attribute.key)) {
      _controller.formatSelection(
          Attribute.clone(attribute, null)); // Remove formatting
    } else {
      _controller.formatSelection(attribute); // Apply formatting
    }
    _isToolbarUpdated.value = !_isToolbarUpdated.value; // Update UI
  }

  bool isAttributeActive(Attribute attribute) {
    var currentStyle = _controller.getSelectionStyle();
    return currentStyle.containsKey(attribute.key);
  }

  Widget _buildToolbarButton(IconData icon, Attribute attribute) {
    return IconButton(
      icon: Icon(icon,
          color: isAttributeActive(attribute) ? Colors.blue : Colors.black),
      onPressed: () => toggleAttribute(attribute),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ValueListenableBuilder(
          valueListenable: _isToolbarUpdated,
          builder: (context, _, __) {
            return Container(
              decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    color: FlutterFlowTheme.of(context).neutral300,
                    width: 1.0,
                  ),
                  right: BorderSide(
                    color: FlutterFlowTheme.of(context).neutral300,
                    width: 1.0,
                  ),
                  top: BorderSide(
                    color: Color(0xFFDFE0E2),
                    width: 1.0,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _buildToolbarButton(Icons.format_bold, Attribute.bold),
                  _buildToolbarButton(Icons.format_italic, Attribute.italic),
                  _buildToolbarButton(
                      Icons.format_underline, Attribute.underline),
                  _buildToolbarButton(
                      Icons.format_strikethrough, Attribute.strikeThrough),
                  _buildToolbarButton(Icons.format_list_bulleted, Attribute.ul),
                  _buildToolbarButton(Icons.format_list_numbered, Attribute.ol),
                  _buildToolbarButton(Icons.format_quote, Attribute.blockQuote),
                ],
              ),
            );
          },
        ),
        GestureDetector(
          onTap: () {
            _editorFocusNode.requestFocus();
          },
          child: Container(
            height: widget.height ?? 300,
            decoration: BoxDecoration(
                border: Border(
                  left: BorderSide(
                    color: FlutterFlowTheme.of(context).neutral300,
                    width: 1.0,
                  ),
                  right: BorderSide(
                    color: FlutterFlowTheme.of(context).neutral300,
                    width: 1.0,
                  ),
                  bottom: BorderSide(
                    color: Color(0xFFDFE0E2),
                    width: 1.0,
                  ),
                ),
                color: FlutterFlowTheme.of(context).secondaryInfoBGStroke10),
            child: QuillEditor.basic(
              controller: _controller,
              scrollController: ScrollController(),
              focusNode: _editorFocusNode,
            ),
          ),
        ),
      ],
    );
  }
}
