import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const List<String> ListOfProfiles = [
    'Deductor',
    'TaxPayer',
    'PAO',
    'DAO'
  ];
  static const List<String> ListOfToggles = [
    'LDC/NDC',
    'Demand',
    'Prosecution',
    'Collection'
  ];
}
