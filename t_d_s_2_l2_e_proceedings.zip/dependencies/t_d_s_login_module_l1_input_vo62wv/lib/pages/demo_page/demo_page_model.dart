import '/components/chip_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'demo_page_widget.dart' show DemoPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DemoPageModel extends FlutterFlowModel<DemoPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for InputField_Generic_LabelText component.
  late InputFieldGenericLabelTextModel inputFieldGenericLabelTextModel1;
  // Model for InputField_Generic_LabelText component.
  late InputFieldGenericLabelTextModel inputFieldGenericLabelTextModel2;
  // Model for ChipDropdown component.
  late ChipDropdownModel chipDropdownModel;

  @override
  void initState(BuildContext context) {
    inputFieldGenericLabelTextModel1 =
        createModel(context, () => InputFieldGenericLabelTextModel());
    inputFieldGenericLabelTextModel2 =
        createModel(context, () => InputFieldGenericLabelTextModel());
    chipDropdownModel = createModel(context, () => ChipDropdownModel());
  }

  @override
  void dispose() {
    inputFieldGenericLabelTextModel1.dispose();
    inputFieldGenericLabelTextModel2.dispose();
    chipDropdownModel.dispose();
  }
}
