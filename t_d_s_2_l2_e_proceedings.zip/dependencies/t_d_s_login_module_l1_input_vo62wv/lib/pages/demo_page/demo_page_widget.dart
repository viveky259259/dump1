import '/components/chip_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'demo_page_model.dart';
export 'demo_page_model.dart';

class DemoPageWidget extends StatefulWidget {
  const DemoPageWidget({super.key});

  @override
  State<DemoPageWidget> createState() => _DemoPageWidgetState();
}

class _DemoPageWidgetState extends State<DemoPageWidget> {
  late DemoPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DemoPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.inputFieldGenericLabelTextModel1,
                updateCallback: () => safeSetState(() {}),
                child: InputFieldGenericLabelTextWidget(
                  labelText: 'PAN Number ',
                  isMandatory: false,
                  keyPrefix: 'key',
                ),
              ),
              wrapWithModel(
                model: _model.inputFieldGenericLabelTextModel2,
                updateCallback: () => safeSetState(() {}),
                child: InputFieldGenericLabelTextWidget(
                  labelText: 'First Name',
                  isMandatory: false,
                  keyPrefix: 'ajgnl',
                ),
              ),
              wrapWithModel(
                model: _model.chipDropdownModel,
                updateCallback: () => safeSetState(() {}),
                child: ChipDropdownWidget(
                  keyPrefix: 'ntg',
                  labelName: 'Year | Q1',
                  optionList: ["Year Q1", "Year Q2", "Year Q3", "Year Q4"],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
