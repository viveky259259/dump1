import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart';
import '/radio_buttons/toggle_switch/toggle_switch_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'home_page_model.dart';
export 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({super.key});

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  late HomePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomePageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              wrapWithModel(
                model: _model.toggleSwitchModel,
                updateCallback: () => safeSetState(() {}),
                child: ToggleSwitchWidget(
                  keyPrefix: 'iii',
                  activeInger: 1,
                  onClick: () async {},
                ),
              ),
              wrapWithModel(
                model: _model.inputfieldFileUploadBrowseFilesModel,
                updateCallback: () => safeSetState(() {}),
                updateOnChange: true,
                child: InputfieldFileUploadBrowseFilesWidget(
                  maxFileSize: '5MB',
                  keyPrefix: 'keyprefix',
                  isDisable: false,
                  format: 'jpg pdf jpeg png',
                  onTapBrowseFiles: () async {},
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
