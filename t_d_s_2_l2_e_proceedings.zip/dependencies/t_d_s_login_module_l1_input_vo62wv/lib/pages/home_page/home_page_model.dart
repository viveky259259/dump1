import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/file_upload/inputfield_file_upload_browse_files/inputfield_file_upload_browse_files_widget.dart';
import '/radio_buttons/toggle_switch/toggle_switch_widget.dart';
import 'dart:ui';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Toggle_Switch component.
  late ToggleSwitchModel toggleSwitchModel;
  // Model for Inputfield_File_Upload_BrowseFiles component.
  late InputfieldFileUploadBrowseFilesModel
      inputfieldFileUploadBrowseFilesModel;

  @override
  void initState(BuildContext context) {
    toggleSwitchModel = createModel(context, () => ToggleSwitchModel());
    inputfieldFileUploadBrowseFilesModel =
        createModel(context, () => InputfieldFileUploadBrowseFilesModel());
  }

  @override
  void dispose() {
    toggleSwitchModel.dispose();
    inputfieldFileUploadBrowseFilesModel.dispose();
  }
}
