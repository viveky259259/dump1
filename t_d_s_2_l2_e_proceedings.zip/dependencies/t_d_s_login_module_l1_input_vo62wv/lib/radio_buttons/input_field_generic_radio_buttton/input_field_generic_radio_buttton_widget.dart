import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_radio_buttton_model.dart';
export 'input_field_generic_radio_buttton_model.dart';

class InputFieldGenericRadioButttonWidget extends StatefulWidget {
  const InputFieldGenericRadioButttonWidget({
    super.key,
    required this.labelText,
    required this.keyPrefix,
    required this.options,
    bool? isMandatory,
    bool? isVertical,
    this.radioButtonSelection,
    this.initialOption,
  })  : this.isMandatory = isMandatory ?? false,
        this.isVertical = isVertical ?? false;

  final String? labelText;
  final String? keyPrefix;
  final List<String>? options;
  final bool isMandatory;
  final bool isVertical;
  final Future Function(String selectedOption)? radioButtonSelection;
  final String? initialOption;

  @override
  State<InputFieldGenericRadioButttonWidget> createState() =>
      _InputFieldGenericRadioButttonWidgetState();
}

class _InputFieldGenericRadioButttonWidgetState
    extends State<InputFieldGenericRadioButttonWidget> {
  late InputFieldGenericRadioButttonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericRadioButttonModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (widget!.initialOption != null && widget!.initialOption != '') {
        _model.selectedOption = widget!.initialOption;
        safeSetState(() {});
        return;
      } else {
        return;
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 0.0, 0.0, 0.0),
            child: Semantics(
              label:
                  'This is the label component with mandatory icon for the text.',
              child: wrapWithModel(
                model: _model.inputFieldGenericLabelTextModel,
                updateCallback: () => safeSetState(() {}),
                child: InputFieldGenericLabelTextWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'InputField_Radio',
                          'InputField_Generic_LabelText')),
                  labelText: widget!.labelText!,
                  isMandatory: widget!.isMandatory,
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'InputField_Generic_RadioButtton',
                          'InputField_Generic_LabelText'),
                ),
              ),
            ),
          ),
          Builder(
            builder: (context) {
              if (widget!.isVertical) {
                return Semantics(
                  label:
                      'This is the radio button used for selecting one of the many options.',
                  child: FlutterFlowRadioButton(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'InputField_Generic_RadioButtton',
                            'VerticalRadioButton')),
                    options: widget!.options!.toList(),
                    onChanged: (val) async {
                      safeSetState(() {});
                      _model.selectedOption = _model.verticalRadioButtonValue;
                      safeSetState(() {});
                      await widget.radioButtonSelection?.call(
                        _model.selectedOption!,
                      );
                    },
                    controller: _model.verticalRadioButtonValueController ??=
                        FormFieldController<String>(widget!.initialOption!),
                    optionHeight: 28.0,
                    textStyle:
                        FlutterFlowTheme.of(context).labelMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                    selectedTextStyle:
                        FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).primaryTxtClr,
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                    buttonPosition: RadioButtonPosition.left,
                    direction: Axis.vertical,
                    radioButtonColor:
                        FlutterFlowTheme.of(context).formTxtBtnClr,
                    inactiveRadioButtonColor:
                        FlutterFlowTheme.of(context).neutral700,
                    toggleable: false,
                    horizontalAlignment: WrapAlignment.start,
                    verticalAlignment: WrapCrossAlignment.start,
                  ),
                );
              } else {
                return Semantics(
                  label:
                      'This is the radio button used for selecting one of the many options.',
                  child: FlutterFlowRadioButton(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'InputField_Generic_RadioButtton',
                            'HorizontalRadioButton')),
                    options: widget!.options!.toList(),
                    onChanged: (val) async {
                      safeSetState(() {});
                      _model.selectedOption = _model.horizontalRadioButtonValue;
                      safeSetState(() {});
                      await widget.radioButtonSelection?.call(
                        _model.selectedOption!,
                      );
                    },
                    controller: _model.horizontalRadioButtonValueController ??=
                        FormFieldController<String>(widget!.initialOption!),
                    optionHeight: 18.0,
                    textStyle:
                        FlutterFlowTheme.of(context).labelMedium.override(
                              fontFamily: 'Inter',
                              letterSpacing: 0.0,
                            ),
                    selectedTextStyle:
                        FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).primaryTxtClr,
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                    textPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 28.0, 0.0),
                    buttonPosition: RadioButtonPosition.left,
                    direction: Axis.horizontal,
                    radioButtonColor:
                        FlutterFlowTheme.of(context).formTxtBtnClr,
                    inactiveRadioButtonColor:
                        FlutterFlowTheme.of(context).neutral700,
                    toggleable: false,
                    horizontalAlignment: WrapAlignment.start,
                    verticalAlignment: WrapCrossAlignment.start,
                  ),
                );
              }
            },
          ),
        ].divide(SizedBox(height: 12.0)),
      ),
    );
  }
}
