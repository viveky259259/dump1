import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'toggle_switch_widget.dart' show ToggleSwitchWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ToggleSwitchModel extends FlutterFlowModel<ToggleSwitchWidget> {
  ///  Local state fields for this component.

  int? activeState = 1;

  bool switchStatus = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
