import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'toggle_switch_model.dart';
export 'toggle_switch_model.dart';

/// /// A widget that represents a switchable radio component.
///
///
/// ///
/// /// This widget allows users to toggle between different states .///
/// /// State Variables:
/// /// - `_isSelected`: A boolean that indicates whether the chip is
/// currently selected or not.
class ToggleSwitchWidget extends StatefulWidget {
  const ToggleSwitchWidget({
    super.key,
    required this.keyPrefix,
    required this.activeInger,
    required this.onClick,
  });

  final String? keyPrefix;
  final int? activeInger;
  final Future Function()? onClick;

  @override
  State<ToggleSwitchWidget> createState() => _ToggleSwitchWidgetState();
}

class _ToggleSwitchWidgetState extends State<ToggleSwitchWidget> {
  late ToggleSwitchModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ToggleSwitchModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40.0,
      height: 20.0,
      decoration: BoxDecoration(
        color: _model.activeState == 0
            ? FlutterFlowTheme.of(context).secondaryInfo500Default
            : FlutterFlowTheme.of(context).neutral300,
        borderRadius: BorderRadius.circular(50.0),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await widget.onClick?.call();
              _model.activeState = 1;
              _model.switchStatus = true;
              safeSetState(() {});
            },
            child: Container(
              width: 18.0,
              height: 18.0,
              decoration: BoxDecoration(
                color: _model.activeState == 0
                    ? FlutterFlowTheme.of(context).secondaryInfo500Default
                    : FlutterFlowTheme.of(context).secondaryBackground,
                shape: BoxShape.circle,
              ),
              alignment: AlignmentDirectional(0.0, 0.0),
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await widget.onClick?.call();
              _model.activeState = 0;
              _model.switchStatus = false;
              safeSetState(() {});
            },
            child: Container(
              width: 18.0,
              height: 18.0,
              decoration: BoxDecoration(
                color: _model.activeState == 1
                    ? FlutterFlowTheme.of(context).neutral300
                    : FlutterFlowTheme.of(context).secondaryBackground,
                shape: BoxShape.circle,
              ),
              alignment: AlignmentDirectional(0.0, 0.0),
            ),
          ),
        ].divide(SizedBox(width: 4.0)),
      ),
    );
  }
}
