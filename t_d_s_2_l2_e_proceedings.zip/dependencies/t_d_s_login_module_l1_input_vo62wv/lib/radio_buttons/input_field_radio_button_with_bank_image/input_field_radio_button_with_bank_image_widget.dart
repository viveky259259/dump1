import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_radio_button_with_bank_image_model.dart';
export 'input_field_radio_button_with_bank_image_model.dart';

class InputFieldRadioButtonWithBankImageWidget extends StatefulWidget {
  const InputFieldRadioButtonWithBankImageWidget({
    super.key,
    required this.keyPrefix,
    bool? isSelected,
    this.width,
    this.height,
    required this.bankLogoImage,
  }) : this.isSelected = isSelected ?? false;

  final String? keyPrefix;
  final bool isSelected;
  final double? width;
  final double? height;
  final String? bankLogoImage;

  @override
  State<InputFieldRadioButtonWithBankImageWidget> createState() =>
      _InputFieldRadioButtonWithBankImageWidgetState();
}

class _InputFieldRadioButtonWithBankImageWidgetState
    extends State<InputFieldRadioButtonWithBankImageWidget> {
  late InputFieldRadioButtonWithBankImageModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => InputFieldRadioButtonWithBankImageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Container(
          width: widget!.width,
          height: widget!.height,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).transactionDetailsContainerBg,
            borderRadius: BorderRadius.circular(4.0),
            border: Border.all(
              color: FlutterFlowTheme.of(context).modeOfOTPBorderClr,
              width: 1.0,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Semantics(
                label:
                    'This is the icon shown when any of the option is selected.',
                child: Icon(
                  Icons.radio_button_checked,
                  color: FlutterFlowTheme.of(context).hyperlinkBtnIconClr,
                  size: 24.0,
                ),
              ),
              Semantics(
                label: 'This is the icon shown when no option is selected.',
                child: Icon(
                  Icons.radio_button_off,
                  color: FlutterFlowTheme.of(context).unSelectedRadioBtnColor,
                  size: 24.0,
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 14.0, 0.0, 14.0),
                child: Image.asset(
                  'dependencies/t_d_s_login_module_l1_input_vo62wv/assets/images/Screenshot_2025-01-09_141116.png',
                  fit: BoxFit.cover,
                ),
              ),
            ].divide(SizedBox(width: 16.0)).addToStart(SizedBox(width: 20.0)),
          ),
        ),
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Builder(
              builder: (context) {
                if (widget!.isSelected) {
                  return Container(
                    width: widget!.width,
                    height: widget!.height,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).primaryBGStroke15,
                      borderRadius: BorderRadius.circular(4.0),
                      border: Border.all(
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Semantics(
                          label:
                              'This is the icon shown when any of the option is selected.',
                          child: Icon(
                            Icons.radio_button_checked,
                            color: FlutterFlowTheme.of(context)
                                .secondaryInfo500Default,
                            size: 24.0,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 14.0, 0.0, 14.0),
                          child: Image.asset(
                            'dependencies/t_d_s_login_module_l1_input_vo62wv/assets/images/Screenshot_2025-01-09_141116.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ]
                          .divide(SizedBox(width: 16.0))
                          .addToStart(SizedBox(width: 20.0)),
                    ),
                  );
                } else {
                  return Container(
                    width: widget!.width,
                    height: widget!.height,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context)
                          .transactionDetailsContainerBg,
                      borderRadius: BorderRadius.circular(4.0),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).modeOfOTPBorderClr,
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Semantics(
                          label:
                              'This is the icon shown when no option is selected.',
                          child: Icon(
                            Icons.radio_button_off,
                            color: FlutterFlowTheme.of(context)
                                .unSelectedRadioBtnColor,
                            size: 24.0,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 14.0, 0.0, 14.0),
                          child: Image.asset(
                            'dependencies/t_d_s_login_module_l1_input_vo62wv/assets/images/Screenshot_2025-01-09_141116.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ]
                          .divide(SizedBox(width: 16.0))
                          .addToStart(SizedBox(width: 20.0)),
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}
