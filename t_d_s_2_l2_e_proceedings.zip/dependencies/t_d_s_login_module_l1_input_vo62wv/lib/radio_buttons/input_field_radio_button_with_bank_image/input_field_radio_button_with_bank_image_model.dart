import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'input_field_radio_button_with_bank_image_widget.dart'
    show InputFieldRadioButtonWithBankImageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldRadioButtonWithBankImageModel
    extends FlutterFlowModel<InputFieldRadioButtonWithBankImageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
