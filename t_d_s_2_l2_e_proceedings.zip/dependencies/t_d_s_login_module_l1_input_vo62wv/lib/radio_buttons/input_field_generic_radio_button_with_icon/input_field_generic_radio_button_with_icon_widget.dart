import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_radio_button_with_icon_model.dart';
export 'input_field_generic_radio_button_with_icon_model.dart';

class InputFieldGenericRadioButtonWithIconWidget extends StatefulWidget {
  const InputFieldGenericRadioButtonWithIconWidget({
    super.key,
    required this.keyPrefix,
    this.listOfObject,
    required this.callBackAction,
  });

  final String? keyPrefix;
  final List<RegisterTypeRadioButtonSchemaStruct>? listOfObject;
  final Future Function(int selectedIndexParam)? callBackAction;

  @override
  State<InputFieldGenericRadioButtonWithIconWidget> createState() =>
      _InputFieldGenericRadioButtonWithIconWidgetState();
}

class _InputFieldGenericRadioButtonWithIconWidgetState
    extends State<InputFieldGenericRadioButtonWithIconWidget> {
  late InputFieldGenericRadioButtonWithIconModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => InputFieldGenericRadioButtonWithIconModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: Builder(
        builder: (context) {
          final listOfObjDyChil = widget!.listOfObject?.toList() ?? [];

          return Wrap(
            spacing: 24.0,
            runSpacing: 24.0,
            alignment: WrapAlignment.start,
            crossAxisAlignment: WrapCrossAlignment.start,
            direction: Axis.horizontal,
            runAlignment: WrapAlignment.start,
            verticalDirection: VerticalDirection.down,
            clipBehavior: Clip.none,
            children:
                List.generate(listOfObjDyChil.length, (listOfObjDyChilIndex) {
              final listOfObjDyChilItem = listOfObjDyChil[listOfObjDyChilIndex];
              return InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  _model.selectedIndexCompState = listOfObjDyChilIndex;
                  safeSetState(() {});
                  await widget.callBackAction?.call(
                    _model.selectedIndexCompState,
                  );
                },
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth: 450.0,
                  ),
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
                    borderRadius: BorderRadius.circular(4.0),
                    border: Border.all(
                      color: FlutterFlowTheme.of(context).secondaryInfo100,
                      width: 1.0,
                    ),
                  ),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 12.0, 12.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Builder(
                              builder: (context) {
                                if (_model.selectedIndexCompState ==
                                    listOfObjDyChilIndex) {
                                  return Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Semantics(
                                      label:
                                          'This is the icon shown when any of the option is selected.',
                                      child: Icon(
                                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'InputField_Generic_RadioButton_with_Icon',
                                                'ActiveIcon_${listOfObjDyChilIndex.toString()}')),
                                        Icons.radio_button_checked,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryInfo500Default,
                                        size: 24.0,
                                      ),
                                    ),
                                  );
                                } else {
                                  return Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        20.0, 0.0, 0.0, 0.0),
                                    child: Semantics(
                                      label:
                                          'This is the icon shown when no option is selected.',
                                      child: Icon(
                                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'InputField_Generic_RadioButton_with_Icon',
                                                'InactiveIcon_${listOfObjDyChilIndex.toString()}')),
                                        Icons.radio_button_off,
                                        color: FlutterFlowTheme.of(context)
                                            .neutral700,
                                        size: 24.0,
                                      ),
                                    ),
                                  );
                                }
                              },
                            ),
                            Semantics(
                              label:
                                  'This is the text used for type of mode of OTP to be received.',
                              child: Text(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_RadioButton_with_Icon',
                                        'RegisteredType_Text_${listOfObjDyChilIndex.toString()}')),
                                listOfObjDyChilItem.option,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .textBasic,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ),
                          ].divide(SizedBox(width: 12.0)),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            if (listOfObjDyChilItem.iconName ==
                                RadioButtonIconEnum.signature)
                              FaIcon(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_RadioButton_with_Icon',
                                        'SignatureIcon_${listOfObjDyChilIndex.toString()}')),
                                FontAwesomeIcons.signature,
                                color: FlutterFlowTheme.of(context).neutral800,
                                size: 24.0,
                              ),
                            if (listOfObjDyChilItem.iconName ==
                                RadioButtonIconEnum.fingerprint)
                              Icon(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_RadioButton_with_Icon',
                                        'FingerprintIcon_${listOfObjDyChilIndex.toString()}')),
                                Icons.fingerprint,
                                color: FlutterFlowTheme.of(context).primaryText,
                                size: 24.0,
                              ),
                            if (listOfObjDyChilItem.iconName ==
                                RadioButtonIconEnum.mobile_friendly)
                              Icon(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_RadioButton_with_Icon',
                                        'MobileFieldIcon_${listOfObjDyChilIndex.toString()}')),
                                Icons.mobile_friendly,
                                color: FlutterFlowTheme.of(context).primaryText,
                                size: 24.0,
                              ),
                            if (listOfObjDyChilItem.iconName ==
                                RadioButtonIconEnum.account_balance)
                              Icon(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'InputField_Generic_RadioButton_with_Icon',
                                        'AccountBalanceIcon_${listOfObjDyChilIndex.toString()}')),
                                Icons.account_balance,
                                color: FlutterFlowTheme.of(context).primaryText,
                                size: 24.0,
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}
