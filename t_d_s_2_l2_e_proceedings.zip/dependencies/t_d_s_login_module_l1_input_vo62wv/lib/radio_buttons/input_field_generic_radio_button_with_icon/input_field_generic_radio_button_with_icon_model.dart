import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'input_field_generic_radio_button_with_icon_widget.dart'
    show InputFieldGenericRadioButtonWithIconWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericRadioButtonWithIconModel
    extends FlutterFlowModel<InputFieldGenericRadioButtonWithIconWidget> {
  ///  Local state fields for this component.

  int selectedIndexCompState = 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
