import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'toggle_button_with_list_widget.dart' show ToggleButtonWithListWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ToggleButtonWithListModel
    extends FlutterFlowModel<ToggleButtonWithListWidget> {
  ///  Local state fields for this component.

  int? selectedIndexCompState = 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Action blocks.
  Future onButtonTap(
    BuildContext context, {
    required int? index,
  }) async {
    selectedIndexCompState = index;
  }
}
