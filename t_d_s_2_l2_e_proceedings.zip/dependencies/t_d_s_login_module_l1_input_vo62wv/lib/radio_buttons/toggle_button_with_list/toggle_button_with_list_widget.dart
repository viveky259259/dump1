import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'toggle_button_with_list_model.dart';
export 'toggle_button_with_list_model.dart';

class ToggleButtonWithListWidget extends StatefulWidget {
  const ToggleButtonWithListWidget({
    super.key,
    required this.keyPrefix,
    this.listOfToggle,
    required this.callBackAction,
  });

  final String? keyPrefix;
  final List<String>? listOfToggle;
  final Future Function(int selectedIndex)? callBackAction;

  @override
  State<ToggleButtonWithListWidget> createState() =>
      _ToggleButtonWithListWidgetState();
}

class _ToggleButtonWithListWidgetState
    extends State<ToggleButtonWithListWidget> {
  late ToggleButtonWithListModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ToggleButtonWithListModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        borderRadius: BorderRadius.circular(4.0),
        border: Border.all(
          color: FlutterFlowTheme.of(context).neutral400,
          width: 0.5,
        ),
      ),
      child: Builder(
        builder: (context) {
          final listOfToggleDynChil = widget!.listOfToggle?.toList() ?? [];

          return Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(listOfToggleDynChil.length,
                (listOfToggleDynChilIndex) {
              final listOfToggleDynChilItem =
                  listOfToggleDynChil[listOfToggleDynChilIndex];
              return Builder(
                builder: (context) {
                  if (listOfToggleDynChilIndex ==
                      _model.selectedIndexCompState) {
                    return Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(8.0, 3.5, 16.0, 3.5),
                      child: FFButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Toggle_Button_With_List',
                                'Toggled_Button_${listOfToggleDynChilIndex.toString()}')),
                        onPressed: () async {
                          await _model.onButtonTap(
                            context,
                            index: listOfToggleDynChilIndex,
                          );
                          await widget.callBackAction?.call(
                            _model.selectedIndexCompState!,
                          );
                        },
                        text: listOfToggleDynChilItem,
                        options: FFButtonOptions(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 3.5, 16.0, 3.5),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context)
                              .secondaryInfoBGStroke10,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryInfo500Default,
                                    fontSize: 14.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(2.0),
                        ),
                        showLoadingIndicator: false,
                      ),
                    );
                  } else {
                    return Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(8.0, 3.5, 16.0, 3.5),
                      child: FFButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Toggle_Button_With_List',
                                'Untoggled_Button_${listOfToggleDynChilIndex.toString()}')),
                        onPressed: () async {
                          await _model.onButtonTap(
                            context,
                            index: listOfToggleDynChilIndex,
                          );
                          await widget.callBackAction?.call(
                            _model.selectedIndexCompState!,
                          );
                        },
                        text: listOfToggleDynChilItem,
                        options: FFButtonOptions(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 3.5, 16.0, 3.5),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Color(0x00FFFFFF),
                          textStyle: FlutterFlowTheme.of(context)
                              .titleSmall
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 14.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w500,
                              ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(2.0),
                        ),
                        showLoadingIndicator: false,
                      ),
                    );
                  }
                },
              );
            }),
          );
        },
      ),
    );
  }
}
