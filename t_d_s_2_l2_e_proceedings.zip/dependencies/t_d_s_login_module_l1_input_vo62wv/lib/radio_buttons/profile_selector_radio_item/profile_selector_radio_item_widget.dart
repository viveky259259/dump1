import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'profile_selector_radio_item_model.dart';
export 'profile_selector_radio_item_model.dart';

/// How to use this Component: If you are using this comp for two times as a
/// group then you have to add two states and you have to pass the two states
/// as a parameter to the  isSelected variable.
class ProfileSelectorRadioItemWidget extends StatefulWidget {
  const ProfileSelectorRadioItemWidget({
    super.key,
    required this.keyPrefix,
    required this.optionText,
    bool? isSelected,
    this.width,
    this.height,
  }) : this.isSelected = isSelected ?? false;

  final String? keyPrefix;
  final String? optionText;
  final bool isSelected;
  final double? width;
  final double? height;

  @override
  State<ProfileSelectorRadioItemWidget> createState() =>
      _ProfileSelectorRadioItemWidgetState();
}

class _ProfileSelectorRadioItemWidgetState
    extends State<ProfileSelectorRadioItemWidget> {
  late ProfileSelectorRadioItemModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ProfileSelectorRadioItemModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Builder(
            builder: (context) {
              if (widget!.isSelected) {
                return Container(
                  width: 80.0,
                  height: 80.0,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                  ),
                  child: Image.asset(
                    'dependencies/t_d_s_login_module_l1_input_vo62wv/assets/images/SelectedProfile.png',
                    fit: BoxFit.cover,
                  ),
                );
              } else {
                return Container(
                  width: 80.0,
                  height: 80.0,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                  ),
                  child: Image.asset(
                    'dependencies/t_d_s_login_module_l1_input_vo62wv/assets/images/UnselectedProfile.png',
                    fit: BoxFit.cover,
                  ),
                );
              }
            },
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(12.5, 0.0, 12.5, 0.0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Builder(
                  builder: (context) {
                    if (widget!.isSelected) {
                      return Semantics(
                        label:
                            'This is the icon shown when any of the option is selected.',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'InputField_Generic_RadioButton_with_Icon',
                                  'ActiveIcon')),
                          Icons.radio_button_checked,
                          color: FlutterFlowTheme.of(context)
                              .secondaryInfo500Default,
                          size: 24.0,
                        ),
                      );
                    } else {
                      return Semantics(
                        label:
                            'This is the icon shown when no option is selected.',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'InputField_Generic_RadioButton_with_Icon',
                                  'InactiveIcon')),
                          Icons.radio_button_off,
                          color: FlutterFlowTheme.of(context).neutral700,
                          size: 24.0,
                        ),
                      );
                    }
                  },
                ),
                Semantics(
                  label:
                      'This is the text used for type of mode of OTP to be received.',
                  child: Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'InputField_modeToReceiveOTP',
                            'RegisteredType_Text')),
                    valueOrDefault<String>(
                      widget!.optionText,
                      'optionText',
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).primaryTxtClr,
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ].divide(SizedBox(width: 8.0)),
            ),
          ),
        ].divide(SizedBox(height: 16.0)),
      ),
    );
  }
}
