import '/flutter_flow/flutter_flow_util.dart';
import '/radio_buttons/profile_selector_radio_item/profile_selector_radio_item_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'profile_selector_radio_button_with_list_model.dart';
export 'profile_selector_radio_button_with_list_model.dart';

class ProfileSelectorRadioButtonWithListWidget extends StatefulWidget {
  const ProfileSelectorRadioButtonWithListWidget({
    super.key,
    required this.keyPrefix,
    required this.listOfProfiles,
    required this.callbackAction,
  });

  final String? keyPrefix;
  final List<String>? listOfProfiles;
  final Future Function(int selectedIndex)? callbackAction;

  @override
  State<ProfileSelectorRadioButtonWithListWidget> createState() =>
      _ProfileSelectorRadioButtonWithListWidgetState();
}

class _ProfileSelectorRadioButtonWithListWidgetState
    extends State<ProfileSelectorRadioButtonWithListWidget> {
  late ProfileSelectorRadioButtonWithListModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => ProfileSelectorRadioButtonWithListModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        final profileSelector = widget!.listOfProfiles!.toList();

        return Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.start,
          children:
              List.generate(profileSelector.length, (profileSelectorIndex) {
            final profileSelectorItem = profileSelector[profileSelectorIndex];
            return InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                _model.selectedIndex = profileSelectorIndex;
                safeSetState(() {});
                await widget.callbackAction?.call(
                  _model.selectedIndex!,
                );
              },
              child: wrapWithModel(
                model: _model.userProfileSelectorRadioButtonWithIconModels
                    .getModel(
                  profileSelectorIndex.toString(),
                  profileSelectorIndex,
                ),
                updateCallback: () => safeSetState(() {}),
                child: ProfileSelectorRadioItemWidget(
                  key: Key(
                    'Keymhk_${profileSelectorIndex.toString()}',
                  ),
                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'RadioButton_WithList',
                      'Profile_Selector_RadioButton_with_Icon_${profileSelectorIndex.toString()}'),
                  optionText: profileSelectorItem,
                  isSelected: profileSelectorIndex == _model.selectedIndex,
                ),
              ),
            );
          }).divide(SizedBox(width: 10.0)).around(SizedBox(width: 10.0)),
        );
      },
    );
  }
}
