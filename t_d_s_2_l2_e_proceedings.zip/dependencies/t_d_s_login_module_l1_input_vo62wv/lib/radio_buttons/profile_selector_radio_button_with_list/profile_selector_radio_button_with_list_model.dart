import '/flutter_flow/flutter_flow_util.dart';
import '/radio_buttons/profile_selector_radio_item/profile_selector_radio_item_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'profile_selector_radio_button_with_list_widget.dart'
    show ProfileSelectorRadioButtonWithListWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfileSelectorRadioButtonWithListModel
    extends FlutterFlowModel<ProfileSelectorRadioButtonWithListWidget> {
  ///  Local state fields for this component.

  int? selectedIndex = 0;

  ///  State fields for stateful widgets in this component.

  // Models for UserProfile_Selector_RadioButton_with_Icon.
  late FlutterFlowDynamicModels<ProfileSelectorRadioItemModel>
      userProfileSelectorRadioButtonWithIconModels;

  @override
  void initState(BuildContext context) {
    userProfileSelectorRadioButtonWithIconModels =
        FlutterFlowDynamicModels(() => ProfileSelectorRadioItemModel());
  }

  @override
  void dispose() {
    userProfileSelectorRadioButtonWithIconModels.dispose();
  }
}
