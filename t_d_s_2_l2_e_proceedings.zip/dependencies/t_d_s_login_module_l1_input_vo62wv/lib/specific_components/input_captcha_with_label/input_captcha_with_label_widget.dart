import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_captcha_with_label_model.dart';
export 'input_captcha_with_label_model.dart';

/// A versatile reusable component that displays a CAPTCHA challenge to the
/// user and validates their input
class InputCaptchaWithLabelWidget extends StatefulWidget {
  const InputCaptchaWithLabelWidget({
    super.key,
    required this.keyPrefix,
    this.width,
    this.height,
    this.hintText,
    this.labelText,
    this.isMandatory,
  });

  final String? keyPrefix;
  final double? width;
  final double? height;
  final String? hintText;
  final String? labelText;
  final bool? isMandatory;

  @override
  State<InputCaptchaWithLabelWidget> createState() =>
      _InputCaptchaWithLabelWidgetState();
}

class _InputCaptchaWithLabelWidgetState
    extends State<InputCaptchaWithLabelWidget> {
  late InputCaptchaWithLabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputCaptchaWithLabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: widget!.width,
            height: valueOrDefault<double>(
              widget!.height,
              52.0,
            ),
            decoration: BoxDecoration(),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Semantics(
                  label: 'This is the Image of the captcha.',
                  child: ClipRRect(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'Input_Captcha_WithLabel',
                            'Captcha_Image')),
                    borderRadius: BorderRadius.circular(4.0),
                    child: Image.asset(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Input_Captcha_WithLabel',
                              'Captcha_Image')),
                      'dependencies/t_d_s_login_module_l1_input_vo62wv/assets/images/Screenshot_2024-12-10_214611.png',
                      width: 279.0,
                      height: 52.0,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 24.0,
                        height: 24.0,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(3.0),
                          border: Border.all(
                            color: Color(0xFF9DA4CB),
                            width: 1.0,
                          ),
                        ),
                        child: Semantics(
                          label: 'This will read the captcha aloud.',
                          child: Icon(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Input_Captcha_WithLabel',
                                    'iconReadAloud')),
                            Icons.volume_up,
                            color: FlutterFlowTheme.of(context).neutral800,
                            size: 16.0,
                          ),
                        ),
                      ),
                      Container(
                        width: 24.0,
                        height: 24.0,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(3.0),
                          border: Border.all(
                            color: Color(0xFF9DA4CB),
                            width: 1.0,
                          ),
                        ),
                        child: Semantics(
                          label: 'This will refresh the captcha.',
                          child: Icon(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Input_Captcha_WithLabel', 'iconRefresh')),
                            Icons.refresh,
                            color: FlutterFlowTheme.of(context).neutral800,
                            size: 16.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ].divide(SizedBox(width: 16.0)),
            ),
          ),
          wrapWithModel(
            model: _model.inputFieldGenericTextFieldModel,
            updateCallback: () => safeSetState(() {}),
            child: InputFieldGenericTextFieldWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Input_Captcha_WithLabel',
                      'Input_Field_Generic_TextField')),
              hintText: widget!.hintText,
              width: widget!.width,
              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                  widget!.keyPrefix!,
                  'InputField_Generic_TextField',
                  'Input_Captcha'),
              isDisable: false,
              isMandatory: false,
              textFieldHeight: widget!.height,
              labelText: widget!.labelText!,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
