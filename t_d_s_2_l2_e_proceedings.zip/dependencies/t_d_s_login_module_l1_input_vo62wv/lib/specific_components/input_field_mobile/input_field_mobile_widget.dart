import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_mobile_model.dart';
export 'input_field_mobile_model.dart';

/// A input feils to enter mobile number of different country
class InputFieldMobileWidget extends StatefulWidget {
  const InputFieldMobileWidget({
    super.key,
    this.leadingIconInputField,
    this.trailingIconInputField,
    this.labelText,
    this.dropdownHintText,
    this.hintTextInputField,
    required this.keyPrefix,
    this.errorText,
    this.containerHeight,
    this.containerWidth,
    this.listDropDown,
    double? witdthDropDown,
    double? heightDropDown,
    double? widthTextField,
  })  : this.witdthDropDown = witdthDropDown ?? 80.0,
        this.heightDropDown = heightDropDown ?? 40.0,
        this.widthTextField = widthTextField ?? 240.0;

  final Widget? leadingIconInputField;
  final Widget? trailingIconInputField;
  final String? labelText;
  final String? dropdownHintText;
  final String? hintTextInputField;
  final String? keyPrefix;
  final String? errorText;
  final double? containerHeight;
  final double? containerWidth;
  final List<String>? listDropDown;
  final double witdthDropDown;
  final double heightDropDown;
  final double widthTextField;

  @override
  State<InputFieldMobileWidget> createState() => _InputFieldMobileWidgetState();
}

class _InputFieldMobileWidgetState extends State<InputFieldMobileWidget> {
  late InputFieldMobileModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldMobileModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.containerHeight,
      height: widget!.containerWidth,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // A text to give the lebel  of the componet name. Made with richtext, and it is developed as a mandatory field
          Semantics(
            label: ' A text to give label to the component.',
            child: wrapWithModel(
              model: _model.inputFieldGenericLabelTextModel,
              updateCallback: () => safeSetState(() {}),
              child: InputFieldGenericLabelTextWidget(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'InputField_Mobile',
                        'InputField_Generic_LabelText')),
                labelText: widget!.labelText!,
                isMandatory: true,
                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                    widget!.keyPrefix!,
                    'InputField_Mobile',
                    'InputField_Generic_LabelText'),
              ),
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 90.0,
                decoration: BoxDecoration(),
                child: FlutterFlowDropDown<String>(
                  controller: _model.dropDownValueController ??=
                      FormFieldController<String>(null),
                  options: widget!.listDropDown!,
                  onChanged: (val) =>
                      safeSetState(() => _model.dropDownValue = val),
                  width: 72.0,
                  height: 37.0,
                  textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        letterSpacing: 0.0,
                      ),
                  hintText: '+91',
                  icon: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: FlutterFlowTheme.of(context).secondaryText,
                    size: 24.0,
                  ),
                  fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                  elevation: 2.0,
                  borderColor: FlutterFlowTheme.of(context).neutral400,
                  borderWidth: 0.0,
                  borderRadius: 4.0,
                  margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                  hidesUnderline: true,
                  isOverButton: false,
                  isSearchable: false,
                  isMultiSelect: false,
                ),
              ),
              Container(
                decoration: BoxDecoration(),
                child:
                    // Textfeild to enter the mobile numer, it will have error , regex validation.
                    Semantics(
                  label: 'Textfeild to enter mobile number',
                  child: wrapWithModel(
                    model: _model.inputFieldGenericTextFieldModel,
                    updateCallback: () => safeSetState(() {}),
                    child: InputFieldGenericTextFieldWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'InputFieldMobile',
                              'InputField_Generic_TextField')),
                      hintText: widget!.hintTextInputField,
                      errorText: widget!.errorText,
                      width: widget!.widthTextField,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'InputField_Mobile',
                              'InputField_Generic_TextField'),
                      isDisable: false,
                      isMandatory: false,
                      trailingIcon: widget!.trailingIconInputField,
                      labelText: '',
                      isViewOnly: false,
                      showExternalErrorMessage: false,
                      onSubmitAction: () async {},
                      onInputValueChangeCallback: (value) async {},
                      onFocusChangeCallback: (hasFocus) async {},
                      onInputValidationCallback: (isValid) async {},
                      onTapLabelTrailingButton: () async {},
                    ),
                  ),
                ),
              ),
            ].divide(SizedBox(width: 8.0)),
          ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
