import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'input_field_mobile_widget.dart' show InputFieldMobileWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldMobileModel extends FlutterFlowModel<InputFieldMobileWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for InputField_Generic_LabelText component.
  late InputFieldGenericLabelTextModel inputFieldGenericLabelTextModel;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // Model for InputField_Generic_TextField component.
  late InputFieldGenericTextFieldModel inputFieldGenericTextFieldModel;

  @override
  void initState(BuildContext context) {
    inputFieldGenericLabelTextModel =
        createModel(context, () => InputFieldGenericLabelTextModel());
    inputFieldGenericTextFieldModel =
        createModel(context, () => InputFieldGenericTextFieldModel());
  }

  @override
  void dispose() {
    inputFieldGenericLabelTextModel.dispose();
    inputFieldGenericTextFieldModel.dispose();
  }
}
