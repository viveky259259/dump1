import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dialog_box_heading_model.dart';
export 'dialog_box_heading_model.dart';

class DialogBoxHeadingWidget extends StatefulWidget {
  const DialogBoxHeadingWidget({
    super.key,
    this.dialogBoxTitle,
    required this.keyPrefix,
  });

  final String? dialogBoxTitle;
  final String? keyPrefix;

  @override
  State<DialogBoxHeadingWidget> createState() => _DialogBoxHeadingWidgetState();
}

class _DialogBoxHeadingWidgetState extends State<DialogBoxHeadingWidget> {
  late DialogBoxHeadingModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DialogBoxHeadingModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        FaIcon(
          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
              widget!.keyPrefix!, 'DialogueBoxHeading', 'Icon')),
          FontAwesomeIcons.checkCircle,
          color: Color(0xFF27904D),
          size: 23.33,
        ),
        RichText(
          textScaler: MediaQuery.of(context).textScaler,
          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
              widget!.keyPrefix!, 'DialogueBoxHeading', 'Title')),
          text: TextSpan(
            children: [
              TextSpan(
                text: valueOrDefault<String>(
                  widget!.dialogBoxTitle,
                  'Title',
                ),
                style: FlutterFlowTheme.of(context).titleMedium.override(
                      fontFamily: 'Inter',
                      color: Color(0xFF27904D),
                      letterSpacing: 0.0,
                      fontWeight: FontWeight.bold,
                    ),
              )
            ],
            style: FlutterFlowTheme.of(context).bodyLarge.override(
                  fontFamily: 'Inter',
                  letterSpacing: 0.0,
                ),
          ),
        ),
      ].divide(SizedBox(width: 8.0)),
    );
  }
}
