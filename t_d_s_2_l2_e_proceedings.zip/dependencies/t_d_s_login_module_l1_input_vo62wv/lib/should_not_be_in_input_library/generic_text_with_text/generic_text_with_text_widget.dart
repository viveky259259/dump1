import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_text_with_text_model.dart';
export 'generic_text_with_text_model.dart';

class GenericTextWithTextWidget extends StatefulWidget {
  const GenericTextWithTextWidget({
    super.key,
    String? label1,
    String? label2,
    this.width,
    this.heigth,
  })  : this.label1 = label1 ?? 'heading 1',
        this.label2 = label2 ?? 'heading 2';

  final String label1;
  final String label2;
  final double? width;
  final double? heigth;

  @override
  State<GenericTextWithTextWidget> createState() =>
      _GenericTextWithTextWidgetState();
}

class _GenericTextWithTextWidgetState extends State<GenericTextWithTextWidget> {
  late GenericTextWithTextModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericTextWithTextModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.heigth,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget!.label1,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: Color(0xFF1F1F1F),
                  fontSize: 12.0,
                  letterSpacing: 0.0,
                ),
          ),
          Text(
            widget!.label2,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: Color(0xFF252525),
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w600,
                ),
          ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
