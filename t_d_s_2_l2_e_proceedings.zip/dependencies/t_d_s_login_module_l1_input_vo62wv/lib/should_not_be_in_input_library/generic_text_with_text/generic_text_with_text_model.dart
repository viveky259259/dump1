import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'generic_text_with_text_widget.dart' show GenericTextWithTextWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericTextWithTextModel
    extends FlutterFlowModel<GenericTextWithTextWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
