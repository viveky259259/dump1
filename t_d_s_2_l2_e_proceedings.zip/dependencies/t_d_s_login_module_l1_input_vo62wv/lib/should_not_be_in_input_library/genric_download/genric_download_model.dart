import '/flutter_flow/flutter_flow_util.dart';
import 'genric_download_widget.dart' show GenricDownloadWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenricDownloadModel extends FlutterFlowModel<GenricDownloadWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
