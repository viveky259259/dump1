import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'genric_download_model.dart';
export 'genric_download_model.dart';

class GenricDownloadWidget extends StatefulWidget {
  const GenricDownloadWidget({super.key});

  @override
  State<GenricDownloadWidget> createState() => _GenricDownloadWidgetState();
}

class _GenricDownloadWidgetState extends State<GenricDownloadWidget> {
  late GenricDownloadModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenricDownloadModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
