import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_generic_textwith_label_model.dart';
export 'input_generic_textwith_label_model.dart';

/// A componenet that shows text along with its label
class InputGenericTextwithLabelWidget extends StatefulWidget {
  const InputGenericTextwithLabelWidget({
    super.key,
    this.inputText,
    required this.keyPrefix,
    this.labelText,
    this.width,
    this.height,
  });

  final String? inputText;
  final String? keyPrefix;
  final String? labelText;
  final double? width;
  final double? height;

  @override
  State<InputGenericTextwithLabelWidget> createState() =>
      _InputGenericTextwithLabelWidgetState();
}

class _InputGenericTextwithLabelWidgetState
    extends State<InputGenericTextwithLabelWidget> {
  late InputGenericTextwithLabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputGenericTextwithLabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          wrapWithModel(
            model: _model.inputFieldGenericLabelTextModel,
            updateCallback: () => safeSetState(() {}),
            updateOnChange: true,
            child: InputFieldGenericLabelTextWidget(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Input_Generic_TextwithLabel',
                      'InputField_Generic_LabelText')),
              labelText: widget!.labelText!,
              isMandatory: true,
              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                  widget!.keyPrefix!,
                  'Input_Generic_TextwithLabel',
                  'InputField_Generic_LabelText'),
            ),
          ),
          Text(
            valueOrDefault<String>(
              widget!.inputText,
              'inputText',
            ),
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).primaryTxtClr,
                  fontSize: 16.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ].divide(SizedBox(height: 4.0)),
      ),
    );
  }
}
