import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import 'dart:ui';
import 'input_generic_textwith_label_widget.dart'
    show InputGenericTextwithLabelWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputGenericTextwithLabelModel
    extends FlutterFlowModel<InputGenericTextwithLabelWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for InputField_Generic_LabelText component.
  late InputFieldGenericLabelTextModel inputFieldGenericLabelTextModel;

  @override
  void initState(BuildContext context) {
    inputFieldGenericLabelTextModel =
        createModel(context, () => InputFieldGenericLabelTextModel());
  }

  @override
  void dispose() {
    inputFieldGenericLabelTextModel.dispose();
  }
}
