import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'generic_label_with_icon_widget.dart' show GenericLabelWithIconWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericLabelWithIconModel
    extends FlutterFlowModel<GenericLabelWithIconWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
