import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_label_with_icon_model.dart';
export 'generic_label_with_icon_model.dart';

class GenericLabelWithIconWidget extends StatefulWidget {
  const GenericLabelWithIconWidget({
    super.key,
    this.width,
    this.height,
    this.label,
  });

  final double? width;
  final double? height;
  final String? label;

  @override
  State<GenericLabelWithIconWidget> createState() =>
      _GenericLabelWithIconWidgetState();
}

class _GenericLabelWithIconWidgetState
    extends State<GenericLabelWithIconWidget> {
  late GenericLabelWithIconModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericLabelWithIconModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          valueOrDefault<String>(
            widget!.label,
            'label',
          ),
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Inter',
                color: Color(0xFF0675E2),
                letterSpacing: 0.0,
                fontWeight: FontWeight.w500,
              ),
        ),
        Icon(
          Icons.navigate_next_sharp,
          color: FlutterFlowTheme.of(context).secondaryText,
          size: 20.0,
        ),
      ],
    );
  }
}
