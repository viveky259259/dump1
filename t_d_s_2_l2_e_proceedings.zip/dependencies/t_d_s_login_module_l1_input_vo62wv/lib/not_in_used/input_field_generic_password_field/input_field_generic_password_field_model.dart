import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'input_field_generic_password_field_widget.dart'
    show InputFieldGenericPasswordFieldWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericPasswordFieldModel
    extends FlutterFlowModel<InputFieldGenericPasswordFieldWidget> {
  ///  Local state fields for this component.

  bool isInputValid = true;

  String? inputValue;

  bool hasBeenFocussed = false;

  bool showError = false;

  String? errorMessage;

  ///  State fields for stateful widgets in this component.

  // State field(s) for Generic_TextField widget.
  FocusNode? genericTextFieldFocusNode;
  TextEditingController? genericTextFieldTextController;
  String? Function(BuildContext, String?)?
      genericTextFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    genericTextFieldFocusNode?.dispose();
    genericTextFieldTextController?.dispose();
  }

  /// Action blocks.
  Future validateTextField(BuildContext context) async {
    if ((widget!.validationRegex != null && widget!.validationRegex != '') &&
        (genericTextFieldTextController.text != null &&
            genericTextFieldTextController.text != '')) {
      isInputValid = functions.isInputValid(
          genericTextFieldTextController.text, widget!.validationRegex!);
      showError = true;
      errorMessage = isInputValid ? null : widget!.errorText;
      return;
    } else {
      return;
    }
  }
}
