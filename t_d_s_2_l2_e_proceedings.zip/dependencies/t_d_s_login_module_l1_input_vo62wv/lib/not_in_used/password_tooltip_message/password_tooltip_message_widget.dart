import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'password_tooltip_message_model.dart';
export 'password_tooltip_message_model.dart';

class PasswordTooltipMessageWidget extends StatefulWidget {
  const PasswordTooltipMessageWidget({super.key});

  @override
  State<PasswordTooltipMessageWidget> createState() =>
      _PasswordTooltipMessageWidgetState();
}

class _PasswordTooltipMessageWidgetState
    extends State<PasswordTooltipMessageWidget> {
  late PasswordTooltipMessageModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PasswordTooltipMessageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primaryText,
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: Padding(
        padding: EdgeInsets.all(5.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Icons.circle_rounded,
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                  size: 5.0,
                ),
                Text(
                  ' Use 8 to 15 characters8',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w300,
                      ),
                ),
              ].divide(SizedBox(width: 5.0)),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Icons.circle_rounded,
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                  size: 5.0,
                ),
                Text(
                  'A combination of uppercase letters, lowercase \nletters, numbers, and special characters.',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w300,
                      ),
                ),
              ].divide(SizedBox(width: 5.0)),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Icons.circle_rounded,
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                  size: 5.0,
                ),
                Text(
                  'Significantly different from your previous \npassword.',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w300,
                      ),
                ),
              ].divide(SizedBox(width: 5.0)),
            ),
          ].divide(SizedBox(height: 5.0)),
        ),
      ),
    );
  }
}
