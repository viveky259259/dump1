import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'password_tooltip_message_widget.dart' show PasswordTooltipMessageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PasswordTooltipMessageModel
    extends FlutterFlowModel<PasswordTooltipMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
