import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/text_label_with_tooltip/text_label_with_tooltip_widget.dart';
import '/not_in_used/input_field_generic_password/input_field_generic_password_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_password_with_label_model.dart';
export 'input_field_password_with_label_model.dart';

class InputFieldPasswordWithLabelWidget extends StatefulWidget {
  const InputFieldPasswordWithLabelWidget({
    super.key,
    required this.keyPrefix,
    required this.labelText,
  });

  final String? keyPrefix;
  final String? labelText;

  @override
  State<InputFieldPasswordWithLabelWidget> createState() =>
      _InputFieldPasswordWithLabelWidgetState();
}

class _InputFieldPasswordWithLabelWidgetState
    extends State<InputFieldPasswordWithLabelWidget> {
  late InputFieldPasswordWithLabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldPasswordWithLabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        wrapWithModel(
          model: _model.textLabelWithTooltipModel,
          updateCallback: () => safeSetState(() {}),
          child: TextLabelWithTooltipWidget(
            labelText: widget!.labelText,
            isMandatory: false,
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'InputField_Password_WithLabel',
                'Text_Label_With_Tooltip'),
          ),
        ),
        wrapWithModel(
          model: _model.inputFieldGenericPasswordModel,
          updateCallback: () => safeSetState(() {}),
          child: InputFieldGenericPasswordWidget(
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'InputField_Password_WithLabel',
                'InputField_Generic_Password'),
            shouldObscureText: false,
            isReadOnly: false,
            isMandatory: false,
            showErrorMessage: false,
            onSubmitAction: () async {},
            onChangeAction: () async {},
            onFocusChangeAction: () async {},
          ),
        ),
      ],
    );
  }
}
