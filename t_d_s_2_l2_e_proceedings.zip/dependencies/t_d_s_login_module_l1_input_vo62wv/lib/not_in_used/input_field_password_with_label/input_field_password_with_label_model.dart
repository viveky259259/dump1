import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/text_label_with_tooltip/text_label_with_tooltip_widget.dart';
import '/not_in_used/input_field_generic_password/input_field_generic_password_widget.dart';
import 'dart:ui';
import 'input_field_password_with_label_widget.dart'
    show InputFieldPasswordWithLabelWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldPasswordWithLabelModel
    extends FlutterFlowModel<InputFieldPasswordWithLabelWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Text_Label_With_Tooltip component.
  late TextLabelWithTooltipModel textLabelWithTooltipModel;
  // Model for InputField_Generic_Password component.
  late InputFieldGenericPasswordModel inputFieldGenericPasswordModel;

  @override
  void initState(BuildContext context) {
    textLabelWithTooltipModel =
        createModel(context, () => TextLabelWithTooltipModel());
    inputFieldGenericPasswordModel =
        createModel(context, () => InputFieldGenericPasswordModel());
  }

  @override
  void dispose() {
    textLabelWithTooltipModel.dispose();
    inputFieldGenericPasswordModel.dispose();
  }
}
