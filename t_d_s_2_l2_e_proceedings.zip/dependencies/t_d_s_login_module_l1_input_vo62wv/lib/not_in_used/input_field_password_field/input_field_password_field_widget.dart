import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_password_field_model.dart';
export 'input_field_password_field_model.dart';

class InputFieldPasswordFieldWidget extends StatefulWidget {
  const InputFieldPasswordFieldWidget({
    super.key,
    required this.validationRegex,
    required this.showPasswordIcon,
    required this.hidePasswordIcon,
    required this.labelText,
    required this.hintText,
    required this.errorText,
    required this.keyPrefix,
    this.width,
    this.widthContainer,
    this.heightContainer,
    double? itemSpacingColumn,
  }) : this.itemSpacingColumn = itemSpacingColumn ?? 8.0;

  final String? validationRegex;
  final Widget? showPasswordIcon;
  final Widget? hidePasswordIcon;
  final String? labelText;
  final String? hintText;
  final String? errorText;
  final String? keyPrefix;
  final double? width;
  final double? widthContainer;
  final double? heightContainer;
  final double itemSpacingColumn;

  @override
  State<InputFieldPasswordFieldWidget> createState() =>
      _InputFieldPasswordFieldWidgetState();
}

class _InputFieldPasswordFieldWidgetState
    extends State<InputFieldPasswordFieldWidget> {
  late InputFieldPasswordFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldPasswordFieldModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.widthContainer,
      height: widget!.heightContainer,
      decoration: BoxDecoration(),
      child: Semantics(
        label: 'This is the textField to enter Password.',
        child: wrapWithModel(
          model: _model.inputFieldGenericTextFieldModel,
          updateCallback: () => safeSetState(() {}),
          child: InputFieldGenericTextFieldWidget(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'InputField_PasswordField',
                'InputField_Generic_TextField')),
            hintText: widget!.hintText,
            errorText: widget!.errorText,
            minLines: 1,
            maxLines: 2,
            width: widget!.width,
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'InputField_PasswordField',
                'InputField_Generic_TextField'),
            validationRegex:
                '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,15}\$',
            isDisable: false,
            isMandatory: false,
            trailingIcon: widget!.hidePasswordIcon,
            labelText: widget!.labelText!,
            onSubmitAction: () async {},
            onInputValueChangeCallback: (value) async {},
            onFocusChangeCallback: (hasFocus) async {},
            onInputValidationCallback: (isValid) async {},
            onTapLabelTrailingButton: () async {},
          ),
        ),
      ),
    );
  }
}
