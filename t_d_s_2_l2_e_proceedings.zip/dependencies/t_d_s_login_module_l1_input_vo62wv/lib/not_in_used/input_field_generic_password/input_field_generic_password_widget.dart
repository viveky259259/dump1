import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_password_model.dart';
export 'input_field_generic_password_model.dart';

/// "A versatile input field component without LabelText designed for various
/// text entry needs.
///
///
///
/// ### Parameters:
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText**: `String`
///   Displays an error message if validation fails.
///
/// - **validationRegex**: `String`
///   A regular expression pattern used to validate the input, allowing for
/// specific format constraints.
///
/// - **minLines**: `int`
///   Sets the minimum number of lines for the text field.
///
/// - **maxLines**: `int`
///   Sets the maximum number of lines for the text field.
///
/// ### State Variables:
/// - **isValid**: `bool`
///   Indicates input validity based on the applied regex and mandatory
/// status.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   hintText: 'Full name',
///   errorText: 'Name cannot be empty',
///   validationRegex: r'^[a-zA-Z ]+$',
///   minLines: 1,
///   maxLines: 3,
/// )"
class InputFieldGenericPasswordWidget extends StatefulWidget {
  const InputFieldGenericPasswordWidget({
    super.key,
    this.hintText,
    String? errorText,
    this.minLines,
    this.maxLines,
    this.width,
    required this.keyPrefix,
    bool? shouldObscureText,
    this.validationRegex,
    bool? isReadOnly,
    bool? isMandatory,
    this.onSubmitAction,
    this.onChangeAction,
    this.onFocusChangeAction,
    this.leadingIcon,
    this.trailingIcon,
    this.maxLength,
    this.height,
    bool? showErrorMessage,
    this.initialValue,
  })  : this.errorText = errorText ?? ' ',
        this.shouldObscureText = shouldObscureText ?? false,
        this.isReadOnly = isReadOnly ?? false,
        this.isMandatory = isMandatory ?? false,
        this.showErrorMessage = showErrorMessage ?? false;

  final String? hintText;
  final String errorText;
  final int? minLines;
  final int? maxLines;
  final double? width;
  final String? keyPrefix;
  final bool shouldObscureText;
  final String? validationRegex;
  final bool isReadOnly;
  final bool isMandatory;
  final Future Function()? onSubmitAction;
  final Future Function()? onChangeAction;
  final Future Function()? onFocusChangeAction;
  final Widget? leadingIcon;
  final Widget? trailingIcon;
  final int? maxLength;
  final double? height;
  final bool showErrorMessage;
  final String? initialValue;

  @override
  State<InputFieldGenericPasswordWidget> createState() =>
      _InputFieldGenericPasswordWidgetState();
}

class _InputFieldGenericPasswordWidgetState
    extends State<InputFieldGenericPasswordWidget> {
  late InputFieldGenericPasswordModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldGenericPasswordModel());

    _model.genericTextFieldTextController ??= TextEditingController();
    _model.genericTextFieldFocusNode ??= FocusNode();
    _model.genericTextFieldFocusNode!.addListener(() => safeSetState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(),
          ),
          Container(
            width: widget!.width,
            height: widget!.height,
            decoration: BoxDecoration(),
            child: Semantics(
              label: 'This is the textField to enter the Input.',
              child: TextFormField(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'InputField_Generic_TextField',
                        'Generic_TextField')),
                controller: _model.genericTextFieldTextController,
                focusNode: _model.genericTextFieldFocusNode,
                onChanged: (_) => EasyDebounce.debounce(
                  '_model.genericTextFieldTextController',
                  Duration(milliseconds: 2000),
                  () async {
                    await widget.onChangeAction?.call();
                  },
                ),
                onFieldSubmitted: (_) async {
                  await widget.onSubmitAction?.call();
                },
                autofocus: false,
                readOnly: widget!.isReadOnly,
                obscureText: !_model.genericTextFieldVisibility,
                decoration: InputDecoration(
                  isDense: true,
                  labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
                        fontFamily: 'Inter',
                        letterSpacing: 0.0,
                      ),
                  hintText: widget!.hintText,
                  hintStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).neutral600,
                        fontSize: 14.0,
                        letterSpacing: 0.0,
                      ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: FlutterFlowTheme.of(context).neutral400,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color:
                          FlutterFlowTheme.of(context).secondaryInfo500Default,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: FlutterFlowTheme.of(context).danger500Default,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: FlutterFlowTheme.of(context).danger500Default,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  filled: true,
                  fillColor: FlutterFlowTheme.of(context).neutral100,
                  suffixIcon: InkWell(
                    onTap: () => safeSetState(
                      () => _model.genericTextFieldVisibility =
                          !_model.genericTextFieldVisibility,
                    ),
                    focusNode: FocusNode(skipTraversal: true),
                    child: Icon(
                      _model.genericTextFieldVisibility
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      size: 22,
                    ),
                  ),
                ),
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).textBasic,
                      letterSpacing: 0.0,
                    ),
                maxLength: widget!.maxLength,
                maxLengthEnforcement: MaxLengthEnforcement.enforced,
                buildCounter: (context,
                        {required currentLength,
                        required isFocused,
                        maxLength}) =>
                    null,
                cursorColor: FlutterFlowTheme.of(context).primaryText,
                validator: _model.genericTextFieldTextControllerValidator
                    .asValidator(context),
              ),
            ),
          ),
          if (widget!.showErrorMessage)
            Semantics(
              label:
                  'This is the text which will be displayed as error message.',
              child: Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'InputField_Generic_TextField',
                        'errorText')),
                widget!.errorText,
                style: FlutterFlowTheme.of(context).bodySmall.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).danger500Default,
                      letterSpacing: 0.0,
                      fontWeight: FontWeight.w500,
                    ),
              ),
            ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
