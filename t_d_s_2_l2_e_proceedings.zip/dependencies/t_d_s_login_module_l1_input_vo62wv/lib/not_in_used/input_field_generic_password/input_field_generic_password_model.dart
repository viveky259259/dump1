import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'input_field_generic_password_widget.dart'
    show InputFieldGenericPasswordWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericPasswordModel
    extends FlutterFlowModel<InputFieldGenericPasswordWidget> {
  ///  Local state fields for this component.

  bool? isValid;

  ///  State fields for stateful widgets in this component.

  // State field(s) for Generic_TextField widget.
  FocusNode? genericTextFieldFocusNode;
  TextEditingController? genericTextFieldTextController;
  late bool genericTextFieldVisibility;
  String? Function(BuildContext, String?)?
      genericTextFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {
    genericTextFieldVisibility = false;
  }

  @override
  void dispose() {
    genericTextFieldFocusNode?.dispose();
    genericTextFieldTextController?.dispose();
  }
}
