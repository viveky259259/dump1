import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_a_i_n_field_model.dart';
export 'input_field_a_i_n_field_model.dart';

/// "A versatile input field component designed for taking AIN no as an input.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the input field, displayed at the top. Defaults to 'Label'.
///
/// - **isMandatory**: `bool`
///   Specifies whether the field is required. Displays an asterisk (*) next
/// to the label if true.
///
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText**: `String`
///   Displays an error message if validation fails.
///
/// - **minLines**: `int`
///   Sets the minimum number of lines for the text field.
///
/// - **maxLines**: `int`
///   Sets the maximum number of lines for the text field.
///
/// ### State Variables:
/// - **isValid**: `bool`
///   Indicates input validity based on the applied regex and mandatory
/// status.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   labelText: 'Search',
///   isMandatory: true,
///   hintText: 'Search',
///   errorText: 'No result found',
///   minLines: 1,
///   maxLines: 3,
/// )"
class InputFieldAINFieldWidget extends StatefulWidget {
  const InputFieldAINFieldWidget({
    super.key,
    required this.validationRegex,
    required this.labelText,
    required this.hintText,
    required this.errorText,
    required this.width,
    required this.height,
    required this.keyPrefix,
    this.leadingIcon,
    this.trailingIcon,
  });

  final String? validationRegex;
  final String? labelText;
  final String? hintText;
  final String? errorText;
  final double? width;
  final double? height;
  final String? keyPrefix;
  final Widget? leadingIcon;
  final Widget? trailingIcon;

  @override
  State<InputFieldAINFieldWidget> createState() =>
      _InputFieldAINFieldWidgetState();
}

class _InputFieldAINFieldWidgetState extends State<InputFieldAINFieldWidget> {
  late InputFieldAINFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldAINFieldModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Semantics(
            label: 'This is the textField to enter AIN no.',
            child: wrapWithModel(
              model: _model.inputFieldGenericTextFieldModel,
              updateCallback: () => safeSetState(() {}),
              child: InputFieldGenericTextFieldWidget(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'InputField_AINField',
                        'Input_Generic_TextField')),
                hintText: widget!.hintText,
                errorText: widget!.errorText,
                minLines: 1,
                maxLines: 2,
                width: widget!.width,
                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                    widget!.keyPrefix!,
                    'InputField_AINField',
                    'Input_Generic_TextField'),
                isDisable: false,
                isMandatory: false,
                trailingIcon: widget!.trailingIcon,
                labelText: widget!.labelText!,
                onSubmitAction: () async {},
                onInputValueChangeCallback: (value) async {},
                onFocusChangeCallback: (hasFocus) async {},
                onInputValidationCallback: (isValid) async {},
                onTapLabelTrailingButton: () async {},
              ),
            ),
          ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
