import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_p_a_n_field_model.dart';
export 'input_field_p_a_n_field_model.dart';

class InputFieldPANFieldWidget extends StatefulWidget {
  const InputFieldPANFieldWidget({
    super.key,
    required this.validationRegex,
    required this.errorText,
    required this.width,
    this.isReadOnly,
    this.initialValue,
    required this.keyPrefix,
    this.leadingIcon,
    this.trailingIcon,
    required this.labelText,
    required this.hintText,
    bool? isMandatory,
    double? itemSpacingColumn,
  })  : this.isMandatory = isMandatory ?? true,
        this.itemSpacingColumn = itemSpacingColumn ?? 8.0;

  final String? validationRegex;
  final String? errorText;
  final double? width;
  final bool? isReadOnly;
  final String? initialValue;
  final String? keyPrefix;
  final Widget? leadingIcon;
  final Widget? trailingIcon;
  final String? labelText;
  final String? hintText;
  final bool isMandatory;
  final double itemSpacingColumn;

  @override
  State<InputFieldPANFieldWidget> createState() =>
      _InputFieldPANFieldWidgetState();
}

class _InputFieldPANFieldWidgetState extends State<InputFieldPANFieldWidget> {
  late InputFieldPANFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputFieldPANFieldModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Semantics(
            label: 'This is the textField to enter PAN no.',
            child: wrapWithModel(
              model: _model.inputFieldGenericTextFieldModel,
              updateCallback: () => safeSetState(() {}),
              child: InputFieldGenericTextFieldWidget(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'InputField_PANField',
                        'InputField_Generic_TextField')),
                hintText: widget!.hintText,
                errorText: widget!.errorText,
                minLines: 1,
                maxLines: 2,
                width: widget!.width,
                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                    widget!.keyPrefix!,
                    'InputField_PANField',
                    'InputField_Generic_TextField'),
                isDisable: false,
                isMandatory: false,
                trailingIcon: widget!.trailingIcon,
                labelText: widget!.labelText!,
                onSubmitAction: () async {},
                onInputValueChangeCallback: (value) async {},
                onFocusChangeCallback: (hasFocus) async {},
                onInputValidationCallback: (isValid) async {},
                onTapLabelTrailingButton: () async {},
              ),
            ),
          ),
        ].divide(SizedBox(height: widget!.itemSpacingColumn)),
      ),
    );
  }
}
