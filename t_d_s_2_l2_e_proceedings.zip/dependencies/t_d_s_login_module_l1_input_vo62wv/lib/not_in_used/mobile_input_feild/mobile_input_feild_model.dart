import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'mobile_input_feild_widget.dart' show MobileInputFeildWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MobileInputFeildModel extends FlutterFlowModel<MobileInputFeildWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
