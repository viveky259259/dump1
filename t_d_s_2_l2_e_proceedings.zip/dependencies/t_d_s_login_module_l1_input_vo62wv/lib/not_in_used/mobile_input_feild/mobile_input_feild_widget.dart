import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mobile_input_feild_model.dart';
export 'mobile_input_feild_model.dart';

class MobileInputFeildWidget extends StatefulWidget {
  const MobileInputFeildWidget({
    super.key,
    required this.labelText,
  });

  final String? labelText;

  @override
  State<MobileInputFeildWidget> createState() => _MobileInputFeildWidgetState();
}

class _MobileInputFeildWidgetState extends State<MobileInputFeildWidget> {
  late MobileInputFeildModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MobileInputFeildModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Text(
          'Hello World',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Inter',
                letterSpacing: 0.0,
              ),
        ),
      ],
    );
  }
}
