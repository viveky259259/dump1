import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'input_password_label_textwith_tool_widget.dart'
    show InputPasswordLabelTextwithToolWidget;
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputPasswordLabelTextwithToolModel
    extends FlutterFlowModel<InputPasswordLabelTextwithToolWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
