import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_text_field_with_label_model.dart';
export 'input_field_generic_text_field_with_label_model.dart';

/// "A versatile input field component designed for various text entry needs.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the input field, displayed at the top. Defaults to 'Label'.
///
/// - **isMandatory**: `bool`
///   Specifies whether the field is required. Displays an asterisk (*) next
/// to the label if true.
///
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText**: `String`
///   Displays an error message if validation fails.
///
/// - **validationRegex**: `String`
///   A regular expression pattern used to validate the input, allowing for
/// specific format constraints.
///
/// - **minLines**: `int`
///   Sets the minimum number of lines for the text field.
///
/// - **maxLines**: `int`
///   Sets the maximum number of lines for the text field.
///
/// ### State Variables:
/// - **isValid**: `bool`
///   Indicates input validity based on the applied regex and mandatory
/// status.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   labelText: 'Enter your name',
///   isMandatory: true,
///   hintText: 'Full name',
///   errorText: 'Name cannot be empty',
///   validationRegex: r'^[a-zA-Z ]+$',
///   minLines: 1,
///   maxLines: 3,
/// )"
class InputFieldGenericTextFieldWithLabelWidget extends StatefulWidget {
  const InputFieldGenericTextFieldWithLabelWidget({
    super.key,
    this.labelText,
    this.hintText,
    this.isMandatory,
    this.minLines,
    double? width,
    this.labelColor,
    this.maxLines,
    this.validationRegex,
    required this.keyPrefix,
    bool? isMandatoryErrorText,
    bool? isReadOnly,
    this.leadingIcon,
    this.trailingIcon,
    this.maxLength,
    this.errorText,
    this.height,
    this.textFieldAction,
    bool? shouldObscureText,
  })  : this.width = width ?? 200.0,
        this.isMandatoryErrorText = isMandatoryErrorText ?? false,
        this.isReadOnly = isReadOnly ?? false,
        this.shouldObscureText = shouldObscureText ?? false;

  final String? labelText;
  final String? hintText;
  final bool? isMandatory;
  final int? minLines;
  final double width;
  final Color? labelColor;
  final int? maxLines;
  final String? validationRegex;
  final String? keyPrefix;
  final bool isMandatoryErrorText;
  final bool isReadOnly;
  final Widget? leadingIcon;
  final Widget? trailingIcon;
  final int? maxLength;
  final String? errorText;
  final double? height;
  final Future Function()? textFieldAction;
  final bool shouldObscureText;

  @override
  State<InputFieldGenericTextFieldWithLabelWidget> createState() =>
      _InputFieldGenericTextFieldWithLabelWidgetState();
}

class _InputFieldGenericTextFieldWithLabelWidgetState
    extends State<InputFieldGenericTextFieldWithLabelWidget> {
  late InputFieldGenericTextFieldWithLabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => InputFieldGenericTextFieldWithLabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Semantics(
        label: 'This is the textField component used to accept the inputs.',
        child: wrapWithModel(
          model: _model.inputFieldGenericTextFieldModel,
          updateCallback: () => safeSetState(() {}),
          updateOnChange: true,
          child: InputFieldGenericTextFieldWidget(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'InputField_Generic_TextFieldWithLabel',
                'InputField_Generic_TextField')),
            hintText: widget!.hintText,
            errorText: widget!.errorText,
            minLines: widget!.minLines,
            maxLines: widget!.maxLines,
            width: widget!.width,
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'InputField_Generic_TextFieldWithLabel',
                'InputField_Generic_TextField'),
            validationRegex: widget!.validationRegex,
            isDisable: widget!.isReadOnly,
            isMandatory: widget!.isMandatory,
            trailingIcon: widget!.trailingIcon,
            textFieldHeight: widget!.height,
            labelText: widget!.labelText!,
            onSubmitAction: () async {},
            onInputValueChangeCallback: (value) async {
              await widget.textFieldAction?.call();
            },
            onFocusChangeCallback: (hasFocus) async {},
            onInputValidationCallback: (isValid) async {},
            onTapLabelTrailingButton: () async {},
          ),
        ),
      ),
    );
  }
}
