import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_email_field_model.dart';
export 'input_email_field_model.dart';

/// A texfeild that takes email as input
class InputEmailFieldWidget extends StatefulWidget {
  const InputEmailFieldWidget({
    super.key,
    this.width,
    this.errorText,
    this.isReadOnly,
    this.initialVlaue,
    this.isMandatory,
    this.labelText,
    this.keyPrefix,
    this.hintText,
    this.leadingIcon,
    this.trailingIcon,
  });

  final double? width;
  final String? errorText;
  final bool? isReadOnly;
  final String? initialVlaue;
  final bool? isMandatory;
  final String? labelText;
  final String? keyPrefix;
  final String? hintText;
  final Widget? leadingIcon;
  final Widget? trailingIcon;

  @override
  State<InputEmailFieldWidget> createState() => _InputEmailFieldWidgetState();
}

class _InputEmailFieldWidgetState extends State<InputEmailFieldWidget> {
  late InputEmailFieldModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputEmailFieldModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: wrapWithModel(
        model: _model.inputFieldGenericTextFieldModel,
        updateCallback: () => safeSetState(() {}),
        child: InputFieldGenericTextFieldWidget(
          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
              widget!.keyPrefix!,
              'Input_EmailField',
              'Input_Generic_TextField')),
          hintText: widget!.hintText,
          errorText: widget!.errorText,
          width: widget!.width,
          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
              widget!.keyPrefix!,
              'Input_EmailField',
              'Input_Generic_TextField'),
          validationRegex:
              '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\$',
          isDisable: false,
          isMandatory: false,
          trailingIcon: widget!.trailingIcon,
          labelText: widget!.labelText!,
          onSubmitAction: () async {},
          onInputValueChangeCallback: (value) async {},
          onFocusChangeCallback: (hasFocus) async {},
          onInputValidationCallback: (isValid) async {},
          onTapLabelTrailingButton: () async {},
        ),
      ),
    );
  }
}
