import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import '/not_in_used/password_tooltip_message/password_tooltip_message_widget.dart';
import 'dart:ui';
import 'input_password_with_tooltip_icon_widget.dart'
    show InputPasswordWithTooltipIconWidget;
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputPasswordWithTooltipIconModel
    extends FlutterFlowModel<InputPasswordWithTooltipIconWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for InputField_Generic_LabelText component.
  late InputFieldGenericLabelTextModel inputFieldGenericLabelTextModel;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {
    inputFieldGenericLabelTextModel =
        createModel(context, () => InputFieldGenericLabelTextModel());
    passwordVisibility = false;
  }

  @override
  void dispose() {
    inputFieldGenericLabelTextModel.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
