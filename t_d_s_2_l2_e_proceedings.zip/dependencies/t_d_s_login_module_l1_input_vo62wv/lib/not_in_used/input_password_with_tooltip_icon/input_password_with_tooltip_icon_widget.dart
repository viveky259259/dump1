import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import '/not_in_used/password_tooltip_message/password_tooltip_message_widget.dart';
import 'dart:ui';
import 'package:aligned_tooltip/aligned_tooltip.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_password_with_tooltip_icon_model.dart';
export 'input_password_with_tooltip_icon_model.dart';

/// "A versatile input field component designed for various text entry needs.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the input field, displayed at the top. Defaults to 'Label'.
///
/// - **isMandatory**: `bool`
///   Specifies whether the field is required. Displays an asterisk (*) next
/// to the label if true.
///
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText1**: `String`
///   Displays an error message if validation fails.
///
/// - **errorText2**: `String`
///   Displays an error message if API validation fails.
/// - **maxLength**: `int`
///   Sets the max character for the text field.
///
/// - **maxLines**: `int`
///   Sets the maximum number of lines for the text field.
///
/// ### State Variables:
/// - **showToolTip**: `bool`
///   Indicates input validity based on the applied mandatory status.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   labelText: 'Enter your name',
///   isMandatory: true,
///   hintText: 'Full name',
///   errorText: 'Name cannot be empty',
///   validationRegex: r'^[a-zA-Z ]+$',
///   minLines: 8,
///   maxLines: 15,
/// )"
class InputPasswordWithTooltipIconWidget extends StatefulWidget {
  const InputPasswordWithTooltipIconWidget({
    super.key,
    this.errorMsg,
    this.hintText,
    this.maxLength,
    required this.keyPrefix,
    bool? showToolTip,
    this.labelText,
    bool? isMandatory,
    this.textFieldAction,
    bool? isErrorRequired,
  })  : this.showToolTip = showToolTip ?? false,
        this.isMandatory = isMandatory ?? false,
        this.isErrorRequired = isErrorRequired ?? false;

  final String? errorMsg;
  final String? hintText;
  final int? maxLength;
  final String? keyPrefix;
  final bool showToolTip;
  final String? labelText;
  final bool isMandatory;
  final Future Function()? textFieldAction;
  final bool isErrorRequired;

  @override
  State<InputPasswordWithTooltipIconWidget> createState() =>
      _InputPasswordWithTooltipIconWidgetState();
}

class _InputPasswordWithTooltipIconWidgetState
    extends State<InputPasswordWithTooltipIconWidget> {
  late InputPasswordWithTooltipIconModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputPasswordWithTooltipIconModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();
    _model.textFieldFocusNode!.addListener(() => safeSetState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.inputFieldGenericLabelTextModel,
                updateCallback: () => safeSetState(() {}),
                updateOnChange: true,
                child: InputFieldGenericLabelTextWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Input_Passowrd_withTooltipIcon',
                          'InputField_Generic_LabelText')),
                  labelText: widget!.labelText!,
                  isMandatory: widget!.isMandatory,
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Input_Passowrd_withTooltipIcon',
                          'InputField_Generic_LabelText'),
                ),
              ),
              if (widget!.showToolTip)
                AlignedTooltip(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Input_Password_withTooltipIcon',
                          'Tooltip')),
                  content: Padding(
                    padding: EdgeInsets.all(4.0),
                    child: PasswordTooltipMessageWidget(),
                  ),
                  offset: 4.0,
                  preferredDirection: AxisDirection.up,
                  borderRadius: BorderRadius.circular(8.0),
                  backgroundColor:
                      FlutterFlowTheme.of(context).secondaryBackground,
                  elevation: 4.0,
                  tailBaseWidth: 24.0,
                  tailLength: 12.0,
                  waitDuration: Duration(milliseconds: 100),
                  showDuration: Duration(milliseconds: 1500),
                  triggerMode: TooltipTriggerMode.tap,
                  child: Icon(
                    Icons.info_outline,
                    color: FlutterFlowTheme.of(context).primaryText,
                    size: 24.0,
                  ),
                ),
            ],
          ),
          TextFormField(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Input_Password_withTooltipIcon',
                'TextField')),
            controller: _model.textController,
            focusNode: _model.textFieldFocusNode,
            onChanged: (_) => EasyDebounce.debounce(
              '_model.textController',
              Duration(milliseconds: 1000),
              () => safeSetState(() {}),
            ),
            onFieldSubmitted: (_) async {
              await widget.textFieldAction?.call();
            },
            autofocus: false,
            obscureText: !_model.passwordVisibility,
            decoration: InputDecoration(
              isDense: true,
              labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
              hintText: widget!.hintText,
              hintStyle: FlutterFlowTheme.of(context).labelMedium.override(
                    fontFamily: 'Inter',
                    fontSize: 14.0,
                    letterSpacing: 0.0,
                  ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).secondaryText,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).primary,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              errorBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).error,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              focusedErrorBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).error,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(8.0),
              ),
              filled: true,
              fillColor: FlutterFlowTheme.of(context).secondaryBackground,
              suffixIcon: InkWell(
                onTap: () => safeSetState(
                  () => _model.passwordVisibility = !_model.passwordVisibility,
                ),
                focusNode: FocusNode(skipTraversal: true),
                child: Icon(
                  _model.passwordVisibility
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
              ),
            ),
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  letterSpacing: 0.0,
                ),
            maxLength: widget!.maxLength,
            maxLengthEnforcement: MaxLengthEnforcement.enforced,
            buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) =>
                null,
            cursorColor: FlutterFlowTheme.of(context).primaryText,
            validator: _model.textControllerValidator.asValidator(context),
          ),
          if (widget!.isErrorRequired &&
              (widget!.errorMsg != null && widget!.errorMsg != ''))
            Text(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Input_Password_withTooltipIcon',
                      'Text1')),
              widget!.errorMsg!,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).error,
                    letterSpacing: 0.0,
                  ),
            ),
        ].divide(SizedBox(height: 5.0)),
      ),
    );
  }
}
