import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/text_label_with_tooltip/text_label_with_tooltip_widget.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_field_generic_text_field_with_tooltip_model.dart';
export 'input_field_generic_text_field_with_tooltip_model.dart';

/// "A versatile input field component designed for various text entry needs.
///
///
///
/// ### Parameters:
/// - **labelText**: `String`
///   A label for the input field, displayed at the top. Defaults to 'Label'.
///
/// - **isMandatory**: `bool`
///   Specifies whether the field is required. Displays an asterisk (*) next
/// to the label if true.
///
/// - **hintText**: `String`
///   Placeholder text shown inside the text field to guide the user.
///
/// - **errorText**: `String`
///   Displays an error message if validation fails.
///
/// - **validationRegex**: `String`
///   A regular expression pattern used to validate the input, allowing for
/// specific format constraints.
///
/// - **minLines**: `int`
///   Sets the minimum number of lines for the text field.
///
/// - **maxLines**: `int`
///   Sets the maximum number of lines for the text field.
///
/// ### State Variables:
/// - **isValid**: `bool`
///   Indicates input validity based on the applied regex and mandatory
/// status.
///
/// ### Example:
/// ```dart
/// InputField_Generic_Text(
///   labelText: 'Enter your name',
///   isMandatory: true,
///   hintText: 'Full name',
///   errorText: 'Name cannot be empty',
///   validationRegex: r'^[a-zA-Z ]+$',
///   minLines: 1,
///   maxLines: 3,
/// )"
class InputFieldGenericTextFieldWithTooltipWidget extends StatefulWidget {
  const InputFieldGenericTextFieldWithTooltipWidget({
    super.key,
    this.labelText,
    this.hintText,
    this.errorText,
    this.isMandatory,
    this.minLines,
    this.width,
    this.height,
    this.labelColor,
    this.fontSize,
    this.hintTextColor,
    this.hintFontSize,
    this.borderColor,
    this.focusBorderColor,
    this.maxLines,
    this.leadingIcon,
    this.trailingIcon,
    this.tooltipRequired,
    this.tooltipIconColor,
    this.tooltipMessage,
    required this.keyPrefix,
    this.maxLength,
    this.showErrorMessage,
    bool? shouldObscureText,
  }) : this.shouldObscureText = shouldObscureText ?? false;

  final String? labelText;
  final String? hintText;
  final String? errorText;
  final bool? isMandatory;
  final int? minLines;
  final double? width;
  final double? height;
  final Color? labelColor;
  final double? fontSize;
  final Color? hintTextColor;
  final double? hintFontSize;
  final Color? borderColor;
  final Color? focusBorderColor;
  final int? maxLines;
  final Widget? leadingIcon;
  final Widget? trailingIcon;
  final bool? tooltipRequired;
  final Color? tooltipIconColor;
  final String? tooltipMessage;
  final String? keyPrefix;
  final int? maxLength;
  final bool? showErrorMessage;
  final bool shouldObscureText;

  @override
  State<InputFieldGenericTextFieldWithTooltipWidget> createState() =>
      _InputFieldGenericTextFieldWithTooltipWidgetState();
}

class _InputFieldGenericTextFieldWithTooltipWidgetState
    extends State<InputFieldGenericTextFieldWithTooltipWidget> {
  late InputFieldGenericTextFieldWithTooltipModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => InputFieldGenericTextFieldWithTooltipModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          wrapWithModel(
            model: _model.textLabelWithTooltipModel,
            updateCallback: () => safeSetState(() {}),
            child: TextLabelWithTooltipWidget(
              labelText: widget!.labelText,
              isMandatory: widget!.isMandatory,
              fontSize: widget!.fontSize,
              labelColor: widget!.labelColor,
              toolTipIconColor: widget!.tooltipIconColor,
              toolTipMessage: widget!.tooltipMessage,
              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                  widget!.keyPrefix!,
                  'InputField_Generic_TextField_WithTooltip',
                  'Text_Label_With_Tooltip'),
            ),
          ),
          wrapWithModel(
            model: _model.inputFieldGenericTextFieldModel,
            updateCallback: () => safeSetState(() {}),
            updateOnChange: true,
            child: InputFieldGenericTextFieldWidget(
              hintText: widget!.hintText,
              errorText: widget!.errorText,
              minLines: widget!.minLines,
              maxLines: widget!.maxLines,
              width: widget!.width,
              keyPrefix: widget!.keyPrefix!,
              isDisable: false,
              isMandatory: widget!.isMandatory,
              trailingIcon: widget!.trailingIcon,
              labelText: widget!.labelText!,
              onSubmitAction: () async {},
              onInputValueChangeCallback: (value) async {},
              onFocusChangeCallback: (hasFocus) async {},
              onInputValidationCallback: (isValid) async {},
              onTapLabelTrailingButton: () async {},
            ),
          ),
        ].divide(SizedBox(height: 8.0)),
      ),
    );
  }
}
