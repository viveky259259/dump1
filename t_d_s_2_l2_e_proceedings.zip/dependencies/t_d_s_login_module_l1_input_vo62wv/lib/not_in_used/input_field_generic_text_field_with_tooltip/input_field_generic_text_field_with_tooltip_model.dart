import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/text_label_with_tooltip/text_label_with_tooltip_widget.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'input_field_generic_text_field_with_tooltip_widget.dart'
    show InputFieldGenericTextFieldWithTooltipWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InputFieldGenericTextFieldWithTooltipModel
    extends FlutterFlowModel<InputFieldGenericTextFieldWithTooltipWidget> {
  ///  Local state fields for this component.

  bool isValid = false;

  ///  State fields for stateful widgets in this component.

  // Model for Text_Label_With_Tooltip component.
  late TextLabelWithTooltipModel textLabelWithTooltipModel;
  // Model for InputField_Generic_TextField component.
  late InputFieldGenericTextFieldModel inputFieldGenericTextFieldModel;

  @override
  void initState(BuildContext context) {
    textLabelWithTooltipModel =
        createModel(context, () => TextLabelWithTooltipModel());
    inputFieldGenericTextFieldModel =
        createModel(context, () => InputFieldGenericTextFieldModel());
  }

  @override
  void dispose() {
    textLabelWithTooltipModel.dispose();
    inputFieldGenericTextFieldModel.dispose();
  }
}
