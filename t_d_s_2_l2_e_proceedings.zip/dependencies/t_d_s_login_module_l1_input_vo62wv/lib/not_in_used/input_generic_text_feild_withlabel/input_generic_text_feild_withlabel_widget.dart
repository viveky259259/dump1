import '/flutter_flow/flutter_flow_util.dart';
import '/generic_components/label_text/input_field_generic_label_text/input_field_generic_label_text_widget.dart';
import '/generic_components/text_field/input_field_generic_text_field/input_field_generic_text_field_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_generic_text_feild_withlabel_model.dart';
export 'input_generic_text_feild_withlabel_model.dart';

class InputGenericTextFeildWithlabelWidget extends StatefulWidget {
  const InputGenericTextFeildWithlabelWidget({
    super.key,
    this.leadingIcon,
    this.trailingIcon,
  });

  final Widget? leadingIcon;
  final Widget? trailingIcon;

  @override
  State<InputGenericTextFeildWithlabelWidget> createState() =>
      _InputGenericTextFeildWithlabelWidgetState();
}

class _InputGenericTextFeildWithlabelWidgetState
    extends State<InputGenericTextFeildWithlabelWidget> {
  late InputGenericTextFeildWithlabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputGenericTextFeildWithlabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        wrapWithModel(
          model: _model.inputFieldGenericLabelTextModel,
          updateCallback: () => safeSetState(() {}),
          child: InputFieldGenericLabelTextWidget(
            isMandatory: false,
            keyPrefix: 'keyPrefix',
          ),
        ),
        wrapWithModel(
          model: _model.inputFieldGenericTextFieldModel,
          updateCallback: () => safeSetState(() {}),
          child: InputFieldGenericTextFieldWidget(
            keyPrefix: 'keyPrefix',
            isDisable: false,
            isMandatory: false,
            trailingIcon: widget!.trailingIcon,
            labelText: 'Text',
            onSubmitAction: () async {},
            onInputValueChangeCallback: (value) async {},
            onFocusChangeCallback: (hasFocus) async {},
            onInputValidationCallback: (isValid) async {},
            onTapLabelTrailingButton: () async {},
          ),
        ),
      ],
    );
  }
}
