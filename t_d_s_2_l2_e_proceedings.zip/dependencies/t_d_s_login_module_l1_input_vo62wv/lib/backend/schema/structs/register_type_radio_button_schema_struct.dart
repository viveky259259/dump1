// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegisterTypeRadioButtonSchemaStruct extends BaseStruct {
  RegisterTypeRadioButtonSchemaStruct({
    String? option,
    RadioButtonIconEnum? iconName,
  })  : _option = option,
        _iconName = iconName;

  // "option" field.
  String? _option;
  String get option => _option ?? '';
  set option(String? val) => _option = val;

  bool hasOption() => _option != null;

  // "IconName" field.
  RadioButtonIconEnum? _iconName;
  RadioButtonIconEnum? get iconName => _iconName;
  set iconName(RadioButtonIconEnum? val) => _iconName = val;

  bool hasIconName() => _iconName != null;

  static RegisterTypeRadioButtonSchemaStruct fromMap(
          Map<String, dynamic> data) =>
      RegisterTypeRadioButtonSchemaStruct(
        option: data['option'] as String?,
        iconName: data['IconName'] is RadioButtonIconEnum
            ? data['IconName']
            : deserializeEnum<RadioButtonIconEnum>(data['IconName']),
      );

  static RegisterTypeRadioButtonSchemaStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? RegisterTypeRadioButtonSchemaStruct.fromMap(
              data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'option': _option,
        'IconName': _iconName?.serialize(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'option': serializeParam(
          _option,
          ParamType.String,
        ),
        'IconName': serializeParam(
          _iconName,
          ParamType.Enum,
        ),
      }.withoutNulls;

  static RegisterTypeRadioButtonSchemaStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      RegisterTypeRadioButtonSchemaStruct(
        option: deserializeParam(
          data['option'],
          ParamType.String,
          false,
        ),
        iconName: deserializeParam<RadioButtonIconEnum>(
          data['IconName'],
          ParamType.Enum,
          false,
        ),
      );

  @override
  String toString() => 'RegisterTypeRadioButtonSchemaStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is RegisterTypeRadioButtonSchemaStruct &&
        option == other.option &&
        iconName == other.iconName;
  }

  @override
  int get hashCode => const ListEquality().hash([option, iconName]);
}

RegisterTypeRadioButtonSchemaStruct createRegisterTypeRadioButtonSchemaStruct({
  String? option,
  RadioButtonIconEnum? iconName,
}) =>
    RegisterTypeRadioButtonSchemaStruct(
      option: option,
      iconName: iconName,
    );
