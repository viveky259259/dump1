import 'package:collection/collection.dart';

enum FileUploadStatus {
  Uploaded,
  Uploading,
  Error,
}

enum RadioButtonIconEnum {
  signature,
  fingerprint,
  mobile_friendly,
  account_balance,
}

enum ErrorType {
  PasswordProtectedFile,
  FormatNotSupported,
  DuplicateFile,
  FileSizeExceeded,
  uploadFailed,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (FileUploadStatus):
      return FileUploadStatus.values.deserialize(value) as T?;
    case (RadioButtonIconEnum):
      return RadioButtonIconEnum.values.deserialize(value) as T?;
    case (ErrorType):
      return ErrorType.values.deserialize(value) as T?;
    default:
      return null;
  }
}
