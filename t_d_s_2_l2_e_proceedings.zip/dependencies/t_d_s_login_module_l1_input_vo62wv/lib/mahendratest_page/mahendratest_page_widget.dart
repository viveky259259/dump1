import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart';
import '/generic_components/text_field/input_field_generic_mobile/input_field_generic_mobile_widget.dart';
import '/generic_components/text_field/input_field_password/input_field_password_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mahendratest_page_model.dart';
export 'mahendratest_page_model.dart';

class MahendratestPageWidget extends StatefulWidget {
  const MahendratestPageWidget({super.key});

  @override
  State<MahendratestPageWidget> createState() => _MahendratestPageWidgetState();
}

class _MahendratestPageWidgetState extends State<MahendratestPageWidget> {
  late MahendratestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MahendratestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(-1.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Align(
                  alignment: AlignmentDirectional(-1.0, 0.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: Container(
                          width: 500.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: wrapWithModel(
                            model: _model.inputFieldGenericDropdownModel,
                            updateCallback: () => safeSetState(() {}),
                            child: InputFieldGenericDropdownWidget(
                              hintText: 'Select one value',
                              initialOption: '',
                              keyPrefix: 'keyPrefix',
                              isDropdownDisable: false,
                              errorMessgae: 'Select one value',
                              showErrorMessage: _model.isShowError,
                              labelText: 'Select City',
                              isMandatory: true,
                              dropDownList: [
                                "Delhi",
                                "Pune",
                                "Shivpuri",
                                "Noida"
                              ],
                              dropdownValues: [
                                "Delhi",
                                "Pune",
                                "Shivpuri",
                                "Noida"
                              ],
                              onDropDownSelection: (selectedVlaue) async {
                                _model.dropDownSelectedValue = selectedVlaue;
                                safeSetState(() {});
                              },
                            ),
                          ),
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 40.0, 0.0, 0.0),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              _model.dropDownSelectedValue =
                                  _model.dropDownSelectedValue;
                              safeSetState(() {});
                            },
                            child: Container(
                              width: 500.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                              ),
                              child: Text(
                                _model.dropDownSelectedValue,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      wrapWithModel(
                        model: _model.inputFieldGenericMobileModel,
                        updateCallback: () => safeSetState(() {}),
                        child: InputFieldGenericMobileWidget(),
                      ),
                    ],
                  ),
                ),
                FFButtonWidget(
                  onPressed: () async {
                    if (_model.inputFieldGenericDropdownModel.dropDownValue ==
                            null ||
                        _model.inputFieldGenericDropdownModel.dropDownValue ==
                            '') {
                      _model.isShowError = true;
                      safeSetState(() {});
                    } else {
                      _model.isShowError = false;
                      safeSetState(() {});
                    }
                  },
                  text: 'Button',
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Inter',
                          color: Colors.white,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                wrapWithModel(
                  model: _model.inputFieldPasswordModel,
                  updateCallback: () => safeSetState(() {}),
                  child: InputFieldPasswordWidget(
                    hintText: '********',
                    keyPrefix: 'Test',
                    validationRegex:
                        '^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}\$',
                    isDisable: false,
                    isMandatory: true,
                    labelText: 'Password',
                    isViewOnly: false,
                    showExternalErrorMessage: true,
                    onSubmitAction: () async {},
                    onInputValueChangeCallback: (value) async {},
                    onFocusChangeCallback: (hasFocus) async {},
                    onInputValidationCallback: (isValid) async {},
                    onTapLabelTrailingButton: () async {},
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
