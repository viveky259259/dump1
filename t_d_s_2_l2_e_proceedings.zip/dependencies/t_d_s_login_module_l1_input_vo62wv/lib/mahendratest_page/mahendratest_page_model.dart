import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/generic_components/text_field/input_field_generic_dropdown/input_field_generic_dropdown_widget.dart';
import '/generic_components/text_field/input_field_generic_mobile/input_field_generic_mobile_widget.dart';
import '/generic_components/text_field/input_field_password/input_field_password_widget.dart';
import 'dart:ui';
import 'mahendratest_page_widget.dart' show MahendratestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MahendratestPageModel extends FlutterFlowModel<MahendratestPageWidget> {
  ///  Local state fields for this page.

  String dropDownSelectedValue = '';

  bool isShowError = false;

  ///  State fields for stateful widgets in this page.

  // Model for InputField_Generic_Dropdown component.
  late InputFieldGenericDropdownModel inputFieldGenericDropdownModel;
  // Model for InputField_Generic_Mobile component.
  late InputFieldGenericMobileModel inputFieldGenericMobileModel;
  // Model for InputField_Password component.
  late InputFieldPasswordModel inputFieldPasswordModel;

  @override
  void initState(BuildContext context) {
    inputFieldGenericDropdownModel =
        createModel(context, () => InputFieldGenericDropdownModel());
    inputFieldGenericMobileModel =
        createModel(context, () => InputFieldGenericMobileModel());
    inputFieldPasswordModel =
        createModel(context, () => InputFieldPasswordModel());
  }

  @override
  void dispose() {
    inputFieldGenericDropdownModel.dispose();
    inputFieldGenericMobileModel.dispose();
    inputFieldPasswordModel.dispose();
  }
}
