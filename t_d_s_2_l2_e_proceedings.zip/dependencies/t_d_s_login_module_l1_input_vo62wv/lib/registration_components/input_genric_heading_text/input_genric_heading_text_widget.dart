import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'input_genric_heading_text_model.dart';
export 'input_genric_heading_text_model.dart';

class InputGenricHeadingTextWidget extends StatefulWidget {
  const InputGenricHeadingTextWidget({
    super.key,
    required this.inputText,
    this.headingFontSize,
    this.headingTextColor,
    required this.keyPrefix,
    bool? dividerVisibility,
    this.iconRequired,
    this.icon,
  }) : this.dividerVisibility = dividerVisibility ?? true;

  final String? inputText;
  final double? headingFontSize;
  final Color? headingTextColor;
  final String? keyPrefix;
  final bool dividerVisibility;
  final bool? iconRequired;
  final Widget? icon;

  @override
  State<InputGenricHeadingTextWidget> createState() =>
      _InputGenricHeadingTextWidgetState();
}

class _InputGenricHeadingTextWidgetState
    extends State<InputGenricHeadingTextWidget> {
  late InputGenricHeadingTextModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InputGenricHeadingTextModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            if (widget!.iconRequired ?? true) widget!.icon!,
            Text(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!, 'Input_Genric_HeadingText', 'Text')),
              widget!.inputText!,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: valueOrDefault<Color>(
                      widget!.headingTextColor,
                      FlutterFlowTheme.of(context).primary,
                    ),
                    fontSize: valueOrDefault<double>(
                      widget!.headingFontSize,
                      24.0,
                    ),
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ].divide(SizedBox(width: 8.0)),
        ),
        if (widget!.dividerVisibility)
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Divider(
                  height: 1.0,
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).neutral300,
                ),
              ],
            ),
          ),
      ],
    );
  }
}
