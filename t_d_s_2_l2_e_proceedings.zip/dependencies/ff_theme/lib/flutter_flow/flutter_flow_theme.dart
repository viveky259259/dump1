// ignore_for_file: overridden_fields, annotate_overrides

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

abstract class FlutterFlowTheme {
  static FlutterFlowTheme of(BuildContext context) {
    return LightModeTheme();
  }

  @Deprecated('Use primary instead')
  Color get primaryColor => primary;
  @Deprecated('Use secondary instead')
  Color get secondaryColor => secondary;
  @Deprecated('Use tertiary instead')
  Color get tertiaryColor => tertiary;

  late Color primary;
  late Color secondary;
  late Color tertiary;
  late Color alternate;
  late Color primaryText;
  late Color secondaryText;
  late Color primaryBackground;
  late Color secondaryBackground;
  late Color accent1;
  late Color accent2;
  late Color accent3;
  late Color accent4;
  late Color success;
  late Color warning;
  late Color error;
  late Color info;

  late Color primary100;
  late Color primary200;
  late Color primary300;
  late Color primary400;
  late Color primary500;
  late Color primary600Default;
  late Color primary700;
  late Color primary800;
  late Color primary900;
  late Color primaryBGStroke2;
  late Color primaryBGStroke5;
  late Color primaryBGStroke10;
  late Color primaryBGStroke15;
  late Color primaryBGStroke20;
  late Color primaryBGStroke25;
  late Color primaryBGStroke30;
  late Color secondaryInfo100;
  late Color secondaryInfo200;
  late Color secondaryInfo300;
  late Color secondaryInfo500Default;
  late Color secondaryInfo700;
  late Color secondaryInfo800;
  late Color secondaryInfo900;
  late Color secondaryInfoBGStroke2;
  late Color secondaryInfoBGStroke5;
  late Color secondaryInfoBGStroke10;
  late Color secondaryInfoBGStroke15;
  late Color secondaryInfoBGStroke20;
  late Color secondaryInfoBGStroke25;
  late Color secondaryInfoBGStroke30;
  late Color success100;
  late Color success200;
  late Color success300;
  late Color success400;
  late Color success500Default;
  late Color success600;
  late Color success700;
  late Color success800;
  late Color success900;
  late Color successBGStroke5;
  late Color successBGStroke10;
  late Color successBGStroke15;
  late Color successBGStroke20;
  late Color successBGStroke25;
  late Color successBGStroke30;
  late Color warning100;
  late Color warning200;
  late Color warning300;
  late Color warning400;
  late Color warning500Default;
  late Color warning600;
  late Color warning700;
  late Color warning800;
  late Color warning900;
  late Color warningBGStroke5;
  late Color warningBGStroke10;
  late Color warningBGStroke15;
  late Color warningBGStroke20;
  late Color warningBGStroke25;
  late Color warningBGStroke30;
  late Color danger100;
  late Color danger200;
  late Color danger300;
  late Color danger400;
  late Color danger500Default;
  late Color danger600;
  late Color danger700;
  late Color danger800;
  late Color danger900;
  late Color dangerBGStroke5;
  late Color dangerBGStroke10;
  late Color dangerBGStroke15;
  late Color dangerBGStroke20;
  late Color dangerBGStroke25;
  late Color dangerBGStroke30;
  late Color neutral100;
  late Color neutral200;
  late Color neutral300;
  late Color neutral400;
  late Color neutral500Default;
  late Color neutral600;
  late Color neutral700;
  late Color neutral800;
  late Color neutral900;
  late Color neutral1000;
  late Color neutral1100;
  late Color neutral1200;
  late Color neutralBGStroke5;
  late Color neutralBGStroke10;
  late Color neutralBGStroke15;
  late Color neutralBGStroke20;
  late Color neutralBGStroke25;
  late Color neutralBGStroke30;
  late Color textBasic;
  late Color textPrimary;
  late Color textAlternative;
  late Color textTertiary;
  late Color textDisabled;
  late Color secondaryInfo400;
  late Color secondaryInfo600;
  late Color borderColor;
  late Color buttonBackBorderText;
  late Color buttonBorderTextColor;
  late Color breadcrumbColor;
  late Color primaryTxtClr;
  late Color secondaryTxtClr;
  late Color primaryHyperlinkTxtClr;
  late Color transactionDetailsContainerBg;
  late Color deleteBtnBorder;
  late Color modeOfOTPBorderClr;
  late Color activeIconBtnBgClr;
  late Color disbaleHyperlinkBtnTxtIconClr;
  late Color textFieldBorderColor;
  late Color deleteIcon;
  late Color fileAttachmentBorder;
  late Color errorText;
  late Color eyeIconClr;
  late Color fileNameTxtClr;
  late Color fileIconClr;
  late Color uploadIconClr;
  late Color uploadFileContainerBorder;
  late Color uploadFileTextClr;
  late Color hyperlinkBtnIconClr;
  late Color unSelectedRadioBtnColor;
  late Color formTxtBtnClr;

  @Deprecated('Use displaySmallFamily instead')
  String get title1Family => displaySmallFamily;
  @Deprecated('Use displaySmall instead')
  TextStyle get title1 => typography.displaySmall;
  @Deprecated('Use headlineMediumFamily instead')
  String get title2Family => typography.headlineMediumFamily;
  @Deprecated('Use headlineMedium instead')
  TextStyle get title2 => typography.headlineMedium;
  @Deprecated('Use headlineSmallFamily instead')
  String get title3Family => typography.headlineSmallFamily;
  @Deprecated('Use headlineSmall instead')
  TextStyle get title3 => typography.headlineSmall;
  @Deprecated('Use titleMediumFamily instead')
  String get subtitle1Family => typography.titleMediumFamily;
  @Deprecated('Use titleMedium instead')
  TextStyle get subtitle1 => typography.titleMedium;
  @Deprecated('Use titleSmallFamily instead')
  String get subtitle2Family => typography.titleSmallFamily;
  @Deprecated('Use titleSmall instead')
  TextStyle get subtitle2 => typography.titleSmall;
  @Deprecated('Use bodyMediumFamily instead')
  String get bodyText1Family => typography.bodyMediumFamily;
  @Deprecated('Use bodyMedium instead')
  TextStyle get bodyText1 => typography.bodyMedium;
  @Deprecated('Use bodySmallFamily instead')
  String get bodyText2Family => typography.bodySmallFamily;
  @Deprecated('Use bodySmall instead')
  TextStyle get bodyText2 => typography.bodySmall;

  String get displayLargeFamily => typography.displayLargeFamily;
  TextStyle get displayLarge => typography.displayLarge;
  String get displayMediumFamily => typography.displayMediumFamily;
  TextStyle get displayMedium => typography.displayMedium;
  String get displaySmallFamily => typography.displaySmallFamily;
  TextStyle get displaySmall => typography.displaySmall;
  String get headlineLargeFamily => typography.headlineLargeFamily;
  TextStyle get headlineLarge => typography.headlineLarge;
  String get headlineMediumFamily => typography.headlineMediumFamily;
  TextStyle get headlineMedium => typography.headlineMedium;
  String get headlineSmallFamily => typography.headlineSmallFamily;
  TextStyle get headlineSmall => typography.headlineSmall;
  String get titleLargeFamily => typography.titleLargeFamily;
  TextStyle get titleLarge => typography.titleLarge;
  String get titleMediumFamily => typography.titleMediumFamily;
  TextStyle get titleMedium => typography.titleMedium;
  String get titleSmallFamily => typography.titleSmallFamily;
  TextStyle get titleSmall => typography.titleSmall;
  String get labelLargeFamily => typography.labelLargeFamily;
  TextStyle get labelLarge => typography.labelLarge;
  String get labelMediumFamily => typography.labelMediumFamily;
  TextStyle get labelMedium => typography.labelMedium;
  String get labelSmallFamily => typography.labelSmallFamily;
  TextStyle get labelSmall => typography.labelSmall;
  String get bodyLargeFamily => typography.bodyLargeFamily;
  TextStyle get bodyLarge => typography.bodyLarge;
  String get bodyMediumFamily => typography.bodyMediumFamily;
  TextStyle get bodyMedium => typography.bodyMedium;
  String get bodySmallFamily => typography.bodySmallFamily;
  TextStyle get bodySmall => typography.bodySmall;

  Typography get typography => ThemeTypography(this);
}

class LightModeTheme extends FlutterFlowTheme {
  @Deprecated('Use primary instead')
  Color get primaryColor => primary;
  @Deprecated('Use secondary instead')
  Color get secondaryColor => secondary;
  @Deprecated('Use tertiary instead')
  Color get tertiaryColor => tertiary;

  late Color primary = const Color(0xFF2A3A8D);
  late Color secondary = const Color(0xFF076BCF);
  late Color tertiary = const Color(0xFF61646B);
  late Color alternate = const Color(0xFFFFFFFF);
  late Color primaryText = const Color(0xFF14181B);
  late Color secondaryText = const Color(0xFF57636C);
  late Color primaryBackground = const Color(0xFFF1F4F8);
  late Color secondaryBackground = const Color(0xFFFFFFFF);
  late Color accent1 = const Color(0x4C4B39EF);
  late Color accent2 = const Color(0x4D39D2C0);
  late Color accent3 = const Color(0x4DEE8B60);
  late Color accent4 = const Color(0xCCFFFFFF);
  late Color success = const Color(0xFF34A853);
  late Color warning = const Color(0xFFFFAA01);
  late Color error = const Color(0xFFFF5963);
  late Color info = const Color(0xFF076BCF);

  late Color primary100 = Color(0xFFD7DAE9);
  late Color primary200 = Color(0xFFC3C8DF);
  late Color primary300 = Color(0xFF9DA4CB);
  late Color primary400 = Color(0xFF7781B6);
  late Color primary500 = Color(0xFF505DA2);
  late Color primary600Default = Color(0xFF2A3A8D);
  late Color primary700 = Color(0xFF202C6B);
  late Color primary800 = Color(0xFF161E49);
  late Color primary900 = Color(0xFF0C1027);
  late Color primaryBGStroke2 = Color(0xFFFAFAFC);
  late Color primaryBGStroke5 = Color(0xFFF4F5F9);
  late Color primaryBGStroke10 = Color(0xFFEAEBF4);
  late Color primaryBGStroke15 = Color(0xFFDFE1EE);
  late Color primaryBGStroke20 = Color(0xFFD4D8E8);
  late Color primaryBGStroke25 = Color(0xFFCACEE3);
  late Color primaryBGStroke30 = Color(0xFFBFC4DD);
  late Color secondaryInfo100 = Color(0xFFBAD6F2);
  late Color secondaryInfo200 = Color(0xFF8DBBE9);
  late Color secondaryInfo300 = Color(0xFF60A0E0);
  late Color secondaryInfo500Default = Color(0xFF076BCF);
  late Color secondaryInfo700 = Color(0xFF05519D);
  late Color secondaryInfo800 = Color(0xFF044484);
  late Color secondaryInfo900 = Color(0xFF04386C);
  late Color secondaryInfoBGStroke2 = Color(0xFFF9FBFE);
  late Color secondaryInfoBGStroke5 = Color(0xFFF3F7FD);
  late Color secondaryInfoBGStroke10 = Color(0xFFE6F0FA);
  late Color secondaryInfoBGStroke15 = Color(0xFFDAE9F8);
  late Color secondaryInfoBGStroke20 = Color(0xFFCDE1F5);
  late Color secondaryInfoBGStroke25 = Color(0xFFC1DAF3);
  late Color secondaryInfoBGStroke30 = Color(0xFFB5D3F1);
  late Color success100 = Color(0xFFDCFAD8);
  late Color success200 = Color(0xFFB3F6B1);
  late Color success300 = Color(0xFF86E48C);
  late Color success400 = Color(0xFF62CA73);
  late Color success500Default = Color(0xFF34A853);
  late Color success600 = Color(0xFF27904D);
  late Color success700 = Color(0xFF1A7844);
  late Color success800 = Color(0xFF10623E);
  late Color success900 = Color(0xFF085038);
  late Color successBGStroke5 = Color(0xFFF5FBF6);
  late Color successBGStroke10 = Color(0xFFEBF6EE);
  late Color successBGStroke15 = Color(0xFFE1F2E5);
  late Color successBGStroke20 = Color(0xFFD6EEDD);
  late Color successBGStroke25 = Color(0xFFCCE9D4);
  late Color successBGStroke30 = Color(0xFFC2E5CB);
  late Color warning100 = Color(0xFFFFF4CC);
  late Color warning200 = Color(0xFFFEE799);
  late Color warning300 = Color(0xFFFFD565);
  late Color warning400 = Color(0xFFFFC53F);
  late Color warning500Default = Color(0xFFFFAA01);
  late Color warning600 = Color(0xFFDB8900);
  late Color warning700 = Color(0xFFB76D00);
  late Color warning800 = Color(0xFF945301);
  late Color warning900 = Color(0xFF7A4000);
  late Color warningBGStroke5 = Color(0xFFFFFBF2);
  late Color warningBGStroke10 = Color(0xFFFFF6E6);
  late Color warningBGStroke15 = Color(0xFFFFF2D9);
  late Color warningBGStroke20 = Color(0xFFFFEECC);
  late Color warningBGStroke25 = Color(0xFFFFEABF);
  late Color warningBGStroke30 = Color(0xFFFFE5B3);
  late Color danger100 = Color(0xFFFBE1D2);
  late Color danger200 = Color(0xFFF7BDA5);
  late Color danger300 = Color(0xFFE88C73);
  late Color danger400 = Color(0xFFD1604E);
  late Color danger500Default = Color(0xFFB3261D);
  late Color danger600 = Color(0xFF9A151A);
  late Color danger700 = Color(0xFF7F0F1B);
  late Color danger800 = Color(0xFF66091C);
  late Color danger900 = Color(0xFF55061C);
  late Color dangerBGStroke5 = Color(0xFFFBF4F4);
  late Color dangerBGStroke10 = Color(0xFFF7E9E8);
  late Color dangerBGStroke15 = Color(0xFFF4DEDD);
  late Color dangerBGStroke20 = Color(0xFFF0D4D2);
  late Color dangerBGStroke25 = Color(0xFFECC9C6);
  late Color dangerBGStroke30 = Color(0xFFE8BEBB);
  late Color neutral100 = Color(0xFFFFFFFF);
  late Color neutral200 = Color(0xFFF4F5F5);
  late Color neutral300 = Color(0xFFDFE0E2);
  late Color neutral400 = Color(0xFFBFC1C5);
  late Color neutral500Default = Color(0xFFA9ACB1);
  late Color neutral600 = Color(0xFF909296);
  late Color neutral700 = Color(0xFF74777A);
  late Color neutral800 = Color(0xFF616265);
  late Color neutral900 = Color(0xFF484A4C);
  late Color neutral1000 = Color(0xFF303133);
  late Color neutral1100 = Color(0xFF181919);
  late Color neutral1200 = Color(0xFF000000);
  late Color neutralBGStroke5 = Color(0xFFFBFBFB);
  late Color neutralBGStroke10 = Color(0xFFF6F7F7);
  late Color neutralBGStroke15 = Color(0xFFF2F3F3);
  late Color neutralBGStroke20 = Color(0xFFEEEEEF);
  late Color neutralBGStroke25 = Color(0xFFE9EAEB);
  late Color neutralBGStroke30 = Color(0xFFE5E6E8);
  late Color textBasic = Color(0xFF1C1D1F);
  late Color textPrimary = Color(0xFF2A3A8D);
  late Color textAlternative = Color(0xFFFFFFFF);
  late Color textTertiary = Color(0xFF61646B);
  late Color textDisabled = Color(0xFFA9ACB1);
  late Color secondaryInfo400 = Color(0xFF3486D8);
  late Color secondaryInfo600 = Color(0xFF065EB6);
  late Color borderColor = Color(0xFFADADAD);
  late Color buttonBackBorderText = Color(0xFF1F1F1F);
  late Color buttonBorderTextColor = Color(0xFF0675E2);
  late Color breadcrumbColor = Color(0xFF1A73E9);
  late Color primaryTxtClr = Color(0xFF1C1D1F);
  late Color secondaryTxtClr = Color(0xFF616265);
  late Color primaryHyperlinkTxtClr = Color(0xFF2A3A8D);
  late Color transactionDetailsContainerBg = Color(0xFFF9FBFE);
  late Color deleteBtnBorder = Color(0xFFB3261D);
  late Color modeOfOTPBorderClr = Color(0xFFBAD6F2);
  late Color activeIconBtnBgClr = Color(0xFF076BCF);
  late Color disbaleHyperlinkBtnTxtIconClr = Color(0xFFA9ACB1);
  late Color textFieldBorderColor = Color(0xFFBFC1C5);
  late Color deleteIcon = Color(0xFFB3261D);
  late Color fileAttachmentBorder = Color(0xFF1A7844);
  late Color errorText = Color(0xFFB3261D);
  late Color eyeIconClr = Color(0xFF798084);
  late Color fileNameTxtClr = Color(0xFF1A7844);
  late Color fileIconClr = Color(0xFF1A7844);
  late Color uploadIconClr = Color(0xFF076BCF);
  late Color uploadFileContainerBorder = Color(0xFF076BCF);
  late Color uploadFileTextClr = Color(0xFF61646B);
  late Color hyperlinkBtnIconClr = Color(0xFF076BCF);
  late Color unSelectedRadioBtnColor = Color(0xFF74777A);
  late Color formTxtBtnClr = Color(0xFF076BCF);
}

abstract class Typography {
  String get displayLargeFamily;
  TextStyle get displayLarge;
  String get displayMediumFamily;
  TextStyle get displayMedium;
  String get displaySmallFamily;
  TextStyle get displaySmall;
  String get headlineLargeFamily;
  TextStyle get headlineLarge;
  String get headlineMediumFamily;
  TextStyle get headlineMedium;
  String get headlineSmallFamily;
  TextStyle get headlineSmall;
  String get titleLargeFamily;
  TextStyle get titleLarge;
  String get titleMediumFamily;
  TextStyle get titleMedium;
  String get titleSmallFamily;
  TextStyle get titleSmall;
  String get labelLargeFamily;
  TextStyle get labelLarge;
  String get labelMediumFamily;
  TextStyle get labelMedium;
  String get labelSmallFamily;
  TextStyle get labelSmall;
  String get bodyLargeFamily;
  TextStyle get bodyLarge;
  String get bodyMediumFamily;
  TextStyle get bodyMedium;
  String get bodySmallFamily;
  TextStyle get bodySmall;
}

class ThemeTypography extends Typography {
  ThemeTypography(this.theme);

  final FlutterFlowTheme theme;

  String get displayLargeFamily => 'Inter';
  TextStyle get displayLarge => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 64.0,
      );
  String get displayMediumFamily => 'Inter';
  TextStyle get displayMedium => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 44.0,
      );
  String get displaySmallFamily => 'Inter';
  TextStyle get displaySmall => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 36.0,
      );
  String get headlineLargeFamily => 'Inter';
  TextStyle get headlineLarge => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 32.0,
      );
  String get headlineMediumFamily => 'Inter';
  TextStyle get headlineMedium => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 28.0,
      );
  String get headlineSmallFamily => 'Inter';
  TextStyle get headlineSmall => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 24.0,
      );
  String get titleLargeFamily => 'Inter';
  TextStyle get titleLarge => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 20.0,
      );
  String get titleMediumFamily => 'Inter';
  TextStyle get titleMedium => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 18.0,
      );
  String get titleSmallFamily => 'Inter';
  TextStyle get titleSmall => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.w600,
        fontSize: 16.0,
      );
  String get labelLargeFamily => 'Inter';
  TextStyle get labelLarge => GoogleFonts.getFont(
        'Inter',
        color: theme.secondaryText,
        fontWeight: FontWeight.normal,
        fontSize: 16.0,
      );
  String get labelMediumFamily => 'Inter';
  TextStyle get labelMedium => GoogleFonts.getFont(
        'Inter',
        color: theme.secondaryText,
        fontWeight: FontWeight.normal,
        fontSize: 14.0,
      );
  String get labelSmallFamily => 'Inter';
  TextStyle get labelSmall => GoogleFonts.getFont(
        'Inter',
        color: theme.secondaryText,
        fontWeight: FontWeight.normal,
        fontSize: 12.0,
      );
  String get bodyLargeFamily => 'Inter';
  TextStyle get bodyLarge => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.normal,
        fontSize: 16.0,
      );
  String get bodyMediumFamily => 'Inter';
  TextStyle get bodyMedium => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.normal,
        fontSize: 14.0,
      );
  String get bodySmallFamily => 'Inter';
  TextStyle get bodySmall => GoogleFonts.getFont(
        'Inter',
        color: theme.primaryText,
        fontWeight: FontWeight.normal,
        fontSize: 12.0,
      );
}

extension TextStyleHelper on TextStyle {
  TextStyle override({
    String? fontFamily,
    Color? color,
    double? fontSize,
    FontWeight? fontWeight,
    double? letterSpacing,
    FontStyle? fontStyle,
    bool useGoogleFonts = true,
    TextDecoration? decoration,
    double? lineHeight,
    List<Shadow>? shadows,
  }) =>
      useGoogleFonts
          ? GoogleFonts.getFont(
              fontFamily!,
              color: color ?? this.color,
              fontSize: fontSize ?? this.fontSize,
              letterSpacing: letterSpacing ?? this.letterSpacing,
              fontWeight: fontWeight ?? this.fontWeight,
              fontStyle: fontStyle ?? this.fontStyle,
              decoration: decoration,
              height: lineHeight,
              shadows: shadows,
            )
          : copyWith(
              fontFamily: fontFamily,
              color: color,
              fontSize: fontSize,
              letterSpacing: letterSpacing,
              fontWeight: fontWeight,
              fontStyle: fontStyle,
              decoration: decoration,
              height: lineHeight,
              shadows: shadows,
            );
}
