// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class InfoTableStruct extends BaseStruct {
  InfoTableStruct({
    String? cy,
    int? c200,
    int? c400,
    int? c800,
    int? total,
  })  : _cy = cy,
        _c200 = c200,
        _c400 = c400,
        _c800 = c800,
        _total = total;

  // "CY" field.
  String? _cy;
  String get cy => _cy ?? '';
  set cy(String? val) => _cy = val;

  bool hasCy() => _cy != null;

  // "C200" field.
  int? _c200;
  int get c200 => _c200 ?? 0;
  set c200(int? val) => _c200 = val;

  void incrementC200(int amount) => c200 = c200 + amount;

  bool hasC200() => _c200 != null;

  // "C400" field.
  int? _c400;
  int get c400 => _c400 ?? 0;
  set c400(int? val) => _c400 = val;

  void incrementC400(int amount) => c400 = c400 + amount;

  bool hasC400() => _c400 != null;

  // "C800" field.
  int? _c800;
  int get c800 => _c800 ?? 0;
  set c800(int? val) => _c800 = val;

  void incrementC800(int amount) => c800 = c800 + amount;

  bool hasC800() => _c800 != null;

  // "Total" field.
  int? _total;
  int get total => _total ?? 0;
  set total(int? val) => _total = val;

  void incrementTotal(int amount) => total = total + amount;

  bool hasTotal() => _total != null;

  static InfoTableStruct fromMap(Map<String, dynamic> data) => InfoTableStruct(
        cy: data['CY'] as String?,
        c200: castToType<int>(data['C200']),
        c400: castToType<int>(data['C400']),
        c800: castToType<int>(data['C800']),
        total: castToType<int>(data['Total']),
      );

  static InfoTableStruct? maybeFromMap(dynamic data) => data is Map
      ? InfoTableStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'CY': _cy,
        'C200': _c200,
        'C400': _c400,
        'C800': _c800,
        'Total': _total,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'CY': serializeParam(
          _cy,
          ParamType.String,
        ),
        'C200': serializeParam(
          _c200,
          ParamType.int,
        ),
        'C400': serializeParam(
          _c400,
          ParamType.int,
        ),
        'C800': serializeParam(
          _c800,
          ParamType.int,
        ),
        'Total': serializeParam(
          _total,
          ParamType.int,
        ),
      }.withoutNulls;

  static InfoTableStruct fromSerializableMap(Map<String, dynamic> data) =>
      InfoTableStruct(
        cy: deserializeParam(
          data['CY'],
          ParamType.String,
          false,
        ),
        c200: deserializeParam(
          data['C200'],
          ParamType.int,
          false,
        ),
        c400: deserializeParam(
          data['C400'],
          ParamType.int,
          false,
        ),
        c800: deserializeParam(
          data['C800'],
          ParamType.int,
          false,
        ),
        total: deserializeParam(
          data['Total'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'InfoTableStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is InfoTableStruct &&
        cy == other.cy &&
        c200 == other.c200 &&
        c400 == other.c400 &&
        c800 == other.c800 &&
        total == other.total;
  }

  @override
  int get hashCode => const ListEquality().hash([cy, c200, c400, c800, total]);
}

InfoTableStruct createInfoTableStruct({
  String? cy,
  int? c200,
  int? c400,
  int? c800,
  int? total,
}) =>
    InfoTableStruct(
      cy: cy,
      c200: c200,
      c400: c400,
      c800: c800,
      total: total,
    );
