// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NewsItemStruct extends BaseStruct {
  NewsItemStruct({
    String? title,
    DateTime? date,
    String? description,
  })  : _title = title,
        _date = date,
        _description = description;

  // "Title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "Date" field.
  DateTime? _date;
  DateTime? get date => _date;
  set date(DateTime? val) => _date = val;

  bool hasDate() => _date != null;

  // "Description" field.
  String? _description;
  String get description => _description ?? '';
  set description(String? val) => _description = val;

  bool hasDescription() => _description != null;

  static NewsItemStruct fromMap(Map<String, dynamic> data) => NewsItemStruct(
        title: data['Title'] as String?,
        date: data['Date'] as DateTime?,
        description: data['Description'] as String?,
      );

  static NewsItemStruct? maybeFromMap(dynamic data) =>
      data is Map ? NewsItemStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'Title': _title,
        'Date': _date,
        'Description': _description,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Title': serializeParam(
          _title,
          ParamType.String,
        ),
        'Date': serializeParam(
          _date,
          ParamType.DateTime,
        ),
        'Description': serializeParam(
          _description,
          ParamType.String,
        ),
      }.withoutNulls;

  static NewsItemStruct fromSerializableMap(Map<String, dynamic> data) =>
      NewsItemStruct(
        title: deserializeParam(
          data['Title'],
          ParamType.String,
          false,
        ),
        date: deserializeParam(
          data['Date'],
          ParamType.DateTime,
          false,
        ),
        description: deserializeParam(
          data['Description'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'NewsItemStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is NewsItemStruct &&
        title == other.title &&
        date == other.date &&
        description == other.description;
  }

  @override
  int get hashCode => const ListEquality().hash([title, date, description]);
}

NewsItemStruct createNewsItemStruct({
  String? title,
  DateTime? date,
  String? description,
}) =>
    NewsItemStruct(
      title: title,
      date: date,
      description: description,
    );
