// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TableExpandViewStruct extends BaseStruct {
  TableExpandViewStruct({
    DateTime? dateTime,
    String? description,
    String? status,
    String? dispatchDetails,
    bool? isExpanded,
  })  : _dateTime = dateTime,
        _description = description,
        _status = status,
        _dispatchDetails = dispatchDetails,
        _isExpanded = isExpanded;

  // "Date_Time" field.
  DateTime? _dateTime;
  DateTime? get dateTime => _dateTime;
  set dateTime(DateTime? val) => _dateTime = val;

  bool hasDateTime() => _dateTime != null;

  // "Description" field.
  String? _description;
  String get description => _description ?? '';
  set description(String? val) => _description = val;

  bool hasDescription() => _description != null;

  // "Status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "DispatchDetails" field.
  String? _dispatchDetails;
  String get dispatchDetails => _dispatchDetails ?? '';
  set dispatchDetails(String? val) => _dispatchDetails = val;

  bool hasDispatchDetails() => _dispatchDetails != null;

  // "isExpanded" field.
  bool? _isExpanded;
  bool get isExpanded => _isExpanded ?? false;
  set isExpanded(bool? val) => _isExpanded = val;

  bool hasIsExpanded() => _isExpanded != null;

  static TableExpandViewStruct fromMap(Map<String, dynamic> data) =>
      TableExpandViewStruct(
        dateTime: data['Date_Time'] as DateTime?,
        description: data['Description'] as String?,
        status: data['Status'] as String?,
        dispatchDetails: data['DispatchDetails'] as String?,
        isExpanded: data['isExpanded'] as bool?,
      );

  static TableExpandViewStruct? maybeFromMap(dynamic data) => data is Map
      ? TableExpandViewStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'Date_Time': _dateTime,
        'Description': _description,
        'Status': _status,
        'DispatchDetails': _dispatchDetails,
        'isExpanded': _isExpanded,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Date_Time': serializeParam(
          _dateTime,
          ParamType.DateTime,
        ),
        'Description': serializeParam(
          _description,
          ParamType.String,
        ),
        'Status': serializeParam(
          _status,
          ParamType.String,
        ),
        'DispatchDetails': serializeParam(
          _dispatchDetails,
          ParamType.String,
        ),
        'isExpanded': serializeParam(
          _isExpanded,
          ParamType.bool,
        ),
      }.withoutNulls;

  static TableExpandViewStruct fromSerializableMap(Map<String, dynamic> data) =>
      TableExpandViewStruct(
        dateTime: deserializeParam(
          data['Date_Time'],
          ParamType.DateTime,
          false,
        ),
        description: deserializeParam(
          data['Description'],
          ParamType.String,
          false,
        ),
        status: deserializeParam(
          data['Status'],
          ParamType.String,
          false,
        ),
        dispatchDetails: deserializeParam(
          data['DispatchDetails'],
          ParamType.String,
          false,
        ),
        isExpanded: deserializeParam(
          data['isExpanded'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'TableExpandViewStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is TableExpandViewStruct &&
        dateTime == other.dateTime &&
        description == other.description &&
        status == other.status &&
        dispatchDetails == other.dispatchDetails &&
        isExpanded == other.isExpanded;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([dateTime, description, status, dispatchDetails, isExpanded]);
}

TableExpandViewStruct createTableExpandViewStruct({
  DateTime? dateTime,
  String? description,
  String? status,
  String? dispatchDetails,
  bool? isExpanded,
}) =>
    TableExpandViewStruct(
      dateTime: dateTime,
      description: description,
      status: status,
      dispatchDetails: dispatchDetails,
      isExpanded: isExpanded,
    );
