// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProfileMenuStruct extends BaseStruct {
  ProfileMenuStruct({
    String? labelName,
    String? image,
  })  : _labelName = labelName,
        _image = image;

  // "labelName" field.
  String? _labelName;
  String get labelName => _labelName ?? '';
  set labelName(String? val) => _labelName = val;

  bool hasLabelName() => _labelName != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;

  bool hasImage() => _image != null;

  static ProfileMenuStruct fromMap(Map<String, dynamic> data) =>
      ProfileMenuStruct(
        labelName: data['labelName'] as String?,
        image: data['image'] as String?,
      );

  static ProfileMenuStruct? maybeFromMap(dynamic data) => data is Map
      ? ProfileMenuStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'labelName': _labelName,
        'image': _image,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'labelName': serializeParam(
          _labelName,
          ParamType.String,
        ),
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
      }.withoutNulls;

  static ProfileMenuStruct fromSerializableMap(Map<String, dynamic> data) =>
      ProfileMenuStruct(
        labelName: deserializeParam(
          data['labelName'],
          ParamType.String,
          false,
        ),
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'ProfileMenuStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ProfileMenuStruct &&
        labelName == other.labelName &&
        image == other.image;
  }

  @override
  int get hashCode => const ListEquality().hash([labelName, image]);
}

ProfileMenuStruct createProfileMenuStruct({
  String? labelName,
  String? image,
}) =>
    ProfileMenuStruct(
      labelName: labelName,
      image: image,
    );
