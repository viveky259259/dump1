// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MenuListItemsStruct extends BaseStruct {
  MenuListItemsStruct({
    List<String>? iconName,
    List<String>? menuName,
  })  : _iconName = iconName,
        _menuName = menuName;

  // "iconName" field.
  List<String>? _iconName;
  List<String> get iconName => _iconName ?? const [];
  set iconName(List<String>? val) => _iconName = val;

  void updateIconName(Function(List<String>) updateFn) {
    updateFn(_iconName ??= []);
  }

  bool hasIconName() => _iconName != null;

  // "menuName" field.
  List<String>? _menuName;
  List<String> get menuName => _menuName ?? const [];
  set menuName(List<String>? val) => _menuName = val;

  void updateMenuName(Function(List<String>) updateFn) {
    updateFn(_menuName ??= []);
  }

  bool hasMenuName() => _menuName != null;

  static MenuListItemsStruct fromMap(Map<String, dynamic> data) =>
      MenuListItemsStruct(
        iconName: getDataList(data['iconName']),
        menuName: getDataList(data['menuName']),
      );

  static MenuListItemsStruct? maybeFromMap(dynamic data) => data is Map
      ? MenuListItemsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'iconName': _iconName,
        'menuName': _menuName,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'iconName': serializeParam(
          _iconName,
          ParamType.String,
          isList: true,
        ),
        'menuName': serializeParam(
          _menuName,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static MenuListItemsStruct fromSerializableMap(Map<String, dynamic> data) =>
      MenuListItemsStruct(
        iconName: deserializeParam<String>(
          data['iconName'],
          ParamType.String,
          true,
        ),
        menuName: deserializeParam<String>(
          data['menuName'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'MenuListItemsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is MenuListItemsStruct &&
        listEquality.equals(iconName, other.iconName) &&
        listEquality.equals(menuName, other.menuName);
  }

  @override
  int get hashCode => const ListEquality().hash([iconName, menuName]);
}

MenuListItemsStruct createMenuListItemsStruct() => MenuListItemsStruct();
