// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Form15BranchDataStruct extends BaseStruct {
  Form15BranchDataStruct({
    int? sno,
    String? country,
    String? state,
    String? district,
    String? flat,
    String? road,
    int? pinCode,
    String? postOffice,
    String? area,
  })  : _sno = sno,
        _country = country,
        _state = state,
        _district = district,
        _flat = flat,
        _road = road,
        _pinCode = pinCode,
        _postOffice = postOffice,
        _area = area;

  // "Sno" field.
  int? _sno;
  int get sno => _sno ?? 0;
  set sno(int? val) => _sno = val;

  void incrementSno(int amount) => sno = sno + amount;

  bool hasSno() => _sno != null;

  // "Country" field.
  String? _country;
  String get country => _country ?? '';
  set country(String? val) => _country = val;

  bool hasCountry() => _country != null;

  // "State" field.
  String? _state;
  String get state => _state ?? '';
  set state(String? val) => _state = val;

  bool hasState() => _state != null;

  // "District" field.
  String? _district;
  String get district => _district ?? '';
  set district(String? val) => _district = val;

  bool hasDistrict() => _district != null;

  // "Flat" field.
  String? _flat;
  String get flat => _flat ?? '';
  set flat(String? val) => _flat = val;

  bool hasFlat() => _flat != null;

  // "Road" field.
  String? _road;
  String get road => _road ?? '';
  set road(String? val) => _road = val;

  bool hasRoad() => _road != null;

  // "PinCode" field.
  int? _pinCode;
  int get pinCode => _pinCode ?? 0;
  set pinCode(int? val) => _pinCode = val;

  void incrementPinCode(int amount) => pinCode = pinCode + amount;

  bool hasPinCode() => _pinCode != null;

  // "PostOffice" field.
  String? _postOffice;
  String get postOffice => _postOffice ?? '';
  set postOffice(String? val) => _postOffice = val;

  bool hasPostOffice() => _postOffice != null;

  // "Area" field.
  String? _area;
  String get area => _area ?? '';
  set area(String? val) => _area = val;

  bool hasArea() => _area != null;

  static Form15BranchDataStruct fromMap(Map<String, dynamic> data) =>
      Form15BranchDataStruct(
        sno: castToType<int>(data['Sno']),
        country: data['Country'] as String?,
        state: data['State'] as String?,
        district: data['District'] as String?,
        flat: data['Flat'] as String?,
        road: data['Road'] as String?,
        pinCode: castToType<int>(data['PinCode']),
        postOffice: data['PostOffice'] as String?,
        area: data['Area'] as String?,
      );

  static Form15BranchDataStruct? maybeFromMap(dynamic data) => data is Map
      ? Form15BranchDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'Sno': _sno,
        'Country': _country,
        'State': _state,
        'District': _district,
        'Flat': _flat,
        'Road': _road,
        'PinCode': _pinCode,
        'PostOffice': _postOffice,
        'Area': _area,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Sno': serializeParam(
          _sno,
          ParamType.int,
        ),
        'Country': serializeParam(
          _country,
          ParamType.String,
        ),
        'State': serializeParam(
          _state,
          ParamType.String,
        ),
        'District': serializeParam(
          _district,
          ParamType.String,
        ),
        'Flat': serializeParam(
          _flat,
          ParamType.String,
        ),
        'Road': serializeParam(
          _road,
          ParamType.String,
        ),
        'PinCode': serializeParam(
          _pinCode,
          ParamType.int,
        ),
        'PostOffice': serializeParam(
          _postOffice,
          ParamType.String,
        ),
        'Area': serializeParam(
          _area,
          ParamType.String,
        ),
      }.withoutNulls;

  static Form15BranchDataStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      Form15BranchDataStruct(
        sno: deserializeParam(
          data['Sno'],
          ParamType.int,
          false,
        ),
        country: deserializeParam(
          data['Country'],
          ParamType.String,
          false,
        ),
        state: deserializeParam(
          data['State'],
          ParamType.String,
          false,
        ),
        district: deserializeParam(
          data['District'],
          ParamType.String,
          false,
        ),
        flat: deserializeParam(
          data['Flat'],
          ParamType.String,
          false,
        ),
        road: deserializeParam(
          data['Road'],
          ParamType.String,
          false,
        ),
        pinCode: deserializeParam(
          data['PinCode'],
          ParamType.int,
          false,
        ),
        postOffice: deserializeParam(
          data['PostOffice'],
          ParamType.String,
          false,
        ),
        area: deserializeParam(
          data['Area'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Form15BranchDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Form15BranchDataStruct &&
        sno == other.sno &&
        country == other.country &&
        state == other.state &&
        district == other.district &&
        flat == other.flat &&
        road == other.road &&
        pinCode == other.pinCode &&
        postOffice == other.postOffice &&
        area == other.area;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [sno, country, state, district, flat, road, pinCode, postOffice, area]);
}

Form15BranchDataStruct createForm15BranchDataStruct({
  int? sno,
  String? country,
  String? state,
  String? district,
  String? flat,
  String? road,
  int? pinCode,
  String? postOffice,
  String? area,
}) =>
    Form15BranchDataStruct(
      sno: sno,
      country: country,
      state: state,
      district: district,
      flat: flat,
      road: road,
      pinCode: pinCode,
      postOffice: postOffice,
      area: area,
    );
