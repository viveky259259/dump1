// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TableExpandFileUploadStruct extends BaseStruct {
  TableExpandFileUploadStruct({
    String? fileName,
    String? fileSize,
  })  : _fileName = fileName,
        _fileSize = fileSize;

  // "FileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "FileSize" field.
  String? _fileSize;
  String get fileSize => _fileSize ?? '';
  set fileSize(String? val) => _fileSize = val;

  bool hasFileSize() => _fileSize != null;

  static TableExpandFileUploadStruct fromMap(Map<String, dynamic> data) =>
      TableExpandFileUploadStruct(
        fileName: data['FileName'] as String?,
        fileSize: data['FileSize'] as String?,
      );

  static TableExpandFileUploadStruct? maybeFromMap(dynamic data) => data is Map
      ? TableExpandFileUploadStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'FileName': _fileName,
        'FileSize': _fileSize,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'FileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'FileSize': serializeParam(
          _fileSize,
          ParamType.String,
        ),
      }.withoutNulls;

  static TableExpandFileUploadStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      TableExpandFileUploadStruct(
        fileName: deserializeParam(
          data['FileName'],
          ParamType.String,
          false,
        ),
        fileSize: deserializeParam(
          data['FileSize'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'TableExpandFileUploadStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is TableExpandFileUploadStruct &&
        fileName == other.fileName &&
        fileSize == other.fileSize;
  }

  @override
  int get hashCode => const ListEquality().hash([fileName, fileSize]);
}

TableExpandFileUploadStruct createTableExpandFileUploadStruct({
  String? fileName,
  String? fileSize,
}) =>
    TableExpandFileUploadStruct(
      fileName: fileName,
      fileSize: fileSize,
    );
