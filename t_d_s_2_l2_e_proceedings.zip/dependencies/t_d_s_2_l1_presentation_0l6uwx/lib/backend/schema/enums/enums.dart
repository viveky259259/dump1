import 'package:collection/collection.dart';

enum Status {
  error,
  information,
  name,
}

enum ToastMessage {
  Warning,
  Information,
  Success,
  Error,
  Alert,
}

enum AlertTextStatus {
  Warning,
  Information,
  Success,
  Error,
  Alert,
}

enum BadgeStatus {
  Information,
  Success,
  Warning,
  Error,
  Alert,
  Disabled,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (Status):
      return Status.values.deserialize(value) as T?;
    case (ToastMessage):
      return ToastMessage.values.deserialize(value) as T?;
    case (AlertTextStatus):
      return AlertTextStatus.values.deserialize(value) as T?;
    case (BadgeStatus):
      return BadgeStatus.values.deserialize(value) as T?;
    default:
      return null;
  }
}
