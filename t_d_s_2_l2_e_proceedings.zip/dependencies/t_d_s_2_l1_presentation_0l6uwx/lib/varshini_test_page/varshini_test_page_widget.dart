import '/ao_portal/badge/badge_widget.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'varshini_test_page_model.dart';
export 'varshini_test_page_model.dart';

class VarshiniTestPageWidget extends StatefulWidget {
  const VarshiniTestPageWidget({super.key});

  @override
  State<VarshiniTestPageWidget> createState() => _VarshiniTestPageWidgetState();
}

class _VarshiniTestPageWidgetState extends State<VarshiniTestPageWidget> {
  late VarshiniTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VarshiniTestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(10.0, 10.0, 0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                wrapWithModel(
                  model: _model.badgeModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: BadgeWidget(
                    keyPrefix: 'key',
                    description:
                        'Hearing Date Passed or Ageing of Case > 365 Days',
                    showIcon: true,
                    states: BadgeStatus.Information,
                  ),
                ),
                wrapWithModel(
                  model: _model.badgeModel2,
                  updateCallback: () => safeSetState(() {}),
                  child: BadgeWidget(
                    keyPrefix: 'key',
                    description:
                        'Hearing Date Passed or Ageing of Case > 365 Days',
                    showIcon: false,
                    states: BadgeStatus.Success,
                  ),
                ),
                wrapWithModel(
                  model: _model.badgeModel3,
                  updateCallback: () => safeSetState(() {}),
                  child: BadgeWidget(
                    keyPrefix: 'key',
                    description:
                        'Hearing Date Passed or Ageing of Case > 365 Days',
                    showIcon: false,
                    states: BadgeStatus.Warning,
                  ),
                ),
                wrapWithModel(
                  model: _model.badgeModel4,
                  updateCallback: () => safeSetState(() {}),
                  child: BadgeWidget(
                    keyPrefix: 'key',
                    description:
                        'Hearing Date Passed or Ageing of Case > 365 Days',
                    showIcon: false,
                    states: BadgeStatus.Error,
                  ),
                ),
                wrapWithModel(
                  model: _model.badgeModel5,
                  updateCallback: () => safeSetState(() {}),
                  child: BadgeWidget(
                    keyPrefix: 'key',
                    description:
                        'Hearing Date Passed or Ageing of Case > 365 Days',
                    showIcon: false,
                    states: BadgeStatus.Alert,
                  ),
                ),
                wrapWithModel(
                  model: _model.badgeModel6,
                  updateCallback: () => safeSetState(() {}),
                  child: BadgeWidget(
                    keyPrefix: 'key',
                    description:
                        'Hearing Date Passed or Ageing of Case > 365 Days',
                    showIcon: false,
                    states: BadgeStatus.Disabled,
                  ),
                ),
              ].divide(SizedBox(height: 20.0)),
            ),
          ),
        ),
      ),
    );
  }
}
