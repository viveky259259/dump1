import '/ao_portal/badge/badge_widget.dart';
import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'varshini_test_page_widget.dart' show VarshiniTestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VarshiniTestPageModel extends FlutterFlowModel<VarshiniTestPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Badge component.
  late BadgeModel badgeModel1;
  // Model for Badge component.
  late BadgeModel badgeModel2;
  // Model for Badge component.
  late BadgeModel badgeModel3;
  // Model for Badge component.
  late BadgeModel badgeModel4;
  // Model for Badge component.
  late BadgeModel badgeModel5;
  // Model for Badge component.
  late BadgeModel badgeModel6;

  @override
  void initState(BuildContext context) {
    badgeModel1 = createModel(context, () => BadgeModel());
    badgeModel2 = createModel(context, () => BadgeModel());
    badgeModel3 = createModel(context, () => BadgeModel());
    badgeModel4 = createModel(context, () => BadgeModel());
    badgeModel5 = createModel(context, () => BadgeModel());
    badgeModel6 = createModel(context, () => BadgeModel());
  }

  @override
  void dispose() {
    badgeModel1.dispose();
    badgeModel2.dispose();
    badgeModel3.dispose();
    badgeModel4.dispose();
    badgeModel5.dispose();
    badgeModel6.dispose();
  }
}
