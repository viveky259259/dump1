import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _socialMediaFamily = 'SocialMedia';
  static const String _customIconsFamily = 'CustomIcons';
  static const String _numberIconsFamily = 'NumberIcons';

  // SocialMedia
  static const IconData kfacebook =
      IconData(0xe800, fontFamily: _socialMediaFamily);
  static const IconData kinstagram =
      IconData(0xe801, fontFamily: _socialMediaFamily);
  static const IconData kx = IconData(0xe802, fontFamily: _socialMediaFamily);
  static const IconData kyoutube =
      IconData(0xe803, fontFamily: _socialMediaFamily);
  static const IconData klinkedin =
      IconData(0xe804, fontFamily: _socialMediaFamily);

  // CustomIcons
  static const IconData kicon =
      IconData(0xe800, fontFamily: _customIconsFamily);
  static const IconData ktextToSpeech =
      IconData(0xe801, fontFamily: _customIconsFamily);

  // NumberIcons
  static const IconData kstep1 =
      IconData(0xe800, fontFamily: _numberIconsFamily);
  static const IconData kstep5 =
      IconData(0xe801, fontFamily: _numberIconsFamily);
  static const IconData kstep6 =
      IconData(0xe802, fontFamily: _numberIconsFamily);
  static const IconData kstep7 =
      IconData(0xe803, fontFamily: _numberIconsFamily);
  static const IconData kstep11 =
      IconData(0xe804, fontFamily: _numberIconsFamily);
  static const IconData kstep4 =
      IconData(0xe805, fontFamily: _numberIconsFamily);
  static const IconData kstep3 =
      IconData(0xe806, fontFamily: _numberIconsFamily);
  static const IconData kstep8 =
      IconData(0xe807, fontFamily: _numberIconsFamily);
  static const IconData kstep12 =
      IconData(0xe808, fontFamily: _numberIconsFamily);
  static const IconData kstep9 =
      IconData(0xe809, fontFamily: _numberIconsFamily);
  static const IconData kstep2 =
      IconData(0xe80a, fontFamily: _numberIconsFamily);
  static const IconData kstep10 =
      IconData(0xe80b, fontFamily: _numberIconsFamily);
}
