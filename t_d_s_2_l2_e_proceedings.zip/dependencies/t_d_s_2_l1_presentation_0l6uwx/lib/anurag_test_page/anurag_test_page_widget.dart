import '/components/timer_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'anurag_test_page_model.dart';
export 'anurag_test_page_model.dart';

class AnuragTestPageWidget extends StatefulWidget {
  const AnuragTestPageWidget({super.key});

  @override
  State<AnuragTestPageWidget> createState() => _AnuragTestPageWidgetState();
}

class _AnuragTestPageWidgetState extends State<AnuragTestPageWidget> {
  late AnuragTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AnuragTestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.timerModel,
                updateCallback: () => safeSetState(() {}),
                child: TimerWidget(
                  keyPrefix: 'keyPrefix',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
