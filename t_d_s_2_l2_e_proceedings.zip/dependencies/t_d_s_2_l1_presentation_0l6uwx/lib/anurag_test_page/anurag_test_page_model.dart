import '/components/timer_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'anurag_test_page_widget.dart' show AnuragTestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AnuragTestPageModel extends FlutterFlowModel<AnuragTestPageWidget> {
  ///  Local state fields for this page.

  String? timerValue;

  ///  State fields for stateful widgets in this page.

  // Model for Timer component.
  late TimerModel timerModel;

  @override
  void initState(BuildContext context) {
    timerModel = createModel(context, () => TimerModel());
  }

  @override
  void dispose() {
    timerModel.dispose();
  }
}
