import '/components/info_tables_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'vaishali_testing_model.dart';
export 'vaishali_testing_model.dart';

class VaishaliTestingWidget extends StatefulWidget {
  const VaishaliTestingWidget({super.key});

  @override
  State<VaishaliTestingWidget> createState() => _VaishaliTestingWidgetState();
}

class _VaishaliTestingWidgetState extends State<VaishaliTestingWidget> {
  late VaishaliTestingModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VaishaliTestingModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.infoTablesModel,
                updateCallback: () => safeSetState(() {}),
                child: InfoTablesWidget(
                  infoTableDataList: FFAppState().InfoDataTable,
                  xAxis: [" ", "1234", "12455", "124356", "12345"],
                  yAxis: ["CY", "PY", "Growth"],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
