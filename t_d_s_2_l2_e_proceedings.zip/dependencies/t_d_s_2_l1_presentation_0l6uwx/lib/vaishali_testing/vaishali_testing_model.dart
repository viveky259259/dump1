import '/components/info_tables_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'vaishali_testing_widget.dart' show VaishaliTestingWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VaishaliTestingModel extends FlutterFlowModel<VaishaliTestingWidget> {
  ///  Local state fields for this page.

  int currentItem = 0;

  ///  State fields for stateful widgets in this page.

  // Model for InfoTables component.
  late InfoTablesModel infoTablesModel;

  @override
  void initState(BuildContext context) {
    infoTablesModel = createModel(context, () => InfoTablesModel());
  }

  @override
  void dispose() {
    infoTablesModel.dispose();
  }
}
