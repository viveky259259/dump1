import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/form15_c/info_alert/info_alert_widget.dart';
import 'dart:ui';
import 'somesh_page_widget.dart' show SomeshPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SomeshPageModel extends FlutterFlowModel<SomeshPageWidget> {
  ///  Local state fields for this page.

  List<TableExpandViewStruct> demo = [];
  void addToDemo(TableExpandViewStruct item) => demo.add(item);
  void removeFromDemo(TableExpandViewStruct item) => demo.remove(item);
  void removeAtIndexFromDemo(int index) => demo.removeAt(index);
  void insertAtIndexInDemo(int index, TableExpandViewStruct item) =>
      demo.insert(index, item);
  void updateDemoAtIndex(int index, Function(TableExpandViewStruct) updateFn) =>
      demo[index] = updateFn(demo[index]);

  ///  State fields for stateful widgets in this page.

  // Model for InfoAlert component.
  late InfoAlertModel infoAlertModel;

  @override
  void initState(BuildContext context) {
    infoAlertModel = createModel(context, () => InfoAlertModel());
  }

  @override
  void dispose() {
    infoAlertModel.dispose();
  }
}
