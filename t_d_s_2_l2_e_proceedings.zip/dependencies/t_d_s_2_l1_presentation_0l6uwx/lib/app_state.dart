import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<InfoTableStruct> _InfoDataTable = [
    InfoTableStruct.fromSerializableMap(jsonDecode(
        '{\"CY\":\"CY\",\"C200\":\"1234\",\"C400\":\"4567\",\"C800\":\"891230\",\"Total\":\"7868364\"}')),
    InfoTableStruct.fromSerializableMap(jsonDecode(
        '{\"CY\":\"PY\",\"C200\":\"1234\",\"C400\":\"1234567\",\"C800\":\"345678\",\"Total\":\"2457677\"}')),
    InfoTableStruct.fromSerializableMap(jsonDecode(
        '{\"CY\":\"Growth\",\"C200\":\"12345\",\"C400\":\"4444\",\"C800\":\"5667\",\"Total\":\"9098589\"}'))
  ];
  List<InfoTableStruct> get InfoDataTable => _InfoDataTable;
  set InfoDataTable(List<InfoTableStruct> value) {
    _InfoDataTable = value;
  }

  void addToInfoDataTable(InfoTableStruct value) {
    InfoDataTable.add(value);
  }

  void removeFromInfoDataTable(InfoTableStruct value) {
    InfoDataTable.remove(value);
  }

  void removeAtIndexFromInfoDataTable(int index) {
    InfoDataTable.removeAt(index);
  }

  void updateInfoDataTableAtIndex(
    int index,
    InfoTableStruct Function(InfoTableStruct) updateFn,
  ) {
    InfoDataTable[index] = updateFn(_InfoDataTable[index]);
  }

  void insertAtIndexInInfoDataTable(int index, InfoTableStruct value) {
    InfoDataTable.insert(index, value);
  }

  List<TableExpandViewStruct> _TableExpandDataTable = [
    TableExpandViewStruct.fromSerializableMap(jsonDecode(
        '{\"Date_Time\":\"1738732946654\",\"Description\":\"Lorem Epsum\",\"Status\":\"Done\",\"DispatchDetails\":\"Mailed to lorem@com\"}')),
    TableExpandViewStruct.fromSerializableMap(jsonDecode(
        '{\"Date_Time\":\"1738732991820\",\"Description\":\"Reply Received from Deductor\",\"Status\":\"Reply Received from Deductor\",\"DispatchDetails\":\"Mailed to lorem@com\"}')),
    TableExpandViewStruct.fromSerializableMap(jsonDecode(
        '{\"Date_Time\":\"1738733035583\",\"Description\":\"Reminder sent \",\"Status\":\"Attached Document\",\"DispatchDetails\":\"Mailed to lorem@com\"}'))
  ];
  List<TableExpandViewStruct> get TableExpandDataTable => _TableExpandDataTable;
  set TableExpandDataTable(List<TableExpandViewStruct> value) {
    _TableExpandDataTable = value;
  }

  void addToTableExpandDataTable(TableExpandViewStruct value) {
    TableExpandDataTable.add(value);
  }

  void removeFromTableExpandDataTable(TableExpandViewStruct value) {
    TableExpandDataTable.remove(value);
  }

  void removeAtIndexFromTableExpandDataTable(int index) {
    TableExpandDataTable.removeAt(index);
  }

  void updateTableExpandDataTableAtIndex(
    int index,
    TableExpandViewStruct Function(TableExpandViewStruct) updateFn,
  ) {
    TableExpandDataTable[index] = updateFn(_TableExpandDataTable[index]);
  }

  void insertAtIndexInTableExpandDataTable(
      int index, TableExpandViewStruct value) {
    TableExpandDataTable.insert(index, value);
  }

  List<TableExpandFileUploadStruct> _TableExpandFileUploaded = [
    TableExpandFileUploadStruct.fromSerializableMap(
        jsonDecode('{\"FileName\":\"OrderABC.pdf\",\"FileSize\":\"2 mb\"}')),
    TableExpandFileUploadStruct.fromSerializableMap(
        jsonDecode('{\"FileName\":\"OrderDEF.pdf\",\"FileSize\":\"3 mb\"}'))
  ];
  List<TableExpandFileUploadStruct> get TableExpandFileUploaded =>
      _TableExpandFileUploaded;
  set TableExpandFileUploaded(List<TableExpandFileUploadStruct> value) {
    _TableExpandFileUploaded = value;
  }

  void addToTableExpandFileUploaded(TableExpandFileUploadStruct value) {
    TableExpandFileUploaded.add(value);
  }

  void removeFromTableExpandFileUploaded(TableExpandFileUploadStruct value) {
    TableExpandFileUploaded.remove(value);
  }

  void removeAtIndexFromTableExpandFileUploaded(int index) {
    TableExpandFileUploaded.removeAt(index);
  }

  void updateTableExpandFileUploadedAtIndex(
    int index,
    TableExpandFileUploadStruct Function(TableExpandFileUploadStruct) updateFn,
  ) {
    TableExpandFileUploaded[index] = updateFn(_TableExpandFileUploaded[index]);
  }

  void insertAtIndexInTableExpandFileUploaded(
      int index, TableExpandFileUploadStruct value) {
    TableExpandFileUploaded.insert(index, value);
  }
}
