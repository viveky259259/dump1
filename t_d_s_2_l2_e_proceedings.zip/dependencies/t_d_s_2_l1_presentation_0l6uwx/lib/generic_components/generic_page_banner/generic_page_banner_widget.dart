import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_page_banner_model.dart';
export 'generic_page_banner_model.dart';

///  A widget that displays a banner with navigation buttons (Previous, Next,
/// Close)
///  and a message.
///
/// It also shows the current step out of the total steps.
///
///  The widget requires the following parameters:
///  - [keyPrefix]: A prefix for generating unique keys for the buttons.
///  - [message]: The message to be displayed in the banner.
///  - [onPreviousTap]: A callback function to be executed when the Previous
/// button is tapped.
///  - [onNextTap]: A callback function to be executed when the Next button is
/// tapped.
///  - [onCloseTap]: A callback function to be executed when the Close button
/// is tapped.
///  - [currentStep]: The current step number.
///  - [totalSteps]: The total number of steps.
class GenericPageBannerWidget extends StatefulWidget {
  const GenericPageBannerWidget({
    super.key,
    required this.keyPrefix,
    required this.message,
    required this.onPreviousTap,
    required this.onNextTap,
    required this.onCloseTap,
    required this.currentStep,
    required this.totalSteps,
  });

  final String? keyPrefix;
  final String? message;
  final Future Function()? onPreviousTap;
  final Future Function()? onNextTap;
  final Future Function()? onCloseTap;
  final int? currentStep;
  final int? totalSteps;

  @override
  State<GenericPageBannerWidget> createState() =>
      _GenericPageBannerWidgetState();
}

class _GenericPageBannerWidgetState extends State<GenericPageBannerWidget> {
  late GenericPageBannerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericPageBannerModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 28.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 48.0, 0.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                FFButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Generic_PageBanner',
                          'Prev_Button')),
                  onPressed: (widget!.currentStep == 1)
                      ? null
                      : () async {
                          await widget.onPreviousTap?.call();
                        },
                  text: 'Prev',
                  icon: Icon(
                    Icons.arrow_back_ios,
                    size: 15.0,
                  ),
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).primary600Default,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                SizedBox(
                  height: 20.0,
                  child: VerticalDivider(
                    thickness: 1.0,
                    color: FlutterFlowTheme.of(context).neutral400,
                  ),
                ),
                Text(
                  '${widget!.currentStep?.toString()}/${widget!.totalSteps?.toString()}',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).primary600Default,
                        letterSpacing: 0.0,
                      ),
                ),
                SizedBox(
                  height: 20.0,
                  child: VerticalDivider(
                    thickness: 1.0,
                    color: FlutterFlowTheme.of(context).neutral400,
                  ),
                ),
                FFButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Generic_PageBanner',
                          'Next_Button')),
                  onPressed: (widget!.currentStep == widget!.totalSteps)
                      ? null
                      : () async {
                          await widget.onNextTap?.call();
                        },
                  text: 'Next',
                  icon: Icon(
                    Icons.arrow_forward_ios_sharp,
                    size: 15.0,
                  ),
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconAlignment: IconAlignment.end,
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).primary600Default,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ].divide(SizedBox(width: 8.0)).addToStart(SizedBox(width: 48.0)),
            ),
            Text(
              widget!.message!,
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).primary600Default,
                    fontSize: 12.0,
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            FlutterFlowIconButton(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Generic_PageBanner',
                      'Close_Button')),
              borderRadius: 8.0,
              fillColor: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
              icon: Icon(
                Icons.clear,
                color: FlutterFlowTheme.of(context).primary400,
                size: 18.0,
              ),
              onPressed: () async {
                await widget.onCloseTap?.call();
              },
            ),
          ],
        ),
      ),
    );
  }
}
