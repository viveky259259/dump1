import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_text_with_label_model.dart';
export 'generic_text_with_label_model.dart';

/// A text componemt that will dispaly details along with the label.
class GenericTextWithLabelWidget extends StatefulWidget {
  const GenericTextWithLabelWidget({
    super.key,
    required this.labelText,
    required this.descripitionText,
    required this.keyPrefix,
  });

  final String? labelText;
  final String? descripitionText;
  final String? keyPrefix;

  @override
  State<GenericTextWithLabelWidget> createState() =>
      _GenericTextWithLabelWidgetState();
}

class _GenericTextWithLabelWidgetState
    extends State<GenericTextWithLabelWidget> {
  late GenericTextWithLabelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericTextWithLabelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // A label text that give the description about the input text.
        //
        Semantics(
          label:
              'A labeltext that give the description about the input text.\n',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Generic_Text_with_Label', 'Label_Text')),
            widget!.labelText!,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).neutral900,
                  fontSize: 12.0,
                  letterSpacing: 0.0,
                ),
          ),
        ),

        // An input text to display the details of user mainly used in confirmation page.
        Semantics(
          label:
              'An input text to display the details of user mainly used in confirmation page.',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Generic_Text_with_Label',
                'Descripition_Text')),
            widget!.descripitionText!,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).textBasic,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ),
      ].divide(SizedBox(height: 4.0)),
    );
  }
}
