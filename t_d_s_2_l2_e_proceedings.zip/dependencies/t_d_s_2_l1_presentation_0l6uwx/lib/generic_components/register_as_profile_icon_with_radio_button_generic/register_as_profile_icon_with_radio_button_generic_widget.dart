import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'register_as_profile_icon_with_radio_button_generic_model.dart';
export 'register_as_profile_icon_with_radio_button_generic_model.dart';

class RegisterAsProfileIconWithRadioButtonGenericWidget extends StatefulWidget {
  const RegisterAsProfileIconWithRadioButtonGenericWidget({
    super.key,
    required this.height,
    required this.width,
    double? iconContainerDiameter,
    required this.icon,
    String? selectionText,
    required this.keyPrefix,
    bool? isRadioEnabled,
    this.onRadioClickAction,
  })  : this.iconContainerDiameter = iconContainerDiameter ?? 80.0,
        this.selectionText = selectionText ?? 'Taxpayer',
        this.isRadioEnabled = isRadioEnabled ?? false;

  final double? height;
  final double? width;
  final double iconContainerDiameter;
  final Widget? icon;
  final String selectionText;
  final String? keyPrefix;
  final bool isRadioEnabled;
  final Future Function()? onRadioClickAction;

  @override
  State<RegisterAsProfileIconWithRadioButtonGenericWidget> createState() =>
      _RegisterAsProfileIconWithRadioButtonGenericWidgetState();
}

class _RegisterAsProfileIconWithRadioButtonGenericWidgetState
    extends State<RegisterAsProfileIconWithRadioButtonGenericWidget> {
  late RegisterAsProfileIconWithRadioButtonGenericModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => RegisterAsProfileIconWithRadioButtonGenericModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 0.0, 0.0),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: valueOrDefault<double>(
                    widget!.iconContainerDiameter,
                    80.0,
                  ),
                  height: valueOrDefault<double>(
                    widget!.iconContainerDiameter,
                    80.0,
                  ),
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).alternate,
                    shape: BoxShape.circle,
                  ),
                  child: widget!.icon!,
                ),
                Container(
                  width: valueOrDefault<double>(
                    widget!.iconContainerDiameter,
                    80.0,
                  ),
                  height: valueOrDefault<double>(
                    widget!.iconContainerDiameter,
                    80.0,
                  ),
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).alternate,
                    shape: BoxShape.circle,
                  ),
                  child: widget!.icon!,
                ),
                Container(
                  width: valueOrDefault<double>(
                    widget!.iconContainerDiameter,
                    80.0,
                  ),
                  height: valueOrDefault<double>(
                    widget!.iconContainerDiameter,
                    80.0,
                  ),
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).alternate,
                    shape: BoxShape.circle,
                  ),
                  child: widget!.icon!,
                ),
              ].divide(SizedBox(width: 20.0)),
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
            child: FlutterFlowRadioButton(
              options: [
                valueOrDefault<String>(
                  widget!.selectionText,
                  'Taxpayer',
                ),
                'PAO',
                'Deductor'
              ].toList(),
              onChanged: (val) async {
                safeSetState(() {});
                await widget.onRadioClickAction?.call();
              },
              controller: _model.radioButtonValueController ??=
                  FormFieldController<String>(null),
              optionHeight: 24.0,
              textStyle: FlutterFlowTheme.of(context).labelMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
              selectedTextStyle:
                  FlutterFlowTheme.of(context).headlineMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).secondary,
                        fontSize: 14.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                      ),
              textPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 20.0, 0.0),
              buttonPosition: RadioButtonPosition.left,
              direction: Axis.horizontal,
              radioButtonColor: FlutterFlowTheme.of(context).primary,
              inactiveRadioButtonColor:
                  FlutterFlowTheme.of(context).secondaryText,
              toggleable: false,
              horizontalAlignment: WrapAlignment.center,
              verticalAlignment: WrapCrossAlignment.center,
            ),
          ),
        ],
      ),
    );
  }
}
