import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String WarningToastMessageLabel = 'Warning : ';
  static const String InformationToastMessageTextLabel = 'Information : ';
  static const String SuccessToastMessageTextLabel = 'Success : ';
  static const String ErrorToastMessageTextLabel = 'Error :';
  static const String AlertToastMessageTextLabel = 'Alert :';
}
