import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'menu_side_bar_for_one_component_do_not_use_it_model.dart';
export 'menu_side_bar_for_one_component_do_not_use_it_model.dart';

class MenuSideBarForOneComponentDoNotUseItWidget extends StatefulWidget {
  const MenuSideBarForOneComponentDoNotUseItWidget({
    super.key,
    required this.keyPrefix,
    this.onTab,
    int? currentItem,
  }) : this.currentItem = currentItem ?? 0;

  final String? keyPrefix;
  final Future Function(int selectedIndex)? onTab;
  final int currentItem;

  @override
  State<MenuSideBarForOneComponentDoNotUseItWidget> createState() =>
      _MenuSideBarForOneComponentDoNotUseItWidgetState();
}

class _MenuSideBarForOneComponentDoNotUseItWidgetState
    extends State<MenuSideBarForOneComponentDoNotUseItWidget> {
  late MenuSideBarForOneComponentDoNotUseItModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => MenuSideBarForOneComponentDoNotUseItModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(-1.0, -1.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Color(0xFFF9FBFE),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTab?.call(
                          0,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget!.currentItem == 0
                              ? Color(0xFFE6F0FA)
                              : Color(0x00000000),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 14.0, 12.0, 14.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  FaIcon(
                                    FontAwesomeIcons.userCircle,
                                    color: widget!.currentItem == 0
                                        ? Color(0xFF076BCF)
                                        : FlutterFlowTheme.of(context)
                                            .neutral900,
                                    size: 20.0,
                                  ),
                                  Text(
                                    'My Profile',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: widget!.currentItem == 0
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .neutral900,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ].divide(SizedBox(width: 12.0)),
                              ),
                              if (widget!.currentItem == 0)
                                Icon(
                                  Icons.keyboard_arrow_right_sharp,
                                  color: widget!.currentItem == 0
                                      ? Color(0xFF076BCF)
                                      : FlutterFlowTheme.of(context).neutral900,
                                  size: 20.0,
                                ),
                            ].divide(SizedBox(width: 8.0)),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTab?.call(
                          1,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget!.currentItem == 1
                              ? Color(0xFFE6F0FA)
                              : Color(0x00000000),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 14.0, 12.0, 14.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Icon(
                                Icons.format_list_numbered,
                                color: widget!.currentItem == 1
                                    ? Color(0xFF076BCF)
                                    : FlutterFlowTheme.of(context).neutral900,
                                size: 20.0,
                              ),
                              Text(
                                'Main/Additional Charge',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: widget!.currentItem == 1
                                          ? Color(0xFF076BCF)
                                          : FlutterFlowTheme.of(context)
                                              .neutral900,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              if (widget!.currentItem == 1)
                                Icon(
                                  Icons.keyboard_arrow_right_sharp,
                                  color: widget!.currentItem == 1
                                      ? Color(0xFF076BCF)
                                      : FlutterFlowTheme.of(context).neutral900,
                                  size: 20.0,
                                ),
                            ].divide(SizedBox(width: 8.0)),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTab?.call(
                          2,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget!.currentItem == 2
                              ? Color(0xFFE6F0FA)
                              : Color(0x00000000),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 14.0, 12.0, 14.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Icon(
                                Icons.manage_accounts_outlined,
                                color: widget!.currentItem == 2
                                    ? Color(0xFF076BCF)
                                    : FlutterFlowTheme.of(context).neutral900,
                                size: 20.0,
                              ),
                              Text(
                                'Sub - User Management',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: widget!.currentItem == 2
                                          ? Color(0xFF076BCF)
                                          : FlutterFlowTheme.of(context)
                                              .neutral900,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              if (widget!.currentItem == 2)
                                Icon(
                                  Icons.keyboard_arrow_right_sharp,
                                  color: widget!.currentItem == 2
                                      ? Color(0xFF076BCF)
                                      : FlutterFlowTheme.of(context).neutral900,
                                  size: 20.0,
                                ),
                            ].divide(SizedBox(width: 8.0)),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTab?.call(
                          3,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget!.currentItem == 3
                              ? Color(0xFFE6F0FA)
                              : Color(0x00000000),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 14.0, 12.0, 14.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Icon(
                                Icons.password_sharp,
                                color: widget!.currentItem == 3
                                    ? Color(0xFF076BCF)
                                    : FlutterFlowTheme.of(context).neutral900,
                                size: 20.0,
                              ),
                              Text(
                                'Change Password',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: widget!.currentItem == 3
                                          ? Color(0xFF076BCF)
                                          : FlutterFlowTheme.of(context)
                                              .neutral900,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              if (widget!.currentItem == 3)
                                Icon(
                                  Icons.keyboard_arrow_right_sharp,
                                  color: widget!.currentItem == 3
                                      ? Color(0xFF076BCF)
                                      : FlutterFlowTheme.of(context).neutral900,
                                  size: 20.0,
                                ),
                            ].divide(SizedBox(width: 8.0)),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTab?.call(
                          4,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget!.currentItem == 4
                              ? Color(0xFFE6F0FA)
                              : Color(0x00000000),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 14.0, 12.0, 14.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Icon(
                                Icons.list_alt_rounded,
                                color: widget!.currentItem == 4
                                    ? Color(0xFF076BCF)
                                    : FlutterFlowTheme.of(context).neutral900,
                                size: 20.0,
                              ),
                              Text(
                                'Update / Register DSC',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: widget!.currentItem == 4
                                          ? Color(0xFF076BCF)
                                          : FlutterFlowTheme.of(context)
                                              .neutral900,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              if (widget!.currentItem == 4)
                                Icon(
                                  Icons.keyboard_arrow_right_sharp,
                                  color: widget!.currentItem == 4
                                      ? Color(0xFF076BCF)
                                      : FlutterFlowTheme.of(context)
                                          .primaryText,
                                  size: 20.0,
                                ),
                            ].divide(SizedBox(width: 8.0)),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTab?.call(
                          5,
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: widget!.currentItem == 5
                              ? Color(0xFFE6F0FA)
                              : Color(0x00000000),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 14.0, 12.0, 14.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Icon(
                                Icons.logout,
                                color: widget!.currentItem == 5
                                    ? Color(0xFF076BCF)
                                    : FlutterFlowTheme.of(context).neutral900,
                                size: 20.0,
                              ),
                              Text(
                                'Logout',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: widget!.currentItem == 5
                                          ? Color(0xFF076BCF)
                                          : FlutterFlowTheme.of(context)
                                              .neutral900,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              if (widget!.currentItem == 5)
                                Icon(
                                  Icons.keyboard_arrow_right_sharp,
                                  color: widget!.currentItem == 5
                                      ? Color(0xFF076BCF)
                                      : FlutterFlowTheme.of(context).neutral900,
                                  size: 20.0,
                                ),
                            ].divide(SizedBox(width: 8.0)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
