import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'presentation_generic_menu_side_bar_basic_widget.dart'
    show PresentationGenericMenuSideBarBasicWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationGenericMenuSideBarBasicModel
    extends FlutterFlowModel<PresentationGenericMenuSideBarBasicWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
