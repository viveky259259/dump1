import '/backend/schema/structs/index.dart';
import '/components/file_uploaded_view_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'table_file_upload_dialog_model.dart';
export 'table_file_upload_dialog_model.dart';

class TableFileUploadDialogWidget extends StatefulWidget {
  const TableFileUploadDialogWidget({
    super.key,
    required this.keyPrefix,
    this.previewIcon,
    this.dowmloadIcon,
    required this.fileUploadList,
  });

  final String? keyPrefix;
  final Future Function()? previewIcon;
  final Future Function()? dowmloadIcon;
  final List<TableExpandFileUploadStruct>? fileUploadList;

  @override
  State<TableFileUploadDialogWidget> createState() =>
      _TableFileUploadDialogWidgetState();
}

class _TableFileUploadDialogWidgetState
    extends State<TableFileUploadDialogWidget> {
  late TableFileUploadDialogModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TableFileUploadDialogModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 320.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        boxShadow: [
          BoxShadow(
            blurRadius: 0.0,
            color: Color(0x00000026),
            offset: Offset(
              12.0,
              0.0,
            ),
            spreadRadius: 0.0,
          )
        ],
        border: Border.all(
          color: FlutterFlowTheme.of(context).tertiary,
        ),
      ),
      child: Builder(
        builder: (context) {
          final fileUploadList = widget!.fileUploadList!.toList();

          return ListView.builder(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            itemCount: fileUploadList.length,
            itemBuilder: (context, fileUploadListIndex) {
              final fileUploadListItem = fileUploadList[fileUploadListIndex];
              return FileUploadedViewWidget(
                key: Key(
                    'Keyz3x_${fileUploadListIndex}_of_${fileUploadList.length}'),
                height: 48.0,
                width: 301.0,
                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                    widget!.keyPrefix!,
                    'TableFileUploadDialog',
                    'FileUploadedView'),
                fileName: fileUploadListItem.fileName,
                fileSize: fileUploadListItem.fileSize,
                onTabEyeIconAction: () async {
                  await widget.previewIcon?.call();
                },
                onTabDownloadIconAction: () async {
                  await widget.dowmloadIcon?.call();
                },
              );
            },
          );
        },
      ),
    );
  }
}
