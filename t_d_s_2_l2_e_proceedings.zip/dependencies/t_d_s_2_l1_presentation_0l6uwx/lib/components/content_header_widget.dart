import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'content_header_model.dart';
export 'content_header_model.dart';

/// A customizable header widget that displays either a primary or secondary
/// header,
/// depending on the `showPrimaryHeader` flag.
///
/// The widget is designed to show a large,
/// bold primary header or a smaller, secondary header with a trailing title.
///
///  **State Variables:**
///
/// `_model`: An instance of `ContentHeaderModel` that manages the logic for
/// the widget's data.
///
/// **Constructor Parameters:**
/// `primaryHeader`: The text content for the primary header (displayed when
/// `showPrimaryHeader` is true).
/// `secondaryHeaderTitle`: The text content for the secondary header
/// (displayed when `showPrimaryHeader` is false).
/// `secondaryHeaderTrailingTitle`: The text content for the trailing title on
/// the secondary header.
///  `showPrimaryHeader`: A boolean flag to determine whether to display the
/// primary header (true) or secondary header (false).
/// `keyPrefix`: A prefix to be used in generating unique keys for widget
/// elements.
class ContentHeaderWidget extends StatefulWidget {
  const ContentHeaderWidget({
    super.key,
    this.primaryHeader,
    this.secondaryHeaderTitle,
    this.secondaryHeaderTrailingTitle,
    required this.showPrimaryHeader,
    required this.keyPrefix,
  });

  final String? primaryHeader;
  final String? secondaryHeaderTitle;
  final String? secondaryHeaderTrailingTitle;
  final bool? showPrimaryHeader;
  final String? keyPrefix;

  @override
  State<ContentHeaderWidget> createState() => _ContentHeaderWidgetState();
}

class _ContentHeaderWidgetState extends State<ContentHeaderWidget> {
  late ContentHeaderModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ContentHeaderModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Builder(
        builder: (context) {
          if (widget!.showPrimaryHeader ?? false) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!, 'ContentHeader', 'pText')),
                  valueOrDefault<String>(
                    widget!.primaryHeader,
                    'hello',
                  ),
                  style: GoogleFonts.getFont(
                    'Inter',
                    color: FlutterFlowTheme.of(context).primary600Default,
                    fontWeight: FontWeight.bold,
                    fontSize: 24.0,
                  ),
                ),
                Divider(
                  thickness: 1.0,
                  color: Color(0xFFDFE0E2),
                ),
              ],
            );
          } else {
            return Container(
              decoration: BoxDecoration(),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!, 'ContentHeader', 'Stextleft')),
                    valueOrDefault<String>(
                      widget!.secondaryHeaderTitle,
                      'sh',
                    ),
                    style: GoogleFonts.getFont(
                      'Inter',
                      color: FlutterFlowTheme.of(context).primary,
                      fontWeight: FontWeight.bold,
                      fontSize: 24.0,
                    ),
                  ),
                  Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!, 'ContentHeader', 'Stextright')),
                    valueOrDefault<String>(
                      widget!.secondaryHeaderTrailingTitle,
                      'tt',
                    ),
                    style: GoogleFonts.getFont(
                      'Inter',
                      color: FlutterFlowTheme.of(context).tertiary,
                      fontSize: 14.0,
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
