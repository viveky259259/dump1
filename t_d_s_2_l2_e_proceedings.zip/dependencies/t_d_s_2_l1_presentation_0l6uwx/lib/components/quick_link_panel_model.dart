import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'quick_link_panel_widget.dart' show QuickLinkPanelWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuickLinkPanelModel extends FlutterFlowModel<QuickLinkPanelWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
