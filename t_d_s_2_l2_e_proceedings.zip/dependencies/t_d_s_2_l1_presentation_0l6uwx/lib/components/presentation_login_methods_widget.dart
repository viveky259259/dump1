import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_login_methods_model.dart';
export 'presentation_login_methods_model.dart';

class PresentationLoginMethodsWidget extends StatefulWidget {
  const PresentationLoginMethodsWidget({
    super.key,
    required this.labelText,
    this.leadingIcon,
    this.infoText1,
    required this.infoText2,
    this.infoText3,
    required this.keyPrefix,
    required this.onTap,
    bool? isTextVisible,
    bool? isLinkVisible,
    required this.width,
    required this.height,
  })  : this.isTextVisible = isTextVisible ?? false,
        this.isLinkVisible = isLinkVisible ?? false;

  final String? labelText;
  final Widget? leadingIcon;
  final String? infoText1;
  final String? infoText2;
  final String? infoText3;
  final String? keyPrefix;
  final Future Function()? onTap;
  final bool isTextVisible;
  final bool isLinkVisible;
  final double? width;
  final double? height;

  @override
  State<PresentationLoginMethodsWidget> createState() =>
      _PresentationLoginMethodsWidgetState();
}

class _PresentationLoginMethodsWidgetState
    extends State<PresentationLoginMethodsWidget> {
  late PresentationLoginMethodsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationLoginMethodsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                'keyPrefix', 'Presentation_LoginMethods', 'Container_Heading')),
            decoration: BoxDecoration(),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Presentation_LoginMethods',
                          'Leading_Icon')),
                  child: widget!.leadingIcon!,
                ),
                FFButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'keyPrefix',
                          'Presentation_LoginMethods',
                          'LoginMethods_Button')),
                  onPressed: () {
                    print('Button pressed ...');
                  },
                  text: widget!.labelText!,
                  icon: Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 15.0,
                  ),
                  options: FFButtonOptions(
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    iconAlignment: IconAlignment.end,
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 4.0, 0.0),
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context)
                              .secondaryInfo500Default,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(0.0),
                  ),
                ),
              ],
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (widget!.isTextVisible)
                Text(
                  widget!.infoText1!,
                  style: GoogleFonts.getFont(
                    'Inter',
                    color: FlutterFlowTheme.of(context).neutral900,
                    fontWeight: FontWeight.w500,
                    fontSize: 14.0,
                  ),
                ),
              Wrap(
                spacing: 0.0,
                runSpacing: 0.0,
                alignment: WrapAlignment.start,
                crossAxisAlignment: WrapCrossAlignment.start,
                direction: Axis.horizontal,
                runAlignment: WrapAlignment.start,
                verticalDirection: VerticalDirection.down,
                clipBehavior: Clip.none,
                children: [
                  Text(
                    widget!.infoText2!,
                    textAlign: TextAlign.start,
                    maxLines: 5,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).neutral900,
                          letterSpacing: 0.0,
                        ),
                  ),
                  if (widget!.isLinkVisible)
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTap?.call();
                      },
                      child: Text(
                        valueOrDefault<String>(
                          widget!.infoText3,
                          'infoText3',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).primary,
                              letterSpacing: 0.0,
                              decoration: TextDecoration.underline,
                              lineHeight: 1.5,
                            ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
