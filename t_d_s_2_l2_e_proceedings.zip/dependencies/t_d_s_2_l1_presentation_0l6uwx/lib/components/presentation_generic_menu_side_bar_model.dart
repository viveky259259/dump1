import '/components/presentation_generic_menu_side_bar_basic_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'presentation_generic_menu_side_bar_widget.dart'
    show PresentationGenericMenuSideBarWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationGenericMenuSideBarModel
    extends FlutterFlowModel<PresentationGenericMenuSideBarWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Presentation_Generic_MenuSideBarBasic component.
  late PresentationGenericMenuSideBarBasicModel
      presentationGenericMenuSideBarBasicModel1;
  // Model for Presentation_Generic_MenuSideBarBasic component.
  late PresentationGenericMenuSideBarBasicModel
      presentationGenericMenuSideBarBasicModel2;
  // Model for Presentation_Generic_MenuSideBarBasic component.
  late PresentationGenericMenuSideBarBasicModel
      presentationGenericMenuSideBarBasicModel3;
  // Model for Presentation_Generic_MenuSideBarBasic component.
  late PresentationGenericMenuSideBarBasicModel
      presentationGenericMenuSideBarBasicModel4;
  // Model for Presentation_Generic_MenuSideBarBasic component.
  late PresentationGenericMenuSideBarBasicModel
      presentationGenericMenuSideBarBasicModel5;
  // Model for Presentation_Generic_MenuSideBarBasic component.
  late PresentationGenericMenuSideBarBasicModel
      presentationGenericMenuSideBarBasicModel6;

  @override
  void initState(BuildContext context) {
    presentationGenericMenuSideBarBasicModel1 =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());
    presentationGenericMenuSideBarBasicModel2 =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());
    presentationGenericMenuSideBarBasicModel3 =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());
    presentationGenericMenuSideBarBasicModel4 =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());
    presentationGenericMenuSideBarBasicModel5 =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());
    presentationGenericMenuSideBarBasicModel6 =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());
  }

  @override
  void dispose() {
    presentationGenericMenuSideBarBasicModel1.dispose();
    presentationGenericMenuSideBarBasicModel2.dispose();
    presentationGenericMenuSideBarBasicModel3.dispose();
    presentationGenericMenuSideBarBasicModel4.dispose();
    presentationGenericMenuSideBarBasicModel5.dispose();
    presentationGenericMenuSideBarBasicModel6.dispose();
  }
}
