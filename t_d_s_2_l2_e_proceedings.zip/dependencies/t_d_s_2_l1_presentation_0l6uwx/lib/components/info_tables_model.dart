import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'info_tables_widget.dart' show InfoTablesWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InfoTablesModel extends FlutterFlowModel<InfoTablesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
