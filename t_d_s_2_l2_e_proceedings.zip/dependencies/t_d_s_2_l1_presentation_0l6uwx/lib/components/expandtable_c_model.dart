import '/backend/schema/structs/index.dart';
import '/components/table_file_upload_dialog_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'expandtable_c_widget.dart' show ExpandtableCWidget;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ExpandtableCModel extends FlutterFlowModel<ExpandtableCWidget> {
  ///  Local state fields for this component.

  List<TableExpandViewStruct> tableExpandDataTable = [];
  void addToTableExpandDataTable(TableExpandViewStruct item) =>
      tableExpandDataTable.add(item);
  void removeFromTableExpandDataTable(TableExpandViewStruct item) =>
      tableExpandDataTable.remove(item);
  void removeAtIndexFromTableExpandDataTable(int index) =>
      tableExpandDataTable.removeAt(index);
  void insertAtIndexInTableExpandDataTable(
          int index, TableExpandViewStruct item) =>
      tableExpandDataTable.insert(index, item);
  void updateTableExpandDataTableAtIndex(
          int index, Function(TableExpandViewStruct) updateFn) =>
      tableExpandDataTable[index] = updateFn(tableExpandDataTable[index]);

  List<TableExpandFileUploadStruct> fileUploadTableExpand = [];
  void addToFileUploadTableExpand(TableExpandFileUploadStruct item) =>
      fileUploadTableExpand.add(item);
  void removeFromFileUploadTableExpand(TableExpandFileUploadStruct item) =>
      fileUploadTableExpand.remove(item);
  void removeAtIndexFromFileUploadTableExpand(int index) =>
      fileUploadTableExpand.removeAt(index);
  void insertAtIndexInFileUploadTableExpand(
          int index, TableExpandFileUploadStruct item) =>
      fileUploadTableExpand.insert(index, item);
  void updateFileUploadTableExpandAtIndex(
          int index, Function(TableExpandFileUploadStruct) updateFn) =>
      fileUploadTableExpand[index] = updateFn(fileUploadTableExpand[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
