import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'info_tables_model.dart';
export 'info_tables_model.dart';

class InfoTablesWidget extends StatefulWidget {
  const InfoTablesWidget({
    super.key,
    required this.infoTableDataList,
    required this.xAxis,
    required this.yAxis,
  });

  final List<InfoTableStruct>? infoTableDataList;
  final List<String>? xAxis;
  final List<String>? yAxis;

  @override
  State<InfoTablesWidget> createState() => _InfoTablesWidgetState();
}

class _InfoTablesWidgetState extends State<InfoTablesWidget> {
  late InfoTablesModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InfoTablesModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Align(
            alignment: AlignmentDirectional(-1.0, -1.0),
            child: Container(
              height: 138.0,
              decoration: BoxDecoration(),
              child: Align(
                alignment: AlignmentDirectional(-1.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 41.0, 0.0),
                  child: Text(
                    'Hello World',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            child: Align(
              alignment: AlignmentDirectional(-1.0, -1.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 12.0, 8.0),
                      child: Container(
                        height: 30.0,
                        constraints: BoxConstraints(
                          minWidth: 428.0,
                        ),
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 0.0, 10.0, 0.0),
                          child: Builder(
                            builder: (context) {
                              final xAxisValue = widget!.xAxis!.toList();

                              return Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: List.generate(xAxisValue.length,
                                    (xAxisValueIndex) {
                                  final xAxisValueItem =
                                      xAxisValue[xAxisValueIndex];
                                  return Expanded(
                                    child: Container(
                                      decoration: BoxDecoration(),
                                      child: Text(
                                        (widget!.xAxis!
                                            .elementAtOrNull(xAxisValueIndex))!,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                  );
                                }),
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  Flexible(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4.0),
                        border: Border.all(
                          color: Color(0xFFD5D5D5),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Flexible(
                            child: Builder(
                              builder: (context) {
                                final infoTableData =
                                    widget!.infoTableDataList!.toList();

                                return ListView.builder(
                                  padding: EdgeInsets.zero,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.vertical,
                                  itemCount: infoTableData.length,
                                  itemBuilder: (context, infoTableDataIndex) {
                                    final infoTableDataItem =
                                        infoTableData[infoTableDataIndex];
                                    return Container(
                                      height: 40.0,
                                      decoration: BoxDecoration(
                                        color: (infoTableDataIndex % 2)
                                                    .toString() ==
                                                '0'
                                            ? FlutterFlowTheme.of(context)
                                                .secondaryBackground
                                            : Color(0xFFF9FAFF),
                                      ),
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 0.0, 10.0, 0.0),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Expanded(
                                              child: Text(
                                                (widget!.yAxis!.elementAtOrNull(
                                                    infoTableDataIndex))!,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                infoTableDataItem.c200
                                                    .toString(),
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      color: (infoTableDataIndex ==
                                                                  widget!.infoTableDataList!
                                                                          .length -
                                                                      1) ==
                                                              true
                                                          ? Color(0xFF077528)
                                                          : FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                infoTableDataItem.c400
                                                    .toString(),
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      color: (infoTableDataIndex ==
                                                                  widget!.infoTableDataList!
                                                                          .length -
                                                                      1) ==
                                                              true
                                                          ? Color(0xFF077528)
                                                          : FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                infoTableDataItem.c800
                                                    .toString(),
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      color: (infoTableDataIndex ==
                                                                  widget!.infoTableDataList!
                                                                          .length -
                                                                      1) ==
                                                              true
                                                          ? Color(0xFF077528)
                                                          : FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Text(
                                                infoTableDataItem.total
                                                    .toString(),
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      color: (infoTableDataIndex ==
                                                                  widget!.infoTableDataList!
                                                                          .length -
                                                                      1) ==
                                                              true
                                                          ? Color(0xFF077528)
                                                          : FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
