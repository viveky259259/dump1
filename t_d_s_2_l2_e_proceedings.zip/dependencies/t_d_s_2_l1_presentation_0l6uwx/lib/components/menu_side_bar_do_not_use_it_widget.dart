import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'menu_side_bar_do_not_use_it_model.dart';
export 'menu_side_bar_do_not_use_it_model.dart';

class MenuSideBarDoNotUseItWidget extends StatefulWidget {
  const MenuSideBarDoNotUseItWidget({
    super.key,
    required this.keyPrefix,
    this.onTab,
    this.currentItem,
    this.menuItem,
  });

  final String? keyPrefix;
  final Future Function(int selectedIndex)? onTab;
  final int? currentItem;
  final List<String>? menuItem;

  @override
  State<MenuSideBarDoNotUseItWidget> createState() =>
      _MenuSideBarDoNotUseItWidgetState();
}

class _MenuSideBarDoNotUseItWidgetState
    extends State<MenuSideBarDoNotUseItWidget> {
  late MenuSideBarDoNotUseItModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MenuSideBarDoNotUseItModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(-1.0, -1.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Align(
            alignment: AlignmentDirectional(-1.0, -1.0),
            child: Container(
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
              ),
              child: Align(
                alignment: AlignmentDirectional(-1.0, -1.0),
                child: Builder(
                  builder: (context) {
                    final menuItem = widget!.menuItem?.toList() ?? [];

                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: List.generate(menuItem.length, (menuItemIndex) {
                        final menuItemItem = menuItem[menuItemIndex];
                        return Align(
                          alignment: AlignmentDirectional(-1.0, -1.0),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await widget.onTab?.call(
                                menuItemIndex,
                              );
                            },
                            child: Container(
                              height: 48.0,
                              decoration: BoxDecoration(
                                color: widget!.currentItem == (menuItemIndex)
                                    ? Color(0xFFE6F0FA)
                                    : Color(0x00000000),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Builder(
                                    builder: (context) {
                                      if ((menuItemIndex) == 0) {
                                        return FaIcon(
                                          FontAwesomeIcons.userCircle,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        );
                                      } else if ((menuItemIndex) == 1) {
                                        return Icon(
                                          Icons.format_list_numbered,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        );
                                      } else if ((menuItemIndex) == 2) {
                                        return Icon(
                                          Icons.manage_accounts_outlined,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        );
                                      } else if ((menuItemIndex) == 3) {
                                        return Icon(
                                          Icons.password_outlined,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        );
                                      } else if ((menuItemIndex) == 4) {
                                        return Icon(
                                          Icons.list_alt,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        );
                                      } else {
                                        return Icon(
                                          Icons.logout,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        );
                                      }
                                    },
                                  ),
                                  Flexible(
                                    child: Text(
                                      menuItemItem,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: widget!.currentItem ==
                                                    (menuItemIndex)
                                                ? Color(0xFF076BCF)
                                                : FlutterFlowTheme.of(context)
                                                    .primaryText,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                  ),
                                  if (widget!.currentItem == (menuItemIndex))
                                    Flexible(
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            8.0, 0.0, 0.0, 0.0),
                                        child: Icon(
                                          Icons.keyboard_arrow_right,
                                          color: widget!.currentItem ==
                                                  (menuItemIndex)
                                              ? Color(0xFF076BCF)
                                              : FlutterFlowTheme.of(context)
                                                  .primaryText,
                                          size: 20.0,
                                        ),
                                      ),
                                    ),
                                ]
                                    .divide(SizedBox(width: 12.0))
                                    .around(SizedBox(width: 12.0)),
                              ),
                            ),
                          ),
                        );
                      }),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
