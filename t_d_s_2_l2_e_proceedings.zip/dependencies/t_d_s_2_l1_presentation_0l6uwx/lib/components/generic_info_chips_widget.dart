import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_info_chips_model.dart';
export 'generic_info_chips_model.dart';

class GenericInfoChipsWidget extends StatefulWidget {
  const GenericInfoChipsWidget({
    super.key,
    required this.keyPrefix,
    required this.icon,
    required this.number,
    required this.title,
  });

  final String? keyPrefix;
  final Widget? icon;
  final int? number;
  final String? title;

  @override
  State<GenericInfoChipsWidget> createState() => _GenericInfoChipsWidgetState();
}

class _GenericInfoChipsWidgetState extends State<GenericInfoChipsWidget> {
  late GenericInfoChipsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericInfoChipsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label:
          'This container has the icon of the InfoChip & its title wrapped inside it.',
      child: Container(
        decoration: BoxDecoration(),
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Flexible(
                child: Semantics(
                  label:
                      'This container has the icon of the InfoChip & number wrapped inside it.',
                  child: Container(
                    width: 50.0,
                    height: 70.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).primaryBGStroke10,
                      borderRadius: BorderRadius.circular(24.0),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).primary300,
                        width: 1.0,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Semantics(
                          label: 'This is the InfoChip icon.',
                          child: Container(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Generic_InfoChips', 'InfoChip_Icon')),
                            child: widget!.icon!,
                          ),
                        ),
                        Semantics(
                          label:
                              'This is the amount/quantity number of the InfoChip.',
                          child: Text(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Generic_InfoChips', 'InfoChip_Number')),
                            valueOrDefault<String>(
                              widget!.number?.toString(),
                              'number',
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context).primary,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ]
                          .divide(SizedBox(height: 10.0))
                          .addToStart(SizedBox(height: 15.0)),
                    ),
                  ),
                ),
              ),
              Semantics(
                label: 'This is the title of the InfoChip.',
                child: Text(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Generic_InfoChips',
                          'InfoChip_Title')),
                  valueOrDefault<String>(
                    widget!.title,
                    'title',
                  ),
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).textBasic,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
            ].divide(SizedBox(height: 10.0)),
          ),
        ),
      ),
    );
  }
}
