import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'menu_side_bar_for_one_component_do_not_use_it_widget.dart'
    show MenuSideBarForOneComponentDoNotUseItWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MenuSideBarForOneComponentDoNotUseItModel
    extends FlutterFlowModel<MenuSideBarForOneComponentDoNotUseItWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
