import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'file_uploaded_view_model.dart';
export 'file_uploaded_view_model.dart';

/// Component to dispaly the uploaded file.
class FileUploadedViewWidget extends StatefulWidget {
  const FileUploadedViewWidget({
    super.key,
    this.height,
    this.width,
    required this.keyPrefix,
    required this.fileName,
    required this.fileSize,
    this.onTabEyeIconAction,
    this.onTabDownloadIconAction,
  });

  final double? height;
  final double? width;
  final String? keyPrefix;
  final String? fileName;
  final String? fileSize;
  final Future Function()? onTabEyeIconAction;
  final Future Function()? onTabDownloadIconAction;

  @override
  State<FileUploadedViewWidget> createState() => _FileUploadedViewWidgetState();
}

class _FileUploadedViewWidgetState extends State<FileUploadedViewWidget> {
  late FileUploadedViewModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FileUploadedViewModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).neutral100,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Flexible(
            child: Text(
              '${widget!.fileName} (${widget!.fileSize} )',
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).textBasic,
                    letterSpacing: 0.0,
                  ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).neutral100,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsets.all(6.0),
                  child: InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      await widget.onTabEyeIconAction?.call();
                    },
                    child: Icon(
                      Icons.remove_red_eye_outlined,
                      color: FlutterFlowTheme.of(context).neutral800,
                      size: 20.0,
                    ),
                  ),
                ),
                SizedBox(
                  height: 22.0,
                  child: VerticalDivider(
                    thickness: 2.0,
                    color: FlutterFlowTheme.of(context).neutral400,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(6.0),
                  child: InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      await widget.onTabDownloadIconAction?.call();
                    },
                    child: Icon(
                      Icons.download_outlined,
                      color: FlutterFlowTheme.of(context).neutral800,
                      size: 20.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ].divide(SizedBox(width: 8.0)),
      ),
    );
  }
}
