import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_generic_menu_side_bar_basic_model.dart';
export 'presentation_generic_menu_side_bar_basic_model.dart';

class PresentationGenericMenuSideBarBasicWidget extends StatefulWidget {
  const PresentationGenericMenuSideBarBasicWidget({
    super.key,
    required this.keyPrefix,
    this.onTab,
    int? currentItem,
    int? setItem,
    this.iconName,
    this.proFileName,
  })  : this.currentItem = currentItem ?? 0,
        this.setItem = setItem ?? 0;

  final String? keyPrefix;
  final Future Function(int selectedIndex)? onTab;
  final int currentItem;
  final int setItem;
  final Widget? iconName;
  final String? proFileName;

  @override
  State<PresentationGenericMenuSideBarBasicWidget> createState() =>
      _PresentationGenericMenuSideBarBasicWidgetState();
}

class _PresentationGenericMenuSideBarBasicWidgetState
    extends State<PresentationGenericMenuSideBarBasicWidget> {
  late PresentationGenericMenuSideBarBasicModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => PresentationGenericMenuSideBarBasicModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            await widget.onTab?.call(
              widget!.setItem,
            );
          },
          child: Container(
            decoration: BoxDecoration(
              color: widget!.currentItem == widget!.setItem
                  ? Color(0xFFE6F0FA)
                  : Color(0x00000000),
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(12.0, 14.0, 12.0, 14.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      widget!.iconName!,
                      Text(
                        valueOrDefault<String>(
                          widget!.proFileName,
                          'My Profile',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: widget!.currentItem == widget!.setItem
                                  ? Color(0xFF076BCF)
                                  : FlutterFlowTheme.of(context).neutral900,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ].divide(SizedBox(width: 12.0)),
                  ),
                  if (widget!.currentItem == widget!.setItem)
                    Icon(
                      Icons.keyboard_arrow_right_sharp,
                      color: widget!.currentItem == widget!.setItem
                          ? Color(0xFF076BCF)
                          : FlutterFlowTheme.of(context).neutral900,
                      size: 20.0,
                    ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
