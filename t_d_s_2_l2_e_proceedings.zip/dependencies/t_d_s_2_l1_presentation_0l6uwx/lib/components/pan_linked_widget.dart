import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'pan_linked_model.dart';
export 'pan_linked_model.dart';

class PanLinkedWidget extends StatefulWidget {
  const PanLinkedWidget({
    super.key,
    required this.keyprefix,
    required this.height,
    required this.width,
    required this.isLinked,
    required this.onTap,
  });

  final String? keyprefix;
  final double? height;
  final double? width;
  final bool? isLinked;
  final Future Function()? onTap;

  @override
  State<PanLinkedWidget> createState() => _PanLinkedWidgetState();
}

class _PanLinkedWidgetState extends State<PanLinkedWidget> {
  late PanLinkedModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PanLinkedModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
            child: Text(
              'Hello World',
              style: FlutterFlowTheme.of(context).bodySmall.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).neutral900,
                    letterSpacing: 0.0,
                  ),
            ),
          ),
          Container(
            decoration: BoxDecoration(),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Builder(
                  builder: (context) {
                    if (widget!.isLinked ?? false) {
                      return Container(
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsets.all(1.75),
                          child: Icon(
                            Icons.check_circle_outline_outlined,
                            color: FlutterFlowTheme.of(context).success600,
                            size: 17.5,
                          ),
                        ),
                      );
                    } else {
                      return Container(
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsets.all(1.75),
                          child: Icon(
                            Icons.error_outline_outlined,
                            color:
                                FlutterFlowTheme.of(context).danger500Default,
                            size: 17.5,
                          ),
                        ),
                      );
                    }
                  },
                ),
                Text(
                  'Hello World',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: widget!.isLinked!
                            ? FlutterFlowTheme.of(context).success600
                            : FlutterFlowTheme.of(context).danger500Default,
                        letterSpacing: 0.0,
                      ),
                ),
                if (!widget!.isLinked!)
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(5.0, 0.0, 0.0, 3.0),
                    child: InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTap?.call();
                      },
                      child: Text(
                        'Hello World',
                        style: FlutterFlowTheme.of(context).bodySmall.override(
                              fontFamily: 'Inter',
                              color:
                                  FlutterFlowTheme.of(context).secondaryInfo600,
                              letterSpacing: 0.0,
                              decoration: TextDecoration.underline,
                            ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
