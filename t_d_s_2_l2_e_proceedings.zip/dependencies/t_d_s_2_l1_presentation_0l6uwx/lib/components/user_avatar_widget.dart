import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'user_avatar_model.dart';
export 'user_avatar_model.dart';

/// "User_Avatar is designed to display the user details like name, role and
/// profile picture.
///
/// If edit icon is required on your screen click the showEditIcon which will
/// execute the callback of that
/// Parameters:
/// keyPrefix: String
/// Use keyprefix to generate unique keys which will be used for testing
/// name:String
/// Pass the name of the user from the backend
/// role:String
/// Pass the role of the user from the backend
/// image: Image Path
/// Send the image path for profile photo
/// showEditIcon:Boolean
/// Boolean value to show or hide edit button.
/// editAction:Action
/// Pass the action to be performed when edit button is visible."
class UserAvatarWidget extends StatefulWidget {
  const UserAvatarWidget({
    super.key,
    required this.keyPrefix,
    required this.name,
    required this.role,
    this.image,
    bool? showEditIcon,
    this.editAction,
  }) : this.showEditIcon = showEditIcon ?? false;

  final String? keyPrefix;
  final String? name;
  final String? role;
  final String? image;
  final bool showEditIcon;
  final Future Function()? editAction;

  @override
  State<UserAvatarWidget> createState() => _UserAvatarWidgetState();
}

class _UserAvatarWidgetState extends State<UserAvatarWidget> {
  late UserAvatarModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => UserAvatarModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // User_Avatar is designed to display the user details like name, role and profile picture. If edit icon is required on your screen click the showEditIcon which will execute the callback
        Container(
      height: 77.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6.0),
        border: Border.all(
          color: FlutterFlowTheme.of(context).secondaryInfo300,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Semantics(
                label:
                    'It will conditionally render the container when a profile photo of the user is passed.',
                child: Builder(
                  builder: (context) {
                    if (widget!.image != null && widget!.image != '') {
                      return Semantics(
                        label:
                            'It will show the profile photo of the user when image is passed',
                        child: Container(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'User_Avatar', 'Profile_Photo_Container')),
                          width: 61.0,
                          height: 61.0,
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).neutralBGStroke25,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8.0),
                                child: Image.network(
                                  'https://picsum.photos/seed/184/600',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              if (widget!.showEditIcon)
                                Align(
                                  alignment: AlignmentDirectional(-1.0, 1.0),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        2.0, 0.0, 0.0, 2.0),
                                    child: Semantics(
                                      label:
                                          'It will show the edit icon conditionally when the boolean value is set true.',
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          await widget.editAction?.call();
                                        },
                                        child: Container(
                                          width: 24.0,
                                          height: 24.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(4.0),
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .neutral400,
                                            ),
                                          ),
                                          child: Icon(
                                            key: ValueKey(
                                                t_d_s_2_l1_logic_2wrus1_functions
                                                    .generateL1KeyValue(
                                                        widget!.keyPrefix!,
                                                        'User_Avatar',
                                                        'Icon')),
                                            Icons.edit_outlined,
                                            color: FlutterFlowTheme.of(context)
                                                .neutral800,
                                            size: 15.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    } else {
                      return Semantics(
                        label:
                            'It will show the default profile icon when no image path is passed',
                        child: Container(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'User_Avatar', 'Default_Profile_Container')),
                          width: 61.0,
                          height: 61.0,
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).neutralBGStroke25,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Stack(
                            children: [
                              Align(
                                alignment: AlignmentDirectional(0.0, 1.0),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 0.0, 10.0, 0.0),
                                  child: FaIcon(
                                    FontAwesomeIcons.solidUser,
                                    color:
                                        FlutterFlowTheme.of(context).primary500,
                                    size: 47.0,
                                  ),
                                ),
                              ),
                              if (widget!.showEditIcon)
                                Align(
                                  alignment: AlignmentDirectional(-1.0, 1.0),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        2.0, 0.0, 0.0, 2.0),
                                    child: Semantics(
                                      label:
                                          'It will show the edit icon conditionally when the boolean value is set true.',
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          await widget.editAction?.call();
                                        },
                                        child: Container(
                                          width: 24.0,
                                          height: 24.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(4.0),
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .neutral400,
                                            ),
                                          ),
                                          child: Icon(
                                            Icons.edit_outlined,
                                            color: FlutterFlowTheme.of(context)
                                                .neutral800,
                                            size: 15.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(12.0, 18.0, 0.0, 18.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Semantics(
                      label: 'Name of the user',
                      child: Text(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'User_Avatar', 'Name_Text')),
                        valueOrDefault<String>(
                          widget!.name,
                          'Name',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).textPrimary,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Semantics(
                      label: 'role of the user',
                      child: Text(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'User_Avatar', 'Role_Text')),
                        valueOrDefault<String>(
                          widget!.role,
                          'DLC_C_256_1',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).neutral800,
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ),
                ].divide(SizedBox(height: 2.0)),
              ),
            ),
          ),
        ].addToStart(SizedBox(width: 8.0)).addToEnd(SizedBox(width: 25.0)),
      ),
    );
  }
}
