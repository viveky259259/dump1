import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'p_d_f_viewer_footer_model.dart';
export 'p_d_f_viewer_footer_model.dart';

class PDFViewerFooterWidget extends StatefulWidget {
  const PDFViewerFooterWidget({
    super.key,
    required this.keyPrefix,
    required this.onTapBack,
    this.zoomIn,
    this.zoomOut,
    this.onTapDownload,
    this.onTapGenerate,
  });

  final String? keyPrefix;
  final Future Function()? onTapBack;
  final Future Function()? zoomIn;
  final Future Function()? zoomOut;
  final Future Function()? onTapDownload;
  final Future Function()? onTapGenerate;

  @override
  State<PDFViewerFooterWidget> createState() => _PDFViewerFooterWidgetState();
}

class _PDFViewerFooterWidgetState extends State<PDFViewerFooterWidget> {
  late PDFViewerFooterModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PDFViewerFooterModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        boxShadow: [
          BoxShadow(
            blurRadius: 14.0,
            color: Color(0x00000014),
            offset: Offset(
              -1.0,
              4.0,
            ),
            spreadRadius: 0.0,
          )
        ],
        border: Border.all(
          color: FlutterFlowTheme.of(context).neutral300,
          width: 0.5,
        ),
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(48.0, 8.0, 48.0, 8.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            FFButtonWidget(
              onPressed: () async {
                // onTapBack
                await widget.onTapBack?.call();
              },
              text: 'Back',
              options: FFButtonOptions(
                height: 28.0,
                padding: EdgeInsetsDirectional.fromSTEB(19.0, 4.0, 19.0, 4.0),
                iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                color: FlutterFlowTheme.of(context).secondaryBackground,
                textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).primary600Default,
                      fontSize: 14.0,
                      letterSpacing: 0.0,
                      fontWeight: FontWeight.w500,
                    ),
                elevation: 0.0,
                borderSide: BorderSide(
                  color: FlutterFlowTheme.of(context).primary600Default,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(4.0),
              ),
            ),
            Container(
              decoration: BoxDecoration(),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  FlutterFlowIconButton(
                    borderRadius: 8.0,
                    fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                    icon: Icon(
                      Icons.add,
                      color: FlutterFlowTheme.of(context).primary600Default,
                      size: 20.0,
                    ),
                    onPressed: () async {
                      // zoomIn
                      await widget.zoomIn?.call();
                    },
                  ),
                  Text(
                    'Zoom In/Out',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: FlutterFlowTheme.of(context).textBasic,
                          letterSpacing: 0.0,
                        ),
                  ),
                  FlutterFlowIconButton(
                    borderRadius: 8.0,
                    fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                    icon: Icon(
                      Icons.remove_rounded,
                      color: FlutterFlowTheme.of(context).primary600Default,
                      size: 16.0,
                    ),
                    onPressed: () async {
                      // zoomOut
                      await widget.zoomOut?.call();
                    },
                  ),
                ].divide(SizedBox(width: 16.0)),
              ),
            ),
            Container(
              decoration: BoxDecoration(),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  FFButtonWidget(
                    onPressed: () async {
                      // onTapDownload
                      await widget.onTapDownload?.call();
                    },
                    text: 'Download',
                    icon: Icon(
                      Icons.download_outlined,
                      size: 15.0,
                    ),
                    options: FFButtonOptions(
                      height: 28.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(12.0, 4.0, 12.0, 4.0),
                      iconAlignment: IconAlignment.start,
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      textStyle: FlutterFlowTheme.of(context)
                          .titleSmall
                          .override(
                            fontFamily: 'Inter',
                            color:
                                FlutterFlowTheme.of(context).primary600Default,
                            fontSize: 14.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.w500,
                          ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                  ),
                  FFButtonWidget(
                    onPressed: () async {
                      // onTapGenerate
                      await widget.onTapGenerate?.call();
                    },
                    text: 'Generate and Digitally sign',
                    options: FFButtonOptions(
                      height: 28.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(12.0, 4.0, 12.0, 4.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: FlutterFlowTheme.of(context).primary600Default,
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Inter',
                                color: Colors.white,
                                fontSize: 14.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w500,
                              ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                  ),
                ].divide(SizedBox(width: 20.0)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
