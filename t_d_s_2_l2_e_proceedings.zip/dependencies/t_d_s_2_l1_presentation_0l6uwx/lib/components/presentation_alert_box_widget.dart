import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_alert_box_model.dart';
export 'presentation_alert_box_model.dart';

/// "A versatile box component designed to display additional information,
/// context, or actions related to a primary content area.
///
///
///
/// Parameters: title: String
/// The title of the card, displayed prominently at the top.
/// content: String
/// The main content of the card, which can include text, images, or other
/// HTML elements.
/// icon: Icon (Optional)
/// An icon displayed at the top of the card, often used to represent the
/// card's purpose or category."
class PresentationAlertBoxWidget extends StatefulWidget {
  const PresentationAlertBoxWidget({
    super.key,
    this.status,
    this.width,
    this.height,
    required this.keyPrefix,
    required this.content,
  });

  final Status? status;
  final double? width;
  final double? height;
  final String? keyPrefix;
  final Widget Function()? content;

  @override
  State<PresentationAlertBoxWidget> createState() =>
      _PresentationAlertBoxWidgetState();
}

class _PresentationAlertBoxWidgetState
    extends State<PresentationAlertBoxWidget> {
  late PresentationAlertBoxModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationAlertBoxModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: () {
          if (widget!.status == Status.error) {
            return FlutterFlowTheme.of(context).dangerBGStroke5;
          } else if (widget!.status == Status.information) {
            return FlutterFlowTheme.of(context).secondaryInfoBGStroke5;
          } else {
            return FlutterFlowTheme.of(context).primaryText;
          }
        }(),
        borderRadius: BorderRadius.circular(4.0),
        border: Border.all(
          color: () {
            if (widget!.status == Status.error) {
              return FlutterFlowTheme.of(context).danger300;
            } else if (widget!.status == Status.information) {
              return FlutterFlowTheme.of(context).secondaryInfo300;
            } else {
              return FlutterFlowTheme.of(context).primaryText;
            }
          }(),
          width: 1.0,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(12.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Builder(
              builder: (context) {
                if (widget!.keyPrefix != null && widget!.keyPrefix != '') {
                  return Semantics(
                    label: 'This is used as Alert Icon.',
                    child: Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Presentation_AlertBox',
                              'Info_Icon')),
                      Icons.info_outline,
                      color: () {
                        if (widget!.status == Status.error) {
                          return FlutterFlowTheme.of(context).danger500Default;
                        } else if (widget!.status == Status.information) {
                          return FlutterFlowTheme.of(context).primary500;
                        } else {
                          return FlutterFlowTheme.of(context).primaryText;
                        }
                      }(),
                      size: 20.0,
                    ),
                  );
                } else {
                  return Semantics(
                    label: 'This is used as Alert Icon.',
                    child: Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Presentation_AlertBox',
                              'Info_Icon')),
                      Icons.info_outline,
                      color: () {
                        if (widget!.status == Status.error) {
                          return FlutterFlowTheme.of(context).danger500Default;
                        } else if (widget!.status == Status.information) {
                          return FlutterFlowTheme.of(context).primary500;
                        } else {
                          return FlutterFlowTheme.of(context).primaryText;
                        }
                      }(),
                      size: 20.0,
                    ),
                  );
                }
              },
            ),
            Container(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!, 'Presentation_AlertBox', 'content')),
              child: Builder(builder: (_) {
                return widget.content!();
              }),
            ),
          ].divide(SizedBox(width: 12.0)),
        ),
      ),
    );
  }
}
