import '/components/presentation_generic_menu_side_bar_basic_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_generic_menu_side_bar_model.dart';
export 'presentation_generic_menu_side_bar_model.dart';

class PresentationGenericMenuSideBarWidget extends StatefulWidget {
  const PresentationGenericMenuSideBarWidget({
    super.key,
    required this.keyPrefix,
    this.onTab,
    int? currentItem,
  }) : this.currentItem = currentItem ?? 0;

  final String? keyPrefix;
  final Future Function(int? selectedIndex)? onTab;
  final int currentItem;

  @override
  State<PresentationGenericMenuSideBarWidget> createState() =>
      _PresentationGenericMenuSideBarWidgetState();
}

class _PresentationGenericMenuSideBarWidgetState
    extends State<PresentationGenericMenuSideBarWidget> {
  late PresentationGenericMenuSideBarModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationGenericMenuSideBarModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            color: Color(0xFFF9FBFE),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.presentationGenericMenuSideBarBasicModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: PresentationGenericMenuSideBarBasicWidget(
                    keyPrefix: 'keyPrefix',
                    currentItem: widget!.currentItem,
                    setItem: 0,
                    iconName: FaIcon(
                      FontAwesomeIcons.userCircle,
                      color: widget!.currentItem == 0
                          ? Color(0xFF076BCF)
                          : Color(0xFF484A4C),
                      size: 20.0,
                    ),
                    proFileName: 'My Profile',
                    onTab: (selectedIndex) async {
                      await widget.onTab?.call(
                        0,
                      );
                    },
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.presentationGenericMenuSideBarBasicModel2,
                  updateCallback: () => safeSetState(() {}),
                  child: PresentationGenericMenuSideBarBasicWidget(
                    keyPrefix: 'keyPrefix',
                    currentItem: widget!.currentItem,
                    setItem: 1,
                    iconName: Icon(
                      Icons.format_list_numbered,
                      color: widget!.currentItem == 1
                          ? Color(0xFF076BCF)
                          : Color(0xFF484A4C),
                      size: 20.0,
                    ),
                    proFileName: 'Main/Additional Charge',
                    onTab: (selectedIndex) async {
                      await widget.onTab?.call(
                        1,
                      );
                    },
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.presentationGenericMenuSideBarBasicModel3,
                  updateCallback: () => safeSetState(() {}),
                  child: PresentationGenericMenuSideBarBasicWidget(
                    keyPrefix: 'keyPrefix',
                    currentItem: widget!.currentItem,
                    setItem: 2,
                    iconName: Icon(
                      Icons.manage_accounts_outlined,
                      color: widget!.currentItem == 2
                          ? Color(0xFF076BCF)
                          : Color(0xFF484A4C),
                      size: 20.0,
                    ),
                    proFileName: 'Sub - User Management',
                    onTab: (selectedIndex) async {
                      await widget.onTab?.call(
                        2,
                      );
                    },
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.presentationGenericMenuSideBarBasicModel4,
                  updateCallback: () => safeSetState(() {}),
                  child: PresentationGenericMenuSideBarBasicWidget(
                    keyPrefix: 'keyPrefix',
                    currentItem: widget!.currentItem,
                    setItem: 3,
                    iconName: Icon(
                      Icons.password_sharp,
                      color: widget!.currentItem == 3
                          ? Color(0xFF076BCF)
                          : Color(0xFF484A4C),
                      size: 20.0,
                    ),
                    proFileName: 'Change Password',
                    onTab: (selectedIndex) async {
                      await widget.onTab?.call(
                        3,
                      );
                    },
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.presentationGenericMenuSideBarBasicModel5,
                  updateCallback: () => safeSetState(() {}),
                  child: PresentationGenericMenuSideBarBasicWidget(
                    keyPrefix: 'keyPrefix',
                    currentItem: widget!.currentItem,
                    setItem: 4,
                    iconName: Icon(
                      Icons.list_alt,
                      color: widget!.currentItem == 4
                          ? Color(0xFF076BCF)
                          : Color(0xFF484A4C),
                      size: 20.0,
                    ),
                    proFileName: 'Update/ Register DSC',
                    onTab: (selectedIndex) async {
                      await widget.onTab?.call(
                        4,
                      );
                    },
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.presentationGenericMenuSideBarBasicModel6,
                  updateCallback: () => safeSetState(() {}),
                  child: PresentationGenericMenuSideBarBasicWidget(
                    keyPrefix: 'keyPrefix',
                    currentItem: widget!.currentItem,
                    setItem: 5,
                    iconName: Icon(
                      Icons.logout,
                      color: widget!.currentItem == 5
                          ? Color(0xFF076BCF)
                          : Color(0xFF484A4C),
                      size: 20.0,
                    ),
                    proFileName: 'Logout',
                    onTab: (selectedIndex) async {
                      await widget.onTab?.call(
                        5,
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
