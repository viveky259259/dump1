import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'icon_text_with_file_name_widget.dart' show IconTextWithFileNameWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class IconTextWithFileNameModel
    extends FlutterFlowModel<IconTextWithFileNameWidget> {
  ///  Local state fields for this component.

  String? link;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
