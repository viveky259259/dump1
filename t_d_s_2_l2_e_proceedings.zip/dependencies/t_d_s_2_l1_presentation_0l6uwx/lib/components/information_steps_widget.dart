import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'information_steps_model.dart';
export 'information_steps_model.dart';

class InformationStepsWidget extends StatefulWidget {
  const InformationStepsWidget({
    super.key,
    required this.infoStepsList,
    required this.keyPrefix,
  });

  final List<String>? infoStepsList;
  final String? keyPrefix;

  @override
  State<InformationStepsWidget> createState() => _InformationStepsWidgetState();
}

class _InformationStepsWidgetState extends State<InformationStepsWidget> {
  late InformationStepsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InformationStepsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
      ),
      child: Builder(
        builder: (context) {
          final infoStepsDynamicList = widget!.infoStepsList!.toList();

          return Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: List.generate(infoStepsDynamicList.length,
                (infoStepsDynamicListIndex) {
              final infoStepsDynamicListItem =
                  infoStepsDynamicList[infoStepsDynamicListIndex];
              return Text(
                '${(infoStepsDynamicListIndex + 1).toString()}. ${infoStepsDynamicListItem}',
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
              );
            }),
          );
        },
      ),
    );
  }
}
