import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'table_page_view_footer_widget.dart' show TablePageViewFooterWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TablePageViewFooterModel
    extends FlutterFlowModel<TablePageViewFooterWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for currentPageTextField widget.
  FocusNode? currentPageTextFieldFocusNode;
  TextEditingController? currentPageTextFieldTextController;
  String? Function(BuildContext, String?)?
      currentPageTextFieldTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    currentPageTextFieldFocusNode?.dispose();
    currentPageTextFieldTextController?.dispose();
  }
}
