import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'content_text_model.dart';
export 'content_text_model.dart';

/// Here’s a documentation comment that can sit at the top of the
/// ContentTextWidget class, along with an explanation of the state variables:
///
/// dart
/// Copy
/// A widget that displays a content header and a content description in a
/// vertical column.
///
///
/// The content header is displayed as a bold, larger text, while the content
/// description is
///  shown as a regular-sized paragraph. Both texts are customizable through
/// the constructor parameters.
///
///  **State Variables:**
///
/// `_model`: An instance of `ContentTextModel` that manages the state and
/// logic for the widget.
///
///  **Constructor Parameters:**
/// `contentHeader`: The text content for the header displayed at the top of
/// the widget.
/// `contentDescription`: The text content for the description displayed below
/// the header.
/// `keyPrefix`: A prefix to be used for generating unique keys for widget
/// elements.
class ContentTextWidget extends StatefulWidget {
  const ContentTextWidget({
    super.key,
    required this.contentHeader,
    required this.contentDescription,
    required this.keyPrefix,
  });

  final String? contentHeader;
  final String? contentDescription;
  final String? keyPrefix;

  @override
  State<ContentTextWidget> createState() => _ContentTextWidgetState();
}

class _ContentTextWidgetState extends State<ContentTextWidget> {
  late ContentTextModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ContentTextModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'ContentText', 'HeadingText')),
            valueOrDefault<String>(
              widget!.contentHeader,
              'hhhh',
            ),
            style: GoogleFonts.getFont(
              'Inter',
              color: FlutterFlowTheme.of(context).textBasic,
              fontWeight: FontWeight.bold,
              fontSize: 18.0,
            ),
          ),
          Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'ContentText', 'ParaText')),
            widget!.contentDescription!,
            style: GoogleFonts.getFont(
              'Inter',
              color: FlutterFlowTheme.of(context).textBasic,
              fontSize: 14.0,
            ),
          ),
        ].divide(SizedBox(height: 4.0)),
      ),
    );
  }
}
