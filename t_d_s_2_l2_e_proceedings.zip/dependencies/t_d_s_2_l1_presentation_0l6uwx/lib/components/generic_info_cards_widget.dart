import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_info_cards_model.dart';
export 'generic_info_cards_model.dart';

class GenericInfoCardsWidget extends StatefulWidget {
  const GenericInfoCardsWidget({
    super.key,
    required this.keyPrefix,
    this.height,
    this.width,
    required this.headingText,
    required this.numberCount,
  });

  final String? keyPrefix;
  final double? height;
  final double? width;
  final String? headingText;
  final String? numberCount;

  @override
  State<GenericInfoCardsWidget> createState() => _GenericInfoCardsWidgetState();
}

class _GenericInfoCardsWidgetState extends State<GenericInfoCardsWidget> {
  late GenericInfoCardsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericInfoCardsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: valueOrDefault<Color>(
          _model.isSelected
              ? FlutterFlowTheme.of(context).neutral100
              : FlutterFlowTheme.of(context).neutralBGStroke5,
          FlutterFlowTheme.of(context).secondaryBackground,
        ),
        boxShadow: [
          BoxShadow(
            blurRadius: _model.isSelected ? 6.0 : 0.0,
            color: _model.isSelected ? Color(0x1F000000) : Colors.transparent,
            offset: Offset(
              _model.isSelected ? 1.0 : 0.0,
              _model.isSelected ? 4.0 : 0.0,
            ),
            spreadRadius: 0.0,
          )
        ],
        borderRadius: BorderRadius.circular(4.0),
        border: Border.all(
          color: _model.isSelected
              ? FlutterFlowTheme.of(context).neutral300
              : FlutterFlowTheme.of(context).neutral400,
          width: 0.5,
        ),
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Flexible(
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: valueOrDefault<Color>(
                            _model.isSelected
                                ? FlutterFlowTheme.of(context)
                                    .secondaryBackground
                                : Color(0xFFFBFBFB),
                            FlutterFlowTheme.of(context).secondaryBackground,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrefix!,
                                      'Generic_InfoCards', 'headingText')),
                              widget!.headingText!,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Roboto',
                                    color: _model.isSelected
                                        ? FlutterFlowTheme.of(context).textBasic
                                        : FlutterFlowTheme.of(context)
                                            .textTertiary,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: valueOrDefault<Color>(
                            _model.isSelected
                                ? FlutterFlowTheme.of(context).secondaryInfo200
                                : FlutterFlowTheme.of(context)
                                    .neutralBGStroke20,
                            FlutterFlowTheme.of(context).secondaryInfo200,
                          ),
                          borderRadius: BorderRadius.circular(12.0),
                          shape: BoxShape.rectangle,
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 2.5, 8.0, 2.5),
                          child: Text(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Generic_InfoCards', 'CountText')),
                            widget!.numberCount!,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Roboto',
                                  color: valueOrDefault<Color>(
                                    _model.isSelected
                                        ? FlutterFlowTheme.of(context).secondary
                                        : FlutterFlowTheme.of(context)
                                            .textTertiary,
                                    FlutterFlowTheme.of(context)
                                        .buttonBorderTextColor,
                                  ),
                                  fontSize: 14.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                      ),
                    ].divide(SizedBox(height: 8.0)),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Container(
                        width: 16.0,
                        height: 16.0,
                        decoration: BoxDecoration(
                          color: valueOrDefault<Color>(
                            _model.isSelected
                                ? FlutterFlowTheme.of(context)
                                    .secondaryBackground
                                : Color(0xFFFAFAFA),
                            FlutterFlowTheme.of(context).secondaryBackground,
                          ),
                        ),
                        child: Builder(
                          builder: (context) {
                            if (_model.isSelected) {
                              return Padding(
                                padding: EdgeInsets.all(1.33),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.isSelected = !_model.isSelected;
                                    safeSetState(() {});
                                  },
                                  child: Icon(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_InfoCards',
                                                'CheckIcon')),
                                    Icons.check_circle_outline,
                                    color: FlutterFlowTheme.of(context).info,
                                    size: 13.33,
                                  ),
                                ),
                              );
                            } else {
                              return Padding(
                                padding: EdgeInsets.all(1.33),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.isSelected = !_model.isSelected;
                                    safeSetState(() {});
                                  },
                                  child: Icon(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_InfoCards',
                                                'UncheckIcon')),
                                    Icons.circle_outlined,
                                    color:
                                        FlutterFlowTheme.of(context).neutral800,
                                    size: 13.33,
                                  ),
                                ),
                              );
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ].divide(SizedBox(width: 12.0)),
              ),
            ),
          ].addToStart(SizedBox(height: 10.0)).addToEnd(SizedBox(height: 10.0)),
        ),
      ),
    );
  }
}
