import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'p_d_f_viewer_footer_widget.dart' show PDFViewerFooterWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PDFViewerFooterModel extends FlutterFlowModel<PDFViewerFooterWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
