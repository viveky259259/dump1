import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'timer_widget.dart' show TimerWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TimerModel extends FlutterFlowModel<TimerWidget> {
  ///  Local state fields for this component.

  String? mintues1;

  String? mintues2;

  String? seconds1;

  String? seconds2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
