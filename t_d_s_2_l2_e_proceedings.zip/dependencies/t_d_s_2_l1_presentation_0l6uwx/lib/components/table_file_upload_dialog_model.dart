import '/backend/schema/structs/index.dart';
import '/components/file_uploaded_view_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'table_file_upload_dialog_widget.dart' show TableFileUploadDialogWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TableFileUploadDialogModel
    extends FlutterFlowModel<TableFileUploadDialogWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
