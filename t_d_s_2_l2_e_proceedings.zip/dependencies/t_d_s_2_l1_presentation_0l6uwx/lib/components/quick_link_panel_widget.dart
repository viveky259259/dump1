import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'quick_link_panel_model.dart';
export 'quick_link_panel_model.dart';

/// /// A widget that displays a panel of quick links with an optional
/// heading.
///
///
/// ///
/// /// The `QuickLinkPanelWidget` class is a stateful widget that shows a
/// list of links
/// /// with an optional heading. Each link is displayed with an icon and a
/// forward arrow.
/// ///
/// /// State Variables:
/// /// - `keyPrefix`: A prefix for the key used in the widget.
/// /// - `linkTitle`: A list of titles for the links to be displayed in the
/// panel.
class QuickLinkPanelWidget extends StatefulWidget {
  const QuickLinkPanelWidget({
    super.key,
    required this.keyPrefix,
    required this.linkTitle,
    this.panelHeading,
    required this.onTap,
  });

  final String? keyPrefix;
  final List<String>? linkTitle;
  final String? panelHeading;
  final Future Function()? onTap;

  @override
  State<QuickLinkPanelWidget> createState() => _QuickLinkPanelWidgetState();
}

class _QuickLinkPanelWidgetState extends State<QuickLinkPanelWidget> {
  late QuickLinkPanelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => QuickLinkPanelModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primaryBGStroke5,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 24.0),
              child: Text(
                '',
                style: GoogleFonts.getFont(
                  'Inter',
                  color: FlutterFlowTheme.of(context).textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 18.0,
                ),
              ),
            ),
            Builder(
              builder: (context) {
                final newsList = widget!.linkTitle!.toList();

                return Column(
                  mainAxisSize: MainAxisSize.max,
                  children: List.generate(newsList.length, (newsListIndex) {
                    final newsListItem = newsList[newsListIndex];
                    return InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        await widget.onTap?.call();
                      },
                      child: Container(
                        height: 45.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          borderRadius: BorderRadius.circular(4.0),
                          shape: BoxShape.rectangle,
                          border: Border.all(
                            color: FlutterFlowTheme.of(context).primary500,
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 12.5, 0.0, 12.5),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 8.0, 0.0),
                                    child: Icon(
                                      Icons.email_outlined,
                                      color: FlutterFlowTheme.of(context)
                                          .primaryText,
                                      size: 13.0,
                                    ),
                                  ),
                                  Text(
                                    '',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .primary600Default,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14.0,
                                    ),
                                  ),
                                ],
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 12.5, 0.0),
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  size: 13.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).divide(SizedBox(height: 24.0)),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
