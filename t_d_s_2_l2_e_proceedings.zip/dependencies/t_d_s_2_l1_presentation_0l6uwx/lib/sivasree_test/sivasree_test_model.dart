import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/form15_c/view_as_option/view_as_option_widget.dart';
import 'dart:ui';
import 'sivasree_test_widget.dart' show SivasreeTestWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SivasreeTestModel extends FlutterFlowModel<SivasreeTestWidget> {
  ///  Local state fields for this page.

  int? activeState = 0;

  ///  State fields for stateful widgets in this page.

  // Model for View_As_Option component.
  late ViewAsOptionModel viewAsOptionModel;

  @override
  void initState(BuildContext context) {
    viewAsOptionModel = createModel(context, () => ViewAsOptionModel());
  }

  @override
  void dispose() {
    viewAsOptionModel.dispose();
  }
}
