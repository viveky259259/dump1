import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/form15_c/view_as_option/view_as_option_widget.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'sivasree_test_model.dart';
export 'sivasree_test_model.dart';

class SivasreeTestWidget extends StatefulWidget {
  const SivasreeTestWidget({super.key});

  @override
  State<SivasreeTestWidget> createState() => _SivasreeTestWidgetState();
}

class _SivasreeTestWidgetState extends State<SivasreeTestWidget> {
  late SivasreeTestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SivasreeTestModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                wrapWithModel(
                  model: _model.viewAsOptionModel,
                  updateCallback: () => safeSetState(() {}),
                  child: ViewAsOptionWidget(
                    activeIndex: _model.activeState!,
                    label: 'View as',
                    keyPrefix: 'keyPrefix',
                    onClick: (index) async {},
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
