// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import "package:t_d_s_2_l1_logic_2wrus1/backend/schema/structs/index.dart"
    as t_d_s_2_l1_logic_2wrus1_data_schema;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';

Timer? _timer;
int _totalSeconds = 0;

Future getSessionTimer(
  BuildContext context,
  Future Function(List<String>? timerValue) updateUI,
) async {
  // Add your function code here!
  _totalSeconds = 5 * 60 + 45;

  _timer?.cancel();
  _timer = Timer.periodic(Duration(seconds: 1), (timer) {
    if (_totalSeconds > 0) {
      _totalSeconds--;
      int minutes = _totalSeconds ~/ 60;
      int seconds = _totalSeconds % 60;
      String formattedTime =
          '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';

      List<String> timeParts = formattedTime.split('');
      String formattedMinutes = timeParts[0];
      String formattedSeconds = timeParts[1];

      // You can now use formattedMinutes and formattedSeconds separately
      print("Minutes: $formattedMinutes, Seconds: $formattedSeconds");

      // Call the callback function to update UI
      updateUI.call(timeParts);
    } else {
      timer.cancel();
    }
  });
}
