import '/ao_portal/toast_message/toast_message_widget.dart';
import '/backend/schema/enums/enums.dart';
import '/components/generic_info_cards_widget.dart';
import '/components/generic_info_chips_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'deep_test_page_widget.dart' show DeepTestPageWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DeepTestPageModel extends FlutterFlowModel<DeepTestPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Generic_InfoCards component.
  late GenericInfoCardsModel genericInfoCardsModel;
  // Model for Toast_Message component.
  late ToastMessageModel toastMessageModel1;
  // Model for Toast_Message component.
  late ToastMessageModel toastMessageModel2;
  // Model for Toast_Message component.
  late ToastMessageModel toastMessageModel3;
  // Model for Toast_Message component.
  late ToastMessageModel toastMessageModel4;
  // Model for Toast_Message component.
  late ToastMessageModel toastMessageModel5;
  // Model for Generic_InfoChips component.
  late GenericInfoChipsModel genericInfoChipsModel1;
  // Model for Generic_InfoChips component.
  late GenericInfoChipsModel genericInfoChipsModel2;
  // Model for Generic_InfoChips component.
  late GenericInfoChipsModel genericInfoChipsModel3;

  @override
  void initState(BuildContext context) {
    genericInfoCardsModel = createModel(context, () => GenericInfoCardsModel());
    toastMessageModel1 = createModel(context, () => ToastMessageModel());
    toastMessageModel2 = createModel(context, () => ToastMessageModel());
    toastMessageModel3 = createModel(context, () => ToastMessageModel());
    toastMessageModel4 = createModel(context, () => ToastMessageModel());
    toastMessageModel5 = createModel(context, () => ToastMessageModel());
    genericInfoChipsModel1 =
        createModel(context, () => GenericInfoChipsModel());
    genericInfoChipsModel2 =
        createModel(context, () => GenericInfoChipsModel());
    genericInfoChipsModel3 =
        createModel(context, () => GenericInfoChipsModel());
  }

  @override
  void dispose() {
    genericInfoCardsModel.dispose();
    toastMessageModel1.dispose();
    toastMessageModel2.dispose();
    toastMessageModel3.dispose();
    toastMessageModel4.dispose();
    toastMessageModel5.dispose();
    genericInfoChipsModel1.dispose();
    genericInfoChipsModel2.dispose();
    genericInfoChipsModel3.dispose();
  }
}
