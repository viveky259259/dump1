import '/ao_portal/toast_message/toast_message_widget.dart';
import '/backend/schema/enums/enums.dart';
import '/components/generic_info_cards_widget.dart';
import '/components/generic_info_chips_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'deep_test_page_model.dart';
export 'deep_test_page_model.dart';

class DeepTestPageWidget extends StatefulWidget {
  const DeepTestPageWidget({super.key});

  @override
  State<DeepTestPageWidget> createState() => _DeepTestPageWidgetState();
}

class _DeepTestPageWidgetState extends State<DeepTestPageWidget> {
  late DeepTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DeepTestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              wrapWithModel(
                model: _model.genericInfoCardsModel,
                updateCallback: () => safeSetState(() {}),
                child: GenericInfoCardsWidget(
                  keyPrefix: 'key',
                  headingText: 'gfxc',
                  numberCount: 'trdfc',
                ),
              ),
              wrapWithModel(
                model: _model.toastMessageModel1,
                updateCallback: () => safeSetState(() {}),
                child: ToastMessageWidget(
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'keyPrefix', 'DeepTestPage', 'Toast_Message'),
                  description:
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                  states: ToastMessage.Warning,
                ),
              ),
              wrapWithModel(
                model: _model.toastMessageModel2,
                updateCallback: () => safeSetState(() {}),
                child: ToastMessageWidget(
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'keyPrefix', 'DeepTestPage', 'Toast_Message'),
                  description:
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                  states: ToastMessage.Information,
                ),
              ),
              wrapWithModel(
                model: _model.toastMessageModel3,
                updateCallback: () => safeSetState(() {}),
                child: ToastMessageWidget(
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'keyPrefix', 'DeepTestPage', 'Toast_Message'),
                  description:
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                  states: ToastMessage.Success,
                ),
              ),
              wrapWithModel(
                model: _model.toastMessageModel4,
                updateCallback: () => safeSetState(() {}),
                child: ToastMessageWidget(
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'keyPrefix', 'DeepTestPage', 'Toast_Message'),
                  description:
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                  states: ToastMessage.Error,
                ),
              ),
              wrapWithModel(
                model: _model.toastMessageModel5,
                updateCallback: () => safeSetState(() {}),
                child: ToastMessageWidget(
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'keyPrefix', 'DeepTestPage', 'Toast_Message'),
                  description:
                      'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                  states: ToastMessage.Alert,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primaryBGStroke5,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        wrapWithModel(
                          model: _model.genericInfoChipsModel1,
                          updateCallback: () => safeSetState(() {}),
                          child: GenericInfoChipsWidget(
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue('keyPrefix', 'DeepTestPage',
                                    'Generic_InfoChips'),
                            icon: FaIcon(
                              FontAwesomeIcons.ticketAlt,
                              color: FlutterFlowTheme.of(context).primary,
                              size: 20.0,
                            ),
                            number: 9170,
                            title: 'Tickets',
                          ),
                        ),
                        wrapWithModel(
                          model: _model.genericInfoChipsModel2,
                          updateCallback: () => safeSetState(() {}),
                          child: GenericInfoChipsWidget(
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue('keyPrefix', 'DeepTestPage',
                                    'Generic_InfoChips'),
                            icon: Icon(
                              Icons.assignment_outlined,
                              color: FlutterFlowTheme.of(context).primary,
                              size: 20.0,
                            ),
                            number: 170,
                            title: 'Forms/\nApplications',
                          ),
                        ),
                        wrapWithModel(
                          model: _model.genericInfoChipsModel3,
                          updateCallback: () => safeSetState(() {}),
                          child: GenericInfoChipsWidget(
                            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue('keyPrefix', 'DeepTestPage',
                                    'Generic_InfoChips'),
                            icon: FaIcon(
                              FontAwesomeIcons.file,
                              color: FlutterFlowTheme.of(context).primary,
                              size: 20.0,
                            ),
                            number: 170,
                            title: 'Proceeding\nu/s 201/206C',
                          ),
                        ),
                      ]
                          .divide(SizedBox(width: 10.0))
                          .around(SizedBox(width: 10.0)),
                    ),
                  ],
                ),
              ),
            ].divide(SizedBox(height: 50.0)).addToStart(SizedBox(height: 50.0)),
          ),
        ),
      ),
    );
  }
}
