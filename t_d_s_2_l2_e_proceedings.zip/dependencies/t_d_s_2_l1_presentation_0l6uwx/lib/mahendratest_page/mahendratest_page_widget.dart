import '/ao_portal/presentation_generic_pdf_viewer/presentation_generic_pdf_viewer_widget.dart';
import '/components/presentation_generic_menu_side_bar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mahendratest_page_model.dart';
export 'mahendratest_page_model.dart';

class MahendratestPageWidget extends StatefulWidget {
  const MahendratestPageWidget({super.key});

  @override
  State<MahendratestPageWidget> createState() => _MahendratestPageWidgetState();
}

class _MahendratestPageWidgetState extends State<MahendratestPageWidget> {
  late MahendratestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MahendratestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    wrapWithModel(
                      model: _model.presentationGenericMenuSideBarModel,
                      updateCallback: () => safeSetState(() {}),
                      child: PresentationGenericMenuSideBarWidget(
                        keyPrefix: 'keyPrefix',
                        currentItem: _model.currentItem,
                        onTab: (selectedIndex) async {
                          _model.currentItem = selectedIndex!;
                          safeSetState(() {});
                        },
                      ),
                    ),
                    FFButtonWidget(
                      onPressed: () async {
                        _model.currentItem = _model.currentItem + 1;
                        safeSetState(() {});
                      },
                      text: 'Button',
                      options: FFButtonOptions(
                        height: 40.0,
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: FlutterFlowTheme.of(context).primary,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Inter',
                                  color: Colors.white,
                                  letterSpacing: 0.0,
                                ),
                        elevation: 0.0,
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 100.0, 0.0, 0.0),
                child: Container(
                  width: MediaQuery.sizeOf(context).width * 1.0,
                  height: MediaQuery.sizeOf(context).height * 0.5,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: wrapWithModel(
                    model: _model.presentationGenericPdfViewerModel,
                    updateCallback: () => safeSetState(() {}),
                    child: PresentationGenericPdfViewerWidget(
                      keyPrefix: 'keyPrefix',
                      headingName: 'Notice u/s 201 or 206C',
                      pdfUrl:
                          'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
