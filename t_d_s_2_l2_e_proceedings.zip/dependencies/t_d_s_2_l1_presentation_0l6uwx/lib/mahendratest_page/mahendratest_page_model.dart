import '/ao_portal/presentation_generic_pdf_viewer/presentation_generic_pdf_viewer_widget.dart';
import '/components/presentation_generic_menu_side_bar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'mahendratest_page_widget.dart' show MahendratestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MahendratestPageModel extends FlutterFlowModel<MahendratestPageWidget> {
  ///  Local state fields for this page.

  int currentItem = 0;

  ///  State fields for stateful widgets in this page.

  // Model for Presentation_Generic_MenuSideBar component.
  late PresentationGenericMenuSideBarModel presentationGenericMenuSideBarModel;
  // Model for Presentation_Generic_Pdf_Viewer component.
  late PresentationGenericPdfViewerModel presentationGenericPdfViewerModel;

  @override
  void initState(BuildContext context) {
    presentationGenericMenuSideBarModel =
        createModel(context, () => PresentationGenericMenuSideBarModel());
    presentationGenericPdfViewerModel =
        createModel(context, () => PresentationGenericPdfViewerModel());
  }

  @override
  void dispose() {
    presentationGenericMenuSideBarModel.dispose();
    presentationGenericPdfViewerModel.dispose();
  }
}
