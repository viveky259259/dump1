import '/ao_portal/a_o_p_o_r_t_a_l_footer/a_o_p_o_r_t_a_l_footer_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'prashant_test_model.dart';
export 'prashant_test_model.dart';

class PrashantTestWidget extends StatefulWidget {
  const PrashantTestWidget({super.key});

  @override
  State<PrashantTestWidget> createState() => _PrashantTestWidgetState();
}

class _PrashantTestWidgetState extends State<PrashantTestWidget> {
  late PrashantTestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PrashantTestModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.aOPORTALFooterModel,
                updateCallback: () => safeSetState(() {}),
                child: AOPORTALFooterWidget(
                  keyPrefix: 'String',
                  email: 'aohelpdesk@tdscpc.gov.in',
                  phoneNumber: '1800 103 0344',
                  feedbackSuggestion: () async {},
                  directoryOfOfficersSection: () async {},
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
