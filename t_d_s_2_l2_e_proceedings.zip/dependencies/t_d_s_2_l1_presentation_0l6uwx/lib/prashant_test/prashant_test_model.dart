import '/ao_portal/a_o_p_o_r_t_a_l_footer/a_o_p_o_r_t_a_l_footer_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'prashant_test_widget.dart' show PrashantTestWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PrashantTestModel extends FlutterFlowModel<PrashantTestWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for AO_PORTAL_footer component.
  late AOPORTALFooterModel aOPORTALFooterModel;

  @override
  void initState(BuildContext context) {
    aOPORTALFooterModel = createModel(context, () => AOPORTALFooterModel());
  }

  @override
  void dispose() {
    aOPORTALFooterModel.dispose();
  }
}
