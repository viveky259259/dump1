import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'in_page_notification_model.dart';
export 'in_page_notification_model.dart';

/// // A widget that displays in-page notifications with different alert
/// statuses.
///
///
/// ///
/// /// The `InPageNotificationWidget` class is a stateful widget that shows
/// an icon and a description
/// /// based on the provided alert status. It supports various alert statuses
/// such as Warning,
/// /// Information, Success, Error, and Alert.
/// ///
/// /// State Variables:
/// /// - `keyPrefix`: A prefix for the key used in the widget.
/// /// - `states`: The current alert status of the notification.
/// /// - `description`: A description text that accompanies the notification.
class InPageNotificationWidget extends StatefulWidget {
  const InPageNotificationWidget({
    super.key,
    required this.keyPrefix,
    required this.states,
    required this.description,
  });

  final String? keyPrefix;
  final AlertTextStatus? states;
  final String? description;

  @override
  State<InPageNotificationWidget> createState() =>
      _InPageNotificationWidgetState();
}

class _InPageNotificationWidgetState extends State<InPageNotificationWidget> {
  late InPageNotificationModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InPageNotificationModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Builder(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'In_Page_Notification',
                'ConditionalBuilder')),
            builder: (context) {
              if (widget!.states == AlertTextStatus.Warning) {
                return Icon(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          'Presentation_AlertText',
                          widget!.keyPrefix!,
                          'Icon')),
                  Icons.warning_amber,
                  color: FlutterFlowTheme.of(context).warning800,
                  size: 24.0,
                );
              } else if (widget!.states == AlertTextStatus.Information) {
                return Icon(
                  Icons.info_outline,
                  color: FlutterFlowTheme.of(context).secondaryInfo500Default,
                  size: 24.0,
                );
              } else if (widget!.states == AlertTextStatus.Success) {
                return Icon(
                  Icons.check_circle_outline,
                  color: FlutterFlowTheme.of(context).success700,
                  size: 24.0,
                );
              } else if (widget!.states == AlertTextStatus.Error) {
                return Icon(
                  Icons.cancel_outlined,
                  color: FlutterFlowTheme.of(context).danger500Default,
                  size: 24.0,
                );
              } else if (widget!.states == AlertTextStatus.Alert) {
                return Icon(
                  Icons.report_outlined,
                  color: FlutterFlowTheme.of(context).danger500Default,
                  size: 24.0,
                );
              } else {
                return Icon(
                  Icons.check_circle_outlined,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 24.0,
                );
              }
            },
          ),
          Flexible(
            child: RichText(
              textScaler: MediaQuery.of(context).textScaler,
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      'Presentation_AlertText',
                      widget!.keyPrefix!,
                      'RichText')),
              text: TextSpan(
                children: [
                  TextSpan(
                    text: () {
                      if (widget!.states == AlertTextStatus.Warning) {
                        return FFAppConstants.WarningToastMessageLabel;
                      } else if (widget!.states ==
                          AlertTextStatus.Information) {
                        return FFAppConstants.InformationToastMessageTextLabel;
                      } else if (widget!.states == AlertTextStatus.Success) {
                        return FFAppConstants.SuccessToastMessageTextLabel;
                      } else if (widget!.states == AlertTextStatus.Error) {
                        return FFAppConstants.ErrorToastMessageTextLabel;
                      } else if (widget!.states == AlertTextStatus.Alert) {
                        return FFAppConstants.AlertToastMessageTextLabel;
                      } else {
                        return '';
                      }
                    }(),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: () {
                            if (widget!.states == AlertTextStatus.Warning) {
                              return FlutterFlowTheme.of(context).warning800;
                            } else if (widget!.states ==
                                AlertTextStatus.Information) {
                              return FlutterFlowTheme.of(context)
                                  .secondaryInfo500Default;
                            } else if (widget!.states ==
                                AlertTextStatus.Success) {
                              return FlutterFlowTheme.of(context).success700;
                            } else if (widget!.states ==
                                AlertTextStatus.Error) {
                              return FlutterFlowTheme.of(context)
                                  .danger500Default;
                            } else if (widget!.states ==
                                AlertTextStatus.Alert) {
                              return FlutterFlowTheme.of(context)
                                  .danger500Default;
                            } else {
                              return Color(0x00000000);
                            }
                          }(),
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  TextSpan(
                    text: widget!.description!,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: () {
                            if (widget!.states == AlertTextStatus.Warning) {
                              return FlutterFlowTheme.of(context).warning800;
                            } else if (widget!.states ==
                                AlertTextStatus.Information) {
                              return FlutterFlowTheme.of(context)
                                  .secondaryInfo500Default;
                            } else if (widget!.states ==
                                AlertTextStatus.Success) {
                              return FlutterFlowTheme.of(context).success700;
                            } else if (widget!.states ==
                                AlertTextStatus.Error) {
                              return FlutterFlowTheme.of(context)
                                  .danger500Default;
                            } else if (widget!.states ==
                                AlertTextStatus.Alert) {
                              return FlutterFlowTheme.of(context)
                                  .danger500Default;
                            } else {
                              return Color(0x00000000);
                            }
                          }(),
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                        ),
                  )
                ],
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
              ),
            ),
          ),
        ].divide(SizedBox(width: 8.0)),
      ),
    );
  }
}
