import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'toast_message_model.dart';
export 'toast_message_model.dart';

class ToastMessageWidget extends StatefulWidget {
  const ToastMessageWidget({
    super.key,
    required this.keyPrefix,
    required this.states,
    required this.description,
  });

  final String? keyPrefix;
  final ToastMessage? states;
  final String? description;

  @override
  State<ToastMessageWidget> createState() => _ToastMessageWidgetState();
}

class _ToastMessageWidgetState extends State<ToastMessageWidget> {
  late ToastMessageModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ToastMessageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(1.0, -1.0),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(5.0, 0.0, 5.0, 0.0),
        child: Semantics(
          label:
              'This is the container in which the toast message & icon of the toast message will be shown.',
          child: Container(
            decoration: BoxDecoration(
              color: () {
                if (widget!.states == ToastMessage.Warning) {
                  return FlutterFlowTheme.of(context).warningBGStroke5;
                } else if (widget!.states == ToastMessage.Information) {
                  return FlutterFlowTheme.of(context).secondaryInfoBGStroke5;
                } else if (widget!.states == ToastMessage.Success) {
                  return FlutterFlowTheme.of(context).successBGStroke5;
                } else if (widget!.states == ToastMessage.Error) {
                  return FlutterFlowTheme.of(context).dangerBGStroke5;
                } else if (widget!.states == ToastMessage.Alert) {
                  return FlutterFlowTheme.of(context).dangerBGStroke5;
                } else {
                  return FlutterFlowTheme.of(context).primaryBackground;
                }
              }(),
              boxShadow: [
                BoxShadow(
                  blurRadius: 6.0,
                  color: Color(0x0000001F),
                  offset: Offset(
                    1.0,
                    4.0,
                  ),
                  spreadRadius: 0.0,
                )
              ],
              borderRadius: BorderRadius.circular(4.0),
              border: Border.all(
                color: () {
                  if (widget!.states == ToastMessage.Warning) {
                    return FlutterFlowTheme.of(context).warning600;
                  } else if (widget!.states == ToastMessage.Information) {
                    return FlutterFlowTheme.of(context).secondaryInfo300;
                  } else if (widget!.states == ToastMessage.Success) {
                    return FlutterFlowTheme.of(context).success400;
                  } else if (widget!.states == ToastMessage.Error) {
                    return FlutterFlowTheme.of(context).danger300;
                  } else if (widget!.states == ToastMessage.Alert) {
                    return FlutterFlowTheme.of(context).danger300;
                  } else {
                    return Color(0x00000000);
                  }
                }(),
              ),
            ),
            child: Padding(
              padding: EdgeInsets.all(12.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Builder(
                    builder: (context) {
                      if (widget!.states == ToastMessage.Warning) {
                        return Semantics(
                          label: 'This is the warning icon.',
                          child: Icon(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Generic_Success_Error_Message',
                                    'Leading_Icon')),
                            Icons.warning_amber,
                            color: FlutterFlowTheme.of(context).warning800,
                            size: 24.0,
                          ),
                        );
                      } else if (widget!.states == ToastMessage.Information) {
                        return Semantics(
                          label: 'This is the information icon.',
                          child: Icon(
                            Icons.info_outline,
                            color: FlutterFlowTheme.of(context).secondary,
                            size: 24.0,
                          ),
                        );
                      } else if (widget!.states == ToastMessage.Success) {
                        return Semantics(
                          label: 'This is the check icon.',
                          child: Icon(
                            Icons.check_circle_outline,
                            color: FlutterFlowTheme.of(context).success700,
                            size: 24.0,
                          ),
                        );
                      } else if (widget!.states == ToastMessage.Error) {
                        return Semantics(
                          label: 'This is the error icon.',
                          child: Icon(
                            Icons.cancel_outlined,
                            color:
                                FlutterFlowTheme.of(context).danger500Default,
                            size: 24.0,
                          ),
                        );
                      } else if (widget!.states == ToastMessage.Alert) {
                        return Semantics(
                          label: 'This is the alert icon.',
                          child: Icon(
                            Icons.report_outlined,
                            color:
                                FlutterFlowTheme.of(context).danger500Default,
                            size: 24.0,
                          ),
                        );
                      } else {
                        return Semantics(
                          label: 'This is the success icon.',
                          child: Icon(
                            Icons.check_circle_outlined,
                            color: FlutterFlowTheme.of(context).success700,
                            size: 24.0,
                          ),
                        );
                      }
                    },
                  ),
                  Flexible(
                    child: RichText(
                      textScaler: MediaQuery.of(context).textScaler,
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Presentation_AlertBox',
                              'AlertText')),
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: () {
                              if (widget!.states == ToastMessage.Warning) {
                                return FFAppConstants.WarningToastMessageLabel;
                              } else if (widget!.states ==
                                  ToastMessage.Information) {
                                return FFAppConstants
                                    .InformationToastMessageTextLabel;
                              } else if (widget!.states ==
                                  ToastMessage.Success) {
                                return FFAppConstants
                                    .SuccessToastMessageTextLabel;
                              } else if (widget!.states == ToastMessage.Error) {
                                return FFAppConstants
                                    .ErrorToastMessageTextLabel;
                              } else if (widget!.states == ToastMessage.Alert) {
                                return FFAppConstants
                                    .AlertToastMessageTextLabel;
                              } else {
                                return '';
                              }
                            }(),
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: 'Inter',
                                      color: () {
                                        if (widget!.states ==
                                            ToastMessage.Warning) {
                                          return FlutterFlowTheme.of(context)
                                              .warning800;
                                        } else if (widget!.states ==
                                            ToastMessage.Information) {
                                          return FlutterFlowTheme.of(context)
                                              .secondaryInfo500Default;
                                        } else if (widget!.states ==
                                            ToastMessage.Success) {
                                          return FlutterFlowTheme.of(context)
                                              .success700;
                                        } else if (widget!.states ==
                                            ToastMessage.Error) {
                                          return FlutterFlowTheme.of(context)
                                              .danger500Default;
                                        } else if (widget!.states ==
                                            ToastMessage.Alert) {
                                          return FlutterFlowTheme.of(context)
                                              .danger500Default;
                                        } else {
                                          return FlutterFlowTheme.of(context)
                                              .textBasic;
                                        }
                                      }(),
                                      fontSize: 14.0,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                          ),
                          TextSpan(
                            text: widget!.description!,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: () {
                                    if (widget!.states ==
                                        ToastMessage.Warning) {
                                      return FlutterFlowTheme.of(context)
                                          .warning800;
                                    } else if (widget!.states ==
                                        ToastMessage.Information) {
                                      return FlutterFlowTheme.of(context)
                                          .secondaryInfo500Default;
                                    } else if (widget!.states ==
                                        ToastMessage.Success) {
                                      return FlutterFlowTheme.of(context)
                                          .success700;
                                    } else if (widget!.states ==
                                        ToastMessage.Error) {
                                      return FlutterFlowTheme.of(context)
                                          .danger500Default;
                                    } else if (widget!.states ==
                                        ToastMessage.Alert) {
                                      return FlutterFlowTheme.of(context)
                                          .danger500Default;
                                    } else {
                                      return FlutterFlowTheme.of(context)
                                          .textBasic;
                                    }
                                  }(),
                                  letterSpacing: 0.0,
                                ),
                          )
                        ],
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: () {
                                if (widget!.states == ToastMessage.Warning) {
                                  return FlutterFlowTheme.of(context)
                                      .warning800;
                                } else if (widget!.states ==
                                    ToastMessage.Information) {
                                  return FlutterFlowTheme.of(context)
                                      .secondaryInfo500Default;
                                } else if (widget!.states ==
                                    ToastMessage.Success) {
                                  return FlutterFlowTheme.of(context)
                                      .success700;
                                } else if (widget!.states ==
                                    ToastMessage.Error) {
                                  return FlutterFlowTheme.of(context)
                                      .danger500Default;
                                } else if (widget!.states ==
                                    ToastMessage.Alert) {
                                  return FlutterFlowTheme.of(context)
                                      .danger500Default;
                                } else {
                                  return FlutterFlowTheme.of(context).textBasic;
                                }
                              }(),
                              letterSpacing: 0.0,
                              lineHeight: 0.0,
                            ),
                      ),
                      textAlign: TextAlign.start,
                      maxLines: 2,
                    ),
                  ),
                  Semantics(
                    label:
                        'This is the cross icon for closing the toast message popup.',
                    child: Icon(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              'Generic_Success_Error_Message',
                              widget!.keyPrefix!,
                              'Trailling_Icon')),
                      Icons.close,
                      color: () {
                        if (widget!.states == ToastMessage.Warning) {
                          return FlutterFlowTheme.of(context).warning800;
                        } else if (widget!.states == ToastMessage.Information) {
                          return FlutterFlowTheme.of(context)
                              .secondaryInfo500Default;
                        } else if (widget!.states == ToastMessage.Success) {
                          return FlutterFlowTheme.of(context).success700;
                        } else if (widget!.states == ToastMessage.Error) {
                          return FlutterFlowTheme.of(context).danger500Default;
                        } else if (widget!.states == ToastMessage.Alert) {
                          return FlutterFlowTheme.of(context).danger500Default;
                        } else {
                          return FlutterFlowTheme.of(context).textBasic;
                        }
                      }(),
                      size: 24.0,
                    ),
                  ),
                ].divide(SizedBox(width: 8.0)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
