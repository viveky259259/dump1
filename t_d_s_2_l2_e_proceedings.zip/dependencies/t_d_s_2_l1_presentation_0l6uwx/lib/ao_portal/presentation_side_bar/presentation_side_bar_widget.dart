import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_side_bar_model.dart';
export 'presentation_side_bar_model.dart';

class PresentationSideBarWidget extends StatefulWidget {
  const PresentationSideBarWidget({
    super.key,
    this.mainContainerColor,
    this.insideIconVisibility,
    this.insideContainerVisibility1,
    this.insideContainerVisibility2,
    this.numberText,
    this.presentationText,
    this.outsideIconVisibility,
    this.presentationTextColor,
    this.isVerticalDividerMandatory,
    required this.keyPrefix,
  });

  final Color? mainContainerColor;
  final bool? insideIconVisibility;
  final bool? insideContainerVisibility1;
  final bool? insideContainerVisibility2;
  final String? numberText;
  final String? presentationText;
  final bool? outsideIconVisibility;
  final Color? presentationTextColor;
  final bool? isVerticalDividerMandatory;
  final String? keyPrefix;

  @override
  State<PresentationSideBarWidget> createState() =>
      _PresentationSideBarWidgetState();
}

class _PresentationSideBarWidgetState extends State<PresentationSideBarWidget> {
  late PresentationSideBarModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationSideBarModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Container(
          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
              widget!.keyPrefix!, 'Presentation_SideBar', 'OutSideContainer')),
          height: 50.0,
          decoration: BoxDecoration(
            color: widget!.mainContainerColor,
          ),
          child: Row(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, '', '')),
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Stack(
                    children: [
                      if (widget!.insideIconVisibility ?? true)
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Presentation_SideBar', 'Icon1')),
                          Icons.check_circle_outline_rounded,
                          color: FlutterFlowTheme.of(context).success,
                          size: 24.0,
                        ),
                      if (widget!.insideContainerVisibility1 ?? true)
                        Container(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Presentation_SideBar', 'InsideContainer1')),
                          width: 24.0,
                          height: 24.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: FlutterFlowTheme.of(context).primary,
                              width: 3.0,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.circle_sharp,
                                    color: FlutterFlowTheme.of(context).primary,
                                    size: 5.0,
                                  ),
                                  Icon(
                                    Icons.circle_sharp,
                                    color: FlutterFlowTheme.of(context).primary,
                                    size: 5.0,
                                  ),
                                ].divide(SizedBox(width: 4.0)),
                              ),
                            ],
                          ),
                        ),
                      if (widget!.insideContainerVisibility2 ?? true)
                        Container(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Presentation_SideBar', 'InsideContainer2')),
                          width: 24.0,
                          height: 24.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: FlutterFlowTheme.of(context).secondaryText,
                              width: 2.0,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(widget!.keyPrefix!,
                                        'Presentation_SideBar', 'InsideText')),
                                valueOrDefault<String>(
                                  widget!.numberText,
                                  'number',
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      fontSize: 14.0,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                  Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'Presentation_SideBar',
                            'OutsideText')),
                    valueOrDefault<String>(
                      widget!.presentationText,
                      'presentation',
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          color: widget!.presentationTextColor,
                          fontSize: 18.0,
                          letterSpacing: 0.0,
                        ),
                  ),
                ].divide(SizedBox(width: 20.0)),
              ),
              if (widget!.outsideIconVisibility ?? true)
                Icon(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Presentation_SideBar',
                          'OutSideIcon')),
                  Icons.chevron_right,
                  color: FlutterFlowTheme.of(context).primary,
                  size: 24.0,
                ),
            ],
          ),
        ),
        if (widget!.isVerticalDividerMandatory ?? true)
          Row(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Presentation_SideBar', 'VerticalRow')),
            mainAxisSize: MainAxisSize.max,
            children: [
              SizedBox(
                height: 20.0,
                child: VerticalDivider(
                  width: 20.0,
                  thickness: 2.0,
                  color: FlutterFlowTheme.of(context).alternate,
                ),
              ),
            ],
          ),
      ],
    );
  }
}
