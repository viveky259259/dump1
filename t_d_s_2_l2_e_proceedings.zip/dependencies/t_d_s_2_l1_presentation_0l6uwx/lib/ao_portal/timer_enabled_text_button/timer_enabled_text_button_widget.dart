import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'timer_enabled_text_button_model.dart';
export 'timer_enabled_text_button_model.dart';

/// A class that represents a simple counter.
///
///
/// ///
/// /// This class provides functionality to increment, decrement, and reset
/// the counter value.
/// ///
/// /// State Variables:
/// /// - `int _counter`: The current value of the counter.
/// /// - `int _initialValue`: The initial value of the counter, used for
/// resetting.
/// ///
/// /// Methods:
/// /// - `increment()`: Increases the counter value by one.
/// /// - `decrement()`: Decreases the counter value by one.
/// /// - `reset()`: Resets the counter value to the initial value.
class TimerEnabledTextButtonWidget extends StatefulWidget {
  const TimerEnabledTextButtonWidget({
    super.key,
    required this.linkText,
    required this.timerText,
    required this.keyPrefix,
    required this.timerDurationInSeconds,
    required this.availableText,
    required this.onLinkTap,
    this.hyperLinkDisable,
  });

  final String? linkText;
  final String? timerText;
  final String? keyPrefix;
  final int? timerDurationInSeconds;
  final String? availableText;
  final Future Function()? onLinkTap;
  final bool? hyperLinkDisable;

  @override
  State<TimerEnabledTextButtonWidget> createState() =>
      _TimerEnabledTextButtonWidgetState();
}

class _TimerEnabledTextButtonWidgetState
    extends State<TimerEnabledTextButtonWidget> {
  late TimerEnabledTextButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TimerEnabledTextButtonModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.timerController.onStartTimer();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // A text that perfom as a link , which regenerate the OTO on click.
        Semantics(
          label:
              'A text that perfom as a link , which regenerate the OTO on click.',
          child: InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              if (_model.linkEnabled) {
                await widget.onLinkTap?.call();
                return;
              }
            },
            child: Text(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Timer_Enabled_Text_Button',
                      'Link_Text')),
              '',
              style: GoogleFonts.getFont(
                'Inter',
                color: FlutterFlowTheme.of(context).textBasic,
                fontSize: 14.0,
              ),
            ),
          ),
        ),

        // text before timer.
        Semantics(
          label: 'text before timer.',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Timer_Enabled_Text_Button',
                'Available_Text')),
            'AvailableText',
            style: GoogleFonts.getFont(
              'Inter',
              color: FlutterFlowTheme.of(context).textBasic,
              fontSize: 14.0,
            ),
          ),
        ),

        // Timer widget that shows timer for the link text to get activated.
        Semantics(
          label:
              'Timer widget that shows timer for the link text to get activated.',
          child: FlutterFlowTimer(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Timer_Enabled_Text_Button', 'Timer')),
            initialTime: (widget!.timerDurationInSeconds!) * 1000,
            getDisplayTime: (value) => StopWatchTimer.getDisplayTime(
              value,
              hours: false,
              milliSecond: false,
            ),
            controller: _model.timerController,
            updateStateInterval: Duration(milliseconds: 1000),
            onChanged: (value, displayTime, shouldUpdate) {
              _model.timerMilliseconds = value;
              _model.timerValue = displayTime;
              if (shouldUpdate) safeSetState(() {});
            },
            onEnded: () async {
              _model.linkEnabled = true;
              safeSetState(() {});
            },
            textAlign: TextAlign.start,
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).textBasic,
                  fontSize: 14.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.normal,
                ),
          ),
        ),

        // Text widget that displays text after the timer.
        Semantics(
          label: 'Text widget that displays text after the timer.',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Timer_Enabled_Text_Button', 'Timer_Text')),
            'TimerText',
            style: GoogleFonts.getFont(
              'Inter',
              color: FlutterFlowTheme.of(context).textBasic,
              fontSize: 14.0,
            ),
          ),
        ),
      ].divide(SizedBox(width: 6.0)),
    );
  }
}
