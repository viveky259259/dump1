import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'news_box_model.dart';
export 'news_box_model.dart';

///  /// A widget that represents a news box in the AO Portal application.
///
///
/// ///
///   /// This widget displays news items with relevant information and
/// styling.
///   ///
///   /// State Variables:
///   /// - `newsTitle`: A string representing the title of the news item.
///   /// - `newsDescription`: A string representing the description or
/// content of the news item.
///   /// - `newsImageUrl`: A string representing the URL of the image
/// associated with the news item.
///   /// - `publishDate`: A DateTime object representing the date and time
/// when the news item was published.
///   /// - `isFavorite`: A boolean indicating whether the news item is marked
/// as a favorite by the user.
class NewsBoxWidget extends StatefulWidget {
  const NewsBoxWidget({
    super.key,
    this.containerHeight,
    required this.descriptionText,
    required this.newsListItems,
    required this.headText,
    required this.onViewClick,
    required this.keyPrefix,
  });

  final double? containerHeight;
  final String? descriptionText;
  final List<NewsItemStruct>? newsListItems;
  final String? headText;
  final Future Function()? onViewClick;
  final String? keyPrefix;

  @override
  State<NewsBoxWidget> createState() => _NewsBoxWidgetState();
}

class _NewsBoxWidgetState extends State<NewsBoxWidget> {
  late NewsBoxModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NewsBoxModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      elevation: 5.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(4.0),
        ),
        child: Padding(
          padding: EdgeInsets.all(24.0),
          child: Container(
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(0.0),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!, 'News_Box', 'Update_Text')),
                      '',
                      style: GoogleFonts.getFont(
                        'Inter',
                        color: FlutterFlowTheme.of(context).primary,
                        fontWeight: FontWeight.bold,
                        fontSize: 18.0,
                      ),
                    ),
                    FFButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!, 'News_Box', 'Veiw_Button')),
                      onPressed: () async {
                        await widget.onViewClick?.call();
                      },
                      text: 'View All',
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15.0,
                      ),
                      options: FFButtonOptions(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 0.0),
                        iconAlignment: IconAlignment.end,
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryInfo500Default,
                                  fontSize: 14.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.normal,
                                ),
                        elevation: 0.0,
                        borderRadius: BorderRadius.circular(0.0),
                      ),
                    ),
                  ],
                ),
                Builder(
                  builder: (context) {
                    final newsItem =
                        widget!.newsListItems!.toList().take(3).toList();

                    return ListView.separated(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!, 'News_Box', 'ListView')),
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      itemCount: newsItem.length,
                      separatorBuilder: (_, __) => SizedBox(height: 20.0),
                      itemBuilder: (context, newsItemIndex) {
                        final newsItemItem = newsItem[newsItemIndex];
                        return Container(
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'News_Box',
                                                'Sub_Text')),
                                    '',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .textBasic,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14.0,
                                    ),
                                  ),
                                  Text(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'News_Box',
                                                'Date')),
                                    '',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .textBasic,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14.0,
                                    ),
                                  ),
                                ],
                              ),
                              Text(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(widget!.keyPrefix!,
                                        'News_Box', 'Description_Text')),
                                '',
                                maxLines: 2,
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  color: FlutterFlowTheme.of(context).tertiary,
                                  fontSize: 14.0,
                                ),
                              ),
                            ].divide(SizedBox(height: 8.0)),
                          ),
                        );
                      },
                    );
                  },
                ),
              ].divide(SizedBox(height: 20.0)),
            ),
          ),
        ),
      ),
    );
  }
}
