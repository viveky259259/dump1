import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'timer_info_text_model.dart';
export 'timer_info_text_model.dart';

/// /// A class that represents a selection of items.
///
///
/// ///
/// /// This class provides functionality to manage a selection of items,
/// /// including adding, removing, and checking if an item is selected.
/// ///
/// /// State Variables:
/// ///
/// /// - `List<T> _items`: A list that holds the items in the selection.
/// /// - `Set<T> _selectedItems`: A set that holds the currently selected
/// items.
/// ///
/// /// Methods:
/// ///
/// /// - `void addItem(T item)`: Adds an item to the selection.
/// /// - `void removeItem(T item)`: Removes an item from the selection.
/// /// - `bool isSelected(T item)`: Checks if an item is selected.
/// /// - `void toggleSelection(T item)`: Toggles the selection state of an
/// item.
class TimerInfoTextWidget extends StatefulWidget {
  const TimerInfoTextWidget({
    super.key,
    required this.prefixText,
    required this.timerDurationInSeconds,
    required this.suffixText,
    required this.keyPrefix,
    this.onTimerEnd,
  });

  final String? prefixText;
  final int? timerDurationInSeconds;
  final String? suffixText;
  final String? keyPrefix;
  final Future Function()? onTimerEnd;

  @override
  State<TimerInfoTextWidget> createState() => _TimerInfoTextWidgetState();
}

class _TimerInfoTextWidgetState extends State<TimerInfoTextWidget> {
  late TimerInfoTextModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TimerInfoTextModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.timerController.onStartTimer();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // A text to display the text before the timer
        Semantics(
          label: 'A text to display the text before the timer',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Timer_Info_Text', 'Prefix_Text')),
            widget!.prefixText!,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).textTertiary,
                  letterSpacing: 0.0,
                ),
          ),
        ),

        // A timer to show the countdown
        Semantics(
          label: 'A timer to show the countdown',
          child: FlutterFlowTimer(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Timer_Info_Text', 'Timer')),
            initialTime: (widget!.timerDurationInSeconds!) * 1000,
            getDisplayTime: (value) => StopWatchTimer.getDisplayTime(
              value,
              hours: false,
              milliSecond: false,
            ),
            controller: _model.timerController,
            updateStateInterval: Duration(milliseconds: 1000),
            onChanged: (value, displayTime, shouldUpdate) {
              _model.timerMilliseconds = value;
              _model.timerValue = displayTime;
              if (shouldUpdate) safeSetState(() {});
            },
            onEnded: () async {
              await widget.onTimerEnd?.call();
            },
            textAlign: TextAlign.start,
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).textTertiary,
                  fontSize: 14.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ),

        // A text widget to display the text after timer
        Semantics(
          label: 'A text widget to display the text after timer',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Timer_Info_Text', 'Suffix_Text')),
            widget!.suffixText!,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).textTertiary,
                  letterSpacing: 0.0,
                ),
          ),
        ),
      ].divide(SizedBox(width: 6.0)),
    );
  }
}
