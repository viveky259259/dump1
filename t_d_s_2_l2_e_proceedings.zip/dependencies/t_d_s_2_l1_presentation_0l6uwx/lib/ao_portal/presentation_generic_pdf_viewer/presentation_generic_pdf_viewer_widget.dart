import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_generic_pdf_viewer_model.dart';
export 'presentation_generic_pdf_viewer_model.dart';

class PresentationGenericPdfViewerWidget extends StatefulWidget {
  const PresentationGenericPdfViewerWidget({
    super.key,
    required this.keyPrefix,
    this.headingName,
    String? pdfUrl,
  }) : this.pdfUrl = pdfUrl ??
            'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';

  final String? keyPrefix;
  final String? headingName;
  final String pdfUrl;

  @override
  State<PresentationGenericPdfViewerWidget> createState() =>
      _PresentationGenericPdfViewerWidgetState();
}

class _PresentationGenericPdfViewerWidgetState
    extends State<PresentationGenericPdfViewerWidget> {
  late PresentationGenericPdfViewerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationGenericPdfViewerModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFFE6F0FA),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 14.0,
                        color: Color(0x33000000),
                        offset: Offset(
                          -1.0,
                          4.0,
                        ),
                        spreadRadius: 0.0,
                      )
                    ],
                    border: Border.all(
                      color: Color(0xFFDFE0E2),
                    ),
                  ),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(48.0, 12.0, 48.0, 12.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Text(
                          valueOrDefault<String>(
                            widget!.headingName,
                            'Notice u/s 201 or 206C - Preview',
                          ),
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textPrimary,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w600,
                              ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              150.0, 0.0, 150.0, 0.0),
                          child: FlutterFlowPdfViewer(
                            networkPath:
                                'https://samples-files.com/samples/documents/pdf/sample-3-text-images.pdf',
                            horizontalScroll: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
