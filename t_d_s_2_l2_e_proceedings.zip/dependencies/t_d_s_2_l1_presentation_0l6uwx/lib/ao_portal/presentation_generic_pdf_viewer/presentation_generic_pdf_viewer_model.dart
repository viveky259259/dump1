import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'presentation_generic_pdf_viewer_widget.dart'
    show PresentationGenericPdfViewerWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationGenericPdfViewerModel
    extends FlutterFlowModel<PresentationGenericPdfViewerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
