import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'a_o_p_o_r_t_a_l_footer_widget.dart' show AOPORTALFooterWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AOPORTALFooterModel extends FlutterFlowModel<AOPORTALFooterWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
