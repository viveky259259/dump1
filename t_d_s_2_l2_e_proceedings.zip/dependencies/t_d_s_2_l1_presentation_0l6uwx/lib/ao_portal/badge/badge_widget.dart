import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'badge_model.dart';
export 'badge_model.dart';

/// "Badge is designed to show some information based on its states.
///
/// It has 6 different states like information,success,warning, error,alert
/// and disabled. The icon can also be showed along with the description for
/// each of the states if showIcon is set to true.
/// Parameters:
/// keyPrefix: String
/// Use this to generate unique keys which will be used for testing the
/// component.
/// states: Enum: BadgeStatus
/// Choose the state from BadgeStatus enum.
/// description: String
/// Pass the Text to be displayed on the screen
/// showIcon: Boolean
/// To show the icon make the boolean value true else by default it is set to
/// false.
/// width: Double
/// Width of the badge container
/// height: Double
/// Height of the badge container."
class BadgeWidget extends StatefulWidget {
  const BadgeWidget({
    super.key,
    required this.keyPrefix,
    required this.states,
    required this.description,
    bool? showIcon,
    this.width,
    this.height,
  }) : this.showIcon = showIcon ?? false;

  final String? keyPrefix;
  final BadgeStatus? states;
  final String? description;
  final bool showIcon;
  final double? width;
  final double? height;

  @override
  State<BadgeWidget> createState() => _BadgeWidgetState();
}

class _BadgeWidgetState extends State<BadgeWidget> {
  late BadgeModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BadgeModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // Badge is designed to show some information based on its states. It has 6 different states like information,success,warning, error,alert and disabled. The icon can also be showed along with the description for each of the states if showIcon is set to true.
        Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: () {
          if (widget!.states == BadgeStatus.Information) {
            return FlutterFlowTheme.of(context).secondaryInfoBGStroke5;
          } else if (widget!.states == BadgeStatus.Success) {
            return FlutterFlowTheme.of(context).successBGStroke5;
          } else if (widget!.states == BadgeStatus.Warning) {
            return FlutterFlowTheme.of(context).warningBGStroke5;
          } else if (widget!.states == BadgeStatus.Error) {
            return FlutterFlowTheme.of(context).dangerBGStroke5;
          } else if (widget!.states == BadgeStatus.Alert) {
            return FlutterFlowTheme.of(context).dangerBGStroke5;
          } else if (widget!.states == BadgeStatus.Disabled) {
            return FlutterFlowTheme.of(context).neutralBGStroke5;
          } else {
            return FlutterFlowTheme.of(context).neutral100;
          }
        }(),
        borderRadius: BorderRadius.circular(20.0),
        border: Border.all(
          color: () {
            if (widget!.states == BadgeStatus.Information) {
              return FlutterFlowTheme.of(context).secondaryInfoBGStroke30;
            } else if (widget!.states == BadgeStatus.Success) {
              return FlutterFlowTheme.of(context).successBGStroke30;
            } else if (widget!.states == BadgeStatus.Warning) {
              return FlutterFlowTheme.of(context).warning300;
            } else if (widget!.states == BadgeStatus.Error) {
              return FlutterFlowTheme.of(context).dangerBGStroke30;
            } else if (widget!.states == BadgeStatus.Alert) {
              return FlutterFlowTheme.of(context).dangerBGStroke30;
            } else if (widget!.states == BadgeStatus.Disabled) {
              return FlutterFlowTheme.of(context).neutralBGStroke30;
            } else {
              return FlutterFlowTheme.of(context).neutral100;
            }
          }(),
          width: 1.0,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Semantics(
            label:
                'Based on the condition of the states the icon will be displayed.',
            child: Builder(
              builder: (context) {
                if (widget!.states == BadgeStatus.Information) {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Semantics(
                        label: 'Icon for information',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!, 'Badge', 'Info_Icon')),
                          Icons.info_outline,
                          color: FlutterFlowTheme.of(context)
                              .secondaryInfo500Default,
                          size: 16.0,
                        ),
                      ),
                    ),
                  );
                } else if (widget!.states == BadgeStatus.Success) {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Semantics(
                        label:
                            'Icon for success state  will be displayed if the show icon is set to true.',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!, 'Badge', 'Success_Icon')),
                          Icons.check_circle_outlined,
                          color: FlutterFlowTheme.of(context).success700,
                          size: 16.0,
                        ),
                      ),
                    ),
                  );
                } else if (widget!.states == BadgeStatus.Warning) {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Semantics(
                        label:
                            'Icon for warning state  will be displayed if the show icon is set to true.',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!, 'Badge', 'Warning_Icon')),
                          Icons.warning_amber,
                          color: FlutterFlowTheme.of(context).warning800,
                          size: 16.0,
                        ),
                      ),
                    ),
                  );
                } else if (widget!.states == BadgeStatus.Error) {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Semantics(
                        label:
                            'Icon for error state  will be displayed if the show icon is set to true.',
                        child: FaIcon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!, 'Badge', 'Error_Icon')),
                          FontAwesomeIcons.timesCircle,
                          color: FlutterFlowTheme.of(context).danger500Default,
                          size: 16.0,
                        ),
                      ),
                    ),
                  );
                } else if (widget!.states == BadgeStatus.Alert) {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Semantics(
                        label:
                            'Icon for alert state  will be displayed if the show icon is set to true.',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!, 'Badge', 'Alert_Icon')),
                          Icons.report_outlined,
                          color: FlutterFlowTheme.of(context).danger500Default,
                          size: 16.0,
                        ),
                      ),
                    ),
                  );
                } else if (widget!.states == BadgeStatus.Disabled) {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Semantics(
                        label:
                            'Icon for disabled state  will be displayed if the show icon is set to true.',
                        child: Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!, 'Badge',
                                  'Disabled_Icon')),
                          Icons.remove_circle_outline,
                          color: FlutterFlowTheme.of(context).neutral800,
                          size: 16.0,
                        ),
                      ),
                    ),
                  );
                } else {
                  return Visibility(
                    visible: widget!.showIcon,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 6.0),
                      child: Icon(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!, 'Badge', 'Icon')),
                        Icons.info_outline,
                        color: FlutterFlowTheme.of(context).primaryText,
                        size: 16.0,
                      ),
                    ),
                  );
                }
              },
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 5.0),
            child: Semantics(
              label: 'Description of the badge',
              child: Text(
                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                    .generateL1KeyValue(widget!.keyPrefix!, 'Badge', 'Text')),
                widget!.description!,
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      color: () {
                        if (widget!.states == BadgeStatus.Information) {
                          return FlutterFlowTheme.of(context)
                              .secondaryInfo500Default;
                        } else if (widget!.states == BadgeStatus.Success) {
                          return FlutterFlowTheme.of(context).success700;
                        } else if (widget!.states == BadgeStatus.Warning) {
                          return FlutterFlowTheme.of(context).warning800;
                        } else if (widget!.states == BadgeStatus.Error) {
                          return FlutterFlowTheme.of(context).danger500Default;
                        } else if (widget!.states == BadgeStatus.Alert) {
                          return FlutterFlowTheme.of(context).danger500Default;
                        } else if (widget!.states == BadgeStatus.Disabled) {
                          return FlutterFlowTheme.of(context).neutral800;
                        } else {
                          return FlutterFlowTheme.of(context).textBasic;
                        }
                      }(),
                      fontSize: 14.0,
                      letterSpacing: 0.0,
                    ),
              ),
            ),
          ),
        ]
            .divide(SizedBox(width: 5.0))
            .addToStart(SizedBox(width: 8.0))
            .addToEnd(SizedBox(width: 8.0)),
      ),
    );
  }
}
