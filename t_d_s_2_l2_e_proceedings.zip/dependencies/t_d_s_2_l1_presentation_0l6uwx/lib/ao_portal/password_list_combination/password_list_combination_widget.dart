import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'password_list_combination_model.dart';
export 'password_list_combination_model.dart';

class PasswordListCombinationWidget extends StatefulWidget {
  const PasswordListCombinationWidget({
    super.key,
    this.divider1Color,
    this.divider2Color,
    this.divider3Color,
    this.stateText,
    bool? passwordLength,
    bool? upperCase,
    bool? lowerCase,
    bool? oneNumber,
    bool? specialChar,
    required this.keyPrefix,
    this.dividerWidth,
    this.textLabel,
  })  : this.passwordLength = passwordLength ?? false,
        this.upperCase = upperCase ?? false,
        this.lowerCase = lowerCase ?? false,
        this.oneNumber = oneNumber ?? false,
        this.specialChar = specialChar ?? false;

  final Color? divider1Color;
  final Color? divider2Color;
  final Color? divider3Color;
  final String? stateText;
  final bool passwordLength;
  final bool upperCase;
  final bool lowerCase;
  final bool oneNumber;
  final bool specialChar;
  final String? keyPrefix;
  final int? dividerWidth;
  final String? textLabel;

  @override
  State<PasswordListCombinationWidget> createState() =>
      _PasswordListCombinationWidgetState();
}

class _PasswordListCombinationWidgetState
    extends State<PasswordListCombinationWidget> {
  late PasswordListCombinationModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PasswordListCombinationModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
          widget!.keyPrefix!, 'PasswordListCombination', 'Container')),
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!, 'PassowrdListCombination', 'Text')),
                valueOrDefault<String>(
                  widget!.textLabel,
                  'Password Strength : ',
                ),
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
              ),
              Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'PasswordListCombination',
                        'StateText')),
                valueOrDefault<String>(
                  widget!.stateText,
                  'State',
                ),
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
              ),
            ],
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: widget!.dividerWidth?.toDouble(),
                    child: Divider(
                      thickness: 5.0,
                      color: widget!.divider1Color,
                    ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: widget!.dividerWidth?.toDouble(),
                    child: Divider(
                      thickness: 5.0,
                      color: widget!.divider2Color,
                    ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: widget!.dividerWidth?.toDouble(),
                    child: Divider(
                      thickness: 5.0,
                      color: widget!.divider3Color,
                    ),
                  ),
                ],
              ),
            ].divide(SizedBox(width: 5.0)),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Builder(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'PasswordListCombination',
                        'ConditinalBuilder1')),
                builder: (context) {
                  if (widget!.passwordLength) {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PasswordListCombination', 'Success_Icon')),
                          Icons.check_sharp,
                          color: FlutterFlowTheme.of(context).success,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'PasswordListCombination',
                                  'Characters_Length')),
                          'Use 8 to 15 characters',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).success,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  } else {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PasswordListCombination', 'Warning_Icon')),
                          Icons.cancel_outlined,
                          color: FlutterFlowTheme.of(context).error,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'PasswordListCombination',
                                  'Character_Length')),
                          'Use 8 to 15 characters',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).error,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  }
                },
              ),
            ].divide(SizedBox(width: 5.0)),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Builder(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'PasswordListCombination',
                        'ConditinalBuilder2')),
                builder: (context) {
                  if (widget!.upperCase) {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PasswordListCombination', 'Success_Icon')),
                          Icons.check_sharp,
                          color: FlutterFlowTheme.of(context).success,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'PasswordListCombination',
                                  'UpperCase_Character')),
                          'Use at least one uppercase letter (A-Z)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).success,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  } else {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PasswordListCombination', 'Warning_Icon')),
                          Icons.cancel_outlined,
                          color: FlutterFlowTheme.of(context).error,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'PasswordListCombination',
                                  'UpperCase_Character')),
                          'Use at least one uppercase letter (A-Z)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).error,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  }
                },
              ),
            ].divide(SizedBox(width: 5.0)),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Builder(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'PasswordListCombination',
                        'ConditinalBuilder3')),
                builder: (context) {
                  if (widget!.lowerCase) {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Success_Icon')),
                          Icons.check_sharp,
                          color: FlutterFlowTheme.of(context).success,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'LowerCase_Text')),
                          'Use at least one lowercase letter (a-z)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).success,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  } else {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          Icons.cancel_outlined,
                          color: FlutterFlowTheme.of(context).error,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'LowerCase_Text')),
                          'Use at least one lowercase letter (a-z)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).error,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  }
                },
              ),
            ].divide(SizedBox(width: 5.0)),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Builder(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'PasswordListCombination',
                        'ConditinalBuilder4')),
                builder: (context) {
                  if (widget!.oneNumber) {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Success_Icon')),
                          Icons.check_sharp,
                          color: FlutterFlowTheme.of(context).success,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Numeric_Value')),
                          'Use at least one number (e.g. 123)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).success,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  } else {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Warning_Icon')),
                          Icons.cancel_outlined,
                          color: FlutterFlowTheme.of(context).error,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Numeric_Value')),
                          'Use at least one number (e.g. 123)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).error,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  }
                },
              ),
            ].divide(SizedBox(width: 5.0)),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Builder(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'PasswordListCombination',
                        'ConditinalBuilder5')),
                builder: (context) {
                  if (widget!.specialChar) {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Success_Icon')),
                          Icons.check_sharp,
                          color: FlutterFlowTheme.of(context).success,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'PassowrdListCombination',
                                  'Special_Character')),
                          'Use at least special character (e.g.~`!@#\$)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).success,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  } else {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'PassowrdListCombination', 'Warning_icon')),
                          Icons.cancel_outlined,
                          color: FlutterFlowTheme.of(context).error,
                          size: 24.0,
                        ),
                        Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'PassowrdListCombination',
                                  'Special_Character')),
                          'Use at least special character (e.g.~`!@#\$)',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).error,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ].divide(SizedBox(width: 5.0)),
                    );
                  }
                },
              ),
            ].divide(SizedBox(width: 5.0)),
          ),
        ].divide(SizedBox(height: 5.0)),
      ),
    );
  }
}
