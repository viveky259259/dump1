import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_generic_font_size_increment_decrement_model.dart';
export 'presentation_generic_font_size_increment_decrement_model.dart';

class PresentationGenericFontSizeIncrementDecrementWidget
    extends StatefulWidget {
  const PresentationGenericFontSizeIncrementDecrementWidget({
    super.key,
    required this.onTapFontIcon,
    required this.onTapFontIncrease,
    required this.onTapFontDecrease,
    required this.keyPrefix,
  });

  final Future Function()? onTapFontIcon;
  final Future Function()? onTapFontIncrease;
  final Future Function()? onTapFontDecrease;
  final String? keyPrefix;

  @override
  State<PresentationGenericFontSizeIncrementDecrementWidget> createState() =>
      _PresentationGenericFontSizeIncrementDecrementWidgetState();
}

class _PresentationGenericFontSizeIncrementDecrementWidgetState
    extends State<PresentationGenericFontSizeIncrementDecrementWidget> {
  late PresentationGenericFontSizeIncrementDecrementModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => PresentationGenericFontSizeIncrementDecrementModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 336.0,
      height: 166.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Container(
        decoration: BoxDecoration(),
        child: Semantics(
          label:
              'Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text size.',
          child: Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 8.0,
                buttonSize: 40.0,
                icon: Icon(
                  Icons.text_decrease,
                  color: FlutterFlowTheme.of(context).primary,
                  size: 15.0,
                ),
                onPressed: () async {
                  await widget.onTapFontDecrease?.call();
                },
              ),
              FlutterFlowIconButton(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Generic_Header_Website',
                        'FontIconButton')),
                borderRadius: 8.0,
                buttonSize: 40.0,
                fillColor: Colors.transparent,
                icon: Icon(
                  Icons.font_download,
                  color: FlutterFlowTheme.of(context).primary,
                  size: 20.0,
                ),
                onPressed: () async {
                  await widget.onTapFontIcon?.call();
                },
              ),
              FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 8.0,
                buttonSize: 40.0,
                icon: Icon(
                  Icons.text_increase,
                  color: FlutterFlowTheme.of(context).primary,
                  size: 15.0,
                ),
                onPressed: () async {
                  await widget.onTapFontIncrease?.call();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
