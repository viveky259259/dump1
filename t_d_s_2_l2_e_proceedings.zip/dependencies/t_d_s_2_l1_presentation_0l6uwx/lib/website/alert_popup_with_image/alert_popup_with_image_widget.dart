import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'alert_popup_with_image_model.dart';
export 'alert_popup_with_image_model.dart';

/// An altert popup that displays if KYC  verification is successfull.
class AlertPopupWithImageWidget extends StatefulWidget {
  const AlertPopupWithImageWidget({
    super.key,
    required this.headText,
    required this.image,
    required this.keyPrefix,
    this.height,
  });

  final String? headText;
  final String? image;
  final String? keyPrefix;
  final double? height;

  @override
  State<AlertPopupWithImageWidget> createState() =>
      _AlertPopupWithImageWidgetState();
}

class _AlertPopupWithImageWidgetState extends State<AlertPopupWithImageWidget> {
  late AlertPopupWithImageModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AlertPopupWithImageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      elevation: 5.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: Container(
        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
            widget!.keyPrefix!, 'Alert_Popup_with_Image', 'Container')),
        width: 408.0,
        height: widget!.height,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(4.0),
        ),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(20.0, 24.0, 20.0, 0.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // A text that displays the sucess message.
              Semantics(
                label: 'A text that displays the sucess message.',
                child: Text(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Alert_Popup_with_Image',
                          'Sucess_Text')),
                  widget!.headText!,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).success700,
                        fontSize: 20.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),

              // A simple divider.
              Semantics(
                label: 'A simple divider.',
                child: Divider(
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).neutral300,
                ),
              ),

              // Image space to add the image in L2.
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Semantics(
                  label: 'Image space to add the image in L2.',
                  child: ClipRRect(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'Alert_Popup_with_Image',
                            'Popup_Image')),
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.network(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Alert_Popup_with_Image',
                              'Popup_Image')),
                      widget!.image!,
                      width: 236.0,
                      height: 166.0,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
