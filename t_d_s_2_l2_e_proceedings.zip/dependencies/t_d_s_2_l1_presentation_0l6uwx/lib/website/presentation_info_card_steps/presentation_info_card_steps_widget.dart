import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_info_card_steps_model.dart';
export 'presentation_info_card_steps_model.dart';

/// component designed to display information and used to to highlight key
/// data points or summaries.
class PresentationInfoCardStepsWidget extends StatefulWidget {
  const PresentationInfoCardStepsWidget({
    super.key,
    this.infoCardHeading,
    required this.keyPrefix,
    this.width,
    this.height,
    required this.isBoldTextVisible,
    this.maxWidth,
    this.discriptionList,
  });

  final String? infoCardHeading;
  final String? keyPrefix;
  final double? width;
  final double? height;
  final bool? isBoldTextVisible;
  final double? maxWidth;
  final List<String>? discriptionList;

  @override
  State<PresentationInfoCardStepsWidget> createState() =>
      _PresentationInfoCardStepsWidgetState();
}

class _PresentationInfoCardStepsWidgetState
    extends State<PresentationInfoCardStepsWidget> {
  late PresentationInfoCardStepsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationInfoCardStepsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget!.infoCardHeading!,
          style: FlutterFlowTheme.of(context).titleMedium.override(
                fontFamily: 'Inter',
                color: FlutterFlowTheme.of(context).neutral1100,
                letterSpacing: 0.0,
                fontWeight: FontWeight.bold,
              ),
        ),
        Container(
          width: widget!.width,
          height: widget!.height,
          constraints: BoxConstraints(
            maxWidth: widget!.maxWidth!,
          ),
          decoration: BoxDecoration(),
          child: Builder(
            builder: (context) {
              final listInfo = widget!.discriptionList?.toList() ?? [];

              return ListView.separated(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: listInfo.length,
                separatorBuilder: (_, __) => SizedBox(height: 24.0),
                itemBuilder: (context, listInfoIndex) {
                  final listInfoItem = listInfo[listInfoIndex];
                  return Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Icon conatiner
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 1.0, 0.0),
                        child: Semantics(
                          label: 'Icon conatiner',
                          child: Container(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Presentation_InfoCard_Steps',
                                    'Icon_Container')),
                            width: 68.0,
                            height: 44.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryInfoBGStroke5,
                              borderRadius: BorderRadius.circular(3.0),
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).neutral400,
                                width: 1.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (widget!.isBoldTextVisible ?? true)
                              Text(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Presentation_InfoCard_Steps',
                                        'Bold_Text')),
                                'Step ${(listInfoIndex + 1).toString()}',
                                textAlign: TextAlign.start,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .neutral900,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Presentation_InfoCard_Steps',
                                      'Normal_Text')),
                              (widget!.discriptionList!
                                  .elementAtOrNull(listInfoIndex))!,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).neutral900,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ].divide(SizedBox(height: 2.0)),
                        ),
                      ),
                    ].divide(SizedBox(width: 16.0)),
                  );
                },
              );
            },
          ),
        ),
      ].divide(SizedBox(height: 24.0)),
    );
  }
}
