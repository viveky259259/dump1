import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'presentation_info_card_forms_widget.dart'
    show PresentationInfoCardFormsWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PresentationInfoCardFormsModel
    extends FlutterFlowModel<PresentationInfoCardFormsWidget> {
  ///  Local state fields for this component.

  int? showDetails = 1;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
