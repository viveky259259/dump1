import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_info_card_forms_model.dart';
export 'presentation_info_card_forms_model.dart';

class PresentationInfoCardFormsWidget extends StatefulWidget {
  const PresentationInfoCardFormsWidget({
    super.key,
    this.description,
    this.onTap,
    this.labelText,
    this.width,
    this.height,
    required this.keyPrefix,
    this.discriptionList,
  });

  final String? description;
  final Future Function()? onTap;
  final String? labelText;
  final double? width;
  final double? height;
  final String? keyPrefix;
  final List<String>? discriptionList;

  @override
  State<PresentationInfoCardFormsWidget> createState() =>
      _PresentationInfoCardFormsWidgetState();
}

class _PresentationInfoCardFormsWidgetState
    extends State<PresentationInfoCardFormsWidget> {
  late PresentationInfoCardFormsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationInfoCardFormsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(10.0),
      child: Container(
        width: widget!.width,
        height: widget!.height,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Presentation_InfoCard_Forms',
                      'Info_Icon')),
              Icons.info_outline,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 24.0,
            ),
            Flexible(
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 4.0, 0.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Flexible(
                      child: Text(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue('Presentation_InfoCard_Forms',
                                widget!.keyPrefix!, 'LabelText')),
                        valueOrDefault<String>(
                          widget!.labelText,
                          'label',
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).neutral900,
                              fontSize: 16.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w500,
                            ),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Builder(
                          builder: (context) {
                            final infoCardFormDiscription =
                                widget!.discriptionList?.toList() ?? [];

                            return ListView.builder(
                              padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              itemCount: infoCardFormDiscription.length,
                              itemBuilder:
                                  (context, infoCardFormDiscriptionIndex) {
                                final infoCardFormDiscriptionItem =
                                    infoCardFormDiscription[
                                        infoCardFormDiscriptionIndex];
                                return Row(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${(infoCardFormDiscriptionIndex + 1).toString()}. ',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    Flexible(
                                      child: Text(
                                        (widget!.discriptionList!
                                            .elementAtOrNull(
                                                infoCardFormDiscriptionIndex))!,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .neutral900,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                        ),
                      ],
                    ),
                    Semantics(
                      label:
                          'This is a clickable button. After clicking It will expand the text.',
                      child: FFButtonWidget(
                        onPressed: () async {
                          await widget.onTap?.call();
                          _model.showDetails = _model.showDetails == 1
                              ? widget!.discriptionList?.length
                              : 1;
                          safeSetState(() {});
                        },
                        text: 'Read More',
                        options: FFButtonOptions(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Colors.transparent,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context).primary,
                                    fontSize: 14.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(0.0),
                        ),
                      ),
                    ),
                  ].divide(SizedBox(height: 12.0)),
                ),
              ),
            ),
          ].divide(SizedBox(width: 12.0)),
        ),
      ),
    );
  }
}
