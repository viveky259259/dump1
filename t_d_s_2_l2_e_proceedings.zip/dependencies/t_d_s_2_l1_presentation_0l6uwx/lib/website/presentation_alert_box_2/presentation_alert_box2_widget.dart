import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'presentation_alert_box2_model.dart';
export 'presentation_alert_box2_model.dart';

/// "A versatile box component designed to display additional information,
/// context, or actions related to a primary content area.
///
///
///
/// Parameters: title: String
/// The title of the card, displayed prominently at the top.
/// content: String
/// The main content of the card, which can include text, images, or other
/// HTML elements.
/// icon: Icon (Optional)
/// An icon displayed at the top of the card, often used to represent the
/// card's purpose or category."
class PresentationAlertBox2Widget extends StatefulWidget {
  const PresentationAlertBox2Widget({
    super.key,
    required this.hintText1,
    required this.hintText2,
    this.status,
    this.width,
    this.height,
    required this.keyPrefix,
  });

  final String? hintText1;
  final String? hintText2;
  final Status? status;
  final int? width;
  final int? height;
  final String? keyPrefix;

  @override
  State<PresentationAlertBox2Widget> createState() =>
      _PresentationAlertBox2WidgetState();
}

class _PresentationAlertBox2WidgetState
    extends State<PresentationAlertBox2Widget> {
  late PresentationAlertBox2Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PresentationAlertBox2Model());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width?.toDouble(),
      height: widget!.height?.toDouble(),
      decoration: BoxDecoration(
        color: () {
          if (widget!.status == Status.error) {
            return FlutterFlowTheme.of(context).danger100;
          } else if (widget!.status == Status.information) {
            return FlutterFlowTheme.of(context).secondaryInfoBGStroke5;
          } else {
            return FlutterFlowTheme.of(context).primaryText;
          }
        }(),
        borderRadius: BorderRadius.circular(4.0),
        border: Border.all(
          color: () {
            if (widget!.status == Status.error) {
              return FlutterFlowTheme.of(context).danger500Default;
            } else if (widget!.status == Status.information) {
              return FlutterFlowTheme.of(context).secondaryInfo300;
            } else {
              return FlutterFlowTheme.of(context).primaryText;
            }
          }(),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(12.0),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Semantics(
              label: 'This is used as Alert Icon.',
              child: Icon(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Presentation_AlertBox',
                        'Info_Icon')),
                Icons.info_outline,
                color: () {
                  if (widget!.status == Status.error) {
                    return FlutterFlowTheme.of(context).danger500Default;
                  } else if (widget!.status == Status.information) {
                    return FlutterFlowTheme.of(context).primary500;
                  } else {
                    return FlutterFlowTheme.of(context).primaryText;
                  }
                }(),
                size: 15.0,
              ),
            ),
            Flexible(
              child: RichText(
                textScaler: MediaQuery.of(context).textScaler,
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Presentation_AlertBox',
                        'AlertText')),
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: valueOrDefault<String>(
                        widget!.hintText1,
                        'asd',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color: () {
                              if (widget!.status == Status.error) {
                                return FlutterFlowTheme.of(context)
                                    .danger500Default;
                              } else if (widget!.status == Status.information) {
                                return FlutterFlowTheme.of(context).primary500;
                              } else {
                                return FlutterFlowTheme.of(context).primaryText;
                              }
                            }(),
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    TextSpan(
                      text: widget!.hintText2!,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color: () {
                              if (widget!.status == Status.error) {
                                return FlutterFlowTheme.of(context)
                                    .danger500Default;
                              } else if (widget!.status == Status.information) {
                                return FlutterFlowTheme.of(context).primary500;
                              } else {
                                return FlutterFlowTheme.of(context).primaryText;
                              }
                            }(),
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.w500,
                          ),
                    )
                  ],
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: () {
                          if (widget!.status == Status.error) {
                            return FlutterFlowTheme.of(context)
                                .danger500Default;
                          } else if (widget!.status == Status.information) {
                            return FlutterFlowTheme.of(context).primary500;
                          } else {
                            return FlutterFlowTheme.of(context).primaryText;
                          }
                        }(),
                        letterSpacing: 0.0,
                      ),
                ),
                textAlign: TextAlign.start,
                maxLines: 3,
              ),
            ),
          ].divide(SizedBox(width: 8.0)),
        ),
      ),
    );
  }
}
