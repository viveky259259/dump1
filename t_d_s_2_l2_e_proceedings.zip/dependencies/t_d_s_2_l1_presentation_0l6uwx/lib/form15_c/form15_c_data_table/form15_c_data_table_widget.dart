import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_data_table_model.dart';
export 'form15_c_data_table_model.dart';

class Form15CDataTableWidget extends StatefulWidget {
  const Form15CDataTableWidget({
    super.key,
    required this.dataTableParam,
    required this.keyPrefix,
  });

  final List<Form15BranchDataStruct>? dataTableParam;
  final String? keyPrefix;

  @override
  State<Form15CDataTableWidget> createState() => _Form15CDataTableWidgetState();
}

class _Form15CDataTableWidgetState extends State<Form15CDataTableWidget> {
  late Form15CDataTableModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CDataTableModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 250.0,
            decoration: BoxDecoration(),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 5.0),
              child: Builder(
                builder: (context) {
                  final tableForm15c = widget!.dataTableParam!.toList();

                  return FlutterFlowDataTable<Form15BranchDataStruct>(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'DataTable',
                            'Form15C_DataTable')),
                    controller: _model.form15CTableController,
                    data: tableForm15c,
                    columnsBuilder: (onSortChanged) => [
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            ' ',
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'Country ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'State ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'District ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'Flat/Door/Building',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'Road/Street/Block/Sector ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'PIN Code ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'Post Office ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                      DataColumn2(
                        label: DefaultTextStyle.merge(
                          softWrap: true,
                          child: Text(
                            'Area/Locality ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).textBasic,
                              fontWeight: FontWeight.bold,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ),
                    ],
                    dataRowBuilder: (tableForm15cItem, tableForm15cIndex,
                            selected, onSelectChanged) =>
                        DataRow(
                      color: MaterialStateProperty.all(
                        tableForm15cIndex % 2 == 0
                            ? FlutterFlowTheme.of(context).secondaryBackground
                            : FlutterFlowTheme.of(context).neutral300,
                      ),
                      cells: [
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          tableForm15cItem.country,
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          tableForm15cItem.state,
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                        Text(
                          '',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.0,
                          ),
                        ),
                      ].map((c) => DataCell(c)).toList(),
                    ),
                    paginated: true,
                    selectable: false,
                    hidePaginator: true,
                    showFirstLastButtons: false,
                    headingRowHeight: 56.0,
                    dataRowHeight: 48.0,
                    columnSpacing: 20.0,
                    headingRowColor: FlutterFlowTheme.of(context).neutral300,
                    borderRadius: BorderRadius.circular(8.0),
                    addHorizontalDivider: true,
                    addTopAndBottomDivider: false,
                    hideDefaultHorizontalDivider: true,
                    horizontalDividerColor:
                        FlutterFlowTheme.of(context).secondaryBackground,
                    horizontalDividerThickness: 1.0,
                    addVerticalDivider: false,
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
