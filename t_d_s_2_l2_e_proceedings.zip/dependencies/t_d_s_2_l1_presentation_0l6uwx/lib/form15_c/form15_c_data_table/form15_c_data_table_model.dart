import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'form15_c_data_table_widget.dart' show Form15CDataTableWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CDataTableModel extends FlutterFlowModel<Form15CDataTableWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Form15CTable widget.
  final form15CTableController =
      FlutterFlowDataTableController<Form15BranchDataStruct>();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    form15CTableController.dispose();
  }
}
