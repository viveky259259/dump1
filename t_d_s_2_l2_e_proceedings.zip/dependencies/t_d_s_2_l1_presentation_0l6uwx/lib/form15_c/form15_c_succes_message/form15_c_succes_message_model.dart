import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'form15_c_succes_message_widget.dart' show Form15CSuccesMessageWidget;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Form15CSuccesMessageModel
    extends FlutterFlowModel<Form15CSuccesMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
