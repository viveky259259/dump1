import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form15_c_succes_message_model.dart';
export 'form15_c_succes_message_model.dart';

/// /// A widget that displays a success message for Form 15C with an image,
/// heading, and multiple info texts.
///
///
/// ///
/// /// This widget is a stateful widget that uses a model to manage its
/// state. It displays an image, a heading text,
/// /// and three informational texts. The keys for the widgets are generated
/// using a custom function to ensure uniqueness.
/// ///
/// /// State Variables:
/// /// - `_model`: An instance of `Form15CSuccesMessageModel` that manages
/// the state of this widget.
class Form15CSuccesMessageWidget extends StatefulWidget {
  const Form15CSuccesMessageWidget({
    super.key,
    required this.headText,
    required this.keyPrefix,
    required this.infoText1,
    required this.infoText2,
    required this.infoText3,
  });

  final String? headText;
  final String? keyPrefix;
  final String? infoText1;
  final String? infoText2;
  final String? infoText3;

  @override
  State<Form15CSuccesMessageWidget> createState() =>
      _Form15CSuccesMessageWidgetState();
}

class _Form15CSuccesMessageWidgetState
    extends State<Form15CSuccesMessageWidget> {
  late Form15CSuccesMessageModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Form15CSuccesMessageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(),
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipRRect(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'Form15C_Succes_Message', 'Image')),
            borderRadius: BorderRadius.circular(8.0),
            child: Image.asset(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!, 'Form15C_Succes_Message', 'Image')),
              'dependencies/t_d_s_2_l1_presentation_0l6uwx/assets/images/Illustration.png',
              width: 192.0,
              height: 192.0,
              fit: BoxFit.cover,
            ),
          ),

          // A text which displays thw heading of sucess message.
          Semantics(
            label: 'A text which displays thw heading of sucess message.',
            child: Text(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Form15C_Succes_Message',
                      'Head_Text')),
              '',
              style: GoogleFonts.getFont(
                'Inter',
                color: FlutterFlowTheme.of(context).primary,
                fontWeight: FontWeight.bold,
                fontSize: 24.0,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Text widget that displays info texts.
                Semantics(
                  label: 'ext widget that displays info texts.',
                  child: Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'Form15C_Succes_Message',
                            'Info_Text1')),
                    widget!.infoText1!,
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),

                // ext widget that displays info texts.
                Semantics(
                  label: 'ext widget that displays info texts.',
                  child: Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'Form15C_Succes_Message',
                            'Info_Text2')),
                    widget!.infoText2!,
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),

                // ext widget that displays info texts.
                Semantics(
                  label: 'ext widget that displays info texts.',
                  child: Text(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'Form15C_Succes_Message',
                            'Info_Text3')),
                    widget!.infoText3!,
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ].divide(SizedBox(height: 16.0)),
            ),
          ),
        ].divide(SizedBox(height: 24.0)),
      ),
    );
  }
}
