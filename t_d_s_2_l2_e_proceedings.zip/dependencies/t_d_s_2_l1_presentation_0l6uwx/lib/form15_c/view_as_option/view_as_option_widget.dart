import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'view_as_option_model.dart';
export 'view_as_option_model.dart';

///  A class that represents a selection with state variables to manage
/// /// the selection's properties and behavior.
///
///
/// ///
/// /// State Variables:
/// /// - `selectedItems`: A list of items that are currently selected.
/// /// - `isSelected`: A boolean indicating whether the selection is active.
/// /// - `selectionMode`: An enum representing the mode of selection (e.g.,
/// single, multiple).
/// /// - `selectionColor`: A color used to highlight the selected items.
/// ///
/// /// This class provides methods to add, remove, and clear selections, as
/// well as
/// /// to check if an item is selected.
class ViewAsOptionWidget extends StatefulWidget {
  const ViewAsOptionWidget({
    super.key,
    required this.activeIndex,
    required this.label,
    required this.keyPrefix,
    required this.onClick,
  });

  final int? activeIndex;
  final String? label;
  final String? keyPrefix;
  final Future Function(int index)? onClick;

  @override
  State<ViewAsOptionWidget> createState() => _ViewAsOptionWidgetState();
}

class _ViewAsOptionWidgetState extends State<ViewAsOptionWidget> {
  late ViewAsOptionModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ViewAsOptionModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Semantics(
          label: 'A text widget that to display the label text for view .',
          child: Text(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!, 'View_As_Option', 'View_Text')),
            '',
            style: GoogleFonts.getFont(
              'Inter',
              color: FlutterFlowTheme.of(context).textBasic,
              fontSize: 12.0,
            ),
          ),
        ),
        InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            _model.activeState = 0;
            safeSetState(() {});
            await widget.onClick?.call(
              widget!.activeIndex!,
            );
          },
          child: Container(
            width: 36.0,
            height: 36.0,
            decoration: BoxDecoration(
              color: _model.activeState == 0
                  ? FlutterFlowTheme.of(context).secondary
                  : FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(8.0),
              border: Border.all(
                color: _model.activeState == 0
                    ? FlutterFlowTheme.of(context).secondaryInfo500Default
                    : FlutterFlowTheme.of(context).secondaryInfoBGStroke30,
                width: 1.0,
              ),
            ),
            child:
                // An icon widget to display grid icon.
                Semantics(
              label: 'An icon widget to display grid icon.',
              child: Icon(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!, 'View_As_Option', 'Grid_Icon')),
                Icons.grid_view,
                color: _model.activeState == 0
                    ? FlutterFlowTheme.of(context).alternate
                    : FlutterFlowTheme.of(context).secondaryInfo500Default,
                size: 15.0,
              ),
            ),
          ),
        ),
        InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            _model.activeState = 1;
            safeSetState(() {});
            await widget.onClick?.call(
              widget!.activeIndex!,
            );
          },
          child: Container(
            width: 36.0,
            height: 36.0,
            decoration: BoxDecoration(
              color: _model.activeState == 1
                  ? FlutterFlowTheme.of(context).secondaryInfo500Default
                  : FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(8.0),
              border: Border.all(
                color: _model.activeState == 1
                    ? FlutterFlowTheme.of(context).secondaryInfo500Default
                    : FlutterFlowTheme.of(context).secondaryInfoBGStroke30,
                width: 1.0,
              ),
            ),
            child:
                // A n icon widget to display list icon
                Semantics(
              label: 'A n icon widget to display list icon',
              child: Icon(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!, 'View_As_Option', 'List_Icon')),
                Icons.list,
                color: _model.activeState == 1
                    ? FlutterFlowTheme.of(context).secondaryBackground
                    : FlutterFlowTheme.of(context).secondaryInfo500Default,
                size: 15.0,
              ),
            ),
          ),
        ),
      ].divide(SizedBox(width: 16.0)),
    );
  }
}
