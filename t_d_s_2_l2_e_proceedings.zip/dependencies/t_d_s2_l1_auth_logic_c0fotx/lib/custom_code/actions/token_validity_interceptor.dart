// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:ff_commons/api_requests/api_interceptor.dart';
import 'package:t_d_s2_l1_events_289fsk/custom_code/actions/index.dart'
    as eventActions;

class TokenValidityInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    final _token = FFAppState().authToken;
    if (_token.isNotEmpty) {
      options.headers['authorization'] = 'Bearer $_token';
    }
    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Check the status code to see if the token is expired
    if (response.statusCode == 401) {
      // Token is expired, we need to trigger logout
      final logoutEvent = LogoutEventModelStruct(
        message: response.jsonBody['message'],
      );
      await eventActions.triggerEvent(
        FFAppConstants.logoutEventType,
        logoutEvent.toMap(),
      );
    }
    return response;
  }
}
