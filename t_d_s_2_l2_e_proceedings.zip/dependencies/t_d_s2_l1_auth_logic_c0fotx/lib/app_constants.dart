import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String logoutEventType = 'LOGOUT_EVENT';
  static const String loginEventType = 'LOGIN_EVENT';
}
