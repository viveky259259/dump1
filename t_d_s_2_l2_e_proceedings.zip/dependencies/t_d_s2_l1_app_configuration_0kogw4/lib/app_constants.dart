import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String apiBaseUrlKey = 'API_BASE_URL';
  static const String reportErrorKey = 'REPORT_ERROR';
  static const String apiBaseUrlPlaceholder = 'https://localhost';
  static const String reportAnalyticsKey = 'REPORT_ANALYTICS';
  static const String mixpanelProjectTokenKey = 'MIXPANEL_PROJECT_TOKEN';
  static const String sentryDSNKey = 'SENTRY_DSN';
}
