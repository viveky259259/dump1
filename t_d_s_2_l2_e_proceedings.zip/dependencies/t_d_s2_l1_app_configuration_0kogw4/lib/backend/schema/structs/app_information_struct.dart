// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AppInformationStruct extends BaseStruct {
  AppInformationStruct({
    String? version,
    String? name,
    String? buildNumber,
  })  : _version = version,
        _name = name,
        _buildNumber = buildNumber;

  // "version" field.
  String? _version;
  String get version => _version ?? '';
  set version(String? val) => _version = val;

  bool hasVersion() => _version != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "buildNumber" field.
  String? _buildNumber;
  String get buildNumber => _buildNumber ?? '';
  set buildNumber(String? val) => _buildNumber = val;

  bool hasBuildNumber() => _buildNumber != null;

  static AppInformationStruct fromMap(Map<String, dynamic> data) =>
      AppInformationStruct(
        version: data['version'] as String?,
        name: data['name'] as String?,
        buildNumber: data['buildNumber'] as String?,
      );

  static AppInformationStruct? maybeFromMap(dynamic data) => data is Map
      ? AppInformationStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'version': _version,
        'name': _name,
        'buildNumber': _buildNumber,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'version': serializeParam(
          _version,
          ParamType.String,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'buildNumber': serializeParam(
          _buildNumber,
          ParamType.String,
        ),
      }.withoutNulls;

  static AppInformationStruct fromSerializableMap(Map<String, dynamic> data) =>
      AppInformationStruct(
        version: deserializeParam(
          data['version'],
          ParamType.String,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        buildNumber: deserializeParam(
          data['buildNumber'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'AppInformationStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AppInformationStruct &&
        version == other.version &&
        name == other.name &&
        buildNumber == other.buildNumber;
  }

  @override
  int get hashCode => const ListEquality().hash([version, name, buildNumber]);
}

AppInformationStruct createAppInformationStruct({
  String? version,
  String? name,
  String? buildNumber,
}) =>
    AppInformationStruct(
      version: version,
      name: name,
      buildNumber: buildNumber,
    );
