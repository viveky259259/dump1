// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AppConfigurationStruct extends BaseStruct {
  AppConfigurationStruct({
    String? apiBaseUrl,
    bool? reportError,
    bool? reportAnalytics,
    String? mixpanelProjectToken,
    String? sentryDSN,
  })  : _apiBaseUrl = apiBaseUrl,
        _reportError = reportError,
        _reportAnalytics = reportAnalytics,
        _mixpanelProjectToken = mixpanelProjectToken,
        _sentryDSN = sentryDSN;

  // "apiBaseUrl" field.
  String? _apiBaseUrl;
  String get apiBaseUrl => _apiBaseUrl ?? '';
  set apiBaseUrl(String? val) => _apiBaseUrl = val;

  bool hasApiBaseUrl() => _apiBaseUrl != null;

  // "reportError" field.
  bool? _reportError;
  bool get reportError => _reportError ?? false;
  set reportError(bool? val) => _reportError = val;

  bool hasReportError() => _reportError != null;

  // "reportAnalytics" field.
  bool? _reportAnalytics;
  bool get reportAnalytics => _reportAnalytics ?? false;
  set reportAnalytics(bool? val) => _reportAnalytics = val;

  bool hasReportAnalytics() => _reportAnalytics != null;

  // "mixpanelProjectToken" field.
  String? _mixpanelProjectToken;
  String get mixpanelProjectToken => _mixpanelProjectToken ?? '';
  set mixpanelProjectToken(String? val) => _mixpanelProjectToken = val;

  bool hasMixpanelProjectToken() => _mixpanelProjectToken != null;

  // "sentryDSN" field.
  String? _sentryDSN;
  String get sentryDSN => _sentryDSN ?? '';
  set sentryDSN(String? val) => _sentryDSN = val;

  bool hasSentryDSN() => _sentryDSN != null;

  static AppConfigurationStruct fromMap(Map<String, dynamic> data) =>
      AppConfigurationStruct(
        apiBaseUrl: data['apiBaseUrl'] as String?,
        reportError: data['reportError'] as bool?,
        reportAnalytics: data['reportAnalytics'] as bool?,
        mixpanelProjectToken: data['mixpanelProjectToken'] as String?,
        sentryDSN: data['sentryDSN'] as String?,
      );

  static AppConfigurationStruct? maybeFromMap(dynamic data) => data is Map
      ? AppConfigurationStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'apiBaseUrl': _apiBaseUrl,
        'reportError': _reportError,
        'reportAnalytics': _reportAnalytics,
        'mixpanelProjectToken': _mixpanelProjectToken,
        'sentryDSN': _sentryDSN,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'apiBaseUrl': serializeParam(
          _apiBaseUrl,
          ParamType.String,
        ),
        'reportError': serializeParam(
          _reportError,
          ParamType.bool,
        ),
        'reportAnalytics': serializeParam(
          _reportAnalytics,
          ParamType.bool,
        ),
        'mixpanelProjectToken': serializeParam(
          _mixpanelProjectToken,
          ParamType.String,
        ),
        'sentryDSN': serializeParam(
          _sentryDSN,
          ParamType.String,
        ),
      }.withoutNulls;

  static AppConfigurationStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      AppConfigurationStruct(
        apiBaseUrl: deserializeParam(
          data['apiBaseUrl'],
          ParamType.String,
          false,
        ),
        reportError: deserializeParam(
          data['reportError'],
          ParamType.bool,
          false,
        ),
        reportAnalytics: deserializeParam(
          data['reportAnalytics'],
          ParamType.bool,
          false,
        ),
        mixpanelProjectToken: deserializeParam(
          data['mixpanelProjectToken'],
          ParamType.String,
          false,
        ),
        sentryDSN: deserializeParam(
          data['sentryDSN'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'AppConfigurationStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AppConfigurationStruct &&
        apiBaseUrl == other.apiBaseUrl &&
        reportError == other.reportError &&
        reportAnalytics == other.reportAnalytics &&
        mixpanelProjectToken == other.mixpanelProjectToken &&
        sentryDSN == other.sentryDSN;
  }

  @override
  int get hashCode => const ListEquality().hash([
        apiBaseUrl,
        reportError,
        reportAnalytics,
        mixpanelProjectToken,
        sentryDSN
      ]);
}

AppConfigurationStruct createAppConfigurationStruct({
  String? apiBaseUrl,
  bool? reportError,
  bool? reportAnalytics,
  String? mixpanelProjectToken,
  String? sentryDSN,
}) =>
    AppConfigurationStruct(
      apiBaseUrl: apiBaseUrl,
      reportError: reportError,
      reportAnalytics: reportAnalytics,
      mixpanelProjectToken: mixpanelProjectToken,
      sentryDSN: sentryDSN,
    );
