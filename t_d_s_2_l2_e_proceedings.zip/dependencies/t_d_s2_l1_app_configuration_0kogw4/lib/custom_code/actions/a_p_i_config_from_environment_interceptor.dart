// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:ff_commons/api_requests/api_interceptor.dart';

class APIConfigFromEnvironmentInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    // 1. Replace the baseUrl placeholder with the baseUrl from environment
    final baseUrlFromEnv = FFAppState().appConfiguration.apiBaseUrl;
    final apiUrl = options.apiUrl;
    final updatedUrl =
        apiUrl.replaceAll(FFAppConstants.apiBaseUrlPlaceholder, baseUrlFromEnv);

    // Update the ApiCallOptions with new config
    final updatedOptions = copyWithApiCallOptions(
      options,
      apiUrl: updatedUrl, // updated based url from environment
    );

    return updatedOptions;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Perform any necessary calls or modifications to the [response] prior
    // to returning it.
    return response;
  }
}

ApiCallOptions copyWithApiCallOptions(
  ApiCallOptions options, {
  String? callName,
  String? apiUrl,
  Map<String, dynamic>? headers,
  Map<String, dynamic>? params,
  String? body,
  bool? returnBody,
  bool? encodeBodyUtf8,
  bool? decodeUtf8,
  bool? alwaysAllowBody,
  bool? cache,
  bool? isStreamingApi,
}) {
  return ApiCallOptions(
    callName: callName ?? options.callName,
    callType: options.callType,
    apiUrl: apiUrl ?? options.apiUrl,
    headers: headers ?? options.headers,
    params: params ?? options.params,
    bodyType: options.bodyType,
    body: body ?? options.body,
    returnBody: returnBody ?? options.returnBody,
    encodeBodyUtf8: encodeBodyUtf8 ?? options.encodeBodyUtf8,
    decodeUtf8: decodeUtf8 ?? options.decodeUtf8,
    alwaysAllowBody: alwaysAllowBody ?? options.alwaysAllowBody,
    cache: cache ?? options.cache,
    isStreamingApi: isStreamingApi ?? options.isStreamingApi,
  );
}
