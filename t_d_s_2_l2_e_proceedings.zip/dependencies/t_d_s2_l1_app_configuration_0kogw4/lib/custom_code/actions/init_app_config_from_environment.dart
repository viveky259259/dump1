// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future initAppConfigFromEnvironment() async {
  const apiBaseUrl = const String.fromEnvironment(
    FFAppConstants.apiBaseUrlKey,
    defaultValue: 'http://localhost:3005/api',
  );

  const reportError = const bool.fromEnvironment(
    FFAppConstants.reportErrorKey,
    defaultValue: false,
  );

  const reportAnalytics = const bool.fromEnvironment(
    FFAppConstants.reportAnalyticsKey,
    defaultValue: false,
  );

  const mixpanelProjectToken = const String.fromEnvironment(
    FFAppConstants.mixpanelProjectTokenKey,
    defaultValue: '',
  );

  const sentryDSN = const String.fromEnvironment(
    FFAppConstants.sentryDSNKey,
    defaultValue: '',
  );

  FFAppState().appConfiguration = AppConfigurationStruct(
    apiBaseUrl: apiBaseUrl,
    reportError: reportError,
    reportAnalytics: reportAnalytics,
    mixpanelProjectToken: mixpanelProjectToken,
    sentryDSN: sentryDSN,
  );
}
