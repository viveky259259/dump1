import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:ff_commons/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  AppConfigurationStruct _appConfiguration = AppConfigurationStruct();
  AppConfigurationStruct get appConfiguration => _appConfiguration;
  set appConfiguration(AppConfigurationStruct value) {
    _appConfiguration = value;
  }

  void updateAppConfigurationStruct(Function(AppConfigurationStruct) updateFn) {
    updateFn(_appConfiguration);
  }

  AppInformationStruct _appInformation = AppInformationStruct();
  AppInformationStruct get appInformation => _appInformation;
  set appInformation(AppInformationStruct value) {
    _appInformation = value;
  }

  void updateAppInformationStruct(Function(AppInformationStruct) updateFn) {
    updateFn(_appInformation);
  }
}
