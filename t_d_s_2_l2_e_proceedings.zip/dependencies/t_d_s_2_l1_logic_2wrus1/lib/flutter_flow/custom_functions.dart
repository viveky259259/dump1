import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:ff_commons/flutter_flow/lat_lng.dart';
import 'package:ff_commons/flutter_flow/place.dart';
import 'package:ff_commons/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String generateL1KeyValue(
  String keyPrefix,
  String componentName,
  String widget,
) {
  /// Generates a key for Level 1 components.
  ///
  /// - [keyPrefix]: The prefix passed from higher levels (L2 or L3).
  /// - [componentName]: The name of the L1 component.
  /// - [widget]: The specific widget within the L1 component.
  String value = "${keyPrefix}_${componentName}_$widget";

  return value;
}

String generateL2KeyValuePrefix(
  String keyPrefix,
  String componentName,
  String useCase,
) {
  /// Generates a key prefix for Level 2 components.
  ///
  /// - [keyPrefix]: The prefix passed from L3 components.
  /// - [componentName]: The name of the L2 component.
  /// - [useCase]: The specific use case or field within the L2 component.
  String prefixValue = '${keyPrefix}_${componentName}_${useCase}';
  return prefixValue;
}

String generateL3KeyValuePrefix(
  String moduleName,
  String routeName,
) {
  /// Generates a key for Level 3 components.
  ///
  /// - [moduleName]: The name of the module (e.g., 'Onboarding').
  /// - [routeName]: The name of the route or screen (e.g., 'PersonalKYC').
  return "${moduleName}_$routeName";
}

String maskMobileNumber(String mobileNumber) {
  String maskedNumber = 'XX' + mobileNumber.substring(mobileNumber.length - 3);
  return maskedNumber;
}

String maskEmailAddress(String emailAddress) {
  List<String> parts = emailAddress.split('@');

  String maskedPart = 'XXXX' + parts[0].substring(parts[0].length - 3);
  String finalMaskedEmail = maskedPart + '@' + parts[1];
  return finalMaskedEmail;
}

bool isUploadedCorrectFileSize(List<FFUploadedFile> files) {
  // write a function to check file size if any file size greater than 5 MB return false
  for (var file in files) {
    if ((file.bytes!.length / (1024 * 1024)) > 5 || (file.bytes!.length <= 0)) {
      return false;
    }
  }
  return true;
}

List<FileMetadataStruct> getMetadataForUploadedFiles(
    List<FFUploadedFile> uploadedFiles) {
  final metadataForFiles = uploadedFiles.map((FFUploadedFile uploadedFile) {
    int fileSizeInBytes = uploadedFile.bytes?.lengthInBytes ?? 0;
    int fileSizeInKB = fileSizeInBytes ~/ 1024;
    int fileSizeInMB = fileSizeInBytes ~/ (1024 * 1024);

    return FileMetadataStruct(
      fileName: uploadedFile.name,
      height: uploadedFile.height,
      width: uploadedFile.width,
      sizeInMB: fileSizeInMB,
      sizeInKB: fileSizeInKB,
      format: uploadedFile.name?.split('.').last,
    );
  }).toList();

  return metadataForFiles;
}
