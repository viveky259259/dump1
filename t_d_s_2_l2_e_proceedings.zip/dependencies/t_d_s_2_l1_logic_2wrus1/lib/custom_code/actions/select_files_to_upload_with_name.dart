// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:file_picker/file_picker.dart';
import 'dart:async';

Future<List<FFUploadedFile>> selectFilesToUploadWithName(
    List<String>? supportedFileExtensions) async {
  // Check if a mock is provided in the current zone
  final mockFunction = Zone.current['mockSelectPDFFilesToUpload']
      as Future<List<FFUploadedFile>> Function()?;
  if (mockFunction != null) {
    // Use the mock function if defined
    return mockFunction();
  }
  try {
    final allowedExtensions =
        (supportedFileExtensions != null && supportedFileExtensions.isNotEmpty)
            ? supportedFileExtensions
            : ['pdf', 'tiff', 'zip', 'jpeg', 'jpg'];
    final selectedFiles = await selectFiles(
      allowedExtensions: allowedExtensions,
      multiFile: true,
    );

    if (selectedFiles != null && selectedFiles.isNotEmpty) {
      return selectedFiles.map((m) {
        final _file = FFUploadedFile(
          name: Uri.encodeFull(m.storagePath.split('/').last),
          bytes: m.bytes,
        );
        return _file;
      }).toList();
    }
  } catch (e, stacktrace) {
    print(e);
    print(stacktrace);
  }
  return [];
}

Future<SelectedFile?> selectFile({
  String? storageFolderPath,
  List<String>? allowedExtensions,
}) =>
    selectFiles(
      storageFolderPath: storageFolderPath,
      allowedExtensions: allowedExtensions,
      multiFile: false,
    ).then((value) => value?.first);

class SelectedFile {
  const SelectedFile({
    this.storagePath = '',
    this.filePath,
    required this.bytes,
    this.dimensions,
    this.blurHash,
  });
  final String storagePath;
  final String? filePath;
  final Uint8List bytes;
  final MediaDimensions? dimensions;
  final String? blurHash;
}

class MediaDimensions {
  const MediaDimensions({
    this.height,
    this.width,
  });
  final double? height;
  final double? width;
}

Future<List<SelectedFile>?> selectFiles({
  String? storageFolderPath,
  List<String>? allowedExtensions,
  bool multiFile = false,
}) async {
  final pickedFiles = await FilePicker.platform.pickFiles(
    type: allowedExtensions != null ? FileType.custom : FileType.any,
    allowedExtensions: allowedExtensions,
    withData: true,
    allowMultiple: multiFile,
  );
  if (pickedFiles == null || pickedFiles.files.isEmpty) {
    return null;
  }
  if (multiFile) {
    return Future.wait(pickedFiles.files.asMap().entries.map((e) async {
      final index = e.key;
      final file = e.value;
      final storagePath =
          _getStoragePath(storageFolderPath, file.name, false, index);
      return SelectedFile(
        storagePath: storagePath,
        filePath: isWeb ? null : file.path,
        bytes: file.bytes!,
      );
    }));
  }
  final file = pickedFiles.files.first;
  if (file.bytes == null) {
    return null;
  }
  final storagePath = _getStoragePath(storageFolderPath, file.name, false);
  return [
    SelectedFile(
      storagePath: storagePath,
      filePath: isWeb ? null : file.path,
      bytes: file.bytes!,
    )
  ];
}

String _getStoragePath(
  String? pathPrefix,
  String fileName,
  bool isVideo, [
  int? index,
]) {
  pathPrefix = _removeTrailingSlash(pathPrefix);
  final ext = isVideo ? 'mp4' : fileName.split('.').last;
  final indexStr = index != null ? '_$index' : '';
  final fileNameSansExtension = fileName.split('.').first.replaceAll(' ', '_');
  //return '$pathPrefix/$fileNameSansExtension$indexStr.$ext';
  return '$pathPrefix/$fileNameSansExtension.$ext';
}

String? _removeTrailingSlash(String? path) => path != null && path.endsWith('/')
    ? path.substring(0, path.length - 1)
    : path;
