// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FileMetadataStruct extends BaseStruct {
  FileMetadataStruct({
    String? fileName,
    double? height,
    double? width,
    int? sizeInMB,
    int? sizeInKB,
    String? format,
  })  : _fileName = fileName,
        _height = height,
        _width = width,
        _sizeInMB = sizeInMB,
        _sizeInKB = sizeInKB,
        _format = format;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "height" field.
  double? _height;
  double get height => _height ?? 0.0;
  set height(double? val) => _height = val;

  void incrementHeight(double amount) => height = height + amount;

  bool hasHeight() => _height != null;

  // "width" field.
  double? _width;
  double get width => _width ?? 0.0;
  set width(double? val) => _width = val;

  void incrementWidth(double amount) => width = width + amount;

  bool hasWidth() => _width != null;

  // "sizeInMB" field.
  int? _sizeInMB;
  int get sizeInMB => _sizeInMB ?? 0;
  set sizeInMB(int? val) => _sizeInMB = val;

  void incrementSizeInMB(int amount) => sizeInMB = sizeInMB + amount;

  bool hasSizeInMB() => _sizeInMB != null;

  // "sizeInKB" field.
  int? _sizeInKB;
  int get sizeInKB => _sizeInKB ?? 0;
  set sizeInKB(int? val) => _sizeInKB = val;

  void incrementSizeInKB(int amount) => sizeInKB = sizeInKB + amount;

  bool hasSizeInKB() => _sizeInKB != null;

  // "format" field.
  String? _format;
  String get format => _format ?? '';
  set format(String? val) => _format = val;

  bool hasFormat() => _format != null;

  static FileMetadataStruct fromMap(Map<String, dynamic> data) =>
      FileMetadataStruct(
        fileName: data['fileName'] as String?,
        height: castToType<double>(data['height']),
        width: castToType<double>(data['width']),
        sizeInMB: castToType<int>(data['sizeInMB']),
        sizeInKB: castToType<int>(data['sizeInKB']),
        format: data['format'] as String?,
      );

  static FileMetadataStruct? maybeFromMap(dynamic data) => data is Map
      ? FileMetadataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
        'height': _height,
        'width': _width,
        'sizeInMB': _sizeInMB,
        'sizeInKB': _sizeInKB,
        'format': _format,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'height': serializeParam(
          _height,
          ParamType.double,
        ),
        'width': serializeParam(
          _width,
          ParamType.double,
        ),
        'sizeInMB': serializeParam(
          _sizeInMB,
          ParamType.int,
        ),
        'sizeInKB': serializeParam(
          _sizeInKB,
          ParamType.int,
        ),
        'format': serializeParam(
          _format,
          ParamType.String,
        ),
      }.withoutNulls;

  static FileMetadataStruct fromSerializableMap(Map<String, dynamic> data) =>
      FileMetadataStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        height: deserializeParam(
          data['height'],
          ParamType.double,
          false,
        ),
        width: deserializeParam(
          data['width'],
          ParamType.double,
          false,
        ),
        sizeInMB: deserializeParam(
          data['sizeInMB'],
          ParamType.int,
          false,
        ),
        sizeInKB: deserializeParam(
          data['sizeInKB'],
          ParamType.int,
          false,
        ),
        format: deserializeParam(
          data['format'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FileMetadataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FileMetadataStruct &&
        fileName == other.fileName &&
        height == other.height &&
        width == other.width &&
        sizeInMB == other.sizeInMB &&
        sizeInKB == other.sizeInKB &&
        format == other.format;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([fileName, height, width, sizeInMB, sizeInKB, format]);
}

FileMetadataStruct createFileMetadataStruct({
  String? fileName,
  double? height,
  double? width,
  int? sizeInMB,
  int? sizeInKB,
  String? format,
}) =>
    FileMetadataStruct(
      fileName: fileName,
      height: height,
      width: width,
      sizeInMB: sizeInMB,
      sizeInKB: sizeInKB,
      format: format,
    );
