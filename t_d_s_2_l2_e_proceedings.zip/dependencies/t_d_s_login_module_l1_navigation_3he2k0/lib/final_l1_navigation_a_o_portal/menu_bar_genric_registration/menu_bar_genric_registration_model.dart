import '/components/dropdown_list_widget.dart';
import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'menu_bar_genric_registration_widget.dart'
    show MenuBarGenricRegistrationWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MenuBarGenricRegistrationModel
    extends FlutterFlowModel<MenuBarGenricRegistrationWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Home.
  late NavigationGenericMenuButtonModel homeModel;
  // Model for About_Us.
  late NavigationGenericMenuButtonModel aboutUsModel;
  // Model for LMS.
  late NavigationGenericMenuButtonModel lmsModel;
  // Model for Help.
  late NavigationGenericMenuButtonModel helpModel;
  // Model for Related_Links.
  late NavigationGenericMenuButtonModel relatedLinksModel;
  // Model for Utilities.
  late NavigationGenericMenuButtonModel utilitiesModel;

  @override
  void initState(BuildContext context) {
    homeModel = createModel(context, () => NavigationGenericMenuButtonModel());
    aboutUsModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    lmsModel = createModel(context, () => NavigationGenericMenuButtonModel());
    helpModel = createModel(context, () => NavigationGenericMenuButtonModel());
    relatedLinksModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    utilitiesModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
  }

  @override
  void dispose() {
    homeModel.dispose();
    aboutUsModel.dispose();
    lmsModel.dispose();
    helpModel.dispose();
    relatedLinksModel.dispose();
    utilitiesModel.dispose();
  }
}
