import '/components/dropdown_list_widget.dart';
import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'menu_bar_genric_registration_model.dart';
export 'menu_bar_genric_registration_model.dart';

/// A Generic Menubar designed for AO portal for the user to select different
/// options and naviagte to the required page after the user logins.
///
///
///
/// Parameters:
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// actionCallBack: Action
/// Define the action to be performed when the File Now Text  is tapped, It
/// will navigate to the different page.
///
/// isDropdownVisible : Boolean
class MenuBarGenricRegistrationWidget extends StatefulWidget {
  const MenuBarGenricRegistrationWidget({
    super.key,
    required this.keyPrefix,
    this.onTapHome,
    this.onTapAboutUs,
    this.onTapLMS,
    this.onTapHelp,
    this.onTapRelatedLinks,
    this.onTapUtilities,
    this.onTapSearch,
  });

  final String? keyPrefix;
  final Future Function()? onTapHome;
  final Future Function()? onTapAboutUs;
  final Future Function()? onTapLMS;
  final Future Function()? onTapHelp;
  final Future Function()? onTapRelatedLinks;
  final Future Function()? onTapUtilities;
  final Future Function()? onTapSearch;

  @override
  State<MenuBarGenricRegistrationWidget> createState() =>
      _MenuBarGenricRegistrationWidgetState();
}

class _MenuBarGenricRegistrationWidgetState
    extends State<MenuBarGenricRegistrationWidget> {
  late MenuBarGenricRegistrationModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MenuBarGenricRegistrationModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primary700,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(48.0, 0.0, 0.0, 0.0),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  child: wrapWithModel(
                    model: _model.homeModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Home')),
                      title: 'Home',
                      isIconVisible: false,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Home'),
                      onTapAction: () async {
                        // OnTapHome
                        await widget.onTapHome?.call();
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  child: wrapWithModel(
                    model: _model.aboutUsModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'About_Us')),
                      title: 'About Us',
                      isIconVisible: false,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'About_Us'),
                      onTapAction: () async {
                        // onTapAboutUs
                        await widget.onTapAboutUs?.call();
                      },
                    ),
                  ),
                ),
                Builder(
                  builder: (context) => Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    child: wrapWithModel(
                      model: _model.lmsModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericMenuButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'MenuBar_Generic_Registration', 'LMS')),
                        title: 'LMS',
                        isIconVisible: true,
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'MenuBar_Generic_Registration', 'LMS'),
                        onTapAction: () async {
                          await widget.onTapLMS?.call();
                          await showAlignedDialog(
                            barrierColor: Colors.transparent,
                            context: context,
                            isGlobal: false,
                            avoidOverflow: false,
                            targetAnchor: AlignmentDirectional(0.0, 1.0)
                                .resolve(Directionality.of(context)),
                            followerAnchor: AlignmentDirectional(-1.0, -1.0)
                                .resolve(Directionality.of(context)),
                            builder: (dialogContext) {
                              return Material(
                                color: Colors.transparent,
                                child: DropdownListWidget(),
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  child: wrapWithModel(
                    model: _model.helpModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Help')),
                      title: 'Help',
                      isIconVisible: false,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Help'),
                      onTapAction: () async {
                        // onTapHelp
                        await widget.onTapHelp?.call();
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  child: wrapWithModel(
                    model: _model.relatedLinksModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Related_Links')),
                      title: 'Related Links',
                      isIconVisible: false,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Related_Links'),
                      onTapAction: () async {
                        // onTapRelatedLinks
                        await widget.onTapRelatedLinks?.call();
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  child: wrapWithModel(
                    model: _model.utilitiesModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Utilities')),
                      title: 'Utilities',
                      isIconVisible: false,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Generic_Registration',
                              'Utilities'),
                      onTapAction: () async {
                        await widget.onTapUtilities?.call();
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 48.0, 0.0),
            child: FlutterFlowIconButton(
              borderColor: FlutterFlowTheme.of(context).primary500,
              borderRadius: 4.0,
              borderWidth: 1.0,
              buttonSize: 32.0,
              fillColor: FlutterFlowTheme.of(context).primary700,
              icon: Icon(
                Icons.search_sharp,
                color: FlutterFlowTheme.of(context).alternate,
                size: 18.0,
              ),
              onPressed: () async {
                await widget.onTapSearch?.call();
              },
            ),
          ),
        ],
      ),
    );
  }
}
