import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_footer_model.dart';
export 'navigation_generic_footer_model.dart';

class NavigationGenericFooterWidget extends StatefulWidget {
  const NavigationGenericFooterWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<NavigationGenericFooterWidget> createState() =>
      _NavigationGenericFooterWidgetState();
}

class _NavigationGenericFooterWidgetState
    extends State<NavigationGenericFooterWidget> {
  late NavigationGenericFooterModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NavigationGenericFooterModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 111.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primary700,
        border: Border.all(
          color: FlutterFlowTheme.of(context).primary500,
        ),
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(48.0, 0.0, 48.0, 0.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      height: 64.0,
                      decoration: BoxDecoration(),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Semantics(
                            label: 'Government of India Logo',
                            child: ClipRRect(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_AO_Portal',
                                      'Logo_1')),
                              borderRadius: BorderRadius.circular(0.0),
                              child: SvgPicture.asset(
                                'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/Logo_(New).svg',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Semantics(
                            label: 'harit aaykar logo',
                            child: ClipRRect(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_AO_Portal',
                                      'Logo_2')),
                              borderRadius: BorderRadius.circular(4.0),
                              child: Image.network(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Navigation_Generic_Footer_AO_Portal',
                                        'Logo_2')),
                                'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTsPkZTOaDOAwhN5L91EuneMtnrCqyAr-e8NB6UC_Zv8HBwh-9h',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ]
                            .divide(SizedBox(width: 20.0))
                            .addToStart(SizedBox(width: 24.0)),
                      ),
                    ),
                  ],
                ),
                Container(
                  decoration: BoxDecoration(),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Text(
                              'Last reviewed and updated on : ',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                    lineHeight: 2.0,
                                  ),
                            ),
                            Text(
                              dateTimeFormat(
                                "yMMMd",
                                getCurrentTimestamp,
                                locale:
                                    FFLocalizations.of(context).languageCode,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                    lineHeight: 2.0,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        'This site is best viewed in 1366x768 resolution with latest version of Chrome, Firefox, Safari & Microsoft Edge',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w500,
                              lineHeight: 2.0,
                            ),
                      ),
                      Text(
                        '© 2016 - Copyright Income Tax Department, Ministry of Finance, Government of India. All Rights Reserved.',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w500,
                              lineHeight: 2.0,
                            ),
                      ),
                    ].divide(SizedBox(height: 5.0)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
