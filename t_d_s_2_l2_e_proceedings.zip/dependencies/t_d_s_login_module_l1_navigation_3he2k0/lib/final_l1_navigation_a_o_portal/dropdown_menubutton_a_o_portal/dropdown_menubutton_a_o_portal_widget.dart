import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dropdown_menubutton_a_o_portal_model.dart';
export 'dropdown_menubutton_a_o_portal_model.dart';

class DropdownMenubuttonAOPortalWidget extends StatefulWidget {
  const DropdownMenubuttonAOPortalWidget({
    super.key,
    required this.menuButtonAction,
    required this.keyPrefix,
    this.labelText,
  });

  final Future Function()? menuButtonAction;
  final String? keyPrefix;
  final String? labelText;

  @override
  State<DropdownMenubuttonAOPortalWidget> createState() =>
      _DropdownMenubuttonAOPortalWidgetState();
}

class _DropdownMenubuttonAOPortalWidgetState
    extends State<DropdownMenubuttonAOPortalWidget> {
  late DropdownMenubuttonAOPortalModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DropdownMenubuttonAOPortalModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(24.0, 16.0, 24.0, 16.0),
      child: Container(
        height: 54.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(4.0),
          shape: BoxShape.rectangle,
        ),
        child: FFButtonWidget(
          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
              widget!.keyPrefix!, 'Dropdown_Menubutton_AO_portal', 'Button')),
          onPressed: () async {
            await widget.menuButtonAction?.call();
          },
          text: valueOrDefault<String>(
            widget!.labelText,
            'Lower/Nil Deduction Certificate',
          ),
          options: FFButtonOptions(
            height: 54.0,
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
            iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
            textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                  fontFamily: 'Inter',
                  color: FlutterFlowTheme.of(context).neutral900,
                  fontSize: 12.0,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w500,
                ),
            elevation: 0.0,
            borderRadius: BorderRadius.circular(8.0),
          ),
        ),
      ),
    );
  }
}
