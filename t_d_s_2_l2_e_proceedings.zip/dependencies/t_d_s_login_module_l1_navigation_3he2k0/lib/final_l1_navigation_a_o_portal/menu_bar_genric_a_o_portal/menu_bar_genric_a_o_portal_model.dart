import '/final_l1_navigation_a_o_portal/dropdown_menubutton_a_o_portal/dropdown_menubutton_a_o_portal_widget.dart';
import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'menu_bar_genric_a_o_portal_widget.dart'
    show MenuBarGenricAOPortalWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MenuBarGenricAOPortalModel
    extends FlutterFlowModel<MenuBarGenricAOPortalWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Dashboard_component.
  late NavigationGenericMenuButtonModel dashboardComponentModel;
  // Model for Service_Component.
  late NavigationGenericMenuButtonModel serviceComponentModel;
  // Model for StatutoryComponent.
  late NavigationGenericMenuButtonModel statutoryComponentModel;
  // Model for FormsApplicationsComponent.
  late NavigationGenericMenuButtonModel formsApplicationsComponentModel;
  // Model for CommonFunctionComponent.
  late NavigationGenericMenuButtonModel commonFunctionComponentModel;
  // Model for TicketsComponent.
  late NavigationGenericMenuButtonModel ticketsComponentModel;
  // Model for MISAnalyticsComponent.
  late NavigationGenericMenuButtonModel mISAnalyticsComponentModel;
  // Model for LmsComponent.
  late NavigationGenericMenuButtonModel lmsComponentModel;
  // Model for ProfileComponent.
  late NavigationGenericMenuButtonModel profileComponentModel;

  @override
  void initState(BuildContext context) {
    dashboardComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    serviceComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    statutoryComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    formsApplicationsComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    commonFunctionComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    ticketsComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    mISAnalyticsComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    lmsComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    profileComponentModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
  }

  @override
  void dispose() {
    dashboardComponentModel.dispose();
    serviceComponentModel.dispose();
    statutoryComponentModel.dispose();
    formsApplicationsComponentModel.dispose();
    commonFunctionComponentModel.dispose();
    ticketsComponentModel.dispose();
    mISAnalyticsComponentModel.dispose();
    lmsComponentModel.dispose();
    profileComponentModel.dispose();
  }
}
