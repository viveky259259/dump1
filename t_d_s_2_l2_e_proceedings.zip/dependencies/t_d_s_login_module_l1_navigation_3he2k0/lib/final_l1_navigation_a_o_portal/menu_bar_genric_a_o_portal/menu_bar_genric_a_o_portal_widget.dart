import '/final_l1_navigation_a_o_portal/dropdown_menubutton_a_o_portal/dropdown_menubutton_a_o_portal_widget.dart';
import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'menu_bar_genric_a_o_portal_model.dart';
export 'menu_bar_genric_a_o_portal_model.dart';

/// A Generic Menubar designed for AO portal for the user to select different
/// options and naviagte to the required page after the user logins.
///
///
///
/// Parameters:
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// actionCallBack: Action
/// Define the action to be performed when the File Now Text  is tapped, It
/// will navigate to the different page.
///
/// isDropdownVisible : Boolean
class MenuBarGenricAOPortalWidget extends StatefulWidget {
  const MenuBarGenricAOPortalWidget({
    super.key,
    this.isDropdownVisible,
    required this.keyPrefix,
    this.onTapAction,
  });

  final bool? isDropdownVisible;
  final String? keyPrefix;
  final Future Function()? onTapAction;

  @override
  State<MenuBarGenricAOPortalWidget> createState() =>
      _MenuBarGenricAOPortalWidgetState();
}

class _MenuBarGenricAOPortalWidgetState
    extends State<MenuBarGenricAOPortalWidget> {
  late MenuBarGenricAOPortalModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MenuBarGenricAOPortalModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primary700,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.dashboardComponentModel,
                updateCallback: () => safeSetState(() {}),
                child: NavigationGenericMenuButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'MenuBar_Genric',
                          'Navigation_Generic_MenuButton')),
                  title: 'Dashboard',
                  isIconVisible: false,
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'MenuBar_Genric',
                          'Navigation_Generic_MenuButton'),
                  onTapAction: () async {},
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: wrapWithModel(
                  model: _model.serviceComponentModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericMenuButtonWidget(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton')),
                    title: 'Services',
                    isIconVisible: true,
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton'),
                    onTapAction: () async {},
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: wrapWithModel(
                  model: _model.statutoryComponentModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericMenuButtonWidget(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton')),
                    title: 'Statutory Functions',
                    isIconVisible: true,
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton'),
                    onTapAction: () async {},
                  ),
                ),
              ),
              Builder(
                builder: (context) => Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  child: wrapWithModel(
                    model: _model.formsApplicationsComponentModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Genric',
                              'Navigation_Generic_MenuButton')),
                      title: 'Forms & Applications',
                      isIconVisible: false,
                      keyPrefix: 'key',
                      onTapAction: () async {
                        await showAlignedDialog(
                          barrierColor: Colors.transparent,
                          context: context,
                          isGlobal: false,
                          avoidOverflow: false,
                          targetAnchor: AlignmentDirectional(-1.0, 0.0)
                              .resolve(Directionality.of(context)),
                          followerAnchor: AlignmentDirectional(-1.0, -1.0)
                              .resolve(Directionality.of(context)),
                          builder: (dialogContext) {
                            return Material(
                              color: Colors.transparent,
                              child: DropdownMenubuttonAOPortalWidget(
                                keyPrefix: 'key',
                                menuButtonAction: () async {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        '',
                                        style: TextStyle(
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                        ),
                                      ),
                                      duration: Duration(milliseconds: 4000),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context)
                                              .secondary,
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: wrapWithModel(
                  model: _model.commonFunctionComponentModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericMenuButtonWidget(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton')),
                    title: 'Common Functions',
                    isIconVisible: false,
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton'),
                    onTapAction: () async {},
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: wrapWithModel(
                  model: _model.ticketsComponentModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericMenuButtonWidget(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton')),
                    title: 'Tickets',
                    isIconVisible: false,
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton'),
                    onTapAction: () async {},
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: wrapWithModel(
                  model: _model.mISAnalyticsComponentModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericMenuButtonWidget(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton')),
                    title: 'MIS & Analytics',
                    isIconVisible: false,
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton'),
                    onTapAction: () async {},
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: wrapWithModel(
                  model: _model.lmsComponentModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericMenuButtonWidget(
                    key: ValueKey(
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton')),
                    title: 'LMS',
                    isIconVisible: false,
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            widget!.keyPrefix!,
                            'MenuBar_Genric',
                            'Navigation_Generic_MenuButton'),
                    onTapAction: () async {},
                  ),
                ),
              ),
            ].divide(SizedBox(width: 12.0)),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Icon(
                    Icons.account_circle_outlined,
                    color: FlutterFlowTheme.of(context).primaryBackground,
                    size: 24.0,
                  ),
                  wrapWithModel(
                    model: _model.profileComponentModel,
                    updateCallback: () => safeSetState(() {}),
                    child: NavigationGenericMenuButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Genric',
                              'Navigation_Generic_MenuButton')),
                      title: 'Profile',
                      isIconVisible: true,
                      keyPrefix:
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'MenuBar_Genric',
                              'Navigation_Generic_MenuButton'),
                      onTapAction: () async {},
                    ),
                  ),
                ].divide(SizedBox(width: 8.0)),
              ),
              SizedBox(
                height: 20.0,
                child: VerticalDivider(
                  width: 0.0,
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).alternate,
                ),
              ),
              FlutterFlowIconButton(
                borderRadius: 4.0,
                buttonSize: 32.0,
                fillColor: FlutterFlowTheme.of(context).primary700,
                icon: Icon(
                  Icons.notifications_none_outlined,
                  color: FlutterFlowTheme.of(context).alternate,
                  size: 20.0,
                ),
                onPressed: () {
                  print('IconButton pressed ...');
                },
              ),
              SizedBox(
                height: 20.0,
                child: VerticalDivider(
                  width: 0.0,
                  thickness: 1.0,
                  color: FlutterFlowTheme.of(context).alternate,
                ),
              ),
              FlutterFlowIconButton(
                borderColor: FlutterFlowTheme.of(context).primary500,
                borderRadius: 4.0,
                borderWidth: 1.0,
                buttonSize: 32.0,
                fillColor: FlutterFlowTheme.of(context).primary700,
                icon: Icon(
                  Icons.search_sharp,
                  color: FlutterFlowTheme.of(context).alternate,
                  size: 20.0,
                ),
                onPressed: () {
                  print('IconButton pressed ...');
                },
              ),
            ].divide(SizedBox(width: 16.0)),
          ),
        ].addToStart(SizedBox(width: 48.0)).addToEnd(SizedBox(width: 48.0)),
      ),
    );
  }
}
