import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'chip_switch_model.dart';
export 'chip_switch_model.dart';

/// /// A widget that represents a switchable chip component.
///
///
/// ///
/// /// This widget allows users to toggle between different states using a
/// chip-like UI element.
/// ///
/// /// State Variables:
/// /// - `_isSelected`: A boolean that indicates whether the chip is
/// currently selected or not.
/// /// - `_chipLabel`: A string that holds the label text displayed on the
/// chip.
class ChipSwitchWidget extends StatefulWidget {
  const ChipSwitchWidget({
    super.key,
    required this.keyPrefix,
    required this.activeIndex,
    required this.onClick,
  });

  final String? keyPrefix;
  final int? activeIndex;
  final Future Function()? onClick;

  @override
  State<ChipSwitchWidget> createState() => _ChipSwitchWidgetState();
}

class _ChipSwitchWidgetState extends State<ChipSwitchWidget> {
  late ChipSwitchModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChipSwitchModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        borderRadius: BorderRadius.circular(50.0),
        border: Border.all(
          color: FlutterFlowTheme.of(context).neutral400,
          width: 0.5,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await widget.onClick?.call();
              _model.activeState = 0;
              safeSetState(() {});
            },
            child: Container(
              width: 26.0,
              height: 26.0,
              decoration: BoxDecoration(
                color: _model.activeState == 0
                    ? FlutterFlowTheme.of(context).secondaryInfoBGStroke10
                    : FlutterFlowTheme.of(context).secondaryBackground,
                shape: BoxShape.circle,
              ),
              alignment: AlignmentDirectional(0.0, 0.0),
              child:
                  // An icon widget to display file view
                  Semantics(
                label: 'An icon widget to display file view',
                child: Icon(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!, 'Chip_Switch', 'File_Icon')),
                  Icons.list_alt_sharp,
                  color: _model.activeState == 0
                      ? FlutterFlowTheme.of(context).secondaryInfo500Default
                      : FlutterFlowTheme.of(context).neutral800,
                  size: 12.0,
                ),
              ),
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await widget.onClick?.call();
              _model.activeState = 1;
              safeSetState(() {});
            },
            child: Container(
              width: 26.0,
              height: 26.0,
              decoration: BoxDecoration(
                color: _model.activeState == 1
                    ? FlutterFlowTheme.of(context).secondaryInfoBGStroke10
                    : FlutterFlowTheme.of(context).secondaryBackground,
                shape: BoxShape.circle,
              ),
              alignment: AlignmentDirectional(0.0, 0.0),
              child:
                  // An icon widget to display graph veiw.
                  Semantics(
                label: 'An icon widget to display graph veiw.',
                child: Icon(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!, 'Chip_Switch', 'Graph_Icon')),
                  Icons.bar_chart,
                  color: _model.activeState == 1
                      ? FlutterFlowTheme.of(context).secondaryInfo500Default
                      : FlutterFlowTheme.of(context).neutral800,
                  size: 12.0,
                ),
              ),
            ),
          ),
        ].divide(SizedBox(width: 4.0)),
      ),
    );
  }
}
