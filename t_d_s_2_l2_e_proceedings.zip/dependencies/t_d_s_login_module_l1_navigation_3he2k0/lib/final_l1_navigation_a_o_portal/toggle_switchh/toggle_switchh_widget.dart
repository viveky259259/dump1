import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'toggle_switchh_model.dart';
export 'toggle_switchh_model.dart';

/// /// A widget that represents a switchable radio component.
///
///
/// ///
/// /// This widget allows users to toggle between different states .///
/// /// State Variables:
/// /// - `_isSelected`: A boolean that indicates whether the chip is
/// currently selected or not.
class ToggleSwitchhWidget extends StatefulWidget {
  const ToggleSwitchhWidget({
    super.key,
    required this.keyPrefix,
    required this.activeIndex,
    required this.onClick,
  });

  final String? keyPrefix;
  final int? activeIndex;
  final Future Function()? onClick;

  @override
  State<ToggleSwitchhWidget> createState() => _ToggleSwitchhWidgetState();
}

class _ToggleSwitchhWidgetState extends State<ToggleSwitchhWidget> {
  late ToggleSwitchhModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ToggleSwitchhModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40.0,
      height: 20.0,
      decoration: BoxDecoration(
        color: _model.activeState == 0
            ? FlutterFlowTheme.of(context).secondaryInfo500Default
            : FlutterFlowTheme.of(context).neutral300,
        borderRadius: BorderRadius.circular(50.0),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(1.0, 0.0, 0.0, 0.0),
            child: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                await widget.onClick?.call();
                _model.activeState = 0;
                safeSetState(() {});
              },
              child: Container(
                width: 18.0,
                height: 18.0,
                decoration: BoxDecoration(
                  color: _model.activeState == 0
                      ? FlutterFlowTheme.of(context).secondaryInfo500Default
                      : FlutterFlowTheme.of(context).secondaryBackground,
                  shape: BoxShape.circle,
                ),
                alignment: AlignmentDirectional(0.0, 0.0),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 1.0, 0.0),
            child: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                await widget.onClick?.call();
                _model.activeState = 1;
                safeSetState(() {});
              },
              child: Container(
                width: 18.0,
                height: 18.0,
                decoration: BoxDecoration(
                  color: _model.activeState == 1
                      ? FlutterFlowTheme.of(context).neutral300
                      : FlutterFlowTheme.of(context).secondaryBackground,
                  shape: BoxShape.circle,
                ),
                alignment: AlignmentDirectional(0.0, 0.0),
              ),
            ),
          ),
        ].divide(SizedBox(width: 4.0)),
      ),
    );
  }
}
