import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_page_banner_model.dart';
export 'generic_page_banner_model.dart';

class GenericPageBannerWidget extends StatefulWidget {
  const GenericPageBannerWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<GenericPageBannerWidget> createState() =>
      _GenericPageBannerWidgetState();
}

class _GenericPageBannerWidgetState extends State<GenericPageBannerWidget> {
  late GenericPageBannerModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericPageBannerModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 28.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 48.0, 0.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(
                  Icons.navigate_before,
                  color: FlutterFlowTheme.of(context).primary400,
                  size: 20.0,
                ),
                Text(
                  'Prev',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).primary600Default,
                        letterSpacing: 0.0,
                      ),
                ),
                SizedBox(
                  height: 20.0,
                  child: VerticalDivider(
                    thickness: 1.0,
                    color: FlutterFlowTheme.of(context).neutral400,
                  ),
                ),
                Text(
                  '1/4',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).primary600Default,
                        letterSpacing: 0.0,
                      ),
                ),
                SizedBox(
                  height: 20.0,
                  child: VerticalDivider(
                    thickness: 1.0,
                    color: FlutterFlowTheme.of(context).neutral400,
                  ),
                ),
                Text(
                  'Next',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).primary600Default,
                        letterSpacing: 0.0,
                      ),
                ),
                Icon(
                  Icons.navigate_next,
                  color: FlutterFlowTheme.of(context).primary400,
                  size: 20.0,
                ),
              ].divide(SizedBox(width: 8.0)).addToStart(SizedBox(width: 48.0)),
            ),
            Text(
              'CPC TDS 2.0 is coming live soon',
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).primary600Default,
                    fontSize: 12.0,
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            FlutterFlowIconButton(
              borderRadius: 8.0,
              fillColor: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
              icon: Icon(
                Icons.clear,
                color: FlutterFlowTheme.of(context).primary400,
                size: 18.0,
              ),
              onPressed: () {
                print('IconButton pressed ...');
              },
            ),
          ],
        ),
      ),
    );
  }
}
