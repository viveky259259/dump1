import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_data_points_a_o_portal_model.dart';
export 'generic_data_points_a_o_portal_model.dart';

class GenericDataPointsAOPortalWidget extends StatefulWidget {
  const GenericDataPointsAOPortalWidget({
    super.key,
    required this.keyPrefix,
    required this.isPositive,
    required this.amount,
    required this.labelText,
  });

  final String? keyPrefix;
  final bool? isPositive;
  final String? amount;
  final String? labelText;

  @override
  State<GenericDataPointsAOPortalWidget> createState() =>
      _GenericDataPointsAOPortalWidgetState();
}

class _GenericDataPointsAOPortalWidgetState
    extends State<GenericDataPointsAOPortalWidget> {
  late GenericDataPointsAOPortalModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericDataPointsAOPortalModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label:
          'This is the main container which consists of the label of the information being shown & the amount of the label which is getting shown.',
      child: Container(
        decoration: BoxDecoration(
          color: widget!.isPositive!
              ? FlutterFlowTheme.of(context).successBGStroke5
              : FlutterFlowTheme.of(context).dangerBGStroke5,
          borderRadius: BorderRadius.circular(4.0),
          border: Border.all(
            color: widget!.isPositive!
                ? FlutterFlowTheme.of(context).success
                : FlutterFlowTheme.of(context).danger500Default,
            width: 1.0,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 13.5, 0.0, 13.5),
              child: Semantics(
                label:
                    'This container consists of an icon & the label of the information which is getting shown.',
                child: Container(
                  decoration: BoxDecoration(),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Semantics(
                        label: 'This is the ellipse icon.',
                        child: Icon(
                          Icons.circle,
                          color: widget!.isPositive!
                              ? FlutterFlowTheme.of(context).success400
                              : FlutterFlowTheme.of(context).danger400,
                          size: 10.0,
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 37.0, 0.0),
                        child: Semantics(
                          label:
                              'This is the label of the information which is getting shown.',
                          child: Text(
                            '',
                            style: GoogleFonts.getFont(
                              'Inter',
                              color: FlutterFlowTheme.of(context).neutral900,
                              fontWeight: FontWeight.w500,
                              fontSize: 14.0,
                            ),
                          ),
                        ),
                      ),
                    ].divide(SizedBox(width: 12.0)),
                  ),
                ),
              ),
            ),
            Semantics(
              label:
                  'This container consists of the amount of the information which is getting shown.',
              child: Container(
                decoration: BoxDecoration(),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 9.0, 0.0, 9.0),
                  child: Semantics(
                    label:
                        'This is the amount of the information which is getting shown.',
                    child: Text(
                      '',
                      style: GoogleFonts.getFont(
                        'Inter',
                        color: Color(0x00000000),
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ].addToStart(SizedBox(width: 16.0)).addToEnd(SizedBox(width: 16.0)),
        ),
      ),
    );
  }
}
