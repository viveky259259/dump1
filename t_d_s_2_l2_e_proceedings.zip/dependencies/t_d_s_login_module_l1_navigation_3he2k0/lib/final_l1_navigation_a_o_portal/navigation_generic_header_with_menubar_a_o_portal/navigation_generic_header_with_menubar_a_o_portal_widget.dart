import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_header_with_menubar_a_o_portal_model.dart';
export 'navigation_generic_header_with_menubar_a_o_portal_model.dart';

class NavigationGenericHeaderWithMenubarAOPortalWidget extends StatefulWidget {
  const NavigationGenericHeaderWithMenubarAOPortalWidget({super.key});

  @override
  State<NavigationGenericHeaderWithMenubarAOPortalWidget> createState() =>
      _NavigationGenericHeaderWithMenubarAOPortalWidgetState();
}

class _NavigationGenericHeaderWithMenubarAOPortalWidgetState
    extends State<NavigationGenericHeaderWithMenubarAOPortalWidget> {
  late NavigationGenericHeaderWithMenubarAOPortalModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => NavigationGenericHeaderWithMenubarAOPortalModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
