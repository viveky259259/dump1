import '/final_l1_navigation_common/navigation_generic_hyper_link_button/navigation_generic_hyper_link_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'generic_header_a_o_portal_widget.dart' show GenericHeaderAOPortalWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericHeaderAOPortalModel
    extends FlutterFlowModel<GenericHeaderAOPortalWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for ScreenReader.
  late NavigationGenericHyperLinkButtonModel screenReaderModel;
  // State field(s) for LanguageDropDown widget.
  String? languageDropDownValue;
  FormFieldController<String>? languageDropDownValueController;

  @override
  void initState(BuildContext context) {
    screenReaderModel =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
  }

  @override
  void dispose() {
    screenReaderModel.dispose();
  }
}
