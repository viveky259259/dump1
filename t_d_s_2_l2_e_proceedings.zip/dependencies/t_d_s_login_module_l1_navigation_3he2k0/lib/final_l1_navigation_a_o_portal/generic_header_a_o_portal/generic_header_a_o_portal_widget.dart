import '/final_l1_navigation_common/navigation_generic_hyper_link_button/navigation_generic_hyper_link_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_header_a_o_portal_model.dart';
export 'generic_header_a_o_portal_model.dart';

/// This is Generic Header for AO designed for the following purposes listed
/// below.
///
///
/// It includes the following elements:
/// Income_Tax_Logo: Image
/// TDS logo: Image
/// Screen Reader Icon & Text: Accessibility feature or reading text aloud.
/// Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text
/// size.
/// Tonality( Theme Switcher Dark/Light Mode): Enables users to toggle between
/// dark and light themes for the application's interface depending on their
/// preference or lighting conditions.
/// Language Selector: Dropdown to switch between different languages(e.g.,
/// "English","Hindi")
///
/// Parameters:
/// onTap: Action
/// Define the action to be performed when the IconButton, Text  is tapped,
/// such as reading text aloud.
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
class GenericHeaderAOPortalWidget extends StatefulWidget {
  const GenericHeaderAOPortalWidget({
    super.key,
    required this.keyPrefix,
    required this.onTapScreenReader,
    required this.onTapFontDecrease,
    required this.onTapFontIncrease,
    required this.onTapFontIcon,
    required this.onTapTonality,
    required this.onLanguageDropDownSelection,
  });

  final String? keyPrefix;
  final Future Function()? onTapScreenReader;
  final Future Function()? onTapFontDecrease;
  final Future Function()? onTapFontIncrease;
  final Future Function()? onTapFontIcon;
  final Future Function()? onTapTonality;
  final Future Function()? onLanguageDropDownSelection;

  @override
  State<GenericHeaderAOPortalWidget> createState() =>
      _GenericHeaderAOPortalWidgetState();
}

class _GenericHeaderAOPortalWidgetState
    extends State<GenericHeaderAOPortalWidget> {
  late GenericHeaderAOPortalModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericHeaderAOPortalModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(48.0, 8.0, 48.0, 8.0),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Semantics(
                  label: 'Consists of Tds_Logo_1 and Tds_Logo_2 for header.',
                  child: Wrap(
                    spacing: 0.0,
                    runSpacing: 0.0,
                    alignment: WrapAlignment.start,
                    crossAxisAlignment: WrapCrossAlignment.start,
                    direction: Axis.horizontal,
                    runAlignment: WrapAlignment.start,
                    verticalDirection: VerticalDirection.down,
                    clipBehavior: Clip.none,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          ClipRRect(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Generic_Header_AO_Portal',
                                    'Income_Tax_Logo')),
                            borderRadius: BorderRadius.circular(0.0),
                            child: Image.asset(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'Income_Tax_Logo')),
                              'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/Income_Tax_Logo.png',
                              height: 64.0,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(
                            height: 56.0,
                            child: VerticalDivider(
                              thickness: 2.0,
                              color: Color(0xFFEAEBF4),
                            ),
                          ),
                          ClipRRect(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Generic_Header_AO_Portal', 'Tds_Logo')),
                            borderRadius: BorderRadius.circular(8.0),
                            child: Image.asset(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal', 'Tds_Logo')),
                              'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/Traces_logo.png',
                              width: 415.0,
                              height: 64.0,
                              fit: BoxFit.contain,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Wrap(
                  spacing: 5.0,
                  runSpacing: 0.0,
                  alignment: WrapAlignment.start,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  direction: Axis.horizontal,
                  runAlignment: WrapAlignment.start,
                  verticalDirection: VerticalDirection.down,
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      decoration: BoxDecoration(),
                      child: Semantics(
                        label:
                            'Screen Reader Icon & Text: Accessibility feature or reading text aloud.',
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'ScreenReaderIcon')),
                              FFIcons.ktextToSpeech,
                              color: FlutterFlowTheme.of(context)
                                  .primary600Default,
                              size: 20.0,
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  4.0, 0.0, 0.0, 0.0),
                              child: wrapWithModel(
                                model: _model.screenReaderModel,
                                updateCallback: () => safeSetState(() {}),
                                child: NavigationGenericHyperLinkButtonWidget(
                                  key: ValueKey(
                                      t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Generic_Header_AO_Portal',
                                              'ScreenReader')),
                                  labelText: 'Screen Reader',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL1KeyValue(
                                          widget!.keyPrefix!,
                                          'Generic_Header_AO_Portal',
                                          'ScreenReader'),
                                  labelTextColor: FlutterFlowTheme.of(context)
                                      .primary600Default,
                                  onTapAction: () async {
                                    await widget.onTapScreenReader?.call();
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(),
                      child: Semantics(
                        label:
                            'Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text size.',
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'TextDecreaseIcon')),
                              borderRadius: 8.0,
                              icon: Icon(
                                Icons.text_decrease,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 20.0,
                              ),
                              onPressed: () async {
                                await widget.onTapFontDecrease?.call();
                              },
                            ),
                            FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'FontIconButton')),
                              borderRadius: 8.0,
                              icon: Icon(
                                Icons.font_download,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 20.0,
                              ),
                              onPressed: () async {
                                await widget.onTapFontIcon?.call();
                              },
                            ),
                            FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'TextIncreaseIcon')),
                              borderRadius: 8.0,
                              icon: Icon(
                                Icons.text_increase,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 20.0,
                              ),
                              onPressed: () async {
                                await widget.onTapFontIncrease?.call();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Semantics(
                      label:
                          'Tonality( Theme Switcher Dark/Light Mode): Enables users to toggle between dark and light themes for the application\'s interface depending on their preference or lighting conditions.',
                      child: FlutterFlowIconButton(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_Header_AO_Portal',
                                'TonalityIconButton')),
                        borderRadius: 8.0,
                        icon: Icon(
                          Icons.tonality,
                          color: FlutterFlowTheme.of(context).primary600Default,
                          size: 20.0,
                        ),
                        onPressed: () async {
                          await widget.onTapTonality?.call();
                        },
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Container(
                      height: 40.0,
                      decoration: BoxDecoration(),
                      child: Semantics(
                        label:
                            'Language Selector: Dropdown to switch between different languages(e.g., \"English\",\"Hindi\")',
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'LanguageIcon')),
                              Icons.language,
                              color: FlutterFlowTheme.of(context)
                                  .primary600Default,
                              size: 20.0,
                            ),
                            FlutterFlowDropDown<String>(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_AO_Portal',
                                      'LanguageDropDown')),
                              controller:
                                  _model.languageDropDownValueController ??=
                                      FormFieldController<String>(
                                _model.languageDropDownValue ??= 'English',
                              ),
                              options: ['English', 'Hindi'],
                              onChanged: (val) async {
                                safeSetState(
                                    () => _model.languageDropDownValue = val);
                                await widget.onLanguageDropDownSelection
                                    ?.call();
                              },
                              width: 96.0,
                              height: 40.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                              hintText: 'Select',
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 24.0,
                              ),
                              elevation: 2.0,
                              borderColor: Colors.transparent,
                              borderWidth: 0.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 0.0, 12.0, 0.0),
                              hidesUnderline: true,
                              isOverButton: false,
                              isSearchable: false,
                              isMultiSelect: false,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
