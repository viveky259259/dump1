import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_back_button_model.dart';
export 'navigation_generic_back_button_model.dart';

/// A Back button component designed designed specifically for Form 15.
///
///
///
/// Parameters
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// onTapAction: Action
/// Define the action to be performed when the Back Button is tapped. It will
/// navigate to the different page.
/// isBtnDisable:Boolean
/// Disables the button
class NavigationGenericBackButtonWidget extends StatefulWidget {
  const NavigationGenericBackButtonWidget({
    super.key,
    required this.keyPrefix,
    required this.onTapAction,
  });

  final String? keyPrefix;
  final Future Function()? onTapAction;

  @override
  State<NavigationGenericBackButtonWidget> createState() =>
      _NavigationGenericBackButtonWidgetState();
}

class _NavigationGenericBackButtonWidgetState
    extends State<NavigationGenericBackButtonWidget> {
  late NavigationGenericBackButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NavigationGenericBackButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label:
          'A Back button component designed designed specifically for Form 15 to navigate back.',
      child: FFButtonWidget(
        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
            widget!.keyPrefix!, 'Navigation_Generic_Back_Button', 'Button')),
        onPressed: () async {
          await widget.onTapAction?.call();
        },
        text: 'Back',
        icon: Icon(
          Icons.arrow_back_ios_rounded,
          color: FlutterFlowTheme.of(context).buttonBackBorderText,
          size: 15.0,
        ),
        options: FFButtonOptions(
          height: 36.0,
          padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
          iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
          color: FlutterFlowTheme.of(context).neutral100,
          textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                fontFamily: 'Inter',
                color: FlutterFlowTheme.of(context).buttonBackBorderText,
                fontSize: 14.0,
                letterSpacing: 0.0,
                fontWeight: FontWeight.normal,
              ),
          elevation: 0.0,
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).buttonBackBorderText,
            width: 1.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
      ),
    );
  }
}
