import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_edit_button_model.dart';
export 'navigation_generic_edit_button_model.dart';

/// A Edit button component designed designed specifically for Form 15.
///
///
///
/// Parameters
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// onTapAction: Action
/// Define the action to be performed when the Back Button is tapped. It will
/// navigate to the different page.
class NavigationGenericEditButtonWidget extends StatefulWidget {
  const NavigationGenericEditButtonWidget({
    super.key,
    required this.keyPrefix,
    required this.onTapAction,
    this.labelText,
  });

  final String? keyPrefix;
  final Future Function()? onTapAction;
  final String? labelText;

  @override
  State<NavigationGenericEditButtonWidget> createState() =>
      _NavigationGenericEditButtonWidgetState();
}

class _NavigationGenericEditButtonWidgetState
    extends State<NavigationGenericEditButtonWidget> {
  late NavigationGenericEditButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NavigationGenericEditButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        await widget.onTapAction?.call();
      },
      child: Container(
        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
            widget!.keyPrefix!,
            'Navigation_Generic_Edit_Button',
            'Edit_Button_Container')),
        height: 40.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).neutral100,
          borderRadius: BorderRadius.circular(8.0),
          border: Border.all(
            color: FlutterFlowTheme.of(context).borderColor,
          ),
        ),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              FaIcon(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Navigation_Generic_Edit_Button',
                        'Icon')),
                FontAwesomeIcons.edit,
                color: FlutterFlowTheme.of(context).buttonBackBorderText,
                size: 20.0,
              ),
              Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Navigation_Generic_Edit_Button',
                        'Text')),
                valueOrDefault<String>(
                  widget!.labelText,
                  'Edit',
                ),
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      color: FlutterFlowTheme.of(context).neutral1200,
                      letterSpacing: 0.0,
                    ),
              ),
            ]
                .divide(SizedBox(width: 19.0))
                .addToStart(SizedBox(width: 8.0))
                .addToEnd(SizedBox(width: 12.0)),
          ),
        ),
      ),
    );
  }
}
