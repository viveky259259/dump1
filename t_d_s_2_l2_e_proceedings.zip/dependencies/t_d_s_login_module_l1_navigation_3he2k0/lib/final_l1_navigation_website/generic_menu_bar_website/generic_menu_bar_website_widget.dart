import '/backend/schema/structs/index.dart';
import '/components/hamburger_menu_mobile_widget.dart';
import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_menu_bar_website_model.dart';
export 'generic_menu_bar_website_model.dart';

/// This is a generic navigation bar which provides users with organized links
/// and options to navigate different sections and functionalities of the
/// website before logging in.
///
///
///
/// It includes the following elements:
///
/// Home: A button return to the main page.
///
/// About Us: A dropdown menu for viewing organization related details.
///
/// Contact Us: A dropdown menu for viewing organization contact details.
///
/// Things To Know: A dropdown menu for viewing the details which are
/// necessary to know about anything in the website.
///
/// Related Links: A dropdown menu for accessing the links which are related
/// to the website.
///
/// Downloads: A dropdown menu for downloading files or resources.
///
/// Search Button- It is used to allow users to search quickly for the
/// specific information or features on the website.
///
/// Parameters:
///
/// onTap: Action
/// Define the action to be performed on click of each button shown in the
/// navigation bar.
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
class GenericMenuBarWebsiteWidget extends StatefulWidget {
  const GenericMenuBarWebsiteWidget({
    super.key,
    this.onTap,
    required this.keyPrefix,
    this.menuItems,
    bool? isUserLoggedIn,
  }) : this.isUserLoggedIn = isUserLoggedIn ?? false;

  final Future Function()? onTap;
  final String? keyPrefix;
  final List<MenuItemStruct>? menuItems;
  final bool isUserLoggedIn;

  @override
  State<GenericMenuBarWebsiteWidget> createState() =>
      _GenericMenuBarWebsiteWidgetState();
}

class _GenericMenuBarWebsiteWidgetState
    extends State<GenericMenuBarWebsiteWidget> {
  late GenericMenuBarWebsiteModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericMenuBarWebsiteModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (responsiveVisibility(
          context: context,
          phone: false,
        ))
          Container(
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).primary700,
            ),
            child: Builder(
              builder: (context) {
                if (widget!.isUserLoggedIn) {
                  return Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 36.0,
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              48.0, 0.0, 0.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Semantics(
                                label:
                                    'Home: A button return to the main page.',
                                child: wrapWithModel(
                                  model: _model.homeButtonModel1,
                                  updateCallback: () => safeSetState(() {}),
                                  updateOnChange: true,
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website_PostLogin',
                                            'HomeButton')),
                                    title: 'Home',
                                    isIconVisible: false,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_WebsitePostLogin',
                                            'HomeButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'e-File & View: A dropdown menu for filling and viewing related options.',
                                child: wrapWithModel(
                                  model: _model.efileViewButtonModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website_PostLogin',
                                            'efileViewButton')),
                                    title: 'e-file & View',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_WebsitePostLogin',
                                            'e-fileViewButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    1.0, 0.0, 0.0, 0.0),
                                child: Semantics(
                                  label:
                                      'Services: A dropdown menu for accessing various services.',
                                  child: wrapWithModel(
                                    model: _model.servicesButtonModel,
                                    updateCallback: () => safeSetState(() {}),
                                    child: NavigationGenericMenuButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Generic_MenuBar_Website_PostLogin',
                                                  'ServicesButton')),
                                      title: 'Services',
                                      isIconVisible: true,
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Generic_MenuBar_WebsitePostLogin',
                                              'ServicesButton'),
                                      onTapAction: () async {
                                        await widget.onTap?.call();
                                      },
                                    ),
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'Pending Actions: A dropdown menu for the actions that are pending.',
                                child: wrapWithModel(
                                  model: _model.pendingActionsButtonModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website_PostLogin',
                                            'PendingActionsButton')),
                                    title: 'Pending Actions',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_WebsitePostLogin',
                                            'PendingActionsButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'Grievance: A button for grievance or complaint related features.',
                                child: wrapWithModel(
                                  model: _model.grievanceButtonModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website_PostLogin',
                                            'GrievanceButton')),
                                    title: 'Grievance',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_WebsitePostLogin',
                                            'GrievanceButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'Downloads: A dropdown menu for downloading files or resources.',
                                child: wrapWithModel(
                                  model: _model.downloadsButtonModel1,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website_PostLogin',
                                            'DownloadsButton')),
                                    title: 'Downloads',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_WebsitePostLogin',
                                            'DownloadsButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                            ].divide(SizedBox(width: 12.0)),
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 2.0, 48.0, 2.0),
                        child: Container(
                          width: 32.0,
                          height: 32.0,
                          decoration: BoxDecoration(),
                          child: Semantics(
                            label:
                                'Search Button- It is used to allow users to search quickly for the specific information or features on the website.',
                            child: FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_MenuBar_Website_PostLogin',
                                      'SearchButton')),
                              borderColor:
                                  FlutterFlowTheme.of(context).primary500,
                              borderRadius: 4.0,
                              borderWidth: 1.0,
                              buttonSize: 32.0,
                              fillColor: Colors.transparent,
                              icon: Icon(
                                Icons.search_sharp,
                                color: FlutterFlowTheme.of(context)
                                    .textAlternative,
                                size: 20.0,
                              ),
                              onPressed: () async {
                                await widget.onTap?.call();
                              },
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                } else {
                  return Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 36.0,
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              48.0, 0.0, 0.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Semantics(
                                label:
                                    'Home: A button return to the main page.',
                                child: wrapWithModel(
                                  model: _model.homeButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_MenuBar_Website',
                                                'HomeButton')),
                                    title: 'Home',
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website',
                                            'Navigation_Generic_MenuButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'A dropdown menu for viewing organization related details.',
                                child: wrapWithModel(
                                  model: _model.aboutUsButtonModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_MenuBar_Website',
                                                'AboutUsButton')),
                                    title: 'About Us',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website',
                                            'Navigation_Generic_MenuButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    1.0, 0.0, 0.0, 0.0),
                                child: Semantics(
                                  label:
                                      'A dropdown menu for viewing organization contact details.',
                                  child: wrapWithModel(
                                    model: _model.contactUsButtonModel,
                                    updateCallback: () => safeSetState(() {}),
                                    child: NavigationGenericMenuButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Generic_MenuBar_Website',
                                                  'ContactUsButton')),
                                      title: 'Contact Us',
                                      isIconVisible: true,
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Generic_MenuBar_Website',
                                              'Navigation_Generic_MenuButton'),
                                      onTapAction: () async {
                                        await widget.onTap?.call();
                                      },
                                    ),
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'A dropdown menu for viewing the details which are necessary to know about anything in the website.',
                                child: wrapWithModel(
                                  model: _model.thingsToKnowButtonModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_MenuBar_Website',
                                                'ThingsToKnowButton')),
                                    title: 'Things To Know',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website',
                                            'Navigation_Generic_MenuButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'A dropdown menu for accessing the links which are related to the website.',
                                child: wrapWithModel(
                                  model: _model.relatedLinksButtonModel,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_MenuBar_Website',
                                                'RelatedLinksButton')),
                                    title: 'Related Links',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website',
                                            'Navigation_Generic_MenuButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                              Semantics(
                                label:
                                    'Downloads: A dropdown menu for downloading files or resources.',
                                child: wrapWithModel(
                                  model: _model.downloadsButtonModel2,
                                  updateCallback: () => safeSetState(() {}),
                                  child: NavigationGenericMenuButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Generic_MenuBar_Website',
                                                'DownloadsButton')),
                                    title: 'Downloads',
                                    isIconVisible: true,
                                    keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                        .generateL1KeyValue(
                                            widget!.keyPrefix!,
                                            'Generic_MenuBar_Website',
                                            'Navigation_Generic_MenuButton'),
                                    onTapAction: () async {
                                      await widget.onTap?.call();
                                    },
                                  ),
                                ),
                              ),
                            ].divide(SizedBox(width: 12.0)),
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 2.0, 48.0, 2.0),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(0.0),
                          ),
                          child: Semantics(
                            label:
                                'Search Button- It is used to allow users to search quickly for the specific information or features on the website.',
                            child: FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_MenuBar_Website',
                                      'SearchButton')),
                              borderColor:
                                  FlutterFlowTheme.of(context).primary500,
                              borderRadius: 4.0,
                              borderWidth: 1.0,
                              buttonSize: 32.0,
                              fillColor: Colors.transparent,
                              icon: Icon(
                                Icons.search_sharp,
                                color: FlutterFlowTheme.of(context)
                                    .textAlternative,
                                size: 20.0,
                              ),
                              onPressed: () async {
                                await widget.onTap?.call();
                              },
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                }
              },
            ),
          ),
        if (responsiveVisibility(
          context: context,
          tablet: false,
          tabletLandscape: false,
          desktop: false,
        ))
          Container(
            height: 44.0,
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).primary700,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  decoration: BoxDecoration(),
                  child: Builder(
                    builder: (context) {
                      if (!_model.isIconTapped) {
                        return Builder(
                          builder: (context) => Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                19.0, 0.0, 0.0, 0.0),
                            child: FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_MenuBar_Website',
                                      'Menu_Icon_Button')),
                              borderRadius: 8.0,
                              buttonSize: 40.0,
                              icon: Icon(
                                Icons.menu,
                                color: FlutterFlowTheme.of(context)
                                    .textAlternative,
                                size: 24.0,
                              ),
                              onPressed: () async {
                                _model.isIconTapped = !_model.isIconTapped;
                                _model.activeLabel = 'Menu';
                                _model.updatePage(() {});
                                await showDialog(
                                  barrierColor: Colors.transparent,
                                  context: context,
                                  builder: (dialogContext) {
                                    return Dialog(
                                      elevation: 0,
                                      insetPadding: EdgeInsets.zero,
                                      backgroundColor: Colors.transparent,
                                      alignment: AlignmentDirectional(1.0, -1.0)
                                          .resolve(Directionality.of(context)),
                                      child: HamburgerMenuMobileWidget(
                                        keyPrefix: 'key',
                                        menu: widget!.menuItems!,
                                        onMenuOpen: (activeMenuLabel) async {
                                          _model.activeLabel = activeMenuLabel;
                                          _model.changeIconOnMenuTap =
                                              !_model.changeIconOnMenuTap;
                                          _model.updatePage(() {});
                                        },
                                        onMenuClose: () async {
                                          _model.activeLabel = ' ';
                                          _model.isIconTapped =
                                              !_model.isIconTapped;
                                          _model.updatePage(() {});
                                        },
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        );
                      } else {
                        return Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            if (_model.changeIconOnMenuTap)
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    19.0, 0.0, 0.0, 0.0),
                                child: FlutterFlowIconButton(
                                  borderRadius: 8.0,
                                  buttonSize: 30.0,
                                  icon: Icon(
                                    Icons.arrow_back_ios,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    size: 18.0,
                                  ),
                                  onPressed: () async {
                                    _model.changeIconOnMenuTap =
                                        !_model.changeIconOnMenuTap;
                                    _model.isIconTapped = false;
                                    safeSetState(() {});
                                  },
                                ),
                              ),
                            if (!_model.changeIconOnMenuTap)
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    19.0, 0.0, 0.0, 0.0),
                                child: FlutterFlowIconButton(
                                  key: ValueKey(
                                      t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Generic_MenuBar_Website',
                                              'IconButton')),
                                  borderRadius: 8.0,
                                  buttonSize: 40.0,
                                  icon: Icon(
                                    Icons.menu_open,
                                    color: FlutterFlowTheme.of(context)
                                        .textAlternative,
                                    size: 24.0,
                                  ),
                                  onPressed: () async {
                                    _model.isIconTapped = false;
                                    safeSetState(() {});
                                  },
                                ),
                              ),
                            Text(
                              _model.activeLabel,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textAlternative,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ],
                        );
                      }
                    },
                  ),
                ),
                if (!_model.isIconTapped)
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 16.0, 8.0),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(0.0),
                      ),
                      child: Semantics(
                        label:
                            'Search Button- It is used to allow users to search quickly for the specific information or features on the website.',
                        child: FlutterFlowIconButton(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Generic_MenuBar_Website', 'SearchButton')),
                          borderColor: FlutterFlowTheme.of(context).primary500,
                          borderRadius: 4.0,
                          borderWidth: 1.0,
                          buttonSize: 30.0,
                          fillColor: Colors.transparent,
                          icon: Icon(
                            Icons.search_sharp,
                            color: FlutterFlowTheme.of(context).textAlternative,
                            size: 14.0,
                          ),
                          onPressed: () async {
                            await widget.onTap?.call();
                          },
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
