import '/backend/schema/structs/index.dart';
import '/components/hamburger_menu_mobile_widget.dart';
import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'generic_menu_bar_website_widget.dart' show GenericMenuBarWebsiteWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericMenuBarWebsiteModel
    extends FlutterFlowModel<GenericMenuBarWebsiteWidget> {
  ///  Local state fields for this component.

  bool isIconTapped = false;

  String activeLabel = 'Menu';

  bool changeIconOnMenuTap = false;

  ///  State fields for stateful widgets in this component.

  // Model for HomeButton.
  late NavigationGenericMenuButtonModel homeButtonModel1;
  // Model for efileViewButton.
  late NavigationGenericMenuButtonModel efileViewButtonModel;
  // Model for ServicesButton.
  late NavigationGenericMenuButtonModel servicesButtonModel;
  // Model for PendingActionsButton.
  late NavigationGenericMenuButtonModel pendingActionsButtonModel;
  // Model for GrievanceButton.
  late NavigationGenericMenuButtonModel grievanceButtonModel;
  // Model for DownloadsButton.
  late NavigationGenericMenuButtonModel downloadsButtonModel1;
  // Model for HomeButton.
  late NavigationGenericMenuButtonModel homeButtonModel2;
  // Model for AboutUsButton.
  late NavigationGenericMenuButtonModel aboutUsButtonModel;
  // Model for ContactUsButton.
  late NavigationGenericMenuButtonModel contactUsButtonModel;
  // Model for ThingsToKnowButton.
  late NavigationGenericMenuButtonModel thingsToKnowButtonModel;
  // Model for RelatedLinksButton.
  late NavigationGenericMenuButtonModel relatedLinksButtonModel;
  // Model for DownloadsButton.
  late NavigationGenericMenuButtonModel downloadsButtonModel2;

  @override
  void initState(BuildContext context) {
    homeButtonModel1 =
        createModel(context, () => NavigationGenericMenuButtonModel());
    efileViewButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    servicesButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    pendingActionsButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    grievanceButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    downloadsButtonModel1 =
        createModel(context, () => NavigationGenericMenuButtonModel());
    homeButtonModel2 =
        createModel(context, () => NavigationGenericMenuButtonModel());
    aboutUsButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    contactUsButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    thingsToKnowButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    relatedLinksButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    downloadsButtonModel2 =
        createModel(context, () => NavigationGenericMenuButtonModel());
  }

  @override
  void dispose() {
    homeButtonModel1.dispose();
    efileViewButtonModel.dispose();
    servicesButtonModel.dispose();
    pendingActionsButtonModel.dispose();
    grievanceButtonModel.dispose();
    downloadsButtonModel1.dispose();
    homeButtonModel2.dispose();
    aboutUsButtonModel.dispose();
    contactUsButtonModel.dispose();
    thingsToKnowButtonModel.dispose();
    relatedLinksButtonModel.dispose();
    downloadsButtonModel2.dispose();
  }
}
