import '/final_l1_navigation_common/navigation_generic_hyper_link_button/navigation_generic_hyper_link_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'navigation_generic_footer_website_widget.dart'
    show NavigationGenericFooterWebsiteWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NavigationGenericFooterWebsiteModel
    extends FlutterFlowModel<NavigationGenericFooterWebsiteWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for AboutUs_Desc_Text.
  late NavigationGenericHyperLinkButtonModel aboutUsDescTextModel1;
  // Model for AboutUs_Desc_Text.
  late NavigationGenericHyperLinkButtonModel aboutUsDescTextModel2;
  // Model for AboutUs_Desc_Text.
  late NavigationGenericHyperLinkButtonModel aboutUsDescTextModel3;
  // Model for ContactUs_Desc_Text.
  late NavigationGenericHyperLinkButtonModel contactUsDescTextModel1;
  // Model for ContactUs_Desc_Text.
  late NavigationGenericHyperLinkButtonModel contactUsDescTextModel2;
  // Model for ContactUs_Desc_Text.
  late NavigationGenericHyperLinkButtonModel contactUsDescTextModel3;
  // Model for UsingThePortal_Desc_Text.
  late NavigationGenericHyperLinkButtonModel usingThePortalDescTextModel1;
  // Model for UsingThePortal_Desc_Text.
  late NavigationGenericHyperLinkButtonModel usingThePortalDescTextModel2;
  // Model for RelatedSites_Desc_Text.
  late NavigationGenericHyperLinkButtonModel relatedSitesDescTextModel1;
  // Model for RelatedSites_Desc_Text.
  late NavigationGenericHyperLinkButtonModel relatedSitesDescTextModel2;
  // Model for RelatedSites_Desc_Text.
  late NavigationGenericHyperLinkButtonModel relatedSitesDescTextModel3;
  // Model for RelatedSites_Desc_Text.
  late NavigationGenericHyperLinkButtonModel relatedSitesDescTextModel4;
  // Model for WebsitePolicies_Text.
  late NavigationGenericHyperLinkButtonModel websitePoliciesTextModel;
  // Model for Feedback_Text.
  late NavigationGenericHyperLinkButtonModel feedbackTextModel;
  // Model for Sitemap_Text.
  late NavigationGenericHyperLinkButtonModel sitemapTextModel;
  // Model for TermsConditions_Text.
  late NavigationGenericHyperLinkButtonModel termsConditionsTextModel;

  @override
  void initState(BuildContext context) {
    aboutUsDescTextModel1 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    aboutUsDescTextModel2 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    aboutUsDescTextModel3 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    contactUsDescTextModel1 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    contactUsDescTextModel2 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    contactUsDescTextModel3 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    usingThePortalDescTextModel1 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    usingThePortalDescTextModel2 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    relatedSitesDescTextModel1 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    relatedSitesDescTextModel2 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    relatedSitesDescTextModel3 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    relatedSitesDescTextModel4 =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    websitePoliciesTextModel =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    feedbackTextModel =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    sitemapTextModel =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    termsConditionsTextModel =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
  }

  @override
  void dispose() {
    aboutUsDescTextModel1.dispose();
    aboutUsDescTextModel2.dispose();
    aboutUsDescTextModel3.dispose();
    contactUsDescTextModel1.dispose();
    contactUsDescTextModel2.dispose();
    contactUsDescTextModel3.dispose();
    usingThePortalDescTextModel1.dispose();
    usingThePortalDescTextModel2.dispose();
    relatedSitesDescTextModel1.dispose();
    relatedSitesDescTextModel2.dispose();
    relatedSitesDescTextModel3.dispose();
    relatedSitesDescTextModel4.dispose();
    websitePoliciesTextModel.dispose();
    feedbackTextModel.dispose();
    sitemapTextModel.dispose();
    termsConditionsTextModel.dispose();
  }
}
