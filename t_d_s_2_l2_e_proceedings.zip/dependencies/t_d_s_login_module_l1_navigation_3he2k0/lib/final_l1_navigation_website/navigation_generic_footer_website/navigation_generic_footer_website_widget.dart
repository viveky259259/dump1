import '/final_l1_navigation_common/navigation_generic_hyper_link_button/navigation_generic_hyper_link_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_footer_website_model.dart';
export 'navigation_generic_footer_website_model.dart';

class NavigationGenericFooterWebsiteWidget extends StatefulWidget {
  const NavigationGenericFooterWebsiteWidget({
    super.key,
    this.date,
    required this.keyPrefix,
    required this.onTapAction,
  });

  final DateTime? date;
  final String? keyPrefix;
  final Future Function()? onTapAction;

  @override
  State<NavigationGenericFooterWebsiteWidget> createState() =>
      _NavigationGenericFooterWebsiteWidgetState();
}

class _NavigationGenericFooterWebsiteWidgetState
    extends State<NavigationGenericFooterWebsiteWidget> {
  late NavigationGenericFooterWebsiteModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NavigationGenericFooterWebsiteModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 344.0,
      decoration: BoxDecoration(
        color: Color(0xFF202C6B),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 1366.0,
            height: 246.0,
            decoration: BoxDecoration(
              color: Color(0xFF202C6B),
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(48.0, 24.0, 48.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 320.0,
                    decoration: BoxDecoration(),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 320.0,
                          decoration: BoxDecoration(),
                          child: Semantics(
                            label: 'This is image of Government Of India Logo.',
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(0.0),
                              child: Image.asset(
                                'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/GovLogo.jpg',
                                height: 64.0,
                                fit: BoxFit.contain,
                                alignment: Alignment(-1.0, 0.0),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          width: 320.0,
                          decoration: BoxDecoration(),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Follow Us On:',
                                style: FlutterFlowTheme.of(context)
                                    .bodyLarge
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                              Container(
                                decoration: BoxDecoration(),
                                child: Semantics(
                                  label:
                                      'Social Media Links: Logos with social media links (Facebook, Instagram, X, YouTube, LinkedIn) are given here.',
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      FlutterFlowIconButton(
                                        borderRadius: 0.0,
                                        buttonSize: 40.0,
                                        icon: Icon(
                                          Icons.facebook,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral100,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onTapAction?.call();
                                        },
                                      ),
                                      FlutterFlowIconButton(
                                        borderColor: Colors.transparent,
                                        borderRadius: 0.0,
                                        buttonSize: 40.0,
                                        icon: FaIcon(
                                          FontAwesomeIcons.instagram,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral100,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onTapAction?.call();
                                        },
                                      ),
                                      FlutterFlowIconButton(
                                        borderColor: Colors.transparent,
                                        borderRadius: 0.0,
                                        buttonSize: 40.0,
                                        icon: FaIcon(
                                          FontAwesomeIcons.twitter,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral100,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onTapAction?.call();
                                        },
                                      ),
                                      FlutterFlowIconButton(
                                        borderColor: Colors.transparent,
                                        borderRadius: 0.0,
                                        buttonSize: 40.0,
                                        icon: FaIcon(
                                          FontAwesomeIcons.youtube,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral100,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onTapAction?.call();
                                        },
                                      ),
                                      FlutterFlowIconButton(
                                        borderColor: Colors.transparent,
                                        borderRadius: 0.0,
                                        buttonSize: 40.0,
                                        icon: FaIcon(
                                          FontAwesomeIcons.linkedin,
                                          color: FlutterFlowTheme.of(context)
                                              .neutral100,
                                          size: 24.0,
                                        ),
                                        onPressed: () async {
                                          await widget.onTapAction?.call();
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ].divide(SizedBox(height: 16.0)),
                          ),
                        ),
                        Semantics(
                          label:
                              'Website Updation Date: The date on which the website is last reviewed & updated is shown here.',
                          child: Container(
                            width: 320.0,
                            decoration: BoxDecoration(),
                            child: RichText(
                              textScaler: MediaQuery.of(context).textScaler,
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Last reviewed and updated on : ',
                                    style: FlutterFlowTheme.of(context)
                                        .bodySmall
                                        .override(
                                          fontFamily: 'Inter',
                                          color: Color(0xFFDFE0E2),
                                          letterSpacing: 0.0,
                                          fontStyle: FontStyle.italic,
                                        ),
                                  ),
                                  TextSpan(
                                    text: valueOrDefault<String>(
                                      widget!.date?.toString(),
                                      '23-Oct-2024',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodySmall
                                        .override(
                                          fontFamily: 'Inter',
                                          color: Color(0xFFDFE0E2),
                                          letterSpacing: 0.0,
                                          fontStyle: FontStyle.italic,
                                        ),
                                  )
                                ],
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ].divide(SizedBox(height: 24.0)),
                    ),
                  ),
                  Container(
                    width: 886.0,
                    decoration: BoxDecoration(),
                    child: Semantics(
                      label:
                          'All the necessary hyperlinks related to this website are given here.',
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 185.5,
                            decoration: BoxDecoration(),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'About Us',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textAlternative,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16.0,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      wrapWithModel(
                                        model: _model.aboutUsDescTextModel1,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'AboutUs_Desc_Text')),
                                          labelText: 'About the Portal',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'AboutUs_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model: _model.aboutUsDescTextModel2,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'AboutUs_Desc_Text')),
                                          labelText: 'Right to Information',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'AboutUs_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model: _model.aboutUsDescTextModel3,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'AboutUs_Desc_Text')),
                                          labelText:
                                              'Organization and Functions',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'AboutUs_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 12.0)),
                                  ),
                                ),
                              ].divide(SizedBox(height: 24.0)),
                            ),
                          ),
                          Container(
                            width: 185.5,
                            decoration: BoxDecoration(),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Contact Us',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textAlternative,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16.0,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      wrapWithModel(
                                        model: _model.contactUsDescTextModel1,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'ContactUs_Desc_Text')),
                                          labelText: 'Helpdesk Numbers',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'ContactUs_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model: _model.contactUsDescTextModel2,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'ContactUs_Desc_Text')),
                                          labelText: 'Grievances',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'ContactUs_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model: _model.contactUsDescTextModel3,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'ContactUs_Desc_Text')),
                                          labelText: 'Help',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'ContactUs_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 12.0)),
                                  ),
                                ),
                              ].divide(SizedBox(height: 24.0)),
                            ),
                          ),
                          Container(
                            width: 185.5,
                            decoration: BoxDecoration(),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Using the Portal',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textAlternative,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16.0,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      wrapWithModel(
                                        model:
                                            _model.usingThePortalDescTextModel1,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'UsingThePortal_Desc_Text')),
                                          labelText: 'Accessibility Statement',
                                          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Navigation_Generic_Footer_Website',
                                                  'UsingThePortal_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model:
                                            _model.usingThePortalDescTextModel2,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'UsingThePortal_Desc_Text')),
                                          labelText: 'Browser Support',
                                          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Navigation_Generic_Footer_Website',
                                                  'UsingThePortal_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 12.0)),
                                  ),
                                ),
                              ].divide(SizedBox(height: 24.0)),
                            ),
                          ),
                          Container(
                            width: 185.5,
                            decoration: BoxDecoration(),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Related Sites',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textAlternative,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16.0,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      wrapWithModel(
                                        model:
                                            _model.relatedSitesDescTextModel1,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text')),
                                          labelText: 'National Portal of India',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model:
                                            _model.relatedSitesDescTextModel2,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text')),
                                          labelText: 'e-Filing',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model:
                                            _model.relatedSitesDescTextModel3,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text')),
                                          labelText: 'Income Tax India',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                      wrapWithModel(
                                        model:
                                            _model.relatedSitesDescTextModel4,
                                        updateCallback: () =>
                                            safeSetState(() {}),
                                        child:
                                            NavigationGenericHyperLinkButtonWidget(
                                          key: ValueKey(
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text')),
                                          labelText:
                                              'Protean (previously NSDL)',
                                          keyPrefix:
                                              t_d_s_2_l1_logic_2wrus1_functions
                                                  .generateL1KeyValue(
                                                      widget!.keyPrefix!,
                                                      'Navigation_Generic_Footer_Website',
                                                      'RelatedSites_Desc_Text'),
                                          labelTextColor:
                                              FlutterFlowTheme.of(context)
                                                  .neutral300,
                                          onTapAction: () async {},
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 12.0)),
                                  ),
                                ),
                              ].divide(SizedBox(height: 24.0)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Divider(
            thickness: 1.0,
            color: Color(0xFF505DA2),
          ),
          Container(
            width: 1366.0,
            height: 82.0,
            decoration: BoxDecoration(
              color: Color(0xFF202C6B),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(48.0, 0.0, 0.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(),
                    child: Semantics(
                      label:
                          'Some of the necessary hyperlinks related to this website are given here.',
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          wrapWithModel(
                            model: _model.websitePoliciesTextModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericHyperLinkButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'WebsitePolicies_Text')),
                              labelText: 'Website Policies',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'WebsitePolicies_Text'),
                              labelTextColor:
                                  FlutterFlowTheme.of(context).textAlternative,
                              onTapAction: () async {},
                            ),
                          ),
                          SizedBox(
                            height: 20.0,
                            child: VerticalDivider(
                              thickness: 1.0,
                              color: Color(0xFFDFE0E2),
                            ),
                          ),
                          wrapWithModel(
                            model: _model.feedbackTextModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericHyperLinkButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'Feedback_Text')),
                              labelText: 'Feedback',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'Feedback_Text'),
                              labelTextColor:
                                  FlutterFlowTheme.of(context).textAlternative,
                              onTapAction: () async {},
                            ),
                          ),
                          SizedBox(
                            height: 20.0,
                            child: VerticalDivider(
                              thickness: 1.0,
                              color: Color(0xFFDFE0E2),
                            ),
                          ),
                          wrapWithModel(
                            model: _model.sitemapTextModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericHyperLinkButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'Sitemap_Text')),
                              labelText: 'Sitemap',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'Sitemap_Text'),
                              labelTextColor:
                                  FlutterFlowTheme.of(context).textAlternative,
                              onTapAction: () async {},
                            ),
                          ),
                          SizedBox(
                            height: 20.0,
                            child: VerticalDivider(
                              thickness: 1.0,
                              color: Color(0xFFDFE0E2),
                            ),
                          ),
                          wrapWithModel(
                            model: _model.termsConditionsTextModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericHyperLinkButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'TermsConditions_Text')),
                              labelText: 'Terms & Conditions',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Navigation_Generic_Footer_Website',
                                      'TermsConditions_Text'),
                              labelTextColor:
                                  FlutterFlowTheme.of(context).textAlternative,
                              onTapAction: () async {},
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 48.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'This site is best viewed in 1366x768 resolution with latest version of Chrome, Firefox, Safari & Microsoft Edge',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textAlternative,
                            fontWeight: FontWeight.w500,
                            fontSize: 14.0,
                          ),
                        ),
                        Text(
                          '© 2016 - Copyright Income Tax Department, Ministry of Finance, Government of India. All Rights Reserved.',
                          style: GoogleFonts.getFont(
                            'Inter',
                            color: FlutterFlowTheme.of(context).textAlternative,
                            fontWeight: FontWeight.w500,
                            fontSize: 14.0,
                          ),
                        ),
                      ].divide(SizedBox(height: 8.0)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
