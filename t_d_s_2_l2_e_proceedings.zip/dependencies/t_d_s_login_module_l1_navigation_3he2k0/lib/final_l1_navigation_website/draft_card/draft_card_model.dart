import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'draft_card_widget.dart' show DraftCardWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DraftCardModel extends FlutterFlowModel<DraftCardWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Resume_Button_Mobile.
  late NavigationGenericPrimaryButtonModel resumeButtonMobileModel;
  // Model for Draft_Delete_Button_Mobile.
  late NavigationGenericSecondaryButtonModel draftDeleteButtonMobileModel;
  // Model for Delete_Button_Website.
  late NavigationGenericSecondaryButtonModel deleteButtonWebsiteModel;
  // Model for Resume_Button_Website.
  late NavigationGenericPrimaryButtonModel resumeButtonWebsiteModel;

  @override
  void initState(BuildContext context) {
    resumeButtonMobileModel =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    draftDeleteButtonMobileModel =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
    deleteButtonWebsiteModel =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
    resumeButtonWebsiteModel =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    resumeButtonMobileModel.dispose();
    draftDeleteButtonMobileModel.dispose();
    deleteButtonWebsiteModel.dispose();
    resumeButtonWebsiteModel.dispose();
  }
}
