import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'draft_card_model.dart';
export 'draft_card_model.dart';

class DraftCardWidget extends StatefulWidget {
  const DraftCardWidget({
    super.key,
    required this.keyPrefix,
    required this.title,
    required this.descriptionText,
    required this.financialYear,
    required this.pan,
    required this.lastModified,
    required this.time,
    required this.onTapDeleteAction,
    required this.onTapResumeAction,
  });

  final String? keyPrefix;
  final String? title;
  final String? descriptionText;
  final String? financialYear;
  final String? pan;
  final String? lastModified;
  final String? time;
  final Future Function()? onTapDeleteAction;
  final Future Function()? onTapResumeAction;

  @override
  State<DraftCardWidget> createState() => _DraftCardWidgetState();
}

class _DraftCardWidgetState extends State<DraftCardWidget> {
  late DraftCardModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DraftCardModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(25.0, 25.0, 25.0, 25.0),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Draft_Card',
                              'Heading_Text')),
                      valueOrDefault<String>(
                        widget!.title,
                        'Title',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color: FlutterFlowTheme.of(context).textBasic,
                            fontSize: 16.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    Text(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Draft_Card',
                              'Description_Text')),
                      valueOrDefault<String>(
                        widget!.descriptionText,
                        'description',
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color: FlutterFlowTheme.of(context).neutral900,
                            fontSize: 12.0,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.normal,
                          ),
                    ),
                    if (responsiveVisibility(
                      context: context,
                      phone: false,
                    ))
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            'F.Y. ${widget!.financialYear}',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                          Text(
                            'PAN: ${widget!.pan}',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                          Text(
                            'Last Modified: ${widget!.lastModified}',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                          Text(
                            'Time: ${widget!.time}',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ].divide(SizedBox(width: 40.0)),
                      ),
                    if (responsiveVisibility(
                      context: context,
                      tablet: false,
                      tabletLandscape: false,
                      desktop: false,
                    ))
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Expanded(
                                child: Container(
                                  decoration: BoxDecoration(),
                                  child: Text(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Draft_Card',
                                                'FY_Text')),
                                    'F.Y. ${widget!.financialYear}',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  decoration: BoxDecoration(),
                                  child: Text(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Draft_Card',
                                                'Pan_Text')),
                                    'PAN: ${widget!.pan}',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Expanded(
                                child: Container(
                                  decoration: BoxDecoration(),
                                  child: Text(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Draft_Card',
                                                'Last_Modified_Text')),
                                    'Last Modified: ${widget!.lastModified}',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  decoration: BoxDecoration(),
                                  child: Text(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Draft_Card',
                                                'Time_Text')),
                                    'Time: ${widget!.time}',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          fontSize: 12.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    if (responsiveVisibility(
                      context: context,
                      tablet: false,
                      tabletLandscape: false,
                      desktop: false,
                    ))
                      Container(
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context)
                              .secondaryInfoBGStroke2,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  wrapWithModel(
                                    model: _model.resumeButtonMobileModel,
                                    updateCallback: () => safeSetState(() {}),
                                    child: NavigationGenericPrimaryButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Draft_Card',
                                                  'Resume_Button_Mobile')),
                                      labeltext: 'Resume',
                                      keyPrefix:
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Draft_Card',
                                                  'Resume_Button_Mobile'),
                                      width: MediaQuery.sizeOf(context).width,
                                      states: ButtonState.byDefault,
                                      onTap: () async {
                                        await widget.onTapResumeAction?.call();
                                      },
                                    ),
                                  ),
                                  wrapWithModel(
                                    model: _model.draftDeleteButtonMobileModel,
                                    updateCallback: () => safeSetState(() {}),
                                    child:
                                        NavigationGenericSecondaryButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Draft_Card',
                                                  'Draft_Delete_Button_Mobile')),
                                      labelText: 'Delete Draft',
                                      keyPrefix:
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Draft_Card',
                                                  'Draft_Delete_Button_Mobile'),
                                      width: MediaQuery.sizeOf(context).width,
                                      states: ButtonState.byDefault,
                                      onTap: () async {
                                        await widget.onTapDeleteAction?.call();
                                      },
                                    ),
                                  ),
                                ].divide(SizedBox(height: 10.0)),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ].divide(SizedBox(height: 8.0)),
                ),
              ),
            ),
            if (responsiveVisibility(
              context: context,
              phone: false,
            ))
              Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    wrapWithModel(
                      model: _model.deleteButtonWebsiteModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericSecondaryButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Draft_Card', 'Delete_Button_Website')),
                        labelText: 'Delete Draft',
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Draft_Card', 'Delete_Button_Website'),
                        states: ButtonState.byDefault,
                        onTap: () async {
                          await widget.onTapDeleteAction?.call();
                        },
                      ),
                    ),
                    wrapWithModel(
                      model: _model.resumeButtonWebsiteModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericPrimaryButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Draft_Card', 'Resume_Button_Website')),
                        labeltext: 'Resume',
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Draft_Card', 'Resume_Button_Website'),
                        states: ButtonState.byDefault,
                        onTap: () async {
                          await widget.onTapResumeAction?.call();
                        },
                      ),
                    ),
                  ].divide(SizedBox(width: 20.0)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
