import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'stepper_with_sub_steps_model.dart';
export 'stepper_with_sub_steps_model.dart';

class StepperWithSubStepsWidget extends StatefulWidget {
  const StepperWithSubStepsWidget({
    super.key,
    this.stepperHeading,
    this.currentStep,
    required this.keyPrefix,
    bool? showVerticalLine,
    bool? hideTrailingIcon,
    bool? showHeading,
    this.stepperWithSubStepperListParam,
    this.currentSubStep,
  })  : this.showVerticalLine = showVerticalLine ?? true,
        this.hideTrailingIcon = hideTrailingIcon ?? false,
        this.showHeading = showHeading ?? false;

  final String? stepperHeading;
  final int? currentStep;
  final String? keyPrefix;
  final bool showVerticalLine;
  final bool hideTrailingIcon;
  final bool showHeading;
  final List<StepperWithSubStepperListStruct>? stepperWithSubStepperListParam;
  final int? currentSubStep;

  @override
  State<StepperWithSubStepsWidget> createState() =>
      _StepperWithSubStepsWidgetState();
}

class _StepperWithSubStepsWidgetState extends State<StepperWithSubStepsWidget> {
  late StepperWithSubStepsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => StepperWithSubStepsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget!.showHeading)
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 16.0),
                  child: Container(
                    decoration: BoxDecoration(),
                    child: Visibility(
                      visible: widget!.showHeading,
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            48.0, 0.0, 48.0, 0.0),
                        child: Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Stepper_With_Sub_Steps', 'stepperHeading')),
                          valueOrDefault<String>(
                            widget!.stepperHeading,
                            'stepperHeading',
                          ),
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textPrimary,
                                fontSize: 18.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          Divider(
            thickness: 2.0,
            color: FlutterFlowTheme.of(context).neutral300,
          ),
          Container(
            decoration: BoxDecoration(),
            child: Builder(
              builder: (context) {
                final stepperWithSubStepperListDynChil =
                    widget!.stepperWithSubStepperListParam?.toList() ?? [];

                return Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:
                      List.generate(stepperWithSubStepperListDynChil.length,
                          (stepperWithSubStepperListDynChilIndex) {
                    final stepperWithSubStepperListDynChilItem =
                        stepperWithSubStepperListDynChil[
                            stepperWithSubStepperListDynChilIndex];
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 4.0, 0.0, 4.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: () {
                                if (widget!.currentStep! >
                                    (stepperWithSubStepperListDynChilIndex +
                                        1)) {
                                  return Colors.transparent;
                                } else if (widget!.currentStep ==
                                    (stepperWithSubStepperListDynChilIndex)) {
                                  return FlutterFlowTheme.of(context)
                                      .secondaryInfoBGStroke10;
                                } else {
                                  return Colors.transparent;
                                }
                              }(),
                            ),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  48.0, 14.0, 12.0, 14.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        if (widget!.currentStep ==
                                            stepperWithSubStepperListDynChilIndex)
                                          Container(
                                            width: 20.0,
                                            height: 20.0,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: widget!.currentStep ==
                                                        stepperWithSubStepperListDynChilIndex
                                                    ? FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryInfo500Default
                                                    : Color(0x00000000),
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Container(
                                                  width: 3.0,
                                                  height: 3.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryInfo500Default,
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                                Container(
                                                  width: 3.0,
                                                  height: 3.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryInfo500Default,
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                              ].divide(SizedBox(width: 4.0)),
                                            ),
                                          ),
                                        if (widget!.currentStep! >
                                            stepperWithSubStepperListDynChilIndex)
                                          Container(
                                            width: 20.0,
                                            height: 20.0,
                                            decoration: BoxDecoration(
                                              color: () {
                                                if (widget!.currentStep! >
                                                    stepperWithSubStepperListDynChilIndex) {
                                                  return FlutterFlowTheme.of(
                                                          context)
                                                      .success200;
                                                } else if (widget!
                                                        .currentStep ==
                                                    stepperWithSubStepperListDynChilIndex) {
                                                  return FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryInfo500Default;
                                                } else {
                                                  return Color(0x00000000);
                                                }
                                              }(),
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: () {
                                                  if (widget!.currentStep ==
                                                      stepperWithSubStepperListDynChilIndex) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryInfo500Default;
                                                  } else if (widget!
                                                          .currentStep! >
                                                      stepperWithSubStepperListDynChilIndex) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .success700;
                                                  } else {
                                                    return Color(0x00000000);
                                                  }
                                                }(),
                                              ),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: FaIcon(
                                                key: ValueKey(
                                                    t_d_s_2_l1_logic_2wrus1_functions
                                                        .generateL1KeyValue(
                                                            widget!.keyPrefix!,
                                                            'Stepper_With_Sub_Steps',
                                                            'DoneIcon_${stepperWithSubStepperListDynChilIndex.toString()}')),
                                                FontAwesomeIcons.check,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .success700,
                                                size: 10.0,
                                              ),
                                            ),
                                          ),
                                        if (widget!.currentStep! <
                                            stepperWithSubStepperListDynChilIndex)
                                          Container(
                                            width: 20.0,
                                            height: 20.0,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: () {
                                                  if (widget!.currentStep ==
                                                      stepperWithSubStepperListDynChilIndex) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .primary600Default;
                                                  } else if (widget!
                                                          .currentStep! >
                                                      stepperWithSubStepperListDynChilIndex) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .success700;
                                                  } else {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .neutral700;
                                                  }
                                                }(),
                                              ),
                                            ),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                (stepperWithSubStepperListDynChilIndex +
                                                        1)
                                                    .toString(),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color: () {
                                                            if (widget!
                                                                    .currentStep ==
                                                                stepperWithSubStepperListDynChilIndex) {
                                                              return FlutterFlowTheme
                                                                      .of(context)
                                                                  .primary600Default;
                                                            } else if (widget!
                                                                    .currentStep! >
                                                                stepperWithSubStepperListDynChilIndex) {
                                                              return FlutterFlowTheme
                                                                      .of(context)
                                                                  .success700;
                                                            } else {
                                                              return FlutterFlowTheme
                                                                      .of(context)
                                                                  .neutral700;
                                                            }
                                                          }(),
                                                          fontSize: 10.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  8.0, 0.0, 0.0, 0.0),
                                          child: Text(
                                            stepperWithSubStepperListDynChilItem
                                                .heading,
                                            textAlign: TextAlign.start,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: () {
                                                    if (widget!.currentStep ==
                                                        stepperWithSubStepperListDynChilIndex) {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryInfo500Default;
                                                    } else if (widget!
                                                            .currentStep! >
                                                        stepperWithSubStepperListDynChilIndex) {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .success700;
                                                    } else {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .neutral900;
                                                    }
                                                  }(),
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if ((widget!.currentStep ==
                                          stepperWithSubStepperListDynChilIndex) &&
                                      !widget!.hideTrailingIcon &&
                                      (stepperWithSubStepperListDynChilItem
                                          .subHeadingList.isNotEmpty))
                                    InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        _model.showSubHeadingList =
                                            !(_model.showSubHeadingList ??
                                                true);
                                        safeSetState(() {});
                                      },
                                      child: Icon(
                                        key: ValueKey(
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL1KeyValue(
                                                    widget!.keyPrefix!,
                                                    'Stepper_With_Sub_Steps',
                                                    'ArrowIcon_${stepperWithSubStepperListDynChilIndex.toString()}')),
                                        Icons.arrow_forward_ios,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryInfo500Default,
                                        size: 10.0,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        if (_model.showSubHeadingList ?? true)
                          Container(
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).neutral100,
                            ),
                            child: Visibility(
                              visible: stepperWithSubStepperListDynChilIndex ==
                                  widget!.currentStep,
                              child: Builder(
                                builder: (context) {
                                  final subHeadingListCurrIndDynChil =
                                      stepperWithSubStepperListDynChilItem
                                          .subHeadingList
                                          .toList();

                                  return Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: List.generate(
                                        subHeadingListCurrIndDynChil.length,
                                        (subHeadingListCurrIndDynChilIndex) {
                                      final subHeadingListCurrIndDynChilItem =
                                          subHeadingListCurrIndDynChil[
                                              subHeadingListCurrIndDynChilIndex];
                                      return Container(
                                        decoration: BoxDecoration(),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      52.0, 12.0, 12.0, 12.0),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Container(
                                                    decoration: BoxDecoration(),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Container(
                                                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                                              .generateL1KeyValue(
                                                                  widget!
                                                                      .keyPrefix!,
                                                                  'Stepper_With_Sub_Steps',
                                                                  'SubHeadingIcon_${subHeadingListCurrIndDynChilIndex.toString()}')),
                                                          width: 12.0,
                                                          height: 12.0,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: () {
                                                              if (widget!
                                                                      .currentSubStep! >
                                                                  subHeadingListCurrIndDynChilIndex) {
                                                                return FlutterFlowTheme.of(
                                                                        context)
                                                                    .success300;
                                                              } else if (widget!
                                                                      .currentSubStep ==
                                                                  subHeadingListCurrIndDynChilIndex) {
                                                                return FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryInfoBGStroke10;
                                                              } else {
                                                                return FlutterFlowTheme.of(
                                                                        context)
                                                                    .neutral100;
                                                              }
                                                            }(),
                                                            shape:
                                                                BoxShape.circle,
                                                            border: Border.all(
                                                              color: () {
                                                                if (widget!
                                                                        .currentSubStep! >
                                                                    subHeadingListCurrIndDynChilIndex) {
                                                                  return FlutterFlowTheme.of(
                                                                          context)
                                                                      .success500Default;
                                                                } else if (widget!
                                                                        .currentSubStep ==
                                                                    subHeadingListCurrIndDynChilIndex) {
                                                                  return FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryInfo500Default;
                                                                } else {
                                                                  return FlutterFlowTheme.of(
                                                                          context)
                                                                      .neutral700;
                                                                }
                                                              }(),
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      8.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            stepperWithSubStepperListDynChilItem
                                                                .heading,
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Inter',
                                                                  color: () {
                                                                    if (widget!
                                                                            .currentSubStep ==
                                                                        subHeadingListCurrIndDynChilIndex) {
                                                                      return FlutterFlowTheme.of(
                                                                              context)
                                                                          .secondaryInfo500Default;
                                                                    } else if (widget!
                                                                            .currentSubStep! >
                                                                        subHeadingListCurrIndDynChilIndex) {
                                                                      return FlutterFlowTheme.of(
                                                                              context)
                                                                          .success700;
                                                                    } else {
                                                                      return FlutterFlowTheme.of(
                                                                              context)
                                                                          .neutral900;
                                                                    }
                                                                  }(),
                                                                  fontSize:
                                                                      12.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            if (subHeadingListCurrIndDynChilIndex <
                                                (stepperWithSubStepperListDynChilItem
                                                        .subHeadingList.length -
                                                    1))
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        57.0, 0.0, 0.0, 0.0),
                                                child: Container(
                                                  width: 1.0,
                                                  height: 12.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .neutral400,
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      );
                                    }),
                                  );
                                },
                              ),
                            ),
                          ),
                        if (stepperWithSubStepperListDynChilIndex <
                            (widget!.stepperWithSubStepperListParam!.length -
                                1))
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                57.0, 4.0, 0.0, 0.0),
                            child: Container(
                              width: 1.0,
                              height: 12.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).neutral400,
                              ),
                            ),
                          ),
                      ],
                    );
                  }),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
