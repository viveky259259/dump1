import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'generic_menu_bar_website_post_login_widget.dart'
    show GenericMenuBarWebsitePostLoginWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericMenuBarWebsitePostLoginModel
    extends FlutterFlowModel<GenericMenuBarWebsitePostLoginWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for HomeButton.
  late NavigationGenericMenuButtonModel homeButtonModel;
  // Model for efileViewButton.
  late NavigationGenericMenuButtonModel efileViewButtonModel;
  // Model for ServicesButton.
  late NavigationGenericMenuButtonModel servicesButtonModel;
  // Model for PendingActionsButton.
  late NavigationGenericMenuButtonModel pendingActionsButtonModel;
  // Model for GrievanceButton.
  late NavigationGenericMenuButtonModel grievanceButtonModel;
  // Model for DownloadsButton.
  late NavigationGenericMenuButtonModel downloadsButtonModel;

  @override
  void initState(BuildContext context) {
    homeButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    efileViewButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    servicesButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    pendingActionsButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    grievanceButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
    downloadsButtonModel =
        createModel(context, () => NavigationGenericMenuButtonModel());
  }

  @override
  void dispose() {
    homeButtonModel.dispose();
    efileViewButtonModel.dispose();
    servicesButtonModel.dispose();
    pendingActionsButtonModel.dispose();
    grievanceButtonModel.dispose();
    downloadsButtonModel.dispose();
  }
}
