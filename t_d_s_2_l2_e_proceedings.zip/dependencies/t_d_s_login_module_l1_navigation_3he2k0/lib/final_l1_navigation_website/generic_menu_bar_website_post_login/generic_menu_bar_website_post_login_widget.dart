import '/final_l1_navigation_common/navigation_generic_menu_button/navigation_generic_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_menu_bar_website_post_login_model.dart';
export 'generic_menu_bar_website_post_login_model.dart';

/// This is a generic navigation bar which provides users with organized links
/// and options to navigate different sections and functionalities of the
/// website after logging in.
///
///
///
/// It includes the following elements:
///
/// Home: A button return to the main page.
///
/// e-File & View: A dropdown menu for filling and viewing related options.
///
/// Services: A dropdown menu for accessing various services.
///
/// Pending Actions: A dropdown menu for the actions that are pending.
///
/// Grievance: A button for grievance or complaint related features.
///
/// Downloads: A dropdown menu for downloading files or resources.
///
/// Search Button- It is used to allow users to search quickly for the
/// specific information or features on the website.
///
/// Parameters:
///
/// onTap: Action
/// Define the action to be performed on click of each button shown in the
/// navigation bar.
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
class GenericMenuBarWebsitePostLoginWidget extends StatefulWidget {
  const GenericMenuBarWebsitePostLoginWidget({
    super.key,
    this.onTap,
    required this.keyPrefix,
  });

  final Future Function()? onTap;
  final String? keyPrefix;

  @override
  State<GenericMenuBarWebsitePostLoginWidget> createState() =>
      _GenericMenuBarWebsitePostLoginWidgetState();
}

class _GenericMenuBarWebsitePostLoginWidgetState
    extends State<GenericMenuBarWebsitePostLoginWidget> {
  late GenericMenuBarWebsitePostLoginModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericMenuBarWebsitePostLoginModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).primary700,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: 36.0,
            decoration: BoxDecoration(),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(48.0, 0.0, 0.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Semantics(
                    label: 'Home: A button return to the main page.',
                    child: wrapWithModel(
                      model: _model.homeButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      updateOnChange: true,
                      child: NavigationGenericMenuButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_Website_PostLogin',
                                'HomeButton')),
                        title: 'Home',
                        isIconVisible: false,
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_WebsitePostLogin',
                                'HomeButton'),
                        onTapAction: () async {
                          await widget.onTap?.call();
                        },
                      ),
                    ),
                  ),
                  Semantics(
                    label:
                        'e-File & View: A dropdown menu for filling and viewing related options.',
                    child: wrapWithModel(
                      model: _model.efileViewButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericMenuButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_Website_PostLogin',
                                'efileViewButton')),
                        title: 'e-file & View',
                        isIconVisible: true,
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_WebsitePostLogin',
                                'e-fileViewButton'),
                        onTapAction: () async {
                          await widget.onTap?.call();
                        },
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(1.0, 0.0, 0.0, 0.0),
                    child: Semantics(
                      label:
                          'Services: A dropdown menu for accessing various services.',
                      child: wrapWithModel(
                        model: _model.servicesButtonModel,
                        updateCallback: () => safeSetState(() {}),
                        child: NavigationGenericMenuButtonWidget(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Generic_MenuBar_Website_PostLogin',
                                  'ServicesButton')),
                          title: 'Services',
                          isIconVisible: true,
                          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Generic_MenuBar_WebsitePostLogin',
                                  'ServicesButton'),
                          onTapAction: () async {
                            await widget.onTap?.call();
                          },
                        ),
                      ),
                    ),
                  ),
                  Semantics(
                    label:
                        'Pending Actions: A dropdown menu for the actions that are pending.',
                    child: wrapWithModel(
                      model: _model.pendingActionsButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericMenuButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_Website_PostLogin',
                                'PendingActionsButton')),
                        title: 'Pending Actions',
                        isIconVisible: true,
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_WebsitePostLogin',
                                'PendingActionsButton'),
                        onTapAction: () async {
                          await widget.onTap?.call();
                        },
                      ),
                    ),
                  ),
                  Semantics(
                    label:
                        'Grievance: A button for grievance or complaint related features.',
                    child: wrapWithModel(
                      model: _model.grievanceButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericMenuButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_Website_PostLogin',
                                'GrievanceButton')),
                        title: 'Grievance',
                        isIconVisible: true,
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_WebsitePostLogin',
                                'GrievanceButton'),
                        onTapAction: () async {
                          await widget.onTap?.call();
                        },
                      ),
                    ),
                  ),
                  Semantics(
                    label:
                        'Downloads: A dropdown menu for downloading files or resources.',
                    child: wrapWithModel(
                      model: _model.downloadsButtonModel,
                      updateCallback: () => safeSetState(() {}),
                      child: NavigationGenericMenuButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_Website_PostLogin',
                                'DownloadsButton')),
                        title: 'Downloads',
                        isIconVisible: true,
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_MenuBar_WebsitePostLogin',
                                'DownloadsButton'),
                        onTapAction: () async {
                          await widget.onTap?.call();
                        },
                      ),
                    ),
                  ),
                ].divide(SizedBox(width: 12.0)),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 2.0, 48.0, 2.0),
            child: Container(
              width: 32.0,
              height: 32.0,
              decoration: BoxDecoration(),
              child: Semantics(
                label:
                    'Search Button- It is used to allow users to search quickly for the specific information or features on the website.',
                child: FlutterFlowIconButton(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'Generic_MenuBar_Website_PostLogin',
                          'SearchButton')),
                  borderColor: FlutterFlowTheme.of(context).primary500,
                  borderRadius: 4.0,
                  borderWidth: 1.0,
                  buttonSize: 32.0,
                  fillColor: Colors.transparent,
                  icon: Icon(
                    Icons.search_sharp,
                    color: FlutterFlowTheme.of(context).textAlternative,
                    size: 20.0,
                  ),
                  onPressed: () async {
                    await widget.onTap?.call();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
