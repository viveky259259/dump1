import '/final_l1_navigation_website/generic_header_website/generic_header_website_widget.dart';
import '/final_l1_navigation_website/generic_menu_bar_website_post_login/generic_menu_bar_website_post_login_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'navigation_generic_header_with_menu_bar_post_login_widget.dart'
    show NavigationGenericHeaderWithMenuBarPostLoginWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NavigationGenericHeaderWithMenuBarPostLoginModel extends FlutterFlowModel<
    NavigationGenericHeaderWithMenuBarPostLoginWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Generic_Header_Website component.
  late GenericHeaderWebsiteModel genericHeaderWebsiteModel;
  // Model for Generic_MenuBar_Website_PostLogin component.
  late GenericMenuBarWebsitePostLoginModel genericMenuBarWebsitePostLoginModel;

  @override
  void initState(BuildContext context) {
    genericHeaderWebsiteModel =
        createModel(context, () => GenericHeaderWebsiteModel());
    genericMenuBarWebsitePostLoginModel =
        createModel(context, () => GenericMenuBarWebsitePostLoginModel());
  }

  @override
  void dispose() {
    genericHeaderWebsiteModel.dispose();
    genericMenuBarWebsitePostLoginModel.dispose();
  }
}
