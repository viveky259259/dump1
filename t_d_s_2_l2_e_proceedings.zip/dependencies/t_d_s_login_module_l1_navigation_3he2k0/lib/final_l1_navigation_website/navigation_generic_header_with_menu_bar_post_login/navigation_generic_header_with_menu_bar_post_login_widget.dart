import '/final_l1_navigation_website/generic_header_website/generic_header_website_widget.dart';
import '/final_l1_navigation_website/generic_menu_bar_website_post_login/generic_menu_bar_website_post_login_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_header_with_menu_bar_post_login_model.dart';
export 'navigation_generic_header_with_menu_bar_post_login_model.dart';

class NavigationGenericHeaderWithMenuBarPostLoginWidget extends StatefulWidget {
  const NavigationGenericHeaderWithMenuBarPostLoginWidget({
    super.key,
    this.isEnable,
    required this.keyPrefix,
  });

  final bool? isEnable;
  final String? keyPrefix;

  @override
  State<NavigationGenericHeaderWithMenuBarPostLoginWidget> createState() =>
      _NavigationGenericHeaderWithMenuBarPostLoginWidgetState();
}

class _NavigationGenericHeaderWithMenuBarPostLoginWidgetState
    extends State<NavigationGenericHeaderWithMenuBarPostLoginWidget> {
  late NavigationGenericHeaderWithMenuBarPostLoginModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => NavigationGenericHeaderWithMenuBarPostLoginModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        wrapWithModel(
          model: _model.genericHeaderWebsiteModel,
          updateCallback: () => safeSetState(() {}),
          child: GenericHeaderWebsiteWidget(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar_PostLogin',
                'Generic_Header_Website_PostLogin')),
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar_PostLogin',
                'Generic_Header_Website_PostLogin'),
            onTapAction: () async {},
          ),
        ),
        wrapWithModel(
          model: _model.genericMenuBarWebsitePostLoginModel,
          updateCallback: () => safeSetState(() {}),
          child: GenericMenuBarWebsitePostLoginWidget(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar_PostLogin',
                'Generic_MenuBar_Website_PostLogin')),
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar_PostLogin',
                'Generic_MenuBar_Website_PostLogin'),
            onTap: () async {},
          ),
        ),
      ],
    );
  }
}
