import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/accessibility_menu_mobile_widget.dart';
import '/components/profile_menu_mobile_widget.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import "package:t_d_s2_l1_language_support_4doo8y/backend/schema/structs/index.dart"
    as t_d_s2_l1_language_support_4doo8y_data_schema;
import 'generic_header_website_widget.dart' show GenericHeaderWebsiteWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s2_l1_language_support_4doo8y/app_state.dart'
    as t_d_s2_l1_language_support_4doo8y_app_state;
import 'package:t_d_s2_l1_language_support_4doo8y/custom_code/actions/index.dart'
    as t_d_s2_l1_language_support_4doo8y_actions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GenericHeaderWebsiteModel
    extends FlutterFlowModel<GenericHeaderWebsiteWidget> {
  ///  Local state fields for this component.

  bool isIconTapped = false;

  ///  State fields for stateful widgets in this component.

  // State field(s) for LanguageDropDown widget.
  String? languageDropDownValue;
  FormFieldController<String>? languageDropDownValueController;
  // State field(s) for ProfileDropDown widget.
  String? profileDropDownValue;
  FormFieldController<String>? profileDropDownValueController;
  // Model for LoginButton.
  late NavigationGenericSecondaryButtonModel loginButtonModel;
  // Model for RegisterButton.
  late NavigationGenericPrimaryButtonModel registerButtonModel;

  @override
  void initState(BuildContext context) {
    loginButtonModel =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
    registerButtonModel =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    loginButtonModel.dispose();
    registerButtonModel.dispose();
  }
}
