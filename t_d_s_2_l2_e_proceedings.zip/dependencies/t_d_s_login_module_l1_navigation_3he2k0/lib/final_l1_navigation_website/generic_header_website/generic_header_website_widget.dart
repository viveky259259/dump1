import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/accessibility_menu_mobile_widget.dart';
import '/components/profile_menu_mobile_widget.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import "package:t_d_s2_l1_language_support_4doo8y/backend/schema/structs/index.dart"
    as t_d_s2_l1_language_support_4doo8y_data_schema;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s2_l1_language_support_4doo8y/app_state.dart'
    as t_d_s2_l1_language_support_4doo8y_app_state;
import 'package:t_d_s2_l1_language_support_4doo8y/custom_code/actions/index.dart'
    as t_d_s2_l1_language_support_4doo8y_actions;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'generic_header_website_model.dart';
export 'generic_header_website_model.dart';

/// This is Generic Header is a part of the application's user interface that
/// become visible after the user successfully logs in.
///
///
/// It includes the following elements:
/// TDS logo: Image
/// Contact Us: A clickable text for user assistance or inquiries.
/// Screen Reader Icon & Text: Accessibility feature or reading text aloud.
/// Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text
/// size.
///
/// Tonality( Theme Switcher Dark/Light Mode): Enables users to toggle between
/// dark and light themes for the application's interface depending on their
/// preference or lighting conditions.
/// Language Selector: Dropdown to switch between different languages(e.g.,
/// "English","Hindi")
///
/// Notifications(Bell Icon):  It displays any new alerts or updates relevant
/// to the user's activity within the application.
///
/// Profile DropDown(User Icon): It shows user related options such as:
///
/// Viewing or editing the user's profile
/// Accessing account settings.
/// Logging out of the application.
/// Clicking this icon opens a dropdown menu with these options.
/// Parameters:
/// onTap: Action
/// Define the action to be performed when the IconButton, Text  is tapped,
/// such as reading text aloud.
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
class GenericHeaderWebsiteWidget extends StatefulWidget {
  const GenericHeaderWebsiteWidget({
    super.key,
    required this.keyPrefix,
    required this.onTapAction,
    bool? isUserLoggedIn,
  }) : this.isUserLoggedIn = isUserLoggedIn ?? false;

  final String? keyPrefix;
  final Future Function()? onTapAction;
  final bool isUserLoggedIn;

  @override
  State<GenericHeaderWebsiteWidget> createState() =>
      _GenericHeaderWebsiteWidgetState();
}

class _GenericHeaderWebsiteWidgetState
    extends State<GenericHeaderWebsiteWidget> {
  late GenericHeaderWebsiteModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GenericHeaderWebsiteModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<t_d_s2_l1_language_support_4doo8y_app_state.FFAppState>();

    return Container(
      width: MediaQuery.sizeOf(context).width,
      height: 80.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).neutral100,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(
            valueOrDefault<double>(
              () {
                if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                  return 16.0;
                } else if (MediaQuery.sizeOf(context).width <
                    kBreakpointMedium) {
                  return 48.0;
                } else if (MediaQuery.sizeOf(context).width <
                    kBreakpointLarge) {
                  return 48.0;
                } else {
                  return 48.0;
                }
              }(),
              48.0,
            ),
            8.0,
            valueOrDefault<double>(
              () {
                if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                  return 16.0;
                } else if (MediaQuery.sizeOf(context).width <
                    kBreakpointMedium) {
                  return 48.0;
                } else if (MediaQuery.sizeOf(context).width <
                    kBreakpointLarge) {
                  return 48.0;
                } else {
                  return 48.0;
                }
              }(),
              48.0,
            ),
            8.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Wrap(
              spacing: 0.0,
              runSpacing: 0.0,
              alignment: WrapAlignment.start,
              crossAxisAlignment: WrapCrossAlignment.center,
              direction: Axis.horizontal,
              runAlignment: WrapAlignment.start,
              verticalDirection: VerticalDirection.down,
              clipBehavior: Clip.none,
              children: [
                if (responsiveVisibility(
                  context: context,
                  phone: false,
                ))
                  Semantics(
                    label: 'This is image of TDS Logo.',
                    child: ClipRRect(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Generic_Header_Website_PostLogin',
                              'TDSLogo')),
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.asset(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Generic_Header_Website_PostLogin', 'TDSLogo')),
                        'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/tdscpclogo.png',
                        width: 415.0,
                        height: 56.0,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                if (responsiveVisibility(
                  context: context,
                  tablet: false,
                  tabletLandscape: false,
                  desktop: false,
                ))
                  Semantics(
                    label: 'This is image of TDS Logo.',
                    child: ClipRRect(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Generic_Header_Website_PostLogin',
                              'TDSLogo')),
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.asset(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Generic_Header_Website_PostLogin', 'TDSLogo')),
                        'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/TDS_mobile_logo.png',
                        width: 152.0,
                        height: 56.0,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
              ],
            ),
            if (responsiveVisibility(
              context: context,
              phone: false,
            ))
              Wrap(
                spacing: 0.0,
                runSpacing: 0.0,
                alignment: WrapAlignment.start,
                crossAxisAlignment: WrapCrossAlignment.center,
                direction: Axis.horizontal,
                runAlignment: WrapAlignment.start,
                verticalDirection: VerticalDirection.down,
                clipBehavior: Clip.none,
                children: [
                  Semantics(
                    label:
                        'Screen Reader button: Accessibility feature or reading text aloud.',
                    child: FFButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Generic_Header_Website_PostLogin',
                              'ScreenReaderButton')),
                      onPressed: () {
                        print('ScreenReaderButton pressed ...');
                      },
                      text: 'Screen Reader',
                      icon: Icon(
                        FFIcons.ktextToSpeech,
                        color: FlutterFlowTheme.of(context).primary600Default,
                        size: 20.0,
                      ),
                      options: FFButtonOptions(
                        height: 40.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconAlignment: IconAlignment.start,
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Colors.transparent,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context)
                                      .primary600Default,
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                        elevation: 0.0,
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                    child: VerticalDivider(
                      thickness: 0.5,
                      color: FlutterFlowTheme.of(context).primaryBGStroke30,
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(),
                    child: Semantics(
                      label:
                          'Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text size.',
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FlutterFlowIconButton(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Generic_Header_Website_PostLogin',
                                    'TextDecreaseIcon')),
                            borderColor: Colors.transparent,
                            borderRadius: 8.0,
                            buttonSize: 40.0,
                            icon: Icon(
                              Icons.text_decrease,
                              color: FlutterFlowTheme.of(context)
                                  .primary600Default,
                              size: 20.0,
                            ),
                            onPressed: () {
                              print('TextDecreaseIcon pressed ...');
                            },
                          ),
                          FlutterFlowIconButton(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Generic_Header_Website_PostLogin',
                                    'FontIconButton')),
                            borderColor: Colors.transparent,
                            borderRadius: 8.0,
                            buttonSize: 40.0,
                            fillColor: Colors.transparent,
                            icon: Icon(
                              Icons.font_download,
                              color: FlutterFlowTheme.of(context)
                                  .primary600Default,
                              size: 20.0,
                            ),
                            onPressed: () {
                              print('FontIconButton pressed ...');
                            },
                          ),
                          FlutterFlowIconButton(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Generic_Header_Website_PostLogin',
                                    'TextIncreaseIcon')),
                            borderColor: Colors.transparent,
                            borderRadius: 8.0,
                            buttonSize: 40.0,
                            icon: Icon(
                              Icons.text_increase,
                              color: FlutterFlowTheme.of(context)
                                  .primary600Default,
                              size: 20.0,
                            ),
                            onPressed: () {
                              print('TextIncreaseIcon pressed ...');
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                    child: VerticalDivider(
                      thickness: 0.5,
                      color: FlutterFlowTheme.of(context).primaryBGStroke30,
                    ),
                  ),
                  Semantics(
                    label:
                        'Tonality( Theme Switcher Dark/Light Mode): Enables users to toggle between dark and light themes for the application\'s interface depending on their preference or lighting conditions.',
                    child: FlutterFlowIconButton(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Generic_Header_Website_PostLogin',
                              'TonalityIconButton')),
                      borderColor: Colors.transparent,
                      borderRadius: 8.0,
                      buttonSize: 40.0,
                      fillColor: Colors.transparent,
                      icon: Icon(
                        Icons.tonality,
                        color: FlutterFlowTheme.of(context).primary600Default,
                        size: 20.0,
                      ),
                      onPressed: () {
                        print('TonalityIconButton pressed ...');
                      },
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                    child: VerticalDivider(
                      thickness: 0.5,
                      color: FlutterFlowTheme.of(context).primaryBGStroke30,
                    ),
                  ),
                  Container(
                    width: 90.0,
                    decoration: BoxDecoration(),
                    child: Semantics(
                      label:
                          'Language Selector: Dropdown to switch between different languages (e.g., \"English\",\"Hindi\")',
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Icon(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Generic_Header_Website_PostLogin',
                                    'LanguageIcon')),
                            Icons.language,
                            color:
                                FlutterFlowTheme.of(context).primary600Default,
                            size: 20.0,
                          ),
                          Flexible(
                            child: FlutterFlowDropDown<String>(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_Website_PostLogin',
                                      'LanguageDropDown')),
                              controller:
                                  _model.languageDropDownValueController ??=
                                      FormFieldController<String>(
                                _model.languageDropDownValue ??=
                                    t_d_s2_l1_language_support_4doo8y_app_state
                                            .FFAppState()
                                        .currentLanguage
                                        .code,
                              ),
                              options: List<String>.from(
                                  t_d_s2_l1_language_support_4doo8y_app_state
                                          .FFAppState()
                                      .supportedLanguages
                                      .map((e) => e.code)
                                      .toList()),
                              optionLabels:
                                  t_d_s2_l1_language_support_4doo8y_app_state
                                          .FFAppState()
                                      .supportedLanguages
                                      .map((e) => e.name)
                                      .toList(),
                              onChanged: (val) async {
                                safeSetState(
                                    () => _model.languageDropDownValue = val);
                                await t_d_s2_l1_language_support_4doo8y_actions
                                    .changeCurrentLanguage(
                                  t_d_s2_l1_language_support_4doo8y_data_schema
                                      .LanguageStruct(
                                    code: _model.languageDropDownValue,
                                    name:
                                        t_d_s2_l1_language_support_4doo8y_app_state
                                                .FFAppState()
                                            .supportedLanguages
                                            .where((e) =>
                                                e.code ==
                                                _model.languageDropDownValue)
                                            .toList()
                                            .firstOrNull
                                            ?.name,
                                  ),
                                );
                              },
                              height: 40.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                              hintText: 'Language',
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 20.0,
                              ),
                              elevation: 2.0,
                              borderColor: Colors.transparent,
                              borderWidth: 0.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              hidesUnderline: true,
                              isOverButton: false,
                              isSearchable: false,
                              isMultiSelect: false,
                            ),
                          ),
                        ].divide(SizedBox(width: 5.0)),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                    child: VerticalDivider(
                      thickness: 0.5,
                      color: FlutterFlowTheme.of(context).primaryBGStroke30,
                    ),
                  ),
                  Semantics(
                    label:
                        'This is Help Button for users assistance or inquiries.',
                    child: FFButtonWidget(
                      key: ValueKey(
                          t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                              widget!.keyPrefix!,
                              'Generic_Header_Website_PostLogin',
                              'HelpButton')),
                      onPressed: () {
                        print('HelpButton pressed ...');
                      },
                      text: 'Help',
                      icon: Icon(
                        Icons.help_outline,
                        size: 20.0,
                      ),
                      options: FFButtonOptions(
                        height: 20.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Colors.transparent,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context)
                                      .primary600Default,
                                  fontSize: 12.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                        elevation: 0.0,
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                  if (widget!.isUserLoggedIn)
                    Container(
                      decoration: BoxDecoration(),
                      child: Semantics(
                        label:
                            'Profile DropDown(User Icon): It shows user related options such as:\nViewing or editing the user\'s profile\nAccessing account settings.\nLogging out of the application.\nClicking this icon opens a dropdown menu with these options.',
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Semantics(
                              label:
                                  'Notifications(Bell Icon):  It displays any new alerts or updates relevant to the user\'s activity within the application.',
                              child: FlutterFlowIconButton(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Generic_Header_Website_PostLogin',
                                        'NotifficationIcon')),
                                borderRadius: 8.0,
                                buttonSize: 40.0,
                                fillColor: Colors.transparent,
                                icon: Icon(
                                  Icons.notifications_none,
                                  color:
                                      FlutterFlowTheme.of(context).neutral800,
                                  size: 20.0,
                                ),
                                onPressed: () {
                                  print('NotifficationIcon pressed ...');
                                },
                              ),
                            ),
                            FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_Website_PostLogin',
                                      'ProfileIconButton')),
                              buttonSize: 40.0,
                              fillColor: Colors.transparent,
                              icon: Icon(
                                Icons.account_circle_outlined,
                                color: FlutterFlowTheme.of(context).neutral800,
                                size: 20.0,
                              ),
                              onPressed: () {
                                print('ProfileIconButton pressed ...');
                              },
                            ),
                            FlutterFlowDropDown<String>(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_Website_PostLogin',
                                      'ProfileDropDown')),
                              controller:
                                  _model.profileDropDownValueController ??=
                                      FormFieldController<String>(
                                _model.profileDropDownValue ??= 'Profile',
                              ),
                              options: ['Profile'],
                              onChanged: (val) => safeSetState(
                                  () => _model.profileDropDownValue = val),
                              width: 99.0,
                              height: 40.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).neutral800,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                              hintText: 'Profile',
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                size: 24.0,
                              ),
                              elevation: 2.0,
                              borderColor: Colors.transparent,
                              borderWidth: 0.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 0.0, 12.0, 0.0),
                              hidesUnderline: true,
                              isOverButton: false,
                              isSearchable: false,
                              isMultiSelect: false,
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (!widget!.isUserLoggedIn)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Semantics(
                            label:
                                'If isNewUser is false, then the Login button will show.',
                            child: wrapWithModel(
                              model: _model.loginButtonModel,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: NavigationGenericSecondaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Generic_Header_Website',
                                        'LoginButton')),
                                labelText: 'Login',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Generic_Header_Website',
                                        'LoginButton'),
                                width: 72.0,
                                height: 28.0,
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  await widget.onTapAction?.call();
                                },
                              ),
                            ),
                          ),
                          wrapWithModel(
                            model: _model.registerButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericPrimaryButtonWidget(
                              labeltext: 'Register',
                              keyPrefix: 'key',
                              width: 80.0,
                              height: 28.0,
                              states: ButtonState.byDefault,
                              onTap: () async {
                                await widget.onTapAction?.call();
                              },
                            ),
                          ),
                        ].divide(SizedBox(width: 12.0)),
                      ),
                    ),
                ],
              ),
            if (responsiveVisibility(
              context: context,
              tablet: false,
              tabletLandscape: false,
              desktop: false,
            ))
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 0.0, 0.0),
                child: Wrap(
                  spacing: 0.0,
                  runSpacing: 0.0,
                  alignment: WrapAlignment.start,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  direction: Axis.horizontal,
                  runAlignment: WrapAlignment.start,
                  verticalDirection: VerticalDirection.down,
                  clipBehavior: Clip.none,
                  children: [
                    Semantics(
                      label:
                          'This is Help Button for users assistance or inquiries.',
                      child: FlutterFlowIconButton(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_Header_Website_PostLogin',
                                'HelpButton')),
                        borderRadius: 8.0,
                        buttonSize: 40.0,
                        fillColor: Colors.transparent,
                        icon: Icon(
                          Icons.help_outline,
                          color: FlutterFlowTheme.of(context).neutral800,
                          size: 24.0,
                        ),
                        onPressed: () {
                          print('HelpButton pressed ...');
                        },
                      ),
                    ),
                    if (widget!.isUserLoggedIn)
                      Semantics(
                        label:
                            'Notifications(Bell Icon):  It displays any new alerts or updates relevant to the user\'s activity within the application.',
                        child: FlutterFlowIconButton(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Generic_Header_Website_PostLogin',
                                  'NotifficationIcon')),
                          borderRadius: 8.0,
                          buttonSize: 40.0,
                          fillColor: Colors.transparent,
                          icon: Icon(
                            Icons.notifications_none,
                            color: FlutterFlowTheme.of(context).neutral800,
                            size: 24.0,
                          ),
                          onPressed: () {
                            print('NotifficationIcon pressed ...');
                          },
                        ),
                      ),
                    Builder(
                      builder: (context) => FlutterFlowIconButton(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_Header_Website_PostLogin',
                                'ProfileIconButton')),
                        buttonSize: 40.0,
                        fillColor: Colors.transparent,
                        icon: Icon(
                          Icons.account_circle_outlined,
                          color: _model.isIconTapped == true
                              ? FlutterFlowTheme.of(context)
                                  .secondaryInfo500Default
                              : FlutterFlowTheme.of(context).neutral800,
                          size: 24.0,
                        ),
                        onPressed: () async {
                          _model.isIconTapped = !_model.isIconTapped;
                          safeSetState(() {});
                          await showDialog(
                            barrierColor: Colors.transparent,
                            context: context,
                            builder: (dialogContext) {
                              return Dialog(
                                elevation: 0,
                                insetPadding: EdgeInsets.zero,
                                backgroundColor: Colors.transparent,
                                alignment: AlignmentDirectional(1.0, -1.0)
                                    .resolve(Directionality.of(context)),
                                child: ProfileMenuMobileWidget(
                                  keyPrefix: 'key',
                                  onTapRegister: () async {
                                    context.safePop();
                                  },
                                  onTapLogin: () async {
                                    context.safePop();
                                  },
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                    Builder(
                      builder: (context) => FlutterFlowIconButton(
                        borderRadius: 8.0,
                        buttonSize: 40.0,
                        fillColor: Colors.transparent,
                        icon: Icon(
                          Icons.accessibility_new,
                          color: FlutterFlowTheme.of(context).neutral800,
                          size: 24.0,
                        ),
                        onPressed: () async {
                          _model.isIconTapped = !_model.isIconTapped;
                          safeSetState(() {});
                          await showDialog(
                            barrierColor: Colors.transparent,
                            context: context,
                            builder: (dialogContext) {
                              return Dialog(
                                elevation: 0,
                                insetPadding: EdgeInsets.zero,
                                backgroundColor: Colors.transparent,
                                alignment: AlignmentDirectional(1.0, -1.0)
                                    .resolve(Directionality.of(context)),
                                child: AccessibilityMenuMobileWidget(
                                  keyPrefix: 'key',
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
