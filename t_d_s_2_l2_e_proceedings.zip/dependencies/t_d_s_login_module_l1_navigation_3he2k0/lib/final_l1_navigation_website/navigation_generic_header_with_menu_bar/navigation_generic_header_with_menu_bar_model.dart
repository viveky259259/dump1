import '/components/dont_use_this_component_widget.dart';
import '/final_l1_navigation_website/generic_menu_bar_website/generic_menu_bar_website_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'navigation_generic_header_with_menu_bar_widget.dart'
    show NavigationGenericHeaderWithMenuBarWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NavigationGenericHeaderWithMenuBarModel
    extends FlutterFlowModel<NavigationGenericHeaderWithMenuBarWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Dont_Use_This_Component component.
  late DontUseThisComponentModel dontUseThisComponentModel;
  // Model for Generic_MenuBar_Website component.
  late GenericMenuBarWebsiteModel genericMenuBarWebsiteModel;

  @override
  void initState(BuildContext context) {
    dontUseThisComponentModel =
        createModel(context, () => DontUseThisComponentModel());
    genericMenuBarWebsiteModel =
        createModel(context, () => GenericMenuBarWebsiteModel());
  }

  @override
  void dispose() {
    dontUseThisComponentModel.dispose();
    genericMenuBarWebsiteModel.dispose();
  }
}
