import '/components/dont_use_this_component_widget.dart';
import '/final_l1_navigation_website/generic_menu_bar_website/generic_menu_bar_website_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_header_with_menu_bar_model.dart';
export 'navigation_generic_header_with_menu_bar_model.dart';

class NavigationGenericHeaderWithMenuBarWidget extends StatefulWidget {
  const NavigationGenericHeaderWithMenuBarWidget({
    super.key,
    this.isEnable,
    required this.keyPrefix,
  });

  final bool? isEnable;
  final String? keyPrefix;

  @override
  State<NavigationGenericHeaderWithMenuBarWidget> createState() =>
      _NavigationGenericHeaderWithMenuBarWidgetState();
}

class _NavigationGenericHeaderWithMenuBarWidgetState
    extends State<NavigationGenericHeaderWithMenuBarWidget> {
  late NavigationGenericHeaderWithMenuBarModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => NavigationGenericHeaderWithMenuBarModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        wrapWithModel(
          model: _model.dontUseThisComponentModel,
          updateCallback: () => safeSetState(() {}),
          child: DontUseThisComponentWidget(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar',
                'Generic_Header_Website')),
            isNewUser: false,
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar',
                'Generic_Header_Website'),
            onTapAction: () async {},
          ),
        ),
        wrapWithModel(
          model: _model.genericMenuBarWebsiteModel,
          updateCallback: () => safeSetState(() {}),
          child: GenericMenuBarWebsiteWidget(
            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar',
                'Generic_MenuBar_Website')),
            keyPrefix: t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                widget!.keyPrefix!,
                'Navigation_Generic_HeaderWithMenuBar',
                'Generic_MenuBar_Website'),
            onTap: () async {},
          ),
        ),
      ],
    );
  }
}
