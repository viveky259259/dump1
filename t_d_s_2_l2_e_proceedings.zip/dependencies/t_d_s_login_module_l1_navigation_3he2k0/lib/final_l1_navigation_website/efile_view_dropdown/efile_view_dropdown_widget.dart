import '/final_l1_navigation_common/dropdown_menu_button/dropdown_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'efile_view_dropdown_model.dart';
export 'efile_view_dropdown_model.dart';

/// This dropdown menu appears under the 'e-file & View' tab of the TRACES
/// portal.
///
/// It provides several options for interacting with forms and statements
/// related to tax filing.
/// The options listed are:
/// File Forms: Allows you to file various tax-related forms.
/// File Correction Statement: Used to correct errors in previously filled
/// forms or statements.
/// View Filed Forms & Returns: Lets you view the forms and returns you have
/// already submitted.
/// View Default Summary: Displays a summary of defaults identified in filed
/// returns.
/// View 26AS/Annual TS: provides access to the tax credit statement(Form
/// 26AS) or Annual Tax Statement.
class EfileViewDropdownWidget extends StatefulWidget {
  const EfileViewDropdownWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<EfileViewDropdownWidget> createState() =>
      _EfileViewDropdownWidgetState();
}

class _EfileViewDropdownWidgetState extends State<EfileViewDropdownWidget> {
  late EfileViewDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EfileViewDropdownModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
        boxShadow: [
          BoxShadow(
            blurRadius: 6.0,
            color: FlutterFlowTheme.of(context).textPrimary,
            offset: Offset(
              0.0,
              4.0,
            ),
            spreadRadius: 0.0,
          )
        ],
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Semantics(
              label: 'File Forms: Allows you to file various tax-related forms',
              child: wrapWithModel(
                model: _model.fileFormsModel,
                updateCallback: () => safeSetState(() {}),
                child: DropdownMenuButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'FileForms')),
                  buttonText: 'File Forms',
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'FileForms'),
                  onTap: () async {},
                ),
              ),
            ),
            Semantics(
              label:
                  'File Correction Statement: Used to correct errors in previously filled forms or statements.',
              child: wrapWithModel(
                model: _model.fileCorrectionStatementModel,
                updateCallback: () => safeSetState(() {}),
                child: DropdownMenuButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'FileCorrectionStatement')),
                  buttonText: 'File Correction Statement',
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'FileCorrectionStatement'),
                  onTap: () async {},
                ),
              ),
            ),
            Semantics(
              label:
                  'View Filed Forms & Returns: Lets you view the forms and returns you have already submitted.',
              child: wrapWithModel(
                model: _model.viewFiledFormsReturnsModel,
                updateCallback: () => safeSetState(() {}),
                child: DropdownMenuButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'View Filed Forms & Returns')),
                  buttonText: 'View Filed Forms & Returns',
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'View Filed Forms & Returns'),
                  onTap: () async {},
                ),
              ),
            ),
            Semantics(
              label:
                  'View Default Summary: Displays a summary of defaults identified in filed returns.',
              child: wrapWithModel(
                model: _model.viewDefaultSummaryModel,
                updateCallback: () => safeSetState(() {}),
                child: DropdownMenuButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'View Default Summary')),
                  buttonText: 'View Default Summary',
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'View Default Summary'),
                  onTap: () async {},
                ),
              ),
            ),
            Semantics(
              label:
                  'View 26AS/Annual TS: provides access to the tax credit statement(Form 26AS) or Annual Tax Statement.',
              child: wrapWithModel(
                model: _model.view26ASAnnualTSModel,
                updateCallback: () => safeSetState(() {}),
                child: DropdownMenuButtonWidget(
                  key: ValueKey(
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'View 26AS/Annual TS')),
                  buttonText: 'View 26AS/Annual TS',
                  keyPrefix:
                      t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                          widget!.keyPrefix!,
                          'efileView_Dropdown',
                          'View 26AS/Annual TS'),
                  onTap: () async {},
                ),
              ),
            ),
          ]
              .divide(SizedBox(height: 12.0))
              .addToStart(SizedBox(height: 12.0))
              .addToEnd(SizedBox(height: 16.0)),
        ),
      ),
    );
  }
}
