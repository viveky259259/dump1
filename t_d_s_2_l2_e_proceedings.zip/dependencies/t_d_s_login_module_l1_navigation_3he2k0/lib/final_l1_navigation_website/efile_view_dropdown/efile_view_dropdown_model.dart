import '/final_l1_navigation_common/dropdown_menu_button/dropdown_menu_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'efile_view_dropdown_widget.dart' show EfileViewDropdownWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EfileViewDropdownModel extends FlutterFlowModel<EfileViewDropdownWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for FileForms.
  late DropdownMenuButtonModel fileFormsModel;
  // Model for FileCorrectionStatement.
  late DropdownMenuButtonModel fileCorrectionStatementModel;
  // Model for ViewFiledFormsReturns.
  late DropdownMenuButtonModel viewFiledFormsReturnsModel;
  // Model for ViewDefaultSummary.
  late DropdownMenuButtonModel viewDefaultSummaryModel;
  // Model for View26ASAnnualTS.
  late DropdownMenuButtonModel view26ASAnnualTSModel;

  @override
  void initState(BuildContext context) {
    fileFormsModel = createModel(context, () => DropdownMenuButtonModel());
    fileCorrectionStatementModel =
        createModel(context, () => DropdownMenuButtonModel());
    viewFiledFormsReturnsModel =
        createModel(context, () => DropdownMenuButtonModel());
    viewDefaultSummaryModel =
        createModel(context, () => DropdownMenuButtonModel());
    view26ASAnnualTSModel =
        createModel(context, () => DropdownMenuButtonModel());
  }

  @override
  void dispose() {
    fileFormsModel.dispose();
    fileCorrectionStatementModel.dispose();
    viewFiledFormsReturnsModel.dispose();
    viewDefaultSummaryModel.dispose();
    view26ASAnnualTSModel.dispose();
  }
}
