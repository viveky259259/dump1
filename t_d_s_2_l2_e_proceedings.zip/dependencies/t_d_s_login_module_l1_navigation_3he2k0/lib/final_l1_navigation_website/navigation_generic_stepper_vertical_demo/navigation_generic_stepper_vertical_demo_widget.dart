import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_stepper_vertical_demo_model.dart';
export 'navigation_generic_stepper_vertical_demo_model.dart';

class NavigationGenericStepperVerticalDemoWidget extends StatefulWidget {
  const NavigationGenericStepperVerticalDemoWidget({
    super.key,
    this.stepperHeading,
    this.stepsList,
    this.currentStep,
    this.width,
    this.height,
    required this.keyPrefix,
    bool? showVerticalLine,
    this.onTap,
  }) : this.showVerticalLine = showVerticalLine ?? true;

  final String? stepperHeading;
  final List<String>? stepsList;
  final int? currentStep;
  final double? width;
  final double? height;
  final String? keyPrefix;
  final bool showVerticalLine;
  final Future Function()? onTap;

  @override
  State<NavigationGenericStepperVerticalDemoWidget> createState() =>
      _NavigationGenericStepperVerticalDemoWidgetState();
}

class _NavigationGenericStepperVerticalDemoWidgetState
    extends State<NavigationGenericStepperVerticalDemoWidget> {
  late NavigationGenericStepperVerticalDemoModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => NavigationGenericStepperVerticalDemoModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 16.0),
            child: Container(
              width: 286.0,
              height: 27.0,
              decoration: BoxDecoration(),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(48.0, 0.0, 48.0, 0.0),
                child: Text(
                  valueOrDefault<String>(
                    widget!.stepperHeading,
                    'stepperHeading',
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).textPrimary,
                        fontSize: 18.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ),
            ),
          ),
          Divider(
            thickness: 2.0,
            color: FlutterFlowTheme.of(context).neutral300,
          ),
          Builder(
            builder: (context) {
              final stepsName = widget!.stepsList?.toList() ?? [];

              return ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: stepsName.length,
                itemBuilder: (context, stepsNameIndex) {
                  final stepsNameItem = stepsName[stepsNameIndex];
                  return Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 4.0),
                        child: InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            await widget.onTap?.call();
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: () {
                                if (widget!.currentStep! >
                                    (stepsNameIndex + 1)) {
                                  return Colors.transparent;
                                } else if (widget!.currentStep ==
                                    (stepsNameIndex + 1)) {
                                  return FlutterFlowTheme.of(context)
                                      .secondaryInfoBGStroke10;
                                } else {
                                  return Colors.transparent;
                                }
                              }(),
                            ),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  48.0, 14.0, 12.0, 14.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Builder(
                                    builder: (context) {
                                      if (widget!.currentStep! >
                                          (stepsNameIndex + 1)) {
                                        return Container(
                                          width: 20.0,
                                          height: 20.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .success100,
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .success700,
                                              width: 1.3,
                                            ),
                                          ),
                                          child: Icon(
                                            Icons.check_sharp,
                                            color: FlutterFlowTheme.of(context)
                                                .success700,
                                            size: 11.6,
                                          ),
                                        );
                                      } else if (widget!.currentStep ==
                                          (stepsNameIndex + 1)) {
                                        return Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            color: Colors.transparent,
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryInfo500Default,
                                              width: 1.5,
                                            ),
                                          ),
                                          alignment:
                                              AlignmentDirectional(0.0, 0.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            children: [
                                              Icon(
                                                Icons.circle_rounded,
                                                color: FlutterFlowTheme.of(
                                                        context)
                                                    .secondaryInfo500Default,
                                                size: 3.38,
                                              ),
                                              Icon(
                                                Icons.circle_rounded,
                                                color: FlutterFlowTheme.of(
                                                        context)
                                                    .secondaryInfo500Default,
                                                size: 3.38,
                                              ),
                                            ].divide(SizedBox(width: 1.0)),
                                          ),
                                        );
                                      } else {
                                        return Builder(
                                          builder: (context) {
                                            if (stepsNameIndex == 0) {
                                              return Icon(
                                                FFIcons.kstep1,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else if (stepsNameIndex == 1) {
                                              return Icon(
                                                FFIcons.kstep2,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else if (stepsNameIndex == 2) {
                                              return Icon(
                                                FFIcons.kstep3,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else if (stepsNameIndex == 3) {
                                              return Icon(
                                                FFIcons.kstep4,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else if (stepsNameIndex == 4) {
                                              return Icon(
                                                FFIcons.kstep5,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else if (stepsNameIndex == 5) {
                                              return Icon(
                                                FFIcons.kstep6,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else if (stepsNameIndex == 6) {
                                              return Icon(
                                                FFIcons.kstep7,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            } else {
                                              return Icon(
                                                FFIcons.kstep8,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                size: 16.0,
                                              );
                                            }
                                          },
                                        );
                                      }
                                    },
                                  ),
                                  Builder(
                                    builder: (context) {
                                      if ((widget!.currentStep! >
                                              (stepsNameIndex + 1)) ||
                                          (widget!.currentStep ==
                                              (stepsNameIndex + 1))) {
                                        return Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Text(
                                              stepsNameItem,
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily: 'Inter',
                                                    color: () {
                                                      if (widget!.currentStep! >
                                                          (stepsNameIndex +
                                                              1)) {
                                                        return FlutterFlowTheme
                                                                .of(context)
                                                            .success700;
                                                      } else if (widget!
                                                              .currentStep ==
                                                          (stepsNameIndex +
                                                              1)) {
                                                        return FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryInfo500Default;
                                                      } else {
                                                        return FlutterFlowTheme
                                                                .of(context)
                                                            .neutral900;
                                                      }
                                                    }(),
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                            ),
                                            if (widget!.currentStep ==
                                                (stepsNameIndex + 1))
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        20.0, 0.0, 0.0, 0.0),
                                                child: Icon(
                                                  Icons.arrow_forward_ios_sharp,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryText,
                                                  size: 14.0,
                                                ),
                                              ),
                                          ],
                                        );
                                      } else {
                                        return Text(
                                          stepsNameItem,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                color: () {
                                                  if (widget!.currentStep! >
                                                      (stepsNameIndex + 1)) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .success700;
                                                  } else if (widget!
                                                          .currentStep ==
                                                      (stepsNameIndex + 1)) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryInfo500Default;
                                                  } else {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .neutral900;
                                                  }
                                                }(),
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.normal,
                                              ),
                                        );
                                      }
                                    },
                                  ),
                                ].divide(SizedBox(width: 8.0)),
                              ),
                            ),
                          ),
                        ),
                      ),
                      if (stepsNameItem == widget!.stepsList?.lastOrNull
                          ? !widget!.showVerticalLine
                          : widget!.showVerticalLine)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              57.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: 1.0,
                            height: 12.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).neutral400,
                            ),
                          ),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
