import '/final_l1_navigation_website/navigation_generic_stepper_vertical/navigation_generic_stepper_vertical_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:expandable/expandable.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mobile_filling_stepper_model.dart';
export 'mobile_filling_stepper_model.dart';

/// "Mobile Filling Stepper is a vertical stepper designed for the mobile
/// view.
///
///
/// It displays the steps involved in the basic details.
///
/// Parameters:
/// "1. keyPrefix:String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
/// 2.stepperHeading:String
/// Give the header of the stepper.
/// 3.currentStep:Integer;
/// Indicates the current step of the stepper
/// 4.stepList:List<String>;
/// Pass the List of strings to be displayed in the stepper.
/// 5.width:double;
/// width of the stepper
/// 6.height:double;
/// height of the stepper
/// 7.showVerticalLine:Boolean;
/// Boolean value whether to show or hide the vertical line.
/// 8.onTap:Action:Action;
/// onTap of it the respectice action will take place.
/// 9.showHeading:Boolean;
/// Boolean value to show or hide the heading"
class MobileFillingStepperWidget extends StatefulWidget {
  const MobileFillingStepperWidget({
    super.key,
    this.stepperHeading,
    this.stepsList,
    this.currentStep,
    this.width,
    this.height,
    required this.keyPrefix,
    bool? showVerticalLine,
    this.onTap,
    bool? showHeading,
  })  : this.showVerticalLine = showVerticalLine ?? true,
        this.showHeading = showHeading ?? true;

  final String? stepperHeading;
  final List<String>? stepsList;
  final int? currentStep;
  final double? width;
  final double? height;
  final String? keyPrefix;
  final bool showVerticalLine;
  final Future Function()? onTap;
  final bool showHeading;

  @override
  State<MobileFillingStepperWidget> createState() =>
      _MobileFillingStepperWidgetState();
}

class _MobileFillingStepperWidgetState
    extends State<MobileFillingStepperWidget> {
  late MobileFillingStepperModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MobileFillingStepperModel());

    _model.expandableExpandableController =
        ExpandableController(initialExpanded: false);
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // Mobile Filling Stepper is a vertical stepper designed for the mobile view.
        // It displays the steps involved in the basic details.
        Container(
      width: widget!.width,
      height: widget!.height,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 0.0),
            child: Container(
              decoration: BoxDecoration(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    color: Color(0x00000000),
                    child: ExpandableNotifier(
                      controller: _model.expandableExpandableController,
                      child: ExpandablePanel(
                        header: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  50.0, 0.0, 0.0, 4.0),
                              child: Semantics(
                                label: 'Heading of the stepper',
                                child: Text(
                                  valueOrDefault<String>(
                                    widget!.stepperHeading,
                                    'stepperHeading',
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .textPrimary,
                                        fontSize: 18.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  50.0, 0.0, 0.0, 10.0),
                              child: Text(
                                'Basic Details',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .primary600Default,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ),
                          ],
                        ),
                        collapsed: Container(),
                        expanded: Semantics(
                          label: 'Vertical stepper L1 component.',
                          child: wrapWithModel(
                            model: _model.navigationGenericStepperVerticalModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericStepperVerticalWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Mobile_Filling_Stepper',
                                      'Navigation_Generic_Stepper_Vertical')),
                              stepperHeading: widget!.stepperHeading,
                              currentStep: widget!.currentStep,
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Mobile_Filling_Stepper',
                                      'Navigation_Generic_Stepper_Vertical'),
                              showVerticalLine: true,
                              hideTrailingIcon: true,
                              showHeading: widget!.showHeading,
                              stepsList: widget!.stepsList,
                              onTap: (selectedIndex) async {
                                await widget.onTap?.call();
                              },
                            ),
                          ),
                        ),
                        theme: ExpandableThemeData(
                          tapHeaderToExpand: true,
                          tapBodyToExpand: false,
                          tapBodyToCollapse: false,
                          headerAlignment:
                              ExpandablePanelHeaderAlignment.center,
                          hasIcon: true,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
