import '/final_l1_navigation_website/navigation_generic_stepper_vertical/navigation_generic_stepper_vertical_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'mobile_filling_stepper_widget.dart' show MobileFillingStepperWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:expandable/expandable.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MobileFillingStepperModel
    extends FlutterFlowModel<MobileFillingStepperWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Expandable widget.
  late ExpandableController expandableExpandableController;

  // Model for Navigation_Generic_Stepper_Vertical component.
  late NavigationGenericStepperVerticalModel
      navigationGenericStepperVerticalModel;

  @override
  void initState(BuildContext context) {
    navigationGenericStepperVerticalModel =
        createModel(context, () => NavigationGenericStepperVerticalModel());
  }

  @override
  void dispose() {
    expandableExpandableController.dispose();
    navigationGenericStepperVerticalModel.dispose();
  }
}
