import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_stepper_vertical_model.dart';
export 'navigation_generic_stepper_vertical_model.dart';

class NavigationGenericStepperVerticalWidget extends StatefulWidget {
  const NavigationGenericStepperVerticalWidget({
    super.key,
    this.stepperHeading,
    this.stepsList,
    this.currentStep,
    required this.keyPrefix,
    bool? showVerticalLine,
    this.onTap,
    bool? hideTrailingIcon,
    bool? showHeading,
  })  : this.showVerticalLine = showVerticalLine ?? true,
        this.hideTrailingIcon = hideTrailingIcon ?? false,
        this.showHeading = showHeading ?? false;

  final String? stepperHeading;
  final List<String>? stepsList;
  final int? currentStep;
  final String? keyPrefix;
  final bool showVerticalLine;
  final Future Function(int selectedIndex)? onTap;
  final bool hideTrailingIcon;
  final bool showHeading;

  @override
  State<NavigationGenericStepperVerticalWidget> createState() =>
      _NavigationGenericStepperVerticalWidgetState();
}

class _NavigationGenericStepperVerticalWidgetState
    extends State<NavigationGenericStepperVerticalWidget> {
  late NavigationGenericStepperVerticalModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => NavigationGenericStepperVerticalModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget!.showHeading)
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 28.0, 0.0, 16.0),
                  child: Container(
                    decoration: BoxDecoration(),
                    child: Visibility(
                      visible: widget!.showHeading,
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            48.0, 0.0, 48.0, 0.0),
                        child: Text(
                          valueOrDefault<String>(
                            widget!.stepperHeading,
                            'stepperHeading',
                          ),
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textPrimary,
                                fontSize: 18.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          Divider(
            thickness: 2.0,
            color: FlutterFlowTheme.of(context).neutral300,
          ),
          Container(
            decoration: BoxDecoration(),
            child: Builder(
              builder: (context) {
                final stepsName = widget!.stepsList?.toList() ?? [];

                return Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(stepsName.length, (stepsNameIndex) {
                    final stepsNameItem = stepsName[stepsNameIndex];
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 4.0, 0.0, 4.0),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await widget.onTap?.call(
                                stepsNameIndex,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: () {
                                  if (widget!.currentStep! >
                                      (stepsNameIndex + 1)) {
                                    return Colors.transparent;
                                  } else if (widget!.currentStep ==
                                      (stepsNameIndex)) {
                                    return FlutterFlowTheme.of(context)
                                        .secondaryInfoBGStroke10;
                                  } else {
                                    return Colors.transparent;
                                  }
                                }(),
                              ),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    48.0, 14.0, 12.0, 14.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (widget!.currentStep ==
                                              stepsNameIndex)
                                            Container(
                                              width: 20.0,
                                              height: 20.0,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: widget!.currentStep ==
                                                          stepsNameIndex
                                                      ? FlutterFlowTheme.of(
                                                              context)
                                                          .secondaryInfo500Default
                                                      : Color(0x00000000),
                                                ),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width: 3.0,
                                                    height: 3.0,
                                                    decoration: BoxDecoration(
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryInfo500Default,
                                                      shape: BoxShape.circle,
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 3.0,
                                                    height: 3.0,
                                                    decoration: BoxDecoration(
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryInfo500Default,
                                                      shape: BoxShape.circle,
                                                    ),
                                                  ),
                                                ].divide(SizedBox(width: 4.0)),
                                              ),
                                            ),
                                          if (widget!.currentStep! >
                                              stepsNameIndex)
                                            Container(
                                              width: 20.0,
                                              height: 20.0,
                                              decoration: BoxDecoration(
                                                color: () {
                                                  if (widget!.currentStep! >
                                                      stepsNameIndex) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .success200;
                                                  } else if (widget!
                                                          .currentStep ==
                                                      stepsNameIndex) {
                                                    return FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryInfo500Default;
                                                  } else {
                                                    return Color(0x00000000);
                                                  }
                                                }(),
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: () {
                                                    if (widget!.currentStep ==
                                                        stepsNameIndex) {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryInfo500Default;
                                                    } else if (widget!
                                                            .currentStep! >
                                                        stepsNameIndex) {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .success700;
                                                    } else {
                                                      return Color(0x00000000);
                                                    }
                                                  }(),
                                                ),
                                              ),
                                              child: Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: FaIcon(
                                                  FontAwesomeIcons.check,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .success700,
                                                  size: 10.0,
                                                ),
                                              ),
                                            ),
                                          if (widget!.currentStep! <
                                              stepsNameIndex)
                                            Container(
                                              width: 20.0,
                                              height: 20.0,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: () {
                                                    if (widget!.currentStep ==
                                                        stepsNameIndex) {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .primary600Default;
                                                    } else if (widget!
                                                            .currentStep! >
                                                        stepsNameIndex) {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .success700;
                                                    } else {
                                                      return FlutterFlowTheme
                                                              .of(context)
                                                          .neutral700;
                                                    }
                                                  }(),
                                                ),
                                              ),
                                              child: Align(
                                                alignment: AlignmentDirectional(
                                                    0.0, 0.0),
                                                child: Text(
                                                  (stepsNameIndex + 1)
                                                      .toString(),
                                                  style:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .bodyMedium
                                                          .override(
                                                            fontFamily: 'Inter',
                                                            color: () {
                                                              if (widget!
                                                                      .currentStep ==
                                                                  stepsNameIndex) {
                                                                return FlutterFlowTheme.of(
                                                                        context)
                                                                    .primary600Default;
                                                              } else if (widget!
                                                                      .currentStep! >
                                                                  stepsNameIndex) {
                                                                return FlutterFlowTheme.of(
                                                                        context)
                                                                    .success700;
                                                              } else {
                                                                return FlutterFlowTheme.of(
                                                                        context)
                                                                    .neutral700;
                                                              }
                                                            }(),
                                                            fontSize: 10.0,
                                                            letterSpacing: 0.0,
                                                          ),
                                                ),
                                              ),
                                            ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    8.0, 0.0, 0.0, 0.0),
                                            child: Text(
                                              stepsNameItem,
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color: () {
                                                          if (widget!
                                                                  .currentStep ==
                                                              stepsNameIndex) {
                                                            return FlutterFlowTheme
                                                                    .of(context)
                                                                .secondaryInfo500Default;
                                                          } else if (widget!
                                                                  .currentStep! >
                                                              stepsNameIndex) {
                                                            return FlutterFlowTheme
                                                                    .of(context)
                                                                .success700;
                                                          } else {
                                                            return FlutterFlowTheme
                                                                    .of(context)
                                                                .neutral900;
                                                          }
                                                        }(),
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if ((widget!.currentStep ==
                                            stepsNameIndex) ||
                                        !widget!.hideTrailingIcon)
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        color: FlutterFlowTheme.of(context)
                                            .neutral800,
                                        size: 10.0,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (stepsNameItem == widget!.stepsList?.lastOrNull
                            ? !widget!.showVerticalLine
                            : widget!.showVerticalLine)
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                57.0, 0.0, 0.0, 0.0),
                            child: Container(
                              width: 1.0,
                              height: 12.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).neutral400,
                              ),
                            ),
                          ),
                      ],
                    );
                  }),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
