import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form_content_card_model.dart';
export 'form_content_card_model.dart';

/// The Form_ContentCard is a UI component designed to display specific
/// details within a form, with various customization options.
///
/// It includes a label, a description, conditional logic(e.g., "If/Then/Else"
/// condition to show Read Less & Read More option) and an actionable button
/// (e.g., "File Now >)
/// Parameters:
/// labelText:String
/// Defines the title of the form displayed at the top of card.
/// formDetails:String
/// additional details about the form.
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
/// onTap: Action
/// Define the action to be performed when the File Now Text  is tapped, It
/// will navigate to the different page.
/// width: Double
/// Sets the width of the card.
/// isGridView: Boolean
/// Determines if the card should be displayed in grid layout or not.
class FormContentCardWidget extends StatefulWidget {
  const FormContentCardWidget({
    super.key,
    this.labelText,
    this.formDetails,
    required this.keyPrefix,
    required this.onFileNow,
    bool? isGridView,
    int? maxCharacter,
  })  : this.isGridView = isGridView ?? true,
        this.maxCharacter = maxCharacter ?? 86;

  final String? labelText;
  final String? formDetails;
  final String? keyPrefix;
  final Future Function()? onFileNow;
  final bool isGridView;
  final int maxCharacter;

  @override
  State<FormContentCardWidget> createState() => _FormContentCardWidgetState();
}

class _FormContentCardWidgetState extends State<FormContentCardWidget> {
  late FormContentCardModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FormContentCardModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).neutral100,
      ),
      child: Builder(
        builder: (context) {
          if (widget!.isGridView) {
            return Container(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Form_ContentCard',
                      'GridViewContainer')),
              constraints: BoxConstraints(
                maxWidth: 231.6,
              ),
              decoration: BoxDecoration(
                border: Border.all(
                  color: FlutterFlowTheme.of(context).neutralBGStroke25,
                ),
              ),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: Semantics(
                        label: 'This is the title of the form being discussed.',
                        child: Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Form_ContentCard', 'GV_Label')),
                          valueOrDefault<String>(
                            widget!.labelText,
                            'Label',
                          ),
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).textBasic,
                                fontSize: 20.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                      child: Semantics(
                        label:
                            'This formDetails is basically explains the purpose of the Form.',
                        child: Text(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Form_ContentCard', 'GV_formDetails')),
                          valueOrDefault<String>(
                            widget!.formDetails,
                            'Form Description',
                          ).maybeHandleOverflow(
                            maxChars: _model.showFullDetails
                                ? null
                                : widget!.maxCharacter,
                            replacement: '…',
                          ),
                          maxLines: _model.showFullDetails ? null : 3,
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                fontFamily: 'Inter',
                                color: FlutterFlowTheme.of(context).neutral800,
                                fontSize: 12.0,
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                    ),
                    Semantics(
                      label:
                          'This is a clickable link that allows users to collapse or shorten the description if it is too long.',
                      child: FFButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Form_ContentCard',
                                'GV_ReadLessReadMoreButton')),
                        onPressed: () async {
                          _model.showFullDetails = !_model.showFullDetails;
                          safeSetState(() {});
                        },
                        text:
                            _model.showFullDetails ? 'Read Less' : 'Read More',
                        options: FFButtonOptions(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Colors.transparent,
                          textStyle:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryInfo500Default,
                                    letterSpacing: 0.0,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 13.0, 0.0, 16.0),
                      child: Semantics(
                        label:
                            'This is a clickable button for users to proceed with filling form online.',
                        child: FFButtonWidget(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Form_ContentCard', 'GV_FileNowButton')),
                          onPressed: () async {
                            await widget.onFileNow?.call();
                          },
                          text: 'File Now',
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            size: 15.0,
                          ),
                          options: FFButtonOptions(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            iconAlignment: IconAlignment.end,
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: Colors.transparent,
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'Inter',
                                  color: FlutterFlowTheme.of(context)
                                      .primary600Default,
                                  fontSize: 14.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                            elevation: 0.0,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          } else {
            return Container(
              key: ValueKey(
                  t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                      widget!.keyPrefix!,
                      'Form_ContentCard',
                      'ListViewContainer')),
              decoration: BoxDecoration(
                border: Border.all(
                  color: FlutterFlowTheme.of(context).neutralBGStroke25,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 16.0, 0.0, 16.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 16.0, 0.0, 0.0),
                            child: Semantics(
                              label:
                                  'This is the title of the form being discussed.',
                              child: Text(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(widget!.keyPrefix!,
                                        'Form_ContentCard', 'LV_Label')),
                                valueOrDefault<String>(
                                  widget!.labelText,
                                  'Label',
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .textBasic,
                                      fontSize: 20.0,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ),
                          ),
                          Flexible(
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 8.0, 0.0),
                                    child: Semantics(
                                      label:
                                          'This formDetails is basically explains the purpose of the Form.',
                                      child: Text(
                                        key: ValueKey(
                                            t_d_s_2_l1_logic_2wrus1_functions
                                                .generateL1KeyValue(
                                                    widget!.keyPrefix!,
                                                    'Form_ContentCard',
                                                    'LV_formDetails')),
                                        valueOrDefault<String>(
                                          widget!.formDetails,
                                          'Form Description',
                                        ).maybeHandleOverflow(
                                          maxChars: _model.showFullDetails
                                              ? null
                                              : widget!.maxCharacter,
                                          replacement: '…',
                                        ),
                                        maxLines:
                                            _model.showFullDetails ? null : 2,
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .neutral800,
                                              fontSize: 12.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                  ),
                                ),
                                Semantics(
                                  label:
                                      'This is a clickable link that allows users to collapse or shorten the description if it is too long.',
                                  child: FFButtonWidget(
                                    key: ValueKey(
                                        t_d_s_2_l1_logic_2wrus1_functions
                                            .generateL1KeyValue(
                                                widget!.keyPrefix!,
                                                'Form_ContentCard',
                                                'LV_ReadLessReadMoreBtn')),
                                    onPressed: () async {
                                      _model.showFullDetails =
                                          !_model.showFullDetails;
                                      safeSetState(() {});
                                    },
                                    text: _model.showFullDetails
                                        ? 'Read Less'
                                        : 'Read More',
                                    options: FFButtonOptions(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Colors.transparent,
                                      textStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryInfo500Default,
                                            letterSpacing: 0.0,
                                          ),
                                      elevation: 0.0,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ].divide(SizedBox(height: 8.0)),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 24.0, 0.0),
                    child: Semantics(
                      label:
                          'This is a clickable button for users to proceed with filling form online.',
                      child: FFButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Form_ContentCard', 'LV_FileNowButton')),
                        onPressed: () async {
                          await widget.onFileNow?.call();
                        },
                        text: 'File Now',
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          size: 15.0,
                        ),
                        options: FFButtonOptions(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconAlignment: IconAlignment.end,
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Colors.transparent,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    fontSize: 14.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
