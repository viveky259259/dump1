import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'navigation_generic_stepper_horizontal_widget.dart'
    show NavigationGenericStepperHorizontalWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NavigationGenericStepperHorizontalModel
    extends FlutterFlowModel<NavigationGenericStepperHorizontalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
