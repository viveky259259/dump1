import '/final_l1_navigation_common/work_list_communication_tab_bar/work_list_communication_tab_bar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'arpit_page_widget.dart' show ArpitPageWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ArpitPageModel extends FlutterFlowModel<ArpitPageWidget> {
  ///  Local state fields for this page.

  int curSelected = 0;

  ///  State fields for stateful widgets in this page.

  // Model for WorkListCommunicationTabBar component.
  late WorkListCommunicationTabBarModel workListCommunicationTabBarModel;

  @override
  void initState(BuildContext context) {
    workListCommunicationTabBarModel =
        createModel(context, () => WorkListCommunicationTabBarModel());
  }

  @override
  void dispose() {
    workListCommunicationTabBarModel.dispose();
  }
}
