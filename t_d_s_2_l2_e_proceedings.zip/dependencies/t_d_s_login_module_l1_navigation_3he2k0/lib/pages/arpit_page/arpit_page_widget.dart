import '/final_l1_navigation_common/work_list_communication_tab_bar/work_list_communication_tab_bar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'arpit_page_model.dart';
export 'arpit_page_model.dart';

class ArpitPageWidget extends StatefulWidget {
  const ArpitPageWidget({super.key});

  @override
  State<ArpitPageWidget> createState() => _ArpitPageWidgetState();
}

class _ArpitPageWidgetState extends State<ArpitPageWidget> {
  late ArpitPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ArpitPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.workListCommunicationTabBarModel,
                updateCallback: () => safeSetState(() {}),
                child: WorkListCommunicationTabBarWidget(
                  keyPrefix: 'k',
                  buttonTexts: ["1", "2", "3"],
                  callBackAction: (selectedIndex) async {
                    _model.curSelected = selectedIndex;
                    safeSetState(() {});
                  },
                ),
              ),
              Text(
                _model.curSelected.toString(),
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
