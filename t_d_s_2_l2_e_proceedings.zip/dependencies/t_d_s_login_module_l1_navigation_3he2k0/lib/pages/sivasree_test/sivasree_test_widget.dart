import '/final_l1_navigation_a_o_portal/toggle_switchh/toggle_switchh_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'sivasree_test_model.dart';
export 'sivasree_test_model.dart';

class SivasreeTestWidget extends StatefulWidget {
  const SivasreeTestWidget({super.key});

  @override
  State<SivasreeTestWidget> createState() => _SivasreeTestWidgetState();
}

class _SivasreeTestWidgetState extends State<SivasreeTestWidget> {
  late SivasreeTestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SivasreeTestModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.toggleSwitchhModel,
                updateCallback: () => safeSetState(() {}),
                child: ToggleSwitchhWidget(
                  keyPrefix: 'koko',
                  activeIndex: 1,
                  onClick: () async {},
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
