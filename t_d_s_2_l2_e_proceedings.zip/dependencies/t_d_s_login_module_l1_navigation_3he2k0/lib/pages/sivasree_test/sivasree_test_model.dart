import '/final_l1_navigation_a_o_portal/toggle_switchh/toggle_switchh_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'sivasree_test_widget.dart' show SivasreeTestWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SivasreeTestModel extends FlutterFlowModel<SivasreeTestWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Toggle_Switchh component.
  late ToggleSwitchhModel toggleSwitchhModel;

  @override
  void initState(BuildContext context) {
    toggleSwitchhModel = createModel(context, () => ToggleSwitchhModel());
  }

  @override
  void dispose() {
    toggleSwitchhModel.dispose();
  }
}
