import '/backend/schema/structs/index.dart';
import '/final_l1_navigation_website/generic_header_website/generic_header_website_widget.dart';
import '/final_l1_navigation_website/generic_menu_bar_website/generic_menu_bar_website_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'varshini_test_page_widget.dart' show VarshiniTestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VarshiniTestPageModel extends FlutterFlowModel<VarshiniTestPageWidget> {
  ///  Local state fields for this page.

  List<MenuItemStruct> menu = [];
  void addToMenu(MenuItemStruct item) => menu.add(item);
  void removeFromMenu(MenuItemStruct item) => menu.remove(item);
  void removeAtIndexFromMenu(int index) => menu.removeAt(index);
  void insertAtIndexInMenu(int index, MenuItemStruct item) =>
      menu.insert(index, item);
  void updateMenuAtIndex(int index, Function(MenuItemStruct) updateFn) =>
      menu[index] = updateFn(menu[index]);

  List<MenuItemStruct> subMenu = [];
  void addToSubMenu(MenuItemStruct item) => subMenu.add(item);
  void removeFromSubMenu(MenuItemStruct item) => subMenu.remove(item);
  void removeAtIndexFromSubMenu(int index) => subMenu.removeAt(index);
  void insertAtIndexInSubMenu(int index, MenuItemStruct item) =>
      subMenu.insert(index, item);
  void updateSubMenuAtIndex(int index, Function(MenuItemStruct) updateFn) =>
      subMenu[index] = updateFn(subMenu[index]);

  ///  State fields for stateful widgets in this page.

  // Model for Generic_Header_Website component.
  late GenericHeaderWebsiteModel genericHeaderWebsiteModel;
  // Model for Generic_MenuBar_Website component.
  late GenericMenuBarWebsiteModel genericMenuBarWebsiteModel;
  // State field(s) for Switch widget.
  bool? switchValue;

  @override
  void initState(BuildContext context) {
    genericHeaderWebsiteModel =
        createModel(context, () => GenericHeaderWebsiteModel());
    genericMenuBarWebsiteModel =
        createModel(context, () => GenericMenuBarWebsiteModel());
  }

  @override
  void dispose() {
    genericHeaderWebsiteModel.dispose();
    genericMenuBarWebsiteModel.dispose();
  }
}
