import '/backend/schema/structs/index.dart';
import '/final_l1_navigation_website/generic_header_website/generic_header_website_widget.dart';
import '/final_l1_navigation_website/generic_menu_bar_website/generic_menu_bar_website_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'varshini_test_page_model.dart';
export 'varshini_test_page_model.dart';

class VarshiniTestPageWidget extends StatefulWidget {
  const VarshiniTestPageWidget({super.key});

  @override
  State<VarshiniTestPageWidget> createState() => _VarshiniTestPageWidgetState();
}

class _VarshiniTestPageWidgetState extends State<VarshiniTestPageWidget> {
  late VarshiniTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VarshiniTestPageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.addToMenu(MenuItemStruct(
        name: 'E-file view',
        navigateTo: '',
        subMenu: _model.subMenu,
      ));
      _model.addToSubMenu(MenuItemStruct(
        name: 'File Forms',
        navigateTo: '/forms',
      ));
      safeSetState(() {});
    });

    _model.switchValue = true;
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              wrapWithModel(
                model: _model.genericHeaderWebsiteModel,
                updateCallback: () => safeSetState(() {}),
                child: GenericHeaderWebsiteWidget(
                  keyPrefix: 'key',
                  isUserLoggedIn: false,
                  onTapAction: () async {},
                ),
              ),
              wrapWithModel(
                model: _model.genericMenuBarWebsiteModel,
                updateCallback: () => safeSetState(() {}),
                updateOnChange: true,
                child: GenericMenuBarWebsiteWidget(
                  keyPrefix: 'key',
                  menuItems: _model.menu,
                  isUserLoggedIn: false,
                  onTap: () async {},
                ),
              ),
              Switch.adaptive(
                value: _model.switchValue!,
                onChanged: (newValue) async {
                  safeSetState(() => _model.switchValue = newValue!);
                },
                activeColor: FlutterFlowTheme.of(context).primary,
                inactiveTrackColor: FlutterFlowTheme.of(context).alternate,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
