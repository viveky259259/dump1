import '/final_l1_navigation_a_o_portal/generic_data_points_a_o_portal/generic_data_points_a_o_portal_widget.dart';
import '/final_l1_navigation_common/navigation_generic_breadcrumbs/navigation_generic_breadcrumbs_widget.dart';
import '/final_l1_navigation_website/form_content_card/form_content_card_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'deep_test_page_model.dart';
export 'deep_test_page_model.dart';

class DeepTestPageWidget extends StatefulWidget {
  const DeepTestPageWidget({super.key});

  @override
  State<DeepTestPageWidget> createState() => _DeepTestPageWidgetState();
}

class _DeepTestPageWidgetState extends State<DeepTestPageWidget> {
  late DeepTestPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DeepTestPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                wrapWithModel(
                  model: _model.navigationGenericBreadcrumbsModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericBreadcrumbsWidget(
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            'keyPrefix',
                            'DeepTestPage',
                            'Navigation_Generic_Breadcrumbs'),
                    listItems: ['Home', 'Registration'],
                    onItemTap: (index) async {},
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    wrapWithModel(
                      model: _model.genericDataPointsAOPortalModel1,
                      updateCallback: () => safeSetState(() {}),
                      child: GenericDataPointsAOPortalWidget(
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue('keyPrefix', 'DeepTestPage',
                                'Generic_DataPoints_AO_Portal'),
                        isPositive: true,
                        amount: '50,000',
                        labelText: 'Total Requests',
                      ),
                    ),
                    wrapWithModel(
                      model: _model.genericDataPointsAOPortalModel2,
                      updateCallback: () => safeSetState(() {}),
                      child: GenericDataPointsAOPortalWidget(
                        keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue('keyPrefix', 'DeepTestPage',
                                'Generic_DataPoints_AO_Portal'),
                        isPositive: false,
                        amount: '30,000',
                        labelText: 'Pending Requests',
                      ),
                    ),
                  ].divide(SizedBox(width: 50.0)),
                ),
                wrapWithModel(
                  model: _model.formContentCardModel1,
                  updateCallback: () => safeSetState(() {}),
                  child: FormContentCardWidget(
                    labelText: 'Form 15C',
                    formDetails:
                        'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            'keyPrefix', 'DeepTestPage', 'Form_ContentCard'),
                    isGridView: _model.isGrid,
                    onFileNow: () async {},
                  ),
                ),
                wrapWithModel(
                  model: _model.formContentCardModel2,
                  updateCallback: () => safeSetState(() {}),
                  child: FormContentCardWidget(
                    labelText: 'Form 15C',
                    formDetails:
                        'Application by a banking company or insurer for a certificate under Section 195(3) of the Income-tax Act, 1961, for receipt of interest and other sums without deduction of tax.',
                    keyPrefix:
                        t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                            'keyPrefix', 'DeepTestPage', 'Form_ContentCard'),
                    isGridView: !_model.isGrid,
                    onFileNow: () async {},
                  ),
                ),
              ]
                  .divide(SizedBox(height: 50.0))
                  .addToStart(SizedBox(height: 50.0)),
            ),
          ),
        ),
      ),
    );
  }
}
