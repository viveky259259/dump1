import '/final_l1_navigation_a_o_portal/generic_data_points_a_o_portal/generic_data_points_a_o_portal_widget.dart';
import '/final_l1_navigation_common/navigation_generic_breadcrumbs/navigation_generic_breadcrumbs_widget.dart';
import '/final_l1_navigation_website/form_content_card/form_content_card_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'deep_test_page_widget.dart' show DeepTestPageWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DeepTestPageModel extends FlutterFlowModel<DeepTestPageWidget> {
  ///  Local state fields for this page.

  bool isGrid = true;

  ///  State fields for stateful widgets in this page.

  // Model for Navigation_Generic_Breadcrumbs component.
  late NavigationGenericBreadcrumbsModel navigationGenericBreadcrumbsModel;
  // Model for Generic_DataPoints_AO_Portal component.
  late GenericDataPointsAOPortalModel genericDataPointsAOPortalModel1;
  // Model for Generic_DataPoints_AO_Portal component.
  late GenericDataPointsAOPortalModel genericDataPointsAOPortalModel2;
  // Model for Form_ContentCard component.
  late FormContentCardModel formContentCardModel1;
  // Model for Form_ContentCard component.
  late FormContentCardModel formContentCardModel2;

  @override
  void initState(BuildContext context) {
    navigationGenericBreadcrumbsModel =
        createModel(context, () => NavigationGenericBreadcrumbsModel());
    genericDataPointsAOPortalModel1 =
        createModel(context, () => GenericDataPointsAOPortalModel());
    genericDataPointsAOPortalModel2 =
        createModel(context, () => GenericDataPointsAOPortalModel());
    formContentCardModel1 = createModel(context, () => FormContentCardModel());
    formContentCardModel2 = createModel(context, () => FormContentCardModel());
  }

  @override
  void dispose() {
    navigationGenericBreadcrumbsModel.dispose();
    genericDataPointsAOPortalModel1.dispose();
    genericDataPointsAOPortalModel2.dispose();
    formContentCardModel1.dispose();
    formContentCardModel2.dispose();
  }
}
