import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'do_not_click_on_this_page_create_your_own_project_widget.dart'
    show DoNotClickOnThisPageCreateYourOwnProjectWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DoNotClickOnThisPageCreateYourOwnProjectModel
    extends FlutterFlowModel<DoNotClickOnThisPageCreateYourOwnProjectWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
