import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'saurabh_test_page_widget.dart' show SaurabhTestPageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SaurabhTestPageModel extends FlutterFlowModel<SaurabhTestPageWidget> {
  ///  Local state fields for this page.

  List<String> listOfBreads = ['Home'];
  void addToListOfBreads(String item) => listOfBreads.add(item);
  void removeFromListOfBreads(String item) => listOfBreads.remove(item);
  void removeAtIndexFromListOfBreads(int index) => listOfBreads.removeAt(index);
  void insertAtIndexInListOfBreads(int index, String item) =>
      listOfBreads.insert(index, item);
  void updateListOfBreadsAtIndex(int index, Function(String) updateFn) =>
      listOfBreads[index] = updateFn(listOfBreads[index]);

  String currentPage = 'Register';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
