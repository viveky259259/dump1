import '/components/alert_content_form15_c_traces_widget.dart';
import '/components/confirmation_alert_dialog_form15_c_widget.dart';
import '/components/confirmation_alert_dialog_widget.dart';
import '/final_l1_navigation_a_o_portal/menu_bar_genric_registration/menu_bar_genric_registration_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'anurag_page_model.dart';
export 'anurag_page_model.dart';

class AnuragPageWidget extends StatefulWidget {
  const AnuragPageWidget({super.key});

  @override
  State<AnuragPageWidget> createState() => _AnuragPageWidgetState();
}

class _AnuragPageWidgetState extends State<AnuragPageWidget> {
  late AnuragPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AnuragPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              wrapWithModel(
                model: _model.menuBarGenricRegistrationModel,
                updateCallback: () => safeSetState(() {}),
                child: MenuBarGenricRegistrationWidget(
                  keyPrefix: 'Menubar',
                  onTapHome: () async {},
                  onTapAboutUs: () async {},
                  onTapLMS: () async {},
                  onTapHelp: () async {},
                  onTapRelatedLinks: () async {},
                  onTapUtilities: () async {},
                  onTapSearch: () async {},
                ),
              ),
              Builder(
                builder: (context) => FFButtonWidget(
                  onPressed: () async {
                    await showDialog(
                      barrierColor: FlutterFlowTheme.of(context).tertiary,
                      context: context,
                      builder: (dialogContext) {
                        return Dialog(
                          elevation: 0,
                          insetPadding: EdgeInsets.zero,
                          backgroundColor: Colors.transparent,
                          alignment: AlignmentDirectional(0.0, 0.0)
                              .resolve(Directionality.of(context)),
                          child: GestureDetector(
                            onTap: () {
                              FocusScope.of(dialogContext).unfocus();
                              FocusManager.instance.primaryFocus?.unfocus();
                            },
                            child: Container(
                              height: MediaQuery.sizeOf(context).height * 0.5,
                              width: 408.0,
                              child: ConfirmationAlertDialogForm15CWidget(
                                alertBoxTitle:
                                    'Please confirm if you want to proceed.',
                                keyPrefix: 'keyPrefix',
                                alertBoxContent:
                                    'You have files uploaded in this section. If you choose to proceed, all the uploaded files will be removed permanently.',
                                showCancelAndConfirmButton: true,
                                onTapExit: () async {},
                                onTapSave: () async {},
                                onTapCancel: () async {},
                                onTapConfirm: () async {},
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                  text: 'Unsave changes',
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Inter',
                          color: Colors.white,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
              Builder(
                builder: (context) => FFButtonWidget(
                  onPressed: () async {
                    await showDialog(
                      barrierColor: FlutterFlowTheme.of(context).tertiary,
                      context: context,
                      builder: (dialogContext) {
                        return Dialog(
                          elevation: 0,
                          insetPadding: EdgeInsets.zero,
                          backgroundColor: Colors.transparent,
                          alignment: AlignmentDirectional(0.0, 0.0)
                              .resolve(Directionality.of(context)),
                          child: GestureDetector(
                            onTap: () {
                              FocusScope.of(dialogContext).unfocus();
                              FocusManager.instance.primaryFocus?.unfocus();
                            },
                            child: Container(
                              height: 484.0,
                              width: 848.0,
                              child: ConfirmationAlertDialogWidget(
                                alertBoxTitle: 'What is Form 15C?',
                                keyPrefix: 'keyPrefix',
                                showSingleButton: true,
                                onTapConfirm: () async {},
                                onTapCancel: () async {},
                                alertContent: () =>
                                    AlertContentForm15CTracesWidget(
                                  bulletPoints: [
                                    "This Form is relevant to a person concerned, which is a banking company or Insurer which is neither an Indian Company nor a company which has made the prescribed arrangements for the declaration and payment of dividends.",
                                    "This Form is relevant to a person concerned, which is a banking company or Insurer which is neither an Indian Company nor a company which has made the prescribed arrangements for the declaration and payment of dividends."
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                  text: 'Pop up',
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Inter',
                          color: Colors.white,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            ].divide(SizedBox(height: 20.0)),
          ),
        ),
      ),
    );
  }
}
