import '/components/alert_content_form15_c_traces_widget.dart';
import '/components/confirmation_alert_dialog_form15_c_widget.dart';
import '/components/confirmation_alert_dialog_widget.dart';
import '/final_l1_navigation_a_o_portal/menu_bar_genric_registration/menu_bar_genric_registration_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'anurag_page_widget.dart' show AnuragPageWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AnuragPageModel extends FlutterFlowModel<AnuragPageWidget> {
  ///  Local state fields for this page.

  int currentPageIndex = 0;

  ///  State fields for stateful widgets in this page.

  // Model for MenuBar_Genric_Registration component.
  late MenuBarGenricRegistrationModel menuBarGenricRegistrationModel;

  @override
  void initState(BuildContext context) {
    menuBarGenricRegistrationModel =
        createModel(context, () => MenuBarGenricRegistrationModel());
  }

  @override
  void dispose() {
    menuBarGenricRegistrationModel.dispose();
  }
}
