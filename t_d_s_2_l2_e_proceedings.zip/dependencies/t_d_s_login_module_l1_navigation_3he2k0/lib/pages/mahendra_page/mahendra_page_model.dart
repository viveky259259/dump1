import '/final_l1_navigation_common/navigation_generic_change_password_side_menu/navigation_generic_change_password_side_menu_widget.dart';
import '/final_l1_navigation_website/navigation_generic_stepper_vertical/navigation_generic_stepper_vertical_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'mahendra_page_widget.dart' show MahendraPageWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MahendraPageModel extends FlutterFlowModel<MahendraPageWidget> {
  ///  Local state fields for this page.

  int? currentItemNo = 0;

  int? currentItem = 0;

  ///  State fields for stateful widgets in this page.

  // Model for Navigation_Generic_Stepper_Vertical component.
  late NavigationGenericStepperVerticalModel
      navigationGenericStepperVerticalModel;
  // Model for Navigation_Generic_ChangePassword_Side_Menu component.
  late NavigationGenericChangePasswordSideMenuModel
      navigationGenericChangePasswordSideMenuModel;

  @override
  void initState(BuildContext context) {
    navigationGenericStepperVerticalModel =
        createModel(context, () => NavigationGenericStepperVerticalModel());
    navigationGenericChangePasswordSideMenuModel = createModel(
        context, () => NavigationGenericChangePasswordSideMenuModel());
  }

  @override
  void dispose() {
    navigationGenericStepperVerticalModel.dispose();
    navigationGenericChangePasswordSideMenuModel.dispose();
  }
}
