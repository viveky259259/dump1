import '/final_l1_navigation_common/navigation_generic_change_password_side_menu/navigation_generic_change_password_side_menu_widget.dart';
import '/final_l1_navigation_website/navigation_generic_stepper_vertical/navigation_generic_stepper_vertical_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'mahendra_page_model.dart';
export 'mahendra_page_model.dart';

class MahendraPageWidget extends StatefulWidget {
  const MahendraPageWidget({super.key});

  @override
  State<MahendraPageWidget> createState() => _MahendraPageWidgetState();
}

class _MahendraPageWidgetState extends State<MahendraPageWidget> {
  late MahendraPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MahendraPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                decoration: BoxDecoration(),
                child: wrapWithModel(
                  model: _model.navigationGenericStepperVerticalModel,
                  updateCallback: () => safeSetState(() {}),
                  child: NavigationGenericStepperVerticalWidget(
                    stepperHeading: 'Heading',
                    currentStep: _model.currentItemNo,
                    keyPrefix: 'key',
                    showVerticalLine: true,
                    hideTrailingIcon: true,
                    showHeading: true,
                    stepsList: ["one", "two"],
                    onTap: (selectedIndex) async {
                      _model.currentItemNo = selectedIndex;
                      safeSetState(() {});
                    },
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      wrapWithModel(
                        model:
                            _model.navigationGenericChangePasswordSideMenuModel,
                        updateCallback: () => safeSetState(() {}),
                        child: NavigationGenericChangePasswordSideMenuWidget(
                          keyPrefix: 'keyPrefix',
                          currentItem: _model.currentItem,
                          menuList: [
                            "Taxpayer Details",
                            "Communication Details",
                            "Authorised Person",
                            "Signature",
                            "Change Password",
                            "Deactivate Account"
                          ],
                          onTab: (selectedIndex) async {
                            _model.currentItem = selectedIndex;
                            safeSetState(() {});
                          },
                        ),
                      ),
                      FFButtonWidget(
                        onPressed: () async {
                          _model.currentItem = _model.currentItem! + 1;
                          safeSetState(() {});
                        },
                        text: 'Button',
                        options: FFButtonOptions(
                          height: 40.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 0.0, 16.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.white,
                                    letterSpacing: 0.0,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
