import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_tertiary_button_model.dart';
export 'navigation_generic_tertiary_button_model.dart';

class NavigationGenericTertiaryButtonWidget extends StatefulWidget {
  const NavigationGenericTertiaryButtonWidget({
    super.key,
    required this.states,
    required this.labelText,
    required this.keyPrefix,
    this.height,
    this.width,
    this.leftIcon,
    required this.onTap,
  });

  final ButtonState? states;
  final String? labelText;
  final String? keyPrefix;
  final double? height;
  final double? width;
  final Widget? leftIcon;
  final Future Function()? onTap;

  @override
  State<NavigationGenericTertiaryButtonWidget> createState() =>
      _NavigationGenericTertiaryButtonWidgetState();
}

class _NavigationGenericTertiaryButtonWidgetState
    extends State<NavigationGenericTertiaryButtonWidget> {
  late NavigationGenericTertiaryButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NavigationGenericTertiaryButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        if (widget!.leftIcon != null) {
          return FFButtonWidget(
            onPressed: (widget!.states == ButtonState.disabled)
                ? null
                : () async {
                    await widget.onTap?.call();
                  },
            text: 'Button',
            icon: widget!.leftIcon,
            options: FFButtonOptions(
              width: widget!.width,
              height: valueOrDefault<double>(
                widget!.height,
                36.0,
              ),
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
              iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
              color: valueOrDefault<Color>(
                () {
                  if (widget!.states == ButtonState.byDefault) {
                    return Colors.transparent;
                  } else if (widget!.states == ButtonState.selected) {
                    return FlutterFlowTheme.of(context).primaryBGStroke10;
                  } else if (widget!.states == ButtonState.loading) {
                    return FlutterFlowTheme.of(context).primaryBGStroke5;
                  } else if (widget!.states == ButtonState.focused) {
                    return FlutterFlowTheme.of(context).neutral100;
                  } else if (widget!.states == ButtonState.disabled) {
                    return Colors.transparent;
                  } else {
                    return FlutterFlowTheme.of(context).neutral100;
                  }
                }(),
                FlutterFlowTheme.of(context).neutral100,
              ),
              textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                    fontFamily: 'Inter',
                    color: valueOrDefault<Color>(
                      () {
                        if (widget!.states == ButtonState.byDefault) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else if (widget!.states == ButtonState.selected) {
                          return FlutterFlowTheme.of(context).primary800;
                        } else if (widget!.states == ButtonState.loading) {
                          return FlutterFlowTheme.of(context).primary700;
                        } else if (widget!.states == ButtonState.focused) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else {
                          return FlutterFlowTheme.of(context).primary600Default;
                        }
                      }(),
                      FlutterFlowTheme.of(context).primary600Default,
                    ),
                    fontSize: 14.0,
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.w500,
                  ),
              elevation: 0.0,
              borderSide: BorderSide(
                color: Colors.transparent,
              ),
              borderRadius: BorderRadius.circular(4.0),
              disabledColor: Colors.transparent,
              disabledTextColor: FlutterFlowTheme.of(context).textDisabled,
              hoverColor: FlutterFlowTheme.of(context).primaryBGStroke5,
              hoverTextColor: FlutterFlowTheme.of(context).primary700,
            ),
          );
        } else {
          return FFButtonWidget(
            onPressed: (widget!.states == ButtonState.disabled)
                ? null
                : () async {
                    await widget.onTap?.call();
                  },
            text: 'Button',
            options: FFButtonOptions(
              width: widget!.width,
              height: valueOrDefault<double>(
                widget!.height,
                36.0,
              ),
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
              iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
              color: valueOrDefault<Color>(
                () {
                  if (widget!.states == ButtonState.byDefault) {
                    return Colors.transparent;
                  } else if (widget!.states == ButtonState.selected) {
                    return FlutterFlowTheme.of(context).primaryBGStroke10;
                  } else if (widget!.states == ButtonState.loading) {
                    return FlutterFlowTheme.of(context).primaryBGStroke5;
                  } else if (widget!.states == ButtonState.focused) {
                    return FlutterFlowTheme.of(context).neutral100;
                  } else if (widget!.states == ButtonState.disabled) {
                    return FlutterFlowTheme.of(context).neutral100;
                  } else {
                    return FlutterFlowTheme.of(context).neutral100;
                  }
                }(),
                FlutterFlowTheme.of(context).neutral100,
              ),
              textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                    fontFamily: 'Inter',
                    color: valueOrDefault<Color>(
                      () {
                        if (widget!.states == ButtonState.byDefault) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else if (widget!.states == ButtonState.selected) {
                          return FlutterFlowTheme.of(context).primary800;
                        } else if (widget!.states == ButtonState.loading) {
                          return FlutterFlowTheme.of(context).primary700;
                        } else if (widget!.states == ButtonState.focused) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else {
                          return FlutterFlowTheme.of(context).primary600Default;
                        }
                      }(),
                      FlutterFlowTheme.of(context).primary600Default,
                    ),
                    fontSize: 14.0,
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.w500,
                  ),
              elevation: 0.0,
              borderRadius: BorderRadius.circular(4.0),
              disabledColor: FlutterFlowTheme.of(context).neutral100,
              disabledTextColor: FlutterFlowTheme.of(context).textDisabled,
              hoverColor: FlutterFlowTheme.of(context).primaryBGStroke5,
              hoverTextColor: FlutterFlowTheme.of(context).primary700,
            ),
          );
        }
      },
    );
  }
}
