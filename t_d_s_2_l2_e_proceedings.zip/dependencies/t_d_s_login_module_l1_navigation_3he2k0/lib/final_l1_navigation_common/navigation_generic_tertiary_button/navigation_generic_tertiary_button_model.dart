import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'navigation_generic_tertiary_button_widget.dart'
    show NavigationGenericTertiaryButtonWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NavigationGenericTertiaryButtonModel
    extends FlutterFlowModel<NavigationGenericTertiaryButtonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
