import '/flutter_flow/flutter_flow_util.dart';
import 'dropdown_menu_button_widget.dart' show DropdownMenuButtonWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DropdownMenuButtonModel
    extends FlutterFlowModel<DropdownMenuButtonWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for MouseRegion widget.
  bool mouseRegionHovered = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
