import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dropdown_menu_button_model.dart';
export 'dropdown_menu_button_model.dart';

/// This 'DropDown_MenuButton' component is likely part of a larger UI,
/// providing a dropdown functionality that displays option upon interaction.
///
/// This button is created by using MouseRegion which Adds hover or mouse
/// interaction functionality, which has container and text that displays the
/// button's label or text.
/// OnTap:( Action)
/// when the container is tapped then a specific action is triggered.
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
class DropdownMenuButtonWidget extends StatefulWidget {
  const DropdownMenuButtonWidget({
    super.key,
    this.buttonText,
    required this.onTap,
    required this.keyPrefix,
  });

  final String? buttonText;
  final Future Function()? onTap;
  final String? keyPrefix;

  @override
  State<DropdownMenuButtonWidget> createState() =>
      _DropdownMenuButtonWidgetState();
}

class _DropdownMenuButtonWidgetState extends State<DropdownMenuButtonWidget> {
  late DropdownMenuButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DropdownMenuButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      opaque: false,
      cursor: MouseCursor.defer ?? MouseCursor.defer,
      child: InkWell(
        splashColor: Colors.transparent,
        focusColor: Colors.transparent,
        hoverColor: Colors.transparent,
        highlightColor: Colors.transparent,
        onTap: () async {
          await widget.onTap?.call();
        },
        child: Container(
          width: 208.0,
          height: 30.0,
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(0.0),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(8.0, 6.0, 8.0, 6.0),
            child: Semantics(
              label:
                  'This is a  button text that displays the button\'s label or text.',
              child: Text(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Dropdown_MenuButton',
                        'buttonText')),
                valueOrDefault<String>(
                  widget!.buttonText,
                  'buttonLabel',
                ),
                textAlign: TextAlign.start,
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      color: _model.mouseRegionHovered!
                          ? FlutterFlowTheme.of(context).secondaryInfo700
                          : FlutterFlowTheme.of(context).neutral900,
                      letterSpacing: 0.0,
                    ),
              ),
            ),
          ),
        ),
      ),
      onEnter: ((event) async {
        safeSetState(() => _model.mouseRegionHovered = true);
      }),
      onExit: ((event) async {
        safeSetState(() => _model.mouseRegionHovered = false);
      }),
    );
  }
}
