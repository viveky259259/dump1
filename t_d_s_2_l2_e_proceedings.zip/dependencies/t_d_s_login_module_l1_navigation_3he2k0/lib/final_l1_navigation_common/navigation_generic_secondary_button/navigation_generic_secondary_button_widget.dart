import '/backend/schema/enums/enums.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_secondary_button_model.dart';
export 'navigation_generic_secondary_button_model.dart';

/// "A versatile secondary button component designed for various action needs.
///
///
///
/// Parameters:
/// states: Enum : ButtonState
/// Pass the state of the button based on the given enum.
/// leftIcon: Icon
/// Pass left Icon for the button.
/// rightIcon: Icon
/// Pass right Icon for the button.
/// labelText: String
/// The text displayed on the button.
/// onTap: Action
/// The action to be performed when the button is pressed.
/// width: double
/// The width of the button.
/// height: double
/// The height of the button.
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for the button, useful
/// for testing or tracking
/// ."
class NavigationGenericSecondaryButtonWidget extends StatefulWidget {
  const NavigationGenericSecondaryButtonWidget({
    super.key,
    this.rightIcon,
    required this.labelText,
    required this.onTap,
    required this.keyPrefix,
    this.width,
    this.height,
    this.leftIcon,
    required this.states,
  });

  final Widget? rightIcon;
  final String? labelText;
  final Future Function()? onTap;
  final String? keyPrefix;
  final double? width;
  final double? height;
  final Widget? leftIcon;
  final ButtonState? states;

  @override
  State<NavigationGenericSecondaryButtonWidget> createState() =>
      _NavigationGenericSecondaryButtonWidgetState();
}

class _NavigationGenericSecondaryButtonWidgetState
    extends State<NavigationGenericSecondaryButtonWidget> {
  late NavigationGenericSecondaryButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => NavigationGenericSecondaryButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label:
          'If the left icon is passed then Secondary Button with leftIcon will be rendered \nIf no icon is passed or right icon is passed Secondary Button with right icon or no icon Button will be rendered.',
      child: Builder(
        builder: (context) {
          if (widget!.rightIcon != null) {
            return Semantics(
              label:
                  'Secondary Button with left icon will be displayed if left icon is passed',
              child: FFButtonWidget(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Navigation_Generic_Secondary_Button',
                        'Secondary_Button_Right_Icon')),
                onPressed: (widget!.states == ButtonState.disabled)
                    ? null
                    : () async {
                        await widget.onTap?.call();
                      },
                text: widget!.labelText!,
                icon: widget!.rightIcon,
                options: FFButtonOptions(
                  width: widget!.width,
                  height: valueOrDefault<double>(
                    widget!.height,
                    36.0,
                  ),
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  iconAlignment: IconAlignment.end,
                  iconPadding:
                      EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                  color: valueOrDefault<Color>(
                    () {
                      if (widget!.states == ButtonState.byDefault) {
                        return FlutterFlowTheme.of(context).neutral100;
                      } else if (widget!.states == ButtonState.selected) {
                        return FlutterFlowTheme.of(context).primaryBGStroke10;
                      } else if (widget!.states == ButtonState.loading) {
                        return FlutterFlowTheme.of(context).primaryBGStroke5;
                      } else if (widget!.states == ButtonState.focused) {
                        return FlutterFlowTheme.of(context).neutral100;
                      } else if (widget!.states == ButtonState.disabled) {
                        return FlutterFlowTheme.of(context).neutral100;
                      } else {
                        return FlutterFlowTheme.of(context).neutral100;
                      }
                    }(),
                    FlutterFlowTheme.of(context).neutral100,
                  ),
                  textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                        fontFamily: 'Inter',
                        color: valueOrDefault<Color>(
                          () {
                            if (widget!.states == ButtonState.byDefault) {
                              return FlutterFlowTheme.of(context)
                                  .primary600Default;
                            } else if (widget!.states == ButtonState.selected) {
                              return FlutterFlowTheme.of(context).primary800;
                            } else if (widget!.states == ButtonState.loading) {
                              return FlutterFlowTheme.of(context).primary700;
                            } else if (widget!.states == ButtonState.focused) {
                              return FlutterFlowTheme.of(context)
                                  .primary600Default;
                            } else {
                              return FlutterFlowTheme.of(context)
                                  .primary600Default;
                            }
                          }(),
                          FlutterFlowTheme.of(context).primary600Default,
                        ),
                        fontSize: 14.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                      ),
                  elevation: 0.0,
                  borderSide: BorderSide(
                    color: valueOrDefault<Color>(
                      () {
                        if (widget!.states == ButtonState.byDefault) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else if (widget!.states == ButtonState.selected) {
                          return FlutterFlowTheme.of(context).primary800;
                        } else if (widget!.states == ButtonState.loading) {
                          return FlutterFlowTheme.of(context).primary700;
                        } else if (widget!.states == ButtonState.focused) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else if (widget!.states == ButtonState.disabled) {
                          return FlutterFlowTheme.of(context).textDisabled;
                        } else {
                          return FlutterFlowTheme.of(context).primary600Default;
                        }
                      }(),
                      FlutterFlowTheme.of(context).primary600Default,
                    ),
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(4.0),
                  disabledColor: FlutterFlowTheme.of(context).neutral100,
                  disabledTextColor: FlutterFlowTheme.of(context).textDisabled,
                  hoverColor: FlutterFlowTheme.of(context).primaryBGStroke5,
                  hoverBorderSide: BorderSide(
                    color: FlutterFlowTheme.of(context).primary700,
                    width: 1.0,
                  ),
                  hoverTextColor: FlutterFlowTheme.of(context).primary700,
                ),
                showLoadingIndicator: widget!.states == ButtonState.loading,
              ),
            );
          } else {
            return Semantics(
              label:
                  'Secondary button with right icon will be displayed if right icon is passed.\nIf no icon is passed secondary button without any icon will be displayed.',
              child: FFButtonWidget(
                key: ValueKey(
                    t_d_s_2_l1_logic_2wrus1_functions.generateL1KeyValue(
                        widget!.keyPrefix!,
                        'Navigation_Generic_Secondary_Button',
                        'Secondary_Button_Left_Icon_Or_No_Icon')),
                onPressed: (widget!.states == ButtonState.disabled)
                    ? null
                    : () async {
                        await widget.onTap?.call();
                      },
                text: widget!.labelText!,
                icon: widget!.leftIcon,
                options: FFButtonOptions(
                  width: widget!.width,
                  height: valueOrDefault<double>(
                    widget!.height,
                    36.0,
                  ),
                  padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                  iconPadding:
                      EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                  color: valueOrDefault<Color>(
                    () {
                      if (widget!.states == ButtonState.byDefault) {
                        return FlutterFlowTheme.of(context).neutral100;
                      } else if (widget!.states == ButtonState.selected) {
                        return FlutterFlowTheme.of(context).primaryBGStroke10;
                      } else if (widget!.states == ButtonState.loading) {
                        return FlutterFlowTheme.of(context).primaryBGStroke5;
                      } else if (widget!.states == ButtonState.focused) {
                        return FlutterFlowTheme.of(context).neutral100;
                      } else if (widget!.states == ButtonState.disabled) {
                        return FlutterFlowTheme.of(context).neutral100;
                      } else {
                        return FlutterFlowTheme.of(context).neutral100;
                      }
                    }(),
                    FlutterFlowTheme.of(context).neutral100,
                  ),
                  textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                        fontFamily: 'Inter',
                        color: valueOrDefault<Color>(
                          () {
                            if (widget!.states == ButtonState.byDefault) {
                              return FlutterFlowTheme.of(context)
                                  .primary600Default;
                            } else if (widget!.states == ButtonState.selected) {
                              return FlutterFlowTheme.of(context).primary800;
                            } else if (widget!.states == ButtonState.loading) {
                              return FlutterFlowTheme.of(context).primary700;
                            } else if (widget!.states == ButtonState.focused) {
                              return FlutterFlowTheme.of(context)
                                  .primary600Default;
                            } else {
                              return FlutterFlowTheme.of(context)
                                  .primary600Default;
                            }
                          }(),
                          FlutterFlowTheme.of(context).primary600Default,
                        ),
                        fontSize: 14.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                      ),
                  elevation: 0.0,
                  borderSide: BorderSide(
                    color: valueOrDefault<Color>(
                      () {
                        if (widget!.states == ButtonState.byDefault) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else if (widget!.states == ButtonState.selected) {
                          return FlutterFlowTheme.of(context).primary800;
                        } else if (widget!.states == ButtonState.loading) {
                          return FlutterFlowTheme.of(context).primary700;
                        } else if (widget!.states == ButtonState.focused) {
                          return FlutterFlowTheme.of(context).primary600Default;
                        } else if (widget!.states == ButtonState.disabled) {
                          return FlutterFlowTheme.of(context).textDisabled;
                        } else {
                          return FlutterFlowTheme.of(context).primary600Default;
                        }
                      }(),
                      FlutterFlowTheme.of(context).primary600Default,
                    ),
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(4.0),
                  disabledColor: FlutterFlowTheme.of(context).neutral100,
                  disabledTextColor: FlutterFlowTheme.of(context).textDisabled,
                  hoverColor: FlutterFlowTheme.of(context).primaryBGStroke5,
                  hoverBorderSide: BorderSide(
                    color: FlutterFlowTheme.of(context).primary700,
                    width: 1.0,
                  ),
                  hoverTextColor: FlutterFlowTheme.of(context).primary700,
                ),
                showLoadingIndicator: widget!.states == ButtonState.loading,
              ),
            );
          }
        },
      ),
    );
  }
}
