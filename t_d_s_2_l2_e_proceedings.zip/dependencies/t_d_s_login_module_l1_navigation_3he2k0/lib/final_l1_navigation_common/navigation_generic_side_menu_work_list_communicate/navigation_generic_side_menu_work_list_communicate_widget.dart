import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'navigation_generic_side_menu_work_list_communicate_model.dart';
export 'navigation_generic_side_menu_work_list_communicate_model.dart';

class NavigationGenericSideMenuWorkListCommunicateWidget
    extends StatefulWidget {
  const NavigationGenericSideMenuWorkListCommunicateWidget({
    super.key,
    required this.keyPrefix,
    this.menuListInfo,
    this.currentItemMenuList,
    this.currentItemSubMenuList,
    this.onTabMenu,
    this.onTabSubMenu,
  });

  final String? keyPrefix;
  final List<MenuListItemForWorkListStruct>? menuListInfo;
  final int? currentItemMenuList;
  final int? currentItemSubMenuList;
  final Future Function(int? selectedIndexMenu)? onTabMenu;
  final Future Function(int? selectedIndexSub)? onTabSubMenu;

  @override
  State<NavigationGenericSideMenuWorkListCommunicateWidget> createState() =>
      _NavigationGenericSideMenuWorkListCommunicateWidgetState();
}

class _NavigationGenericSideMenuWorkListCommunicateWidgetState
    extends State<NavigationGenericSideMenuWorkListCommunicateWidget> {
  late NavigationGenericSideMenuWorkListCommunicateModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => NavigationGenericSideMenuWorkListCommunicateModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            color: Color(0xFFF9FBFE),
            border: Border.all(
              color: FlutterFlowTheme.of(context).neutral300,
            ),
          ),
          child: Builder(
            builder: (context) {
              final menuListItemListView = widget!.menuListInfo?.toList() ?? [];

              return ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: menuListItemListView.length,
                itemBuilder: (context, menuListItemListViewIndex) {
                  final menuListItemListViewItem =
                      menuListItemListView[menuListItemListViewIndex];
                  return Container(
                    decoration: BoxDecoration(),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 4.0),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await widget.onTabMenu?.call(
                                menuListItemListViewIndex,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: widget!.currentItemMenuList ==
                                        menuListItemListViewIndex
                                    ? Color(0xFFE6F0FA)
                                    : Color(0x00000000),
                              ),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    12.0, 13.5, 12.0, 13.5),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      menuListItemListViewItem.heading,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: widget!
                                                        .currentItemMenuList ==
                                                    menuListItemListViewIndex
                                                ? Color(0xFF076BCF)
                                                : FlutterFlowTheme.of(context)
                                                    .neutral900,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    if (widget!.currentItemMenuList ==
                                        (menuListItemListViewIndex))
                                      Icon(
                                        Icons.keyboard_arrow_right_sharp,
                                        color: FlutterFlowTheme.of(context)
                                            .neutral900,
                                        size: 20.0,
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (widget!.currentItemMenuList ==
                            (menuListItemListViewIndex))
                          Builder(
                            builder: (context) {
                              final subMenuList = (widget!.menuListInfo
                                          ?.elementAtOrNull(
                                              menuListItemListViewIndex))
                                      ?.subMenuList
                                      ?.toList() ??
                                  [];

                              return Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: List.generate(subMenuList.length,
                                    (subMenuListIndex) {
                                  final subMenuListItem =
                                      subMenuList[subMenuListIndex];
                                  return InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      await widget.onTabSubMenu?.call(
                                        subMenuListIndex,
                                      );
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: widget!.currentItemSubMenuList ==
                                                subMenuListIndex
                                            ? Color(0xFFEAEBF4)
                                            : Color(0x00000000),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    20.0, 9.0, 20.0, 9.0),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Text(
                                                  valueOrDefault<String>(
                                                    subMenuListItem
                                                        .subMenuItemName,
                                                    'Sub1',
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color: widget!
                                                                    .currentItemSubMenuList ==
                                                                subMenuListIndex
                                                            ? Color(0xFF2A3A8D)
                                                            : FlutterFlowTheme
                                                                    .of(context)
                                                                .neutral900,
                                                        fontSize: 12.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          if (subMenuListIndex ==
                                              ((widget!.menuListInfo!
                                                          .elementAtOrNull(widget!
                                                              .currentItemMenuList!))!
                                                      .subMenuList
                                                      .length -
                                                  1))
                                            Divider(
                                              height: 1.0,
                                              thickness: 2.0,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .neutral300,
                                            ),
                                        ],
                                      ),
                                    ),
                                  );
                                }),
                              );
                            },
                          ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
