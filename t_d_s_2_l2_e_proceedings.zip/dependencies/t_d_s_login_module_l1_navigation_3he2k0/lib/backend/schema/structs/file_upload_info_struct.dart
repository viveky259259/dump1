// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FileUploadInfoStruct extends BaseStruct {
  FileUploadInfoStruct({
    String? heading,
    List<FileDetailStruct>? fileDetails,
  })  : _heading = heading,
        _fileDetails = fileDetails;

  // "heading" field.
  String? _heading;
  String get heading => _heading ?? '';
  set heading(String? val) => _heading = val;

  bool hasHeading() => _heading != null;

  // "fileDetails" field.
  List<FileDetailStruct>? _fileDetails;
  List<FileDetailStruct> get fileDetails => _fileDetails ?? const [];
  set fileDetails(List<FileDetailStruct>? val) => _fileDetails = val;

  void updateFileDetails(Function(List<FileDetailStruct>) updateFn) {
    updateFn(_fileDetails ??= []);
  }

  bool hasFileDetails() => _fileDetails != null;

  static FileUploadInfoStruct fromMap(Map<String, dynamic> data) =>
      FileUploadInfoStruct(
        heading: data['heading'] as String?,
        fileDetails: getStructList(
          data['fileDetails'],
          FileDetailStruct.fromMap,
        ),
      );

  static FileUploadInfoStruct? maybeFromMap(dynamic data) => data is Map
      ? FileUploadInfoStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'heading': _heading,
        'fileDetails': _fileDetails?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'heading': serializeParam(
          _heading,
          ParamType.String,
        ),
        'fileDetails': serializeParam(
          _fileDetails,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static FileUploadInfoStruct fromSerializableMap(Map<String, dynamic> data) =>
      FileUploadInfoStruct(
        heading: deserializeParam(
          data['heading'],
          ParamType.String,
          false,
        ),
        fileDetails: deserializeStructParam<FileDetailStruct>(
          data['fileDetails'],
          ParamType.DataStruct,
          true,
          structBuilder: FileDetailStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'FileUploadInfoStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is FileUploadInfoStruct &&
        heading == other.heading &&
        listEquality.equals(fileDetails, other.fileDetails);
  }

  @override
  int get hashCode => const ListEquality().hash([heading, fileDetails]);
}

FileUploadInfoStruct createFileUploadInfoStruct({
  String? heading,
}) =>
    FileUploadInfoStruct(
      heading: heading,
    );
