// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MenuListItemForWorkListStruct extends BaseStruct {
  MenuListItemForWorkListStruct({
    String? heading,
    List<SubMenuItemsForWorkListStruct>? subMenuList,
  })  : _heading = heading,
        _subMenuList = subMenuList;

  // "heading" field.
  String? _heading;
  String get heading => _heading ?? '';
  set heading(String? val) => _heading = val;

  bool hasHeading() => _heading != null;

  // "subMenuList" field.
  List<SubMenuItemsForWorkListStruct>? _subMenuList;
  List<SubMenuItemsForWorkListStruct> get subMenuList =>
      _subMenuList ?? const [];
  set subMenuList(List<SubMenuItemsForWorkListStruct>? val) =>
      _subMenuList = val;

  void updateSubMenuList(
      Function(List<SubMenuItemsForWorkListStruct>) updateFn) {
    updateFn(_subMenuList ??= []);
  }

  bool hasSubMenuList() => _subMenuList != null;

  static MenuListItemForWorkListStruct fromMap(Map<String, dynamic> data) =>
      MenuListItemForWorkListStruct(
        heading: data['heading'] as String?,
        subMenuList: getStructList(
          data['subMenuList'],
          SubMenuItemsForWorkListStruct.fromMap,
        ),
      );

  static MenuListItemForWorkListStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? MenuListItemForWorkListStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'heading': _heading,
        'subMenuList': _subMenuList?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'heading': serializeParam(
          _heading,
          ParamType.String,
        ),
        'subMenuList': serializeParam(
          _subMenuList,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static MenuListItemForWorkListStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      MenuListItemForWorkListStruct(
        heading: deserializeParam(
          data['heading'],
          ParamType.String,
          false,
        ),
        subMenuList: deserializeStructParam<SubMenuItemsForWorkListStruct>(
          data['subMenuList'],
          ParamType.DataStruct,
          true,
          structBuilder: SubMenuItemsForWorkListStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'MenuListItemForWorkListStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is MenuListItemForWorkListStruct &&
        heading == other.heading &&
        listEquality.equals(subMenuList, other.subMenuList);
  }

  @override
  int get hashCode => const ListEquality().hash([heading, subMenuList]);
}

MenuListItemForWorkListStruct createMenuListItemForWorkListStruct({
  String? heading,
}) =>
    MenuListItemForWorkListStruct(
      heading: heading,
    );
