// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class StepperWithSubStepperListStruct extends BaseStruct {
  StepperWithSubStepperListStruct({
    String? heading,
    List<String>? subHeadingList,
  })  : _heading = heading,
        _subHeadingList = subHeadingList;

  // "heading" field.
  String? _heading;
  String get heading => _heading ?? '';
  set heading(String? val) => _heading = val;

  bool hasHeading() => _heading != null;

  // "SubHeadingList" field.
  List<String>? _subHeadingList;
  List<String> get subHeadingList => _subHeadingList ?? const [];
  set subHeadingList(List<String>? val) => _subHeadingList = val;

  void updateSubHeadingList(Function(List<String>) updateFn) {
    updateFn(_subHeadingList ??= []);
  }

  bool hasSubHeadingList() => _subHeadingList != null;

  static StepperWithSubStepperListStruct fromMap(Map<String, dynamic> data) =>
      StepperWithSubStepperListStruct(
        heading: data['heading'] as String?,
        subHeadingList: getDataList(data['SubHeadingList']),
      );

  static StepperWithSubStepperListStruct? maybeFromMap(dynamic data) => data
          is Map
      ? StepperWithSubStepperListStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'heading': _heading,
        'SubHeadingList': _subHeadingList,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'heading': serializeParam(
          _heading,
          ParamType.String,
        ),
        'SubHeadingList': serializeParam(
          _subHeadingList,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static StepperWithSubStepperListStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      StepperWithSubStepperListStruct(
        heading: deserializeParam(
          data['heading'],
          ParamType.String,
          false,
        ),
        subHeadingList: deserializeParam<String>(
          data['SubHeadingList'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'StepperWithSubStepperListStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is StepperWithSubStepperListStruct &&
        heading == other.heading &&
        listEquality.equals(subHeadingList, other.subHeadingList);
  }

  @override
  int get hashCode => const ListEquality().hash([heading, subHeadingList]);
}

StepperWithSubStepperListStruct createStepperWithSubStepperListStruct({
  String? heading,
}) =>
    StepperWithSubStepperListStruct(
      heading: heading,
    );
