// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SubMenuItemsForWorkListStruct extends BaseStruct {
  SubMenuItemsForWorkListStruct({
    String? subMenuItemName,
  }) : _subMenuItemName = subMenuItemName;

  // "subMenuItemName" field.
  String? _subMenuItemName;
  String get subMenuItemName => _subMenuItemName ?? '';
  set subMenuItemName(String? val) => _subMenuItemName = val;

  bool hasSubMenuItemName() => _subMenuItemName != null;

  static SubMenuItemsForWorkListStruct fromMap(Map<String, dynamic> data) =>
      SubMenuItemsForWorkListStruct(
        subMenuItemName: data['subMenuItemName'] as String?,
      );

  static SubMenuItemsForWorkListStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? SubMenuItemsForWorkListStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'subMenuItemName': _subMenuItemName,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'subMenuItemName': serializeParam(
          _subMenuItemName,
          ParamType.String,
        ),
      }.withoutNulls;

  static SubMenuItemsForWorkListStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      SubMenuItemsForWorkListStruct(
        subMenuItemName: deserializeParam(
          data['subMenuItemName'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SubMenuItemsForWorkListStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SubMenuItemsForWorkListStruct &&
        subMenuItemName == other.subMenuItemName;
  }

  @override
  int get hashCode => const ListEquality().hash([subMenuItemName]);
}

SubMenuItemsForWorkListStruct createSubMenuItemsForWorkListStruct({
  String? subMenuItemName,
}) =>
    SubMenuItemsForWorkListStruct(
      subMenuItemName: subMenuItemName,
    );
