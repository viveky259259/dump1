// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MenuItemStruct extends BaseStruct {
  MenuItemStruct({
    String? name,
    String? navigateTo,
    List<MenuItemStruct>? subMenu,
  })  : _name = name,
        _navigateTo = navigateTo,
        _subMenu = subMenu;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "navigateTo" field.
  String? _navigateTo;
  String get navigateTo => _navigateTo ?? '';
  set navigateTo(String? val) => _navigateTo = val;

  bool hasNavigateTo() => _navigateTo != null;

  // "subMenu" field.
  List<MenuItemStruct>? _subMenu;
  List<MenuItemStruct> get subMenu => _subMenu ?? const [];
  set subMenu(List<MenuItemStruct>? val) => _subMenu = val;

  void updateSubMenu(Function(List<MenuItemStruct>) updateFn) {
    updateFn(_subMenu ??= []);
  }

  bool hasSubMenu() => _subMenu != null;

  static MenuItemStruct fromMap(Map<String, dynamic> data) => MenuItemStruct(
        name: data['name'] as String?,
        navigateTo: data['navigateTo'] as String?,
        subMenu: getStructList(
          data['subMenu'],
          MenuItemStruct.fromMap,
        ),
      );

  static MenuItemStruct? maybeFromMap(dynamic data) =>
      data is Map ? MenuItemStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'navigateTo': _navigateTo,
        'subMenu': _subMenu?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'navigateTo': serializeParam(
          _navigateTo,
          ParamType.String,
        ),
        'subMenu': serializeParam(
          _subMenu,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static MenuItemStruct fromSerializableMap(Map<String, dynamic> data) =>
      MenuItemStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        navigateTo: deserializeParam(
          data['navigateTo'],
          ParamType.String,
          false,
        ),
        subMenu: deserializeStructParam<MenuItemStruct>(
          data['subMenu'],
          ParamType.DataStruct,
          true,
          structBuilder: MenuItemStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'MenuItemStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is MenuItemStruct &&
        name == other.name &&
        navigateTo == other.navigateTo &&
        listEquality.equals(subMenu, other.subMenu);
  }

  @override
  int get hashCode => const ListEquality().hash([name, navigateTo, subMenu]);
}

MenuItemStruct createMenuItemStruct({
  String? name,
  String? navigateTo,
}) =>
    MenuItemStruct(
      name: name,
      navigateTo: navigateTo,
    );
