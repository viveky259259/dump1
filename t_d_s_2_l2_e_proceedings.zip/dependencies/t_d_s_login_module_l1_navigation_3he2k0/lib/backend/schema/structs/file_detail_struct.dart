// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FileDetailStruct extends BaseStruct {
  FileDetailStruct({
    String? fileName,
    String? fileUrl,
  })  : _fileName = fileName,
        _fileUrl = fileUrl;

  // "fileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "fileUrl" field.
  String? _fileUrl;
  String get fileUrl => _fileUrl ?? '';
  set fileUrl(String? val) => _fileUrl = val;

  bool hasFileUrl() => _fileUrl != null;

  static FileDetailStruct fromMap(Map<String, dynamic> data) =>
      FileDetailStruct(
        fileName: data['fileName'] as String?,
        fileUrl: data['fileUrl'] as String?,
      );

  static FileDetailStruct? maybeFromMap(dynamic data) => data is Map
      ? FileDetailStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fileName': _fileName,
        'fileUrl': _fileUrl,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'fileUrl': serializeParam(
          _fileUrl,
          ParamType.String,
        ),
      }.withoutNulls;

  static FileDetailStruct fromSerializableMap(Map<String, dynamic> data) =>
      FileDetailStruct(
        fileName: deserializeParam(
          data['fileName'],
          ParamType.String,
          false,
        ),
        fileUrl: deserializeParam(
          data['fileUrl'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FileDetailStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FileDetailStruct &&
        fileName == other.fileName &&
        fileUrl == other.fileUrl;
  }

  @override
  int get hashCode => const ListEquality().hash([fileName, fileUrl]);
}

FileDetailStruct createFileDetailStruct({
  String? fileName,
  String? fileUrl,
}) =>
    FileDetailStruct(
      fileName: fileName,
      fileUrl: fileUrl,
    );
