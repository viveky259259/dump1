import 'package:collection/collection.dart';

enum ButtonState {
  byDefault,
  selected,
  loading,
  focused,
  disabled,
  hover,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (ButtonState):
      return ButtonState.values.deserialize(value) as T?;
    default:
      return null;
  }
}
