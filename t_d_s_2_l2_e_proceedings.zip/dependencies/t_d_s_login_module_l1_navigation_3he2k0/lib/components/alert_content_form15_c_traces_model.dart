import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'alert_content_form15_c_traces_widget.dart'
    show AlertContentForm15CTracesWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AlertContentForm15CTracesModel
    extends FlutterFlowModel<AlertContentForm15CTracesWidget> {
  ///  Local state fields for this component.

  List<String> bulletPoints = [];
  void addToBulletPoints(String item) => bulletPoints.add(item);
  void removeFromBulletPoints(String item) => bulletPoints.remove(item);
  void removeAtIndexFromBulletPoints(int index) => bulletPoints.removeAt(index);
  void insertAtIndexInBulletPoints(int index, String item) =>
      bulletPoints.insert(index, item);
  void updateBulletPointsAtIndex(int index, Function(String) updateFn) =>
      bulletPoints[index] = updateFn(bulletPoints[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
