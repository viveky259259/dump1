import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'confirmation_alert_dialog_widget.dart'
    show ConfirmationAlertDialogWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ConfirmationAlertDialogModel
    extends FlutterFlowModel<ConfirmationAlertDialogWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Navigation_Generic_Secondary_Button component.
  late NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel3;

  @override
  void initState(BuildContext context) {
    navigationGenericSecondaryButtonModel =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel1 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    navigationGenericPrimaryButtonModel2 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    navigationGenericPrimaryButtonModel3 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    navigationGenericSecondaryButtonModel.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel3.dispose();
  }
}
