import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_hyper_link_button/navigation_generic_hyper_link_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'dont_use_this_component_widget.dart' show DontUseThisComponentWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DontUseThisComponentModel
    extends FlutterFlowModel<DontUseThisComponentWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for ContactUs.
  late NavigationGenericHyperLinkButtonModel contactUsModel;
  // State field(s) for LanguageDropDown widget.
  String? languageDropDownValue;
  FormFieldController<String>? languageDropDownValueController;
  // Model for RegisterButton.
  late NavigationGenericPrimaryButtonModel registerButtonModel;
  // Model for LoginButton.
  late NavigationGenericSecondaryButtonModel loginButtonModel;

  @override
  void initState(BuildContext context) {
    contactUsModel =
        createModel(context, () => NavigationGenericHyperLinkButtonModel());
    registerButtonModel =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    loginButtonModel =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
  }

  @override
  void dispose() {
    contactUsModel.dispose();
    registerButtonModel.dispose();
    loginButtonModel.dispose();
  }
}
