import '/flutter_flow/flutter_flow_util.dart';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'delete_this_comp_after_addding_model.dart';
export 'delete_this_comp_after_addding_model.dart';

class DeleteThisCompAfterAdddingWidget extends StatefulWidget {
  const DeleteThisCompAfterAdddingWidget({super.key});

  @override
  State<DeleteThisCompAfterAdddingWidget> createState() =>
      _DeleteThisCompAfterAdddingWidgetState();
}

class _DeleteThisCompAfterAdddingWidgetState
    extends State<DeleteThisCompAfterAdddingWidget> {
  late DeleteThisCompAfterAdddingModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DeleteThisCompAfterAdddingModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200.0,
      height: 140.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Align(
        alignment: AlignmentDirectional(0.0, 0.0),
        child: Padding(
          padding: EdgeInsets.all(12.0),
          child: Text(
            'This was a test component, please delete this component after adding.',
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  letterSpacing: 0.0,
                ),
          ),
        ),
      ),
    );
  }
}
