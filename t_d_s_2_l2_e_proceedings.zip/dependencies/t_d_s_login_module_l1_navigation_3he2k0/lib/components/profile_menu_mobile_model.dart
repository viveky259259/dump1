import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'profile_menu_mobile_widget.dart' show ProfileMenuMobileWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfileMenuMobileModel extends FlutterFlowModel<ProfileMenuMobileWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Register_Button.
  late NavigationGenericPrimaryButtonModel registerButtonModel;
  // Model for Login_Button.
  late NavigationGenericSecondaryButtonModel loginButtonModel;

  @override
  void initState(BuildContext context) {
    registerButtonModel =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    loginButtonModel =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
  }

  @override
  void dispose() {
    registerButtonModel.dispose();
    loginButtonModel.dispose();
  }
}
