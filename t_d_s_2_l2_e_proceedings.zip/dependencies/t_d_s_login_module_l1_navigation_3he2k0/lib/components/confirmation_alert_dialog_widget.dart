import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'confirmation_alert_dialog_model.dart';
export 'confirmation_alert_dialog_model.dart';

class ConfirmationAlertDialogWidget extends StatefulWidget {
  const ConfirmationAlertDialogWidget({
    super.key,
    this.alertBoxTitleIcon,
    required this.alertBoxTitle,
    required this.keyPrefix,
    this.onTapConfirm,
    this.onTapCancel,
    this.alertBoxContent,
    bool? isIconVisible,
    required this.alertContent,
    bool? isAlertBoxContentVisible,
    bool? showSingleButton,
  })  : this.isIconVisible = isIconVisible ?? false,
        this.isAlertBoxContentVisible = isAlertBoxContentVisible ?? false,
        this.showSingleButton = showSingleButton ?? false;

  final Widget? alertBoxTitleIcon;
  final String? alertBoxTitle;
  final String? keyPrefix;
  final Future Function()? onTapConfirm;
  final Future Function()? onTapCancel;
  final String? alertBoxContent;
  final bool isIconVisible;
  final Widget Function()? alertContent;
  final bool isAlertBoxContentVisible;
  final bool showSingleButton;

  @override
  State<ConfirmationAlertDialogWidget> createState() =>
      _ConfirmationAlertDialogWidgetState();
}

class _ConfirmationAlertDialogWidgetState
    extends State<ConfirmationAlertDialogWidget> {
  late ConfirmationAlertDialogModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ConfirmationAlertDialogModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(
          valueOrDefault<double>(
            () {
              if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                return 12.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                return 0.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                return 0.0;
              } else {
                return 0.0;
              }
            }(),
            0.0,
          ),
          0.0,
          valueOrDefault<double>(
            () {
              if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                return 12.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                return 0.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                return 0.0;
              } else {
                return 0.0;
              }
            }(),
            0.0,
          ),
          0.0),
      child: Container(
        width: MediaQuery.sizeOf(context).width * 1.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(24.0, 20.0, 24.0, 20.0),
              child: Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            if (widget!.isIconVisible)
                              widget!.alertBoxTitleIcon!,
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(),
                                child: Text(
                                  widget!.alertBoxTitle!,
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .textPrimary,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                              ),
                            ),
                          ].divide(SizedBox(width: 8.0)),
                        ),
                      ),
                    ),
                    Divider(
                      thickness: 1.0,
                      color: FlutterFlowTheme.of(context).neutral300,
                    ),
                    Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (widget!.alertBoxContent != null &&
                              widget!.alertBoxContent != '')
                            Text(
                              widget!.alertBoxContent!,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          Builder(builder: (_) {
                            return widget.alertContent!();
                          }),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              width: MediaQuery.sizeOf(context).width * 1.0,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (!widget!.showSingleButton &&
                      responsiveVisibility(
                        context: context,
                        phone: false,
                      ))
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          24.0, 16.0, 24.0, 16.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          wrapWithModel(
                            model: _model.navigationGenericSecondaryButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericSecondaryButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Confirmation_Alert_Dialog',
                                      'Navigation_Generic_Secondary_Button')),
                              labelText: 'Yes',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Confirmation_Alert_Dialog',
                                      'Navigation_Generic_Secondary_Button'),
                              states: ButtonState.byDefault,
                              onTap: () async {
                                // onTapConfirm
                                await widget.onTapConfirm?.call();
                                Navigator.pop(context, true);
                              },
                            ),
                          ),
                          wrapWithModel(
                            model: _model.navigationGenericPrimaryButtonModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericPrimaryButtonWidget(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Confirmation_Alert_Dialog',
                                      'Navigation_Generic_Primary_Button')),
                              labeltext: 'No',
                              keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Confirmation_Alert_Dialog',
                                      'Navigation_Generic_Primary_Button'),
                              states: ButtonState.byDefault,
                              onTap: () async {
                                // onTapCancel
                                await widget.onTapCancel?.call();
                                Navigator.pop(context, false);
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (widget!.showSingleButton &&
                      responsiveVisibility(
                        context: context,
                        phone: false,
                      ))
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          24.0, 16.0, 24.0, 16.0),
                      child: wrapWithModel(
                        model: _model.navigationGenericPrimaryButtonModel2,
                        updateCallback: () => safeSetState(() {}),
                        child: NavigationGenericPrimaryButtonWidget(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Confirmation_Alert_Dialog',
                                  'Navigation_Generic_Primary_Button')),
                          labeltext: 'Ok',
                          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Confirmation_Alert_Dialog',
                                  'Navigation_Generic_Primary_Button'),
                          states: ButtonState.byDefault,
                          onTap: () async {
                            // onTapCancel
                            await widget.onTapCancel?.call();
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ),
                  if (responsiveVisibility(
                    context: context,
                    tablet: false,
                    tabletLandscape: false,
                    desktop: false,
                  ))
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        if (widget!.showSingleButton)
                          Expanded(
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  24.0, 16.0, 24.0, 16.0),
                              child: wrapWithModel(
                                model:
                                    _model.navigationGenericPrimaryButtonModel3,
                                updateCallback: () => safeSetState(() {}),
                                child: NavigationGenericPrimaryButtonWidget(
                                  key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL1KeyValue(
                                          widget!.keyPrefix!,
                                          'Confirmation_Alert_Dialog',
                                          'Navigation_Generic_Primary_Button')),
                                  labeltext: 'Ok',
                                  keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                      .generateL1KeyValue(
                                          widget!.keyPrefix!,
                                          'Confirmation_Alert_Dialog',
                                          'Navigation_Generic_Primary_Button'),
                                  states: ButtonState.byDefault,
                                  onTap: () async {
                                    // onTapCancel
                                    await widget.onTapCancel?.call();
                                    Navigator.pop(context);
                                  },
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
