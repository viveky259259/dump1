import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_destructive_button/navigation_generic_destructive_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'confirmation_alert_dialog_form15_c_model.dart';
export 'confirmation_alert_dialog_form15_c_model.dart';

class ConfirmationAlertDialogForm15CWidget extends StatefulWidget {
  const ConfirmationAlertDialogForm15CWidget({
    super.key,
    this.alertBoxTitleIcon,
    required this.alertBoxTitle,
    required this.keyPrefix,
    this.onTapExit,
    this.onTapSave,
    required this.alertBoxContent,
    bool? isIconVisible,
    bool? showCancelAndConfirmButton,
    this.onTapCancel,
    this.onTapConfirm,
  })  : this.isIconVisible = isIconVisible ?? false,
        this.showCancelAndConfirmButton = showCancelAndConfirmButton ?? false;

  final Widget? alertBoxTitleIcon;
  final String? alertBoxTitle;
  final String? keyPrefix;
  final Future Function()? onTapExit;
  final Future Function()? onTapSave;
  final String? alertBoxContent;
  final bool isIconVisible;
  final bool showCancelAndConfirmButton;
  final Future Function()? onTapCancel;
  final Future Function()? onTapConfirm;

  @override
  State<ConfirmationAlertDialogForm15CWidget> createState() =>
      _ConfirmationAlertDialogForm15CWidgetState();
}

class _ConfirmationAlertDialogForm15CWidgetState
    extends State<ConfirmationAlertDialogForm15CWidget> {
  late ConfirmationAlertDialogForm15CModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ConfirmationAlertDialogForm15CModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(
          valueOrDefault<double>(
            () {
              if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                return 12.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                return 0.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                return 0.0;
              } else {
                return 0.0;
              }
            }(),
            0.0,
          ),
          0.0,
          valueOrDefault<double>(
            () {
              if (MediaQuery.sizeOf(context).width < kBreakpointSmall) {
                return 12.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointMedium) {
                return 0.0;
              } else if (MediaQuery.sizeOf(context).width < kBreakpointLarge) {
                return 0.0;
              } else {
                return 0.0;
              }
            }(),
            0.0,
          ),
          0.0),
      child: Container(
        width: MediaQuery.sizeOf(context).width * 1.0,
        height: 400.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(24.0, 20.0, 24.0, 20.0),
              child: Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).dangerBGStroke5,
                        borderRadius: BorderRadius.circular(4.0),
                        border: Border.all(
                          color: FlutterFlowTheme.of(context).danger300,
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Icon(
                              Icons.report_outlined,
                              color:
                                  FlutterFlowTheme.of(context).danger500Default,
                              size: 20.0,
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(),
                                child: RichText(
                                  textScaler: MediaQuery.of(context).textScaler,
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: 'Alert :',
                                        style: FlutterFlowTheme.of(context)
                                            .titleMedium
                                            .override(
                                              fontFamily: 'Inter',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .danger500Default,
                                              fontSize: 14.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                      TextSpan(
                                        text: ' This action cannot be undone',
                                        style: TextStyle(
                                          color: FlutterFlowTheme.of(context)
                                              .danger500Default,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      )
                                    ],
                                    style: FlutterFlowTheme.of(context)
                                        .titleMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .danger500Default,
                                          fontSize: 14.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                          ].divide(SizedBox(width: 8.0)),
                        ),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          width: MediaQuery.sizeOf(context).width * 1.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 12.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (widget!.isIconVisible)
                                  widget!.alertBoxTitleIcon!,
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(),
                                    child: Text(
                                      widget!.alertBoxTitle!,
                                      style: FlutterFlowTheme.of(context)
                                          .titleMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: FlutterFlowTheme.of(context)
                                                .textPrimary,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ),
                                ),
                              ].divide(SizedBox(width: 8.0)),
                            ),
                          ),
                        ),
                        Divider(
                          thickness: 1.0,
                          color: FlutterFlowTheme.of(context).neutral300,
                        ),
                        Container(
                          width: MediaQuery.sizeOf(context).width * 1.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Text(
                                widget!.alertBoxContent!,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .textBasic,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ].divide(SizedBox(height: 24.0)),
                ),
              ),
            ),
            if (responsiveVisibility(
              context: context,
              phone: false,
            ))
              Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    if (!widget!.showCancelAndConfirmButton)
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 16.0, 24.0, 16.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            wrapWithModel(
                              model: _model
                                  .navigationGenericDestructiveButtonModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: NavigationGenericDestructiveButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog_Form15C',
                                        'Navigation_Generic_Destructive_Button')),
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog_Form15C',
                                        'Navigation_Generic_Destructive_Button'),
                                height: 36.0,
                                labelText: 'Exit Without Saving',
                                state: ButtonState.byDefault,
                                onTap: () async {
                                  // onTapExit
                                  await widget.onTapExit?.call();
                                },
                              ),
                            ),
                            wrapWithModel(
                              model:
                                  _model.navigationGenericPrimaryButtonModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: NavigationGenericPrimaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog',
                                        'Navigation_Generic_Primary_Button')),
                                labeltext: 'Save & Exit',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog',
                                        'Navigation_Generic_Primary_Button'),
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  // onTapCancel
                                  await widget.onTapSave?.call();
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    if (widget!.showCancelAndConfirmButton)
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 16.0, 24.0, 16.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            wrapWithModel(
                              model:
                                  _model.navigationGenericSecondaryButtonModel1,
                              updateCallback: () => safeSetState(() {}),
                              child: NavigationGenericSecondaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog',
                                        'Navigation_Generic_Secondary_Button')),
                                labelText: 'Cancel',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog',
                                        'Navigation_Generic_Secondary_Button'),
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  // onTap Cancel
                                  await widget.onTapCancel?.call();
                                },
                              ),
                            ),
                            wrapWithModel(
                              model:
                                  _model.navigationGenericPrimaryButtonModel2,
                              updateCallback: () => safeSetState(() {}),
                              child: NavigationGenericPrimaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog',
                                        'Navigation_Generic_Primary_Button')),
                                labeltext: 'Confirm',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Confirmation_Alert_Dialog',
                                        'Navigation_Generic_Primary_Button'),
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  // onTap Confirm
                                  await widget.onTapConfirm?.call();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            if (responsiveVisibility(
              context: context,
              tablet: false,
              tabletLandscape: false,
              desktop: false,
            ))
              Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryInfoBGStroke5,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    if (!widget!.showCancelAndConfirmButton)
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 16.0, 24.0, 16.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: wrapWithModel(
                                    model: _model
                                        .navigationGenericDestructiveButtonModel2,
                                    updateCallback: () => safeSetState(() {}),
                                    child:
                                        NavigationGenericDestructiveButtonWidget(
                                      key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Confirmation_Alert_Dialog_Form15C',
                                              'Navigation_Generic_Destructive_Button')),
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Confirmation_Alert_Dialog_Form15C',
                                              'Navigation_Generic_Destructive_Button'),
                                      height: 36.0,
                                      labelText: 'Exit Without Saving',
                                      state: ButtonState.byDefault,
                                      onTap: () async {
                                        // onTapExit
                                        await widget.onTapExit?.call();
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: wrapWithModel(
                                    model: _model
                                        .navigationGenericPrimaryButtonModel3,
                                    updateCallback: () => safeSetState(() {}),
                                    child: NavigationGenericPrimaryButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Confirmation_Alert_Dialog',
                                                  'Navigation_Generic_Primary_Button')),
                                      labeltext: 'Save & Exit',
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Confirmation_Alert_Dialog',
                                              'Navigation_Generic_Primary_Button'),
                                      states: ButtonState.byDefault,
                                      onTap: () async {
                                        // onTapCancel
                                        await widget.onTapSave?.call();
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 12.0)),
                        ),
                      ),
                    if (widget!.showCancelAndConfirmButton)
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 16.0, 24.0, 16.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: wrapWithModel(
                                    model: _model
                                        .navigationGenericSecondaryButtonModel2,
                                    updateCallback: () => safeSetState(() {}),
                                    child:
                                        NavigationGenericSecondaryButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Confirmation_Alert_Dialog',
                                                  'Navigation_Generic_Secondary_Button')),
                                      labelText: 'Cancel',
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Confirmation_Alert_Dialog',
                                              'Navigation_Generic_Secondary_Button'),
                                      states: ButtonState.byDefault,
                                      onTap: () async {
                                        // onTapConfirm
                                        await widget.onTapCancel?.call();
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Expanded(
                                  child: wrapWithModel(
                                    model: _model
                                        .navigationGenericPrimaryButtonModel4,
                                    updateCallback: () => safeSetState(() {}),
                                    child: NavigationGenericPrimaryButtonWidget(
                                      key: ValueKey(
                                          t_d_s_2_l1_logic_2wrus1_functions
                                              .generateL1KeyValue(
                                                  widget!.keyPrefix!,
                                                  'Confirmation_Alert_Dialog',
                                                  'Navigation_Generic_Primary_Button')),
                                      labeltext: 'Confirm',
                                      keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                          .generateL1KeyValue(
                                              widget!.keyPrefix!,
                                              'Confirmation_Alert_Dialog',
                                              'Navigation_Generic_Primary_Button'),
                                      states: ButtonState.byDefault,
                                      onTap: () async {
                                        // onTapCancel
                                        await widget.onTapConfirm?.call();
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 12.0)),
                        ),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
