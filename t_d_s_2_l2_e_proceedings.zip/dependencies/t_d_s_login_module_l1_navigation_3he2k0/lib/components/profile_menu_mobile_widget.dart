import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'profile_menu_mobile_model.dart';
export 'profile_menu_mobile_model.dart';

/// "Profile_Menu_Mobile on click of the profile menu in headerthis components
/// allows the user to register or login into the Traces website.
///
/// It is designed for the mobile view screen.
///
/// Parameters:
/// 1.keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// onTapRegister:Action
/// onTap of the register button it will take the user to register page to
/// enter their credientials.
///
/// onTapLogin:Action
/// onTap of the login button it will take the user to login page to enter
/// their credientials."
class ProfileMenuMobileWidget extends StatefulWidget {
  const ProfileMenuMobileWidget({
    super.key,
    required this.keyPrefix,
    required this.onTapRegister,
    required this.onTapLogin,
  });

  final String? keyPrefix;
  final Future Function()? onTapRegister;
  final Future Function()? onTapLogin;

  @override
  State<ProfileMenuMobileWidget> createState() =>
      _ProfileMenuMobileWidgetState();
}

class _ProfileMenuMobileWidgetState extends State<ProfileMenuMobileWidget> {
  late ProfileMenuMobileModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ProfileMenuMobileModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // This components allows the user to register or login into the Traces website. It is designed for the mobile view screen.
        Visibility(
      visible: responsiveVisibility(
        context: context,
        tablet: false,
        tabletLandscape: false,
        desktop: false,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 64.0, 16.0, 0.0),
        child: Container(
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).neutral100,
            boxShadow: [
              BoxShadow(
                blurRadius: 14.0,
                color: Color(0x00000014),
                offset: Offset(
                  -1.0,
                  4.0,
                ),
              )
            ],
            borderRadius: BorderRadius.circular(4.0),
            border: Border.all(
              color: FlutterFlowTheme.of(context).neutral300,
              width: 0.5,
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 16.0, 24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Do not have an account?',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Semantics(
                            label:
                                'Register button navigates the user to register their details ',
                            child: wrapWithModel(
                              model: _model.registerButtonModel,
                              updateCallback: () => safeSetState(() {}),
                              child: NavigationGenericPrimaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Profile_Menu_Mobile',
                                        'Register_Button')),
                                labeltext: 'Register',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Profile_Menu_Mobile',
                                        'Register_Button'),
                                width: MediaQuery.sizeOf(context).width,
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  await widget.onTapRegister?.call();
                                },
                              ),
                            ),
                          ),
                        ].divide(SizedBox(height: 12.0)),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Already have an account?',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Semantics(
                            label:
                                'Login button navigates the user to login their credentials to get into the portal.',
                            child: wrapWithModel(
                              model: _model.loginButtonModel,
                              updateCallback: () => safeSetState(() {}),
                              child: NavigationGenericSecondaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(widget!.keyPrefix!,
                                        'Profile_Menu_Mobile', 'Login_Button')),
                                labelText: 'Login',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(widget!.keyPrefix!,
                                        'Profile_Menu_Mobile', 'Login_Button'),
                                width: MediaQuery.sizeOf(context).width,
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  await widget.onTapLogin?.call();
                                },
                              ),
                            ),
                          ),
                        ].divide(SizedBox(height: 12.0)),
                      ),
                    ),
                  ],
                ),
              ].divide(SizedBox(height: 24.0)),
            ),
          ),
        ),
      ),
    );
  }
}
