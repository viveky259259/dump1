import '/backend/schema/structs/index.dart';
import '/components/sub_menu_dropdown_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'hamburger_menu_mobile_model.dart';
export 'hamburger_menu_mobile_model.dart';

/// "The hamburger menu will appear when the user clicks the menu icon in the
/// menubar.
///
/// This is desiged specifically for the mobile view. It will show the list of
/// options that comes under the menu.
///
/// Parameters
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// menu:List<Data(MenuItem)>
/// Pass the datatype menuItem from the app state for the dynamic menu options
/// that is required.
///
/// onMenuOpen:Action - Required parameter- activeMenuLabel String.
/// onTap of the menu option it will take the active menu name and pass it to
/// the menubar to display that name."
class HamburgerMenuMobileWidget extends StatefulWidget {
  const HamburgerMenuMobileWidget({
    super.key,
    required this.keyPrefix,
    required this.menu,
    required this.onMenuOpen,
    required this.onMenuClose,
  });

  final String? keyPrefix;
  final List<MenuItemStruct>? menu;
  final Future Function(String activeMenuLabel)? onMenuOpen;
  final Future Function()? onMenuClose;

  @override
  State<HamburgerMenuMobileWidget> createState() =>
      _HamburgerMenuMobileWidgetState();
}

class _HamburgerMenuMobileWidgetState extends State<HamburgerMenuMobileWidget> {
  late HamburgerMenuMobileModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HamburgerMenuMobileModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // The hamburger menu will appear when the user clicks the hamburger menu icon in the menubar. This is desiged specifically for the mobile view. It will show the list of options that comes under the menu.
        //
        //
        Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 120.0, 0.0, 0.0),
      child: Container(
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).primary700,
        ),
        child: Builder(
          builder: (context) {
            final menu = widget!.menu!.toList();

            return Semantics(
              label:
                  'Dynamically generate children based the menu that is passed in the component parameter.',
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(menu.length, (menuIndex) {
                  final menuItem = menu[menuIndex];
                  return Builder(
                    builder: (context) => InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        Navigator.pop(context);
                        await widget.onMenuOpen?.call(
                          menuItem.name,
                        );
                        await showDialog(
                          barrierColor: Colors.transparent,
                          context: context,
                          builder: (dialogContext) {
                            return Dialog(
                              elevation: 0,
                              insetPadding: EdgeInsets.zero,
                              backgroundColor: Colors.transparent,
                              alignment: AlignmentDirectional(1.0, -1.0)
                                  .resolve(Directionality.of(context)),
                              child: SubMenuDropdownWidget(
                                keyPrefix: 'key',
                                menu:
                                    (widget!.menu!.elementAtOrNull(menuIndex))!
                                        .subMenu,
                                activeIndex: menuIndex,
                                onTap: () async {},
                              ),
                            );
                          },
                        );

                        await widget.onMenuClose?.call();
                      },
                      child: Container(
                        decoration: BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 12.0, 0.0, 12.0),
                                child: Semantics(
                                  label:
                                      'Displays the name of the menuItem from the data that is passed from the parameter.',
                                  child: Text(
                                    menuItem.name,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .textAlternative,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                            if (menuItem.subMenu.length > 0)
                              Semantics(
                                label:
                                    'If the menu item have submenu options then the icon will be visible.',
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color:
                                      FlutterFlowTheme.of(context).neutral100,
                                  size: 15.0,
                                ),
                              ),
                          ]
                              .addToStart(SizedBox(width: 52.0))
                              .addToEnd(SizedBox(width: 25.0)),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            );
          },
        ),
      ),
    );
  }
}
