import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'custom_tabs_model.dart';
export 'custom_tabs_model.dart';

class CustomTabsWidget extends StatefulWidget {
  const CustomTabsWidget({
    super.key,
    required this.listOfTabs,
    required this.tabAction,
    required this.tabName,
    this.width,
    this.height,
  });

  final List<String>? listOfTabs;
  final Future Function(int selectedIndex)? tabAction;
  final String? tabName;
  final double? width;
  final double? height;

  @override
  State<CustomTabsWidget> createState() => _CustomTabsWidgetState();
}

class _CustomTabsWidgetState extends State<CustomTabsWidget> {
  late CustomTabsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CustomTabsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Builder(
            builder: (context) {
              final tabList = widget!.listOfTabs!.toList();

              return Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(tabList.length, (tabListIndex) {
                  final tabListItem = tabList[tabListIndex];
                  return InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      _model.selectedIndex = tabListIndex;
                      safeSetState(() {});
                      await widget.tabAction?.call(
                        tabListIndex,
                      );
                    },
                    child: Container(
                      width: widget!.width,
                      height: widget!.height,
                      decoration: BoxDecoration(
                        color: _model.selectedIndex == tabListIndex
                            ? FlutterFlowTheme.of(context)
                                .secondaryInfoBGStroke5
                            : FlutterFlowTheme.of(context).neutral100,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(0.0),
                          bottomRight: Radius.circular(0.0),
                          topLeft: Radius.circular(0.0),
                          topRight: Radius.circular(0.0),
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            widget!.tabName!,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: _model.selectedIndex == tabListIndex
                                      ? FlutterFlowTheme.of(context).primary
                                      : FlutterFlowTheme.of(context).textBasic,
                                  letterSpacing: 0.0,
                                ),
                          ),
                          if (_model.selectedIndex == tabListIndex)
                            Divider(
                              thickness: 4.0,
                              endIndent: 70.0,
                              color: FlutterFlowTheme.of(context).secondary,
                            ),
                        ],
                      ),
                    ),
                  );
                }),
              );
            },
          ),
        ],
      ),
    );
  }
}
