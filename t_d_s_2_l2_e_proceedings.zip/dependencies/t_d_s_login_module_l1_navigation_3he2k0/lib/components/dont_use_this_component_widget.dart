import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_hyper_link_button/navigation_generic_hyper_link_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dont_use_this_component_model.dart';
export 'dont_use_this_component_model.dart';

/// This is Generic Header designed based on the User's Login status like
/// Existing user or New user.
///
///
/// It includes the following elements:
/// TDS logo: Image
/// Contact Us: A clickable text for user assistance or inquiries.
/// Screen Reader Icon & Text: Accessibility feature or reading text aloud.
/// Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text
/// size.
/// Tonality( Theme Switcher Dark/Light Mode): Enables users to toggle between
/// dark and light themes for the application's interface depending on their
/// preference or lighting conditions.
/// Language Selector: Dropdown to switch between different languages(e.g.,
/// "English","Hindi")
/// Parameters:
/// isNewUser: Boolean
/// It determines the state of the button used in the header.
/// we used Conditional Builder using a boolean (isNewUser) in the header to
/// switch the button state.
/// For example:
/// If isNewUser is true, then the Register button will show.
/// If isNewUser is false, then the Login button will show.
/// onTap: Action
/// Define the action to be performed when the IconButton, Text  is tapped,
/// such as reading text aloud.
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
class DontUseThisComponentWidget extends StatefulWidget {
  const DontUseThisComponentWidget({
    super.key,
    bool? isNewUser,
    required this.keyPrefix,
    required this.onTapAction,
  }) : this.isNewUser = isNewUser ?? true;

  final bool isNewUser;
  final String? keyPrefix;
  final Future Function()? onTapAction;

  @override
  State<DontUseThisComponentWidget> createState() =>
      _DontUseThisComponentWidgetState();
}

class _DontUseThisComponentWidgetState
    extends State<DontUseThisComponentWidget> {
  late DontUseThisComponentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DontUseThisComponentModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).neutral100,
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(48.0, 8.0, 48.0, 8.0),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Semantics(
                      label: 'This is image of TDS Logo.',
                      child: ClipRRect(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(widget!.keyPrefix!,
                                'Generic_Header_Website', 'TDSLogo')),
                        borderRadius: BorderRadius.circular(8.0),
                        child: Image.asset(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Generic_Header_Website', 'TDSLogo')),
                          'dependencies/t_d_s_login_module_l1_navigation_3he2k0/assets/images/Traces_logo.png',
                          width: 415.0,
                          height: 56.0,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Semantics(
                      label:
                          'Contact Us: A clickable text for user assistance or inquiries.',
                      child: wrapWithModel(
                        model: _model.contactUsModel,
                        updateCallback: () => safeSetState(() {}),
                        child: NavigationGenericHyperLinkButtonWidget(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Generic_Header_Website', 'ContactUs')),
                          labelText: 'Contact Us',
                          keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Generic_Header_Website', 'ContactUs'),
                          labelTextColor:
                              FlutterFlowTheme.of(context).primary600Default,
                          onTapAction: () async {
                            await widget.onTapAction?.call();
                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Semantics(
                      label:
                          'Screen Reader button: Accessibility feature or reading text aloud.',
                      child: FFButtonWidget(
                        key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                            .generateL1KeyValue(
                                widget!.keyPrefix!,
                                'Generic_Header_Website_PostLogin',
                                'ScreenReaderButton')),
                        onPressed: () async {
                          await widget.onTapAction?.call();
                        },
                        text: 'Screen Reader ',
                        icon: Icon(
                          Icons.text_snippet_outlined,
                          size: 20.0,
                        ),
                        options: FFButtonOptions(
                          height: 40.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconAlignment: IconAlignment.start,
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Colors.transparent,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(),
                      child: Semantics(
                        label:
                            'Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text size.',
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            FlutterFlowIconButton(
                              borderColor: Colors.transparent,
                              borderRadius: 8.0,
                              buttonSize: 40.0,
                              icon: Icon(
                                Icons.text_decrease,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 15.0,
                              ),
                              onPressed: () async {
                                await widget.onTapAction?.call();
                              },
                            ),
                            FlutterFlowIconButton(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_Website',
                                      'FontIconButton')),
                              borderRadius: 8.0,
                              buttonSize: 40.0,
                              fillColor: Colors.transparent,
                              icon: Icon(
                                Icons.font_download,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 20.0,
                              ),
                              onPressed: () async {
                                await widget.onTapAction?.call();
                              },
                            ),
                            FlutterFlowIconButton(
                              borderColor: Colors.transparent,
                              borderRadius: 8.0,
                              buttonSize: 40.0,
                              icon: Icon(
                                Icons.text_increase,
                                color: FlutterFlowTheme.of(context)
                                    .primary600Default,
                                size: 15.0,
                              ),
                              onPressed: () async {
                                await widget.onTapAction?.call();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Semantics(
                      label:
                          'Tonality (Theme Switcher Dark/Light Mode): Enables users to toggle between dark and light themes for the application\'s interface depending on their preference or lighting conditions.',
                      child: FlutterFlowIconButton(
                        borderRadius: 8.0,
                        buttonSize: 40.0,
                        fillColor: Colors.transparent,
                        icon: Icon(
                          Icons.tonality,
                          color: FlutterFlowTheme.of(context).primary600Default,
                          size: 20.0,
                        ),
                        onPressed: () async {
                          await widget.onTapAction?.call();
                        },
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Container(
                      height: 40.0,
                      decoration: BoxDecoration(),
                      child: Semantics(
                        label:
                            'Language Selector: Dropdown to switch between different languages (e.g., \"English\",\"Hindi\")',
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_Website',
                                      'LanguageIcon')),
                              Icons.language,
                              color: FlutterFlowTheme.of(context)
                                  .primary600Default,
                              size: 20.0,
                            ),
                            FlutterFlowDropDown<String>(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Generic_Header_Website',
                                      'LanguageDropDown')),
                              controller:
                                  _model.languageDropDownValueController ??=
                                      FormFieldController<String>(
                                _model.languageDropDownValue ??= 'English',
                              ),
                              options: ['English', 'Hindi'],
                              onChanged: (val) => safeSetState(
                                  () => _model.languageDropDownValue = val),
                              width: 100.0,
                              height: 40.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .primary600Default,
                                    fontSize: 12.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                              hintText: 'Select',
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: FlutterFlowTheme.of(context)
                                    .secondaryInfo500Default,
                                size: 24.0,
                              ),
                              elevation: 2.0,
                              borderColor: Colors.transparent,
                              borderWidth: 0.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 0.0, 12.0, 0.0),
                              hidesUnderline: true,
                              isOverButton: false,
                              isSearchable: false,
                              isMultiSelect: false,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                      child: VerticalDivider(
                        thickness: 0.5,
                        color: Color(0xFFBFC4DD),
                      ),
                    ),
                    Builder(
                      builder: (context) {
                        if (widget!.isNewUser) {
                          return wrapWithModel(
                            model: _model.registerButtonModel,
                            updateCallback: () => safeSetState(() {}),
                            child: NavigationGenericPrimaryButtonWidget(
                              labeltext: 'Register',
                              keyPrefix: 'key',
                              states: ButtonState.byDefault,
                              onTap: () async {
                                await widget.onTapAction?.call();
                              },
                            ),
                          );
                        } else {
                          return Semantics(
                            label:
                                'If isNewUser is false, then the Login button will show.',
                            child: wrapWithModel(
                              model: _model.loginButtonModel,
                              updateCallback: () => safeSetState(() {}),
                              updateOnChange: true,
                              child: NavigationGenericSecondaryButtonWidget(
                                key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Generic_Header_Website',
                                        'LoginButton')),
                                labelText: 'Login',
                                keyPrefix: t_d_s_2_l1_logic_2wrus1_functions
                                    .generateL1KeyValue(
                                        widget!.keyPrefix!,
                                        'Generic_Header_Website',
                                        'LoginButton'),
                                states: ButtonState.byDefault,
                                onTap: () async {
                                  await widget.onTapAction?.call();
                                },
                              ),
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
