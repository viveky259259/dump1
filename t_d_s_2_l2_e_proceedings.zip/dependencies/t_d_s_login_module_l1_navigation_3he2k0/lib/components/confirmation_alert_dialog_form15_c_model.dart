import '/backend/schema/enums/enums.dart';
import '/final_l1_navigation_common/navigation_generic_destructive_button/navigation_generic_destructive_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_primary_button/navigation_generic_primary_button_widget.dart';
import '/final_l1_navigation_common/navigation_generic_secondary_button/navigation_generic_secondary_button_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'confirmation_alert_dialog_form15_c_widget.dart'
    show ConfirmationAlertDialogForm15CWidget;
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ConfirmationAlertDialogForm15CModel
    extends FlutterFlowModel<ConfirmationAlertDialogForm15CWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Navigation_Generic_Destructive_Button component.
  late NavigationGenericDestructiveButtonModel
      navigationGenericDestructiveButtonModel1;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel1;
  // Model for Navigation_Generic_Secondary_Button component.
  late NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel1;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel2;
  // Model for Navigation_Generic_Destructive_Button component.
  late NavigationGenericDestructiveButtonModel
      navigationGenericDestructiveButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel3;
  // Model for Navigation_Generic_Secondary_Button component.
  late NavigationGenericSecondaryButtonModel
      navigationGenericSecondaryButtonModel2;
  // Model for Navigation_Generic_Primary_Button component.
  late NavigationGenericPrimaryButtonModel navigationGenericPrimaryButtonModel4;

  @override
  void initState(BuildContext context) {
    navigationGenericDestructiveButtonModel1 =
        createModel(context, () => NavigationGenericDestructiveButtonModel());
    navigationGenericPrimaryButtonModel1 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel1 =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel2 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    navigationGenericDestructiveButtonModel2 =
        createModel(context, () => NavigationGenericDestructiveButtonModel());
    navigationGenericPrimaryButtonModel3 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
    navigationGenericSecondaryButtonModel2 =
        createModel(context, () => NavigationGenericSecondaryButtonModel());
    navigationGenericPrimaryButtonModel4 =
        createModel(context, () => NavigationGenericPrimaryButtonModel());
  }

  @override
  void dispose() {
    navigationGenericDestructiveButtonModel1.dispose();
    navigationGenericPrimaryButtonModel1.dispose();
    navigationGenericSecondaryButtonModel1.dispose();
    navigationGenericPrimaryButtonModel2.dispose();
    navigationGenericDestructiveButtonModel2.dispose();
    navigationGenericPrimaryButtonModel3.dispose();
    navigationGenericSecondaryButtonModel2.dispose();
    navigationGenericPrimaryButtonModel4.dispose();
  }
}
