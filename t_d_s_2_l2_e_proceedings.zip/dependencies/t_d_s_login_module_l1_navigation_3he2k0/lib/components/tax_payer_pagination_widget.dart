import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'tax_payer_pagination_model.dart';
export 'tax_payer_pagination_model.dart';

class TaxPayerPaginationWidget extends StatefulWidget {
  const TaxPayerPaginationWidget({
    super.key,
    required this.keyPrefix,
    this.menuList,
    this.currentItem,
    required this.onTap,
  });

  final String? keyPrefix;
  final List<int>? menuList;
  final int? currentItem;
  final Future Function(int? seletedIndex)? onTap;

  @override
  State<TaxPayerPaginationWidget> createState() =>
      _TaxPayerPaginationWidgetState();
}

class _TaxPayerPaginationWidgetState extends State<TaxPayerPaginationWidget> {
  late TaxPayerPaginationModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TaxPayerPaginationModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Container(
          decoration: BoxDecoration(),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 10.0, 16.0, 10.0),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  decoration: BoxDecoration(),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Icon(
                          Icons.chevron_left,
                          color: FlutterFlowTheme.of(context).neutral500Default,
                          size: 20.0,
                        ),
                      ),
                      Text(
                        'Previous',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              fontSize: 12.0,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 22.0,
                  child: VerticalDivider(
                    thickness: 0.5,
                    color: Color(0xFF919191),
                  ),
                ),
                Container(
                  width: 68.9,
                  height: 39.6,
                  decoration: BoxDecoration(),
                  child: ListView(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    children: [
                      Container(
                        width: 60.0,
                        height: 60.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: FlutterFlowTheme.of(context).primary,
                          ),
                        ),
                        child: Align(
                          alignment: AlignmentDirectional(0.0, 0.0),
                          child: Text(
                            '1',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 22.0,
                  child: VerticalDivider(
                    thickness: 0.5,
                    color: Color(0xFF919191),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 30.75,
                  decoration: BoxDecoration(),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Text(
                        'Next',
                        style: GoogleFonts.getFont(
                          'Inter',
                          color: FlutterFlowTheme.of(context)
                              .secondaryInfo500Default,
                          fontSize: 12.0,
                        ),
                      ),
                      Icon(
                        Icons.keyboard_arrow_right_rounded,
                        color: FlutterFlowTheme.of(context)
                            .secondaryInfo500Default,
                        size: 20.0,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
