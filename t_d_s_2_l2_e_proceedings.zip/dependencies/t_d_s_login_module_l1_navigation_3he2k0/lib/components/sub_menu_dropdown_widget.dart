import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'sub_menu_dropdown_model.dart';
export 'sub_menu_dropdown_model.dart';

/// "The SubMenu_Dropdown will appear when the user selects an option from the
/// hamburger menu.
///
/// This is desiged specifically for the mobile view. It will show the list of
/// options that comes under that menu.
///
/// Parameters
/// keyPrefix: String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking.
///
/// menu:List<Data(MenuItem)>
/// Pass the datatype menuItem from the app state for the dynamic menu options
/// that is required.
///
/// onTap:Action
/// onTap of the menu option it will navigate to the respective page."
class SubMenuDropdownWidget extends StatefulWidget {
  const SubMenuDropdownWidget({
    super.key,
    required this.keyPrefix,
    required this.menu,
    required this.activeIndex,
    this.onTap,
  });

  final String? keyPrefix;
  final List<MenuItemStruct>? menu;
  final int? activeIndex;
  final Future Function()? onTap;

  @override
  State<SubMenuDropdownWidget> createState() => _SubMenuDropdownWidgetState();
}

class _SubMenuDropdownWidgetState extends State<SubMenuDropdownWidget> {
  late SubMenuDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SubMenuDropdownModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // "The SubMenu_Dropdown will appear when the user selects an option from the hamburger menu. This is desiged specifically for the mobile view. It will show the list of options that comes under that menu.
        //
        Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 120.0, 0.0, 0.0),
      child: Container(
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryInfoBGStroke2,
        ),
        child: Builder(
          builder: (context) {
            final menu = widget!.menu!.toList();

            return Semantics(
              label:
                  'Dynamically generate children based the menu that is passed in the component parameter.',
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(menu.length, (menuIndex) {
                  final menuItem = menu[menuIndex];
                  return InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      await widget.onTap?.call();
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: widget!.activeIndex == menuIndex
                            ? FlutterFlowTheme.of(context)
                                .secondaryInfoBGStroke10
                            : FlutterFlowTheme.of(context)
                                .secondaryInfoBGStroke5,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 12.0, 0.0, 12.0),
                              child: Semantics(
                                label:
                                    'It will contain the submenu options that falls under a particular menu option.',
                                child: Text(
                                  menuItem.name,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: widget!.activeIndex == menuIndex
                                            ? FlutterFlowTheme.of(context)
                                                .secondaryInfo800
                                            : FlutterFlowTheme.of(context)
                                                .textBasic,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w500,
                                      ),
                                ),
                              ),
                            ),
                          ),
                        ]
                            .addToStart(SizedBox(width: 52.0))
                            .addToEnd(SizedBox(width: 18.0)),
                      ),
                    ),
                  );
                }),
              ),
            );
          },
        ),
      ),
    );
  }
}
