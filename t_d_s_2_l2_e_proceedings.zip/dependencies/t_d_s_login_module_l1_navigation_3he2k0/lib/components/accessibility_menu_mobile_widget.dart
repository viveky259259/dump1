import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:t_d_s2_l1_language_support_4doo8y/app_constants.dart'
    as t_d_s2_l1_language_support_4doo8y_app_constant;
import 'package:t_d_s_2_l1_logic_2wrus1/flutter_flow/custom_functions.dart'
    as t_d_s_2_l1_logic_2wrus1_functions;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'accessibility_menu_mobile_model.dart';
export 'accessibility_menu_mobile_model.dart';

/// "Accessibility Menu is designed specifically for the mobile view to deal
/// with the accessibility like Font decrease,increase,screen reader, to
/// change the theme and select language from dropdown.
///
///
///
/// Parameters:
/// 1.keyPrefix:String
/// Use the keyPrefix parameter to generate unique keys for each widget,
/// useful for testing or tracking."
class AccessibilityMenuMobileWidget extends StatefulWidget {
  const AccessibilityMenuMobileWidget({
    super.key,
    required this.keyPrefix,
  });

  final String? keyPrefix;

  @override
  State<AccessibilityMenuMobileWidget> createState() =>
      _AccessibilityMenuMobileWidgetState();
}

class _AccessibilityMenuMobileWidgetState
    extends State<AccessibilityMenuMobileWidget> {
  late AccessibilityMenuMobileModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AccessibilityMenuMobileModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return
        // Accessibility Menu is designed specifically for the mobile view to deal with the accessibility like Font decrease,increase,screen reader, to change the theme and select language from dropdown.
        //
        Visibility(
      visible: responsiveVisibility(
        context: context,
        tablet: false,
        tabletLandscape: false,
        desktop: false,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 64.0, 16.0, 0.0),
        child: Container(
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).neutral100,
            boxShadow: [
              BoxShadow(
                blurRadius: 14.0,
                color: Color(0x00000014),
                offset: Offset(
                  -1.0,
                  4.0,
                ),
                spreadRadius: 0.0,
              )
            ],
            borderRadius: BorderRadius.circular(4.0),
            border: Border.all(
              color: FlutterFlowTheme.of(context).neutral300,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Container(
                  height: 36.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    borderRadius: BorderRadius.circular(4.0),
                    border: Border.all(
                      color: FlutterFlowTheme.of(context).neutral300,
                    ),
                  ),
                  child: Semantics(
                    label:
                        'Font Size Adjuster: Options (A-,A,A+) to decrease, reset or increase text size.',
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        FlutterFlowIconButton(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Accessibility_Menu',
                                  'Font_Decrease_Icon_Button')),
                          borderRadius: 8.0,
                          buttonSize: 40.0,
                          icon: Icon(
                            Icons.text_decrease,
                            color:
                                FlutterFlowTheme.of(context).primary600Default,
                            size: 20.0,
                          ),
                          onPressed: () {
                            print('Font_Decrease_Icon_Button pressed ...');
                          },
                        ),
                        FlutterFlowIconButton(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Accessibility_Menu', 'Font_Icon_Button')),
                          borderRadius: 8.0,
                          buttonSize: 40.0,
                          icon: Icon(
                            Icons.font_download_rounded,
                            color:
                                FlutterFlowTheme.of(context).primary600Default,
                            size: 20.0,
                          ),
                          onPressed: () {
                            print('Font_Icon_Button pressed ...');
                          },
                        ),
                        FlutterFlowIconButton(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(
                                  widget!.keyPrefix!,
                                  'Accessibility_Menu',
                                  'Font_Increase_Icon_Button')),
                          borderRadius: 8.0,
                          buttonSize: 40.0,
                          icon: Icon(
                            Icons.text_increase,
                            color:
                                FlutterFlowTheme.of(context).primary600Default,
                            size: 20.0,
                          ),
                          onPressed: () {
                            print('Font_Increase_Icon_Button pressed ...');
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 48.0,
                    decoration: BoxDecoration(),
                    child: Semantics(
                      label:
                          'Screen Reader button: Accessibility feature or reading text aloud.',
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Icon(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(
                                    widget!.keyPrefix!,
                                    'Accessibility_Menu',
                                    'Text_To_Speech_Icon')),
                            FFIcons.ktextToSpeech,
                            color: FlutterFlowTheme.of(context).textPrimary,
                            size: 24.0,
                          ),
                          Expanded(
                            child: Text(
                              key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                  .generateL1KeyValue(
                                      widget!.keyPrefix!,
                                      'Accessibility_Menu_Mobile',
                                      'Screen_Reader_Text')),
                              'Screen Reader',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textPrimary,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ]
                            .divide(SizedBox(width: 12.0))
                            .around(SizedBox(width: 12.0)),
                      ),
                    ),
                  ),
                  Container(
                    height: 48.0,
                    decoration: BoxDecoration(),
                    child: Semantics(
                      label:
                          'Tonality( Theme Switcher Dark/Light Mode): Enables users to toggle between dark and light themes for the application\'s interface depending on their preference or lighting conditions.',
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Icon(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Accessibility_Menu', 'Tonality_Icon')),
                            Icons.tonality_sharp,
                            color: FlutterFlowTheme.of(context).textPrimary,
                            size: 24.0,
                          ),
                          Expanded(
                            child: Text(
                              'High Contrast Theme',
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    color: FlutterFlowTheme.of(context)
                                        .textPrimary,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ]
                            .divide(SizedBox(width: 12.0))
                            .around(SizedBox(width: 12.0)),
                      ),
                    ),
                  ),
                  Container(
                    height: 48.0,
                    decoration: BoxDecoration(),
                    child:
                        // Language Selector: Dropdown to switch between different languages (e.g., "English","Hindi")
                        Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Icon(
                          key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                              .generateL1KeyValue(widget!.keyPrefix!,
                                  'Accessibility_Menu', 'Language_Icon')),
                          Icons.language_sharp,
                          color: FlutterFlowTheme.of(context).textPrimary,
                          size: 24.0,
                        ),
                        Expanded(
                          child: FlutterFlowDropDown<String>(
                            key: ValueKey(t_d_s_2_l1_logic_2wrus1_functions
                                .generateL1KeyValue(widget!.keyPrefix!,
                                    'Accessibility_Menu_Mobile', 'Dropdown')),
                            controller: _model.dropDownValueController ??=
                                FormFieldController<String>(
                              _model.dropDownValue ??= 'English',
                            ),
                            options: ['English', 'Hindi'],
                            onChanged: (val) =>
                                safeSetState(() => _model.dropDownValue = val),
                            width: 200.0,
                            height: 40.0,
                            textStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color:
                                      FlutterFlowTheme.of(context).textPrimary,
                                  letterSpacing: 0.0,
                                ),
                            hintText: 'Select...',
                            icon: Icon(
                              Icons.keyboard_arrow_down_rounded,
                              color: FlutterFlowTheme.of(context).secondaryText,
                              size: 24.0,
                            ),
                            fillColor: FlutterFlowTheme.of(context).neutral100,
                            elevation: 2.0,
                            borderColor: Colors.transparent,
                            borderWidth: 0.0,
                            borderRadius: 8.0,
                            margin: EdgeInsetsDirectional.fromSTEB(
                                12.0, 0.0, 12.0, 0.0),
                            hidesUnderline: true,
                            isOverButton: false,
                            isSearchable: false,
                            isMultiSelect: false,
                          ),
                        ),
                      ]
                          .divide(SizedBox(width: 12.0))
                          .around(SizedBox(width: 12.0)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
