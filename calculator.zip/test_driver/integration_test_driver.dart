import 'package:integration_test/integration_test_driver_extended.dart';
import 'dart:io';
Future<void> main() async {
  await integrationDriver(
    onScreenshot: (String screenshotName, List<int> screenshotBytes,
        [Map<String, Object?>? args]) async {
      final File image =
      await File('screenshots/$screenshotName.png').create(recursive: true);
      image.writeAsBytesSync(screenshotBytes);
      print('file: ${image.path}');
      return true;
    },
  );
}
