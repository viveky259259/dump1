import 'package:calculator/flutter_flow/custom_functions.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('roundOffNumber tests', () {
    test('should round off positive numbers correctly', () {
    // Arrange
    double number = 1000.56789;
    const expectedResult = 1000.568;

    // Act
    final result = roundOffNumber(number);

    // Assert
    expect(result, expectedResult);
  });

  test('should round off negative numbers correctly', () {
    // Arrange
    double number = -400.12345;
    const expectedResult = -400.123;

    // Act
    final result = roundOffNumber(number);

    // Assert
    expect(result, expectedResult);
  });

  test('should handle Infinity input', () {
    // Arrange
    double number = double.infinity;
    const expectedResult = double.infinity;

    // Act
    final result = roundOffNumber(number);

    // Assert
    expect(result, expectedResult);
  });

  test('should handle maxFinite input', () {
    // Arrange
    double number = double.maxFinite;
    const expectedResult = double.maxFinite;

    // Act
    final result = roundOffNumber(number);

    // Assert
    expect(result, expectedResult);
  });

  test('should handle minPostive input', () {
    // Arrange
    double number = double.minPositive;
    const expectedResult = 0.0;

    // Act
    final result = roundOffNumber(number);

    // Assert
    expect(result, expectedResult);
  });

  });

     test('should handle NAN input', () {
    // Arrange
    double number = double.nan;
    const expectedResult =0.0;

    // Act
    final result = roundOffNumber(number);

    // Assert
    expect(result, expectedResult);
  });
  }