import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
// import 'package:get_it/get_it.dart';
import 'dart:io';
import 'package:integration_test/integration_test.dart';

import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

const kDesktopWindowSize = Size(1200, 800);
const kTabletWindowSize = Size(700, 800);
const kMobileWindowSize = Size(479, 600);

/// A list of predefined window sizes to be used for testing.
///
/// This list includes various window sizes to simulate different screen resolutions
/// and aspect ratios during widget tests.
const testWindowSizes = [
  kDesktopWindowSize,
  kTabletWindowSize,
  kMobileWindowSize
];

/// Sets up the test environment with necessary configurations.
/// This includes initializing integration test binding and setting up HTTP and path provider overrides.
void setupTest() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() {
    HttpOverrides.global = MyHttpOverrides();
    PathProviderPlatform.instance = MockPathProviderPlatform();
  });

  setUp(() {
    // Register navigation services and observers using GetIt for dependency injection
    // GetIt.instance.registerLazySingleton<AppNavigationService>(
    //       () => AppNavigationService(),
    // );
    // GetIt.instance.registerLazySingleton<AppNavigationObserver>(
    //       () => AppNavigationObserver(),
    // );
  });
  tearDown(() {
    // Reset the registered services and observers after each test
    // GetIt.instance.reset();
  });
}

/// Runs a series of widget tests for a given component.
///
/// This function iterates over predefined window sizes, sets up the test widget,
/// runs the specified test function, and tears down the widget after each test.
///
/// [name] - The name of the test.
/// [widget] - The widget to be tested.
/// [testFunction] - The function that contains the test logic.
Future<void> testComponent(
    String name, Widget widget, Function(WidgetTester tester) testFunction,
    {bool testResponsiveness = false}) async {
  if (!testResponsiveness) {
    testWidgets(name, (tester) async {
      await setupTestWidget(tester, widget, windowSize: kDesktopWindowSize);
      await testFunction(tester);
      tearDownWidget(tester);
    });
  } else {
    for (final eachSize in testWindowSizes) {
      testWidgets(name, (tester) async {
        await setupTestWidget(tester, widget, windowSize: eachSize);
        await testFunction(tester);
        tearDownWidget(tester);
      });
    }
  }
}

/// Helper function to setup and render a widget for testing.
///
/// [tester] - The WidgetTester instance used to interact with the widget.
/// [widget] - The widget to be tested.
/// [windowSize] - Optional parameter to set the window size.
///
/// Example usage:
/// ```dart
/// await setupTestWidget(tester, MyWidget(), windowSize: Size(800, 600));
/// ```
Future<void> setupTestWidget(WidgetTester tester, Widget widget,
    {Size? windowSize}) async {
  tester.view.devicePixelRatio = 1.0;
  if (windowSize != null) {
    await IntegrationTestWidgetsFlutterBinding.instance
        .setSurfaceSize(windowSize);
  }
  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(body: widget),
    ),
  );
  await tester.pumpAndSettle();
}

/// Resets the widget tester's view to its default state after a test.
void tearDownWidget(WidgetTester tester) {
  addTearDown(() {
    tester.view.resetPhysicalSize();
    tester.view.resetDevicePixelRatio();
  });
}

/// Custom HTTP overrides to handle SSL certificate validation during testing.
/// Allows self-signed certificates by always returning true in the callback.
class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

/// Creates a mock font file at the specified path.
/// Used to simulate font files during testing when actual fonts are not available.
///
/// [path] - The file path where the mock font should be created
void createMockFontFile(String path) {
  final file = File(path);
  if (!file.existsSync()) {
    file.createSync(recursive: true);
    file.writeAsBytesSync([]); // Write an empty file or mock font data
  }
}

/// Mock implementation of PathProviderPlatform for testing.
/// Provides a mock application support directory path for testing purposes.
class MockPathProviderPlatform extends PathProviderPlatform {
  @override
  Future<String?> getApplicationSupportPath() async {
    const path = './mocked_application_support_directory';
    // Ensure the directory exists
    final directory = Directory(path);
    if (!directory.existsSync()) {
      directory.createSync(recursive: true);
    }

    return path;
  }
}