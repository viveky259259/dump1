import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
// Import your calculator page model
import 'package:calculator/calculatorpage/calculatorpage_model.dart';

@GenerateNiceMocks([MockSpec<CalculatorpageModel>()])
import 'calculatorpage_model_test.mocks.dart';

void main() {
  late MockCalculatorpageModel mockCalculatorModel;

  setUp(() {
    mockCalculatorModel = MockCalculatorpageModel();
  });

  group('CalculatorPage Model Tests', () {
    test('should initialize with default values', () async {
      // Arrange
      when(mockCalculatorModel.calculatorField).thenReturn('0');
      when(mockCalculatorModel.resultField).thenReturn(null);

      // Act
      await mockCalculatorModel.clearResultAndField(null);
      // Assert
      expect(mockCalculatorModel.calculatorField, '0');
      expect(mockCalculatorModel.resultField, null);
      verify(mockCalculatorModel.clearResultAndField(null)).called(1);
    });
  }); 
}
