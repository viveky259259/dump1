import 'package:calculator/app_state.dart';
import 'package:calculator/backend/schema/structs/index.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:calculator/custom_code/actions/get_calculations_by_date.dart';
import 'package:shared_preferences/shared_preferences.dart';

void stubSharedPreferences() {
  const channel = MethodChannel('plugins.flutter.io/shared_preferences');

  handler(MethodCall methodCall) async {
    if (methodCall.method == 'getAll') {
      return <String, dynamic>{
      
      };
    }
    return null;
  }

  TestWidgetsFlutterBinding.ensureInitialized();

  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
      .setMockMethodCallHandler(channel, handler);
}
void main() {
  setUpAll(() async{
    stubSharedPreferences();
      TestWidgetsFlutterBinding.ensureInitialized();
      await FFAppState().initializePersistedState();
      SharedPreferences.setMockInitialValues({
        'ff_calculations': [],
      });
      await SharedPreferences.getInstance();
  });
  group('getCalculationsFilteredByDate', () {
    test('should return empty list when no calculations exist', () async {
      // Arrange
    
      final targetDate = DateTime(2024, 3, 15);
      FFAppState().calculations = [];

      // Act
      final result = await getCalculationsFilteredByDate(targetDate);

      // Assert
      expect(result, isEmpty);
    });

    test('should return calculations matching the target date', () async {
      // Arrange
      final targetDate = DateTime(2024, 3, 15);
      final matchingDate =
          DateTime(2024, 3, 15, 14, 30); // Same date, different time
      final differentDate = DateTime(2024, 3, 16);

      FFAppState().calculations = [
        CaculationStruct(
          createdAt: matchingDate,
          input: '5 + 5',
          output: '10',
        ),
        CaculationStruct(
          createdAt: differentDate,
          input: '20',
          output: '10 + 10',
        ),
      ];

      // Act
      final result = await getCalculationsFilteredByDate(targetDate);

      // Assert
      expect(result.length, 1);
      expect(result.first.createdAt, matchingDate);
      expect(result.first.output, '10');
    });

    test('should filter out calculations with null createdAt', () async {
      // Arrange
      final targetDate = DateTime(2024, 3, 15);
      final validDate = DateTime(2024, 3, 15);

      FFAppState().calculations = [
        CaculationStruct(
          createdAt: validDate,
          input: '10',
          output: '5 + 5',
        ),
        CaculationStruct(
          createdAt: null,
          input: '20',
          output: '10 + 10',
        ),
      ];

      // Act
      final result = await getCalculationsFilteredByDate(targetDate);

      // Assert
      expect(result.length, 1);
      expect(result.first.createdAt, validDate);
    });
  });

  group('Date class', () {
    test('should compare dates correctly', () {
      // Arrange
      final date1 = Date(2024, 3, 15);
      final date2 = Date(2024, 3, 15);
      final date3 = Date(2024, 3, 16);

      // Assert
      expect(date1 == date2, true);
      expect(date1 == date3, false);
    });

    test('should generate consistent hash codes', () {
      // Arrange
      final date1 = Date(2024, 3, 15);
      final date2 = Date(2024, 3, 15);
      final date3 = Date(2024, 3, 16);

      // Assert
      expect(date1.hashCode, date2.hashCode);
      expect(date1.hashCode, isNot(date3.hashCode));
    });
  });

  group('DateTime extension', () {
    test('should convert DateTime to Date correctly', () {
      // Arrange
      final dateTime = DateTime(2024, 3, 15, 14, 30);
      final expectedDate = Date(2024, 3, 15);

      // Act
      final result = dateTime.date;

      // Assert
      expect(result, expectedDate);
    });
  });
}
