import 'package:flutter_test/flutter_test.dart';
import 'package:calculator/custom_code/actions/add_two_numbers.dart';

void main() {
  group('addTwoNumbers', () {
    test('should add two valid numbers correctly', () async {
      // Arrange
      const firstNumber = "10.5";
      const secondNumber = "20.7";
      const expectedResult = 31.2;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should handle negative numbers correctly', () async {
      // Arrange
      const firstNumber = "-10.5";
      const secondNumber = "20.7";
      const expectedResult = 10.2;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should return 0.0 when the first number is null', () async {
      // Arrange
      const String? firstNumber = null;
      const secondNumber = "20.7";
      const expectedResult = 0.0;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should return 0.0 when the second number is null', () async {
      // Arrange
      const firstNumber = "10.5";
      const String? secondNumber = null;
      const expectedResult = 0.0;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should return 0.0 when both numbers are null', () async {
      // Arrange
      const String? firstNumber = null;
      const String? secondNumber = null;
      const expectedResult = 0.0;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should return 0.0 when the first number is empty', () async {
      // Arrange
      const firstNumber = "";
      const secondNumber = "20.7";
      const expectedResult = 0.0;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should return 0.0 when the second number is empty', () async {
      // Arrange
      const firstNumber = "10.5";
      const secondNumber = "";
      const expectedResult = 0.0;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should return 0.0 when an invalid number format', () async {
      // Arrange
      const firstNumber = "abc";
      const secondNumber = "20.7";
      const expectedResult = 0.0;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });

    test('should handle large numbers correctly', () async {
      // Arrange
      const firstNumber = "999999999.999";
      const secondNumber = "999999999.999";
      const expectedResult = 1999999999.998;

      // Act
      final result = await addTwoNumbers(firstNumber, secondNumber);

      // Assert
      expect(result, expectedResult);
    });
  });
}
