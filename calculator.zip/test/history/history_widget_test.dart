import 'package:calculator/history/history_widget.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import '../setup.dart';

void main() {
  // Setup the test environment
  setupTest();
  // Run the widget tests
  widgetTests();
}

void widgetTests() {
  testComponent('Test history page', HistoryWidget(), runTest);
}

Future<void> runTest(WidgetTester tester) async {
  final historyTextFinder = find.text('Calculation History');
  await tester.pumpAndSettle(Duration(seconds: 2));
// get binding object from IntegrationTestWidgetsFlutterBinding
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
//  use binding object call takeScreenshot in between tests
  // await binding.takeScreenshot('basic_details_initial_state');
  expect(historyTextFinder, findsOneWidget);
}
