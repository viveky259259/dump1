import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _calculations = prefs
              .getStringList('ff_calculations')
              ?.map((x) {
                try {
                  return CaculationStruct.fromSerializableMap(jsonDecode(x));
                } catch (e) {
                  print("Can't decode persisted data type. Error: $e.");
                  return null;
                }
              })
              .withoutNulls
              .toList() ??
          _calculations;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  List<CaculationStruct> _calculations = [];
  List<CaculationStruct> get calculations => _calculations;
  set calculations(List<CaculationStruct> value) {
    _calculations = value;
    prefs.setStringList(
        'ff_calculations', value.map((x) => x.serialize()).toList());
  }

  void addToCalculations(CaculationStruct value) {
    calculations.add(value);
    prefs.setStringList(
        'ff_calculations', _calculations.map((x) => x.serialize()).toList());
  }

  void removeFromCalculations(CaculationStruct value) {
    calculations.remove(value);
    prefs.setStringList(
        'ff_calculations', _calculations.map((x) => x.serialize()).toList());
  }

  void removeAtIndexFromCalculations(int index) {
    calculations.removeAt(index);
    prefs.setStringList(
        'ff_calculations', _calculations.map((x) => x.serialize()).toList());
  }

  void updateCalculationsAtIndex(
    int index,
    CaculationStruct Function(CaculationStruct) updateFn,
  ) {
    calculations[index] = updateFn(_calculations[index]);
    prefs.setStringList(
        'ff_calculations', _calculations.map((x) => x.serialize()).toList());
  }

  void insertAtIndexInCalculations(int index, CaculationStruct value) {
    calculations.insert(index, value);
    prefs.setStringList(
        'ff_calculations', _calculations.map((x) => x.serialize()).toList());
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
