import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'built_with_f_f_widget.dart' show BuiltWithFFWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BuiltWithFFModel extends FlutterFlowModel<BuiltWithFFWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
