// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CaculationStruct extends BaseStruct {
  CaculationStruct({
    String? input,
    String? output,
    DateTime? createdAt,
  })  : _input = input,
        _output = output,
        _createdAt = createdAt;

  // "input" field.
  String? _input;
  String get input => _input ?? '';
  set input(String? val) => _input = val;

  bool hasInput() => _input != null;

  // "output" field.
  String? _output;
  String get output => _output ?? '';
  set output(String? val) => _output = val;

  bool hasOutput() => _output != null;

  // "createdAt" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  set createdAt(DateTime? val) => _createdAt = val;

  bool hasCreatedAt() => _createdAt != null;

  static CaculationStruct fromMap(Map<String, dynamic> data) =>
      CaculationStruct(
        input: data['input'] as String?,
        output: data['output'] as String?,
        createdAt: data['createdAt'] as DateTime?,
      );

  static CaculationStruct? maybeFromMap(dynamic data) => data is Map
      ? CaculationStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'input': _input,
        'output': _output,
        'createdAt': _createdAt,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'input': serializeParam(
          _input,
          ParamType.String,
        ),
        'output': serializeParam(
          _output,
          ParamType.String,
        ),
        'createdAt': serializeParam(
          _createdAt,
          ParamType.DateTime,
        ),
      }.withoutNulls;

  static CaculationStruct fromSerializableMap(Map<String, dynamic> data) =>
      CaculationStruct(
        input: deserializeParam(
          data['input'],
          ParamType.String,
          false,
        ),
        output: deserializeParam(
          data['output'],
          ParamType.String,
          false,
        ),
        createdAt: deserializeParam(
          data['createdAt'],
          ParamType.DateTime,
          false,
        ),
      );

  @override
  String toString() => 'CaculationStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is CaculationStruct &&
        input == other.input &&
        output == other.output &&
        createdAt == other.createdAt;
  }

  @override
  int get hashCode => const ListEquality().hash([input, output, createdAt]);
}

CaculationStruct createCaculationStruct({
  String? input,
  String? output,
  DateTime? createdAt,
}) =>
    CaculationStruct(
      input: input,
      output: output,
      createdAt: createdAt,
    );
