// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CaculationsStruct extends BaseStruct {
  CaculationsStruct({
    String? input,
    String? output,
  })  : _input = input,
        _output = output;

  // "input" field.
  String? _input;
  String get input => _input ?? '';
  set input(String? val) => _input = val;

  bool hasInput() => _input != null;

  // "output" field.
  String? _output;
  String get output => _output ?? '';
  set output(String? val) => _output = val;

  bool hasOutput() => _output != null;

  static CaculationsStruct fromMap(Map<String, dynamic> data) =>
      CaculationsStruct(
        input: data['input'] as String?,
        output: data['output'] as String?,
      );

  static CaculationsStruct? maybeFromMap(dynamic data) => data is Map
      ? CaculationsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'input': _input,
        'output': _output,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'input': serializeParam(
          _input,
          ParamType.String,
        ),
        'output': serializeParam(
          _output,
          ParamType.String,
        ),
      }.withoutNulls;

  static CaculationsStruct fromSerializableMap(Map<String, dynamic> data) =>
      CaculationsStruct(
        input: deserializeParam(
          data['input'],
          ParamType.String,
          false,
        ),
        output: deserializeParam(
          data['output'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'CaculationsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is CaculationsStruct &&
        input == other.input &&
        output == other.output;
  }

  @override
  int get hashCode => const ListEquality().hash([input, output]);
}

CaculationsStruct createCaculationsStruct({
  String? input,
  String? output,
}) =>
    CaculationsStruct(
      input: input,
      output: output,
    );
