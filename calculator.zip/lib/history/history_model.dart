import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'history_widget.dart' show HistoryWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HistoryModel extends FlutterFlowModel<HistoryWidget> {
  ///  Local state fields for this page.

  List<CaculationStruct> currentCalculations = [];
  void addToCurrentCalculations(CaculationStruct item) =>
      currentCalculations.add(item);
  void removeFromCurrentCalculations(CaculationStruct item) =>
      currentCalculations.remove(item);
  void removeAtIndexFromCurrentCalculations(int index) =>
      currentCalculations.removeAt(index);
  void insertAtIndexInCurrentCalculations(int index, CaculationStruct item) =>
      currentCalculations.insert(index, item);
  void updateCurrentCalculationsAtIndex(
          int index, Function(CaculationStruct) updateFn) =>
      currentCalculations[index] = updateFn(currentCalculations[index]);

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - getCalculationsFilteredByDate] action in History widget.
  List<CaculationStruct>? filteredCalculations;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
