import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';

double roundOffNumber(double number) {
  // Rounds a double number to 3 decimal places and returns the result as a double.

  if (number.isNaN) {
    return 0;
  }
  return double.parse(number.toStringAsFixed(3));
}

double stringToDouble(String numberInString) {
  return double.tryParse(numberInString) ?? 0.0;
}

String? getPastCaclulationsCount() {
  // get Past Caclulations Count from database. add call to databse and bring total values
  // Add code here to call the database and retrieve the total count of past calculations
  int totalCount =
      10; // Assume the total count is 10 for demonstration purposes
  return totalCount.toString();
}
