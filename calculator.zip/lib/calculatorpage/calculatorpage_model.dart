import '/backend/schema/structs/index.dart';
import '/components/built_with_f_f_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'calculatorpage_widget.dart' show CalculatorpageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CalculatorpageModel extends FlutterFlowModel<CalculatorpageWidget> {
  ///  Local state fields for this page.

  String? calculatorField;

  String? resultField;

  ///  State fields for stateful widgets in this page.

  // Model for BuiltWithFF component.
  late BuiltWithFFModel builtWithFFModel;

  @override
  void initState(BuildContext context) {
    builtWithFFModel = createModel(context, () => BuiltWithFFModel());
  }

  @override
  void dispose() {
    builtWithFFModel.dispose();
  }

  /// Action blocks.
  /// this action will add a tapped value of button in text
  Future addToCalcText(
    BuildContext context, {
    required String? inputValue,
  }) async {
    calculatorField = calculatorField != null && calculatorField != ''
        ? '${calculatorField}${inputValue}'
        : inputValue;
  }

  /// This function clears the result and caclulator fields
  Future clearResultAndField(BuildContext context) async {
    calculatorField = null;
    resultField = null;
  }

  Future parseAndCalculate(BuildContext context) async {
    String? result;

    result = await actions.parseCalcField(
      calculatorField,
    );
    if (result != null && result != '') {
      FFAppState().addToCalculations(CaculationStruct(
        input: calculatorField,
        output: result,
        createdAt: getCurrentTimestamp,
      ));
      resultField = result;
      calculatorField = result;
    }
  }
}
