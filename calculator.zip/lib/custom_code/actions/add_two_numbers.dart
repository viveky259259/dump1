// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<double> addTwoNumbers(
  String? firstNumber,
  String? secondNumber,
) async {
  if (firstNumber == null || secondNumber == null) {
    return 0.0;
  }

  if (firstNumber.isEmpty || secondNumber.isEmpty) {
    return 0.0;
  }

  try {
    double firstNum = double.parse(firstNumber);
    double secondNum = double.parse(secondNumber);

    double result = firstNum + secondNum;

    return result;
  } catch (e) {
    return 0;
  }
}
