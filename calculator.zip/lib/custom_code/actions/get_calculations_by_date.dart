// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<List<CaculationStruct>> getCalculationsFilteredByDate(
    DateTime targetDate) async {
  // Add your function code here!

  return FFAppState().calculations.where((each) {
    if (each.createdAt == null) return false;
    return each.createdAt!.date == targetDate.date;
  }).toList();
}

extension DateExtesion on DateTime {
  Date get date => Date(year, month, day);
}

class Date {
  int year;
  int month;
  int day;

  Date(this.year, this.month, this.day);
  @override
  bool operator ==(Object other) =>
      other is Date &&
      year == other.year &&
      month == other.month &&
      day == other.day;

  @override
  int get hashCode => Object.hash(year, month, day);
}
