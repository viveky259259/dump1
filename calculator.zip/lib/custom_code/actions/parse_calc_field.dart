// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

Future<String> parseCalcField(String? input) async {
  // create a function to parse a string, and split to find out numbers and operators(+,/,-).  output of this function should be a operator function call based on the operator. these operator function calls take fist number and second number.
  String result = '';
  if (input == null || input.isEmpty) return result;

  List<String> operators = ['+', '-', '/', '*'];

  late String currentOperator;
  late double num1;
  late double num2;
  bool assigned = false;
  try {
    for (String op in operators) {
      if (input.contains(op)) {
        currentOperator = op;
        List<String> parts = input.split(op);
        num1 = double.parse(parts[0]);
        num2 = double.parse(parts[1]);
        assigned = true;
        break;
      }
    }
    if (!assigned) {
      return result;
    }

    switch (currentOperator) {
      case "+":
        result =
            (await addTwoNumbers(num1.toString(), num2.toString())).toString();
        break;
      case "-":
        result = (await subtractTwoNumbers(num1.toString(), num2.toString()))
            .toString();
        break;
      case "/":
        result = (await divideTwoNumbers(num1.toString(), num2.toString()))
            .toString();
        break;
      case "*":
        result = (await multiplyTwoNumbers(num1.toString(), num2.toString()))
            .toString();
        break;
      default:
        print("Invalid operator");
    }
  } catch (e) {
    print(e);
  }
  return result;
}
