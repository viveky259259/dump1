Generate a single Dart widget test file.
Return ONLY the Dart code, no explanations or markdown.

=== FILE INFO ===
File name: widget_test.dart 
$Change: Actualfilepath_test.dart

=== IMPORTS ===
- package:flutter_test/flutter_test.dart
- package:flutter/material.dart

=== WIDGET UNDER TEST ===
Widget/Class: FloatingActionButton
Constructor signature: FloatingActionButton({super.key})
Factory for test:

Widget buildTestSubject() {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true),
    home: FloatingActionButton(
        key: Key('floatingactionbutton_key'),
        children: [
          Icon(key: Key('icon_key'), ),
        ],
      ),
  );
}

=== WIDGET PROPERTIES ===
- onPressed: null (VoidCallback) [widget_specific]
- child: null (Widget) [widget_specific]
- style: null (ButtonStyle) [widget_specific]

=== CHILD WIDGETS ===
- Icon (Icon): Icon
  Properties:
    - depth: 202 (String)
    - widget: inspector-69 (String)
    - key:  (String)
    - icon: inspector-70 (String)
    - size:  (String)
    - fill:  (String)
    - weight:  (String)
    - grade:  (String)
    - opticalSize:  (String)
    - color:  (String)
    - shadows:  (String)
    - semanticLabel:  (String)
    - textDirection:  (String)
    - applyTextScaling:  (String)
    - dirty: false (String)
    - dependencies: inspector-71 (String)

    $ Change: Populate the values in properties

=== STABLE IDENTIFIERS ===
- Root widget: Key('floatingactionbutton_key')
$Change: If key does not exist, do not add

=== TEST REQUIREMENTS ===
1. Group tests under `group('FloatingActionButton', ...)`.
2. Verify widget renders with all expected children.
3. Assert child properties (text values, sizes, alignment, etc.).
4. Test interactions (e.g., tapping buttons, form submissions).
5. Test conditional UI state changes (if applicable).
6. Verify provider/dependency setup (if required).
7. Assert theming/config flags (e.g., `useMaterial3 == true`, `debugShowCheckedModeBanner == false`).
8. Accessibility/semantics tests if semantics labels/roles provided.
9. Use robust finders (`find.byKey`, `find.text`) and clear test names.
10. Omit performance, memory, lifecycle, or error-handling tests unless explicitly specified.

=== NON-GOALS ===
- Performance testing (unless specific performance code is provided)
- Memory testing (unless specific memory management code is provided)
- Lifecycle testing (unless specific lifecycle code is provided)
- Generic error handling tests (unless specific error scenarios are provided)
- Negative scenarios without specific test cases

$Change: remove first two


=== OUTPUT CONSTRAINTS ===
- Return one Dart test file, named `widget_test.dart`.
- Contain only Dart code.
- No markdown, comments, or explanations.

$Change : update file name
$Change : remove no markdown


"{name: depth, value: 202, type: String, source: inspector_service, isImportant: false, isEditable: false},{name: widget, value: inspector-69, type: String, source: inspector_service, isImportant: false, isEditable: false},{name: key, value: , type: String, source: inspector_service, isImportant: true, isEditable: false},{name: icon, value: inspector-70, type: String, source: inspector_service, isImportant: false, isEditable: false},{name: size, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: fill, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: weight, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: grade, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: opticalSize, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: color, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: shadows, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: semanticLabel, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: textDirection, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: applyTextScaling, value: , type: String, source: inspector_service, isImportant: false, isEditable: false},{name: dirty, value: false, type: String, source: inspector_service, isImportant: false, isEditable: false},{name: dependencies, value: inspector-71, type: String, source: inspector_service, isImportant: false, isEditable: false}"