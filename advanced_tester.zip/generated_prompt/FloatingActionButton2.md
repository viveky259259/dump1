Generate a single Dart widget test file.
Return ONLY the Dart code, no explanations or markdown.

=== FILE INFO ===
File name: main_test.dart

=== IMPORTS ===
- package:flutter_test/flutter_test.dart
- package:flutter/material.dart

=== WIDGET UNDER TEST ===
Widget/Class: FloatingActionButton
Constructor signature: FloatingActionButton({super.key})
Factory for test:

Widget buildTestSubject() {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true),
    home: FloatingActionButton(
        key: Key('floatingactionbutton_key'),
        children: [
          Icon(key: Key('icon_key'), ),
        ],

      ),
  );
}

=== WIDGET PROPERTIES ===
- onPressed: null (VoidCallback) [widget_specific]
- child: null (Widget) [widget_specific]
- style: null (ButtonStyle) [widget_specific]

=== CHILD WIDGETS ===
- Icon (Icon): Icon

=== STABLE IDENTIFIERS ===
- Root widget: Key('floatingactionbutton_key')

=== TEST REQUIREMENTS ===
1. Group tests under `group('FloatingActionButton', ...)`.
2. Verify widget renders with all expected children.
3. Assert child properties (text values, sizes, alignment, etc.).
4. Test interactions (e.g., tapping buttons, form submissions).
5. Test conditional UI state changes (if applicable).
6. Verify provider/dependency setup (if required).
7. Assert theming/config flags (e.g., `useMaterial3 == true`, `debugShowCheckedModeBanner == false`).
8. Accessibility/semantics tests if semantics labels/roles provided.
9. Use robust finders (`find.byKey`, `find.text`) and clear test names.
10. Omit performance, memory, lifecycle, or error-handling tests unless explicitly specified.

=== NON-GOALS ===
- Lifecycle testing (unless specific lifecycle code is provided)
- Generic error handling tests (unless specific error scenarios are provided)
- Negative scenarios without specific test cases

=== OUTPUT CONSTRAINTS ===
- Return one Dart test file, named `main_test.dart`.
- Contain only Dart code.
- No markdown, comments, or explanations.