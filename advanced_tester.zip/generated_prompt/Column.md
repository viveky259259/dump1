Generate a single Dart widget test file.
Return ONLY the Dart code, no explanations or markdown.

=== FILE INFO ===
File name: main_test.dart

=== IMPORTS ===
- package:flutter_test/flutter_test.dart
- package:flutter/material.dart

=== WIDGET UNDER TEST ===
Widget/Class: Column
Constructor signature: Column({super.key})
Factory for test:

Widget buildTestSubject() {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true),
    home: Column(
        key: Key('column_key'),
      ),
  );
}

=== STABLE IDENTIFIERS ===
- Root widget: Key('column_key')

=== TEST REQUIREMENTS ===
1. Group tests under `group('Column', ...)`.
2. Verify widget renders with all expected children.
3. Assert child properties (text values, sizes, alignment, etc.).
4. Test interactions (e.g., tapping buttons, form submissions).
5. Test conditional UI state changes (if applicable).
6. Verify provider/dependency setup (if required).
7. Assert theming/config flags (e.g., `useMaterial3 == true`, `debugShowCheckedModeBanner == false`).
8. Accessibility/semantics tests if semantics labels/roles provided.
9. Use robust finders (`find.byKey`, `find.text`) and clear test names.
10. Omit performance, memory, lifecycle, or error-handling tests unless explicitly specified.

=== NON-GOALS ===
- Performance testing (unless specific performance code is provided)
- Memory testing (unless specific memory management code is provided)
- Lifecycle testing (unless specific lifecycle code is provided)
- Generic error handling tests (unless specific error scenarios are provided)
- Negative scenarios without specific test cases

=== OUTPUT CONSTRAINTS ===
- Return one Dart test file, named `main_test.dart`.
- Contain only Dart code.
- No markdown, comments, or explanations.