# Implementation Plan: Comprehensive Observability & Local Logging

## Overview

### Feature Reference
- **Spec**: `specs/001-observability/spec.md`
- **Feature ID**: `001-observability`
- **Target Version**: `1.1.0`
- **Estimated Effort**: 4 weeks (1 engineer)

## Architecture Overview

### System Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    Application Layers                        │
├─────────────────────────────────────────────────────────────┤
│  UI Layer (Widgets, Pages, Controllers)                     │
│           ↓ logs user actions                               │
│  Presentation Layer (Providers, Controllers)                 │
│           ↓ logs state changes                              │
│  Domain Layer (Use Cases, Entities)                         │
│           ↓ logs business logic                             │
│  Data Layer (Repositories, Data Sources)                    │
│           ↓ logs data operations                            │
│  Services Layer (Inspector, AI, etc.)                       │
│           ↓ logs service operations                         │
├─────────────────────────────────────────────────────────────┤
│                  ↓ ALL LOG TO ↓                             │
├─────────────────────────────────────────────────────────────┤
│              Logging Infrastructure                          │
│  ┌──────────────────────────────────────────────┐          │
│  │  AppLogger (Singleton)                       │          │
│  │  - getLogger(name)                           │          │
│  │  - configure(config)                         │          │
│  │  - setLevel(service, level)                  │          │
│  └───────────┬──────────────────────────────────┘          │
│              │                                               │
│  ┌───────────▼────────────┐  ┌───────────────────┐        │
│  │  Logger Instance       │  │  LoggerConfig     │        │
│  │  - debug(msg, context) │  │  - globalLevel    │        │
│  │  - info(msg, context)  │  │  - serviceLevel   │        │
│  │  - warn(msg, context)  │  │  - redactionRules │        │
│  │  - error(msg, err)     │  │  - retention      │        │
│  │  - fatal(msg, err)     │  │  - fileSize       │        │
│  └───────────┬────────────┘  └───────────────────┘        │
│              │                                               │
│  ┌───────────▼──────────────────────────────────┐          │
│  │  LogEntry (Model)                            │          │
│  │  - timestamp                                 │          │
│  │  - level                                     │          │
│  │  - loggerName                                │          │
│  │  - message                                   │          │
│  │  - context (Map<String, dynamic>)            │          │
│  │  - correlationId                             │          │
│  │  - performance (duration, memory)            │          │
│  │  - location (file, line, function)           │          │
│  │  - stackTrace (for errors)                   │          │
│  └───────────┬──────────────────────────────────┘          │
│              │                                               │
│  ┌───────────▼──────────────────────────────────┐          │
│  │  LogWriter (File Handling)                   │          │
│  │  - writeLog(entry)                           │          │
│  │  - rotateIfNeeded()                          │          │
│  │  - compressOldLogs()                         │          │
│  │  - cleanupOldLogs()                          │          │
│  │  - flush()                                   │          │
│  └───────────┬──────────────────────────────────┘          │
│              │                                               │
│              ▼                                               │
│     Local File System                                       │
│     ~/.advanced_tester/logs/                                │
│       - advanced_tester_2025-10-01_10-30-45.log            │
│       - advanced_tester_2025-10-01_15-22-10.log            │
│       - advanced_tester_2025-09-30_*.log.gz (compressed)   │
└─────────────────────────────────────────────────────────────┘
```

### Layer Impact Analysis
- **Domain Layer**: Minimal direct changes (use logging decorators/mixins)
- **Data Layer**: Add logging to all repositories and data sources
- **Presentation Layer**: Add logging to all controllers and providers  
- **Services Layer**: Comprehensive logging in all services
- **Core Layer**: New `lib/core/logging/` with logging infrastructure

### Component Diagram
```
┌────────────────────────────────────────────────────────────┐
│                    New Components                          │
├────────────────────────────────────────────────────────────┤
│  lib/core/logging/                                         │
│    ├── app_logger.dart           (Logger factory/config)  │
│    ├── logger.dart                (Logger instance)        │
│    ├── log_entry.dart             (Log data model)        │
│    ├── log_writer.dart            (File I/O)              │
│    ├── log_formatter.dart         (JSON formatting)       │
│    ├── log_level.dart             (Log levels enum)       │
│    ├── correlation_context.dart   (Correlation IDs)       │
│    ├── sensitive_data_redactor.dart (PII redaction)       │
│    └── log_config.dart            (Configuration)         │
│                                                            │
│  lib/ui/widgets/log_viewer_panel.dart (In-app log viewer) │
│  lib/services/log_export_service.dart (Export logs)       │
└────────────────────────────────────────────────────────────┘
```

## Technical Decisions

### Technology Choices

#### Decision 1: Custom Logger vs Library
**Context**: Need structured logging with file output, correlation IDs, and performance tracking

**Options Considered**:
1. **logger package**: Popular Dart logger
   - Pros: Well-tested, simple API, color output
   - Cons: Console-focused, limited file support, no built-in correlation IDs
   
2. **Custom wrapper around logger**: Extend logger package
   - Pros: Leverage logger's formatting, add our features
   - Cons: Some complexity in wrapping
   
3. **Fully custom logger**: Build from scratch
   - Pros: Complete control, exactly what we need
   - Cons: More work, need to test thoroughly

**Decision**: Custom wrapper around `logger` package
- Use logger's formatting and level management
- Add our file writing, correlation IDs, and performance tracking
- Best balance of leverage vs. control

**Consequences**: 
- Faster implementation with proven foundation
- Easy to swap implementation if needed
- Minor dependency risk

#### Decision 2: Log File Format
**Context**: Need machine-readable logs for tooling, human-readable for debugging

**Options Considered**:
1. **Plain text**: Simple, human-readable
   - Pros: Easy to read, no parsing needed
   - Cons: Hard to parse for tools, no structure
   
2. **JSON (one object per line)**: Structured, parseable
   - Pros: Easy to parse, queryable, structured
   - Cons: Verbose, less human-readable in raw form
   
3. **Binary format**: Compact, efficient
   - Pros: Very efficient, small files
   - Cons: Need tools to read, harder to debug

**Decision**: JSON (one object per line - JSONL format)
- Each log entry is a complete JSON object on one line
- Easy to parse programmatically (line-by-line)
- Tools can process it easily
- Can be pretty-printed for human reading

**Consequences**:
- Slightly larger file sizes (mitigated by compression)
- Need JSON parser for reading
- Excellent for tooling and analysis

#### Decision 3: Async vs Sync Logging
**Context**: Logging must not block application performance

**Options Considered**:
1. **Synchronous**: Write logs immediately
   - Pros: Simple, guaranteed order, immediate flush
   - Cons: Blocks calling code, performance impact
   
2. **Asynchronous with queue**: Queue logs, write on separate isolate
   - Pros: Non-blocking, no performance impact
   - Cons: Complex, potential log loss on crash, ordering challenges
   
3. **Buffered with periodic flush**: Buffer in memory, flush periodically
   - Pros: Good performance, simpler than isolate, mostly safe
   - Cons: Risk of losing recent logs on crash

**Decision**: Buffered with periodic flush + error flush
- Buffer logs in memory
- Flush every 5 seconds automatically
- Flush immediately on ERROR/FATAL
- Flush on app shutdown

**Consequences**:
- Excellent performance (non-blocking)
- Minimal risk of log loss (errors flushed immediately)
- Simple to implement and maintain

#### Decision 4: Correlation ID Strategy
**Context**: Need to trace operations across service boundaries

**Options Considered**:
1. **Zone-based**: Use Dart Zones to propagate context
   - Pros: Automatic propagation, clean API
   - Cons: Zone overhead, complex debugging
   
2. **Explicit parameter**: Pass correlation ID as parameter
   - Pros: Explicit, clear, no magic
   - Cons: API changes, verbose
   
3. **Thread-local storage pattern**: Global context per execution
   - Pros: Automatic, no API changes
   - Cons: Not available in Dart, complex

**Decision**: Explicit CorrelationContext with helper mixin
- Create CorrelationContext class
- Use mixin to add correlation helpers to services
- Explicitly pass in user-facing operations
- Auto-generate for internal operations

**Consequences**:
- Clear and explicit
- No magic behavior
- Minimal API impact (mixins help)
- Easy to debug

### Architecture Patterns

#### Pattern 1: Logger Mixin
```dart
mixin LoggerMixin {
  late final Logger _logger = AppLogger.getLogger(runtimeType.toString());
  
  Logger get logger => _logger;
  
  T logOperation<T>(String operation, T Function() fn, {Map<String, dynamic>? context}) {
    final stopwatch = Stopwatch()..start();
    logger.debug('Starting $operation', context);
    try {
      final result = fn();
      logger.debug('Completed $operation in ${stopwatch.elapsedMilliseconds}ms', context);
      return result;
    } catch (e, stackTrace) {
      logger.error('Failed $operation after ${stopwatch.elapsedMilliseconds}ms', e, stackTrace);
      rethrow;
    }
  }
  
  Future<T> logAsyncOperation<T>(String operation, Future<T> Function() fn, {Map<String, dynamic>? context}) async {
    final stopwatch = Stopwatch()..start();
    logger.debug('Starting $operation', context);
    try {
      final result = await fn();
      logger.debug('Completed $operation in ${stopwatch.elapsedMilliseconds}ms', context);
      return result;
    } catch (e, stackTrace) {
      logger.error('Failed $operation after ${stopwatch.elapsedMilliseconds}ms', e, stackTrace);
      rethrow;
    }
  }
}
```

#### Pattern 2: Correlation Context
```dart
class CorrelationContext {
  static final _contextMap = <String, String>{};
  
  static String get current => _contextMap['correlationId'] ?? _generate();
  
  static String _generate() {
    final id = Uuid().v4();
    _contextMap['correlationId'] = id;
    return id;
  }
  
  static void set(String id) => _contextMap['correlationId'] = id;
  
  static void clear() => _contextMap.remove('correlationId');
  
  static T withCorrelation<T>(String id, T Function() fn) {
    final previousId = _contextMap['correlationId'];
    try {
      set(id);
      return fn();
    } finally {
      if (previousId != null) {
        set(previousId);
      } else {
        clear();
      }
    }
  }
}
```

## Data Model

### Entities

#### LogEntry
```dart
class LogEntry {
  final DateTime timestamp;
  final LogLevel level;
  final String loggerName;
  final String message;
  final Map<String, dynamic> context;
  final String? correlationId;
  final LogLocation? location;
  final Duration? duration;
  final int? memoryDelta;
  final Object? error;
  final StackTrace? stackTrace;
  
  LogEntry({
    required this.timestamp,
    required this.level,
    required this.loggerName,
    required this.message,
    this.context = const {},
    this.correlationId,
    this.location,
    this.duration,
    this.memoryDelta,
    this.error,
    this.stackTrace,
  });
  
  Map<String, dynamic> toJson() => {
    'timestamp': timestamp.toIso8601String(),
    'level': level.name,
    'logger': loggerName,
    'message': message,
    if (context.isNotEmpty) 'context': context,
    if (correlationId != null) 'correlationId': correlationId,
    if (location != null) 'location': location!.toJson(),
    if (duration != null) 'durationMs': duration!.inMilliseconds,
    if (memoryDelta != null) 'memoryBytes': memoryDelta,
    if (error != null) 'error': error.toString(),
    if (stackTrace != null) 'stackTrace': stackTrace.toString(),
  };
  
  factory LogEntry.fromJson(Map<String, dynamic> json) { /* ... */ }
}
```

**Purpose**: Represents a single log entry with all metadata
**Relationships**: Created by Logger, written by LogWriter

#### LogLevel
```dart
enum LogLevel {
  debug(0),
  info(1),
  warn(2),
  error(3),
  fatal(4);
  
  final int severity;
  const LogLevel(this.severity);
  
  bool operator >=(LogLevel other) => severity >= other.severity;
}
```

#### LogLocation
```dart
class LogLocation {
  final String file;
  final int line;
  final String function;
  
  LogLocation({
    required this.file,
    required this.line,
    required this.function,
  });
  
  factory LogLocation.current() {
    // Use StackTrace.current to extract location
    final trace = StackTrace.current;
    // Parse trace to extract file, line, function
    return LogLocation(/* ... */);
  }
  
  Map<String, dynamic> toJson() => {
    'file': file,
    'line': line,
    'function': function,
  };
}
```

### Data Flow
```
User Action (correlationId=UUID-1)
  ↓
Controller.handleAction() → Logger.info("User clicked button", {action: "generate_test"})
  ↓                           ↓
UseCase.execute()           LogEntry created with correlationId=UUID-1
  ↓                           ↓
Repository.getData()        Buffered in memory
  ↓                           ↓
DataSource.fetch()          Periodic flush (every 5s) or immediate (on ERROR)
  ↓                           ↓
Service.process()           LogWriter.writeLog(entry)
  ↓                           ↓
Result returned             Written to file as JSON line
                             ↓
                            advanced_tester_2025-10-01_10-30-45.log

All operations share correlationId=UUID-1, making them traceable
```

## API Specifications

### Internal APIs

#### AppLogger (Factory)
```dart
class AppLogger {
  static final Map<String, Logger> _loggers = {};
  static LoggerConfig _config = LoggerConfig.defaultConfig();
  
  /// Get or create a logger for the given name
  static Logger getLogger(String name) {
    return _loggers.putIfAbsent(name, () => Logger._(name, _config));
  }
  
  /// Configure global logging settings
  static void configure(LoggerConfig config) {
    _config = config;
    for (final logger in _loggers.values) {
      logger._updateConfig(config);
    }
  }
  
  /// Set log level for specific logger
  static void setLevel(String loggerName, LogLevel level) {
    _config = _config.copyWith(
      serviceLevels: {..._config.serviceLevels, loggerName: level},
    );
    _loggers[loggerName]?._updateConfig(_config);
  }
  
  /// Initialize logging system
  static Future<void> initialize() async {
    await LogWriter.instance.initialize();
  }
  
  /// Shutdown logging system (flush buffers)
  static Future<void> shutdown() async {
    await LogWriter.instance.shutdown();
  }
}
```

#### Logger (Instance)
```dart
class Logger {
  final String name;
  LoggerConfig _config;
  
  Logger._(this.name, this._config);
  
  /// Log debug message
  void debug(String message, [Map<String, dynamic>? context]) {
    _log(LogLevel.debug, message, context);
  }
  
  /// Log info message
  void info(String message, [Map<String, dynamic>? context]) {
    _log(LogLevel.info, message, context);
  }
  
  /// Log warning message
  void warn(String message, [Map<String, dynamic>? context]) {
    _log(LogLevel.warn, message, context);
  }
  
  /// Log error with exception
  void error(String message, Object error, [StackTrace? stackTrace, Map<String, dynamic>? context]) {
    final entry = LogEntry(
      timestamp: DateTime.now(),
      level: LogLevel.error,
      loggerName: name,
      message: message,
      context: context ?? {},
      correlationId: CorrelationContext.current,
      location: LogLocation.current(),
      error: error,
      stackTrace: stackTrace,
    );
    _write(entry, flushImmediately: true);
  }
  
  /// Log fatal error
  void fatal(String message, Object error, [StackTrace? stackTrace, Map<String, dynamic>? context]) {
    final entry = LogEntry(
      timestamp: DateTime.now(),
      level: LogLevel.fatal,
      loggerName: name,
      message: message,
      context: context ?? {},
      correlationId: CorrelationContext.current,
      location: LogLocation.current(),
      error: error,
      stackTrace: stackTrace,
    );
    _write(entry, flushImmediately: true);
  }
  
  /// Time an operation and log it
  Future<T> timeAsync<T>(String operation, Future<T> Function() fn, [Map<String, dynamic>? context]) async {
    final stopwatch = Stopwatch()..start();
    debug('Starting: $operation', context);
    try {
      final result = await fn();
      stopwatch.stop();
      info('Completed: $operation', {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });
      return result;
    } catch (e, stackTrace) {
      stopwatch.stop();
      error('Failed: $operation', e, stackTrace, {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });
      rethrow;
    }
  }
  
  void _log(LogLevel level, String message, Map<String, dynamic>? context) {
    if (!_shouldLog(level)) return;
    
    final entry = LogEntry(
      timestamp: DateTime.now(),
      level: level,
      loggerName: name,
      message: message,
      context: _redactSensitive(context ?? {}),
      correlationId: CorrelationContext.current,
      location: level >= LogLevel.warn ? LogLocation.current() : null,
    );
    
    _write(entry);
  }
  
  bool _shouldLog(LogLevel level) {
    final serviceLevel = _config.serviceLevels[name];
    final effectiveLevel = serviceLevel ?? _config.globalLevel;
    return level >= effectiveLevel;
  }
  
  Map<String, dynamic> _redactSensitive(Map<String, dynamic> context) {
    return SensitiveDataRedactor.redact(context, _config.redactionRules);
  }
  
  void _write(LogEntry entry, {bool flushImmediately = false}) {
    LogWriter.instance.write(entry, flushImmediately: flushImmediately);
  }
  
  void _updateConfig(LoggerConfig config) {
    _config = config;
  }
}
```

#### LogWriter (Singleton)
```dart
class LogWriter {
  static final LogWriter instance = LogWriter._();
  LogWriter._();
  
  final List<LogEntry> _buffer = [];
  Timer? _flushTimer;
  File? _currentFile;
  IOSink? _sink;
  final _writeLock = Lock();
  
  Future<void> initialize() async {
    final logsDir = await _getLogsDirectory();
    _currentFile = File('${logsDir.path}/advanced_tester_${_timestamp()}.log');
    _sink = _currentFile!.openWrite(mode: FileMode.append);
    _flushTimer = Timer.periodic(Duration(seconds: 5), (_) => flush());
  }
  
  void write(LogEntry entry, {bool flushImmediately = false}) {
    _buffer.add(entry);
    if (flushImmediately || _buffer.length >= 100) {
      flush();
    }
  }
  
  Future<void> flush() async {
    if (_buffer.isEmpty) return;
    
    await _writeLock.synchronized(() async {
      final entries = List<LogEntry>.from(_buffer);
      _buffer.clear();
      
      for (final entry in entries) {
        final json = jsonEncode(entry.toJson());
        _sink?.writeln(json);
      }
      await _sink?.flush();
      
      await _rotateIfNeeded();
    });
  }
  
  Future<void> _rotateIfNeeded() async {
    if (_currentFile == null) return;
    
    final fileSize = await _currentFile!.length();
    final maxSize = 50 * 1024 * 1024; // 50MB
    
    if (fileSize >= maxSize) {
      await _sink?.close();
      final logsDir = await _getLogsDirectory();
      _currentFile = File('${logsDir.path}/advanced_tester_${_timestamp()}.log');
      _sink = _currentFile!.openWrite(mode: FileMode.append);
      
      // Trigger cleanup
      _cleanupOldLogs();
    }
  }
  
  Future<void> _cleanupOldLogs() async {
    final logsDir = await _getLogsDirectory();
    final logFiles = logsDir.listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.log') || f.path.endsWith('.log.gz'))
        .toList();
    
    // Sort by modification time
    logFiles.sort((a, b) => a.statSync().modified.compareTo(b.statSync().modified));
    
    // Calculate total size
    var totalSize = logFiles.fold<int>(0, (sum, file) => sum + file.lengthSync());
    final maxTotalSize = 500 * 1024 * 1024; // 500MB
    
    // Delete oldest files until under limit
    while (totalSize > maxTotalSize && logFiles.isNotEmpty) {
      final oldest = logFiles.removeAt(0);
      totalSize -= oldest.lengthSync();
      await oldest.delete();
    }
    
    // Delete files older than 30 days
    final cutoffDate = DateTime.now().subtract(Duration(days: 30));
    for (final file in logFiles) {
      if (file.statSync().modified.isBefore(cutoffDate)) {
        await file.delete();
      }
    }
  }
  
  Future<void> shutdown() async {
    _flushTimer?.cancel();
    await flush();
    await _sink?.close();
  }
  
  Future<Directory> _getLogsDirectory() async {
    // Platform-specific home directory
    final home = Platform.environment['HOME'] ?? Platform.environment['USERPROFILE']!;
    final logsDir = Directory('$home/.advanced_tester/logs');
    if (!await logsDir.exists()) {
      await logsDir.create(recursive: true);
    }
    return logsDir;
  }
  
  String _timestamp() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}_'
           '${now.hour.toString().padLeft(2, '0')}-${now.minute.toString().padLeft(2, '0')}-${now.second.toString().padLeft(2, '0')}';
  }
}
```

### External Dependencies
- `logger: ^2.0.0` - Base logging functionality
- `path_provider: ^2.1.0` - Access to logs directory (or use Platform.environment)
- `intl: ^0.18.0` - Date/time formatting
- `synchronized: ^3.1.0` - Lock for thread-safe file writes

## Storage Design

### Log File Structure
```
~/.advanced_tester/logs/
├── advanced_tester_2025-10-01_10-30-45.log      (Current, 45MB)
├── advanced_tester_2025-10-01_09-15-22.log      (Previous, 50MB)
├── advanced_tester_2025-09-30_14-22-10.log.gz   (Compressed, 5MB)
├── advanced_tester_2025-09-30_08-45-33.log.gz   (Compressed, 4.8MB)
└── ...

Each .log file contains JSONL (one JSON object per line):
{"timestamp":"2025-10-01T10:30:45.123Z","level":"info","logger":"InspectorService","message":"Connected to VM service","context":{"vmServiceUri":"ws://127.0.0.1:1234/ws"},"correlationId":"uuid-1234"}
{"timestamp":"2025-10-01T10:30:45.456Z","level":"debug","logger":"InspectorService","message":"Fetching widget tree","correlationId":"uuid-1234"}
{"timestamp":"2025-10-01T10:30:45.789Z","level":"info","logger":"InspectorService","message":"Widget tree retrieved","context":{"widgetCount":1523,"durationMs":266},"correlationId":"uuid-1234"}
```

### Configuration Storage
```dart
// Stored in SharedPreferences
{
  "log_level_global": "info",
  "log_level_InspectorService": "debug",
  "log_level_AITestGenerationService": "debug",
  "log_retention_days": 30,
  "log_max_file_size_mb": 50,
  "log_max_total_size_mb": 500,
}
```

## Implementation Tasks Summary

See `tasks.md` for detailed task breakdown. Here's the high-level structure:

### Phase 1: Foundation (Week 1)
- Create logging infrastructure (AppLogger, Logger, LogEntry, LogWriter)
- Implement file handling and rotation
- Implement correlation context
- Create configuration system

### Phase 2: Service Integration (Week 2)
- Add logging to all 10+ services
- Add logging to all use cases
- Add logging to repositories
- Implement sensitive data redaction

### Phase 3: UI & Tools (Week 3)
- Create log viewer panel
- Implement log export
- Add log settings UI
- Create diagnostic report generator

### Phase 4: Testing & Documentation (Week 4)
- Comprehensive testing
- Performance benchmarking
- Documentation
- Code review

## Performance Considerations

### Performance Targets
- Log write operation: < 1ms (async, non-blocking)
- Memory overhead: < 10MB for entire logging infrastructure
- CPU overhead: < 2% during normal operation
- No impact on UI responsiveness

### Optimization Strategies
1. **Buffered Writes**: Buffer logs in memory, write in batches
2. **Async Flushing**: Write to disk asynchronously (periodic + on error)
3. **Lazy Location**: Only capture file/line for WARN+ levels
4. **Level Filtering**: Don't create LogEntry objects for filtered-out levels
5. **Efficient JSON**: Use fast JSON encoding, pre-allocate buffers
6. **Log Rotation**: Don't check file size on every write, check periodically

### Performance Tests
```dart
test('logging should have minimal overhead', () async {
  final logger = AppLogger.getLogger('PerfTest');
  
  // Baseline: operation without logging
  final baselineStopwatch = Stopwatch()..start();
  for (var i = 0; i < 10000; i++) {
    await someOperation();
  }
  baselineStopwatch.stop();
  final baselineTime = baselineStopwatch.elapsedMilliseconds;
  
  // With logging
  final loggingStopwatch = Stopwatch()..start();
  for (var i = 0; i < 10000; i++) {
    await logger.timeAsync('someOperation', () => someOperation());
  }
  loggingStopwatch.stop();
  final loggingTime = loggingStopwatch.elapsedMilliseconds;
  
  // Overhead should be < 5%
  final overhead = (loggingTime - baselineTime) / baselineTime;
  expect(overhead, lessThan(0.05));
});
```

## Security Considerations

### Sensitive Data Redaction
```dart
class SensitiveDataRedactor {
  static final _sensitiveKeys = {
    'password', 'token', 'apiKey', 'secret', 'accessToken',
    'refreshToken', 'credential', 'auth', 'bearer',
  };
  
  static Map<String, dynamic> redact(Map<String, dynamic> data, List<RedactionRule> rules) {
    final redacted = <String, dynamic>{};
    for (final entry in data.entries) {
      if (_shouldRedact(entry.key, rules)) {
        redacted[entry.key] = '***REDACTED***';
      } else if (entry.value is Map) {
        redacted[entry.key] = redact(entry.value as Map<String, dynamic>, rules);
      } else {
        redacted[entry.key] = entry.value;
      }
    }
    return redacted;
  }
  
  static bool _shouldRedact(String key, List<RedactionRule> rules) {
    final lowerKey = key.toLowerCase();
    if (_sensitiveKeys.contains(lowerKey)) return true;
    return rules.any((rule) => rule.matches(key));
  }
}

class RedactionRule {
  final RegExp pattern;
  const RedactionRule(this.pattern);
  bool matches(String key) => pattern.hasMatch(key);
}
```

## Success Criteria

### Functional Criteria
- [ ] 100% of services have comprehensive logging
- [ ] 100% of use cases log entry/exit
- [ ] 100% of repositories log data operations
- [ ] Log viewer UI functional with filtering
- [ ] Log export generates diagnostic reports
- [ ] Sensitive data is redacted automatically

### Non-Functional Criteria
- [ ] Performance overhead < 2% CPU
- [ ] Memory overhead < 10MB
- [ ] Log file rotation works automatically
- [ ] Logs retained for 30 days by default
- [ ] No log data loss on normal shutdown
- [ ] All tests passing

---

**Created**: 2025-10-01
**Last Updated**: 2025-10-01
**Author**: Advanced Tester Team
**Status**: Ready for Implementation
