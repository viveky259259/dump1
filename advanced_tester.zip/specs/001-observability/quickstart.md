# Quickstart: Comprehensive Observability & Local Logging

## What is this feature?
A complete logging system that automatically tracks and records every operation, function call, error, and performance metric across the entire Advanced Tester application to local log files.

## Why do we need it?
Currently, when bugs occur or performance issues arise, we have no historical record of what happened. This makes debugging nearly impossible and user-reported issues difficult to diagnose. Comprehensive logging solves this by creating a detailed audit trail of everything that happens.

## How does it work?

### Automatic Logging
Every service, use case, repository, and controller will automatically log:
- **Function Entry**: When a function is called (with parameters)
- **Function Exit**: When a function completes (with result and duration)
- **Errors**: Any exceptions with full context and stack traces
- **State Changes**: All state updates with before/after values
- **Performance**: Execution time and memory usage for operations

### Structured JSON Logs
```json
{
  "timestamp": "2025-10-01T10:30:45.123Z",
  "level": "info",
  "logger": "InspectorService",
  "message": "Connected to VM service",
  "context": {
    "vmServiceUri": "ws://127.0.0.1:1234/ws"
  },
  "correlationId": "uuid-1234-5678",
  "durationMs": 145
}
```

### Local File Storage
- Logs stored in `~/.advanced_tester/logs/`
- Rotating files (50MB per file, 500MB total, 30 days retention)
- Automatic cleanup of old logs
- Compressed archives for old logs

### In-App Log Viewer
- View logs in real-time within the app
- Filter by level (DEBUG, INFO, WARN, ERROR, FATAL)
- Search by text, service, or time range
- Export logs for bug reports

## Quick Usage Example

### For Developers - Adding Logging to New Code

```dart
import 'package:advanced_tester/core/logging/app_logger.dart';
import 'package:advanced_tester/core/logging/logger_mixin.dart';

// Use mixin for automatic logging
class MyService with LoggerMixin {
  Future<Result> performOperation(String param) async {
    // Automatically logs entry, exit, duration, and errors
    return await logAsyncOperation(
      'performOperation',
      () async {
        logger.info('Processing request', {'param': param});
        
        final result = await _doWork(param);
        
        logger.info('Work completed', {'resultSize': result.length});
        return result;
      },
      context: {'param': param},
    );
  }
  
  Future<String> _doWork(String param) async {
    // This will also be logged via the wrapper
    logger.debug('Starting work', {'param': param});
    
    try {
      final data = await fetchData(param);
      return processData(data);
    } catch (e, stackTrace) {
      logger.error('Work failed', e, stackTrace, {'param': param});
      rethrow;
    }
  }
}

// Manual logging
class MyWidget extends StatelessWidget {
  final logger = AppLogger.getLogger('MyWidget');
  
  void _handleButtonPress() {
    logger.info('Button pressed', {'action': 'generate_test'});
    // ... rest of handler
  }
}
```

### For Users - Viewing and Exporting Logs

1. **View Logs**: Click "Logs" tab in the UI
2. **Filter**: Select log level and time range
3. **Search**: Type keywords to find specific events
4. **Export**: Click "Export Diagnostic Report" to save logs for bug reports

### Log Levels

- **DEBUG**: Detailed information for diagnosis (verbose)
- **INFO**: General informational messages
- **WARN**: Warning messages (potential issues)
- **ERROR**: Error messages (recoverable errors)
- **FATAL**: Fatal errors (unrecoverable)

### Correlation IDs

All operations triggered by a user action share a correlation ID, making it easy to trace the entire flow:

```
User clicks "Generate Test" (correlationId=abc-123)
  → Controller.generateTest()  [correlationId=abc-123]
    → UseCase.execute()        [correlationId=abc-123]
      → Repository.getData()   [correlationId=abc-123]
        → Service.fetch()      [correlationId=abc-123]
```

Just search logs for `"correlationId":"abc-123"` to see everything related to that action!

## Configuration

Set log levels in Settings:
- **Global Level**: Default for all services (INFO recommended)
- **Per-Service**: Override for specific services (e.g., InspectorService: DEBUG)
- **Retention**: How long to keep logs (30 days default)
- **Max Size**: Total log storage limit (500MB default)

## Performance Impact

Logging is designed for **zero performance impact**:
- Async writes (non-blocking)
- Buffered I/O
- Level filtering (disabled levels have near-zero cost)
- < 2% CPU overhead
- < 10MB memory overhead

## What's Next?

1. Review the [full specification](spec.md) for complete requirements
2. Check the [implementation plan](plan.md) for technical details
3. View [task breakdown](tasks.md) for implementation steps
4. Read [research findings](research.md) for technology choices

---

**Feature ID**: 001-observability
**Status**: Ready for Implementation
**Target Version**: 1.1.0
**Implementation Time**: 4 weeks
