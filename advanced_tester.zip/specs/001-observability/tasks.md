# Implementation Tasks: Comprehensive Observability & Local Logging

## Task Breakdown

This document provides a detailed, sequential task breakdown for implementing comprehensive observability with local file logging. Each task is atomic and can be completed independently.

## Task Format

Each task follows this structure:
```
### [TASK-ID] Task Title
**Status**: ⬜ Pending | 🔄 In Progress | ✅ Complete | ❌ Blocked
**Estimated Time**: X hours
**Dependencies**: [TASK-IDs]
**Priority**: 🔴 Critical | 🟡 High | 🟢 Medium | ⚪ Low
**Type**: [Implementation | Testing | Documentation | Research]
```

---

## Phase 1: Foundation (Week 1)

### [001] Create LogLevel Enum
**Status**: ⬜ Pending
**Estimated Time**: 0.5 hours
**Dependencies**: None
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create LogLevel enum with severity levels.

**Files to Create/Modify**:
- `lib/core/logging/log_level.dart`

**Implementation Steps**:
1. Create LogLevel enum with values: DEBUG, INFO, WARN, ERROR, FATAL
2. Add severity property to each level
3. Implement comparison operators (>=, >, <, <=)
4. Add toString() and fromString() methods
5. Add documentation

**Acceptance Criteria**:
- [ ] Enum has all 5 levels
- [ ] Severity comparison works correctly
- [ ] String conversion works both ways
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for severity comparison
- [ ] Unit test for string conversion

---

### [002] Create LogLocation Class
**Status**: ⬜ Pending
**Estimated Time**: 1 hour
**Dependencies**: None
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Create LogLocation class to capture file, line, and function information.

**Files to Create/Modify**:
- `lib/core/logging/log_location.dart`

**Implementation Steps**:
1. Create LogLocation class with file, line, function properties
2. Implement factory constructor LogLocation.current() using StackTrace
3. Parse stack trace to extract file, line, function
4. Implement toJson() and fromJson()
5. Add documentation

**Acceptance Criteria**:
- [ ] Captures current location from stack trace
- [ ] Parses stack trace correctly
- [ ] JSON serialization works
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for location capture
- [ ] Unit test for stack trace parsing
- [ ] Unit test for JSON serialization

---

### [003] Create LogEntry Entity
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [001], [002]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create LogEntry entity class representing a single log entry.

**Files to Create/Modify**:
- `lib/core/logging/log_entry.dart`

**Implementation Steps**:
1. Create LogEntry class with all properties (timestamp, level, logger, message, context, correlationId, location, duration, memoryDelta, error, stackTrace)
2. Implement toJson() for file serialization
3. Implement fromJson() for reading logs
4. Implement toString() for debugging
5. Add equality operators
6. Add documentation

**Acceptance Criteria**:
- [ ] All properties defined and immutable
- [ ] JSON serialization produces valid JSONL format
- [ ] JSON deserialization works correctly
- [ ] Equality operators work
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for entity creation
- [ ] Unit test for JSON serialization
- [ ] Unit test for JSON deserialization
- [ ] Unit test for equality

---

### [004] Create CorrelationContext System
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: None
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create correlation context system for tracking operations across services.

**Files to Create/Modify**:
- `lib/core/logging/correlation_context.dart`

**Implementation Steps**:
1. Create CorrelationContext class with static methods
2. Implement UUID generation for correlation IDs
3. Implement context storage (thread-local pattern using Map)
4. Implement get current(), set(), clear() methods
5. Implement withCorrelation() wrapper method
6. Add documentation

**Acceptance Criteria**:
- [ ] Generates unique correlation IDs
- [ ] Context persists within execution scope
- [ ] withCorrelation() properly manages context
- [ ] Thread-safe for async operations
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for ID generation
- [ ] Unit test for context management
- [ ] Unit test for withCorrelation wrapper
- [ ] Test async context propagation

---

### [005] Create SensitiveDataRedactor
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: None
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Create sensitive data redactor for automatic PII protection.

**Files to Create/Modify**:
- `lib/core/logging/sensitive_data_redactor.dart`

**Implementation Steps**:
1. Create SensitiveDataRedactor class
2. Define default sensitive key patterns (password, token, apiKey, etc.)
3. Implement redact() method for Map<String, dynamic>
4. Implement recursive redaction for nested maps
5. Create RedactionRule class for custom rules
6. Add documentation

**Acceptance Criteria**:
- [ ] Redacts default sensitive keys
- [ ] Handles nested maps recursively
- [ ] Supports custom redaction rules
- [ ] Performance is acceptable (< 1ms for typical context)
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for default key redaction
- [ ] Unit test for nested map redaction
- [ ] Unit test for custom rules
- [ ] Performance benchmark test

---

### [006] Create LogConfig Class
**Status**: ⬜ Pending
**Estimated Time**: 1 hour
**Dependencies**: [001]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Create configuration class for logging system.

**Files to Create/Modify**:
- `lib/core/logging/log_config.dart`

**Implementation Steps**:
1. Create LogConfig class with configuration properties
2. Add globalLevel, serviceLevels map, redactionRules
3. Add retention settings (retentionDays, maxFileSizeMb, maxTotalSizeMb)
4. Implement copyWith() method
5. Implement factory constructor defaultConfig()
6. Implement toJson() and fromJson() for persistence
7. Add documentation

**Acceptance Criteria**:
- [ ] All configuration options represented
- [ ] copyWith() allows easy updates
- [ ] Default config is sensible
- [ ] JSON serialization works
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for default config
- [ ] Unit test for copyWith
- [ ] Unit test for JSON serialization

---

### [007] Create LogWriter (File Handling)
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: [003], [006]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create LogWriter singleton for file I/O operations.

**Files to Create/Modify**:
- `lib/core/logging/log_writer.dart`

**Implementation Steps**:
1. Create LogWriter singleton class
2. Implement initialize() - create logs directory, open file
3. Implement write() - add entry to buffer
4. Implement flush() - write buffer to file with lock
5. Implement _rotateIfNeeded() - check size and rotate files
6. Implement _cleanupOldLogs() - delete old/oversized logs
7. Implement _getLogsDirectory() - get ~/.advanced_tester/logs/
8. Implement shutdown() - final flush and close
9. Add periodic flush timer (every 5 seconds)
10. Add documentation

**Acceptance Criteria**:
- [ ] Creates log directory automatically
- [ ] Writes logs as JSONL (one object per line)
- [ ] Buffers writes for performance
- [ ] Flushes periodically and on shutdown
- [ ] Rotates files at 50MB
- [ ] Cleans up old logs (30 days / 500MB)
- [ ] Thread-safe with lock
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for initialization
- [ ] Unit test for write and flush
- [ ] Unit test for rotation logic
- [ ] Unit test for cleanup logic
- [ ] Integration test for full lifecycle

---

### [008] Create Logger Class
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [001], [003], [004], [005], [006], [007]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create Logger instance class with logging methods.

**Files to Create/Modify**:
- `lib/core/logging/logger.dart`

**Implementation Steps**:
1. Create Logger class with name and config properties
2. Implement debug(), info(), warn(), error(), fatal() methods
3. Implement _log() internal method with level filtering
4. Implement _shouldLog() for level checking
5. Implement _redactSensitive() for context redaction
6. Implement timeAsync() for automatic operation timing
7. Implement _write() to call LogWriter
8. Add correlation ID to all log entries
9. Add location capture for WARN+ levels
10. Add documentation

**Acceptance Criteria**:
- [ ] All log levels work correctly
- [ ] Level filtering works per-logger
- [ ] Sensitive data is redacted
- [ ] Correlation IDs are included
- [ ] Location captured for warnings/errors
- [ ] timeAsync() times operations correctly
- [ ] Error logs flush immediately
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for each log level
- [ ] Unit test for level filtering
- [ ] Unit test for redaction
- [ ] Unit test for timeAsync
- [ ] Unit test for error flushing

---

### [009] Create AppLogger (Factory)
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [008]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create AppLogger factory class for logger management.

**Files to Create/Modify**:
- `lib/core/logging/app_logger.dart`

**Implementation Steps**:
1. Create AppLogger class with static methods
2. Implement getLogger() - create or retrieve logger by name
3. Implement configure() - update global configuration
4. Implement setLevel() - set level for specific logger
5. Implement initialize() - initialize logging system
6. Implement shutdown() - shutdown logging system
7. Maintain map of all loggers
8. Add documentation

**Acceptance Criteria**:
- [ ] getLogger() returns same instance for same name
- [ ] configure() updates all loggers
- [ ] setLevel() updates specific logger
- [ ] initialize() sets up logging system
- [ ] shutdown() cleans up properly
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for getLogger caching
- [ ] Unit test for configure
- [ ] Unit test for setLevel
- [ ] Unit test for lifecycle (init/shutdown)

---

### [010] Create LoggerMixin
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [009]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Create LoggerMixin for easy logging integration in classes.

**Files to Create/Modify**:
- `lib/core/logging/logger_mixin.dart`

**Implementation Steps**:
1. Create LoggerMixin mixin
2. Add lazy logger property using runtimeType
3. Implement logOperation() for sync operations
4. Implement logAsyncOperation() for async operations
5. Automatic timing in both methods
6. Automatic error logging with context
7. Add documentation and usage examples

**Acceptance Criteria**:
- [ ] Mixin provides logger property automatically
- [ ] logOperation() works for sync code
- [ ] logAsyncOperation() works for async code
- [ ] Operations are timed automatically
- [ ] Errors are logged automatically
- [ ] Easy to use with minimal boilerplate
- [ ] Documentation with examples complete

**Test Requirements**:
- [ ] Unit test for sync operation logging
- [ ] Unit test for async operation logging
- [ ] Unit test for timing
- [ ] Unit test for error logging

---

### [011] Persist Log Configuration
**Status**: ⬜ Pending
**Estimated Time**: 1.5 hours
**Dependencies**: [006], [009]
**Priority**: 🟢 Medium
**Type**: Implementation

**Description**: Integrate log configuration with PrefsService for persistence.

**Files to Create/Modify**:
- `lib/services/prefs_service.dart`

**Implementation Steps**:
1. Add methods to save/load LogConfig in PrefsService
2. Save config when changed via AppLogger.configure()
3. Load config on app startup
4. Store as JSON in SharedPreferences
5. Update documentation

**Acceptance Criteria**:
- [ ] LogConfig persists across app restarts
- [ ] Config loads automatically on startup
- [ ] Config saves when changed
- [ ] Documentation updated

**Test Requirements**:
- [ ] Unit test for save/load config
- [ ] Integration test for persistence

---

## Phase 2: Service Integration (Week 2)

### [012] Add Logging to InspectorService
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [010]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add comprehensive logging to InspectorService (all 15+ methods).

**Files to Create/Modify**:
- `lib/services/inspector_service.dart`

**Implementation Steps**:
1. Add LoggerMixin to InspectorService
2. Wrap connect() with logAsyncOperation
3. Wrap disconnect() with logging
4. Wrap getRootWidgetSummaryTree() with logging and timing
5. Wrap getSelectedWidget() with logging
6. Wrap selectWidget() with logging
7. Wrap getProperties() with logging and count
8. Add context logging for important parameters (vmServiceUri, widgetId, etc.)
9. Log cache hits/misses
10. Update documentation

**Acceptance Criteria**:
- [ ] All public methods log entry/exit
- [ ] Operation durations logged
- [ ] Important parameters included in context
- [ ] Errors logged with full context
- [ ] Cache operations logged
- [ ] No performance degradation

**Test Requirements**:
- [ ] Verify logs are created for each operation
- [ ] Performance test shows < 2% overhead

---

### [013] Add Logging to DependencyAnalysisService
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [010]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add comprehensive logging to DependencyAnalysisService.

**Files to Create/Modify**:
- `lib/services/dependency_analysis_service.dart`

**Implementation Steps**:
1. Add LoggerMixin to DependencyAnalysisService
2. Wrap analyzeWidgetDependencies() with logging
3. Log dependency count and types found
4. Wrap detectProviders() with logging
5. Wrap detectInheritedWidgets() with logging
6. Wrap generateTestSetup() with logging
7. Add context for analysis results
8. Update documentation

**Acceptance Criteria**:
- [ ] All methods log entry/exit
- [ ] Analysis results logged (dependency counts)
- [ ] Operation timing logged
- [ ] Errors logged with context

**Test Requirements**:
- [ ] Verify logs created for analysis operations
- [ ] Performance test

---

### [014] Add Logging to TestGenerationService
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [010]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add comprehensive logging to TestGenerationService.

**Files to Create/Modify**:
- `lib/services/test_generation_service.dart`

**Implementation Steps**:
1. Add LoggerMixin to TestGenerationService
2. Wrap generateTest() with logging
3. Wrap generateImports() with logging
4. Wrap generateSetup() with logging
5. Wrap generateAssertions() with logging
6. Wrap saveTestFile() with logging (file path)
7. Log test generation metrics (lines, time)
8. Update documentation

**Acceptance Criteria**:
- [ ] All methods log entry/exit
- [ ] Test generation metrics logged
- [ ] File operations logged
- [ ] Errors logged

**Test Requirements**:
- [ ] Verify logs for test generation
- [ ] Performance test

---

### [015] Add Logging to AITestGenerationService
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [010]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add comprehensive logging to AITestGenerationService (1,923 lines).

**Files to Create/Modify**:
- `lib/services/ai_test_generation_service.dart`

**Implementation Steps**:
1. Add LoggerMixin to AITestGenerationService
2. Wrap generateWithAI() with logging
3. Wrap enhanceTest() with logging
4. Log API calls (without sensitive data - tokens)
5. Log prompt generation (truncated)
6. Log response parsing
7. Log AI response time and token usage
8. Redact API keys automatically
9. Update documentation

**Acceptance Criteria**:
- [ ] All methods log entry/exit
- [ ] API calls logged (no tokens)
- [ ] Response times logged
- [ ] Token usage logged
- [ ] Errors logged with context

**Test Requirements**:
- [ ] Verify API keys are redacted
- [ ] Verify logs created for AI operations
- [ ] Performance test

---

### [016] Add Logging to ServiceManager
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [010]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add comprehensive logging to ServiceManager.

**Files to Create/Modify**:
- `lib/services/service_manager.dart`

**Implementation Steps**:
1. Add LoggerMixin to ServiceManager
2. Wrap initializeServices() with logging
3. Log each service initialization individually
4. Wrap registerService() with logging
5. Wrap getService() with logging
6. Wrap disposeServices() with logging
7. Log health checks
8. Update documentation

**Acceptance Criteria**:
- [ ] Service lifecycle logged
- [ ] Each service init/dispose logged
- [ ] Health checks logged
- [ ] Service access logged (DEBUG level)

**Test Requirements**:
- [ ] Verify logs for service lifecycle
- [ ] Performance test

---

### [017] Add Logging to Remaining Services
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: [010]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add comprehensive logging to AppRunner, SyncService, PrefsService, DeviceService, SourceCodeAnalyzer.

**Files to Create/Modify**:
- `lib/services/app_runner.dart`
- `lib/services/sync_service.dart`
- `lib/services/prefs_service.dart`
- `lib/services/device_service.dart`
- `lib/services/source_code_analyzer.dart`
- `lib/services/enhanced_dependency_analysis_service.dart`

**Implementation Steps**:
1. Add LoggerMixin to each service
2. Wrap all public methods with logAsyncOperation
3. Add appropriate context for each service
4. Log important operations and results
5. Update documentation for each

**Acceptance Criteria**:
- [ ] All services have logging
- [ ] All public methods logged
- [ ] Appropriate context for each service
- [ ] Documentation updated

**Test Requirements**:
- [ ] Verify logs for each service
- [ ] Performance test for all services

---

### [018] Add Logging to All Use Cases
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [010]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Add entry/exit logging to all use cases in domain layer.

**Files to Create/Modify**:
- All files in `lib/domain/usecases/`

**Implementation Steps**:
1. Add LoggerMixin to each use case class
2. Wrap execute() method with logAsyncOperation
3. Log parameters (redacted if sensitive)
4. Log result type (Success/Failure)
5. Log validation errors
6. Update documentation

**Acceptance Criteria**:
- [ ] All use cases log entry/exit
- [ ] Parameters logged (safely)
- [ ] Results logged
- [ ] Validation errors logged
- [ ] Documentation updated

**Test Requirements**:
- [ ] Verify logs for use case execution
- [ ] Verify sensitive data redaction

---

### [019] Add Logging to All Repositories
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [010]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Add logging to all repository implementations.

**Files to Create/Modify**:
- All files in `lib/data/repositories/`

**Implementation Steps**:
1. Add LoggerMixin to each repository
2. Wrap all methods with logAsyncOperation
3. Log data source interactions
4. Log data mapping operations
5. Log cache hits/misses (if applicable)
6. Update documentation

**Acceptance Criteria**:
- [ ] All repositories log operations
- [ ] Data source calls logged
- [ ] Mapping logged
- [ ] Cache operations logged
- [ ] Documentation updated

**Test Requirements**:
- [ ] Verify logs for repository operations

---

### [020] Add Logging to All Controllers
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [010]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Add logging to all controllers in presentation layer.

**Files to Create/Modify**:
- All files in `lib/presentation/controllers/`

**Implementation Steps**:
1. Add LoggerMixin to each controller
2. Log all public method calls
3. Log use case invocations
4. Log state updates
5. Log user action context
6. Update documentation

**Acceptance Criteria**:
- [ ] All controller methods logged
- [ ] User actions tracked
- [ ] Use case calls logged
- [ ] State changes logged
- [ ] Documentation updated

**Test Requirements**:
- [ ] Verify logs for controller operations

---

### [021] Add Logging to All Providers
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [010]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Add logging to all Provider state classes.

**Files to Create/Modify**:
- All files in `lib/presentation/providers/`
- `lib/state/app_state.dart`

**Implementation Steps**:
1. Add LoggerMixin to each provider
2. Log before/after state changes
3. Log notifyListeners() calls with reason
4. Log async operations (loading states)
5. Log error states
6. Update documentation

**Acceptance Criteria**:
- [ ] State changes logged with before/after
- [ ] notifyListeners() calls logged
- [ ] Async operations logged
- [ ] Error states logged
- [ ] Documentation updated

**Test Requirements**:
- [ ] Verify logs for state changes

---

## Phase 3: UI & Tools (Week 3)

### [022] Create LogViewerPanel Widget
**Status**: ⬜ Pending
**Estimated Time**: 6 hours
**Dependencies**: [009]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create in-app log viewer panel with filtering and search.

**Files to Create/Modify**:
- `lib/ui/widgets/log_viewer_panel.dart`

**Implementation Steps**:
1. Create stateful widget LogViewerPanel
2. Read logs from file system
3. Parse JSONL format
4. Display logs in scrollable list
5. Implement level filter dropdown
6. Implement text search field
7. Implement time range filter
8. Implement service/logger filter
9. Add syntax highlighting (color by level)
10. Add auto-scroll toggle
11. Add clear logs button
12. Add documentation

**Acceptance Criteria**:
- [ ] Displays logs in real-time
- [ ] Level filtering works
- [ ] Text search works
- [ ] Time range filtering works
- [ ] Service filtering works
- [ ] Syntax highlighting works
- [ ] Auto-scroll works
- [ ] Performance is good with 1000+ logs
- [ ] Documentation complete

**Test Requirements**:
- [ ] Widget test for rendering
- [ ] Widget test for filtering
- [ ] Widget test for search
- [ ] Performance test with large log files

---

### [023] Create LogExportService
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [009]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Create service to export logs for diagnostic reports.

**Files to Create/Modify**:
- `lib/services/log_export_service.dart`

**Implementation Steps**:
1. Create LogExportService class
2. Implement exportDiagnosticReport() method
3. Read recent logs (configurable time range)
4. Redact sensitive data
5. Include system information (OS, Flutter version, etc.)
6. Create ZIP archive with logs and system info
7. Save to user-selected location
8. Add documentation

**Acceptance Criteria**:
- [ ] Exports logs from last N hours
- [ ] Sensitive data redacted
- [ ] System info included
- [ ] Creates ZIP archive
- [ ] User can select save location
- [ ] Documentation complete

**Test Requirements**:
- [ ] Unit test for export logic
- [ ] Unit test for redaction
- [ ] Integration test for full export

---

### [024] Add Export Button to UI
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [022], [023]
**Priority**: 🟡 High
**Type**: Implementation

**Description**: Add export diagnostic report button to log viewer.

**Files to Create/Modify**:
- `lib/ui/widgets/log_viewer_panel.dart`

**Implementation Steps**:
1. Add "Export Diagnostic Report" button to UI
2. Add time range selector for export
3. Show progress indicator during export
4. Show success message with file location
5. Handle export errors gracefully
6. Add documentation

**Acceptance Criteria**:
- [ ] Button is visible and accessible
- [ ] Time range selector works
- [ ] Progress indicator shown
- [ ] Success message displayed
- [ ] Errors handled gracefully
- [ ] Documentation updated

**Test Requirements**:
- [ ] Widget test for button interaction
- [ ] Widget test for success/error states

---

### [025] Create Log Settings UI
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: [009]
**Priority**: 🟢 Medium
**Type**: Implementation

**Description**: Create UI for configuring log levels and settings.

**Files to Create/Modify**:
- `lib/ui/widgets/log_settings_panel.dart`
- `lib/ui/pages/settings_page.dart` (update)

**Implementation Steps**:
1. Create LogSettingsPanel widget
2. Add global log level dropdown
3. Add per-service level overrides UI
4. Add retention settings (days, size)
5. Add redaction rules configuration
6. Connect to AppLogger.configure() and setLevel()
7. Save settings via PrefsService
8. Add documentation

**Acceptance Criteria**:
- [ ] Global level can be changed
- [ ] Per-service levels can be set
- [ ] Retention settings configurable
- [ ] Settings persist across restarts
- [ ] Changes take effect immediately
- [ ] Documentation complete

**Test Requirements**:
- [ ] Widget test for settings UI
- [ ] Integration test for settings persistence

---

### [026] Integrate Log Viewer into HomePage
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [022]
**Priority**: 🔴 Critical
**Type**: Implementation

**Description**: Add log viewer as a tab/panel in the main UI.

**Files to Create/Modify**:
- `lib/ui/pages/home_page.dart`

**Implementation Steps**:
1. Add "Logs" tab to HomePage
2. Integrate LogViewerPanel widget
3. Ensure proper sizing in multi-panel layout
4. Add keyboard shortcut to open logs (Ctrl+L)
5. Update documentation

**Acceptance Criteria**:
- [ ] Logs tab visible in main UI
- [ ] Log viewer displays correctly
- [ ] Multi-panel layout works
- [ ] Keyboard shortcut works
- [ ] Documentation updated

**Test Requirements**:
- [ ] Widget test for integration
- [ ] Widget test for keyboard shortcut

---

### [027] Create Performance Metrics View
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [009]
**Priority**: 🟢 Medium
**Type**: Implementation

**Description**: Create view to display aggregated performance metrics from logs.

**Files to Create/Modify**:
- `lib/ui/widgets/performance_metrics_panel.dart`

**Implementation Steps**:
1. Create PerformanceMetricsPanel widget
2. Parse logs to extract timing information
3. Calculate aggregate metrics (avg, p50, p95, p99)
4. Display metrics per operation/service
5. Show slowest operations
6. Add time range selector
7. Add documentation

**Acceptance Criteria**:
- [ ] Displays aggregate performance metrics
- [ ] Shows per-operation statistics
- [ ] Identifies slow operations
- [ ] Time range filtering works
- [ ] Documentation complete

**Test Requirements**:
- [ ] Widget test for metrics display
- [ ] Unit test for metrics calculation

---

## Phase 4: Testing & Documentation (Week 4)

### [028] Write Unit Tests for Logging Infrastructure
**Status**: ⬜ Pending
**Estimated Time**: 6 hours
**Dependencies**: [009]
**Priority**: 🔴 Critical
**Type**: Testing

**Description**: Comprehensive unit tests for all logging classes.

**Files to Create/Modify**:
- `test/core/logging/log_level_test.dart`
- `test/core/logging/log_entry_test.dart`
- `test/core/logging/log_writer_test.dart`
- `test/core/logging/logger_test.dart`
- `test/core/logging/app_logger_test.dart`
- `test/core/logging/correlation_context_test.dart`
- `test/core/logging/sensitive_data_redactor_test.dart`

**Implementation Steps**:
1. Test LogLevel comparison and conversion
2. Test LogEntry serialization/deserialization
3. Test LogWriter file operations, rotation, cleanup
4. Test Logger level filtering, redaction, timing
5. Test AppLogger factory and configuration
6. Test CorrelationContext management
7. Test SensitiveDataRedactor redaction rules
8. Achieve > 90% code coverage for logging infrastructure

**Acceptance Criteria**:
- [ ] All logging classes have unit tests
- [ ] Code coverage > 90%
- [ ] All tests pass
- [ ] Edge cases covered

**Test Requirements**:
- Complete test suite for logging infrastructure

---

### [029] Write Integration Tests for Log Coverage
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: [021]
**Priority**: 🔴 Critical
**Type**: Testing

**Description**: Integration tests to verify all services/classes log correctly.

**Files to Create/Modify**:
- `test/integration/logging_coverage_test.dart`

**Implementation Steps**:
1. Create integration test that exercises all services
2. Verify logs are created for each operation
3. Verify correlation IDs propagate correctly
4. Verify timing information is present
5. Verify sensitive data is redacted
6. Verify error logging works
7. Check log file creation and format

**Acceptance Criteria**:
- [ ] All services produce logs
- [ ] Correlation IDs work correctly
- [ ] Timing data present
- [ ] Sensitive data redacted
- [ ] Errors logged with context
- [ ] Log files formatted correctly

**Test Requirements**:
- End-to-end integration test for logging

---

### [030] Performance Benchmarking
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: [021]
**Priority**: 🔴 Critical
**Type**: Testing

**Description**: Benchmark logging performance and verify overhead targets.

**Files to Create/Modify**:
- `test/performance/logging_performance_test.dart`

**Implementation Steps**:
1. Create baseline benchmark (without logging)
2. Create benchmark with logging enabled
3. Measure CPU overhead
4. Measure memory overhead
5. Measure throughput (logs/second)
6. Measure write latency
7. Verify targets met (< 2% CPU, < 10MB memory, < 1ms write)
8. Document results

**Acceptance Criteria**:
- [ ] CPU overhead < 2%
- [ ] Memory overhead < 10MB
- [ ] Write latency < 1ms (async)
- [ ] Throughput > 10,000 logs/minute
- [ ] No UI blocking
- [ ] Results documented

**Test Requirements**:
- Comprehensive performance benchmarks

---

### [031] Security Review for Data Redaction
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [005], [023]
**Priority**: 🔴 Critical
**Type**: Testing

**Description**: Security review to ensure no PII leakage in logs.

**Files to Create/Modify**:
- `test/security/logging_security_test.dart`
- `docs/LOGGING_SECURITY.md`

**Implementation Steps**:
1. Test redaction of all default sensitive keys
2. Test redaction in nested objects
3. Test redaction in arrays
4. Test file path anonymization
5. Verify exported logs have no PII
6. Test custom redaction rules
7. Document security measures

**Acceptance Criteria**:
- [ ] No passwords in logs
- [ ] No API tokens in logs
- [ ] No credentials in logs
- [ ] File paths anonymized
- [ ] Exported logs are safe to share
- [ ] Security documentation complete

**Test Requirements**:
- Comprehensive security tests for redaction

---

### [032] Write Widget Tests for Log Viewer
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [026]
**Priority**: 🟡 High
**Type**: Testing

**Description**: Widget tests for log viewer UI components.

**Files to Create/Modify**:
- `test/ui/widgets/log_viewer_panel_test.dart`
- `test/ui/widgets/log_settings_panel_test.dart`

**Implementation Steps**:
1. Test log viewer rendering
2. Test filtering functionality
3. Test search functionality
4. Test export button interaction
5. Test settings UI
6. Test auto-scroll behavior
7. Test error states

**Acceptance Criteria**:
- [ ] All UI components tested
- [ ] User interactions covered
- [ ] Error states tested
- [ ] All tests pass

**Test Requirements**:
- Complete widget test suite

---

### [033] Create Developer Documentation
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: [021]
**Priority**: 🟡 High
**Type**: Documentation

**Description**: Write comprehensive developer documentation for logging.

**Files to Create/Modify**:
- `docs/LOGGING_GUIDE.md`
- `docs/LOGGING_BEST_PRACTICES.md`
- `docs/LOGGING_API.md`

**Implementation Steps**:
1. Write logging guide (how to add logging to code)
2. Document LoggerMixin usage with examples
3. Document best practices (what to log, what not to log)
4. Document log levels and when to use each
5. Document correlation ID usage
6. Document performance considerations
7. Document security considerations
8. Add code examples for common scenarios

**Acceptance Criteria**:
- [ ] Developer guide complete
- [ ] Best practices documented
- [ ] API reference complete
- [ ] Code examples provided
- [ ] Security guidelines included

---

### [034] Create User Documentation
**Status**: ⬜ Pending
**Estimated Time**: 3 hours
**Dependencies**: [026]
**Priority**: 🟡 High
**Type**: Documentation

**Description**: Write user-facing documentation for logging features.

**Files to Create/Modify**:
- `docs/USER_LOGGING_GUIDE.md`
- Update `docs/FEATURE_DOCUMENTATION.md`

**Implementation Steps**:
1. Write user guide for log viewer
2. Document how to filter and search logs
3. Document how to export diagnostic reports
4. Write troubleshooting guide
5. Add screenshots of log viewer
6. Update feature documentation
7. Update README with logging info

**Acceptance Criteria**:
- [ ] User guide complete
- [ ] Export process documented
- [ ] Troubleshooting guide complete
- [ ] Screenshots included
- [ ] Feature docs updated
- [ ] README updated

---

### [035] Create Usage Examples
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [021]
**Priority**: 🟢 Medium
**Type**: Documentation

**Description**: Create comprehensive code examples for logging usage.

**Files to Create/Modify**:
- `lib/examples/logging_example.dart`

**Implementation Steps**:
1. Create example showing basic logging
2. Create example showing LoggerMixin usage
3. Create example showing correlation context
4. Create example showing custom configuration
5. Create example showing performance timing
6. Add comprehensive comments
7. Verify examples run successfully

**Acceptance Criteria**:
- [ ] All examples are complete
- [ ] Examples run successfully
- [ ] Examples are well-commented
- [ ] Cover all major use cases

---

### [036] Update Architecture Documentation
**Status**: ⬜ Pending
**Estimated Time**: 2 hours
**Dependencies**: [009]
**Priority**: 🟢 Medium
**Type**: Documentation

**Description**: Update architecture documentation to include logging.

**Files to Create/Modify**:
- `lib/core/architecture/clean_architecture_diagram.md`
- `docs/ARCHITECTURE.md`

**Implementation Steps**:
1. Update architecture diagram with logging layer
2. Document how logging fits into clean architecture
3. Document logging infrastructure components
4. Document cross-cutting concern approach
5. Update component diagrams

**Acceptance Criteria**:
- [ ] Architecture diagrams updated
- [ ] Logging layer documented
- [ ] Component relationships clear
- [ ] Documentation complete

---

### [037] Final Code Review and Polish
**Status**: ⬜ Pending
**Estimated Time**: 4 hours
**Dependencies**: All previous tasks
**Priority**: 🔴 Critical
**Type**: Polish

**Description**: Final code review, cleanup, and preparation for merge.

**Implementation Steps**:
1. Run all tests and verify 100% pass
2. Run Flutter analyze and fix any issues
3. Check code coverage (target > 80%)
4. Review all TODO comments
5. Clean up debug code
6. Verify documentation completeness
7. Verify no sensitive data in code
8. Run performance benchmarks
9. Create summary of changes
10. Prepare for code review

**Acceptance Criteria**:
- [ ] All tests passing (unit, widget, integration)
- [ ] No linter errors or warnings
- [ ] Code coverage > 80%
- [ ] No TODO comments remaining
- [ ] No debug code in production
- [ ] All documentation complete
- [ ] Performance benchmarks met
- [ ] Ready for code review

---

## Task Dependencies Graph

```
Phase 1: Foundation
[001] LogLevel
  └─> [003] LogEntry
  └─> [006] LogConfig
  └─> [008] Logger

[002] LogLocation
  └─> [003] LogEntry

[003] LogEntry
  └─> [007] LogWriter
  └─> [008] Logger

[004] CorrelationContext
  └─> [008] Logger

[005] SensitiveDataRedactor
  └─> [008] Logger

[006] LogConfig
  └─> [007] LogWriter
  └─> [008] Logger
  └─> [009] AppLogger

[007] LogWriter
  └─> [008] Logger

[008] Logger
  └─> [009] AppLogger

[009] AppLogger
  └─> [010] LoggerMixin
  └─> [011] Persist Config
  └─> [022] LogViewerPanel
  └─> [023] LogExportService

[010] LoggerMixin
  └─> [012-021] All Service/Class Logging

Phase 2: Service Integration
[012-021] All logging integration tasks run in parallel
  └─> [028] Unit Tests
  └─> [029] Integration Tests

Phase 3: UI & Tools
[022] LogViewerPanel
  └─> [024] Export Button
  └─> [026] Integration into HomePage

[023] LogExportService
  └─> [024] Export Button

[024] + [026] → UI Complete
  └─> [032] Widget Tests

Phase 4: Testing & Documentation
[028-032] All tests
  └─> [037] Final Review

[033-036] All documentation
  └─> [037] Final Review

All Tasks
  └─> [037] Final Review
```

## Progress Tracking

### Overall Progress
- **Total Tasks**: 37
- **Completed**: 0
- **In Progress**: 0
- **Blocked**: 0
- **Pending**: 37

### Phase Progress
- **Phase 1 (Foundation)**: 0/11 (0%)
- **Phase 2 (Service Integration)**: 0/10 (0%)
- **Phase 3 (UI & Tools)**: 0/6 (0%)
- **Phase 4 (Testing & Documentation)**: 0/10 (0%)

### Time Estimates
- **Phase 1**: ~22 hours (Week 1)
- **Phase 2**: ~24 hours (Week 2)
- **Phase 3**: ~20 hours (Week 3)
- **Phase 4**: ~29 hours (Week 4)
- **Total**: ~95 hours (~4 weeks for 1 engineer at 24 hours/week)

## Notes

### Parallel Execution Opportunities
- **Phase 1**: Tasks [001], [002], [004], [005] can be done in parallel
- **Phase 2**: All service integration tasks [012-021] can be done in parallel after [010]
- **Phase 3**: Tasks [022], [023], [025] can be done in parallel
- **Phase 4**: All testing [028-032] and documentation [033-036] can be done in parallel

### Critical Path
```
[001] → [003] → [007] → [008] → [009] → [010] → 
[012-021 Service Integration] → [022] → [026] → 
[028-032 Testing] → [037]
```

### Key Milestones
1. **Week 1 End**: Logging infrastructure complete and tested
2. **Week 2 End**: All services/classes have logging integrated
3. **Week 3 End**: Log viewer UI complete and integrated
4. **Week 4 End**: All tests pass, documentation complete, ready for merge

### Testing Strategy
- Unit tests written alongside implementation (not deferred)
- Integration tests after all services have logging
- Widget tests after UI components complete
- Performance and security tests before final review

### Performance Checkpoints
- After [009]: Verify logging infrastructure overhead
- After [021]: Verify service integration overhead
- After [026]: Verify UI performance with large logs
- Final [030]: Comprehensive performance benchmarks

---

**Created**: 2025-10-01
**Last Updated**: 2025-10-01
**Feature**: 001-observability
**Status**: Ready for Implementation
**Estimated Duration**: 4 weeks (95 hours)
