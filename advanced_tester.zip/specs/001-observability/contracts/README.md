# API Contracts

This directory contains API contracts and specifications for Observability.

## Files

- `api-spec.json` - REST API specifications (if applicable)
- `service-contract.md` - Service interface contracts
- `data-models.md` - Data model specifications

## Purpose

Contracts define the interfaces between components and ensure:
- Consistent API design
- Clear communication between layers
- Easier testing with mocks
- Better documentation

---

**Created**: 2025-10-01
