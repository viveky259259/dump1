# Quickstart: Golden Test Generation

## What is this feature?
[Brief 1-2 sentence description]

## Why do we need it?
[Brief explanation of the problem it solves]

## How does it work?
[High-level explanation of the solution]

## Quick Usage Example

```dart
// Example code showing how to use the feature
final feature = Feature();
await feature.doSomething();
```

## What's Next?
1. Review the [full specification](spec.md)
2. Check the [implementation plan](plan.md)
3. View [task breakdown](tasks.md)
4. Read [research findings](research.md)

---

**Created**: 2025-10-01
