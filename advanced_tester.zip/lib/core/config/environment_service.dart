import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'environment_config.dart';

/// Service for managing environment configuration
class EnvironmentService extends ChangeNotifier {
  static const String _configKey = 'environment_config';

  EnvironmentConfig _config = const EnvironmentConfig();
  bool _isInitialized = false;
  SharedPreferences? _prefs;

  // Getters
  EnvironmentConfig get config => _config;
  bool get isInitialized => _isInitialized;
  bool get hasAICapabilities => _config.hasAICapabilities;
  String? get primaryAIProvider => _config.primaryAIProvider;

  /// Initialize the environment service
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      _prefs = await SharedPreferences.getInstance();

      // Load configuration in order of precedence:
      // 1. Dart-define flags (highest priority)
      // 2. Environment variables
      // 3. Saved preferences (lowest priority)

      final dartDefineConfig = EnvironmentConfig.fromDartDefine();
      final envConfig = EnvironmentConfig.fromEnvironment();
      final savedConfig = await _loadSavedConfig();

      // Merge configurations with dart-define taking precedence
      _config = dartDefineConfig.merge(envConfig).merge(savedConfig);

      _isInitialized = true;
      notifyListeners();

      if (kDebugMode) {
        print('Environment initialized: $_config');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to initialize environment: $e');
      }
      // Use default config on error
      _config = const EnvironmentConfig();
      _isInitialized = true;
      notifyListeners();
    }
  }

  /// Update configuration
  Future<void> updateConfig(EnvironmentConfig newConfig) async {
    _config = newConfig;
    await _saveConfig();
    notifyListeners();
  }

  /// Update specific configuration values
  Future<void> updateConfigValues(Map<String, dynamic> values) async {
    final updatedConfig = EnvironmentConfig.fromMap(
      _config.toMap()..addAll(values),
    );
    await updateConfig(updatedConfig);
  }

  /// Get API key for specific provider
  String? getApiKey(String provider) {
    return _config.getApiKey(provider);
  }

  /// Set API key for specific provider
  Future<void> setApiKey(String provider, String? apiKey) async {
    final updates = <String, dynamic>{};

    switch (provider.toLowerCase()) {
      case 'openai':
        updates['openaiApiKey'] = apiKey;
        break;
      case 'anthropic':
        updates['anthropicApiKey'] = apiKey;
        break;
      case 'gemini':
        updates['geminiApiKey'] = apiKey;
        break;
    }

    if (updates.isNotEmpty) {
      await updateConfigValues(updates);
    }
  }

  /// Enable/disable AI features
  Future<void> setAIEnabled(bool enabled) async {
    await updateConfigValues({'enableAI': enabled});
  }

  /// Enable/disable demo mode
  Future<void> setDemoMode(bool enabled) async {
    await updateConfigValues({'enableDemoMode': enabled});
  }

  /// Enable/disable debug mode
  Future<void> setDebugMode(bool enabled) async {
    await updateConfigValues({'enableDebugMode': enabled});
  }

  /// Set theme preferences
  Future<void> setThemePreferences({
    bool? enableDarkMode,
    String? themeColor,
    bool? enableAnimations,
  }) async {
    final updates = <String, dynamic>{};

    if (enableDarkMode != null) updates['enableDarkMode'] = enableDarkMode;
    if (themeColor != null) updates['themeColor'] = themeColor;
    if (enableAnimations != null)
      updates['enableAnimations'] = enableAnimations;

    if (updates.isNotEmpty) {
      await updateConfigValues(updates);
    }
  }

  /// Set test generation preferences
  Future<void> setTestGenerationPreferences({
    bool? enableAutoTestGeneration,
    String? defaultTestFramework,
    bool? enableTestCoverage,
  }) async {
    final updates = <String, dynamic>{};

    if (enableAutoTestGeneration != null) {
      updates['enableAutoTestGeneration'] = enableAutoTestGeneration;
    }
    if (defaultTestFramework != null) {
      updates['defaultTestFramework'] = defaultTestFramework;
    }
    if (enableTestCoverage != null) {
      updates['enableTestCoverage'] = enableTestCoverage;
    }

    if (updates.isNotEmpty) {
      await updateConfigValues(updates);
    }
  }

  /// Set development preferences
  Future<void> setDevelopmentPreferences({
    bool? enableHotReload,
    bool? enablePerformanceMonitoring,
    String? logLevel,
  }) async {
    final updates = <String, dynamic>{};

    if (enableHotReload != null) {
      updates['enableHotReload'] = enableHotReload;
    }
    if (enablePerformanceMonitoring != null) {
      updates['enablePerformanceMonitoring'] = enablePerformanceMonitoring;
    }
    if (logLevel != null) {
      updates['logLevel'] = logLevel;
    }

    if (updates.isNotEmpty) {
      await updateConfigValues(updates);
    }
  }

  /// Set service URLs
  Future<void> setServiceUrls({
    String? devtoolsServerUrl,
    String? vmServiceUrl,
  }) async {
    final updates = <String, dynamic>{};

    if (devtoolsServerUrl != null) {
      updates['devtoolsServerUrl'] = devtoolsServerUrl;
    }
    if (vmServiceUrl != null) {
      updates['vmServiceUrl'] = vmServiceUrl;
    }

    if (updates.isNotEmpty) {
      await updateConfigValues(updates);
    }
  }

  /// Validate current configuration
  List<String> validateConfig() {
    return _config.validate();
  }

  /// Reset to default configuration
  Future<void> resetToDefaults() async {
    _config = const EnvironmentConfig();
    await _saveConfig();
    notifyListeners();
  }

  /// Clear all saved configuration
  Future<void> clearSavedConfig() async {
    if (_prefs != null) {
      await _prefs!.remove(_configKey);
    }
    _config = const EnvironmentConfig();
    notifyListeners();
  }

  /// Export configuration for sharing/debugging
  Map<String, dynamic> exportConfig() {
    return _config.toMap();
  }

  /// Import configuration from map
  Future<void> importConfig(Map<String, dynamic> configMap) async {
    try {
      final importedConfig = EnvironmentConfig.fromMap(configMap);
      await updateConfig(importedConfig);
    } catch (e) {
      if (kDebugMode) {
        print('Failed to import configuration: $e');
      }
      throw Exception('Invalid configuration format');
    }
  }

  /// Check if a specific feature is enabled
  bool isFeatureEnabled(String feature) {
    switch (feature.toLowerCase()) {
      case 'ai':
        return _config.enableAI;
      case 'demo':
        return _config.enableDemoMode;
      case 'debug':
        return _config.enableDebugMode;
      case 'analytics':
        return _config.enableAnalytics;
      case 'hot_reload':
        return _config.enableHotReload;
      case 'performance_monitoring':
        return _config.enablePerformanceMonitoring;
      case 'dark_mode':
        return _config.enableDarkMode;
      case 'animations':
        return _config.enableAnimations;
      case 'auto_test_generation':
        return _config.enableAutoTestGeneration;
      case 'test_coverage':
        return _config.enableTestCoverage;
      case 'secure_mode':
        return _config.enableSecureMode;
      case 'api_key_validation':
        return _config.enableApiKeyValidation;
      default:
        return false;
    }
  }

  /// Get configuration summary for debugging
  Map<String, dynamic> getConfigSummary() {
    return {
      'isInitialized': _isInitialized,
      'hasAICapabilities': hasAICapabilities,
      'primaryAIProvider': primaryAIProvider,
      'features': {
        'ai': _config.enableAI,
        'demo': _config.enableDemoMode,
        'debug': _config.enableDebugMode,
        'analytics': _config.enableAnalytics,
        'hotReload': _config.enableHotReload,
        'performanceMonitoring': _config.enablePerformanceMonitoring,
        'darkMode': _config.enableDarkMode,
        'animations': _config.enableAnimations,
        'autoTestGeneration': _config.enableAutoTestGeneration,
        'testCoverage': _config.enableTestCoverage,
        'secureMode': _config.enableSecureMode,
        'apiKeyValidation': _config.enableApiKeyValidation,
      },
      'urls': {
        'devtoolsServer': _config.devtoolsServerUrl,
        'vmService': _config.vmServiceUrl,
      },
      'settings': {
        'logLevel': _config.logLevel,
        'themeColor': _config.themeColor,
        'defaultTestFramework': _config.defaultTestFramework,
        'apiTimeout': _config.apiTimeout?.inMilliseconds,
      },
    };
  }

  // Private methods
  Future<EnvironmentConfig> _loadSavedConfig() async {
    if (_prefs == null) return const EnvironmentConfig();

    try {
      final configString = _prefs!.getString(_configKey);
      if (configString == null) return const EnvironmentConfig();

      // For now, we'll store as a simple string representation
      // In a real app, you might want to use JSON serialization
      return const EnvironmentConfig(); // Placeholder
    } catch (e) {
      if (kDebugMode) {
        print('Failed to load saved config: $e');
      }
      return const EnvironmentConfig();
    }
  }

  Future<void> _saveConfig() async {
    if (_prefs == null) return;

    try {
      // For now, we'll save a simple representation
      // In a real app, you might want to use JSON serialization
      await _prefs!.setString(_configKey, _config.toString());
    } catch (e) {
      if (kDebugMode) {
        print('Failed to save config: $e');
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
  }
}
