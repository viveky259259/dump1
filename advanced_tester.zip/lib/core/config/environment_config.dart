import 'dart:io';

/// Environment configuration model
class EnvironmentConfig {
  // API Configuration
  final String? openaiApiKey;
  final String? anthropicApiKey;
  final String? geminiApiKey;

  // Service URLs
  final String? devtoolsServerUrl;
  final String? vmServiceUrl;

  // Feature Flags
  final bool enableAI;
  final bool enableDemoMode;
  final bool enableDebugMode;
  final bool enableAnalytics;

  // Development Settings
  final bool enableHotReload;
  final bool enablePerformanceMonitoring;
  final String? logLevel;

  // UI Settings
  final bool enableDarkMode;
  final String? themeColor;
  final bool enableAnimations;

  // Test Generation Settings
  final bool enableAutoTestGeneration;
  final String? defaultTestFramework;
  final bool enableTestCoverage;

  // Security Settings
  final bool enableSecureMode;
  final bool enableApiKeyValidation;
  final Duration? apiTimeout;

  // Recursive Analysis Settings
  final int? recursiveAnalysisMaxDepth;
  final int? recursiveAnalysisMaxChildren;
  final bool? recursiveAnalysisEnableCaching;
  final bool? recursiveAnalysisIncludeProperties;
  final bool? recursiveAnalysisIncludeDependencies;
  final bool? recursiveAnalysisIncludeSourceContext;
  final bool? recursiveAnalysisIncludeAccessibility;
  final bool? recursiveAnalysisUseDetailedHierarchy;
  final Set<String>? recursiveAnalysisSkipWidgets;
  final Set<String>? recursiveAnalysisPriorityWidgets;

  const EnvironmentConfig({
    this.openaiApiKey,
    this.anthropicApiKey,
    this.geminiApiKey,
    this.devtoolsServerUrl,
    this.vmServiceUrl,
    this.enableAI = true,
    this.enableDemoMode = false,
    this.enableDebugMode = false,
    this.enableAnalytics = true,
    this.enableHotReload = true,
    this.enablePerformanceMonitoring = false,
    this.logLevel,
    this.enableDarkMode = true,
    this.themeColor,
    this.enableAnimations = true,
    this.enableAutoTestGeneration = false,
    this.defaultTestFramework = 'flutter_test',
    this.enableTestCoverage = true,
    this.enableSecureMode = false,
    this.enableApiKeyValidation = true,
    this.apiTimeout,
    this.recursiveAnalysisMaxDepth,
    this.recursiveAnalysisMaxChildren,
    this.recursiveAnalysisEnableCaching,
    this.recursiveAnalysisIncludeProperties,
    this.recursiveAnalysisIncludeDependencies,
    this.recursiveAnalysisIncludeSourceContext,
    this.recursiveAnalysisIncludeAccessibility,
    this.recursiveAnalysisUseDetailedHierarchy,
    this.recursiveAnalysisSkipWidgets,
    this.recursiveAnalysisPriorityWidgets,
  });

  /// Create environment config from environment variables
  factory EnvironmentConfig.fromEnvironment() {
    return EnvironmentConfig(
      // API Keys
      openaiApiKey: _getEnvVar('OPENAI_API_KEY'),
      anthropicApiKey: _getEnvVar('ANTHROPIC_API_KEY'),
      geminiApiKey: _getEnvVar('GEMINI_API_KEY'),

      // Service URLs
      devtoolsServerUrl: _getEnvVar('DEVTOOLS_SERVER_URL'),
      vmServiceUrl: _getEnvVar('VM_SERVICE_URL'),

      // Feature Flags
      enableAI: _getBoolEnvVar('ENABLE_AI', true),
      enableDemoMode: _getBoolEnvVar('DEMO_MODE', false),
      enableDebugMode: _getBoolEnvVar('DEBUG_MODE', false),
      enableAnalytics: _getBoolEnvVar('ENABLE_ANALYTICS', true),

      // Development Settings
      enableHotReload: _getBoolEnvVar('ENABLE_HOT_RELOAD', true),
      enablePerformanceMonitoring: _getBoolEnvVar(
        'ENABLE_PERFORMANCE_MONITORING',
        false,
      ),
      logLevel: _getEnvVar('LOG_LEVEL'),

      // UI Settings
      enableDarkMode: _getBoolEnvVar('ENABLE_DARK_MODE', true),
      themeColor: _getEnvVar('THEME_COLOR'),
      enableAnimations: _getBoolEnvVar('ENABLE_ANIMATIONS', true),

      // Test Generation Settings
      enableAutoTestGeneration: _getBoolEnvVar(
        'ENABLE_AUTO_TEST_GENERATION',
        false,
      ),
      defaultTestFramework:
          _getEnvVar('DEFAULT_TEST_FRAMEWORK') ?? 'flutter_test',
      enableTestCoverage: _getBoolEnvVar('ENABLE_TEST_COVERAGE', true),

      // Security Settings
      enableSecureMode: _getBoolEnvVar('ENABLE_SECURE_MODE', false),
      enableApiKeyValidation: _getBoolEnvVar('ENABLE_API_KEY_VALIDATION', true),
      apiTimeout: _getDurationEnvVar('API_TIMEOUT'),
    );
  }

  /// Create environment config from dart-define flags
  factory EnvironmentConfig.fromDartDefine() {
    return EnvironmentConfig(
      // API Keys
      openaiApiKey: _getDartDefine('OPENAI_API_KEY'),
      anthropicApiKey: _getDartDefine('ANTHROPIC_API_KEY'),
      geminiApiKey: _getDartDefine('GEMINI_API_KEY'),

      // Service URLs
      devtoolsServerUrl: _getDartDefine('DEVTOOLS_SERVER_URL'),
      vmServiceUrl: _getDartDefine('VM_SERVICE_URL'),

      // Feature Flags
      enableAI: _getBoolDartDefine('ENABLE_AI', true),
      enableDemoMode: _getBoolDartDefine('DEMO_MODE', false),
      enableDebugMode: _getBoolDartDefine('DEBUG_MODE', false),
      enableAnalytics: _getBoolDartDefine('ENABLE_ANALYTICS', true),

      // Development Settings
      enableHotReload: _getBoolDartDefine('ENABLE_HOT_RELOAD', true),
      enablePerformanceMonitoring: _getBoolDartDefine(
        'ENABLE_PERFORMANCE_MONITORING',
        false,
      ),
      logLevel: _getDartDefine('LOG_LEVEL'),

      // UI Settings
      enableDarkMode: _getBoolDartDefine('ENABLE_DARK_MODE', true),
      themeColor: _getDartDefine('THEME_COLOR'),
      enableAnimations: _getBoolDartDefine('ENABLE_ANIMATIONS', true),

      // Test Generation Settings
      enableAutoTestGeneration: _getBoolDartDefine(
        'ENABLE_AUTO_TEST_GENERATION',
        false,
      ),
      defaultTestFramework:
          _getDartDefine('DEFAULT_TEST_FRAMEWORK') ?? 'flutter_test',
      enableTestCoverage: _getBoolDartDefine('ENABLE_TEST_COVERAGE', true),

      // Security Settings
      enableSecureMode: _getBoolDartDefine('ENABLE_SECURE_MODE', false),
      enableApiKeyValidation: _getBoolDartDefine(
        'ENABLE_API_KEY_VALIDATION',
        true,
      ),
      apiTimeout: _getDurationDartDefine('API_TIMEOUT'),
      recursiveAnalysisMaxDepth: _getIntDartDefine(
        'RECURSIVE_ANALYSIS_MAX_DEPTH',
      ),
      recursiveAnalysisMaxChildren: _getIntDartDefine(
        'RECURSIVE_ANALYSIS_MAX_CHILDREN',
      ),
      recursiveAnalysisEnableCaching: _getBoolDartDefine(
        'RECURSIVE_ANALYSIS_ENABLE_CACHING',
        true,
      ),
      recursiveAnalysisIncludeProperties: _getBoolDartDefine(
        'RECURSIVE_ANALYSIS_INCLUDE_PROPERTIES',
        true,
      ),
      recursiveAnalysisIncludeDependencies: _getBoolDartDefine(
        'RECURSIVE_ANALYSIS_INCLUDE_DEPENDENCIES',
        true,
      ),
      recursiveAnalysisIncludeSourceContext: _getBoolDartDefine(
        'RECURSIVE_ANALYSIS_INCLUDE_SOURCE_CONTEXT',
        false,
      ),
      recursiveAnalysisIncludeAccessibility: _getBoolDartDefine(
        'RECURSIVE_ANALYSIS_INCLUDE_ACCESSIBILITY',
        true,
      ),
      recursiveAnalysisUseDetailedHierarchy: _getBoolDartDefine(
        'RECURSIVE_ANALYSIS_USE_DETAILED_HIERARCHY',
        true,
      ),
      recursiveAnalysisSkipWidgets: _getStringSetDartDefine(
        'RECURSIVE_ANALYSIS_SKIP_WIDGETS',
      ),
      recursiveAnalysisPriorityWidgets: _getStringSetDartDefine(
        'RECURSIVE_ANALYSIS_PRIORITY_WIDGETS',
      ),
    );
  }

  /// Merge with another config (this takes precedence)
  EnvironmentConfig merge(EnvironmentConfig other) {
    return EnvironmentConfig(
      // API Keys
      openaiApiKey: openaiApiKey ?? other.openaiApiKey,
      anthropicApiKey: anthropicApiKey ?? other.anthropicApiKey,
      geminiApiKey: geminiApiKey ?? other.geminiApiKey,

      // Service URLs
      devtoolsServerUrl: devtoolsServerUrl ?? other.devtoolsServerUrl,
      vmServiceUrl: vmServiceUrl ?? other.vmServiceUrl,

      // Feature Flags
      enableAI: enableAI,
      enableDemoMode: enableDemoMode,
      enableDebugMode: enableDebugMode,
      enableAnalytics: enableAnalytics,

      // Development Settings
      enableHotReload: enableHotReload,
      enablePerformanceMonitoring: enablePerformanceMonitoring,
      logLevel: logLevel ?? other.logLevel,

      // UI Settings
      enableDarkMode: enableDarkMode,
      themeColor: themeColor ?? other.themeColor,
      enableAnimations: enableAnimations,

      // Test Generation Settings
      enableAutoTestGeneration: enableAutoTestGeneration,
      defaultTestFramework: defaultTestFramework,
      enableTestCoverage: enableTestCoverage,

      // Security Settings
      enableSecureMode: enableSecureMode,
      enableApiKeyValidation: enableApiKeyValidation,
      apiTimeout: apiTimeout ?? other.apiTimeout,
      // Recursive Analysis Settings
      recursiveAnalysisMaxDepth:
          recursiveAnalysisMaxDepth ?? other.recursiveAnalysisMaxDepth,
      recursiveAnalysisMaxChildren:
          recursiveAnalysisMaxChildren ?? other.recursiveAnalysisMaxChildren,
      recursiveAnalysisEnableCaching:
          recursiveAnalysisEnableCaching ??
          other.recursiveAnalysisEnableCaching,
      recursiveAnalysisIncludeProperties:
          recursiveAnalysisIncludeProperties ??
          other.recursiveAnalysisIncludeProperties,
      recursiveAnalysisIncludeDependencies:
          recursiveAnalysisIncludeDependencies ??
          other.recursiveAnalysisIncludeDependencies,
      recursiveAnalysisIncludeSourceContext:
          recursiveAnalysisIncludeSourceContext ??
          other.recursiveAnalysisIncludeSourceContext,
      recursiveAnalysisIncludeAccessibility:
          recursiveAnalysisIncludeAccessibility ??
          other.recursiveAnalysisIncludeAccessibility,
      recursiveAnalysisUseDetailedHierarchy:
          recursiveAnalysisUseDetailedHierarchy ??
          other.recursiveAnalysisUseDetailedHierarchy,
      recursiveAnalysisSkipWidgets:
          recursiveAnalysisSkipWidgets ?? other.recursiveAnalysisSkipWidgets,
      recursiveAnalysisPriorityWidgets:
          recursiveAnalysisPriorityWidgets ??
          other.recursiveAnalysisPriorityWidgets,
    );
  }

  /// Check if AI features are available
  bool get hasAICapabilities {
    return enableAI &&
        (openaiApiKey != null ||
            anthropicApiKey != null ||
            geminiApiKey != null);
  }

  /// Get primary AI provider
  String? get primaryAIProvider {
    if (openaiApiKey != null) return 'openai';
    if (anthropicApiKey != null) return 'anthropic';
    if (geminiApiKey != null) return 'gemini';
    return null;
  }

  /// Get API key for specific provider
  String? getApiKey(String provider) {
    switch (provider.toLowerCase()) {
      case 'openai':
        return openaiApiKey;
      case 'anthropic':
        return anthropicApiKey;
      case 'gemini':
        return geminiApiKey;
      default:
        return null;
    }
  }

  /// Validate configuration
  List<String> validate() {
    final errors = <String>[];

    if (enableAI && !hasAICapabilities) {
      errors.add('AI is enabled but no API keys are configured');
    }

    if (enableApiKeyValidation) {
      if (openaiApiKey != null && !_isValidApiKey(openaiApiKey!)) {
        errors.add('Invalid OpenAI API key format');
      }
      if (anthropicApiKey != null && !_isValidApiKey(anthropicApiKey!)) {
        errors.add('Invalid Anthropic API key format');
      }
      if (geminiApiKey != null && !_isValidApiKey(geminiApiKey!)) {
        errors.add('Invalid Gemini API key format');
      }
    }

    if (devtoolsServerUrl != null && !_isValidUrl(devtoolsServerUrl!)) {
      errors.add('Invalid DevTools server URL format');
    }

    if (vmServiceUrl != null && !_isValidUrl(vmServiceUrl!)) {
      errors.add('Invalid VM service URL format');
    }

    return errors;
  }

  /// Convert to map for storage
  Map<String, dynamic> toMap() {
    return {
      'openaiApiKey': openaiApiKey,
      'anthropicApiKey': anthropicApiKey,
      'geminiApiKey': geminiApiKey,
      'devtoolsServerUrl': devtoolsServerUrl,
      'vmServiceUrl': vmServiceUrl,
      'enableAI': enableAI,
      'enableDemoMode': enableDemoMode,
      'enableDebugMode': enableDebugMode,
      'enableAnalytics': enableAnalytics,
      'enableHotReload': enableHotReload,
      'enablePerformanceMonitoring': enablePerformanceMonitoring,
      'logLevel': logLevel,
      'enableDarkMode': enableDarkMode,
      'themeColor': themeColor,
      'enableAnimations': enableAnimations,
      'enableAutoTestGeneration': enableAutoTestGeneration,
      'defaultTestFramework': defaultTestFramework,
      'enableTestCoverage': enableTestCoverage,
      'enableSecureMode': enableSecureMode,
      'enableApiKeyValidation': enableApiKeyValidation,
      'apiTimeout': apiTimeout?.inMilliseconds,
      'recursiveAnalysisMaxDepth': recursiveAnalysisMaxDepth,
      'recursiveAnalysisMaxChildren': recursiveAnalysisMaxChildren,
      'recursiveAnalysisEnableCaching': recursiveAnalysisEnableCaching,
      'recursiveAnalysisIncludeProperties': recursiveAnalysisIncludeProperties,
      'recursiveAnalysisIncludeDependencies':
          recursiveAnalysisIncludeDependencies,
      'recursiveAnalysisIncludeSourceContext':
          recursiveAnalysisIncludeSourceContext,
      'recursiveAnalysisIncludeAccessibility':
          recursiveAnalysisIncludeAccessibility,
      'recursiveAnalysisUseDetailedHierarchy':
          recursiveAnalysisUseDetailedHierarchy,
      'recursiveAnalysisSkipWidgets': recursiveAnalysisSkipWidgets?.toList(),
      'recursiveAnalysisPriorityWidgets': recursiveAnalysisPriorityWidgets
          ?.toList(),
    };
  }

  /// Create from map
  factory EnvironmentConfig.fromMap(Map<String, dynamic> map) {
    return EnvironmentConfig(
      openaiApiKey: map['openaiApiKey'] as String?,
      anthropicApiKey: map['anthropicApiKey'] as String?,
      geminiApiKey: map['geminiApiKey'] as String?,
      devtoolsServerUrl: map['devtoolsServerUrl'] as String?,
      vmServiceUrl: map['vmServiceUrl'] as String?,
      enableAI: map['enableAI'] as bool? ?? true,
      enableDemoMode: map['enableDemoMode'] as bool? ?? false,
      enableDebugMode: map['enableDebugMode'] as bool? ?? false,
      enableAnalytics: map['enableAnalytics'] as bool? ?? true,
      enableHotReload: map['enableHotReload'] as bool? ?? true,
      enablePerformanceMonitoring:
          map['enablePerformanceMonitoring'] as bool? ?? false,
      logLevel: map['logLevel'] as String?,
      enableDarkMode: map['enableDarkMode'] as bool? ?? true,
      themeColor: map['themeColor'] as String?,
      enableAnimations: map['enableAnimations'] as bool? ?? true,
      enableAutoTestGeneration:
          map['enableAutoTestGeneration'] as bool? ?? false,
      defaultTestFramework:
          map['defaultTestFramework'] as String? ?? 'flutter_test',
      enableTestCoverage: map['enableTestCoverage'] as bool? ?? true,
      enableSecureMode: map['enableSecureMode'] as bool? ?? false,
      enableApiKeyValidation: map['enableApiKeyValidation'] as bool? ?? true,
      apiTimeout: map['apiTimeout'] != null
          ? Duration(milliseconds: map['apiTimeout'] as int)
          : null,
      recursiveAnalysisMaxDepth: map['recursiveAnalysisMaxDepth'] as int?,
      recursiveAnalysisMaxChildren: map['recursiveAnalysisMaxChildren'] as int?,
      recursiveAnalysisEnableCaching:
          map['recursiveAnalysisEnableCaching'] as bool?,
      recursiveAnalysisIncludeProperties:
          map['recursiveAnalysisIncludeProperties'] as bool?,
      recursiveAnalysisIncludeDependencies:
          map['recursiveAnalysisIncludeDependencies'] as bool?,
      recursiveAnalysisIncludeSourceContext:
          map['recursiveAnalysisIncludeSourceContext'] as bool?,
      recursiveAnalysisIncludeAccessibility:
          map['recursiveAnalysisIncludeAccessibility'] as bool?,
      recursiveAnalysisUseDetailedHierarchy:
          map['recursiveAnalysisUseDetailedHierarchy'] as bool?,
      recursiveAnalysisSkipWidgets: map['recursiveAnalysisSkipWidgets'] != null
          ? (map['recursiveAnalysisSkipWidgets'] as List).cast<String>().toSet()
          : null,
      recursiveAnalysisPriorityWidgets:
          map['recursiveAnalysisPriorityWidgets'] != null
          ? (map['recursiveAnalysisPriorityWidgets'] as List)
                .cast<String>()
                .toSet()
          : null,
    );
  }

  // Helper methods
  static String? _getEnvVar(String key) {
    return Platform.environment[key];
  }

  static String? _getDartDefine(String key) {
    return String.fromEnvironment(key);
  }

  static bool _getBoolEnvVar(String key, bool defaultValue) {
    final value = Platform.environment[key];
    if (value == null) return defaultValue;
    return value.toLowerCase() == 'true';
  }

  static bool _getBoolDartDefine(String key, bool defaultValue) {
    final value = String.fromEnvironment(key);
    if (value.isEmpty) return defaultValue;
    return value.toLowerCase() == 'true';
  }

  static Duration? _getDurationEnvVar(String key) {
    final value = Platform.environment[key];
    if (value == null) return null;
    try {
      return Duration(milliseconds: int.parse(value));
    } catch (e) {
      return null;
    }
  }

  static Duration? _getDurationDartDefine(String key) {
    final value = String.fromEnvironment(key);
    if (value.isEmpty) return null;
    try {
      return Duration(milliseconds: int.parse(value));
    } catch (e) {
      return null;
    }
  }

  static int? _getIntDartDefine(String key) {
    final value = String.fromEnvironment(key);
    if (value.isEmpty) return null;
    try {
      return int.parse(value);
    } catch (e) {
      return null;
    }
  }

  static Set<String>? _getStringSetDartDefine(String key) {
    final value = String.fromEnvironment(key);
    if (value.isEmpty) return null;
    return value.split(',').map((s) => s.trim()).toSet();
  }

  bool _isValidApiKey(String key) {
    // Basic validation - API keys should be non-empty and contain expected characters
    return key.isNotEmpty && key.length > 10;
  }

  bool _isValidUrl(String url) {
    try {
      Uri.parse(url);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  String toString() {
    return 'EnvironmentConfig('
        'enableAI: $enableAI, '
        'enableDemoMode: $enableDemoMode, '
        'enableDebugMode: $enableDebugMode, '
        'hasAICapabilities: $hasAICapabilities, '
        'primaryAIProvider: $primaryAIProvider'
        ')';
  }
}
