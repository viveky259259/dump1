import 'service_locator.dart';
import '../../domain/repositories/widget_repository.dart';
import '../../data/datasources/vm_service_datasource.dart';
import '../../data/datasources/file_system_datasource.dart' as fs;
import '../../data/repositories/widget_repository_impl.dart';
import '../../data/mappers/widget_mapper.dart';
import '../../domain/usecases/get_widget_tree_usecase.dart';
import '../../domain/usecases/get_widget_properties_usecase.dart';
import '../../domain/usecases/select_widget_usecase.dart';
import '../../domain/usecases/check_inspector_availability_usecase.dart';
import '../../domain/usecases/generate_test_usecase.dart';
import '../../domain/usecases/manage_test_cases_usecase.dart';

/// Dependency injection configuration
class DependencyInjection {
  static void configure() {
    _registerDataSources();
    _registerRepositories();
    _registerUseCases();
  }

  static void _registerDataSources() {
    // Register VM Service Data Source as factory (new instance each time)
    serviceLocator.registerFactory<VmServiceDataSource>(
      () => VmServiceDataSource(Uri.parse('ws://localhost:8080')),
    );

    // Register File System Data Source as singleton
    serviceLocator.registerSingleton<fs.FileSystemDataSource>(
      fs.FileSystemDataSource(),
    );

    // Register Widget Mapper as singleton
    serviceLocator.registerSingleton<WidgetMapper>(WidgetMapper());
  }

  static void _registerRepositories() {
    // Register Widget Repository as singleton
    serviceLocator.registerLazySingleton<WidgetRepository>(
      () => WidgetRepositoryImpl(
        serviceLocator.get<VmServiceDataSource>(),
        serviceLocator.get<fs.FileSystemDataSource>(),
        serviceLocator.get<WidgetMapper>(),
      ),
    );
  }

  static void _registerUseCases() {
    // Register Widget Use Cases
    serviceLocator.registerLazySingleton<GetWidgetTreeUseCase>(
      () => GetWidgetTreeUseCase(serviceLocator.get<WidgetRepository>()),
    );

    serviceLocator.registerLazySingleton<GetWidgetPropertiesUseCase>(
      () => GetWidgetPropertiesUseCase(serviceLocator.get<WidgetRepository>()),
    );

    serviceLocator.registerLazySingleton<SelectWidgetUseCase>(
      () => SelectWidgetUseCase(serviceLocator.get<WidgetRepository>()),
    );

    serviceLocator.registerLazySingleton<CheckInspectorAvailabilityUseCase>(
      () => CheckInspectorAvailabilityUseCase(
        serviceLocator.get<WidgetRepository>(),
      ),
    );

    // Register Test Generation Use Cases
    serviceLocator.registerLazySingleton<GenerateTestUseCase>(
      () => GenerateTestUseCase(),
    );

    serviceLocator.registerLazySingleton<ManageTestCasesUseCase>(
      () => ManageTestCasesUseCase(),
    );
  }

  /// Configure with custom VM Service URI
  static void configureWithVmServiceUri(Uri vmServiceUri) {
    // Unregister existing VM Service Data Source
    serviceLocator.unregister<VmServiceDataSource>();

    // Register with custom URI
    serviceLocator.registerFactory<VmServiceDataSource>(
      () => VmServiceDataSource(vmServiceUri),
    );
  }

  /// Reset all dependencies
  static void reset() {
    serviceLocator.reset();
  }
}
