/// Simple service locator for dependency injection
class ServiceLocator {
  static final ServiceLocator _instance = ServiceLocator._internal();
  factory ServiceLocator() => _instance;
  ServiceLocator._internal();

  final Map<Type, dynamic> _services = {};
  final Map<Type, FactoryFunction> _factories = {};
  final Map<Type, dynamic> _singletons = {};

  /// Register a singleton instance
  void registerSingleton<T>(T instance) {
    _singletons[T] = instance;
  }

  /// Register a factory function
  void registerFactory<T>(FactoryFunction<T> factory) {
    _factories[T] = factory;
  }

  /// Register a lazy singleton (created on first access)
  void registerLazySingleton<T>(FactoryFunction<T> factory) {
    _factories[T] = factory;
    // Mark as singleton
    _services[T] = null; // Placeholder
  }

  /// Get a service instance
  T get<T>() {
    // Check if it's a registered singleton
    if (_singletons.containsKey(T)) {
      return _singletons[T] as T;
    }

    // Check if it's a lazy singleton
    if (_services.containsKey(T)) {
      if (_services[T] == null && _factories.containsKey(T)) {
        _services[T] = _factories[T]!();
        return _services[T] as T;
      }
      return _services[T] as T;
    }

    // Check if it's a factory
    if (_factories.containsKey(T)) {
      return _factories[T]!() as T;
    }

    throw ServiceLocatorException('Service of type $T not registered');
  }

  /// Check if a service is registered
  bool isRegistered<T>() {
    return _singletons.containsKey(T) ||
        _services.containsKey(T) ||
        _factories.containsKey(T);
  }

  /// Reset all registrations
  void reset() {
    _services.clear();
    _factories.clear();
    _singletons.clear();
  }

  /// Unregister a specific service
  void unregister<T>() {
    _services.remove(T);
    _factories.remove(T);
    _singletons.remove(T);
  }
}

/// Factory function type
typedef FactoryFunction<T> = T Function();

/// Service locator exception
class ServiceLocatorException implements Exception {
  final String message;

  const ServiceLocatorException(this.message);

  @override
  String toString() => 'ServiceLocatorException: $message';
}

/// Global service locator instance
final serviceLocator = ServiceLocator();
