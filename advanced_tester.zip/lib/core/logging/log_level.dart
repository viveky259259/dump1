/// Logging levels with severity ordering.
///
/// Levels are ordered by severity from DEBUG (lowest) to FATAL (highest).
/// Use comparison operators to check if a level is enabled.
enum LogLevel {
  /// Detailed diagnostic information for debugging.
  debug(0, 'DEBUG'),

  /// General informational messages about application flow.
  info(1, 'INFO'),

  /// Warning messages for potentially problematic situations.
  warn(2, 'WARN'),

  /// Error messages for recoverable error conditions.
  error(3, 'ERROR'),

  /// Fatal error messages for unrecoverable errors.
  fatal(4, 'FATAL');

  /// Numeric severity level (0-4).
  final int severity;

  /// String representation of the level.
  final String name;

  const LogLevel(this.severity, this.name);

  /// Check if this level is at least as severe as [other].
  bool operator >=(LogLevel other) => severity >= other.severity;

  /// Check if this level is more severe than [other].
  bool operator >(LogLevel other) => severity > other.severity;

  /// Check if this level is less severe than [other].
  bool operator <(LogLevel other) => severity < other.severity;

  /// Check if this level is at most as severe as [other].
  bool operator <=(LogLevel other) => severity <= other.severity;

  /// Parse a log level from its string name.
  ///
  /// Returns null if the name is not recognized.
  static LogLevel? fromString(String name) {
    final upperName = name.toUpperCase();
    for (final level in LogLevel.values) {
      if (level.name == upperName) {
        return level;
      }
    }
    return null;
  }

  @override
  String toString() => name;
}
