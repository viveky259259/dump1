import 'log_level.dart';
import 'sensitive_data_redactor.dart';

/// Configuration for the logging system.
///
/// Controls log levels, retention policies, and redaction rules.
class LogConfig {
  /// Global default log level.
  final LogLevel globalLevel;

  /// Per-service log level overrides.
  ///
  /// Map of logger name to log level. If a logger name is in this map,
  /// it uses the specified level instead of [globalLevel].
  final Map<String, LogLevel> serviceLevels;

  /// Custom redaction rules for sensitive data.
  final List<RedactionRule> redactionRules;

  /// Number of days to retain log files.
  final int retentionDays;

  /// Maximum size of a single log file in MB before rotation.
  final int maxFileSizeMb;

  /// Maximum total size of all log files in MB.
  final int maxTotalSizeMb;

  /// Maximum age of log files in days.
  final int maxAgeDays;

  /// Whether to enable compression for old log files.
  final bool enableCompression;

  /// Whether to enable console logging in addition to file logging.
  final bool enableConsoleLogging;

  /// Whether to capture location information for WARN+ logs.
  final bool captureLocation;

  const LogConfig({
    this.globalLevel = LogLevel.info,
    this.serviceLevels = const {},
    this.redactionRules = const [],
    this.retentionDays = 30,
    this.maxFileSizeMb = 50,
    this.maxTotalSizeMb = 500,
    this.maxAgeDays = 30,
    this.enableCompression = true,
    this.enableConsoleLogging = true,
    this.captureLocation = true,
  });

  /// Create a default configuration with sensible defaults.
  factory LogConfig.defaultConfig() {
    return const LogConfig();
  }

  /// Create a debug configuration with verbose logging.
  factory LogConfig.debug() {
    return const LogConfig(
      globalLevel: LogLevel.debug,
      enableConsoleLogging: true,
    );
  }

  /// Create a production configuration with minimal logging.
  factory LogConfig.production() {
    return const LogConfig(
      globalLevel: LogLevel.info,
      enableConsoleLogging: false,
      captureLocation: false, // Skip location capture for performance
    );
  }

  /// Create a copy with modified fields.
  LogConfig copyWith({
    LogLevel? globalLevel,
    Map<String, LogLevel>? serviceLevels,
    List<RedactionRule>? redactionRules,
    int? retentionDays,
    int? maxFileSizeMb,
    int? maxTotalSizeMb,
    bool? enableConsoleLogging,
    bool? captureLocation,
  }) {
    return LogConfig(
      globalLevel: globalLevel ?? this.globalLevel,
      serviceLevels: serviceLevels ?? this.serviceLevels,
      redactionRules: redactionRules ?? this.redactionRules,
      retentionDays: retentionDays ?? this.retentionDays,
      maxFileSizeMb: maxFileSizeMb ?? this.maxFileSizeMb,
      maxTotalSizeMb: maxTotalSizeMb ?? this.maxTotalSizeMb,
      enableConsoleLogging: enableConsoleLogging ?? this.enableConsoleLogging,
      captureLocation: captureLocation ?? this.captureLocation,
    );
  }

  /// Convert to JSON for persistence.
  Map<String, dynamic> toJson() {
    return {
      'globalLevel': globalLevel.name,
      'serviceLevels': serviceLevels.map(
        (key, value) => MapEntry(key, value.name),
      ),
      'retentionDays': retentionDays,
      'maxFileSizeMb': maxFileSizeMb,
      'maxTotalSizeMb': maxTotalSizeMb,
      'enableConsoleLogging': enableConsoleLogging,
      'captureLocation': captureLocation,
      // Note: redactionRules are not persisted (use defaults)
    };
  }

  /// Create from JSON.
  factory LogConfig.fromJson(Map<String, dynamic> json) {
    return LogConfig(
      globalLevel:
          LogLevel.fromString(json['globalLevel'] as String? ?? 'INFO') ??
          LogLevel.info,
      serviceLevels:
          (json['serviceLevels'] as Map<String, dynamic>?)?.map(
            (key, value) => MapEntry(
              key,
              LogLevel.fromString(value as String) ?? LogLevel.info,
            ),
          ) ??
          {},
      retentionDays: json['retentionDays'] as int? ?? 30,
      maxFileSizeMb: json['maxFileSizeMb'] as int? ?? 50,
      maxTotalSizeMb: json['maxTotalSizeMb'] as int? ?? 500,
      enableConsoleLogging: json['enableConsoleLogging'] as bool? ?? true,
      captureLocation: json['captureLocation'] as bool? ?? true,
    );
  }

  @override
  String toString() {
    return 'LogConfig(globalLevel: $globalLevel, '
        'serviceLevels: ${serviceLevels.length}, '
        'retention: ${retentionDays}d, '
        'maxFileSize: ${maxFileSizeMb}MB, '
        'maxTotal: ${maxTotalSizeMb}MB)';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LogConfig &&
          runtimeType == other.runtimeType &&
          globalLevel == other.globalLevel &&
          retentionDays == other.retentionDays &&
          maxFileSizeMb == other.maxFileSizeMb &&
          maxTotalSizeMb == other.maxTotalSizeMb;

  @override
  int get hashCode =>
      Object.hash(globalLevel, retentionDays, maxFileSizeMb, maxTotalSizeMb);
}
