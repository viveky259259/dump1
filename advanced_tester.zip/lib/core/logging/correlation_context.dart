import 'dart:async';

import 'package:uuid/uuid.dart';

/// Manages correlation IDs for tracing operations across services.
///
/// Correlation IDs allow you to trace a user action or request as it flows
/// through multiple services, use cases, and layers. All operations related
/// to the same user action share the same correlation ID.
///
/// Usage:
/// ```dart
/// // Start a new operation with a new correlation ID
/// final correlationId = CorrelationContext.generate();
/// CorrelationContext.set(correlationId);
///
/// // Or use a wrapper that automatically manages context
/// final result = CorrelationContext.withCorrelation(
///   correlationId,
///   () => performOperation(),
/// );
///
/// // Get the current correlation ID (returns new ID if none set)
/// final currentId = CorrelationContext.current;
/// ```
class CorrelationContext {
  static final _uuid = Uuid();
  static final Map<int, String> _contextMap = {};

  /// Get the current correlation ID for this execution context.
  ///
  /// If no correlation ID has been set, generates and sets a new one.
  static String get current {
    final key = _getCurrentKey();
    return _contextMap[key] ?? _generate();
  }

  /// Generate a new correlation ID.
  ///
  /// Returns a UUID v4 string suitable for use as a correlation ID.
  static String generate() => _uuid.v4();

  /// Set the correlation ID for the current execution context.
  static void set(String id) {
    final key = _getCurrentKey();
    _contextMap[key] = id;
  }

  /// Clear the correlation ID for the current execution context.
  static void clear() {
    final key = _getCurrentKey();
    _contextMap.remove(key);
  }

  /// Execute a function within a specific correlation context.
  ///
  /// The correlation ID is set before executing [fn] and restored to its
  /// previous value (or cleared) afterwards, even if [fn] throws.
  ///
  /// Example:
  /// ```dart
  /// final result = CorrelationContext.withCorrelation(
  ///   'my-correlation-id',
  ///   () {
  ///     // All logs here will have correlationId='my-correlation-id'
  ///     return doWork();
  ///   },
  /// );
  /// ```
  static T withCorrelation<T>(String id, T Function() fn) {
    final key = _getCurrentKey();
    final previousId = _contextMap[key];

    try {
      set(id);
      return fn();
    } finally {
      if (previousId != null) {
        set(previousId);
      } else {
        clear();
      }
    }
  }

  /// Async version of [withCorrelation].
  ///
  /// Execute an async function within a specific correlation context.
  static Future<T> withCorrelationAsync<T>(
    String id,
    Future<T> Function() fn,
  ) async {
    final key = _getCurrentKey();
    final previousId = _contextMap[key];

    try {
      set(id);
      return await fn();
    } finally {
      if (previousId != null) {
        set(previousId);
      } else {
        clear();
      }
    }
  }

  /// Generate a new correlation ID and set it.
  static String _generate() {
    final id = generate();
    set(id);
    return id;
  }

  /// Get a key for the current execution context.
  ///
  /// In Dart, we use a simple approach of using the current zone's hash code
  /// as a key. This works for both sync and async contexts since async
  /// operations inherit their zone.
  static int _getCurrentKey() {
    // Use the current zone's hash code as a thread-local-like key
    // This allows different async contexts to have different correlation IDs
    return Zone.current.hashCode;
  }

  /// Clear all correlation contexts.
  ///
  /// This is primarily useful for testing to ensure a clean state.
  static void clearAll() {
    _contextMap.clear();
  }
}
