import 'log_config.dart';
import 'log_level.dart';
import 'log_writer.dart';
import 'logger.dart';

/// Factory and manager for Logger instances.
///
/// AppLogger is the main entry point for the logging system. It provides:
/// - Logger instance creation and caching
/// - Global configuration management
/// - System initialization and shutdown
/// - Per-logger level configuration
///
/// Usage:
/// ```dart
/// // Initialize logging system at app startup
/// await AppLogger.initialize();
///
/// // Get a logger for a class
/// final logger = AppLogger.getLogger('MyClass');
///
/// // Use the logger
/// logger.info('Application started');
///
/// // Shutdown at app exit
/// await AppLogger.shutdown();
/// ```
class AppLogger {
  static final Map<String, Logger> _loggers = {};
  static LogConfig _config = LogConfig.defaultConfig();
  static bool _initialized = false;

  /// Get or create a logger with the given name.
  ///
  /// If a logger with this name already exists, returns the cached instance.
  /// Otherwise, creates a new logger with the current configuration.
  ///
  /// The [name] is typically a class name or service name.
  static Logger getLogger(String name) {
    return _loggers.putIfAbsent(name, () => Logger(name, _config));
  }

  /// Initialize the logging system.
  ///
  /// Must be called before using any loggers. Optionally accepts a
  /// [config] to customize logging behavior.
  ///
  /// Example:
  /// ```dart
  /// await AppLogger.initialize(LogConfig(
  ///   globalLevel: LogLevel.debug,
  ///   retentionDays: 7,
  /// ));
  /// ```
  static Future<void> initialize([LogConfig? config]) async {
    if (_initialized) return;

    _config = config ?? LogConfig.defaultConfig();
    await LogWriter.instance.initialize(_config);
    _initialized = true;

    // Log that logging system started
    final logger = getLogger('AppLogger');
    logger.info('Logging system initialized', {
      'globalLevel': _config.globalLevel.name,
      'retentionDays': _config.retentionDays,
      'maxFileSizeMb': _config.maxFileSizeMb,
    });
  }

  /// Update the global logging configuration.
  ///
  /// This updates the configuration for all existing and future loggers.
  ///
  /// Example:
  /// ```dart
  /// AppLogger.configure(LogConfig(
  ///   globalLevel: LogLevel.warn,
  /// ));
  /// ```
  static void configure(LogConfig config) {
    _config = config;

    // Update all existing loggers
    for (final logger in _loggers.values) {
      logger.updateConfig(config);
    }

    // Update log writer config
    LogWriter.instance.updateConfig(config);

    final logger = getLogger('AppLogger');
    logger.info('Configuration updated', {
      'globalLevel': config.globalLevel.name,
    });
  }

  /// Set the log level for a specific logger.
  ///
  /// This overrides the global level for the specified logger only.
  ///
  /// Example:
  /// ```dart
  /// // Set InspectorService to debug level while keeping others at info
  /// AppLogger.setLevel('InspectorService', LogLevel.debug);
  /// ```
  static void setLevel(String loggerName, LogLevel level) {
    _config = _config.copyWith(
      serviceLevels: {..._config.serviceLevels, loggerName: level},
    );

    // Update the specific logger if it exists
    _loggers[loggerName]?.updateConfig(_config);

    final logger = getLogger('AppLogger');
    logger.debug('Level updated for $loggerName', {'level': level.name});
  }

  /// Shutdown the logging system.
  ///
  /// Flushes all pending logs and closes file handles.
  /// Should be called before application exit to ensure no logs are lost.
  static Future<void> shutdown() async {
    if (!_initialized) return;

    final logger = getLogger('AppLogger');
    logger.info('Shutting down logging system');

    await LogWriter.instance.shutdown();
    _loggers.clear();
    _initialized = false;
  }

  /// Check if the logging system is initialized.
  static bool get isInitialized => _initialized;

  /// Get the current configuration.
  static LogConfig get config => _config;

  /// Get all registered logger names.
  static List<String> get loggerNames => _loggers.keys.toList();

  /// Get the current log file path.
  static String? get currentLogFilePath =>
      LogWriter.instance.currentLogFilePath;

  /// Enable console logging (in addition to file logging).
  static void enableConsoleLogging() {
    configure(_config.copyWith(enableConsoleLogging: true));
  }

  /// Disable console logging (file logging only).
  static void disableConsoleLogging() {
    configure(_config.copyWith(enableConsoleLogging: false));
  }

  /// Flush logs to disk immediately.
  static Future<void> flush() async {
    await LogWriter.instance.flush();
  }
}
