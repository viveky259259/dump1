/// Represents the source code location where a log entry was created.
class LogLocation {
  /// The source file path.
  final String file;

  /// The line number in the source file.
  final int line;

  /// The function or method name.
  final String function;

  const LogLocation({
    required this.file,
    required this.line,
    required this.function,
  });

  /// Capture the current location from the stack trace.
  ///
  /// This attempts to extract the caller's location by parsing the stack trace.
  /// Returns a LogLocation with 'unknown' values if parsing fails.
  factory LogLocation.current() {
    try {
      final trace = StackTrace.current;
      final lines = trace.toString().split('\n');

      // Skip the first few frames which are inside the logging system
      // Typically we want frame 3 or 4 to get the actual caller
      if (lines.length > 3) {
        final frame = lines[3];
        return _parseFrame(frame);
      }

      return const LogLocation(file: 'unknown', line: 0, function: 'unknown');
    } catch (e) {
      return const LogLocation(file: 'unknown', line: 0, function: 'unknown');
    }
  }

  /// Parse a stack trace frame to extract location information.
  static LogLocation _parseFrame(String frame) {
    try {
      // Stack trace format varies by platform, but typically:
      // #3      ClassName.methodName (file:///path/to/file.dart:123:45)
      // or
      // #3      methodName (package:name/file.dart:123:45)

      final parenMatch = RegExp(r'\((.+):(\d+):(\d+)\)').firstMatch(frame);
      if (parenMatch != null) {
        final filePath = parenMatch.group(1) ?? 'unknown';
        final line = int.tryParse(parenMatch.group(2) ?? '0') ?? 0;

        // Extract function name (before the parenthesis)
        final functionMatch = RegExp(r'#\d+\s+(.+?)\s+\(').firstMatch(frame);
        final function = functionMatch?.group(1)?.trim() ?? 'unknown';

        // Clean up file path to show just the relevant part
        final cleanFile = _cleanFilePath(filePath);

        return LogLocation(file: cleanFile, line: line, function: function);
      }

      return const LogLocation(file: 'unknown', line: 0, function: 'unknown');
    } catch (e) {
      return const LogLocation(file: 'unknown', line: 0, function: 'unknown');
    }
  }

  /// Clean up file path to show only relevant parts.
  static String _cleanFilePath(String path) {
    // Remove file:/// prefix
    if (path.startsWith('file:///')) {
      path = path.substring(8);
    }

    // For package paths, keep package:name/path format
    if (path.startsWith('package:')) {
      return path;
    }

    // For absolute paths, try to show just lib/... or test/...
    final libIndex = path.indexOf('/lib/');
    if (libIndex != -1) {
      return path.substring(libIndex + 1); // Keep lib/...
    }

    final testIndex = path.indexOf('/test/');
    if (testIndex != -1) {
      return path.substring(testIndex + 1); // Keep test/...
    }

    // Otherwise, show the last few path components
    final parts = path.split('/');
    if (parts.length > 3) {
      return parts.sublist(parts.length - 3).join('/');
    }

    return path;
  }

  /// Convert to JSON for serialization.
  Map<String, dynamic> toJson() => {
    'file': file,
    'line': line,
    'function': function,
  };

  /// Create from JSON.
  factory LogLocation.fromJson(Map<String, dynamic> json) {
    return LogLocation(
      file: json['file'] as String? ?? 'unknown',
      line: json['line'] as int? ?? 0,
      function: json['function'] as String? ?? 'unknown',
    );
  }

  @override
  String toString() => '$file:$line ($function)';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LogLocation &&
          runtimeType == other.runtimeType &&
          file == other.file &&
          line == other.line &&
          function == other.function;

  @override
  int get hashCode => Object.hash(file, line, function);
}
