import 'correlation_context.dart';
import 'log_config.dart';
import 'log_entry.dart';
import 'log_level.dart';
import 'log_location.dart';
import 'log_writer.dart';
import 'sensitive_data_redactor.dart';

/// A logger instance for a specific class or service.
///
/// Provides methods for logging at different severity levels:
/// - [debug]: Detailed diagnostic information
/// - [info]: General informational messages
/// - [warn]: Warning messages
/// - [error]: Error messages with exception details
/// - [fatal]: Fatal errors that cause application failure
///
/// Loggers automatically include:
/// - Timestamps
/// - Correlation IDs for tracing
/// - Source location for warnings and errors
/// - Sensitive data redaction
///
/// Example usage:
/// ```dart
/// final logger = AppLogger.getLogger('MyClass');
///
/// logger.info('Processing started', {'itemCount': 42});
/// logger.error('Failed to process', exception, stackTrace);
/// ```
class Logger {
  /// The name of this logger (typically a class or service name).
  final String name;

  LogConfig _config;

  // Internal constructor (package-private)
  Logger(this.name, this._config);

  /// Log a debug message.
  ///
  /// Debug logs provide detailed diagnostic information useful during
  /// development. They are typically disabled in production.
  ///
  /// [message] is the human-readable log message.
  /// [context] is optional structured data providing additional information.
  void debug(String message, [Map<String, dynamic>? context]) {
    _log(LogLevel.debug, message, context);
  }

  /// Log an info message.
  ///
  /// Info logs provide general informational messages about application flow.
  ///
  /// [message] is the human-readable log message.
  /// [context] is optional structured data providing additional information.
  void info(String message, [Map<String, dynamic>? context]) {
    _log(LogLevel.info, message, context);
  }

  /// Log a warning message.
  ///
  /// Warning logs indicate potentially problematic situations that don't
  /// prevent the application from functioning but should be investigated.
  ///
  /// [message] is the human-readable log message.
  /// [context] is optional structured data providing additional information.
  void warn(String message, [Map<String, dynamic>? context]) {
    _log(LogLevel.warn, message, context);
  }

  /// Log an error with exception details.
  ///
  /// Error logs indicate error conditions that prevent an operation from
  /// completing but don't crash the application.
  ///
  /// [message] is the human-readable log message.
  /// [error] is the exception or error object.
  /// [stackTrace] is the stack trace (optional but recommended).
  /// [context] is optional structured data providing additional information.
  void error(
    String message,
    Object error, [
    StackTrace? stackTrace,
    Map<String, dynamic>? context,
  ]) {
    final entry = LogEntry(
      timestamp: DateTime.now(),
      level: LogLevel.error,
      loggerName: name,
      message: message,
      context: _redactSensitive(context ?? {}),
      correlationId: CorrelationContext.current,
      location: _config.captureLocation ? LogLocation.current() : null,
      error: error,
      stackTrace: stackTrace,
    );

    _write(entry, flushImmediately: true);
  }

  /// Log a fatal error.
  ///
  /// Fatal logs indicate unrecoverable errors that cause application failure.
  ///
  /// [message] is the human-readable log message.
  /// [error] is the exception or error object.
  /// [stackTrace] is the stack trace (optional but recommended).
  /// [context] is optional structured data providing additional information.
  void fatal(
    String message,
    Object error, [
    StackTrace? stackTrace,
    Map<String, dynamic>? context,
  ]) {
    final entry = LogEntry(
      timestamp: DateTime.now(),
      level: LogLevel.fatal,
      loggerName: name,
      message: message,
      context: _redactSensitive(context ?? {}),
      correlationId: CorrelationContext.current,
      location: _config.captureLocation ? LogLocation.current() : null,
      error: error,
      stackTrace: stackTrace,
    );

    _write(entry, flushImmediately: true);
  }

  /// Time an async operation and log entry, exit, and duration.
  ///
  /// Automatically logs:
  /// - Entry: When the operation starts
  /// - Exit: When the operation completes (with duration)
  /// - Error: If the operation throws (with duration and stack trace)
  ///
  /// Example:
  /// ```dart
  /// final result = await logger.timeAsync('fetchData', () async {
  ///   return await fetchDataFromApi();
  /// });
  /// ```
  Future<T> timeAsync<T>(
    String operation,
    Future<T> Function() fn, [
    Map<String, dynamic>? context,
  ]) async {
    final stopwatch = Stopwatch()..start();
    debug('Starting: $operation', context);

    try {
      final result = await fn();
      stopwatch.stop();

      info('Completed: $operation', {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      return result;
    } catch (e, stackTrace) {
      stopwatch.stop();

      error('Failed: $operation', e, stackTrace, {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      rethrow;
    }
  }

  /// Time a synchronous operation and log entry, exit, and duration.
  ///
  /// Similar to [timeAsync] but for synchronous operations.
  T time<T>(
    String operation,
    T Function() fn, [
    Map<String, dynamic>? context,
  ]) {
    final stopwatch = Stopwatch()..start();
    debug('Starting: $operation', context);

    try {
      final result = fn();
      stopwatch.stop();

      info('Completed: $operation', {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      return result;
    } catch (e, stackTrace) {
      stopwatch.stop();

      error('Failed: $operation', e, stackTrace, {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      rethrow;
    }
  }

  /// Internal method to log at a specific level.
  void _log(LogLevel level, String message, [Map<String, dynamic>? context]) {
    // Check if this level should be logged
    if (!_shouldLog(level)) return;

    final entry = LogEntry(
      timestamp: DateTime.now(),
      level: level,
      loggerName: name,
      message: message,
      context: _redactSensitive(context ?? {}),
      correlationId: CorrelationContext.current,
      // Only capture location for WARN and above (performance optimization)
      location: (level >= LogLevel.warn && _config.captureLocation)
          ? LogLocation.current()
          : null,
    );

    _write(entry);
  }

  /// Check if a log level should be logged based on configuration.
  bool _shouldLog(LogLevel level) {
    // Check if there's a service-specific level override
    final serviceLevel = _config.serviceLevels[name];
    final effectiveLevel = serviceLevel ?? _config.globalLevel;

    return level >= effectiveLevel;
  }

  /// Redact sensitive data from context.
  Map<String, dynamic> _redactSensitive(Map<String, dynamic> context) {
    return SensitiveDataRedactor.redact(context, _config.redactionRules);
  }

  /// Write a log entry to the log writer.
  void _write(LogEntry entry, {bool flushImmediately = false}) {
    LogWriter.instance.write(entry, flushImmediately: flushImmediately);

    // Also write to console if enabled
    if (_config.enableConsoleLogging) {
      _writeToConsole(entry);
    }
  }

  /// Write a log entry to console for development.
  void _writeToConsole(LogEntry entry) {
    // Use colored output for different log levels
    const reset = '\x1B[0m';
    const blue = '\x1B[34m'; // DEBUG
    const green = '\x1B[32m'; // INFO
    const yellow = '\x1B[33m'; // WARN
    const red = '\x1B[31m'; // ERROR
    const magenta = '\x1B[35m'; // FATAL

    final color = switch (entry.level) {
      LogLevel.debug => blue,
      LogLevel.info => green,
      LogLevel.warn => yellow,
      LogLevel.error => red,
      LogLevel.fatal => magenta,
    };

    // Build console message
    final buffer = StringBuffer();
    buffer.write('$color[${entry.level.name}]$reset ');
    buffer.write('${entry.loggerName}: ');
    buffer.write(entry.message);

    if (entry.correlationId != null) {
      buffer.write(' [cid=${entry.correlationId}]');
    }

    if (entry.duration != null) {
      buffer.write(' (${entry.duration!.inMilliseconds}ms)');
    }

    // ignore: avoid_print
    print(buffer.toString());

    if (entry.context.isNotEmpty) {
      // ignore: avoid_print
      print('  Context: ${entry.context}');
    }

    if (entry.error != null) {
      // ignore: avoid_print
      print('  Error: ${entry.error}');

      if (entry.stackTrace != null) {
        // ignore: avoid_print
        print('  Stack trace:\n${entry.stackTrace}');
      }
    }
  }

  /// Update this logger's configuration (internal use).
  void updateConfig(LogConfig config) {
    _config = config;
  }
}
