import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:synchronized/synchronized.dart';
import 'package:intl/intl.dart';

import 'log_config.dart';
import 'log_entry.dart';

/// Handles writing log entries to local files with rotation and cleanup.
///
/// LogWriter is a singleton that manages:
/// - Writing log entries to disk as JSONL (JSON Lines) format
/// - Buffering writes for performance
/// - Periodic flushing (every 5 seconds)
/// - Immediate flushing for ERROR/FATAL logs
/// - File rotation when size limit reached
/// - Cleanup of old log files
/// - Proper shutdown and resource cleanup
class LogWriter {
  static final LogWriter instance = LogWriter._();

  LogWriter._();

  final List<LogEntry> _buffer = [];
  Timer? _flushTimer;
  File? _currentFile;
  IOSink? _sink;
  final _writeLock = Lock();
  LogConfig _config = LogConfig.defaultConfig();
  bool _initialized = false;

  /// Initialize the log writer.
  ///
  /// Creates the logs directory and opens the current log file.
  /// Must be called before writing any logs.
  Future<void> initialize([LogConfig? config]) async {
    if (_initialized) return;

    _config = config ?? LogConfig.defaultConfig();

    try {
      final logsDir = await _getLogsDirectory();
      _currentFile = File(
        '${logsDir.path}/advanced_tester_${_timestamp()}.log',
      );

      // Create parent directories if they don't exist
      await _currentFile!.parent.create(recursive: true);

      _sink = _currentFile!.openWrite(mode: FileMode.append);

      // Start periodic flush timer
      _flushTimer = Timer.periodic(const Duration(seconds: 5), (_) => flush());

      _initialized = true;

      // Trigger initial cleanup
      unawaited(_cleanupOldLogs());
    } catch (e) {
      // If initialization fails, we can't log it, but we print to console
      // ignore: avoid_print
      print('Failed to initialize LogWriter: $e');
    }
  }

  /// Write a log entry to the buffer.
  ///
  /// The entry is buffered and will be written to disk:
  /// - Every 5 seconds (periodic flush)
  /// - Immediately if [flushImmediately] is true (e.g., for errors)
  /// - When buffer reaches 100 entries
  void write(LogEntry entry, {bool flushImmediately = false}) {
    if (!_initialized) {
      // If not initialized, try to initialize synchronously
      // This shouldn't normally happen, but provides a fallback
      initialize();
    }

    _buffer.add(entry);

    if (flushImmediately || _buffer.length >= 100) {
      flush();
    }
  }

  /// Flush buffered log entries to disk.
  ///
  /// Writes all buffered entries to the current log file and rotates
  /// if necessary. This operation is synchronized to prevent concurrent writes.
  Future<void> flush() async {
    if (_buffer.isEmpty || !_initialized) return;

    await _writeLock.synchronized(() async {
      try {
        final entries = List<LogEntry>.from(_buffer);
        _buffer.clear();

        for (final entry in entries) {
          final json = jsonEncode(entry.toJson());
          _sink?.writeln(json);
        }

        await _sink?.flush();

        // Check if rotation is needed
        await _rotateIfNeeded();
      } catch (e) {
        // If write fails, put entries back in buffer to retry
        _buffer.insertAll(0, _buffer);
        // ignore: avoid_print
        print('Failed to flush logs: $e');
      }
    });
  }

  /// Rotate the log file if it exceeds the size limit.
  Future<void> _rotateIfNeeded() async {
    if (_currentFile == null) return;

    try {
      final fileSize = await _currentFile!.length();
      final maxSize =
          _config.maxFileSizeMb * 1024 * 1024; // Convert MB to bytes

      if (fileSize >= maxSize) {
        // Close current file
        await _sink?.close();

        // Create new file
        final logsDir = await _getLogsDirectory();
        _currentFile = File(
          '${logsDir.path}/advanced_tester_${_timestamp()}.log',
        );
        _sink = _currentFile!.openWrite(mode: FileMode.append);

        // Trigger cleanup of old logs
        unawaited(_cleanupOldLogs());
      }
    } catch (e) {
      // ignore: avoid_print
      print('Failed to rotate log file: $e');
    }
  }

  /// Clean up old log files based on retention policy.
  ///
  /// Removes logs older than [retentionDays] and ensures total size
  /// doesn't exceed [maxTotalSizeMb].
  Future<void> _cleanupOldLogs() async {
    try {
      final logsDir = await _getLogsDirectory();

      if (!await logsDir.exists()) return;

      final logFiles = logsDir
          .listSync()
          .whereType<File>()
          .where((f) => f.path.endsWith('.log') || f.path.endsWith('.log.gz'))
          .toList();

      if (logFiles.isEmpty) return;

      // Sort by modification time (oldest first)
      logFiles.sort((a, b) {
        final aStat = a.statSync();
        final bStat = b.statSync();
        return aStat.modified.compareTo(bStat.modified);
      });

      // Delete files older than retention period
      final cutoffDate = DateTime.now().subtract(
        Duration(days: _config.retentionDays),
      );

      for (final file in List<File>.from(logFiles)) {
        final stat = file.statSync();
        if (stat.modified.isBefore(cutoffDate)) {
          await file.delete();
          logFiles.remove(file);
        }
      }

      // Calculate total size and delete oldest files if over limit
      var totalSize = logFiles.fold<int>(
        0,
        (sum, file) => sum + file.lengthSync(),
      );

      final maxTotalSize =
          _config.maxTotalSizeMb * 1024 * 1024; // Convert MB to bytes

      while (totalSize > maxTotalSize && logFiles.isNotEmpty) {
        final oldest = logFiles.removeAt(0);
        final size = oldest.lengthSync();
        await oldest.delete();
        totalSize -= size;
      }

      // Compress old log files (optional - files older than 1 day)
      final compressionCutoff = DateTime.now().subtract(
        const Duration(days: 1),
      );
      for (final file in logFiles) {
        if (file.path.endsWith('.log')) {
          final stat = file.statSync();
          if (stat.modified.isBefore(compressionCutoff)) {
            await _compressLogFile(file);
          }
        }
      }
    } catch (e) {
      // ignore: avoid_print
      print('Failed to cleanup old logs: $e');
    }
  }

  /// Compress a log file using gzip.
  Future<void> _compressLogFile(File file) async {
    try {
      // Read the log file
      final content = await file.readAsBytes();

      // Compress using gzip
      final compressed = gzip.encode(content);

      // Write compressed file
      final compressedFile = File('${file.path}.gz');
      await compressedFile.writeAsBytes(compressed);

      // Delete original file
      await file.delete();
    } catch (e) {
      // If compression fails, just leave the file as is
      // ignore: avoid_print
      print('Failed to compress log file: $e');
    }
  }

  /// Get the logs directory path.
  ///
  /// Returns ~/.advanced_tester/logs/ directory, creating it if needed.
  Future<Directory> _getLogsDirectory() async {
    // Get home directory based on platform
    final home =
        Platform.environment['HOME'] ??
        Platform.environment['USERPROFILE'] ??
        '.';

    final logsDir = Directory('$home/.advanced_tester/logs');

    if (!await logsDir.exists()) {
      await logsDir.create(recursive: true);
    }

    return logsDir;
  }

  /// Generate a timestamp string for log file names.
  ///
  /// Format: YYYY-MM-DD_HH-MM-SS
  String _timestamp() {
    final now = DateTime.now();
    final formatter = DateFormat('yyyy-MM-dd_HH-mm-ss');
    return formatter.format(now);
  }

  /// Update configuration.
  ///
  /// This allows runtime configuration changes.
  void updateConfig(LogConfig config) {
    _config = config;
  }

  /// Shutdown the log writer.
  ///
  /// Flushes any remaining buffered logs and closes file handles.
  /// Should be called before application exit.
  Future<void> shutdown() async {
    _flushTimer?.cancel();
    await flush();
    await _sink?.close();
    _sink = null;
    _currentFile = null;
    _initialized = false;
  }

  /// Get the path to the current log file.
  ///
  /// Returns null if not initialized.
  String? get currentLogFilePath => _currentFile?.path;

  /// Check if the writer is initialized.
  bool get isInitialized => _initialized;

  /// Get list of all log files.
  Future<List<File>> getLogFiles() async {
    try {
      final logsDir = await _getLogsDirectory();

      if (!await logsDir.exists()) return [];

      return logsDir
          .listSync()
          .whereType<File>()
          .where((f) => f.path.endsWith('.log') || f.path.endsWith('.log.gz'))
          .toList();
    } catch (e) {
      return [];
    }
  }

  /// Read recent log entries from files.
  ///
  /// Returns up to [maxEntries] most recent log entries.
  Future<List<LogEntry>> readRecentLogs({int maxEntries = 1000}) async {
    try {
      final logFiles = await getLogFiles();

      // Sort by modification time (newest first)
      logFiles.sort((a, b) {
        final aStat = a.statSync();
        final bStat = b.statSync();
        return bStat.modified.compareTo(aStat.modified);
      });

      final entries = <LogEntry>[];

      for (final file in logFiles) {
        if (entries.length >= maxEntries) break;

        // Only read uncompressed log files for now
        if (!file.path.endsWith('.log')) continue;

        try {
          final lines = await file.readAsLines();

          // Read lines in reverse (newest first)
          for (var i = lines.length - 1; i >= 0; i--) {
            if (entries.length >= maxEntries) break;

            final line = lines[i].trim();
            if (line.isEmpty) continue;

            try {
              final json = jsonDecode(line) as Map<String, dynamic>;
              entries.add(LogEntry.fromJson(json));
            } catch (e) {
              // Skip malformed log lines
              continue;
            }
          }
        } catch (e) {
          // Skip files that can't be read
          continue;
        }
      }

      return entries;
    } catch (e) {
      return [];
    }
  }
}
