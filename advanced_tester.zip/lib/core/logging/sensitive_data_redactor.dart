/// Automatically redacts sensitive data from log context.
///
/// This class provides automatic redaction of sensitive information like
/// passwords, API tokens, and credentials from log context data to prevent
/// accidental exposure of sensitive information in log files.
class SensitiveDataRedactor {
  /// Default sensitive key patterns that should always be redacted.
  static final Set<String> _defaultSensitiveKeys = {
    'password',
    'passwd',
    'pwd',
    'token',
    'apikey',
    'api_key',
    'secret',
    'accesstoken',
    'access_token',
    'refreshtoken',
    'refresh_token',
    'credential',
    'credentials',
    'auth',
    'authorization',
    'bearer',
    'key',
    'private',
    'privatekey',
    'private_key',
  };

  /// Redact sensitive data from a context map.
  ///
  /// Recursively redacts values for keys that match sensitive patterns.
  /// Custom redaction rules can be provided via [rules].
  ///
  /// Example:
  /// ```dart
  /// final context = {
  ///   'username': 'john',
  ///   'password': 'secret123',  // Will be redacted
  ///   'data': {
  ///     'apiKey': 'xyz',        // Will be redacted
  ///   }
  /// };
  ///
  /// final redacted = SensitiveDataRedactor.redact(context);
  /// // Result:
  /// // {
  /// //   'username': 'john',
  /// //   'password': '***REDACTED***',
  /// //   'data': {'apiKey': '***REDACTED***'}
  /// // }
  /// ```
  static Map<String, dynamic> redact(
    Map<String, dynamic> data, [
    List<RedactionRule>? rules,
  ]) {
    final redacted = <String, dynamic>{};

    for (final entry in data.entries) {
      if (_shouldRedact(entry.key, rules)) {
        redacted[entry.key] = '***REDACTED***';
      } else if (entry.value is Map) {
        // Recursively redact nested maps
        redacted[entry.key] = redact(
          Map<String, dynamic>.from(entry.value as Map),
          rules,
        );
      } else if (entry.value is List) {
        // Redact items in lists
        redacted[entry.key] = _redactList(entry.value as List, rules);
      } else {
        redacted[entry.key] = entry.value;
      }
    }

    return redacted;
  }

  /// Redact items in a list.
  static List<dynamic> _redactList(
    List<dynamic> list, [
    List<RedactionRule>? rules,
  ]) {
    return list.map((item) {
      if (item is Map) {
        return redact(Map<String, dynamic>.from(item), rules);
      } else if (item is List) {
        return _redactList(item, rules);
      }
      return item;
    }).toList();
  }

  /// Check if a key should be redacted.
  static bool _shouldRedact(String key, List<RedactionRule>? rules) {
    final lowerKey = key.toLowerCase();

    // Check default sensitive keys
    if (_defaultSensitiveKeys.contains(lowerKey)) {
      return true;
    }

    // Check custom rules
    if (rules != null) {
      for (final rule in rules) {
        if (rule.matches(key)) {
          return true;
        }
      }
    }

    return false;
  }

  /// Anonymize a file path by removing user-specific information.
  ///
  /// Replaces user home directory with ~ and removes absolute paths
  /// to prevent exposing system-specific information.
  static String anonymizePath(String path) {
    // Replace common user directories
    final homePatterns = [
      RegExp(r'/Users/[^/]+'),
      RegExp(r'/home/[^/]+'),
      RegExp(r'C:\\Users\\[^\\]+'),
    ];

    var anonymized = path;
    for (final pattern in homePatterns) {
      anonymized = anonymized.replaceAll(pattern, '~');
    }

    return anonymized;
  }
}

/// A rule for redacting specific fields.
///
/// Provides custom pattern matching for field names that should be redacted.
class RedactionRule {
  /// The pattern to match against field names.
  final RegExp pattern;

  /// Optional description of what this rule redacts.
  final String? description;

  const RedactionRule(this.pattern, {this.description});

  /// Check if this rule matches the given field name.
  bool matches(String fieldName) => pattern.hasMatch(fieldName);

  /// Create a rule that redacts fields containing a specific substring.
  factory RedactionRule.contains(String substring, {String? description}) {
    return RedactionRule(
      RegExp(substring, caseSensitive: false),
      description: description,
    );
  }

  /// Create a rule that redacts fields matching an exact name.
  factory RedactionRule.exact(String name, {String? description}) {
    return RedactionRule(
      RegExp('^$name\$', caseSensitive: false),
      description: description,
    );
  }

  /// Create a rule that redacts fields starting with a prefix.
  factory RedactionRule.startsWith(String prefix, {String? description}) {
    return RedactionRule(
      RegExp('^$prefix', caseSensitive: false),
      description: description,
    );
  }

  /// Create a rule that redacts fields ending with a suffix.
  factory RedactionRule.endsWith(String suffix, {String? description}) {
    return RedactionRule(
      RegExp('$suffix\$', caseSensitive: false),
      description: description,
    );
  }
}
