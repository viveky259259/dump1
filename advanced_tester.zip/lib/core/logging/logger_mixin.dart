import 'app_logger.dart';
import 'logger.dart';

/// Mixin to easily add logging capability to any class.
///
/// This mixin provides:
/// - Automatic logger instance based on class name
/// - Helper methods for logging operations with timing
/// - Consistent logging patterns across the codebase
///
/// Usage:
/// ```dart
/// class MyService with LoggerMixin {
///   Future<Result> fetchData() async {
///     return await logAsyncOperation(
///       'fetchData',
///       () async {
///         logger.info('Fetching data from API');
///         final data = await api.get();
///         logger.info('Data fetched successfully', {'count': data.length});
///         return data;
///       },
///     );
///   }
/// }
/// ```
mixin LoggerMixin {
  /// The logger instance for this class.
  ///
  /// Automatically named after the class using runtimeType.
  Logger get logger => _logger;

  late final Logger _logger = AppLogger.getLogger(runtimeType.toString());

  /// Log a synchronous operation with automatic timing and error handling.
  ///
  /// Logs:
  /// - Entry: When operation starts (DEBUG level)
  /// - Exit: When operation completes successfully (INFO level with duration)
  /// - Error: If operation throws (ERROR level with duration and stack trace)
  ///
  /// Example:
  /// ```dart
  /// final result = logOperation('processData', () {
  ///   // Your code here
  ///   return processData(input);
  /// }, context: {'inputSize': input.length});
  /// ```
  T logOperation<T>(
    String operation,
    T Function() fn, {
    Map<String, dynamic>? context,
  }) {
    final stopwatch = Stopwatch()..start();
    logger.debug('Starting: $operation', context);

    try {
      final result = fn();
      stopwatch.stop();

      logger.info('Completed: $operation', {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      return result;
    } catch (e, stackTrace) {
      stopwatch.stop();

      logger.error('Failed: $operation', e, stackTrace, {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      rethrow;
    }
  }

  /// Log an asynchronous operation with automatic timing and error handling.
  ///
  /// Similar to [logOperation] but for async operations. Automatically logs
  /// entry, exit with timing, and any errors that occur.
  ///
  /// Example:
  /// ```dart
  /// final result = await logAsyncOperation('fetchFromAPI', () async {
  ///   return await api.fetch();
  /// }, context: {'endpoint': '/users'});
  /// ```
  Future<T> logAsyncOperation<T>(
    String operation,
    Future<T> Function() fn, {
    Map<String, dynamic>? context,
  }) async {
    final stopwatch = Stopwatch()..start();
    logger.debug('Starting: $operation', context);

    try {
      final result = await fn();
      stopwatch.stop();

      logger.info('Completed: $operation', {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      return result;
    } catch (e, stackTrace) {
      stopwatch.stop();

      logger.error('Failed: $operation', e, stackTrace, {
        ...?context,
        'durationMs': stopwatch.elapsedMilliseconds,
      });

      rethrow;
    }
  }

  /// Log entry into a method.
  ///
  /// Useful for logging method entry without automatic timing.
  void logEntry(String method, [Map<String, dynamic>? context]) {
    logger.debug('→ $method', context);
  }

  /// Log exit from a method.
  ///
  /// Useful for logging method exit without automatic timing.
  void logExit(String method, [Map<String, dynamic>? context]) {
    logger.debug('← $method', context);
  }

  /// Log a state change.
  ///
  /// Useful for logging state transitions in state management.
  void logStateChange(
    String stateName,
    dynamic oldValue,
    dynamic newValue, [
    Map<String, dynamic>? context,
  ]) {
    logger.debug('State change: $stateName', {
      ...?context,
      'oldValue': oldValue?.toString(),
      'newValue': newValue?.toString(),
    });
  }
}
