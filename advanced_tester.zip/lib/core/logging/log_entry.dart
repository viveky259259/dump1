import 'log_level.dart';
import 'log_location.dart';

/// Represents a single log entry with all metadata.
///
/// Each log entry contains:
/// - Timestamp of when the log was created
/// - Log level (DEBUG, INFO, WARN, ERROR, FATAL)
/// - Logger name (typically class or service name)
/// - Human-readable message
/// - Optional structured context data
/// - Optional correlation ID for tracing related operations
/// - Optional location information (file, line, function)
/// - Optional performance data (duration, memory usage)
/// - Optional error and stack trace information
class LogEntry {
  /// When this log entry was created.
  final DateTime timestamp;

  /// The severity level of this log entry.
  final LogLevel level;

  /// The name of the logger that created this entry.
  final String loggerName;

  /// The main log message.
  final String message;

  /// Additional structured context data.
  final Map<String, dynamic> context;

  /// Correlation ID for tracing related operations across services.
  final String? correlationId;

  /// Source code location where this log was created.
  final LogLocation? location;

  /// Duration of the operation being logged (if applicable).
  final Duration? duration;

  /// Memory delta for this operation in bytes (if applicable).
  final int? memoryDelta;

  /// Error object (if this is an error log).
  final Object? error;

  /// Stack trace (if this is an error log).
  final StackTrace? stackTrace;

  const LogEntry({
    required this.timestamp,
    required this.level,
    required this.loggerName,
    required this.message,
    this.context = const {},
    this.correlationId,
    this.location,
    this.duration,
    this.memoryDelta,
    this.error,
    this.stackTrace,
  });

  /// Convert to JSON for file serialization (JSONL format).
  ///
  /// Produces a compact JSON object suitable for writing as a single line.
  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{
      'timestamp': timestamp.toIso8601String(),
      'level': level.name,
      'logger': loggerName,
      'message': message,
    };

    if (context.isNotEmpty) {
      json['context'] = context;
    }

    if (correlationId != null) {
      json['correlationId'] = correlationId;
    }

    if (location != null) {
      json['location'] = location!.toJson();
    }

    if (duration != null) {
      json['durationMs'] = duration!.inMilliseconds;
    }

    if (memoryDelta != null) {
      json['memoryBytes'] = memoryDelta;
    }

    if (error != null) {
      json['error'] = error.toString();
    }

    if (stackTrace != null) {
      json['stackTrace'] = stackTrace.toString();
    }

    return json;
  }

  /// Create from JSON (for reading log files).
  factory LogEntry.fromJson(Map<String, dynamic> json) {
    return LogEntry(
      timestamp: DateTime.parse(json['timestamp'] as String),
      level: LogLevel.fromString(json['level'] as String) ?? LogLevel.info,
      loggerName: json['logger'] as String,
      message: json['message'] as String,
      context: json['context'] as Map<String, dynamic>? ?? {},
      correlationId: json['correlationId'] as String?,
      location: json['location'] != null
          ? LogLocation.fromJson(json['location'] as Map<String, dynamic>)
          : null,
      duration: json['durationMs'] != null
          ? Duration(milliseconds: json['durationMs'] as int)
          : null,
      memoryDelta: json['memoryBytes'] as int?,
      error: json['error'] as String?,
      // Stack trace is stored as string, we don't reconstruct the object
    );
  }

  /// Create a copy with modified fields.
  LogEntry copyWith({
    DateTime? timestamp,
    LogLevel? level,
    String? loggerName,
    String? message,
    Map<String, dynamic>? context,
    String? correlationId,
    LogLocation? location,
    Duration? duration,
    int? memoryDelta,
    Object? error,
    StackTrace? stackTrace,
  }) {
    return LogEntry(
      timestamp: timestamp ?? this.timestamp,
      level: level ?? this.level,
      loggerName: loggerName ?? this.loggerName,
      message: message ?? this.message,
      context: context ?? this.context,
      correlationId: correlationId ?? this.correlationId,
      location: location ?? this.location,
      duration: duration ?? this.duration,
      memoryDelta: memoryDelta ?? this.memoryDelta,
      error: error ?? this.error,
      stackTrace: stackTrace ?? this.stackTrace,
    );
  }

  @override
  String toString() {
    final buffer = StringBuffer();
    buffer.write('${timestamp.toIso8601String()} ');
    buffer.write('[${level.name}] ');
    buffer.write('$loggerName: ');
    buffer.write(message);

    if (correlationId != null) {
      buffer.write(' [cid=$correlationId]');
    }

    if (duration != null) {
      buffer.write(' (${duration!.inMilliseconds}ms)');
    }

    if (error != null) {
      buffer.write('\n  Error: $error');
    }

    if (context.isNotEmpty) {
      buffer.write('\n  Context: $context');
    }

    return buffer.toString();
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LogEntry &&
          runtimeType == other.runtimeType &&
          timestamp == other.timestamp &&
          level == other.level &&
          loggerName == other.loggerName &&
          message == other.message;

  @override
  int get hashCode => Object.hash(timestamp, level, loggerName, message);
}
