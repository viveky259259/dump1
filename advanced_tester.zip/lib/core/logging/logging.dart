/// Comprehensive logging system for Advanced Tester.
///
/// This library provides structured logging with:
/// - Multiple log levels (DEBUG, INFO, WARN, ERROR, FATAL)
/// - Local file storage with automatic rotation
/// - Correlation IDs for tracing operations
/// - Automatic sensitive data redaction
/// - Performance tracking
/// - Easy integration via mixin
///
/// ## Quick Start
///
/// Initialize at app startup:
/// ```dart
/// await AppLogger.initialize();
/// ```
///
/// Use in any class:
/// ```dart
/// class MyService with LoggerMixin {
///   Future<void> doWork() async {
///     logger.info('Starting work');
///     // ... do work
///     logger.info('Work completed');
///   }
/// }
/// ```
///
/// Or get a logger explicitly:
/// ```dart
/// final logger = AppLogger.getLogger('MyClass');
/// logger.info('Hello from MyClass');
/// ```
library logging;

export 'app_logger.dart';
export 'correlation_context.dart';
export 'log_config.dart';
export 'log_entry.dart';
export 'log_level.dart';
export 'log_location.dart';
export 'log_writer.dart';
export 'logger.dart';
export 'logger_mixin.dart';
export 'sensitive_data_redactor.dart';
