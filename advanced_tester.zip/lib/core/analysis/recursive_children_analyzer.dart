import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../services/inspector_service.dart';
import '../../services/dependency_analysis_service.dart';
import '../../services/enhanced_dependency_analysis_service.dart';
import '../config/environment_config.dart';

/// Configuration for recursive children analysis
class RecursiveAnalysisConfig {
  final int maxDepth;
  final int maxChildrenPerLevel;
  final bool enableCaching;
  final bool includeAllProperties;
  final bool includeDependencies;
  final bool includeSourceContext;
  final bool includeAccessibility;
  final Set<String> skipWidgetTypes;
  final Set<String> priorityWidgetTypes;
  final Duration cacheExpiry;

  const RecursiveAnalysisConfig({
    this.maxDepth = 5,
    this.maxChildrenPerLevel = 10,
    this.enableCaching = true,
    this.includeAllProperties = true,
    this.includeDependencies = true,
    this.includeSourceContext = false,
    this.includeAccessibility = true,
    this.skipWidgetTypes = const {
      'Padding',
      'Container',
      'SizedBox',
      'Divider',
      'Spacer',
      'SizedBox.shrink',
    },
    this.priorityWidgetTypes = const {
      'Scaffold',
      'AppBar',
      'ListView',
      'GridView',
      'Form',
      'TextField',
      'Button',
      'Card',
      'Material',
    },
    this.cacheExpiry = const Duration(minutes: 5),
  });

  /// Create from environment configuration
  factory RecursiveAnalysisConfig.fromEnvironment(EnvironmentConfig envConfig) {
    return RecursiveAnalysisConfig(
      maxDepth: envConfig.recursiveAnalysisMaxDepth ?? 5,
      maxChildrenPerLevel: envConfig.recursiveAnalysisMaxChildren ?? 10,
      enableCaching: envConfig.recursiveAnalysisEnableCaching ?? true,
      includeAllProperties:
          envConfig.recursiveAnalysisIncludeProperties ?? true,
      includeDependencies:
          envConfig.recursiveAnalysisIncludeDependencies ?? true,
      includeSourceContext:
          envConfig.recursiveAnalysisIncludeSourceContext ?? false,
      includeAccessibility:
          envConfig.recursiveAnalysisIncludeAccessibility ?? true,
      skipWidgetTypes:
          envConfig.recursiveAnalysisSkipWidgets ??
          const {'Padding', 'Container', 'SizedBox', 'Divider', 'Spacer'},
      priorityWidgetTypes:
          envConfig.recursiveAnalysisPriorityWidgets ??
          const {
            'Scaffold',
            'AppBar',
            'ListView',
            'GridView',
            'Form',
            'TextField',
          },
    );
  }
}

/// Widget importance levels for analysis prioritization
enum WidgetImportance { low, medium, high, critical }

/// Analysis context for understanding widget relationships
class AnalysisContext {
  final String? parentType;
  final List<String> ancestorTypes;
  final Map<String, dynamic> parentProperties;
  final String? layoutDirection;
  final bool isInScrollable;
  final bool isInForm;
  final bool isInMaterial;
  final String? packageName;
  final String? projectPath;

  const AnalysisContext({
    this.parentType,
    this.ancestorTypes = const [],
    this.parentProperties = const {},
    this.layoutDirection,
    this.isInScrollable = false,
    this.isInForm = false,
    this.isInMaterial = false,
    this.packageName,
    this.projectPath,
  });

  AnalysisContext withChild(
    WidgetTreeNode child, {
    String? packageName,
    String? projectPath,
  }) {
    return AnalysisContext(
      parentType: child.widgetRuntimeType,
      ancestorTypes: [...ancestorTypes, parentType ?? ''],
      parentProperties: _extractProperties(child),
      layoutDirection: _determineLayoutDirection(child),
      isInScrollable: isInScrollable || _isScrollable(child),
      isInForm: isInForm || _isForm(child),
      isInMaterial: isInMaterial || _isMaterial(child),
      packageName: packageName ?? this.packageName,
      projectPath: projectPath ?? this.projectPath,
    );
  }

  Map<String, dynamic> _extractProperties(WidgetTreeNode node) {
    final properties = <String, dynamic>{};
    if (node.attributes != null) {
      for (final attr in node.attributes!) {
        properties[attr.name] = attr.label;
      }
    }
    return properties;
  }

  String? _determineLayoutDirection(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';
    if (type.contains('row')) return 'horizontal';
    if (type.contains('column')) return 'vertical';
    if (type.contains('flex')) return 'flexible';
    return null;
  }

  bool _isScrollable(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';
    return type.contains('scroll') ||
        type.contains('list') ||
        type.contains('grid') ||
        type.contains('pageview');
  }

  bool _isForm(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';
    return type.contains('form') ||
        type.contains('field') ||
        type.contains('input');
  }

  bool _isMaterial(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';
    return type.contains('material') ||
        type.contains('scaffold') ||
        type.contains('appbar');
  }
}

/// Cached analysis result
class CachedAnalysis {
  final Map<String, dynamic> data;
  final DateTime timestamp;
  final Duration expiry;

  CachedAnalysis({
    required this.data,
    required this.timestamp,
    required this.expiry,
  });

  bool get isExpired => DateTime.now().difference(timestamp) > expiry;
}

/// Main recursive children analyzer
class RecursiveChildrenAnalyzer {
  final RecursiveAnalysisConfig config;
  final InspectorService? inspectorService;
  final DependencyAnalysisService? dependencyService;
  final EnhancedDependencyAnalysisService? enhancedDependencyService;

  final Map<String, CachedAnalysis> _analysisCache = {};
  final Map<String, String> _packageNameCache = {};

  RecursiveChildrenAnalyzer({
    required this.config,
    this.inspectorService,
    this.dependencyService,
    this.enhancedDependencyService,
  });

  /// Analyze children recursively with detailed hierarchy information
  Future<Map<String, dynamic>> analyzeChildrenRecursivelyWithDetailedHierarchy(
    WidgetTreeNode node, {
    int currentDepth = 0,
    AnalysisContext? context,
    Set<String> visitedNodes = const {},
    String? packageName,
    String? projectPath,
  }) async {
    // Prevent infinite loops
    if (node.objectId != null && visitedNodes.contains(node.objectId!)) {
      return {'children': [], 'error': 'Circular reference detected'};
    }

    // Check depth limit
    if (currentDepth >= config.maxDepth) {
      return {
        'children': [],
        'truncated': true,
        'reason': 'Max depth reached (${config.maxDepth})',
      };
    }

    // Check cache if enabled
    final cacheKey = _generateCacheKey(node, currentDepth, context);
    if (config.enableCaching) {
      final cached = await _getCachedAnalysis(cacheKey);
      if (cached != null) {
        return cached;
      }
    }

    final children = <Map<String, dynamic>>[];
    final newVisitedNodes = {
      ...visitedNodes,
      if (node.objectId != null) node.objectId!,
    };

    // Extract package name if not provided
    final effectivePackageName =
        packageName ?? await _extractPackageName(node, projectPath);

    // Create analysis context
    final analysisContext =
        context?.withChild(
          node,
          packageName: effectivePackageName,
          projectPath: projectPath,
        ) ??
        AnalysisContext(
          packageName: effectivePackageName,
          projectPath: projectPath,
        );

    // Get detailed children using inspector service
    List<WidgetTreeNode> childrenToAnalyze;
    if (node.objectId != null && inspectorService != null) {
      try {
        // Use lazy loading for detailed children
        final detailedChildren = await inspectorService!.getChildren(
          node.objectId!,
        );
        childrenToAnalyze = detailedChildren
            .take(config.maxChildrenPerLevel)
            .toList();
        print(
          '🔍 Loaded ${detailedChildren.length} detailed children for ${node.widgetRuntimeType}',
        );
      } catch (e) {
        print('🔍 ❌ Failed to load detailed children: $e');
        childrenToAnalyze = node.children
            .take(config.maxChildrenPerLevel)
            .toList();
      }
    } else {
      // Fallback to existing children from summary tree
      childrenToAnalyze = node.children
          .take(config.maxChildrenPerLevel)
          .toList();
    }

    for (final child in childrenToAnalyze) {
      try {
        // Apply filtering strategy
        if (_shouldSkipWidget(child)) {
          continue;
        }

        // Determine analysis depth based on widget importance
        final analysisDepth = _getAnalysisDepth(child, currentDepth);

        final childAnalysis = await _analyzeSingleChildWithDetailedHierarchy(
          child,
          currentDepth + 1,
          analysisContext,
          newVisitedNodes,
          analysisDepth,
        );

        children.add(childAnalysis);
      } catch (e) {
        if (kDebugMode) {
          print('Error analyzing child ${child.widgetRuntimeType}: $e');
        }
        children.add({
          'type': child.widgetRuntimeType ?? 'Widget',
          'error': e.toString(),
          'depth': currentDepth + 1,
        });
      }
    }

    final result = {
      'children': children,
      'totalChildren': children.length,
      'analyzedDepth': currentDepth,
      'packageName': effectivePackageName,
      'projectPath': projectPath,
      'context': {
        'parentType': context?.parentType,
        'ancestorTypes': context?.ancestorTypes,
        'isInScrollable': analysisContext.isInScrollable,
        'isInForm': analysisContext.isInForm,
        'isInMaterial': analysisContext.isInMaterial,
        'layoutDirection': analysisContext.layoutDirection,
      },
      'analysisConfig': {
        'maxDepth': config.maxDepth,
        'maxChildrenPerLevel': config.maxChildrenPerLevel,
        'includeProperties': config.includeAllProperties,
        'includeDependencies': config.includeDependencies,
        'includeSourceContext': config.includeSourceContext,
        'includeAccessibility': config.includeAccessibility,
        'useDetailedHierarchy': true,
      },
      'timestamp': DateTime.now().toIso8601String(),
    };

    // Cache the result if enabled
    if (config.enableCaching) {
      _cacheAnalysis(cacheKey, result);
    }

    return result;
  }

  /// Analyze children recursively with comprehensive details
  Future<Map<String, dynamic>> analyzeChildrenRecursively(
    WidgetTreeNode node, {
    int currentDepth = 0,
    AnalysisContext? context,
    Set<String> visitedNodes = const {},
    String? packageName,
    String? projectPath,
  }) async {
    // Prevent infinite loops
    if (node.objectId != null && visitedNodes.contains(node.objectId!)) {
      return {'children': [], 'error': 'Circular reference detected'};
    }

    // Check depth limit
    if (currentDepth >= config.maxDepth) {
      return {
        'children': [],
        'truncated': true,
        'reason': 'Max depth reached (${config.maxDepth})',
      };
    }

    // Check cache if enabled
    final cacheKey = _generateCacheKey(node, currentDepth, context);
    if (config.enableCaching) {
      final cached = await _getCachedAnalysis(cacheKey);
      if (cached != null) {
        return cached;
      }
    }

    final children = <Map<String, dynamic>>[];
    final newVisitedNodes = {
      ...visitedNodes,
      if (node.objectId != null) node.objectId!,
    };

    // Extract package name if not provided
    final effectivePackageName =
        packageName ?? await _extractPackageName(node, projectPath);

    // Create analysis context
    final analysisContext =
        context?.withChild(
          node,
          packageName: effectivePackageName,
          projectPath: projectPath,
        ) ??
        AnalysisContext(
          packageName: effectivePackageName,
          projectPath: projectPath,
        );

    // Limit children per level
    final childrenToAnalyze = node.children
        .take(config.maxChildrenPerLevel)
        .toList();

    for (final child in childrenToAnalyze) {
      try {
        // Apply filtering strategy
        if (_shouldSkipWidget(child)) {
          continue;
        }

        // Determine analysis depth based on widget importance
        final analysisDepth = _getAnalysisDepth(child, currentDepth);

        final childAnalysis = await _analyzeSingleChild(
          child,
          currentDepth + 1,
          analysisContext,
          newVisitedNodes,
          analysisDepth,
        );

        children.add(childAnalysis);
      } catch (e) {
        if (kDebugMode) {
          print('Error analyzing child ${child.widgetRuntimeType}: $e');
        }
        children.add({
          'type': child.widgetRuntimeType ?? 'Widget',
          'error': e.toString(),
          'depth': currentDepth + 1,
        });
      }
    }

    final result = {
      'children': children,
      'totalChildren': children.length,
      'analyzedDepth': currentDepth,
      'packageName': effectivePackageName,
      'projectPath': projectPath,
      'context': {
        'parentType': context?.parentType,
        'ancestorTypes': context?.ancestorTypes,
        'isInScrollable': analysisContext.isInScrollable,
        'isInForm': analysisContext.isInForm,
        'isInMaterial': analysisContext.isInMaterial,
        'layoutDirection': analysisContext.layoutDirection,
      },
      'analysisConfig': {
        'maxDepth': config.maxDepth,
        'maxChildrenPerLevel': config.maxChildrenPerLevel,
        'includeProperties': config.includeAllProperties,
        'includeDependencies': config.includeDependencies,
        'includeSourceContext': config.includeSourceContext,
        'includeAccessibility': config.includeAccessibility,
      },
      'timestamp': DateTime.now().toIso8601String(),
    };

    // Cache the result if enabled
    if (config.enableCaching) {
      _cacheAnalysis(cacheKey, result);
    }

    return result;
  }

  /// Analyze a single child widget with detailed hierarchy information
  Future<Map<String, dynamic>> _analyzeSingleChildWithDetailedHierarchy(
    WidgetTreeNode child,
    int depth,
    AnalysisContext context,
    Set<String> visitedNodes,
    int analysisDepth,
  ) async {
    final childType = child.widgetRuntimeType ?? child.description ?? 'Widget';
    final childName = _extractWidgetName(childType);

    final childAnalysis = {
      'type': childType,
      'name': childName,
      'description': child.description,
      'objectId': child.objectId,
      'depth': depth,
      'importance': _getWidgetImportance(child).toString(),
      'packageName': context.packageName,
      'projectPath': context.projectPath,
      'hasChildren': child.children.isNotEmpty,
      'childrenCount': child.children.length,
      'useDetailedHierarchy': true,
    };

    // Add comprehensive properties with detailed hierarchy
    if (config.includeAllProperties) {
      childAnalysis['properties'] = await _extractComprehensiveProperties(
        child,
      );
      childAnalysis['widgetSpecificProperties'] =
          _extractWidgetSpecificProperties(child);

      // Get detailed properties from inspector service
      if (child.objectId != null && inspectorService != null) {
        try {
          final detailedProps = await inspectorService!.getWidgetDetails(
            child.objectId!,
          );
          if (detailedProps != null) {
            childAnalysis['detailedInspectorProperties'] = detailedProps;
            print(
              '🔍 ✅ Loaded ${detailedProps.length} detailed properties for $childType',
            );
          }
        } catch (e) {
          print('🔍 ❌ Failed to load detailed properties: $e');
        }
      }
    }

    // Add dependencies analysis
    if (config.includeDependencies && child.objectId != null) {
      childAnalysis['dependencies'] = await _extractWidgetDependencies(child);
    }

    // Add source context
    if (config.includeSourceContext && child.objectId != null) {
      childAnalysis['sourceContext'] = await _extractSourceContext(child);
    }

    // Add accessibility information
    if (config.includeAccessibility) {
      childAnalysis['accessibility'] = await _extractAccessibilityInfo(child);
    }

    // Add layout and constraint information
    childAnalysis['layout'] = _extractLayoutInfo(child, context);

    // Recursive analysis for important widgets or within depth limit
    if (analysisDepth > 0 && child.children.isNotEmpty) {
      childAnalysis['children'] =
          await analyzeChildrenRecursivelyWithDetailedHierarchy(
            child,
            currentDepth: depth,
            context: context,
            visitedNodes: visitedNodes,
            packageName: context.packageName,
            projectPath: context.projectPath,
          );
    }

    return childAnalysis;
  }

  /// Analyze a single child widget comprehensively
  Future<Map<String, dynamic>> _analyzeSingleChild(
    WidgetTreeNode child,
    int depth,
    AnalysisContext context,
    Set<String> visitedNodes,
    int analysisDepth,
  ) async {
    final childType = child.widgetRuntimeType ?? child.description ?? 'Widget';
    final childName = _extractWidgetName(childType);
    final importance = _getWidgetImportance(child);

    final childAnalysis = {
      'type': childType,
      'name': childName,
      'description': child.description,
      'objectId': child.objectId,
      'depth': depth,
      'importance': importance.toString(),
      'packageName': context.packageName,
      'projectPath': context.projectPath,
      'hasChildren': child.children.isNotEmpty,
      'childrenCount': child.children.length,
    };

    // Add comprehensive properties
    if (config.includeAllProperties) {
      childAnalysis['properties'] = await _extractComprehensiveProperties(
        child,
      );
      childAnalysis['widgetSpecificProperties'] =
          _extractWidgetSpecificProperties(child);
    }

    // Add dependencies analysis
    if (config.includeDependencies && child.objectId != null) {
      childAnalysis['dependencies'] = await _extractWidgetDependencies(child);
    }

    // Add source context
    if (config.includeSourceContext && child.objectId != null) {
      childAnalysis['sourceContext'] = await _extractSourceContext(child);
    }

    // Add accessibility information
    if (config.includeAccessibility) {
      childAnalysis['accessibility'] = await _extractAccessibilityInfo(child);
    }

    // Add layout and constraint information
    childAnalysis['layout'] = _extractLayoutInfo(child, context);

    // Recursive analysis for important widgets or within depth limit
    if (analysisDepth > 0 && child.children.isNotEmpty) {
      childAnalysis['children'] = await analyzeChildrenRecursively(
        child,
        currentDepth: depth,
        context: context,
        visitedNodes: visitedNodes,
        packageName: context.packageName,
        projectPath: context.projectPath,
      );
    }

    return childAnalysis;
  }

  /// Extract comprehensive properties for a widget
  Future<List<Map<String, dynamic>>> _extractComprehensiveProperties(
    WidgetTreeNode node,
  ) async {
    final properties = <Map<String, dynamic>>[];

    try {
      // Extract from node attributes
      if (node.attributes != null) {
        for (final attr in node.attributes!) {
          properties.add({
            'name': attr.name,
            'value': attr.label,
            'type': _inferPropertyType(attr.label),
            'source': 'attributes',
            'isImportant': _isImportantProperty(attr.name),
            'isEditable': _isEditableProperty(attr.name),
          });
        }
      }

      // Get detailed properties using inspector service if available
      if (node.objectId != null && inspectorService != null) {
        try {
          final detailedProperties = await inspectorService?.getWidgetDetails(
            node.objectId!,
          );
          if (detailedProperties != null) {
            for (final prop in detailedProperties) {
              properties.add({
                'name': prop['name'],
                'value':
                    prop['label'] ?? prop['value'] ?? prop['valueId'] ?? '',
                'type': _inferPropertyType(prop['type']),
                'source': 'inspector_service',
                'isImportant': _isImportantProperty(prop['name']),
                'isEditable': _isEditableProperty(prop['name']),
              });
            }
          }
        } catch (e) {
          if (kDebugMode) {
            print('Error getting detailed properties: $e');
          }
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error extracting comprehensive properties: $e');
      }
    }

    return properties;
  }

  /// Extract widget-specific properties based on type
  List<Map<String, dynamic>> _extractWidgetSpecificProperties(
    WidgetTreeNode node,
  ) {
    final properties = <Map<String, dynamic>>[];
    final widgetType = node.widgetRuntimeType?.toLowerCase() ?? '';
    final description = node.description ?? '';

    // Text widgets
    if (widgetType.contains('text')) {
      properties.addAll(_extractTextProperties(description));
    }

    // Button widgets
    if (widgetType.contains('button')) {
      properties.addAll(_extractButtonProperties(description));
    }

    // Input widgets
    if (widgetType.contains('field') || widgetType.contains('input')) {
      properties.addAll(_extractInputProperties(description));
    }

    // Layout widgets
    if (widgetType.contains('column') || widgetType.contains('row')) {
      properties.addAll(_extractLayoutProperties(description));
    }

    // Container widgets
    if (widgetType.contains('container')) {
      properties.addAll(_extractContainerProperties(description));
    }

    return properties;
  }

  /// Extract text widget properties
  List<Map<String, dynamic>> _extractTextProperties(String description) {
    final properties = <Map<String, dynamic>>[];

    // Extract text content
    final textMatch = RegExp(r"Text\('([^']*)'\)").firstMatch(description);
    if (textMatch != null) {
      properties.add({
        'name': 'text',
        'value': textMatch.group(1),
        'type': 'String',
        'source': 'parsed',
        'isImportant': true,
        'isEditable': true,
      });
    }

    // Extract style information
    if (description.contains('TextStyle')) {
      properties.add({
        'name': 'style',
        'value': 'TextStyle',
        'type': 'TextStyle',
        'source': 'parsed',
        'isImportant': true,
        'isEditable': true,
      });
    }

    return properties;
  }

  /// Extract button widget properties
  List<Map<String, dynamic>> _extractButtonProperties(String description) {
    final properties = <Map<String, dynamic>>[];

    // Extract button text
    final textMatch = RegExp(r"'([^']*)'").firstMatch(description);
    if (textMatch != null) {
      properties.add({
        'name': 'text',
        'value': textMatch.group(1),
        'type': 'String',
        'source': 'parsed',
        'isImportant': true,
        'isEditable': true,
      });
    }

    return properties;
  }

  /// Extract input widget properties
  List<Map<String, dynamic>> _extractInputProperties(String description) {
    final properties = <Map<String, dynamic>>[];

    // Extract hint text
    final hintMatch = RegExp(r"hintText:\s*'([^']*)'").firstMatch(description);
    if (hintMatch != null) {
      properties.add({
        'name': 'hintText',
        'value': hintMatch.group(1),
        'type': 'String',
        'source': 'parsed',
        'isImportant': true,
        'isEditable': true,
      });
    }

    return properties;
  }

  /// Extract layout widget properties
  List<Map<String, dynamic>> _extractLayoutProperties(String description) {
    final properties = <Map<String, dynamic>>[];

    // Extract main axis alignment
    if (description.contains('MainAxisAlignment')) {
      final alignmentMatch = RegExp(
        r"MainAxisAlignment\.(\w+)",
      ).firstMatch(description);
      if (alignmentMatch != null) {
        properties.add({
          'name': 'mainAxisAlignment',
          'value': alignmentMatch.group(1),
          'type': 'MainAxisAlignment',
          'source': 'parsed',
          'isImportant': true,
          'isEditable': true,
        });
      }
    }

    return properties;
  }

  /// Extract container widget properties
  List<Map<String, dynamic>> _extractContainerProperties(String description) {
    final properties = <Map<String, dynamic>>[];

    // Extract padding
    if (description.contains('EdgeInsets')) {
      properties.add({
        'name': 'padding',
        'value': 'EdgeInsets',
        'type': 'EdgeInsets',
        'source': 'parsed',
        'isImportant': true,
        'isEditable': true,
      });
    }

    // Extract decoration
    if (description.contains('BoxDecoration')) {
      properties.add({
        'name': 'decoration',
        'value': 'BoxDecoration',
        'type': 'BoxDecoration',
        'source': 'parsed',
        'isImportant': true,
        'isEditable': true,
      });
    }

    return properties;
  }

  /// Extract widget dependencies
  Future<List<Map<String, dynamic>>> _extractWidgetDependencies(
    WidgetTreeNode node,
  ) async {
    final dependencies = <Map<String, dynamic>>[];

    try {
      if (enhancedDependencyService != null) {
        final result = await enhancedDependencyService
            ?.analyzeWidgetDependencies(node);
        for (final dep in result?.dependencies ?? []) {
          dependencies.add({
            'type': dep.type,
            'category': dep.category,
            'description': dep.description,
            'distanceFromTarget': dep.distanceFromTarget,
            'setupCode': dep.setupCode,
            'usage': dep.usage,
            'location': dep.location != null
                ? {
                    'file': dep.location!.file,
                    'line': dep.location!.line,
                    'column': dep.location!.column,
                  }
                : null,
          });
        }
      } else if (dependencyService != null) {
        final deps = await dependencyService?.analyzeDependencies(node);
        for (final dep in deps ?? []) {
          dependencies.add({
            'type': dep.type,
            'category': dep.category,
            'description': dep.description,
            'distanceFromTarget': dep.distanceFromTarget,
            'setupCode': dep.setupCode,
            'usage': dep.usage,
            'location': dep.location != null
                ? {
                    'file': dep.location!.file,
                    'line': dep.location!.line,
                    'column': dep.location!.column,
                  }
                : null,
          });
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error extracting widget dependencies: $e');
      }
    }

    return dependencies;
  }

  /// Extract source context for a widget
  Future<Map<String, dynamic>> _extractSourceContext(
    WidgetTreeNode node,
  ) async {
    try {
      if (node.objectId != null && inspectorService != null) {
        // This would require additional inspector service methods
        // For now, return basic context
        return {
          'objectId': node.objectId,
          'hasSourceInfo': true,
          'note':
              'Source context extraction requires additional inspector service methods',
        };
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error extracting source context: $e');
      }
    }

    return {'hasSourceInfo': false, 'note': 'Source context not available'};
  }

  /// Extract accessibility information
  Future<Map<String, dynamic>> _extractAccessibilityInfo(
    WidgetTreeNode node,
  ) async {
    try {
      return {
        'semanticLabel': _extractSemanticLabel(node),
        'semanticHint': _extractSemanticHint(node),
        'isAccessible': _isAccessible(node),
        'accessibilityTraits': _extractAccessibilityTraits(node),
        'focusable': _isFocusable(node),
        'hasSemantics': _hasSemantics(node),
      };
    } catch (e) {
      if (kDebugMode) {
        print('Error extracting accessibility info: $e');
      }
      return {};
    }
  }

  /// Extract layout information
  Map<String, dynamic> _extractLayoutInfo(
    WidgetTreeNode node,
    AnalysisContext context,
  ) {
    return {
      'layoutDirection': context.layoutDirection,
      'isInScrollable': context.isInScrollable,
      'isInForm': context.isInForm,
      'isInMaterial': context.isInMaterial,
      'constraints': _extractConstraints(node),
      'layoutType': _extractLayoutType(node),
    };
  }

  /// Extract package name from project path or widget context
  Future<String?> _extractPackageName(
    WidgetTreeNode node,
    String? projectPath,
  ) async {
    if (projectPath == null) return null;

    // Check cache first
    if (_packageNameCache.containsKey(projectPath)) {
      return _packageNameCache[projectPath];
    }

    try {
      // Extract from project path
      final packageName = projectPath.split('/').last;
      _packageNameCache[projectPath] = packageName;
      return packageName;
    } catch (e) {
      if (kDebugMode) {
        print('Error extracting package name: $e');
      }
      return null;
    }
  }

  /// Determine if widget should be skipped
  bool _shouldSkipWidget(WidgetTreeNode widget) {
    final type = widget.widgetRuntimeType?.toLowerCase() ?? '';
    return config.skipWidgetTypes.contains(type);
  }

  /// Get analysis depth based on widget importance
  int _getAnalysisDepth(WidgetTreeNode widget, int currentDepth) {
    final widgetType = widget.widgetRuntimeType?.toLowerCase() ?? '';

    // Always analyze priority widgets deeper
    if (config.priorityWidgetTypes.contains(widgetType)) {
      return (config.maxDepth - currentDepth).clamp(0, 4);
    }

    // Layout widgets get moderate depth
    if (_isLayoutWidget(widgetType)) {
      return (config.maxDepth - currentDepth).clamp(0, 3);
    }

    // Regular widgets get limited depth
    return (config.maxDepth - currentDepth).clamp(0, 2);
  }

  /// Get widget importance level
  WidgetImportance _getWidgetImportance(WidgetTreeNode widget) {
    final type = widget.widgetRuntimeType?.toLowerCase() ?? '';

    if (config.priorityWidgetTypes.contains(type)) return WidgetImportance.high;
    if (_isLayoutWidget(type)) return WidgetImportance.medium;
    if (config.skipWidgetTypes.contains(type)) return WidgetImportance.low;

    // Check for interactive elements
    if (type.contains('button') ||
        type.contains('field') ||
        type.contains('input')) {
      return WidgetImportance.high;
    }

    // Check for critical widgets
    if (type.contains('scaffold') ||
        type.contains('appbar') ||
        type.contains('material')) {
      return WidgetImportance.critical;
    }

    return WidgetImportance.medium;
  }

  /// Check if widget is a layout widget
  bool _isLayoutWidget(String type) {
    const layoutTypes = {
      'column',
      'row',
      'stack',
      'flex',
      'wrap',
      'flow',
      'listview',
      'gridview',
      'pageview',
      'tabbarview',
    };
    return layoutTypes.contains(type);
  }

  /// Generate cache key for analysis
  String _generateCacheKey(
    WidgetTreeNode node,
    int depth,
    AnalysisContext? context,
  ) {
    final contextStr = context?.parentType ?? '';
    return '${node.objectId}_${depth}_$contextStr';
  }

  /// Get cached analysis
  Future<Map<String, dynamic>?> _getCachedAnalysis(String key) async {
    final cached = _analysisCache[key];
    if (cached != null && !cached.isExpired) {
      return cached.data;
    }
    return null;
  }

  /// Cache analysis result
  void _cacheAnalysis(String key, Map<String, dynamic> data) {
    _analysisCache[key] = CachedAnalysis(
      data: data,
      timestamp: DateTime.now(),
      expiry: config.cacheExpiry,
    );
  }

  /// Clear expired cache
  void clearExpiredCache() {
    _analysisCache.removeWhere((key, value) => value.isExpired);
  }

  /// Clear all cache
  void clearCache() {
    _analysisCache.clear();
    _packageNameCache.clear();
  }

  // Helper methods for property extraction
  String _extractWidgetName(String widgetType) {
    return widgetType.split('(').first.trim();
  }

  String _inferPropertyType(String value) {
    if (value.startsWith('Color(')) return 'Color';
    if (value.startsWith('EdgeInsets(')) return 'EdgeInsets';
    if (value.startsWith('BorderRadius(')) return 'BorderRadius';
    if (value.startsWith('TextStyle(')) return 'TextStyle';
    if (value.startsWith('MainAxisAlignment.')) return 'MainAxisAlignment';
    if (value.startsWith('CrossAxisAlignment.')) return 'CrossAxisAlignment';
    if (value == 'true' || value == 'false') return 'bool';
    if (RegExp(r'^\d+$').hasMatch(value)) return 'int';
    if (RegExp(r'^\d+\.\d+$').hasMatch(value)) return 'double';
    return 'String';
  }

  bool _isImportantProperty(String name) {
    const importantProps = {
      'text',
      'child',
      'children',
      'onPressed',
      'onTap',
      'onChanged',
      'value',
      'controller',
      'key',
      'style',
      'decoration',
      'padding',
      'margin',
      'alignment',
      'mainAxisAlignment',
      'crossAxisAlignment',
    };
    return importantProps.contains(name.toLowerCase());
  }

  bool _isEditableProperty(String name) {
    const editableProps = {
      'text',
      'value',
      'hintText',
      'labelText',
      'style',
      'decoration',
      'padding',
      'margin',
      'alignment',
      'mainAxisAlignment',
      'crossAxisAlignment',
    };
    return editableProps.contains(name.toLowerCase());
  }

  // Accessibility helper methods
  String? _extractSemanticLabel(WidgetTreeNode node) {
    // Extract from description or properties
    return null;
  }

  String? _extractSemanticHint(WidgetTreeNode node) {
    // Extract from description or properties
    return null;
  }

  bool _isAccessible(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';
    return type.contains('button') ||
        type.contains('field') ||
        type.contains('input') ||
        type.contains('text');
  }

  List<String> _extractAccessibilityTraits(WidgetTreeNode node) {
    final traits = <String>[];
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';

    if (type.contains('button')) traits.add('button');
    if (type.contains('field') || type.contains('input'))
      traits.add('textField');
    if (type.contains('text')) traits.add('text');

    return traits;
  }

  bool _isFocusable(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';
    return type.contains('button') ||
        type.contains('field') ||
        type.contains('input');
  }

  bool _hasSemantics(WidgetTreeNode node) {
    return _isAccessible(node);
  }

  // Layout helper methods
  Map<String, dynamic> _extractConstraints(WidgetTreeNode node) {
    return {
      'hasConstraints': node.description?.contains('BoxConstraints') == true,
      'isConstrained': node.description?.contains('constrained') == true,
      'isUnconstrained': node.description?.contains('unconstrained') == true,
    };
  }

  String _extractLayoutType(WidgetTreeNode node) {
    final description = node.description?.toLowerCase() ?? '';
    if (description.contains('column')) return 'column';
    if (description.contains('row')) return 'row';
    if (description.contains('stack')) return 'stack';
    if (description.contains('flex')) return 'flex';
    if (description.contains('wrap')) return 'wrap';
    if (description.contains('flow')) return 'flow';
    return 'unknown';
  }
}
