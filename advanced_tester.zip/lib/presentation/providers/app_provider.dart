import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../controllers/widget_tree_controller.dart';
import '../controllers/test_generation_controller.dart';
import '../../core/di/service_locator.dart';
import '../../core/config/environment_service.dart';
import '../../domain/repositories/widget_repository.dart';
import '../../domain/usecases/check_inspector_availability_usecase.dart';
import '../../core/di/dependency_injection.dart';
import '../../services/device_service.dart';
import '../../services/inspector_service.dart';
import '../../services/ios_simulator_service.dart';
import '../../core/logging/logging.dart';

/// Console message class
class ConsoleMessage {
  final String message;
  final DateTime timestamp;
  final String type;

  ConsoleMessage({
    required this.message,
    required this.timestamp,
    this.type = 'log',
  });

  @override
  String toString() => '[${timestamp.toIso8601String()}] $message';
}

/// Main app provider that manages the overall application state
class AppProvider extends ChangeNotifier with LoggerMixin {
  final WidgetTreeController _widgetTreeController;
  final TestGenerationController _testGenerationController;
  final CheckInspectorAvailabilityUseCase _checkInspectorAvailabilityUseCase;
  EnvironmentService? _environmentService;

  bool _isInitialized = false;
  bool _isConnecting = false;
  String? _connectionError;
  String? _vmServiceUri;

  // Legacy AppState properties for compatibility
  String? _selectedProjectPath;
  bool _isRunning = false;
  String? _runningUrl;
  Process? _flutterProcess;
  String _testEditorText = '';
  StreamSubscription<String>? _runLogSub;
  String? _flutterSdkDir;
  String? _debugServiceUrl;
  Object? _inspectorService;
  List<DeviceInfo> _availableDevices = [DeviceService.defaultDevice];
  DeviceInfo _selectedDevice = DeviceService.defaultDevice;
  bool _isLoadingDevices = false;
  WidgetTreeNode? _selectedWidget;
  final List<ConsoleMessage> _consoleMessages = [];
  bool _showConsole = false;
  final IOSSimulatorService _iosSimulatorService = IOSSimulatorService();
  List<IOSSimulatorDevice> _iosSimulators = const [];
  IOSSimulatorDevice? _selectedIosSimulator;
  bool _isIosSimulatorLoading = false;
  bool _isIosPreviewStarting = false;
  bool _isIosPreviewActive = false;
  StreamSubscription<Uint8List>? _iosScreenshotSub;
  Uint8List? _iosScreenshotBytes;
  DateTime? _iosLastFrameTime;
  String? _iosStatus;
  Size? _iosScreenshotResolution;

  AppProvider()
    : _widgetTreeController = WidgetTreeController(),
      _testGenerationController = TestGenerationController(),
      _checkInspectorAvailabilityUseCase = serviceLocator
          .get<CheckInspectorAvailabilityUseCase>() {
    logger.info('AppProvider initialized');
  }

  // Getters
  WidgetTreeController get widgetTreeController => _widgetTreeController;
  TestGenerationController get testGenerationController =>
      _testGenerationController;
  bool get isInitialized => _isInitialized;
  bool get isConnecting => _isConnecting;
  String? get connectionError => _connectionError;
  String? get vmServiceUri => _vmServiceUri;
  bool get hasConnectionError => _connectionError != null;
  EnvironmentService? get environmentService => _environmentService;

  // Legacy AppState getters for compatibility
  String? get selectedProjectPath => _selectedProjectPath;
  bool get isRunning => _isRunning;
  String? get runningUrl => _runningUrl;
  String get testEditorText => _testEditorText;
  String? get flutterSdkDir => _flutterSdkDir;
  String? get debugServiceUrl => _debugServiceUrl;
  List<DeviceInfo> get availableDevices => _availableDevices;
  DeviceInfo get selectedDevice => _selectedDevice;
  bool get isLoadingDevices => _isLoadingDevices;
  WidgetTreeNode? get selectedWidget => _selectedWidget;
  List<ConsoleMessage> get consoleMessages => _consoleMessages;
  bool get showConsole => _showConsole;
  List<IOSSimulatorDevice> get iosSimulators => _iosSimulators;
  IOSSimulatorDevice? get selectedIosSimulator => _selectedIosSimulator;
  bool get isIosSimulatorLoading => _isIosSimulatorLoading;
  bool get isIosPreviewStarting => _isIosPreviewStarting;
  bool get isIosPreviewActive => _isIosPreviewActive;
  Uint8List? get iosScreenshotBytes => _iosScreenshotBytes;
  DateTime? get iosLastFrameTime => _iosLastFrameTime;
  String? get iosStatus => _iosStatus;
  Size? get iosScreenshotResolution => _iosScreenshotResolution;

  /// Set environment service reference
  void setEnvironmentService(EnvironmentService environmentService) {
    _environmentService = environmentService;
  }

  /// Initialize the application with VM service URI
  Future<void> initialize(String vmServiceUri) async {
    if (_isInitialized) return;

    _vmServiceUri = vmServiceUri;
    _setConnecting(true);
    _clearConnectionError();

    try {
      // Configure dependency injection with the VM service URI
      DependencyInjection.configureWithVmServiceUri(Uri.parse(vmServiceUri));

      // Get the widget repository and connect
      final widgetRepository = serviceLocator.get<WidgetRepository>();
      await widgetRepository.connect();

      // Check if inspector is available
      final isAvailable = await _checkInspectorAvailabilityUseCase.execute();
      if (!isAvailable) {
        throw Exception('Inspector is not available');
      }

      _isInitialized = true;
      notifyListeners();

      // Log initialization with environment info
      if (_environmentService != null) {
        final config = _environmentService!.config;
        addConsoleMessage(
          'App initialized with environment: ${config.enableDebugMode ? 'DEBUG' : 'PRODUCTION'} mode',
        );
        if (config.hasAICapabilities) {
          addConsoleMessage(
            'AI capabilities enabled with provider: ${config.primaryAIProvider}',
          );
        }
      }
    } catch (e) {
      _setConnectionError('Failed to initialize: $e');
    } finally {
      _setConnecting(false);
    }
  }

  /// Reconnect to VM service
  Future<void> reconnect(String vmServiceUri) async {
    _isInitialized = false;
    await initialize(vmServiceUri);
  }

  /// Disconnect from VM service
  Future<void> disconnect() async {
    if (!_isInitialized) return;

    try {
      final widgetRepository = serviceLocator.get<WidgetRepository>();
      await widgetRepository.disconnect();

      _isInitialized = false;
      _vmServiceUri = null;
      notifyListeners();
    } catch (e) {
      _setConnectionError('Failed to disconnect: $e');
    }
  }

  /// Refresh all data
  Future<void> refresh() async {
    if (!_isInitialized) return;

    try {
      await _widgetTreeController.refresh();
      notifyListeners();
    } catch (e) {
      _setConnectionError('Failed to refresh: $e');
    }
  }

  /// Clear connection error
  void _clearConnectionError() {
    _connectionError = null;
  }

  /// Set connection error
  void _setConnectionError(String error) {
    _connectionError = error;
    notifyListeners();
  }

  /// Set connecting state
  void _setConnecting(bool connecting) {
    _isConnecting = connecting;
    notifyListeners();
  }

  // Legacy AppState methods for compatibility
  void addConsoleMessage(String message, {String type = 'log'}) {
    _consoleMessages.add(
      ConsoleMessage(message: message, timestamp: DateTime.now(), type: type),
    );
    notifyListeners();
  }

  void setSelectedProjectPath(String? path) {
    _selectedProjectPath = path;
    notifyListeners();
  }

  void setFlutterSdkDir(String? dir) {
    _flutterSdkDir = dir;
    notifyListeners();
  }

  void toggleConsoleVisibility() {
    _showConsole = !_showConsole;
    notifyListeners();
  }

  void setTestEditorText(String text) {
    _testEditorText = text;
    notifyListeners();
  }

  void setConsoleVisibility(bool visible) {
    _showConsole = visible;
    notifyListeners();
  }

  Future<void> copyConsoleToClipboard() async {
    final text = _consoleMessages.map((m) => m.toString()).join('\n');
    await Clipboard.setData(ClipboardData(text: text));
  }

  void clearConsoleMessages() {
    _consoleMessages.clear();
    notifyListeners();
  }

  void setFlutterProcess(Process? process) {
    _flutterProcess = process;
    notifyListeners();
  }

  void setIsRunning(bool running) {
    _isRunning = running;
    notifyListeners();
  }

  void setRunningUrl(String? url) {
    _runningUrl = url;
    notifyListeners();
  }

  void setDebugServiceUrl(String? url) {
    _debugServiceUrl = url;
    notifyListeners();
  }

  void setInspectorService(Object? service) {
    _inspectorService = service;
    notifyListeners();
  }

  void setSelectedWidget(WidgetTreeNode? widget) {
    _selectedWidget = widget;
    notifyListeners();
  }

  void setVmServiceUri(Uri uri) {
    _vmServiceUri = uri.toString();
    notifyListeners();
  }

  Object? get inspectorService => _inspectorService;

  void setRunLogSubscription(StreamSubscription<String>? subscription) {
    _runLogSub?.cancel();
    _runLogSub = subscription;
    notifyListeners();
  }

  void clearRunningProjectData() {
    _isRunning = false;
    _runningUrl = null;
    _debugServiceUrl = null;
    _inspectorService = null;
    _flutterProcess?.kill();
    _flutterProcess = null;
    _runLogSub?.cancel();
    _runLogSub = null;
    notifyListeners();
  }

  Process? get flutterProcess => _flutterProcess;

  void refreshDevices() async {
    _isLoadingDevices = true;
    notifyListeners();

    try {
      final devices = await DeviceService().getAvailableDevices();
      _availableDevices = devices;

      if (_availableDevices.isEmpty) {
        _selectedDevice = DeviceService.defaultDevice;
      } else if (!_availableDevices.contains(_selectedDevice)) {
        _selectedDevice = _availableDevices.first;
      }
    } catch (e) {
      // Keep existing devices on error
    } finally {
      _isLoadingDevices = false;
      notifyListeners();
    }
  }

  void setSelectedDevice(DeviceInfo device) {
    _selectedDevice = device;
    notifyListeners();
  }


  Future<void> refreshIosSimulators() async {
    _isIosSimulatorLoading = true;
    notifyListeners();

    try {
      final sims = await _iosSimulatorService.listSimulators();
      _iosSimulators = sims;

      if (_selectedIosSimulator == null && sims.isNotEmpty) {
        _selectedIosSimulator =
            sims.firstWhere((sim) => sim.isBooted, orElse: () => sims.first);
      } else if (_selectedIosSimulator != null) {
        final updated = sims.where(
          (sim) => sim.udid == _selectedIosSimulator!.udid,
        );
        if (updated.isNotEmpty) {
          _selectedIosSimulator = updated.first;
        }
      }
    } catch (e) {
      addConsoleMessage(
        'Failed to load iOS simulators: $e',
        type: 'error',
      );
    } finally {
      _isIosSimulatorLoading = false;
      notifyListeners();
    }
  }

  void setSelectedIosSimulator(IOSSimulatorDevice simulator) {
    _selectedIosSimulator = simulator;
    notifyListeners();
  }

  Future<void> startIosPreview() async {
    if (_selectedIosSimulator == null &&
        _iosSimulators.isEmpty &&
        !_isIosSimulatorLoading) {
      await refreshIosSimulators();
    }
    final simulator = _selectedIosSimulator ??
        (_iosSimulators.isNotEmpty ? _iosSimulators.first : null);
    if (simulator == null) {
      addConsoleMessage(
        'No iOS simulators available. Ensure Xcode tools are installed.',
        type: 'warning',
      );
      return;
    }

    _isIosPreviewStarting = true;
    _iosStatus = 'Booting ${simulator.name}...';
    notifyListeners();

    try {
      await _iosSimulatorService.bootSimulator(simulator.udid);
      _iosStatus = 'Booted ${simulator.name}. Starting preview...';
      _selectedIosSimulator = simulator;
      _isIosPreviewActive = true;

      await _iosScreenshotSub?.cancel();
      _iosScreenshotSub = _iosSimulatorService
          .startScreenshotStream(simulator.udid)
          .listen((frame) {
        _iosScreenshotBytes = frame;
        _iosLastFrameTime = DateTime.now();
        _iosScreenshotResolution = _extractImageResolution(frame);
        _iosStatus = 'Streaming from ${simulator.name}';
        notifyListeners();
      }, onError: (error) {
        addConsoleMessage('iOS preview error: $error', type: 'error');
        _iosStatus = 'Preview error: $error';
        _isIosPreviewActive = false;
        notifyListeners();
      }, onDone: () {
        _iosStatus = 'Preview stopped';
        _isIosPreviewActive = false;
        notifyListeners();
      });
    } catch (e) {
      addConsoleMessage('Failed to start iOS preview: $e', type: 'error');
      _iosStatus = 'Failed: $e';
    } finally {
      _isIosPreviewStarting = false;
      notifyListeners();
    }
  }

  Future<void> stopIosPreview() async {
    await _iosScreenshotSub?.cancel();
    _iosScreenshotSub = null;
    _iosScreenshotBytes = null;
    _iosLastFrameTime = null;
    _iosScreenshotResolution = null;
    _isIosPreviewActive = false;
    _iosStatus = 'Preview stopped';
    notifyListeners();
  }

  Future<void> sendPreviewTap(Offset normalized, {bool doubleTap = false}) async {
    if (!_isIosPreviewActive) return;
    final simulator = _selectedIosSimulator;
    if (simulator == null) return;

    try {
      await _iosSimulatorService.sendTapGesture(
        simulator.udid,
        normalized,
        doubleTap: doubleTap,
      );
    } catch (e) {
      addConsoleMessage('Failed to send tap: $e', type: 'warning');
    }
  }

  Future<void> sendPreviewDrag(Offset startNormalized, Offset endNormalized) async {
    if (!_isIosPreviewActive) return;
    final simulator = _selectedIosSimulator;
    if (simulator == null) return;

    try {
      await _iosSimulatorService.sendDragGesture(
        simulator.udid,
        startNormalized,
        endNormalized,
      );
    } catch (e) {
      addConsoleMessage('Failed to send drag: $e', type: 'warning');
    }
  }

  Size? _extractImageResolution(Uint8List bytes) {
    if (bytes.length < 24) return null;
    final data = ByteData.view(bytes.buffer, bytes.offsetInBytes, bytes.length);
    final width = data.getUint32(16, Endian.big);
    final height = data.getUint32(20, Endian.big);
    if (width == 0 || height == 0) return null;
    return Size(width.toDouble(), height.toDouble());
  }

  @override
  void dispose() {
    _runLogSub?.cancel();
    _flutterProcess?.kill();
    _widgetTreeController.dispose();
    _testGenerationController.dispose();
    _iosScreenshotSub?.cancel();
    super.dispose();
  }
}
