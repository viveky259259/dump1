import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../core/logging/logging.dart';
import '../../domain/entities/ui_element.dart';
import '../../services/ui_automation_service.dart';

/// Provider for managing UI automation and screen inspection state.
///
/// This provider manages the UI screen state, hovered/inspected elements,
/// and search functionality for UI element inspection.
class UIAutomationProvider extends ChangeNotifier with LoggerMixin {
  final UIAutomationService _automationService = UIAutomationService();

  // Device connection state
  String? _deviceId;
  bool _isConnected = false;
  bool _isConnecting = false;
  String? _connectionError;

  // Screen capture state
  UIScreen? _uiScreen;
  Uint8List? _screenshotBytes;
  bool _isCapturing = false;
  DateTime? _lastCaptureTime;
  StreamSubscription<UIScreen>? _screenSubscription;

  // Element interaction state
  UIElement? _hoveredElement;
  UIElement? _inspectedElement;
  String _searchQuery = '';
  List<UIElement> _filteredElements = [];

  // UI state
  bool _annotationsEnabled = true;
  bool _isGestureMode = false;
  String? _footerHint;
  String? _generatedCommand;

  // Getters
  String? get deviceId => _deviceId;
  bool get isConnected => _isConnected;
  bool get isConnecting => _isConnecting;
  String? get connectionError => _connectionError;

  UIScreen? get uiScreen => _uiScreen;
  
  /// Backwards compatibility getter
  @Deprecated('Use uiScreen instead')
  UIScreen? get deviceScreen => _uiScreen;
  
  Uint8List? get screenshotBytes => _screenshotBytes;
  bool get isCapturing => _isCapturing;
  DateTime? get lastCaptureTime => _lastCaptureTime;

  UIElement? get hoveredElement => _hoveredElement;
  UIElement? get inspectedElement => _inspectedElement;
  String get searchQuery => _searchQuery;
  List<UIElement> get filteredElements => _filteredElements;

  bool get annotationsEnabled => _annotationsEnabled;
  bool get isGestureMode => _isGestureMode;
  String? get footerHint => _footerHint;
  String? get generatedCommand => _generatedCommand;

  /// Get all selectable elements from the current screen (with text/id/accessibility)
  List<UIElement> get selectableElements {
    return _uiScreen?.selectableElements ?? [];
  }

  /// Get all elements from the current screen
  List<UIElement> get allElements {
    return _uiScreen?.elements ?? [];
  }

  /// Get the total element count
  int get elementCount => _uiScreen?.elements.length ?? 0;

  /// Check if automation service is available (Maestro CLI)
  Future<bool> checkAutomationAvailable() async {
    return await _automationService.isMaestroAvailable();
  }

  /// Backwards compatibility alias
  @Deprecated('Use checkAutomationAvailable instead')
  Future<bool> checkInspectorAvailable() => checkAutomationAvailable();

  /// Connect to a device and start screen streaming
  Future<void> connectToDevice(String deviceId) async {
    if (_isConnecting || (_isConnected && _deviceId == deviceId)) return;

    _isConnecting = true;
    _connectionError = null;
    notifyListeners();

    try {
      logger.info('Connecting to device', {'deviceId': deviceId});

      // Verify device is available
      final devices = await _automationService.listDevices();
      final deviceExists = devices.any((d) => d['id'] == deviceId);

      if (!deviceExists) {
        throw Exception('Device $deviceId not found');
      }

      _deviceId = deviceId;
      _isConnected = true;

      // Start screen streaming
      _startScreenStream();

      logger.info('Connected to device', {'deviceId': deviceId});
    } catch (e) {
      _connectionError = 'Failed to connect: $e';
      _isConnected = false;
      logger.error('Failed to connect to device', e);
    } finally {
      _isConnecting = false;
      notifyListeners();
    }
  }

  /// Disconnect from the current device
  void disconnect() {
    _stopScreenStream();
    _deviceId = null;
    _isConnected = false;
    _uiScreen = null;
    _screenshotBytes = null;
    _hoveredElement = null;
    _inspectedElement = null;
    _filteredElements = [];
    notifyListeners();
  }

  /// Start continuous screen capture
  void _startScreenStream() {
    if (_deviceId == null) return;

    _screenSubscription?.cancel();
    _isCapturing = true;
    notifyListeners();

    _screenSubscription = _automationService
        .startScreenStream(
          _deviceId!,
          interval: const Duration(milliseconds: 300),
        )
        .listen(
          _onScreenUpdate,
          onError: _onScreenError,
          onDone: _onScreenDone,
        );
  }

  /// Stop screen capture
  void _stopScreenStream() {
    _screenSubscription?.cancel();
    _screenSubscription = null;
    _automationService.stopScreenStream();
    _isCapturing = false;
  }

  void _onScreenUpdate(UIScreen screen) {
    // Only update if elements have changed (optimization)
    final elementsChanged = !_elementsEqual(_uiScreen?.elements, screen.elements);

    if (elementsChanged || _uiScreen == null) {
      _uiScreen = screen;
      _updateFilteredElements();
    }

    // Always update screenshot
    if (screen.screenshotBytes != null) {
      _screenshotBytes = Uint8List.fromList(screen.screenshotBytes!);
    }

    _lastCaptureTime = screen.capturedAt;
    notifyListeners();
  }

  void _onScreenError(Object error) {
    logger.error('Screen stream error', error);
    _connectionError = 'Screen capture error: $error';
    notifyListeners();
  }

  void _onScreenDone() {
    logger.info('Screen stream ended');
    _isCapturing = false;
    notifyListeners();
  }

  bool _elementsEqual(List<UIElement>? a, List<UIElement>? b) {
    if (a == null && b == null) return true;
    if (a == null || b == null) return false;
    if (a.length != b.length) return false;

    for (var i = 0; i < a.length; i++) {
      if (a[i].id != b[i].id) return false;
    }

    return true;
  }

  /// Capture a single screenshot
  Future<void> captureScreen() async {
    if (_deviceId == null || _isCapturing) return;

    _isCapturing = true;
    notifyListeners();

    try {
      final screen = await _automationService.captureUIScreen(_deviceId!);
      if (screen != null) {
        _onScreenUpdate(screen);
      }
    } catch (e) {
      logger.error('Failed to capture screen', e);
    } finally {
      _isCapturing = false;
      notifyListeners();
    }
  }

  /// Set the hovered element
  void setHoveredElement(UIElement? element) {
    if (_hoveredElement?.id == element?.id) return;

    _hoveredElement = element;
    _footerHint = element?.displayText;
    notifyListeners();
  }

  /// Set the inspected (selected) element
  void setInspectedElement(UIElement? element) {
    _inspectedElement = element;

    if (element != null) {
      _generatedCommand = element.generateTapCommand();
    } else {
      _generatedCommand = null;
    }

    notifyListeners();
  }

  /// Clear the inspected element
  void clearInspectedElement() {
    setInspectedElement(null);
  }

  /// Update the search query
  void setSearchQuery(String query) {
    _searchQuery = query;
    _updateFilteredElements();
    notifyListeners();
  }

  /// Clear the search query
  void clearSearchQuery() {
    setSearchQuery('');
  }

  void _updateFilteredElements() {
    if (_uiScreen == null) {
      _filteredElements = [];
      return;
    }

    _filteredElements = _uiScreen!.searchElements(_searchQuery);

    // Sort: prefix matches first, then alphabetically
    if (_searchQuery.isNotEmpty) {
      final lowerQuery = _searchQuery.toLowerCase();
      _filteredElements.sort((a, b) {
        final aPrefix = a.text?.toLowerCase().startsWith(lowerQuery) ?? false;
        final bPrefix = b.text?.toLowerCase().startsWith(lowerQuery) ?? false;

        if (aPrefix && !bPrefix) return -1;
        if (bPrefix && !aPrefix) return 1;

        final aText = a.text ?? a.resourceId ?? '';
        final bText = b.text ?? b.resourceId ?? '';
        return aText.compareTo(bText);
      });
    }
  }

  /// Toggle annotations visibility
  void toggleAnnotations() {
    _annotationsEnabled = !_annotationsEnabled;
    notifyListeners();
  }

  /// Set annotations enabled state
  void setAnnotationsEnabled(bool enabled) {
    _annotationsEnabled = enabled;
    notifyListeners();
  }

  /// Toggle gesture mode
  void toggleGestureMode() {
    _isGestureMode = !_isGestureMode;
    notifyListeners();
  }

  /// Set gesture mode
  void setGestureMode(bool enabled) {
    _isGestureMode = enabled;
    notifyListeners();
  }

  /// Find element at normalized position (0-1)
  UIElement? findElementAt(double normalizedX, double normalizedY) {
    return _uiScreen?.findElementAt(normalizedX, normalizedY);
  }

  /// Tap on an element
  Future<bool> tapElement(UIElement element) async {
    if (_deviceId == null) return false;

    logger.info('Tapping element', {'element': element.id});
    return await _automationService.tapElement(_deviceId!, element);
  }

  /// Tap at a specific normalized position
  Future<bool> tapAt(double normalizedX, double normalizedY) async {
    if (_deviceId == null || _uiScreen == null) return false;

    final x = (normalizedX * _uiScreen!.width).toInt();
    final y = (normalizedY * _uiScreen!.height).toInt();

    logger.info('Tapping at point', {'x': x, 'y': y});
    return await _automationService.tapAt(_deviceId!, x, y);
  }

  /// Swipe gesture
  Future<bool> swipe({
    required double startX,
    required double startY,
    required double endX,
    required double endY,
    int duration = 300,
  }) async {
    if (_deviceId == null || _uiScreen == null) return false;

    final screen = _uiScreen!;
    return await _automationService.swipe(
      _deviceId!,
      startX: (startX * screen.width).toInt(),
      startY: (startY * screen.height).toInt(),
      endX: (endX * screen.width).toInt(),
      endY: (endY * screen.height).toInt(),
      duration: duration,
    );
  }

  /// Input text
  Future<bool> inputText(String text) async {
    if (_deviceId == null) return false;
    return await _automationService.inputText(_deviceId!, text);
  }

  /// Press back button
  Future<bool> pressBack() async {
    if (_deviceId == null) return false;
    return await _automationService.pressBack(_deviceId!);
  }

  /// Generate command for the inspected element
  String? generateCommand({String? commandType}) {
    if (_inspectedElement == null) return null;

    switch (commandType) {
      case 'tap':
        return _inspectedElement!.generateTapCommand();
      case 'assert':
        return _inspectedElement!.generateAssertCommand();
      default:
        return _inspectedElement!.generateTapCommand();
    }
  }

  /// Get available devices
  Future<List<Map<String, dynamic>>> getAvailableDevices() async {
    return await _automationService.listDevices();
  }

  @override
  void dispose() {
    _stopScreenStream();
    super.dispose();
  }
}

/// Backwards compatibility alias
@Deprecated('Use UIAutomationProvider instead')
typedef DeviceInspectorProvider = UIAutomationProvider;

