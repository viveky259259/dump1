import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../core/logging/logging.dart';
import '../../domain/entities/widget_entity.dart';
import '../../core/logging/logging.dart';
import '../../domain/entities/test_entity.dart';
import '../../core/logging/logging.dart';
import '../../domain/usecases/generate_test_usecase.dart';
import '../../core/logging/logging.dart';
import '../../domain/usecases/manage_test_cases_usecase.dart';
import '../../core/logging/logging.dart';
import '../../core/di/service_locator.dart';
import '../../core/logging/logging.dart';

/// Controller for managing test generation operations
class TestGenerationController extends ChangeNotifier {
  final GenerateTestUseCase _generateTestUseCase;
  final ManageTestCasesUseCase _manageTestCasesUseCase;

  List<TestCase> _testCases = [];
  bool _isGenerating = false;
  String? _error;
  TestGenerationResult? _lastGenerationResult;

  TestGenerationController()
    : _generateTestUseCase = serviceLocator.get<GenerateTestUseCase>(),
      _manageTestCasesUseCase = serviceLocator.get<ManageTestCasesUseCase>();

  // Getters
  List<TestCase> get testCases => _testCases;
  bool get isGenerating => _isGenerating;
  String? get error => _error;
  bool get hasError => _error != null;
  TestGenerationResult? get lastGenerationResult => _lastGenerationResult;

  /// Generate test for a widget
  Future<void> generateTest(
    WidgetEntity widget,
    TestType testType, {
    Map<String, dynamic>? options,
    String? customPrompt,
  }) async {
    if (widget.objectId == null) {
      _setError('Widget must have an object ID');
      return;
    }

    _setGenerating(true);
    _clearError();

    try {
      final result = await _generateTestUseCase.execute(
        widget,
        testType,
        options: options,
        customPrompt: customPrompt,
      );

      _lastGenerationResult = result;

      if (result.success && result.testCase != null) {
        // Save the generated test case
        await _manageTestCasesUseCase.saveTestCase(result.testCase!);

        // Refresh test cases list
        await _loadTestCasesForWidget(widget.objectId!);
      } else {
        _setError(result.error ?? 'Test generation failed');
      }

      notifyListeners();
    } catch (e) {
      _setError('Failed to generate test: $e');
    } finally {
      _setGenerating(false);
    }
  }

  /// Generate test setup code
  Future<String> generateTestSetupCode(WidgetEntity widget) async {
    if (widget.objectId == null) {
      throw ArgumentError('Widget must have an object ID');
    }

    try {
      return await _generateTestUseCase.generateTestSetupCode(widget);
    } catch (e) {
      _setError('Failed to generate test setup code: $e');
      rethrow;
    }
  }

  /// Load test cases for a widget
  Future<void> loadTestCasesForWidget(String widgetId) async {
    try {
      _testCases = await _manageTestCasesUseCase.getTestCasesForWidget(
        widgetId,
      );
      notifyListeners();
    } catch (e) {
      _setError('Failed to load test cases: $e');
    }
  }

  /// Save test case
  Future<void> saveTestCase(TestCase testCase) async {
    try {
      await _manageTestCasesUseCase.saveTestCase(testCase);
      await _loadTestCasesForWidget(testCase.targetWidget.objectId ?? '');
      notifyListeners();
    } catch (e) {
      _setError('Failed to save test case: $e');
    }
  }

  /// Update test case
  Future<void> updateTestCase(TestCase testCase) async {
    try {
      await _manageTestCasesUseCase.updateTestCase(testCase);
      await _loadTestCasesForWidget(testCase.targetWidget.objectId ?? '');
      notifyListeners();
    } catch (e) {
      _setError('Failed to update test case: $e');
    }
  }

  /// Delete test case
  Future<void> deleteTestCase(String testCaseId) async {
    try {
      await _manageTestCasesUseCase.deleteTestCase(testCaseId);

      // Remove from local list
      _testCases.removeWhere((testCase) => testCase.id == testCaseId);
      notifyListeners();
    } catch (e) {
      _setError('Failed to delete test case: $e');
    }
  }

  /// Get test case by ID
  Future<TestCase?> getTestCase(String id) async {
    try {
      return await _manageTestCasesUseCase.getTestCase(id);
    } catch (e) {
      _setError('Failed to get test case: $e');
      return null;
    }
  }

  /// Clear test cases
  void clearTestCases() {
    _testCases = [];
    notifyListeners();
  }

  /// Clear error
  void _clearError() {
    _error = null;
  }

  /// Set error
  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  /// Set generating state
  void _setGenerating(bool generating) {
    _isGenerating = generating;
    notifyListeners();
  }

  /// Load test cases for widget (private helper)
  Future<void> _loadTestCasesForWidget(String widgetId) async {
    try {
      _testCases = await _manageTestCasesUseCase.getTestCasesForWidget(
        widgetId,
      );
    } catch (e) {
      _setError('Failed to load test cases: $e');
    }
  }
}
