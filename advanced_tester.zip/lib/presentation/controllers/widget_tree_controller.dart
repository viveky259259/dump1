import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../domain/entities/widget_entity.dart';
import '../../domain/usecases/get_widget_tree_usecase.dart';
import '../../domain/usecases/get_widget_properties_usecase.dart';
import '../../domain/usecases/select_widget_usecase.dart';
import '../../core/di/service_locator.dart';

/// Controller for managing widget tree operations
class WidgetTreeController extends ChangeNotifier {
  final GetWidgetTreeUseCase _getWidgetTreeUseCase;
  final GetWidgetPropertiesUseCase _getWidgetPropertiesUseCase;
  final SelectWidgetUseCase _selectWidgetUseCase;

  WidgetEntity? _rootWidget;
  WidgetEntity? _selectedWidget;
  List<WidgetAttribute> _selectedWidgetProperties = [];
  bool _isLoading = false;
  String? _error;
  StreamSubscription? _connectionSubscription;

  WidgetTreeController()
    : _getWidgetTreeUseCase = serviceLocator.get<GetWidgetTreeUseCase>(),
      _getWidgetPropertiesUseCase = serviceLocator
          .get<GetWidgetPropertiesUseCase>(),
      _selectWidgetUseCase = serviceLocator.get<SelectWidgetUseCase>();

  // Getters
  WidgetEntity? get rootWidget => _rootWidget;
  WidgetEntity? get selectedWidget => _selectedWidget;
  List<WidgetAttribute> get selectedWidgetProperties =>
      _selectedWidgetProperties;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get hasError => _error != null;

  /// Load the widget tree
  Future<void> loadWidgetTree() async {
    _setLoading(true);
    _clearError();

    try {
      _rootWidget = await _getWidgetTreeUseCase.execute();
      notifyListeners();
    } catch (e) {
      _setError('Failed to load widget tree: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Select a widget
  Future<void> selectWidget(WidgetEntity widget) async {
    if (widget.objectId == null) return;

    _setLoading(true);
    _clearError();

    try {
      // Select widget in inspector
      await _selectWidgetUseCase.execute(widget.objectId!);

      // Update selected widget
      _selectedWidget = widget;

      // Load widget properties
      await _loadWidgetProperties(widget.objectId!);

      notifyListeners();
    } catch (e) {
      _setError('Failed to select widget: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Load properties for a widget
  Future<void> _loadWidgetProperties(String objectId) async {
    try {
      final properties = await _getWidgetPropertiesUseCase.execute(objectId);
      _selectedWidgetProperties = properties ?? [];
    } catch (e) {
      _selectedWidgetProperties = [];
      _setError('Failed to load widget properties: $e');
    }
  }

  /// Clear selection
  void clearSelection() {
    _selectedWidget = null;
    _selectedWidgetProperties = [];
    notifyListeners();
  }

  /// Refresh widget tree
  Future<void> refresh() async {
    await loadWidgetTree();
  }

  /// Clear error
  void _clearError() {
    _error = null;
  }

  /// Set error
  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  /// Set loading state
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  @override
  void dispose() {
    _connectionSubscription?.cancel();
    super.dispose();
  }
}
