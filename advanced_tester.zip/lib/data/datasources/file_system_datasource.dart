import 'dart:io';
import 'dart:math' as math;

/// Data source for file system operations
class FileSystemDataSource  {
  /// Read file content
  Future<String?> readFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        return await file.readAsString();
      }
      return null;
    } catch (e) {
      throw FileSystemException('Failed to read file: $e');
    }
  }

  /// Write file content
  Future<void> writeFile(String filePath, String content) async {
    try {
      final file = File(filePath);
      await file.writeAsString(content);
    } catch (e) {
      throw FileSystemException('Failed to write file: $e');
    }
  }

  /// Check if file exists
  Future<bool> fileExists(String filePath) async {
    try {
      final file = File(filePath);
      return await file.exists();
    } catch (e) {
      return false;
    }
  }

  /// Get file content at specific location
  Future<String?> getFileContentAtLocation(
    String filePath,
    int startLine,
    int endLine, {
    int contextLines = 5,
  }) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return null;

      final content = await file.readAsString();
      final lines = content.split('\n');

      final adjustedStartLine = math.max(0, startLine - contextLines);
      final adjustedEndLine = math.min(endLine + contextLines, lines.length);

      if (adjustedStartLine < lines.length) {
        return lines.sublist(adjustedStartLine, adjustedEndLine).join('\n');
      }
      return null;
    } catch (e) {
      throw FileSystemException('Failed to get file content at location: $e');
    }
  }

  /// Find required imports from a Dart file
  Future<List<String>> findRequiredImports(String filePath) async {
    try {
      final content = await readFile(filePath);
      if (content == null) return [];

      final imports = <String>[];
      final importPattern = RegExp(r'import\s+.([^.]+).');
      final matches = importPattern.allMatches(content);

      for (final match in matches) {
        final importPath = match.group(1);
        if (importPath != null) {
          imports.add(importPath);
        }
      }

      return imports;
    } catch (e) {
      throw FileSystemException('Failed to find imports: $e');
    }
  }

  /// Analyze source code structure
  Future<SourceCodeAnalysisResult> analyzeSourceCode(String filePath) async {
    try {
      final content = await readFile(filePath);
      if (content == null) {
        throw FileSystemException('File not found: $filePath');
      }

      final startTime = DateTime.now();
      final imports = await findRequiredImports(filePath);

      // Extract classes
      final classes = <String>[];
      final classPattern = RegExp(r'class\s+(\w+)');
      final classMatches = classPattern.allMatches(content);
      for (final match in classMatches) {
        final className = match.group(1);
        if (className != null) {
          classes.add(className);
        }
      }

      // Extract functions
      final functions = <String>[];
      final functionPattern = RegExp(
        r'(?:void|Future|String|int|double|bool|Widget)\s+(\w+)\s*\(',
      );
      final functionMatches = functionPattern.allMatches(content);
      for (final match in functionMatches) {
        final functionName = match.group(1);
        if (functionName != null) {
          functions.add(functionName);
        }
      }

      final analysisTime = DateTime.now().difference(startTime);

      return SourceCodeAnalysisResult(
        filePath: filePath,
        imports: imports,
        classes: classes,
        functions: functions,
        metadata: {
          'lineCount': content.split('\n').length,
          'characterCount': content.length,
        },
        analysisTime: analysisTime,
      );
    } catch (e) {
      throw FileSystemException('Failed to analyze source code: $e');
    }
  }

  /// Create directory if it doesn't exist
  Future<void> createDirectoryIfNotExists(String dirPath) async {
    try {
      final directory = Directory(dirPath);
      if (!await directory.exists()) {
        await directory.create(recursive: true);
      }
    } catch (e) {
      throw FileSystemException('Failed to create directory: $e');
    }
  }

  /// List files in directory
  Future<List<String>> listFiles(String dirPath, {String? extension}) async {
    try {
      final directory = Directory(dirPath);
      if (!await directory.exists()) return [];

      final files = <String>[];
      await for (final entity in directory.list()) {
        if (entity is File) {
          if (extension == null || entity.path.endsWith(extension)) {
            files.add(entity.path);
          }
        }
      }
      return files;
    } catch (e) {
      throw FileSystemException('Failed to list files: $e');
    }
  }
}

/// Source code analysis result
class SourceCodeAnalysisResult {
  final String filePath;
  final List<String> imports;
  final List<String> classes;
  final List<String> functions;
  final Map<String, dynamic> metadata;
  final Duration analysisTime;

  const SourceCodeAnalysisResult({
    required this.filePath,
    required this.imports,
    required this.classes,
    required this.functions,
    this.metadata = const {},
    required this.analysisTime,
  });

  @override
  String toString() =>
      'SourceCodeAnalysisResult($filePath, ${classes.length} classes)';
}

/// File system exception
class FileSystemException implements Exception {
  final String message;

  const FileSystemException(this.message);

  @override
  String toString() => 'FileSystemException: $message';
}
