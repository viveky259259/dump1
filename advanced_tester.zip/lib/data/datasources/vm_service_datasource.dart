import 'dart:async';
import 'package:vm_service/vm_service.dart' as vm;
import 'package:vm_service/vm_service_io.dart' as vm_io;

/// Data source for VM Service operations
class VmServiceDataSource  {
  final Uri vmServiceUri;
  vm.VmService? _service;
  String? _currentObjectGroup;
  int _objectGroupCounter = 0;
  bool _isConnected = false;

  VmServiceDataSource(this.vmServiceUri);

  /// Connect to VM service
  Future<void> connect() async {
    try {
      final wsUri = _toWsUri(vmServiceUri);
      _service = await vm_io.vmServiceConnectUri(wsUri);
      _isConnected = true;

      // Wait for service extensions to be available
      await Future.delayed(const Duration(seconds: 2));
      await _initializeInspector();
    } catch (e) {
      _isConnected = false;
      rethrow;
    }
  }

  /// Disconnect from VM service
  Future<void> disconnect() async {
    if (_currentObjectGroup != null) {
      try {
        await invokeInspector(method: 'disposeGroup');
      } catch (e) {
        // Ignore disposal errors
      }
      _currentObjectGroup = null;
    }

    _service?.dispose();
    _service = null;
    _isConnected = false;
  }

  /// Check if connected
  bool get isConnected => _isConnected && _service != null;

  /// Get VM instance
  Future<vm.VM> getVM() async {
    if (!isConnected) throw StateError('Not connected to VM service');
    return _service!.getVM();
  }

  /// Get first Flutter isolate ID
  Future<String?> getFirstFlutterIsolateId() async {
    final vmResult = await getVM();
    for (final isolateRef in vmResult.isolates ?? <vm.IsolateRef>[]) {
      if (isolateRef.name?.toLowerCase().contains('main') == true) {
        return isolateRef.id;
      }
    }
    return vmResult.isolates?.firstOrNull?.id;
  }

  /// Invoke inspector method
  Future<vm.Response?> invokeInspector({
    required String method,
    Map<String, Object?>? args,
  }) async {
    if (!isConnected) throw StateError('Not connected to VM service');

    final isolateId = await getFirstFlutterIsolateId();
    if (isolateId == null) {
      throw StateError('No isolate ID available');
    }

    return await _service!.callServiceExtension(
      'ext.flutter.inspector.$method',
      isolateId: isolateId,
      args: args,
    );
  }

  /// Check if inspector is available
  Future<bool> isInspectorAvailable() async {
    try {
      await getVM();
      final isolateId = await getFirstFlutterIsolateId();
      if (isolateId == null) return false;

      final isolate = await _service!.getIsolate(isolateId);
      final extensions = isolate.extensionRPCs ?? [];

      final hasInspectorExtensions = extensions.any(
        (ext) => ext.startsWith('ext.flutter.inspector'),
      );

      if (!hasInspectorExtensions) return false;

      final response = await invokeInspector(method: 'isWidgetTreeReady');
      final result = (response?.json as Map)['result'];
      return result == true;
    } catch (e) {
      return false;
    }
  }

  String _toWsUri(Uri uri) {
    if (uri.scheme.startsWith('ws')) return uri.toString();
    return uri.replace(scheme: uri.scheme == 'https' ? 'wss' : 'ws').toString();
  }

  Future<void> _initializeInspector() async {
    try {
      await invokeInspector(
        method: 'setPubRootDirectories',
        args: {'objectGroup': _getObjectGroup()},
      );
    } catch (e) {
      // Don't rethrow - inspector can still work without this initialization
    }
  }

  String _getObjectGroup() {
    _currentObjectGroup ??= 'inspector_${_objectGroupCounter++}';
    return _currentObjectGroup!;
  }
}
