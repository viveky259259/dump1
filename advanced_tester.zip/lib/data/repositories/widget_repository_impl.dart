import '../../domain/entities/widget_entity.dart';
import '../../core/logging/logging.dart';
import '../../domain/repositories/widget_repository.dart';
import '../../core/logging/logging.dart';
import '../datasources/vm_service_datasource.dart';
import '../../core/logging/logging.dart';
import '../datasources/file_system_datasource.dart' as fs;
import '../mappers/widget_mapper.dart';
import '../../core/logging/logging.dart';

/// Implementation of WidgetRepository
class WidgetRepositoryImpl  implements WidgetRepository {
  final VmServiceDataSource _vmDataSource;
  final fs.FileSystemDataSource _fileDataSource;
  final WidgetMapper _mapper;

  // Caching
  final Map<String, WidgetEntity> _widgetCache = {};
  final Map<String, List<WidgetAttribute>> _propertiesCache = {};
  final Map<String, DateTime> _cacheTimestamps = {};
  final Duration _cacheExpiry = const Duration(minutes: 5);

  WidgetRepositoryImpl(this._vmDataSource, this._fileDataSource, this._mapper);

  @override
  Future<void> connect() async {
    await _vmDataSource.connect();
  }

  @override
  Future<void> disconnect() async {
    await _vmDataSource.disconnect();
    clearCache();
  }

  @override
  bool get isConnected => _vmDataSource.isConnected;

  @override
  Future<WidgetEntity?> getRootWidgetTree() async {
    if (!isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    const cacheKey = 'root_widget_tree';

    // Check cache first
    if (_isCacheValid(cacheKey)) {
      return _widgetCache[cacheKey];
    }

    try {
      final response = await _vmDataSource.invokeInspector(
        method: 'getRootWidgetSummaryTree',
        args: {'objectGroup': _getObjectGroup(), 'maxDescendents': 100000},
      );

      if (response?.json == null) return null;

      final json = response!.json!;
      final resultJson = json['result'] as Map<String, dynamic>?;
      if (resultJson == null) return null;

      final rootNode = _mapper.mapToEntity(resultJson);

      // Cache the result
      _widgetCache[cacheKey] = rootNode;
      _cacheTimestamps[cacheKey] = DateTime.now();

      return rootNode;
    } catch (e) {
      throw WidgetRepositoryException('Failed to get widget tree: $e');
    }
  }

  @override
  Future<List<WidgetAttribute>?> getWidgetProperties(String objectId) async {
    if (!isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    // Check cache first
    if (_isCacheValid(objectId)) {
      return _propertiesCache[objectId];
    }

    try {
      final response = await _vmDataSource.invokeInspector(
        method: 'getProperties',
        args: {'objectGroup': _getObjectGroup(), 'arg': objectId},
      );

      if (response?.json == null) return null;

      final result = response!.json!['result'];
      if (result is List) {
        final properties = result.cast<Map<String, dynamic>>();
        final attributes = _mapper.mapToAttributes(properties);

        // Cache the result
        _propertiesCache[objectId] = attributes;
        _cacheTimestamps[objectId] = DateTime.now();

        return attributes;
      }
      return null;
    } catch (e) {
      throw WidgetRepositoryException('Failed to get widget properties: $e');
    }
  }

  @override
  Future<List<WidgetEntity>> getWidgetChildren(String objectId) async {
    if (!isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    try {
      final response = await _vmDataSource.invokeInspector(
        method: 'getChildren',
        args: {'objectGroup': _getObjectGroup(), 'arg': objectId},
      );

      if (response?.json == null) return [];

      final json = response!.json!;
      return (json as List<dynamic>)
          .map((e) => _mapper.mapToEntity(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      throw WidgetRepositoryException('Failed to get widget children: $e');
    }
  }

  @override
  Future<void> selectWidget(String objectId) async {
    if (!isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    try {
      await _vmDataSource.invokeInspector(
        method: 'setSelectionById',
        args: {'objectGroup': _getObjectGroup(), 'arg': objectId},
      );
    } catch (e) {
      throw WidgetRepositoryException('Failed to select widget: $e');
    }
  }

  @override
  Future<WidgetEntity?> getSelectedWidget() async {
    if (!isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    try {
      final response = await _vmDataSource.invokeInspector(
        method: 'getSelectedSummaryWidget',
        args: {'objectGroup': _getObjectGroup(), 'arg': null},
      );

      if (response?.json == null) return null;

      final json = response!.json!;
      return _mapper.mapToEntity(json);
    } catch (e) {
      throw WidgetRepositoryException('Failed to get selected widget: $e');
    }
  }

  @override
  Future<bool> isInspectorAvailable() async {
    return await _vmDataSource.isInspectorAvailable();
  }

  @override
  void clearCache() {
    _widgetCache.clear();
    _propertiesCache.clear();
    _cacheTimestamps.clear();
  }

  @override
  Future<SourceLocation?> getWidgetSourceLocation(String objectId) async {
    if (!isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    try {
      // Get the root widget tree to find the widget
      final rootWidget = await getRootWidgetTree();
      if (rootWidget == null) return null;

      // Find the widget in the tree
      final widgetNode = _findWidgetInTree(rootWidget, objectId);
      if (widgetNode == null) return null;

      // Use the creationLocation from the widget node
      final creationLocation = widgetNode.creationLocation;
      if (creationLocation == null) return null;

      return SourceLocation(
        file: creationLocation.file,
        line: creationLocation.line,
        column: creationLocation.column,
      );
    } catch (e) {
      throw WidgetRepositoryException(
        'Failed to get widget source location: $e',
      );
    }
  }

  @override
  Future<String?> getWidgetSourceCode(SourceLocation location) async {
    try {
      return await _fileDataSource.getFileContentAtLocation(
        location.file,
        location.line,
        location.endLine ?? location.line + 20,
      );
    } catch (e) {
      throw WidgetRepositoryException('Failed to get widget source code: $e');
    }
  }

  bool _isCacheValid(String key) {
    final timestamp = _cacheTimestamps[key];
    if (timestamp == null) return false;
    return DateTime.now().difference(timestamp) < _cacheExpiry;
  }

  String _getObjectGroup() {
    return 'inspector_${DateTime.now().millisecondsSinceEpoch}';
  }

  WidgetEntity? _findWidgetInTree(WidgetEntity root, String objectId) {
    if (root.objectId == objectId) {
      return root;
    }

    for (final child in root.children) {
      final found = _findWidgetInTree(child, objectId);
      if (found != null) {
        return found;
      }
    }

    return null;
  }
}

/// Widget repository exception
class WidgetRepositoryException implements Exception {
  final String message;

  const WidgetRepositoryException(this.message);

  @override
  String toString() => 'WidgetRepositoryException: $message';
}
