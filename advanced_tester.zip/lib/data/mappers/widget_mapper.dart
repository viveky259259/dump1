import '../../domain/entities/widget_entity.dart';
import '../../core/logging/logging.dart';

/// Mapper for converting between data models and domain entities
class WidgetMapper {
  /// Map JSON data to WidgetEntity
  WidgetEntity mapToEntity(Map<String, dynamic> json) {
    // Parse creation location if available
    CreationLocation? creationLocation;
    if (json['creationLocation'] != null) {
      final locationJson = json['creationLocation'] as Map<String, dynamic>;
      creationLocation = CreationLocation(
        file: locationJson['file'] as String? ?? '',
        line: locationJson['line'] as int? ?? 0,
        column: locationJson['column'] as int? ?? 0,
        name: locationJson['name'] as String? ?? '',
      );
    }

    // Parse attributes if available
    List<WidgetAttribute>? attributes;
    if (json['attributes'] != null) {
      attributes = (json['attributes'] as List<dynamic>).map((attr) {
        final attrJson = attr as Map<String, dynamic>;
        return WidgetAttribute(
          name: attrJson['name'] as String? ?? '',
          label: attrJson['label'] as String? ?? '',
          type: attrJson['type'] as String?,
          value: attrJson['value'],
        );
      }).toList();
    }

    return WidgetEntity(
      description: json['description'] as String?,
      type: json['type'] as String?,
      objectId: json['valueId'] as String?, // Map valueId to objectId
      style: json['style'] as String?,
      hasChildren: json['hasChildren'] as bool? ?? false,
      allowWrap: json['allowWrap'] as bool? ?? false,
      summaryTree: json['summaryTree'] as bool? ?? false,
      locationId: json['locationId'] as int?,
      creationLocation: creationLocation,
      createdByLocalProject: json['createdByLocalProject'] as bool?,
      widgetRuntimeType: json['widgetRuntimeType'] as String?,
      stateful: json['stateful'] as bool?,
      properties: json['properties'] as Map<String, dynamic>?,
      attributes: attributes,
      children:
          (json['children'] as List<dynamic>?)
              ?.map((e) => mapToEntity(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  /// Map properties to WidgetAttribute list
  List<WidgetAttribute> mapToAttributes(List<Map<String, dynamic>> properties) {
    final attributes = <WidgetAttribute>[];

    // Convert the DevTools diagnostic format to a flat map for easier processing
    final flatProperties = <String, dynamic>{};
    for (final prop in properties) {
      final name = prop['name'] as String?;
      final value = prop['value'];
      final description = prop['description'];

      if (name != null) {
        // Use the actual value if available, otherwise use description
        flatProperties[name] = value ?? description;
      }
    }

    // Extract common properties
    _extractCommonProperties(flatProperties, attributes);

    return attributes;
  }

  /// Extract common properties from flat properties map
  void _extractCommonProperties(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Common property names to extract
    final commonProps = ['data', 'text', 'value', 'title', 'tooltip', 'label'];

    for (final prop in commonProps) {
      final value = _getNestedProperty(properties, prop);
      if (value != null && value.toString().isNotEmpty) {
        attributes.add(
          WidgetAttribute(
            name: prop,
            label: "'$value'",
            type: 'String',
            value: value,
          ),
        );
      }
    }

    // Extract dimension properties
    _extractDimensionProperties(properties, attributes);

    // Extract style properties
    _extractStyleProperties(properties, attributes);
  }

  /// Extract dimension properties (width, height, etc.)
  void _extractDimensionProperties(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final dimensionProps = ['width', 'height', 'size'];

    for (final prop in dimensionProps) {
      final value = _getNestedProperty(properties, prop);
      if (value != null) {
        attributes.add(
          WidgetAttribute(
            name: prop,
            label: _formatDimensionValue(value),
            type: 'double',
            value: value,
          ),
        );
      }
    }
  }

  /// Extract style properties (color, padding, etc.)
  void _extractStyleProperties(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final styleProps = ['color', 'padding', 'margin', 'decoration'];

    for (final prop in styleProps) {
      final value = _getNestedProperty(properties, prop);
      if (value != null) {
        String label = value.toString();
        String type = 'dynamic';

        if (prop == 'color') {
          label = _formatColorValue(value);
          type = 'Color';
        } else if (prop == 'padding' || prop == 'margin') {
          label = _formatPaddingValue(value);
          type = 'EdgeInsets';
        }

        attributes.add(
          WidgetAttribute(name: prop, label: label, type: type, value: value),
        );
      }
    }
  }

  /// Get nested property from a map using dot notation
  dynamic _getNestedProperty(Map<String, dynamic> properties, String path) {
    final parts = path.split('.');
    dynamic current = properties;

    for (final part in parts) {
      if (current is Map<String, dynamic> && current.containsKey(part)) {
        current = current[part];
      } else {
        return null;
      }
    }

    return current;
  }

  /// Format dimension values
  String _formatDimensionValue(dynamic value) {
    if (value == null) return 'null';
    if (value is double) {
      if (value == double.infinity) return 'double.infinity';
      if (value == double.negativeInfinity) return 'double.negativeInfinity';
      return value.toStringAsFixed(1);
    }
    if (value is int) return value.toString();
    return value.toString();
  }

  /// Format color values
  String _formatColorValue(dynamic color) {
    if (color == null) return 'null';
    final colorStr = color.toString();

    // Extract color value if it's in Color(0xXXXXXXXX) format
    final colorMatch = RegExp(
      r'Color\(0x([0-9a-fA-F]+)\)',
    ).firstMatch(colorStr);
    if (colorMatch != null) {
      return 'Color(0x${colorMatch.group(1)})';
    }

    return colorStr;
  }

  /// Format padding/margin values
  String _formatPaddingValue(dynamic padding) {
    if (padding == null) return 'null';
    final paddingStr = padding.toString();

    // Common EdgeInsets patterns
    if (paddingStr.contains('EdgeInsets.all')) {
      final allMatch = RegExp(r'all\(([^)]+)\)').firstMatch(paddingStr);
      if (allMatch != null) {
        return 'EdgeInsets.all(${allMatch.group(1)})';
      }
    } else if (paddingStr.contains('EdgeInsets.only')) {
      return paddingStr;
    } else if (paddingStr.contains('EdgeInsets.symmetric')) {
      return paddingStr;
    }

    return paddingStr;
  }
}
