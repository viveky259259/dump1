import 'package:flutter/material.dart';

import '../../domain/entities/ui_element.dart';
import '../../services/device_service.dart';
import '../widgets/device_preview_panel.dart';
import '../widgets/ios_simulator_panel.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _showActiveOnly = false;
  List<DeviceInfo> _flutterDevices = [];
  bool _isLoadingFlutterDevices = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadFlutterDevices();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadFlutterDevices() async {
    setState(() => _isLoadingFlutterDevices = true);
    try {
      final devices = await DeviceService().getAvailableDevices();
      setState(() {
        _flutterDevices = devices;
        _isLoadingFlutterDevices = false;
      });
    } catch (e) {
      setState(() => _isLoadingFlutterDevices = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Device Preview & Settings'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.devices), text: 'All Devices'),
            Tab(icon: Icon(Icons.phone_iphone), text: 'iOS'),
            Tab(icon: Icon(Icons.phone_android), text: 'Android'),
            Tab(icon: Icon(Icons.language), text: 'Web'),
          ],
        ),
        actions: [
          // Active devices filter toggle
          Tooltip(
            message: 'Show only active/running devices',
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Active only',
                  style: TextStyle(
                    fontSize: 12,
                    color: colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
                Switch(
                  value: _showActiveOnly,
                  onChanged: (value) {
                    setState(() => _showActiveOnly = value);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          // Flutter devices summary bar
          _buildFlutterDevicesBar(colorScheme),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // All Devices tab
                _buildAllDevicesTab(),
                // iOS tab
                _buildPlatformTab(UIPlatform.ios),
                // Android tab
                _buildPlatformTab(UIPlatform.android),
                // Web tab
                _buildPlatformTab(UIPlatform.web),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFlutterDevicesBar(ColorScheme colorScheme) {
    final iosCount = _flutterDevices
        .where((d) => d.platform.toLowerCase().contains('ios'))
        .length;
    final androidCount = _flutterDevices
        .where((d) => d.platform.toLowerCase().contains('android'))
        .length;
    final webCount = _flutterDevices
        .where((d) =>
            d.platform.toLowerCase().contains('web') ||
            d.deviceId.toLowerCase() == 'chrome')
        .length;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withOpacity(0.5),
        border: Border(
          bottom: BorderSide(color: colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, size: 18, color: colorScheme.primary),
          const SizedBox(width: 12),
          Text(
            'Flutter Devices: ',
            style: TextStyle(
              fontWeight: FontWeight.w500,
              color: colorScheme.onSurface,
            ),
          ),
          _buildDeviceChip('iOS', iosCount, Icons.phone_iphone, colorScheme),
          const SizedBox(width: 8),
          _buildDeviceChip('Android', androidCount, Icons.phone_android, colorScheme),
          const SizedBox(width: 8),
          _buildDeviceChip('Web', webCount, Icons.language, colorScheme),
          const Spacer(),
          TextButton.icon(
            onPressed: _isLoadingFlutterDevices ? null : _loadFlutterDevices,
            icon: _isLoadingFlutterDevices
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh, size: 16),
            label: const Text('Refresh'),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceChip(
    String label,
    int count,
    IconData icon,
    ColorScheme colorScheme,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: count > 0
            ? colorScheme.primaryContainer
            : colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: count > 0
                ? colorScheme.onPrimaryContainer
                : colorScheme.onSurfaceVariant,
          ),
          const SizedBox(width: 4),
          Text(
            '$label: $count',
            style: TextStyle(
              fontSize: 12,
              fontWeight: count > 0 ? FontWeight.w600 : FontWeight.normal,
              color: count > 0
                  ? colorScheme.onPrimaryContainer
                  : colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAllDevicesTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Available Devices',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Select a device to start live preview. Active devices are highlighted.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: DevicePreviewPanel(
                showManualControls: true,
                showDeviceSelector: true,
                activeDevicesOnly: _showActiveOnly,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlatformTab(UIPlatform platform) {
    final platformName = platform == UIPlatform.ios
        ? 'iOS'
        : platform == UIPlatform.android
            ? 'Android'
            : 'Web';
    final platformIcon = platform == UIPlatform.ios
        ? Icons.phone_iphone
        : platform == UIPlatform.android
            ? Icons.phone_android
            : Icons.language;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(platformIcon, size: 20),
              const SizedBox(width: 8),
              Text(
                '$platformName Device Preview',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _getPlatformDescription(platform),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: platform == UIPlatform.ios
                  ? const IosSimulatorPanel(showManualControls: true)
                  : DevicePreviewPanel(
                      platformFilter: {platform},
                      showManualControls: true,
                      showDeviceSelector: true,
                      activeDevicesOnly: _showActiveOnly,
                    ),
            ),
          ),
        ],
      ),
    );
  }

  String _getPlatformDescription(UIPlatform platform) {
    switch (platform) {
      case UIPlatform.ios:
        return 'Connect to iOS simulators for live preview. '
            'Requires Xcode and iOS Simulator to be installed.';
      case UIPlatform.android:
        return 'Connect to Android emulators or physical devices. '
            'Requires Android Studio and ADB to be configured.';
      case UIPlatform.web:
        return 'Preview web applications in Chromium browser. '
            'Requires Maestro with web support enabled.';
      default:
        return 'Select a device to start live preview.';
    }
  }
}

/// Widget showing active Flutter devices with quick actions
class FlutterDevicesWidget extends StatefulWidget {
  final bool compactMode;
  final void Function(DeviceInfo device)? onDeviceSelected;

  const FlutterDevicesWidget({
    super.key,
    this.compactMode = false,
    this.onDeviceSelected,
  });

  @override
  State<FlutterDevicesWidget> createState() => _FlutterDevicesWidgetState();
}

class _FlutterDevicesWidgetState extends State<FlutterDevicesWidget> {
  List<DeviceInfo> _devices = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    setState(() => _isLoading = true);
    try {
      final devices = await DeviceService().getAvailableDevices();
      setState(() {
        _devices = devices;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_devices.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.devices_other, size: 48, color: Colors.grey),
            const SizedBox(height: 16),
            const Text('No devices found'),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: _loadDevices,
              icon: const Icon(Icons.refresh),
              label: const Text('Refresh'),
            ),
          ],
        ),
      );
    }

    return widget.compactMode
        ? _buildCompactList()
        : _buildDetailedList();
  }

  Widget _buildCompactList() {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: _devices.length,
      itemBuilder: (context, index) {
        final device = _devices[index];
        return ListTile(
          dense: true,
          leading: Icon(_getDeviceIcon(device.platform)),
          title: Text(device.name),
          subtitle: Text(device.deviceId),
          onTap: () => widget.onDeviceSelected?.call(device),
        );
      },
    );
  }

  Widget _buildDetailedList() {
    return ListView.builder(
      itemCount: _devices.length,
      itemBuilder: (context, index) {
        final device = _devices[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              child: Icon(_getDeviceIcon(device.platform)),
            ),
            title: Text(device.name),
            subtitle: Text('${device.deviceId}\n${device.description}'),
            isThreeLine: true,
            trailing: IconButton(
              icon: const Icon(Icons.play_arrow),
              onPressed: () => widget.onDeviceSelected?.call(device),
              tooltip: 'Connect to device',
            ),
          ),
        );
      },
    );
  }

  IconData _getDeviceIcon(String platform) {
    final p = platform.toLowerCase();
    if (p.contains('ios')) return Icons.phone_iphone;
    if (p.contains('android')) return Icons.phone_android;
    if (p.contains('web')) return Icons.language;
    if (p.contains('macos')) return Icons.desktop_mac;
    if (p.contains('windows')) return Icons.desktop_windows;
    if (p.contains('linux')) return Icons.computer;
    return Icons.devices;
  }
}
