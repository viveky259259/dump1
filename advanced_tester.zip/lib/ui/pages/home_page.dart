import 'dart:io';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:multi_split_view/multi_split_view.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../../presentation/providers/app_provider.dart';
import '../widgets/toolbar.dart';
import '../../services/sync_service.dart';
import '../widgets/widget_tree_panel.dart';
import '../widgets/dependency_analysis_panel.dart';
import '../widgets/enhanced_widget_details_panel.dart';
import '../../services/prefs_service.dart';
import '../../services/app_runner.dart';
import '../widgets/ios_simulator_panel.dart';
import '../widgets/device_inspector/device_inspector_widgets.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  final bool isDemoMode;

  const HomePage({super.key, this.isDemoMode = false});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _testController = TextEditingController();
  final PrefsService _prefs = PrefsService();
  final ScrollController _consoleScrollController = ScrollController();

  @override
  void dispose() {
    _testController.dispose();
    _consoleScrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_consoleScrollController.hasClients) {
      _consoleScrollController.animateTo(
        _consoleScrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final appProvider = context.read<AppProvider>();

      if (widget.isDemoMode) {
        // In demo mode, automatically start the web app
        appProvider.addConsoleMessage('Demo mode activated', type: 'info');
        appProvider.addConsoleMessage(
          'Starting test_flutter_project...',
          type: 'info',
        );

        // Add a small delay to let the UI settle
        await Future.delayed(const Duration(milliseconds: 500));

        try {
          await AppRunner.run(appProvider);
          appProvider.addConsoleMessage(
            'Demo app started successfully',
            type: 'info',
          );
        } catch (e) {
          appProvider.addConsoleMessage(
            'Failed to start demo app: $e',
            type: 'error',
          );
        }
      } else {
        // Normal mode - check for last project
        final lastProject = await _prefs.getLastProjectPath();
        final lastSdk = await _prefs.getLastFlutterSdkPath();
        if (!mounted) return;
        if (lastProject != null) {
          _promptReopen(lastProject, lastSdk);
        }
      }

      // Add some test console messages
      appProvider.addConsoleMessage('Advanced Tester started', type: 'info');
      appProvider.addConsoleMessage(
        'Console output ready for debugging',
        type: 'log',
      );
      if (!widget.isDemoMode) {
        appProvider.addConsoleMessage('Test warning message', type: 'warning');
        appProvider.addConsoleMessage('Test error message', type: 'error');
      }
    });
  }

  Future<void> _promptReopen(String project, String? sdk) async {
    if (!mounted) return;
    final appProvider = context.read<AppProvider>();
    final choice = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Reopen last project?'),
          content: Text(project),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('No'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Yes'),
            ),
          ],
        );
      },
    );
    if (choice == true) {
      appProvider.setSelectedProjectPath(project);
      if (sdk != null) appProvider.setFlutterSdkDir(sdk);
    }
  }

  Future<void> _selectProject(BuildContext context) async {
    final appProvider = context.read<AppProvider>();
    final directory = await getDirectoryPath(confirmButtonText: 'Select');
    if (directory == null) return;
    // Basic validation: must contain pubspec.yaml
    final pubspec = File(p.join(directory, 'pubspec.yaml'));
    if (!await pubspec.exists()) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Not a Flutter project (pubspec.yaml missing)'),
          ),
        );
      }
      return;
    }
    appProvider.setSelectedProjectPath(directory);
    await _prefs.saveLastProjectPath(directory);
  }

  Future<void> _selectFlutterSdk(BuildContext context) async {
    final appProvider = context.read<AppProvider>();
    final directory = await getDirectoryPath(confirmButtonText: 'Use SDK');
    if (directory == null) return;
    // basic check: directory/bin/flutter exists
    final flutterBin = File(p.join(directory, 'bin', 'flutter'));
    if (!await flutterBin.exists()) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Invalid Flutter SDK path (bin/flutter missing)'),
          ),
        );
      }
      return;
    }
    appProvider.setFlutterSdkDir(directory);
    await _prefs.saveLastFlutterSdkPath(directory);
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = context.watch<AppProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Advanced Tester'),
        actions: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8.0),
            child: Center(child: ControlToolbar()),
          ),
          const VerticalDivider(width: 1),
          TextButton.icon(
            onPressed: () => _selectProject(context),
            icon: const Icon(Icons.folder_open),
            label: const Text('Select Project'),
          ),
          TextButton.icon(
            onPressed: () => _selectFlutterSdk(context),
            icon: const Icon(Icons.bolt),
            label: const Text('Flutter SDK'),
          ),
          IconButton(
            onPressed: () => appProvider.toggleConsoleVisibility(),
            icon: Icon(
              appProvider.showConsole
                  ? Icons.terminal
                  : Icons.terminal_outlined,
            ),
            tooltip: appProvider.showConsole ? 'Hide Console' : 'Show Console',
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const SettingsPage()),
              );
            },
            icon: const Icon(Icons.settings),
            tooltip: 'Settings',
          ),
        ],
      ),
      body: MultiSplitView(
        axis: Axis.horizontal,
        initialAreas: [
          Area(
            builder: (context, area) => _buildLeftPanel(appProvider),
            size: 320,
          ),
          Area(builder: (context, area) => _buildRightPanel(appProvider)),
        ],
      ),
    );
  }

  Widget _buildLeftPanel(AppProvider appProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          title: const Text('Project'),
          subtitle: Text(appProvider.selectedProjectPath ?? 'None'),
        ),
        const Divider(),
        const Expanded(child: WidgetTreePanel()),
      ],
    );
  }

  Widget _buildRightPanel(AppProvider appProvider) {
    final showDeviceView = _shouldShowRunningDeviceView(appProvider);
    final areas = <Area>[];

    if (showDeviceView) {
      areas.add(
        Area(
          builder: (context, area) => _buildIosPreviewCard(),
          size: 320,
        ),
      );
    }

    areas.add(
      Area(
        builder: (context, area) => _buildTestEditor(appProvider),
        size: appProvider.showConsole ? 300 : 360,
      ),
    );

    if (appProvider.showConsole) {
      areas.add(
        Area(
          builder: (context, area) => _buildConsolePanel(appProvider),
          size: 200,
        ),
      );
    }

    return MultiSplitView(
      key: ValueKey(
        '${showDeviceView ? 'device' : 'no_device'}_${appProvider.showConsole ? 'console' : 'no_console'}',
      ),
      axis: Axis.vertical,
      initialAreas: areas,
    );
  }

  Widget _buildIosPreviewCard() {
    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
      child: const IosSimulatorPanel(),
    );
  }

  bool _shouldShowRunningDeviceView(AppProvider appProvider) {
    if (!appProvider.isRunning) return false;
    final device = appProvider.selectedDevice;
    final platform = device.platform.toLowerCase();
    final name = device.name.toLowerCase();
    final isIosDevice =
        platform.contains('ios') || name.contains('iphone') || name.contains('ios');
    return isIosDevice;
  }

  Widget _buildTestEditor(AppProvider appProvider) {
    return DefaultTabController(
      length: 4,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Theme.of(
                context,
              ).colorScheme.surfaceVariant.withOpacity(0.3),
            ),
            child: TabBar(
              isScrollable: true,
              tabs: [
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.info, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        'Details${appProvider.selectedWidget != null ? ' (${appProvider.selectedWidget!.type ?? 'Widget'})' : ''}',
                      ),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.analytics, size: 16),
                      const SizedBox(width: 4),
                      const Text('Dependencies'),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.layers_outlined, size: 16),
                      const SizedBox(width: 4),
                      const Text('UI Inspector'),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.edit_note, size: 16),
                      const SizedBox(width: 4),
                      const Text('Test Editor'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              children: [
                EnhancedWidgetDetailsPanel(
                  selectedWidget: appProvider.selectedWidget,
                  isDialog: false,
                ),
                DependencyAnalysisPanel(
                  selectedWidget: appProvider.selectedWidget,
                ),
                const DeviceInspectorPanel(),
                _buildOriginalTestEditor(appProvider),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOriginalTestEditor(AppProvider appProvider) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('Test Code'),
              const Spacer(),
              FilledButton.icon(
                onPressed: appProvider.selectedProjectPath == null
                    ? null
                    : () async {
                        appProvider.setTestEditorText(_testController.text);
                        await SyncService().saveDraft(
                          fileName: 'generated_widget_test.dart',
                          content: _testController.text,
                        );
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Draft saved.')),
                          );
                        }
                      },
                icon: const Icon(Icons.save),
                label: const Text('Save Draft'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: TextField(
              controller: _testController,
              expands: true,
              maxLines: null,
              minLines: null,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText:
                    'Write widget tests here... (will be synced to test/)',
              ),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: appProvider.selectedProjectPath == null
                  ? null
                  : () async {
                      await SyncService().syncToProject(
                        projectRoot: appProvider.selectedProjectPath!,
                        fileName: 'generated_widget_test.dart',
                      );
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Synced to test/generated_widget_test.dart',
                            ),
                          ),
                        );
                      }
                    },
              icon: const Icon(Icons.sync),
              label: const Text('Sync to Project'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConsolePanel(AppProvider appProvider) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        border: Border.all(color: Colors.grey.shade700),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Console header with controls
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey.shade800,
              border: Border(bottom: BorderSide(color: Colors.grey.shade700)),
            ),
            child: Row(
              children: [
                const Icon(Icons.terminal, size: 16, color: Colors.white),
                const SizedBox(width: 8),
                const Text(
                  'Console Output',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  ' (${appProvider.consoleMessages.length} messages)',
                  style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
                ),
                const Spacer(),
                // Copy button
                IconButton(
                  onPressed: appProvider.consoleMessages.isEmpty
                      ? null
                      : () async {
                          await appProvider.copyConsoleToClipboard();
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Console output copied to clipboard',
                                ),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        },
                  icon: const Icon(Icons.copy, size: 16),
                  tooltip: 'Copy to clipboard',
                  color: Colors.white70,
                  constraints: const BoxConstraints(
                    minWidth: 32,
                    minHeight: 32,
                  ),
                ),
                // Clear button
                IconButton(
                  onPressed: appProvider.consoleMessages.isEmpty
                      ? null
                      : () => appProvider.clearConsoleMessages(),
                  icon: const Icon(Icons.clear_all, size: 16),
                  tooltip: 'Clear console',
                  color: Colors.white70,
                  constraints: const BoxConstraints(
                    minWidth: 32,
                    minHeight: 32,
                  ),
                ),
                // Close button
                IconButton(
                  onPressed: () => appProvider.setConsoleVisibility(false),
                  icon: const Icon(Icons.close, size: 16),
                  tooltip: 'Hide console',
                  color: Colors.white70,
                  constraints: const BoxConstraints(
                    minWidth: 32,
                    minHeight: 32,
                  ),
                ),
              ],
            ),
          ),
          // Console messages
          Expanded(
            child: Consumer<AppProvider>(
              builder: (context, appProvider, child) {
                // Auto-scroll to bottom when new messages are added
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _scrollToBottom();
                });

                return appProvider.consoleMessages.isEmpty
                    ? Center(
                        child: Text(
                          'No console messages yet',
                          style: TextStyle(
                            color: Colors.grey.shade500,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      )
                    : ListView.builder(
                        controller: _consoleScrollController,
                        padding: const EdgeInsets.all(8),
                        itemCount: appProvider.consoleMessages.length,
                        itemBuilder: (context, index) {
                          final message = appProvider.consoleMessages[index];
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 4),
                            child: SelectableText(
                              message.toString(),
                              style: TextStyle(
                                color: _getMessageColor(message.type),
                                fontFamily: 'monospace',
                                fontSize: 12,
                              ),
                              // Allow text to wrap for long messages
                              textAlign: TextAlign.left,
                            ),
                          );
                        },
                      );
              },
            ),
          ),
        ],
      ),
    );
  }

  Color _getMessageColor(String type) {
    switch (type.toLowerCase()) {
      case 'error':
        return Colors.red.shade300;
      case 'warning':
        return Colors.orange.shade300;
      case 'info':
        return Colors.blue.shade300;
      default:
        return Colors.white;
    }
  }
}
