import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../services/inspector_service.dart';
import '../../services/test_generation_service.dart';
import '../../presentation/providers/app_provider.dart';

/// Comprehensive widget details panel that shows structured information about selected widgets
class EnhancedWidgetDetailsPanel extends StatefulWidget {
  final WidgetTreeNode? selectedWidget;
  final bool isDialog; // Whether this is shown as a dialog or embedded panel

  const EnhancedWidgetDetailsPanel({
    super.key,
    required this.selectedWidget,
    this.isDialog = false,
  });

  @override
  State<EnhancedWidgetDetailsPanel> createState() =>
      _EnhancedWidgetDetailsPanelState();
}

class _EnhancedWidgetDetailsPanelState extends State<EnhancedWidgetDetailsPanel>
    with TickerProviderStateMixin {
  Map<String, dynamic>? _rawProperties;
  List<WidgetAttribute>? _structuredAttributes;
  SourceLocation? _sourceLocation;
  String? _sourceCode;
  WidgetHierarchy? _hierarchy;
  bool showDetailedHierarchy = false;
  final Set<String> _expandedNodes = <String>{};

  bool _isLoadingProperties = false;
  bool _isLoadingSource = false;
  String? _error;

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadWidgetDetails();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(EnhancedWidgetDetailsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.selectedWidget?.objectId != oldWidget.selectedWidget?.objectId) {
      _loadWidgetDetails();
      // Clear expanded state when widget changes
      _expandedNodes.clear();
    }
  }

  Future<void> _loadWidgetDetails() async {
    print('🔍 _loadWidgetDetails called');
    print('🔍 Selected widget: ${widget.selectedWidget?.type}');
    print('🔍 Object ID: ${widget.selectedWidget?.objectId}');

    if (widget.selectedWidget == null) {
      print('🔍 No widget selected, clearing state');
      setState(() {
        _rawProperties = null;
        _structuredAttributes = null;
        _sourceLocation = null;
        _sourceCode = null;
        _hierarchy = null;
        _error = null;
      });
      return;
    }

    final appProvider = context.read<AppProvider>();
    final inspectorService = appProvider.inspectorService as InspectorService?;

    print('🔍 Inspector service available: ${inspectorService != null}');

    setState(() {
      _isLoadingProperties = true;
      _isLoadingSource = true;
      _error = null;
    });

    try {
      // Always load fallback properties first (works on web and mobile)
      print('🔍 Loading fallback properties and attributes');
      final fallbackProperties = _extractFallbackProperties();
      final fallbackAttributes = _extractFallbackAttributes();

      print(
        '🔍 Fallback properties loaded: ${fallbackProperties.keys.toList()}',
      );
      print('🔍 Fallback attributes loaded: ${fallbackAttributes.length}');

      // Set fallback data immediately so tabs show content
      setState(() {
        _rawProperties = fallbackProperties;
        _structuredAttributes = fallbackAttributes;
      });

      // Try to enhance with inspector service if available
      if (inspectorService != null && widget.selectedWidget!.objectId != null) {
        print('🔍 Attempting to enhance with inspector service');
        await _enhanceWithInspectorService(inspectorService);
      } else {
        print(
          '🔍 Inspector service not available or no object ID, using fallback only',
        );
      }

      // Build widget hierarchy
      _buildHierarchy();
    } catch (e) {
      print('🔍 Error in _loadWidgetDetails: $e');
      // Don't show error if we have fallback data - web limitations are expected
      if (_rawProperties == null || _rawProperties!.isEmpty) {
        setState(() {
          _error = 'Failed to load widget details: $e';
        });
      }
    } finally {
      setState(() {
        _isLoadingProperties = false;
        _isLoadingSource = false;
      });
    }
  }

  Future<void> _enhanceWithInspectorService(
    InspectorService inspectorService,
  ) async {
    try {
      print('🔍 Enhancing with inspector service...');

      // Get fresh widget properties from DevTools inspector
      // This ensures we always have the most up-to-date widget data
      final enhancedProperties = await inspectorService.getWidgetDetails(
        widget.selectedWidget!.objectId!,
      );

      if (enhancedProperties != null && enhancedProperties.isNotEmpty) {
        print(
          '🔍 Fresh DevTools properties received: ${enhancedProperties.length} properties',
        );

        // Convert DevTools properties to a flat map for merging
        final flatProperties = <String, dynamic>{};
        for (final prop in enhancedProperties) {
          final name = prop['name'] as String?;
          final value = prop['value'];
          final description = prop['description'];

          if (name != null) {
            flatProperties[name] = value ?? description;
          }
        }

        // Merge with fallback properties
        final mergedProperties = Map<String, dynamic>.from(
          _rawProperties ?? {},
        );
        mergedProperties.addAll(flatProperties);

        // Always process the fresh enhancedProperties from DevTools
        // This ensures we get the most up-to-date widget data
        final enhancedAttrs = inspectorService.extractAttributesFromProperties(
          enhancedProperties,
          widget.selectedWidget!.type,
        );

        // Update cache with fresh data for future use
        if (enhancedAttrs.isNotEmpty) {
          inspectorService.updateCachedAttributes(
            widget.selectedWidget!.objectId!,
            enhancedAttrs,
          );
        }

        print(
          '🔍 Processed ${enhancedAttrs.length} attributes from fresh DevTools data',
        );

        if (enhancedAttrs.isNotEmpty) {
          print('🔍 Enhanced attributes received: ${enhancedAttrs.length}');

          // Merge with fallback attributes (avoid duplicates)
          final mergedAttributes = <WidgetAttribute>[
            ...(_structuredAttributes ?? []),
          ];
          for (final attr in enhancedAttrs) {
            if (!mergedAttributes.any(
              (existing) => existing.name == attr.name,
            )) {
              mergedAttributes.add(attr);
            }
          }

          setState(() {
            _rawProperties = mergedProperties;
            _structuredAttributes = mergedAttributes;
          });
        }
      } else {
        print('🔍 No enhanced properties received from inspector service');
      }

      // Try to get source location (may not work on web)
      await _loadSourceInformation(inspectorService);
    } catch (e) {
      print('🔍 Error enhancing with inspector service: $e');
      // Don't fail - we already have fallback data
    }
  }

  // Removed _loadProperties method - functionality moved to _enhanceWithInspectorService

  /// Extract basic properties from widget node when service calls fail
  Map<String, dynamic> _extractFallbackProperties() {
    final widget = this.widget.selectedWidget!;
    final properties = <String, dynamic>{};

    if (widget.type != null) {
      properties['widget_type'] = widget.type!;
    }

    if (widget.description != null) {
      properties['description'] = widget.description!;
    }

    if (widget.objectId != null) {
      properties['object_id'] = widget.objectId!;
    }

    properties['has_children'] = widget.hasChildren;
    properties['children_count'] = widget.children.length;

    // Try to extract from existing properties if available
    if (widget.properties != null) {
      properties.addAll(widget.properties!);
    }

    return properties;
  }

  /// Extract basic attributes from widget description when service calls fail
  List<WidgetAttribute> _extractFallbackAttributes() {
    final widget = this.widget.selectedWidget!;
    final attributes = <WidgetAttribute>[];

    // Add basic widget information as attributes
    if (widget.type != null) {
      attributes.add(
        WidgetAttribute(
          name: 'widget_type',
          label: widget.type!,
          type: 'String',
          value: widget.type!,
        ),
      );
    }

    // Try to extract text content from description
    if (widget.description != null) {
      final description = widget.description!;

      // Try to extract text content for Text widgets
      if (description.startsWith('Text(')) {
        // Simple extraction for Text widgets
        final textPattern = RegExp(r"Text\('([^']*)'\)");
        final textMatch = textPattern.firstMatch(description);
        if (textMatch != null) {
          attributes.add(
            WidgetAttribute(
              name: 'text_content',
              label: "'${textMatch.group(1)!}'",
              type: 'String',
              value: textMatch.group(1)!,
            ),
          );
        } else {
          // Try double quotes
          final textPattern2 = RegExp(r'Text\("([^"]*)"\)');
          final textMatch2 = textPattern2.firstMatch(description);
          if (textMatch2 != null) {
            attributes.add(
              WidgetAttribute(
                name: 'text_content',
                label: '"${textMatch2.group(1)!}"',
                type: 'String',
                value: textMatch2.group(1)!,
              ),
            );
          }
        }
      }
      // Try to extract icon info for Icon widgets
      else if (description.contains('Icon(')) {
        final iconPattern = RegExp(r'Icons\.(\w+)');
        final iconMatch = iconPattern.firstMatch(description);
        if (iconMatch != null) {
          attributes.add(
            WidgetAttribute(
              name: 'icon',
              label: 'Icons.${iconMatch.group(1)!}',
              type: 'IconData',
              value: iconMatch.group(0)!,
            ),
          );
        }
      }

      // Add description as an attribute
      attributes.add(
        WidgetAttribute(
          name: 'description',
          label: description,
          type: 'String',
          value: description,
        ),
      );
    }

    return attributes;
  }

  Future<void> _loadSourceInformation(InspectorService inspectorService) async {
    try {
      print('🔍 Loading source information...');

      // Get source location (may not work on web)
      final sourceLocation = await inspectorService.getWidgetSourceLocation(
        widget.selectedWidget!.objectId!,
      );

      print(
        '🔍 Source location received: ${sourceLocation?.file}:${sourceLocation?.line}',
      );

      String? sourceCode;
      if (sourceLocation != null) {
        print('🔍 Attempting to load source code...');
        // Get source code
        sourceCode = await inspectorService.getWidgetSourceCode(sourceLocation);
        print(
          '🔍 Source code loaded: ${sourceCode != null ? '${sourceCode.length} characters' : 'null'}',
        );
      }

      setState(() {
        _sourceLocation = sourceLocation;
        _sourceCode = sourceCode;
      });
    } catch (e) {
      print('🔍 Error loading source information: $e');
      // Don't fail - source info is optional, especially on web
    }
  }

  void _buildHierarchy() {
    if (widget.selectedWidget == null) return;

    print('🔍 Building hierarchy for widget: ${widget.selectedWidget!.type}');
    print('🔍 Widget has ${widget.selectedWidget!.children.length} children');

    // Build a simple hierarchy representation with available data
    _hierarchy = WidgetHierarchy(
      current: widget.selectedWidget!,
      parents: [], // TODO: Could implement parent traversal if needed
      children: widget.selectedWidget!.children,
    );

    print('🔍 Hierarchy built successfully');
  }

  @override
  Widget build(BuildContext context) {
    final content = _buildContent();

    if (widget.isDialog) {
      return Dialog(
        child: Container(
          width: 800,
          height: 700,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDialogHeader(),
              const SizedBox(height: 16),
              Expanded(child: content),
            ],
          ),
        ),
      );
    }

    return content;
  }

  Widget _buildDialogHeader() {
    return Row(
      children: [
        Icon(
          Icons.info_outlined,
          color: Theme.of(context).colorScheme.primary,
          size: 24,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Widget Details',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (widget.selectedWidget != null)
                Text(
                  widget.selectedWidget!.type ?? 'Unknown Widget',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
            ],
          ),
        ),
        IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close),
          tooltip: 'Close',
        ),
      ],
    );
  }

  Widget _buildContent() {
    if (widget.selectedWidget == null) {
      return _buildEmptyState();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (!widget.isDialog) _buildPanelHeader(),
        _buildTabBar(),
        Expanded(child: _buildTabContent()),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.info_outlined,
            size: 64,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'No Widget Selected',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Select a widget from the tree to view detailed information',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPanelHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(8),
          topRight: Radius.circular(8),
        ),
      ),
      child: Row(
        children: [
          _getWidgetIcon(widget.selectedWidget!),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.selectedWidget!.type ?? 'Unknown Widget',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600),
                ),
                if (widget.selectedWidget!.description != null)
                  Text(
                    widget.selectedWidget!.description!,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withOpacity(0.7),
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: _loadWidgetDetails,
            icon: _isLoadingProperties || _isLoadingSource
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
            tooltip: 'Refresh details',
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return TabBar(
      controller: _tabController,
      tabs: [
        Tab(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.info, size: 16),
              const SizedBox(width: 4),
              const Text('Overview'),
            ],
          ),
        ),
        Tab(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.settings, size: 16),
              const SizedBox(width: 4),
              Text('All Data${_getPropertyCount()}'),
            ],
          ),
        ),
        Tab(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.code, size: 16),
              const SizedBox(width: 4),
              const Text('Source'),
            ],
          ),
        ),
        Tab(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.account_tree, size: 16),
              const SizedBox(width: 4),
              const Text('Hierarchy'),
            ],
          ),
        ),
      ],
    );
  }

  String _getPropertyCount() {
    if (widget.selectedWidget == null) return '';

    int totalCount = 0;

    // Basic widget properties (always available)
    totalCount += 6; // displayName, runtime type, description, etc.

    // Creation location properties
    if (widget.selectedWidget!.creationLocation != null ||
        _sourceLocation != null) {
      totalCount += 5; // file, path, line, column, constructor
    }

    // Classification properties
    totalCount += 4; // user project, stateful, dependencies, children

    // Inspector metadata
    totalCount += 4; // location ID, style, summary tree, allow wrap

    // Structured attributes
    final structuredCount = _structuredAttributes?.length ?? 0;
    totalCount += structuredCount;

    // Raw properties
    final rawCount = _rawProperties?.length ?? 0;
    totalCount += rawCount;

    // Widget context properties
    totalCount += 1; // children count
    if (widget.selectedWidget!.children.isNotEmpty) {
      totalCount += widget.selectedWidget!.children.length; // child types
    }

    return totalCount > 0 ? ' ($totalCount)' : '';
  }

  Widget _buildTabContent() {
    return TabBarView(
      controller: _tabController,
      children: [
        _buildOverviewTab(),
        _buildPropertiesTab(),
        _buildSourceTab(),
        _buildHierarchyTab(),
      ],
    );
  }

  Widget _buildOverviewTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Web limitations banner
          if (_isRunningOnWeb()) _buildWebLimitationsBanner(),
          // Structured Properties (if available)
          if (_structuredAttributes != null &&
              _structuredAttributes!.isNotEmpty) ...[
            _buildStructuredPropertiesCard(),
            const SizedBox(height: 16),
          ],
          const SizedBox(height: 16),
          _buildRenderInfoCard(),
          const SizedBox(height: 16),
          _buildTestGenerationCard(),
          const SizedBox(height: 16),
          _buildQuickActionsCard(),
        ],
      ),
    );
  }

  bool _isRunningOnWeb() {
    // Use Flutter's built-in web detection
    return kIsWeb;
  }

  Widget _buildWebLimitationsBanner() {
    return Card(
      color: Colors.blue.shade50,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.blue.shade600, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Running on Flutter Web: Some inspector features may be limited. Fallback widget analysis is active.',
                style: TextStyle(fontSize: 12, color: Colors.blue.shade800),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRenderInfoCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.aspect_ratio,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Render Information',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildTestGenerationCard() {
    final widget = this.widget.selectedWidget!;
    final hasCreationLocation = widget.creationLocation != null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.add_task,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Test Generation',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (hasCreationLocation) ...[
              _buildInfoRow(
                'Source File',
                widget.creationLocation!.file.split('/').last,
              ),
              _buildInfoRow(
                'Line',
                '${widget.creationLocation!.line}:${widget.creationLocation!.column}',
              ),
              _buildInfoRow('Test File', _getTestFilePath()),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green.shade200),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.check_circle,
                      color: Colors.green.shade600,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Ready for test generation',
                        style: TextStyle(
                          color: Colors.green.shade800,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.warning,
                      color: Colors.orange.shade600,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'No source location available for test generation',
                        style: TextStyle(
                          color: Colors.orange.shade800,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.flash_on,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Quick Actions',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildActionChip(
                  'Copy Widget Info',
                  Icons.copy,
                  () => _copyWidgetInfo(),
                ),
                if (_sourceLocation != null)
                  _buildActionChip(
                    'Copy Source Path',
                    Icons.link,
                    () => _copySourcePath(),
                  ),
                if (widget.selectedWidget!.objectId != null)
                  _buildActionChip(
                    'Copy Object ID',
                    Icons.fingerprint,
                    () => _copyObjectId(),
                  ),
                if (widget.selectedWidget!.creationLocation != null)
                  _buildActionChip(
                    'Generate Test',
                    Icons.add_task,
                    () => _generateTest(),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPropertiesTab() {
    if (_isLoadingProperties) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 48,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.error,
              ),
            ),
          ],
        ),
      );
    }

    return _buildComprehensiveProperties();
  }

  Widget _buildComprehensiveProperties() {
    final widget = this.widget.selectedWidget!;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Widget Overview Section
        _buildWidgetOverviewCard(widget),
        const SizedBox(height: 16),

        // Creation & Source Information
        if (widget.creationLocation != null || _sourceLocation != null)
          _buildCreationInfoCard(widget),
        if (widget.creationLocation != null || _sourceLocation != null)
          const SizedBox(height: 16),

        // Widget Classification
        _buildWidgetClassificationCard(widget),
        const SizedBox(height: 16),

        // Inspector Metadata
        _buildInspectorMetadataCard(widget),
        const SizedBox(height: 16),

        // Structured Properties (if available)
        if (_structuredAttributes != null &&
            _structuredAttributes!.isNotEmpty) ...[
          _buildStructuredPropertiesCard(),
          const SizedBox(height: 16),
        ],

        // Raw Properties (if available)
        if (_rawProperties != null && _rawProperties!.isNotEmpty) ...[
          _buildRawPropertiesCard(),
          const SizedBox(height: 16),
        ],

        // Widget Tree Context
        _buildWidgetContextCard(widget),
      ],
    );
  }

  Widget _buildWidgetOverviewCard(WidgetTreeNode widget) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.info, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  'Widget Overview',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildPropertyRow('Display Name', widget.displayName),
            if (widget.widgetRuntimeType != null)
              _buildPropertyRow('Runtime Type', widget.widgetRuntimeType!),
            if (widget.effectiveWidgetType != null &&
                widget.effectiveWidgetType != widget.widgetRuntimeType)
              _buildPropertyRow('Effective Type', widget.effectiveWidgetType!),
            if (widget.description != null)
              _buildPropertyRow('Description', widget.description!),
            if (widget.type != null)
              _buildPropertyRow('Inspector Type', widget.type!),
            if (widget.objectId != null)
              _buildPropertyRow('Object ID', widget.objectId!),
            _buildInfoRow(
              'Has Children',
              widget.hasChildren ? 'Yes (${widget.children.length})' : 'No',
            ),
            if (_sourceLocation != null)
              _buildInfoRow(
                'Source File',
                _sourceLocation!.file.split('/').last,
              ),
            if (_sourceLocation != null)
              _buildInfoRow(
                'Source Line',
                '${_sourceLocation!.line}:${_sourceLocation!.column}',
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCreationInfoCard(WidgetTreeNode widget) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.source,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Creation & Source Information',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (widget.creationLocation != null) ...[
              _buildPropertyRow(
                'Source File',
                widget.creationLocation!.file.split('/').last,
              ),
              _buildPropertyRow('Full Path', widget.creationLocation!.file),
              _buildPropertyRow('Line', '${widget.creationLocation!.line}'),
              _buildPropertyRow('Column', '${widget.creationLocation!.column}'),
              _buildPropertyRow(
                'Constructor Name',
                widget.creationLocation!.name,
              ),
            ],
            if (_sourceLocation != null && widget.creationLocation == null) ...[
              _buildPropertyRow(
                'Source File',
                _sourceLocation!.file.split('/').last,
              ),
              _buildPropertyRow('Full Path', _sourceLocation!.file),
              _buildPropertyRow('Line', '${_sourceLocation!.line}'),
              _buildPropertyRow('Column', '${_sourceLocation!.column}'),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildWidgetClassificationCard(WidgetTreeNode widget) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.category,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Widget Classification',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildPropertyRowWithStatus(
              'User Project Widget',
              widget.isFromUserProject,
              widget.isFromUserProject ? '👤 Yes' : '🏗️ Framework Widget',
            ),
            if (widget.stateful != null)
              _buildPropertyRowWithStatus(
                'Stateful Widget',
                widget.stateful!,
                widget.stateful! ? '🔄 Stateful' : '🔒 Stateless',
              ),
            _buildPropertyRowWithStatus(
              'Has Dependencies',
              widget.hasPotentialDependencies,
              widget.hasPotentialDependencies
                  ? '🔗 May have dependencies'
                  : '✅ Likely self-contained',
            ),
            _buildPropertyRow(
              'Has Children',
              widget.hasChildren ? 'Yes (${widget.children.length})' : 'No',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInspectorMetadataCard(WidgetTreeNode widget) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.settings_applications,
                  color: Theme.of(context).colorScheme.outline,
                ),
                const SizedBox(width: 8),
                Text(
                  'Inspector Metadata',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (widget.locationId != null)
              _buildPropertyRow('Location ID', widget.locationId.toString()),
            if (widget.style != null)
              _buildPropertyRow('Display Style', widget.style!),
            _buildPropertyRow(
              'Summary Tree',
              widget.summaryTree ? 'Yes' : 'No',
            ),
            _buildPropertyRow('Allow Wrap', widget.allowWrap ? 'Yes' : 'No'),
          ],
        ),
      ),
    );
  }

  Widget _buildStructuredPropertiesCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.list_alt,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Structured Properties (${_structuredAttributes!.length})',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ..._structuredAttributes!.map((attr) => _buildPropertyCard(attr)),
          ],
        ),
      ),
    );
  }

  Widget _buildRawPropertiesCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.data_object,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Raw Properties (${_rawProperties!.length})',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ..._rawProperties!.entries.map(
              (entry) => _buildRawPropertyCard(entry),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWidgetContextCard(WidgetTreeNode widget) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.account_tree,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Widget Tree Context',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildPropertyRow(
              'Children Count',
              widget.children.length.toString(),
            ),
            if (widget.children.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'Child Widget Types:',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Theme.of(
                    context,
                  ).colorScheme.onSurface.withOpacity(0.8),
                ),
              ),
              const SizedBox(height: 4),
              Wrap(
                spacing: 4,
                runSpacing: 4,
                children: widget.children
                    .take(10)
                    .map(
                      (child) => Chip(
                        label: Text(
                          child.displayName,
                          style: const TextStyle(fontSize: 11),
                        ),
                        visualDensity: VisualDensity.compact,
                      ),
                    )
                    .toList(),
              ),
              if (widget.children.length > 10)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    '... and ${widget.children.length - 10} more children',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPropertyRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
            ),
          ),
          Expanded(
            child: SelectableText(value, style: const TextStyle(fontSize: 13)),
          ),
          IconButton(
            onPressed: () => _copyText(value),
            icon: const Icon(Icons.copy, size: 14),
            tooltip: 'Copy $label',
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }

  Widget _buildPropertyRowWithStatus(
    String label,
    bool status,
    String displayValue,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13),
            ),
          ),
          Expanded(
            child: Row(
              children: [
                Icon(
                  status ? Icons.check_circle : Icons.cancel,
                  size: 16,
                  color: status ? Colors.green : Colors.grey,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: SelectableText(
                    displayValue,
                    style: const TextStyle(fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => _copyText(displayValue),
            icon: const Icon(Icons.copy, size: 14),
            tooltip: 'Copy $label',
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }

  void _copyText(String text) {
    Clipboard.setData(ClipboardData(text: text));
    _showCopySuccess('Copied to clipboard!');
  }

  Widget _buildPropertyCard(WidgetAttribute attribute) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(
              context,
            ).colorScheme.primaryContainer.withOpacity(0.3),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            _getPropertyIcon(attribute.name),
            size: 20,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
        title: Text(
          attribute.name,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(attribute.label),
            if (attribute.type != null)
              Text(
                'Type: ${attribute.type}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(
                    context,
                  ).colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.copy, size: 16),
          onPressed: () => _copyPropertyValue(attribute),
          tooltip: 'Copy value',
        ),
      ),
    );
  }

  Widget _buildRawPropertyCard(MapEntry<String, dynamic> entry) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        title: Text(
          entry.key,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          entry.value.toString(),
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: IconButton(
          icon: const Icon(Icons.copy, size: 16),
          onPressed: () => _copyRawPropertyValue(entry),
          tooltip: 'Copy value',
        ),
      ),
    );
  }

  Widget _buildSourceTab() {
    if (_isLoadingSource) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_sourceLocation == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.code_off,
              size: 48,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              'Source Location Not Available',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSourceLocationCard(),
          const SizedBox(height: 16),
          if (_sourceCode != null) _buildSourceCodeCard(),
        ],
      ),
    );
  }

  Widget _buildSourceLocationCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.location_on,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Source Location',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => _copySourcePath(),
                  icon: const Icon(Icons.copy, size: 16),
                  tooltip: 'Copy file path',
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildInfoRow('File', _sourceLocation!.file),
            _buildInfoRow('Line', _sourceLocation!.line.toString()),
            _buildInfoRow('Column', _sourceLocation!.column.toString()),
            if (_sourceLocation!.endLine != null)
              _buildInfoRow('End Line', _sourceLocation!.endLine.toString()),
          ],
        ),
      ),
    );
  }

  Widget _buildSourceCodeCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.code,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Source Code',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => _copySourceCode(),
                  icon: const Icon(Icons.copy, size: 16),
                  tooltip: 'Copy source code',
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
                ),
              ),
              child: SelectableText(
                _sourceCode!,
                style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHierarchyTab() {
    print(
      '🔍 Building hierarchy tab, hierarchy available: ${_hierarchy != null}',
    );

    if (_hierarchy == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.account_tree_outlined,
              size: 48,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              'Building Widget Hierarchy...',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Widget hierarchy information will be displayed here',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
              ),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCurrentWidgetCard(),
          const SizedBox(height: 16),
          if (_hierarchy!.children.isNotEmpty)
            _buildChildrenCard()
          else
            _buildNoChildrenCard(),
        ],
      ),
    );
  }

  Widget _buildNoChildrenCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'No Child Widgets',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'This widget does not have any child widgets.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentWidgetCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.my_location,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Current Widget',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: _getWidgetIcon(_hierarchy!.current),
              title: Text(_hierarchy!.current.type ?? 'Unknown'),
              // subtitle: Text(_hierarchy!.current.description ?? ''),
              tileColor: Theme.of(
                context,
              ).colorScheme.primaryContainer.withOpacity(0.2),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChildrenCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.arrow_downward,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Children (${_hierarchy!.children.length})',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Spacer(),
                Text('Show Detailed Hierarchy'),
                SizedBox(width: 8),
                Switch(
                  value: showDetailedHierarchy,
                  onChanged: (value) {
                    setState(() {
                      showDetailedHierarchy = value;
                    });
                  },
                ),
                if (showDetailedHierarchy) ...[
                  const SizedBox(width: 16),
                  TextButton.icon(
                    onPressed: _expandAllNodes,
                    icon: const Icon(Icons.expand_more, size: 16),
                    label: const Text('Expand All'),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton.icon(
                    onPressed: _collapseAllNodes,
                    icon: const Icon(Icons.expand_less, size: 16),
                    label: const Text('Collapse All'),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 12),
            if (showDetailedHierarchy) ...[
              Container(
                height: 400,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Theme.of(
                      context,
                    ).colorScheme.outline.withOpacity(0.2),
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(8),
                  child: buildDetailedHierarchy(widget.selectedWidget!),
                ),
              ),
            ] else ...[
              // Show compact view
              ..._hierarchy!.children
                  .take(10)
                  .map(
                    (child) => ListTile(
                      leading: _getWidgetIcon(child),
                      // subtitle: Text(child.type ?? 'Unknown'),
                      title:
                          child.description != null &&
                              child.description!.isNotEmpty
                          ? Text(child.description!)
                          : null,
                      trailing: child.hasChildren
                          ? Text(
                              '${child.children.length}',
                              style: TextStyle(
                                fontSize: 10,
                                color: Theme.of(
                                  context,
                                ).colorScheme.onSurface.withOpacity(0.6),
                              ),
                            )
                          : null,
                    ),
                  ),
              if (_hierarchy!.children.length > 10)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    '... and ${_hierarchy!.children.length - 10} more children',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget buildDetailedHierarchy(WidgetTreeNode current, {int depth = 0}) {
    final nodeKey = '${current.objectId}_$depth';
    final isExpanded = _expandedNodes.contains(nodeKey);

    return Container(
      margin: EdgeInsets.only(left: depth * 20.0),
      child: current.hasChildren
          ? ExpansionTile(
              key: ValueKey(nodeKey),

              initiallyExpanded:
                  depth < 2 ||
                  isExpanded, // Auto-expand first 2 levels or previously expanded
              tilePadding: EdgeInsets.zero,
              childrenPadding: EdgeInsets.only(left: 20),
              leading: _getWidgetIcon(current),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: BorderSide(color: Colors.transparent),
              ),
              title: Text(
                current.description != null && current.description!.isNotEmpty
                    ? current.description!
                    : current.type ?? 'Unknown',
                style: TextStyle(
                  fontSize: 12 + (depth == 0 ? 2 : 0),
                  fontWeight: depth == 0 ? FontWeight.bold : FontWeight.normal,
                  color: depth == 0
                      ? Theme.of(context).colorScheme.primary
                      : null,
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    // decoration: BoxDecoration(
                    //   color: Theme.of(
                    //     context,
                    //   ).colorScheme.secondary.withOpacity(0.1),
                    //   borderRadius: BorderRadius.circular(10),
                    // ),
                    child: Text(
                      '${current.children.length}',
                      style: TextStyle(
                        fontSize: 9,
                        color: Theme.of(context).colorScheme.secondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              onExpansionChanged: (expanded) {
                setState(() {
                  if (expanded) {
                    _expandedNodes.add(nodeKey);
                  } else {
                    _expandedNodes.remove(nodeKey);
                  }
                });
              },
              children: current.children
                  .map(
                    (child) => Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: buildDetailedHierarchy(child, depth: depth + 1),
                    ),
                  )
                  .toList(),
            )
          : Container(
              decoration: BoxDecoration(
                color: depth == 0
                    ? Theme.of(
                        context,
                      ).colorScheme.primaryContainer.withOpacity(0.3)
                    : null,
                borderRadius: BorderRadius.circular(8),
                border: depth == 0
                    ? Border.all(
                        color: Theme.of(
                          context,
                        ).colorScheme.primary.withOpacity(0.3),
                      )
                    : null,
              ),
              child: ListTile(
                dense: true,
                leading: _getWidgetIcon(current),
                title: Text(
                  current.description != null && current.description!.isNotEmpty
                      ? current.description!
                      : current.type ?? 'Unknown',
                  style: TextStyle(
                    fontSize: 12 + (depth == 0 ? 2 : 0),
                    fontWeight: depth == 0
                        ? FontWeight.bold
                        : FontWeight.normal,
                    color: depth == 0
                        ? Theme.of(context).colorScheme.primary
                        : null,
                  ),
                ),
                trailing: Icon(
                  Icons.circle,
                  size: 6,
                  color: Theme.of(
                    context,
                  ).colorScheme.onSurface.withOpacity(0.3),
                ),
                onTap: () {
                  // Could implement navigation to child widget
                },
              ),
            ),
    );
  }

  // Helper methods
  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(child: SelectableText(value)),
        ],
      ),
    );
  }

  Widget _buildActionChip(String label, IconData icon, VoidCallback onPressed) {
    return ActionChip(
      avatar: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      onPressed: onPressed,
    );
  }

  IconData _getPropertyIcon(String propertyName) {
    switch (propertyName.toLowerCase()) {
      case 'data':
      case 'text':
        return Icons.text_fields;
      case 'icon':
      case 'icondata':
        return Icons.star_outline;
      case 'color':
        return Icons.palette;
      case 'style':
        return Icons.style;
      case 'child':
      case 'children':
        return Icons.account_tree;
      default:
        return Icons.settings;
    }
  }

  Widget _getWidgetIcon(WidgetTreeNode node) {
    // Reuse the existing widget icon logic from WidgetTreePanel
    final name = node.description ?? '';
    final typeLower = name.toLowerCase();
    IconData iconData;
    Color iconColor = Theme.of(context).colorScheme.onSurface;

    if (typeLower.contains('text')) {
      iconData = Icons.text_fields;
      iconColor = Colors.green.shade600;
    } else if (typeLower.contains('button')) {
      iconData = Icons.smart_button_outlined;
      iconColor = Colors.orange.shade600;
    } else if (typeLower.contains('icon')) {
      iconData = Icons.star_outline;
      iconColor = Colors.amber.shade700;
    } else if (typeLower.contains('container')) {
      iconData = Icons.crop_free_outlined;
      iconColor = Colors.deepPurple.shade600;
    } else {
      iconData = Icons.widgets_outlined;
    }

    return Icon(iconData, size: 20, color: iconColor);
  }

  // Action methods
  void _copyWidgetInfo() {
    final widget = this.widget.selectedWidget!;
    final info =
        '''
Widget Type: ${widget.type ?? 'Unknown'}
Description: ${widget.description ?? 'N/A'}
Object ID: ${widget.objectId ?? 'N/A'}
Has Children: ${widget.hasChildren ? 'Yes (${widget.children.length})' : 'No'}
${_sourceLocation != null ? 'Source: ${_sourceLocation!.file}:${_sourceLocation!.line}' : ''}
'''
            .trim();

    Clipboard.setData(ClipboardData(text: info));
    _showCopySuccess('Widget info copied!');
  }

  void _copySourcePath() {
    if (_sourceLocation != null) {
      final path =
          '${_sourceLocation!.file}:${_sourceLocation!.line}:${_sourceLocation!.column}';
      Clipboard.setData(ClipboardData(text: path));
      _showCopySuccess('Source path copied!');
    }
  }

  void _copyObjectId() {
    if (widget.selectedWidget?.objectId != null) {
      Clipboard.setData(ClipboardData(text: widget.selectedWidget!.objectId!));
      _showCopySuccess('Object ID copied!');
    }
  }

  void _generateTest() async {
    final widget = this.widget.selectedWidget!;

    try {
      // Check if widget has creation location
      if (widget.creationLocation == null) {
        _showError(
          'Cannot generate test: No source location found for ${widget.widgetRuntimeType ?? 'Widget'}',
        );
        return;
      }

      // Show loading indicator
      _showLoading('Generating test file...');

      // Generate test file
      final appProvider = context.read<AppProvider>();
      final testService = TestGenerationService(
        projectPath: appProvider.selectedProjectPath,
      );
      final success = await testService.generateTestForWidget(widget);

      // Hide loading indicator
      _hideLoading();

      if (success) {
        final widgetType =
            widget.widgetRuntimeType ?? widget.description ?? 'Widget';
        final sourceFile = widget.creationLocation!.file;
        final testFile = sourceFile
            .replaceFirst('lib/', 'test/')
            .replaceAll('.dart', '_test.dart');

        _showSuccess(
          'Test file generated successfully!\n\nWidget: $widgetType\nTest file: $testFile',
        );
      } else {
        _showError(
          'Failed to generate test file for ${widget.widgetRuntimeType ?? 'Widget'}',
        );
      }
    } catch (e) {
      _hideLoading();
      _showError('Error generating test: $e');
    }
  }

  void _copySourceCode() {
    if (_sourceCode != null) {
      Clipboard.setData(ClipboardData(text: _sourceCode!));
      _showCopySuccess('Source code copied!');
    }
  }

  void _copyPropertyValue(WidgetAttribute attribute) {
    Clipboard.setData(ClipboardData(text: attribute.label));
    _showCopySuccess('Property value copied!');
  }

  void _copyRawPropertyValue(MapEntry<String, dynamic> entry) {
    Clipboard.setData(ClipboardData(text: entry.value.toString()));
    _showCopySuccess('Property value copied!');
  }

  void _showCopySuccess(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
      );
    }
  }

  void _showLoading(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
              const SizedBox(width: 16),
              Text(message),
            ],
          ),
          duration: const Duration(seconds: 10), // Longer duration for loading
        ),
      );
    }
  }

  void _hideLoading() {
    if (mounted) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
    }
  }

  void _showSuccess(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  void _showError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  String _getTestFilePath() {
    final widget = this.widget.selectedWidget!;
    if (widget.creationLocation == null) return 'N/A';

    final sourceFile = widget.creationLocation!.file;
    final testService = TestGenerationService();
    return testService.convertToTestPath(sourceFile).split('/').last;
  }

  void _expandAllNodes() {
    setState(() {
      _expandedNodes.clear();
      _collectAllNodeKeys(widget.selectedWidget!, 0);
    });
  }

  void _collapseAllNodes() {
    setState(() {
      _expandedNodes.clear();
    });
  }

  void _collectAllNodeKeys(WidgetTreeNode node, int depth) {
    final nodeKey = '${node.objectId}_$depth';
    if (node.hasChildren) {
      _expandedNodes.add(nodeKey);
      for (final child in node.children) {
        _collectAllNodeKeys(child, depth + 1);
      }
    }
  }
}

/// Helper class to represent widget hierarchy
class WidgetHierarchy {
  final WidgetTreeNode current;
  final List<WidgetTreeNode> parents;
  final List<WidgetTreeNode> children;

  WidgetHierarchy({
    required this.current,
    required this.parents,
    required this.children,
  });
}

// InspectorService method is now public, so no extension needed
