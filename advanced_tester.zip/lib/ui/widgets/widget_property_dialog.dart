import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/inspector_service.dart';
import '../../presentation/providers/app_provider.dart';

/// Enhanced dialog for displaying widget properties with visual representation
class WidgetPropertyDialog extends StatefulWidget {
  final WidgetTreeNode node;

  const WidgetPropertyDialog({super.key, required this.node});

  @override
  State<WidgetPropertyDialog> createState() => _WidgetPropertyDialogState();
}

class _WidgetPropertyDialogState extends State<WidgetPropertyDialog> {
  List<WidgetAttribute>? _properties;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadProperties();
  }

  Future<void> _loadProperties() async {
    if (widget.node.objectId == null) {
      setState(() {
        _isLoading = false;
        _error = 'No object ID available';
      });
      return;
    }

    final appProvider = context.read<AppProvider>();
    final inspectorService = appProvider.inspectorService as InspectorService?;

    if (inspectorService == null) {
      setState(() {
        _isLoading = false;
        _error = 'Inspector service not available';
      });
      return;
    }

    try {
      final properties = await inspectorService.getWidgetProperties(
        widget.node.objectId!,
        widget.node.widgetRuntimeType,
      );
      setState(() {
        _properties = properties;
        _isLoading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _error = 'Failed to load properties: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 600,
        height: 700,
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 16),
            Expanded(child: _buildContent()),
            const SizedBox(height: 16),
            _buildActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        _getWidgetIcon(),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.node.displayName,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (widget.node.description != null &&
                  widget.node.description != widget.node.displayName)
                Text(
                  widget.node.description!,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              if (widget.node.objectId != null)
                Text(
                  'ID: ${widget.node.objectId}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontFamily: 'monospace',
                  ),
                ),
            ],
          ),
        ),
        IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close),
        ),
      ],
    );
  }

  Widget _getWidgetIcon() {
    final name = widget.node.description ?? '';
    final typeLower = name.toLowerCase();
    IconData iconData;
    Color iconColor = Theme.of(context).colorScheme.primary;

    if (typeLower.contains('text')) {
      iconData = Icons.text_fields;
      iconColor = Colors.green.shade600;
    } else if (typeLower.contains('button')) {
      iconData = Icons.smart_button_outlined;
      iconColor = Colors.orange.shade600;
    } else if (typeLower.contains('icon')) {
      iconData = Icons.star_outline;
      iconColor = Colors.amber.shade700;
    } else if (typeLower.contains('image')) {
      iconData = Icons.image_outlined;
      iconColor = Colors.pink.shade600;
    } else if (typeLower.contains('container')) {
      iconData = Icons.crop_free_outlined;
      iconColor = Colors.blue.shade600;
    } else if (typeLower.contains('column')) {
      iconData = Icons.view_column_outlined;
      iconColor = Colors.deepPurple.shade600;
    } else if (typeLower.contains('row')) {
      iconData = Icons.table_rows_outlined;
      iconColor = Colors.deepPurple.shade600;
    } else if (typeLower.contains('stack')) {
      iconData = Icons.layers_outlined;
      iconColor = Colors.deepPurple.shade600;
    } else {
      iconData = Icons.widgets_outlined;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: iconColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: iconColor.withOpacity(0.3)),
      ),
      child: Icon(iconData, size: 32, color: iconColor),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading widget properties...'),
          ],
        ),
      );
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 48,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _loadProperties,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_properties == null || _properties!.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.info_outline, size: 48),
            SizedBox(height: 16),
            Text('No properties available for this widget'),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Widget Properties',
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          _buildVisualRepresentation(),
          const SizedBox(height: 16),
          _buildPropertiesTable(),
        ],
      ),
    );
  }

  Widget _buildVisualRepresentation() {
    // Create a visual representation of the widget based on its type
    final widgetType = widget.node.widgetRuntimeType?.toLowerCase() ?? '';

    Widget visualWidget;

    if (widgetType.contains('text')) {
      final textValue = _getPropertyValue('data') ?? 'Text';
      visualWidget = Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.green.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.green.shade200),
        ),
        child: Text(
          textValue.toString(),
          style: TextStyle(
            color: Colors.green.shade800,
            fontWeight: FontWeight.w500,
          ),
        ),
      );
    } else if (widgetType.contains('container')) {
      final width = _getPropertyValue('width');
      final height = _getPropertyValue('height');
      final color = _getPropertyValue('color');

      visualWidget = Container(
        width: width != null ? (width is num ? width.toDouble() : 100) : 100,
        height: height != null ? (height is num ? height.toDouble() : 60) : 60,
        decoration: BoxDecoration(
          color: color != null ? Colors.blue.shade100 : Colors.blue.shade50,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.blue.shade200),
        ),
        child: const Center(
          child: Text('Container', style: TextStyle(fontSize: 12)),
        ),
      );
    } else if (widgetType.contains('sizedbox')) {
      final width = _getPropertyValue('width');
      final height = _getPropertyValue('height');

      visualWidget = Container(
        width: width != null ? (width is num ? width.toDouble() : 80) : 80,
        height: height != null ? (height is num ? height.toDouble() : 40) : 40,
        decoration: BoxDecoration(
          color: Colors.orange.shade50,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: Colors.orange.shade200),
        ),
        child: const Center(
          child: Text('SizedBox', style: TextStyle(fontSize: 10)),
        ),
      );
    } else {
      // Generic widget representation
      visualWidget = Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Theme.of(context).colorScheme.outline.withOpacity(0.3),
          ),
        ),
        child: Text(
          widget.node.displayName,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Visual Representation',
          style: Theme.of(
            context,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 8),
        Center(child: visualWidget),
      ],
    );
  }

  Widget _buildPropertiesTable() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(
                context,
              ).colorScheme.surfaceVariant.withOpacity(0.3),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'Property Name',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    'Value',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          ..._properties!.map((property) => _buildPropertyRow(property)),
        ],
      ),
    );
  }

  Widget _buildPropertyRow(WidgetAttribute property) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outline.withOpacity(0.1),
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Text(
              property.name,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
                fontFamily: 'monospace',
              ),
            ),
          ),
          Expanded(flex: 3, child: _buildPropertyValue(property)),
        ],
      ),
    );
  }

  Widget _buildPropertyValue(WidgetAttribute property) {
    final value = property.label;

    // Special handling for different property types
    if (property.name.toLowerCase().contains('color')) {
      return Row(
        children: [
          Expanded(
            child: Text(
              value,
              style: Theme.of(
                context,
              ).textTheme.bodyMedium?.copyWith(fontFamily: 'monospace'),
            ),
          ),
          if (value.contains('Color('))
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: _parseColor(value),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline,
                ),
              ),
            ),
        ],
      );
    } else if (property.name.toLowerCase().contains('padding') ||
        property.name.toLowerCase().contains('margin')) {
      return Text(
        value,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          fontFamily: 'monospace',
          color: Colors.blue.shade700,
        ),
      );
    } else if (property.name.toLowerCase().contains('width') ||
        property.name.toLowerCase().contains('height')) {
      return Text(
        value,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          fontFamily: 'monospace',
          color: Colors.orange.shade700,
        ),
      );
    } else if (property.name.toLowerCase().contains('data') ||
        property.name.toLowerCase().contains('text')) {
      return Text(
        value,
        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
          fontFamily: 'monospace',
          color: Colors.green.shade700,
        ),
      );
    } else {
      return Text(
        value,
        style: Theme.of(
          context,
        ).textTheme.bodyMedium?.copyWith(fontFamily: 'monospace'),
      );
    }
  }

  Color? _parseColor(String colorString) {
    try {
      final match = RegExp(
        r'Color\(0x([0-9a-fA-F]+)\)',
      ).firstMatch(colorString);
      if (match != null) {
        final hexValue = int.parse(match.group(1)!, radix: 16);
        return Color(hexValue);
      }
    } catch (e) {
      // Ignore parsing errors
    }
    return null;
  }

  dynamic _getPropertyValue(String propertyName) {
    if (_properties == null) return null;

    for (final property in _properties!) {
      if (property.name.toLowerCase() == propertyName.toLowerCase()) {
        return property.value;
      }
    }
    return null;
  }

  Widget _buildActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
        const SizedBox(width: 8),
        ElevatedButton.icon(
          onPressed: _loadProperties,
          icon: const Icon(Icons.refresh, size: 16),
          label: const Text('Refresh'),
        ),
      ],
    );
  }
}
