import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/inspector_service.dart';
import '../../services/device_service.dart';
import '../../services/app_runner.dart';
import '../../presentation/providers/app_provider.dart';

class ControlToolbar extends StatefulWidget {
  ControlToolbar({super.key});

  @override
  State<ControlToolbar> createState() => _ControlToolbarState();
}

class _ControlToolbarState extends State<ControlToolbar> {
  final TextEditingController customUrlController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Refresh devices when toolbar is initialized
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final appProvider = context.read<AppProvider>();
      if (appProvider.availableDevices.length == 1 &&
          appProvider.availableDevices.first.deviceId == 'chrome') {
        // Only has default device, refresh to get actual devices
        appProvider.refreshDevices();
      }
    });
  }

  static void _handleAppFinished(AppProvider appProvider) {
    // Clear all running project related values
    appProvider.clearRunningProjectData();
    print('Cleared all running project data');
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = context.watch<AppProvider>();
    final isRunning = appProvider.isRunning;
    final canRunApp =
        !isRunning &&
        appProvider.selectedProjectPath != null &&
        appProvider.availableDevices.isNotEmpty;
    return Row(
      children: [
        Container(
          width: 100,
          child: TextField(
            decoration: const InputDecoration(hintText: 'Enter custom URL'),
            controller: customUrlController,
          ),
        ),
        IconButton(
          onPressed: () {
            appProvider.setRunningUrl(customUrlController.text);
            print('set running url to ${customUrlController.text}');
          },
          icon: Icon(Icons.connect_without_contact),
        ),
        FilledButton.icon(
          onPressed: canRunApp
              ? () async {
                  await AppRunner.run(appProvider);
                }
              : null,
          icon: const Icon(Icons.play_arrow),
          label: const Text('Run App'),
        ),
        const SizedBox(width: 8),
        FilledButton.tonalIcon(
          onPressed: isRunning
              ? () async {
                  final process = appProvider.flutterProcess;
                  if (process != null) {
                    process.kill();
                  }
                  _handleAppFinished(appProvider);
                }
              : null,
          icon: const Icon(Icons.stop),
          label: const Text('Stop'),
        ),
        const SizedBox(width: 8),
        _buildDeviceSelector(appProvider),
        const SizedBox(width: 8),
        IconButton(
          onPressed: isRunning
              ? () => _showInspectorDebugDialog(context, appProvider)
              : null,
          icon: const Icon(Icons.bug_report),
          tooltip: 'Debug Widget Inspector',
        ),
        const SizedBox(width: 8),
        IconButton(
          onPressed: isRunning
              ? () => _startElementInspection(context, appProvider)
              : null,
          icon: const Icon(Icons.search),
          tooltip: 'Start Element Inspection',
        ),
      ],
    );
  }

  Widget _buildDeviceSelector(AppProvider appProvider) {
    if (appProvider.isLoadingDevices) {
      return const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          SizedBox(width: 8),
          Text('Loading devices...', style: TextStyle(fontSize: 12)),
        ],
      );
    }

    final devices = appProvider.availableDevices;
    if (devices.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade400),
          borderRadius: BorderRadius.circular(6),
        ),
        child: const Text('No devices found', style: TextStyle(fontSize: 12)),
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.devices, size: 16),
        const SizedBox(width: 4),
        DropdownButton<DeviceInfo>(
          value: appProvider.selectedDevice,
          items: devices.map((device) {
            final label = '${device.name} • ${device.platform}';
            return DropdownMenuItem<DeviceInfo>(
              value: device,
              child: Container(
                constraints: const BoxConstraints(maxWidth: 220),
                child: Text(
                  label,
                  style: const TextStyle(fontSize: 12, color: Colors.white),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            );
          }).toList(),
          onChanged: !appProvider.isRunning
              ? (DeviceInfo? device) {
                  if (device != null) {
                    appProvider.setSelectedDevice(device);
                  }
                }
              : null,
          underline: const SizedBox(),
          style: const TextStyle(fontSize: 12, color: Colors.black87),
          icon: const Icon(Icons.arrow_drop_down, size: 16),
        ),
        IconButton(
          onPressed: !appProvider.isLoadingDevices && !appProvider.isRunning
              ? () => appProvider.refreshDevices()
              : null,
          icon: const Icon(Icons.refresh, size: 16),
          tooltip: 'Refresh devices',
          padding: const EdgeInsets.all(4),
          constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
        ),
      ],
    );
  }

  static void _showInspectorDebugDialog(
    BuildContext context,
    AppProvider appProvider,
  ) {
    showDialog(
      context: context,
      builder: (context) => InspectorDebugDialog(appProvider: appProvider),
    );
  }

  static void _startElementInspection(
    BuildContext context,
    AppProvider appProvider,
  ) async {
    try {
      // Get the inspector service
      final inspector = appProvider.inspectorService as InspectorService?;
      if (inspector == null) {
        _showInspectionError(
          context,
          'Inspector service not available. Please restart the app.',
        );
        return;
      }

      // Check if inspector is ready
      final isReady = await inspector.isInspectorAvailable();
      if (!isReady) {
        _showInspectionError(
          context,
          'Widget inspector is not ready. Please wait for the app to fully load.',
        );
        return;
      }

      // Get the widget tree
      final rootWidget = await inspector.getRootWidgetSummaryTree();
      if (rootWidget == null) {
        _showInspectionError(
          context,
          'Could not retrieve widget tree. The app might not be fully loaded.',
        );
        return;
      }

      // Show inspection dialog
      showDialog(
        context: context,
        builder: (context) => ElementInspectionDialog(
          appProvider: appProvider,
          rootWidget: rootWidget,
        ),
      );
    } catch (e) {
      _showInspectionError(context, 'Failed to start element inspection: $e');
    }
  }

  static void _showInspectionError(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Inspection Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}

class InspectorDebugDialog extends StatefulWidget {
  final AppProvider appProvider;

  const InspectorDebugDialog({super.key, required this.appProvider});

  @override
  State<InspectorDebugDialog> createState() => _InspectorDebugDialogState();
}

class _InspectorDebugDialogState extends State<InspectorDebugDialog> {
  String _debugInfo = '';
  bool _isChecking = false;

  @override
  void initState() {
    super.initState();
    _runDiagnostics();
  }

  Future<void> _runDiagnostics() async {
    setState(() {
      _isChecking = true;
      _debugInfo = 'Running inspector diagnostics...\n\n';
    });

    final appProvider = widget.appProvider;
    final buffer = StringBuffer();

    buffer.writeln('=== Flutter Widget Inspector Diagnostics ===\n');

    // Check VM Service URI
    buffer.writeln('1. VM Service URI: ${appProvider.vmServiceUri}');
    if (appProvider.vmServiceUri == null) {
      buffer.writeln('   ❌ No VM service URI available');
      buffer.writeln('   💡 Make sure Flutter app is running with debug mode');
    } else {
      buffer.writeln('   ✅ VM service URI found');
    }
    buffer.writeln();

    // Check Inspector Service Connection
    final inspector = appProvider.inspectorService as InspectorService?;
    buffer.writeln('2. Inspector Service Connection:');
    if (inspector == null) {
      buffer.writeln('   ❌ Inspector service not initialized');
      buffer.writeln('   💡 Try stopping and restarting the Flutter app');
    } else {
      buffer.writeln('   ✅ Inspector service initialized');

      try {
        // Check VM connection
        final vm = await inspector.getVM();
        buffer.writeln('   ✅ VM connection successful');
        buffer.writeln('   📱 VM version: ${vm.version}');

        // Check isolates
        final isolateId = await inspector.getFirstFlutterIsolateId();
        if (isolateId != null) {
          buffer.writeln('   ✅ Flutter isolate found: $isolateId');

          // Check service extensions
          final vmService = inspector.service;
          if (vmService != null) {
            final isolate = await vmService.getIsolate(isolateId);
            final extensions = isolate.extensionRPCs ?? [];
            buffer.writeln(
              '   🔧 Available service extensions: ${extensions.length}',
            );

            final inspectorExtensions = extensions.where(
              (ext) => ext.startsWith('ext.flutter.inspector'),
            );
            if (inspectorExtensions.isNotEmpty) {
              buffer.writeln('   ✅ Inspector extensions found:');
              for (final ext in inspectorExtensions) {
                buffer.writeln('      - $ext');
              }

              // Test inspector availability
              final isReady = await inspector.isInspectorAvailable();
              if (isReady) {
                buffer.writeln('   ✅ Widget inspector is ready!');

                // Try to get widget tree
                try {
                  final rootWidget = await inspector.getRootWidgetSummaryTree();
                  if (rootWidget != null) {
                    buffer.writeln('   ✅ Widget tree retrieved successfully');
                    buffer.writeln(
                      '   🌳 Root widget: ${rootWidget.description ?? rootWidget.type}',
                    );
                  } else {
                    buffer.writeln(
                      '   ⚠️  Widget tree is null (app might not be fully loaded)',
                    );
                  }
                } catch (e) {
                  buffer.writeln('   ❌ Failed to get widget tree: $e');
                }
              } else {
                buffer.writeln('   ❌ Widget inspector not ready');
                buffer.writeln('   💡 App might still be starting up');
              }
            } else {
              buffer.writeln('   ❌ No inspector extensions found');
              buffer.writeln('   💡 Make sure app is running in debug mode');
              buffer.writeln('   💡 Try: flutter run -d chrome --debug');
            }
          }
        } else {
          buffer.writeln('   ❌ No Flutter isolate found');
          buffer.writeln(
            '   💡 Make sure you\'re running a Flutter app, not just Dart',
          );
        }
      } catch (e) {
        buffer.writeln('   ❌ Inspector service error: $e');
      }
    }

    buffer.writeln('\n=== Troubleshooting Tips ===');
    buffer.writeln('• Make sure your Flutter app is running in debug mode');
    buffer.writeln('• Try stopping and restarting the Flutter app');
    buffer.writeln(
      '• Check that your app has widgets rendered (not just a blank screen)',
    );
    buffer.writeln(
      '• For web: make sure you\'re using a debug build, not release',
    );
    buffer.writeln(
      '• Wait 10-15 seconds after app starts before testing inspector',
    );

    setState(() {
      _debugInfo = buffer.toString();
      _isChecking = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Widget Inspector Debug'),
      content: SizedBox(
        width: 600,
        height: 400,
        child: Column(
          children: [
            if (_isChecking)
              const LinearProgressIndicator()
            else
              Row(
                children: [
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _runDiagnostics,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Re-run Diagnostics'),
                  ),
                ],
              ),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                child: SelectableText(
                  _debugInfo,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}

class ElementInspectionDialog extends StatefulWidget {
  final AppProvider appProvider;
  final WidgetTreeNode rootWidget;

  const ElementInspectionDialog({
    super.key,
    required this.appProvider,
    required this.rootWidget,
  });

  @override
  State<ElementInspectionDialog> createState() =>
      _ElementInspectionDialogState();
}

class _ElementInspectionDialogState extends State<ElementInspectionDialog> {
  WidgetTreeNode? _selectedNode;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Element Inspector'),
      content: SizedBox(
        width: 600,
        height: 500,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Click on any widget in the tree below to inspect it:',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            Expanded(child: _buildWidgetTree()),
            if (_selectedNode != null) ...[
              const Divider(),
              _buildSelectedNodeInfo(),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
        if (_selectedNode != null)
          FilledButton(
            onPressed: _selectWidget,
            child: const Text('Select Widget'),
          ),
      ],
    );
  }

  Widget _buildWidgetTree() {
    return SingleChildScrollView(child: _buildTreeNode(widget.rootWidget, 0));
  }

  Widget _buildTreeNode(WidgetTreeNode node, int depth) {
    final isSelected = _selectedNode?.objectId == node.objectId;
    final indent = depth * 20.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              _selectedNode = node;
            });
          },
          child: Container(
            padding: EdgeInsets.only(left: indent, top: 4, bottom: 4),
            decoration: BoxDecoration(
              color: isSelected
                  ? Theme.of(context).colorScheme.primaryContainer
                  : null,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Row(
              children: [
                Icon(
                  _getWidgetIcon(node),
                  size: 16,
                  color: isSelected
                      ? Theme.of(context).colorScheme.onPrimaryContainer
                      : Theme.of(context).colorScheme.onSurface,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    node.displayName,
                    style: TextStyle(
                      fontWeight: isSelected
                          ? FontWeight.bold
                          : FontWeight.normal,
                      color: isSelected
                          ? Theme.of(context).colorScheme.onPrimaryContainer
                          : Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                ),
                if (node.hasChildren)
                  Text(
                    '(${node.children.length} children)',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
              ],
            ),
          ),
        ),
        if (node.hasChildren && depth < 3) // Limit depth for performance
          ...node.children.map((child) => _buildTreeNode(child, depth + 1)),
      ],
    );
  }

  IconData _getWidgetIcon(WidgetTreeNode node) {
    final type = node.widgetRuntimeType?.toLowerCase() ?? '';

    if (type.contains('text')) return Icons.text_fields;
    if (type.contains('button')) return Icons.touch_app;
    if (type.contains('image')) return Icons.image;
    if (type.contains('icon')) return Icons.star;
    if (type.contains('container')) return Icons.crop_square;
    if (type.contains('column')) return Icons.view_column;
    if (type.contains('row')) return Icons.view_stream;
    if (type.contains('stack')) return Icons.layers;
    if (type.contains('scaffold')) return Icons.apps;
    if (type.contains('padding')) return Icons.padding;
    if (type.contains('margin')) return Icons.margin;
    if (type.contains('sizedbox')) return Icons.crop_free;
    if (type.contains('expanded')) return Icons.open_in_full;
    if (type.contains('flexible')) return Icons.open_in_full;
    if (type.contains('listview')) return Icons.list;
    if (type.contains('gridview')) return Icons.grid_view;
    if (type.contains('card')) return Icons.credit_card;
    if (type.contains('material')) return Icons.texture;
    if (type.contains('inkwell')) return Icons.touch_app;
    if (type.contains('gesture')) return Icons.pan_tool;
    if (type.contains('form')) return Icons.article;
    if (type.contains('field')) return Icons.input;
    if (type.contains('tab')) return Icons.tab;
    if (type.contains('navigator')) return Icons.navigation;
    if (type.contains('theme')) return Icons.palette;
    if (type.contains('provider')) return Icons.settings;
    if (type.contains('bloc')) return Icons.account_tree;
    if (type.contains('inherited')) return Icons.account_tree;

    return Icons.widgets;
  }

  Widget _buildSelectedNodeInfo() {
    if (_selectedNode == null) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Selected Widget: ${_selectedNode!.displayName}',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        if (_selectedNode!.widgetRuntimeType != null)
          Text('Type: ${_selectedNode!.widgetRuntimeType}'),
        if (_selectedNode!.creationLocation != null) ...[
          Text(
            'File: ${_selectedNode!.creationLocation!.file.split('/').last}',
          ),
          Text('Line: ${_selectedNode!.creationLocation!.line}'),
        ],
        if (_selectedNode!.objectId != null)
          Text('Object ID: ${_selectedNode!.objectId}'),
        if (_selectedNode!.hasChildren)
          Text('Children: ${_selectedNode!.children.length}'),
      ],
    );
  }

  void _selectWidget() async {
    if (_selectedNode?.objectId == null) return;

    try {
      final inspector =
          widget.appProvider.inspectorService as InspectorService?;
      if (inspector == null) return;

      // Select the widget in the inspector using the correct method
      await inspector.selectWidget(_selectedNode!.objectId!);

      // Update the app state with the selected widget
      widget.appProvider.setSelectedWidget(_selectedNode);

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Selected widget: ${_selectedNode!.displayName}'),
            duration: const Duration(seconds: 2),
          ),
        );
      }

      // Close the dialog
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to select widget: $e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }
}
