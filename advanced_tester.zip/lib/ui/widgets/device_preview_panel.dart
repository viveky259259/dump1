import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../domain/entities/ui_element.dart';
import '../../presentation/providers/ui_automation_provider.dart';

/// Unified device preview panel supporting iOS, Android, and Web
class DevicePreviewPanel extends StatefulWidget {
  /// Filter to show only specific platform(s)
  final Set<UIPlatform>? platformFilter;

  /// Whether to show manual start/stop controls
  final bool showManualControls;

  /// Whether to show the device selector dropdown
  final bool showDeviceSelector;

  /// Whether to filter by active (running) devices only
  final bool activeDevicesOnly;

  /// Callback when a device is selected
  final void Function(String deviceId, UIPlatform platform)? onDeviceSelected;

  const DevicePreviewPanel({
    super.key,
    this.platformFilter,
    this.showManualControls = true,
    this.showDeviceSelector = true,
    this.activeDevicesOnly = false,
    this.onDeviceSelected,
  });

  @override
  State<DevicePreviewPanel> createState() => _DevicePreviewPanelState();
}

class _DevicePreviewPanelState extends State<DevicePreviewPanel> {
  bool _isLoadingDevices = false;
  List<_DeviceEntry> _devices = [];
  _DeviceEntry? _selectedDevice;
  Offset? _dragStart;
  Offset? _dragLatest;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadDevices() async {
    if (_isLoadingDevices) return;

    setState(() => _isLoadingDevices = true);

    try {
      final provider = context.read<UIAutomationProvider>();
      final devices = await provider.getAvailableDevices();
      
      final entries = <_DeviceEntry>[];
      
      for (final device in devices) {
        final platformStr = device['platform']?.toString().toLowerCase() ?? '';
        UIPlatform platform;
        
        if (platformStr.contains('ios') || platformStr.contains('iphone')) {
          platform = UIPlatform.ios;
        } else if (platformStr.contains('android')) {
          platform = UIPlatform.android;
        } else if (platformStr.contains('web') || platformStr.contains('chromium')) {
          platform = UIPlatform.web;
        } else {
          platform = UIPlatform.unknown;
        }

        // Apply platform filter
        if (widget.platformFilter != null && !widget.platformFilter!.contains(platform)) {
          continue;
        }

        entries.add(_DeviceEntry(
          id: device['id'] as String? ?? '',
          name: device['name'] as String? ?? 'Unknown Device',
          platform: platform,
          isConnected: device['connected'] == true || device['state'] == 'Booted',
        ));
      }

      // Filter by active devices if requested
      final filteredEntries = widget.activeDevicesOnly
          ? entries.where((e) => e.isConnected).toList()
          : entries;

      // Sort: connected first, then by name
      filteredEntries.sort((a, b) {
        if (a.isConnected != b.isConnected) {
          return a.isConnected ? -1 : 1;
        }
        return a.name.compareTo(b.name);
      });

      setState(() {
        _devices = filteredEntries;
        if (_selectedDevice == null && filteredEntries.isNotEmpty) {
          _selectedDevice = filteredEntries.firstWhere(
            (d) => d.isConnected,
            orElse: () => filteredEntries.first,
          );
        }
      });
    } catch (e) {
      debugPrint('Error loading devices: $e');
    } finally {
      setState(() => _isLoadingDevices = false);
    }
  }

  Future<void> _connectToDevice(_DeviceEntry device) async {
    final provider = context.read<UIAutomationProvider>();
    
    setState(() => _selectedDevice = device);
    widget.onDeviceSelected?.call(device.id, device.platform);
    
    await provider.connectToDevice(device.id);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UIAutomationProvider>(
      builder: (context, provider, child) {
        final screenshot = provider.screenshotBytes;
        final isConnected = provider.isConnected;
        final isConnecting = provider.isConnecting;

        return Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              _buildHeader(provider, isConnected),
              const SizedBox(height: 12),

              // Device selector
              if (widget.showDeviceSelector) ...[
                _buildDeviceSelector(provider),
                const SizedBox(height: 8),
              ],

              // Manual controls
              if (widget.showManualControls) ...[
                _buildControls(provider, isConnected, isConnecting),
                const SizedBox(height: 12),
              ],

              // Preview area
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade800),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: screenshot != null
                      ? _buildScreenshot(screenshot, provider)
                      : _buildPlaceholder(provider),
                ),
              ),

              // Footer status
              const SizedBox(height: 8),
              _buildFooter(provider),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHeader(UIAutomationProvider provider, bool isConnected) {
    final platformIcon = _selectedDevice != null
        ? _getPlatformIcon(_selectedDevice!.platform)
        : Icons.devices;

    final statusText = provider.connectionError != null
        ? 'Error'
        : isConnected
            ? 'Connected'
            : provider.isConnecting
                ? 'Connecting...'
                : 'Disconnected';

    final statusColor = provider.connectionError != null
        ? Colors.red
        : isConnected
            ? Colors.green
            : provider.isConnecting
                ? Colors.orange
                : Colors.grey;

    return Row(
      children: [
        Icon(platformIcon, size: 18),
        const SizedBox(width: 8),
        Text(
          'Device Preview',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: statusColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                statusText,
                style: TextStyle(
                  fontSize: 12,
                  color: statusColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDeviceSelector(UIAutomationProvider provider) {
    return Row(
      children: [
        Expanded(child: _buildDeviceDropdown()),
        const SizedBox(width: 8),
        IconButton(
          onPressed: _isLoadingDevices ? null : _loadDevices,
          icon: _isLoadingDevices
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.refresh),
          tooltip: 'Refresh devices',
        ),
      ],
    );
  }

  Widget _buildDeviceDropdown() {
    if (_devices.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Row(
          children: [
            Icon(Icons.info_outline, size: 16, color: Colors.grey.shade600),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _isLoadingDevices
                    ? 'Loading devices...'
                    : 'No devices found. Start an emulator or connect a device.',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: DropdownButton<_DeviceEntry>(
        value: _selectedDevice,
        isExpanded: true,
        underline: const SizedBox(),
        items: _devices.map((device) {
          return DropdownMenuItem<_DeviceEntry>(
            value: device,
            child: Row(
              children: [
                Icon(
                  _getPlatformIcon(device.platform),
                  size: 16,
                  color: device.isConnected ? Colors.green : Colors.grey,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    device.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (device.isConnected)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'Active',
                      style: TextStyle(fontSize: 10, color: Colors.green),
                    ),
                  ),
              ],
            ),
          );
        }).toList(),
        onChanged: (device) {
          if (device != null) {
            _connectToDevice(device);
          }
        },
      ),
    );
  }

  Widget _buildControls(
    UIAutomationProvider provider,
    bool isConnected,
    bool isConnecting,
  ) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        FilledButton.icon(
          onPressed: isConnected || isConnecting || _selectedDevice == null
              ? null
              : () => _connectToDevice(_selectedDevice!),
          icon: isConnecting
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.play_arrow),
          label: const Text('Connect'),
        ),
        FilledButton.tonalIcon(
          onPressed: isConnected ? () => provider.disconnect() : null,
          icon: const Icon(Icons.stop),
          label: const Text('Disconnect'),
        ),
        if (isConnected) ...[
          IconButton(
            onPressed: provider.captureScreen,
            icon: const Icon(Icons.camera_alt),
            tooltip: 'Capture screenshot',
          ),
          IconButton(
            onPressed: provider.toggleAnnotations,
            icon: Icon(
              provider.annotationsEnabled
                  ? Icons.visibility
                  : Icons.visibility_off,
            ),
            tooltip: provider.annotationsEnabled
                ? 'Hide element overlays'
                : 'Show element overlays',
          ),
        ],
      ],
    );
  }

  Widget _buildScreenshot(Uint8List screenshot, UIAutomationProvider provider) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final containerSize = Size(
          constraints.maxWidth,
          constraints.maxHeight,
        );

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (details) => _handleTap(
            details.localPosition,
            containerSize,
            provider,
          ),
          onPanStart: (details) {
            _dragStart = details.localPosition;
            _dragLatest = details.localPosition;
          },
          onPanUpdate: (details) {
            _dragLatest = details.localPosition;
          },
          onPanEnd: (details) {
            if (_dragStart != null && _dragLatest != null) {
              _handleDrag(_dragStart!, _dragLatest!, containerSize, provider);
            }
            _dragStart = null;
            _dragLatest = null;
          },
          child: Stack(
            fit: StackFit.expand,
            children: [
              FittedBox(
                fit: BoxFit.contain,
                alignment: Alignment.center,
                child: Image.memory(
                  screenshot,
                  gaplessPlayback: true,
                  filterQuality: FilterQuality.medium,
                ),
              ),
              // Element overlays
              if (provider.annotationsEnabled && provider.deviceScreen != null)
                _buildElementOverlays(provider, containerSize),
            ],
          ),
        );
      },
    );
  }

  Widget _buildElementOverlays(
    UIAutomationProvider provider,
    Size containerSize,
  ) {
    final screen = provider.deviceScreen!;
    final scale = _calculateScale(
      screen.width.toDouble(),
      screen.height.toDouble(),
      containerSize,
    );

    return CustomPaint(
      size: containerSize,
      painter: _ElementOverlayPainter(
        elements: screen.selectableElements,
        hoveredElement: provider.hoveredElement,
        inspectedElement: provider.inspectedElement,
        deviceWidth: screen.width,
        deviceHeight: screen.height,
        containerSize: containerSize,
        scale: scale,
      ),
    );
  }

  double _calculateScale(double imageWidth, double imageHeight, Size containerSize) {
    return math.min(
      containerSize.width / imageWidth,
      containerSize.height / imageHeight,
    );
  }

  Widget _buildPlaceholder(UIAutomationProvider provider) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            provider.isConnecting ? Icons.hourglass_empty : Icons.devices_other,
            size: 48,
            color: Colors.white30,
          ),
          const SizedBox(height: 16),
          Text(
            provider.isConnecting
                ? 'Connecting to device...'
                : provider.connectionError != null
                    ? provider.connectionError!
                    : 'Select a device and tap Connect to start preview.\n'
                        'Tap, drag, or swipe to interact with the device.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter(UIAutomationProvider provider) {
    final lastCapture = provider.lastCaptureTime;
    final elementCount = provider.elementCount;

    return Row(
      children: [
        Text(
          'Last update: ${_formatTimestamp(lastCapture)}',
          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
        ),
        const Spacer(),
        if (elementCount > 0)
          Text(
            '$elementCount elements',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
      ],
    );
  }

  IconData _getPlatformIcon(UIPlatform platform) {
    switch (platform) {
      case UIPlatform.ios:
        return Icons.phone_iphone;
      case UIPlatform.android:
        return Icons.phone_android;
      case UIPlatform.web:
        return Icons.language;
      default:
        return Icons.devices;
    }
  }

  String _formatTimestamp(DateTime? time) {
    if (time == null) return '-';
    final local = time.toLocal();
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    return '${twoDigits(local.hour)}:${twoDigits(local.minute)}:${twoDigits(local.second)}';
  }

  void _handleTap(
    Offset localPosition,
    Size containerSize,
    UIAutomationProvider provider,
  ) {
    if (!provider.isConnected || provider.deviceScreen == null) return;

    final screen = provider.deviceScreen!;
    final normalized = _normalizePosition(
      localPosition,
      containerSize,
      screen.width.toDouble(),
      screen.height.toDouble(),
    );

    if (normalized != null) {
      provider.tapAt(normalized.dx, normalized.dy);
    }
  }

  void _handleDrag(
    Offset start,
    Offset end,
    Size containerSize,
    UIAutomationProvider provider,
  ) {
    if (!provider.isConnected || provider.deviceScreen == null) return;

    final screen = provider.deviceScreen!;
    final startNorm = _normalizePosition(
      start,
      containerSize,
      screen.width.toDouble(),
      screen.height.toDouble(),
    );
    final endNorm = _normalizePosition(
      end,
      containerSize,
      screen.width.toDouble(),
      screen.height.toDouble(),
    );

    if (startNorm != null && endNorm != null) {
      provider.swipe(
        startX: startNorm.dx,
        startY: startNorm.dy,
        endX: endNorm.dx,
        endY: endNorm.dy,
      );
    }
  }

  Offset? _normalizePosition(
    Offset position,
    Size containerSize,
    double imageWidth,
    double imageHeight,
  ) {
    if (containerSize.width <= 0 || containerSize.height <= 0) return null;

    final scale = _calculateScale(imageWidth, imageHeight, containerSize);
    final displayWidth = imageWidth * scale;
    final displayHeight = imageHeight * scale;
    final offsetX = (containerSize.width - displayWidth) / 2;
    final offsetY = (containerSize.height - displayHeight) / 2;

    final relativeX = (position.dx - offsetX) / displayWidth;
    final relativeY = (position.dy - offsetY) / displayHeight;

    if (relativeX < 0 || relativeX > 1 || relativeY < 0 || relativeY > 1) {
      return null;
    }

    return Offset(relativeX, relativeY);
  }
}

/// Internal device entry model
class _DeviceEntry {
  final String id;
  final String name;
  final UIPlatform platform;
  final bool isConnected;

  const _DeviceEntry({
    required this.id,
    required this.name,
    required this.platform,
    required this.isConnected,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is _DeviceEntry &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}

/// Custom painter for element overlays
class _ElementOverlayPainter extends CustomPainter {
  final List<UIElement> elements;
  final UIElement? hoveredElement;
  final UIElement? inspectedElement;
  final int deviceWidth;
  final int deviceHeight;
  final Size containerSize;
  final double scale;

  _ElementOverlayPainter({
    required this.elements,
    this.hoveredElement,
    this.inspectedElement,
    required this.deviceWidth,
    required this.deviceHeight,
    required this.containerSize,
    required this.scale,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final displayWidth = deviceWidth * scale;
    final displayHeight = deviceHeight * scale;
    final offsetX = (containerSize.width - displayWidth) / 2;
    final offsetY = (containerSize.height - displayHeight) / 2;

    for (final element in elements) {
      if (element.bounds == null) continue;

      final bounds = element.bounds!;
      final rect = Rect.fromLTWH(
        offsetX + bounds.x * scale,
        offsetY + bounds.y * scale,
        bounds.width * scale,
        bounds.height * scale,
      );

      final isHovered = element == hoveredElement;
      final isInspected = element == inspectedElement;

      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = isInspected ? 2 : 1
        ..color = isInspected
            ? Colors.blue
            : isHovered
                ? Colors.orange
                : Colors.white.withOpacity(0.3);

      canvas.drawRect(rect, paint);

      // Fill for selected/hovered
      if (isInspected || isHovered) {
        final fillPaint = Paint()
          ..style = PaintingStyle.fill
          ..color = (isInspected ? Colors.blue : Colors.orange).withOpacity(0.1);
        canvas.drawRect(rect, fillPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ElementOverlayPainter oldDelegate) {
    return oldDelegate.hoveredElement != hoveredElement ||
        oldDelegate.inspectedElement != inspectedElement ||
        oldDelegate.elements.length != elements.length;
  }
}

