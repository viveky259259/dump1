import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../presentation/providers/app_provider.dart';
import '../../services/ios_simulator_service.dart';

class IosSimulatorPanel extends StatefulWidget {
  final bool showManualControls;

  const IosSimulatorPanel({super.key, this.showManualControls = false});

  @override
  State<IosSimulatorPanel> createState() => _IosSimulatorPanelState();
}

class _IosSimulatorPanelState extends State<IosSimulatorPanel> {
  bool _requestedRefresh = false;
  Offset? _dragStart;
  Offset? _dragLatest;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_requestedRefresh) {
      _requestedRefresh = true;
      final provider = context.read<AppProvider>();
      if (provider.iosSimulators.isEmpty && !provider.isIosSimulatorLoading) {
        provider.refreshIosSimulators();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, appProvider, child) {
        final screenshot = appProvider.iosScreenshotBytes;
        final status = appProvider.iosStatus ??
            (appProvider.isIosPreviewActive
                ? 'Streaming...'
                : 'Waiting for preview');

        return Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.phone_iphone, size: 18),
                  const SizedBox(width: 8),
                  const Text(
                    'iOS Simulator Preview',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const Spacer(),
                  Text(
                    status,
                    style: TextStyle(
                      fontSize: 12,
                      color: appProvider.isIosPreviewActive
                          ? Colors.green
                          : Colors.grey,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildSimulatorDropdown(appProvider),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: appProvider.isIosSimulatorLoading
                        ? null
                        : () => appProvider.refreshIosSimulators(),
                    icon: appProvider.isIosSimulatorLoading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.refresh),
                    tooltip: 'Refresh simulators',
                  ),
                ],
              ),
              if (widget.showManualControls) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: appProvider.isIosPreviewActive ||
                              appProvider.isIosPreviewStarting
                          ? null
                          : () => appProvider.startIosPreview(),
                      icon: appProvider.isIosPreviewStarting
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.play_arrow),
                      label: const Text('Start Preview'),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: appProvider.isIosPreviewActive
                          ? () => appProvider.stopIosPreview()
                          : null,
                      icon: const Icon(Icons.stop),
                      label: const Text('Stop Preview'),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: 12),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade800),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: screenshot != null
                      ? _buildScreenshot(screenshot)
                      : _buildPlaceholder(appProvider),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Last frame: ${_formatTimestamp(appProvider.iosLastFrameTime)}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSimulatorDropdown(AppProvider appProvider) {
    final simulators = appProvider.iosSimulators;
    final selected = appProvider.selectedIosSimulator;

    if (simulators.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: const Text(
          'No simulators detected - install Xcode or run `xcode-select --install`',
          style: TextStyle(fontSize: 12),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: DropdownButton<IOSSimulatorDevice>(
        value: selected ?? simulators.first,
        isExpanded: true,
        underline: const SizedBox(),
        items: simulators.map((sim) {
          return DropdownMenuItem<IOSSimulatorDevice>(
            value: sim,
            child: Text(
              '${sim.name} (${sim.runtime.split('.').last})',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          );
        }).toList(),
        onChanged: appProvider.isIosPreviewActive
            ? null
            : (device) {
                if (device != null) {
                  appProvider.setSelectedIosSimulator(device);
                }
              },
      ),
    );
  }

  Widget _buildScreenshot(Uint8List screenshot) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final appProvider = context.read<AppProvider>();
        final containerSize = Size(
          constraints.maxWidth,
          constraints.maxHeight,
        );

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (details) =>
              _handleTap(details.localPosition, containerSize, appProvider),
          onDoubleTapDown: (details) => _handleTap(
            details.localPosition,
            containerSize,
            appProvider,
            doubleTap: true,
          ),
          onPanStart: (details) {
            _dragStart = details.localPosition;
            _dragLatest = details.localPosition;
          },
          onPanUpdate: (details) {
            _dragLatest = details.localPosition;
          },
          onPanEnd: (details) {
            if (_dragStart != null && _dragLatest != null) {
              _handleDrag(
                _dragStart!,
                _dragLatest!,
                containerSize,
                appProvider,
              );
            }
            _dragStart = null;
            _dragLatest = null;
          },
          child: FittedBox(
            fit: BoxFit.contain,
            alignment: Alignment.center,
            child: Image.memory(
              screenshot,
              gaplessPlayback: true,
              filterQuality: FilterQuality.medium,
            ),
          ),
        );
      },
    );
  }

  Widget _buildPlaceholder(AppProvider appProvider) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.all(24),
      child: Text(
        appProvider.isIosPreviewStarting
            ? 'Booting simulator...'
            : 'Preview starts automatically when an iOS run begins. '
                'Tap, double-tap, or drag anywhere to mirror the interaction on the simulator.',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.white70),
      ),
    );
  }

  String _formatTimestamp(DateTime? time) {
    if (time == null) return '-';
    final local = time.toLocal();
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    return '${twoDigits(local.hour)}:${twoDigits(local.minute)}:${twoDigits(local.second)}';
  }

  void _handleTap(
    Offset localPosition,
    Size containerSize,
    AppProvider appProvider, {
    bool doubleTap = false,
  }) {
    if (!appProvider.isIosPreviewActive) return;
    final normalized =
        _normalizedPosition(localPosition, containerSize, appProvider);
    if (normalized == null) return;
    appProvider.sendPreviewTap(normalized, doubleTap: doubleTap);
  }

  void _handleDrag(
    Offset start,
    Offset end,
    Size containerSize,
    AppProvider appProvider,
  ) {
    if (!appProvider.isIosPreviewActive) return;
    final startNorm =
        _normalizedPosition(start, containerSize, appProvider);
    final endNorm = _normalizedPosition(end, containerSize, appProvider);
    if (startNorm == null || endNorm == null) return;
    appProvider.sendPreviewDrag(startNorm, endNorm);
  }

  Offset? _normalizedPosition(
    Offset position,
    Size containerSize,
    AppProvider appProvider,
  ) {
    final imageSize = appProvider.iosScreenshotResolution;
    if (imageSize == null ||
        containerSize.width <= 0 ||
        containerSize.height <= 0) {
      return null;
    }

    final scale = math.min(
      containerSize.width / imageSize.width,
      containerSize.height / imageSize.height,
    );

    final displayWidth = imageSize.width * scale;
    final displayHeight = imageSize.height * scale;
    final offsetX = (containerSize.width - displayWidth) / 2;
    final offsetY = (containerSize.height - displayHeight) / 2;

    final relativeX = (position.dx - offsetX) / displayWidth;
    final relativeY = (position.dy - offsetY) / displayHeight;

    if (relativeX < 0 || relativeX > 1 || relativeY < 0 || relativeY > 1) {
      return null;
    }

    return Offset(relativeX, relativeY);
  }
}
