import 'dart:async';

import 'package:advanced_tester/services/service_manager.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/inspector_service.dart';
import '../../services/ai_test_generation_service.dart';
import '../../presentation/providers/app_provider.dart';

class WidgetTreePanel extends StatefulWidget {
  const WidgetTreePanel({super.key});

  @override
  State<WidgetTreePanel> createState() => _WidgetTreePanelState();
}

class _WidgetTreePanelState extends State<WidgetTreePanel> {
  WidgetTreeNode? _rootNode;
  bool _isLoading = false;
  String? _error;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  final Set<String> _expandedNodes = <String>{};
  Timer? _autoRefreshTimer;
  bool _hasTriedAutoRefresh = false;

  static const Set<String> _multiChildWidgets = {
    'Column',
    'Row',
    'Stack',
    'Container',
    'Padding',
    'Center',
    'Align',
    'Positioned',
    'Flex',
    'Wrap',
    'Flow',
    'ListView',
    'GridView',
    'CustomScrollView',
    'SingleChildScrollView',
    'PageView',
    'TabBarView',
    'SliverList',
    'SliverGrid',
    'SliverAppBar',
    'SliverToBoxAdapter',
    'SliverFillRemaining',
    'SliverPadding',
  };
  // Comprehensive list of Flutter layout widgets that should be expanded by default
  static const Set<String> _layoutWidgets = {
    // Basic layout widgets
    'Column',
    'Row',
    'Stack',
    'Container',
    'Padding',
    'Center',
    'Align',
    'Positioned',
    'Flex',
    'Wrap',
    'Flow',

    // Scrollable widgets
    'ListView',
    'GridView',
    'CustomScrollView',
    'SingleChildScrollView',
    'PageView',
    'TabBarView',
    'SliverList',
    'SliverGrid',
    'SliverAppBar',
    'SliverToBoxAdapter',
    'SliverFillRemaining',
    'SliverPadding',

    // Scaffold and app structure
    'Scaffold',
    'AppBar',
    'BottomNavigationBar',
    'Drawer',
    'EndDrawer',
    'FloatingActionButton',
    'BottomAppBar',
    'BottomSheet',
    'PersistentFooterButtons',

    // Sizing and constraints
    'Expanded',
    'Flexible',
    'SizedBox',
    'AspectRatio',
    'FractionallySizedBox',
    'IntrinsicHeight',
    'IntrinsicWidth',
    'ConstrainedBox',
    'LimitedBox',
    'UnconstrainedBox',
    'OverflowBox',
    'FittedBox',

    // Layout builders and responsive
    'LayoutBuilder',
    'OrientationBuilder',
    'MediaQuery',

    // Safety and boundaries
    'SafeArea',
    'Visibility',
    'Offstage',
    'IgnorePointer',
    'AbsorbPointer',

    // Transformation
    'Transform',
    'RotatedBox',
    'ClipRect',
    'ClipRRect',
    'ClipOval',
    'ClipPath',

    // Stack-based layouts
    'IndexedStack',
    'PositionedDirectional',

    // Table layouts
    'Table',
    'TableRow',
    'TableCell',

    // Card and surface layouts
    'Card',
    'Material',
    'Surface',

    // Tabs and navigation
    'TabBar',
    'NavigationBar',
    'NavigationRail',

    // Additional Slivers
    'SliverFillViewport',
    'SliverFixedExtentList',
    'SliverPrototypeExtentList',
    'SliverOpacity',
    'SliverIgnorePointer',

    // Other common layout widgets
    'Divider',
    'VerticalDivider',
    'Spacer',
    'Gap', // From gap package if used
    'AnimatedContainer',
    'AnimatedPadding',
    'AnimatedAlign',
    'AnimatedPositioned',
    'DecoratedBox',
    'ColoredBox',
  };

  @override
  void initState() {
    super.initState();
    _refreshTree();
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.toLowerCase();
      });
    });

    // Listen to AppProvider changes to auto-refresh when URL becomes available
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final appProvider = context.read<AppProvider>();
      appProvider.addListener(_onAppProviderChanged);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _autoRefreshTimer?.cancel();
    // Remove listener to prevent memory leaks
    try {
      final appProvider = context.read<AppProvider>();
      appProvider.removeListener(_onAppProviderChanged);
    } catch (e) {
      // Ignore errors during dispose - widget might be deactivated
    }
    super.dispose();
  }

  /// Clear widget tree panel state
  void clearWidgetTreeState() {
    setState(() {
      _rootNode = null;
      _isLoading = false;
      _error = null;
      _searchQuery = '';
      _expandedNodes.clear();
      _hasTriedAutoRefresh = false;
    });
    _searchController.clear();
    _autoRefreshTimer?.cancel();
  }

  void _onAppProviderChanged() {
    if (!mounted) return;

    final appProvider = context.read<AppProvider>();

    // Clear widget tree state when project is stopped
    if (!appProvider.isRunning && _rootNode != null) {
      print('Project stopped - clearing widget tree state');
      clearWidgetTreeState();
      return;
    }

    // Auto-refresh when vmServiceUri becomes available
    if (appProvider.vmServiceUri != null &&
        appProvider.inspectorService != null) {
      // Only refresh if we don't already have a tree or if there was an error
      if (_rootNode == null || _error != null) {
        print('Auto-refreshing widget tree - vmServiceUri is available');
        _refreshTree();
        _hasTriedAutoRefresh = true;
      }
    } else if (appProvider.vmServiceUri != null && !_hasTriedAutoRefresh) {
      // Start a timer to check for inspector service availability
      _startAutoRefreshTimer();
    }
  }

  void _startAutoRefreshTimer() {
    _autoRefreshTimer?.cancel();
    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 2), (
      timer,
    ) async {
      if (!mounted) {
        timer.cancel();
        return;
      }

      final appProvider = context.read<AppProvider>();
      if (appProvider.inspectorService != null) {
        print(
          'Inspector service became available - auto-refreshing widget tree',
        );
        await _refreshTree();
        _hasTriedAutoRefresh = true;
        timer.cancel();
      } else if (_rootNode != null) {
        // Already have a tree, stop the timer
        timer.cancel();
      }
    });

    // Cancel timer after 30 seconds to avoid running indefinitely
    Timer(const Duration(seconds: 30), () {
      _autoRefreshTimer?.cancel();
    });
  }

  double _calculateTreeWidth() {
    if (_rootNode == null) return 300; // Default minimum width

    int maxDepth = _getMaxDepth(_rootNode!, 0);
    // Calculate width based on depth: base width + (depth * indentation)
    double baseWidth = 200;
    double depthWidth = maxDepth * 20.0; // 20px per level of indentation
    double nodeContentWidth = 200; // Approximate width needed for node content

    return baseWidth + depthWidth + nodeContentWidth;
  }

  int _getMaxDepth(WidgetTreeNode node, int currentDepth) {
    if (node.children.isEmpty) {
      return currentDepth;
    }

    int maxChildDepth = currentDepth;
    for (final child in node.children) {
      int childDepth = _getMaxDepth(child, currentDepth + 1);
      if (childDepth > maxChildDepth) {
        maxChildDepth = childDepth;
      }
    }
    return maxChildDepth;
  }

  /// Automatically expand widgets based on smart expansion rules
  void _autoExpandLayoutWidgets(WidgetTreeNode node) {
    final nodeKey = node.objectId ?? '${node.type}_${node.hashCode}';
    final nodeType = node.type ?? '';
    final childCount = node.children.length;
    final description = node.description ?? nodeType;

    bool shouldExpand = false;
    String reason = '';

    // Always expand the root node
    if (_rootNode == node) {
      shouldExpand = true;
      reason = 'root node';
    }
    // Expand if this is a layout widget (high priority)
    else if (_multiChildWidgets.contains(description) && childCount > 1) {
      shouldExpand = true;
      reason = 'layout widget';
    }
    // Expand commonly important structural widgets
    else if (nodeType.toLowerCase().contains('scaffold') ||
        nodeType.toLowerCase().contains('app') ||
        nodeType.toLowerCase().contains('body') ||
        nodeType.toLowerCase().contains('main')) {
      shouldExpand = true;
      reason = 'structural widget';
    }
    // NEW RULE: Expand widgets with 0 or 1 children (avoid unnecessary nesting)
    else if (childCount <= 1) {
      shouldExpand = true;
      reason = 'single/no child widget';
    }
    // Collapse widgets with multiple children (2+) by default
    else {
      shouldExpand = false;
      reason =
          'multi-child widget (${childCount} children) - collapsed for clarity';
    }

    if (shouldExpand) {
      _expandedNodes.add(nodeKey);
      print('Auto-expanding $nodeType: $reason');
    } else {
      print('Keeping collapsed $nodeType: $reason');
    }

    // Recursively process children
    for (final child in node.children) {
      _autoExpandLayoutWidgets(child);
    }
  }

  /// Check if a widget type is a layout widget
  bool _isLayoutWidget(String? widgetType) {
    if (widgetType == null) return false;
    return _layoutWidgets.contains(widgetType);
  }

  /// Count total nodes in the tree
  int _getTotalNodeCount(WidgetTreeNode node) {
    int count = 1; // Count this node
    for (final child in node.children) {
      count += _getTotalNodeCount(child);
    }
    return count;
  }

  /// Expand all widgets in the tree
  void _expandAll() {
    if (_rootNode == null) return;
    setState(() {
      _expandAllNodes(_rootNode!);
    });
  }

  /// Recursively expand all nodes
  void _expandAllNodes(WidgetTreeNode node) {
    final nodeKey = node.objectId ?? '${node.type}_${node.hashCode}';
    _expandedNodes.add(nodeKey);
    for (final child in node.children) {
      _expandAllNodes(child);
    }
  }

  /// Collapse all widgets and re-apply smart expansion rules
  void _collapseAll() {
    if (_rootNode == null) return;
    setState(() {
      _expandedNodes.clear();
      // Re-apply smart expansion rules
      _autoExpandLayoutWidgets(_rootNode!);
    });
  }

  Future<void> _refreshTree() async {
    final appProvider = context.read<AppProvider>();
    final inspectorService = appProvider.inspectorService as InspectorService?;

    if (inspectorService == null) {
      setState(() {
        _error = 'Inspector service not available';
        _rootNode = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final isAvailable = await inspectorService.isInspectorAvailable();
      if (!isAvailable) {
        setState(() {
          _error =
              'Flutter widget inspector not ready. Make sure the app is running in debug mode.';
          _isLoading = false;
        });
        return;
      }

      final rootNode = await inspectorService.getRootWidgetSummaryTree();
      setState(() {
        _rootNode = rootNode;
        _isLoading = false;
        _error = rootNode == null ? 'No widget tree data available' : null;
        // Auto-expand the root node and layout widgets
        if (rootNode != null) {
          _autoExpandLayoutWidgets(rootNode);
        }
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load widget tree: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSearchBar(),
        _buildHeader(),
        const Divider(height: 1),
        Expanded(child: _buildContent()),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        children: [
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText:
                  'Search widgets by name, content, or properties... (try "layout", "text", "hello")',
              prefixIcon: Icon(
                Icons.search,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                size: 20,
              ),
              suffixIcon: _searchQuery.isNotEmpty
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_getLayoutWidgetCount() > 0)
                          Container(
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.deepPurple.shade100,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '${_getLayoutWidgetCount()}L',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepPurple.shade700,
                              ),
                            ),
                          ),
                        IconButton(
                          icon: const Icon(Icons.clear, size: 20),
                          onPressed: () {
                            _searchController.clear();
                          },
                        ),
                      ],
                    )
                  : null,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: Theme.of(context).colorScheme.outline,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: Theme.of(context).colorScheme.outline.withOpacity(0.5),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: Theme.of(context).colorScheme.primary,
                  width: 2,
                ),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 8,
              ),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surface,
            ),
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          if (_searchQuery.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    if (_searchQuery == 'layout')
                      Chip(
                        label: Text(
                          'Layout Widgets',
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.deepPurple.shade700,
                          ),
                        ),
                        backgroundColor: Colors.deepPurple.shade50,
                        side: BorderSide(color: Colors.deepPurple.shade200),
                        onDeleted: () => _searchController.clear(),
                      )
                    else if (_searchQuery == 'text')
                      Chip(
                        label: Text(
                          'Text Widgets',
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.green.shade700,
                          ),
                        ),
                        backgroundColor: Colors.green.shade50,
                        side: BorderSide(color: Colors.green.shade200),
                        onDeleted: () => _searchController.clear(),
                      )
                    else
                      Chip(
                        label: Text(
                          'Search: "$_searchQuery"',
                          style: const TextStyle(fontSize: 11),
                        ),
                        onDeleted: () => _searchController.clear(),
                      ),
                    const SizedBox(width: 8),
                    if (_searchQuery != 'layout')
                      ActionChip(
                        label: const Text(
                          'Layout',
                          style: TextStyle(fontSize: 11),
                        ),
                        onPressed: () {
                          _searchController.text = 'layout';
                        },
                      ),
                    const SizedBox(width: 8),
                    if (_searchQuery != 'text')
                      ActionChip(
                        label: const Text(
                          'Text',
                          style: TextStyle(fontSize: 11),
                        ),
                        onPressed: () {
                          _searchController.text = 'text';
                        },
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  int _getLayoutWidgetCount() {
    if (_rootNode == null) return 0;
    return _countLayoutWidgets(_rootNode!);
  }

  int _countLayoutWidgets(WidgetTreeNode node) {
    int count = _isLayoutWidget(node.type) ? 1 : 0;
    for (final child in node.children) {
      count += _countLayoutWidgets(child);
    }
    return count;
  }

  Widget _buildHeader() {
    final expandedCount = _expandedNodes.length;
    final totalNodes = _rootNode != null ? _getTotalNodeCount(_rootNode!) : 0;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Widget Tree',
                style: Theme.of(
                  context,
                ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
              ),
              if (totalNodes > 0)
                Text(
                  '$expandedCount/$totalNodes expanded • Smart: Multi-child widgets collapsed',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontSize: 10,
                  ),
                ),
            ],
          ),
          const Spacer(),
          if (_isLoading)
            const SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          else ...[
            IconButton(
              icon: const Icon(Icons.unfold_less_outlined, size: 20),
              onPressed: _collapseAll,
              tooltip: 'Collapse all multi-child widgets',
            ),
            IconButton(
              icon: const Icon(Icons.unfold_more_outlined, size: 20),
              onPressed: _expandAll,
              tooltip: 'Expand all widgets',
            ),
            IconButton(
              icon: const Icon(Icons.refresh, size: 20),
              onPressed: _refreshTree,
              tooltip: 'Refresh widget tree',
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 32,
              height: 32,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Loading widget tree...',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(
                    context,
                  ).colorScheme.errorContainer.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.error_outline,
                  size: 48,
                  color: Theme.of(context).colorScheme.error,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.error,
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _refreshTree,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_rootNode == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.account_tree_outlined,
              size: 64,
              color: Theme.of(
                context,
              ).colorScheme.onSurfaceVariant.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No widget tree data available',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(8),
          topRight: Radius.circular(8),
        ),
      ),
      child: Scrollbar(
        thumbVisibility: true,
        child: Scrollbar(
          thumbVisibility: true,
          notificationPredicate: (notification) => notification.depth == 1,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Container(
              width: _calculateTreeWidth(),
              constraints: BoxConstraints(
                minWidth: MediaQuery.of(context).size.width - 40,
              ),
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                shrinkWrap: false,
                children: _buildFilteredNodes(_rootNode!, 0),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildFilteredNodes(WidgetTreeNode node, int depth) {
    if (_searchQuery.isNotEmpty) {
      // Search mode: show all matching nodes
      return _buildSearchResults(node, depth);
    } else {
      // Normal mode: show expanded nodes only
      return [_buildNodeTile(node, depth)];
    }
  }

  List<Widget> _buildSearchResults(WidgetTreeNode node, int depth) {
    List<Widget> results = [];

    // Check if current node matches search
    final nodeType = (node.type ?? '').toLowerCase();
    final nodeDescription = (node.description ?? '').toLowerCase();
    final nodeDisplayName = _getWidgetDisplayName(node).toLowerCase();

    bool matches = false;

    if (_searchQuery == 'layout') {
      // Special search for layout widgets
      matches = _isLayoutWidget(node.type);
    } else if (_searchQuery == 'text') {
      // Special search for text widgets
      matches = nodeType.contains('text');
    } else {
      // ENHANCED SEARCH: Include attributes in search
      matches = _performEnhancedSearch(
        node,
        nodeType,
        nodeDescription,
        nodeDisplayName,
      );
    }

    if (matches) {
      results.add(_buildNodeTile(node, depth));
    }

    // Recursively search children
    for (final child in node.children) {
      results.addAll(_buildSearchResults(child, depth + 1));
    }

    return results;
  }

  /// Perform enhanced search including attributes and content
  bool _performEnhancedSearch(
    WidgetTreeNode node,
    String nodeType,
    String nodeDescription,
    String nodeDisplayName,
  ) {
    // Search in basic node properties
    if (nodeType.contains(_searchQuery) ||
        nodeDescription.contains(_searchQuery) ||
        nodeDisplayName.contains(_searchQuery)) {
      return true;
    }

    // Search in structured attributes
    if (node.attributes != null) {
      for (final attr in node.attributes!) {
        if (attr.name.toLowerCase().contains(_searchQuery) ||
            attr.label.toLowerCase().contains(_searchQuery)) {
          return true;
        }
      }
    }

    // Search in cached attributes
    final appProvider = context.read<AppProvider>();
    final inspectorService = appProvider.inspectorService as InspectorService?;
    if (inspectorService != null && node.objectId != null) {
      final cachedAttributes = inspectorService.getCachedAttributes(
        node.objectId,
      );
      if (cachedAttributes != null) {
        for (final attr in cachedAttributes) {
          if (attr.name.toLowerCase().contains(_searchQuery) ||
              attr.label.toLowerCase().contains(_searchQuery)) {
            return true;
          }
        }
      }
    }

    return false;
  }

  Widget _buildNodeTile(WidgetTreeNode node, int depth) {
    final appProvider = context.watch<AppProvider>();
    final isSelected = appProvider.selectedWidget?.objectId == node.objectId;
    final hasChildren = node.hasChildren || node.children.isNotEmpty;
    final nodeKey = node.objectId ?? '${node.type}_${node.hashCode}';
    final isExpanded = _expandedNodes.contains(nodeKey);

    // Generate enhanced tooltip
    final tooltip = _buildEnhancedTooltip(node);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Tooltip(
          message: tooltip,
          preferBelow: false,
          waitDuration: const Duration(milliseconds: 500),
          child: GestureDetector(
            onTap: () => _selectNode(node),
            onSecondaryTap: () => _showContextMenu(node),
            onLongPress: () => _showContextMenu(node),
            child: InkWell(
              onTap: () => _selectNode(node),
              onHover: (isHovering) {
                // Add hover effect if needed
              },
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 1),
                padding: EdgeInsets.only(
                  left: depth * 20.0 + 8,
                  right: 8,
                  top: 6,
                  bottom: 6,
                ),
                decoration: isSelected
                    ? BoxDecoration(
                        color: Theme.of(
                          context,
                        ).colorScheme.primaryContainer.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: Theme.of(
                            context,
                          ).colorScheme.primary.withOpacity(0.3),
                        ),
                      )
                    : null,
                child: Row(
                  children: [
                    // Expand/collapse arrow
                    if (hasChildren)
                      GestureDetector(
                        onTap: () => _toggleNodeExpansion(nodeKey),
                        child: Container(
                          padding: const EdgeInsets.all(2),
                          child: Icon(
                            isExpanded
                                ? Icons.keyboard_arrow_down
                                : Icons.keyboard_arrow_right,
                            size: 16,
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                      )
                    else
                      const SizedBox(width: 20),
                    // Widget type icon
                    _getWidgetIcon(node),
                    const SizedBox(width: 8),
                    // Widget name/type
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              _getWidgetDisplayName(node),
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: isSelected
                                    ? FontWeight.w600
                                    : (_isLayoutWidget(node.description)
                                          ? FontWeight.w600
                                          : FontWeight.w500),
                                color: _getWidgetTextColor(node, isSelected),
                                letterSpacing: 0.1,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          // Enhanced smart widget badges
                          ..._buildWidgetBadges(node),
                        ],
                      ),
                    ),
                    // Additional info
                    if (node.objectId != null)
                      Container(
                        margin: const EdgeInsets.only(left: 4),
                        child: Icon(
                          Icons.info_outline,
                          size: 12,
                          color: Theme.of(
                            context,
                          ).colorScheme.onSurfaceVariant.withOpacity(0.6),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
        // Render children if expanded
        if (hasChildren && (isExpanded || _searchQuery.isNotEmpty))
          ...node.children.map((child) => _buildNodeTile(child, depth + 1)),
      ],
    );
  }

  void _toggleNodeExpansion(String nodeKey) {
    setState(() {
      if (_expandedNodes.contains(nodeKey)) {
        _expandedNodes.remove(nodeKey);
      } else {
        _expandedNodes.add(nodeKey);
      }
    });
  }

  Widget _getWidgetIcon(WidgetTreeNode node) {
    final name = node.description ?? '';
    final typeLower = name.toLowerCase();
    IconData iconData;
    Color iconColor = Theme.of(context).colorScheme.onSurfaceVariant;

    // Check if this is a layout widget first - give them special treatment
    if (_isLayoutWidget(name)) {
      iconColor =
          Colors.deepPurple.shade600; // Distinctive color for layout widgets

      // Specific icons for different layout widget categories
      if (typeLower.contains('scaffold')) {
        iconData = Icons.web_asset_outlined;
      } else if (typeLower.contains('column')) {
        iconData = Icons.view_column_outlined;
      } else if (typeLower.contains('row')) {
        iconData = Icons.table_rows_outlined;
      } else if (typeLower.contains('stack')) {
        iconData = Icons.layers_outlined;
      } else if (typeLower.contains('container') ||
          typeLower.contains('padding')) {
        iconData = Icons.crop_free_outlined;
      } else if (typeLower.contains('center') || typeLower.contains('align')) {
        iconData = Icons.center_focus_weak_outlined;
      } else if (typeLower.contains('expanded') ||
          typeLower.contains('flexible')) {
        iconData = Icons.unfold_more_outlined;
      } else if (typeLower.contains('list') || typeLower.contains('scroll')) {
        iconData = Icons.view_list_outlined;
      } else if (typeLower.contains('grid')) {
        iconData = Icons.grid_view_outlined;
      } else if (typeLower.contains('wrap')) {
        iconData = Icons.wrap_text_outlined;
      } else if (typeLower.contains('appbar')) {
        iconData = Icons.web_stories_outlined;
      } else if (typeLower.contains('safe')) {
        iconData = Icons.security_outlined;
      } else if (typeLower.contains('positioned')) {
        iconData = Icons.place_outlined;
      } else if (typeLower.contains('sized')) {
        iconData = Icons.aspect_ratio_outlined;
      } else if (typeLower.contains('card') || typeLower.contains('material')) {
        iconData = Icons.credit_card_outlined;
      } else {
        iconData = Icons.account_tree_outlined; // Default layout icon
      }
    } else {
      // Non-layout widgets get different colors
      if (typeLower.contains('text')) {
        // Special treatment for Text widgets with actual content
        final displayName = _getWidgetDisplayName(node);
        if (displayName.startsWith('Text(')) {
          iconData = Icons.text_format; // Different icon for text with content
          iconColor = Colors.green.shade800;
        } else {
          iconData = Icons.text_fields;
          iconColor = Colors.green.shade600;
        }
      } else if (typeLower.contains('button')) {
        iconData = Icons.smart_button_outlined;
        iconColor = Colors.orange.shade600;
      } else if (typeLower.contains('icon')) {
        iconData = Icons.star_outline;
        iconColor = Colors.amber.shade700;
      } else if (typeLower.contains('image')) {
        iconData = Icons.image_outlined;
        iconColor = Colors.pink.shade600;
      } else if (typeLower.contains('input') || typeLower.contains('field')) {
        iconData = Icons.input_outlined;
        iconColor = Colors.cyan.shade600;
      } else if (typeLower.contains('gesture') ||
          typeLower.contains('inkwell')) {
        iconData = Icons.touch_app_outlined;
        iconColor = Colors.indigo.shade600;
      } else if (typeLower.contains('animation') ||
          typeLower.contains('transition')) {
        iconData = Icons.animation_outlined;
        iconColor = Colors.deepOrange.shade600;
      } else {
        iconData = Icons.widgets_outlined;
        iconColor = Theme.of(context).colorScheme.onSurfaceVariant;
      }
    }

    return Icon(iconData, size: 16, color: iconColor);
  }

  String _getWidgetDisplayName(WidgetTreeNode node) {
    final type = node.type ?? 'Unknown Widget';
    final description = node.description ?? '';

    // Commenting it's bad structured as of now: _ElementDiagnosticableTreeNode('You have pushed the button thi...')"
    // // ENHANCED: Try structured attributes first (most accurate)
    // final attributeContent = _extractContentFromAttributes(node);
    // if (attributeContent.isNotEmpty) {
    //   return attributeContent;
    // }

    // FALLBACK: Use original regex-based extraction for backward compatibility
    final legacyContent = _extractLegacyContent(node, type, description);
    if (legacyContent.isNotEmpty) {
      return legacyContent;
    }

    // DEFAULT: Clean type name
    return _cleanTypeName(type, description);
  }

  /// Legacy content extraction (fallback)
  String _extractLegacyContent(
    WidgetTreeNode node,
    String type,
    String description,
  ) {
    // Special handling for Text widgets - extract and display text content
    if (description == 'Text' || description.contains('Text')) {
      final textContent = _extractTextContent(node);
      if (textContent.isNotEmpty) {
        return "Text('$textContent')";
      }
    }

    // Special handling for other common widgets with important content
    if (description == 'Icon') {
      final iconInfo = _extractIconInfo(description);
      if (iconInfo.isNotEmpty) {
        return "Icon($iconInfo)";
      }
    }

    return '';
  }

  /// Clean type name for display
  String _cleanTypeName(String type, String description) {
    // For widgets with meaningful descriptions, prefer description over type
    if (description.isNotEmpty && description != type) {
      // If description contains useful info beyond just the type, use it
      if (description.length > type.length &&
          !description.toLowerCase().startsWith(type.toLowerCase() + '(#')) {
        return description.length > 50
            ? '${description.substring(0, 50)}...'
            : description;
      } else {
        return description;
      }
    }

    // Default: use type name
    String name = type;

    // Clean up the name for better readability
    if (name.startsWith('_')) {
      name = name.substring(1);
    }

    return name;
  }

  /// Extract text content from Text widget nodes
  String _extractTextContent(WidgetTreeNode node) {
    // Try to extract from description first
    final description = node.description ?? '';

    // Pattern 1: Text('content') or Text("content")
    final singleQuotePattern = RegExp(r"Text\('([^']*)'\)");
    final doubleQuotePattern = RegExp(r'Text\("([^"]*)"\)');

    Match? match = singleQuotePattern.firstMatch(description);
    match ??= doubleQuotePattern.firstMatch(description);

    if (match != null) {
      String content = match.group(1) ?? '';
      // Limit length for display
      return content.length > 30 ? '${content.substring(0, 30)}...' : content;
    }

    // Pattern 2: Look for quoted strings in description
    final quotedStringPattern = RegExp(r"'([^']+)'|" + r'"([^"]+)"');
    match = quotedStringPattern.firstMatch(description);
    if (match != null) {
      String content = match.group(1) ?? match.group(2) ?? '';
      return content.length > 30 ? '${content.substring(0, 30)}...' : content;
    }

    // Pattern 3: Try to extract from properties if available
    if (node.properties != null) {
      final props = node.properties!;

      // Look for common text properties
      final textValue = props['data'] ?? props['text'] ?? props['value'];
      if (textValue != null && textValue.toString().isNotEmpty) {
        String content = textValue.toString();
        return content.length > 30 ? '${content.substring(0, 30)}...' : content;
      }
    }

    return ''; // No text content found
  }

  /// Extract icon information from Icon widget descriptions
  String _extractIconInfo(String description) {
    // Pattern: Icon(Icons.something) or IconData(0x1234)
    final iconPattern = RegExp(
      r'Icons\.([a-zA-Z_]+)|IconData\(0x([a-fA-F0-9]+)\)',
    );
    final match = iconPattern.firstMatch(description);

    if (match != null) {
      if (match.group(1) != null) {
        return 'Icons.${match.group(1)}';
      } else if (match.group(2) != null) {
        return 'IconData(0x${match.group(2)})';
      }
    }

    return '';
  }

  Color _getWidgetTextColor(WidgetTreeNode node, bool isSelected) {
    if (isSelected) {
      return Theme.of(context).colorScheme.onPrimaryContainer;
    }

    final type = node.type?.toLowerCase() ?? '';
    final displayName = _getWidgetDisplayName(node);

    if (type.contains('scaffold') || type.contains('app')) {
      return Colors.blue.shade700;
    } else if (type.contains('text')) {
      // Special styling for Text widgets with content
      if (displayName.startsWith('Text(')) {
        return Colors.green.shade800; // Darker green for text with content
      }
      return Colors.green.shade700;
    } else if (type.contains('button')) {
      return Colors.orange.shade700;
    } else {
      return Theme.of(context).colorScheme.onSurface;
    }
  }

  /// Build enhanced tooltip with attributes and properties
  String _buildEnhancedTooltip(WidgetTreeNode node) {
    final type = node.type ?? 'Widget';
    final displayName = _getWidgetDisplayName(node);

    String tooltip = '';

    // Add display name if different from type
    if (displayName != type) {
      tooltip += displayName;
    }

    // Add structured attributes if available
    List<WidgetAttribute>? attributes = node.attributes;

    // Try cached attributes if node attributes not available
    if (attributes == null || attributes.isEmpty) {
      final appProvider = context.read<AppProvider>();
      final inspectorService =
          appProvider.inspectorService as InspectorService?;
      if (inspectorService != null && node.objectId != null) {
        attributes = inspectorService.getCachedAttributes(node.objectId);
      }
    }

    // Add attributes to tooltip
    if (attributes != null && attributes.isNotEmpty) {
      tooltip += '; Properties:';
      for (final attr in attributes) {
        tooltip += '• ${attr.name}: ${attr.label}';
      }
    }

    return tooltip;
  }

  /// Build smart widget badges
  List<Widget> _buildWidgetBadges(WidgetTreeNode node) {
    final badges = <Widget>[];
    final type = node.type?.toLowerCase() ?? '';
    final displayName = _getWidgetDisplayName(node);

    // Layout widget badge
    if (_isLayoutWidget(node.description)) {
      badges.add(_buildBadge('L', Colors.deepPurple, 'Layout Widget'));
    }
    // Text widget badge (with content)
    else if (type.contains('text') && displayName.startsWith('Text(')) {
      badges.add(_buildBadge('T', Colors.green, 'Text Widget with Content'));
    }
    // Icon widget badge
    else if (type.contains('icon') && displayName.startsWith('Icon(')) {
      badges.add(_buildBadge('I', Colors.amber, 'Icon Widget'));
    }
    // Button widget badge
    else if (type.contains('button') && displayName.contains("'")) {
      badges.add(_buildBadge('B', Colors.orange, 'Button with Text'));
    }
    // TextField widget badge
    else if ((type.contains('field') || type.contains('input')) &&
        displayName.contains("'")) {
      badges.add(_buildBadge('F', Colors.cyan, 'Text Field'));
    }
    // Interactive widget badge
    else if (type.contains('gesture') ||
        type.contains('inkwell') ||
        type.contains('detector')) {
      badges.add(_buildBadge('G', Colors.indigo, 'Interactive Widget'));
    }

    return badges;
  }

  /// Helper: Build a colored badge
  Widget _buildBadge(String letter, MaterialColor color, String tooltip) {
    return Tooltip(
      message: tooltip,
      child: Container(
        margin: const EdgeInsets.only(left: 4),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
        decoration: BoxDecoration(
          color: color.shade100,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.shade300, width: 0.5),
        ),
        child: Text(
          letter,
          style: TextStyle(
            fontSize: 8,
            fontWeight: FontWeight.bold,
            color: color.shade700,
          ),
        ),
      ),
    );
  }

  Future<void> _selectNode(WidgetTreeNode node) async {
    final appProvider = context.read<AppProvider>();
    appProvider.setSelectedWidget(node);

    // if (inspectorService != null && node.objectId != null) {
    //   try {
    //     await inspectorService.selectWidget(node.objectId!);
    //     // Show widget properties dialog
    //     if (mounted) {
    //       _showWidgetPropertyDialog(node);
    //     }
    //   } catch (e) {
    //     if (mounted) {
    //       ScaffoldMessenger.of(context).showSnackBar(
    //         SnackBar(content: Text('Failed to select widget: $e')),
    //       );
    //     }
    //   }
    // } else {
    //   // Even if inspector service is not available, show the dialog
    //   if (mounted) {
    //     _showWidgetPropertyDialog(node);
    //   }
    // }
  }

  void _showContextMenu(WidgetTreeNode node) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final Offset position = renderBox.localToGlobal(Offset.zero);

    showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(
        position.dx + 100, // Adjust position as needed
        position.dy + 50,
        position.dx + 200,
        position.dy + 150,
      ),
      items: [
        const PopupMenuItem<String>(
          value: 'add_test',
          child: Row(
            children: [
              Icon(Icons.add_task, size: 18),
              SizedBox(width: 8),
              Text('Add Test'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'explore_children',
          child: Row(
            children: [
              Icon(Icons.explore, size: 18),
              SizedBox(width: 8),
              Text('Explore Children'),
            ],
          ),
        ),
        const PopupMenuItem<String>(
          value: 'use_ai',
          child: Row(
            children: [
              Icon(Icons.psychology, size: 18),
              SizedBox(width: 8),
              Text('Use AI'),
            ],
          ),
        ),
      ],
    ).then((value) {
      if (value != null) {
        _handleContextMenuAction(value, node);
      }
    });
  }

  void _handleContextMenuAction(String action, WidgetTreeNode node) {
    switch (action) {
      case 'add_test':
        _addTestForWidget(node);
        break;
      case 'explore_children':
        _exploreChildren(node);
        break;
      case 'use_ai':
        _useAIForWidget(node);
        break;
    }
  }

  void _addTestForWidget(WidgetTreeNode node) async {
    try {
      // Check if widget has creation location
      if (node.creationLocation == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Cannot generate test: No source location found for ${node.widgetRuntimeType ?? 'Widget'}',
            ),
            backgroundColor: Colors.orange,
            duration: const Duration(seconds: 3),
          ),
        );
        return;
      }

      // Show loading indicator with AI-specific message
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const AlertDialog(
          content: Row(
            children: [
              CircularProgressIndicator(),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('🤖 Generating AI-powered test file...'),
                    SizedBox(height: 8),
                    Text(
                      'This may take a few moments as AI analyzes your widget',
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );

      // Generate test file using AI
      final appProvider = context.read<AppProvider>();
      final environmentService = appProvider.environmentService;
      final inspectorService =
          appProvider.inspectorService as InspectorService?;

      final aiTestService = AITestGenerationService(
        projectPath: appProvider.selectedProjectPath,
        apiKey: _getOpenAIKey(),
        environmentService: environmentService,
        inspectorService: inspectorService,
        // Note: Dependency services would need to be injected here
        // dependencyService: dependencyService,
        // enhancedDependencyService: enhancedDependencyService,
      );
      final success = await aiTestService.generateTestForWidget(node);

      // Close loading dialog
      if (mounted) {
        Navigator.of(context).pop();
      }

      if (success) {
        final widgetType =
            node.widgetRuntimeType ?? node.description ?? 'Widget';
        final sourceFile = node.creationLocation!.file;
        final testFile = sourceFile
            .replaceFirst('lib/', 'test/')
            .replaceAll('.dart', '_test.dart');

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('🤖 AI Test file generated successfully!'),
                Text('Widget: $widgetType'),
                Text('Test file: $testFile'),
                SizedBox(height: 4),
                Text(
                  '✨ AI-generated comprehensive test cases included',
                  style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                ),
              ],
            ),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 5),
            action: SnackBarAction(
              label: 'View in Details',
              onPressed: () {
                // Navigate to Details tab to see test generation info
                // The Overview tab now shows test generation information
              },
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '❌ Failed to generate AI test file for ${node.widgetRuntimeType ?? 'Widget'}',
            ),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      // Close loading dialog if still open
      if (mounted) {
        Navigator.of(context).pop();
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Error generating AI test: $e'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  /// Get OpenAI API key from environment service
  String? _getOpenAIKey() {
    try {
      final appProvider = context.read<AppProvider>();
      final environmentService = appProvider.environmentService;

      if (environmentService != null &&
          environmentService.getApiKey('openai') != null &&
          environmentService.getApiKey('openai')!.isNotEmpty) {
        return environmentService.getApiKey('openai');
      } else {
        final openAIApiKey = ServiceManagerConfig().openAIApiKey;
        if (openAIApiKey != null && openAIApiKey.isNotEmpty) {
          return openAIApiKey;
        }
      }
    } catch (e) {
      // Fallback to environment variables if service not available
      const envKey = String.fromEnvironment('OPENAI_API_KEY');
      if (envKey.isNotEmpty) {
        return envKey;
      }
    }

    return null;
  }

  void _exploreChildren(WidgetTreeNode node) {
    // Expand the node to show its children
    final nodeKey = node.objectId ?? '${node.type}_${node.hashCode}';
    setState(() {
      _expandedNodes.add(nodeKey);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Exploring children of ${node.type ?? 'Widget'}'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _useAIForWidget(WidgetTreeNode node) {
    // TODO: Implement AI functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'AI Analysis for ${node.type ?? 'Widget'} - Coming Soon!',
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

class WidgetDetailsDialog extends StatefulWidget {
  final WidgetTreeNode node;

  const WidgetDetailsDialog({super.key, required this.node});

  @override
  State<WidgetDetailsDialog> createState() => _WidgetDetailsDialogState();
}

class _WidgetDetailsDialogState extends State<WidgetDetailsDialog> {
  Map<String, dynamic>? _properties;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProperties();
  }

  Future<void> _loadProperties() async {
    if (widget.node.objectId == null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }

    final appProvider = context.read<AppProvider>();
    final inspectorService = appProvider.inspectorService as InspectorService?;

    if (inspectorService == null) {
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      final properties = await inspectorService.getWidgetDetails(
        widget.node.objectId!,
      );
      setState(() {
        _properties = properties?.fold({}, (a, b) => a?..addAll(b));
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.node.type ?? 'Widget Details'),
      content: SizedBox(
        width: 400,
        height: 500,
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (widget.node.description != null) ...[
                      const Text(
                        'Description:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(widget.node.description!),
                      const SizedBox(height: 8),
                    ],
                    if (_properties != null) ...[
                      const Text(
                        'Properties:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      ..._properties!.entries.map(
                        (entry) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 120,
                                child: Text(
                                  '${entry.key}:',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Expanded(child: Text('${entry.value}')),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}
