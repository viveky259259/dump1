import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../services/dependency_analysis_service.dart';
import '../../services/inspector_service.dart';
import '../../presentation/providers/app_provider.dart';

class DependencyAnalysisPanel extends StatefulWidget {
  final WidgetTreeNode? selectedWidget;

  const DependencyAnalysisPanel({super.key, required this.selectedWidget});

  @override
  State<DependencyAnalysisPanel> createState() =>
      _DependencyAnalysisPanelState();
}

class _DependencyAnalysisPanelState extends State<DependencyAnalysisPanel> {
  List<WidgetDependency>? _dependencies;
  bool _isAnalyzing = false;
  String? _error;
  String _generatedTestCode = '';

  @override
  void initState() {
    super.initState();
    _analyzeDependencies();
  }

  @override
  void didUpdateWidget(DependencyAnalysisPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.selectedWidget != oldWidget.selectedWidget) {
      _analyzeDependencies();
    }
  }

  Future<void> _analyzeDependencies() async {
    if (widget.selectedWidget == null) {
      setState(() {
        _dependencies = null;
        _generatedTestCode = '';
        _error = null;
      });
      return;
    }

    setState(() {
      _isAnalyzing = true;
      _error = null;
    });

    try {
      final appProvider = context.read<AppProvider>();
      final inspectorService =
          appProvider.inspectorService as InspectorService?;

      if (inspectorService == null) {
        setState(() {
          _error = 'Inspector service not available';
          _isAnalyzing = false;
        });
        return;
      }

      final analysisService = DependencyAnalysisService(inspectorService);

      print(
        '🎯 DependencyAnalysisPanel: Starting analysis for ${widget.selectedWidget!.type}',
      );
      print('🎯 Widget objectId: ${widget.selectedWidget!.objectId}');

      // Use enhanced analysis that combines source code and tree analysis
      final dependencies = await analysisService
          .analyzeWidgetDependenciesEnhanced(widget.selectedWidget!);

      print('🎯 Analysis complete: Found ${dependencies.length} dependencies');

      final targetWidgetName = widget.selectedWidget!.type ?? 'YourWidget';
      final testCode = analysisService.generateTestSetupCode(
        dependencies,
        targetWidgetName,
      );

      setState(() {
        _dependencies = dependencies;
        _generatedTestCode = testCode;
        _isAnalyzing = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to analyze dependencies: $e';
        _isAnalyzing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(),
          const Divider(height: 1),
          Expanded(child: _buildContent()),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(8),
          topRight: Radius.circular(8),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.analytics_outlined,
            size: 20,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Text(
            'Dependency Analysis',
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
          ),
          const Spacer(),
          if (widget.selectedWidget != null) ...[
            IconButton(
              icon: const Icon(Icons.refresh, size: 18),
              onPressed: _isAnalyzing ? null : _analyzeDependencies,
              tooltip: 'Refresh analysis',
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (widget.selectedWidget == null) {
      return _buildEmptyState();
    }

    if (_isAnalyzing) {
      return _buildLoadingState();
    }

    if (_error != null) {
      return _buildErrorState();
    }

    return DefaultTabController(
      length: 2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TabBar(
            tabs: [
              Tab(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.list_alt, size: 16),
                    const SizedBox(width: 4),
                    Text('Dependencies (${_dependencies?.length ?? 0})'),
                  ],
                ),
              ),
              const Tab(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.code, size: 16),
                    SizedBox(width: 4),
                    Text('Test Code'),
                  ],
                ),
              ),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [_buildDependenciesList(), _buildTestCodeView()],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.analytics_outlined,
            size: 48,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'Select a widget to analyze dependencies',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Click on any widget in the tree to see what dependencies\nare required for testing',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          Text(
            'Analyzing dependencies...',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 48,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.error,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _analyzeDependencies,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDependenciesList() {
    if (_dependencies == null || _dependencies!.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.check_circle_outline,
              size: 48,
              color: Colors.green.shade400,
            ),
            const SizedBox(height: 16),
            Text(
              'No dependencies detected!',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.green.shade700,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'This widget can be tested without additional setup.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ],
        ),
      );
    }

    // Group dependencies by category
    final groupedDependencies = <String, List<WidgetDependency>>{};
    for (final dependency in _dependencies!) {
      groupedDependencies
          .putIfAbsent(dependency.category, () => [])
          .add(dependency);
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        _buildSelectedWidgetCard(),
        const SizedBox(height: 16),
        ...groupedDependencies.entries.map(
          (entry) => _buildCategorySection(entry.key, entry.value),
        ),
      ],
    );
  }

  Widget _buildSelectedWidgetCard() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.widgets,
            color: Theme.of(context).colorScheme.primary,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Target Widget',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  widget.selectedWidget!.type ?? 'Unknown',
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                if (widget.selectedWidget!.description != null)
                  Text(
                    widget.selectedWidget!.description!,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withOpacity(0.7),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategorySection(
    String category,
    List<WidgetDependency> dependencies,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              _getCategoryIcon(category),
              const SizedBox(width: 8),
              Text(
                category,
                style: Theme.of(
                  context,
                ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _getCategoryColor(category).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _getCategoryColor(category).withOpacity(0.3),
                  ),
                ),
                child: Text(
                  '${dependencies.length}',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: _getCategoryColor(category),
                  ),
                ),
              ),
            ],
          ),
        ),
        ...dependencies.map((dep) => _buildDependencyCard(dep)),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildDependencyCard(WidgetDependency dependency) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Add visual indicator for source-based dependencies
              if (dependency.description.contains('Source-based'))
                Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 4,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade100,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: Colors.blue.shade300),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.code, size: 10, color: Colors.blue.shade700),
                      const SizedBox(width: 2),
                      Text(
                        'SRC',
                        style: TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      dependency.type,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      dependency.description,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(
                          context,
                        ).colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${dependency.distanceFromTarget} level${dependency.distanceFromTarget != 1 ? 's' : ''} up',
                  style: TextStyle(fontSize: 10, color: Colors.grey.shade700),
                ),
              ),
            ],
          ),
          if (dependency.setupCode.isNotEmpty) ...[
            const SizedBox(height: 8),
            ExpansionTile(
              title: const Text(
                'Setup Code',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
              ),
              initiallyExpanded: false,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Flutter Test Setup',
                            style: TextStyle(
                              fontSize: 10,
                              color: Colors.grey.shade600,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.copy, size: 14),
                            onPressed: () {
                              Clipboard.setData(
                                ClipboardData(text: dependency.setupCode),
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Setup code copied!'),
                                ),
                              );
                            },
                            tooltip: 'Copy setup code',
                          ),
                        ],
                      ),
                      Text(
                        dependency.setupCode,
                        style: TextStyle(
                          fontSize: 11,
                          fontFamily: 'monospace',
                          color: Colors.grey.shade800,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTestCodeView() {
    return Container(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Generated Test Code',
                style: Theme.of(
                  context,
                ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.copy, size: 18),
                onPressed: _generatedTestCode.isNotEmpty
                    ? () {
                        Clipboard.setData(
                          ClipboardData(text: _generatedTestCode),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Test code copied!')),
                        );
                      }
                    : null,
                tooltip: 'Copy test code',
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
                ),
              ),
              child: SingleChildScrollView(
                child: SelectableText(
                  _generatedTestCode.isNotEmpty
                      ? _generatedTestCode
                      : 'No test code generated yet.',
                  style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Icon _getCategoryIcon(String category) {
    switch (category) {
      case DependencyCategory.provider:
        return const Icon(
          Icons.settings_input_component,
          size: 18,
          color: Colors.blue,
        );
      case DependencyCategory.material:
        return const Icon(Icons.palette, size: 18, color: Colors.purple);
      case DependencyCategory.inherited:
        return const Icon(Icons.account_tree, size: 18, color: Colors.orange);
      case DependencyCategory.navigation:
        return const Icon(Icons.navigation, size: 18, color: Colors.green);
      case DependencyCategory.media:
        return const Icon(Icons.devices, size: 18, color: Colors.teal);
      default:
        return const Icon(Icons.category, size: 18, color: Colors.grey);
    }
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case DependencyCategory.provider:
        return Colors.blue;
      case DependencyCategory.material:
        return Colors.purple;
      case DependencyCategory.inherited:
        return Colors.orange;
      case DependencyCategory.navigation:
        return Colors.green;
      case DependencyCategory.media:
        return Colors.teal;
      default:
        return Colors.grey;
    }
  }
}
