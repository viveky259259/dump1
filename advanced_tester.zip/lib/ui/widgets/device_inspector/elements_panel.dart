import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../domain/entities/ui_element.dart';

/// Panel displaying a searchable list of UI elements.
///
/// Provides search, filter, and keyboard navigation for inspecting
/// device UI elements.
class ElementsPanel extends StatefulWidget {
  /// All UI elements to display
  final List<UIElement> elements;

  /// Currently hovered element
  final UIElement? hoveredElement;

  /// Currently inspected element
  final UIElement? inspectedElement;

  /// Callback when an element is hovered
  final void Function(UIElement?)? onHover;

  /// Callback when an element is selected
  final void Function(UIElement)? onSelect;

  /// Search query
  final String searchQuery;

  /// Callback when search query changes
  final void Function(String)? onSearchChanged;

  const ElementsPanel({
    super.key,
    required this.elements,
    this.hoveredElement,
    this.inspectedElement,
    this.onHover,
    this.onSelect,
    this.searchQuery = '',
    this.onSearchChanged,
  });

  @override
  State<ElementsPanel> createState() => _ElementsPanelState();
}

class _ElementsPanelState extends State<ElementsPanel> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  final ScrollController _scrollController = ScrollController();
  final Map<int, GlobalKey> _itemKeys = {};

  int _currentNavigationIndex = -1;

  @override
  void initState() {
    super.initState();
    _searchController.text = widget.searchQuery;
  }

  @override
  void didUpdateWidget(ElementsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.searchQuery != oldWidget.searchQuery) {
      _searchController.text = widget.searchQuery;
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        border: Border(
          left: BorderSide(color: colorScheme.outlineVariant),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(theme, colorScheme),
          _buildSearchBar(colorScheme),
          Expanded(
            child: _buildElementList(theme, colorScheme),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeData theme, ColorScheme colorScheme) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        border: Border(
          bottom: BorderSide(color: colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.layers,
            size: 16,
            color: colorScheme.onSurfaceVariant,
          ),
          const SizedBox(width: 8),
          Text(
            'Elements',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          Text(
            '${widget.elements.length}',
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(ColorScheme colorScheme) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: TextField(
        controller: _searchController,
        focusNode: _searchFocusNode,
        decoration: InputDecoration(
          hintText: 'Search elements...',
          hintStyle: TextStyle(
            color: colorScheme.onSurfaceVariant.withValues(alpha: 0.6),
          ),
          prefixIcon: Icon(
            Icons.search,
            size: 18,
            color: colorScheme.onSurfaceVariant,
          ),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: Icon(
                    Icons.clear,
                    size: 18,
                    color: colorScheme.onSurfaceVariant,
                  ),
                  onPressed: () {
                    _searchController.clear();
                    widget.onSearchChanged?.call('');
                  },
                )
              : null,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 8,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: colorScheme.outline),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: colorScheme.outlineVariant),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: colorScheme.primary),
          ),
          filled: true,
          fillColor: colorScheme.surfaceContainerLow,
        ),
        style: TextStyle(fontSize: 13),
        onChanged: widget.onSearchChanged,
        onSubmitted: (_) => _selectCurrentElement(),
      ),
    );
  }

  Widget _buildElementList(ThemeData theme, ColorScheme colorScheme) {
    if (widget.elements.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.search_off,
              size: 48,
              color: colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
            ),
            const SizedBox(height: 8),
            Text(
              widget.searchQuery.isNotEmpty
                  ? 'No matching elements'
                  : 'No elements found',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      );
    }

    return KeyboardListener(
      focusNode: FocusNode(),
      onKeyEvent: _handleKeyEvent,
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.symmetric(vertical: 4),
        itemCount: widget.elements.length,
        itemBuilder: (context, index) {
          final element = widget.elements[index];
          _itemKeys[index] ??= GlobalKey();

          return _ElementListItem(
            key: _itemKeys[index],
            element: element,
            isHovered: widget.hoveredElement?.id == element.id,
            isSelected: widget.inspectedElement?.id == element.id,
            searchQuery: widget.searchQuery,
            onHover: widget.onHover,
            onSelect: widget.onSelect,
          );
        },
      ),
    );
  }

  void _handleKeyEvent(KeyEvent event) {
    if (event is! KeyDownEvent) return;

    switch (event.logicalKey) {
      case LogicalKeyboardKey.arrowDown:
        _navigateNext();
        break;
      case LogicalKeyboardKey.arrowUp:
        _navigatePrevious();
        break;
      case LogicalKeyboardKey.enter:
        _selectCurrentElement();
        break;
      case LogicalKeyboardKey.escape:
        widget.onHover?.call(null);
        _currentNavigationIndex = -1;
        break;
    }
  }

  void _navigateNext() {
    if (widget.elements.isEmpty) return;

    _currentNavigationIndex =
        (_currentNavigationIndex + 1) % widget.elements.length;
    _updateHoveredFromNavigation();
  }

  void _navigatePrevious() {
    if (widget.elements.isEmpty) return;

    _currentNavigationIndex = _currentNavigationIndex <= 0
        ? widget.elements.length - 1
        : _currentNavigationIndex - 1;
    _updateHoveredFromNavigation();
  }

  void _updateHoveredFromNavigation() {
    if (_currentNavigationIndex >= 0 &&
        _currentNavigationIndex < widget.elements.length) {
      final element = widget.elements[_currentNavigationIndex];
      widget.onHover?.call(element);
      _scrollToIndex(_currentNavigationIndex);
    }
  }

  void _scrollToIndex(int index) {
    final key = _itemKeys[index];
    if (key?.currentContext != null) {
      Scrollable.ensureVisible(
        key!.currentContext!,
        alignment: 0.5,
        duration: const Duration(milliseconds: 200),
      );
    }
  }

  void _selectCurrentElement() {
    if (_currentNavigationIndex >= 0 &&
        _currentNavigationIndex < widget.elements.length) {
      widget.onSelect?.call(widget.elements[_currentNavigationIndex]);
    } else if (widget.hoveredElement != null) {
      widget.onSelect?.call(widget.hoveredElement!);
    }
  }
}

/// Single element list item with all its selectors
class _ElementListItem extends StatelessWidget {
  final UIElement element;
  final bool isHovered;
  final bool isSelected;
  final String searchQuery;
  final void Function(UIElement?)? onHover;
  final void Function(UIElement)? onSelect;

  const _ElementListItem({
    super.key,
    required this.element,
    required this.isHovered,
    required this.isSelected,
    required this.searchQuery,
    this.onHover,
    this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final selectors = element.availableSelectors;
    if (selectors.isEmpty) return const SizedBox.shrink();

    return MouseRegion(
      onEnter: (_) => onHover?.call(element),
      onExit: (_) => onHover?.call(null),
      child: GestureDetector(
        onTap: () => onSelect?.call(element),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          decoration: BoxDecoration(
            color: isSelected
                ? colorScheme.primaryContainer
                : isHovered
                    ? colorScheme.surfaceContainerHighest
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: isSelected
                  ? colorScheme.primary
                  : isHovered
                      ? colorScheme.outlineVariant
                      : Colors.transparent,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final selector in selectors)
                  _SelectorRow(
                    selector: selector,
                    searchQuery: searchQuery,
                    isSelected: isSelected,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Row displaying a single selector type
class _SelectorRow extends StatelessWidget {
  final SelectorInfo selector;
  final String searchQuery;
  final bool isSelected;

  const _SelectorRow({
    required this.selector,
    required this.searchQuery,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
            decoration: BoxDecoration(
              color: _getSelectorColor(colorScheme).withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(3),
            ),
            child: Text(
              selector.typeLabel,
              style: theme.textTheme.labelSmall?.copyWith(
                color: _getSelectorColor(colorScheme),
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: _HighlightedText(
              text: selector.value,
              query: searchQuery,
              style: theme.textTheme.bodySmall?.copyWith(
                color: isSelected
                    ? colorScheme.onPrimaryContainer
                    : colorScheme.onSurface,
              ),
              highlightStyle: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.w600,
                backgroundColor: colorScheme.primary.withValues(alpha: 0.15),
              ),
            ),
          ),
          if (selector.index != null) ...[
            const SizedBox(width: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
              decoration: BoxDecoration(
                color: colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(3),
              ),
              child: Text(
                '[${selector.index}]',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontSize: 10,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getSelectorColor(ColorScheme colorScheme) {
    switch (selector.type) {
      case SelectorType.id:
        return Colors.blue;
      case SelectorType.text:
        return Colors.green;
      case SelectorType.hintText:
        return Colors.orange;
      case SelectorType.accessibilityText:
        return Colors.purple;
      case SelectorType.point:
        return Colors.grey;
    }
  }
}

/// Text widget that highlights matching portions of the search query
class _HighlightedText extends StatelessWidget {
  final String text;
  final String query;
  final TextStyle? style;
  final TextStyle? highlightStyle;

  const _HighlightedText({
    required this.text,
    required this.query,
    this.style,
    this.highlightStyle,
  });

  @override
  Widget build(BuildContext context) {
    if (query.isEmpty) {
      return Text(
        text,
        style: style,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      );
    }

    final lowerText = text.toLowerCase();
    final lowerQuery = query.toLowerCase();
    final index = lowerText.indexOf(lowerQuery);

    if (index == -1) {
      return Text(
        text,
        style: style,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      );
    }

    return RichText(
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      text: TextSpan(
        children: [
          if (index > 0)
            TextSpan(
              text: text.substring(0, index),
              style: style,
            ),
          TextSpan(
            text: text.substring(index, index + query.length),
            style: highlightStyle ?? style,
          ),
          if (index + query.length < text.length)
            TextSpan(
              text: text.substring(index + query.length),
              style: style,
            ),
        ],
      ),
    );
  }
}

