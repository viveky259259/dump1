import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:multi_split_view/multi_split_view.dart';
import 'package:provider/provider.dart';

import '../../../domain/entities/ui_element.dart';
import '../../../presentation/providers/ui_automation_provider.dart';
import 'annotated_screenshot.dart';
import 'elements_panel.dart';

/// Main panel for device UI inspection.
///
/// Combines the annotated screenshot viewer with the elements panel,
/// providing a complete UI for inspecting device screen elements.
class DeviceInspectorPanel extends StatefulWidget {
  /// Whether to show the elements panel
  final bool showElementsPanel;

  /// Whether to show the element details panel
  final bool showDetailsPanel;

  /// Callback when an element is selected for detailed inspection
  final void Function(UIElement?)? onElementInspected;

  const DeviceInspectorPanel({
    super.key,
    this.showElementsPanel = true,
    this.showDetailsPanel = true,
    this.onElementInspected,
  });

  @override
  State<DeviceInspectorPanel> createState() => _DeviceInspectorPanelState();
}

class _DeviceInspectorPanelState extends State<DeviceInspectorPanel> {
  bool _isMetaKeyDown = false;

  @override
  void initState() {
    super.initState();
    HardwareKeyboard.instance.addHandler(_handleKeyEvent);
  }

  @override
  void dispose() {
    HardwareKeyboard.instance.removeHandler(_handleKeyEvent);
    super.dispose();
  }

  bool _handleKeyEvent(KeyEvent event) {
    final isMetaPressed =
        HardwareKeyboard.instance.isMetaPressed ||
        HardwareKeyboard.instance.isControlPressed;

    if (_isMetaKeyDown != isMetaPressed) {
      setState(() {
        _isMetaKeyDown = isMetaPressed;
      });
    }

    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<UIAutomationProvider>(
      builder: (context, provider, child) {
        if (!provider.isConnected) {
          return _buildDisconnectedView(context, provider);
        }

        // Use a key to force rebuild when panel configuration changes
        final showDetails =
            widget.showDetailsPanel && provider.inspectedElement != null;
        final areaKey = '${widget.showElementsPanel}_$showDetails';

        return MultiSplitView(
          key: ValueKey(areaKey),
          axis: Axis.horizontal,
          initialAreas: [
            Area(
              builder: (context, area) => _buildScreenViewer(provider),
              flex: 2,
            ),
            if (widget.showElementsPanel)
              Area(
                builder: (context, area) => _buildElementsPanel(provider),
                size: 280,
              ),
            if (showDetails)
              Area(
                builder: (context, area) =>
                    _buildDetailsPanel(provider.inspectedElement!),
                size: 300,
              ),
          ],
        );
      },
    );
  }

  Widget _buildDisconnectedView(
    BuildContext context,
    UIAutomationProvider provider,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.phonelink_off,
            size: 64,
            color: colorScheme.onSurfaceVariant.withValues(alpha: 0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'No Device Connected',
            style: theme.textTheme.titleLarge?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Connect to a device to start inspecting UI elements',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 24),
          if (provider.connectionError != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: colorScheme.errorContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 16,
                    color: colorScheme.onErrorContainer,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    provider.connectionError!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onErrorContainer,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
          _DeviceSelector(provider: provider),
        ],
      ),
    );
  }

  Widget _buildScreenViewer(UIAutomationProvider provider) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      color: Colors.black,
      child: Column(
        children: [
          // Toolbar
          _buildToolbar(provider, colorScheme),
          // Screenshot area
          Expanded(
            child: Stack(
              children: [
                AnnotatedScreenshot(
                  screenshotBytes: provider.screenshotBytes,
                  deviceWidth: provider.uiScreen?.width ?? 390,
                  deviceHeight: provider.uiScreen?.height ?? 844,
                  elements: provider.uiScreen?.elements ?? [],
                  hoveredElement: provider.hoveredElement,
                  inspectedElement: provider.inspectedElement,
                  annotationsEnabled:
                      provider.annotationsEnabled && !_isMetaKeyDown,
                  gestureMode: _isMetaKeyDown || provider.isGestureMode,
                  onHover: provider.setHoveredElement,
                  onSelect: (element) {
                    provider.setInspectedElement(element);
                    widget.onElementInspected?.call(element);
                  },
                  onTap: (x, y) => provider.tapAt(x, y),
                  onSwipe: (startX, startY, endX, endY) => provider.swipe(
                    startX: startX,
                    startY: startY,
                    endX: endX,
                    endY: endY,
                  ),
                ),
                // Loading overlay
                if (provider.isCapturing && provider.screenshotBytes == null)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 16),
                          Text(
                            'Capturing screen...',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          // Footer hint
          _buildFooter(provider, colorScheme),
        ],
      ),
    );
  }

  Widget _buildToolbar(UIAutomationProvider provider, ColorScheme colorScheme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        border: Border(bottom: BorderSide(color: colorScheme.outlineVariant)),
      ),
      child: Row(
        children: [
          // Annotations toggle
          IconButton(
            onPressed: provider.toggleAnnotations,
            icon: Icon(
              provider.annotationsEnabled
                  ? Icons.visibility
                  : Icons.visibility_off,
              size: 18,
            ),
            tooltip: provider.annotationsEnabled
                ? 'Hide annotations'
                : 'Show annotations',
            visualDensity: VisualDensity.compact,
          ),
          // Gesture mode toggle
          IconButton(
            onPressed: provider.toggleGestureMode,
            icon: Icon(
              provider.isGestureMode
                  ? Icons.touch_app
                  : Icons.touch_app_outlined,
              size: 18,
            ),
            tooltip: provider.isGestureMode
                ? 'Disable gesture mode'
                : 'Enable gesture mode',
            visualDensity: VisualDensity.compact,
          ),
          // Refresh button
          IconButton(
            onPressed: provider.isCapturing ? null : provider.captureScreen,
            icon: provider.isCapturing
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh, size: 18),
            tooltip: 'Refresh screen',
            visualDensity: VisualDensity.compact,
          ),
          const Spacer(),
          // Device info
          if (provider.uiScreen != null) ...[
            _PlatformBadge(platform: provider.uiScreen!.platform),
            const SizedBox(width: 8),
            Text(
              '${provider.uiScreen!.width}×${provider.uiScreen!.height}',
              style: TextStyle(
                fontSize: 11,
                color: colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(width: 8),
            _ElementCountBadge(
              count: provider.elementCount,
              elements: provider.allElements,
              colorScheme: colorScheme,
              onElementSelected: (element) {
                provider.setInspectedElement(element);
                widget.onElementInspected?.call(element);
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFooter(UIAutomationProvider provider, ColorScheme colorScheme) {
    final hint =
        provider.footerHint ??
        (_isMetaKeyDown
            ? 'Gesture mode: Click to tap, drag to swipe'
            : 'Hover over elements to highlight, click to inspect');

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        border: Border(top: BorderSide(color: colorScheme.outlineVariant)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              hint,
              style: TextStyle(
                fontSize: 11,
                color: colorScheme.onSurfaceVariant,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (provider.lastCaptureTime != null) ...[
            const SizedBox(width: 8),
            Text(
              _formatTime(provider.lastCaptureTime!),
              style: TextStyle(
                fontSize: 11,
                color: colorScheme.onSurfaceVariant.withValues(alpha: 0.7),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildElementsPanel(UIAutomationProvider provider) {
    return ElementsPanel(
      elements: provider.filteredElements,
      hoveredElement: provider.hoveredElement,
      inspectedElement: provider.inspectedElement,
      searchQuery: provider.searchQuery,
      onHover: provider.setHoveredElement,
      onSelect: (element) {
        provider.setInspectedElement(element);
        widget.onElementInspected?.call(element);
      },
      onSearchChanged: provider.setSearchQuery,
    );
  }

  Widget _buildDetailsPanel(UIElement element) {
    return _ElementDetailsPanel(
      element: element,
      onClose: () {
        final provider = context.read<UIAutomationProvider>();
        provider.clearInspectedElement();
        widget.onElementInspected?.call(null);
      },
    );
  }

  String _formatTime(DateTime time) {
    final local = time.toLocal();
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    return '${twoDigits(local.hour)}:${twoDigits(local.minute)}:${twoDigits(local.second)}';
  }
}

/// Device selector widget
class _DeviceSelector extends StatefulWidget {
  final UIAutomationProvider provider;

  const _DeviceSelector({required this.provider});

  @override
  State<_DeviceSelector> createState() => _DeviceSelectorState();
}

class _DeviceSelectorState extends State<_DeviceSelector> {
  List<Map<String, dynamic>>? _devices;
  bool _isLoading = false;
  String? _selectedDeviceId;

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    setState(() => _isLoading = true);

    try {
      final devices = await widget.provider.getAvailableDevices();
      setState(() {
        _devices = devices;
        if (devices.isNotEmpty) {
          _selectedDeviceId = devices.first['id'] as String?;
        }
      });
    } catch (e) {
      // Handle error
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (_isLoading) {
      return const CircularProgressIndicator();
    }

    if (_devices == null || _devices!.isEmpty) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'No devices found',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: _loadDevices,
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh'),
          ),
        ],
      );
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        DropdownButton<String>(
          value: _selectedDeviceId,
          items: _devices!.map((device) {
            return DropdownMenuItem<String>(
              value: device['id'] as String,
              child: Text(device['name'] as String? ?? 'Unknown Device'),
            );
          }).toList(),
          onChanged: (value) {
            setState(() => _selectedDeviceId = value);
          },
        ),
        const SizedBox(width: 8),
        FilledButton(
          onPressed: _selectedDeviceId != null && !widget.provider.isConnecting
              ? () => widget.provider.connectToDevice(_selectedDeviceId!)
              : null,
          child: widget.provider.isConnecting
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Text('Connect'),
        ),
      ],
    );
  }
}

/// Platform badge widget
class _PlatformBadge extends StatelessWidget {
  final UIPlatform platform;

  const _PlatformBadge({required this.platform});

  @override
  Widget build(BuildContext context) {
    final color = _getPlatformColor();
    final icon = _getPlatformIcon();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            platform.name.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Color _getPlatformColor() {
    switch (platform) {
      case UIPlatform.ios:
        return Colors.blue;
      case UIPlatform.android:
        return Colors.green;
      case UIPlatform.web:
        return Colors.orange;
      case UIPlatform.unknown:
        return Colors.grey;
      case UIPlatform.macos:
        return Colors.purple;
      case UIPlatform.linux:
        return Colors.brown;
      case UIPlatform.windows:
        return Colors.blue;
    }
  }

  IconData _getPlatformIcon() {
    switch (platform) {
      case UIPlatform.ios:
        return Icons.phone_iphone;
      case UIPlatform.android:
        return Icons.android;
      case UIPlatform.web:
        return Icons.web;
      case UIPlatform.macos:
        return Icons.desktop_mac;
      case UIPlatform.linux:
        return Icons.computer;
      case UIPlatform.windows:
        return Icons.desktop_windows;
      case UIPlatform.unknown:
        return Icons.device_unknown;
    }
  }
}

/// Clickable element count badge that shows element list on tap
class _ElementCountBadge extends StatelessWidget {
  final int count;
  final List<UIElement> elements;
  final ColorScheme colorScheme;
  final void Function(UIElement) onElementSelected;

  const _ElementCountBadge({
    required this.count,
    required this.elements,
    required this.colorScheme,
    required this.onElementSelected,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => _showElementsPopup(context),
      borderRadius: BorderRadius.circular(4),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: colorScheme.primaryContainer.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.widgets_outlined,
              size: 12,
              color: colorScheme.onPrimaryContainer,
            ),
            const SizedBox(width: 4),
            Text(
              '$count elements',
              style: TextStyle(
                fontSize: 11,
                color: colorScheme.onPrimaryContainer,
              ),
            ),
            const SizedBox(width: 2),
            Icon(
              Icons.arrow_drop_down,
              size: 14,
              color: colorScheme.onPrimaryContainer,
            ),
          ],
        ),
      ),
    );
  }

  void _showElementsPopup(BuildContext context) {
    final RenderBox button = context.findRenderObject() as RenderBox;
    final RenderBox overlay =
        Navigator.of(context).overlay!.context.findRenderObject() as RenderBox;
    final Offset position = button.localToGlobal(
      Offset(0, button.size.height),
      ancestor: overlay,
    );

    showMenu<UIElement>(
      context: context,
      position: RelativeRect.fromLTRB(
        position.dx,
        position.dy,
        overlay.size.width - position.dx - button.size.width,
        0,
      ),
      constraints: const BoxConstraints(
        maxHeight: 400,
        maxWidth: 350,
        minWidth: 280,
      ),
      items: [
        // Header
        PopupMenuItem<UIElement>(
          enabled: false,
          height: 36,
          child: Row(
            children: [
              Icon(Icons.list, size: 16, color: colorScheme.primary),
              const SizedBox(width: 8),
              Text(
                'Identified Elements ($count)',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
        const PopupMenuDivider(),
        // Element list - sorted: known items first, then unknown
        ..._sortedElements(elements)
            .take(50)
            .map(
              (element) => PopupMenuItem<UIElement>(
                value: element,
                height: 48,
                child: _ElementListItem(
                  element: element,
                  colorScheme: colorScheme,
                ),
              ),
            ),
        if (elements.length > 50)
          PopupMenuItem<UIElement>(
            enabled: false,
            height: 32,
            child: Text(
              '... and ${elements.length - 50} more elements',
              style: TextStyle(
                fontSize: 11,
                color: colorScheme.onSurfaceVariant,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
      ],
    ).then((selectedElement) {
      if (selectedElement != null) {
        onElementSelected(selectedElement);
      }
    });
  }

  /// Sort elements: known items (with text/id/accessibility) first, then unknown
  List<UIElement> _sortedElements(List<UIElement> elements) {
    final sorted = List<UIElement>.from(elements);
    sorted.sort((a, b) {
      final aKnown = _isKnownElement(a);
      final bKnown = _isKnownElement(b);

      // Known elements come first
      if (aKnown && !bKnown) return -1;
      if (!aKnown && bKnown) return 1;

      // Within same category, sort by display text
      final aText = a.text ?? a.resourceId ?? a.accessibilityText ?? '';
      final bText = b.text ?? b.resourceId ?? b.accessibilityText ?? '';
      return aText.compareTo(bText);
    });
    return sorted;
  }

  /// Check if element has identifiable attributes
  bool _isKnownElement(UIElement element) {
    return element.text != null ||
        element.resourceId != null ||
        element.accessibilityText != null ||
        element.hintText != null;
  }
}

/// Single element item in the popup list
class _ElementListItem extends StatelessWidget {
  final UIElement element;
  final ColorScheme colorScheme;

  const _ElementListItem({required this.element, required this.colorScheme});

  @override
  Widget build(BuildContext context) {
    final displayInfo = _getDisplayInfo();
    final isKnown = _isKnownElement();

    return Row(
      children: [
        // Type icon
        Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: (isKnown ? _getTypeColor() : Colors.grey).withValues(
              alpha: 0.15,
            ),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Center(
            child: Icon(
              _getTypeIcon(),
              size: 14,
              color: isKnown ? _getTypeColor() : Colors.grey,
            ),
          ),
        ),
        const SizedBox(width: 8),
        // Element info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                displayInfo.primary,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isKnown ? FontWeight.w500 : FontWeight.normal,
                  color: isKnown
                      ? colorScheme.onSurface
                      : colorScheme.onSurfaceVariant,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                displayInfo.secondary,
                style: TextStyle(
                  fontSize: 10,
                  color: colorScheme.onSurfaceVariant.withValues(alpha: 0.8),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        // Indicators
        if (element.clickable == true)
          Padding(
            padding: const EdgeInsets.only(left: 4),
            child: Icon(
              Icons.touch_app,
              size: 12,
              color: colorScheme.primary.withValues(alpha: 0.7),
            ),
          ),
        if (element.resourceId != null)
          Padding(
            padding: const EdgeInsets.only(left: 4),
            child: Icon(
              Icons.tag,
              size: 12,
              color: colorScheme.secondary.withValues(alpha: 0.7),
            ),
          ),
      ],
    );
  }

  bool _isKnownElement() {
    return element.text != null ||
        element.resourceId != null ||
        element.accessibilityText != null ||
        element.hintText != null;
  }

  ({String primary, String secondary}) _getDisplayInfo() {
    // Known element - has identifiable text
    if (element.text != null) {
      return (primary: '"${element.text}"', secondary: _getTypeDescription());
    }
    if (element.resourceId != null) {
      return (primary: element.resourceId!, secondary: _getTypeDescription());
    }
    if (element.accessibilityText != null) {
      return (
        primary: element.accessibilityText!,
        secondary: 'Accessibility • ${_getTypeDescription()}',
      );
    }
    if (element.hintText != null) {
      return (
        primary: element.hintText!,
        secondary: 'Hint • ${_getTypeDescription()}',
      );
    }

    // Unknown element - show bounds or element number
    if (element.bounds != null) {
      final b = element.bounds!;
      return (
        primary: 'Element at (${b.x}, ${b.y})',
        secondary: '${b.width}×${b.height} • ${_getTypeDescription()}',
      );
    }

    // Fallback
    return (
      primary: 'Element #${element.elementNum ?? element.id.hashCode % 1000}',
      secondary: _getTypeDescription(),
    );
  }

  String _getTypeDescription() {
    if (element.elementType != null) {
      // Clean up type name (remove package prefixes)
      final type = element.elementType!;
      final lastDot = type.lastIndexOf('.');
      return lastDot >= 0 ? type.substring(lastDot + 1) : type;
    }
    return element.depth != null ? 'Depth: ${element.depth}' : 'UI Element';
  }

  Color _getTypeColor() {
    final type = element.elementType?.toLowerCase() ?? '';
    if (type.contains('button')) return Colors.blue;
    if (type.contains('text')) return Colors.green;
    if (type.contains('image')) return Colors.purple;
    if (type.contains('input') || type.contains('field')) return Colors.orange;
    if (type.contains('list') || type.contains('scroll')) return Colors.teal;
    return Colors.grey;
  }

  IconData _getTypeIcon() {
    final type = element.elementType?.toLowerCase() ?? '';
    if (type.contains('button')) return Icons.smart_button;
    if (type.contains('text')) return Icons.text_fields;
    if (type.contains('image')) return Icons.image;
    if (type.contains('input') || type.contains('field')) return Icons.edit;
    if (type.contains('list') || type.contains('scroll')) return Icons.list;
    if (type.contains('switch') || type.contains('toggle')) {
      return Icons.toggle_on;
    }
    if (type.contains('checkbox')) return Icons.check_box;
    return Icons.widgets;
  }
}

/// Element details panel
class _ElementDetailsPanel extends StatelessWidget {
  final UIElement element;
  final VoidCallback? onClose;

  const _ElementDetailsPanel({required this.element, this.onClose});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        border: Border(left: BorderSide(color: colorScheme.outlineVariant)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: colorScheme.surfaceContainerHighest,
              border: Border(
                bottom: BorderSide(color: colorScheme.outlineVariant),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  size: 16,
                  color: colorScheme.onSurfaceVariant,
                ),
                const SizedBox(width: 8),
                Text(
                  'Element Details',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: onClose,
                  icon: const Icon(Icons.close, size: 18),
                  visualDensity: VisualDensity.compact,
                  constraints: const BoxConstraints(
                    minWidth: 32,
                    minHeight: 32,
                  ),
                ),
              ],
            ),
          ),
          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Selectors
                  _DetailSection(
                    title: 'Selectors',
                    children: [
                      for (final selector in element.availableSelectors)
                        _DetailRow(
                          label: selector.typeLabel,
                          value: selector.value,
                          index: selector.index,
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Bounds
                  if (element.bounds != null)
                    _DetailSection(
                      title: 'Bounds',
                      children: [
                        _DetailRow(
                          label: 'x',
                          value: element.bounds!.x.toString(),
                        ),
                        _DetailRow(
                          label: 'y',
                          value: element.bounds!.y.toString(),
                        ),
                        _DetailRow(
                          label: 'width',
                          value: element.bounds!.width.toString(),
                        ),
                        _DetailRow(
                          label: 'height',
                          value: element.bounds!.height.toString(),
                        ),
                      ],
                    ),
                  const SizedBox(height: 16),
                  // State
                  _DetailSection(
                    title: 'State',
                    children: [
                      if (element.enabled != null)
                        _DetailRow(
                          label: 'enabled',
                          value: element.enabled.toString(),
                        ),
                      if (element.focused != null)
                        _DetailRow(
                          label: 'focused',
                          value: element.focused.toString(),
                        ),
                      if (element.checked != null)
                        _DetailRow(
                          label: 'checked',
                          value: element.checked.toString(),
                        ),
                      if (element.selected != null)
                        _DetailRow(
                          label: 'selected',
                          value: element.selected.toString(),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Generated commands
                  _DetailSection(
                    title: 'Generated Commands',
                    children: [
                      _CodeBlock(
                        code: element.generateTapCommand(),
                        language: 'yaml',
                      ),
                      const SizedBox(height: 8),
                      _CodeBlock(
                        code: element.generateAssertCommand(),
                        language: 'yaml',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Section with title and children
class _DetailSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _DetailSection({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          title,
          style: theme.textTheme.labelMedium?.copyWith(
            color: colorScheme.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        ...children,
      ],
    );
  }
}

/// Row with label and value
class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final int? index;

  const _DetailRow({required this.label, required this.value, this.index});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Expanded(
            child: Row(
              children: [
                Flexible(
                  child: SelectableText(
                    value,
                    style: theme.textTheme.bodySmall?.copyWith(
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                if (index != null) ...[
                  const SizedBox(width: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 1,
                    ),
                    decoration: BoxDecoration(
                      color: colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: Text(
                      '[$index]',
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: value));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Copied to clipboard'),
                  duration: Duration(seconds: 1),
                ),
              );
            },
            icon: const Icon(Icons.copy, size: 14),
            visualDensity: VisualDensity.compact,
            constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
            tooltip: 'Copy',
          ),
        ],
      ),
    );
  }
}

/// Code block with copy functionality
class _CodeBlock extends StatelessWidget {
  final String code;
  final String language;

  const _CodeBlock({required this.code, required this.language});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Code content
          Padding(
            padding: const EdgeInsets.all(8),
            child: SelectableText(
              code,
              style: TextStyle(
                fontFamily: 'monospace',
                fontSize: 11,
                color: colorScheme.onSurface,
              ),
            ),
          ),
          // Copy button
          Container(
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: colorScheme.outlineVariant),
              ),
            ),
            child: TextButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: code));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Command copied to clipboard'),
                    duration: Duration(seconds: 1),
                  ),
                );
              },
              icon: const Icon(Icons.copy, size: 14),
              label: const Text('Copy'),
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
