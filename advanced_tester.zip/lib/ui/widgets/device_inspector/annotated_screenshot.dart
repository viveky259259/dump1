import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../../domain/entities/ui_element.dart';

/// Visual state for element annotations
enum AnnotationState {
  /// Default state - subtle dashed border
  defaultState,

  /// Hovered state - highlighted with overlay
  hovered,

  /// Selected state - highlighted with different overlay
  selected,

  /// Hidden state - not rendered
  hidden,
}

/// Widget that displays a device screenshot with interactive UI element overlays.
///
/// Provides hover detection, click selection, and visual annotations for
/// inspecting device UI elements.
class AnnotatedScreenshot extends StatefulWidget {
  /// Screenshot bytes to display
  final Uint8List? screenshotBytes;

  /// Device screen dimensions
  final int deviceWidth;
  final int deviceHeight;

  /// All UI elements to annotate
  final List<UIElement> elements;

  /// Currently hovered element
  final UIElement? hoveredElement;

  /// Currently inspected (selected) element
  final UIElement? inspectedElement;

  /// Whether annotations are enabled
  final bool annotationsEnabled;

  /// Callback when mouse hovers over an element
  final void Function(UIElement?)? onHover;

  /// Callback when an element is clicked
  final void Function(UIElement)? onSelect;

  /// Callback for tap gesture (in gesture mode)
  final void Function(double x, double y)? onTap;

  /// Callback for swipe gesture (in gesture mode)
  final void Function(double startX, double startY, double endX, double endY)?
      onSwipe;

  /// Whether gesture mode is enabled
  final bool gestureMode;

  const AnnotatedScreenshot({
    super.key,
    this.screenshotBytes,
    required this.deviceWidth,
    required this.deviceHeight,
    required this.elements,
    this.hoveredElement,
    this.inspectedElement,
    this.annotationsEnabled = true,
    this.onHover,
    this.onSelect,
    this.onTap,
    this.onSwipe,
    this.gestureMode = false,
  });

  @override
  State<AnnotatedScreenshot> createState() => _AnnotatedScreenshotState();
}

class _AnnotatedScreenshotState extends State<AnnotatedScreenshot> {
  Offset? _mousePosition;
  Offset? _dragStart;
  bool _isDragging = false;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return MouseRegion(
          onEnter: _handleMouseEnter,
          onHover: _handleMouseHover,
          onExit: _handleMouseExit,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: _handleTap,
            onPanStart: _handlePanStart,
            onPanUpdate: _handlePanUpdate,
            onPanEnd: _handlePanEnd,
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Screenshot background
                _buildScreenshot(),

                // Element annotations (bounding boxes)
                if (widget.annotationsEnabled && !widget.gestureMode)
                  ..._buildAnnotations(),

                // Crosshairs for focused element
                if (widget.annotationsEnabled) _buildCrosshairs(),

                // Drag visualization
                if (_isDragging && _dragStart != null && _mousePosition != null)
                  _buildDragLine(constraints),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildScreenshot() {
    if (widget.screenshotBytes == null) {
      return Container(
        color: Colors.black,
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.phone_android,
                size: 48,
                color: Colors.white38,
              ),
              SizedBox(height: 16),
              Text(
                'No screenshot available',
                style: TextStyle(color: Colors.white54),
              ),
            ],
          ),
        ),
      );
    }

    return Image.memory(
      widget.screenshotBytes!,
      fit: BoxFit.contain,
      gaplessPlayback: true,
      filterQuality: FilterQuality.medium,
    );
  }

  List<Widget> _buildAnnotations() {
    final annotations = <Widget>[];

    for (final element in widget.elements) {
      if (element.bounds == null) continue;

      final state = _getAnnotationState(element);
      if (state == AnnotationState.hidden) continue;

      annotations.add(
        _ElementAnnotation(
          element: element,
          deviceWidth: widget.deviceWidth,
          deviceHeight: widget.deviceHeight,
          state: state,
          onTap: () => widget.onSelect?.call(element),
        ),
      );
    }

    return annotations;
  }

  AnnotationState _getAnnotationState(UIElement element) {
    // If an element is inspected, hide all others
    if (widget.inspectedElement != null) {
      if (element.id == widget.inspectedElement!.id) {
        return AnnotationState.selected;
      }
      return AnnotationState.hidden;
    }

    // If hovered, show highlighted
    if (widget.hoveredElement != null &&
        element.id == widget.hoveredElement!.id) {
      return AnnotationState.hovered;
    }

    return AnnotationState.defaultState;
  }

  Widget _buildCrosshairs() {
    final focusedElement = widget.inspectedElement ?? widget.hoveredElement;
    if (focusedElement?.bounds == null) return const SizedBox.shrink();

    final bounds = focusedElement!.bounds!;
    final cx = (bounds.x + bounds.width / 2) / widget.deviceWidth;
    final cy = (bounds.y + bounds.height / 2) / widget.deviceHeight;

    final color = widget.inspectedElement != null
        ? Colors.blue.shade400
        : Colors.pink.shade400;

    return _Crosshairs(cx: cx, cy: cy, color: color);
  }

  Widget _buildDragLine(BoxConstraints constraints) {
    return CustomPaint(
      painter: _DragLinePainter(
        start: _dragStart!,
        end: _mousePosition!,
        containerSize: Size(constraints.maxWidth, constraints.maxHeight),
      ),
    );
  }

  void _handleMouseEnter(PointerEnterEvent event) {
    // Nothing special needed
  }

  void _handleMouseHover(PointerHoverEvent event) {
    _mousePosition = event.localPosition;

    if (!widget.annotationsEnabled || widget.gestureMode) {
      widget.onHover?.call(null);
      return;
    }

    // Find element under cursor
    final element = _findElementAtPosition(event.localPosition);
    widget.onHover?.call(element);
  }

  void _handleMouseExit(PointerExitEvent event) {
    _mousePosition = null;
    widget.onHover?.call(null);
  }

  void _handleTap(TapUpDetails details) {
    if (widget.gestureMode) {
      final normalized = _normalizePosition(details.localPosition);
      if (normalized != null) {
        widget.onTap?.call(normalized.dx, normalized.dy);
      }
    } else if (widget.annotationsEnabled) {
      final element = _findElementAtPosition(details.localPosition);
      if (element != null) {
        widget.onSelect?.call(element);
      }
    }
  }

  void _handlePanStart(DragStartDetails details) {
    _dragStart = details.localPosition;
    _isDragging = true;
    setState(() {});
  }

  void _handlePanUpdate(DragUpdateDetails details) {
    _mousePosition = details.localPosition;
    setState(() {});
  }

  void _handlePanEnd(DragEndDetails details) {
    if (_dragStart != null && _mousePosition != null && widget.gestureMode) {
      final startNorm = _normalizePosition(_dragStart!);
      final endNorm = _normalizePosition(_mousePosition!);

      if (startNorm != null && endNorm != null) {
        final distance = (endNorm - startNorm).distance;
        // Only trigger swipe if distance is significant
        if (distance > 0.05) {
          widget.onSwipe?.call(
            startNorm.dx,
            startNorm.dy,
            endNorm.dx,
            endNorm.dy,
          );
        }
      }
    }

    _dragStart = null;
    _isDragging = false;
    setState(() {});
  }

  UIElement? _findElementAtPosition(Offset position) {
    final normalized = _normalizePosition(position);
    if (normalized == null) return null;

    // Find all elements containing this point
    final matching = widget.elements.where((element) {
      if (element.bounds == null) return false;
      return element.bounds!.containsNormalized(
        normalized.dx,
        normalized.dy,
        widget.deviceWidth,
        widget.deviceHeight,
      );
    }).toList();

    if (matching.isEmpty) return null;

    // Return smallest element (most specific)
    matching.sort((a, b) {
      final aArea = a.bounds?.area ?? 9999999999;
      final bArea = b.bounds?.area ?? 9999999999;
      return aArea.compareTo(bArea);
    });

    return matching.first;
  }

  Offset? _normalizePosition(Offset position) {
    // Get the render box to calculate actual image dimensions
    final renderBox = context.findRenderObject() as RenderBox?;
    if (renderBox == null) return null;

    final containerSize = renderBox.size;
    final aspectRatio = widget.deviceWidth / widget.deviceHeight;
    final containerAspectRatio = containerSize.width / containerSize.height;

    double imageWidth, imageHeight, offsetX, offsetY;

    if (containerAspectRatio > aspectRatio) {
      // Container is wider, image is height-constrained
      imageHeight = containerSize.height;
      imageWidth = imageHeight * aspectRatio;
      offsetX = (containerSize.width - imageWidth) / 2;
      offsetY = 0;
    } else {
      // Container is taller, image is width-constrained
      imageWidth = containerSize.width;
      imageHeight = imageWidth / aspectRatio;
      offsetX = 0;
      offsetY = (containerSize.height - imageHeight) / 2;
    }

    final relativeX = (position.dx - offsetX) / imageWidth;
    final relativeY = (position.dy - offsetY) / imageHeight;

    // Check bounds
    if (relativeX < 0 || relativeX > 1 || relativeY < 0 || relativeY > 1) {
      return null;
    }

    return Offset(relativeX, relativeY);
  }
}

/// Widget for a single element annotation (bounding box)
class _ElementAnnotation extends StatelessWidget {
  final UIElement element;
  final int deviceWidth;
  final int deviceHeight;
  final AnnotationState state;
  final VoidCallback? onTap;

  const _ElementAnnotation({
    required this.element,
    required this.deviceWidth,
    required this.deviceHeight,
    required this.state,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    if (element.bounds == null || state == AnnotationState.hidden) {
      return const SizedBox.shrink();
    }

    final bounds = element.bounds!;

    // Convert pixel coordinates to percentages
    final left = (bounds.x / deviceWidth) * 100;
    final top = (bounds.y / deviceHeight) * 100;
    final width = (bounds.width / deviceWidth) * 100;
    final height = (bounds.height / deviceHeight) * 100;

    return Positioned(
      left: 0,
      top: 0,
      right: 0,
      bottom: 0,
      child: FractionallySizedBox(
        alignment: Alignment.topLeft,
        widthFactor: 1,
        heightFactor: 1,
        child: Stack(
          children: [
            Positioned(
              left: left.percent,
              top: top.percent,
              width: width.percent,
              height: height.percent,
              child: GestureDetector(
                onTap: onTap,
                child: _buildBox(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBox() {
    BoxDecoration decoration;
    List<BoxShadow>? shadows;

    switch (state) {
      case AnnotationState.hovered:
        decoration = BoxDecoration(
          border: Border.all(
            color: Colors.blue.shade500,
            width: 3,
          ),
          borderRadius: BorderRadius.circular(2),
        );
        shadows = [
          BoxShadow(
            color: Colors.pink.shade400.withValues(alpha: 0.4),
            blurRadius: 0,
            spreadRadius: 9999,
          ),
        ];
        break;

      case AnnotationState.selected:
        decoration = BoxDecoration(
          border: Border.all(
            color: Colors.blue.shade500,
            width: 3,
          ),
          borderRadius: BorderRadius.circular(2),
        );
        shadows = [
          BoxShadow(
            color: Colors.blue.shade400.withValues(alpha: 0.4),
            blurRadius: 0,
            spreadRadius: 9999,
          ),
        ];
        break;

      default:
        decoration = BoxDecoration(
          border: Border.all(
            color: Colors.pink.shade400.withValues(alpha: 0.6),
            width: 1,
            strokeAlign: BorderSide.strokeAlignInside,
          ),
          borderRadius: BorderRadius.circular(2),
        );
    }

    return Container(
      decoration: decoration,
      child: shadows != null
          ? Container(
              decoration: BoxDecoration(
                boxShadow: shadows,
              ),
            )
          : null,
    );
  }
}

/// Widget for crosshairs showing the center of focused element
class _Crosshairs extends StatelessWidget {
  final double cx;
  final double cy;
  final Color color;

  const _Crosshairs({
    required this.cx,
    required this.cy,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Stack(
        children: [
          // Vertical line
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: FractionallySizedBox(
              alignment: Alignment(cx * 2 - 1, 0),
              widthFactor: 0,
              heightFactor: 1,
              child: Container(
                width: 1,
                color: color.withValues(alpha: 0.6),
              ),
            ),
          ),
          // Horizontal line
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: FractionallySizedBox(
              alignment: Alignment(0, cy * 2 - 1),
              widthFactor: 1,
              heightFactor: 0,
              child: Container(
                height: 1,
                color: color.withValues(alpha: 0.6),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Painter for drag line visualization
class _DragLinePainter extends CustomPainter {
  final Offset start;
  final Offset end;
  final Size containerSize;

  _DragLinePainter({
    required this.start,
    required this.end,
    required this.containerSize,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue.shade400
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    canvas.drawLine(start, end, paint);

    // Draw arrow at end
    final direction = (end - start).direction;
    const arrowSize = 10.0;
    final arrowPath = Path()
      ..moveTo(end.dx, end.dy)
      ..lineTo(
        end.dx - arrowSize * math.cos(direction - 0.5),
        end.dy - arrowSize * math.sin(direction - 0.5),
      )
      ..moveTo(end.dx, end.dy)
      ..lineTo(
        end.dx - arrowSize * math.cos(direction + 0.5),
        end.dy - arrowSize * math.sin(direction + 0.5),
      );

    canvas.drawPath(arrowPath, paint);
  }

  @override
  bool shouldRepaint(covariant _DragLinePainter oldDelegate) {
    return start != oldDelegate.start || end != oldDelegate.end;
  }
}

extension _PercentExtension on double {
  double get percent => this / 100;
}

