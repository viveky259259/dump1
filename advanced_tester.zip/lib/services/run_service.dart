import 'dart:async';
import 'dart:convert';
import 'dart:io';
import '../core/logging/logging.dart';

class RunService with LoggerMixin {
  Future<
    ({Process process, StreamController<String> logStream, Uri? vmServiceUri})
  >
  startFlutterApp({
    required String projectPath,
    required String flutterSdkDir,
    required String deviceId,
    List<String> additionalArgs = const [],
  }) async {
    logger.info('Starting Flutter run process', {
      'projectPath': projectPath,
      'deviceId': deviceId,
      'extraArgs': additionalArgs,
    });

    final flutterBin = Uri.file('$flutterSdkDir/bin/flutter').toFilePath();
    final process = await Process.start(
      flutterBin,
      [
        'run',
        '-d',
        deviceId,
        '--debug', // Explicitly enable debug mode
        '--track-widget-creation', // Essential for widget inspector
        '--verbose', // More detailed logging
        ...additionalArgs,
      ],
      workingDirectory: projectPath,
      runInShell: false,
      mode: ProcessStartMode.detachedWithStdio,
    );
    final controller = StreamController<String>.broadcast();
    Uri? vmUri;
    void listenStream(Stream<List<int>> s) {
      s.transform(utf8.decoder).listen((chunk) {
        controller.add(chunk);
        // Handle multiple VM service URI patterns

        // Pattern 1: Direct WebSocket URL (ws://...)
        final wsMatch = RegExp(
          r'(ws://[^\s]+)',
          caseSensitive: false,
        ).firstMatch(chunk);
        if (wsMatch != null) {
          final uriStr = wsMatch.group(1)!;
          try {
            vmUri = Uri.parse(uriStr);
            print('VM Service WebSocket URI detected: $vmUri');
          } catch (e) {
            print('Failed to parse WebSocket URI: $e');
          }
        }

        // Pattern 2: "The Dart VM service is listening on..."
        final vmServiceMatch = RegExp(
          r'The Dart VM service is listening on (http://[^\s]+)',
          caseSensitive: false,
        ).firstMatch(chunk);
        if (vmServiceMatch != null) {
          final uriStr = vmServiceMatch.group(1)!;
          try {
            // Convert http to ws for VM service
            final uri = Uri.parse(uriStr);
            vmUri = uri.replace(scheme: 'ws', path: '/ws');
            print('VM Service URI from "listening on": $vmUri');
          } catch (e) {
            print('Failed to parse VM service URI from listening: $e');
          }
        }

        // Pattern 3: Flutter web server URL (for app preview)
        final webServerMatch = RegExp(
          r'Flutter web app is served at (http://[^\s]+)',
          caseSensitive: false,
        ).firstMatch(chunk);
        if (webServerMatch != null) {
          final webUrl = webServerMatch.group(1)!;
          print('Flutter web app URL detected: $webUrl');
          // This will be used by the UI to set the running URL
        }
      });
    }

    listenStream(process.stdout);
    listenStream(process.stderr);

    return (process: process, logStream: controller, vmServiceUri: vmUri);
  }

  Future<void> stop(Process process) async {
    logger.info('Stopping Flutter process', {'pid': process.pid});
    try {
      process.kill(ProcessSignal.sigint);
    } catch (e) {
      logger.warn('SIGINT failed, forcing kill', {'error': e.toString()});
      process.kill();
    }
  }
}
