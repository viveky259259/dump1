import 'dart:io';

import 'package:path/path.dart' as p;
import '../core/logging/logging.dart';

class SyncService with LoggerMixin {
  final Directory draftsDir;

  SyncService({Directory? draftsDirectory})
    : draftsDir =
          draftsDirectory ??
          Directory(p.join(Directory.current.path, '.draft_tests')) {
    if (!draftsDir.existsSync()) {
      draftsDir.createSync(recursive: true);
      logger.info('Created drafts directory', {'path': draftsDir.path});
    }
    logger.info('SyncService initialized', {'draftsDir': draftsDir.path});
  }

  Future<File> saveDraft({
    required String fileName,
    required String content,
  }) async {
    return await logAsyncOperation('saveDraft', () async {
      final file = File(p.join(draftsDir.path, fileName));
      await file.writeAsString(content);
      logger.info('Draft saved', {
        'fileName': fileName,
        'size': content.length,
      });
      return file;
    }, context: {'fileName': fileName});
  }

  Future<File?> syncToProject({
    required String projectRoot,
    required String fileName,
  }) async {
    final src = File(p.join(draftsDir.path, fileName));
    if (!await src.exists()) return null;
    final testDir = Directory(p.join(projectRoot, 'test'));
    if (!await testDir.exists()) {
      await testDir.create(recursive: true);
    }
    final dest = File(p.join(testDir.path, fileName));
    await dest.writeAsBytes(await src.readAsBytes());
    return dest;
  }
}
