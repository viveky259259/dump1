import 'dart:io';
import 'inspector_service.dart';
import '../core/logging/logging.dart';

/// Service for analyzing widget source code to detect dependencies
class SourceCodeAnalyzer with LoggerMixin {
  /// Map of regex patterns to dependency types for detecting actual usage
  static final Map<RegExp, ContextDependencyType> _dependencyPatterns = {
    // Provider patterns - detects actual usage, not just provider presence
    RegExp(r'Provider\.of<(\w+)>\s*\(\s*context\s*\)'):
        ContextDependencyType.provider,
    RegExp(r'context\.read<(\w+)>\s*\(\s*\)'): ContextDependencyType.provider,
    RegExp(r'context\.watch<(\w+)>\s*\(\s*\)'): ContextDependencyType.provider,
    RegExp(r'Consumer<(\w+)>'): ContextDependencyType.provider,
    RegExp(r'Selector<\w*,\s*(\w+)>'): ContextDependencyType.provider,

    // BLoC patterns
    RegExp(r'BlocProvider\.of<(\w+)>\s*\(\s*context\s*\)'):
        ContextDependencyType.bloc,
    RegExp(r'context\.read<(\w+)Bloc>\s*\(\s*\)'): ContextDependencyType.bloc,
    RegExp(r'context\.read<(\w+)Cubit>\s*\(\s*\)'): ContextDependencyType.bloc,
    RegExp(r'BlocBuilder<(\w+),'): ContextDependencyType.bloc,
    RegExp(r'BlocConsumer<(\w+),'): ContextDependencyType.bloc,
    RegExp(r'BlocListener<(\w+),'): ContextDependencyType.bloc,

    // Flutter built-in dependencies - actual usage detection
    RegExp(r'Theme\.of\s*\(\s*context\s*\)'): ContextDependencyType.theme,
    RegExp(r'MediaQuery\.of\s*\(\s*context\s*\)'):
        ContextDependencyType.mediaQuery,
    RegExp(r'Navigator\.of\s*\(\s*context\s*\)'):
        ContextDependencyType.navigator,
    RegExp(r'Scaffold\.of\s*\(\s*context\s*\)'): ContextDependencyType.scaffold,
    RegExp(r'DefaultTabController\.of\s*\(\s*context\s*\)'):
        ContextDependencyType.tabController,

    // Localization
    RegExp(r'Localizations\.of\s*\(\s*context\s*\)'):
        ContextDependencyType.localization,
    RegExp(r'AppLocalizations\.of\s*\(\s*context\s*\)'):
        ContextDependencyType.localization,

    // Form dependencies
    RegExp(r'Form\.of\s*\(\s*context\s*\)'): ContextDependencyType.form,

    // FocusScope
    RegExp(r'FocusScope\.of\s*\(\s*context\s*\)'):
        ContextDependencyType.focusScope,

    // Overlay
    RegExp(r'Overlay\.of\s*\(\s*context\s*\)'): ContextDependencyType.overlay,

    // Router (Go Router, Auto Route, etc.)
    RegExp(r'GoRouter\.of\s*\(\s*context\s*\)'): ContextDependencyType.router,
    RegExp(r'AutoRouter\.of\s*\(\s*context\s*\)'): ContextDependencyType.router,

    // Custom InheritedWidget pattern (generic catch-all)
    RegExp(r'(\w+)\.of\s*\(\s*context\s*\)'): ContextDependencyType.inherited,
  };

  /// Secondary patterns for additional context clues
  static final Map<RegExp, ContextDependencyType> _contextualPatterns = {
    // Material Design widgets that implicitly need Theme
    RegExp(
      r'\b(?:ElevatedButton|OutlinedButton|TextButton|FloatingActionButton|AppBar|Card|Chip|Dialog|Drawer|BottomSheet)\b',
    ): ContextDependencyType.theme,

    // Widgets that need MediaQuery
    RegExp(
      r'\bMediaQuery\.(?:sizeOf|orientationOf|platformBrightnessOf)\s*\(\s*context\s*\)',
    ): ContextDependencyType.mediaQuery,

    // Navigation patterns
    RegExp(r'\bNavigator\.(?:push|pop|replace|pushNamed)\s*\(\s*context\s*'):
        ContextDependencyType.navigator,
  };

  /// Analyze source code for dependency patterns
  Future<List<SourceCodeDependency>> analyzeDependencies(
    String sourceCode,
    SourceLocation location,
  ) async {
    return await logAsyncOperation(
      'analyzeDependencies',
      () async => _analyzeDependenciesImpl(sourceCode, location),
      context: {
        'sourceFile': location.file,
        'sourceLine': location.line,
        'codeLength': sourceCode.length,
      },
    );
  }

  Future<List<SourceCodeDependency>> _analyzeDependenciesImpl(
    String sourceCode,
    SourceLocation location,
  ) async {
    final dependencies = <SourceCodeDependency>[];
    final foundTypes = <String>{};

    // Analyze explicit dependency patterns
    print(
      '🔍 Scanning source code with ${_dependencyPatterns.length} patterns...',
    );
    for (final entry in _dependencyPatterns.entries) {
      final matches = entry.key.allMatches(sourceCode);

      for (final match in matches) {
        final dependencyType = entry.value;
        final typeParam = match.groupCount > 0 ? match.group(1) : null;
        final matchedText = match.group(0)!;

        // Avoid duplicates
        final key = '${dependencyType}_${typeParam ?? 'default'}';
        if (foundTypes.contains(key)) continue;
        foundTypes.add(key);

        print(
          '🔍 ✅ MATCHED: "$matchedText" → ${dependencyType} ${typeParam ?? ''}',
        );

        final dependency = _createSourceCodeDependency(
          dependencyType,
          typeParam,
          matchedText,
          location,
        );
        if (dependency != null) {
          dependencies.add(dependency);
        }
      }
    }

    // Analyze contextual patterns for implicit dependencies
    for (final entry in _contextualPatterns.entries) {
      final matches = entry.key.allMatches(sourceCode);

      if (matches.isNotEmpty) {
        final dependencyType = entry.value;
        final key = '${dependencyType}_contextual';

        if (!foundTypes.contains(key)) {
          foundTypes.add(key);
          final dependency = _createSourceCodeDependency(
            dependencyType,
            null,
            matches.first.group(0)!,
            location,
          );
          if (dependency != null) {
            dependencies.add(dependency);
          }
        }
      }
    }

    // Special analysis for constructor parameters and callbacks
    final constructorDeps = await _analyzeConstructorDependencies(
      sourceCode,
      location,
    );
    dependencies.addAll(constructorDeps);

    return dependencies;
  }

  /// Create a specific dependency from detected patterns
  SourceCodeDependency? _createSourceCodeDependency(
    ContextDependencyType type,
    String? typeParam,
    String matchedText,
    SourceLocation location,
  ) {
    switch (type) {
      case ContextDependencyType.provider:
        return ProviderSourceDependency(
          providerType: typeParam ?? 'dynamic',
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.bloc:
        return BlocSourceDependency(
          blocType: typeParam ?? 'dynamic',
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.theme:
        return ThemeSourceDependency(usage: matchedText, location: location);
      case ContextDependencyType.mediaQuery:
        return MediaQuerySourceDependency(
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.navigator:
        return NavigatorSourceDependency(
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.scaffold:
        return ScaffoldSourceDependency(usage: matchedText, location: location);
      case ContextDependencyType.localization:
        return LocalizationSourceDependency(
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.form:
        return FormSourceDependency(usage: matchedText, location: location);
      case ContextDependencyType.tabController:
        return TabControllerSourceDependency(
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.focusScope:
        return FocusScopeSourceDependency(
          usage: matchedText,
          location: location,
        );
      case ContextDependencyType.overlay:
        return OverlaySourceDependency(usage: matchedText, location: location);
      case ContextDependencyType.router:
        return RouterSourceDependency(usage: matchedText, location: location);
      case ContextDependencyType.inherited:
        return InheritedWidgetSourceDependency(
          widgetType: typeParam ?? 'Unknown',
          usage: matchedText,
          location: location,
        );
    }
  }

  /// Analyze constructor parameters for potential dependencies
  Future<List<SourceCodeDependency>> _analyzeConstructorDependencies(
    String sourceCode,
    SourceLocation location,
  ) async {
    final dependencies = <SourceCodeDependency>[];

    // Look for callback parameters that might need mocking
    final callbackPattern = RegExp(
      r'(?:VoidCallback|Function(?:\([^)]*\))?|ValueChanged<\w+>)\s+(\w+)',
    );
    final matches = callbackPattern.allMatches(sourceCode);

    if (matches.isNotEmpty) {
      dependencies.add(
        CallbackSourceDependency(
          callbackTypes: matches.map((m) => m.group(0)!).toList(),
          usage: 'Constructor parameters',
          location: location,
        ),
      );
    }

    return dependencies;
  }

  /// Extract all imports from a Dart file
  Future<List<String>> findRequiredImports(String filePath) async {
    final imports = <String>[];

    try {
      final file = File(filePath);
      if (await file.exists()) {
        final content = await file.readAsString();
        final importPattern = RegExp(r'import\s+.([^.]+).');
        final matches = importPattern.allMatches(content);

        for (final match in matches) {
          final importPath = match.group(1);
          if (importPath != null) {
            imports.add(importPath);
          }
        }
      }
    } catch (e) {
      print('Error reading imports: $e');
    }

    return imports;
  }
}

/// Enum for different types of context dependencies
enum ContextDependencyType {
  provider,
  bloc,
  theme,
  mediaQuery,
  navigator,
  scaffold,
  localization,
  form,
  tabController,
  focusScope,
  overlay,
  router,
  inherited,
}

/// Base class for source code dependencies with location information
abstract class SourceCodeDependency {
  final String usage;
  final SourceLocation location;

  SourceCodeDependency({required this.usage, required this.location});

  String get name;
  String get description;
  List<String> get requiredImports;
  String generateTestWrapper(String widgetCode);
  String generateMockSetup();
}

/// Provider dependency detected from source code
class ProviderSourceDependency extends SourceCodeDependency {
  final String providerType;

  ProviderSourceDependency({
    required this.providerType,
    required super.usage,
    required super.location,
  });

  @override
  String get name => 'Provider<$providerType>';

  @override
  String get description => 'Uses $providerType via Provider pattern: $usage';

  @override
  List<String> get requiredImports => [
    'package:provider/provider.dart',
    'package:mockito/mockito.dart',
  ];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
ChangeNotifierProvider<$providerType>(
  create: (_) => Mock$providerType(),
  child: $widgetCode,
)''';
  }

  @override
  String generateMockSetup() {
    return '''
class Mock$providerType extends Mock implements $providerType {}
final mock$providerType = Mock$providerType();''';
  }
}

/// BLoC dependency detected from source code
class BlocSourceDependency extends SourceCodeDependency {
  final String blocType;

  BlocSourceDependency({
    required this.blocType,
    required super.usage,
    required super.location,
  });

  @override
  String get name => 'BloC<$blocType>';

  @override
  String get description => 'Uses $blocType via BLoC pattern: $usage';

  @override
  List<String> get requiredImports => [
    'package:flutter_bloc/flutter_bloc.dart',
    'package:mockito/mockito.dart',
  ];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
BlocProvider<$blocType>(
  create: (_) => Mock$blocType(),
  child: $widgetCode,
)''';
  }

  @override
  String generateMockSetup() {
    return '''
class Mock$blocType extends MockBloc<dynamic, dynamic> implements $blocType {}
final mock$blocType = Mock$blocType();''';
  }
}

/// Theme dependency detected from source code
class ThemeSourceDependency extends SourceCodeDependency {
  ThemeSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Theme';

  @override
  String get description => 'Accesses theme data: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
MaterialApp(
  theme: ThemeData(),
  home: Scaffold(body: $widgetCode),
)''';
  }

  @override
  String generateMockSetup() => '';
}

/// MediaQuery dependency detected from source code
class MediaQuerySourceDependency extends SourceCodeDependency {
  MediaQuerySourceDependency({required super.usage, required super.location});

  @override
  String get name => 'MediaQuery';

  @override
  String get description => 'Accesses media query data: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
MediaQuery(
  data: const MediaQueryData(
    size: Size(400, 800),
    devicePixelRatio: 1.0,
  ),
  child: $widgetCode,
)''';
  }

  @override
  String generateMockSetup() => '';
}

/// Navigator dependency detected from source code
class NavigatorSourceDependency extends SourceCodeDependency {
  NavigatorSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Navigator';

  @override
  String get description => 'Uses navigation: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
MaterialApp(
  home: $widgetCode,
)''';
  }

  @override
  String generateMockSetup() => '';
}

/// Scaffold dependency detected from source code
class ScaffoldSourceDependency extends SourceCodeDependency {
  ScaffoldSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Scaffold';

  @override
  String get description => 'Requires Scaffold context: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
MaterialApp(
  home: Scaffold(
    body: $widgetCode,
  ),
)''';
  }

  @override
  String generateMockSetup() => '';
}

/// Additional dependency classes following the same pattern...
class LocalizationSourceDependency extends SourceCodeDependency {
  LocalizationSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Localizations';

  @override
  String get description => 'Uses localization: $usage';

  @override
  List<String> get requiredImports => [
    'package:flutter/material.dart',
    'package:flutter_localizations/flutter_localizations.dart',
  ];

  @override
  String generateTestWrapper(String widgetCode) {
    return '''
MaterialApp(
  localizationsDelegates: const [
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ],
  supportedLocales: const [Locale('en', 'US')],
  home: $widgetCode,
)''';
  }

  @override
  String generateMockSetup() => '';
}

class FormSourceDependency extends SourceCodeDependency {
  FormSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Form';

  @override
  String get description => 'Uses form context: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return 'Form(key: GlobalKey<FormState>(), child: $widgetCode)';
  }

  @override
  String generateMockSetup() => '';
}

class TabControllerSourceDependency extends SourceCodeDependency {
  TabControllerSourceDependency({
    required super.usage,
    required super.location,
  });

  @override
  String get name => 'TabController';

  @override
  String get description => 'Uses tab controller: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return 'DefaultTabController(length: 3, child: $widgetCode)';
  }

  @override
  String generateMockSetup() => '';
}

class FocusScopeSourceDependency extends SourceCodeDependency {
  FocusScopeSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'FocusScope';

  @override
  String get description => 'Uses focus scope: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) => widgetCode;

  @override
  String generateMockSetup() => '';
}

class OverlaySourceDependency extends SourceCodeDependency {
  OverlaySourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Overlay';

  @override
  String get description => 'Uses overlay: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return 'MaterialApp(home: $widgetCode)';
  }

  @override
  String generateMockSetup() => '';
}

class RouterSourceDependency extends SourceCodeDependency {
  RouterSourceDependency({required super.usage, required super.location});

  @override
  String get name => 'Router';

  @override
  String get description => 'Uses routing: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return 'MaterialApp(home: $widgetCode)';
  }

  @override
  String generateMockSetup() => '';
}

class InheritedWidgetSourceDependency extends SourceCodeDependency {
  final String widgetType;

  InheritedWidgetSourceDependency({
    required this.widgetType,
    required super.usage,
    required super.location,
  });

  @override
  String get name => 'InheritedWidget<$widgetType>';

  @override
  String get description => 'Uses inherited widget $widgetType: $usage';

  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];

  @override
  String generateTestWrapper(String widgetCode) {
    return 'Mock$widgetType(child: $widgetCode)';
  }

  @override
  String generateMockSetup() {
    return '''
class Mock$widgetType extends InheritedWidget {
  const Mock$widgetType({super.key, required super.child});
  
  @override
  bool updateShouldNotify(Mock$widgetType oldWidget) => false;
  
  static Mock$widgetType? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<Mock$widgetType>();
  }
}''';
  }
}

class CallbackSourceDependency extends SourceCodeDependency {
  final List<String> callbackTypes;

  CallbackSourceDependency({
    required this.callbackTypes,
    required super.usage,
    required super.location,
  });

  @override
  String get name => 'Callbacks';

  @override
  String get description =>
      'Requires callback mocking: ${callbackTypes.join(', ')}';

  @override
  List<String> get requiredImports => ['package:mockito/mockito.dart'];

  @override
  String generateTestWrapper(String widgetCode) => widgetCode;

  @override
  String generateMockSetup() {
    return '''
// Mock callbacks for ${callbackTypes.join(', ')}
${callbackTypes.map((type) => 'final mock${type.replaceAll(RegExp(r'[<>(),\s]'), '')} = MockFunction();').join('\n')}

class MockFunction extends Mock {
  void call() {}
}''';
  }
}
