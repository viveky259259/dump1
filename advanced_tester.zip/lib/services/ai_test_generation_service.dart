import 'dart:io';
import 'inspector_service.dart';
import 'dependency_analysis_service.dart';
import 'enhanced_dependency_analysis_service.dart';
import '../core/analysis/recursive_children_analyzer.dart';
import '../core/config/environment_service.dart';
import '../core/logging/logging.dart';

/// Service for generating test files using AI
class AITestGenerationService with LoggerMixin {
  final String? projectPath;
  final String? apiKey;
  final EnvironmentService? environmentService;
  final InspectorService? inspectorService;
  final DependencyAnalysisService? dependencyService;
  final EnhancedDependencyAnalysisService? enhancedDependencyService;

  RecursiveChildrenAnalyzer? _recursiveAnalyzer;

  AITestGenerationService({
    this.projectPath,
    this.apiKey,
    this.environmentService,
    this.inspectorService,
    this.dependencyService,
    this.enhancedDependencyService,
  }) {
    logger.info('AITestGenerationService initialized', {
      'projectPath': projectPath,
      'hasApiKey': apiKey != null,
    });
    _initializeRecursiveAnalyzer();
  }

  /// Initialize recursive analyzer with configuration
  void _initializeRecursiveAnalyzer() {
    print('🔍 🔍 DEBUG: Initializing recursive analyzer...');
    print(
      '🔍 🔍 DEBUG: environmentService is null: ${environmentService == null}',
    );
    print('🔍 🔍 DEBUG: inspectorService is null: ${inspectorService == null}');

    if (environmentService != null) {
      final config = RecursiveAnalysisConfig.fromEnvironment(
        environmentService!.config,
      );
      _recursiveAnalyzer = RecursiveChildrenAnalyzer(
        config: config,
        inspectorService: inspectorService,
        dependencyService: dependencyService,
        enhancedDependencyService: enhancedDependencyService,
      );
      print('🔍 🔍 DEBUG: Recursive analyzer initialized successfully');
    } else {
      print(
        '🔍 🔍 DEBUG: Recursive analyzer NOT initialized - environmentService is null',
      );
    }
  }

  /// Generate a test file for a widget using AI
  Future<bool> generateTestForWidget(WidgetTreeNode node) async {
    return await logAsyncOperation(
      'generateTestForWidget',
      () async => _generateTestForWidgetImpl(node),
      context: {'widgetType': node.type, 'objectId': node.objectId},
    );
  }

  Future<bool> _generateTestForWidgetImpl(WidgetTreeNode node) async {
    try {
      logger.info('Generating AI test for widget', {'type': node.type});
      // Check if widget has creation location
      final creationLocation = node.creationLocation;
      if (creationLocation == null) {
        throw Exception('No creation location found for widget');
      }

      // Extract file path and convert to test path
      final sourceFilePath = creationLocation.file;
      final testFilePath = convertToTestPath(sourceFilePath);

      // Create test directory if it doesn't exist
      final testDir = Directory(testFilePath).parent;
      if (!await testDir.exists()) {
        await testDir.create(recursive: true);
      }

      // Generate test content using AI
      final testContent = await _generateAITestContent(node, creationLocation);

      // Write test file
      final testFile = File(testFilePath);
      await testFile.writeAsString(testContent);

      logger.info('AI test file generated successfully', {
        'path': testFilePath,
      });
      return true;
    } catch (e, stackTrace) {
      logger.error('Error generating AI test', e, stackTrace, {
        'widgetType': node.type,
      });
      return false;
    }
  }

  /// Convert source file path to test file path
  String convertToTestPath(String sourcePath) {
    if (sourcePath.startsWith('file://')) {
      // Remove file:// prefix
      final cleanPath = sourcePath.substring(7);

      // Find the lib/ directory in the path
      final libIndex = cleanPath.indexOf('/lib/');
      if (libIndex != -1) {
        // Extract the project root and the relative path from lib/
        final projectRoot = cleanPath.substring(0, libIndex);
        final relativePath = cleanPath.substring(
          libIndex + 5,
        ); // +5 for '/lib/'

        // Convert to test path
        final testPath = '$projectRoot/test/$relativePath';
        return testPath.replaceAll('.dart', '_test.dart');
      }

      // If no lib/ found, try to extract filename and create in test directory
      final fileName = cleanPath
          .split('/')
          .last
          .replaceAll('.dart', '_test.dart');
      final projectRoot = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
      return '$projectRoot/test/$fileName';
    }

    // Handle relative paths starting with lib/
    if (sourcePath.startsWith('lib/')) {
      return sourcePath
          .replaceFirst('lib/', 'test/')
          .replaceAll('.dart', '_test.dart');
    }

    // Handle absolute paths containing /lib/
    if (sourcePath.contains('/lib/')) {
      final parts = sourcePath.split('/lib/');
      if (parts.length > 1) {
        final projectRoot = parts[0];
        final relativePath = parts[1];
        return '$projectRoot/test/$relativePath'.replaceAll(
          '.dart',
          '_test.dart',
        );
      }
    }

    // Fallback: create test in test directory
    final fileName = sourcePath
        .split('/')
        .last
        .replaceAll('.dart', '_test.dart');
    return 'test/$fileName';
  }

  /// Generate test content using AI
  Future<String> _generateAITestContent(
    WidgetTreeNode node,
    CreationLocation location,
  ) async {
    try {
      // Check if API key is available
      if (apiKey == null || apiKey!.isEmpty) {
        print('No OpenAI API key provided, using fallback generation');
        return await _generateFallbackTestContent(node, location);
      }

      // Prepare widget information for AI
      final widgetInfo = await _prepareWidgetInfo(node, location);

      // Create AI prompt
      final prompt = _createTestGenerationPrompt(widgetInfo);
      print(prompt);
      // Call OpenAI API using HTTP
      // final response = await _callOpenAIAPI(prompt);
      final response = '';
      if (response.isEmpty) {
        throw Exception('AI generated empty content');
      }

      return response;
    } catch (e) {
      print('Error generating AI test content: $e');
      // Fallback to basic test generation
      return await _generateFallbackTestContent(node, location);
    }
  }

  /// Prepare comprehensive widget information for AI analysis
  /// This enhanced version utilizes multiple DevTools services to provide
  /// detailed widget tree analysis, dependencies, and properties
  Future<Map<String, dynamic>> _prepareWidgetInfo(
    WidgetTreeNode node,
    CreationLocation location,
  ) async {
    final widgetType = node.widgetRuntimeType ?? node.description ?? 'Widget';
    final widgetName = _extractWidgetName(widgetType);

    print('🔍 Preparing comprehensive widget info for: $widgetType');

    // Extract comprehensive widget properties using inspector service
    final properties = await _extractComprehensiveProperties(node);

    // Extract detailed child information with their properties using recursive analyzer
    final children = await _extractDetailedChildrenInfoRecursively(node);

    // Extract widget dependencies using dependency analysis service
    final dependencies = await _extractWidgetDependencies(node);

    // Extract source code context
    final sourceContext = await _extractSourceContext(node, location);

    // Extract widget hierarchy and constraints
    final hierarchy = await _extractWidgetHierarchy(node);

    // Extract accessibility and semantic information
    final accessibility = await _extractAccessibilityInfo(node);

    // Generate import path
    final importPath = _generateImportPath(location.file);

    final comprehensiveInfo = {
      'widgetType': widgetType,
      'widgetName': widgetName,
      'importPath': importPath,
      'properties': properties,
      'children': children,
      'dependencies': dependencies,
      'sourceContext': sourceContext,
      'hierarchy': hierarchy,
      'accessibility': accessibility,
      'hasChildren': node.children.isNotEmpty,
      'description': node.description,
      'objectId': node.objectId,
      'creationLocation': {
        'file': location.file,
        'line': location.line,
        'column': location.column,
      },
      'analysisTimestamp': DateTime.now().toIso8601String(),
    };

    print(
      '🔍 ✅ Prepared comprehensive info with ${properties.length} properties, ${children.length} children, ${dependencies.length} dependencies',
    );
    return comprehensiveInfo;
  }

  /// Create focused prompt for AI test generation following the template structure
  String _createTestGenerationPrompt(Map<String, dynamic> widgetInfo) {
    final buffer = StringBuffer();

    // Follow the widget_test_prompt_template.md structure
    buffer.writeln('Generate a single Dart widget test file.');
    buffer.writeln('Return ONLY the Dart code, no explanations or markdown.');
    buffer.writeln();

    // Extract clean widget information
    final widgetType = widgetInfo['widgetType'] as String? ?? '';
    final sourceFile =
        (widgetInfo['sourceContext'] as Map)['file'] as String? ?? '';
    final importPath = widgetInfo['importPath'] as String? ?? '';

    // Clean widget type - remove generic types
    final cleanWidgetType = _cleanWidgetType(widgetType);
    final testFileName = _generateTestFileName(sourceFile);

    buffer.writeln('=== FILE INFO ===');
    buffer.writeln('File name: $testFileName');
    buffer.writeln();

    // Extract imports
    final sourceContext = widgetInfo['sourceContext'] as Map<String, dynamic>?;

    buffer.writeln('=== IMPORTS ===');
    buffer.writeln('- package:flutter_test/flutter_test.dart');
    buffer.writeln('- package:flutter/material.dart');

    // Check for Provider dependencies
    final dependencies = widgetInfo['dependencies'] as List<dynamic>? ?? [];
    final hasProvider = dependencies.any(
      (dep) => (dep as Map<String, dynamic>)['category'] == 'Provider',
    );
    if (hasProvider) {
      buffer.writeln('- package:provider/provider.dart');
    }

    // Add widget import
    if (importPath.isNotEmpty && importPath != 'main') {
      buffer.writeln('- package:<your_app>/$importPath show $cleanWidgetType');
    }
    buffer.writeln();

    // Widget under test
    buffer.writeln('=== WIDGET UNDER TEST ===');
    buffer.writeln('Widget/Class: $cleanWidgetType');

    // Extract constructor signature from class definition
    final classDefinition = sourceContext?['classDefinition'] as String? ?? '';
    final constructorSignature = _extractConstructorSignature(
      classDefinition,
      cleanWidgetType,
    );
    buffer.writeln('Constructor signature: $constructorSignature');

    buffer.writeln('Factory for test:');
    buffer.writeln();
    buffer.writeln('Widget buildTestSubject() {');
    buffer.writeln('  return MaterialApp(');
    buffer.writeln('    debugShowCheckedModeBanner: false,');
    buffer.writeln('    theme: ThemeData(useMaterial3: true),');

    // Add wrapper if needed (Provider, etc.)
    if (hasProvider) {
      buffer.writeln('    home: Provider<MyModel>(');
      buffer.writeln('      create: (_) => MyModel(),');
      buffer.writeln('      child: $cleanWidgetType(');
    } else {
      buffer.writeln('    home: $cleanWidgetType(');
    }

    buffer.writeln(
      '        key: Key(\'${cleanWidgetType.toLowerCase()}_key\'),',
    );

    // Add constructor parameters if available
    final constructorParams = _extractConstructorParams(constructorSignature);
    if (constructorParams.isNotEmpty) {
      for (final param in constructorParams) {
        buffer.writeln('        $param,');
      }
    }

    // Add widget properties
    final widgetProperties = _generateWidgetProperties(widgetInfo);
    if (widgetProperties.isNotEmpty) {
      buffer.writeln('        $widgetProperties');
    }

    // Add widget tree structure with children
    final widgetTreeCode = _generateWidgetTreeCode(widgetInfo);
    if (widgetTreeCode.isNotEmpty) {
      buffer.writeln('        $widgetTreeCode');
    }

    if (hasProvider) {
      buffer.writeln('      ),');
      buffer.writeln('    ),');
    } else {
      buffer.writeln('      ),');
    }
    buffer.writeln('  );');
    buffer.writeln('}');
    buffer.writeln();

    // Widget properties
    final properties = widgetInfo['properties'] as List<dynamic>? ?? [];
    if (properties.isNotEmpty) {
      buffer.writeln('=== WIDGET PROPERTIES ===');
      for (final prop in properties) {
        final propMap = prop as Map<String, dynamic>;
        buffer.writeln(
          '- ${propMap['name']}: ${propMap['value']} (${propMap['type']}) [${propMap['source']}]',
        );
      }
      buffer.writeln();
    }

    // Child widgets
    final children = widgetInfo['children'] as List<dynamic>? ?? [];
    print('🔍 📋 Prompt generation: Processing ${children.length} children');

    if (children.isNotEmpty) {
      buffer.writeln('=== CHILD WIDGETS ===');
      for (int i = 0; i < children.length; i++) {
        final childMap = children[i] as Map<String, dynamic>;
        final childType = childMap['type'];
        buffer.writeln(
          '- ${childMap['type']} (${childMap['name']}): ${childMap['description']}',
        );

        // Check if child has properties (they SHOULD after recursive extraction)
        final childProperties = childMap['properties'] as List<dynamic>? ?? [];
        print(
          '🔍 🔍 Child #$i ($childType) has ${childProperties.length} properties',
        );

        if (childProperties.isNotEmpty) {
          buffer.writeln('  Properties:');
          for (final prop in childProperties) {
            final propMap = prop as Map<String, dynamic>;
            if (propMap['value'].toString().trim() != '') {
              buffer.writeln(
                '    - ${propMap['name']}: ${propMap['value']} (${propMap['type']})',
              );
            }
          }
        } else {
          print(
            '🔍 ⚠️  WARNING: Child #$i ($childType) has NO properties! This might indicate a problem.',
          );
        }

        final grandChildren = childMap['children'] as List<dynamic>? ?? [];
        if (grandChildren.isNotEmpty) {
          buffer.writeln('  Children:');
          for (final grandChild in grandChildren) {
            final grandChildMap = grandChild as Map<String, dynamic>;
            buffer.writeln(
              '    - ${grandChildMap['type']}: ${grandChildMap['description']}',
            );
          }
        }
        buffer.writeln();
      }
    }

    // Stable identifiers
    buffer.writeln('=== STABLE IDENTIFIERS ===');
    buffer.writeln(
      '- Root widget: Key(\'${cleanWidgetType.toLowerCase()}_key\')',
    );

    // Extract stable identifiers from children
    final childWidgets = widgetInfo['children'] as List<dynamic>? ?? [];
    final stableIdentifiers = _extractStableIdentifiers(childWidgets);
    for (int i = 0; i < stableIdentifiers.length && i < 4; i++) {
      final identifier = stableIdentifiers[i];
      buffer.writeln('- ${identifier['type']}: ${identifier['identifier']}');
    }
    buffer.writeln();

    // Test requirements
    buffer.writeln('=== TEST REQUIREMENTS ===');
    buffer.writeln('1. Group tests under `group(\'$cleanWidgetType\', ...)`.');
    buffer.writeln('2. Verify widget renders with all expected children.');
    buffer.writeln(
      '3. Assert child properties (text values, sizes, alignment, etc.).',
    );
    buffer.writeln(
      '4. Test interactions (e.g., tapping buttons, form submissions).',
    );
    buffer.writeln('5. Test conditional UI state changes (if applicable).');
    buffer.writeln('6. Verify provider/dependency setup (if required).');
    buffer.writeln(
      '7. Assert theming/config flags (e.g., `useMaterial3 == true`, `debugShowCheckedModeBanner == false`).',
    );
    buffer.writeln(
      '8. Accessibility/semantics tests if semantics labels/roles provided.',
    );
    buffer.writeln(
      '9. Use robust finders (`find.byKey`, `find.text`) and clear test names.',
    );
    buffer.writeln(
      '10. Omit performance, memory, lifecycle, or error-handling tests unless explicitly specified.',
    );
    buffer.writeln();

    // Non-goals
    buffer.writeln('=== NON-GOALS ===');
    buffer.writeln(
      '- Lifecycle testing (unless specific lifecycle code is provided)',
    );
    buffer.writeln(
      '- Generic error handling tests (unless specific error scenarios are provided)',
    );
    buffer.writeln('- Negative scenarios without specific test cases');
    buffer.writeln();

    // Output constraints
    buffer.writeln('=== OUTPUT CONSTRAINTS ===');
    buffer.writeln('- Return one Dart test file, named `$testFileName`.');
    buffer.writeln('- Contain only Dart code.');
    buffer.writeln('- No markdown, comments, or explanations.');

    return buffer.toString();
  }

  /// Generate fallback test content when AI fails
  Future<String> _generateFallbackTestContent(
    WidgetTreeNode node,
    CreationLocation location,
  ) async {
    final widgetType = node.widgetRuntimeType ?? node.description ?? 'Widget';
    final widgetName = _extractWidgetName(widgetType);
    final importPath = _generateImportPath(location.file);

    final buffer = StringBuffer();

    // Add imports
    buffer.writeln("import 'package:flutter/material.dart';");
    buffer.writeln("import 'package:flutter_test/flutter_test.dart';");
    buffer.writeln("import '$importPath';");
    buffer.writeln();

    // Add main test group
    buffer.writeln('void main() {');
    buffer.writeln('  group(\'$widgetName Tests\', () {');
    buffer.writeln();

    // Add basic widget test
    buffer.writeln(
      '    testWidgets(\'should render $widgetName correctly\', (WidgetTester tester) async {',
    );
    buffer.writeln('      // Arrange');
    buffer.writeln('      await tester.pumpWidget(');
    buffer.writeln('        MaterialApp(');
    buffer.writeln('          home: $widgetName(),');
    buffer.writeln('        ),');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Act & Assert');
    buffer.writeln('      expect(find.byType($widgetName), findsOneWidget);');
    buffer.writeln('    });');
    buffer.writeln();

    // Add widget tree test
    buffer.writeln(
      '    testWidgets(\'should have correct widget tree structure\', (WidgetTester tester) async {',
    );
    buffer.writeln('      // Arrange');
    buffer.writeln('      await tester.pumpWidget(');
    buffer.writeln('        MaterialApp(');
    buffer.writeln('          home: $widgetName(),');
    buffer.writeln('        ),');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Act & Assert');
    buffer.writeln('      expect(find.byType($widgetName), findsOneWidget);');

    // Add child widget tests if the widget has children
    if (node.children.isNotEmpty) {
      buffer.writeln();
      buffer.writeln('      // Test child widgets');
      for (final child in node.children) {
        final childType =
            child.widgetRuntimeType ?? child.description ?? 'Widget';
        final childName = _extractWidgetName(childType);
        buffer.writeln(
          '      expect(find.byType($childName), findsOneWidget);',
        );
      }
    }

    buffer.writeln('    });');
    buffer.writeln();
    buffer.writeln('  });');
    buffer.writeln('}');

    return buffer.toString();
  }

  /// Extract widget name from type
  String _extractWidgetName(String widgetType) {
    // Remove common prefixes and suffixes
    String name = widgetType;

    // Remove generic type parameters
    if (name.contains('<')) {
      name = name.substring(0, name.indexOf('<'));
    }

    // Remove underscores
    name = name.replaceAll('_', '');

    // Capitalize first letter
    if (name.isNotEmpty) {
      name = name[0].toUpperCase() + name.substring(1);
    }

    return name;
  }

  /// Generate import path based on file location
  String _generateImportPath(String filePath) {
    if (filePath.startsWith('file://')) {
      final cleanPath = filePath.substring(7);
      final libIndex = cleanPath.indexOf('/lib/');
      if (libIndex != -1) {
        final relativePath = cleanPath.substring(
          libIndex + 5,
        ); // +5 for '/lib/'
        return relativePath.replaceAll('.dart', '');
      }
    }

    if (filePath.startsWith('lib/')) {
      return filePath.replaceAll('.dart', '');
    }

    if (filePath.contains('/lib/')) {
      final parts = filePath.split('/lib/');
      if (parts.length > 1) {
        return parts[1].replaceAll('.dart', '');
      }
    }

    // Fallback
    final fileName = filePath.split('/').last.replaceAll('.dart', '');
    return fileName;
  }

  /// Extract comprehensive widget properties using inspector service
  Future<List<Map<String, dynamic>>> _extractComprehensiveProperties(
    WidgetTreeNode node,
  ) async {
    final properties = <Map<String, dynamic>>[];

    try {
      // Get properties from node attributes if available
      if (node.attributes != null) {
        for (final attr in node.attributes!) {
          // Filter out inspector noise
          if (_isInspectorNoise(attr.name, attr.label)) continue;

          properties.add({
            'name': attr.name,
            'value': attr.label,
            'type': _inferPropertyType(attr.label),
            'source': 'node_attributes',
          });
        }
      }

      // Get detailed properties using inspector service if objectId is available
      if (node.objectId != null) {
        final detailedProperties = await _getDetailedWidgetProperties(node);
        properties.addAll(detailedProperties);
      }

      // If no properties found, add widget-specific properties
      if (properties.isEmpty) {
        final widgetSpecificProps = _extractWidgetSpecificProperties(node);
        properties.addAll(widgetSpecificProps);
      }
    } catch (e) {
      print('🔍 ❌ Error extracting comprehensive properties: $e');
    }

    return properties;
  }

  /// Check if property is inspector noise that should be filtered out
  bool _isInspectorNoise(String name, String value) {
    // Filter out inspector noise
    final noisePatterns = [
      'inspector-',
      'dirty',
      'depth',
      'renderObject',
      'BoxConstraints',
      'RenderObject',
      'Element',
      'Widget',
      'State',
    ];

    for (final pattern in noisePatterns) {
      if (name.toLowerCase().contains(pattern.toLowerCase()) ||
          value.toLowerCase().contains(pattern.toLowerCase())) {
        return true;
      }
    }

    // Filter out generic descriptions
    if (value.isEmpty ||
        value == 'null' ||
        value == 'true' ||
        value == 'false') {
      return true;
    }

    return false;
  }

  /// Extract detailed children information with their properties using recursive analyzer
  Future<List<Map<String, dynamic>>> _extractDetailedChildrenInfoRecursively(
    WidgetTreeNode node,
  ) async {
    print(
      '🔍 🔍 DEBUG: _recursiveAnalyzer is null: ${_recursiveAnalyzer == null}',
    );

    if (_recursiveAnalyzer == null) {
      print('🔍 🔍 DEBUG: Using fallback to _extractDetailedChildrenInfo');
      // Fallback to original method if recursive analyzer is not available
      final nodeDetails = await _extractDetailedChildrenInfo(node);
      // Extract children from the node details since we need a list of children
      final children = nodeDetails['children'] as List<dynamic>? ?? [];
      print(
        '🔍 🔍 DEBUG FALLBACK: Extracted ${children.length} children from node details',
      );
      return children.cast<Map<String, dynamic>>();
    }

    try {
      // Check if detailed hierarchy is enabled
      final useDetailedHierarchy =
          environmentService?.config.recursiveAnalysisUseDetailedHierarchy ??
          true;

      print(
        '🔍 Using recursive analyzer ${useDetailedHierarchy ? 'with detailed hierarchy' : 'with summary tree'} for comprehensive children analysis',
      );

      // Use appropriate analyzer based on configuration
      final recursiveResult = useDetailedHierarchy
          ? await _recursiveAnalyzer!
                .analyzeChildrenRecursivelyWithDetailedHierarchy(
                  node,
                  currentDepth: 0,
                  packageName: await _extractPackageName(),
                  projectPath: projectPath,
                )
          : await _recursiveAnalyzer!.analyzeChildrenRecursively(
              node,
              currentDepth: 0,
              packageName: await _extractPackageName(),
              projectPath: projectPath,
            );

      // Debug: Log the actual structure returned
      print(
        '🔍 🔍 DEBUG: recursiveResult type: ${recursiveResult.runtimeType}',
      );
      print(
        '🔍 🔍 DEBUG: recursiveResult keys: ${recursiveResult.keys.toList()}',
      );
      print(
        '🔍 🔍 DEBUG: children type: ${recursiveResult['children'].runtimeType}',
      );
      print('🔍 🔍 DEBUG: children value: ${recursiveResult['children']}');

      final children =
          recursiveResult['children'] as List<Map<String, dynamic>>? ?? [];

      print(
        '🔍 ✅ Detailed hierarchy analysis completed: ${children.length} children analyzed',
      );
      print('🔍 📊 Analysis config: ${recursiveResult['analysisConfig']}');

      return children;
    } catch (e) {
      print('🔍 ❌ Error in detailed hierarchy analysis: $e');
      // Fallback to original recursive method
      try {
        final fallbackResult = await _recursiveAnalyzer!
            .analyzeChildrenRecursively(
              node,
              currentDepth: 0,
              packageName: await _extractPackageName(),
              projectPath: projectPath,
            );
        // Debug: Log the fallback structure
        print(
          '🔍 🔍 DEBUG FALLBACK: fallbackResult type: ${fallbackResult.runtimeType}',
        );
        print(
          '🔍 🔍 DEBUG FALLBACK: fallbackResult keys: ${fallbackResult.keys.toList()}',
        );
        print(
          '🔍 🔍 DEBUG FALLBACK: children type: ${fallbackResult['children'].runtimeType}',
        );
        print(
          '🔍 🔍 DEBUG FALLBACK: children value: ${fallbackResult['children']}',
        );

        final children =
            fallbackResult['children'] as List<Map<String, dynamic>>? ?? [];
        print(
          '🔍 ✅ Fallback recursive analysis completed: ${children.length} children analyzed',
        );
        return children;
      } catch (fallbackError) {
        print('🔍 ❌ Fallback also failed: $fallbackError');
        // Final fallback to original method
        final nodeDetails = await _extractDetailedChildrenInfo(node);
        // Debug: Log the final fallback structure
        print(
          '🔍 🔍 DEBUG FINAL FALLBACK: nodeDetails type: ${nodeDetails.runtimeType}',
        );
        print(
          '🔍 🔍 DEBUG FINAL FALLBACK: nodeDetails keys: ${nodeDetails.keys.toList()}',
        );
        print(
          '🔍 🔍 DEBUG FINAL FALLBACK: children type: ${nodeDetails['children'].runtimeType}',
        );
        print(
          '🔍 🔍 DEBUG FINAL FALLBACK: children value: ${nodeDetails['children']}',
        );

        // Extract children from the node details since we need a list of children
        final children = nodeDetails['children'] as List<dynamic>? ?? [];
        print(
          '🔍 🔍 DEBUG FINAL FALLBACK: Extracted ${children.length} children from node details',
        );
        return children.cast<Map<String, dynamic>>();
      }
    }
  }

  /// Extract detailed node information with children using recursive method
  Future<Map<String, dynamic>> _extractDetailedChildrenInfo(
    WidgetTreeNode node,
  ) async {
    try {
      // Extract current node details
      final nodeType = node.widgetRuntimeType ?? node.description ?? 'Widget';
      final nodeName = _extractWidgetName(nodeType);

      print(
        '🔍 📝 Extracting properties for: $nodeType (objectId: ${node.objectId})',
      );

      // Get current node properties - THIS MAKES A SEPARATE SERVER QUERY
      final nodeProperties = await _extractComprehensiveProperties(node);

      print(
        '🔍 ✅ Extracted ${nodeProperties.length} properties for: $nodeType',
      );

      // Recursively process children - EACH CHILD GETS ITS OWN SERVER QUERY
      final children = <Map<String, dynamic>>[];
      for (final child in node.children) {
        final childDetails = await _extractDetailedChildrenInfo(child);
        children.add(childDetails);
      }

      print(
        '🔍 📊 Node $nodeType has ${nodeProperties.length} properties and ${children.length} children',
      );

      // Return current node details with recursively processed children
      return {
        'type': nodeType,
        'name': nodeName,
        'description': node.description,
        'hasChildren': node.children.isNotEmpty,
        'objectId': node.objectId,
        'properties': nodeProperties,
        'children': children,
        'depth': _getWidgetDepth(node),
        'childrenCount': node.children.length,
      };
    } catch (e) {
      print('🔍 ❌ Error extracting detailed node info recursively: $e');

      // Return fallback structure in case of error
      return {
        'type': node.widgetRuntimeType ?? node.description ?? 'Widget',
        'name': _extractWidgetName(
          node.widgetRuntimeType ?? node.description ?? 'Widget',
        ),
        'description': node.description,
        'hasChildren': node.children.isNotEmpty,
        'objectId': node.objectId,
        'properties': <Map<String, dynamic>>[],
        'children': <Map<String, dynamic>>[],
        'depth': _getWidgetDepth(node),
        'childrenCount': 0,
        'error': e.toString(),
      };
    }
  }

  /// Extract package name from project path
  Future<String?> _extractPackageName() async {
    if (projectPath == null) return null;

    try {
      // Try to read pubspec.yaml to get package name
      final pubspecFile = '$projectPath/pubspec.yaml';
      final file = File(pubspecFile);

      if (await file.exists()) {
        final content = await file.readAsString();
        final nameMatch = RegExp(
          r'^name:\s*(.+)$',
          multiLine: true,
        ).firstMatch(content);
        if (nameMatch != null) {
          return nameMatch.group(1)?.trim();
        }
      }

      // Fallback: extract from project path
      return projectPath!.split('/').last;
    } catch (e) {
      print('🔍 ❌ Error extracting package name: $e');
      return projectPath!.split('/').last;
    }
  }

  /// Extract widget dependencies using dependency analysis service
  Future<List<Map<String, dynamic>>> _extractWidgetDependencies(
    WidgetTreeNode node,
  ) async {
    final dependencies = <Map<String, dynamic>>[];

    try {
      // This would require access to dependency analysis service
      // For now, we'll extract basic dependency information

      // Check for Provider dependencies
      final providerDeps = _extractProviderDependencies(node);
      dependencies.addAll(providerDeps);

      // Check for InheritedWidget dependencies
      final inheritedDeps = _extractInheritedWidgetDependencies(node);
      dependencies.addAll(inheritedDeps);

      // Check for Material/Theme dependencies
      final materialDeps = _extractMaterialDependencies(node);
      dependencies.addAll(materialDeps);
    } catch (e) {
      print('🔍 ❌ Error extracting widget dependencies: $e');
    }

    return dependencies;
  }

  /// Extract source code context
  Future<Map<String, dynamic>> _extractSourceContext(
    WidgetTreeNode node,
    CreationLocation location,
  ) async {
    try {
      // Read source file content
      final sourceFile = File(location.file.replaceFirst('file://', ''));
      String sourceContent = '';
      if (await sourceFile.exists()) {
        sourceContent = await sourceFile.readAsStringSync();
      }

      // Extract relevant code around the widget creation
      final relevantCode = _extractRelevantSourceCode(sourceContent, location);

      return {
        'file': location.file,
        'line': location.line,
        'column': location.column,
        'sourceContent': sourceContent,
        'relevantCode': relevantCode,
        'imports': _extractImports(sourceContent),
        'classDefinition': _extractClassDefinition(sourceContent, location),
      };
    } catch (e) {
      print('🔍 ❌ Error extracting source context: $e');
      return {};
    }
  }

  /// Extract widget hierarchy and constraints
  Future<Map<String, dynamic>> _extractWidgetHierarchy(
    WidgetTreeNode node,
  ) async {
    try {
      return {
        'depth': _getWidgetDepth(node),
        'parentType': _getParentType(node),
        'siblingCount': _getSiblingCount(node),
        'isRoot': _isRootWidget(node),
        'constraints': _extractConstraints(node),
        'layoutType': _extractLayoutType(node),
      };
    } catch (e) {
      print('🔍 ❌ Error extracting widget hierarchy: $e');
      return {};
    }
  }

  /// Check if widget is likely a root widget
  bool _isRootWidget(WidgetTreeNode node) {
    final description = node.description?.toLowerCase() ?? '';
    final widgetType = node.widgetRuntimeType?.toLowerCase() ?? '';

    return description.contains('root') ||
        description.contains('app') ||
        widgetType.contains('app') ||
        widgetType.contains('materialapp') ||
        widgetType.contains('cupertinoapp');
  }

  /// Extract accessibility and semantic information
  Future<Map<String, dynamic>> _extractAccessibilityInfo(
    WidgetTreeNode node,
  ) async {
    try {
      return {
        'semanticLabel': _extractSemanticLabel(node),
        'semanticHint': _extractSemanticHint(node),
        'isAccessible': _isAccessible(node),
        'accessibilityTraits': _extractAccessibilityTraits(node),
        'focusable': _isFocusable(node),
      };
    } catch (e) {
      print('🔍 ❌ Error extracting accessibility info: $e');
      return {};
    }
  }

  /// Get detailed widget properties using inspector service
  Future<List<Map<String, dynamic>>> _getDetailedWidgetProperties(
    WidgetTreeNode node,
  ) async {
    final properties = <Map<String, dynamic>>[];

    try {
      // Use inspector service if available
      if (inspectorService != null && node.objectId != null) {
        print(
          '🔍 🌐 Making SERVER QUERY for properties: ${node.widgetRuntimeType} (objectId: ${node.objectId})',
        );

        final inspectorProperties = await inspectorService!.getWidgetProperties(
          node.objectId!,
          node.widgetRuntimeType,
        );

        print(
          '🔍 📨 Server returned ${inspectorProperties.length} properties for: ${node.widgetRuntimeType}',
        );

        for (final prop in inspectorProperties) {
          // Filter out inspector noise
          if (_isInspectorNoise(prop.name, prop.label)) continue;

          properties.add({
            'name': prop.name,
            'value': prop.label,
            'type': prop.type,
            'source': 'inspector_service',
          });
        }
      } else {
        print(
          '🔍 ⚠️  Cannot query server - inspectorService: ${inspectorService != null}, objectId: ${node.objectId}',
        );
      }

      // Add widget-specific properties based on type
      final widgetSpecificProps = _extractWidgetSpecificProperties(node);
      properties.addAll(widgetSpecificProps);
    } catch (e) {
      print('🔍 ❌ Error getting detailed widget properties: $e');
    }

    return properties;
  }

  /// Extract widget-specific properties based on type
  List<Map<String, dynamic>> _extractWidgetSpecificProperties(
    WidgetTreeNode node,
  ) {
    final properties = <Map<String, dynamic>>[];
    final widgetType = node.widgetRuntimeType?.toLowerCase() ?? '';

    if (widgetType.contains('text')) {
      properties.addAll(_extractTextWidgetProperties(node));
    } else if (widgetType.contains('container')) {
      properties.addAll(_extractContainerProperties(node));
    } else if (widgetType.contains('button')) {
      properties.addAll(_extractButtonProperties(node));
    } else if (widgetType.contains('image')) {
      properties.addAll(_extractImageProperties(node));
    } else if (widgetType.contains('list')) {
      properties.addAll(_extractListProperties(node));
    } else if (widgetType.contains('column')) {
      properties.addAll(_extractColumnProperties(node));
    } else if (widgetType.contains('row')) {
      properties.addAll(_extractRowProperties(node));
    } else if (widgetType.contains('scaffold')) {
      properties.addAll(_extractScaffoldProperties(node));
    } else if (widgetType.contains('appbar')) {
      properties.addAll(_extractAppBarProperties(node));
    }

    return properties;
  }

  /// Extract Text widget specific properties
  List<Map<String, dynamic>> _extractTextWidgetProperties(WidgetTreeNode node) {
    return [
      {'name': 'textStyle', 'type': 'TextStyle', 'source': 'widget_specific'},
      {'name': 'textAlign', 'type': 'TextAlign', 'source': 'widget_specific'},
      {'name': 'overflow', 'type': 'TextOverflow', 'source': 'widget_specific'},
      {'name': 'maxLines', 'type': 'int', 'source': 'widget_specific'},
    ];
  }

  /// Extract Container widget specific properties
  List<Map<String, dynamic>> _extractContainerProperties(WidgetTreeNode node) {
    return [
      {'name': 'width', 'type': 'double', 'source': 'widget_specific'},
      {'name': 'height', 'type': 'double', 'source': 'widget_specific'},
      {'name': 'color', 'type': 'Color', 'source': 'widget_specific'},
      {'name': 'padding', 'type': 'EdgeInsets', 'source': 'widget_specific'},
      {'name': 'margin', 'type': 'EdgeInsets', 'source': 'widget_specific'},
      {
        'name': 'decoration',
        'type': 'BoxDecoration',
        'source': 'widget_specific',
      },
    ];
  }

  /// Extract Button widget specific properties
  List<Map<String, dynamic>> _extractButtonProperties(WidgetTreeNode node) {
    return [
      {
        'name': 'onPressed',
        'type': 'VoidCallback',
        'source': 'widget_specific',
      },
      {'name': 'child', 'type': 'Widget', 'source': 'widget_specific'},
      {'name': 'style', 'type': 'ButtonStyle', 'source': 'widget_specific'},
    ];
  }

  /// Extract Image widget specific properties
  List<Map<String, dynamic>> _extractImageProperties(WidgetTreeNode node) {
    return [
      {'name': 'image', 'type': 'ImageProvider', 'source': 'widget_specific'},
      {'name': 'width', 'type': 'double', 'source': 'widget_specific'},
      {'name': 'height', 'type': 'double', 'source': 'widget_specific'},
      {'name': 'fit', 'type': 'BoxFit', 'source': 'widget_specific'},
    ];
  }

  /// Extract List widget specific properties
  List<Map<String, dynamic>> _extractListProperties(WidgetTreeNode node) {
    return [
      {'name': 'itemCount', 'type': 'int', 'source': 'widget_specific'},
      {
        'name': 'itemBuilder',
        'type': 'IndexedWidgetBuilder',
        'source': 'widget_specific',
      },
      {'name': 'scrollDirection', 'type': 'Axis', 'source': 'widget_specific'},
    ];
  }

  /// Extract Column widget specific properties
  List<Map<String, dynamic>> _extractColumnProperties(WidgetTreeNode node) {
    return [
      {
        'name': 'mainAxisAlignment',
        'type': 'MainAxisAlignment',
        'source': 'widget_specific',
      },
      {
        'name': 'crossAxisAlignment',
        'type': 'CrossAxisAlignment',
        'source': 'widget_specific',
      },
      {
        'name': 'mainAxisSize',
        'type': 'MainAxisSize',
        'source': 'widget_specific',
      },
      {
        'name': 'textDirection',
        'type': 'TextDirection',
        'source': 'widget_specific',
      },
      {
        'name': 'verticalDirection',
        'type': 'VerticalDirection',
        'source': 'widget_specific',
      },
      {
        'name': 'textBaseline',
        'type': 'TextBaseline',
        'source': 'widget_specific',
      },
    ];
  }

  /// Extract Row widget specific properties
  List<Map<String, dynamic>> _extractRowProperties(WidgetTreeNode node) {
    return [
      {
        'name': 'mainAxisAlignment',
        'type': 'MainAxisAlignment',
        'source': 'widget_specific',
      },
      {
        'name': 'crossAxisAlignment',
        'type': 'CrossAxisAlignment',
        'source': 'widget_specific',
      },
      {
        'name': 'mainAxisSize',
        'type': 'MainAxisSize',
        'source': 'widget_specific',
      },
      {
        'name': 'textDirection',
        'type': 'TextDirection',
        'source': 'widget_specific',
      },
      {
        'name': 'verticalDirection',
        'type': 'VerticalDirection',
        'source': 'widget_specific',
      },
      {
        'name': 'textBaseline',
        'type': 'TextBaseline',
        'source': 'widget_specific',
      },
    ];
  }

  /// Extract Scaffold widget specific properties
  List<Map<String, dynamic>> _extractScaffoldProperties(WidgetTreeNode node) {
    return [
      {
        'name': 'appBar',
        'type': 'PreferredSizeWidget',
        'source': 'widget_specific',
      },
      {'name': 'body', 'type': 'Widget', 'source': 'widget_specific'},
      {
        'name': 'floatingActionButton',
        'type': 'Widget',
        'source': 'widget_specific',
      },
      {
        'name': 'floatingActionButtonLocation',
        'type': 'FloatingActionButtonLocation',
        'source': 'widget_specific',
      },
      {'name': 'drawer', 'type': 'Widget', 'source': 'widget_specific'},
      {'name': 'endDrawer', 'type': 'Widget', 'source': 'widget_specific'},
      {
        'name': 'bottomNavigationBar',
        'type': 'Widget',
        'source': 'widget_specific',
      },
      {'name': 'bottomSheet', 'type': 'Widget', 'source': 'widget_specific'},
      {'name': 'backgroundColor', 'type': 'Color', 'source': 'widget_specific'},
      {
        'name': 'resizeToAvoidBottomInset',
        'type': 'bool',
        'source': 'widget_specific',
      },
    ];
  }

  /// Extract AppBar widget specific properties
  List<Map<String, dynamic>> _extractAppBarProperties(WidgetTreeNode node) {
    return [
      {'name': 'title', 'type': 'Widget', 'source': 'widget_specific'},
      {'name': 'leading', 'type': 'Widget', 'source': 'widget_specific'},
      {'name': 'actions', 'type': 'List<Widget>', 'source': 'widget_specific'},
      {'name': 'backgroundColor', 'type': 'Color', 'source': 'widget_specific'},
      {'name': 'elevation', 'type': 'double', 'source': 'widget_specific'},
      {'name': 'centerTitle', 'type': 'bool', 'source': 'widget_specific'},
      {
        'name': 'automaticallyImplyLeading',
        'type': 'bool',
        'source': 'widget_specific',
      },
    ];
  }

  /// Extract Provider dependencies
  List<Map<String, dynamic>> _extractProviderDependencies(WidgetTreeNode node) {
    final dependencies = <Map<String, dynamic>>[];

    // Check if widget uses Provider
    if (node.description?.contains('Provider') == true) {
      dependencies.add({
        'type': 'Provider',
        'category': 'Provider',
        'description': 'Widget depends on Provider for state management',
        'setupCode':
            'Provider<MyModel>(create: (_) => MyModel(), child: MyWidget())',
        'distanceFromTarget': 0,
      });
    }

    return dependencies;
  }

  /// Extract InheritedWidget dependencies
  List<Map<String, dynamic>> _extractInheritedWidgetDependencies(
    WidgetTreeNode node,
  ) {
    final dependencies = <Map<String, dynamic>>[];

    // Check for common InheritedWidgets
    final inheritedWidgets = [
      'Theme',
      'MediaQuery',
      'Localizations',
      'Directionality',
    ];

    for (final widget in inheritedWidgets) {
      if (node.description?.contains(widget) == true) {
        dependencies.add({
          'type': widget,
          'category': 'Inherited Widget',
          'description': 'Widget depends on $widget for configuration',
          'setupCode': 'MaterialApp(theme: ThemeData(), child: MyWidget())',
          'distanceFromTarget': 0,
        });
      }
    }

    return dependencies;
  }

  /// Extract Material/Theme dependencies
  List<Map<String, dynamic>> _extractMaterialDependencies(WidgetTreeNode node) {
    final dependencies = <Map<String, dynamic>>[];

    if (node.description?.contains('Material') == true) {
      dependencies.add({
        'type': 'Material',
        'category': 'Material/Theme',
        'description': 'Widget requires Material design context',
        'setupCode': 'MaterialApp(child: MyWidget())',
        'distanceFromTarget': 0,
      });
    }

    return dependencies;
  }

  /// Extract relevant source code around widget creation
  String _extractRelevantSourceCode(
    String sourceContent,
    CreationLocation location,
  ) {
    try {
      final lines = sourceContent.split('\n');
      final targetLine = location.line - 1; // Convert to 0-based index

      // Extract 10 lines before and after the widget creation
      final startLine = (targetLine - 10).clamp(0, lines.length);
      final endLine = (targetLine + 10).clamp(0, lines.length);

      return lines.sublist(startLine, endLine).join('\n');
    } catch (e) {
      return sourceContent;
    }
  }

  /// Extract imports from source code
  List<String> _extractImports(String sourceContent) {
    final imports = <String>[];
    final lines = sourceContent.split('\n');

    for (final line in lines) {
      if (line.trim().startsWith('import ')) {
        imports.add(line.trim());
      }
    }

    return imports;
  }

  /// Extract class definition containing the widget
  String _extractClassDefinition(
    String sourceContent,
    CreationLocation location,
  ) {
    try {
      final lines = sourceContent.split('\n');
      final targetLine = location.line - 1;

      // Find the class definition before the widget creation
      for (int i = targetLine; i >= 0; i--) {
        final line = lines[i].trim();
        if (line.startsWith('class ') && line.contains('extends')) {
          // Extract the class definition
          final classStart = i;
          int classEnd = i;

          // Find the end of the class (simplified)
          for (int j = i + 1; j < lines.length; j++) {
            if (lines[j].trim().startsWith('class ') ||
                lines[j].trim().startsWith('}') &&
                    lines[j].trim().length == 1) {
              classEnd = j;
              break;
            }
          }

          return lines.sublist(classStart, classEnd).join('\n');
        }
      }
    } catch (e) {
      print('🔍 ❌ Error extracting class definition: $e');
    }

    return '';
  }

  /// Get widget depth in the tree
  /// Note: Since WidgetTreeNode doesn't have parent property, we'll estimate depth
  /// based on the widget's position in the tree structure
  int _getWidgetDepth(WidgetTreeNode node) {
    // Since we don't have parent reference, we'll estimate depth based on
    // the widget's description and type patterns
    final description = node.description?.toLowerCase() ?? '';

    // Estimate depth based on common patterns
    if (description.contains('root') || description.contains('app')) return 0;
    if (description.contains('scaffold') || description.contains('material'))
      return 1;
    if (description.contains('body') || description.contains('content'))
      return 2;
    if (description.contains('column') || description.contains('row')) return 3;
    if (description.contains('container') || description.contains('padding'))
      return 4;

    // Default depth for leaf widgets
    return 5;
  }

  /// Get parent widget type
  /// Note: Since WidgetTreeNode doesn't have parent property, we'll return null
  String? _getParentType(WidgetTreeNode node) {
    // Since we don't have parent reference, we can't determine parent type
    return null;
  }

  /// Get sibling count
  /// Note: Since WidgetTreeNode doesn't have parent property, we'll return 0
  int _getSiblingCount(WidgetTreeNode node) {
    // Since we don't have parent reference, we can't determine sibling count
    return 0;
  }

  /// Extract constraints information
  Map<String, dynamic> _extractConstraints(WidgetTreeNode node) {
    return {
      'hasConstraints': node.description?.contains('BoxConstraints') == true,
      'isConstrained': node.description?.contains('constrained') == true,
      'isUnconstrained': node.description?.contains('unconstrained') == true,
    };
  }

  /// Extract layout type
  String _extractLayoutType(WidgetTreeNode node) {
    final description = node.description?.toLowerCase() ?? '';

    if (description.contains('column')) return 'Column';
    if (description.contains('row')) return 'Row';
    if (description.contains('stack')) return 'Stack';
    if (description.contains('list')) return 'List';
    if (description.contains('grid')) return 'Grid';

    return 'Unknown';
  }

  /// Extract semantic label
  String? _extractSemanticLabel(WidgetTreeNode node) {
    // This would require semantic analysis
    return null;
  }

  /// Extract semantic hint
  String? _extractSemanticHint(WidgetTreeNode node) {
    // This would require semantic analysis
    return null;
  }

  /// Check if widget is accessible
  bool _isAccessible(WidgetTreeNode node) {
    final description = node.description?.toLowerCase() ?? '';
    return description.contains('semantic') ||
        description.contains('accessible') ||
        node.widgetRuntimeType?.toLowerCase().contains('button') == true ||
        node.widgetRuntimeType?.toLowerCase().contains('text') == true;
  }

  /// Extract accessibility traits
  List<String> _extractAccessibilityTraits(WidgetTreeNode node) {
    final traits = <String>[];
    final description = node.description?.toLowerCase() ?? '';

    if (description.contains('button')) traits.add('button');
    if (description.contains('text')) traits.add('text');
    if (description.contains('image')) traits.add('image');
    if (description.contains('link')) traits.add('link');

    return traits;
  }

  /// Check if widget is focusable
  bool _isFocusable(WidgetTreeNode node) {
    final description = node.description?.toLowerCase() ?? '';
    return description.contains('focus') ||
        description.contains('button') ||
        description.contains('field') ||
        description.contains('input');
  }

  /// Clean widget type by removing generic types and inspector noise
  String _cleanWidgetType(String widgetType) {
    if (widgetType.isEmpty) return 'Widget';

    // Remove generic type parameters
    String cleanType = widgetType;
    if (cleanType.contains('<')) {
      cleanType = cleanType.substring(0, cleanType.indexOf('<'));
    }

    // Remove inspector noise
    cleanType = cleanType.replaceAll(RegExp(r'inspector-\d+'), '');
    cleanType = cleanType.replaceAll(RegExp(r'dirty|depth|renderObject'), '');

    // Don't filter out meaningful widgets like Column, Scaffold, etc.
    // Only filter out truly generic layout containers
    final trulyGenericTypes = [
      'Padding',
      'Center',
      'Align',
      'Positioned',
      'Flex',
      'Wrap',
      'Flow',
    ];

    if (trulyGenericTypes.contains(cleanType)) {
      return 'CustomWidget'; // Replace only truly generic types
    }

    return cleanType.trim();
  }

  /// Generate test file name from source file path
  String _generateTestFileName(String sourceFile) {
    if (sourceFile.isEmpty) return 'widget_test.dart';

    // Extract filename from path
    final fileName = sourceFile.split('/').last;
    final baseName = fileName.replaceAll('.dart', '');

    return '${baseName}_test.dart';
  }

  /// Extract constructor signature from class definition
  String _extractConstructorSignature(
    String classDefinition,
    String widgetType,
  ) {
    if (classDefinition.isEmpty) return '$widgetType({super.key})';

    try {
      final lines = classDefinition.split('\n');
      for (final line in lines) {
        final trimmedLine = line.trim();

        // Look for constructor pattern
        if (trimmedLine.contains('$widgetType(') ||
            trimmedLine.contains('const $widgetType(')) {
          // Extract the constructor line
          final constructorMatch = RegExp(
            r'(const\s+)?$widgetType\s*\([^)]*\)',
          ).firstMatch(trimmedLine);
          if (constructorMatch != null) {
            return constructorMatch.group(0) ?? '$widgetType({super.key})';
          }
        }
      }
    } catch (e) {
      print('🔍 ❌ Error extracting constructor signature: $e');
    }

    return '$widgetType({super.key})';
  }

  /// Extract constructor parameters for test setup
  List<String> _extractConstructorParams(String constructorSignature) {
    final params = <String>[];

    try {
      // Extract parameters from constructor signature
      final paramMatch = RegExp(
        r'\(([^)]*)\)',
      ).firstMatch(constructorSignature);
      if (paramMatch != null) {
        final paramString = paramMatch.group(1) ?? '';

        // Skip super.key and empty parameters
        if (paramString.trim().isEmpty || paramString.trim() == 'super.key') {
          return params;
        }

        // Parse parameters
        final paramParts = paramString.split(',');
        for (final part in paramParts) {
          final trimmed = part.trim();
          if (trimmed.isNotEmpty && trimmed != 'super.key') {
            // Extract parameter name and provide default value
            if (trimmed.contains('required')) {
              final nameMatch = RegExp(
                r'required\s+\w+\s+(\w+)',
              ).firstMatch(trimmed);
              if (nameMatch != null) {
                final paramName = nameMatch.group(1) ?? '';
                params.add('$paramName: \'test_$paramName\'');
              }
            } else if (trimmed.contains(':')) {
              final nameMatch = RegExp(r'(\w+):').firstMatch(trimmed);
              if (nameMatch != null) {
                final paramName = nameMatch.group(1) ?? '';
                params.add('$paramName: \'test_$paramName\'');
              }
            }
          }
        }
      }
    } catch (e) {
      print('🔍 ❌ Error extracting constructor parameters: $e');
    }

    return params;
  }

  /// Extract stable identifiers from children widgets
  List<Map<String, String>> _extractStableIdentifiers(List<dynamic> children) {
    final identifiers = <Map<String, String>>[];

    try {
      for (final child in children) {
        final childMap = child as Map<String, dynamic>;
        final childType = childMap['type'] as String? ?? '';
        final childName = childMap['name'] as String? ?? '';
        final description = childMap['description'] as String? ?? '';

        // Skip generic types
        if (_isGenericType(childType)) continue;

        // Look for text content
        if (childType.toLowerCase().contains('text') &&
            description.isNotEmpty) {
          // Extract text content
          final textMatch = RegExp(r'"([^"]+)"').firstMatch(description);
          if (textMatch != null) {
            final textContent = textMatch.group(1) ?? '';
            if (textContent.isNotEmpty) {
              identifiers.add({
                'type': 'Text content',
                'identifier': 'find.text(\'$textContent\')',
              });
            }
          }
        }

        // Look for buttons
        if (childType.toLowerCase().contains('button')) {
          identifiers.add({
            'type': 'Button',
            'identifier': 'Key(\'${childName.toLowerCase()}_button_key\')',
          });
        }

        // Look for AppBar
        if (childType.toLowerCase().contains('appbar')) {
          identifiers.add({
            'type': 'AppBar',
            'identifier': 'find.byType(AppBar)',
          });
        }

        // Look for FAB
        if (childType.toLowerCase().contains('fab') ||
            description.toLowerCase().contains('floating action button')) {
          identifiers.add({'type': 'FAB', 'identifier': 'Key(\'fab_key\')'});
        }

        // Look for Column
        if (childType.toLowerCase().contains('column')) {
          identifiers.add({
            'type': 'Column',
            'identifier': 'find.byType(Column)',
          });
        }

        // Look for Row
        if (childType.toLowerCase().contains('row')) {
          identifiers.add({'type': 'Row', 'identifier': 'find.byType(Row)'});
        }

        // Look for Scaffold
        if (childType.toLowerCase().contains('scaffold')) {
          identifiers.add({
            'type': 'Scaffold',
            'identifier': 'find.byType(Scaffold)',
          });
        }

        // Look for Container
        if (childType.toLowerCase().contains('container')) {
          identifiers.add({
            'type': 'Container',
            'identifier': 'Key(\'${childName.toLowerCase()}_container_key\')',
          });
        }

        // Look for ListView
        if (childType.toLowerCase().contains('listview')) {
          identifiers.add({
            'type': 'ListView',
            'identifier': 'find.byType(ListView)',
          });
        }

        // Limit to prevent too many identifiers
        if (identifiers.length >= 4) break;
      }
    } catch (e) {
      print('🔍 ❌ Error extracting stable identifiers: $e');
    }

    return identifiers;
  }

  /// Check if widget type is generic
  bool _isGenericType(String widgetType) {
    final genericTypes = [
      'Padding',
      'Center',
      'Align',
      'Positioned',
      'Flex',
      'Wrap',
      'Flow',
      'SliverList',
      'SliverGrid',
      'SliverAppBar',
      'SliverToBoxAdapter',
      'SliverFillRemaining',
      'SliverPadding',
    ];

    return genericTypes.contains(widgetType);
  }

  /// Generate widget properties from widget information
  String _generateWidgetProperties(Map<String, dynamic> widgetInfo) {
    final properties = widgetInfo['properties'] as List<dynamic>? ?? [];
    if (properties.isEmpty) return '';

    final buffer = StringBuffer();
    final cleanWidgetType = _cleanWidgetType(
      widgetInfo['widgetType'] as String? ?? 'Widget',
    );

    // Generate properties based on widget type
    for (final prop in properties) {
      final propMap = prop as Map<String, dynamic>;
      final propName = propMap['name'] as String? ?? '';
      final propValue = propMap['value'] as String? ?? '';

      if (propName.isNotEmpty && propValue.isNotEmpty) {
        // Skip generic properties that don't add value
        if (_isInspectorNoise(propName, propValue)) continue;

        // Generate property based on widget type
        if (cleanWidgetType.toLowerCase().contains('column')) {
          if (propName == 'mainAxisAlignment') {
            buffer.writeln('        mainAxisAlignment: $propValue,');
          } else if (propName == 'crossAxisAlignment') {
            buffer.writeln('        crossAxisAlignment: $propValue,');
          } else if (propName == 'mainAxisSize') {
            buffer.writeln('        mainAxisSize: $propValue,');
          }
        } else if (cleanWidgetType.toLowerCase().contains('row')) {
          if (propName == 'mainAxisAlignment') {
            buffer.writeln('        mainAxisAlignment: $propValue,');
          } else if (propName == 'crossAxisAlignment') {
            buffer.writeln('        crossAxisAlignment: $propValue,');
          } else if (propName == 'mainAxisSize') {
            buffer.writeln('        mainAxisSize: $propValue,');
          }
        } else if (cleanWidgetType.toLowerCase().contains('scaffold')) {
          if (propName == 'backgroundColor') {
            buffer.writeln('        backgroundColor: $propValue,');
          } else if (propName == 'resizeToAvoidBottomInset') {
            buffer.writeln('        resizeToAvoidBottomInset: $propValue,');
          }
        } else if (cleanWidgetType.toLowerCase().contains('container')) {
          if (propName == 'padding') {
            buffer.writeln('        padding: $propValue,');
          } else if (propName == 'margin') {
            buffer.writeln('        margin: $propValue,');
          } else if (propName == 'decoration') {
            buffer.writeln('        decoration: $propValue,');
          }
        } else if (cleanWidgetType.toLowerCase().contains('text')) {
          if (propName == 'textAlign') {
            buffer.writeln('        textAlign: $propValue,');
          } else if (propName == 'style') {
            buffer.writeln('        style: $propValue,');
          }
        }
      }
    }

    return buffer.toString();
  }

  /// Generate widget tree code from widget information
  String _generateWidgetTreeCode(Map<String, dynamic> widgetInfo) {
    final children = widgetInfo['children'] as List<dynamic>? ?? [];
    if (children.isEmpty) return '';

    final buffer = StringBuffer();
    buffer.writeln('children: [');

    for (final child in children) {
      final childMap = child as Map<String, dynamic>;

      // Generate child widget code
      final childCode = _generateChildWidgetCode(childMap);
      buffer.writeln('          $childCode,');
    }

    buffer.writeln('        ],');
    return buffer.toString();
  }

  /// Generate individual child widget code
  String _generateChildWidgetCode(Map<String, dynamic> childInfo) {
    final childType = childInfo['type'] as String? ?? 'Widget';
    final childName = childInfo['name'] as String? ?? '';
    final childDescription = childInfo['description'] as String? ?? '';
    final childProperties = childInfo['properties'] as List<dynamic>? ?? [];
    final grandChildren = childInfo['children'] as List<dynamic>? ?? [];

    final buffer = StringBuffer();

    // Start widget constructor
    buffer.write('$childType(');

    // Add key if available
    if (childName.isNotEmpty) {
      buffer.write('key: Key(\'${childName.toLowerCase()}_key\'), ');
    }

    // Handle Text widgets specially
    if (childType.toLowerCase().contains('text')) {
      // Extract text data from description or properties
      String textData = childDescription;
      if (textData.isEmpty) {
        for (final prop in childProperties) {
          final propMap = prop as Map<String, dynamic>;
          if (propMap['name'] == 'data') {
            textData = propMap['value'] as String? ?? '';
            break;
          }
        }
      }

      if (textData.isNotEmpty) {
        // Clean up text data
        if (textData.startsWith("'") && textData.endsWith("'")) {
          buffer.write('$textData, ');
        } else {
          buffer.write("'$textData', ");
        }
      }
    }

    // Add properties
    for (final prop in childProperties) {
      final propMap = prop as Map<String, dynamic>;
      final propName = propMap['name'] as String? ?? '';
      final propValue = (propMap['value'] ?? '').toString();

      if (propName.isNotEmpty &&
          propValue.isNotEmpty &&
          !_isInspectorNoise(propName, propValue)) {
        // Handle different property types
        if (propName == 'data' && !childType.toLowerCase().contains('text')) {
          buffer.write('data: $propValue, ');
        } else if (propName == 'child' && grandChildren.isEmpty) {
          buffer.write('child: $propValue, ');
        } else if (propName == 'onPressed' &&
            childType.toLowerCase().contains('button')) {
          buffer.write('onPressed: () {}, ');
        } else if (propName == 'title' &&
            childType.toLowerCase().contains('appbar')) {
          buffer.write('title: $propValue, ');
        } else if (propName == 'icon' &&
            childType.toLowerCase().contains('icon')) {
          buffer.write('icon: $propValue, ');
        } else if (propName == 'color' &&
            !childType.toLowerCase().contains('text')) {
          buffer.write('color: $propValue, ');
        } else if (propName == 'padding') {
          buffer.write('padding: $propValue, ');
        } else if (propName == 'margin') {
          buffer.write('margin: $propValue, ');
        } else if (propName == 'alignment') {
          buffer.write('alignment: $propValue, ');
        } else if (propName == 'width') {
          buffer.write('width: $propValue, ');
        } else if (propName == 'height') {
          buffer.write('height: $propValue, ');
        }
      }
    }

    // Add children if available
    if (grandChildren.isNotEmpty) {
      buffer.write('children: [');
      for (int i = 0; i < grandChildren.length; i++) {
        final grandChild = grandChildren[i];
        final grandChildMap = grandChild as Map<String, dynamic>;
        final grandChildType = grandChildMap['type'] as String? ?? 'Widget';
        final grandChildDescription =
            grandChildMap['description'] as String? ?? '';

        if (grandChildType.toLowerCase().contains('text')) {
          if (grandChildDescription.isNotEmpty) {
            buffer.write('$grandChildType(\'$grandChildDescription\')');
          } else {
            buffer.write('$grandChildType(\'Text\')');
          }
        } else {
          buffer.write('$grandChildType()');
        }

        if (i < grandChildren.length - 1) {
          buffer.write(', ');
        }
      }
      buffer.write('], ');
    }

    // Close widget constructor
    buffer.write(')');

    return buffer.toString();
  }

  /// Infer property type from value
  String _inferPropertyType(String value) {
    if (value.startsWith("'") && value.endsWith("'")) {
      return 'String';
    } else if (value == 'true' || value == 'false') {
      return 'bool';
    } else if (RegExp(r'^\d+$').hasMatch(value)) {
      return 'int';
    } else if (RegExp(r'^\d+\.\d+$').hasMatch(value)) {
      return 'double';
    } else if (value.startsWith('Color(') || value.startsWith('Colors.')) {
      return 'Color';
    } else if (value.startsWith('EdgeInsets(')) {
      return 'EdgeInsets';
    } else if (value.contains('(') && value.contains(')')) {
      return 'Function';
    }
    return 'dynamic';
  }
}
