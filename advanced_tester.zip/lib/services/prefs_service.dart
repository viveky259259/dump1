import 'package:shared_preferences/shared_preferences.dart';
import '../core/logging/logging.dart';

class PrefsService with LoggerMixin {
  static const String keyLastProjectPath = 'last_project_path';
  static const String keyLastFlutterSdkPath = 'last_flutter_sdk_path';

  Future<void> saveLastProjectPath(String path) async {
    return await logAsyncOperation('saveLastProjectPath', () async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(keyLastProjectPath, path);
      logger.debug('Saved last project path', {'path': path});
    }, context: {'path': path});
  }

  Future<String?> getLastProjectPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyLastProjectPath);
  }

  Future<void> saveLastFlutterSdkPath(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyLastFlutterSdkPath, path);
  }

  Future<String?> getLastFlutterSdkPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyLastFlutterSdkPath);
  }
}
