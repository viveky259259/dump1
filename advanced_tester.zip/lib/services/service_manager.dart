import 'dart:async';
import 'package:flutter/foundation.dart';
import 'inspector_service.dart';
import 'enhanced_dependency_analysis_service.dart';
import 'source_code_analyzer.dart';
import 'dependency_analysis_service.dart';
import 'ai_test_generation_service.dart';
import '../core/config/environment_service.dart';
import '../core/logging/logging.dart';

/// Central service manager that coordinates all testing services
class ServiceManager with LoggerMixin {
  InspectorService? _inspectorService;
  EnhancedDependencyAnalysisService? _dependencyAnalysisService;
  SourceCodeAnalyzer? _sourceCodeAnalyzer;
  AITestGenerationService? _aiTestGenerationService;

  // Service state management
  final Map<String, ServiceState> _serviceStates = {};
  StreamController<ServiceManagerEvent> _eventController =
      StreamController<ServiceManagerEvent>.broadcast();

  // Configuration
  final ServiceManagerConfig config;

  ServiceManager({this.config = const ServiceManagerConfig()}) {
    logger.info('ServiceManager initialized', {'config': config.toString()});
  }

  Stream<ServiceManagerEvent> get eventStream => _eventController.stream;

  void _emitEvent(ServiceManagerEvent event) {
    if (!_eventController.isClosed) {
      _eventController.add(event);
    }
  }

  void _log(String message, {String? level}) {
    if (config.enableLogging && kDebugMode) {
      final timestamp = DateTime.now().toIso8601String();
      final prefix = level != null ? '[$level]' : '[INFO]';
      print('$prefix [$timestamp] ServiceManager: $message');
    }
  }

  void _logError(String message, [Object? error, StackTrace? stackTrace]) {
    _log(message, level: 'ERROR');
    if (error != null) {
      _log('Error details: $error', level: 'ERROR');
    }
    if (stackTrace != null) {
      _log('Stack trace: $stackTrace', level: 'ERROR');
    }
  }

  void _updateServiceState(String serviceName, ServiceState state) {
    _serviceStates[serviceName] = state;
    _emitEvent(ServiceStateChangedEvent(serviceName, state));
  }

  /// Initialize all services
  Future<void> initializeServices(Uri vmServiceUri) async {
    _log('Initializing services');

    try {
      // Initialize InspectorService
      _updateServiceState('InspectorService', ServiceState.initializing);
      _inspectorService = InspectorService(
        vmServiceUri,
        config: InspectorConfig(
          connectionTimeout: config.connectionTimeout,
          requestTimeout: config.requestTimeout,
          maxRetries: config.maxRetries,
          enableLogging: config.enableLogging,
        ),
      );

      await _inspectorService!.connect();
      _updateServiceState('InspectorService', ServiceState.ready);
      _log('InspectorService initialized successfully');

      // Initialize DependencyAnalysisService
      _updateServiceState(
        'DependencyAnalysisService',
        ServiceState.initializing,
      );
      _dependencyAnalysisService = EnhancedDependencyAnalysisService(
        _inspectorService!,
      );
      _updateServiceState('DependencyAnalysisService', ServiceState.ready);
      _log('DependencyAnalysisService initialized successfully');

      // Initialize SourceCodeAnalyzer
      _updateServiceState('SourceCodeAnalyzer', ServiceState.initializing);
      _sourceCodeAnalyzer = SourceCodeAnalyzer();
      _updateServiceState('SourceCodeAnalyzer', ServiceState.ready);
      _log('SourceCodeAnalyzer initialized successfully');

      // Initialize AITestGenerationService
      _updateServiceState('AITestGenerationService', ServiceState.initializing);
      _aiTestGenerationService = AITestGenerationService(
        projectPath: config.projectPath,
        apiKey: config.openAIApiKey,
        environmentService: config.environmentService,
        inspectorService: _inspectorService,
        dependencyService:
            null, // EnhancedDependencyAnalysisService doesn't expose dependencyService
        enhancedDependencyService: _dependencyAnalysisService,
      );
      _updateServiceState('AITestGenerationService', ServiceState.ready);
      _log('AITestGenerationService initialized successfully');

      _emitEvent(AllServicesReadyEvent());
      _log('All services initialized successfully');
    } catch (e, stackTrace) {
      _logError('Failed to initialize services', e, stackTrace);
      _emitEvent(ServiceInitializationFailedEvent(e));
      rethrow;
    }
  }

  /// Get the InspectorService
  InspectorService? get inspectorService => _inspectorService;

  /// Get the DependencyAnalysisService
  EnhancedDependencyAnalysisService? get dependencyAnalysisService =>
      _dependencyAnalysisService;

  /// Get the SourceCodeAnalyzer
  SourceCodeAnalyzer? get sourceCodeAnalyzer => _sourceCodeAnalyzer;

  /// Get the AITestGenerationService
  AITestGenerationService? get aiTestGenerationService =>
      _aiTestGenerationService;

  /// Check if all services are ready
  bool get allServicesReady {
    return _serviceStates.values.every((state) => state == ServiceState.ready);
  }

  /// Get the state of a specific service
  ServiceState? getServiceState(String serviceName) =>
      _serviceStates[serviceName];

  /// Get all service states
  Map<String, ServiceState> getAllServiceStates() => Map.from(_serviceStates);

  /// Perform comprehensive widget analysis
  Future<ComprehensiveAnalysisResult> analyzeWidget(
    WidgetTreeNode widget, {
    bool includeDependencies = true,
    bool includeSourceCode = true,
    bool includeProperties = true,
  }) async {
    if (!allServicesReady) {
      throw StateError('Services not ready');
    }

    _log('Starting comprehensive analysis for ${widget.displayName}');
    final startTime = DateTime.now();

    try {
      final result = ComprehensiveAnalysisResult(
        widget: widget,
        analysisTime: Duration.zero, // Will be updated
        dependencies: [],
        sourceCode: null,
        properties: [],
        metadata: {},
      );

      // Analyze dependencies
      if (includeDependencies && _dependencyAnalysisService != null) {
        _log('Analyzing dependencies');
        final dependencyResult = await _dependencyAnalysisService!
            .analyzeWidgetDependencies(widget);
        result.dependencies = dependencyResult.dependencies;
        result.metadata['dependencyAnalysis'] = dependencyResult.metadata;
      }

      // Analyze source code
      if (includeSourceCode &&
          widget.objectId != null &&
          _inspectorService != null) {
        _log('Analyzing source code');
        final sourceLocation = await _inspectorService!.getWidgetSourceLocation(
          widget.objectId!,
        );
        if (sourceLocation != null) {
          result.sourceCode = await _inspectorService!.getWidgetSourceCode(
            sourceLocation,
          );
          result.metadata['sourceLocation'] = {
            'file': sourceLocation.file,
            'line': sourceLocation.line,
            'column': sourceLocation.column,
          };
        }
      }

      // Analyze properties
      if (includeProperties &&
          widget.objectId != null &&
          _inspectorService != null) {
        _log('Analyzing properties');
        result.properties = await _inspectorService!.getWidgetProperties(
          widget.objectId!,
          widget.widgetRuntimeType,
        );
      }

      result.analysisTime = DateTime.now().difference(startTime);
      _log(
        'Comprehensive analysis completed in ${result.analysisTime.inMilliseconds}ms',
      );

      return result;
    } catch (e, stackTrace) {
      _logError('Comprehensive analysis failed', e, stackTrace);
      rethrow;
    }
  }

  /// Generate test setup code for a widget
  Future<String> generateTestSetupCode(WidgetTreeNode widget) async {
    if (!allServicesReady) {
      throw StateError('Services not ready');
    }

    _log('Generating test setup code for ${widget.displayName}');

    try {
      final buffer = StringBuffer();

      // Add imports
      buffer.writeln("import 'package:flutter/material.dart';");
      buffer.writeln("import 'package:flutter_test/flutter_test.dart';");
      buffer.writeln();

      // Analyze dependencies
      if (_dependencyAnalysisService != null) {
        final dependencyResult = await _dependencyAnalysisService!
            .analyzeWidgetDependencies(widget);

        // Add provider imports
        final hasProviders = dependencyResult.dependencies.any(
          (d) => d.category == DependencyCategory.provider,
        );
        if (hasProviders) {
          buffer.writeln("import 'package:provider/provider.dart';");
          buffer.writeln();
        }

        // Generate setup code
        buffer.writeln('void main() {');
        buffer.writeln('  group(\'${widget.displayName} Tests\', () {');
        buffer.writeln(
          '    testWidgets(\'should render correctly\', (WidgetTester tester) async {',
        );
        buffer.writeln('      // Arrange');

        // Add dependency setup
        for (final dependency in dependencyResult.dependencies) {
          buffer.writeln('      // Setup ${dependency.type}');
          buffer.writeln('      ${dependency.setupCode}');
          buffer.writeln();
        }

        // Add widget under test
        buffer.writeln('      // Act');
        buffer.writeln('      await tester.pumpWidget(');
        buffer.writeln('        MaterialApp(');
        buffer.writeln('          home: ${widget.displayName}(),');
        buffer.writeln('        ),');
        buffer.writeln('      );');
        buffer.writeln();

        buffer.writeln('      // Assert');
        buffer.writeln(
          '      expect(find.byType(${widget.displayName}), findsOneWidget);',
        );
        buffer.writeln('    });');
        buffer.writeln('  });');
        buffer.writeln('}');
      }

      final setupCode = buffer.toString();
      _log('Generated test setup code: ${setupCode.length} characters');

      return setupCode;
    } catch (e, stackTrace) {
      _logError('Failed to generate test setup code', e, stackTrace);
      rethrow;
    }
  }

  /// Generate AI-powered test file for a widget
  Future<bool> generateAITestForWidget(WidgetTreeNode widget) async {
    if (!allServicesReady) {
      throw StateError('Services not ready');
    }

    if (_aiTestGenerationService == null) {
      throw StateError('AI Test Generation Service not available');
    }

    _log('Generating AI test for ${widget.displayName}');

    try {
      final success = await _aiTestGenerationService!.generateTestForWidget(
        widget,
      );

      if (success) {
        _log('AI test generated successfully for ${widget.displayName}');
      } else {
        _log('Failed to generate AI test for ${widget.displayName}');
      }

      return success;
    } catch (e, stackTrace) {
      _logError('Failed to generate AI test', e, stackTrace);
      return false;
    }
  }

  /// Get service health status
  Map<String, ServiceHealth> getServiceHealth() {
    final health = <String, ServiceHealth>{};

    for (final entry in _serviceStates.entries) {
      final serviceName = entry.key;
      final state = entry.value;

      health[serviceName] = ServiceHealth(
        name: serviceName,
        state: state,
        isHealthy: state == ServiceState.ready,
        lastCheck: DateTime.now(),
      );
    }

    return health;
  }

  /// Dispose all services
  void dispose() {
    _log('Disposing services');

    _inspectorService?.dispose();
    _dependencyAnalysisService?.dispose();

    _inspectorService = null;
    _dependencyAnalysisService = null;
    _sourceCodeAnalyzer = null;

    _serviceStates.clear();

    if (!_eventController.isClosed) {
      _eventController.close();
    }

    _log('All services disposed');
  }
}

/// Configuration for ServiceManager
class ServiceManagerConfig {
  final Duration connectionTimeout;
  final Duration requestTimeout;
  final int maxRetries;
  final bool enableLogging;
  final bool enableCaching;
  final String? projectPath;
  final String? openAIApiKey;
  final EnvironmentService? environmentService;

  const ServiceManagerConfig({
    this.connectionTimeout = const Duration(seconds: 30),
    this.requestTimeout = const Duration(seconds: 10),
    this.maxRetries = 3,
    this.enableLogging = true,
    this.enableCaching = true,
    this.projectPath,
    this.openAIApiKey =
        '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',
    this.environmentService,
  });
}

/// Service states
enum ServiceState { uninitialized, initializing, ready, error, disposed }

/// Service health information
class ServiceHealth {
  final String name;
  final ServiceState state;
  final bool isHealthy;
  final DateTime lastCheck;

  ServiceHealth({
    required this.name,
    required this.state,
    required this.isHealthy,
    required this.lastCheck,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'state': state.toString(),
    'isHealthy': isHealthy,
    'lastCheck': lastCheck.toIso8601String(),
  };
}

/// Comprehensive analysis result
class ComprehensiveAnalysisResult {
  final WidgetTreeNode widget;
  Duration analysisTime;
  List<WidgetDependency> dependencies;
  String? sourceCode;
  List<WidgetAttribute> properties;
  final Map<String, dynamic> metadata;

  ComprehensiveAnalysisResult({
    required this.widget,
    required this.analysisTime,
    required this.dependencies,
    required this.sourceCode,
    required this.properties,
    required this.metadata,
  });

  Map<String, dynamic> toJson() => {
    'widget': {
      'displayName': widget.displayName,
      'type': widget.widgetRuntimeType,
      'objectId': widget.objectId,
    },
    'analysisTime': analysisTime.inMilliseconds,
    'dependencies': dependencies
        .map(
          (d) => {
            'type': d.type,
            'category': d.category,
            'description': d.description,
            'setupCode': d.setupCode,
            'distanceFromTarget': d.distanceFromTarget,
          },
        )
        .toList(),
    'sourceCode': sourceCode,
    'properties': properties
        .map(
          (p) => {
            'name': p.name,
            'label': p.label,
            'type': p.type,
            'value': p.value,
          },
        )
        .toList(),
    'metadata': metadata,
  };
}

/// Events emitted by ServiceManager
abstract class ServiceManagerEvent {}

class ServiceStateChangedEvent extends ServiceManagerEvent {
  final String serviceName;
  final ServiceState state;
  ServiceStateChangedEvent(this.serviceName, this.state);
}

class AllServicesReadyEvent extends ServiceManagerEvent {}

class ServiceInitializationFailedEvent extends ServiceManagerEvent {
  final Object error;
  ServiceInitializationFailedEvent(this.error);
}
