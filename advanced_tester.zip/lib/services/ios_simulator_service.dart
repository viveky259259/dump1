import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';

import '../core/logging/logging.dart';

/// Represents an iOS simulator returned by `xcrun simctl list`.
class IOSSimulatorDevice {
  final String name;
  final String udid;
  final String runtime;
  final bool isAvailable;
  final String state;

  const IOSSimulatorDevice({
    required this.name,
    required this.udid,
    required this.runtime,
    required this.isAvailable,
    required this.state,
  });

  bool get isBooted => state.toLowerCase() == 'booted';

  IOSSimulatorDevice copyWith({String? state, bool? isAvailable}) {
    return IOSSimulatorDevice(
      name: name,
      udid: udid,
      runtime: runtime,
      isAvailable: isAvailable ?? this.isAvailable,
      state: state ?? this.state,
    );
  }

  @override
  String toString() => '$name ($runtime) - $state';
}

/// Service that manages iOS simulators by shelling out to `xcrun simctl`.
///
/// The implementation mirrors the flow described in
/// `docs/simulator_browser_viewer_architecture.md`: discover devices via
/// `simctl list --json`, boot them when needed, and continuously fetch
/// screenshots for browser/desktop previews.
class IOSSimulatorService with LoggerMixin {
  static const _simctl = 'xcrun';
  static const _defaultScreenshotInterval = Duration(milliseconds: 300);

  /// Returns all available iOS simulators (booted + shutdown).
  Future<List<IOSSimulatorDevice>> listSimulators() async {
    try {
      final result = await Process.run(
        _simctl,
        ['simctl', 'list', '--json'],
        stdoutEncoding: utf8,
      );

      if (result.exitCode != 0) {
        throw ProcessException(
          _simctl,
          ['simctl', 'list', '--json'],
          result.stderr?.toString()??'',
          result.exitCode,
        );
      }

      final decoded = json.decode(result.stdout as String) as Map<String, dynamic>;
      final devicesJson = decoded['devices'] as Map<String, dynamic>? ?? {};
      final devices = <IOSSimulatorDevice>[];

      for (final entry in devicesJson.entries) {
        final runtime = entry.key;
        if (!runtime.toLowerCase().contains('ios')) continue;
        final sims = entry.value as List<dynamic>? ?? [];

        for (final sim in sims) {
          final simMap = sim as Map<String, dynamic>;
          final device = IOSSimulatorDevice(
            name: simMap['name'] as String? ?? 'Unknown Simulator',
            udid: simMap['udid'] as String? ?? '',
            runtime: runtime,
            isAvailable: simMap['isAvailable'] as bool? ?? false,
            state: simMap['state'] as String? ?? 'Shutdown',
          );
          if (device.udid.isNotEmpty) {
            devices.add(device);
          }
        }
      }

      devices.sort((a, b) {
        if (a.isBooted == b.isBooted) {
          return a.name.compareTo(b.name);
        }
        return a.isBooted ? -1 : 1;
      });

      return devices;
    } catch (e) {
      logger.error('Failed to list iOS simulators', e);
      rethrow;
    }
  }

  /// Returns the boot state for the simulator with [udid].
  Future<String?> _getSimulatorState(String udid) async {
    try {
      final simulators = await listSimulators();
      return simulators.firstWhere((sim) => sim.udid == udid).state;
    } catch (_) {
      return null;
    }
  }

  /// Boots a simulator if it is not already running.
  Future<void> bootSimulator(String udid, {Duration timeout = const Duration(seconds: 60)}) async {
    final currentState = await _getSimulatorState(udid);
    if (currentState?.toLowerCase() == 'booted') {
      return;
    }

    logger.info('Booting iOS simulator', {'udid': udid});

    final result = await Process.run(
      _simctl,
      ['simctl', 'boot', udid],
      stdoutEncoding: utf8,
      stderrEncoding: utf8,
    );

    if (result.exitCode != 0) {
      throw ProcessException(
        _simctl,
        ['simctl', 'boot', udid],
        result.stderr?.toString() ??'',
        result.exitCode,
      );
    }

    await _awaitSimulatorBoot(udid, timeout);

    // Ensure the Simulator app is focused on the correct device.
    await Process.run('open', [
      '-a',
      'Simulator',
      '--args',
      '-CurrentDeviceUDID',
      udid,
    ]);
  }

  Future<void> _awaitSimulatorBoot(String udid, Duration timeout) async {
    final sw = Stopwatch()..start();
    while (sw.elapsed < timeout) {
      final state = await _getSimulatorState(udid);
      if (state?.toLowerCase() == 'booted') {
        logger.info('Simulator booted', {'udid': udid});
        return;
      }
      await Future.delayed(const Duration(milliseconds: 500));
    }

    throw TimeoutException('Simulator $udid failed to boot within ${timeout.inSeconds}s');
  }

  /// Captures a raw screenshot for [udid] and returns PNG bytes.
  Future<Uint8List> captureScreenshot(String udid) async {
    final result = await Process.run(
      _simctl,
      ['simctl', 'io', udid, 'screenshot', '-'],
      stdoutEncoding: null, // raw bytes
      stderrEncoding: utf8,
    );

    if (result.exitCode != 0) {
      throw ProcessException(
        _simctl,
        ['simctl', 'io', udid, 'screenshot', '-'],
        result.stderr?.toString() ?? '',
        result.exitCode,
      );
    }

    final stdoutBytes = result.stdout;
    if (stdoutBytes is List<int>) {
      return Uint8List.fromList(stdoutBytes);
    }
    throw const FormatException('Unexpected screenshot output type');
  }

  /// Continuously emits screenshots for [udid] at [interval], throttling to the
  /// capture time so we don't pile up overlapping simctl calls.
  Stream<Uint8List> startScreenshotStream(
    String udid, {
    Duration interval = _defaultScreenshotInterval,
  }) {
    final controller = StreamController<Uint8List>.broadcast();
    var isCancelled = false;

    Future<void> captureLoop() async {
      while (!isCancelled) {
        final start = DateTime.now();
        try {
          final bytes = await captureScreenshot(udid);
          if (!controller.isClosed) {
            controller.add(bytes);
          }
        } catch (e, stack) {
          logger.error('Failed to capture screenshot: $e', stack);
          if (!controller.isClosed) {
            controller.addError(e, stack);
          }
        }

        final elapsed = DateTime.now().difference(start);
        final delay = interval - elapsed;
        if (delay > Duration.zero) {
          await Future.delayed(delay);
        }
      }
    }

    controller
      ..onListen = () {
        if (!isCancelled) {
          captureLoop();
        }
      }
      ..onCancel = () {
        isCancelled = true;
      };

    return controller.stream;
  }

  Future<void> sendTapGesture(
    String udid,
    Offset normalized, {
    bool doubleTap = false,
  }) async {
    final bounds = await _getSimulatorWindowBounds();
    if (bounds == null) return;

    final target = _mapNormalizedToWindow(normalized, bounds);
    logger.debug('Sending tap', {
      'udid': udid,
      'normalized': {'x': normalized.dx, 'y': normalized.dy},
      'absolute': {'x': target.dx, 'y': target.dy},
      'doubleTap': doubleTap,
    });

    final script = '''
const simulator = Application('Simulator');
simulator.activate();
ObjC.import('ApplicationServices');
function clickAt(x, y) {
  var point = \$.CGPointMake(x, y);
  var down = \$.CGEventCreateMouseEvent(null, \$.kCGEventLeftMouseDown, point, \$.kCGMouseButtonLeft);
  \$.CGEventPost(\$.kCGHIDEventTap, down);
  var up = \$.CGEventCreateMouseEvent(null, \$.kCGEventLeftMouseUp, point, \$.kCGMouseButtonLeft);
  \$.CGEventPost(\$.kCGHIDEventTap, up);
}
clickAt(${target.dx.toStringAsFixed(2)}, ${target.dy.toStringAsFixed(2)});
${doubleTap ? "ObjC.import('Foundation'); \$.usleep(80000); clickAt(${target.dx.toStringAsFixed(2)}, ${target.dy.toStringAsFixed(2)});" : ''}
''';

    await _runJxa(script);
  }

  Future<void> sendDragGesture(
    String udid,
    Offset startNormalized,
    Offset endNormalized,
  ) async {
    final bounds = await _getSimulatorWindowBounds();
    if (bounds == null) return;

    final start = _mapNormalizedToWindow(startNormalized, bounds);
    final end = _mapNormalizedToWindow(endNormalized, bounds);
    logger.debug('Sending drag', {
      'udid': udid,
      'start': {'normalized': startNormalized.toString(), 'absolute': start.toString()},
      'end': {'normalized': endNormalized.toString(), 'absolute': end.toString()},
    });

    final script = '''
const simulator = Application('Simulator');
simulator.activate();
ObjC.import('ApplicationServices');
function drag(fromX, fromY, toX, toY) {
  var start = \$.CGPointMake(fromX, fromY);
  var end = \$.CGPointMake(toX, toY);
  var down = \$.CGEventCreateMouseEvent(null, \$.kCGEventLeftMouseDown, start, \$.kCGMouseButtonLeft);
  \$.CGEventPost(\$.kCGHIDEventTap, down);
  var drag = \$.CGEventCreateMouseEvent(null, \$.kCGEventLeftMouseDragged, end, \$.kCGMouseButtonLeft);
  \$.CGEventPost(\$.kCGHIDEventTap, drag);
  var up = \$.CGEventCreateMouseEvent(null, \$.kCGEventLeftMouseUp, end, \$.kCGMouseButtonLeft);
  \$.CGEventPost(\$.kCGHIDEventTap, up);
}
drag(${start.dx.toStringAsFixed(2)}, ${start.dy.toStringAsFixed(2)}, ${end.dx.toStringAsFixed(2)}, ${end.dy.toStringAsFixed(2)});
''';

    await _runJxa(script);
  }

  Future<Rect?> _getSimulatorWindowBounds() async {
    final script = '''
const simulator = Application('Simulator');
simulator.activate();
const systemEvents = Application('System Events');
const proc = systemEvents.processes.byName('Simulator');
if (!proc.exists() || proc.windows.length === 0) {
  '';
} else {
  const win = proc.windows[0];
  const pos = win.position();
  const size = win.size();
  pos[0] + ',' + pos[1] + ',' + size[0] + ',' + size[1];
}
''';

    try {
      final result = await Process.run(
        'osascript',
        ['-l', 'JavaScript', '-e', script],
      );
      if (result.exitCode != 0) {
        logger.warn(
          'Failed to get simulator bounds',
          {'stderr': result.stderr},
        );
        return null;
      }

      final output = (result.stdout as String).trim();
      if (output.isEmpty) return null;

      final parts = output.split(',');
      if (parts.length != 4) return null;

      final values = parts.map((p) => double.tryParse(p.trim())).toList();
      if (values.contains(null)) return null;

      return Rect.fromLTWH(
        values[0]!,
        values[1]!,
        values[2]!,
        values[3]!,
      );
    } catch (e, stack) {
      logger.error('Error retrieving simulator bounds', e, stack);
      return null;
    }
  }

  Offset _mapNormalizedToWindow(Offset normalized, Rect bounds) {
    final clampedX = normalized.dx.clamp(0.0, 1.0);
    final clampedY = normalized.dy.clamp(0.0, 1.0);

    final x = bounds.left + bounds.width * clampedX;
    final y = bounds.top + bounds.height * clampedY;

    return Offset(x, y);
  }

  Future<void> _runJxa(String script) async {
    final result = await Process.run(
      'osascript',
      ['-l', 'JavaScript', '-e', script],
    );

    if (result.exitCode != 0) {
      logger.warn(
        'JXA command failed',
        {'stderr': result.stderr, 'stdout': result.stdout},
      );
    }
  }
}
