import '../presentation/providers/app_provider.dart';
import '../core/logging/logging.dart';
import 'run_service.dart';
import 'inspector_service.dart';

class AppRunner with LoggerMixin {
  static Future<void> run(AppProvider appProvider) async {
    final runner = AppRunner();
    await runner._runImpl(appProvider);
  }

  Future<void> _runImpl(AppProvider appProvider) async {
    if (appProvider.isRunning || appProvider.selectedProjectPath == null) {
      logger.warn('Cannot start app - already running or no project selected');
      return;
    }

    final selectedDevice = appProvider.selectedDevice;
    final isWebDevice = _isWeb(selectedDevice.platform, selectedDevice.deviceId);
    final isIosDevice = _isIos(selectedDevice.platform, selectedDevice.name);

    logger.info('Starting Flutter app', {
      'projectPath': appProvider.selectedProjectPath,
      'device': selectedDevice.deviceId,
      'platform': selectedDevice.platform,
    });

    final runService = RunService();
    final result = await runService.startFlutterApp(
      projectPath: appProvider.selectedProjectPath!,
      flutterSdkDir:
          appProvider.flutterSdkDir ?? '/Users/vivekyadav/fvm/versions/stable/',
      deviceId: selectedDevice.deviceId,
    );

    appProvider.setFlutterProcess(result.process);
    appProvider.setIsRunning(true);
    appProvider.setRunningUrl(null);

    if (isIosDevice) {
      appProvider.startIosPreview();
    } else {
      appProvider.stopIosPreview();
    }

    final sub = result.logStream.stream.listen((chunk) {
      print(chunk);

      // Determine log type based on content
      String logType = 'log';
      final trimmedChunk = chunk.trim();

      if (trimmedChunk.toLowerCase().contains('error') ||
          trimmedChunk.toLowerCase().contains('exception')) {
        logType = 'error';
      } else if (trimmedChunk.toLowerCase().contains('warning') ||
          trimmedChunk.toLowerCase().contains('warn')) {
        logType = 'warning';
      } else if (trimmedChunk.toLowerCase().contains('vm service') ||
          trimmedChunk.toLowerCase().contains('listening on')) {
        logType = 'info';
      }

      // Add Flutter process logs to console messages
      appProvider.addConsoleMessage(trimmedChunk, type: logType);

      final wsMatch = RegExp(
        r'(ws://[^\s]+)',
        caseSensitive: false,
      ).firstMatch(chunk);
      if (wsMatch != null) {
        final uriStr = wsMatch.group(1)!;
        try {
          final vmUri = Uri.parse(uriStr);
          appProvider.setVmServiceUri(vmUri);

          if (appProvider.inspectorService == null) {
            (() async {
              await Future.delayed(const Duration(seconds: 3));

              for (int attempt = 1; attempt <= 5; attempt++) {
                try {
                  print('Inspector connection attempt $attempt/5 to $vmUri');
                  final insp = InspectorService(vmUri);
                  await insp.connect();
                  print('set inspector service to $insp');
                  appProvider.setInspectorService(insp);
                  print('Inspector service successfully connected to $vmUri');
                  return;
                } catch (e) {
                  print('Inspector connection attempt $attempt failed: $e');
                  if (attempt < 5) {
                    await Future.delayed(Duration(seconds: attempt * 2));
                  }
                }
              }
              print('All inspector connection attempts failed');
            })();
          }
        } catch (_) {}
      }

      if (isWebDevice) {
        final webAppMatch = RegExp(
          r'Flutter web app is served at (https?://[^\s]+)',
          caseSensitive: false,
        ).firstMatch(chunk);
        if (webAppMatch != null) {
          final webUrl = webAppMatch.group(1)!;
          appProvider.setRunningUrl(webUrl);
          print('Set running URL to: $webUrl');
        }

        final genericUrlMatch = RegExp(
          r'(https?://localhost:\d+)',
          caseSensitive: false,
        ).firstMatch(chunk);
        if (genericUrlMatch != null && appProvider.runningUrl == null) {
          final url = genericUrlMatch.group(1)!;
          appProvider.setRunningUrl(url);
          print('Set fallback running URL to: $url');
        }
      }

      if (chunk.contains('flutter: Application finished.')) {
        _handleAppFinished(appProvider);
      }
    });

    appProvider.setRunLogSubscription(sub);

    if (result.vmServiceUri != null) {
      try {
        print('set inspector service to ${result.vmServiceUri}');
        final insp = InspectorService(result.vmServiceUri!);
        await insp.connect();
        print('set inspector service to $insp');
        appProvider.setInspectorService(insp);
        print('Inspector service connected successfully');
      } catch (e) {
        print('Failed to connect inspector service: $e');
      }
    }
  }

  static bool _isWeb(String platform, String deviceId) {
    final normalized = platform.toLowerCase();
    return normalized.contains('web') || deviceId.toLowerCase() == 'chrome';
  }

  static bool _isIos(String platform, String name) {
    final normalizedPlatform = platform.toLowerCase();
    final normalizedName = name.toLowerCase();
    return normalizedPlatform.contains('ios') ||
        normalizedName.contains('iphone') ||
        normalizedName.contains('ios');
  }

  static void _handleAppFinished(AppProvider appProvider) {
    appProvider.clearRunningProjectData();
    appProvider.stopIosPreview();
    print('Cleared all running project data');
  }
}
