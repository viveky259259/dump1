import 'dart:io';
import 'inspector_service.dart';
import '../core/logging/logging.dart';

/// Service for generating test files for widgets
class TestGenerationService with LoggerMixin {
  final String? projectPath;

  TestGenerationService({this.projectPath}) {
    logger.info('TestGenerationService initialized', {
      'projectPath': projectPath,
    });
  }

  /// Generate a test file for a widget based on its location and properties
  Future<bool> generateTestForWidget(WidgetTreeNode node) async {
    return await logAsyncOperation(
      'generateTestForWidget',
      () async => _generateTestForWidgetImpl(node),
      context: {'widgetType': node.type, 'objectId': node.objectId},
    );
  }

  Future<bool> _generateTestForWidgetImpl(WidgetTreeNode node) async {
    try {
      logger.info('Generating test for widget', {'type': node.type});
      // Get the creation location
      final creationLocation = node.creationLocation;
      if (creationLocation == null) {
        throw Exception('No creation location found for widget');
      }

      // Extract file path and convert to test path
      final sourceFilePath = creationLocation.file;
      final testFilePath = convertToTestPath(sourceFilePath);

      // Create test directory if it doesn't exist
      final testDir = Directory(testFilePath).parent;
      if (!await testDir.exists()) {
        await testDir.create(recursive: true);
      }

      // Generate test content
      final testContent = await _generateTestContent(node, creationLocation);

      // Write test file
      final testFile = File(testFilePath);
      await testFile.writeAsString(testContent);

      logger.info('Test file generated successfully', {'path': testFilePath});
      return true;
    } catch (e, stackTrace) {
      logger.error('Error generating test', e, stackTrace, {
        'widgetType': node.type,
      });
      return false;
    }
  }

  /// Convert source file path to test file path
  String convertToTestPath(String sourcePath) {
    // Handle file:// URLs (absolute paths)
    if (sourcePath.startsWith('file://')) {
      // Remove file:// prefix
      final cleanPath = sourcePath.substring(7);

      // Find the lib/ directory in the path
      final libIndex = cleanPath.indexOf('/lib/');
      if (libIndex != -1) {
        // Extract the project root and the relative path from lib/
        final projectRoot = cleanPath.substring(0, libIndex);
        final relativePath = cleanPath.substring(
          libIndex + 5,
        ); // +5 for '/lib/'

        // Convert to test path
        final testPath = '$projectRoot/test/$relativePath';
        return testPath.replaceAll('.dart', '_test.dart');
      }

      // If no lib/ found, try to extract filename and create in test directory
      final fileName = cleanPath
          .split('/')
          .last
          .replaceAll('.dart', '_test.dart');
      final projectRoot = cleanPath.substring(0, cleanPath.lastIndexOf('/'));
      return '$projectRoot/test/$fileName';
    }

    // Handle relative paths starting with lib/
    if (sourcePath.startsWith('lib/')) {
      return sourcePath
          .replaceFirst('lib/', 'test/')
          .replaceAll('.dart', '_test.dart');
    }

    // Handle absolute paths containing /lib/
    if (sourcePath.contains('/lib/')) {
      final parts = sourcePath.split('/lib/');
      if (parts.length > 1) {
        final projectRoot = parts[0];
        final relativePath = parts[1];
        return '$projectRoot/test/$relativePath'.replaceAll(
          '.dart',
          '_test.dart',
        );
      }
    }

    // Fallback: create test in test directory
    final fileName = sourcePath
        .split('/')
        .last
        .replaceAll('.dart', '_test.dart');
    return 'test/$fileName';
  }

  /// Generate test content for the widget
  Future<String> _generateTestContent(
    WidgetTreeNode node,
    CreationLocation location,
  ) async {
    final widgetType = node.widgetRuntimeType ?? node.description ?? 'Widget';
    final widgetName = extractWidgetName(widgetType);

    // Get widget properties
    final properties = await _extractWidgetProperties(node);

    // Generate test content
    final buffer = StringBuffer();

    // Add imports
    buffer.writeln("import 'package:flutter/material.dart';");
    buffer.writeln("import 'package:flutter_test/flutter_test.dart';");

    // Generate import path based on file location
    final importPath = generateImportPath(location.file);
    buffer.writeln("import '$importPath';");
    buffer.writeln();

    // Add main test group
    buffer.writeln('void main() {');
    buffer.writeln('  group(\'$widgetName Tests\', () {');
    buffer.writeln();

    // Add basic widget test
    buffer.writeln(
      '    testWidgets(\'should render $widgetName correctly\', (WidgetTester tester) async {',
    );
    buffer.writeln('      // Arrange');
    buffer.writeln('      await tester.pumpWidget(');
    buffer.writeln('        MaterialApp(');
    buffer.writeln('          home: $widgetName(');

    // Add widget properties
    for (final property in properties) {
      buffer.writeln('            ${property.name}: ${property.value},');
    }

    buffer.writeln('          ),');
    buffer.writeln('        ),');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Act & Assert');
    buffer.writeln('      expect(find.byType($widgetName), findsOneWidget);');
    buffer.writeln('    });');
    buffer.writeln();

    // Add widget tree test
    buffer.writeln(
      '    testWidgets(\'should have correct widget tree structure\', (WidgetTester tester) async {',
    );
    buffer.writeln('      // Arrange');
    buffer.writeln('      await tester.pumpWidget(');
    buffer.writeln('        MaterialApp(');
    buffer.writeln('          home: $widgetName(');

    // Add widget properties again
    for (final property in properties) {
      buffer.writeln('            ${property.name}: ${property.value},');
    }

    buffer.writeln('          ),');
    buffer.writeln('        ),');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Act & Assert');
    buffer.writeln('      expect(find.byType($widgetName), findsOneWidget);');

    // Add child widget tests if the widget has children
    if (node.children.isNotEmpty) {
      buffer.writeln();
      buffer.writeln('      // Test child widgets');
      for (final child in node.children) {
        final childType =
            child.widgetRuntimeType ?? child.description ?? 'Widget';
        final childName = extractWidgetName(childType);
        buffer.writeln(
          '      expect(find.byType($childName), findsOneWidget);',
        );
      }
    }

    buffer.writeln('    });');
    buffer.writeln();
    buffer.writeln('  });');
    buffer.writeln('}');

    return buffer.toString();
  }

  /// Extract widget name from type
  String extractWidgetName(String widgetType) {
    // Remove common prefixes and suffixes
    String name = widgetType;

    // Remove generic type parameters
    if (name.contains('<')) {
      name = name.substring(0, name.indexOf('<'));
    }

    // Remove underscores
    name = name.replaceAll('_', '');

    // Capitalize first letter
    if (name.isNotEmpty) {
      name = name[0].toUpperCase() + name.substring(1);
    }

    return name;
  }

  /// Extract widget properties for test generation
  Future<List<WidgetProperty>> _extractWidgetProperties(
    WidgetTreeNode node,
  ) async {
    final properties = <WidgetProperty>[];

    // Extract from node attributes
    if (node.attributes != null) {
      for (final attr in node.attributes!) {
        if (isTestableProperty(attr.name)) {
          properties.add(
            WidgetProperty(
              name: attr.name,
              value: formatPropertyValue(attr.label),
              type: _inferPropertyType(attr.label),
            ),
          );
        }
      }
    }

    // Add default properties for common widgets
    final widgetType = node.widgetRuntimeType?.toLowerCase() ?? '';
    if (widgetType.contains('text')) {
      properties.add(
        WidgetProperty(name: 'data', value: "'Sample Text'", type: 'String'),
      );
    } else if (widgetType.contains('button')) {
      properties.add(
        WidgetProperty(name: 'child', value: "Text('Button')", type: 'Widget'),
      );
    } else if (widgetType.contains('container')) {
      properties.add(
        WidgetProperty(
          name: 'child',
          value: "Text('Container')",
          type: 'Widget',
        ),
      );
    }

    return properties;
  }

  /// Check if a property should be included in tests
  bool isTestableProperty(String propertyName) {
    final testableProperties = {
      'data',
      'text',
      'child',
      'children',
      'title',
      'label',
      'value',
      'onPressed',
      'onTap',
      'color',
      'width',
      'height',
      'padding',
      'margin',
      'alignment',
      'crossAxisAlignment',
      'mainAxisAlignment',
    };

    return testableProperties.contains(propertyName.toLowerCase());
  }

  /// Format property value for test code
  String formatPropertyValue(String value) {
    // Handle different value types
    if (value.toLowerCase() == 'true' || value.toLowerCase() == 'false') {
      return value.toLowerCase();
    }

    if (RegExp(r'^\d+$').hasMatch(value)) {
      return value;
    }

    if (RegExp(r'^\d+\.\d+$').hasMatch(value)) {
      return value;
    }

    // Default to string
    if (!value.startsWith("'") && !value.startsWith('"')) {
      return "'$value'";
    }

    return value;
  }

  /// Infer property type from value
  String _inferPropertyType(String value) {
    if (value.toLowerCase() == 'true' || value.toLowerCase() == 'false') {
      return 'bool';
    }

    if (RegExp(r'^\d+$').hasMatch(value)) {
      return 'int';
    }

    if (RegExp(r'^\d+\.\d+$').hasMatch(value)) {
      return 'double';
    }

    return 'String';
  }

  /// Generate import path for the source file
  String generateImportPath(String sourceFile) {
    // Handle file:// URLs
    if (sourceFile.startsWith('file://')) {
      final cleanPath = sourceFile.substring(7);
      final libIndex = cleanPath.indexOf('/lib/');
      if (libIndex != -1) {
        final relativePath = cleanPath.substring(
          libIndex + 5,
        ); // +5 for '/lib/'
        return 'package:${getPackageName()}/$relativePath';
      }
    }

    // Handle relative paths
    if (sourceFile.startsWith('lib/')) {
      return 'package:${getPackageName()}/${sourceFile.substring(4)}'; // Remove 'lib/'
    }

    // Handle absolute paths
    if (sourceFile.contains('/lib/')) {
      final parts = sourceFile.split('/lib/');
      if (parts.length > 1) {
        final relativePath = parts[1];
        return 'package:${getPackageName()}/$relativePath';
      }
    }

    // Fallback: use filename
    final fileName = sourceFile.split('/').last;
    return 'package:${getPackageName()}/$fileName';
  }

  /// Get package name from project path or pubspec.yaml
  String getPackageName() {
    try {
      // Use the provided project path if available
      String projectDir;
      if (projectPath != null && projectPath!.isNotEmpty) {
        projectDir = projectPath!;
      } else {
        // Fallback to current working directory
        projectDir = Directory.current.path;
      }

      final packageName = projectDir.split('/').last;

      // Remove common suffixes that aren't package names
      // Only remove if the suffix is standalone (not part of the actual package name)
      if (packageName.endsWith('_project') && packageName.length > 8) {
        return packageName.replaceAll(RegExp(r'_project$'), '');
      } else if (packageName.endsWith('_app') && packageName.length > 4) {
        return packageName.replaceAll(RegExp(r'_app$'), '');
      }

      return packageName;
    } catch (e) {
      return 'your_package_name';
    }
  }
}

/// Model for widget properties used in test generation
class WidgetProperty {
  final String name;
  final String value;
  final String type;

  WidgetProperty({required this.name, required this.value, required this.type});
}
