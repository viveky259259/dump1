import 'dart:convert';
import 'dart:io';
import '../core/logging/logging.dart';

class DeviceInfo {
  final String name;
  final String deviceId;
  final String platform;
  final String description;

  const DeviceInfo({
    required this.name,
    required this.deviceId,
    required this.platform,
    required this.description,
  });

  @override
  String toString() => '$name ($deviceId)';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DeviceInfo &&
          runtimeType == other.runtimeType &&
          deviceId == other.deviceId;

  @override
  int get hashCode => deviceId.hashCode;
}

class DeviceService with LoggerMixin {
  static const DeviceInfo defaultDevice = DeviceInfo(
    name: 'Chrome (web)',
    deviceId: 'chrome',
    platform: 'web-javascript',
    description: 'Google Chrome',
  );

  /// Fetches available devices using 'flutter devices' command
  Future<List<DeviceInfo>> getAvailableDevices({String? flutterSdkDir}) async {
    return await logAsyncOperation(
      'getAvailableDevices',
      () async => _getAvailableDevicesImpl(flutterSdkDir),
      context: {'flutterSdkDir': flutterSdkDir},
    );
  }

  Future<List<DeviceInfo>> _getAvailableDevicesImpl(
    String? flutterSdkDir,
  ) async {
    try {
      logger.info('Fetching available Flutter devices');
      // Determine flutter executable path
      String flutterBinary;
      if (flutterSdkDir != null) {
        flutterBinary = '$flutterSdkDir/bin/flutter';
      } else {
        // Try default path or system flutter
        flutterBinary = 'flutter';
      }

      // Run flutter devices command
      final result = await Process.run(
        flutterBinary,
        [
          'devices',
          '--machine',
        ],
        workingDirectory: null,
      );

      if (result.exitCode != 0) {
        print('Error running flutter devices: ${result.stderr}');
        // Return default chrome device if command fails
        return [defaultDevice];
      }

      final stdout = result.stdout as String;
      final decoded = json.decode(stdout);

      if (decoded is! List) {
        return [defaultDevice];
      }

      final devices = <DeviceInfo>[];
      for (final entry in decoded) {
        if (entry is! Map<String, dynamic>) continue;
        final device = DeviceInfo(
          name: entry['name'] as String? ?? 'Unknown Device',
          deviceId: entry['id'] as String? ?? 'unknown',
          platform: entry['targetPlatform'] as String? ?? 'unknown',
          description: entry['sdk'] as String? ?? '',
        );
        devices.add(device);
      }

      if (devices.isEmpty) {
        return [defaultDevice];
      }

      // Ensure chrome is available - add it if not found
      final hasChrome = devices.any((d) => d.deviceId == 'chrome');
      if (!hasChrome) {
        devices.add(defaultDevice);
      }

      return devices;
    } catch (e) {
      print('Error fetching devices: $e');
      // Return default device on any error
      return [defaultDevice];
    }
  }

  /// Alternative method using human-readable output parsing
  Future<List<DeviceInfo>> getAvailableDevicesHumanReadable({
    String? flutterSdkDir,
  }) async {
    try {
      // Determine flutter executable path
      String flutterBinary;
      if (flutterSdkDir != null) {
        flutterBinary = '$flutterSdkDir/bin/flutter';
      } else {
        // Try default path or system flutter
        flutterBinary = 'flutter';
      }

      // Run flutter devices command
      final result = await Process.run(
        flutterBinary,
        [
          'devices',
        ],
        workingDirectory: null,
      );

      if (result.exitCode != 0) {
        print('Error running flutter devices: ${result.stderr}');
        // Return default chrome device if command fails
        return [defaultDevice];
      }

      // Parse human-readable output
      final devices = <DeviceInfo>[];
      final lines = (result.stdout as String).split('\n');

      for (final line in lines) {
        // Look for device lines with format: "Device Name • device_id • platform • description"
        final deviceMatch = RegExp(
          r'^(.+?)\s+•\s+(\S+)\s+•\s+(\S+)\s+•\s+(.+)$',
        ).firstMatch(line.trim());
        if (deviceMatch != null) {
          final device = DeviceInfo(
            name: deviceMatch.group(1)!.trim(),
            deviceId: deviceMatch.group(2)!.trim(),
            platform: deviceMatch.group(3)!.trim(),
            description: deviceMatch.group(4)!.trim(),
          );
          devices.add(device);
        }
      }

      // If no devices found, return default
      if (devices.isEmpty) {
        return [defaultDevice];
      }

      // Ensure chrome is available - add it if not found
      final hasChrome = devices.any((d) => d.deviceId == 'chrome');
      if (!hasChrome) {
        devices.add(defaultDevice);
      }

      return devices;
    } catch (e) {
      print('Error fetching devices: $e');
      // Return default device on any error
      return [defaultDevice];
    }
  }
}
