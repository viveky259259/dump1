import 'dart:async';

import 'package:flutter/foundation.dart';
import 'inspector_service.dart';
import 'source_code_analyzer.dart';
import 'dependency_analysis_service.dart';
import '../core/logging/logging.dart';

/// Enhanced dependency analysis result
class EnhancedDependencyResult {
  final List<WidgetDependency> dependencies;
  final Map<String, dynamic> metadata;
  final Duration analysisTime;
  final int widgetsAnalyzed;
  final int sourceFilesAnalyzed;

  EnhancedDependencyResult({
    required this.dependencies,
    required this.metadata,
    required this.analysisTime,
    required this.widgetsAnalyzed,
    required this.sourceFilesAnalyzed,
  });

  Map<String, dynamic> toJson() => {
    'dependencies': dependencies
        .map(
          (d) => {
            'type': d.type,
            'category': d.category,
            'description': d.description,
            'setupCode': d.setupCode,
            'distanceFromTarget': d.distanceFromTarget,
          },
        )
        .toList(),
    'metadata': metadata,
    'analysisTime': analysisTime.inMilliseconds,
    'widgetsAnalyzed': widgetsAnalyzed,
    'sourceFilesAnalyzed': sourceFilesAnalyzed,
  };
}

/// Enhanced dependency analysis service with improved performance and accuracy
class EnhancedDependencyAnalysisService with LoggerMixin {
  final InspectorService inspectorService;
  final SourceCodeAnalyzer _sourceAnalyzer = SourceCodeAnalyzer();

  // Caching for dependency analysis results
  final Map<String, EnhancedDependencyResult> _dependencyCache = {};
  final Map<String, DateTime> _cacheTimestamps = {};
  static const Duration cacheExpiry = Duration(minutes: 10);

  // Performance tracking
  final Map<String, Duration> _performanceMetrics = {};

  // Event streaming
  StreamController<DependencyAnalysisEvent> _eventController =
      StreamController<DependencyAnalysisEvent>.broadcast();

  EnhancedDependencyAnalysisService(this.inspectorService) {
    logger.info('EnhancedDependencyAnalysisService initialized');
  }

  Stream<DependencyAnalysisEvent> get eventStream => _eventController.stream;

  void _emitEvent(DependencyAnalysisEvent event) {
    if (!_eventController.isClosed) {
      _eventController.add(event);
    }
  }

  void _log(String message, {String? level}) {
    if (kDebugMode) {
      final timestamp = DateTime.now().toIso8601String();
      final prefix = level != null ? '[$level]' : '[INFO]';
      print('$prefix [$timestamp] EnhancedDependencyAnalysis: $message');
    }
  }

  void _logError(String message, [Object? error, StackTrace? stackTrace]) {
    _log(message, level: 'ERROR');
    if (error != null) {
      _log('Error details: $error', level: 'ERROR');
    }
    if (stackTrace != null) {
      _log('Stack trace: $stackTrace', level: 'ERROR');
    }
  }

  bool _isCacheValid(String key) {
    final timestamp = _cacheTimestamps[key];
    if (timestamp == null) return false;
    return DateTime.now().difference(timestamp) < cacheExpiry;
  }

  /// Analyze dependencies for a widget with enhanced caching and performance tracking
  Future<EnhancedDependencyResult> analyzeWidgetDependencies(
    WidgetTreeNode targetWidget, {
    bool useCache = true,
    bool includeSourceAnalysis = true,
    bool includeTreeAnalysis = true,
  }) async {
    final startTime = DateTime.now();
    final cacheKey =
        '${targetWidget.objectId}_${targetWidget.widgetRuntimeType}';

    // Check cache first
    if (useCache && _isCacheValid(cacheKey)) {
      _log(
        'Returning cached dependency analysis for ${targetWidget.displayName}',
      );
      return _dependencyCache[cacheKey]!;
    }

    _emitEvent(DependencyAnalysisStartedEvent(targetWidget));
    _log(
      'Starting enhanced dependency analysis for ${targetWidget.displayName}',
    );

    try {
      final dependencies = <WidgetDependency>[];
      int widgetsAnalyzed = 0;
      int sourceFilesAnalyzed = 0;

      // Step 1: Tree-based analysis (fast, but less accurate)
      if (includeTreeAnalysis) {
        _log('Performing tree-based dependency analysis');
        final treeDependencies = await _analyzeTreeDependencies(targetWidget);
        dependencies.addAll(treeDependencies);
        widgetsAnalyzed += _countWidgetsInTree(targetWidget);
      }

      // Step 2: Source code analysis (slower, but more accurate)
      if (includeSourceAnalysis && targetWidget.objectId != null) {
        _log('Performing source code analysis');
        final sourceResult = await _analyzeSourceDependencies(targetWidget);
        dependencies.addAll(sourceResult.dependencies);
        sourceFilesAnalyzed = sourceResult.filesAnalyzed;
      }

      // Step 3: Deduplicate and prioritize dependencies
      final deduplicatedDependencies = _deduplicateDependencies(dependencies);

      // Step 4: Calculate metadata
      final metadata = _calculateMetadata(
        deduplicatedDependencies,
        targetWidget,
      );

      final analysisTime = DateTime.now().difference(startTime);
      final result = EnhancedDependencyResult(
        dependencies: deduplicatedDependencies,
        metadata: metadata,
        analysisTime: analysisTime,
        widgetsAnalyzed: widgetsAnalyzed,
        sourceFilesAnalyzed: sourceFilesAnalyzed,
      );

      // Cache the result
      _dependencyCache[cacheKey] = result;
      _cacheTimestamps[cacheKey] = DateTime.now();

      // Track performance
      _performanceMetrics[cacheKey] = analysisTime;

      _emitEvent(DependencyAnalysisCompletedEvent(targetWidget, result));
      _log('Dependency analysis completed in ${analysisTime.inMilliseconds}ms');

      return result;
    } catch (e, stackTrace) {
      _logError('Dependency analysis failed', e, stackTrace);
      _emitEvent(DependencyAnalysisFailedEvent(targetWidget, e));
      rethrow;
    }
  }

  /// Analyze dependencies by traversing the widget tree
  Future<List<WidgetDependency>> _analyzeTreeDependencies(
    WidgetTreeNode targetWidget,
  ) async {
    final dependencies = <WidgetDependency>[];

    // Get the full widget tree
    final rootTree = await inspectorService.getRootWidgetSummaryTree();
    if (rootTree == null) return dependencies;

    // Find the target widget in the tree
    final targetNode = _findWidgetInTree(rootTree, targetWidget.objectId);
    if (targetNode == null) return dependencies;

    // Analyze ancestors for inherited dependencies
    await _analyzeAncestorDependencies(targetNode, dependencies);

    // Analyze siblings for context dependencies
    await _analyzeSiblingDependencies(targetNode, dependencies);

    return dependencies;
  }

  /// Analyze dependencies by examining source code
  Future<SourceAnalysisResult> _analyzeSourceDependencies(
    WidgetTreeNode targetWidget,
  ) async {
    final dependencies = <WidgetDependency>[];
    int filesAnalyzed = 0;

    try {
      // Get source location
      final sourceLocation = await inspectorService.getWidgetSourceLocation(
        targetWidget.objectId!,
      );

      if (sourceLocation != null) {
        filesAnalyzed++;

        // Get source code
        final sourceCode = await inspectorService.getWidgetSourceCode(
          sourceLocation,
        );

        if (sourceCode != null) {
          // Analyze source code for dependencies
          final sourceDeps = await _sourceAnalyzer.analyzeDependencies(
            sourceCode,
            sourceLocation,
          );

          // Convert to widget dependencies
          for (final sourceDep in sourceDeps) {
            final widgetDep = _convertSourceToWidgetDependency(sourceDep, 0);
            if (widgetDep != null) {
              dependencies.add(widgetDep);
            }
          }
        }
      }
    } catch (e) {
      _logError('Source analysis failed', e);
    }

    return SourceAnalysisResult(
      dependencies: dependencies,
      filesAnalyzed: filesAnalyzed,
    );
  }

  /// Find a widget in the tree by object ID
  WidgetTreeNode? _findWidgetInTree(WidgetTreeNode root, String? objectId) {
    if (root.objectId == objectId) return root;

    for (final child in root.children) {
      final found = _findWidgetInTree(child, objectId);
      if (found != null) return found;
    }

    return null;
  }

  /// Analyze ancestor widgets for inherited dependencies
  Future<void> _analyzeAncestorDependencies(
    WidgetTreeNode targetNode,
    List<WidgetDependency> dependencies,
  ) async {
    // This would traverse up the tree to find inherited widgets
    // For now, we'll implement a simplified version
    _log('Analyzing ancestor dependencies');

    // Look for common inherited widgets in the tree
    final inheritedWidgets = [
      'Theme',
      'MediaQuery',
      'Navigator',
      'Scaffold',
      'MaterialApp',
      'CupertinoApp',
    ];

    for (final inheritedType in inheritedWidgets) {
      if (targetNode.effectiveWidgetType?.contains(inheritedType) == true) {
        dependencies.add(
          WidgetDependency(
            type: inheritedType,
            category: DependencyCategory.inherited,
            description: 'Inherited $inheritedType widget',
            setupCode: _generateInheritedSetupCode(inheritedType),
            distanceFromTarget: 0,
          ),
        );
      }
    }
  }

  /// Analyze sibling widgets for context dependencies
  Future<void> _analyzeSiblingDependencies(
    WidgetTreeNode targetNode,
    List<WidgetDependency> dependencies,
  ) async {
    _log('Analyzing sibling dependencies');

    // Look for provider patterns in siblings
    final providerTypes = [
      'Provider',
      'ChangeNotifierProvider',
      'BlocProvider',
      'Consumer',
      'Selector',
    ];

    for (final providerType in providerTypes) {
      if (targetNode.effectiveWidgetType?.contains(providerType) == true) {
        dependencies.add(
          WidgetDependency(
            type: providerType,
            category: DependencyCategory.provider,
            description: '$providerType dependency',
            setupCode: _generateProviderSetupCode(providerType),
            distanceFromTarget: 1,
          ),
        );
      }
    }
  }

  /// Convert source code dependency to widget dependency
  WidgetDependency? _convertSourceToWidgetDependency(
    SourceCodeDependency sourceDep,
    int distance,
  ) {
    // Map source dependency names to widget dependency categories
    String category;
    final name = sourceDep.name.toLowerCase();

    if (name.contains('provider')) {
      category = DependencyCategory.provider;
    } else if (name.contains('bloc')) {
      category = DependencyCategory.provider; // BLoC is a type of provider
    } else if (name.contains('theme')) {
      category = DependencyCategory.material;
    } else if (name.contains('navigator') || name.contains('router')) {
      category = DependencyCategory.navigation;
    } else if (name.contains('mediaquery')) {
      category = DependencyCategory.media;
    } else if (name.contains('inherited')) {
      category = DependencyCategory.inherited;
    } else {
      category = DependencyCategory.other;
    }

    return WidgetDependency(
      type: sourceDep.name,
      category: category,
      description: sourceDep.description,
      setupCode: sourceDep.generateTestWrapper('YourWidget()'),
      distanceFromTarget: distance,
    );
  }

  /// Deduplicate dependencies and prioritize them
  List<WidgetDependency> _deduplicateDependencies(
    List<WidgetDependency> dependencies,
  ) {
    final uniqueDependencies = <String, WidgetDependency>{};

    for (final dep in dependencies) {
      final key = '${dep.type}_${dep.category}';
      if (!uniqueDependencies.containsKey(key) ||
          dep.distanceFromTarget <
              uniqueDependencies[key]!.distanceFromTarget) {
        uniqueDependencies[key] = dep;
      }
    }

    return uniqueDependencies.values.toList()
      ..sort((a, b) => a.distanceFromTarget.compareTo(b.distanceFromTarget));
  }

  /// Calculate metadata about the analysis
  Map<String, dynamic> _calculateMetadata(
    List<WidgetDependency> dependencies,
    WidgetTreeNode targetWidget,
  ) {
    final categoryCounts = <String, int>{};
    for (final dep in dependencies) {
      categoryCounts[dep.category] = (categoryCounts[dep.category] ?? 0) + 1;
    }

    return {
      'totalDependencies': dependencies.length,
      'categoryCounts': categoryCounts,
      'targetWidgetType': targetWidget.widgetRuntimeType,
      'targetWidgetDescription': targetWidget.description,
      'hasProviderDependencies': dependencies.any(
        (d) => d.category == DependencyCategory.provider,
      ),
      'hasInheritedDependencies': dependencies.any(
        (d) => d.category == DependencyCategory.inherited,
      ),
      'hasThemeDependencies': dependencies.any(
        (d) => d.category == DependencyCategory.material,
      ),
      'analysisTimestamp': DateTime.now().toIso8601String(),
    };
  }

  /// Count widgets in a tree
  int _countWidgetsInTree(WidgetTreeNode root) {
    int count = 1;
    for (final child in root.children) {
      count += _countWidgetsInTree(child);
    }
    return count;
  }

  /// Generate setup code for inherited widgets
  String _generateInheritedSetupCode(String inheritedType) {
    switch (inheritedType) {
      case 'Theme':
        return '''
// Wrap your widget with Theme
Theme(
  data: ThemeData.light(), // or ThemeData.dark()
  child: YourWidget(),
)''';
      case 'MediaQuery':
        return '''
// Wrap your widget with MediaQuery
MediaQuery(
  data: MediaQueryData.fromWindow(WidgetsBinding.instance.window),
  child: YourWidget(),
)''';
      case 'Navigator':
        return '''
// Wrap your widget with Navigator
Navigator(
  initialRoute: '/',
  onGenerateRoute: (settings) => MaterialPageRoute(
    builder: (context) => YourWidget(),
  ),
)''';
      default:
        return '// Setup code for $inheritedType';
    }
  }

  /// Generate setup code for provider widgets
  String _generateProviderSetupCode(String providerType) {
    switch (providerType) {
      case 'Provider':
        return '''
// Wrap your widget with Provider
Provider<YourModel>(
  create: (context) => YourModel(),
  child: YourWidget(),
)''';
      case 'ChangeNotifierProvider':
        return '''
// Wrap your widget with ChangeNotifierProvider
ChangeNotifierProvider<YourNotifier>(
  create: (context) => YourNotifier(),
  child: YourWidget(),
)''';
      case 'BlocProvider':
        return '''
// Wrap your widget with BlocProvider
BlocProvider<YourBloc>(
  create: (context) => YourBloc(),
  child: YourWidget(),
)''';
      default:
        return '// Setup code for $providerType';
    }
  }

  /// Get performance metrics
  Map<String, Duration> getPerformanceMetrics() =>
      Map.from(_performanceMetrics);

  /// Clear cache
  void clearCache() {
    _dependencyCache.clear();
    _cacheTimestamps.clear();
    _performanceMetrics.clear();
    _log('Cache cleared');
  }

  /// Dispose resources
  void dispose() {
    _dependencyCache.clear();
    _cacheTimestamps.clear();
    _performanceMetrics.clear();
    if (!_eventController.isClosed) {
      _eventController.close();
    }
  }
}

/// Source analysis result
class SourceAnalysisResult {
  final List<WidgetDependency> dependencies;
  final int filesAnalyzed;

  SourceAnalysisResult({
    required this.dependencies,
    required this.filesAnalyzed,
  });
}

/// Events for dependency analysis
abstract class DependencyAnalysisEvent {}

class DependencyAnalysisStartedEvent extends DependencyAnalysisEvent {
  final WidgetTreeNode targetWidget;
  DependencyAnalysisStartedEvent(this.targetWidget);
}

class DependencyAnalysisCompletedEvent extends DependencyAnalysisEvent {
  final WidgetTreeNode targetWidget;
  final EnhancedDependencyResult result;
  DependencyAnalysisCompletedEvent(this.targetWidget, this.result);
}

class DependencyAnalysisFailedEvent extends DependencyAnalysisEvent {
  final WidgetTreeNode targetWidget;
  final Object error;
  DependencyAnalysisFailedEvent(this.targetWidget, this.error);
}
