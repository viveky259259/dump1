import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:vm_service/vm_service.dart' as vm;
import 'package:vm_service/vm_service_io.dart' as vm_io;

import '../core/logging/logging.dart';

/// Model for widget attributes (structured property data)
class WidgetAttribute {
  final String name; // e.g., "data", "icon", "value"
  final String label; // e.g., "'Hello World'", "Icons.home"
  final String? type; // e.g., "String", "IconData", "Color"
  final dynamic value; // Raw value if available

  WidgetAttribute({
    required this.name,
    required this.label,
    this.type,
    this.value,
  });

  factory WidgetAttribute.fromJson(Map<String, dynamic> json) {
    return WidgetAttribute(
      name: json['name'] as String? ?? '',
      label: json['label'] as String? ?? '',
      type: json['type'] as String?,
      value: json['value'],
    );
  }

  @override
  String toString() => '$name: $label';
}

/// Represents the creation location of a widget in source code
class CreationLocation {
  final String file;
  final int line;
  final int column;
  final String name;

  CreationLocation({
    required this.file,
    required this.line,
    required this.column,
    required this.name,
  });

  factory CreationLocation.fromJson(Map<String, dynamic> json) {
    return CreationLocation(
      file: json['file'] as String? ?? '',
      line: json['line'] as int? ?? 0,
      column: json['column'] as int? ?? 0,
      name: json['name'] as String? ?? '',
    );
  }

  @override
  String toString() => '$file:$line:$column ($name)';
}

/// Configuration for InspectorService
class InspectorConfig {
  final Duration connectionTimeout;
  final Duration requestTimeout;
  final int maxRetries;
  final Duration cacheExpiry;
  final bool enableLogging;
  final int batchSize;
  final bool
  useFullWidgetTree; // Toggle between getRootWidgetTree and getRootWidgetSummaryTree

  const InspectorConfig({
    this.connectionTimeout = const Duration(seconds: 30),
    this.requestTimeout = const Duration(seconds: 10),
    this.maxRetries = 3,
    this.cacheExpiry = const Duration(minutes: 5),
    this.enableLogging = true,
    this.batchSize = 10,
    this.useFullWidgetTree =
        false, // Default to summary tree for better performance
  });
}

/// Connection state for InspectorService
enum InspectorConnectionState { disconnected, connecting, connected, error }

/// Events emitted by InspectorService
abstract class InspectorEvent {}

class WidgetSelectedEvent extends InspectorEvent {
  final String objectId;
  WidgetSelectedEvent(this.objectId);
}

class WidgetTreeChangedEvent extends InspectorEvent {
  final WidgetTreeNode newTree;
  WidgetTreeChangedEvent(this.newTree);
}

class ConnectionStateChangedEvent extends InspectorEvent {
  final InspectorConnectionState state;
  ConnectionStateChangedEvent(this.state);
}

/// Model for widget tree nodes based on actual Flutter inspector output
class WidgetTreeNode {
  final String? description; // Human-readable description
  final String? type; // Always "_ElementDiagnosticableTreeNode"
  final String?
  objectId; // valueId from inspector (inspector-0, inspector-1, etc.)
  final String? style; // Usually "dense"
  final bool hasChildren;
  final bool allowWrap;
  final bool summaryTree;
  final int? locationId; // Numeric location identifier
  final CreationLocation? creationLocation; // Source code location
  final bool?
  createdByLocalProject; // True if from user's project vs Flutter framework
  final String?
  widgetRuntimeType; // Actual widget type (Text, Column, Scaffold, etc.)
  final bool? stateful; // True if stateful widget, false if stateless
  final List<WidgetTreeNode> children;

  // Enhanced fields for additional data
  final Map<String, dynamic>? properties;
  final List<WidgetAttribute>? attributes;

  WidgetTreeNode({
    this.description,
    this.type,
    this.objectId,
    this.style,
    this.hasChildren = false,
    this.allowWrap = false,
    this.summaryTree = false,
    this.locationId,
    this.creationLocation,
    this.createdByLocalProject,
    this.widgetRuntimeType,
    this.stateful,
    this.children = const [],
    this.properties,
    this.attributes,
  });

  factory WidgetTreeNode.fromJson(Map<String, dynamic> json) {
    // Parse creation location if available
    CreationLocation? creationLocation;
    if (json['creationLocation'] != null) {
      creationLocation = CreationLocation.fromJson(
        json['creationLocation'] as Map<String, dynamic>,
      );
    }

    // Parse attributes if available
    List<WidgetAttribute>? attributes;
    if (json['attributes'] != null) {
      attributes = (json['attributes'] as List<dynamic>)
          .map((attr) => WidgetAttribute.fromJson(attr as Map<String, dynamic>))
          .toList();
    }

    return WidgetTreeNode(
      description: json['description'] as String?,
      type: json['type'] as String?,
      objectId: json['valueId'] as String?, // Map valueId to objectId
      style: json['style'] as String?,
      hasChildren: json['hasChildren'] as bool? ?? false,
      allowWrap: json['allowWrap'] as bool? ?? false,
      summaryTree: json['summaryTree'] as bool? ?? false,
      locationId: json['locationId'] as int?,
      creationLocation: creationLocation,
      createdByLocalProject: json['createdByLocalProject'] as bool?,
      widgetRuntimeType: json['widgetRuntimeType'] as String?,
      stateful: json['stateful'] as bool?,
      properties: json['properties'] as Map<String, dynamic>?,
      attributes: attributes,
      children:
          (json['children'] as List<dynamic>?)
              ?.map((e) => WidgetTreeNode.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  /// Get the display name for this widget (prefer widgetRuntimeType over description)
  String get displayName {
    return widgetRuntimeType ?? description ?? type ?? 'Unknown Widget';
  }

  /// Get the widget type for dependency analysis (widgetRuntimeType or extract from description)
  String? get effectiveWidgetType {
    if (widgetRuntimeType != null) return widgetRuntimeType;

    // For Provider-type widgets, extract the generic type from description
    if (description != null) {
      // Handle cases like "ChangeNotifierProvider<UserService>"
      final providerMatch = RegExp(
        r'(\w+Provider)<([^>]+)>',
      ).firstMatch(description!);
      if (providerMatch != null) {
        return providerMatch.group(1); // Returns "ChangeNotifierProvider"
      }

      // Handle cases like "_InheritedProviderScope<UserService?>"
      final inheritedMatch = RegExp(
        r'_Inherited(\w+)Scope<([^>]+)>',
      ).firstMatch(description!);
      if (inheritedMatch != null) {
        return 'InheritedWidget'; // Generalize inherited widgets
      }
    }

    return description;
  }

  /// Check if this widget is from the user's project (vs Flutter framework)
  bool get isFromUserProject => createdByLocalProject ?? false;

  /// Check if this widget is likely to have interesting dependencies
  bool get hasPotentialDependencies {
    final type = effectiveWidgetType?.toLowerCase() ?? '';

    // Provider patterns
    if (type.contains('provider')) return true;
    if (type.contains('consumer')) return true;
    if (type.contains('inherited')) return true;

    // BLoC patterns
    if (type.contains('bloc')) return true;

    // Context-dependent widgets
    if (type.contains('scaffold')) return true;
    if (type.contains('theme')) return true;
    if (type.contains('navigator')) return true;
    if (type.contains('form')) return true;
    if (type.contains('tab')) return true;

    // Custom widgets from user's project are more likely to have dependencies
    if (isFromUserProject && !_isBuiltInFlutterWidget(type)) return true;

    return false;
  }

  bool _isBuiltInFlutterWidget(String type) {
    const builtInWidgets = {
      'container',
      'column',
      'row',
      'center',
      'padding',
      'margin',
      'text',
      'icon',
      'image',
      'sizedbox',
      'expanded',
      'flexible',
      'stack',
      'positioned',
      'align',
      'wrap',
      'listview',
      'gridview',
    };
    return builtInWidgets.contains(type.toLowerCase());
  }
}

/// Enhanced inspector service with comprehensive widget inspection capabilities
class InspectorService with LoggerMixin {
  final Uri vmServiceUri;
  InspectorConfig _config; // Made mutable
  vm.VmService? _service;
  String? _currentObjectGroup;
  int _objectGroupCounter = 0;

  // Connection state management
  InspectorConnectionState _connectionState =
      InspectorConnectionState.disconnected;
  StreamController<InspectorConnectionState> _stateController =
      StreamController<InspectorConnectionState>.broadcast();

  // Event streaming
  StreamController<InspectorEvent> _eventController =
      StreamController<InspectorEvent>.broadcast();

  // Caching
  final Map<String, WidgetTreeNode> _widgetCache = {};
  final Map<String, List<WidgetAttribute>> _propertiesCache = {};
  final Map<String, DateTime> _cacheTimestamps = {};

  // Resource management
  final List<StreamSubscription> _subscriptions = [];
  bool _disposed = false;

  InspectorService(this.vmServiceUri, {InspectorConfig? config})
    : _config = config ?? const InspectorConfig();

  // Public getters
  vm.VmService? get service => _service;
  set service(vm.VmService? value) =>
      _service = value; // Allow setting service for reuse
  String? get currentObjectGroup => _currentObjectGroup;
  set currentObjectGroup(String? value) =>
      _currentObjectGroup = value; // Allow setting object group for reuse
  Stream<InspectorConnectionState> get connectionStateStream =>
      _stateController.stream;
  InspectorConnectionState get connectionState => _connectionState;
  Stream<InspectorEvent> get eventStream => _eventController.stream;
  InspectorConfig get config => _config;

  void _checkDisposed() {
    if (_disposed) {
      throw StateError('InspectorService has been disposed');
    }
  }

  void _updateConnectionState(InspectorConnectionState newState) {
    if (_connectionState != newState) {
      _connectionState = newState;
      _stateController.add(newState);
      _emitEvent(ConnectionStateChangedEvent(newState));
    }
  }

  void _emitEvent(InspectorEvent event) {
    if (!_eventController.isClosed) {
      _eventController.add(event);
    }
  }

  void _log(String message, {String? level}) {
    if (_config.enableLogging && kDebugMode) {
      final timestamp = DateTime.now().toIso8601String();
      final prefix = level != null ? '[$level]' : '[INFO]';
      print('$prefix [$timestamp] InspectorService: $message');
    }
  }

  void _logError(String message, [Object? error, StackTrace? stackTrace]) {
    _log(message, level: 'ERROR');
    if (error != null) {
      _log('Error details: $error', level: 'ERROR');
    }
    if (stackTrace != null) {
      _log('Stack trace: $stackTrace', level: 'ERROR');
    }
  }

  Future<T?> _withRetry<T>(
    Future<T> Function() operation, {
    String? operationName,
  }) async {
    for (int attempt = 1; attempt <= _config.maxRetries; attempt++) {
      try {
        return await operation();
      } catch (e) {
        if (attempt == _config.maxRetries) {
          _logError(
            '$operationName failed after ${_config.maxRetries} attempts',
            e,
          );
          rethrow;
        }
        _log(
          '$operationName attempt $attempt failed: $e, retrying...',
          level: 'WARN',
        );
        await Future.delayed(Duration(seconds: attempt));
      }
    }
    return null;
  }

  bool _isCacheValid(String key) {
    final timestamp = _cacheTimestamps[key];
    if (timestamp == null) return false;
    return DateTime.now().difference(timestamp) < _config.cacheExpiry;
  }

  Future<void> connect() async {
    _checkDisposed();
    _updateConnectionState(InspectorConnectionState.connecting);

    try {
      final wsUri = _toWsUri(vmServiceUri);
      _log('Attempting to connect to VM service at: $wsUri');

      _service = await vm_io
          .vmServiceConnectUri(wsUri)
          .timeout(_config.connectionTimeout);

      _log('InspectorService connected to $vmServiceUri');

      // Wait a moment for service extensions to be available
      await Future.delayed(const Duration(seconds: 2));

      // Initialize inspector
      await _initializeInspector();

      // Verify inspector is working
      final isReady = await isInspectorAvailable();
      _log('Inspector availability check: $isReady');

      if (isReady) {
        _updateConnectionState(InspectorConnectionState.connected);
      } else {
        _updateConnectionState(InspectorConnectionState.error);
      }
    } catch (e) {
      _logError('Failed to connect to VM service', e);
      _updateConnectionState(InspectorConnectionState.error);
      rethrow;
    }
  }

  String _toWsUri(Uri uri) {
    if (uri.scheme.startsWith('ws')) return uri.toString();
    // vm_service needs a ws:// URI; convert http:// into ws://
    return uri.replace(scheme: uri.scheme == 'https' ? 'wss' : 'ws').toString();
  }

  Future<void> _initializeInspector() async {
    try {
      // Set pub root directories to help with source mapping
      await invokeInspector(
        method: 'setPubRootDirectories',
        args: {'objectGroup': _getObjectGroup()},
      );
      _log('Inspector initialized successfully');
    } catch (e) {
      _logError('Failed to initialize inspector', e);
      // Don't rethrow - inspector can still work without this initialization
    }
  }

  String _getObjectGroup() {
    _currentObjectGroup ??= 'inspector_${_objectGroupCounter++}';
    return _currentObjectGroup!;
  }

  Future<vm.VM> getVM() async {
    final s = _service!;
    return s.getVM();
  }

  Future<String?> getFirstFlutterIsolateId() async {
    final vmResult = await getVM();
    for (final isolateRef in vmResult.isolates ?? <vm.IsolateRef>[]) {
      if (isolateRef.name?.toLowerCase().contains('main') == true) {
        return isolateRef.id;
      }
    }
    return vmResult.isolates?.firstOrNull?.id;
  }

  Future<vm.Response?> invokeInspector({
    required String method,
    Map<String, Object?>? args,
  }) async {
    _checkDisposed();
    _log('InvokeInspector: $method with args: $args');

    return await _withRetry(() async {
      final service = _service!;
      final isolateId = await getFirstFlutterIsolateId();
      if (isolateId == null) {
        throw StateError('No isolate ID available');
      }

      _log('Calling service extension: ext.flutter.inspector.$method');
      final result = await service
          .callServiceExtension(
            'ext.flutter.inspector.$method',
            isolateId: isolateId,
            args: args,
          )
          .timeout(_config.requestTimeout);

      _log('Inspector call successful for $method');
      return result;
    }, operationName: 'invokeInspector($method)');
  }

  /// Get the root widget tree (summary or full based on config)
  Future<WidgetTreeNode?> getRootWidgetSummaryTree() async {
    _checkDisposed();
    final cacheKey = config.useFullWidgetTree
        ? 'root_widget_tree_full'
        : 'root_widget_tree_summary';

    // Check cache first
    if (_isCacheValid(cacheKey)) {
      _log(
        'Returning cached widget tree (${_config.useFullWidgetTree ? 'full' : 'summary'})',
      );
      return _widgetCache[cacheKey];
    }

    // Choose method based on config
    final method = _config.useFullWidgetTree
        ? 'getRootWidgetTree'
        : 'getRootWidgetSummaryTree';
    _log(
      'Using ${_config.useFullWidgetTree ? 'full' : 'summary'} widget tree method: $method',
    );

    final response = await invokeInspector(
      method: method,
      args: {
        'objectGroup': _getObjectGroup(),
        'maxDescendents': _config.useFullWidgetTree
            ? null
            : 100000, // Full tree doesn't need maxDescendents limit
      },
    );

    if (response?.json == null) return null;

    try {
      final json = response!.json!;
      _log('Full response received: ${json.length} characters');

      // Extract the result object from the response
      final resultJson = json['result'] as Map<String, dynamic>?;
      if (resultJson == null) {
        _logError('No result in response');
        return null;
      }

      _log('Parsing result');
      final rootNode = WidgetTreeNode.fromJson(resultJson);
      _log('Successfully parsed root node: ${rootNode.displayName}');

      // Enhanced: Fetch detailed properties for nodes that need them
      // Only enrich if using summary tree (full tree already has all properties)
      if (!_config.useFullWidgetTree) {
        await _enrichNodeWithProperties(rootNode);
      }

      // Cache the result
      _widgetCache[cacheKey] = rootNode;
      _cacheTimestamps[cacheKey] = DateTime.now();

      // Emit tree changed event
      _emitEvent(WidgetTreeChangedEvent(rootNode));

      return rootNode;
    } catch (e, stackTrace) {
      _logError('Failed to parse widget tree', e, stackTrace);
      return null;
    }
  }

  /// Get the full widget tree (convenience method)
  Future<WidgetTreeNode?> getRootWidgetTree() async {
    // Temporarily override config to use full tree
    final originalConfig = _config;
    final fullTreeConfig = InspectorConfig(
      connectionTimeout: originalConfig.connectionTimeout,
      requestTimeout: originalConfig.requestTimeout,
      maxRetries: originalConfig.maxRetries,
      cacheExpiry: originalConfig.cacheExpiry,
      enableLogging: originalConfig.enableLogging,
      batchSize: originalConfig.batchSize,
      useFullWidgetTree: true, // Force full tree
    );

    // Create temporary service with full tree config
    final tempService = InspectorService(vmServiceUri, config: fullTreeConfig);
    tempService.service = _service; // Reuse existing connection
    tempService.currentObjectGroup = _currentObjectGroup;

    return await tempService.getRootWidgetSummaryTree();
  }

  /// Recursively enrich nodes with detailed properties
  Future<void> _enrichNodeWithProperties(WidgetTreeNode node) async {
    // Only enrich nodes that are likely to have interesting content
    if (_shouldEnrichNode(node)) {
      await _enrichSingleNode(node);
    }

    // Recursively enrich children
    for (final child in node.children) {
      await _enrichNodeWithProperties(child);
    }
  }

  /// Determine if a node should be enriched with detailed properties
  bool _shouldEnrichNode(WidgetTreeNode node) {
    final type =
        node.widgetRuntimeType?.toLowerCase() ??
        node.description?.toLowerCase() ??
        '';

    // Enrich text-related widgets
    if (type.contains('text')) return true;

    // Enrich input widgets
    if (type.contains('field') || type.contains('input')) return true;

    // Enrich buttons
    if (type.contains('button')) return true;

    // Enrich icons
    if (type.contains('icon')) return true;

    // Enrich images
    if (type.contains('image')) return true;

    // Enrich sizing widgets (SizedBox, Container, Expanded, etc.)
    if (type.contains('sizedbox') ||
        type.contains('container') ||
        type.contains('expanded') ||
        type.contains('flexible') ||
        type.contains('padding') ||
        type.contains('margin'))
      return true;

    // Enrich layout widgets
    if (type.contains('row') ||
        type.contains('column') ||
        type.contains('stack') ||
        type.contains('positioned'))
      return true;

    // Enrich interactive widgets
    if (type.contains('gesture') ||
        type.contains('inkwell') ||
        type.contains('material') ||
        type.contains('card'))
      return true;

    return false;
  }

  /// Enrich a single node with detailed properties
  Future<void> _enrichSingleNode(WidgetTreeNode node) async {
    if (node.objectId == null) return;

    try {
      // Get detailed widget properties
      final properties = await getWidgetDetails(node.objectId!);
      if (properties == null) return;

      // Extract attributes from the detailed properties
      final attributes = extractAttributesFromProperties(properties, node.type);

      // Update node with attributes (we'll need to modify this approach)
      // For now, we'll store in a cache and access it during display
      _nodeAttributeCache[node.objectId!] = attributes;
    } catch (e) {
      print('Failed to enrich node ${node.objectId}: $e');
    }
  }

  // Cache for storing node attributes
  final Map<String, List<WidgetAttribute>> _nodeAttributeCache = {};

  /// Get cached attributes for a node
  List<WidgetAttribute>? getCachedAttributes(String? objectId) {
    if (objectId == null) return null;
    return _nodeAttributeCache[objectId];
  }

  /// Update cache with fresh attributes (for when we have fresh DevTools data)
  void updateCachedAttributes(
    String objectId,
    List<WidgetAttribute> attributes,
  ) {
    _nodeAttributeCache[objectId] = attributes;
    _log('Updated cache for $objectId with ${attributes.length} attributes');
  }

  /// Get comprehensive widget property values for any widget
  /// This is the main method to extract all properties including:
  /// - Text widget: string value
  /// - SizedBox: width and height
  /// - Container: width, height, color, padding, margin
  /// - Icon: icon data
  /// - Image: source and dimensions
  /// - Any other widget: common properties
  Future<List<WidgetAttribute>> getWidgetProperties(
    String objectId,
    String? widgetType, {
    bool useCache = false,
  }) async {
    try {
      print('🔍 Getting properties for widget: $widgetType (ID: $objectId)');

      if (useCache) {
        // First try to get from cache
        final cachedAttributes = getCachedAttributes(objectId);

        try {
          if (cachedAttributes != null && cachedAttributes.isNotEmpty) {
            print(
              '🔍 ✅ Found cached attributes: ${cachedAttributes.length} properties',
            );
            return cachedAttributes;
          }
        } catch (e) {
          print('🔍 ❌ Error getting cached attributes: $e');
        }
      }

      // Get detailed properties from inspector
      final properties = await getWidgetDetails(objectId);
      if (properties == null) {
        print('🔍 ❌ Failed to get widget details');
        return [];
      }

      print('🔍 Raw properties: $properties');

      // Extract structured attributes based on widget type
      final attributes = extractAttributesFromProperties(
        properties,
        widgetType,
      );

      // Cache the results for future use
      _nodeAttributeCache[objectId] = attributes;

      print(
        '🔍 ✅ Extracted ${attributes.length} attributes: ${attributes.map((a) => '${a.name}=${a.label}').join(', ')}',
      );
      return attributes;
    } catch (e, stackTrace) {
      print('🔍 ❌ Error getting widget properties: $e');
      print('🔍 ❌ Stack trace: $stackTrace');
      return [];
    }
  }

  /// Get specific property value from a widget
  /// Example: getWidgetPropertyValue(objectId, 'width') for SizedBox width
  ///          getWidgetPropertyValue(objectId, 'data') for Text content
  Future<dynamic> getWidgetPropertyValue(
    String objectId,
    String propertyName,
    String? widgetType,
  ) async {
    final attributes = await getWidgetProperties(objectId, widgetType);

    for (final attribute in attributes) {
      if (attribute.name == propertyName) {
        return attribute.value;
      }
    }

    return null;
  }

  /// Batch get property values for multiple widgets
  Future<Map<String, List<WidgetAttribute>>> getBatchWidgetProperties(
    List<WidgetTreeNode> nodes,
  ) async {
    _checkDisposed();
    final results = <String, List<WidgetAttribute>>{};
    final objectIds = nodes
        .where((n) => n.objectId != null)
        .map((n) => n.objectId!)
        .toList();

    // Process in batches to avoid overwhelming the inspector
    for (int i = 0; i < objectIds.length; i += _config.batchSize) {
      final batch = objectIds.skip(i).take(_config.batchSize);
      final batchResults = await Future.wait(
        batch.map((id) => getWidgetProperties(id, null)),
      );

      for (int j = 0; j < batch.length; j++) {
        results[batch.elementAt(j)] = batchResults[j];
      }

      // Small delay between batches
      if (i + _config.batchSize < objectIds.length) {
        await Future.delayed(const Duration(milliseconds: 100));
      }
    }

    return results;
  }

  /// Example method demonstrating how to extract specific widget values
  /// This shows practical usage of the property extraction system
  Future<void> demonstratePropertyExtraction() async {
    try {
      print('🎯 === Widget Property Extraction Demo ===');

      // Get the widget tree
      final rootNode = await getRootWidgetSummaryTree();
      if (rootNode == null) {
        print('🎯 ❌ Could not get widget tree');
        return;
      }

      // Find specific widgets and extract their properties
      await _findAndExtractProperties(rootNode);
    } catch (e) {
      print('🎯 ❌ Demo failed: $e');
    }
  }

  /// Recursively find widgets and extract their properties
  Future<void> _findAndExtractProperties(WidgetTreeNode node) async {
    final widgetType = node.widgetRuntimeType?.toLowerCase() ?? '';

    // Extract properties for different widget types
    if (widgetType.contains('text') && node.objectId != null) {
      final textValue = await getWidgetPropertyValue(
        node.objectId!,
        'data',
        'Text',
      );
      if (textValue != null) {
        print('🎯 Found Text widget with value: "$textValue"');
      }
    }

    if (widgetType.contains('sizedbox') && node.objectId != null) {
      final width = await getWidgetPropertyValue(
        node.objectId!,
        'width',
        'SizedBox',
      );
      final height = await getWidgetPropertyValue(
        node.objectId!,
        'height',
        'SizedBox',
      );
      print('🎯 Found SizedBox widget - Width: $width, Height: $height');
    }

    if (widgetType.contains('container') && node.objectId != null) {
      final properties = await getWidgetProperties(node.objectId!, 'Container');
      print('🎯 Found Container widget with properties:');
      for (final prop in properties) {
        print('🎯   ${prop.name}: ${prop.label}');
      }
    }

    // Recursively check children
    for (final child in node.children) {
      await _findAndExtractProperties(child);
    }
  }

  /// Extract attributes from detailed properties based on widget type
  List<WidgetAttribute> extractAttributesFromProperties(
    List<Map<String, dynamic>> properties,
    String? widgetType,
  ) {
    final attributes = <WidgetAttribute>[];
    final type = widgetType?.toLowerCase() ?? '';

    print(
      '🔍 Extracting attributes from ${properties.length} properties for type: $type',
    );

    // Convert the DevTools diagnostic format to a flat map for easier processing
    final flatProperties = <String, dynamic>{};
    for (final prop in properties) {
      final name = prop['name'] as String?;
      final value = prop['value'];
      final description = prop['description'];

      if (name != null) {
        // Use the actual value if available, otherwise use description
        flatProperties[name] = value ?? description;
      }
    }

    print('🔍 Flattened properties: ${flatProperties.keys.toList()}');

    // Extract based on widget type
    if (type.contains('text')) {
      _extractTextWidgetAttributes(flatProperties, attributes);
    } else if (type.contains('sizedbox')) {
      _extractSizedBoxAttributes(flatProperties, attributes);
    } else if (type.contains('container')) {
      _extractContainerAttributes(flatProperties, attributes);
    } else if (type.contains('padding')) {
      _extractPaddingAttributes(flatProperties, attributes);
    } else if (type.contains('expanded') || type.contains('flexible')) {
      _extractFlexibleAttributes(flatProperties, attributes);
    } else if (type.contains('positioned')) {
      _extractPositionedAttributes(flatProperties, attributes);
    } else if (type.contains('icon')) {
      _extractIconWidgetAttributes(flatProperties, attributes);
    } else if (type.contains('button')) {
      _extractButtonWidgetAttributes(flatProperties, attributes);
    } else if (type.contains('field')) {
      _extractTextFieldAttributes(flatProperties, attributes);
    } else if (type.contains('image')) {
      _extractImageAttributes(flatProperties, attributes);
    } else {
      _extractGenericAttributes(flatProperties, attributes);
    }

    print(
      '🔍 Extracted ${attributes.length} attributes: ${attributes.map((a) => '${a.name}=${a.label}').join(', ')}',
    );
    return attributes;
  }

  /// Extract attributes for Text widgets
  void _extractTextWidgetAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Look for text content in various property paths
    final textPaths = ['data', 'text', 'textSpan.text', 'child.data'];

    for (final path in textPaths) {
      final value = _getNestedProperty(properties, path);
      if (value != null && value.toString().isNotEmpty) {
        attributes.add(
          WidgetAttribute(
            name: 'data',
            label: "'$value'",
            type: 'String',
            value: value,
          ),
        );
        break; // Only need the first match
      }
    }

    // Extract style information if available
    final style = _getNestedProperty(properties, 'style');
    if (style is Map) {
      final fontSize = style['fontSize'];
      final color = style['color'];
      if (fontSize != null) {
        attributes.add(
          WidgetAttribute(
            name: 'fontSize',
            label: fontSize.toString(),
            type: 'double',
            value: fontSize,
          ),
        );
      }
      if (color != null) {
        attributes.add(
          WidgetAttribute(
            name: 'color',
            label: color.toString(),
            type: 'Color',
            value: color,
          ),
        );
      }
    }
  }

  /// Extract attributes for Icon widgets
  void _extractIconWidgetAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final iconPaths = ['icon', 'iconData', 'data'];

    for (final path in iconPaths) {
      final value = _getNestedProperty(properties, path);
      if (value != null) {
        String label = value.toString();
        // Clean up icon representation
        if (label.contains('IconData')) {
          // Extract meaningful icon name if possible
          final match = RegExp(r'Icons\.([a-zA-Z_]+)').firstMatch(label);
          if (match != null) {
            label = 'Icons.${match.group(1)}';
          }
        }

        attributes.add(
          WidgetAttribute(
            name: 'icon',
            label: label,
            type: 'IconData',
            value: value,
          ),
        );
        break;
      }
    }
  }

  /// Extract attributes for Button widgets
  void _extractButtonWidgetAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Look for button text in child widgets
    final childPaths = ['child.data', 'child.text', 'child.child.data'];

    for (final path in childPaths) {
      final value = _getNestedProperty(properties, path);
      if (value != null && value.toString().isNotEmpty) {
        attributes.add(
          WidgetAttribute(
            name: 'child',
            label: "'$value'",
            type: 'String',
            value: value,
          ),
        );
        break;
      }
    }
  }

  /// Extract attributes for TextField widgets
  void _extractTextFieldAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final hintText = _getNestedProperty(properties, 'decoration.hintText');
    final labelText = _getNestedProperty(properties, 'decoration.labelText');
    final value = _getNestedProperty(properties, 'controller.text');

    if (hintText != null) {
      attributes.add(
        WidgetAttribute(
          name: 'hintText',
          label: "'$hintText'",
          type: 'String',
          value: hintText,
        ),
      );
    }

    if (labelText != null) {
      attributes.add(
        WidgetAttribute(
          name: 'labelText',
          label: "'$labelText'",
          type: 'String',
          value: labelText,
        ),
      );
    }

    if (value != null && value.toString().isNotEmpty) {
      attributes.add(
        WidgetAttribute(
          name: 'value',
          label: "'$value'",
          type: 'String',
          value: value,
        ),
      );
    }
  }

  /// Extract attributes for SizedBox widgets
  void _extractSizedBoxAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Look for width and height properties
    final width =
        _getNestedProperty(properties, 'width') ??
        _getNestedProperty(properties, 'size.width') ??
        _getNestedProperty(properties, 'constraints.width');

    final height =
        _getNestedProperty(properties, 'height') ??
        _getNestedProperty(properties, 'size.height') ??
        _getNestedProperty(properties, 'constraints.height');

    if (width != null) {
      attributes.add(
        WidgetAttribute(
          name: 'width',
          label: _formatDimensionValue(width),
          type: 'double',
          value: width,
        ),
      );
    }

    if (height != null) {
      attributes.add(
        WidgetAttribute(
          name: 'height',
          label: _formatDimensionValue(height),
          type: 'double',
          value: height,
        ),
      );
    }

    // Extract child information if available
    final child = _getNestedProperty(properties, 'child');
    if (child != null) {
      attributes.add(
        WidgetAttribute(
          name: 'hasChild',
          label: 'true',
          type: 'bool',
          value: true,
        ),
      );
    }
  }

  /// Extract attributes for Container widgets
  void _extractContainerAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Container dimensions
    final width =
        _getNestedProperty(properties, 'constraints.width') ??
        _getNestedProperty(properties, 'width');
    final height =
        _getNestedProperty(properties, 'constraints.height') ??
        _getNestedProperty(properties, 'height');

    if (width != null) {
      attributes.add(
        WidgetAttribute(
          name: 'width',
          label: _formatDimensionValue(width),
          type: 'double',
          value: width,
        ),
      );
    }

    if (height != null) {
      attributes.add(
        WidgetAttribute(
          name: 'height',
          label: _formatDimensionValue(height),
          type: 'double',
          value: height,
        ),
      );
    }

    // Container color
    final color =
        _getNestedProperty(properties, 'color') ??
        _getNestedProperty(properties, 'decoration.color');
    if (color != null) {
      attributes.add(
        WidgetAttribute(
          name: 'color',
          label: _formatColorValue(color),
          type: 'Color',
          value: color,
        ),
      );
    }

    // Padding
    final padding = _getNestedProperty(properties, 'padding');
    if (padding != null) {
      attributes.add(
        WidgetAttribute(
          name: 'padding',
          label: _formatPaddingValue(padding),
          type: 'EdgeInsets',
          value: padding,
        ),
      );
    }

    // Margin
    final margin = _getNestedProperty(properties, 'margin');
    if (margin != null) {
      attributes.add(
        WidgetAttribute(
          name: 'margin',
          label: _formatPaddingValue(margin),
          type: 'EdgeInsets',
          value: margin,
        ),
      );
    }
  }

  /// Extract attributes for Padding widgets
  void _extractPaddingAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final padding =
        _getNestedProperty(properties, 'padding') ??
        _getNestedProperty(properties, 'insets');

    if (padding != null) {
      attributes.add(
        WidgetAttribute(
          name: 'padding',
          label: _formatPaddingValue(padding),
          type: 'EdgeInsets',
          value: padding,
        ),
      );
    }
  }

  /// Extract attributes for Flexible/Expanded widgets
  void _extractFlexibleAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final flex = _getNestedProperty(properties, 'flex');
    if (flex != null) {
      attributes.add(
        WidgetAttribute(
          name: 'flex',
          label: flex.toString(),
          type: 'int',
          value: flex,
        ),
      );
    }

    final fit = _getNestedProperty(properties, 'fit');
    if (fit != null) {
      attributes.add(
        WidgetAttribute(
          name: 'fit',
          label: fit.toString(),
          type: 'FlexFit',
          value: fit,
        ),
      );
    }
  }

  /// Extract attributes for Positioned widgets
  void _extractPositionedAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    final positionProperties = [
      'left',
      'top',
      'right',
      'bottom',
      'width',
      'height',
    ];

    for (final prop in positionProperties) {
      final value = _getNestedProperty(properties, prop);
      if (value != null) {
        attributes.add(
          WidgetAttribute(
            name: prop,
            label: _formatDimensionValue(value),
            type: 'double',
            value: value,
          ),
        );
      }
    }
  }

  /// Extract attributes for Image widgets
  void _extractImageAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Image source
    final image =
        _getNestedProperty(properties, 'image') ??
        _getNestedProperty(properties, 'src') ??
        _getNestedProperty(properties, 'asset');

    if (image != null) {
      String imageLabel = image.toString();

      // Extract asset path or network URL
      if (imageLabel.contains('AssetImage')) {
        final assetMatch = RegExp(r'"([^"]+)"').firstMatch(imageLabel);
        if (assetMatch != null) {
          imageLabel = 'Asset: ${assetMatch.group(1)}';
        }
      } else if (imageLabel.contains('NetworkImage')) {
        final networkMatch = RegExp(r'"([^"]+)"').firstMatch(imageLabel);
        if (networkMatch != null) {
          imageLabel = 'Network: ${networkMatch.group(1)}';
        }
      }

      attributes.add(
        WidgetAttribute(
          name: 'image',
          label: imageLabel,
          type: 'ImageProvider',
          value: image,
        ),
      );
    }

    // Image dimensions
    final width = _getNestedProperty(properties, 'width');
    final height = _getNestedProperty(properties, 'height');

    if (width != null) {
      attributes.add(
        WidgetAttribute(
          name: 'width',
          label: _formatDimensionValue(width),
          type: 'double',
          value: width,
        ),
      );
    }

    if (height != null) {
      attributes.add(
        WidgetAttribute(
          name: 'height',
          label: _formatDimensionValue(height),
          type: 'double',
          value: height,
        ),
      );
    }

    // Fit property
    final fit = _getNestedProperty(properties, 'fit');
    if (fit != null) {
      attributes.add(
        WidgetAttribute(
          name: 'fit',
          label: fit.toString(),
          type: 'BoxFit',
          value: fit,
        ),
      );
    }
  }

  /// Extract generic attributes for any widget
  void _extractGenericAttributes(
    Map<String, dynamic> properties,
    List<WidgetAttribute> attributes,
  ) {
    // Common property names to extract
    final commonProps = ['data', 'text', 'value', 'title', 'tooltip', 'label'];

    for (final prop in commonProps) {
      final value = _getNestedProperty(properties, prop);
      if (value != null && value.toString().isNotEmpty) {
        attributes.add(
          WidgetAttribute(
            name: prop,
            label: "'$value'",
            type: 'String',
            value: value,
          ),
        );
      }
    }
  }

  /// Helper method to format dimension values
  String _formatDimensionValue(dynamic value) {
    if (value == null) return 'null';
    if (value is double) {
      if (value == double.infinity) return 'double.infinity';
      if (value == double.negativeInfinity) return 'double.negativeInfinity';
      return value.toStringAsFixed(1);
    }
    if (value is int) return value.toString();
    return value.toString();
  }

  /// Helper method to format color values
  String _formatColorValue(dynamic color) {
    if (color == null) return 'null';
    final colorStr = color.toString();

    // Extract color value if it's in Color(0xXXXXXXXX) format
    final colorMatch = RegExp(
      r'Color\(0x([0-9a-fA-F]+)\)',
    ).firstMatch(colorStr);
    if (colorMatch != null) {
      return 'Color(0x${colorMatch.group(1)})';
    }

    return colorStr;
  }

  /// Helper method to format padding/margin values
  String _formatPaddingValue(dynamic padding) {
    if (padding == null) return 'null';
    final paddingStr = padding.toString();

    // Common EdgeInsets patterns
    if (paddingStr.contains('EdgeInsets.all')) {
      final allMatch = RegExp(r'all\(([^)]+)\)').firstMatch(paddingStr);
      if (allMatch != null) {
        return 'EdgeInsets.all(${allMatch.group(1)})';
      }
    } else if (paddingStr.contains('EdgeInsets.only')) {
      return paddingStr;
    } else if (paddingStr.contains('EdgeInsets.symmetric')) {
      return paddingStr;
    }

    return paddingStr;
  }

  /// Get nested property from a map using dot notation
  dynamic _getNestedProperty(Map<String, dynamic> properties, String path) {
    final parts = path.split('.');
    dynamic current = properties;

    for (final part in parts) {
      if (current is Map<String, dynamic> && current.containsKey(part)) {
        current = current[part];
      } else {
        return null;
      }
    }

    return current;
  }

  /// Get details for a specific widget
  Future<List<Map<String, dynamic>>?> getWidgetDetails(String objectId) async {
    print('🔧 Getting widget details for objectId: $objectId');
    final response = await invokeInspector(
      method: 'getProperties',
      args: {'objectGroup': _getObjectGroup(), 'arg': objectId},
    );

    if (response?.json == null) {
      print('🔧 ❌ No response from getProperties');
      return null;
    }

    print('🔧 getWidgetDetails full response: ${response?.json}');

    // Extract the result array from the response
    final result = response!.json!['result'];
    if (result is List) {
      print('🔧 ✅ Extracted ${result.length} properties from result array');
      return result.cast<Map<String, dynamic>>();
    } else {
      print('🔧 ❌ Result is not a list: $result');
      return null;
    }
  }

  /// Get children for a widget (for lazy loading)
  Future<List<WidgetTreeNode>> getChildren(String objectId) async {
    final response = await invokeInspector(
      method: 'getChildren',
      args: {
        'objectGroup': _getObjectGroup(),
        'arg': objectId,
      }, // Fixed: 'arg' instead of 'objectId'
    );

    if (response?.json == null) return [];

    try {
      final json = response!.json!;
      return (json as List<dynamic>)
          .map((e) => WidgetTreeNode.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('Failed to parse children: $e');
    }
    return [];
  }

  /// Select a widget in the inspector (highlights it in the UI)
  Future<void> selectWidget(String objectId) async {
    _checkDisposed();
    await invokeInspector(
      method: 'setSelectionById',
      args: {
        'objectGroup': _getObjectGroup(),
        'arg': objectId,
      }, // Fixed: 'arg' instead of 'id'
    );
    _emitEvent(WidgetSelectedEvent(objectId));
  }

  /// Toggle between full and summary widget tree
  void toggleWidgetTreeMode() {
    _config = InspectorConfig(
      connectionTimeout: _config.connectionTimeout,
      requestTimeout: _config.requestTimeout,
      maxRetries: _config.maxRetries,
      cacheExpiry: _config.cacheExpiry,
      enableLogging: _config.enableLogging,
      batchSize: _config.batchSize,
      useFullWidgetTree: !_config.useFullWidgetTree, // Toggle the boolean
    );

    _log(
      'Toggling widget tree mode to: ${_config.useFullWidgetTree ? 'full' : 'summary'}',
    );

    // Clear cache when switching modes
    clearWidgetTreeCache();
  }

  /// Get current widget tree mode
  bool get isUsingFullWidgetTree => _config.useFullWidgetTree;

  /// Clear widget tree cache
  void clearWidgetTreeCache() {
    _widgetCache.clear();
    _propertiesCache.clear();
    _cacheTimestamps.clear();
    _nodeAttributeCache.clear();
    _log('Widget tree cache cleared (both summary and full tree caches)');
  }

  /// Get the currently selected widget
  Future<WidgetTreeNode?> getSelectedWidget() async {
    final response = await invokeInspector(
      method: 'getSelectedSummaryWidget',
      args: {
        'objectGroup': _getObjectGroup(),
        'arg': null,
      }, // Fixed: 'arg' instead of 'previousSelectionId'
    );

    if (response?.json == null) return null;

    try {
      final json = response!.json!;
      return WidgetTreeNode.fromJson(json);
    } catch (e) {
      print('Failed to parse selected widget: $e');
      return null;
    }
  }

  /// Dispose of the current object group to free memory
  Future<void> disposeGroup() async {
    if (_currentObjectGroup != null) {
      try {
        await invokeInspector(
          method: 'disposeGroup',
          args: {'objectGroup': _currentObjectGroup!},
        );
        _log('Object group disposed: ${_currentObjectGroup}');
      } catch (e) {
        _logError('Failed to dispose object group', e);
      } finally {
        _currentObjectGroup = null;
      }
    }
  }

  /// Check if the inspector is available
  Future<bool> isInspectorAvailable() async {
    try {
      print('Checking if widget inspector is available...');

      // First check if we can list service extensions
      await getVM(); // Get VM info
      final isolateId = await getFirstFlutterIsolateId();
      if (isolateId == null) {
        print('No Flutter isolate found');
        return false;
      }

      // Get the isolate and check its service extensions
      final isolate = await _service!.getIsolate(isolateId);
      final extensions = isolate.extensionRPCs ?? [];
      print('Available service extensions: $extensions');

      final hasInspectorExtensions = extensions.any(
        (ext) => ext.startsWith('ext.flutter.inspector'),
      );
      print('Has inspector extensions: $hasInspectorExtensions');

      if (!hasInspectorExtensions) {
        return false;
      }

      // Now try to call isWidgetTreeReady
      final response = await invokeInspector(method: 'isWidgetTreeReady');
      final result = (response?.json as Map)['result'];
      print('isWidgetTreeReady result: ${response?.json}');
      return result;
    } catch (e) {
      print('Error checking inspector availability: $e');
      return false;
    }
  }

  /// Get widget source location from a node (using embedded creationLocation)
  SourceLocation? getWidgetSourceLocationFromNode(WidgetTreeNode node) {
    final creationLocation = node.creationLocation;
    if (creationLocation == null) return null;

    return SourceLocation(
      file: creationLocation.file,
      line: creationLocation.line,
      column: creationLocation.column,
      endLine: null,
      endColumn: null,
    );
  }

  /// Get widget source location by finding the widget in the tree and using creationLocation
  Future<SourceLocation?> getWidgetSourceLocation(String objectId) async {
    print(
      '🔍 InspectorService: Getting source location for objectId: $objectId',
    );
    try {
      // Get the root widget tree to find the widget
      final rootWidget = await getRootWidgetSummaryTree();
      if (rootWidget == null) {
        print('🔍 ❌ Could not get root widget tree');
        return null;
      }

      // Find the widget in the tree
      final widgetNode = _findWidgetInTree(rootWidget, objectId);
      if (widgetNode == null) {
        print('🔍 ❌ Widget not found in tree: $objectId');
        return null;
      }

      // Use the creationLocation from the widget node
      return getWidgetSourceLocationFromNode(widgetNode);
    } catch (e) {
      print('🔍 ❌ Error getting source location: $e');
    }
    return null;
  }

  /// Find a widget in the tree by object ID
  WidgetTreeNode? _findWidgetInTree(WidgetTreeNode root, String objectId) {
    if (root.objectId == objectId) {
      return root;
    }

    for (final child in root.children) {
      final found = _findWidgetInTree(child, objectId);
      if (found != null) {
        return found;
      }
    }

    return null;
  }

  /// Get the actual source code for a widget from CreationLocation
  Future<String?> getWidgetSourceCodeFromCreation(
    CreationLocation location,
  ) async {
    try {
      final file = File(location.file);
      if (await file.exists()) {
        final content = await file.readAsString();
        final lines = content.split('\n');

        // Extract the relevant lines for the widget
        final startLine = math.max(
          0,
          location.line - 5,
        ); // Include some context
        final endLine = math.min(
          location.line + 20,
          lines.length,
        ); // Add context

        if (startLine < lines.length) {
          return lines.sublist(startLine, endLine).join('\n');
        }
      }
    } catch (e) {
      print('Error reading source code from creation location: $e');
    }
    return null;
  }

  /// Get the actual source code for a widget (legacy method)
  Future<String?> getWidgetSourceCode(SourceLocation location) async {
    try {
      final file = File(location.file);
      if (await file.exists()) {
        final content = await file.readAsString();
        final lines = content.split('\n');

        // Extract the relevant lines for the widget
        final startLine = math.max(
          0,
          location.line - 5,
        ); // Include some context
        final endLine = location.endLine != null
            ? location.endLine! + 5
            : math.min(
                location.line + 20,
                lines.length,
              ); // Estimate or add context

        if (startLine < lines.length) {
          return lines
              .sublist(startLine, math.min(endLine, lines.length))
              .join('\n');
        }
      }
    } catch (e) {
      print('Error reading source code: $e');
    }
    return null;
  }

  /// Find required imports from a Dart file
  Future<List<String>> findRequiredImports(String filePath) async {
    final imports = <String>[];

    try {
      final file = File(filePath);
      if (await file.exists()) {
        final content = await file.readAsString();
        final importPattern = RegExp(r'import\s+.([^.]+).');
        final matches = importPattern.allMatches(content);

        for (final match in matches) {
          final importPath = match.group(1);
          if (importPath != null) {
            imports.add(importPath);
          }
        }
      }
    } catch (e) {
      print('Error reading imports: $e');
    }

    return imports;
  }

  /// Debug method to print widget tree structure
  void debugPrintWidgetTree(WidgetTreeNode node, [int indent = 0]) {
    final prefix = '  ' * indent;
    final name = node.displayName;
    final type = node.effectiveWidgetType ?? 'Unknown';
    final userProject = node.isFromUserProject ? '👤' : '🏗️';
    final dependencies = node.hasPotentialDependencies ? '🔗' : '';
    final stateful = node.stateful == true
        ? '🔄'
        : node.stateful == false
        ? '🔒'
        : '';
    final location = node.creationLocation != null
        ? '📍${node.creationLocation!.file.split('/').last}:${node.creationLocation!.line}'
        : '';

    print('$prefix$name ($type) $userProject$dependencies$stateful $location');

    // Print creation location if available and from user project
    if (node.creationLocation != null && node.isFromUserProject) {
      print('$prefix  📁 ${node.creationLocation}');
    }

    // Recursively print children
    for (final child in node.children) {
      debugPrintWidgetTree(child, indent + 1);
    }
  }

  void dispose() {
    if (_disposed) return;
    _disposed = true;

    _log('Disposing InspectorService');

    // Cancel all subscriptions
    for (final subscription in _subscriptions) {
      subscription.cancel();
    }
    _subscriptions.clear();

    // Dispose VM service
    _service?.dispose();

    // Clear all caches
    _widgetCache.clear();
    _propertiesCache.clear();
    _cacheTimestamps.clear();
    _nodeAttributeCache.clear(); // Add missing cache cleanup

    // Close controllers
    if (!_stateController.isClosed) {
      _stateController.close();
    }
    if (!_eventController.isClosed) {
      _eventController.close();
    }

    // Dispose object group
    disposeGroup();
  }
}

/// Represents source code location information
class SourceLocation {
  final String file;
  final int line;
  final int column;
  final int? endLine;
  final int? endColumn;

  SourceLocation({
    required this.file,
    required this.line,
    required this.column,
    this.endLine,
    this.endColumn,
  });

  factory SourceLocation.fromJson(Map<String, dynamic> json) {
    return SourceLocation(
      file: json['file'] as String? ?? json['uri'] as String? ?? '',
      line: json['line'] as int? ?? json['lineNumber'] as int? ?? 0,
      column: json['column'] as int? ?? json['columnNumber'] as int? ?? 0,
      endLine: json['endLine'] as int?,
      endColumn: json['endColumn'] as int?,
    );
  }
}
