import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../core/logging/logging.dart';
import '../domain/entities/ui_element.dart';

/// Service for UI automation including screen capture, view hierarchy, and gestures.
///
/// This service provides:
/// - View hierarchy extraction (accessibility tree)
/// - Screenshot capture
/// - Gesture automation (tap, swipe, input)
/// - Device listing and connection
///
/// Supports iOS, Android, macOS, and Web platforms using Maestro CLI
/// and platform-native tools (adb, simctl, screencapture).
class UIAutomationService with LoggerMixin {
  static const _defaultPollInterval = Duration(milliseconds: 500);

  /// Path to Maestro CLI (can be overridden)
  String _maestroPath = 'maestro';

  String? _currentDeviceId;
  bool _isPolling = false;
  StreamController<UIScreen>? _screenController;

  /// Get the currently connected device ID
  String? get currentDeviceId => _currentDeviceId;

  /// Check if Maestro CLI is available on the system
  Future<bool> isMaestroAvailable() async {
    try {
      // Check for Maestro CLI first (preferred method)
      final maestroResult = await Process.run('which', ['maestro']);
      if (maestroResult.exitCode == 0) {
        _maestroPath = (maestroResult.stdout as String).trim();
        logger.info('Found Maestro CLI at: $_maestroPath');
        return true;
      }

      // Check common Maestro installation paths
      final commonPaths = [
        '${Platform.environment['HOME']}/.maestro/bin/maestro',
        '/usr/local/bin/maestro',
      ];

      for (final path in commonPaths) {
        if (await File(path).exists()) {
          _maestroPath = path;
          logger.info('Found Maestro CLI at: $_maestroPath');
          return true;
        }
      }

      logger.warn('Maestro CLI not found');
      return false;
    } catch (e) {
      logger.error('Error checking Maestro availability', e);
      return false;
    }
  }

  /// Backwards compatibility alias for isMaestroAvailable
  @Deprecated('Use isMaestroAvailable instead')
  Future<bool> isInspectorAvailable() => isMaestroAvailable();

  /// Get the view hierarchy from the connected device using Maestro CLI
  Future<String?> getViewHierarchy(String deviceId) async {
    try {
      final result = await _fetchHierarchyViaMaestro(deviceId);
      return result;
    } catch (e) {
      logger.error('Error getting view hierarchy', e);
      return null;
    }
  }

  /// Fetch hierarchy using Maestro CLI (works for iOS, Android, and Web)
  Future<String?> _fetchHierarchyViaMaestro(String deviceId) async {
    try {
      // Build arguments for maestro hierarchy command
      final args = ['hierarchy', '--compact', '--no-ansi'];

      // For web, we might need different handling
      final isWeb = deviceId == 'chromium' || deviceId.contains('web');

      logger.info('Fetching hierarchy via Maestro', {
        'deviceId': deviceId,
        'isWeb': isWeb,
      });

      final result =
          await Process.run(
            _maestroPath,
            args,
            stdoutEncoding: utf8,
            stderrEncoding: utf8,
            environment: {
              ...Platform.environment,
              // Suppress Maestro warnings in output
              'MAESTRO_DISABLE_WARNINGS': 'true',
            },
          ).timeout(
            const Duration(seconds: 30),
            onTimeout: () => ProcessResult(-1, -1, '', 'Timeout'),
          );

      if (result.exitCode == 0) {
        final output = result.stdout as String;
        // Filter out warning lines and extract CSV data
        final lines = output.split('\n');
        final csvLines = <String>[];
        bool foundHeader = false;

        for (final line in lines) {
          // Skip warning lines
          if (line.startsWith('WARNING:') || line.contains('java.lang')) {
            continue;
          }
          // Skip running info line
          if (line.startsWith('Running on')) {
            continue;
          }
          // Skip "None:" line
          if (line.trim() == 'None:') {
            continue;
          }
          // Check for header
          if (line.startsWith('element_num,')) {
            foundHeader = true;
            continue; // Skip header row
          }
          // Add data lines after header
          if (foundHeader && line.trim().isNotEmpty) {
            csvLines.add(line);
          }
        }

        return csvLines.join('\n');
      } else {
        logger.warn('Maestro hierarchy failed', {
          'exitCode': result.exitCode,
          'stderr': result.stderr,
        });
        return null;
      }
    } catch (e) {
      logger.error('Error fetching hierarchy via Maestro', e);
      return null;
    }
  }

  /// Parse the Maestro hierarchy CSV format into UIElements
  List<UIElement> parseViewHierarchy(String hierarchyData) {
    final elements = <UIElement>[];
    final idCounts = <String, int>{};
    final textCounts = <String, int>{};

    try {
      // Try parsing as JSON first (for backward compatibility)
      if (hierarchyData.trim().startsWith('{') ||
          hierarchyData.trim().startsWith('[')) {
        return _parseJsonHierarchy(hierarchyData);
      }

      // Parse Maestro CSV format:
      // element_num,depth,bounds,attributes,parent_num
      // e.g.: 21,13,"[131,76][270,103]","accessibilityText=Vivek Yadav; enabled=true",18
      final lines = hierarchyData.split('\n');

      for (final line in lines) {
        if (line.trim().isEmpty) continue;

        final element = _parseMaestroCsvLine(line, idCounts, textCounts);
        if (element != null) {
          elements.add(element);
        }
      }
    } catch (e) {
      logger.error('Error parsing view hierarchy', e);
    }

    return elements;
  }

  /// Parse a single line from Maestro CSV format
  UIElement? _parseMaestroCsvLine(
    String line,
    Map<String, int> idCounts,
    Map<String, int> textCounts,
  ) {
    try {
      // Maestro CSV format: element_num,depth,bounds,attributes,parent_num
      // e.g.: 21,13,"[131,76][270,103]","accessibilityText=Vivek Yadav; enabled=true",18
      final parts = _parseCSVLine(line);
      if (parts.length < 4) return null;

      final elementNum = parts[0];
      final depth = int.tryParse(parts[1]) ?? 0;
      final boundsStr = parts[2];
      final attributesStr = parts[3];

      // Parse bounds
      final bounds = UIElementBounds.parse(boundsStr);

      // Parse attributes (semicolon-separated key=value pairs)
      final attributes = _parseAttributes(attributesStr);

      // Extract common attributes
      final text = attributes['text'];
      final resourceId = attributes['resource-id'] ?? attributes['id'];
      final hintText = attributes['hintText'] ?? attributes['hint'];
      final accessibilityText =
          attributes['accessibilityText'] ??
          attributes['accessibilityLabel'] ??
          attributes['content-desc'];

      // Parse boolean attributes
      final enabled = _parseBool(attributes['enabled']);
      final focused = _parseBool(attributes['focused']);
      final checked = _parseBool(attributes['checked']);
      final selected = _parseBool(attributes['selected']);
      final clickable = _parseBool(attributes['clickable']);

      // Skip elements without meaningful content (except if they have bounds)
      if (text == null &&
          resourceId == null &&
          hintText == null &&
          accessibilityText == null &&
          bounds == null) {
        return null;
      }

      // Calculate indices for duplicates
      int? textIndex;
      if (text != null) {
        textCounts[text] = (textCounts[text] ?? 0) + 1;
        if (textCounts[text]! > 1) {
          textIndex = textCounts[text]! - 1;
        }
      }

      int? resourceIdIndex;
      if (resourceId != null) {
        idCounts[resourceId] = (idCounts[resourceId] ?? 0) + 1;
        if (idCounts[resourceId]! > 1) {
          resourceIdIndex = idCounts[resourceId]! - 1;
        }
      }

      // Generate stable ID
      final id = _generateElementId(
        resourceId,
        resourceIdIndex,
        text ?? accessibilityText,
        textIndex,
        bounds,
      );

      return UIElement(
        id: id,
        bounds: bounds,
        resourceId: resourceId,
        resourceIdIndex: resourceIdIndex,
        text: text,
        hintText: hintText,
        accessibilityText: accessibilityText,
        textIndex: textIndex,
        elementType: attributes['type'] ?? attributes['class'],
        clickable: clickable,
        enabled: enabled,
        focused: focused,
        checked: checked,
        selected: selected,
        rawAttributes: attributes,
        depth: depth,
        elementNum: int.tryParse(elementNum),
      );
    } catch (e) {
      logger.warn('Failed to parse Maestro CSV line', {
        'line': line,
        'error': e,
      });
      return null;
    }
  }

  /// Parse Maestro attribute string (semicolon-separated key=value pairs)
  Map<String, String> _parseAttributes(String attributesStr) {
    final attributes = <String, String>{};

    if (attributesStr.isEmpty) return attributes;

    // Split by semicolon, handling potential values that contain semicolons
    final pairs = attributesStr.split('; ');

    for (final pair in pairs) {
      final eqIndex = pair.indexOf('=');
      if (eqIndex > 0) {
        final key = pair.substring(0, eqIndex).trim();
        final value = pair.substring(eqIndex + 1).trim();
        attributes[key] = value;
      }
    }

    return attributes;
  }

  /// Parse boolean value from string
  bool? _parseBool(String? value) {
    if (value == null) return null;
    return value.toLowerCase() == 'true';
  }

  /// Parse JSON hierarchy format (backward compatibility)
  List<UIElement> _parseJsonHierarchy(String jsonData) {
    final elements = <UIElement>[];
    final idCounts = <String, int>{};
    final textCounts = <String, int>{};

    try {
      final decoded = json.decode(jsonData);

      if (decoded is List) {
        for (final item in decoded) {
          final element = _parseJsonElement(
            item as Map<String, dynamic>,
            idCounts,
            textCounts,
          );
          if (element != null) {
            elements.add(element);
          }
        }
      } else if (decoded is Map<String, dynamic>) {
        _parseJsonTree(decoded, elements, idCounts, textCounts);
      }
    } catch (e) {
      logger.error('Error parsing JSON hierarchy', e);
    }

    return elements;
  }

  void _parseJsonTree(
    Map<String, dynamic> node,
    List<UIElement> elements,
    Map<String, int> idCounts,
    Map<String, int> textCounts,
  ) {
    final element = _parseJsonElement(node, idCounts, textCounts);
    if (element != null) {
      elements.add(element);
    }

    final children = node['children'] as List<dynamic>?;
    if (children != null) {
      for (final child in children) {
        if (child is Map<String, dynamic>) {
          _parseJsonTree(child, elements, idCounts, textCounts);
        }
      }
    }
  }

  UIElement? _parseJsonElement(
    Map<String, dynamic> json,
    Map<String, int> idCounts,
    Map<String, int> textCounts,
  ) {
    try {
      final attributes = json['attributes'] as Map<String, dynamic>? ?? json;

      final text = _extractAttribute(attributes, ['text']);
      final resourceId = _extractAttribute(attributes, [
        'resource-id',
        'resourceId',
        'id',
        'accessibilityIdentifier',
      ]);
      final hintText = _extractAttribute(attributes, [
        'hintText',
        'hint',
        'placeholderValue',
        'placeholder',
      ]);
      final accessibilityText = _extractAttribute(attributes, [
        'accessibilityText',
        'content-desc',
        'accessibilityLabel',
        'aria-label',
      ]);
      final boundsStr = _extractAttribute(attributes, ['bounds']);
      final bounds = UIElementBounds.parse(boundsStr);

      if (text == null &&
          resourceId == null &&
          hintText == null &&
          accessibilityText == null) {
        if (bounds == null) return null;
      }

      int? textIndex;
      if (text != null) {
        textCounts[text] = (textCounts[text] ?? 0) + 1;
        if (textCounts[text]! > 1) {
          textIndex = textCounts[text]! - 1;
        }
      }

      int? resourceIdIndex;
      if (resourceId != null) {
        idCounts[resourceId] = (idCounts[resourceId] ?? 0) + 1;
        if (idCounts[resourceId]! > 1) {
          resourceIdIndex = idCounts[resourceId]! - 1;
        }
      }

      final id = _generateElementId(
        resourceId,
        resourceIdIndex,
        text,
        textIndex,
        bounds,
      );

      return UIElement(
        id: id,
        bounds: bounds,
        resourceId: resourceId,
        resourceIdIndex: resourceIdIndex,
        text: text,
        hintText: hintText,
        accessibilityText: accessibilityText,
        textIndex: textIndex,
        elementType: _extractAttribute(attributes, [
          'type',
          'class',
          'tagName',
        ]),
        clickable: _extractBoolAttribute(attributes, ['clickable']),
        enabled: _extractBoolAttribute(attributes, ['enabled']),
        focused: _extractBoolAttribute(attributes, ['focused']),
        checked: _extractBoolAttribute(attributes, ['checked']),
        selected: _extractBoolAttribute(attributes, ['selected']),
        rawAttributes: attributes.map((k, v) => MapEntry(k, v.toString())),
      );
    } catch (e) {
      logger.warn('Failed to parse JSON element', {'error': e});
      return null;
    }
  }

  String? _extractAttribute(Map<String, dynamic> attrs, List<String> keys) {
    for (final key in keys) {
      final value = attrs[key];
      if (value != null && value.toString().isNotEmpty) {
        return value.toString();
      }
    }
    return null;
  }

  bool? _extractBoolAttribute(Map<String, dynamic> attrs, List<String> keys) {
    for (final key in keys) {
      final value = attrs[key];
      if (value != null) {
        if (value is bool) return value;
        if (value is String) {
          return value.toLowerCase() == 'true';
        }
      }
    }
    return null;
  }

  String _generateElementId(
    String? resourceId,
    int? resourceIdIndex,
    String? text,
    int? textIndex,
    UIElementBounds? bounds,
  ) {
    final parts = <String>[];

    if (resourceId != null) {
      parts.add(resourceId);
      if (resourceIdIndex != null) parts.add(resourceIdIndex.toString());
    }

    if (text != null) {
      parts.add(text);
      if (textIndex != null) parts.add(textIndex.toString());
    }

    if (parts.isEmpty) {
      if (bounds != null) {
        return '${bounds.x},${bounds.y},${bounds.width},${bounds.height}';
      }
      return DateTime.now().microsecondsSinceEpoch.toString();
    }

    return parts.join('-');
  }

  /// Parse CSV line handling quoted values
  List<String> _parseCSVLine(String line) {
    final result = <String>[];
    var current = StringBuffer();
    var inQuotes = false;

    for (var i = 0; i < line.length; i++) {
      final char = line[i];

      if (char == '"') {
        inQuotes = !inQuotes;
      } else if (char == ',' && !inQuotes) {
        result.add(current.toString().trim());
        current = StringBuffer();
      } else {
        current.write(char);
      }
    }

    result.add(current.toString().trim());
    return result;
  }

  /// Take a screenshot from the device
  Future<Uint8List?> takeScreenshot(String deviceId) async {
    try {
      final platform = _detectPlatform(deviceId);

      switch (platform) {
        case UIPlatform.android:
          return await _takeAndroidScreenshot(deviceId);
        case UIPlatform.ios:
          return await _takeIosScreenshot(deviceId);
        case UIPlatform.macos:
          return await _takeMacOSScreenshot(deviceId);
        case UIPlatform.web:
          return await _takeWebScreenshot(deviceId);
        default:
          logger.warn('Unknown platform for device', {'deviceId': deviceId});
          return null;
      }
    } catch (e) {
      logger.error('Error taking screenshot', e);
      return null;
    }
  }

  /// Take screenshot from Android device via adb
  Future<Uint8List?> _takeAndroidScreenshot(String deviceId) async {
    try {
      final result = await Process.run(
        'adb',
        ['-s', deviceId, 'exec-out', 'screencap', '-p'],
        stdoutEncoding: null,
        stderrEncoding: utf8,
      );

      if (result.exitCode == 0) {
        final bytes = result.stdout as List<int>;
        return Uint8List.fromList(bytes);
      }
      return null;
    } catch (e) {
      logger.error('Error taking Android screenshot', e);
      return null;
    }
  }

  /// Take screenshot from iOS simulator via simctl
  Future<Uint8List?> _takeIosScreenshot(String deviceId) async {
    try {
      final tempDir = await Directory.systemTemp.createTemp('ios_screenshot');
      final screenshotPath = '${tempDir.path}/screenshot.png';

      final result = await Process.run(
        'xcrun',
        ['simctl', 'io', deviceId, 'screenshot', screenshotPath],
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      );

      if (result.exitCode == 0) {
        final file = File(screenshotPath);
        if (await file.exists()) {
          final bytes = await file.readAsBytes();
          await tempDir.delete(recursive: true);
          return bytes;
        }
      }

      await tempDir.delete(recursive: true);
      return null;
    } catch (e) {
      logger.error('Error taking iOS screenshot', e);
      return null;
    }
  }

  /// Take screenshot from macOS using screencapture command
  Future<Uint8List?> _takeMacOSScreenshot(String deviceId) async {
    try {
      final tempDir = await Directory.systemTemp.createTemp('macos_screenshot');
      final screenshotPath = '${tempDir.path}/screenshot.png';

      // Use screencapture command for macOS (-x removes click sound)
      final result = await Process.run(
        'screencapture',
        ['-x', screenshotPath],
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      );

      if (result.exitCode == 0) {
        final file = File(screenshotPath);
        if (await file.exists()) {
          final bytes = await file.readAsBytes();
          await tempDir.delete(recursive: true);
          logger.info('macOS screenshot captured successfully');
          return bytes;
        }
      }

      await tempDir.delete(recursive: true);
      return null;
    } catch (e) {
      logger.error('Error taking macOS screenshot', e);
      return null;
    }
  }

  /// Take screenshot from web browser using Maestro
  Future<Uint8List?> _takeWebScreenshot(String deviceId) async {
    try {
      // Create temp directory for screenshot
      final tempDir = await Directory.systemTemp.createTemp('web_screenshot');
      final screenshotPath = '${tempDir.path}/screenshot.png';

      // Create a temporary Maestro flow to take screenshot
      final flowFile = File('${tempDir.path}/screenshot.yaml');
      await flowFile.writeAsString('''
appId: chromium
---
- takeScreenshot: $screenshotPath
''');

      // Run Maestro to take screenshot
      final result =
          await Process.run(
            _maestroPath,
            ['test', flowFile.path, '--no-ansi'],
            stdoutEncoding: utf8,
            stderrEncoding: utf8,
          ).timeout(
            const Duration(seconds: 15),
            onTimeout: () => ProcessResult(-1, -1, '', 'Timeout'),
          );

      if (result.exitCode == 0) {
        final file = File(screenshotPath);
        if (await file.exists()) {
          final bytes = await file.readAsBytes();
          await tempDir.delete(recursive: true);
          logger.info('Web screenshot captured successfully');
          return bytes;
        }
      }

      // Fallback: Try using puppeteer-screenshot if available
      final puppeteerResult = await _tryPuppeteerScreenshot(screenshotPath);
      if (puppeteerResult != null) {
        await tempDir.delete(recursive: true);
        return puppeteerResult;
      }

      await tempDir.delete(recursive: true);
      logger.warn('Web screenshot failed', {
        'exitCode': result.exitCode,
        'stderr': result.stderr,
      });
      return null;
    } catch (e) {
      logger.error('Error taking web screenshot', e);
      return null;
    }
  }

  /// Fallback: Try using puppeteer/playwright for web screenshots
  Future<Uint8List?> _tryPuppeteerScreenshot(String outputPath) async {
    try {
      // Check if npx is available for puppeteer
      final npxCheck = await Process.run('which', ['npx']);
      if (npxCheck.exitCode != 0) return null;

      // Try to use a simple puppeteer screenshot script
      // This requires puppeteer to be installed globally or locally
      final scriptContent =
          '''
const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.connect({ browserURL: 'http://localhost:9222' });
  const pages = await browser.pages();
  if (pages.length > 0) {
    await pages[0].screenshot({ path: '$outputPath' });
  }
  await browser.disconnect();
})();
''';

      final tempDir = Directory.systemTemp.createTempSync('puppeteer_script');
      final scriptFile = File('${tempDir.path}/screenshot.js');
      await scriptFile.writeAsString(scriptContent);

      final result =
          await Process.run(
            'npx',
            ['--yes', 'puppeteer', scriptFile.path],
            stdoutEncoding: utf8,
            stderrEncoding: utf8,
          ).timeout(
            const Duration(seconds: 10),
            onTimeout: () {
              return ProcessResult(-1, -1, '', 'Timeout');
            },
          );

      await tempDir.delete(recursive: true);

      if (result.exitCode == 0) {
        final file = File(outputPath);
        if (await file.exists()) {
          return await file.readAsBytes();
        }
      }

      return null;
    } catch (e) {
      // Silently fail - puppeteer is optional
      return null;
    }
  }

  /// Detect platform from device ID
  UIPlatform _detectPlatform(String deviceId) {
    // Web browser
    if (deviceId == 'chromium' || deviceId.toLowerCase().contains('web')) {
      return UIPlatform.web;
    }

    // macOS (check for 'macos' or host machine running macOS app)
    if (deviceId.toLowerCase().contains('macos') || deviceId == 'localhost') {
      return UIPlatform.macos;
    }

    // iOS simulator (UUID format: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX)
    if (RegExp(
      r'^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$',
    ).hasMatch(deviceId)) {
      return UIPlatform.ios;
    }

    // Android devices typically have different ID formats
    return UIPlatform.android;
  }

  /// Get device info (dimensions, platform)
  Future<Map<String, dynamic>?> getDeviceInfo(String deviceId) async {
    try {
      final platform = _detectPlatform(deviceId);

      // Default dimensions based on platform
      int width = 390;
      int height = 844;

      switch (platform) {
        case UIPlatform.ios:
          // Try to get actual dimensions from simctl
          final info = await _getIosDeviceInfo(deviceId);
          width = info?['width'] ?? 390;
          height = info?['height'] ?? 844;
          break;
        case UIPlatform.android:
          // Try to get dimensions from adb
          final info = await _getAndroidDeviceInfo(deviceId);
          width = info?['width'] ?? 1080;
          height = info?['height'] ?? 1920;
          break;
        case UIPlatform.macos:
          // macOS default dimensions
          width = 1440;
          height = 900;
          break;
        case UIPlatform.web:
          width = 1280;
          height = 720;
          break;
        default:
          break;
      }

      return {
        'id': deviceId,
        'platform': platform.name,
        'width': width,
        'height': height,
      };
    } catch (e) {
      logger.error('Error getting device info', e);
      return null;
    }
  }

  /// Get iOS device info
  Future<Map<String, int>?> _getIosDeviceInfo(String deviceId) async {
    try {
      // Common iOS screen sizes
      return {'width': 390, 'height': 844}; // iPhone 14 Pro
    } catch (e) {
      return null;
    }
  }

  /// Get Android device info
  Future<Map<String, int>?> _getAndroidDeviceInfo(String deviceId) async {
    try {
      final result = await Process.run('adb', [
        '-s',
        deviceId,
        'shell',
        'wm',
        'size',
      ], stdoutEncoding: utf8);

      if (result.exitCode == 0) {
        // Parse "Physical size: 1080x1920"
        final match = RegExp(
          r'(\d+)x(\d+)',
        ).firstMatch(result.stdout as String);
        if (match != null) {
          return {
            'width': int.parse(match.group(1)!),
            'height': int.parse(match.group(2)!),
          };
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// List available devices (iOS, Android, macOS, and Web)
  Future<List<Map<String, dynamic>>> listDevices() async {
    final devices = <Map<String, dynamic>>[];

    try {
      // Try using Maestro to list devices (cross-platform)
      final maestroDevices = await _listMaestroDevices();
      if (maestroDevices.isNotEmpty) {
        devices.addAll(maestroDevices);
        return devices;
      }

      // Fallback: List devices manually

      // List Android devices via adb
      final adbDevices = await _listAndroidDevices();
      devices.addAll(adbDevices);

      // List iOS simulators via simctl
      final iosDevices = await _listIosDevices();
      devices.addAll(iosDevices);

      // Add macOS option (localhost)
      if (Platform.isMacOS) {
        devices.add({
          'id': 'macos-localhost',
          'name': 'macOS (This Machine)',
          'platform': 'macos',
        });
      }

      // Add web option
      devices.add({
        'id': 'chromium',
        'name': 'Chromium Web Browser',
        'platform': 'web',
      });
    } catch (e) {
      logger.error('Error listing devices', e);
    }

    return devices;
  }

  /// List devices using Maestro CLI
  Future<List<Map<String, dynamic>>> _listMaestroDevices() async {
    final devices = <Map<String, dynamic>>[];

    try {
      // Note: Maestro doesn't have a direct device list command
      // But we can try running hierarchy with --device flag to discover
      // For now, fall back to manual detection
      return devices;
    } catch (e) {
      return devices;
    }
  }

  /// List Android devices via adb
  Future<List<Map<String, dynamic>>> _listAndroidDevices() async {
    final devices = <Map<String, dynamic>>[];

    try {
      final result = await Process.run(
        'adb',
        ['devices', '-l'],
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      );

      if (result.exitCode == 0) {
        final lines = (result.stdout as String).split('\n');
        for (final line in lines.skip(1)) {
          if (line.trim().isEmpty) continue;
          final parts = line.split(RegExp(r'\s+'));
          if (parts.isNotEmpty && parts.length > 1 && parts[1] == 'device') {
            devices.add({
              'id': parts[0],
              'name': parts.length > 2 ? parts.skip(2).join(' ') : parts[0],
              'platform': 'android',
            });
          }
        }
      }
    } catch (e) {
      logger.warn('Error listing Android devices', {'error': e});
    }

    return devices;
  }

  /// List iOS simulators via simctl
  Future<List<Map<String, dynamic>>> _listIosDevices() async {
    final devices = <Map<String, dynamic>>[];

    try {
      final result = await Process.run(
        'xcrun',
        ['simctl', 'list', 'devices', '--json'],
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      );

      if (result.exitCode == 0) {
        final decoded = json.decode(result.stdout as String);
        final devicesJson = decoded['devices'] as Map<String, dynamic>? ?? {};

        for (final entry in devicesJson.entries) {
          // Include iOS, watchOS, tvOS, visionOS
          final runtime = entry.key.toLowerCase();
          if (!runtime.contains('ios') &&
              !runtime.contains('watch') &&
              !runtime.contains('tv') &&
              !runtime.contains('vision')) {
            continue;
          }

          final sims = entry.value as List<dynamic>? ?? [];

          for (final sim in sims) {
            final simMap = sim as Map<String, dynamic>;
            if (simMap['state'] == 'Booted') {
              devices.add({
                'id': simMap['udid'],
                'name': simMap['name'],
                'platform': 'ios',
                'runtime': entry.key,
              });
            }
          }
        }
      }
    } catch (e) {
      logger.warn('Error listing iOS devices', {'error': e});
    }

    return devices;
  }

  /// Start continuous screen streaming
  Stream<UIScreen> startScreenStream(
    String deviceId, {
    Duration interval = _defaultPollInterval,
  }) {
    _currentDeviceId = deviceId;
    _screenController = StreamController<UIScreen>.broadcast();
    _isPolling = true;

    _pollLoop(deviceId, interval);

    return _screenController!.stream;
  }

  /// Stop the screen stream
  void stopScreenStream() {
    _isPolling = false;
    _screenController?.close();
    _screenController = null;
    _currentDeviceId = null;
  }

  Future<void> _pollLoop(String deviceId, Duration interval) async {
    while (_isPolling) {
      final startTime = DateTime.now();

      try {
        final screen = await captureUIScreen(deviceId);
        if (screen != null && !(_screenController?.isClosed ?? true)) {
          _screenController!.add(screen);
        }
      } catch (e) {
        logger.error('Error in poll loop', e);
        if (!(_screenController?.isClosed ?? true)) {
          _screenController!.addError(e);
        }
      }

      final elapsed = DateTime.now().difference(startTime);
      final delay = interval - elapsed;
      if (delay > Duration.zero) {
        await Future.delayed(delay);
      }
    }
  }

  /// Capture a single UI screen (hierarchy + screenshot)
  Future<UIScreen?> captureUIScreen(String deviceId) async {
    try {
      // Get view hierarchy and screenshot in parallel
      final results = await Future.wait([
        getViewHierarchy(deviceId),
        takeScreenshot(deviceId),
        getDeviceInfo(deviceId),
      ]);

      final hierarchyData = results[0] as String?;
      final screenshotBytes = results[1] as Uint8List?;
      final deviceInfo = results[2] as Map<String, dynamic>?;

      final elements = hierarchyData != null
          ? parseViewHierarchy(hierarchyData)
          : <UIElement>[];

      // Determine platform
      final platform = _detectPlatform(deviceId);

      // Get dimensions
      final width = deviceInfo?['width'] as int? ?? 390;
      final height = deviceInfo?['height'] as int? ?? 844;

      return UIScreen(
        platform: platform,
        screenshotBytes: screenshotBytes,
        width: width,
        height: height,
        elements: elements,
        url: deviceInfo?['url'] as String?,
        capturedAt: DateTime.now(),
      );
    } catch (e) {
      logger.error('Error capturing UI screen', e);
      return null;
    }
  }

  /// Backwards compatibility alias
  @Deprecated('Use captureUIScreen instead')
  Future<UIScreen?> captureDeviceScreen(String deviceId) => captureUIScreen(deviceId);

  /// Send a tap action to the device
  Future<bool> tapElement(String deviceId, UIElement element) async {
    try {
      if (element.bounds != null) {
        return await tapAt(
          deviceId,
          element.bounds!.centerX.toInt(),
          element.bounds!.centerY.toInt(),
        );
      }
      return false;
    } catch (e) {
      logger.error('Error tapping element', e);
      return false;
    }
  }

  /// Send a tap at a specific point using Maestro or platform-specific tools
  Future<bool> tapAt(String deviceId, int x, int y) async {
    try {
      final platform = _detectPlatform(deviceId);

      // Try Maestro flow for tap (works for all platforms)
      final maestroResult = await _executeMaestroCommand(
        deviceId,
        'tapOn:\n  point: "$x,$y"',
      );
      if (maestroResult) return true;

      // Fallback to platform-specific methods
      switch (platform) {
        case UIPlatform.android:
          final result = await Process.run('adb', [
            '-s',
            deviceId,
            'shell',
            'input',
            'tap',
            x.toString(),
            y.toString(),
          ]);
          return result.exitCode == 0;

        case UIPlatform.ios:
          // iOS tap requires different approach (simctl doesn't support tap)
          logger.warn('iOS tap not supported without Maestro');
          return false;

        case UIPlatform.macos:
          // macOS tap could use AppleScript or cliclick
          logger.warn('macOS tap requires additional tooling');
          return false;

        case UIPlatform.web:
          logger.warn('Web tap requires browser automation');
          return false;

        default:
          return false;
      }
    } catch (e) {
      logger.error('Error tapping at point', e);
      return false;
    }
  }

  /// Execute a Maestro command/flow
  Future<bool> _executeMaestroCommand(String deviceId, String command) async {
    try {
      // Create a temporary flow file
      final tempDir = await Directory.systemTemp.createTemp('maestro_cmd');
      final flowFile = File('${tempDir.path}/command.yaml');
      await flowFile.writeAsString('appId: any\n---\n- $command');

      final result = await Process.run(
        _maestroPath,
        ['test', flowFile.path],
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      ).timeout(const Duration(seconds: 10));

      await tempDir.delete(recursive: true);
      return result.exitCode == 0;
    } catch (e) {
      return false;
    }
  }

  /// Send text input
  Future<bool> inputText(String deviceId, String text) async {
    try {
      final platform = _detectPlatform(deviceId);

      // Try Maestro
      final maestroResult = await _executeMaestroCommand(
        deviceId,
        'inputText: "$text"',
      );
      if (maestroResult) return true;

      // Fallback to adb for Android
      if (platform == UIPlatform.android) {
        final escapedText = text.replaceAll(' ', '%s').replaceAll("'", "\\'");
        final result = await Process.run('adb', [
          '-s',
          deviceId,
          'shell',
          'input',
          'text',
          escapedText,
        ]);
        return result.exitCode == 0;
      }

      return false;
    } catch (e) {
      logger.error('Error inputting text', e);
      return false;
    }
  }

  /// Send a swipe gesture
  Future<bool> swipe(
    String deviceId, {
    required int startX,
    required int startY,
    required int endX,
    required int endY,
    int duration = 300,
  }) async {
    try {
      final platform = _detectPlatform(deviceId);

      // Try Maestro swipe
      final maestroResult = await _executeMaestroCommand(
        deviceId,
        'swipe:\n  start: "$startX,$startY"\n  end: "$endX,$endY"\n  duration: $duration',
      );
      if (maestroResult) return true;

      // Fallback to adb for Android
      if (platform == UIPlatform.android) {
        final result = await Process.run('adb', [
          '-s',
          deviceId,
          'shell',
          'input',
          'swipe',
          startX.toString(),
          startY.toString(),
          endX.toString(),
          endY.toString(),
          duration.toString(),
        ]);
        return result.exitCode == 0;
      }

      return false;
    } catch (e) {
      logger.error('Error swiping', e);
      return false;
    }
  }

  /// Press the back button
  Future<bool> pressBack(String deviceId) async {
    try {
      final platform = _detectPlatform(deviceId);

      // Try Maestro
      final maestroResult = await _executeMaestroCommand(deviceId, 'back');
      if (maestroResult) return true;

      // Fallback to adb for Android
      if (platform == UIPlatform.android) {
        final result = await Process.run('adb', [
          '-s',
          deviceId,
          'shell',
          'input',
          'keyevent',
          'KEYCODE_BACK',
        ]);
        return result.exitCode == 0;
      }

      return false;
    } catch (e) {
      logger.error('Error pressing back', e);
      return false;
    }
  }
}

/// Backwards compatibility alias
@Deprecated('Use UIAutomationService instead')
typedef DeviceInspectorService = UIAutomationService;

