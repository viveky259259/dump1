import '../services/inspector_service.dart';
import '../services/source_code_analyzer.dart';
import '../core/logging/logging.dart';

/// Represents a dependency that a widget needs to function
class WidgetDependency {
  final String type;
  final String category;
  final String description;
  final String? providerType;
  final String? objectId;
  final Map<String, dynamic>? properties;
  final String setupCode;
  final int distanceFromTarget;

  WidgetDependency({
    required this.type,
    required this.category,
    required this.description,
    this.providerType,
    this.objectId,
    this.properties,
    required this.setupCode,
    required this.distanceFromTarget,
  });
}

/// Categories of dependencies
class DependencyCategory {
  static const String provider = 'Provider';
  static const String inherited = 'Inherited Widget';
  static const String material = 'Material/Theme';
  static const String navigation = 'Navigation';
  static const String media = 'Media/Layout';
  static const String platform = 'Platform';
  static const String other = 'Other';
}

/// Service to analyze widget dependencies for testing setup
class DependencyAnalysisService with LoggerMixin {
  final InspectorService inspectorService;
  final SourceCodeAnalyzer _sourceAnalyzer = SourceCodeAnalyzer();

  DependencyAnalysisService(this.inspectorService) {
    logger.info('DependencyAnalysisService initialized');
  }

  /// Enhanced dependency analysis using both tree traversal and source code analysis
  Future<List<WidgetDependency>> analyzeWidgetDependenciesEnhanced(
    WidgetTreeNode targetWidget,
  ) async {
    return await logAsyncOperation(
      'analyzeWidgetDependenciesEnhanced',
      () async => _analyzeWidgetDependenciesEnhancedImpl(targetWidget),
      context: {
        'widgetType': targetWidget.type,
        'objectId': targetWidget.objectId,
      },
    );
  }

  Future<List<WidgetDependency>> _analyzeWidgetDependenciesEnhancedImpl(
    WidgetTreeNode targetWidget,
  ) async {
    final allDependencies = <WidgetDependency>[];

    logger.info('Starting enhanced dependency analysis', {
      'widgetType': targetWidget.type,
      'objectId': targetWidget.objectId,
    });

    try {
      // Step 1: Get source code dependencies (most accurate)
      if (targetWidget.objectId != null) {
        print(
          '📍 Step 1: Getting source location for objectId: ${targetWidget.objectId}',
        );
        final sourceLocation = await inspectorService.getWidgetSourceLocation(
          targetWidget.objectId!,
        );

        if (sourceLocation != null) {
          print(
            '📍 ✅ Got source location: ${sourceLocation.file}:${sourceLocation.line}',
          );
          final sourceCode = await inspectorService.getWidgetSourceCode(
            sourceLocation,
          );

          if (sourceCode != null) {
            print('📍 ✅ Got source code: ${sourceCode.length} characters');
          } else {
            print(
              '📍 ❌ Failed to get source code from location: ${sourceLocation.file}',
            );
          }

          if (sourceCode != null) {
            print('📄 Analyzing source code for ${targetWidget.type}...');
            print(
              '📄 Source location: ${sourceLocation.file}:${sourceLocation.line}',
            );
            print(
              '📄 Source code snippet:\n${sourceCode.split('\n').take(5).join('\n')}...',
            );

            final sourceDependencies = await _sourceAnalyzer
                .analyzeDependencies(sourceCode, sourceLocation);

            // Convert source code dependencies to widget dependencies
            for (final sourceDep in sourceDependencies) {
              print(
                '📄 Found dependency: ${sourceDep.name} - ${sourceDep.description}',
              );
              final widgetDep = _convertSourceToWidgetDependency(sourceDep, 0);
              if (widgetDep != null) {
                allDependencies.add(widgetDep);
              }
            }
            print(
              '📄 ✅ Found ${sourceDependencies.length} source code dependencies',
            );
          }
        } else {
          print(
            '📍 ❌ Source location is null - inspector service might not support source locations',
          );
        }
      } else {
        print('📍 ❌ Widget objectId is null - cannot get source location');
      }

      // Step 2: Fallback to tree-based analysis for any missing dependencies
      final treeDependencies = await analyzeDependencies(targetWidget);

      // Merge dependencies, preferring source code analysis results
      final sourceTypes = allDependencies
          .map((d) => '${d.category}_${d.type}')
          .toSet();
      for (final treeDep in treeDependencies) {
        final treeKey = '${treeDep.category}_${treeDep.type}';
        if (!sourceTypes.contains(treeKey)) {
          allDependencies.add(treeDep);
        }
      }

      print('🎯 ✅ TOTAL DEPENDENCIES FOUND: ${allDependencies.length}');
      for (final dep in allDependencies) {
        print('   - ${dep.category}: ${dep.type}');
      }

      // Add web-specific fallback if no dependencies found
      if (allDependencies.isEmpty) {
        print('🌐 No dependencies found, trying web-specific detection...');
        final webDeps = await _webFallbackDetection(targetWidget);
        allDependencies.addAll(webDeps);
        print(
          '🌐 Web fallback found ${webDeps.length} additional dependencies',
        );
      }
    } catch (e) {
      print('❌ Error in enhanced analysis, falling back to tree analysis: $e');
      print('❌ Exception details: ${e.toString()}');
      return await analyzeDependencies(targetWidget);
    }

    // Sort by priority and distance
    allDependencies.sort((a, b) {
      final categoryCompare = _getCategoryPriority(
        a.category,
      ).compareTo(_getCategoryPriority(b.category));
      if (categoryCompare != 0) return categoryCompare;
      return a.distanceFromTarget.compareTo(b.distanceFromTarget);
    });

    return allDependencies;
  }

  /// Convert source code dependency to widget dependency
  WidgetDependency? _convertSourceToWidgetDependency(
    SourceCodeDependency sourceDep,
    int distance,
  ) {
    String category;
    String setupCode;
    String? providerType;

    if (sourceDep is ProviderSourceDependency) {
      category = DependencyCategory.provider;
      providerType = sourceDep.providerType;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is BlocSourceDependency) {
      category = DependencyCategory.provider;
      providerType = sourceDep.blocType;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is ThemeSourceDependency) {
      category = DependencyCategory.material;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is MediaQuerySourceDependency) {
      category = DependencyCategory.media;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is NavigatorSourceDependency) {
      category = DependencyCategory.navigation;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is ScaffoldSourceDependency) {
      category = DependencyCategory.material;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is LocalizationSourceDependency) {
      category = DependencyCategory.other;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else if (sourceDep is InheritedWidgetSourceDependency) {
      category = DependencyCategory.inherited;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    } else {
      category = DependencyCategory.other;
      setupCode = sourceDep.generateTestWrapper('YourWidgetUnderTest()');
    }

    return WidgetDependency(
      type: sourceDep.name,
      category: category,
      description: sourceDep.description,
      providerType: providerType,
      setupCode:
          '''
// Source-based dependency detection
// Found: ${sourceDep.usage}
// Location: ${sourceDep.location.file}:${sourceDep.location.line}

$setupCode''',
      distanceFromTarget: distance,
    );
  }

  /// Analyze dependencies for a given widget by traversing up the tree
  /// NOTE: Current limitation - Flutter inspector doesn't provide parent relationships,
  /// so we analyze the complete tree from root and find dependencies above the target
  /// TODO: Implement source code analysis as described in WIDGET_DEPENDENCY_ANALYSIS_IMPLEMENTATION.md
  /// for much more accurate dependency detection (Theme.of(context) usage, Provider.of<T>, etc.)
  Future<List<WidgetDependency>> analyzeDependencies(
    WidgetTreeNode targetWidget,
  ) async {
    final dependencies = <WidgetDependency>[];

    // Get the root widget tree from inspector
    final rootWidget = await inspectorService.getRootWidgetSummaryTree();
    if (rootWidget == null) {
      return dependencies;
    }

    // Find the target widget in the tree and collect all ancestors with dependencies
    final ancestors = <WidgetTreeNode>[];
    print('🌳 Starting tree analysis for ${targetWidget.type}...');
    _findAncestors(rootWidget, targetWidget, [], ancestors);
    print('🌳 Found ${ancestors.length} ancestor widgets with dependencies');

    // Analyze each ancestor for dependencies
    for (int i = 0; i < ancestors.length; i++) {
      final ancestor = ancestors[i];
      final distance = ancestors.length - i;
      final dependency = _analyzeSingleWidget(ancestor, distance);
      if (dependency != null) {
        dependencies.add(dependency);
      }
    }

    // Sort dependencies by category and distance
    dependencies.sort((a, b) {
      final categoryCompare = _getCategoryPriority(
        a.category,
      ).compareTo(_getCategoryPriority(b.category));
      if (categoryCompare != 0) return categoryCompare;
      return a.distanceFromTarget.compareTo(b.distanceFromTarget);
    });

    return dependencies;
  }

  /// Find all ancestors of the target widget that provide dependencies
  bool _findAncestors(
    WidgetTreeNode current,
    WidgetTreeNode target,
    List<WidgetTreeNode> currentPath,
    List<WidgetTreeNode> foundAncestors,
  ) {
    // Add current widget to the path
    final newPath = [...currentPath, current];

    // Check if we found the target widget
    if (current.objectId == target.objectId ||
        (current.type == target.type &&
            current.description == target.description)) {
      // Found target! Add all ancestors from the path that provide dependencies
      for (final ancestor in newPath) {
        if (_providedDependency(ancestor)) {
          foundAncestors.add(ancestor);
        }
      }
      return true;
    }

    // Recursively search in children
    for (final child in current.children) {
      if (_findAncestors(child, target, newPath, foundAncestors)) {
        return true;
      }
    }

    return false;
  }

  /// Check if a widget provides any dependencies
  bool _providedDependency(WidgetTreeNode widget) {
    final type = widget.type ?? '';
    return _isProviderWidget(type) ||
        _isMaterialWidget(type) ||
        _isInheritedWidget(type) ||
        _isNavigationWidget(type) ||
        _isMediaWidget(type);
  }

  /// Get priority for category sorting (lower number = higher priority)
  int _getCategoryPriority(String category) {
    switch (category) {
      case DependencyCategory.provider:
        return 0;
      case DependencyCategory.material:
        return 1;
      case DependencyCategory.inherited:
        return 2;
      case DependencyCategory.navigation:
        return 3;
      case DependencyCategory.media:
        return 4;
      case DependencyCategory.platform:
        return 5;
      case DependencyCategory.other:
        return 6;
      default:
        return 99;
    }
  }

  /// Analyze a single widget to determine if it provides dependencies
  WidgetDependency? _analyzeSingleWidget(WidgetTreeNode widget, int distance) {
    final type = widget.type ?? '';

    // Provider dependencies
    if (_isProviderWidget(type)) {
      return _analyzeProviderWidget(widget, distance);
    }

    // Material/Theme dependencies
    if (_isMaterialWidget(type)) {
      return _analyzeMaterialWidget(widget, distance);
    }

    // Inherited widget dependencies
    if (_isInheritedWidget(type)) {
      return _analyzeInheritedWidget(widget, distance);
    }

    // Navigation dependencies
    if (_isNavigationWidget(type)) {
      return _analyzeNavigationWidget(widget, distance);
    }

    // Media/Layout dependencies
    if (_isMediaWidget(type)) {
      return _analyzeMediaWidget(widget, distance);
    }

    return null;
  }

  /// Check if widget is a Provider-related widget
  bool _isProviderWidget(String type) {
    final providerTypes = {
      // Flutter Provider package
      'ChangeNotifierProvider',
      'Provider',
      'MultiProvider',
      'Consumer',
      'Selector',
      'StreamProvider',
      'FutureProvider',
      'ValueListenableProvider',
      'ProxyProvider',
      'ChangeNotifierProxyProvider',
      'ListenableProvider',
      'ListenableProxyProvider',

      // BLoC package
      'BlocProvider',
      'RepositoryProvider',
      'MultiBlocProvider',
      'MultiRepositoryProvider',
      'BlocListener',
      'BlocBuilder',
      'BlocConsumer',

      // Riverpod package
      'ProviderScope',
      'ConsumerWidget',
      'ConsumerStatefulWidget',

      // GetX package
      'GetMaterialApp',
      'GetBuilder',
      'GetX',
      'Obx',

      // Redux
      'StoreProvider',
      'StoreConnector',
      'StoreBuilder',

      // MobX
      'Observer',

      // Other common state management
      'ValueNotifier',
      'AnimatedBuilder',
      'StreamBuilder',
      'FutureBuilder',
    };

    return providerTypes.any((providerType) => type.contains(providerType));
  }

  /// Analyze Provider widget
  WidgetDependency _analyzeProviderWidget(WidgetTreeNode widget, int distance) {
    final type = widget.type ?? '';
    String providerType = 'Unknown';
    String setupCode = '';

    if (type.contains('ChangeNotifierProvider')) {
      providerType = 'ChangeNotifier';
      setupCode = '''
// Setup ChangeNotifierProvider for testing
ChangeNotifierProvider<YourNotifier>(
  create: (_) => MockYourNotifier(), // Create mock or real instance
  child: YourWidgetUnderTest(),
)''';
    } else if (type.contains('BlocProvider')) {
      providerType = 'Bloc';
      setupCode = '''
// Setup BlocProvider for testing
BlocProvider<YourBloc>(
  create: (_) => MockYourBloc(), // Create mock or real instance
  child: YourWidgetUnderTest(),
)''';
    } else if (type.contains('Provider')) {
      setupCode = '''
// Setup Provider for testing
Provider<YourType>(
  create: (_) => MockYourType(), // Create mock or real instance
  child: YourWidgetUnderTest(),
)''';
    }

    return WidgetDependency(
      type: type,
      category: DependencyCategory.provider,
      description: 'Provides $providerType state management',
      providerType: providerType,
      objectId: widget.objectId,
      setupCode: setupCode,
      distanceFromTarget: distance,
    );
  }

  /// Check if widget is Material-related
  bool _isMaterialWidget(String type) {
    final materialTypes = {
      'MaterialApp',
      'Theme',
      'ThemeData',
      'Material',
      'Scaffold',
    };

    return materialTypes.any((materialType) => type.contains(materialType));
  }

  /// Analyze Material widget
  WidgetDependency _analyzeMaterialWidget(WidgetTreeNode widget, int distance) {
    final type = widget.type ?? '';
    String setupCode = '';

    if (type.contains('MaterialApp')) {
      setupCode = '''
// Wrap your widget with MaterialApp for testing
MaterialApp(
  home: YourWidgetUnderTest(),
)''';
    } else if (type.contains('Theme')) {
      setupCode = '''
// Provide Theme for testing
Theme(
  data: ThemeData(), // Use default or custom theme
  child: YourWidgetUnderTest(),
)''';
    } else if (type.contains('Scaffold')) {
      setupCode = '''
// Provide Scaffold for testing
Scaffold(
  body: YourWidgetUnderTest(),
)''';
    }

    return WidgetDependency(
      type: type,
      category: DependencyCategory.material,
      description: 'Provides Material Design context and theming',
      objectId: widget.objectId,
      setupCode: setupCode,
      distanceFromTarget: distance,
    );
  }

  /// Check if widget is an Inherited widget
  bool _isInheritedWidget(String type) {
    return type.contains('InheritedWidget') ||
        type.contains('InheritedModel') ||
        type.contains('InheritedNotifier');
  }

  /// Analyze Inherited widget
  WidgetDependency _analyzeInheritedWidget(
    WidgetTreeNode widget,
    int distance,
  ) {
    final type = widget.type ?? '';

    return WidgetDependency(
      type: type,
      category: DependencyCategory.inherited,
      description: 'Provides inherited data down the widget tree',
      objectId: widget.objectId,
      setupCode:
          '''
// Setup InheritedWidget for testing
$type(
  // Add required properties
  child: YourWidgetUnderTest(),
)''',
      distanceFromTarget: distance,
    );
  }

  /// Check if widget is navigation-related
  bool _isNavigationWidget(String type) {
    final navigationTypes = {
      'Navigator',
      'Route',
      'PageRoute',
      'MaterialPageRoute',
      'CupertinoPageRoute',
    };

    return navigationTypes.any((navType) => type.contains(navType));
  }

  /// Analyze Navigation widget
  WidgetDependency _analyzeNavigationWidget(
    WidgetTreeNode widget,
    int distance,
  ) {
    final type = widget.type ?? '';

    return WidgetDependency(
      type: type,
      category: DependencyCategory.navigation,
      description: 'Provides navigation context',
      objectId: widget.objectId,
      setupCode: '''
// Provide Navigator for testing
Navigator(
  onGenerateRoute: (settings) => MaterialPageRoute(
    builder: (_) => YourWidgetUnderTest(),
  ),
)''',
      distanceFromTarget: distance,
    );
  }

  /// Check if widget is media/layout related
  bool _isMediaWidget(String type) {
    final mediaTypes = {'MediaQuery', 'LayoutBuilder', 'OrientationBuilder'};

    return mediaTypes.any((mediaType) => type.contains(mediaType));
  }

  /// Analyze Media widget
  WidgetDependency _analyzeMediaWidget(WidgetTreeNode widget, int distance) {
    final type = widget.type ?? '';
    String setupCode = '';

    if (type.contains('MediaQuery')) {
      setupCode = '''
// Provide MediaQuery for testing
MediaQuery(
  data: MediaQueryData(
    size: Size(400, 600), // Set test screen size
    devicePixelRatio: 1.0,
  ),
  child: YourWidgetUnderTest(),
)''';
    } else if (type.contains('LayoutBuilder')) {
      setupCode = '''
// LayoutBuilder provides constraints automatically
// Wrap parent with a Container to control size
Container(
  width: 300,
  height: 200,
  child: YourWidgetUnderTest(),
)''';
    }

    return WidgetDependency(
      type: type,
      category: DependencyCategory.media,
      description: 'Provides layout and media information',
      objectId: widget.objectId,
      setupCode: setupCode,
      distanceFromTarget: distance,
    );
  }

  /// Generate complete test setup code from dependencies
  String generateTestSetupCode(
    List<WidgetDependency> dependencies,
    String targetWidgetName,
  ) {
    if (dependencies.isEmpty) {
      return '''
testWidgets('$targetWidgetName test', (WidgetTester tester) async {
  await tester.pumpWidget($targetWidgetName());
  
  // Add your test assertions here
});''';
    }

    final buffer = StringBuffer();
    buffer.writeln(
      "testWidgets('$targetWidgetName test', (WidgetTester tester) async {",
    );
    buffer.writeln("  await tester.pumpWidget(");

    // Build nested widget tree with dependencies
    for (int i = dependencies.length - 1; i >= 0; i--) {
      final dependency = dependencies[i];
      final indent = '    ' + ('  ' * (dependencies.length - 1 - i));

      if (dependency.category == DependencyCategory.provider) {
        if (dependency.type.contains('ChangeNotifierProvider')) {
          buffer.writeln("${indent}ChangeNotifierProvider<YourNotifierType>(");
          buffer.writeln("${indent}  create: (_) => MockYourNotifier(),");
          buffer.writeln("${indent}  child:");
        }
      } else if (dependency.category == DependencyCategory.material) {
        if (dependency.type.contains('MaterialApp')) {
          buffer.writeln("${indent}MaterialApp(");
          buffer.writeln("${indent}  home:");
        }
      }
    }

    // Add the target widget
    final finalIndent = '    ' + ('  ' * dependencies.length);
    buffer.writeln("${finalIndent}$targetWidgetName(),");

    // Close all the wrappers
    for (int i = 0; i < dependencies.length; i++) {
      final indent = '    ' + ('  ' * (dependencies.length - 1 - i));
      buffer.writeln("${indent}),");
    }

    buffer.writeln("  );");
    buffer.writeln("");
    buffer.writeln("  // Add your test assertions here");
    buffer.writeln("});");

    return buffer.toString();
  }

  /// Web-specific fallback detection when source code analysis fails
  Future<List<WidgetDependency>> _webFallbackDetection(
    WidgetTreeNode targetWidget,
  ) async {
    final dependencies = <WidgetDependency>[];
    final widgetType = targetWidget.type ?? '';

    print('🌐 Web fallback: Analyzing widget type: $widgetType');

    // Hard-coded patterns for common widgets that typically need dependencies
    if (widgetType == 'DemoWidget') {
      // Special handling for our test widget
      dependencies.addAll([
        WidgetDependency(
          type: 'Provider<UserService>',
          category: DependencyCategory.provider,
          description: 'DemoWidget typically uses UserService provider',
          providerType: 'UserService',
          setupCode: '''
ChangeNotifierProvider<UserService>(
  create: (_) => MockUserService(),
  child: YourWidgetUnderTest(),
)''',
          distanceFromTarget: 0,
        ),
        WidgetDependency(
          type: 'Theme',
          category: DependencyCategory.material,
          description: 'DemoWidget uses Theme.of(context)',
          setupCode: '''
MaterialApp(
  theme: ThemeData(),
  home: YourWidgetUnderTest(),
)''',
          distanceFromTarget: 0,
        ),
      ]);
    }

    // Generic Material Design widget detection
    final materialWidgets = {
      'ElevatedButton',
      'TextButton',
      'OutlinedButton',
      'FloatingActionButton',
      'AppBar',
      'Card',
      'Chip',
      'Dialog',
      'Drawer',
      'BottomSheet',
    };

    if (materialWidgets.contains(widgetType)) {
      dependencies.add(
        WidgetDependency(
          type: 'MaterialApp',
          category: DependencyCategory.material,
          description: '$widgetType requires Material Design context',
          setupCode:
              '''
MaterialApp(
  home: $widgetType(),
)''',
          distanceFromTarget: 0,
        ),
      );
    }

    // Text widgets likely need theme
    if (widgetType == 'Text') {
      dependencies.add(
        WidgetDependency(
          type: 'Theme',
          category: DependencyCategory.material,
          description: 'Text widget may use theme styles',
          setupCode: '''
MaterialApp(
  home: Scaffold(body: Text('...')),
)''',
          distanceFromTarget: 0,
        ),
      );
    }

    print('🌐 Web fallback generated ${dependencies.length} dependencies');
    return dependencies;
  }
}
