import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/di/dependency_injection.dart';
import 'core/config/environment_service.dart';
import 'core/logging/logging.dart';
import 'presentation/providers/app_provider.dart';
import 'presentation/providers/ui_automation_provider.dart';
import 'ui/pages/home_page.dart';

void main(args) async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize logging system
  await AppLogger.initialize(LogConfig.defaultConfig());
  final logger = AppLogger.getLogger('main');
  logger.info('Application starting');

  // Initialize environment configuration
  final environmentService = EnvironmentService();
  await environmentService.initialize();
  logger.info('Environment service initialized');

  // Configure dependency injection
  DependencyInjection.configure();

  final appProvider = AppProvider();

  // Set environment service reference in app provider
  appProvider.setEnvironmentService(environmentService);

  // Get configuration from environment service
  final config = environmentService.config;
  final isDemoMode = config.enableDemoMode;

  logger.info('Environment initialized', {
    'config': config.toString(),
    'isDemoMode': isDemoMode,
  });

  // Initialize with demo VM service URI if in demo mode
  if (isDemoMode) {
    // Use a default VM service URI for demo mode
    const demoVmServiceUri = 'ws://localhost:8080';
    logger.info('Initializing in demo mode', {'uri': demoVmServiceUri});
    await appProvider.initialize(demoVmServiceUri);
  }

  logger.info('Launching application');

  runApp(
    MyApp(
      appProvider: appProvider,
      environmentService: environmentService,
      isDemoMode: isDemoMode,
    ),
  );
}

class MyApp extends StatelessWidget {
  final AppProvider appProvider;
  final EnvironmentService environmentService;
  final bool isDemoMode;

  const MyApp({
    super.key,
    required this.appProvider,
    required this.environmentService,
    required this.isDemoMode,
  });

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: appProvider),
        ChangeNotifierProvider.value(value: environmentService),
        ChangeNotifierProvider(create: (_) => UIAutomationProvider()),
      ],
      child: Consumer<EnvironmentService>(
        builder: (context, envService, child) {
          final config = envService.config;
          final seedColor = _getThemeColor(config.themeColor);

          return MaterialApp(
            title: 'Advanced Tester',
            themeMode: config.enableDarkMode ? ThemeMode.dark : ThemeMode.light,
            theme: ThemeData(
              colorScheme: ColorScheme.fromSeed(
                seedColor: seedColor,
                brightness: Brightness.light,
              ),
              useMaterial3: true,
            ),
            darkTheme: ThemeData(
              colorScheme: ColorScheme.fromSeed(
                seedColor: seedColor,
                brightness: Brightness.dark,
              ),
              useMaterial3: true,
            ),
            home: HomePage(isDemoMode: isDemoMode),
            debugShowCheckedModeBanner: !config.enableDebugMode,
          );
        },
      ),
    );
  }

  Color _getThemeColor(String? themeColor) {
    switch (themeColor?.toLowerCase()) {
      case 'blue':
        return Colors.blue;
      case 'green':
        return Colors.green;
      case 'red':
        return Colors.red;
      case 'orange':
        return Colors.orange;
      case 'purple':
        return Colors.purple;
      case 'teal':
        return Colors.teal;
      case 'pink':
        return Colors.pink;
      case 'indigo':
      default:
        return Colors.indigo;
    }
  }
}
