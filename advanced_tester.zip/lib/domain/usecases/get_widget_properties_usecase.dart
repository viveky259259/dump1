import '../entities/widget_entity.dart';
import '../../core/logging/logging.dart';
import '../repositories/widget_repository.dart';
import '../../core/logging/logging.dart';

/// Use case for getting widget properties
class GetWidgetPropertiesUseCase with LoggerMixin {
  final WidgetRepository _repository;

  GetWidgetPropertiesUseCase(this._repository);

  /// Execute the use case
  Future<List<WidgetAttribute>?> execute(String objectId) async {
    if (!_repository.isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    if (objectId.isEmpty) {
      throw ArgumentError('Object ID cannot be empty');
    }

    try {
      return await _repository.getWidgetProperties(objectId);
    } catch (e) {
      throw WidgetRepositoryException('Failed to get widget properties: $e');
    }
  }
}

/// Repository exception
class WidgetRepositoryException implements Exception {
  final String message;
  final Object? cause;

  const WidgetRepositoryException(this.message, [this.cause]);

  @override
  String toString() => 'WidgetRepositoryException: $message';
}
