import '../entities/widget_entity.dart';
import '../../core/logging/logging.dart';
import '../repositories/widget_repository.dart';
import '../../core/logging/logging.dart';

/// Use case for getting the widget tree
class GetWidgetTreeUseCase with LoggerMixin {
  final WidgetRepository _repository;

  GetWidgetTreeUseCase(this._repository);

  /// Execute the use case
  Future<WidgetEntity?> execute() async {
    if (!_repository.isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    try {
      return await _repository.getRootWidgetTree();
    } catch (e) {
      throw WidgetRepositoryException('Failed to get widget tree: $e');
    }
  }
}

/// Repository exception
class WidgetRepositoryException implements Exception {
  final String message;
  final Object? cause;

  const WidgetRepositoryException(this.message, [this.cause]);

  @override
  String toString() => 'WidgetRepositoryException: $message';
}
