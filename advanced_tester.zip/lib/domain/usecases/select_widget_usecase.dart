import '../repositories/widget_repository.dart';
import '../../core/logging/logging.dart';

/// Use case for selecting a widget
class SelectWidgetUseCase with LoggerMixin {
  final WidgetRepository _repository;

  SelectWidgetUseCase(this._repository);

  /// Execute the use case
  Future<void> execute(String objectId) async {
    if (!_repository.isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }

    if (objectId.isEmpty) {
      throw ArgumentError('Object ID cannot be empty');
    }

    try {
      await _repository.selectWidget(objectId);
    } catch (e) {
      throw WidgetRepositoryException('Failed to select widget: $e');
    }
  }
}

/// Repository exception
class WidgetRepositoryException implements Exception {
  final String message;
  final Object? cause;

  const WidgetRepositoryException(this.message, [this.cause]);

  @override
  String toString() => 'WidgetRepositoryException: $message';
}
