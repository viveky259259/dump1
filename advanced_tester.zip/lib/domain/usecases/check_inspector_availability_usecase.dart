import '../repositories/widget_repository.dart';
import '../../core/logging/logging.dart';

/// Use case for checking inspector availability
class CheckInspectorAvailabilityUseCase with LoggerMixin {
  final WidgetRepository _repository;

  CheckInspectorAvailabilityUseCase(this._repository);

  /// Execute the use case
  Future<bool> execute() async {
    try {
      return await _repository.isInspectorAvailable();
    } catch (e) {
      throw WidgetRepositoryException(
        'Failed to check inspector availability: $e',
      );
    }
  }
}

/// Repository exception
class WidgetRepositoryException implements Exception {
  final String message;
  final Object? cause;

  const WidgetRepositoryException(this.message, [this.cause]);

  @override
  String toString() => 'WidgetRepositoryException: $message';
}
