import '../entities/test_entity.dart';
import '../../core/logging/logging.dart';

/// Use case for managing test cases
class ManageTestCasesUseCase with LoggerMixin {
  final List<TestCase> _testCases = [];

  ManageTestCasesUseCase();

  /// Save test case
  Future<void> saveTestCase(TestCase testCase) async {
    try {
      final existingIndex = _testCases.indexWhere((tc) => tc.id == testCase.id);
      if (existingIndex >= 0) {
        _testCases[existingIndex] = testCase;
      } else {
        _testCases.add(testCase);
      }
    } catch (e) {
      throw TestManagementException('Failed to save test case: $e');
    }
  }

  /// Get test case by ID
  Future<TestCase?> getTestCase(String id) async {
    try {
      return _testCases.firstWhere((tc) => tc.id == id);
    } catch (e) {
      return null;
    }
  }

  /// Get all test cases for a widget
  Future<List<TestCase>> getTestCasesForWidget(String widgetId) async {
    try {
      return _testCases
          .where((tc) => tc.targetWidget.objectId == widgetId)
          .toList();
    } catch (e) {
      throw TestManagementException('Failed to get test cases: $e');
    }
  }

  /// Delete test case
  Future<void> deleteTestCase(String id) async {
    try {
      _testCases.removeWhere((tc) => tc.id == id);
    } catch (e) {
      throw TestManagementException('Failed to delete test case: $e');
    }
  }

  /// Update test case
  Future<void> updateTestCase(TestCase testCase) async {
    try {
      await saveTestCase(testCase);
    } catch (e) {
      throw TestManagementException('Failed to update test case: $e');
    }
  }

  /// Get all test cases
  Future<List<TestCase>> getAllTestCases() async {
    return List.from(_testCases);
  }

  /// Clear all test cases
  Future<void> clearAllTestCases() async {
    _testCases.clear();
  }
}

/// Test management exception
class TestManagementException implements Exception {
  final String message;
  final Object? cause;

  const TestManagementException(this.message, [this.cause]);

  @override
  String toString() => 'TestManagementException: $message';
}
