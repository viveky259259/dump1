import '../entities/widget_entity.dart';

/// Repository interface for widget-related operations
abstract class WidgetRepository {
  /// Connect to the VM service
  Future<void> connect();

  /// Disconnect from the VM service
  Future<void> disconnect();

  /// Check if the repository is connected
  bool get isConnected;

  /// Get the root widget tree
  Future<WidgetEntity?> getRootWidgetTree();

  /// Get widget details by object ID
  Future<List<WidgetAttribute>?> getWidgetProperties(String objectId);

  /// Get widget children
  Future<List<WidgetEntity>> getWidgetChildren(String objectId);

  /// Select a widget in the inspector
  Future<void> selectWidget(String objectId);

  /// Get the currently selected widget
  Future<WidgetEntity?> getSelectedWidget();

  /// Check if inspector is available
  Future<bool> isInspectorAvailable();

  /// Clear widget tree cache
  void clearCache();

  /// Get widget source location
  Future<SourceLocation?> getWidgetSourceLocation(String objectId);

  /// Get widget source code
  Future<String?> getWidgetSourceCode(SourceLocation location);
}

/// Source location information
class SourceLocation {
  final String file;
  final int line;
  final int column;
  final int? endLine;
  final int? endColumn;

  const SourceLocation({
    required this.file,
    required this.line,
    required this.column,
    this.endLine,
    this.endColumn,
  });

  @override
  String toString() => '$file:$line:$column';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is SourceLocation &&
        other.file == file &&
        other.line == line &&
        other.column == column;
  }

  @override
  int get hashCode => Object.hash(file, line, column);
}
