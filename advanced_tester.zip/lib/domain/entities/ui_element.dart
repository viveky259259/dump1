/// Bounding box coordinates for a UI element.
///
/// Represents the position and size of an element on the device screen.
class UIElementBounds {
  /// Left edge (x coordinate) in pixels
  final int x;

  /// Top edge (y coordinate) in pixels
  final int y;

  /// Width in pixels
  final int width;

  /// Height in pixels
  final int height;

  const UIElementBounds({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
  });

  /// Center X coordinate
  double get centerX => x + width / 2;

  /// Center Y coordinate
  double get centerY => y + height / 2;

  /// Area of the bounds (used for sorting)
  int get area => width * height;

  /// Check if a point (normalized 0-1) is within these bounds
  bool containsNormalized(
    double normalizedX,
    double normalizedY,
    int deviceWidth,
    int deviceHeight,
  ) {
    final pixelX = normalizedX * deviceWidth;
    final pixelY = normalizedY * deviceHeight;

    return pixelX >= x &&
        pixelX <= x + width &&
        pixelY >= y &&
        pixelY <= y + height;
  }

  /// Parse bounds from Android/iOS format: "[left,top][right,bottom]"
  static UIElementBounds? parse(String? boundsString) {
    if (boundsString == null || boundsString.isEmpty) return null;

    // Pattern: [left,top][right,bottom]
    final pattern = RegExp(r'\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]');
    final match = pattern.firstMatch(boundsString);

    if (match == null) return null;

    final left = int.tryParse(match.group(1) ?? '');
    final top = int.tryParse(match.group(2) ?? '');
    final right = int.tryParse(match.group(3) ?? '');
    final bottom = int.tryParse(match.group(4) ?? '');

    if (left == null || top == null || right == null || bottom == null) {
      return null;
    }

    return UIElementBounds(
      x: left,
      y: top,
      width: right - left,
      height: bottom - top,
    );
  }

  /// Create bounds from x, y, width, height values
  factory UIElementBounds.fromValues({
    required int x,
    required int y,
    required int width,
    required int height,
  }) {
    return UIElementBounds(x: x, y: y, width: width, height: height);
  }

  Map<String, dynamic> toJson() {
    return {
      'x': x,
      'y': y,
      'width': width,
      'height': height,
    };
  }

  factory UIElementBounds.fromJson(Map<String, dynamic> json) {
    return UIElementBounds(
      x: json['x'] as int,
      y: json['y'] as int,
      width: json['width'] as int,
      height: json['height'] as int,
    );
  }

  @override
  String toString() => 'UIElementBounds(x: $x, y: $y, w: $width, h: $height)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UIElementBounds &&
        other.x == x &&
        other.y == y &&
        other.width == width &&
        other.height == height;
  }

  @override
  int get hashCode => Object.hash(x, y, width, height);
}

/// Represents a single selectable UI element on the device screen.
///
/// Contains all the information needed to identify, display, and interact 
/// with UI elements including text, resource IDs, bounds, and accessibility info.
class UIElement {
  /// Auto-generated stable ID for frontend rendering
  final String id;

  /// Element position and size
  final UIElementBounds? bounds;

  /// Resource ID (Android: com.app:id/button, iOS: accessibilityIdentifier, Web: id)
  final String? resourceId;

  /// Index if multiple elements share the same resourceId
  final int? resourceIdIndex;

  /// Visible text content
  final String? text;

  /// Hint/placeholder text (useful for input fields)
  final String? hintText;

  /// Accessibility label
  final String? accessibilityText;

  /// Index if multiple elements share the same text
  final int? textIndex;

  /// Element class/type (e.g., "Button", "TextField")
  final String? elementType;

  /// Whether the element is clickable
  final bool? clickable;

  /// Whether the element is enabled
  final bool? enabled;

  /// Whether the element is focused
  final bool? focused;

  /// Whether the element is checked (for checkboxes, switches)
  final bool? checked;

  /// Whether the element is selected
  final bool? selected;

  /// Raw attributes from the view hierarchy
  final Map<String, String>? rawAttributes;

  /// Depth in the view hierarchy (from Maestro)
  final int? depth;

  /// Element number in the hierarchy (from Maestro)
  final int? elementNum;

  const UIElement({
    required this.id,
    this.bounds,
    this.resourceId,
    this.resourceIdIndex,
    this.text,
    this.hintText,
    this.accessibilityText,
    this.textIndex,
    this.elementType,
    this.clickable,
    this.enabled,
    this.focused,
    this.checked,
    this.selected,
    this.rawAttributes,
    this.depth,
    this.elementNum,
  });

  /// Check if this element has any selectable attribute
  bool get hasSelectableAttribute {
    return text != null ||
        resourceId != null ||
        hintText != null ||
        accessibilityText != null;
  }

  /// Get the primary display text for this element
  String? get displayText {
    return resourceId ?? text ?? hintText ?? accessibilityText;
  }

  /// Get all selector types available for this element
  List<SelectorInfo> get availableSelectors {
    final selectors = <SelectorInfo>[];

    if (resourceId != null) {
      selectors.add(SelectorInfo(
        type: SelectorType.id,
        value: resourceId!,
        index: resourceIdIndex,
      ));
    }

    if (text != null) {
      selectors.add(SelectorInfo(
        type: SelectorType.text,
        value: text!,
        index: textIndex,
      ));
    }

    if (hintText != null) {
      selectors.add(SelectorInfo(
        type: SelectorType.hintText,
        value: hintText!,
      ));
    }

    if (accessibilityText != null) {
      selectors.add(SelectorInfo(
        type: SelectorType.accessibilityText,
        value: accessibilityText!,
      ));
    }

    return selectors;
  }

  /// Generate a tap command for this element
  String generateTapCommand() {
    if (resourceId != null) {
      final index =
          resourceIdIndex != null ? '\n    index: $resourceIdIndex' : '';
      return '- tapOn:\n    id: "$resourceId"$index';
    }

    if (text != null) {
      final index = textIndex != null ? '\n    index: $textIndex' : '';
      return '- tapOn:\n    text: "$text"$index';
    }

    if (accessibilityText != null) {
      return '- tapOn:\n    accessibilityText: "$accessibilityText"';
    }

    if (bounds != null) {
      // Fallback to point-based tap
      return '- tapOn:\n    point: "${bounds!.centerX.toInt()},${bounds!.centerY.toInt()}"';
    }

    return '# Unable to generate tap command';
  }

  /// Generate an assert command for this element
  String generateAssertCommand() {
    if (text != null) {
      return '- assertVisible: "$text"';
    }

    if (resourceId != null) {
      return '- assertVisible:\n    id: "$resourceId"';
    }

    return '# Unable to generate assert command';
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      if (bounds != null) 'bounds': bounds!.toJson(),
      if (resourceId != null) 'resourceId': resourceId,
      if (resourceIdIndex != null) 'resourceIdIndex': resourceIdIndex,
      if (text != null) 'text': text,
      if (hintText != null) 'hintText': hintText,
      if (accessibilityText != null) 'accessibilityText': accessibilityText,
      if (textIndex != null) 'textIndex': textIndex,
      if (elementType != null) 'elementType': elementType,
      if (clickable != null) 'clickable': clickable,
      if (enabled != null) 'enabled': enabled,
      if (focused != null) 'focused': focused,
      if (checked != null) 'checked': checked,
      if (selected != null) 'selected': selected,
      if (depth != null) 'depth': depth,
      if (elementNum != null) 'elementNum': elementNum,
    };
  }

  factory UIElement.fromJson(Map<String, dynamic> json) {
    return UIElement(
      id: json['id'] as String,
      bounds: json['bounds'] != null
          ? UIElementBounds.fromJson(json['bounds'] as Map<String, dynamic>)
          : null,
      resourceId: json['resourceId'] as String?,
      resourceIdIndex: json['resourceIdIndex'] as int?,
      text: json['text'] as String?,
      hintText: json['hintText'] as String?,
      accessibilityText: json['accessibilityText'] as String?,
      textIndex: json['textIndex'] as int?,
      elementType: json['elementType'] as String?,
      clickable: json['clickable'] as bool?,
      enabled: json['enabled'] as bool?,
      focused: json['focused'] as bool?,
      checked: json['checked'] as bool?,
      selected: json['selected'] as bool?,
      depth: json['depth'] as int?,
      elementNum: json['elementNum'] as int?,
    );
  }

  UIElement copyWith({
    String? id,
    UIElementBounds? bounds,
    String? resourceId,
    int? resourceIdIndex,
    String? text,
    String? hintText,
    String? accessibilityText,
    int? textIndex,
    String? elementType,
    bool? clickable,
    bool? enabled,
    bool? focused,
    bool? checked,
    bool? selected,
    Map<String, String>? rawAttributes,
    int? depth,
    int? elementNum,
  }) {
    return UIElement(
      id: id ?? this.id,
      bounds: bounds ?? this.bounds,
      resourceId: resourceId ?? this.resourceId,
      resourceIdIndex: resourceIdIndex ?? this.resourceIdIndex,
      text: text ?? this.text,
      hintText: hintText ?? this.hintText,
      accessibilityText: accessibilityText ?? this.accessibilityText,
      textIndex: textIndex ?? this.textIndex,
      elementType: elementType ?? this.elementType,
      clickable: clickable ?? this.clickable,
      enabled: enabled ?? this.enabled,
      focused: focused ?? this.focused,
      checked: checked ?? this.checked,
      selected: selected ?? this.selected,
      rawAttributes: rawAttributes ?? this.rawAttributes,
      depth: depth ?? this.depth,
      elementNum: elementNum ?? this.elementNum,
    );
  }

  @override
  String toString() => 'UIElement($id, text: $text, id: $resourceId)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UIElement && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

/// Types of selectors available for UI elements
enum SelectorType {
  id,
  text,
  hintText,
  accessibilityText,
  point,
}

/// Information about a specific selector for a UI element
class SelectorInfo {
  final SelectorType type;
  final String value;
  final int? index;

  const SelectorInfo({
    required this.type,
    required this.value,
    this.index,
  });

  String get typeLabel {
    switch (type) {
      case SelectorType.id:
        return 'id';
      case SelectorType.text:
        return 'text';
      case SelectorType.hintText:
        return 'hintText';
      case SelectorType.accessibilityText:
        return 'accessibilityText';
      case SelectorType.point:
        return 'point';
    }
  }

  @override
  String toString() => '$typeLabel: $value${index != null ? ' [$index]' : ''}';
}

/// Represents the platform type for UI automation
enum UIPlatform {
  ios,
  android,
  web,
  macos,
  linux,
  windows,
  unknown,
}

/// Backwards compatibility alias
@Deprecated('Use UIPlatform instead')
typedef DevicePlatform = UIPlatform;

/// Top-level model representing the captured UI screen state.
///
/// Contains the screenshot, device dimensions, and all selectable UI elements.
class UIScreen {
  /// Platform type (iOS, Android, Web, macOS, etc.)
  final UIPlatform platform;

  /// Path or URL to the screenshot
  final String? screenshotPath;

  /// Screenshot bytes (if available)
  final List<int>? screenshotBytes;

  /// Device width in pixels
  final int width;

  /// Device height in pixels
  final int height;

  /// All selectable UI elements on screen
  final List<UIElement> elements;

  /// Current URL (for web apps)
  final String? url;

  /// Timestamp when this screen was captured
  final DateTime capturedAt;

  const UIScreen({
    required this.platform,
    this.screenshotPath,
    this.screenshotBytes,
    required this.width,
    required this.height,
    required this.elements,
    this.url,
    required this.capturedAt,
  });

  /// Get elements that have at least one selectable attribute
  List<UIElement> get selectableElements {
    return elements.where((e) => e.hasSelectableAttribute).toList();
  }

  /// Find element at the given normalized position (0-1)
  UIElement? findElementAt(double normalizedX, double normalizedY) {
    // Filter elements that contain the point
    final matching = elements.where((element) {
      if (element.bounds == null) return false;
      return element.bounds!.containsNormalized(
        normalizedX,
        normalizedY,
        width,
        height,
      );
    }).toList();

    if (matching.isEmpty) return null;

    // Return the smallest element (most specific)
    matching.sort((a, b) {
      final aArea = a.bounds?.area ?? 9999999999;
      final bArea = b.bounds?.area ?? 9999999999;
      return aArea.compareTo(bArea);
    });

    return matching.first;
  }

  /// Search elements by query
  List<UIElement> searchElements(String query) {
    if (query.isEmpty) return selectableElements;

    final lowerQuery = query.toLowerCase();
    return selectableElements.where((element) {
      return element.text?.toLowerCase().contains(lowerQuery) == true ||
          element.resourceId?.toLowerCase().contains(lowerQuery) == true ||
          element.hintText?.toLowerCase().contains(lowerQuery) == true ||
          element.accessibilityText?.toLowerCase().contains(lowerQuery) == true;
    }).toList();
  }

  Map<String, dynamic> toJson() {
    return {
      'platform': platform.name,
      if (screenshotPath != null) 'screenshot': screenshotPath,
      'width': width,
      'height': height,
      'elements': elements.map((e) => e.toJson()).toList(),
      if (url != null) 'url': url,
      'capturedAt': capturedAt.toIso8601String(),
    };
  }

  factory UIScreen.fromJson(Map<String, dynamic> json) {
    return UIScreen(
      platform: UIPlatform.values.firstWhere(
        (p) => p.name == json['platform'],
        orElse: () => UIPlatform.unknown,
      ),
      screenshotPath: json['screenshot'] as String?,
      width: json['width'] as int,
      height: json['height'] as int,
      elements: (json['elements'] as List<dynamic>)
          .map((e) => UIElement.fromJson(e as Map<String, dynamic>))
          .toList(),
      url: json['url'] as String?,
      capturedAt: json['capturedAt'] != null
          ? DateTime.parse(json['capturedAt'] as String)
          : DateTime.now(),
    );
  }

  UIScreen copyWith({
    UIPlatform? platform,
    String? screenshotPath,
    List<int>? screenshotBytes,
    int? width,
    int? height,
    List<UIElement>? elements,
    String? url,
    DateTime? capturedAt,
  }) {
    return UIScreen(
      platform: platform ?? this.platform,
      screenshotPath: screenshotPath ?? this.screenshotPath,
      screenshotBytes: screenshotBytes ?? this.screenshotBytes,
      width: width ?? this.width,
      height: height ?? this.height,
      elements: elements ?? this.elements,
      url: url ?? this.url,
      capturedAt: capturedAt ?? this.capturedAt,
    );
  }

  @override
  String toString() =>
      'UIScreen($platform, ${width}x$height, ${elements.length} elements)';
}

/// Backwards compatibility alias
@Deprecated('Use UIScreen instead')
typedef DeviceScreen = UIScreen;

