import 'widget_entity.dart';
import 'dependency_entity.dart';

/// Domain entity representing a test case
class TestCase {
  final String id;
  final String name;
  final String description;
  final TestType type;
  final WidgetEntity targetWidget;
  final String testCode;
  final List<String> imports;
  final Map<String, dynamic> metadata;
  final DateTime createdAt;
  final DateTime? updatedAt;

  const TestCase({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.targetWidget,
    required this.testCode,
    required this.imports,
    this.metadata = const {},
    required this.createdAt,
    this.updatedAt,
  });

  /// Create a copy with updated fields
  TestCase copyWith({
    String? id,
    String? name,
    String? description,
    TestType? type,
    WidgetEntity? targetWidget,
    String? testCode,
    List<String>? imports,
    Map<String, dynamic>? metadata,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return TestCase(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      type: type ?? this.type,
      targetWidget: targetWidget ?? this.targetWidget,
      testCode: testCode ?? this.testCode,
      imports: imports ?? this.imports,
      metadata: metadata ?? this.metadata,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is TestCase && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => 'TestCase($name, $type)';
}

/// Types of tests that can be generated
enum TestType { unitTest, widgetTest, integrationTest, goldenTest }

/// Test generation request
class TestGenerationRequest {
  final WidgetEntity widget;
  final TestType testType;
  final List<WidgetDependency> dependencies;
  final Map<String, dynamic> options;
  final String? customPrompt;

  const TestGenerationRequest({
    required this.widget,
    required this.testType,
    required this.dependencies,
    this.options = const {},
    this.customPrompt,
  });

  /// Create a copy with updated fields
  TestGenerationRequest copyWith({
    WidgetEntity? widget,
    TestType? testType,
    List<WidgetDependency>? dependencies,
    Map<String, dynamic>? options,
    String? customPrompt,
  }) {
    return TestGenerationRequest(
      widget: widget ?? this.widget,
      testType: testType ?? this.testType,
      dependencies: dependencies ?? this.dependencies,
      options: options ?? this.options,
      customPrompt: customPrompt ?? this.customPrompt,
    );
  }

  @override
  String toString() =>
      'TestGenerationRequest(${widget.displayName}, $testType)';
}

/// Test generation result
class TestGenerationResult {
  final TestCase? testCase;
  final bool success;
  final String? error;
  final Duration generationTime;
  final Map<String, dynamic> metadata;

  const TestGenerationResult({
    this.testCase,
    required this.success,
    this.error,
    required this.generationTime,
    this.metadata = const {},
  });

  /// Create a copy with updated fields
  TestGenerationResult copyWith({
    TestCase? testCase,
    bool? success,
    String? error,
    Duration? generationTime,
    Map<String, dynamic>? metadata,
  }) {
    return TestGenerationResult(
      testCase: testCase ?? this.testCase,
      success: success ?? this.success,
      error: error ?? this.error,
      generationTime: generationTime ?? this.generationTime,
      metadata: metadata ?? this.metadata,
    );
  }

  @override
  String toString() =>
      'TestGenerationResult(success: $success, ${testCase?.name})';
}
