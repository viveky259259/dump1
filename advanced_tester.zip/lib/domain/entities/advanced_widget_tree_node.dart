import 'package:flutter/foundation.dart';
import 'widget_entity.dart';
import '../../services/inspector_service.dart' as inspector;

/// A class that represents a node and its properties.
/// This class stores info on Widgets as well as their properties in realtime.
/// This class intelligently decides if there is a change required to do.
class AdvancedWidgetTreeNode {
  /// Actual node instance
  final WidgetEntity node;

  /// Detailed node properties
  Map<String, dynamic> properties;

  /// List of children the node is holding, it can be one or many
  List<AdvancedWidgetTreeNode> children;

  /// To check if anything is changed
  int _nodeHashCode;

  /// Indicates completion of property population
  bool _hasPopulated;

  /// Future that returns the detailed nested properties that will include
  /// its self and children's properties when _hasPopulated is true otherwise waits
  Future<Map<String, dynamic>>? _detailedTreeFuture;

  /// Constructor for AdvancedWidgetTreeNode
  AdvancedWidgetTreeNode({
    required this.node,
    Map<String, dynamic>? properties,
    List<AdvancedWidgetTreeNode>? children,
    inspector.InspectorService? inspectorService,
  }) : properties = properties ?? {},
       children = children ?? [],
       _nodeHashCode = DateTime.now().millisecondsSinceEpoch,
       _hasPopulated = false {
    // Start populating properties automatically after construction
    _startPropertyPopulation(inspectorService);
  }

  /// Starts property population automatically after construction
  void _startPropertyPopulation(inspector.InspectorService? inspectorService) {
    // Start population asynchronously without blocking constructor
    Future.microtask(() async {
      try {
        await populateProperties(inspectorService);
      } catch (e) {
        debugPrint('Auto-population failed for ${node.displayName}: $e');
        // Don't rethrow - this is background population
      }
    });
  }

  /// Returns the detailed nested properties that will include its self and children's properties
  /// when _hasPopulated is true otherwise waits
  Future<Map<String, dynamic>> get getDetailedTree {
    if (_hasPopulated) {
      return Future.value(_buildDetailedTree());
    }

    _detailedTreeFuture ??= _waitForPopulationAndBuildTree();

    return _detailedTreeFuture!;
  }

  /// This function populates the properties from node and children's node
  /// using getWidgetDetails from InspectorService
  Future<void> populateProperties([
    inspector.InspectorService? inspectorService,
  ]) async {
    if (_hasPopulated) return;

    try {
      // Populate properties for the current node using InspectorService
      await _populateNodeProperties(inspectorService);

      // Populate properties for all children recursively
      for (final child in children) {
        await child.populateProperties(inspectorService);
      }

      _hasPopulated = true;
      _updateHashCode();
    } catch (e) {
      debugPrint(
        'Error populating properties for node ${node.displayName}: $e',
      );
      rethrow;
    }
  }

  /// Populates properties for the current node using InspectorService
  Future<void> _populateNodeProperties([
    inspector.InspectorService? inspectorService,
  ]) async {
    if (node.objectId == null) {
      debugPrint('Cannot populate properties: node.objectId is null');
      return;
    }

    // First, populate basic properties from WidgetEntity
    properties = {
      'displayName': node.displayName,
      'objectId': node.objectId,
      'effectiveWidgetType': node.effectiveWidgetType,
      'description': node.description,
      'type': node.type,
      'style': node.style,
      'properties': node.properties,
      'children': node.children,
      'hasChildren': node.hasChildren,
      'allowWrap': node.allowWrap,
      'summaryTree': node.summaryTree,
      'locationId': node.locationId,
      'creationLocation': node.creationLocation?.toString(),
      'createdByLocalProject': node.createdByLocalProject,
      'widgetRuntimeType': node.widgetRuntimeType,
      'stateful': node.stateful,
      'isFromUserProject': node.isFromUserProject,
      'hasPotentialDependencies': node.hasPotentialDependencies,
      'attributes': node.attributes
          ?.map(
            (attr) => {
              'name': attr.name,
              'label': attr.label,
              'type': attr.type,
              'value': attr.value,
            },
          )
          .toList(),
    };

    // If InspectorService is provided, get detailed properties
    if (inspectorService != null) {
      try {
        debugPrint(
          'Getting detailed properties for ${node.displayName} (${node.objectId})',
        );

        // Get detailed widget properties from InspectorService
        final detailedProperties = await inspectorService.getWidgetDetails(
          node.objectId!,
        );

        if (detailedProperties != null && detailedProperties.isNotEmpty) {
          debugPrint(
            'Received ${detailedProperties.length} detailed properties',
          );

          // Extract structured attributes from detailed properties
          final attributes = inspectorService.extractAttributesFromProperties(
            detailedProperties,
            node.effectiveWidgetType,
          );

          // Add detailed attributes to properties
          properties['detailedAttributes'] = attributes
              .map(
                (attr) => {
                  'name': attr.name,
                  'label': attr.label,
                  'type': attr.type,
                  'value': attr.value,
                },
              )
              .toList();

          // Add raw detailed properties for debugging/advanced usage
          properties['rawDetailedProperties'] = detailedProperties;

          debugPrint(
            'Added ${attributes.length} detailed attributes to properties',
          );
        } else {
          debugPrint('No detailed properties received from InspectorService');
        }
      } catch (e) {
        debugPrint(
          'Failed to get detailed properties from InspectorService: $e',
        );
        // Continue with basic properties - don't fail the entire operation
      }
    } else {
      debugPrint('No InspectorService provided - using basic properties only');
    }
  }

  /// Waits for population to complete and then builds the detailed tree
  Future<Map<String, dynamic>> _waitForPopulationAndBuildTree() async {
    while (!_hasPopulated) {
      await Future.delayed(const Duration(milliseconds: 10));
    }
    return _buildDetailedTree();
  }

  /// Builds the detailed tree structure including self and children
  Map<String, dynamic> _buildDetailedTree() {
    final Map<String, dynamic> detailedTree = Map.from(properties);

    // Add children's detailed trees
    if (children.isNotEmpty) {
      detailedTree['children'] = children
          .map((child) => child._buildDetailedTree())
          .toList();
    }

    return detailedTree;
  }

  /// Updates the hashCode to reflect changes
  void _updateHashCode() {
    _nodeHashCode = DateTime.now().millisecondsSinceEpoch;
  }

  /// Checks if the node has been populated
  bool get hasPopulated => _hasPopulated;

  /// Adds a child to this node
  void addChild(AdvancedWidgetTreeNode child) {
    children.add(child);
    _updateHashCode();
  }

  /// Removes a child from this node
  void removeChild(AdvancedWidgetTreeNode child) {
    children.remove(child);
    _updateHashCode();
  }

  /// Updates a property and marks the node as changed
  void updateProperty(String key, dynamic value) {
    properties[key] = value;
    _updateHashCode();
  }

  /// Removes a property and marks the node as changed
  void removeProperty(String key) {
    properties.remove(key);
    _updateHashCode();
  }

  /// Gets a property value
  dynamic getProperty(String key) {
    return properties[key];
  }

  /// Checks if a property exists
  bool hasProperty(String key) {
    return properties.containsKey(key);
  }

  /// Gets the total number of descendants (including self)
  int get totalDescendants {
    int count = 1; // Count self
    for (final child in children) {
      count += child.totalDescendants;
    }
    return count;
  }

  /// Gets the depth of the deepest descendant
  int get maxDepth {
    if (children.isEmpty) return 0;

    int maxChildDepth = 0;
    for (final child in children) {
      final childDepth = child.maxDepth;
      if (childDepth > maxChildDepth) {
        maxChildDepth = childDepth;
      }
    }
    return maxChildDepth + 1;
  }

  /// Finds a descendant by object ID
  AdvancedWidgetTreeNode? findDescendantById(String objectId) {
    if (node.objectId == objectId) {
      return this;
    }

    for (final child in children) {
      final found = child.findDescendantById(objectId);
      if (found != null) {
        return found;
      }
    }

    return null;
  }

  /// Finds descendants by widget type
  List<AdvancedWidgetTreeNode> findDescendantsByType(String widgetType) {
    final List<AdvancedWidgetTreeNode> results = [];

    if (node.effectiveWidgetType == widgetType) {
      results.add(this);
    }

    for (final child in children) {
      results.addAll(child.findDescendantsByType(widgetType));
    }

    return results;
  }

  /// Creates a copy of this node with updated properties
  AdvancedWidgetTreeNode copyWith({
    WidgetEntity? node,
    Map<String, dynamic>? properties,
    List<AdvancedWidgetTreeNode>? children,
    inspector.InspectorService? inspectorService,
  }) {
    return AdvancedWidgetTreeNode(
      node: node ?? this.node,
      properties: properties ?? Map.from(this.properties),
      children: children ?? List.from(this.children),
      inspectorService: inspectorService,
    );
  }

  /// Converts the node to a JSON representation
  Map<String, dynamic> toJson() {
    return {
      'node': {
        'description': node.description,
        'type': node.type,
        'objectId': node.objectId,
        'style': node.style,
        'hasChildren': node.hasChildren,
        'allowWrap': node.allowWrap,
        'summaryTree': node.summaryTree,
        'locationId': node.locationId,
        'creationLocation': node.creationLocation != null
            ? {
                'file': node.creationLocation!.file,
                'line': node.creationLocation!.line,
                'column': node.creationLocation!.column,
                'name': node.creationLocation!.name,
              }
            : null,
        'createdByLocalProject': node.createdByLocalProject,
        'widgetRuntimeType': node.widgetRuntimeType,
        'stateful': node.stateful,
        'children': node.children.map((child) => child.toString()).toList(),
        'properties': node.properties,
        'attributes': node.attributes
            ?.map(
              (attr) => {
                'name': attr.name,
                'label': attr.label,
                'type': attr.type,
                'value': attr.value,
              },
            )
            .toList(),
      },
      'properties': properties,
      'children': children.map((child) => child.toJson()).toList(),
      'hashCode': _nodeHashCode,
      'hasPopulated': _hasPopulated,
    };
  }

  /// Creates an AdvancedWidgetTreeNode from JSON
  factory AdvancedWidgetTreeNode.fromJson(
    Map<String, dynamic> json, {
    inspector.InspectorService? inspectorService,
  }) {
    final nodeJson = json['node'] as Map<String, dynamic>;
    final node = WidgetEntity(
      description: nodeJson['description'],
      type: nodeJson['type'],
      objectId: nodeJson['objectId'],
      style: nodeJson['style'],
      hasChildren: nodeJson['hasChildren'] ?? false,
      allowWrap: nodeJson['allowWrap'] ?? false,
      summaryTree: nodeJson['summaryTree'] ?? false,
      locationId: nodeJson['locationId'],
      creationLocation: nodeJson['creationLocation'] != null
          ? CreationLocation(
              file: nodeJson['creationLocation']['file'],
              line: nodeJson['creationLocation']['line'],
              column: nodeJson['creationLocation']['column'],
              name: nodeJson['creationLocation']['name'],
            )
          : null,
      createdByLocalProject: nodeJson['createdByLocalProject'],
      widgetRuntimeType: nodeJson['widgetRuntimeType'],
      stateful: nodeJson['stateful'],
      children: const [], // Children will be populated separately
      properties: nodeJson['properties'] != null
          ? Map<String, dynamic>.from(nodeJson['properties'])
          : null,
      attributes: nodeJson['attributes'] != null
          ? (nodeJson['attributes'] as List)
                .map(
                  (attrJson) => WidgetAttribute(
                    name: attrJson['name'],
                    label: attrJson['label'],
                    type: attrJson['type'],
                    value: attrJson['value'],
                  ),
                )
                .toList()
          : null,
    );

    final properties = Map<String, dynamic>.from(json['properties'] ?? {});
    final children =
        (json['children'] as List?)
            ?.map(
              (childJson) => AdvancedWidgetTreeNode.fromJson(
                childJson,
                inspectorService: inspectorService,
              ),
            )
            .toList() ??
        [];

    final instance = AdvancedWidgetTreeNode(
      node: node,
      properties: properties,
      children: children,
      inspectorService: inspectorService,
    );

    instance._nodeHashCode =
        json['hashCode'] ?? DateTime.now().millisecondsSinceEpoch;
    instance._hasPopulated = json['hasPopulated'] ?? false;

    return instance;
  }

  @override
  String toString() {
    return 'AdvancedWidgetTreeNode(node: ${node.displayName}, children: ${children.length}, hasPopulated: $_hasPopulated)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is AdvancedWidgetTreeNode &&
        other.node == node &&
        other._hasPopulated == _hasPopulated;
  }

  @override
  int get hashCode => _nodeHashCode;
}
