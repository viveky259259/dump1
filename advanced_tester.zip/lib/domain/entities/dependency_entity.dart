import 'widget_entity.dart';

/// Domain entity representing a widget dependency
class WidgetDependency {
  final String type;
  final DependencyCategory category;
  final String description;
  final String setupCode;
  final int distanceFromTarget;
  final Map<String, dynamic> metadata;

  const WidgetDependency({
    required this.type,
    required this.category,
    required this.description,
    required this.setupCode,
    required this.distanceFromTarget,
    this.metadata = const {},
  });

  /// Create a copy with updated fields
  WidgetDependency copyWith({
    String? type,
    DependencyCategory? category,
    String? description,
    String? setupCode,
    int? distanceFromTarget,
    Map<String, dynamic>? metadata,
  }) {
    return WidgetDependency(
      type: type ?? this.type,
      category: category ?? this.category,
      description: description ?? this.description,
      setupCode: setupCode ?? this.setupCode,
      distanceFromTarget: distanceFromTarget ?? this.distanceFromTarget,
      metadata: metadata ?? this.metadata,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is WidgetDependency &&
        other.type == type &&
        other.category == category &&
        other.description == description;
  }

  @override
  int get hashCode => Object.hash(type, category, description);

  @override
  String toString() => 'WidgetDependency($type, $category, $description)';
}

/// Categories of widget dependencies
enum DependencyCategory {
  provider,
  inheritedWidget,
  theme,
  navigation,
  form,
  bloc,
  custom,
  external,
}

/// Analysis result containing widget dependencies
class DependencyAnalysisResult {
  final WidgetEntity widget;
  final List<WidgetDependency> dependencies;
  final Duration analysisTime;
  final Map<String, dynamic> metadata;

  const DependencyAnalysisResult({
    required this.widget,
    required this.dependencies,
    required this.analysisTime,
    this.metadata = const {},
  });

  /// Create a copy with updated fields
  DependencyAnalysisResult copyWith({
    WidgetEntity? widget,
    List<WidgetDependency>? dependencies,
    Duration? analysisTime,
    Map<String, dynamic>? metadata,
  }) {
    return DependencyAnalysisResult(
      widget: widget ?? this.widget,
      dependencies: dependencies ?? this.dependencies,
      analysisTime: analysisTime ?? this.analysisTime,
      metadata: metadata ?? this.metadata,
    );
  }

  @override
  String toString() =>
      'DependencyAnalysisResult(${widget.displayName}, ${dependencies.length} dependencies)';
}
