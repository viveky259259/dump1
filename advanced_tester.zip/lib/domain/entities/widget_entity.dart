/// Domain entity representing a widget in the Flutter widget tree
class WidgetEntity {
  final String? description;
  final String? type;
  final String? objectId;
  final String? style;
  final bool hasChildren;
  final bool allowWrap;
  final bool summaryTree;
  final int? locationId;
  final CreationLocation? creationLocation;
  final bool? createdByLocalProject;
  final String? widgetRuntimeType;
  final bool? stateful;
  final List<WidgetEntity> children;
  final Map<String, dynamic>? properties;
  final List<WidgetAttribute>? attributes;

  const WidgetEntity({
    this.description,
    this.type,
    this.objectId,
    this.style,
    this.hasChildren = false,
    this.allowWrap = false,
    this.summaryTree = false,
    this.locationId,
    this.creationLocation,
    this.createdByLocalProject,
    this.widgetRuntimeType,
    this.stateful,
    this.children = const [],
    this.properties,
    this.attributes,
  });

  /// Get the display name for this widget
  String get displayName {
    return widgetRuntimeType ?? description ?? type ?? 'Unknown Widget';
  }

  /// Get the widget type for dependency analysis
  String? get effectiveWidgetType {
    if (widgetRuntimeType != null) return widgetRuntimeType;

    if (description != null) {
      final providerMatch = RegExp(
        r'(\w+Provider)<([^>]+)>',
      ).firstMatch(description!);
      if (providerMatch != null) {
        return providerMatch.group(1);
      }

      final inheritedMatch = RegExp(
        r'_Inherited(\w+)Scope<([^>]+)>',
      ).firstMatch(description!);
      if (inheritedMatch != null) {
        return 'InheritedWidget';
      }
    }

    return description;
  }

  /// Check if this widget is from the user's project
  bool get isFromUserProject => createdByLocalProject ?? false;

  /// Check if this widget is likely to have interesting dependencies
  bool get hasPotentialDependencies {
    final type = effectiveWidgetType?.toLowerCase() ?? '';

    if (type.contains('provider')) return true;
    if (type.contains('consumer')) return true;
    if (type.contains('inherited')) return true;
    if (type.contains('bloc')) return true;
    if (type.contains('scaffold')) return true;
    if (type.contains('theme')) return true;
    if (type.contains('navigator')) return true;
    if (type.contains('form')) return true;
    if (type.contains('tab')) return true;

    if (isFromUserProject && !_isBuiltInFlutterWidget(type)) return true;

    return false;
  }

  bool _isBuiltInFlutterWidget(String type) {
    const builtInWidgets = {
      'container',
      'column',
      'row',
      'center',
      'padding',
      'margin',
      'text',
      'icon',
      'image',
      'sizedbox',
      'expanded',
      'flexible',
      'stack',
      'positioned',
      'align',
      'wrap',
      'listview',
      'gridview',
    };
    return builtInWidgets.contains(type.toLowerCase());
  }

  /// Create a copy with updated fields
  WidgetEntity copyWith({
    String? description,
    String? type,
    String? objectId,
    String? style,
    bool? hasChildren,
    bool? allowWrap,
    bool? summaryTree,
    int? locationId,
    CreationLocation? creationLocation,
    bool? createdByLocalProject,
    String? widgetRuntimeType,
    bool? stateful,
    List<WidgetEntity>? children,
    Map<String, dynamic>? properties,
    List<WidgetAttribute>? attributes,
  }) {
    return WidgetEntity(
      description: description ?? this.description,
      type: type ?? this.type,
      objectId: objectId ?? this.objectId,
      style: style ?? this.style,
      hasChildren: hasChildren ?? this.hasChildren,
      allowWrap: allowWrap ?? this.allowWrap,
      summaryTree: summaryTree ?? this.summaryTree,
      locationId: locationId ?? this.locationId,
      creationLocation: creationLocation ?? this.creationLocation,
      createdByLocalProject:
          createdByLocalProject ?? this.createdByLocalProject,
      widgetRuntimeType: widgetRuntimeType ?? this.widgetRuntimeType,
      stateful: stateful ?? this.stateful,
      children: children ?? this.children,
      properties: properties ?? this.properties,
      attributes: attributes ?? this.attributes,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is WidgetEntity && other.objectId == objectId;
  }

  @override
  int get hashCode => objectId.hashCode;

  @override
  String toString() => 'WidgetEntity($displayName, $objectId)';
}

/// Represents the creation location of a widget in source code
class CreationLocation {
  final String file;
  final int line;
  final int column;
  final String name;

  const CreationLocation({
    required this.file,
    required this.line,
    required this.column,
    required this.name,
  });

  @override
  String toString() => '$file:$line:$column ($name)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is CreationLocation &&
        other.file == file &&
        other.line == line &&
        other.column == column &&
        other.name == name;
  }

  @override
  int get hashCode => Object.hash(file, line, column, name);
}

/// Model for widget attributes (structured property data)
class WidgetAttribute {
  final String name;
  final String label;
  final String? type;
  final dynamic value;

  const WidgetAttribute({
    required this.name,
    required this.label,
    this.type,
    this.value,
  });

  @override
  String toString() => '$name: $label';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is WidgetAttribute &&
        other.name == name &&
        other.label == label &&
        other.type == type &&
        other.value == value;
  }

  @override
  int get hashCode => Object.hash(name, label, type, value);
}
