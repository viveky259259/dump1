#!/usr/bin/env bash
# Common utilities for spec-kit scripts

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1" >&2
    exit 1
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if Flutter is installed
check_flutter() {
    if ! command_exists flutter; then
        error "Flutter is not installed or not in PATH"
    fi
}

# Check if Dart is installed
check_dart() {
    if ! command_exists dart; then
        error "Dart is not installed or not in PATH"
    fi
}

# Get Flutter version
get_flutter_version() {
    flutter --version | head -n 1 | awk '{print $2}'
}

# Get Dart version
get_dart_version() {
    dart --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+'
}

# Validate project is a Flutter project
validate_flutter_project() {
    local project_dir="$1"
    
    if [ ! -f "$project_dir/pubspec.yaml" ]; then
        error "Not a valid Flutter project: pubspec.yaml not found"
    fi
    
    if ! grep -q "flutter:" "$project_dir/pubspec.yaml"; then
        error "Not a valid Flutter project: flutter dependency not found in pubspec.yaml"
    fi
}

# Check if git repo is clean
check_git_clean() {
    if [ -n "$(git status --porcelain)" ]; then
        warning "Working directory is not clean. Consider committing changes first."
        read -p "Continue anyway? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# Create git branch for feature
create_feature_branch() {
    local feature_name="$1"
    local branch_name="feature/$feature_name"
    
    if git rev-parse --verify "$branch_name" >/dev/null 2>&1; then
        warning "Branch '$branch_name' already exists"
        read -p "Switch to it? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            git checkout "$branch_name"
        fi
    else
        info "Creating branch: $branch_name"
        git checkout -b "$branch_name"
        success "Branch created and checked out"
    fi
}

# Run Flutter tests
run_flutter_tests() {
    info "Running Flutter tests..."
    if flutter test; then
        success "All tests passed"
        return 0
    else
        error "Tests failed"
        return 1
    fi
}

# Run Flutter analyze
run_flutter_analyze() {
    info "Running Flutter analyze..."
    if flutter analyze; then
        success "No analysis issues found"
        return 0
    else
        error "Analysis found issues"
        return 1
    fi
}

# Format Dart code
format_dart_code() {
    info "Formatting Dart code..."
    dart format .
    success "Code formatted"
}

# Check prerequisites
check_prerequisites() {
    info "Checking prerequisites..."
    
    # Check Flutter
    check_flutter
    success "Flutter: $(get_flutter_version)"
    
    # Check Dart
    check_dart
    success "Dart: $(get_dart_version)"
    
    # Check Git
    if command_exists git; then
        success "Git: $(git --version | awk '{print $3}')"
    else
        warning "Git not found (optional)"
    fi
}

# Update CLAUDE.md with current spec structure
update_claude_md() {
    local project_root="$1"
    local claude_file="$project_root/CLAUDE.md"
    
    if [ ! -f "$claude_file" ]; then
        warning "CLAUDE.md not found"
        return 1
    fi
    
    # Count specs
    local spec_count=0
    if [ -d "$project_root/specs" ]; then
        spec_count=$(find "$project_root/specs" -maxdepth 1 -type d | wc -l)
        spec_count=$((spec_count - 1)) # Subtract 1 for specs directory itself
    fi
    
    info "Found $spec_count feature specification(s)"
}

# Print spec-kit banner
print_banner() {
    echo ""
    echo -e "${BLUE}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}   ${GREEN}Advanced Tester - Spec Kit${NC}           ${BLUE}║${NC}"
    echo -e "${BLUE}║${NC}   Spec-Driven Development Workflow      ${BLUE}║${NC}"
    echo -e "${BLUE}╚═══════════════════════════════════════════╝${NC}"
    echo ""
}

# Parse feature ID from directory
parse_feature_id() {
    local feature_dir="$1"
    basename "$feature_dir" | grep -oE '^[0-9]{3}'
}

# Parse feature name from directory
parse_feature_name() {
    local feature_dir="$1"
    basename "$feature_dir" | sed 's/^[0-9]\{3\}-//'
}

# Validate spec structure
validate_spec_structure() {
    local spec_dir="$1"
    local errors=0
    
    # Check required files
    local required_files=("spec.md" "plan.md" "tasks.md")
    for file in "${required_files[@]}"; do
        if [ ! -f "$spec_dir/$file" ]; then
            warning "Missing required file: $file"
            errors=$((errors + 1))
        fi
    done
    
    # Check contracts directory
    if [ ! -d "$spec_dir/contracts" ]; then
        warning "Missing contracts directory"
        errors=$((errors + 1))
    fi
    
    if [ $errors -eq 0 ]; then
        success "Spec structure is valid"
        return 0
    else
        error "Spec structure has $errors error(s)"
        return 1
    fi
}

# Export functions
export -f info success warning error
export -f command_exists check_flutter check_dart
export -f get_flutter_version get_dart_version
export -f validate_flutter_project check_git_clean
export -f create_feature_branch run_flutter_tests
export -f run_flutter_analyze format_dart_code
export -f check_prerequisites update_claude_md
export -f print_banner parse_feature_id parse_feature_name
export -f validate_spec_structure

