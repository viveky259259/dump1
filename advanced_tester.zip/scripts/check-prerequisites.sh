#!/usr/bin/env bash
# Check prerequisites for Advanced Tester development

set -e

# Source common utilities
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

print_banner

info "Checking development prerequisites for Advanced Tester..."
echo ""

# Check Flutter
info "Checking Flutter..."
if command_exists flutter; then
    flutter_version=$(get_flutter_version)
    success "Flutter $flutter_version installed"
    
    # Check if version meets minimum requirement
    required_version="3.8.1"
    if [ "$(printf '%s\n' "$required_version" "$flutter_version" | sort -V | head -n1)" = "$required_version" ]; then
        success "Flutter version meets minimum requirement (>= $required_version)"
    else
        warning "Flutter version $flutter_version is below recommended $required_version"
    fi
else
    error "Flutter is not installed"
fi

# Check Dart
info "Checking Dart..."
if command_exists dart; then
    dart_version=$(get_dart_version)
    success "Dart $dart_version installed"
else
    error "Dart is not installed"
fi

# Check Git
info "Checking Git..."
if command_exists git; then
    git_version=$(git --version | awk '{print $3}')
    success "Git $git_version installed"
else
    warning "Git is not installed (recommended for version control)"
fi

# Check if we're in a Flutter project
info "Checking project structure..."
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
if [ -f "$PROJECT_ROOT/pubspec.yaml" ]; then
    success "Found pubspec.yaml"
    
    # Check for key dependencies
    if grep -q "vm_service:" "$PROJECT_ROOT/pubspec.yaml"; then
        success "vm_service dependency found"
    else
        warning "vm_service dependency not found in pubspec.yaml"
    fi
    
    if grep -q "provider:" "$PROJECT_ROOT/pubspec.yaml"; then
        success "provider dependency found"
    else
        warning "provider dependency not found in pubspec.yaml"
    fi
else
    error "pubspec.yaml not found. Are you in the project root?"
fi

# Check spec-kit structure
info "Checking spec-kit structure..."
if [ -f "$PROJECT_ROOT/CLAUDE.md" ]; then
    success "CLAUDE.md found"
else
    warning "CLAUDE.md not found"
fi

if [ -f "$PROJECT_ROOT/memory/constitution.md" ]; then
    success "Constitution found"
else
    warning "Constitution not found"
fi

if [ -d "$PROJECT_ROOT/templates" ]; then
    success "Templates directory found"
else
    warning "Templates directory not found"
fi

if [ -d "$PROJECT_ROOT/specs" ]; then
    spec_count=$(find "$PROJECT_ROOT/specs" -maxdepth 1 -type d 2>/dev/null | wc -l)
    spec_count=$((spec_count - 1))
    success "Specs directory found ($spec_count specification(s))"
else
    info "Specs directory not found (will be created when first spec is added)"
fi

# Check dependencies
info "Checking Flutter dependencies..."
cd "$PROJECT_ROOT"
if flutter pub get > /dev/null 2>&1; then
    success "Flutter dependencies are available"
else
    warning "Failed to get Flutter dependencies. Run 'flutter pub get' manually."
fi

# Check for analyzer
info "Running Flutter analyze..."
if flutter analyze --no-fatal-infos > /dev/null 2>&1; then
    success "No critical analysis issues found"
else
    warning "Flutter analyze found some issues. Run 'flutter analyze' for details."
fi

# Check test setup
info "Checking test setup..."
if [ -d "$PROJECT_ROOT/test" ]; then
    test_count=$(find "$PROJECT_ROOT/test" -name "*.dart" | wc -l)
    success "Test directory found ($test_count test file(s))"
else
    warning "Test directory not found"
fi

# System information
echo ""
info "System Information:"
echo "  OS: $(uname -s)"
echo "  Architecture: $(uname -m)"
echo "  User: $USER"
echo "  Project Root: $PROJECT_ROOT"

# Summary
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
success "Prerequisites check complete!"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

info "Next steps:"
echo "  1. Create a new feature spec: ./scripts/create-new-feature.sh <number> <name>"
echo "  2. Use Claude with /clarify to define requirements"
echo "  3. Use /plan to create implementation plan"
echo "  4. Use /implement to execute the plan"
echo ""
echo "For more information, see: https://github.com/github/spec-kit"

