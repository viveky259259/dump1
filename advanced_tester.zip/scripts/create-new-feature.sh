#!/usr/bin/env bash
# Script to create a new feature specification from template

set -e

# Source common utilities
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

# Function to display usage
usage() {
    cat << EOF
Usage: $0 <feature-number> <feature-name>

Creates a new feature specification directory with templates.

Arguments:
    feature-number    Three-digit feature number (e.g., 001, 002)
    feature-name      Feature name in kebab-case (e.g., golden-test-support)

Example:
    $0 001 golden-test-support

This will create:
    specs/001-golden-test-support/
    ├── spec.md
    ├── plan.md
    ├── tasks.md
    ├── research.md
    └── contracts/

EOF
    exit 1
}

# Validate arguments
if [ $# -ne 2 ]; then
    echo "Error: Incorrect number of arguments"
    usage
fi

FEATURE_NUMBER=$1
FEATURE_NAME=$2
FEATURE_TITLE=$(echo "$FEATURE_NAME" | tr '-' ' ' | awk '{for(i=1;i<=NF;i++) $i=toupper(substr($i,1,1)) tolower(substr($i,2))}1')
FEATURE_DIR="specs/${FEATURE_NUMBER}-${FEATURE_NAME}"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Validate feature number format
if ! [[ $FEATURE_NUMBER =~ ^[0-9]{3}$ ]]; then
    error "Feature number must be three digits (e.g., 001, 002, 010)"
fi

# Validate feature name format (kebab-case)
if ! [[ $FEATURE_NAME =~ ^[a-z0-9]+(-[a-z0-9]+)*$ ]]; then
    error "Feature name must be in kebab-case (e.g., golden-test-support)"
fi

# Check if feature already exists
if [ -d "$PROJECT_ROOT/$FEATURE_DIR" ]; then
    error "Feature directory already exists: $FEATURE_DIR"
fi

# Get today's date
TODAY=$(date +"%Y-%m-%d")

info "Creating feature specification: $FEATURE_NUMBER-$FEATURE_NAME"

# Create feature directory structure
mkdir -p "$PROJECT_ROOT/$FEATURE_DIR/contracts"

# Copy and customize spec template
info "Creating spec.md from template..."
cat "$PROJECT_ROOT/templates/spec-template.md" | \
    sed "s/\[Feature Name\]/$FEATURE_TITLE/g" | \
    sed "s/\[XXX-feature-name\]/$FEATURE_NUMBER-$FEATURE_NAME/g" | \
    sed "s/\[Date\]/$TODAY/g" | \
    sed "s/\[Status\]/🔄 In Planning/g" \
    > "$PROJECT_ROOT/$FEATURE_DIR/spec.md"

# Copy and customize plan template
info "Creating plan.md from template..."
cat "$PROJECT_ROOT/templates/plan-template.md" | \
    sed "s/\[Feature Name\]/$FEATURE_TITLE/g" | \
    sed "s/\[XXX-feature-name\]/$FEATURE_NUMBER-$FEATURE_NAME/g" | \
    sed "s/\[Date\]/$TODAY/g" \
    > "$PROJECT_ROOT/$FEATURE_DIR/plan.md"

# Copy and customize tasks template
info "Creating tasks.md from template..."
cat "$PROJECT_ROOT/templates/tasks-template.md" | \
    sed "s/\[Feature Name\]/$FEATURE_TITLE/g" | \
    sed "s/\[Date\]/$TODAY/g" \
    > "$PROJECT_ROOT/$FEATURE_DIR/tasks.md"

# Create research.md
info "Creating research.md..."
cat > "$PROJECT_ROOT/$FEATURE_DIR/research.md" << EOF
# Research: $FEATURE_TITLE

## Overview
This document contains research findings and technical discoveries related to the implementation of $FEATURE_TITLE.

## Research Areas

### Area 1: [Research Topic]
**Research Question**: [Question to answer]

**Findings**:
- Finding 1
- Finding 2
- Finding 3

**Sources**:
- [Source 1](link)
- [Source 2](link)

**Recommendations**:
- Recommendation 1
- Recommendation 2

---

### Area 2: [Research Topic]
**Research Question**: [Question to answer]

**Findings**:
- Finding 1
- Finding 2

**Sources**:
- [Source 1](link)

**Recommendations**:
- Recommendation 1

---

## Technology Stack Validation

### Flutter SDK Requirements
- **Current Version**: [Version]
- **Required Version**: >= X.Y.Z
- **Compatibility**: [Notes]

### Dependencies
| Package | Version | Purpose | Status |
|---------|---------|---------|--------|
| package_name | ^X.Y.Z | Purpose | ✅ Compatible |

### API Compatibility
- Flutter VM Service: [Version/Compatibility notes]
- Flutter Inspector Extensions: [Availability notes]

---

## Similar Implementations

### Implementation 1: [Name/Project]
**Source**: [Link]

**Approach**: [Description]

**Pros**:
- Pro 1
- Pro 2

**Cons**:
- Con 1
- Con 2

**Applicability**: [How it applies to our case]

---

### Implementation 2: [Name/Project]
**Source**: [Link]

**Approach**: [Description]

**Applicability**: [How it applies to our case]

---

## Performance Considerations

### Benchmarks
- Benchmark 1: [Results]
- Benchmark 2: [Results]

### Bottlenecks
- Potential bottleneck 1: [Description and mitigation]
- Potential bottleneck 2: [Description and mitigation]

---

## Security Considerations

### Potential Risks
- Risk 1: [Description]
- Risk 2: [Description]

### Mitigation Strategies
- Strategy 1
- Strategy 2

---

## Open Questions

### Technical Questions
- [ ] Question 1?
- [ ] Question 2?
- [ ] Question 3?

### Research Tasks
- [ ] Research task 1
- [ ] Research task 2

---

**Created**: $TODAY
**Last Updated**: $TODAY
**Status**: In Progress
EOF

# Create quickstart.md
info "Creating quickstart.md..."
cat > "$PROJECT_ROOT/$FEATURE_DIR/quickstart.md" << EOF
# Quickstart: $FEATURE_TITLE

## What is this feature?
[Brief 1-2 sentence description]

## Why do we need it?
[Brief explanation of the problem it solves]

## How does it work?
[High-level explanation of the solution]

## Quick Usage Example

\`\`\`dart
// Example code showing how to use the feature
final feature = Feature();
await feature.doSomething();
\`\`\`

## What's Next?
1. Review the [full specification](spec.md)
2. Check the [implementation plan](plan.md)
3. View [task breakdown](tasks.md)
4. Read [research findings](research.md)

---

**Created**: $TODAY
EOF

# Create contracts directory README
cat > "$PROJECT_ROOT/$FEATURE_DIR/contracts/README.md" << EOF
# API Contracts

This directory contains API contracts and specifications for $FEATURE_TITLE.

## Files

- \`api-spec.json\` - REST API specifications (if applicable)
- \`service-contract.md\` - Service interface contracts
- \`data-models.md\` - Data model specifications

## Purpose

Contracts define the interfaces between components and ensure:
- Consistent API design
- Clear communication between layers
- Easier testing with mocks
- Better documentation

---

**Created**: $TODAY
EOF

success "Feature specification created successfully!"

echo ""
info "Next steps:"
echo "  1. Edit spec.md to define the feature requirements"
echo "  2. Use Claude with /clarify to gather more details"
echo "  3. Use /plan to create the technical implementation plan"
echo "  4. Review and refine the specification"
echo "  5. Use /implement when ready to build"
echo ""
echo "Feature directory: $FEATURE_DIR"

