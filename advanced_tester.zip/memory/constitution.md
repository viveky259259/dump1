# Advanced Tester - Project Constitution

## Core Principles

This document defines the fundamental principles and guidelines that govern the Advanced Tester project. All features, implementations, and decisions must align with these principles.

## 1. Architecture Principles

### 1.1 Clean Architecture
- **MUST** maintain clear separation between domain, data, and presentation layers
- **MUST NOT** create dependencies from inner layers to outer layers
- **MUST** use dependency inversion for cross-layer communication
- **SHOULD** use use cases for all business logic
- **SHOULD** keep entities free from framework dependencies

### 1.2 Service Architecture
- **MUST** implement proper initialization and disposal patterns
- **MUST** use async/await for all I/O operations
- **MUST NOT** perform blocking operations on the main thread
- **SHOULD** implement caching where performance benefits exist
- **SHOULD** provide health monitoring capabilities

### 1.3 State Management
- **MUST** use Provider for state management
- **MUST** keep state immutable where possible
- **SHOULD** use ChangeNotifier for complex state
- **SHOULD NOT** expose business logic in state classes

## 2. Code Quality Principles

### 2.1 Dart Style and Conventions
- **MUST** follow the official Dart style guide
- **MUST** pass all linter rules defined in `analysis_options.yaml`
- **MUST** use meaningful variable and function names
- **SHOULD** prefer composition over inheritance
- **SHOULD** use const constructors where possible

### 2.2 Documentation
- **MUST** document all public APIs with dartdoc comments
- **MUST** include parameter descriptions and return values
- **MUST** provide usage examples for complex functionality
- **SHOULD** document error conditions and exceptions
- **SHOULD** maintain up-to-date documentation files

### 2.3 Error Handling
- **MUST** implement try-catch blocks for all service operations
- **MUST** provide meaningful error messages to users
- **MUST** log errors with sufficient context for debugging
- **SHOULD** implement graceful degradation where possible
- **SHOULD NOT** expose implementation details in error messages

## 3. Performance Principles

### 3.1 Memory Management
- **MUST** dispose of resources properly (streams, controllers, services)
- **MUST** use object groups for VM service connections
- **MUST** implement proper cleanup in dispose methods
- **SHOULD** monitor memory usage in services
- **SHOULD** use weak references where appropriate

### 3.2 Performance Optimization
- **MUST NOT** block the UI thread with long operations
- **MUST** use async operations for I/O
- **SHOULD** implement caching for expensive operations
- **SHOULD** use const constructors to reduce rebuilds
- **SHOULD** implement proper widget keys for list optimization

### 3.3 Responsiveness
- **MUST** provide feedback during long operations
- **MUST** keep UI responsive during background work
- **SHOULD** show progress indicators for operations > 500ms
- **SHOULD** implement cancellation for long operations

## 4. Flutter VM Service Integration Principles

### 4.1 Service Extension Usage
- **MUST** check service extension availability before calling
- **MUST** handle service extension failures gracefully
- **SHOULD** cache service extension availability checks
- **SHOULD** implement fallback behaviors when extensions are unavailable

### 4.2 Inspector Service Integration
- **MUST** use Flutter's official inspector service extensions
- **MUST** manage object groups properly to prevent memory leaks
- **SHOULD** batch inspector calls where possible
- **SHOULD** implement timeout handling for inspector calls

### 4.3 Widget Tree Operations
- **MUST** respect widget tree immutability
- **MUST** handle large widget trees efficiently
- **SHOULD** implement progressive loading for large trees
- **SHOULD** cache widget tree data appropriately

## 5. Testing Principles

### 5.1 Test Coverage
- **MUST** write unit tests for all services
- **MUST** write widget tests for UI components
- **SHOULD** write integration tests for critical workflows
- **SHOULD** achieve >80% code coverage for core services

### 5.2 Test Quality
- **MUST** test error conditions and edge cases
- **MUST** use mocks for external dependencies
- **SHOULD** follow AAA pattern (Arrange, Act, Assert)
- **SHOULD** keep tests focused and isolated

### 5.3 Test Generation
- **MUST** generate complete, runnable test files
- **MUST** include all necessary imports and setup code
- **SHOULD** generate assertions based on widget properties
- **SHOULD** include mock objects for detected dependencies

## 6. User Experience Principles

### 6.1 Interface Design
- **MUST** maintain consistency with Flutter DevTools UI patterns
- **MUST** provide clear visual feedback for all actions
- **SHOULD** use familiar Flutter DevTools iconography
- **SHOULD** implement keyboard shortcuts for common actions

### 6.2 Error Communication
- **MUST** show clear, actionable error messages
- **MUST NOT** show stack traces to end users
- **SHOULD** provide suggestions for resolving errors
- **SHOULD** log detailed errors for debugging

### 6.3 Performance Perception
- **MUST** show loading indicators during operations
- **MUST** keep UI responsive during background work
- **SHOULD** implement optimistic UI updates where safe
- **SHOULD** provide operation cancellation options

## 7. Dependency Analysis Principles

### 7.1 Detection Accuracy
- **MUST** detect all Provider-based dependencies
- **MUST** detect all InheritedWidget dependencies
- **SHOULD** detect custom state management patterns
- **SHOULD** minimize false positives in detection

### 7.2 Analysis Performance
- **MUST** complete analysis within 5 seconds for typical widgets
- **SHOULD** provide progress feedback for long analyses
- **SHOULD** cache analysis results appropriately
- **SHOULD** implement incremental analysis where possible

### 7.3 Test Setup Generation
- **MUST** generate valid Dart test setup code
- **MUST** include all detected dependencies in setup
- **SHOULD** order dependencies correctly (parent to child)
- **SHOULD** generate mock objects for complex dependencies

## 8. AI Test Generation Principles

### 8.1 Code Quality
- **MUST** generate syntactically correct Dart code
- **MUST** generate complete, runnable tests
- **MUST** follow Flutter testing best practices
- **SHOULD** generate idiomatic Dart code

### 8.2 Test Completeness
- **MUST** include widget building tests
- **SHOULD** include interaction tests (tap, scroll, etc.)
- **SHOULD** include state verification tests
- **SHOULD** include accessibility tests where applicable

### 8.3 Maintainability
- **MUST** generate readable, well-formatted code
- **SHOULD** include comments for complex setup
- **SHOULD** use descriptive test names
- **SHOULD** organize tests logically (arrange, act, assert)

## 9. Security Principles

### 9.1 Data Handling
- **MUST** validate all user inputs
- **MUST** sanitize file paths before use
- **SHOULD NOT** log sensitive information
- **SHOULD** use secure storage for credentials

### 9.2 VM Service Connection
- **MUST** validate VM service URIs before connecting
- **SHOULD** implement timeout for connection attempts
- **SHOULD** handle connection failures gracefully

## 10. Backwards Compatibility Principles

### 10.1 API Stability
- **MUST NOT** break existing public APIs without major version bump
- **MUST** deprecate APIs before removing them
- **SHOULD** maintain deprecated APIs for at least one major version
- **SHOULD** provide migration guides for breaking changes

### 10.2 Data Format Compatibility
- **MUST** maintain compatibility with saved preferences
- **SHOULD** version data formats for future migration
- **SHOULD** handle missing or malformed data gracefully

## 11. DevTools Server Integration Principles

### 11.1 Server Communication
- **MUST** handle server unavailability gracefully
- **MUST** implement retry logic for failed requests
- **SHOULD** cache server responses where appropriate
- **SHOULD** provide offline mode where feasible

### 11.2 Service Discovery
- **MUST** auto-discover DevTools server when possible
- **SHOULD** allow manual server configuration
- **SHOULD** validate server compatibility

## 12. Configuration Management Principles

### 12.1 Project Configuration
- **MUST** validate Flutter project structure before loading
- **MUST** persist project selections across sessions
- **SHOULD** support multiple Flutter SDK versions
- **SHOULD** provide SDK path auto-detection

### 12.2 User Preferences
- **MUST** persist user preferences across sessions
- **SHOULD** provide preference reset functionality
- **SHOULD** validate preferences before applying
- **SHOULD** provide sensible defaults

## 13. Extensibility Principles

### 13.1 Plugin Architecture (Future)
- **SHOULD** design for future plugin support
- **SHOULD** define clear extension points
- **SHOULD** document extension mechanisms
- **SHOULD** maintain core stability with plugins

### 13.2 Custom Patterns
- **SHOULD** allow user-defined dependency patterns
- **SHOULD** support custom test templates
- **SHOULD** provide pattern import/export
- **SHOULD** validate custom patterns

## 14. Development Workflow Principles

### 14.1 Version Control
- **MUST** commit working code only
- **MUST** write descriptive commit messages
- **SHOULD** use feature branches for new features
- **SHOULD** squash commits before merging

### 14.2 Code Review
- **MUST** review all code changes before merging
- **SHOULD** verify tests pass before review
- **SHOULD** check documentation updates
- **SHOULD** validate against this constitution

### 14.3 Release Process
- **MUST** update version numbers appropriately
- **MUST** update CHANGELOG.md for releases
- **SHOULD** create release notes for major releases
- **SHOULD** tag releases in version control

## 15. Innovation and Evolution

### 15.1 Continuous Improvement
- **SHOULD** evaluate new Flutter features for adoption
- **SHOULD** monitor Flutter DevTools for new patterns
- **SHOULD** gather user feedback for improvements
- **SHOULD** refactor when patterns emerge

### 15.2 Technical Debt
- **MUST** document known technical debt
- **SHOULD** allocate time for debt reduction
- **SHOULD** prevent debt accumulation
- **SHOULD** refactor before adding complexity

## Enforcement

This constitution is enforced through:
1. **Code Review**: All changes must be reviewed against these principles
2. **Automated Checks**: Linters, analyzers, and tests enforce code quality
3. **Documentation**: Principles are documented and accessible
4. **AI Agent Guidance**: Claude follows these principles in all implementations

## Amendment Process

This constitution may be amended when:
1. Project needs evolve significantly
2. New best practices emerge in Flutter ecosystem
3. Performance or security concerns arise
4. User feedback indicates need for change

Amendments must be:
1. Documented with rationale
2. Communicated to all contributors
3. Reflected in codebase gradually
4. Backwards compatible where possible

---

**Adopted**: October 1, 2025
**Version**: 1.0.0
**Status**: Active

