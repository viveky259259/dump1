# Claude AI Agent Instructions for Advanced Tester

## Project Context

You are working on **Advanced Tester**, an advanced Flutter testing framework that provides widget inspection, dependency analysis, and automated test generation capabilities. This is a sophisticated Flutter application that integrates with Flutter's VM service to provide DevTools-like functionality for automated test generation.

## Project Identity

- **Name**: Advanced Tester
- **Type**: Flutter Desktop Application + DevTools Integration
- **Primary Language**: Dart/Flutter
- **Target Platforms**: macOS, Linux, Windows
- **Current Version**: 1.0.0+1
- **Status**: Active Development - Production Ready Core Features

## Core Purpose

This framework enables Flutter developers to:
1. Visually inspect running Flutter applications
2. Analyze widget dependencies automatically
3. Generate comprehensive widget tests with proper setup code
4. Navigate widget trees interactively
5. Extract widget properties for test assertions

## Architecture Philosophy

The project follows **Clean Architecture** principles with clear separation:
- **Domain Layer**: Business logic, entities, use cases
- **Data Layer**: Repositories, data sources, mappers
- **Presentation Layer**: UI, controllers, providers
- **Services Layer**: Infrastructure services (Inspector, VM Service, etc.)

## Key Technologies & Dependencies

### Core Flutter Dependencies
- `vm_service: 15.0.0` - Flutter VM service integration
- `provider: ^6.1.2` - State management
- `webview_flutter: ^4.7.0` - DevTools web content display
- `multi_split_view: ^3.2.0` - Resizable panel UI
- `shared_preferences: ^2.3.2` - Settings persistence
- `http: ^1.2.2` - HTTP communication
- `file_selector: ^1.0.3` - File/folder selection

### Development Environment
- Flutter SDK: ^3.8.1
- Dart SDK: ^3.8.1

## Project Structure

```
advanced_tester/
├── lib/
│   ├── core/                    # Core architecture components
│   │   ├── analysis/            # Analysis utilities
│   │   ├── architecture/        # Architecture documentation
│   │   ├── config/              # Configuration management
│   │   ├── di/                  # Dependency injection
│   │   └── services/            # Clean architecture service manager
│   ├── data/                    # Data layer
│   │   ├── datasources/         # VM service, file system access
│   │   ├── mappers/             # Entity <-> Model mappers
│   │   └── repositories/        # Repository implementations
│   ├── domain/                  # Domain layer
│   │   ├── entities/            # Business entities
│   │   ├── repositories/        # Repository interfaces
│   │   └── usecases/            # Business use cases
│   ├── examples/                # Usage examples
│   ├── presentation/            # Presentation layer
│   │   ├── controllers/         # UI controllers
│   │   └── providers/           # State providers
│   ├── services/                # Infrastructure services
│   │   ├── inspector_service.dart           # Widget tree inspection
│   │   ├── dependency_analysis_service.dart # Dependency detection
│   │   ├── ai_test_generation_service.dart  # AI-powered test generation
│   │   ├── service_manager.dart             # Service orchestration
│   │   └── [other services]
│   ├── state/                   # Application state
│   ├── ui/                      # User interface
│   │   ├── pages/               # Main pages
│   │   └── widgets/             # Reusable widgets
│   └── main.dart                # Application entry point
├── docs/                        # Comprehensive documentation
├── specs/                       # Spec-kit specifications (NEW)
├── memory/                      # AI agent memory (NEW)
├── scripts/                     # Automation scripts (NEW)
├── templates/                   # Spec templates (NEW)
└── test/                        # Test files
```

## Available Commands (Spec-Kit Workflow)

When working with this codebase, you have access to:

### `/clarify` - Specification Clarification
Use this to ask structured clarifying questions about feature requirements before creating specifications. This ensures comprehensive understanding before implementation.

### `/plan` - Technical Planning
Generate detailed implementation plans including:
- Architecture decisions
- Data models
- API specifications
- Task breakdowns
- Research areas

### `/implement` - Execution
Execute the implementation plan step-by-step, following TDD principles and the task breakdown.

## Working Principles (Constitution)

When working on this project, always:

1. **Follow Clean Architecture**: Maintain clear layer separation
2. **Use VM Service Patterns**: Leverage Flutter's inspector service extensions
3. **Implement Proper Disposal**: Services must properly clean up resources
4. **Cache Intelligently**: Use caching for performance but maintain freshness
5. **Handle Errors Gracefully**: Comprehensive error handling with user feedback
6. **Document Thoroughly**: All public APIs must be documented
7. **Test Comprehensively**: Services need unit tests, UI needs widget tests
8. **Optimize Performance**: Monitor memory, avoid blocking operations
9. **Follow Dart Conventions**: Official Dart style guide
10. **Maintain Backwards Compatibility**: Consider existing features

## Key Service Patterns

### Inspector Service Pattern
```dart
// Always check service extension availability
if (await vmService.isServiceExtensionAvailable('ext.flutter.inspector.XXX')) {
  final result = await vmService.callServiceExtension('ext.flutter.inspector.XXX');
}
```

### Dependency Analysis Pattern
```dart
final dependencyService = EnhancedDependencyAnalysisService(inspectorService);
final result = await dependencyService.analyzeWidgetDependencies(widget);
```

### Test Generation Pattern
```dart
final serviceManager = ServiceManager();
await serviceManager.initializeServices(vmServiceUri);
final testCode = await serviceManager.generateTestSetupCode(widget);
```

## Current Feature Status

### ✅ Completed Features
1. **Widget Inspector Service** - Full widget tree inspection
2. **Dependency Analysis** - Multi-layered dependency detection
3. **Service Management** - Centralized service coordination
4. **UI Components** - Multi-panel resizable interface
5. **Property Extraction** - Widget-specific property extraction
6. **Test Generation** - Automated test code generation
7. **Project Management** - Flutter project selection and configuration

### 🔄 Planned Features (Roadmap)
1. **AI-Enhanced Test Generation** - LLM-powered test generation
2. **Golden Test Support** - Visual regression testing
3. **Integration Test Generation** - End-to-end test generation
4. **Performance Profiling** - Widget performance analysis
5. **Custom Dependency Patterns** - User-defined patterns
6. **Plugin System** - Extensible architecture

## Important Files Reference

### Critical Service Files
- `lib/services/inspector_service.dart` (1,673 lines) - Core widget inspection
- `lib/services/service_manager.dart` (421 lines) - Service coordination
- `lib/services/ai_test_generation_service.dart` (1,923 lines) - AI test generation
- `lib/services/dependency_analysis_service.dart` (761 lines) - Dependency analysis

### Critical UI Files
- `lib/ui/pages/home_page.dart` (557 lines) - Main application UI
- `lib/ui/widgets/widget_tree_panel.dart` - Widget tree visualization
- `lib/ui/widgets/enhanced_widget_details_panel.dart` - Widget details

### Documentation Files
- `docs/FEATURE_DOCUMENTATION.md` - Complete feature overview
- `docs/WIDGET_INSPECTOR.md` - Inspector implementation guide
- `docs/WIDGET_DEPENDENCY_ANALYSIS_IMPLEMENTATION.md` - Dependency analysis guide
- `docs/AI_TEST_GENERATION.md` - AI test generation documentation

## Development Workflow

### For New Features
1. Create specification in `specs/[feature-number]-[feature-name]/`
2. Use `/clarify` to gather requirements
3. Use `/plan` to create technical implementation plan
4. Review and validate plan against constitution
5. Use `/implement` to execute plan
6. Update documentation
7. Create tests
8. Create pull request

### For Bug Fixes
1. Understand the issue thoroughly
2. Locate affected services/components
3. Implement fix with proper error handling
4. Add regression tests
5. Update documentation if needed

### For Refactoring
1. Maintain backwards compatibility
2. Preserve existing functionality
3. Improve performance and maintainability
4. Update tests
5. Update documentation

## Quality Standards

### Code Quality
- Dart analyzer must pass (see `analysis_options.yaml`)
- No linter errors or warnings
- Proper null safety
- Meaningful variable names
- Comprehensive documentation

### Testing Standards
- Unit tests for all services
- Widget tests for UI components
- Integration tests for workflows
- Performance tests for critical paths
- Memory leak detection

### Documentation Standards
- All public APIs documented
- Usage examples provided
- Architecture decisions recorded
- Breaking changes highlighted

## Anti-Patterns to Avoid

❌ **DON'T**:
- Create services without proper disposal
- Use blocking operations in UI thread
- Ignore error handling in service calls
- Create circular dependencies
- Hardcode configuration values
- Skip documentation for public APIs
- Create dependencies between UI and services directly (use use cases)
- Violate clean architecture boundaries

✅ **DO**:
- Use dependency injection
- Implement proper resource cleanup
- Use async/await properly
- Follow clean architecture principles
- Cache intelligently
- Handle errors gracefully
- Document thoroughly

## Communication Style

When interacting with developers:
- Be specific about file locations and line numbers
- Provide code examples for complex patterns
- Reference existing implementations
- Explain architectural decisions
- Ask for clarification when requirements are ambiguous
- Suggest improvements based on best practices
- Validate against the constitution

## Research and External Knowledge

When encountering:
- **Flutter/Dart updates**: Research latest stable versions
- **VM Service changes**: Check Flutter DevTools implementation
- **Performance issues**: Research Flutter performance best practices
- **Architecture questions**: Reference clean architecture principles
- **New features**: Research similar implementations in DevTools

## Memory and Context

Important context to remember:
- This project is inspired by Flutter DevTools Inspector
- The framework integrates deeply with Flutter's VM service
- Users are Flutter developers who want automated test generation
- The UI should be familiar to DevTools users
- Performance is critical (real-time widget inspection)
- The framework must handle large widget trees efficiently

## Getting Help

When stuck:
1. Check existing documentation in `docs/`
2. Review similar implementations in `lib/examples/`
3. Reference Flutter DevTools source code
4. Ask for clarification from the user
5. Research online for Flutter VM service patterns

## Success Criteria

A feature is considered successful when:
- [ ] Meets all specification requirements
- [ ] Passes all tests (unit, widget, integration)
- [ ] Has comprehensive documentation
- [ ] Follows clean architecture principles
- [ ] Has no linter errors or warnings
- [ ] Performs efficiently (no blocking operations)
- [ ] Handles errors gracefully
- [ ] Includes usage examples
- [ ] Maintains backwards compatibility
- [ ] Has been code reviewed

## Current Sprint Focus

Based on the latest commits and project status:
1. Enhance AI-powered test generation capabilities
2. Improve widget property extraction accuracy
3. Optimize dependency analysis performance
4. Enhance UI/UX for better developer experience
5. Expand documentation and examples

---

**Last Updated**: October 1, 2025
**Template Version**: 1.0.0
**Spec-Kit Compatible**: Yes

