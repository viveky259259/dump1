# Getting Started with Spec-Driven Development

## 🎉 Welcome!

Your Advanced Tester project is now equipped with **Spec-Driven Development** based on [GitHub's Spec-Kit](https://github.com/github/spec-kit).

## ⚡ Quick Start (30 seconds)

### 1. Check Your Setup
```bash
./scripts/check-prerequisites.sh
```

### 2. Create Your First Feature Spec
```bash
./scripts/create-new-feature.sh 002 my-awesome-feature
```

### 3. Open Claude Code and Say:
```
/clarify

I want to add [describe your feature]
```

That's it! You're now doing Spec-Driven Development! 🚀

---

## 📖 The Three Commands

### `/clarify` - Understand Requirements
Claude asks structured questions to fully understand what you want to build.

**Example:**
```
/clarify

I want to add integration test generation that records user flows
and creates end-to-end tests automatically.
```

Claude will ask about:
- Technical approach
- Integration points
- Edge cases
- User experience

### `/plan` - Create Technical Design
Claude creates a detailed implementation plan.

**Example:**
```
/plan

Use Flutter's integration_test package. Record interactions from
the widget inspector. Generate test files with proper setup and assertions.
```

Claude creates:
- Architecture overview
- Data models
- API specifications  
- Task breakdown
- Testing strategy

### `/implement` - Build It
Claude executes the plan step-by-step.

**Example:**
```
/implement
```

Claude implements:
- Domain entities
- Use cases
- Data layer
- Services
- UI components
- Tests
- Documentation

---

## 🎯 Your First Feature (5 minutes)

Let's create a simple feature together!

### Step 1: Create the Spec
```bash
./scripts/create-new-feature.sh 002 widget-search
```

### Step 2: Tell Claude What You Want
```
/clarify

I want to add a search feature to the widget tree panel.
Users should be able to search for widgets by type or name,
and the tree should filter to show only matching widgets.
```

### Step 3: Let Claude Ask Questions
Claude will ask things like:
- Should search be case-sensitive?
- Should it search widget properties too?
- What should happen to child widgets?
- Should there be search history?

Answer naturally - Claude captures everything in the spec!

### Step 4: Create the Plan
```
/plan

Add a search bar above the widget tree. Search should be:
- Case-insensitive by default
- Real-time (search as you type)
- Highlight matches in the tree
- Show match count

Use the existing InspectorService for widget data.
```

### Step 5: Review the Plan
Claude shows you:
- What files will be created/modified
- Architecture decisions
- Implementation phases
- Testing approach

Ask questions like:
```
Does this follow our clean architecture?
Are there any performance concerns?
What if the widget tree is huge?
```

### Step 6: Build It!
```
/implement
```

Watch Claude:
1. Create domain entities
2. Add use cases
3. Build the UI
4. Write tests
5. Update docs

---

## 📚 Essential Reading (10 minutes)

### Must Read
1. **[README_SPEC_KIT.md](../README_SPEC_KIT.md)** - Complete overview (5 min)
2. **[spec-driven.md](../spec-driven.md)** - Workflow guide (5 min)

### When You Need It
3. **[memory/constitution.md](../memory/constitution.md)** - Project principles
4. **[CLAUDE.md](../CLAUDE.md)** - AI agent instructions
5. **[specs/001-golden-test-generation/](../specs/001-golden-test-generation/)** - Example spec

---

## 🎨 Directory Tour

```
advanced_tester/
│
├── 📘 CLAUDE.md                    # Claude's instruction manual
├── 📘 README_SPEC_KIT.md          # Your main guide  
├── 📘 spec-driven.md              # Workflow reference
│
├── 🧠 memory/
│   └── constitution.md            # Project laws
│
├── 📋 templates/
│   ├── spec-template.md           # For requirements
│   ├── plan-template.md           # For technical design
│   └── tasks-template.md          # For implementation
│
├── 🤖 scripts/
│   ├── create-new-feature.sh      # Scaffold new features
│   └── check-prerequisites.sh     # Validate setup
│
└── 📦 specs/
    └── 001-golden-test-generation/  # Example feature
        ├── spec.md                  # What to build
        ├── plan.md                  # How to build it
        └── tasks.md                 # Step by step
```

---

## 🎓 Learning Path

### Beginner (Today)
1. ✅ Read this file
2. ⬜ Run `./scripts/check-prerequisites.sh`
3. ⬜ Browse `specs/001-golden-test-generation/spec.md`
4. ⬜ Try `/clarify` with a small feature idea

### Intermediate (This Week)
1. ⬜ Create a real feature spec
2. ⬜ Use `/clarify` to fully define it
3. ⬜ Generate a plan with `/plan`
4. ⬜ Review and refine the plan

### Advanced (This Month)
1. ⬜ Implement a feature with `/implement`
2. ⬜ Customize templates for your needs
3. ⬜ Update constitution based on learnings
4. ⬜ Create your own workflow scripts

---

## 💡 Pro Tips

### Tip 1: Be Specific with `/clarify`
**Good:**
```
/clarify

I want to add dark mode support. Users should be able to toggle
between light and dark themes from settings. The preference should
persist across app restarts.
```

**Not So Good:**
```
Add dark mode
```

### Tip 2: Provide Context with `/plan`
**Good:**
```
/plan

Use Flutter's ThemeMode with Provider for state management.
Store preference in SharedPreferences. Support system theme setting.
```

**Not So Good:**
```
/plan

Just make it work
```

### Tip 3: Review Before `/implement`
Always ask Claude:
```
Review this plan against the project constitution.
Check for:
- Clean architecture violations
- Missing error handling
- Performance issues
- Incomplete testing
```

---

## 🚨 Common Pitfalls

### ❌ Skipping `/clarify`
**Don't:**
```
/plan

Add some kind of export feature
```

**Do:**
```
/clarify

I want users to be able to export generated tests.
They should choose the export format and destination.
```

### ❌ Vague Requirements
**Don't:**
```
Make the UI better
```

**Do:**
```
/clarify

I want to improve the widget tree panel by:
- Adding icons for widget types
- Showing widget hierarchy with indentation
- Making it collapsible/expandable
```

### ❌ Implementing Without Planning
**Don't:**
```
/implement

[without a plan.md]
```

**Do:**
```
/plan
[review the plan]
/implement
```

---

## 🎯 Your Roadmap

### This Week
- [ ] Read all documentation
- [ ] Run prerequisites check
- [ ] Create first feature spec
- [ ] Use `/clarify` successfully

### This Month
- [ ] Complete first spec-driven feature
- [ ] Refine templates based on experience
- [ ] Add custom scripts if needed
- [ ] Update constitution with learnings

### This Quarter
- [ ] All new features use spec-driven workflow
- [ ] Build library of specs
- [ ] Measure improvement in code quality
- [ ] Share approach with team

---

## 🤝 Need Help?

### Questions About Workflow
- Read [spec-driven.md](../spec-driven.md)
- Check [README_SPEC_KIT.md](../README_SPEC_KIT.md)
- Review example in `specs/001-golden-test-generation/`

### Questions About Project
- Check [CLAUDE.md](../CLAUDE.md) for project context
- Review [memory/constitution.md](../memory/constitution.md) for principles
- See [docs/FEATURE_DOCUMENTATION.md](../docs/FEATURE_DOCUMENTATION.md)

### Issues or Bugs
- GitHub Spec-Kit: https://github.com/github/spec-kit
- Advanced Tester: Create an issue in your repo

---

## 🌟 Success Metrics

You're succeeding with Spec-Driven Development when:

- ✅ New features have complete specs before coding
- ✅ Implementation follows documented plans
- ✅ Code quality is consistent across features
- ✅ Tests are comprehensive and pass
- ✅ Documentation stays up-to-date
- ✅ Rework decreases (get it right first time)
- ✅ Features align with project principles

---

## 🚀 Next Steps

### Right Now
```bash
# 1. Validate your setup
./scripts/check-prerequisites.sh

# 2. Create your first spec
./scripts/create-new-feature.sh 002 my-feature

# 3. Start with Claude
# Open Claude Code and use /clarify
```

### Today
1. Read [README_SPEC_KIT.md](../README_SPEC_KIT.md)
2. Browse the example spec
3. Try `/clarify` with a simple idea

### This Week
1. Complete your first spec-driven feature
2. Share your experience
3. Refine your workflow

---

**Welcome to Spec-Driven Development!** 🎉

You're now part of a movement toward more systematic, thoughtful, and successful software development with AI.

---

**Created**: October 1, 2025
**Project**: Advanced Tester
**Based on**: [GitHub Spec-Kit](https://github.com/github/spec-kit)

