# Advanced Tester - Spec-Kit Integration

Welcome to the Advanced Tester project! This README explains the Spec-Driven Development workflow integrated into this project.

## 📚 What is Spec-Kit?

[Spec-Kit](https://github.com/github/spec-kit) is a toolkit from GitHub that enables **Spec-Driven Development** - a methodology for transforming ideas into working software through systematic specification, planning, and implementation with AI assistance.

## 🎯 Why Spec-Driven Development?

Traditional development with AI can lead to:
- ❌ Incomplete requirements understanding
- ❌ Over-engineered or under-engineered solutions
- ❌ Inconsistent code quality
- ❌ Missing edge cases and error handling

Spec-Driven Development provides:
- ✅ Structured requirement clarification
- ✅ Comprehensive technical planning
- ✅ Task-by-task implementation tracking
- ✅ Validation against documented specifications
- ✅ Consistent adherence to project principles

## 📁 Project Structure

```
advanced_tester/
├── CLAUDE.md                      # AI agent instructions
├── spec-driven.md                 # This workflow guide
├── README_SPEC_KIT.md            # This file
│
├── memory/                        # Project memory
│   └── constitution.md           # Core principles and guidelines
│
├── templates/                     # Reusable templates
│   ├── spec-template.md          # Feature specification template
│   ├── plan-template.md          # Implementation plan template
│   └── tasks-template.md         # Task breakdown template
│
├── scripts/                       # Automation scripts
│   ├── common.sh                 # Shared utilities
│   ├── check-prerequisites.sh    # Environment validation
│   └── create-new-feature.sh     # Feature scaffolding
│
└── specs/                         # Feature specifications
    └── 001-golden-test-generation/  # Example feature
        ├── spec.md               # Feature specification
        ├── plan.md               # Implementation plan
        ├── tasks.md              # Task breakdown
        ├── research.md           # Research findings
        ├── quickstart.md         # Quick reference
        └── contracts/            # API contracts
```

## 🚀 Quick Start

### 1. Check Prerequisites

```bash
./scripts/check-prerequisites.sh
```

This validates:
- Flutter SDK (>= 3.8.1)
- Dart SDK (>= 3.8.1)
- Project dependencies
- Spec-kit structure

### 2. Create a New Feature Specification

```bash
./scripts/create-new-feature.sh <number> <name>

# Example:
./scripts/create-new-feature.sh 002 integration-test-generation
```

This creates a complete feature specification directory with all necessary templates.

### 3. Use Claude Code with Spec Commands

Open Claude Code (or your AI assistant) and use these commands:

#### `/clarify` - Clarify Requirements
```
/clarify

I want to add integration test generation that records user flows
and generates end-to-end tests automatically.
```

#### `/plan` - Create Technical Plan
```
/plan

Use Flutter's integration_test package. Generate tests that start the app,
record interactions, and create assertions based on state changes.
```

#### `/implement` - Execute Implementation
```
/implement
```

## 📖 Complete Workflow Example

### Step 1: Ideation

You have an idea:
> "I want to add golden test support for visual regression testing"

### Step 2: Create Specification

```bash
./scripts/create-new-feature.sh 001 golden-test-generation
```

### Step 3: Clarify with AI

Talk to Claude:
```
I want to add golden test generation to Advanced Tester.
Users should be able to select a widget and automatically generate
visual regression tests with golden images.

Use /clarify to help me define this properly.
```

Claude will ask structured questions to understand:
- What golden test framework to use?
- How to integrate with existing inspector?
- What device sizes to support?
- How to handle test updates?

### Step 4: Technical Planning

After clarification:
```
/plan

Use Flutter's built-in golden test framework. Integrate with InspectorService.
Support phone, tablet, and desktop sizes. Generate tests in test/ directory
with _golden_test.dart suffix.
```

Claude creates a detailed plan including:
- Architecture decisions
- Data models
- API specifications
- Task breakdown (Foundation → Data → Services → UI → Testing)
- Performance considerations

### Step 5: Review and Validate

```
Review the implementation plan against the project constitution.
Verify it follows clean architecture principles and includes proper
error handling and testing.
```

### Step 6: Implementation

```
/implement
```

Claude works through the task breakdown:
1. ✅ Create domain entities
2. ✅ Create use cases
3. ✅ Implement data layer
4. ✅ Create service
5. ✅ Build UI components
6. ✅ Write tests
7. ✅ Update documentation

## 🎓 Key Concepts

### The Constitution

`memory/constitution.md` defines the project's core principles:
- Clean architecture requirements
- Code quality standards
- Performance guidelines
- Testing requirements
- Security considerations

**All features must align with the constitution.**

### Specifications

Each feature has a `spec.md` that includes:
- Problem statement and user pain points
- User stories with acceptance criteria
- Functional and non-functional requirements
- Success metrics
- Review checklist

### Implementation Plans

Each feature has a `plan.md` that includes:
- Architecture overview
- Technical decisions with rationale
- Data models and API specs
- Detailed task breakdown
- Testing strategy
- Error handling approach

### Task Breakdowns

Each feature has a `tasks.md` that provides:
- Atomic, sequential tasks
- Dependencies between tasks
- Time estimates
- Acceptance criteria per task
- Testing requirements per task

## 🛠️ Best Practices

### 1. Always Start with `/clarify`

Don't skip requirement clarification. It saves time downstream.

**Good:**
```
/clarify

I want to add performance profiling that shows widget rebuild counts
and render times in real-time.
```

**Not Recommended:**
```
Add performance profiling
```

### 2. Be Specific in `/plan`

Provide technical context and constraints.

**Good:**
```
/plan

Use Flutter's Timeline API for profiling. Display data in a separate panel.
Update every 500ms. Show rebuild counts, render times, and memory usage.
```

**Not Recommended:**
```
/plan

Just make it show performance data
```

### 3. Review Before `/implement`

Always review the plan for:
- Architecture violations
- Missing error handling
- Performance concerns
- Incomplete testing

### 4. Reference the Constitution

When planning or implementing, check against the constitution:
```
Does this plan follow clean architecture principles?
Does it implement proper disposal patterns?
Is error handling comprehensive?
```

### 5. Document Decisions

Capture important decisions in the plan:
```
Add an architecture decision record explaining why we chose
approach X over Y, considering performance, maintainability,
and compatibility.
```

## 📚 Documentation

### Project Documentation
- [FEATURE_DOCUMENTATION.md](docs/FEATURE_DOCUMENTATION.md) - All implemented features
- [WIDGET_INSPECTOR.md](docs/WIDGET_INSPECTOR.md) - Widget inspector guide
- [WIDGET_DEPENDENCY_ANALYSIS_IMPLEMENTATION.md](docs/WIDGET_DEPENDENCY_ANALYSIS_IMPLEMENTATION.md) - Dependency analysis
- [AI_TEST_GENERATION.md](docs/AI_TEST_GENERATION.md) - AI test generation
- [spec-driven.md](spec-driven.md) - Complete workflow guide

### Templates
- [spec-template.md](templates/spec-template.md) - Feature specification
- [plan-template.md](templates/plan-template.md) - Implementation plan
- [tasks-template.md](templates/tasks-template.md) - Task breakdown

### Example Specification
- [001-golden-test-generation/](specs/001-golden-test-generation/) - Complete example

## 🤖 Working with Claude Code

### Setup

1. Open your project in Cursor
2. Ensure Claude has access to the codebase
3. Reference `CLAUDE.md` for project context

### Commands

Claude understands these special commands:

- `/clarify` - Structured requirement gathering
- `/plan` - Technical implementation planning
- `/implement` - Execute the implementation plan

### Tips

**For Complex Features:**
```
Break this down. First, identify the specific areas that need research.
Then, spawn parallel research tasks for each area.
```

**For Validation:**
```
Review this plan and check off items in the Review & Acceptance Checklist.
Leave unchecked any items that don't meet the criteria.
```

**For Simplification:**
```
Review the plan for over-engineering. Simplify where possible while
maintaining the constitution principles.
```

## 🔍 Troubleshooting

### Scripts Won't Run
```bash
chmod +x ./scripts/*.sh
```

### Claude Gets Stuck
Break down the request:
```
Let's break this into steps. First, [specific task 1].
Then [specific task 2]. Focus on one at a time.
```

### Plan is Too Complex
```
This plan seems over-engineered. Identify components that
can be simplified while still meeting requirements.
```

### Missing Implementation Details
```
The plan needs more detail for [area]. Add step-by-step
instructions with code examples.
```

## 📊 Project Status

### Completed Features ✅
- Widget Inspector Service
- Dependency Analysis System
- Service Management
- Test Generation
- Enhanced UI Components

### Planned Features 🔮
- Golden Test Generation (spec created)
- Integration Test Generation
- Performance Profiling
- Custom Dependency Patterns

### Roadmap
See [FEATURE_DOCUMENTATION.md](docs/FEATURE_DOCUMENTATION.md) for complete roadmap.

## 🤝 Contributing

When contributing new features:

1. **Create Specification**
   ```bash
   ./scripts/create-new-feature.sh <number> <name>
   ```

2. **Clarify Requirements**
   Use `/clarify` with Claude to understand requirements

3. **Create Plan**
   Use `/plan` to create technical implementation

4. **Validate**
   Review against constitution and project standards

5. **Implement**
   Use `/implement` or implement manually following plan

6. **Test**
   Ensure all tests pass and coverage is adequate

7. **Document**
   Update all relevant documentation

8. **Review**
   Submit for code review with spec reference

## 📞 Support

- **Project Issues**: Create GitHub issue with [spec:XXX] tag
- **Spec-Kit Issues**: See [GitHub Spec-Kit](https://github.com/github/spec-kit)
- **Flutter Issues**: See [Flutter GitHub](https://github.com/flutter/flutter)

## 📄 License

This project follows the same license as the Advanced Tester project.

---

## 🎯 Success Criteria

A feature is successfully implemented when:

- [ ] Requirements fully clarified and documented
- [ ] Technical plan comprehensive and validated
- [ ] Implementation follows task breakdown
- [ ] All tests pass (unit, widget, integration)
- [ ] Code follows project constitution
- [ ] Documentation complete
- [ ] Code reviewed and approved
- [ ] Merged to main branch

---

**Project**: Advanced Tester
**Spec-Kit Version**: 1.0.0
**Last Updated**: October 1, 2025
**Based on**: [GitHub Spec-Kit](https://github.com/github/spec-kit)

---

## 🌟 Key Takeaways

1. **Spec-Driven Development** systematizes AI-assisted development
2. **The Constitution** ensures consistent quality and architecture
3. **Structured Workflow** (clarify → plan → implement) prevents rework
4. **Validation** against specifications ensures completeness
5. **Documentation** captures decisions and knowledge

**Happy Spec-Driven Development! 🚀**

