# Spec-Driven Development Guide for Advanced Tester

## Introduction

This project uses **Spec-Driven Development**, a methodology that leverages AI agents (like Claude) to systematically transform ideas into working software. This document explains how to use the spec-kit workflow within the Advanced Tester project.

## What is Spec-Driven Development?

Spec-Driven Development is a structured approach to software development that:

1. **Clarifies** requirements through systematic questioning
2. **Plans** implementation with detailed technical specifications
3. **Executes** through task-by-task implementation
4. **Validates** against documented specifications

This methodology is particularly effective when working with AI coding assistants like Claude Code.

## Project Structure

```
advanced_tester/
├── CLAUDE.md                 # AI agent instructions
├── memory/
│   └── constitution.md       # Project principles and guidelines
├── templates/                # Templates for specs, plans, tasks
│   ├── spec-template.md
│   ├── plan-template.md
│   └── tasks-template.md
├── scripts/                  # Automation scripts
│   ├── common.sh
│   ├── check-prerequisites.sh
│   └── create-new-feature.sh
└── specs/                    # Feature specifications
    └── [XXX-feature-name]/
        ├── spec.md           # Feature specification
        ├── plan.md           # Implementation plan
        ├── tasks.md          # Task breakdown
        ├── research.md       # Research findings
        ├── quickstart.md     # Quick reference
        └── contracts/        # API contracts
```

## Workflow Commands

When working with Claude Code on this project, you can use these commands:

### `/clarify` - Structured Clarification
Ask systematic clarifying questions to fully understand requirements before creating specifications.

**Example:**
```
/clarify

I want to add golden test support to automatically generate visual regression tests for widgets.
```

Claude will ask structured questions and document answers in a "Clarifications" section.

### `/plan` - Technical Planning
Generate a detailed implementation plan including architecture, data models, API specs, and task breakdown.

**Example:**
```
/plan

We'll use Flutter's golden test framework, integrate with the existing inspector service,
and generate test files with proper image comparison setup.
```

### `/implement` - Execute Implementation
Execute the implementation plan step-by-step following the task breakdown.

**Example:**
```
/implement
```

Claude will follow the tasks.md file and implement each task in order.

## Complete Workflow Example

### Step 1: Create Feature Specification

Use the automation script to create a new feature:

```bash
./scripts/create-new-feature.sh 001 golden-test-support
```

This creates:
```
specs/001-golden-test-support/
├── spec.md
├── plan.md
├── tasks.md
├── research.md
├── quickstart.md
└── contracts/
```

### Step 2: Define Requirements with `/clarify`

Talk to Claude Code:

```
I want to add golden test support to Advanced Tester. This would allow developers
to automatically generate visual regression tests for their widgets. The feature should
integrate with the existing widget inspector and generate test files that compare
widget screenshots.

Use /clarify to help me define this feature properly.
```

Claude will ask questions like:
- What golden test framework should we use?
- Should it integrate with existing test generation?
- What image format should be used?
- How should tests handle different screen sizes?

### Step 3: Create Technical Plan with `/plan`

After clarification, create the technical plan:

```
/plan

Requirements:
- Use Flutter's built-in golden test framework
- Integrate with InspectorService for widget capture
- Generate test files in test/ directory with _golden_test.dart suffix
- Support multiple screen sizes (phone, tablet, desktop)
- Use PNG format for golden images
- Store images in test/golden/ directory
```

Claude will create a detailed implementation plan including:
- Architecture decisions
- Data models
- API specifications
- Task breakdown
- Testing strategy

### Step 4: Validate the Plan

Review the generated plan and ask Claude to validate it:

```
Read through the implementation plan and check against the project constitution.
Verify that:
1. It follows clean architecture principles
2. It integrates properly with existing services
3. Performance considerations are addressed
4. Error handling is comprehensive
5. Testing strategy is thorough
```

### Step 5: Implement with `/implement`

When ready, execute the plan:

```
/implement
```

Claude will work through each task in tasks.md, implementing:
1. Domain entities
2. Use cases
3. Data layer
4. Service layer
5. UI components
6. Tests
7. Documentation

### Step 6: Validate and Review

After implementation:

```
Validate the implementation against the Review & Acceptance Checklist in spec.md.
Check off completed items and identify any remaining work.
```

## Best Practices

### 1. Always Start with Clarification

Don't skip the `/clarify` step. It saves time by ensuring you and Claude understand requirements the same way.

**Good:**
```
/clarify

I want to add integration test generation. Users should be able to select a user flow
and generate end-to-end tests.
```

**Not Recommended:**
```
Add integration test generation
```

### 2. Be Specific in Planning

Provide technical details during the `/plan` phase:

**Good:**
```
/plan

Use Flutter's integration_test package. Generate tests that:
- Start the app with IntegrationTestWidgetsFlutterBinding
- Record user interactions from widget tree selections
- Generate assertions based on expected states
- Support custom test scenarios
```

**Not Recommended:**
```
/plan

Just make it work with integration tests.
```

### 3. Review Before Implementation

Always review the plan before `/implement`:

```
Review the implementation plan and identify any:
- Missing error handling
- Performance concerns
- Architecture violations
- Incomplete test coverage
```

### 4. Use the Constitution

The constitution (`memory/constitution.md`) defines project principles. Reference it:

```
Check this plan against the project constitution. Does it:
- Follow clean architecture principles?
- Implement proper disposal patterns?
- Handle errors gracefully?
- Include comprehensive tests?
```

### 5. Document Decisions

When making technical decisions, document them:

```
Add an architecture decision record to the plan explaining why we chose
approach X over approach Y.
```

## Working with Existing Code

When modifying existing features:

1. **Understand First**
```
Explain how the current inspector service works and where we need to integrate
the new golden test functionality.
```

2. **Plan Changes**
```
Create a plan for adding golden test support that minimizes changes to existing code
and maintains backwards compatibility.
```

3. **Test Impact**
```
Identify all existing tests that might be affected by these changes.
```

## Troubleshooting

### Claude Gets Stuck

If Claude is researching the wrong thing or gets stuck:

```
I think we need to break this down. First, identify specific tasks that need research.
Then, for each task, spawn a separate focused research effort. The research should
answer specific targeted questions, not general topics.
```

### Plan is Over-Engineered

If the plan seems too complex:

```
Review the plan and identify any over-engineered components. Simplify where possible
while maintaining the project's constitution principles.
```

### Missing Implementation Details

If the plan lacks specific details:

```
The implementation plan needs more detail for [specific area]. Add step-by-step
instructions and code examples for implementing [feature].
```

## Integration with Advanced Tester

### Existing Architecture

Advanced Tester follows **Clean Architecture** with these layers:
- **Domain**: Business logic (entities, use cases, repository interfaces)
- **Data**: Data access (repositories, data sources, mappers)
- **Presentation**: UI (widgets, pages, controllers, providers)
- **Services**: Infrastructure (InspectorService, VM service integration)

### Key Integration Points

When adding features, integrate with:

1. **InspectorService** - For widget tree access
```dart
final inspector = serviceManager.inspectorService;
final widget = await inspector.getSelectedWidget();
```

2. **ServiceManager** - For service coordination
```dart
final serviceManager = ServiceManager();
await serviceManager.registerService(myNewService);
```

3. **AppState** - For application state
```dart
final appState = Provider.of<AppState>(context);
appState.updateState(newData);
```

4. **Use Cases** - For business logic
```dart
final useCase = GenerateTestUseCase(repository);
final result = await useCase.execute(params);
```

## Resources

### Project Documentation
- [Feature Documentation](docs/FEATURE_DOCUMENTATION.md)
- [Widget Inspector Guide](docs/WIDGET_INSPECTOR.md)
- [Dependency Analysis](docs/WIDGET_DEPENDENCY_ANALYSIS_IMPLEMENTATION.md)
- [AI Test Generation](docs/AI_TEST_GENERATION.md)

### External Resources
- [Spec-Kit GitHub](https://github.com/github/spec-kit)
- [Flutter Documentation](https://docs.flutter.dev)
- [Flutter DevTools](https://github.com/flutter/devtools)
- [Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)

## Quick Reference

### Create New Feature
```bash
./scripts/create-new-feature.sh <number> <name>
```

### Check Prerequisites
```bash
./scripts/check-prerequisites.sh
```

### Clarify Requirements
```
/clarify

[Describe feature idea]
```

### Create Plan
```
/plan

[Technical requirements and constraints]
```

### Implement
```
/implement
```

### Validate
```
Review the specification checklist and validate all items are complete.
```

---

## Success Criteria

A feature is successfully spec-driven when:

- [ ] Requirements are fully clarified and documented
- [ ] Technical plan is comprehensive and validated
- [ ] Implementation follows the task breakdown
- [ ] All tests pass
- [ ] Documentation is complete
- [ ] Code follows project constitution
- [ ] Review checklist is satisfied

---

**Last Updated**: October 1, 2025
**Version**: 1.0.0
**Based on**: [GitHub Spec-Kit](https://github.com/github/spec-kit)

