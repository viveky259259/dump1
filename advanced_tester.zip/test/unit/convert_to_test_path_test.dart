import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/services/ai_test_generation_service.dart';

void main() {
  group('AITestGenerationService - convertToTestPath', () {
    late AITestGenerationService service;

    setUp(() {
      service = AITestGenerationService();
    });

    group('file:// protocol URLs with /lib/ directory', () {
      test('should convert file URL with /lib/ to test path', () {
        // Arrange
        const sourcePath =
            'file:///Users/dev/my_project/lib/widgets/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('/Users/dev/my_project/test/widgets/my_widget_test.dart'),
        );
      });

      test('should handle file URL with nested lib directories', () {
        // Arrange
        const sourcePath =
            'file:///Users/dev/my_project/lib/src/features/auth/login_screen.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals(
            '/Users/dev/my_project/test/src/features/auth/login_screen_test.dart',
          ),
        );
      });

      test('should handle file URL with lib at root level', () {
        // Arrange
        const sourcePath = 'file:///lib/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('/test/my_widget_test.dart'));
      });

      test('should handle file URL with multiple .dart occurrences', () {
        // Arrange
        const sourcePath =
            'file:///Users/dev/my_project/lib/dart_utils/my.dart.widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Note: replaceAll replaces ALL occurrences of .dart
        expect(
          result,
          equals(
            '/Users/dev/my_project/test/dart_utils/my_test.dart.widget_test.dart',
          ),
        );
      });

      test('should handle Windows-style file URL', () {
        // Arrange
        const sourcePath = 'file:///C:/Users/dev/project/lib/widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Note: file:// protocol handling leaves leading slash for Windows paths
        expect(result, equals('/C:/Users/dev/project/test/widget_test.dart'));
      });
    });

    group('file:// protocol URLs without /lib/ directory', () {
      test('should fallback to test directory when no /lib/ found', () {
        // Arrange
        const sourcePath = 'file:///Users/dev/my_project/src/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('/Users/dev/my_project/src/test/my_widget_test.dart'),
        );
      });

      test('should handle file URL with just filename', () {
        // Arrange
        const sourcePath = 'file:///my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('/test/my_widget_test.dart'));
      });

      test('should extract filename from complex path without /lib/', () {
        // Arrange
        const sourcePath =
            'file:///Users/dev/project/custom/path/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('/Users/dev/project/custom/path/test/my_widget_test.dart'),
        );
      });
    });

    group('Relative paths starting with lib/', () {
      test('should convert lib/ to test/ for simple path', () {
        // Arrange
        const sourcePath = 'lib/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/my_widget_test.dart'));
      });

      test('should convert lib/ to test/ for nested path', () {
        // Arrange
        const sourcePath = 'lib/widgets/buttons/custom_button.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/widgets/buttons/custom_button_test.dart'));
      });

      test('should handle lib/ with deeply nested structure', () {
        // Arrange
        const sourcePath =
            'lib/src/features/authentication/presentation/widgets/login_form.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals(
            'test/src/features/authentication/presentation/widgets/login_form_test.dart',
          ),
        );
      });

      test('should only replace first occurrence of lib/', () {
        // Arrange
        const sourcePath = 'lib/lib_utils/library.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/lib_utils/library_test.dart'));
      });
    });

    group('Absolute paths containing /lib/', () {
      test('should convert absolute path with /lib/ to test path', () {
        // Arrange
        const sourcePath = '/Users/dev/my_project/lib/widgets/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('/Users/dev/my_project/test/widgets/my_widget_test.dart'),
        );
      });

      test('should handle absolute path with nested /lib/ directory', () {
        // Arrange
        const sourcePath =
            '/home/developer/projects/flutter_app/lib/src/core/utils.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals(
            '/home/developer/projects/flutter_app/test/src/core/utils_test.dart',
          ),
        );
      });

      test('should handle Windows absolute path', () {
        // Arrange
        const sourcePath = 'C:\\Users\\dev\\project\\lib\\widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Note: This depends on how split() handles backslashes
        expect(result, contains('test'));
        expect(result, contains('widget_test.dart'));
      });

      test('should handle path with multiple /lib/ occurrences', () {
        // Arrange
        const sourcePath =
            '/Users/dev/my_lib_project/lib/lib_widgets/widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Should split on the first /lib/
        expect(
          result,
          equals('/Users/dev/my_lib_project/test/lib_widgets/widget_test.dart'),
        );
      });
    });

    group('Fallback cases (no lib/ in path)', () {
      test('should create test path in test directory for simple filename', () {
        // Arrange
        const sourcePath = 'my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/my_widget_test.dart'));
      });

      test('should handle path with no lib/ directory', () {
        // Arrange
        const sourcePath = 'src/widgets/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/my_widget_test.dart'));
      });

      test('should extract filename from relative path without lib/', () {
        // Arrange
        const sourcePath = 'custom/path/to/widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/widget_test.dart'));
      });
    });

    group('Edge cases and special characters', () {
      test('should handle file without extension', () {
        // Arrange
        const sourcePath = 'lib/my_widget';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Note: Files without .dart extension don't get _test.dart appended
        expect(result, equals('test/my_widget'));
      });

      test('should handle empty string', () {
        // Arrange
        const sourcePath = '';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Note: Empty string results in just 'test/' with no filename
        expect(result, equals('test/'));
      });

      test('should handle file with multiple extensions', () {
        // Arrange
        const sourcePath = 'lib/my_widget.ui.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/my_widget.ui_test.dart'));
      });

      test('should handle path with spaces', () {
        // Arrange
        const sourcePath = 'lib/my widget with spaces.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/my widget with spaces_test.dart'));
      });

      test('should handle path with special characters', () {
        // Arrange
        const sourcePath = 'lib/my-widget_v2.0.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/my-widget_v2.0_test.dart'));
      });

      test('should handle Unicode characters in filename', () {
        // Arrange
        const sourcePath = 'lib/widgets/按钮_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/widgets/按钮_widget_test.dart'));
      });
    });

    group('Real-world Flutter project scenarios', () {
      test('should handle typical Flutter widget file', () {
        // Arrange
        const sourcePath = 'lib/widgets/custom_button.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/widgets/custom_button_test.dart'));
      });

      test('should handle screen file with feature folder structure', () {
        // Arrange
        const sourcePath =
            'lib/features/authentication/screens/login_screen.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('test/features/authentication/screens/login_screen_test.dart'),
        );
      });

      test('should handle service file', () {
        // Arrange
        const sourcePath = 'lib/services/api_service.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/services/api_service_test.dart'));
      });

      test('should handle model file', () {
        // Arrange
        const sourcePath = 'lib/models/user_model.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/models/user_model_test.dart'));
      });

      test('should handle utils file', () {
        // Arrange
        const sourcePath = 'lib/utils/string_utils.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/utils/string_utils_test.dart'));
      });

      test('should handle repository pattern file', () {
        // Arrange
        const sourcePath = 'lib/data/repositories/user_repository.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('test/data/repositories/user_repository_test.dart'),
        );
      });

      test('should handle bloc file', () {
        // Arrange
        const sourcePath = 'lib/blocs/auth/auth_bloc.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/blocs/auth/auth_bloc_test.dart'));
      });

      test('should handle provider file', () {
        // Arrange
        const sourcePath = 'lib/providers/theme_provider.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/providers/theme_provider_test.dart'));
      });
    });

    group('Path traversal and complex scenarios', () {
      test('should handle path with ../ navigation', () {
        // Arrange
        const sourcePath = 'lib/../lib/widgets/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        // Depends on whether path normalization happens
        expect(result, contains('test'));
        expect(result, contains('my_widget_test.dart'));
      });

      test('should handle path with ./ current directory', () {
        // Arrange
        const sourcePath = './lib/widgets/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('./test/widgets/my_widget_test.dart'));
      });

      test('should handle very long path', () {
        // Arrange
        const sourcePath =
            'lib/src/features/auth/presentation/pages/login/widgets/forms/inputs/fields/custom_text_field.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals(
            'test/src/features/auth/presentation/pages/login/widgets/forms/inputs/fields/custom_text_field_test.dart',
          ),
        );
      });

      test('should handle path with trailing slash', () {
        // Arrange
        const sourcePath = 'lib/widgets/my_widget.dart/';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, isNotEmpty);
      });
    });

    group('Multiple .dart occurrences', () {
      test('should only replace last .dart', () {
        // Arrange
        const sourcePath = 'lib/dart/dart_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/dart/dart_widget_test.dart'));
      });

      test('should handle .dart in directory name', () {
        // Arrange
        const sourcePath = 'lib/dart.utils/widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/dart.utils/widget_test.dart'));
      });
    });

    group('Already test files', () {
      test('should handle file that already has _test suffix', () {
        // Arrange
        const sourcePath = 'lib/widgets/my_widget_test.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/widgets/my_widget_test_test.dart'));
      });

      test('should handle file in test directory with lib/ prefix', () {
        // Arrange
        const sourcePath = 'lib/test/my_widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(result, equals('test/test/my_widget_test.dart'));
      });
    });

    group('Integration with different OS paths', () {
      test('should handle macOS path', () {
        // Arrange
        const sourcePath =
            '/Users/developer/Documents/flutter_project/lib/widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals(
            '/Users/developer/Documents/flutter_project/test/widget_test.dart',
          ),
        );
      });

      test('should handle Linux path', () {
        // Arrange
        const sourcePath = '/home/dev/projects/my_app/lib/widget.dart';

        // Act
        final result = service.convertToTestPath(sourcePath);

        // Assert
        expect(
          result,
          equals('/home/dev/projects/my_app/test/widget_test.dart'),
        );
      });
    });
  });
}
