import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/ui_element.dart';
import 'package:advanced_tester/services/ui_automation_service.dart';

void main() {
  group('UIElementBounds', () {
    group('parse', () {
      test('parses standard Android/iOS format [left,top][right,bottom]', () {
        final bounds = UIElementBounds.parse('[100,200][300,400]');

        expect(bounds, isNotNull);
        expect(bounds!.x, 100);
        expect(bounds.y, 200);
        expect(bounds.width, 200); // 300 - 100
        expect(bounds.height, 200); // 400 - 200
      });

      test('parses bounds with negative coordinates', () {
        final bounds = UIElementBounds.parse('[-10,0][100,50]');

        expect(bounds, isNotNull);
        expect(bounds!.x, -10);
        expect(bounds.y, 0);
        expect(bounds.width, 110); // 100 - (-10)
        expect(bounds.height, 50);
      });

      test('returns null for empty string', () {
        expect(UIElementBounds.parse(''), isNull);
      });

      test('returns null for null input', () {
        expect(UIElementBounds.parse(null), isNull);
      });

      test('returns null for invalid format', () {
        expect(UIElementBounds.parse('invalid'), isNull);
        expect(UIElementBounds.parse('[100,200]'), isNull);
        expect(UIElementBounds.parse('100,200,300,400'), isNull);
      });
    });

    group('properties', () {
      test('centerX returns correct center x coordinate', () {
        final bounds = UIElementBounds(x: 100, y: 200, width: 50, height: 80);
        expect(bounds.centerX, 125.0); // 100 + 50/2
      });

      test('centerY returns correct center y coordinate', () {
        final bounds = UIElementBounds(x: 100, y: 200, width: 50, height: 80);
        expect(bounds.centerY, 240.0); // 200 + 80/2
      });

      test('area returns correct area', () {
        final bounds = UIElementBounds(x: 0, y: 0, width: 100, height: 50);
        expect(bounds.area, 5000);
      });
    });

    group('containsNormalized', () {
      test('returns true when point is inside bounds', () {
        final bounds = UIElementBounds(x: 100, y: 100, width: 200, height: 100);

        // Point at center (normalized 0.5, 0.375 for 400x400 device)
        expect(bounds.containsNormalized(0.5, 0.375, 400, 400), isTrue);
      });

      test('returns false when point is outside bounds', () {
        final bounds = UIElementBounds(x: 100, y: 100, width: 200, height: 100);

        // Point at top-left corner of device
        expect(bounds.containsNormalized(0.0, 0.0, 400, 400), isFalse);
      });

      test('returns true for point on edge', () {
        final bounds = UIElementBounds(x: 100, y: 100, width: 200, height: 100);

        // Point at left edge (100/400 = 0.25, 150/400 = 0.375)
        expect(bounds.containsNormalized(0.25, 0.375, 400, 400), isTrue);
      });
    });

    group('serialization', () {
      test('toJson returns correct map', () {
        final bounds = UIElementBounds(x: 10, y: 20, width: 100, height: 50);
        final json = bounds.toJson();

        expect(json['x'], 10);
        expect(json['y'], 20);
        expect(json['width'], 100);
        expect(json['height'], 50);
      });

      test('fromJson creates correct bounds', () {
        final json = {'x': 10, 'y': 20, 'width': 100, 'height': 50};
        final bounds = UIElementBounds.fromJson(json);

        expect(bounds.x, 10);
        expect(bounds.y, 20);
        expect(bounds.width, 100);
        expect(bounds.height, 50);
      });

      test('roundtrip serialization preserves data', () {
        final original = UIElementBounds(x: 15, y: 25, width: 150, height: 75);
        final restored = UIElementBounds.fromJson(original.toJson());

        expect(restored, equals(original));
      });
    });

    group('equality', () {
      test('equal bounds are equal', () {
        final bounds1 = UIElementBounds(x: 10, y: 20, width: 100, height: 50);
        final bounds2 = UIElementBounds(x: 10, y: 20, width: 100, height: 50);

        expect(bounds1, equals(bounds2));
        expect(bounds1.hashCode, equals(bounds2.hashCode));
      });

      test('different bounds are not equal', () {
        final bounds1 = UIElementBounds(x: 10, y: 20, width: 100, height: 50);
        final bounds2 = UIElementBounds(x: 10, y: 20, width: 100, height: 60);

        expect(bounds1, isNot(equals(bounds2)));
      });
    });
  });

  group('UIElement', () {
    group('hasSelectableAttribute', () {
      test('returns true when text is present', () {
        final element = UIElement(id: '1', text: 'Submit');
        expect(element.hasSelectableAttribute, isTrue);
      });

      test('returns true when resourceId is present', () {
        final element = UIElement(id: '1', resourceId: 'com.app:id/button');
        expect(element.hasSelectableAttribute, isTrue);
      });

      test('returns true when hintText is present', () {
        final element = UIElement(id: '1', hintText: 'Enter email');
        expect(element.hasSelectableAttribute, isTrue);
      });

      test('returns true when accessibilityText is present', () {
        final element = UIElement(id: '1', accessibilityText: 'Submit button');
        expect(element.hasSelectableAttribute, isTrue);
      });

      test('returns false when no selectable attributes', () {
        final element = UIElement(
          id: '1',
          bounds: UIElementBounds(x: 0, y: 0, width: 100, height: 50),
        );
        expect(element.hasSelectableAttribute, isFalse);
      });
    });

    group('displayText', () {
      test('returns resourceId first when available', () {
        final element = UIElement(
          id: '1',
          resourceId: 'btn_submit',
          text: 'Submit',
          accessibilityText: 'Submit button',
        );
        expect(element.displayText, 'btn_submit');
      });

      test('returns text when resourceId is null', () {
        final element = UIElement(
          id: '1',
          text: 'Submit',
          accessibilityText: 'Submit button',
        );
        expect(element.displayText, 'Submit');
      });

      test('returns hintText when text and resourceId are null', () {
        final element = UIElement(
          id: '1',
          hintText: 'Enter password',
        );
        expect(element.displayText, 'Enter password');
      });

      test('returns accessibilityText as last fallback', () {
        final element = UIElement(
          id: '1',
          accessibilityText: 'Close dialog',
        );
        expect(element.displayText, 'Close dialog');
      });

      test('returns null when no display attributes', () {
        final element = UIElement(id: '1');
        expect(element.displayText, isNull);
      });
    });

    group('availableSelectors', () {
      test('includes id selector when resourceId present', () {
        final element = UIElement(id: '1', resourceId: 'btn_submit');
        final selectors = element.availableSelectors;

        expect(selectors.length, 1);
        expect(selectors[0].type, SelectorType.id);
        expect(selectors[0].value, 'btn_submit');
      });

      test('includes text selector when text present', () {
        final element = UIElement(id: '1', text: 'Submit');
        final selectors = element.availableSelectors;

        expect(selectors.length, 1);
        expect(selectors[0].type, SelectorType.text);
        expect(selectors[0].value, 'Submit');
      });

      test('includes index for duplicate text', () {
        final element = UIElement(id: '1', text: 'Item', textIndex: 2);
        final selectors = element.availableSelectors;

        expect(selectors[0].index, 2);
      });

      test('includes all selector types when multiple present', () {
        final element = UIElement(
          id: '1',
          resourceId: 'btn_submit',
          text: 'Submit',
          hintText: 'Tap to submit',
          accessibilityText: 'Submit button',
        );
        final selectors = element.availableSelectors;

        expect(selectors.length, 4);
        expect(selectors.map((s) => s.type).toList(), [
          SelectorType.id,
          SelectorType.text,
          SelectorType.hintText,
          SelectorType.accessibilityText,
        ]);
      });
    });

    group('generateTapCommand', () {
      test('generates id-based tap when resourceId present', () {
        final element = UIElement(id: '1', resourceId: 'btn_submit');
        final command = element.generateTapCommand();

        expect(command, '- tapOn:\n    id: "btn_submit"');
      });

      test('includes index for duplicate resourceId', () {
        final element = UIElement(
          id: '1',
          resourceId: 'btn_item',
          resourceIdIndex: 1,
        );
        final command = element.generateTapCommand();

        expect(command, '- tapOn:\n    id: "btn_item"\n    index: 1');
      });

      test('generates text-based tap when resourceId not present', () {
        final element = UIElement(id: '1', text: 'Submit');
        final command = element.generateTapCommand();

        expect(command, '- tapOn:\n    text: "Submit"');
      });

      test('includes index for duplicate text', () {
        final element = UIElement(id: '1', text: 'Item', textIndex: 2);
        final command = element.generateTapCommand();

        expect(command, '- tapOn:\n    text: "Item"\n    index: 2');
      });

      test('generates accessibilityText-based tap when others not present', () {
        final element = UIElement(id: '1', accessibilityText: 'Submit button');
        final command = element.generateTapCommand();

        expect(command, '- tapOn:\n    accessibilityText: "Submit button"');
      });

      test('generates point-based tap when only bounds available', () {
        final element = UIElement(
          id: '1',
          bounds: UIElementBounds(x: 100, y: 200, width: 50, height: 30),
        );
        final command = element.generateTapCommand();

        expect(command, '- tapOn:\n    point: "125,215"');
      });

      test('returns comment when no selector available', () {
        final element = UIElement(id: '1');
        final command = element.generateTapCommand();

        expect(command, '# Unable to generate tap command');
      });
    });

    group('generateAssertCommand', () {
      test('generates text-based assert when text present', () {
        final element = UIElement(id: '1', text: 'Welcome');
        final command = element.generateAssertCommand();

        expect(command, '- assertVisible: "Welcome"');
      });

      test('generates id-based assert when text not present', () {
        final element = UIElement(id: '1', resourceId: 'welcome_text');
        final command = element.generateAssertCommand();

        expect(command, '- assertVisible:\n    id: "welcome_text"');
      });

      test('prefers text over resourceId', () {
        final element = UIElement(
          id: '1',
          text: 'Welcome',
          resourceId: 'welcome_text',
        );
        final command = element.generateAssertCommand();

        expect(command, '- assertVisible: "Welcome"');
      });
    });

    group('serialization', () {
      test('toJson includes all non-null properties', () {
        final element = UIElement(
          id: 'elem1',
          bounds: UIElementBounds(x: 10, y: 20, width: 100, height: 50),
          resourceId: 'btn_submit',
          text: 'Submit',
          clickable: true,
          enabled: true,
        );
        final json = element.toJson();

        expect(json['id'], 'elem1');
        expect(json['bounds'], isNotNull);
        expect(json['resourceId'], 'btn_submit');
        expect(json['text'], 'Submit');
        expect(json['clickable'], true);
        expect(json['enabled'], true);
      });

      test('toJson excludes null properties', () {
        final element = UIElement(id: 'elem1', text: 'Hello');
        final json = element.toJson();

        expect(json.containsKey('bounds'), isFalse);
        expect(json.containsKey('resourceId'), isFalse);
        expect(json.containsKey('hintText'), isFalse);
      });

      test('fromJson creates correct element', () {
        final json = {
          'id': 'elem1',
          'text': 'Submit',
          'resourceId': 'btn_submit',
          'clickable': true,
          'bounds': {'x': 10, 'y': 20, 'width': 100, 'height': 50},
        };
        final element = UIElement.fromJson(json);

        expect(element.id, 'elem1');
        expect(element.text, 'Submit');
        expect(element.resourceId, 'btn_submit');
        expect(element.clickable, true);
        expect(element.bounds?.x, 10);
      });

      test('roundtrip serialization preserves data', () {
        final original = UIElement(
          id: 'elem1',
          bounds: UIElementBounds(x: 10, y: 20, width: 100, height: 50),
          resourceId: 'btn_submit',
          text: 'Submit',
          accessibilityText: 'Submit button',
          clickable: true,
          enabled: true,
          depth: 5,
          elementNum: 42,
        );
        final restored = UIElement.fromJson(original.toJson());

        expect(restored.id, original.id);
        expect(restored.resourceId, original.resourceId);
        expect(restored.text, original.text);
        expect(restored.accessibilityText, original.accessibilityText);
        expect(restored.clickable, original.clickable);
        expect(restored.enabled, original.enabled);
        expect(restored.depth, original.depth);
        expect(restored.elementNum, original.elementNum);
      });
    });

    group('equality', () {
      test('elements with same id are equal', () {
        final elem1 = UIElement(id: 'elem1', text: 'A');
        final elem2 = UIElement(id: 'elem1', text: 'B');

        expect(elem1, equals(elem2));
      });

      test('elements with different ids are not equal', () {
        final elem1 = UIElement(id: 'elem1', text: 'A');
        final elem2 = UIElement(id: 'elem2', text: 'A');

        expect(elem1, isNot(equals(elem2)));
      });
    });

    group('copyWith', () {
      test('creates copy with updated values', () {
        final original = UIElement(id: 'elem1', text: 'Original');
        final copy = original.copyWith(text: 'Modified');

        expect(copy.id, 'elem1');
        expect(copy.text, 'Modified');
      });

      test('preserves original values when not specified', () {
        final original = UIElement(
          id: 'elem1',
          text: 'Text',
          resourceId: 'res_id',
          clickable: true,
        );
        final copy = original.copyWith(text: 'New Text');

        expect(copy.resourceId, 'res_id');
        expect(copy.clickable, true);
      });
    });
  });

  group('UIScreen', () {
    final testElements = [
      UIElement(
        id: '1',
        text: 'Login',
        bounds: UIElementBounds(x: 100, y: 100, width: 100, height: 50),
        clickable: true,
      ),
      UIElement(
        id: '2',
        text: 'Register',
        bounds: UIElementBounds(x: 100, y: 200, width: 100, height: 50),
        clickable: true,
      ),
      UIElement(
        id: '3',
        resourceId: 'container',
        bounds: UIElementBounds(x: 0, y: 0, width: 400, height: 800),
      ),
      UIElement(
        id: '4',
        bounds: UIElementBounds(x: 200, y: 300, width: 50, height: 50),
      ),
    ];

    group('selectableElements', () {
      test('returns only elements with selectable attributes', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        final selectable = screen.selectableElements;

        expect(selectable.length, 3); // Login, Register, container
        expect(selectable.any((e) => e.id == '4'), isFalse);
      });
    });

    group('findElementAt', () {
      test('finds element at normalized coordinates', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        // Point in center of Login button (150/400 = 0.375, 125/800 = 0.15625)
        final element = screen.findElementAt(0.375, 0.15625);

        expect(element, isNotNull);
        expect(element!.text, 'Login');
      });

      test('returns smallest element when multiple match', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        // Point in Login button which is also inside container
        final element = screen.findElementAt(0.375, 0.15625);

        expect(element, isNotNull);
        expect(element!.text, 'Login'); // Login is smaller than container
      });

      test('returns null when no element at position', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: [
            UIElement(
              id: '1',
              text: 'Button',
              bounds: UIElementBounds(x: 100, y: 100, width: 50, height: 50),
            ),
          ],
          capturedAt: DateTime.now(),
        );

        // Point outside any element
        final element = screen.findElementAt(0.0, 0.0);

        expect(element, isNull);
      });
    });

    group('searchElements', () {
      test('returns all selectable elements when query is empty', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        final results = screen.searchElements('');

        expect(results.length, 3); // All selectable elements
      });

      test('filters by text match', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        final results = screen.searchElements('log');

        expect(results.length, 1);
        expect(results[0].text, 'Login');
      });

      test('filters by resourceId match', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        final results = screen.searchElements('container');

        expect(results.length, 1);
        expect(results[0].resourceId, 'container');
      });

      test('search is case insensitive', () {
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: testElements,
          capturedAt: DateTime.now(),
        );

        final results = screen.searchElements('LOGIN');

        expect(results.length, 1);
        expect(results[0].text, 'Login');
      });

      test('searches across multiple attributes', () {
        final elements = [
          UIElement(id: '1', text: 'Submit'),
          UIElement(id: '2', resourceId: 'submit_btn'),
          UIElement(id: '3', hintText: 'submit form'),
          UIElement(id: '4', accessibilityText: 'Submit button'),
        ];
        final screen = UIScreen(
          platform: UIPlatform.ios,
          width: 400,
          height: 800,
          elements: elements,
          capturedAt: DateTime.now(),
        );

        final results = screen.searchElements('submit');

        expect(results.length, 4);
      });
    });

    group('serialization', () {
      test('toJson includes all properties', () {
        final screen = UIScreen(
          platform: UIPlatform.android,
          width: 1080,
          height: 1920,
          elements: [UIElement(id: '1', text: 'Test')],
          url: 'https://example.com',
          capturedAt: DateTime(2024, 1, 15, 10, 30),
        );
        final json = screen.toJson();

        expect(json['platform'], 'android');
        expect(json['width'], 1080);
        expect(json['height'], 1920);
        expect(json['elements'], isNotEmpty);
        expect(json['url'], 'https://example.com');
        expect(json['capturedAt'], isNotNull);
      });

      test('fromJson creates correct screen', () {
        final json = {
          'platform': 'ios',
          'width': 390,
          'height': 844,
          'elements': [
            {'id': '1', 'text': 'Hello'}
          ],
          'capturedAt': '2024-01-15T10:30:00.000',
        };
        final screen = UIScreen.fromJson(json);

        expect(screen.platform, UIPlatform.ios);
        expect(screen.width, 390);
        expect(screen.height, 844);
        expect(screen.elements.length, 1);
        expect(screen.elements[0].text, 'Hello');
      });
    });
  });

  group('UIAutomationService parsing', () {
    late UIAutomationService service;

    setUp(() {
      service = UIAutomationService();
    });

    group('parseViewHierarchy - CSV format', () {
      test('parses simple Maestro CSV line', () {
        const csvData = '''21,13,"[131,76][270,103]","accessibilityText=Vivek Yadav; enabled=true",18''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].accessibilityText, 'Vivek Yadav');
        expect(elements[0].enabled, true);
        expect(elements[0].depth, 13);
        expect(elements[0].bounds?.x, 131);
        expect(elements[0].bounds?.y, 76);
        expect(elements[0].bounds?.width, 139); // 270 - 131
        expect(elements[0].bounds?.height, 27); // 103 - 76
      });

      test('parses multiple CSV lines', () {
        const csvData = '''1,0,"[0,0][390,844]","enabled=true",0
2,1,"[0,50][390,100]","text=Header; enabled=true",1
3,2,"[20,60][100,90]","text=Button; clickable=true",2''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 3);
        expect(elements[1].text, 'Header');
        expect(elements[2].text, 'Button');
        expect(elements[2].clickable, true);
      });

      test('parses element with resourceId', () {
        const csvData = '''5,3,"[50,100][200,150]","resource-id=com.app:id/submit_btn; text=Submit; clickable=true",4''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].resourceId, 'com.app:id/submit_btn');
        expect(elements[0].text, 'Submit');
        expect(elements[0].clickable, true);
      });

      test('handles empty bounds', () {
        const csvData = '''10,5,"","text=NoPosition; enabled=true",9''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].text, 'NoPosition');
        expect(elements[0].bounds, isNull);
      });

      test('handles special characters in text', () {
        const csvData = '''1,0,"[0,0][100,50]","text=Hello World!; enabled=true",0''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].text, 'Hello World!');
      });

      test('skips empty lines', () {
        const csvData = '''1,0,"[0,0][100,50]","text=First",0

2,1,"[0,50][100,100]","text=Second",1''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 2);
      });

      test('tracks duplicate text indices', () {
        const csvData = '''1,0,"[0,0][100,50]","text=Item",0
2,1,"[0,50][100,100]","text=Item",1
3,2,"[0,100][100,150]","text=Item",2''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 3);
        expect(elements[0].textIndex, isNull); // First occurrence
        expect(elements[1].textIndex, 1); // Second occurrence
        expect(elements[2].textIndex, 2); // Third occurrence
      });

      test('tracks duplicate resourceId indices', () {
        const csvData = '''1,0,"[0,0][100,50]","resource-id=list_item; text=A",0
2,1,"[0,50][100,100]","resource-id=list_item; text=B",1''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 2);
        expect(elements[0].resourceIdIndex, isNull);
        expect(elements[1].resourceIdIndex, 1);
      });

      test('parses all boolean attributes', () {
        const csvData = '''1,0,"[0,0][100,50]","text=Test; enabled=true; focused=false; checked=true; selected=false; clickable=true",0''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].enabled, true);
        expect(elements[0].focused, false);
        expect(elements[0].checked, true);
        expect(elements[0].selected, false);
        expect(elements[0].clickable, true);
      });

      test('parses element type', () {
        const csvData = '''1,0,"[0,0][100,50]","type=Button; text=Click Me",0''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].elementType, 'Button');
      });

      test('parses hintText', () {
        const csvData = '''1,0,"[0,0][100,50]","hintText=Enter email; enabled=true",0''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].hintText, 'Enter email');
      });
    });

    group('parseViewHierarchy - JSON format', () {
      test('parses JSON array format', () {
        const jsonData = '''[
          {"id": "elem1", "text": "Hello", "bounds": "[0,0][100,50]", "clickable": true},
          {"id": "elem2", "text": "World", "bounds": "[0,50][100,100]"}
        ]''';

        final elements = service.parseViewHierarchy(jsonData);

        expect(elements.length, 2);
        expect(elements[0].text, 'Hello');
        expect(elements[0].clickable, true);
        expect(elements[1].text, 'World');
      });

      test('parses nested JSON tree format', () {
        const jsonData = '''{
          "text": "Root",
          "bounds": "[0,0][400,800]",
          "children": [
            {"text": "Child1", "bounds": "[0,0][200,400]"},
            {"text": "Child2", "bounds": "[200,0][400,400]"}
          ]
        }''';

        final elements = service.parseViewHierarchy(jsonData);

        expect(elements.length, 3);
        expect(elements.map((e) => e.text).toList(), ['Root', 'Child1', 'Child2']);
      });

      test('extracts various attribute names', () {
        const jsonData = '''[
          {"accessibilityLabel": "Label1"},
          {"content-desc": "Desc1"},
          {"accessibilityIdentifier": "ID1"},
          {"placeholderValue": "Placeholder1"}
        ]''';

        final elements = service.parseViewHierarchy(jsonData);

        expect(elements.length, 4);
        expect(elements[0].accessibilityText, 'Label1');
        expect(elements[1].accessibilityText, 'Desc1');
        expect(elements[2].resourceId, 'ID1');
        expect(elements[3].hintText, 'Placeholder1');
      });
    });

    group('edge cases', () {
      test('handles empty input', () {
        final elements = service.parseViewHierarchy('');
        expect(elements, isEmpty);
      });

      test('handles whitespace only input', () {
        final elements = service.parseViewHierarchy('   \n  \n  ');
        expect(elements, isEmpty);
      });

      test('skips elements without meaningful content', () {
        const csvData = '''1,0,"","",0'''; // No bounds, no attributes

        final elements = service.parseViewHierarchy(csvData);

        expect(elements, isEmpty);
      });

      test('keeps elements with only bounds', () {
        const csvData = '''1,0,"[0,0][100,50]","",0''';

        final elements = service.parseViewHierarchy(csvData);

        expect(elements.length, 1);
        expect(elements[0].bounds, isNotNull);
      });
    });
  });

  group('SelectorInfo', () {
    test('typeLabel returns correct label for each type', () {
      expect(
        SelectorInfo(type: SelectorType.id, value: 'test').typeLabel,
        'id',
      );
      expect(
        SelectorInfo(type: SelectorType.text, value: 'test').typeLabel,
        'text',
      );
      expect(
        SelectorInfo(type: SelectorType.hintText, value: 'test').typeLabel,
        'hintText',
      );
      expect(
        SelectorInfo(type: SelectorType.accessibilityText, value: 'test').typeLabel,
        'accessibilityText',
      );
      expect(
        SelectorInfo(type: SelectorType.point, value: 'test').typeLabel,
        'point',
      );
    });

    test('toString formats correctly without index', () {
      final selector = SelectorInfo(type: SelectorType.text, value: 'Submit');
      expect(selector.toString(), 'text: Submit');
    });

    test('toString formats correctly with index', () {
      final selector = SelectorInfo(type: SelectorType.text, value: 'Item', index: 2);
      expect(selector.toString(), 'text: Item [2]');
    });
  });

  group('UIPlatform', () {
    test('all platforms are defined', () {
      expect(UIPlatform.values, containsAll([
        UIPlatform.ios,
        UIPlatform.android,
        UIPlatform.web,
        UIPlatform.macos,
        UIPlatform.linux,
        UIPlatform.windows,
        UIPlatform.unknown,
      ]));
    });
  });
}








