// Architecture Validation Script
// This script validates that the clean architecture components are properly structured
// Run with: dart run test/architecture_validation.dart

import 'dart:io';
import 'package:advanced_tester/domain/entities/widget_entity.dart';
import 'package:advanced_tester/domain/repositories/widget_repository.dart';
import 'package:advanced_tester/domain/usecases/get_widget_tree_usecase.dart';
import 'package:advanced_tester/core/di/service_locator.dart';
import 'package:advanced_tester/core/di/dependency_injection.dart';

void main() {
  print('🏗️  Clean Architecture Validation');
  print('=====================================');

  try {
    // Test 1: Service Locator
    print('✅ Testing Service Locator...');
    serviceLocator.reset();
    serviceLocator.registerSingleton<String>('test-value');
    final retrieved = serviceLocator.get<String>();
    assert(retrieved == 'test-value');
    print('   Service Locator: PASSED');

    // Test 2: Dependency Injection
    print('✅ Testing Dependency Injection...');
    DependencyInjection.configure();
    final widgetRepo = serviceLocator.get<WidgetRepository>();
    assert(widgetRepo != null);
    print('   Dependency Injection: PASSED');

    // Test 3: Use Case Creation
    print('✅ Testing Use Case Creation...');
    final useCase = GetWidgetTreeUseCase(widgetRepo);
    assert(useCase != null);
    print('   Use Case Creation: PASSED');

    // Test 4: Entity Creation
    print('✅ Testing Entity Creation...');
    final widget = WidgetEntity(
      description: 'Test Widget',
      objectId: 'test-123',
      widgetRuntimeType: 'TestWidget',
    );
    assert(widget.displayName == 'TestWidget');
    assert(widget.objectId == 'test-123');
    print('   Entity Creation: PASSED');

    // Test 5: Entity Methods
    print('✅ Testing Entity Methods...');
    assert(widget.hasPotentialDependencies == false);
    assert(widget.isFromUserProject == false);
    assert(widget.effectiveWidgetType == 'TestWidget');
    print('   Entity Methods: PASSED');

    print('\n🎉 All Architecture Components Validated Successfully!');
    print('   - Service Locator: ✅');
    print('   - Dependency Injection: ✅');
    print('   - Use Cases: ✅');
    print('   - Entities: ✅');
    print('   - Repository Interfaces: ✅');
  } catch (e) {
    print('❌ Validation Failed: $e');
    exit(1);
  }
}
