import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/services/ai_test_generation_service.dart';
import 'package:advanced_tester/services/inspector_service.dart';
import 'package:advanced_tester/services/enhanced_dependency_analysis_service.dart';

void main() {
  group('AITestGenerationService Tests', () {
    late AITestGenerationService service;
    late MockInspectorService mockInspectorService;
    late MockEnhancedDependencyAnalysisService mockDependencyService;

    setUp(() {
      // Create a mock URI for InspectorService
      final mockUri = Uri.parse('ws://localhost:8080');
      mockInspectorService = MockInspectorService(mockUri);
      mockDependencyService = MockEnhancedDependencyAnalysisService(
        mockInspectorService,
      );

      service = AITestGenerationService(
        projectPath: '/test/project',
        apiKey: 'test-api-key',
        environmentService: null,
        inspectorService: mockInspectorService,
        dependencyService: null,
        enhancedDependencyService: mockDependencyService,
      );
    });

    group('Service Initialization', () {
      test('should initialize service with required parameters', () {
        expect(service, isNotNull);
        expect(service.projectPath, equals('/test/project'));
        expect(service.apiKey, equals('test-api-key'));
      });

      test('should handle null optional parameters', () {
        final serviceWithNulls = AITestGenerationService(
          projectPath: null,
          apiKey: null,
          environmentService: null,
          inspectorService: null,
          dependencyService: null,
          enhancedDependencyService: null,
        );
        expect(serviceWithNulls, isNotNull);
        expect(serviceWithNulls.projectPath, isNull);
        expect(serviceWithNulls.apiKey, isNull);
      });
    });

    group('Test Generation for Widget Tree Nodes', () {
      test(
        'should generate test for simple widget with creation location',
        () async {
          final creationLocation = CreationLocation(
            file: '/test/lib/my_widget.dart',
            line: 10,
            column: 5,
            name: 'Text',
          );
          final node = createMockWidgetTreeNode(
            'Text',
            creationLocation: creationLocation,
          );

          // The method returns bool indicating success
          final result = await service.generateTestForWidget(node);

          expect(result, isA<bool>());
        },
      );

      test('should handle widget without creation location', () async {
        final node = createMockWidgetTreeNode('Text');

        // Should return false for widget without creation location
        // (exception is caught internally and returns false)
        final result = await service.generateTestForWidget(node);
        expect(result, isFalse);
      });

      test('should generate test for Scaffold widget', () async {
        final creationLocation = CreationLocation(
          file: '/test/lib/home_page.dart',
          line: 15,
          column: 8,
          name: 'Scaffold',
        );
        final node = createMockWidgetTreeNode(
          'Scaffold',
          creationLocation: creationLocation,
        );

        final result = await service.generateTestForWidget(node);

        expect(result, isA<bool>());
      });

      test('should generate test for Column widget with children', () async {
        final creationLocation = CreationLocation(
          file: '/test/lib/column_widget.dart',
          line: 20,
          column: 4,
          name: 'Column',
        );

        final children = [
          createMockWidgetTreeNode('Text'),
          createMockWidgetTreeNode('ElevatedButton'),
        ];
        final node = createMockWidgetTreeNode(
          'Column',
          children: children,
          creationLocation: creationLocation,
        );

        final result = await service.generateTestForWidget(node);

        expect(result, isA<bool>());
      });

      test('should handle complex widget hierarchy', () async {
        final creationLocation = CreationLocation(
          file: '/test/lib/complex_widget.dart',
          line: 25,
          column: 6,
          name: 'Scaffold',
        );

        final children = [
          createMockWidgetTreeNode('AppBar'),
          createMockWidgetTreeNode(
            'Column',
            children: [
              createMockWidgetTreeNode('Text'),
              createMockWidgetTreeNode('ElevatedButton'),
              createMockWidgetTreeNode('FloatingActionButton'),
            ],
          ),
        ];
        final node = createMockWidgetTreeNode(
          'Scaffold',
          children: children,
          creationLocation: creationLocation,
        );

        final result = await service.generateTestForWidget(node);

        expect(result, isA<bool>());
      });
    });

    group('Service Dependencies', () {
      test('should work without inspector service', () {
        final serviceWithoutInspector = AITestGenerationService(
          projectPath: '/test/project',
          apiKey: 'test-key',
          environmentService: null,
          inspectorService: null,
          dependencyService: null,
          enhancedDependencyService: null,
        );

        expect(serviceWithoutInspector, isNotNull);
      });

      test('should work without dependency analysis service', () {
        final serviceWithoutDependency = AITestGenerationService(
          projectPath: '/test/project',
          apiKey: 'test-key',
          environmentService: null,
          inspectorService: mockInspectorService,
          dependencyService: null,
          enhancedDependencyService: null,
        );

        expect(serviceWithoutDependency, isNotNull);
      });
    });

    group('Widget Type Handling', () {
      test('should handle common Flutter widget types', () async {
        final widgetTypes = [
          'Text',
          'Container',
          'Column',
          'Row',
          'Scaffold',
          'AppBar',
          'ElevatedButton',
          'FloatingActionButton',
          'ListView',
          'GridView',
        ];

        for (final widgetType in widgetTypes) {
          final creationLocation = CreationLocation(
            file: '/test/lib/${widgetType.toLowerCase()}_widget.dart',
            line: 10,
            column: 5,
            name: widgetType,
          );
          final node = createMockWidgetTreeNode(
            widgetType,
            creationLocation: creationLocation,
          );

          final result = await service.generateTestForWidget(node);

          expect(
            result,
            isA<bool>(),
            reason: 'Failed for widget type: $widgetType',
          );
        }
      });
    });
  });
}

// Helper function to create mock widget tree nodes
WidgetTreeNode createMockWidgetTreeNode(
  String type, {
  List<WidgetTreeNode> children = const [],
  CreationLocation? creationLocation,
}) {
  return WidgetTreeNode(
    description: type,
    type: '_ElementDiagnosticableTreeNode',
    objectId: 'test-object-id-$type',
    widgetRuntimeType: type,
    hasChildren: children.isNotEmpty,
    children: children,
    attributes: [
      WidgetAttribute(name: 'test-attr', label: 'test-value', type: 'String'),
    ],
    creationLocation: creationLocation,
    createdByLocalProject: true,
    stateful: false,
  );
}

// Mock classes for testing
class MockInspectorService extends InspectorService {
  MockInspectorService(Uri vmServiceUri) : super(vmServiceUri);

  Future<List<WidgetAttribute>> getWidgetProperties(
    String objectId,
    String? widgetType, {
    bool useCache = false,
  }) async {
    return [
      WidgetAttribute(
        name: 'test-property',
        label: 'test-value',
        type: 'String',
      ),
    ];
  }

  Future<void> connect() async {
    // Mock implementation - do nothing
  }

  Future<void> disconnect() async {
    // Mock implementation - do nothing
  }

  Future<WidgetTreeNode?> getRootWidgetSummaryTree() async {
    return null;
  }
}

class MockEnhancedDependencyAnalysisService
    extends EnhancedDependencyAnalysisService {
  MockEnhancedDependencyAnalysisService(InspectorService inspectorService)
    : super(inspectorService);

  Future<EnhancedDependencyResult> analyzeWidgetDependencies(
    WidgetTreeNode node, {
    bool includeSourceAnalysis = true,
    bool includeTreeAnalysis = true,
    bool useCache = false,
  }) async {
    return EnhancedDependencyResult(
      dependencies: [],
      metadata: {
        'widgetType': node.widgetRuntimeType ?? 'Widget',
        'objectId': node.objectId ?? '',
      },
      analysisTime: Duration.zero,
      widgetsAnalyzed: 1,
      sourceFilesAnalyzed: 1,
    );
  }
}
