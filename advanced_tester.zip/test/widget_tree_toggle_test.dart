import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/services/inspector_service.dart';

void main() {
  group('Widget Tree Toggle Tests', () {
    test('should create InspectorConfig with useFullWidgetTree toggle', () {
      // Test default configuration (summary tree)
      const defaultConfig = InspectorConfig();
      expect(defaultConfig.useFullWidgetTree, isFalse);
      expect(defaultConfig.enableLogging, isTrue);

      // Test full tree configuration
      const fullTreeConfig = InspectorConfig(useFullWidgetTree: true);
      expect(fullTreeConfig.useFullWidgetTree, isTrue);

      // Test summary tree configuration (explicit)
      const summaryConfig = InspectorConfig(useFullWidgetTree: false);
      expect(summaryConfig.useFullWidgetTree, isFalse);
    });

    test('should create InspectorService with different configurations', () {
      final uri = Uri.parse('ws://localhost:8080');

      // Test with default config (summary tree)
      final service1 = InspectorService(uri);
      expect(service1.config.useFullWidgetTree, isFalse);

      // Test with full tree config
      const fullConfig = InspectorConfig(useFullWidgetTree: true);
      final service2 = InspectorService(uri, config: fullConfig);
      expect(service2.config.useFullWidgetTree, isTrue);

      // Test getter
      expect(service2.isUsingFullWidgetTree, isTrue);
    });

    test('should handle cache keys correctly', () {
      final uri = Uri.parse('ws://localhost:8080');

      // Test summary tree cache key
      const summaryConfig = InspectorConfig(useFullWidgetTree: false);
      final summaryService = InspectorService(uri, config: summaryConfig);
      expect(summaryService.config.useFullWidgetTree, isFalse);

      // Test full tree cache key
      const fullConfig = InspectorConfig(useFullWidgetTree: true);
      final fullService = InspectorService(uri, config: fullConfig);
      expect(fullService.config.useFullWidgetTree, isTrue);
    });

    test('should provide convenience methods', () {
      final uri = Uri.parse('ws://localhost:8080');
      const summaryConfig = InspectorConfig(useFullWidgetTree: false);
      final service = InspectorService(uri, config: summaryConfig);

      // Test getter
      expect(service.isUsingFullWidgetTree, isFalse);

      // Test toggle method exists (can't test actual toggle without connection)
      expect(() => service.toggleWidgetTreeMode(), returnsNormally);

      // Test cache clearing
      expect(() => service.clearWidgetTreeCache(), returnsNormally);
    });
  });
}
