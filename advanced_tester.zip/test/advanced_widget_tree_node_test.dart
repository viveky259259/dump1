import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/advanced_widget_tree_node.dart';
import 'package:advanced_tester/domain/entities/widget_entity.dart';
import 'package:advanced_tester/services/inspector_service.dart' as inspector;

void main() {
  group('AdvancedWidgetTreeNode Tests', () {
    late WidgetEntity testWidget;
    late AdvancedWidgetTreeNode advancedNode;

    setUp(() {
      testWidget = const WidgetEntity(
        description: 'TestContainer',
        type: 'Container',
        objectId: 'test-container-1',
        hasChildren: true,
        widgetRuntimeType: 'Container',
        stateful: false,
      );

      advancedNode = AdvancedWidgetTreeNode(node: testWidget);
    });

    test(
      'should create AdvancedWidgetTreeNode with correct initial values',
      () async {
        // Wait for auto-population to complete
        await Future.delayed(const Duration(milliseconds: 100));

        expect(advancedNode.node, equals(testWidget));
        expect(
          advancedNode.properties,
          isNotEmpty,
        ); // Properties are now auto-populated
        expect(advancedNode.children, isEmpty);
        expect(
          advancedNode.hasPopulated,
          isTrue,
        ); // Auto-population makes this true
        expect(advancedNode.hashCode, isA<int>());
      },
    );

    test('should populate properties correctly', () async {
      await advancedNode.populateProperties();

      expect(advancedNode.hasPopulated, isTrue);
      expect(advancedNode.properties['displayName'], equals('Container'));
      expect(advancedNode.properties['objectId'], equals('test-container-1'));
      expect(
        advancedNode.properties['effectiveWidgetType'],
        equals('Container'),
      );
      expect(advancedNode.properties['hasChildren'], isTrue);
    });

    test('should auto-populate properties on creation', () async {
      // Create node without InspectorService - should auto-populate basic properties
      final autoNode = AdvancedWidgetTreeNode(node: testWidget);

      // Wait for auto-population to complete
      await Future.delayed(const Duration(milliseconds: 100));

      expect(autoNode.hasPopulated, isTrue);
      expect(autoNode.properties['displayName'], equals('Container'));
      expect(autoNode.properties['objectId'], equals('test-container-1'));
      expect(autoNode.properties['hasChildren'], isTrue);
    });

    test(
      'should populate properties with InspectorService when available',
      () async {
        // Create a mock InspectorService
        final mockInspectorService = MockInspectorService();

        // Create node with InspectorService - properties will populate automatically
        final nodeWithInspector = AdvancedWidgetTreeNode(
          node: testWidget,
          inspectorService: mockInspectorService,
        );

        // Wait for auto-population to complete
        await Future.delayed(const Duration(milliseconds: 100));

        expect(nodeWithInspector.hasPopulated, isTrue);
        expect(nodeWithInspector.properties, isNotEmpty);
        expect(
          nodeWithInspector.properties['displayName'],
          equals('Container'),
        );

        // Should have detailed attributes from InspectorService
        expect(
          nodeWithInspector.properties.containsKey('detailedAttributes'),
          isTrue,
        );
        expect(
          nodeWithInspector.properties.containsKey('rawDetailedProperties'),
          isTrue,
        );
      },
    );

    test('should add and remove children correctly', () {
      final childWidget = const WidgetEntity(
        description: 'TestText',
        type: 'Text',
        objectId: 'test-text-1',
        hasChildren: false,
      );

      final childNode = AdvancedWidgetTreeNode(node: childWidget);

      advancedNode.addChild(childNode);
      expect(advancedNode.children.length, equals(1));
      expect(advancedNode.children.first, equals(childNode));

      advancedNode.removeChild(childNode);
      expect(advancedNode.children.length, equals(0));
    });

    test('should update properties correctly', () {
      advancedNode.updateProperty('customProperty', 'customValue');
      expect(advancedNode.getProperty('customProperty'), equals('customValue'));
      expect(advancedNode.hasProperty('customProperty'), isTrue);

      advancedNode.removeProperty('customProperty');
      expect(advancedNode.hasProperty('customProperty'), isFalse);
    });

    test('should calculate total descendants correctly', () {
      final child1 = AdvancedWidgetTreeNode(
        node: const WidgetEntity(description: 'Child1', objectId: 'child1'),
      );
      final child2 = AdvancedWidgetTreeNode(
        node: const WidgetEntity(description: 'Child2', objectId: 'child2'),
      );
      final grandChild = AdvancedWidgetTreeNode(
        node: const WidgetEntity(
          description: 'GrandChild',
          objectId: 'grandchild',
        ),
      );

      child1.addChild(grandChild);
      advancedNode.addChild(child1);
      advancedNode.addChild(child2);

      expect(
        advancedNode.totalDescendants,
        equals(4),
      ); // self + 2 children + 1 grandchild
    });

    test('should find descendants by ID correctly', () {
      final child1 = AdvancedWidgetTreeNode(
        node: const WidgetEntity(description: 'Child1', objectId: 'child1'),
      );
      final child2 = AdvancedWidgetTreeNode(
        node: const WidgetEntity(description: 'Child2', objectId: 'child2'),
      );

      advancedNode.addChild(child1);
      advancedNode.addChild(child2);

      final found = advancedNode.findDescendantById('child1');
      expect(found, isNotNull);
      expect(found!.node.objectId, equals('child1'));

      final notFound = advancedNode.findDescendantById('nonexistent');
      expect(notFound, isNull);
    });

    test('should find descendants by type correctly', () {
      final textChild = AdvancedWidgetTreeNode(
        node: const WidgetEntity(
          description: 'TestText',
          type: 'Text',
          objectId: 'text1',
          widgetRuntimeType: 'Text',
        ),
      );
      final containerChild = AdvancedWidgetTreeNode(
        node: const WidgetEntity(
          description: 'TestContainer',
          type: 'Container',
          objectId: 'container1',
          widgetRuntimeType: 'Container',
        ),
      );

      advancedNode.addChild(textChild);
      advancedNode.addChild(containerChild);

      final textNodes = advancedNode.findDescendantsByType('Text');
      expect(textNodes.length, equals(1));
      expect(textNodes.first.node.effectiveWidgetType, equals('Text'));

      final containerNodes = advancedNode.findDescendantsByType('Container');
      expect(containerNodes.length, equals(2)); // self + child
    });

    test('should get detailed tree correctly after population', () async {
      final child = AdvancedWidgetTreeNode(
        node: const WidgetEntity(
          description: 'Child',
          type: 'Text',
          objectId: 'child1',
          widgetRuntimeType: 'Text',
        ),
      );

      advancedNode.addChild(child);
      await advancedNode.populateProperties();
      await child.populateProperties();

      final detailedTree = await advancedNode.getDetailedTree;

      expect(detailedTree['displayName'], equals('Container'));
      expect(detailedTree['children'], isA<List>());
      expect(detailedTree['children'].length, equals(1));
      expect(detailedTree['children'][0]['displayName'], equals('Text'));
    });

    test('should create copy with updated properties', () {
      final copy = advancedNode.copyWith(
        properties: {'newProperty': 'newValue'},
      );

      expect(copy.node, equals(advancedNode.node));
      expect(copy.properties['newProperty'], equals('newValue'));
      expect(copy.children, equals(advancedNode.children));
    });

    test('should serialize to and from JSON correctly', () {
      advancedNode.updateProperty('testProperty', 'testValue');

      final json = advancedNode.toJson();
      expect(json['properties']['testProperty'], equals('testValue'));
      expect(json['hasPopulated'], isFalse);

      final restored = AdvancedWidgetTreeNode.fromJson(json);
      expect(restored.node.objectId, equals(advancedNode.node.objectId));
      expect(restored.properties['testProperty'], equals('testValue'));
      expect(restored.hasPopulated, isFalse);
    });

    test('should implement equality correctly', () {
      final node1 = AdvancedWidgetTreeNode(node: testWidget);
      final node2 = AdvancedWidgetTreeNode(node: testWidget);

      // Test that nodes with same objectId are equal
      expect(node1.node.objectId, equals(node2.node.objectId));
      expect(node1.node, equals(node2.node));

      // Test that the nodes themselves are equal because they have the same node and hash code
      expect(node1 == node2, isTrue);
    });
  });
}

/// Mock InspectorService for testing
class MockInspectorService extends inspector.InspectorService {
  MockInspectorService() : super(Uri.parse('ws://localhost:8080'));

  @override
  Future<List<Map<String, dynamic>>?> getWidgetDetails(String objectId) async {
    // Return mock detailed properties
    return [
      {'name': 'width', 'value': 200.0, 'description': '200.0'},
      {'name': 'height', 'value': 100.0, 'description': '100.0'},
      {
        'name': 'color',
        'value': 'Color(0xFF2196F3)',
        'description': 'Color(0xFF2196F3)',
      },
    ];
  }

  @override
  List<inspector.WidgetAttribute> extractAttributesFromProperties(
    List<Map<String, dynamic>> properties,
    String? widgetType,
  ) {
    return properties
        .map(
          (prop) => inspector.WidgetAttribute(
            name: prop['name'] as String,
            label: prop['description'] as String,
            type: 'dynamic',
            value: prop['value'],
          ),
        )
        .toList();
  }
}
