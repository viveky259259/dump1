import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/widget_entity.dart';
import 'package:advanced_tester/domain/repositories/widget_repository.dart';
import 'package:advanced_tester/domain/usecases/get_widget_tree_usecase.dart';
import 'package:advanced_tester/core/di/service_locator.dart';

// Mock implementation for testing
class MockWidgetRepository implements WidgetRepository {
  bool _isConnected = true;
  WidgetEntity? _mockWidget;
  Exception? _throwException;

  void setConnected(bool connected) => _isConnected = connected;
  void setMockWidget(WidgetEntity? widget) => _mockWidget = widget;
  void setThrowException(Exception? exception) => _throwException = exception;

  @override
  bool get isConnected => _isConnected;

  @override
  Future<void> connect() async {}

  @override
  Future<void> disconnect() async {}

  @override
  Future<WidgetEntity?> getRootWidgetTree() async {
    if (_throwException != null) {
      throw _throwException!;
    }
    return _mockWidget;
  }

  @override
  Future<List<WidgetAttribute>?> getWidgetProperties(String objectId) async {
    return [];
  }

  @override
  Future<List<WidgetEntity>> getWidgetChildren(String objectId) async {
    return [];
  }

  @override
  Future<void> selectWidget(String objectId) async {}

  @override
  Future<WidgetEntity?> getSelectedWidget() async {
    return null;
  }

  @override
  Future<bool> isInspectorAvailable() async {
    return true;
  }

  @override
  void clearCache() {}

  @override
  Future<SourceLocation?> getWidgetSourceLocation(String objectId) async {
    return null;
  }

  @override
  Future<String?> getWidgetSourceCode(SourceLocation location) async {
    return null;
  }
}

void main() {
  group('Clean Architecture Tests', () {
    late MockWidgetRepository mockRepository;
    late GetWidgetTreeUseCase useCase;

    setUp(() {
      // Reset service locator
      serviceLocator.reset();

      // Create mock repository
      mockRepository = MockWidgetRepository();

      // Register mock in service locator
      serviceLocator.registerSingleton<WidgetRepository>(mockRepository);

      // Create use case
      useCase = GetWidgetTreeUseCase(mockRepository);
    });

    tearDown(() {
      serviceLocator.reset();
    });

    test('should get widget tree successfully', () async {
      // Arrange
      final expectedWidget = WidgetEntity(
        description: 'Test Widget',
        objectId: 'test-123',
        widgetRuntimeType: 'TestWidget',
      );

      mockRepository.setConnected(true);
      mockRepository.setMockWidget(expectedWidget);

      // Act
      final result = await useCase.execute();

      // Assert
      expect(result, equals(expectedWidget));
    });

    test('should throw exception when repository not connected', () async {
      // Arrange
      mockRepository.setConnected(false);

      // Act & Assert
      expect(
        () => useCase.execute(),
        throwsA(isA<WidgetRepositoryException>()),
      );
    });

    test('should throw exception when repository throws error', () async {
      // Arrange
      mockRepository.setConnected(true);
      mockRepository.setThrowException(Exception('Repository error'));

      // Act & Assert
      expect(
        () => useCase.execute(),
        throwsA(isA<WidgetRepositoryException>()),
      );
    });
  });

  group('Dependency Injection Tests', () {
    setUp(() {
      serviceLocator.reset();
    });

    tearDown(() {
      serviceLocator.reset();
    });

    test('should register and retrieve singleton', () {
      // Arrange
      final testInstance = TestClass();
      serviceLocator.registerSingleton<TestClass>(testInstance);

      // Act
      final retrieved = serviceLocator.get<TestClass>();

      // Assert
      expect(retrieved, equals(testInstance));
      expect(serviceLocator.isRegistered<TestClass>(), isTrue);
    });

    test('should register and retrieve factory', () {
      // Arrange
      serviceLocator.registerFactory<TestClass>(() => TestClass());

      // Act
      final instance1 = serviceLocator.get<TestClass>();
      final instance2 = serviceLocator.get<TestClass>();

      // Assert
      expect(instance1, isA<TestClass>());
      expect(instance2, isA<TestClass>());
      expect(instance1, isNot(equals(instance2))); // Different instances
    });

    test('should register and retrieve lazy singleton', () {
      // Arrange
      var callCount = 0;
      serviceLocator.registerLazySingleton<TestClass>(() {
        callCount++;
        return TestClass();
      });

      // Act
      final instance1 = serviceLocator.get<TestClass>();
      final instance2 = serviceLocator.get<TestClass>();

      // Assert
      expect(instance1, equals(instance2)); // Same instance
      expect(callCount, equals(1)); // Factory called only once
    });

    test('should throw exception for unregistered service', () {
      // Act & Assert
      expect(
        () => serviceLocator.get<TestClass>(),
        throwsA(isA<ServiceLocatorException>()),
      );
    });

    test('should check if service is registered', () {
      // Arrange
      expect(serviceLocator.isRegistered<TestClass>(), isFalse);

      serviceLocator.registerSingleton<TestClass>(TestClass());

      // Act & Assert
      expect(serviceLocator.isRegistered<TestClass>(), isTrue);
    });
  });

  group('Widget Entity Tests', () {
    test('should create widget entity with all properties', () {
      // Arrange
      final creationLocation = CreationLocation(
        file: 'test.dart',
        line: 10,
        column: 5,
        name: 'TestWidget',
      );

      final attributes = [
        WidgetAttribute(
          name: 'text',
          label: "'Hello World'",
          type: 'String',
          value: 'Hello World',
        ),
      ];

      // Act
      final widget = WidgetEntity(
        description: 'Test Widget',
        type: '_ElementDiagnosticableTreeNode',
        objectId: 'test-123',
        style: 'dense',
        hasChildren: true,
        allowWrap: false,
        summaryTree: false,
        locationId: 1,
        creationLocation: creationLocation,
        createdByLocalProject: true,
        widgetRuntimeType: 'TestWidget',
        stateful: false,
        children: [],
        properties: {'key': 'value'},
        attributes: attributes,
      );

      // Assert
      expect(widget.description, equals('Test Widget'));
      expect(widget.objectId, equals('test-123'));
      expect(widget.displayName, equals('TestWidget'));
      expect(widget.effectiveWidgetType, equals('TestWidget'));
      expect(widget.isFromUserProject, isTrue);
      // User project widgets that aren't built-in Flutter widgets have potential dependencies
      expect(widget.hasPotentialDependencies, isTrue);
      expect(widget.creationLocation, equals(creationLocation));
      expect(widget.attributes, equals(attributes));
    });

    test('should return correct display name', () {
      // Test with widgetRuntimeType
      final widget1 = WidgetEntity(
        widgetRuntimeType: 'MyWidget',
        description: 'Some Description',
      );
      expect(widget1.displayName, equals('MyWidget'));

      // Test with description
      final widget2 = WidgetEntity(description: 'Some Description');
      expect(widget2.displayName, equals('Some Description'));

      // Test with type
      final widget3 = WidgetEntity(type: 'SomeType');
      expect(widget3.displayName, equals('SomeType'));

      // Test with none
      final widget4 = WidgetEntity();
      expect(widget4.displayName, equals('Unknown Widget'));
    });

    test('should detect potential dependencies', () {
      // Provider widget
      final providerWidget = WidgetEntity(
        description: 'ChangeNotifierProvider<UserService>',
      );
      expect(providerWidget.hasPotentialDependencies, isTrue);

      // Scaffold widget
      final scaffoldWidget = WidgetEntity(widgetRuntimeType: 'Scaffold');
      expect(scaffoldWidget.hasPotentialDependencies, isTrue);

      // Custom widget from user project
      final customWidget = WidgetEntity(
        widgetRuntimeType: 'CustomWidget',
        createdByLocalProject: true,
      );
      expect(customWidget.hasPotentialDependencies, isTrue);

      // Built-in widget
      final builtInWidget = WidgetEntity(
        widgetRuntimeType: 'Container',
        createdByLocalProject: false,
      );
      expect(builtInWidget.hasPotentialDependencies, isFalse);
    });

    test('should create copy with updated fields', () {
      // Arrange
      final original = WidgetEntity(
        description: 'Original',
        objectId: 'original-123',
        widgetRuntimeType: 'OriginalWidget',
      );

      // Act
      final copy = original.copyWith(
        description: 'Updated',
        widgetRuntimeType: 'UpdatedWidget',
      );

      // Assert
      expect(copy.description, equals('Updated'));
      expect(copy.objectId, equals('original-123')); // Unchanged
      expect(copy.widgetRuntimeType, equals('UpdatedWidget'));
    });
  });
}

/// Test class for dependency injection tests
class TestClass {
  @override
  bool operator ==(Object other) {
    return identical(this, other);
  }

  @override
  int get hashCode => runtimeType.hashCode;
}
