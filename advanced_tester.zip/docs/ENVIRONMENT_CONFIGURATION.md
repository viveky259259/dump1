# Environment Configuration System

The Advanced Flutter Testing Framework includes a comprehensive environment configuration system that allows you to customize the application behavior through various configuration methods.

## Overview

The environment configuration system provides:
- **Multiple configuration sources** with precedence order
- **Runtime configuration updates** through the UI
- **Feature flags** for enabling/disabling functionality
- **API key management** for AI services
- **Theme and UI customization**
- **Development and security settings**

## Configuration Sources (Precedence Order)

1. **Dart-define flags** (highest priority)
2. **Environment variables**
3. **Saved preferences** (lowest priority)

## Configuration Methods

### 1. Dart-define Flags

Use `--dart-define` flags when running the app:

```bash
flutter run --dart-define=DEMO_MODE=true --dart-define=OPENAI_API_KEY=sk-... --dart-define=ENABLE_AI=true
```

### 2. Environment Variables

Set environment variables in your system:

```bash
export OPENAI_API_KEY="sk-..."
export DEMO_MODE="true"
export ENABLE_AI="true"
export DEVTOOLS_SERVER_URL="http://localhost:8080"
```

### 3. UI Configuration

Access the Environment Configuration page through the app's settings to configure options at runtime.

## Configuration Options

### API Keys

| Option | Description | Example |
|--------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key for GPT models | `sk-...` |
| `ANTHROPIC_API_KEY` | Anthropic API key for Claude models | `sk-ant-...` |
| `GEMINI_API_KEY` | Google Gemini API key | `AI...` |

### Service URLs

| Option | Description | Example |
|--------|-------------|---------|
| `DEVTOOLS_SERVER_URL` | DevTools server URL | `http://localhost:8080` |
| `VM_SERVICE_URL` | VM service WebSocket URL | `ws://localhost:8080` |

### Feature Flags

| Option | Description | Default |
|--------|-------------|---------|
| `ENABLE_AI` | Enable AI-powered features | `true` |
| `DEMO_MODE` | Enable demo mode with sample data | `false` |
| `DEBUG_MODE` | Enable debug logging and verbose output | `false` |
| `ENABLE_ANALYTICS` | Enable usage analytics and telemetry | `true` |
| `ENABLE_HOT_RELOAD` | Enable hot reload for development | `true` |
| `ENABLE_PERFORMANCE_MONITORING` | Enable performance monitoring | `false` |
| `ENABLE_AUTO_TEST_GENERATION` | Automatically generate tests | `false` |
| `ENABLE_TEST_COVERAGE` | Enable test coverage analysis | `true` |
| `ENABLE_SECURE_MODE` | Enable additional security measures | `false` |
| `ENABLE_API_KEY_VALIDATION` | Validate API key formats | `true` |

### UI Settings

| Option | Description | Default |
|--------|-------------|---------|
| `ENABLE_DARK_MODE` | Enable dark theme | `false` |
| `THEME_COLOR` | Primary theme color | `indigo` |
| `ENABLE_ANIMATIONS` | Enable UI animations | `true` |

### Development Settings

| Option | Description | Default |
|--------|-------------|---------|
| `LOG_LEVEL` | Logging level (debug, info, warning, error) | `info` |
| `DEFAULT_TEST_FRAMEWORK` | Default test framework | `flutter_test` |
| `API_TIMEOUT` | API timeout in milliseconds | `30000` |

## Usage Examples

### Basic Configuration

```bash
# Run with demo mode and OpenAI API key
flutter run --dart-define=DEMO_MODE=true --dart-define=OPENAI_API_KEY=sk-your-key-here
```

### Development Configuration

```bash
# Run in debug mode with performance monitoring
flutter run --dart-define=DEBUG_MODE=true --dart-define=ENABLE_PERFORMANCE_MONITORING=true --dart-define=LOG_LEVEL=debug
```

### Production Configuration

```bash
# Run in production mode with secure settings
flutter run --dart-define=ENABLE_SECURE_MODE=true --dart-define=ENABLE_ANALYTICS=false --dart-define=ENABLE_DEBUG_MODE=false
```

### Custom Theme Configuration

```bash
# Run with custom theme
flutter run --dart-define=THEME_COLOR=blue --dart-define=ENABLE_DARK_MODE=true
```

## Environment Service API

### Getting Configuration

```dart
// Get the environment service
final envService = context.read<EnvironmentService>();

// Check if AI capabilities are available
if (envService.hasAICapabilities) {
  // Use AI features
}

// Get API key for specific provider
final openaiKey = envService.getApiKey('openai');
```

### Updating Configuration

```dart
// Update API key
await envService.setApiKey('openai', 'sk-your-new-key');

// Enable/disable features
await envService.setAIEnabled(true);
await envService.setDemoMode(false);

// Update theme preferences
await envService.setThemePreferences(
  enableDarkMode: true,
  themeColor: 'blue',
  enableAnimations: false,
);
```

### Validating Configuration

```dart
// Validate current configuration
final errors = envService.validateConfig();
if (errors.isNotEmpty) {
  print('Configuration errors: $errors');
}
```

## Configuration Files

### Environment Config Model

The `EnvironmentConfig` class defines all available configuration options:

```dart
class EnvironmentConfig {
  // API Configuration
  final String? openaiApiKey;
  final String? anthropicApiKey;
  final String? geminiApiKey;
  
  // Feature Flags
  final bool enableAI;
  final bool enableDemoMode;
  final bool enableDebugMode;
  
  // UI Settings
  final bool enableDarkMode;
  final String? themeColor;
  final bool enableAnimations;
  
  // ... other options
}
```

### Environment Service

The `EnvironmentService` manages configuration loading, saving, and updates:

```dart
class EnvironmentService extends ChangeNotifier {
  // Initialize configuration
  Future<void> initialize();
  
  // Update configuration
  Future<void> updateConfig(EnvironmentConfig newConfig);
  
  // Get API key
  String? getApiKey(String provider);
  
  // Validate configuration
  List<String> validate();
}
```

## UI Configuration Page

The Environment Configuration page provides a comprehensive interface for managing all configuration options:

### Tabs

1. **API Keys** - Configure AI provider API keys and service URLs
2. **Features** - Enable/disable core features and test generation options
3. **UI** - Customize theme, colors, and animations
4. **Development** - Configure development settings and logging
5. **Security** - Manage security settings and validation

### Features

- **Real-time validation** of configuration values
- **Configuration status** indicators
- **AI capabilities status** display
- **Save/Reset** functionality
- **Configuration summary** for debugging

## Best Practices

### Security

1. **Never commit API keys** to version control
2. **Use environment variables** for sensitive data
3. **Enable API key validation** in production
4. **Use secure mode** for production deployments

### Development

1. **Use debug mode** for development
2. **Enable hot reload** for faster iteration
3. **Set appropriate log levels** for debugging
4. **Use demo mode** for testing without real data

### Production

1. **Disable debug mode** in production
2. **Enable secure mode** for additional security
3. **Configure appropriate timeouts**
4. **Disable unnecessary features** to improve performance

## Troubleshooting

### Common Issues

1. **AI features not working**
   - Check if API keys are configured
   - Verify `ENABLE_AI` is set to `true`
   - Check API key validation errors

2. **Configuration not saving**
   - Check SharedPreferences permissions
   - Verify configuration validation
   - Check for runtime errors

3. **Theme not applying**
   - Verify theme color is valid
   - Check if dark mode is properly configured
   - Restart the app after theme changes

### Debugging

Use the configuration summary to debug issues:

```dart
final summary = envService.getConfigSummary();
print('Configuration summary: $summary');
```

### Validation Errors

Check validation errors to identify configuration issues:

```dart
final errors = envService.validateConfig();
if (errors.isNotEmpty) {
  print('Configuration errors:');
  for (final error in errors) {
    print('- $error');
  }
}
```

## Migration Guide

### From Legacy Configuration

If you're migrating from a legacy configuration system:

1. **Identify existing configuration** sources
2. **Map legacy options** to new environment config
3. **Update initialization code** to use EnvironmentService
4. **Test configuration** in different environments

### Updating Existing Apps

To add environment configuration to existing apps:

1. **Add environment config files** to your project
2. **Initialize EnvironmentService** in main.dart
3. **Update providers** to include EnvironmentService
4. **Add configuration UI** if needed
5. **Update existing code** to use environment config

## Examples

### Complete Configuration Example

```bash
# Complete development configuration
flutter run \
  --dart-define=DEMO_MODE=true \
  --dart-define=DEBUG_MODE=true \
  --dart-define=OPENAI_API_KEY=sk-your-key \
  --dart-define=DEVTOOLS_SERVER_URL=http://localhost:8080 \
  --dart-define=ENABLE_AI=true \
  --dart-define=ENABLE_HOT_RELOAD=true \
  --dart-define=LOG_LEVEL=debug \
  --dart-define=THEME_COLOR=blue \
  --dart-define=ENABLE_DARK_MODE=true
```

### Runtime Configuration Update

```dart
// Update configuration at runtime
final envService = context.read<EnvironmentService>();

// Enable AI with new API key
await envService.setApiKey('openai', 'sk-new-key');
await envService.setAIEnabled(true);

// Update theme
await envService.setThemePreferences(
  enableDarkMode: true,
  themeColor: 'purple',
);

// Validate changes
final errors = envService.validateConfig();
if (errors.isEmpty) {
  print('Configuration updated successfully');
}
```

## API Reference

### EnvironmentConfig

| Method | Description |
|--------|-------------|
| `fromEnvironment()` | Create from environment variables |
| `fromDartDefine()` | Create from dart-define flags |
| `merge(other)` | Merge with another config |
| `validate()` | Validate configuration |
| `toMap()` | Convert to map |
| `fromMap(map)` | Create from map |

### EnvironmentService

| Method | Description |
|--------|-------------|
| `initialize()` | Initialize the service |
| `updateConfig(config)` | Update configuration |
| `getApiKey(provider)` | Get API key for provider |
| `setApiKey(provider, key)` | Set API key for provider |
| `validateConfig()` | Validate current configuration |
| `resetToDefaults()` | Reset to default configuration |
| `getConfigSummary()` | Get configuration summary |

## Contributing

When adding new configuration options:

1. **Add to EnvironmentConfig** class
2. **Update EnvironmentService** methods
3. **Add to UI configuration page**
4. **Update documentation**
5. **Add validation rules**
6. **Test in different environments**

## Support

For issues with environment configuration:

1. **Check configuration validation** errors
2. **Verify environment variables** are set correctly
3. **Check dart-define flags** syntax
4. **Review configuration precedence** order
5. **Test with minimal configuration** first
