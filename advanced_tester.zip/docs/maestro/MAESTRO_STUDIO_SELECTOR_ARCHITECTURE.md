# Maestro Studio Selector Architecture

## Table of Contents
1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Selector Extraction Deep Dive](#selector-extraction-deep-dive)
4. [Backend Implementation](#backend-implementation)
5. [Frontend Implementation](#frontend-implementation)
6. [Data Flow](#data-flow)
7. [API Contracts](#api-contracts)
8. [Interaction Modes](#interaction-modes)
9. [Performance Optimizations](#performance-optimizations)
10. [Code Examples](#code-examples)

---

## Overview

Maestro Studio provides a real-time, interactive interface for inspecting UI elements on connected devices (iOS, Android, or Web). The selector system enables users to:

- **Visually inspect** UI elements with bounding box overlays
- **Search and filter** elements by text, ID, hint text, or accessibility labels
- **Select elements** to view detailed properties
- **Generate Maestro commands** based on selected elements
- **Navigate** elements using keyboard shortcuts or mouse interactions

### Key Features

- **Real-time synchronization**: Device screen updates continuously via Server-Sent Events (SSE)
- **Multi-platform support**: Works with iOS, Android, and Web applications
- **Rich selector data**: Extracts text, resource IDs, bounds, accessibility info, and indices
- **Interactive UI**: Hover highlighting, click selection, searchable panels
- **Performance optimized**: Minimal re-renders, efficient diffing

---

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                          DEVICE LAYER                           │
│         (iOS Simulator/Android Emulator/Web Browser)            │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      MAESTRO DRIVER LAYER                       │
│  • maestro.viewHierarchy() - Captures UI tree                  │
│  • maestro.takeScreenshot() - Captures visual state            │
│  • maestro.deviceInfo() - Gets device dimensions               │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    BACKEND: DeviceService.kt                    │
│                      (Kotlin + Ktor Server)                     │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ 1. View Hierarchy Processing                          │   │
│  │    • treeToElements() - Flatten tree to element list  │   │
│  │    • Extract attributes (text, ID, bounds, etc.)      │   │
│  │    • Calculate indices for duplicate selectors        │   │
│  │    • Generate stable unique IDs                       │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ 2. Screenshot Management                              │   │
│  │    • Capture PNG screenshots                          │   │
│  │    • Store in temp directory                          │   │
│  │    • Cleanup old screenshots (max 10)                 │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ 3. Data Serialization                                 │   │
│  │    • DeviceScreen model → JSON                        │   │
│  │    • Server-Sent Events (SSE) streaming               │   │
│  └────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼ SSE Stream (/api/device-screen/sse)
┌─────────────────────────────────────────────────────────────────┐
│                   FRONTEND: React Application                   │
│                                                                 │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ API Layer (api.ts)                                    │   │
│  │  • useSse() - EventSource subscription                │   │
│  │  • useDeviceScreen() - Real-time hook                 │   │
│  └──────────────────┬─────────────────────────────────────┘   │
│                     │                                           │
│                     ▼                                           │
│  ┌────────────────────────────────────────────────────────┐   │
│  │ DeviceContext (DeviceContext.tsx)                     │   │
│  │  • Manages device screen state                        │   │
│  │  • Tracks hovered element                             │   │
│  │  • Tracks inspected element                           │   │
│  │  • Optimizes re-renders                               │   │
│  └──────────┬─────────────────────┬───────────────────────┘   │
│             │                     │                             │
│             ▼                     ▼                             │
│  ┌──────────────────┐   ┌────────────────────────────────┐   │
│  │AnnotatedScreen   │   │   ElementsPanel                │   │
│  │                  │   │                                │   │
│  │• Screenshot      │   │ • Searchable list              │   │
│  │• Bounding boxes  │   │ • Filter by text/ID            │   │
│  │• Hover detection │   │ • Keyboard navigation          │   │
│  │• Click selection │   │ • Synchronized highlighting    │   │
│  │• Crosshairs      │   │ • Shows all selector types     │   │
│  └──────────────────┘   └────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Technology Stack

**Backend:**
- **Language**: Kotlin
- **Framework**: Ktor (HTTP server)
- **Serialization**: Jackson (JSON)
- **Communication**: Server-Sent Events (SSE)

**Frontend:**
- **Language**: TypeScript
- **Framework**: React
- **State Management**: React Context + Hooks
- **Data Fetching**: SWR (Stale-While-Revalidate)
- **Styling**: Tailwind CSS

---

## Selector Extraction Deep Dive

This section explains **exactly how** Maestro Studio extracts text, IDs, and other selector information from the device's UI hierarchy.

### What Gets Extracted?

For each UI element, Maestro Studio extracts the following attributes:

| Attribute | Description | Example Value | Platforms |
|-----------|-------------|---------------|-----------|
| **text** | Visible text content | `"Login"`, `"Submit Form"` | iOS, Android, Web |
| **resourceId** | Unique identifier | `"com.app:id/login_btn"` (Android)<br>`"login-button"` (iOS accessibility ID)<br>`"submitBtn"` (Web element ID) | iOS, Android, Web |
| **hintText** | Placeholder/hint text | `"Enter your email"` | iOS, Android, Web |
| **accessibilityText** | Accessibility label | `"Login button"`, `"Submit form button"` | iOS, Android, Web |
| **bounds** | Position and size | `x: 50, y: 400, width: 290, height: 44` | iOS, Android, Web |
| **textIndex** | Index among duplicates | `0`, `1`, `2` | All |
| **resourceIdIndex** | Index among ID duplicates | `0`, `1` | All |

### Extraction Process Overview

```
┌──────────────────────────────────────────────────────────────┐
│                    Device UI Hierarchy                        │
│                         (TreeNode)                            │
│                                                               │
│  Button {                                                     │
│    attributes: {                                              │
│      "text": "Login",                                         │
│      "resource-id": "com.app:id/login_btn",                  │
│      "bounds": "[50,400][340,444]",                          │
│      "enabled": "true",                                       │
│      "accessibilityText": "Login button"                      │
│    },                                                         │
│    children: [...]                                            │
│  }                                                            │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           ▼
              ┌────────────────────────────┐
              │   Attribute Extraction     │
              │   (TreeNode.attribute())   │
              └────────────┬───────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────┐
│                    Extracted Attributes                       │
│                                                               │
│  text: "Login"                                                │
│  resourceId: "com.app:id/login_btn"                          │
│  hintText: null                                               │
│  accessibilityText: "Login button"                            │
│  bounds: [50,400][340,444]                                    │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           ▼
              ┌────────────────────────────┐
              │    Bounds Parsing          │
              │   (TreeNode.bounds())      │
              └────────────┬───────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────┐
│                   Structured Bounds                           │
│                                                               │
│  UIElementBounds(                                             │
│    x = 50,                                                    │
│    y = 400,                                                   │
│    width = 290,                                               │
│    height = 44                                                │
│  )                                                            │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           ▼
              ┌────────────────────────────┐
              │   Index Calculation        │
              │   (getIndex())             │
              └────────────┬───────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────┐
│                    Final UIElement                            │
│                                                               │
│  UIElement(                                                   │
│    id = "com.app:id/login_btn",                              │
│    text = "Login",                                            │
│    resourceId = "com.app:id/login_btn",                      │
│    hintText = null,                                           │
│    accessibilityText = "Login button",                        │
│    bounds = UIElementBounds(50, 400, 290, 44),               │
│    textIndex = null,                                          │
│    resourceIdIndex = null                                     │
│  )                                                            │
└──────────────────────────────────────────────────────────────┘
```

### Step-by-Step Extraction Code

#### Step 1: Attribute Extraction Helper

This helper safely extracts attributes from the TreeNode:

```kotlin
// Helper function inside treeToElements()
fun TreeNode.attribute(key: String): String? {
    val value = attributes[key]
    if (value.isNullOrEmpty()) return null
    return value
}
```

**Usage**:
```kotlin
val text = element.attribute("text")              // Returns "Login" or null
val resourceId = element.attribute("resource-id")  // Returns "com.app:id/btn" or null
val hintText = element.attribute("hintText")       // Returns "Enter email" or null
val accessibilityText = element.attribute("accessibilityText") // Returns "Login button" or null
```

**Platform-Specific Attribute Names**:

**Android**:
- `text` → Visible text (TextView, Button)
- `resource-id` → Full resource ID (e.g., `com.example.app:id/submit_button`)
- `content-desc` → Content description (mapped to `accessibilityText`)
- `hint` → Hint text (EditText placeholder)

**iOS**:
- `text` → Label or value
- `accessibilityIdentifier` → Accessibility ID (mapped to `resource-id`)
- `accessibilityLabel` → Accessibility label (mapped to `accessibilityText`)
- `placeholderValue` → Placeholder text (mapped to `hintText`)

**Web**:
- `text` → innerText or textContent
- `id` → Element ID attribute (mapped to `resource-id`)
- `aria-label` → ARIA label (mapped to `accessibilityText`)
- `placeholder` → Input placeholder (mapped to `hintText`)

#### Step 2: Bounds Extraction

Converts platform-specific bounds format to structured coordinates:

```kotlin
private fun TreeNode.bounds(): UIElementBounds? {
    val boundsString = attributes["bounds"] ?: return null
    
    // Pattern: [left,top][right,bottom]
    // Example: "[50,400][340,444]"
    val pattern = Pattern.compile("\\[([0-9-]+),([0-9-]+)]\\[([0-9-]+),([0-9-]+)]")
    val m = pattern.matcher(boundsString)
    
    if (!m.matches()) {
        System.err.println("Warning: Bounds text does not match expected pattern: $boundsString")
        return null
    }

    val left = m.group(1).toIntOrNull() ?: return null
    val top = m.group(2).toIntOrNull() ?: return null
    val right = m.group(3).toIntOrNull() ?: return null
    val bottom = m.group(4).toIntOrNull() ?: return null

    return UIElementBounds(
        x = left,
        y = top,
        width = right - left,    // Calculate width
        height = bottom - top,   // Calculate height
    )
}
```

**Examples**:

| Input Bounds String | Parsed Output |
|---------------------|---------------|
| `[0,0][100,50]` | `{x: 0, y: 0, width: 100, height: 50}` |
| `[50,200][350,300]` | `{x: 50, y: 200, width: 300, height: 100}` |
| `[100,500][200,600]` | `{x: 100, y: 500, width: 100, height: 100}` |

#### Step 3: Index Calculation for Duplicates

When multiple elements have the same selector (e.g., multiple "Submit" buttons), Maestro assigns indices:

```kotlin
fun getIndex(filter: ElementFilter, element: TreeNode): Int? {
    val identityHashMap = IdentityHashMap<TreeNode, Unit>()
    
    // Find all elements matching the same filter
    val matchingElements = Filters.deepestMatchingElement(filter)(elements).filter {
        // Remove duplicates using identity comparison
        identityHashMap.put(it, Unit) == null
    }
    
    // If only 0-1 matches, no index needed
    if (matchingElements.size < 2) return null
    
    // Return position in sorted list
    return matchingElements.sortedWith(Filters.INDEX_COMPARATOR).indexOf(element)
}
```

**Example Scenario**:

```kotlin
// Page has 3 buttons with text "Submit"
Button1: text="Submit" → textIndex = 0
Button2: text="Submit" → textIndex = 1  
Button3: text="Submit" → textIndex = 2

// Page has 2 elements with same resource ID
Element1: resourceId="icon" → resourceIdIndex = 0
Element2: resourceId="icon" → resourceIdIndex = 1
```

**Generated Maestro Commands**:
```yaml
# Target first Submit button
- tapOn:
    text: "Submit"
    index: 0

# Target second Submit button  
- tapOn:
    text: "Submit"
    index: 1

# Target second icon element
- tapOn:
    id: "icon"
    index: 1
```

#### Step 4: Complete Extraction Flow

Here's the complete extraction for each element:

```kotlin
return elements.map { element ->
    // 1. Extract all attributes
    val bounds = element.bounds()
    val text = element.attribute("text")
    val hintText = element.attribute("hintText")
    val accessibilityText = element.attribute("accessibilityText")
    val resourceId = element.attribute("resource-id")
    
    // 2. Calculate text index (if duplicate text exists)
    val textIndex = if (text == null) {
        null
    } else {
        getIndex(
            Filters.textMatches(text.toRegexSafe(Orchestra.REGEX_OPTIONS)), 
            element
        )
    }
    
    // 3. Calculate resource ID index (if duplicate ID exists)
    val resourceIdIndex = if (resourceId == null) {
        null
    } else {
        getIndex(
            Filters.idMatches(resourceId.toRegexSafe(Orchestra.REGEX_OPTIONS)), 
            element
        )
    }
    
    // 4. Generate stable unique ID for frontend
    fun createElementId(): String {
        val parts = listOfNotNull(resourceId, resourceIdIndex, text, textIndex)
        val fallbackId = bounds?.let { (x, y, w, h) -> "$x,$y,$w,$h" } 
            ?: UUID.randomUUID().toString()
        val id = if (parts.isEmpty()) fallbackId else parts.joinToString("-")
        val index = ids.compute(id) { _, i -> (i ?: 0) + 1}
        return if (index == 1) id else "$id-$index"
    }
    
    val id = createElementId()
    
    // 5. Create UIElement object
    UIElement(
        id = id,
        bounds = bounds,
        resourceId = resourceId,
        resourceIdIndex = resourceIdIndex,
        text = text,
        hintText = hintText,
        accessibilityText = accessibilityText,
        textIndex = textIndex
    )
}
```

### Real-World Extraction Examples

#### Example 1: Android Login Button

**Input TreeNode**:
```kotlin
TreeNode(
    attributes = mapOf(
        "text" to "Sign In",
        "resource-id" to "com.example.app:id/sign_in_button",
        "bounds" to "[64,856][316,984]",
        "clickable" to "true",
        "enabled" to "true",
        "content-desc" to "Sign in to your account"
    )
)
```

**Extraction Process**:
```kotlin
// Step 1: Extract attributes
text = "Sign In"
resourceId = "com.example.app:id/sign_in_button"
hintText = null
accessibilityText = "Sign in to your account"

// Step 2: Parse bounds
bounds = "[64,856][316,984]"
→ UIElementBounds(x=64, y=856, width=252, height=128)

// Step 3: Calculate indices
textIndex = null (no other "Sign In" buttons)
resourceIdIndex = null (ID is unique)

// Step 4: Generate ID
id = "com.example.app:id/sign_in_button"
```

**Output UIElement**:
```json
{
  "id": "com.example.app:id/sign_in_button",
  "text": "Sign In",
  "resourceId": "com.example.app:id/sign_in_button",
  "hintText": null,
  "accessibilityText": "Sign in to your account",
  "bounds": {
    "x": 64,
    "y": 856,
    "width": 252,
    "height": 128
  },
  "textIndex": null,
  "resourceIdIndex": null
}
```

**Generated Maestro Commands**:
```yaml
# Option 1: Use resource ID (most reliable)
- tapOn:
    id: "com.example.app:id/sign_in_button"

# Option 2: Use text
- tapOn:
    text: "Sign In"

# Option 3: Use accessibility text
- tapOn:
    accessibilityText: "Sign in to your account"
```

#### Example 2: iOS Text Input Field

**Input TreeNode**:
```kotlin
TreeNode(
    attributes = mapOf(
        "text" to "",
        "placeholderValue" to "Enter your email",
        "accessibilityIdentifier" to "email_input",
        "accessibilityLabel" to "Email address field",
        "bounds" to "[20,200][360,244]",
        "type" to "XCUIElementTypeTextField"
    )
)
```

**Extraction Process**:
```kotlin
// Step 1: Extract attributes
text = "" (empty, so treated as null)
resourceId = "email_input" (from accessibilityIdentifier)
hintText = "Enter your email" (from placeholderValue)
accessibilityText = "Email address field" (from accessibilityLabel)

// Step 2: Parse bounds
bounds = "[20,200][360,244]"
→ UIElementBounds(x=20, y=200, width=340, height=44)

// Step 3: Calculate indices
textIndex = null (no text)
resourceIdIndex = null (unique ID)

// Step 4: Generate ID
id = "email_input"
```

**Output UIElement**:
```json
{
  "id": "email_input",
  "text": null,
  "resourceId": "email_input",
  "hintText": "Enter your email",
  "accessibilityText": "Email address field",
  "bounds": {
    "x": 20,
    "y": 200,
    "width": 340,
    "height": 44
  },
  "textIndex": null,
  "resourceIdIndex": null
}
```

**Generated Maestro Commands**:
```yaml
# Option 1: Use accessibility identifier
- tapOn:
    id: "email_input"

# Option 2: Use hint text
- tapOn:
    hintText: "Enter your email"

# Option 3: Use accessibility label
- tapOn:
    accessibilityText: "Email address field"

# Input text into field
- inputText: "user@example.com"
```

#### Example 3: Multiple Identical Buttons (Duplicate Handling)

**Input TreeNodes**:
```kotlin
// Button 1
TreeNode(
    attributes = mapOf(
        "text" to "Delete",
        "bounds" to "[50,300][150,350]"
    )
)

// Button 2
TreeNode(
    attributes = mapOf(
        "text" to "Delete",
        "bounds" to "[50,400][150,450]"
    )
)

// Button 3
TreeNode(
    attributes = mapOf(
        "text" to "Delete",
        "bounds" to "[50,500][150,550]"
    )
)
```

**Extraction Process**:
```kotlin
// All three buttons have text="Delete"
// getIndex() assigns indices based on position

// Button 1
textIndex = 0  // First in sorted order

// Button 2
textIndex = 1  // Second in sorted order

// Button 3
textIndex = 2  // Third in sorted order
```

**Output UIElements**:
```json
[
  {
    "id": "Delete-0",
    "text": "Delete",
    "textIndex": 0,
    "bounds": {"x": 50, "y": 300, "width": 100, "height": 50}
  },
  {
    "id": "Delete-1",
    "text": "Delete",
    "textIndex": 1,
    "bounds": {"x": 50, "y": 400, "width": 100, "height": 50}
  },
  {
    "id": "Delete-2",
    "text": "Delete",
    "textIndex": 2,
    "bounds": {"x": 50, "y": 500, "width": 100, "height": 50}
  }
]
```

**Generated Maestro Commands**:
```yaml
# Tap first Delete button
- tapOn:
    text: "Delete"
    index: 0

# Tap second Delete button
- tapOn:
    text: "Delete"
    index: 1

# Tap third Delete button
- tapOn:
    text: "Delete"
    index: 2
```

#### Example 4: Web Button with Multiple Attributes

**Input TreeNode**:
```kotlin
TreeNode(
    attributes = mapOf(
        "text" to "Submit Form",
        "id" to "submit-btn",
        "aria-label" to "Submit the registration form",
        "bounds" to "[100,600][300,650]",
        "tagName" to "button",
        "className" to "btn btn-primary"
    )
)
```

**Extraction Process**:
```kotlin
// Step 1: Extract attributes
text = "Submit Form"
resourceId = "submit-btn" (from id attribute)
hintText = null
accessibilityText = "Submit the registration form" (from aria-label)

// Step 2: Parse bounds
bounds = "[100,600][300,650]"
→ UIElementBounds(x=100, y=600, width=200, height=50)

// Step 3: Calculate indices
textIndex = null (unique text)
resourceIdIndex = null (unique ID)

// Step 4: Generate ID
id = "submit-btn"
```

**Output UIElement**:
```json
{
  "id": "submit-btn",
  "text": "Submit Form",
  "resourceId": "submit-btn",
  "hintText": null,
  "accessibilityText": "Submit the registration form",
  "bounds": {
    "x": 100,
    "y": 600,
    "width": 200,
    "height": 50
  },
  "textIndex": null,
  "resourceIdIndex": null
}
```

**Generated Maestro Commands**:
```yaml
# Option 1: Use ID (most reliable for web)
- tapOn:
    id: "submit-btn"

# Option 2: Use text
- tapOn:
    text: "Submit Form"

# Option 3: Use ARIA label
- tapOn:
    accessibilityText: "Submit the registration form"
```

### Attribute Priority and Fallbacks

When multiple selector attributes are available, Maestro Studio displays them in priority order:

1. **Resource ID** → Most specific, platform-dependent
2. **Text** → Human-readable, most common
3. **Hint Text** → Useful for input fields
4. **Accessibility Text** → Fallback for non-visual elements

**Example Priority**:
```json
{
  "resourceId": "login_button",      // 🥇 Shown first
  "text": "Login",                   // 🥈 Shown second
  "hintText": null,                  // ⏭️ Skipped (null)
  "accessibilityText": "Login to app" // 🥉 Shown third
}
```

**ElementsPanel Display**:
```
🔵 login_button • id
🔵 Login • text
🔵 Login to app • accessibilityText
```

### Handling Edge Cases

#### Case 1: Element with No Selectable Attributes

```kotlin
TreeNode(
    attributes = mapOf(
        "bounds" to "[0,0][100,100]",
        "clickable" to "true"
    )
)
```

**Result**: Element is **filtered out** in frontend (ElementsPanel) because it has no text, ID, or accessibility info.

**Fallback ID**: Uses bounds → `"0,0,100,100"`

#### Case 2: Element with Special Characters

```kotlin
TreeNode(
    attributes = mapOf(
        "text" to "Price: $19.99",
        "resource-id" to "com.app:id/price_label"
    )
)
```

**Extraction**: Text preserved exactly as-is
```json
{
  "text": "Price: $19.99",
  "resourceId": "com.app:id/price_label"
}
```

**Maestro Command**:
```yaml
- assertVisible: "Price: $19.99"
```

#### Case 3: Element with Only Bounds

```kotlin
TreeNode(
    attributes = mapOf(
        "bounds" to "[50,50][150,150]"
    )
)
```

**Extraction**:
```json
{
  "id": "50,50,150,150",  // Fallback to bounds-based ID
  "text": null,
  "resourceId": null,
  "hintText": null,
  "accessibilityText": null,
  "bounds": {"x": 50, "y": 50, "width": 100, "height": 100}
}
```

**Maestro Command** (point-based):
```yaml
- tapOn:
    point: "25%,15%"  # Approximate center
```

### Extraction Performance

**Metrics** (for typical app with 500 UI elements):

| Operation | Time | Details |
|-----------|------|---------|
| Tree flattening | ~10ms | Recursive traversal |
| Attribute extraction | ~20ms | String operations |
| Bounds parsing | ~15ms | Regex matching |
| Index calculation | ~5ms | Filtering and sorting |
| **Total** | **~50ms** | Per screen capture |

**Optimization**: Index calculation only runs for elements with duplicates, not for every element.

---

## Backend Implementation

### 1. Core Service: DeviceService.kt

Location: `maestro-studio/server/src/main/java/maestro/studio/DeviceService.kt`

#### 1.1 SSE Endpoint - Continuous Updates

The Server-Sent Events endpoint provides real-time streaming of device state:

```kotlin
routing.get("/api/device-screen/sse") {
    call.response.cacheControl(CacheControl.NoCache(null))
    call.respondBytesWriter(contentType = ContentType.Text.EventStream) {
        while (true) {
            try {
                val deviceScreen = getDeviceScreen(maestro)
                writeStringUtf8("data: $deviceScreen\n\n")
                flush()
            } catch (_: Exception) {
                // Ignoring exceptions to prevent SSE stream from dying
            }
        }
    }
}
```

**Key Points:**
- Runs in an infinite loop, continuously streaming updates
- Each iteration captures fresh device state
- Cache-Control headers prevent caching
- Content-Type: `text/event-stream` for SSE protocol
- Errors are swallowed to keep stream alive

#### 1.2 Device Screen Capture

The `getDeviceScreen()` method orchestrates the capture process:

```kotlin
private fun getDeviceScreen(maestro: Maestro): String {
    val tree: TreeNode
    val screenshotFile: File
    synchronized(DeviceService) {
        // Step 1: Capture view hierarchy
        tree = maestro.viewHierarchy().root
        lastViewHierarchy = tree
        
        // Step 2: Take screenshot
        screenshotFile = takeScreenshot(maestro)
        savedScreenshots.add(screenshotFile)
        
        // Step 3: Cleanup old screenshots
        while (savedScreenshots.size > MAX_SCREENSHOTS) {
            savedScreenshots.removeFirst().delete()
        }
    }

    // Step 4: Get device dimensions
    val deviceInfo = maestro.deviceInfo()
    val deviceWidth = deviceInfo.widthGrid
    val deviceHeight = deviceInfo.heightGrid

    // Step 5: Extract UI elements from tree
    val url = tree.attributes["url"]
    val elements = treeToElements(tree)
    
    // Step 6: Create and serialize DeviceScreen
    val deviceScreen = DeviceScreen(
        deviceInfo.platform, 
        "/screenshot/${screenshotFile.name}", 
        deviceWidth, 
        deviceHeight, 
        elements, 
        url
    )
    
    return jacksonObjectMapper()
        .setSerializationInclusion(JsonInclude.Include.NON_NULL)
        .writeValueAsString(deviceScreen)
}
```

**Synchronization:**
- Thread-safe access to shared resources
- Prevents race conditions during concurrent captures

**Screenshot Management:**
- Stores screenshots in `~/.maestro/studio/screenshots/`
- Limits to MAX_SCREENSHOTS (10) to prevent disk bloat
- Each screenshot has a UUID filename

#### 1.3 Tree to Elements Conversion

This is the **core selector extraction logic**:

```kotlin
private fun treeToElements(tree: TreeNode): List<UIElement> {
    // Helper: Recursively flatten tree
    fun gatherElements(tree: TreeNode, list: MutableList<TreeNode>): List<TreeNode> {
        tree.children.forEach { child ->
            gatherElements(child, list)
        }
        list.add(tree)
        return list
    }

    // Helper: Extract attribute safely
    fun TreeNode.attribute(key: String): String? {
        val value = attributes[key]
        if (value.isNullOrEmpty()) return null
        return value
    }

    // Flatten and sort by index
    val elements = gatherElements(tree, mutableListOf())
        .sortedWith(Filters.INDEX_COMPARATOR)

    // Helper: Calculate index for duplicate selectors
    fun getIndex(filter: ElementFilter, element: TreeNode): Int? {
        val identityHashMap = IdentityHashMap<TreeNode, Unit>()
        val matchingElements = Filters.deepestMatchingElement(filter)(elements).filter {
            // Remove duplicates
            identityHashMap.put(it, Unit) == null
        }
        if (matchingElements.size < 2) return null
        return matchingElements.sortedWith(Filters.INDEX_COMPARATOR).indexOf(element)
    }

    val ids = mutableMapOf<String, Int>()
    
    return elements.map { element ->
        // Extract all selector attributes
        val bounds = element.bounds()
        val text = element.attribute("text")
        val hintText = element.attribute("hintText")
        val accessibilityText = element.attribute("accessibilityText")
        val resourceId = element.attribute("resource-id")
        
        // Calculate indices for duplicates
        val textIndex = if (text == null) {
            null
        } else {
            getIndex(Filters.textMatches(text.toRegexSafe(Orchestra.REGEX_OPTIONS)), element)
        }
        
        val resourceIdIndex = if (resourceId == null) {
            null
        } else {
            getIndex(Filters.idMatches(resourceId.toRegexSafe(Orchestra.REGEX_OPTIONS)), element)
        }
        
        // Generate stable unique ID
        fun createElementId(): String {
            val parts = listOfNotNull(resourceId, resourceIdIndex, text, textIndex)
            val fallbackId = bounds?.let { (x, y, w, h) -> "$x,$y,$w,$h" } ?: UUID.randomUUID().toString()
            val id = if (parts.isEmpty()) fallbackId else parts.joinToString("-")
            val index = ids.compute(id) { _, i -> (i ?: 0) + 1}
            return if (index == 1) id else "$id-$index"
        }
        
        val id = createElementId()
        UIElement(id, bounds, resourceId, resourceIdIndex, text, hintText, accessibilityText, textIndex)
    }
}
```

**Extraction Strategy:**

1. **Flatten Tree**: Converts hierarchical tree to flat list
2. **Extract Attributes**: Pulls out text, IDs, hints, accessibility labels
3. **Parse Bounds**: Converts bounds string to coordinates
4. **Calculate Indices**: For duplicate selectors (e.g., multiple "Login" buttons), assigns index
5. **Generate IDs**: Creates stable IDs for React key management

**Index Calculation Logic:**
- If multiple elements match the same selector (e.g., `text: "Submit"`), they get indices
- Example: First "Submit" button → `textIndex: 0`, Second → `textIndex: 1`
- This enables Maestro commands like `tapOn: { text: "Submit", index: 1 }`

#### 1.4 Bounds Parsing

Converts Android/iOS bounds format to structured coordinates:

```kotlin
private fun TreeNode.bounds(): UIElementBounds? {
    val boundsString = attributes["bounds"] ?: return null
    val pattern = Pattern.compile("\\[([0-9-]+),([0-9-]+)]\\[([0-9-]+),([0-9-]+)]")
    val m = pattern.matcher(boundsString)
    if (!m.matches()) {
        System.err.println("Warning: Bounds text does not match expected pattern: $boundsString")
        return null
    }

    val l = m.group(1).toIntOrNull() ?: return null
    val t = m.group(2).toIntOrNull() ?: return null
    val r = m.group(3).toIntOrNull() ?: return null
    val b = m.group(4).toIntOrNull() ?: return null

    return UIElementBounds(
        x = l,
        y = t,
        width = r - l,
        height = b - t,
    )
}
```

**Input Format**: `[left,top][right,bottom]`  
**Example**: `[100,200][300,400]` → `x:100, y:200, width:200, height:200`

### 2. Data Models

Location: `maestro-studio/server/src/main/java/maestro/studio/Models.kt`

#### 2.1 DeviceScreen

The top-level model sent to the frontend:

```kotlin
data class DeviceScreen(
    val platform: Platform,        // iOS, Android, or Web
    val screenshot: String,         // URL path to screenshot
    val width: Int,                 // Device width in pixels
    val height: Int,                // Device height in pixels
    val elements: List<UIElement>,  // All selectable UI elements
    val url: String?,               // Current URL (for web apps)
)
```

#### 2.2 UIElement

Represents a single selectable UI element:

```kotlin
data class UIElement(
    val id: String,                 // Auto-generated stable ID for frontend
    val bounds: UIElementBounds?,   // Element position and size
    val resourceId: String?,        // Android resource ID (e.g., "com.app:id/button")
    val resourceIdIndex: Int?,      // Index if multiple elements share same ID
    val text: String?,              // Visible text content
    val hintText: String?,          // Hint/placeholder text
    val accessibilityText: String?, // Accessibility label
    val textIndex: Int?             // Index if multiple elements share same text
)
```

#### 2.3 UIElementBounds

Bounding box coordinates:

```kotlin
data class UIElementBounds(
    val x: Int,      // Left edge
    val y: Int,      // Top edge
    val width: Int,  // Width in pixels
    val height: Int, // Height in pixels
)
```

### 3. Additional Endpoints

#### 3.1 Last View Hierarchy

Provides the raw tree structure (useful for debugging):

```kotlin
routing.get("/api/last-view-hierarchy") {
    if (lastViewHierarchy == null) {
        call.respond(HttpStatusCode.NotFound, "No view hierarchy available")
    } else {
        val response = jacksonObjectMapper().writeValueAsString(lastViewHierarchy)
        call.respond(response)
    }
}
```

#### 3.2 Screenshot Static Files

Serves screenshot images:

```kotlin
routing.static("/screenshot") {
    staticRootFolder = SCREENSHOT_DIR.toFile()
    files(".")
}
```

---

## Frontend Implementation

### 1. API Layer

Location: `maestro-studio/web/src/api/api.ts`

#### 1.1 SSE Subscription Hook

Custom hook for Server-Sent Events:

```typescript
const useSse = <T>(url: string): SWRSubscriptionResponse<T> => {
  return useSWRSubscription<T, any, string>(url, (key, { next }) => {
    const eventSource = new EventSource(key);
    
    eventSource.onmessage = (e) => {
      const repl: T = JSON.parse(e.data);
      next(null, repl);
    };
    
    eventSource.onerror = (error) => {
      next(error);
    };
    
    return () => eventSource.close();
  });
};
```

**Key Features:**
- Automatically reconnects on disconnection
- Integrates with SWR for caching and revalidation
- Cleanup function closes EventSource on unmount

#### 1.2 Device Screen Hook

Exposes device screen data to components:

```typescript
const useDeviceScreen = (): { deviceScreen?: DeviceScreen; error?: any } => {
  const { data: deviceScreen, error } = useSse<DeviceScreen>(
    "/api/device-screen/sse"
  );
  return { deviceScreen, error };
};
```

### 2. State Management

Location: `maestro-studio/web/src/context/DeviceContext.tsx`

#### 2.1 DeviceContext Provider

Centralized state management for device screen and selections:

```typescript
export const DeviceProvider: React.FC<DeviceProviderProps> = ({
  children,
  defaultInspectedElement = null,
}) => {
  const { deviceScreen: fetchedDeviceScreen, error } = API.useDeviceScreen();

  const prevDeviceScreenRef = useRef<DeviceScreen | undefined>();
  const [deviceScreenState, setDeviceScreenState] = 
    useState<DeviceScreen | undefined>();
  const [isLoading, setIsLoading] = useState(true);
  const [hoveredElement, setHoveredElement] = useState<UIElement | null>(null);
  const [inspectedElement, setInspectedElement] = useState<UIElement | null>(
    defaultInspectedElement
  );
  const [footerHint, setFooterHint] = useState<string | null>(null);
  const [currentCommandValue, setCurrentCommandValue] = useState<string>("");

  // Optimization: Only update state when data actually changes
  useEffect(() => {
    if (fetchedDeviceScreen) {
      const { screenshot: screenshotFetched, ...restOfFetchedData } =
        fetchedDeviceScreen;
      let restOfPrevData = {};
      if (prevDeviceScreenRef.current) {
        const { screenshot: __, ...restData } = prevDeviceScreenRef.current;
        restOfPrevData = restData;
      }
      // Deep equality check (excluding screenshot)
      if (!_.isEqual(restOfPrevData, restOfFetchedData)) {
        setDeviceScreenState(fetchedDeviceScreen);
        prevDeviceScreenRef.current = fetchedDeviceScreen;
      }
    }
  }, [fetchedDeviceScreen]);

  // Loading state management
  useEffect(() => {
    if (isLoading) {
      if (deviceScreenState || error) {
        setIsLoading(false);
      }
    }
  }, [deviceScreenState, error, isLoading]);

  return (
    <DeviceContext.Provider
      value={{
        isLoading,
        hoveredElement,
        setHoveredElement,
        inspectedElement,
        setInspectedElement,
        footerHint,
        setFooterHint,
        deviceScreen: deviceScreenState,
        currentCommandValue,
        setCurrentCommandValue,
      }}
    >
      {children}
    </DeviceContext.Provider>
  );
};
```

**State Properties:**

| Property | Type | Purpose |
|----------|------|---------|
| `deviceScreen` | `DeviceScreen \| undefined` | Current device state with screenshot and elements |
| `hoveredElement` | `UIElement \| null` | Element currently under mouse cursor |
| `inspectedElement` | `UIElement \| null` | Element selected for detailed inspection |
| `footerHint` | `string \| null` | Text displayed in footer (selector info) |
| `isLoading` | `boolean` | Loading state indicator |

**Performance Optimization:**
- Deep equality check excludes `screenshot` (frequently changing base64 string)
- Only triggers re-renders when element data changes
- Prevents unnecessary re-renders from screenshot updates

### 3. Visual Components

#### 3.1 AnnotatedScreenshot Component

Location: `maestro-studio/web/src/components/device-and-device-elements/AnnotatedScreenshot.tsx`

**Purpose**: Renders device screenshot with interactive selector overlays.

##### Mouse Tracking

```typescript
const ref = useRef(null);
const mouse = useMouse(ref, { enterDelay: 100, leaveDelay: 100 });

useEffect(() => {
  if (mouse.isOver) {
    setHasMouseLeft(false);
    if (annotationsEnabled) {
      const hoveredElement = getHoveredElement(deviceScreen, mouse);
      onHover(hoveredElement, mouse);
    } else {
      onHover(null, mouse);
    }
  } else if (!hasMouseLeft) {
    setHasMouseLeft(true);
    onHover(null, null);
  }
}, [deviceScreen, mouse, annotationsEnabled, hasMouseLeft, onHover]);
```

##### Hover Detection Algorithm

```typescript
const getHoveredElement = (
  deviceScreen: DeviceScreen | undefined,
  mouse: MousePosition
): UIElement | null => {
  if (!deviceScreen) return null;
  
  const hoveredList = deviceScreen.elements.filter((element) => {
    if (!element.bounds) return false;
    
    const {
      x: boundsX,
      y: boundsY,
      width: boundsWidth,
      height: boundsHeight,
    } = element.bounds;
    
    const { x: mouseX, y: mouseY, elementWidth, elementHeight } = mouse;
    
    if (mouseX === null || mouseY === null || 
        elementWidth === null || elementHeight === null)
      return false;
    
    // Check if mouse is within bounds (normalized to 0-1)
    return pointInBounds(
      boundsX / deviceScreen.width,
      boundsY / deviceScreen.height,
      boundsWidth / deviceScreen.width,
      boundsHeight / deviceScreen.height,
      mouseX / elementWidth,
      mouseY / elementHeight
    );
  });
  
  if (hoveredList.length === 0) return null;
  
  // Return SMALLEST element (most specific)
  return hoveredList.sort((a, b) => {
    if (!a.bounds && !b.bounds) return 0;
    if (!a.bounds) return 1;
    if (!b.bounds) return -1;
    return a.bounds.width * a.bounds.height - b.bounds.width * b.bounds.height;
  })[0];
};
```

**Algorithm:**
1. Filter elements whose bounds contain mouse position
2. Sort by area (smallest first)
3. Return smallest element for precision

##### Annotation Rendering

```typescript
const Annotation = ({
  element,
  deviceWidth,
  deviceHeight,
  state,
  onClick,
}: {
  element: UIElement;
  deviceWidth: number;
  deviceHeight: number;
  state: AnnotationState;
  onClick: () => void;
}) => {
  if (!element.bounds || state === "hidden") return null;
  
  const { x, y, width, height } = element.bounds;
  
  // Convert pixel coordinates to percentages
  const l = `${(x / deviceWidth) * 100}%`;
  const t = `${(y / deviceHeight) * 100}%`;
  const w = `${(width / deviceWidth) * 100}%`;
  const h = `${(height / deviceHeight) * 100}%`;

  let className = "border border-dashed border-pink-400/60";
  let style: CSSProperties = {};

  if (state === "hovered") {
    className = "border-4 border-blue-500 active:bg-blue-400/40 z-10";
    style = {
      boxShadow: "0 0 0 9999px rgba(244, 114, 182, 0.4)",
    };
  } else if (state === "selected") {
    className = "border-4 border-blue-500 z-10";
    style = {
      boxShadow: "0 0 0 9999px rgba(96, 165, 250, 0.4)",
    };
  }

  return (
    <div
      className={`absolute ${className}`}
      style={{
        left: l,
        top: t,
        width: w,
        height: h,
        ...style,
      }}
      onClick={onClick}
    />
  );
};
```

**Visual States:**

| State | Appearance | When |
|-------|------------|------|
| `default` | Dashed pink border (subtle) | Element exists but not interacting |
| `hovered` | Solid blue border + pink overlay | Mouse over element |
| `selected` | Solid blue border + blue overlay | Element clicked for inspection |
| `hidden` | Not rendered | Another element is selected |

##### Crosshairs

Displays center point of focused element:

```typescript
const Crosshairs = ({ cx, cy, color }: {
  cx: number;
  cy: number;
  color: string;
}) => {
  return (
    <>
      {/* Vertical line */}
      <div
        className={`absolute z-20 w-[1px] h-full ${color} -translate-x-1/2 pointer-events-none`}
        style={{
          top: 0,
          bottom: 0,
          left: `${cx * 100}%`,
        }}
      />
      {/* Horizontal line */}
      <div
        className={`absolute z-20 h-[1px] w-full ${color} -translate-y-1/2 pointer-events-none`}
        style={{
          left: 0,
          right: 0,
          top: `${cy * 100}%`,
        }}
      />
    </>
  );
};
```

#### 3.2 ElementsPanel Component

Location: `maestro-studio/web/src/components/device-and-device-elements/ElementsPanel.tsx`

**Purpose**: Searchable sidebar listing all selectable elements.

##### Filtering and Sorting

```typescript
const sortedElements: UIElement[] = useMemo(() => {
  if (!deviceScreen) return [];
  
  const filteredElements = deviceScreen.elements.filter((element) => {
    // Skip elements with no selectable attributes
    if (
      !element.text &&
      !element.resourceId &&
      !element.hintText &&
      !element.accessibilityText
    )
      return false;

    // Apply search query
    return (
      !query ||
      element.text?.toLowerCase().includes(query.toLowerCase()) ||
      element.resourceId?.toLowerCase().includes(query.toLowerCase()) ||
      element.hintText?.toLowerCase().includes(query.toLowerCase()) ||
      element.accessibilityText?.toLowerCase().includes(query.toLowerCase())
    );
  });

  // Sort: prefix matches first, then alphabetically
  return filteredElements.sort((a, b) => {
    const aTextPrefixMatch =
      query && a.text?.toLowerCase().startsWith(query.toLowerCase());
    const bTextPrefixMatch =
      query && b.text?.toLowerCase().startsWith(query.toLowerCase());

    if (aTextPrefixMatch && !bTextPrefixMatch) return -1;
    if (bTextPrefixMatch && !aTextPrefixMatch) return 1;

    return compare(a.text, b.text) || compare(a.resourceId, b.resourceId);
  });
}, [query, deviceScreen]);
```

##### Keyboard Navigation

```typescript
const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
  const currentIndex = hoveredElement
    ? sortedElements.findIndex((el) => el.id === hoveredElement.id)
    : -1;

  let newIndex = -1;
  switch (event.key) {
    case "ArrowDown":
      event.preventDefault();
      newIndex =
        currentIndex + 1 >= sortedElements.length ? 0 : currentIndex + 1;
      setHoveredElement(sortedElements[newIndex]);
      break;
    case "ArrowUp":
      event.preventDefault();
      newIndex =
        currentIndex <= 0 ? sortedElements.length - 1 : currentIndex - 1;
      setHoveredElement(sortedElements[newIndex]);
      break;
    case "Enter":
      event.preventDefault();
      if (hoveredElement) {
        setInspectedElement(hoveredElement);
      }
      return;
    default:
      break;
  }
  
  // Auto-scroll to element
  elementRefs.current[newIndex]?.scrollIntoView({
    behavior: "smooth",
    block: "nearest",
  });
};
```

**Keyboard Shortcuts:**
- `↓` - Next element
- `↑` - Previous element
- `Enter` - Select for inspection
- Type to search

##### Element List Item Rendering

```typescript
{sortedElements.map((item: UIElement, index: number) => {
  const onClick = () => setInspectedElement(item);
  const onMouseEnter = () => {
    setHoveredElement(item);
    setFooterHint(item?.resourceId || item?.text || null);
  };
  const onMouseLeave = () => {
    setFooterHint(null);
    if (hoveredElement?.id === item.id) {
      setHoveredElement(null);
    }
  };
  
  return (
    <div key={item.id} ref={(ref) => (elementRefs.current[index] = ref)}>
      {/* Resource ID */}
      {item.resourceId && (
        <ElementListItem
          onClick={onClick}
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
          isHovered={hoveredElement?.id === item?.id}
          query={query}
          text={item.resourceId}
          elementType="id"
        />
      )}
      {/* Text */}
      {item.text && (
        <ElementListItem
          onClick={onClick}
          isHovered={hoveredElement?.id === item?.id}
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
          query={query}
          text={item.text}
          elementType="text"
        />
      )}
      {/* Hint Text */}
      {item.hintText && (
        <ElementListItem
          onClick={onClick}
          isHovered={hoveredElement?.id === item?.id}
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
          query={query}
          text={item.hintText}
          elementType="hintText"
        />
      )}
      {/* Accessibility Text */}
      {item.accessibilityText && (
        <ElementListItem
          onClick={onClick}
          isHovered={hoveredElement?.id === item?.id}
          onMouseEnter={onMouseEnter}
          onMouseLeave={onMouseLeave}
          query={query}
          text={item.accessibilityText}
          elementType="accessibilityText"
        />
      )}
    </div>
  );
})}
```

**Display Strategy:**
- Each element can have multiple list items (one per selector type)
- Highlights matching query text in purple
- Shows selector type badge (e.g., "• id", "• text")

---

## Data Flow

### Complete Request/Response Cycle

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. DEVICE CAPTURE (Backend - Continuous Loop)                  │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
                   maestro.viewHierarchy()
                             │
                             ├─────► TreeNode (hierarchical UI tree)
                             │
                   maestro.takeScreenshot()
                             │
                             ├─────► PNG file
                             │
                   maestro.deviceInfo()
                             │
                             └─────► Platform, width, height

┌─────────────────────────────────────────────────────────────────┐
│ 2. TREE PROCESSING (treeToElements)                            │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
              Flatten tree → List<TreeNode>
                             │
                             ▼
              Extract attributes for each node:
                - text
                - resourceId
                - hintText
                - accessibilityText
                - bounds
                             │
                             ▼
              Calculate indices for duplicates
                             │
                             ▼
              Generate stable unique IDs
                             │
                             ▼
                   List<UIElement>

┌─────────────────────────────────────────────────────────────────┐
│ 3. SERIALIZATION                                               │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
              DeviceScreen {
                platform: "iOS",
                screenshot: "/screenshot/abc-123.png",
                width: 390,
                height: 844,
                elements: [UIElement, UIElement, ...],
                url: null
              }
                             │
                             ▼
              Jackson JSON serialization
                             │
                             ▼
              JSON string

┌─────────────────────────────────────────────────────────────────┐
│ 4. SSE STREAM TRANSMISSION                                      │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
              writeStringUtf8("data: $deviceScreen\n\n")
                             │
                             ▼
              HTTP Stream (text/event-stream)

┌─────────────────────────────────────────────────────────────────┐
│ 5. FRONTEND RECEPTION (EventSource)                            │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
              eventSource.onmessage(e)
                             │
                             ▼
              JSON.parse(e.data)
                             │
                             ▼
              DeviceScreen object

┌─────────────────────────────────────────────────────────────────┐
│ 6. STATE UPDATE (DeviceContext)                                │
└─────────────────────────────────────────────────────────────────┘
                             │
                             ▼
              Deep equality check (excluding screenshot)
                             │
              ┌──────────────┴──────────────┐
              │                             │
         Changed?                      Not changed?
              │                             │
              ▼                             ▼
    setDeviceScreenState(new)       Skip update (optimization)
              │
              ▼
    Trigger re-render

┌─────────────────────────────────────────────────────────────────┐
│ 7. COMPONENT RENDERING                                          │
└─────────────────────────────────────────────────────────────────┘
              │
              ├─────► AnnotatedScreenshot
              │         │
              │         ├─ Render <img src={screenshot} />
              │         ├─ Map over elements
              │         └─ Render <Annotation /> for each
              │
              └─────► ElementsPanel
                        │
                        ├─ Filter elements by query
                        ├─ Sort elements
                        └─ Render ElementListItem for each

┌─────────────────────────────────────────────────────────────────┐
│ 8. USER INTERACTION                                             │
└─────────────────────────────────────────────────────────────────┘
              │
              ├─────► Mouse hover on screenshot
              │         │
              │         ├─ Calculate mouse position
              │         ├─- Call getHoveredElement()
              │         ├─ setHoveredElement(element)
              │         └─ Update annotation styling
              │
              ├─────► Click on element
              │         │
              │         ├─ setInspectedElement(element)
              │         └─ Show element details panel
              │
              └─────► Type in search box
                        │
                        ├─ setQuery(text)
                        ├─ Re-filter sortedElements
                        └─ Update ElementsPanel list
```

### Timing Diagram

```
Time →

Backend:  [Capture] ──→ [Process] ──→ [Serialize] ──→ [Stream] ─┐
            100ms         50ms          10ms          5ms        │
                                                                  │
                                                                  │ SSE
                                                                  │
Frontend: ─────────────────────────────────────────────────────┘
                                                                  │
                                                                  ▼
          [Receive] ──→ [Parse] ──→ [Diff] ──→ [Update] ──→ [Render]
             1ms         5ms        10ms       1ms          16ms
                                                                  │
                                                                  ▼
User:     ────────────────────────────────────────────────── [Sees update]
```

**Total Latency**: ~200ms from device state change to user seeing it

---

## API Contracts

### 1. SSE Stream Response

**Endpoint**: `GET /api/device-screen/sse`

**Content-Type**: `text/event-stream`

**Response Format**:
```
data: {"platform":"iOS","screenshot":"/screenshot/123e4567.png","width":390,"height":844,"elements":[...],"url":null}

data: {"platform":"iOS","screenshot":"/screenshot/123e4568.png","width":390,"height":844,"elements":[...],"url":null}

...
```

**Example DeviceScreen JSON**:
```json
{
  "platform": "iOS",
  "screenshot": "/screenshot/f47ac10b-58cc-4372-a567-0e02b2c3d479.png",
  "width": 390,
  "height": 844,
  "elements": [
    {
      "id": "com.app:id/login_button",
      "bounds": {
        "x": 50,
        "y": 400,
        "width": 290,
        "height": 44
      },
      "resourceId": "com.app:id/login_button",
      "resourceIdIndex": null,
      "text": "Login",
      "hintText": null,
      "accessibilityText": "Login button",
      "textIndex": null
    },
    {
      "id": "Submit-0",
      "bounds": {
        "x": 50,
        "y": 500,
        "width": 290,
        "height": 44
      },
      "resourceId": null,
      "resourceIdIndex": null,
      "text": "Submit",
      "hintText": null,
      "accessibilityText": null,
      "textIndex": 0
    },
    {
      "id": "Submit-1",
      "bounds": {
        "x": 50,
        "y": 600,
        "width": 290,
        "height": 44
      },
      "resourceId": null,
      "resourceIdIndex": null,
      "text": "Submit",
      "hintText": null,
      "accessibilityText": null,
      "textIndex": 1
    }
  ],
  "url": null
}
```

### 2. Last View Hierarchy

**Endpoint**: `GET /api/last-view-hierarchy`

**Response**: Raw TreeNode structure (for debugging)

```json
{
  "attributes": {
    "text": "Login",
    "resource-id": "com.app:id/login_button",
    "bounds": "[50,400][340,444]",
    "enabled": "true",
    "clickable": "true"
  },
  "children": [
    {
      "attributes": {
        "text": "Click here",
        "bounds": "[60,410][330,434]"
      },
      "children": []
    }
  ]
}
```

### 3. Screenshot Files

**Endpoint**: `GET /screenshot/{uuid}.png`

**Response**: PNG image file

---

## Interaction Modes

### Mode 1: Annotation Mode (Default)

**Trigger**: Default state, or when Meta key is NOT pressed

**Behavior**:
- Shows bounding boxes around all elements
- Mouse hover highlights element under cursor
- Click selects element for inspection
- Displays crosshairs at element center

**Use Case**: Exploring and selecting UI elements

### Mode 2: Gesture Mode

**Trigger**: Hold Meta/Cmd key

**Behavior**:
- Hides all annotations
- Mouse interactions generate Maestro commands
- Tap gesture → `tapOn` command
- Swipe gesture → `swipe` command
- Shows crosshairs at cursor position

**Use Case**: Recording user interactions

**Implementation** (`InteractableDevice.tsx`):

```typescript
const metaKeyDown = useMetaKeyDown();

return (
  <GestureDiv
    onTap={onTapGesture}
    onSwipe={onSwipeGesture}
    gesturesEnabled={enableGestureControl ? metaKeyDown : false}
  >
    <AnnotatedScreenshot
      annotationsEnabled={enableGestureControl ? !metaKeyDown : true}
    />
  </GestureDiv>
);
```

**Gesture Detection**:

```typescript
const onEnd: MouseEventHandler<HTMLDivElement> = (e) => {
  if (!gesturesEnabled || !start) return;
  const end = createGestureEvent(e);

  const { width: clientWidth, height: clientHeight } =
    e.currentTarget.getBoundingClientRect();

  const duration = end.timestamp - start.timestamp;
  const distance = Math.hypot(end.x - start.x, end.y - start.y);

  if (duration < 100 || distance < 10) {
    // TAP
    onTap(start.x / clientWidth, start.y / clientHeight);
  } else {
    // SWIPE
    onSwipe(
      start.x / clientWidth,
      start.y / clientHeight,
      end.x / clientWidth,
      end.y / clientHeight,
      duration
    );
  }
};
```

**Generated Commands**:

Tap at 50%, 30%:
```yaml
- tapOn:
    point: "50%,30%"
```

Swipe from (20%, 80%) to (20%, 20%) in 500ms:
```yaml
swipe:
  start: "20%,80%"
  end: "20%,20%"
  duration: 500
```

---

## Performance Optimizations

### 1. Screenshot Diffing

**Problem**: Screenshot base64 strings are large and change frequently, causing unnecessary re-renders.

**Solution**: Exclude screenshot from deep equality check in DeviceContext.

```typescript
const { screenshot: screenshotFetched, ...restOfFetchedData } =
  fetchedDeviceScreen;
let restOfPrevData = {};
if (prevDeviceScreenRef.current) {
  const { screenshot: __, ...restData } = prevDeviceScreenRef.current;
  restOfPrevData = restData;
}
if (!_.isEqual(restOfPrevData, restOfFetchedData)) {
  setDeviceScreenState(fetchedDeviceScreen);
  prevDeviceScreenRef.current = fetchedDeviceScreen;
}
```

**Impact**: Reduces re-renders by ~80% during stable UI states.

### 2. Element Memoization

**Problem**: Filtering and sorting elements is expensive with large element lists.

**Solution**: Use `useMemo` to cache sorted elements.

```typescript
const sortedElements: UIElement[] = useMemo(() => {
  // Expensive filtering and sorting
  ...
}, [query, deviceScreen]);
```

**Impact**: Prevents recalculation on every render.

### 3. Screenshot Cleanup

**Problem**: Continuous screenshot capture fills disk.

**Solution**: Keep only last 10 screenshots.

```kotlin
savedScreenshots.add(screenshotFile)
while (savedScreenshots.size > MAX_SCREENSHOTS) {
    savedScreenshots.removeFirst().delete()
}
```

### 4. SSE Error Handling

**Problem**: Exceptions in SSE loop kill the stream.

**Solution**: Catch and suppress errors to keep stream alive.

```kotlin
while (true) {
    try {
        val deviceScreen = getDeviceScreen(maestro)
        writeStringUtf8("data: $deviceScreen\n\n")
        flush()
    } catch (_: Exception) {
        // Swallow errors to keep stream alive
    }
}
```

### 5. Stable Element IDs

**Problem**: React re-renders all elements if keys change.

**Solution**: Generate stable IDs based on selector attributes.

```kotlin
fun createElementId(): String {
    val parts = listOfNotNull(resourceId, resourceIdIndex, text, textIndex)
    val fallbackId = bounds?.let { (x, y, w, h) -> "$x,$y,$w,$h" } 
        ?: UUID.randomUUID().toString()
    val id = if (parts.isEmpty()) fallbackId else parts.joinToString("-")
    val index = ids.compute(id) { _, i -> (i ?: 0) + 1}
    return if (index == 1) id else "$id-$index"
}
```

**Impact**: React efficiently diffs elements across updates.

---

## Code Examples

### Example 1: Using DeviceContext in a Component

```typescript
import { useDeviceContext } from '../../context/DeviceContext';

function MyComponent() {
  const {
    deviceScreen,
    hoveredElement,
    inspectedElement,
    setInspectedElement,
  } = useDeviceContext();

  if (!deviceScreen) {
    return <div>Loading device...</div>;
  }

  return (
    <div>
      <h1>Device: {deviceScreen.platform}</h1>
      <p>Dimensions: {deviceScreen.width}x{deviceScreen.height}</p>
      <p>Elements: {deviceScreen.elements.length}</p>
      
      {inspectedElement && (
        <div>
          <h2>Selected Element</h2>
          <pre>{JSON.stringify(inspectedElement, null, 2)}</pre>
          <button onClick={() => setInspectedElement(null)}>
            Clear Selection
          </button>
        </div>
      )}
    </div>
  );
}
```

### Example 2: Filtering Elements by Text

```typescript
function SearchableElements() {
  const { deviceScreen } = useDeviceContext();
  const [query, setQuery] = useState('');

  const matchingElements = deviceScreen?.elements.filter(el =>
    el.text?.toLowerCase().includes(query.toLowerCase())
  ) || [];

  return (
    <div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search elements..."
      />
      <ul>
        {matchingElements.map(el => (
          <li key={el.id}>
            {el.text} ({el.bounds?.width}x{el.bounds?.height})
          </li>
        ))}
      </ul>
    </div>
  );
}
```

### Example 3: Adding a New Endpoint (Backend)

```kotlin
// In DeviceService.kt
routing.get("/api/element/{id}") {
    val elementId = call.parameters["id"]
    val deviceScreen = getDeviceScreen(maestro)
    val element = deviceScreen.elements.find { it.id == elementId }
    
    if (element != null) {
        val response = jacksonObjectMapper().writeValueAsString(element)
        call.respond(response)
    } else {
        call.respond(HttpStatusCode.NotFound, "Element not found")
    }
}
```

### Example 4: Custom Element Filter

```typescript
function FilterByBounds() {
  const { deviceScreen } = useDeviceContext();

  // Find elements in top half of screen
  const topElements = deviceScreen?.elements.filter(el => {
    if (!el.bounds || !deviceScreen) return false;
    const centerY = el.bounds.y + el.bounds.height / 2;
    return centerY < deviceScreen.height / 2;
  }) || [];

  return (
    <div>
      <h2>Elements in Top Half</h2>
      <p>Found: {topElements.length}</p>
    </div>
  );
}
```

---

## Appendix

### A. Selector Type Priority

When multiple selector types are available for an element, Maestro Studio displays them in this order:

1. **Resource ID** (most specific, platform-dependent)
2. **Text** (human-readable, most common)
3. **Hint Text** (useful for input fields)
4. **Accessibility Text** (fallback for non-visual elements)

### B. Accessing Extracted Selector Data in Code

#### Backend (Kotlin)

**Access attribute from TreeNode**:
```kotlin
val element: TreeNode = ...
val text = element.attributes["text"]
val resourceId = element.attributes["resource-id"]
val bounds = element.attributes["bounds"]
```

**Access from UIElement**:
```kotlin
val uiElement: UIElement = ...
println("Text: ${uiElement.text}")
println("ID: ${uiElement.resourceId}")
println("Position: (${uiElement.bounds?.x}, ${uiElement.bounds?.y})")
println("Size: ${uiElement.bounds?.width}x${uiElement.bounds?.height}")
```

#### Frontend (TypeScript/React)

**Access from DeviceContext**:
```typescript
import { useDeviceContext } from '../../context/DeviceContext';

function MyComponent() {
  const { deviceScreen } = useDeviceContext();
  
  // Access all elements
  const allElements = deviceScreen?.elements || [];
  
  // Find element by text
  const loginButton = allElements.find(el => el.text === "Login");
  
  // Find elements by resource ID
  const submitButtons = allElements.filter(el => 
    el.resourceId?.includes("submit")
  );
  
  // Find elements in specific region
  const topElements = allElements.filter(el => 
    el.bounds && el.bounds.y < 200
  );
  
  return (
    <div>
      {loginButton && (
        <div>
          <h3>Login Button Found</h3>
          <p>Text: {loginButton.text}</p>
          <p>ID: {loginButton.resourceId}</p>
          <p>Position: ({loginButton.bounds?.x}, {loginButton.bounds?.y})</p>
          <p>Size: {loginButton.bounds?.width}x{loginButton.bounds?.height}</p>
          {loginButton.textIndex !== null && (
            <p>Index: {loginButton.textIndex}</p>
          )}
        </div>
      )}
    </div>
  );
}
```

**Filter by selector type**:
```typescript
// Get all elements with text
const elementsWithText = deviceScreen?.elements.filter(el => el.text) || [];

// Get all elements with resource ID
const elementsWithId = deviceScreen?.elements.filter(el => el.resourceId) || [];

// Get all elements with accessibility text
const accessibleElements = deviceScreen?.elements.filter(el => 
  el.accessibilityText
) || [];

// Get duplicate selectors (have indices)
const duplicateTextElements = deviceScreen?.elements.filter(el => 
  el.textIndex !== null
) || [];
```

**Search elements**:
```typescript
function searchElements(query: string, elements: UIElement[]): UIElement[] {
  const lowerQuery = query.toLowerCase();
  
  return elements.filter(el =>
    el.text?.toLowerCase().includes(lowerQuery) ||
    el.resourceId?.toLowerCase().includes(lowerQuery) ||
    el.hintText?.toLowerCase().includes(lowerQuery) ||
    el.accessibilityText?.toLowerCase().includes(lowerQuery)
  );
}

// Usage
const results = searchElements("submit", deviceScreen?.elements || []);
```

**Generate Maestro command from UIElement**:
```typescript
function generateTapCommand(element: UIElement): string {
  // Prefer resource ID
  if (element.resourceId) {
    const index = element.resourceIdIndex !== null 
      ? `\n  index: ${element.resourceIdIndex}` 
      : '';
    return `- tapOn:\n    id: "${element.resourceId}"${index}`;
  }
  
  // Fallback to text
  if (element.text) {
    const index = element.textIndex !== null 
      ? `\n  index: ${element.textIndex}` 
      : '';
    return `- tapOn:\n    text: "${element.text}"${index}`;
  }
  
  // Fallback to accessibility
  if (element.accessibilityText) {
    return `- tapOn:\n    accessibilityText: "${element.accessibilityText}"`;
  }
  
  // Fallback to point
  if (element.bounds && deviceScreen) {
    const centerX = Math.round((element.bounds.x + element.bounds.width / 2) / deviceScreen.width * 100);
    const centerY = Math.round((element.bounds.y + element.bounds.height / 2) / deviceScreen.height * 100);
    return `- tapOn:\n    point: "${centerX}%,${centerY}%"`;
  }
  
  return '# Unable to generate command';
}

// Usage
const command = generateTapCommand(loginButton);
console.log(command);
// Output:
// - tapOn:
//     id: "login_button"
```

### C. Platform Differences

| Feature | iOS | Android | Web |
|---------|-----|---------|-----|
| Resource ID | ✅ `accessibility id` | ✅ Full resource ID | ⚠️ Limited (element ID) |
| Bounds | ✅ | ✅ | ✅ |
| Text | ✅ | ✅ | ✅ |
| Hint Text | ✅ `placeholder` | ✅ | ✅ |
| Accessibility Text | ✅ `label` | ✅ `content-desc` | ✅ `aria-label` |
| URL | ❌ | ❌ | ✅ |

**Platform-Specific Attribute Mapping**:

```kotlin
// Android
attributes["text"] → UIElement.text
attributes["resource-id"] → UIElement.resourceId
attributes["content-desc"] → UIElement.accessibilityText
attributes["hint"] → UIElement.hintText

// iOS
attributes["text"] → UIElement.text
attributes["accessibilityIdentifier"] → UIElement.resourceId
attributes["accessibilityLabel"] → UIElement.accessibilityText
attributes["placeholderValue"] → UIElement.hintText

// Web
attributes["text"] → UIElement.text
attributes["id"] → UIElement.resourceId
attributes["aria-label"] → UIElement.accessibilityText
attributes["placeholder"] → UIElement.hintText
```

### C. Troubleshooting

**Problem**: Elements not appearing in panel

**Solution**:
- Check if element has any selector attributes (text, ID, etc.)
- Elements without selectable attributes are filtered out
- Try searching for partial text

**Problem**: Screenshot not updating

**Solution**:
- Check SSE connection in browser DevTools (Network tab)
- Verify Maestro driver connection to device
- Restart Maestro Studio

**Problem**: Hover not working

**Solution**:
- Ensure annotations are enabled (Meta key not pressed)
- Check that element has bounds
- Verify mouse position is within bounds

### D. Quick Reference: Selector Extraction Cheat Sheet

#### Extract Text

```kotlin
// Backend
val text = element.attribute("text")

// Frontend
const text = element.text;
```

**Platforms**:
- Android: TextView, Button text
- iOS: Label, value
- Web: innerText, textContent

**Example Values**: `"Login"`, `"Submit Form"`, `"Welcome back!"`

#### Extract Resource ID

```kotlin
// Backend
val resourceId = element.attribute("resource-id")

// Frontend
const resourceId = element.resourceId;
```

**Platforms**:
- Android: Full resource ID (e.g., `"com.app:id/button"`)
- iOS: Accessibility identifier
- Web: Element ID attribute

**Example Values**: 
- Android: `"com.example.app:id/login_button"`
- iOS: `"loginButton"`
- Web: `"submit-btn"`

#### Extract Hint Text

```kotlin
// Backend
val hintText = element.attribute("hintText")

// Frontend
const hintText = element.hintText;
```

**Platforms**:
- Android: EditText hint
- iOS: Placeholder value
- Web: Input placeholder

**Example Values**: `"Enter your email"`, `"Password"`, `"Search..."`

#### Extract Accessibility Text

```kotlin
// Backend
val accessibilityText = element.attribute("accessibilityText")

// Frontend
const accessibilityText = element.accessibilityText;
```

**Platforms**:
- Android: Content description
- iOS: Accessibility label
- Web: ARIA label

**Example Values**: `"Login button"`, `"Submit form button"`, `"Close dialog"`

#### Extract Bounds

```kotlin
// Backend
val bounds = element.bounds()  // Returns UIElementBounds?

// Frontend
const bounds = element.bounds;
const x = bounds?.x;
const y = bounds?.y;
const width = bounds?.width;
const height = bounds?.height;
```

**Properties**:
- `x`: Left edge (pixels)
- `y`: Top edge (pixels)
- `width`: Width (pixels)
- `height`: Height (pixels)

**Example**: `{x: 50, y: 400, width: 290, height: 44}`

#### Extract Index

```kotlin
// Backend (calculated automatically)
val textIndex = getIndex(Filters.textMatches(text), element)
val resourceIdIndex = getIndex(Filters.idMatches(resourceId), element)

// Frontend
const textIndex = element.textIndex;
const resourceIdIndex = element.resourceIdIndex;
```

**Usage**: When multiple elements share the same selector

**Example**: Three "Delete" buttons → indices 0, 1, 2

### E. Common Extraction Patterns

#### Pattern 1: Extract All Buttons

```kotlin
// Backend
val buttons = elements.filter { 
    it.attribute("clickable") == "true" 
}

// Frontend
const buttons = deviceScreen?.elements.filter(el =>
  el.text?.toLowerCase().includes('button') ||
  el.resourceId?.toLowerCase().includes('btn')
) || [];
```

#### Pattern 2: Extract Form Fields

```kotlin
// Backend
val formFields = elements.filter { 
    it.attribute("hintText") != null 
}

// Frontend
const formFields = deviceScreen?.elements.filter(el =>
  el.hintText !== null
) || [];
```

#### Pattern 3: Extract Elements by Region

```kotlin
// Backend
val topElements = elements.filter {
    val bounds = it.bounds()
    bounds?.y ?: Int.MAX_VALUE < deviceHeight / 2
}

// Frontend
const topHalf = deviceScreen?.elements.filter(el =>
  el.bounds && el.bounds.y < (deviceScreen.height / 2)
) || [];
```

#### Pattern 4: Extract Clickable Text Elements

```kotlin
// Backend
val clickableText = elements.filter {
    it.attribute("text") != null && 
    it.attribute("clickable") == "true"
}

// Frontend
const clickableText = deviceScreen?.elements.filter(el =>
  el.text !== null && el.text !== ""
) || [];
```

#### Pattern 5: Find Element by Multiple Criteria

```typescript
// Frontend
function findElement(criteria: {
  text?: string;
  resourceId?: string;
  minWidth?: number;
  maxY?: number;
}): UIElement | undefined {
  return deviceScreen?.elements.find(el => {
    if (criteria.text && el.text !== criteria.text) return false;
    if (criteria.resourceId && el.resourceId !== criteria.resourceId) return false;
    if (criteria.minWidth && (!el.bounds || el.bounds.width < criteria.minWidth)) return false;
    if (criteria.maxY && (!el.bounds || el.bounds.y > criteria.maxY)) return false;
    return true;
  });
}

// Usage
const result = findElement({
  text: "Login",
  minWidth: 100,
  maxY: 500
});
```

### F. Troubleshooting Extraction Issues

#### Issue 1: Attribute Returns Null

**Problem**: `element.attribute("text")` returns `null`

**Causes**:
- Attribute doesn't exist in TreeNode
- Attribute value is empty string
- Attribute key name is incorrect

**Solutions**:
```kotlin
// Check if attribute exists
if ("text" in element.attributes) {
    val text = element.attributes["text"]
}

// Use safe call
val text = element.attribute("text") ?: "No text"

// Check raw attributes
println("All attributes: ${element.attributes}")
```

#### Issue 2: Bounds Parsing Fails

**Problem**: `element.bounds()` returns `null`

**Causes**:
- Bounds string format doesn't match pattern
- Bounds string is malformed
- Element has no bounds

**Solutions**:
```kotlin
// Check bounds string format
val boundsString = element.attributes["bounds"]
println("Bounds string: $boundsString")

// Expected format: "[left,top][right,bottom]"
// Example: "[50,400][340,444]"

// Verify pattern match
val pattern = Pattern.compile("\\[([0-9-]+),([0-9-]+)]\\[([0-9-]+),([0-9-]+)]")
val matches = boundsString?.let { pattern.matcher(it).matches() }
println("Matches pattern: $matches")
```

#### Issue 3: Duplicate Indices Not Calculated

**Problem**: Elements with same text don't have indices

**Cause**: Only one element has that text (indices only assigned when 2+ duplicates)

**Solution**:
```kotlin
// Index is null when element is unique
if (textIndex == null) {
    println("Element has unique text selector")
} else {
    println("Element is duplicate #$textIndex")
}
```

#### Issue 4: Element Not Appearing in Frontend

**Problem**: Element exists in backend but doesn't show in ElementsPanel

**Cause**: Element has no selectable attributes (text, ID, hint, accessibility)

**Solution**:
```typescript
// Check if element has any selector
function hasSelector(el: UIElement): boolean {
  return !!(el.text || el.resourceId || el.hintText || el.accessibilityText);
}

// Elements without selectors are filtered out
const selectableElements = deviceScreen?.elements.filter(hasSelector) || [];
```

#### Issue 5: Platform-Specific Attribute Missing

**Problem**: Android `resource-id` not extracted on iOS

**Cause**: Different platforms use different attribute names

**Solution**: Use platform-specific attribute mapping
```kotlin
// Create platform-agnostic helper
fun TreeNode.getIdentifier(): String? {
    return when (platform) {
        Platform.ANDROID -> attribute("resource-id")
        Platform.IOS -> attribute("accessibilityIdentifier")
        Platform.WEB -> attribute("id")
        else -> null
    }
}
```

### G. Future Enhancements

Potential improvements to the selector system:

1. **XPath/CSS Selector Support**: For web apps, show XPath and CSS selectors
2. **Selector Validation**: Test if selector uniquely identifies element
3. **Selector History**: Track recently used selectors
4. **Export Selectors**: Export element list to CSV/JSON
5. **Visual Selector Builder**: Drag-and-drop to build complex selectors
6. **Performance Metrics**: Show latency between captures
7. **Diff View**: Highlight elements that changed since last capture
8. **Batch Extraction**: Extract selectors from multiple screens at once
9. **Smart Selector Suggestion**: AI-powered selector recommendations
10. **Selector Testing**: Validate selectors across different screen states

---

## Summary

Maestro Studio's selector system is a sophisticated, real-time UI inspection tool that:

1. **Captures** device UI state continuously using Maestro drivers
2. **Processes** view hierarchy into flat, searchable element list
3. **Streams** updates to frontend via Server-Sent Events
4. **Renders** interactive overlays on device screenshots
5. **Enables** precise element selection through visual and text-based methods
6. **Optimizes** performance through intelligent caching and diffing

The architecture prioritizes **real-time feedback**, **cross-platform support**, and **developer experience**, making it an essential tool for authoring and debugging Maestro tests.

