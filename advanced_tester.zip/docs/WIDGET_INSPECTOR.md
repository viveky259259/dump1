# Widget Inspector Feature

The Advanced Tester now includes a comprehensive Widget Inspector feature, similar to the one in the Dart Code VS Code extension. This feature allows you to inspect the widget tree of running Flutter applications.

## Features

### 🔍 Widget Tree Visualization
- **Hierarchical Tree View**: Browse the complete widget hierarchy of your Flutter app
- **Widget Selection**: Click on any widget in the tree to select it for inspection
- **Widget Details**: View detailed information about selected widgets including:
  - Widget description and type
  - Render size and offset
  - Widget properties
  - Source location (when available)

### 🛠 Inspector Service Integration
- **VM Service Connection**: Automatically connects to the Flutter app's VM service
- **Real-time Updates**: Reflects the current state of the widget tree
- **Memory Management**: Properly manages object groups to prevent memory leaks
- **Error Handling**: Graceful handling of connection issues and service unavailability

## How to Use

### 1. Setup Your Flutter Project
1. Click **"Select Project"** and choose a Flutter project directory
2. Click **"Flutter SDK"** and select your Flutter SDK path (if not using the default)

### 2. Run Your Flutter App
1. Click the **"Run App"** button to start your Flutter app on the selected device (Chrome for web or an iOS simulator)
2. Wait for the app to compile and start running
3. The app will automatically connect to the VM service when available

### 3. Inspect Widgets
1. Once the app is running, the **Widget Tree** panel will show the widget hierarchy
2. Click the **refresh button** (🔄) to reload the widget tree
3. Click on any widget in the tree to:
   - Select it for inspection
   - View detailed properties in a popup dialog
4. Use the **bug report button** (🐛) in the toolbar to test inspector connectivity

### 4. Widget Details Dialog
When you click on a widget, you'll see:
- **Description**: Human-readable widget description
- **Type**: The widget class name
- **Render Size**: Width and height of the rendered widget
- **Render Offset**: X,Y position of the widget
- **Properties**: All available widget properties and their values

## Technical Implementation

### Core Components

#### InspectorService
- Manages connection to Flutter's VM service
- Implements all Flutter inspector protocol methods:
  - `getRootWidgetSummaryTree()` - Get the complete widget tree
  - `getWidgetDetails(objectId)` - Get detailed widget information
  - `getChildren(objectId)` - Get child widgets (for lazy loading)
  - `getSelectedWidget()` - Get currently selected widget
  - `isInspectorAvailable()` - Check if inspector is ready

#### WidgetTreeNode Model
```dart
class WidgetTreeNode {
  final String? description;
  final String? type;
  final String? objectId;
  final Map<String, dynamic>? properties;
  final List<WidgetTreeNode> children;
  final bool hasChildren;
  final int? renderOffsetX, renderOffsetY;
  final int? renderWidth, renderHeight;
}
```

#### WidgetTreePanel UI
- Interactive tree view with proper indentation
- Widget selection with visual feedback
- Loading states and error handling
- Refresh functionality
- Widget details dialog

### Service Extensions Used
The inspector uses Flutter's built-in service extensions:
- `ext.flutter.inspector.getRootWidgetSummaryTree`
- `ext.flutter.inspector.getProperties`
- `ext.flutter.inspector.getChildren`
- `ext.flutter.inspector.getSelectedSummaryWidget`
- `ext.flutter.inspector.disposeGroup`
- `ext.flutter.inspector.isWidgetTreeReady`
- `ext.flutter.inspector.setPubRootDirectories`

## Troubleshooting

### Inspector Not Available
- **Make sure the app is running in debug mode**
- **Web debugging**: Flutter web apps must be run with `--web-port` for proper VM service access
- **Connection issues**: Check that the VM service WebSocket URL is correctly detected

### Widget Tree Not Loading
- Click the refresh button in the Widget Tree panel
- Check the debug console for connection errors
- Verify that the Flutter app is fully loaded and running

### Empty Widget Tree
- The inspector only works with debug builds
- Make sure the Flutter app has actually rendered widgets
- Some widgets might not be available if the app is in an error state

## Development Notes

This implementation is based on the widget inspector functionality from the Dart Code VS Code extension, adapted for use in a standalone Flutter application. It demonstrates how to:

1. Connect to Flutter's VM service
2. Use Flutter's inspector service extensions
3. Parse and display widget tree data
4. Create an interactive widget inspection UI
5. Handle real-time widget selection and highlighting

The implementation can be extended to add features like:
- Widget property editing
- Performance monitoring
- Screenshot capture
- Widget search and filtering
- Export widget tree data
