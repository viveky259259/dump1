# Building a Browser-Based Mobile Simulator Viewer and Controller

## Executive Summary

This document describes a comprehensive architecture for building a web-based tool that connects to mobile device simulators (iOS/Android) and displays their screens in a browser with interactive capabilities. The system enables developers to view, inspect, and control mobile simulators remotely through a modern web interface.

**Key Capabilities:**
- Real-time simulator screen streaming to browser
- Interactive UI element inspection
- Remote device control (tap, swipe, input)
- Cross-platform support (iOS & Android)
- View hierarchy extraction and visualization

**Technology Stack:**
- **Backend:** Kotlin/JVM with Ktor web framework
- **Frontend:** React with TypeScript
- **Android Communication:** gRPC over ADB (Android Debug Bridge)
- **iOS Communication:** HTTP/REST via XCTest framework
- **Real-time Streaming:** Server-Sent Events (SSE)

**Architecture Pattern:** Client-Server with Device Driver Layer

---

## 1. Thought Process & Design Philosophy

### 1.1 Core Problem Statement

Modern mobile development requires frequent interaction with simulators/emulators. Traditional approaches have limitations:
- Physical device screens are small and hard to inspect
- Simulator windows clutter the desktop
- No easy way to share simulator state with remote teams
- Element inspection requires switching between tools
- Manual test creation is time-consuming

**Solution:** Create a web-based interface that acts as a "remote control" for simulators, streaming the screen and allowing interaction through a browser.

### 1.2 Design Principles

#### **Separation of Concerns**
The architecture is divided into distinct layers:
1. **Device Driver Layer** - Low-level device communication
2. **Core Abstraction Layer** - Platform-agnostic device operations
3. **Web Server Layer** - HTTP API and resource serving
4. **Frontend Layer** - User interface and interaction

#### **Real-time First**
Device state changes constantly. The system must:
- Stream screenshots continuously (not on-demand)
- Update UI hierarchy in real-time
- Provide immediate feedback for user actions
- Handle device state changes gracefully

#### **Platform Abstraction**
iOS and Android have different control mechanisms:
- **Android:** Instrumentation via ADB
- **iOS:** XCTest framework via simctl

The core layer must abstract these differences behind a unified interface.

#### **Non-Blocking Architecture**
Simulator operations can be slow. The system uses:
- Asynchronous I/O for device communication
- Background threads for screenshot capture
- Non-blocking HTTP handlers
- Event-driven updates to frontend

### 1.3 Key Technical Challenges

#### **Challenge 1: Device Discovery**
How to automatically detect and connect to running simulators?

**Solution:**
- **Android:** Poll ADB server for connected devices
- **iOS:** Parse output of `xcrun simctl list` command
- Maintain a registry of connected devices
- Auto-launch simulators if not running

#### **Challenge 2: Bidirectional Communication**
Browser needs continuous updates, but HTTP is request-response.

**Solution:**
- Use Server-Sent Events (SSE) for server-to-client streaming
- Regular HTTP POST for client-to-server commands
- Screenshot + hierarchy bundled in each SSE event

#### **Challenge 3: Element Identification**
UI elements need stable identifiers for interaction.

**Solution:**
- Extract view hierarchy from device
- Generate composite IDs from: resource-id, text, bounds, index
- Handle duplicate elements with index suffixes
- Map elements to screen coordinates

#### **Challenge 4: Cross-Platform Driver Installation**
Each platform requires a test driver on the device.

**Solution:**
- **Android:** Install APK via `adb install`, launch via instrumentation
- **iOS:** Build XCTest runner, install via `simctl install`, launch via `xcodebuild`
- Bundle pre-built drivers to avoid compilation delays
- Implement lazy installation (install only when needed)

---

## 2. System Architecture

### 2.1 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        Browser (Client)                         │
│  ┌──────────────┐  ┌─────────────┐  ┌─────────────────────┐   │
│  │  Device      │  │  Element    │  │  Command            │   │
│  │  Viewer      │  │  Inspector  │  │  Interface (REPL)   │   │
│  └──────┬───────┘  └──────┬──────┘  └──────┬──────────────┘   │
│         │                 │                 │                   │
│         └─────────────────┴─────────────────┘                   │
│                           │                                     │
│                    React Application                            │
└───────────────────────────┼─────────────────────────────────────┘
                            │
                    HTTP / SSE (WebSocket alternative)
                            │
┌───────────────────────────┼─────────────────────────────────────┐
│                    Web Server (Backend)                         │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                    Ktor Server                            │  │
│  │  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │  │
│  │  │  SSE Stream │  │  API Routes  │  │  Static Assets │  │  │
│  │  │  Endpoint   │  │  Handler     │  │  Server        │  │  │
│  │  └──────┬──────┘  └──────┬───────┘  └────────────────┘  │  │
│  └─────────┼────────────────┼──────────────────────────────┘  │
│            │                │                                   │
│  ┌─────────┴────────────────┴──────────────────────────────┐  │
│  │              Device Service Layer                        │  │
│  │  - Screenshot capture                                    │  │
│  │  - Hierarchy extraction                                  │  │
│  │  - Command execution                                     │  │
│  │  - Element identification                                │  │
│  └─────────────────────────┬─────────────────────────────────┘ │
└────────────────────────────┼────────────────────────────────────┘
                             │
              Platform Abstraction Interface
                             │
        ┌────────────────────┴────────────────────┐
        │                                         │
┌───────┴─────────┐                     ┌─────────┴────────┐
│  Android Driver │                     │   iOS Driver     │
│                 │                     │                  │
│  - gRPC Client  │                     │  - HTTP Client   │
│  - ADB Wrapper  │                     │  - XCTest Client │
└───────┬─────────┘                     └─────────┬────────┘
        │                                         │
   gRPC over TCP                            HTTP/REST
   (Port 7001)                             (Port 22087)
        │                                         │
┌───────┴─────────┐                     ┌─────────┴────────┐
│ Android Device  │                     │  iOS Simulator   │
│                 │                     │                  │
│ Test Runner APK │                     │ XCTest Runner    │
│ (Instrumentation│                     │ Bundle (.app)    │
└─────────────────┘                     └──────────────────┘
```

### 2.2 Component Breakdown

#### **Frontend Components**

1. **Device Viewer**
   - Displays device screenshot
   - Scales to fit viewport
   - Overlays element boundaries
   - Handles gesture input (tap/swipe)

2. **Element Inspector**
   - Shows all UI elements in hierarchy
   - Search/filter by text or ID
   - Displays element properties
   - Highlights selected element on screen

3. **Command Interface**
   - Text input for commands
   - Command history
   - Execution status feedback
   - Export to test files

#### **Backend Components**

1. **SSE Stream Generator**
   - Continuous loop capturing device state
   - Bundles screenshot + hierarchy
   - Sends as SSE events
   - Handles client disconnection

2. **Device Service**
   - Manages device connections
   - Executes commands on device
   - Caches last known hierarchy
   - Manages screenshot storage

3. **Driver Manager**
   - Installs device drivers
   - Maintains driver lifecycle
   - Handles driver crashes
   - Port forwarding management

---

## 3. Detailed Workflows

### 3.1 System Initialization Sequence

```
┌──────┐         ┌────────────┐       ┌──────────┐      ┌──────────┐
│ User │         │   CLI      │       │  Device  │      │  Driver  │
│      │         │  Command   │       │  Service │      │ Installer│
└──┬───┘         └─────┬──────┘       └────┬─────┘      └────┬─────┘
   │                   │                   │                  │
   │  Run 'start'      │                   │                  │
   │──────────────────>│                   │                  │
   │                   │                   │                  │
   │                   │ List Devices      │                  │
   │                   │──────────────────>│                  │
   │                   │                   │                  │
   │                   │ Available Devices │                  │
   │                   │<──────────────────│                  │
   │                   │                   │                  │
   │                   │ Pick/Boot Device  │                  │
   │                   │──────────────────>│                  │
   │                   │                   │                  │
   │                   │                   │ Boot Simulator   │
   │                   │                   │─────────┐        │
   │                   │                   │         │        │
   │                   │                   │<────────┘        │
   │                   │                   │                  │
   │                   │ Device Ready      │                  │
   │                   │<──────────────────│                  │
   │                   │                   │                  │
   │                   │ Install Driver    │                  │
   │                   │──────────────────────────────────────>│
   │                   │                   │                  │
   │                   │                   │   Install APK/   │
   │                   │                   │   XCTest Bundle  │
   │                   │                   │<─────────────────│
   │                   │                   │                  │
   │                   │                   │   Launch Driver  │
   │                   │                   │<─────────────────│
   │                   │                   │                  │
   │                   │ Driver Ready      │                  │
   │                   │<──────────────────────────────────────│
   │                   │                   │                  │
   │                   │ Start Web Server  │                  │
   │                   │─────────┐         │                  │
   │                   │         │         │                  │
   │                   │<────────┘         │                  │
   │                   │                   │                  │
   │ Server URL        │                   │                  │
   │<──────────────────│                   │                  │
   │                   │                   │                  │
   │ Open Browser      │                   │                  │
   │─────────┐         │                   │                  │
   │         │         │                   │                  │
   │<────────┘         │                   │                  │
```

### 3.2 Real-Time Streaming Workflow

```
┌─────────┐         ┌────────────┐       ┌──────────┐      ┌──────────┐
│ Browser │         │ SSE Stream │       │  Device  │      │  Device  │
│         │         │  Handler   │       │  Service │      │  Driver  │
└────┬────┘         └─────┬──────┘       └────┬─────┘      └────┬─────┘
     │                    │                   │                  │
     │ GET /device-       │                   │                  │
     │ screen/sse         │                   │                  │
     │───────────────────>│                   │                  │
     │                    │                   │                  │
     │  200 OK            │                   │                  │
     │  Content-Type:     │                   │                  │
     │  text/event-stream │                   │                  │
     │<───────────────────│                   │                  │
     │                    │                   │                  │
     │                    │   ┌───────────────┐                 │
     │                    │   │ Infinite Loop │                 │
     │                    │   └───────┬───────┘                 │
     │                    │           │                         │
     │                    │   Get Screen State                  │
     │                    │──────────────────>│                 │
     │                    │                   │                 │
     │                    │                   │ Get Hierarchy   │
     │                    │                   │────────────────>│
     │                    │                   │                 │
     │                    │                   │ Hierarchy XML   │
     │                    │                   │<────────────────│
     │                    │                   │                 │
     │                    │                   │ Take Screenshot │
     │                    │                   │────────────────>│
     │                    │                   │                 │
     │                    │                   │ PNG Bytes       │
     │                    │                   │<────────────────│
     │                    │                   │                 │
     │                    │                   │ Save to Disk    │
     │                    │                   │─────────┐       │
     │                    │                   │         │       │
     │                    │                   │<────────┘       │
     │                    │                   │                 │
     │                    │  DeviceScreen     │                 │
     │                    │  (JSON)           │                 │
     │                    │<──────────────────│                 │
     │                    │                   │                 │
     │  data: {...}       │                   │                 │
     │<───────────────────│                   │                 │
     │                    │                   │                 │
     │  [React updates]   │                   │                 │
     │─────────┐          │                   │                 │
     │         │          │                   │                 │
     │<────────┘          │                   │                 │
     │                    │           ┌───────┘                 │
     │                    │           │                         │
     │                    │   [Loop repeats ~every 100ms]       │
```

### 3.3 User Interaction Flow (Tap Element)

```
┌─────────┐      ┌─────────┐     ┌────────────┐    ┌──────────┐    ┌──────────┐
│ Browser │      │ React   │     │ Web Server │    │  Device  │    │  Device  │
│   UI    │      │  App    │     │    API     │    │  Service │    │  Driver  │
└────┬────┘      └────┬────┘     └─────┬──────┘    └────┬─────┘    └────┬─────┘
     │                │                │                │                │
     │ Click Element  │                │                │                │
     │───────────────>│                │                │                │
     │                │                │                │                │
     │                │ Identify       │                │                │
     │                │ Element        │                │                │
     │                │─────┐          │                │                │
     │                │     │          │                │                │
     │                │<────┘          │                │                │
     │                │                │                │                │
     │                │ Generate       │                │                │
     │                │ Command YAML   │                │                │
     │                │─────┐          │                │                │
     │                │     │          │                │                │
     │                │<────┘          │                │                │
     │                │                │                │                │
     │                │ POST /api/     │                │                │
     │                │ run-command    │                │                │
     │                │───────────────>│                │                │
     │                │                │                │                │
     │                │                │ Parse YAML     │                │
     │                │                │─────┐          │                │
     │                │                │     │          │                │
     │                │                │<────┘          │                │
     │                │                │                │                │
     │                │                │ Execute Tap    │                │
     │                │                │───────────────>│                │
     │                │                │                │                │
     │                │                │                │ Send Tap       │
     │                │                │                │ Command        │
     │                │                │                │───────────────>│
     │                │                │                │                │
     │                │                │                │ Tap Event      │
     │                │                │                │─────────┐      │
     │                │                │                │         │      │
     │                │                │                │<────────┘      │
     │                │                │                │                │
     │                │                │                │ Success        │
     │                │                │                │<───────────────│
     │                │                │                │                │
     │                │                │ Success        │                │
     │                │                │<───────────────│                │
     │                │                │                │                │
     │                │ 200 OK         │                │                │
     │                │<───────────────│                │                │
     │                │                │                │                │
     │ Update UI      │                │                │                │
     │<───────────────│                │                │                │
     │                │                │                │                │
     │ [Next SSE event shows updated screen]           │                │
```

---

## 4. Implementation Details

### 4.1 Android Driver Implementation

#### **Technology Stack**
- **ADB Communication:** DADB library (Kotlin)
- **RPC Protocol:** gRPC
- **Driver APK:** Android Instrumentation Test
- **Port Forwarding:** ADB TCP forward

#### **Driver Installation Process**

```kotlin
// 1. Check for connected devices via ADB
fun discoverAndroidDevices(): List<Device> {
    val devices = mutableListOf<Device>()
    
    // Connect to ADB server
    val dadb = Dadb.discover("localhost") 
        ?: AdbServer.createDadb(adbServerPort = 5038)
        ?: throw Exception("No Android devices found")
    
    // Get device properties
    val deviceName = dadb.shell("getprop ro.product.model").output
    val deviceId = dadb.shell("getprop ro.serialno").output
    
    devices.add(Device(
        id = deviceId,
        name = deviceName,
        platform = Platform.ANDROID
    ))
    
    return devices
}

// 2. Install driver APKs
fun installAndroidDriver(dadb: Dadb) {
    val appApk = loadResourceAsFile("maestro-app.apk")
    val testApk = loadResourceAsFile("maestro-test.apk")
    
    // Install both APKs
    dadb.install(appApk)
    dadb.install(testApk)
    
    println("Driver APKs installed successfully")
}

// 3. Start instrumentation server
fun startInstrumentationServer(dadb: Dadb, port: Int = 7001) {
    // Set up port forwarding
    dadb.tcpForward(port, port)
    
    // Build instrumentation command
    val instrumentationCommand = """
        am instrument -w 
        -e debug false 
        -e class 'com.example.driver.DriverService#grpcServer' 
        -e port $port 
        com.example.driver.test/androidx.test.runner.AndroidJUnitRunner &
    """.trimIndent()
    
    // Execute in background
    val session = dadb.openShell(instrumentationCommand)
    
    // Wait for server to be ready
    waitForServerReady(port)
}

// 4. Create gRPC client
fun createGrpcClient(port: Int): DriverServiceGrpc.DriverServiceBlockingStub {
    val channel = ManagedChannelBuilder
        .forAddress("localhost", port)
        .usePlaintext()
        .keepAliveTime(2, TimeUnit.MINUTES)
        .keepAliveTimeout(20, TimeUnit.SECONDS)
        .build()
    
    return DriverServiceGrpc.newBlockingStub(channel)
}
```

#### **gRPC Interface Definition**

```protobuf
syntax = "proto3";

service DriverService {
  rpc GetViewHierarchy(Empty) returns (ViewHierarchyResponse);
  rpc TakeScreenshot(Empty) returns (ScreenshotResponse);
  rpc Tap(TapRequest) returns (TapResponse);
  rpc Swipe(SwipeRequest) returns (SwipeResponse);
  rpc InputText(InputTextRequest) returns (InputTextResponse);
  rpc LaunchApp(LaunchAppRequest) returns (LaunchAppResponse);
  rpc GetDeviceInfo(Empty) returns (DeviceInfoResponse);
}

message ViewHierarchyResponse {
  string xml = 1;
}

message ScreenshotResponse {
  bytes png_data = 1;
}

message TapRequest {
  int32 x = 1;
  int32 y = 2;
}

message TapResponse {
  bool success = 1;
}

message SwipeRequest {
  int32 start_x = 1;
  int32 start_y = 2;
  int32 end_x = 3;
  int32 end_y = 4;
  int32 duration_ms = 5;
}

message DeviceInfoResponse {
  int32 width = 1;
  int32 height = 2;
  string platform = 3;
}
```

#### **Android Test Runner (Instrumentation)**

```kotlin
// In the APK that gets installed on device
class DriverService : AndroidJUnitRunner() {
    
    @Test
    fun grpcServer() {
        val port = InstrumentationRegistry.getArguments()
            .getString("port")?.toInt() ?: 7001
        
        val server = ServerBuilder
            .forPort(port)
            .addService(DriverServiceImpl())
            .build()
            .start()
        
        println("gRPC server started on port $port")
        
        // Keep server running
        server.awaitTermination()
    }
}

class DriverServiceImpl : DriverServiceGrpc.DriverServiceImplBase() {
    
    override fun getViewHierarchy(
        request: Empty,
        responseObserver: StreamObserver<ViewHierarchyResponse>
    ) {
        val uiAutomation = InstrumentationRegistry
            .getInstrumentation()
            .uiAutomation
        
        val accessibilityNodeInfo = uiAutomation.rootInActiveWindow
        val xml = nodeToXml(accessibilityNodeInfo)
        
        val response = ViewHierarchyResponse.newBuilder()
            .setXml(xml)
            .build()
        
        responseObserver.onNext(response)
        responseObserver.onCompleted()
    }
    
    override fun takeScreenshot(
        request: Empty,
        responseObserver: StreamObserver<ScreenshotResponse>
    ) {
        val uiAutomation = InstrumentationRegistry
            .getInstrumentation()
            .uiAutomation
        
        val bitmap = uiAutomation.takeScreenshot()
        val byteArray = bitmapToPngBytes(bitmap)
        
        val response = ScreenshotResponse.newBuilder()
            .setPngData(ByteString.copyFrom(byteArray))
            .build()
        
        responseObserver.onNext(response)
        responseObserver.onCompleted()
    }
    
    override fun tap(
        request: TapRequest,
        responseObserver: StreamObserver<TapResponse>
    ) {
        val uiAutomation = InstrumentationRegistry
            .getInstrumentation()
            .uiAutomation
        
        val path = Path()
        path.moveTo(request.x.toFloat(), request.y.toFloat())
        
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 10))
            .build()
        
        val result = uiAutomation.dispatchGesture(gesture, null, null)
        
        val response = TapResponse.newBuilder()
            .setSuccess(result)
            .build()
        
        responseObserver.onNext(response)
        responseObserver.onCompleted()
    }
}
```

### 4.2 iOS Driver Implementation

#### **Technology Stack**
- **Simulator Control:** xcrun simctl (command-line)
- **RPC Protocol:** HTTP/REST
- **Driver:** XCUITest Runner
- **Framework:** XCTest (Apple's UI testing framework)

#### **Driver Installation Process**

```kotlin
// 1. Discover iOS simulators
fun discoverIOSSimulators(): List<Device> {
    val process = ProcessBuilder("xcrun", "simctl", "list", "--json")
        .start()
    
    val json = process.inputStream.bufferedReader().readText()
    val simctlList = parseSimctlJson(json)
    
    return simctlList.devices.flatMap { (runtime, devices) ->
        devices.filter { it.isAvailable }
            .map { device ->
                Device(
                    id = device.udid,
                    name = "${device.name} - $runtime",
                    platform = Platform.IOS,
                    state = if (device.state == "Booted") 
                        DeviceState.CONNECTED 
                    else 
                        DeviceState.AVAILABLE
                )
            }
    }
}

// 2. Boot simulator if needed
fun bootSimulator(deviceId: String) {
    // Check if already booted
    val state = getSimulatorState(deviceId)
    if (state == "Booted") {
        println("Simulator already booted")
        return
    }
    
    // Boot the simulator
    ProcessBuilder("xcrun", "simctl", "boot", deviceId)
        .start()
        .waitFor()
    
    // Wait for boot to complete
    awaitSimulatorBoot(deviceId)
    
    println("Simulator booted successfully")
}

fun awaitSimulatorBoot(deviceId: String, timeoutSeconds: Int = 60) {
    val startTime = System.currentTimeMillis()
    
    while (System.currentTimeMillis() - startTime < timeoutSeconds * 1000) {
        val state = getSimulatorState(deviceId)
        if (state == "Booted") {
            return
        }
        Thread.sleep(500)
    }
    
    throw TimeoutException("Simulator failed to boot in $timeoutSeconds seconds")
}

// 3. Install XCTest Runner
fun installXCTestRunner(deviceId: String, port: Int = 22087) {
    val runnerBundle = getXCTestRunnerBundle()
    
    // Install the runner app
    ProcessBuilder(
        "xcrun", "simctl", "install", 
        deviceId, 
        runnerBundle.absolutePath
    ).start().waitFor()
    
    println("XCTest runner installed")
    
    // Launch the runner
    launchXCTestRunner(deviceId, port)
}

// 4. Launch XCTest Runner
fun launchXCTestRunner(deviceId: String, port: Int) {
    val xctestRunFile = getXCTestRunFile()
    
    val processBuilder = ProcessBuilder(
        "xcodebuild",
        "test-without-building",
        "-xctestrun", xctestRunFile.absolutePath,
        "-destination", "platform=iOS Simulator,id=$deviceId",
        "MAESTRO_PORT=$port"
    )
    
    processBuilder.environment()["MAESTRO_PORT"] = port.toString()
    
    val process = processBuilder.start()
    
    // Wait for server to be ready
    waitForHttpServer(port)
    
    println("XCTest runner launched on port $port")
}

// 5. Create HTTP client
fun createHttpClient(port: Int): OkHttpClient {
    return OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
}
```

#### **XCTest Runner Implementation (Swift)**

```swift
// XCUITest Runner that runs on the simulator
import XCTest

class DriverUITests: XCTestCase {
    
    static var httpServer: HttpServer?
    
    override class func setUp() {
        super.setUp()
        
        // Get port from environment or use default
        let port = ProcessInfo.processInfo
            .environment["MAESTRO_PORT"]
            .flatMap { Int($0) } ?? 22087
        
        // Start HTTP server
        httpServer = HttpServer(port: port)
        httpServer?.start()
        
        print("HTTP server started on port \(port)")
    }
    
    // This test runs indefinitely, keeping the server alive
    func testKeepServerAlive() {
        while true {
            sleep(1)
        }
    }
}

class HttpServer {
    let port: Int
    var listener: NWListener?
    
    init(port: Int) {
        self.port = port
    }
    
    func start() {
        listener = try? NWListener(using: .tcp, on: NWEndpoint.Port(integerLiteral: UInt16(port)))
        
        listener?.newConnectionHandler = { [weak self] connection in
            self?.handleConnection(connection)
        }
        
        listener?.start(queue: .global())
    }
    
    func handleConnection(_ connection: NWConnection) {
        connection.start(queue: .global())
        
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, isComplete, error in
            guard let data = data else { return }
            
            let request = String(data: data, encoding: .utf8) ?? ""
            let response = self.handleRequest(request)
            
            connection.send(content: response.data(using: .utf8), completion: .contentProcessed({ _ in
                connection.cancel()
            }))
        }
    }
    
    func handleRequest(_ request: String) -> String {
        // Parse HTTP request
        let lines = request.components(separatedBy: "\r\n")
        guard let firstLine = lines.first else {
            return httpResponse(statusCode: 400, body: "Bad Request")
        }
        
        let parts = firstLine.components(separatedBy: " ")
        guard parts.count >= 2 else {
            return httpResponse(statusCode: 400, body: "Bad Request")
        }
        
        let method = parts[0]
        let path = parts[1]
        
        // Route requests
        if method == "GET" && path == "/viewHierarchy" {
            return handleViewHierarchy()
        } else if method == "GET" && path == "/screenshot" {
            return handleScreenshot()
        } else if method == "POST" && path == "/tap" {
            let body = extractBody(from: request)
            return handleTap(body: body)
        } else if method == "GET" && path == "/deviceInfo" {
            return handleDeviceInfo()
        }
        
        return httpResponse(statusCode: 404, body: "Not Found")
    }
    
    func handleViewHierarchy() -> String {
        let app = XCUIApplication()
        let snapshot = app.debugDescription
        
        return httpResponse(statusCode: 200, body: snapshot, contentType: "text/xml")
    }
    
    func handleScreenshot() -> String {
        let screenshot = XCUIScreen.main.screenshot()
        let pngData = screenshot.pngRepresentation
        let base64 = pngData.base64EncodedString()
        
        let json = """
        {"screenshot": "\(base64)"}
        """
        
        return httpResponse(statusCode: 200, body: json, contentType: "application/json")
    }
    
    func handleTap(body: String) -> String {
        guard let data = body.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let x = json["x"] as? Double,
              let y = json["y"] as? Double else {
            return httpResponse(statusCode: 400, body: "Invalid request")
        }
        
        let coordinate = XCUIApplication().coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 0))
        let point = coordinate.withOffset(CGVector(dx: x, dy: y))
        point.tap()
        
        return httpResponse(statusCode: 200, body: """
        {"success": true}
        """, contentType: "application/json")
    }
    
    func handleDeviceInfo() -> String {
        let screen = UIScreen.main
        let width = Int(screen.bounds.width)
        let height = Int(screen.bounds.height)
        
        let json = """
        {
            "width": \(width),
            "height": \(height),
            "platform": "iOS"
        }
        """
        
        return httpResponse(statusCode: 200, body: json, contentType: "application/json")
    }
    
    func httpResponse(statusCode: Int, body: String, contentType: String = "text/plain") -> String {
        let statusText = statusCode == 200 ? "OK" : "Error"
        let bodyData = body.data(using: .utf8)!
        
        return """
        HTTP/1.1 \(statusCode) \(statusText)\r
        Content-Type: \(contentType)\r
        Content-Length: \(bodyData.count)\r
        Connection: close\r
        \r
        \(body)
        """
    }
    
    func extractBody(from request: String) -> String {
        let parts = request.components(separatedBy: "\r\n\r\n")
        return parts.count > 1 ? parts[1] : ""
    }
}
```

### 4.3 Web Server Implementation (Ktor)

```kotlin
// Main server setup
fun startWebServer(port: Int, deviceDriver: DeviceDriver) {
    embeddedServer(Netty, port = port) {
        install(CORS) {
            allowHost("localhost:3000") // For development
            allowHeader(HttpHeaders.ContentType)
        }
        
        install(ContentNegotiation) {
            jackson {
                enable(SerializationFeature.INDENT_OUTPUT)
                setSerializationInclusion(JsonInclude.Include.NON_NULL)
            }
        }
        
        install(StatusPages) {
            exception<Throwable> { call, cause ->
                call.respondText(
                    text = "500: ${cause.message}",
                    status = HttpStatusCode.InternalServerError
                )
                cause.printStackTrace()
            }
        }
        
        routing {
            deviceRoutes(deviceDriver)
            staticResources()
        }
    }.start(wait = false)
    
    println("Server started on http://localhost:$port")
}

// Device routes
fun Routing.deviceRoutes(deviceDriver: DeviceDriver) {
    
    // Server-Sent Events endpoint for real-time streaming
    get("/api/device-screen/sse") {
        call.response.cacheControl(CacheControl.NoCache(null))
        call.respondBytesWriter(contentType = ContentType.Text.EventStream) {
            while (true) {
                try {
                    val deviceScreen = captureDeviceScreen(deviceDriver)
                    val json = Json.encodeToString(deviceScreen)
                    
                    writeStringUtf8("data: $json\n\n")
                    flush()
                    
                    // Capture at ~10 FPS
                    delay(100)
                } catch (e: Exception) {
                    // Client disconnected, exit loop
                    break
                }
            }
        }
    }
    
    // Execute command endpoint
    post("/api/run-command") {
        val request = call.receive<RunCommandRequest>()
        
        try {
            val command = parseCommand(request.yaml)
            
            if (!request.dryRun) {
                executeCommand(deviceDriver, command)
            }
            
            call.respond(HttpStatusCode.OK, mapOf("success" to true))
        } catch (e: Exception) {
            call.respond(
                HttpStatusCode.BadRequest,
                mapOf("error" to (e.message ?: "Command failed"))
            )
        }
    }
    
    // Get cached view hierarchy
    get("/api/last-view-hierarchy") {
        val hierarchy = deviceDriver.getLastViewHierarchy()
            ?: return@get call.respond(
                HttpStatusCode.NotFound,
                "No hierarchy available"
            )
        
        call.respond(hierarchy)
    }
    
    // Serve screenshots
    static("/screenshot") {
        files(getScreenshotDirectory())
    }
}

// Capture device screen state
suspend fun captureDeviceScreen(deviceDriver: DeviceDriver): DeviceScreen {
    // Get view hierarchy
    val hierarchyXml = deviceDriver.getViewHierarchy()
    val hierarchy = parseHierarchy(hierarchyXml)
    
    // Take screenshot
    val screenshotFile = File(getScreenshotDirectory(), "${UUID.randomUUID()}.png")
    deviceDriver.takeScreenshot(screenshotFile)
    
    // Cache hierarchy for later queries
    deviceDriver.cacheHierarchy(hierarchy)
    
    // Extract UI elements from hierarchy
    val elements = extractUIElements(hierarchy)
    
    // Get device info
    val deviceInfo = deviceDriver.getDeviceInfo()
    
    return DeviceScreen(
        platform = deviceInfo.platform,
        screenshot = "/screenshot/${screenshotFile.name}",
        width = deviceInfo.width,
        height = deviceInfo.height,
        elements = elements,
        url = hierarchy.attributes["url"] // For web views
    )
}

// Extract UI elements from hierarchy tree
fun extractUIElements(root: TreeNode): List<UIElement> {
    val elements = mutableListOf<UIElement>()
    val queue = ArrayDeque<TreeNode>()
    queue.add(root)
    
    while (queue.isNotEmpty()) {
        val node = queue.removeFirst()
        
        // Extract element properties
        val bounds = parseBounds(node.attributes["bounds"])
        val text = node.attributes["text"]
        val resourceId = node.attributes["resource-id"]
        val contentDesc = node.attributes["content-desc"]
        
        // Generate unique ID
        val id = generateElementId(resourceId, text, bounds)
        
        elements.add(UIElement(
            id = id,
            bounds = bounds,
            resourceId = resourceId,
            text = text,
            accessibilityText = contentDesc
        ))
        
        queue.addAll(node.children)
    }
    
    return elements
}

// Data models
data class DeviceScreen(
    val platform: String,
    val screenshot: String,
    val width: Int,
    val height: Int,
    val elements: List<UIElement>,
    val url: String? = null
)

data class UIElement(
    val id: String,
    val bounds: Bounds?,
    val resourceId: String?,
    val text: String?,
    val accessibilityText: String?
)

data class Bounds(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

data class RunCommandRequest(
    val yaml: String,
    val dryRun: Boolean = false
)
```

### 4.4 Frontend Implementation (React)

```typescript
// App.tsx - Main application
import React from 'react';
import { DeviceProvider } from './context/DeviceContext';
import DeviceViewer from './components/DeviceViewer';
import CommandInterface from './components/CommandInterface';

function App() {
  return (
    <DeviceProvider>
      <div className="app-container">
        <div className="device-panel">
          <DeviceViewer />
        </div>
        <div className="command-panel">
          <CommandInterface />
        </div>
      </div>
    </DeviceProvider>
  );
}

export default App;

// DeviceContext.tsx - State management
import React, { createContext, useContext, useState, useEffect } from 'react';

interface DeviceScreen {
  platform: string;
  screenshot: string;
  width: number;
  height: number;
  elements: UIElement[];
  url?: string;
}

interface UIElement {
  id: string;
  bounds: { x: number; y: number; width: number; height: number } | null;
  resourceId: string | null;
  text: string | null;
  accessibilityText: string | null;
}

interface DeviceContextType {
  deviceScreen: DeviceScreen | null;
  selectedElement: UIElement | null;
  setSelectedElement: (element: UIElement | null) => void;
}

const DeviceContext = createContext<DeviceContextType | null>(null);

export function DeviceProvider({ children }: { children: React.ReactNode }) {
  const [deviceScreen, setDeviceScreen] = useState<DeviceScreen | null>(null);
  const [selectedElement, setSelectedElement] = useState<UIElement | null>(null);

  useEffect(() => {
    // Connect to SSE endpoint
    const eventSource = new EventSource('/api/device-screen/sse');

    eventSource.onmessage = (event) => {
      const screen: DeviceScreen = JSON.parse(event.data);
      setDeviceScreen(screen);
    };

    eventSource.onerror = (error) => {
      console.error('SSE connection error:', error);
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  }, []);

  return (
    <DeviceContext.Provider value={{ deviceScreen, selectedElement, setSelectedElement }}>
      {children}
    </DeviceContext.Provider>
  );
}

export function useDevice() {
  const context = useContext(DeviceContext);
  if (!context) {
    throw new Error('useDevice must be used within DeviceProvider');
  }
  return context;
}

// DeviceViewer.tsx - Display device screen
import React, { useRef, useState } from 'react';
import { useDevice } from '../context/DeviceContext';

export default function DeviceViewer() {
  const { deviceScreen, selectedElement, setSelectedElement } = useDevice();
  const containerRef = useRef<HTMLDivElement>(null);
  const [mouseDown, setMouseDown] = useState<{ x: number; y: number } | null>(null);

  if (!deviceScreen) {
    return <div>Loading device...</div>;
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;

    setMouseDown({ x, y });
  };

  const handleMouseUp = async (e: React.MouseEvent) => {
    if (!mouseDown) return;

    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;

    const distance = Math.hypot(x - mouseDown.x, y - mouseDown.y);

    if (distance < 0.01) {
      // Tap gesture
      await executeTap(mouseDown.x, mouseDown.y);
    } else {
      // Swipe gesture
      await executeSwipe(mouseDown.x, mouseDown.y, x, y);
    }

    setMouseDown(null);
  };

  const executeTap = async (x: number, y: number) => {
    const yaml = `- tapOn:\n    point: "${Math.round(x * 100)}%,${Math.round(y * 100)}%"`;
    
    await fetch('/api/run-command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ yaml })
    });
  };

  const executeSwipe = async (startX: number, startY: number, endX: number, endY: number) => {
    const yaml = `- swipe:\n    start: "${Math.round(startX * 100)}%,${Math.round(startY * 100)}%"\n    end: "${Math.round(endX * 100)}%,${Math.round(endY * 100)}%"`;
    
    await fetch('/api/run-command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ yaml })
    });
  };

  const handleElementClick = (element: UIElement) => {
    setSelectedElement(element);
  };

  return (
    <div className="device-viewer">
      <div
        ref={containerRef}
        className="device-screen"
        style={{
          aspectRatio: `${deviceScreen.width} / ${deviceScreen.height}`,
          position: 'relative'
        }}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
      >
        <img
          src={deviceScreen.screenshot}
          alt="Device screen"
          style={{ width: '100%', height: '100%' }}
          draggable={false}
        />
        
        {/* Overlay element bounds */}
        {deviceScreen.elements.map(element => {
          if (!element.bounds) return null;

          const isSelected = selectedElement?.id === element.id;

          return (
            <div
              key={element.id}
              className={`element-overlay ${isSelected ? 'selected' : ''}`}
              style={{
                position: 'absolute',
                left: `${(element.bounds.x / deviceScreen.width) * 100}%`,
                top: `${(element.bounds.y / deviceScreen.height) * 100}%`,
                width: `${(element.bounds.width / deviceScreen.width) * 100}%`,
                height: `${(element.bounds.height / deviceScreen.height) * 100}%`,
                border: isSelected ? '2px solid blue' : '1px solid rgba(0, 255, 0, 0.3)',
                backgroundColor: isSelected ? 'rgba(0, 0, 255, 0.1)' : 'transparent',
                cursor: 'pointer'
              }}
              onClick={(e) => {
                e.stopPropagation();
                handleElementClick(element);
              }}
            />
          );
        })}
      </div>

      {/* Element inspector */}
      {selectedElement && (
        <div className="element-inspector">
          <h3>Selected Element</h3>
          <div><strong>ID:</strong> {selectedElement.id}</div>
          <div><strong>Resource ID:</strong> {selectedElement.resourceId || 'N/A'}</div>
          <div><strong>Text:</strong> {selectedElement.text || 'N/A'}</div>
          <div><strong>Accessibility:</strong> {selectedElement.accessibilityText || 'N/A'}</div>
          {selectedElement.bounds && (
            <div>
              <strong>Bounds:</strong> ({selectedElement.bounds.x}, {selectedElement.bounds.y}, 
              {selectedElement.bounds.width}x{selectedElement.bounds.height})
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// CommandInterface.tsx - Command execution interface
import React, { useState } from 'react';

export default function CommandInterface() {
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState<Array<{ command: string; status: string }>>([]);

  const handleExecute = async () => {
    if (!command.trim()) return;

    setHistory(prev => [...prev, { command, status: 'running' }]);

    try {
      const response = await fetch('/api/run-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ yaml: command })
      });

      if (response.ok) {
        setHistory(prev => {
          const updated = [...prev];
          updated[updated.length - 1].status = 'success';
          return updated;
        });
      } else {
        const error = await response.text();
        setHistory(prev => {
          const updated = [...prev];
          updated[updated.length - 1].status = `error: ${error}`;
          return updated;
        });
      }

      setCommand('');
    } catch (error) {
      setHistory(prev => {
        const updated = [...prev];
        updated[updated.length - 1].status = `error: ${error}`;
        return updated;
      });
    }
  };

  return (
    <div className="command-interface">
      <h2>Command Interface</h2>
      
      <div className="command-history">
        {history.map((entry, index) => (
          <div key={index} className={`history-entry ${entry.status}`}>
            <pre>{entry.command}</pre>
            <span className="status">{entry.status}</span>
          </div>
        ))}
      </div>

      <div className="command-input">
        <textarea
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="Enter command YAML..."
          rows={5}
        />
        <button onClick={handleExecute}>Execute</button>
      </div>
    </div>
  );
}
```

---

## 5. External Packages & Dependencies

### 5.1 Backend Dependencies (Kotlin/JVM)

```kotlin
// build.gradle.kts

dependencies {
    // Web framework
    implementation("io.ktor:ktor-server-core:2.3.0")
    implementation("io.ktor:ktor-server-netty:2.3.0")
    implementation("io.ktor:ktor-server-cors:2.3.0")
    implementation("io.ktor:ktor-server-status-pages:2.3.0")
    implementation("io.ktor:ktor-server-content-negotiation:2.3.0")
    implementation("io.ktor:ktor-serialization-jackson:2.3.0")
    
    // Android ADB communication
    implementation("dev.mobile:dadb:1.2.7")
    
    // gRPC for Android driver
    implementation("io.grpc:grpc-netty:1.54.0")
    implementation("io.grpc:grpc-protobuf:1.54.0")
    implementation("io.grpc:grpc-stub:1.54.0")
    implementation("io.grpc:grpc-kotlin-stub:1.3.0")
    
    // HTTP client for iOS driver
    implementation("com.squareup.okhttp3:okhttp:4.11.0")
    
    // JSON parsing
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.15.0")
    implementation("com.fasterxml.jackson.dataformat:jackson-dataformat-yaml:2.15.0")
    
    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.0")
    
    // Logging
    implementation("org.slf4j:slf4j-api:2.0.7")
    implementation("ch.qos.logback:logback-classic:1.4.7")
}
```

### 5.2 Android Driver Dependencies

```kotlin
// Android Test APK build.gradle

dependencies {
    implementation("androidx.test:runner:1.5.2")
    implementation("androidx.test:rules:1.5.0")
    implementation("androidx.test.uiautomator:uiautomator:2.2.0")
    
    // gRPC server
    implementation("io.grpc:grpc-netty:1.54.0")
    implementation("io.grpc:grpc-protobuf:1.54.0")
    implementation("io.grpc:grpc-stub:1.54.0")
    implementation("io.grpc:grpc-services:1.54.0")
}
```

### 5.3 iOS Driver Dependencies

```swift
// Package.swift for XCTest runner

// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "XCTestDriver",
    platforms: [
        .iOS(.v14)
    ],
    products: [
        .library(
            name: "XCTestDriver",
            targets: ["XCTestDriver"]
        ),
    ],
    dependencies: [
        // HTTP server framework (optional, using raw sockets shown above)
        // .package(url: "https://github.com/httpswift/swifter.git", from: "1.5.0"),
    ],
    targets: [
        .target(
            name: "XCTestDriver",
            dependencies: []
        ),
    ]
)
```

### 5.4 Frontend Dependencies (React)

```json
{
  "name": "device-viewer-frontend",
  "version": "1.0.0",
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.10.0",
    "typescript": "^5.0.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0"
  },
  "devDependencies": {
    "vite": "^4.3.0",
    "@vitejs/plugin-react": "^4.0.0",
    "tailwindcss": "^3.3.0",
    "postcss": "^8.4.23",
    "autoprefixer": "^10.4.14"
  },
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  }
}
```

---

## 6. Performance Optimizations

### 6.1 Screenshot Management

**Problem:** Screenshots accumulate quickly and consume disk space.

**Solution:**
```kotlin
private const val MAX_SCREENSHOTS = 10
private val savedScreenshots = mutableListOf<File>()

fun takeScreenshot(deviceDriver: DeviceDriver): File {
    val screenshotFile = File(screenshotDir, "${UUID.randomUUID()}.png")
    deviceDriver.takeScreenshot(screenshotFile)
    
    synchronized(this) {
        savedScreenshots.add(screenshotFile)
        
        // Keep only last N screenshots
        while (savedScreenshots.size > MAX_SCREENSHOTS) {
            savedScreenshots.removeFirst().delete()
        }
    }
    
    return screenshotFile
}
```

### 6.2 Hierarchy Caching

**Problem:** Hierarchy extraction is expensive.

**Solution:**
```kotlin
private var lastViewHierarchy: TreeNode? = null

fun getDeviceScreen(): DeviceScreen {
    val hierarchy = deviceDriver.getViewHierarchy()
    
    // Cache for later queries
    lastViewHierarchy = hierarchy
    
    return DeviceScreen(/* ... */)
}

// Fast endpoint that returns cached hierarchy
fun getLastHierarchy(): TreeNode? = lastViewHierarchy
```

### 6.3 Debounced Updates

**Problem:** Rapid user interactions cause command flooding.

**Solution:**
```typescript
import { debounce } from 'lodash';

const debouncedTap = debounce(async (x: number, y: number) => {
  await executeTap(x, y);
}, 200);
```

### 6.4 SSE Reconnection

**Problem:** SSE connections can drop.

**Solution:**
```typescript
function useDeviceStream() {
  const [deviceScreen, setDeviceScreen] = useState<DeviceScreen | null>(null);
  
  useEffect(() => {
    let eventSource: EventSource;
    let reconnectTimeout: NodeJS.Timeout;
    
    const connect = () => {
      eventSource = new EventSource('/api/device-screen/sse');
      
      eventSource.onmessage = (event) => {
        const screen = JSON.parse(event.data);
        setDeviceScreen(screen);
      };
      
      eventSource.onerror = () => {
        eventSource.close();
        
        // Reconnect after 2 seconds
        reconnectTimeout = setTimeout(connect, 2000);
      };
    };
    
    connect();
    
    return () => {
      eventSource?.close();
      clearTimeout(reconnectTimeout);
    };
  }, []);
  
  return deviceScreen;
}
```

---

## 7. Security Considerations

### 7.1 CORS Configuration

Restrict access to localhost only:

```kotlin
install(CORS) {
    allowHost("localhost:3000")
    allowHost("localhost:8080")
    allowHeader(HttpHeaders.ContentType)
    allowHeader(HttpHeaders.Authorization)
}
```

### 7.2 Command Validation

Validate and sanitize user input:

```kotlin
fun parseCommand(yaml: String): Command {
    // Validate YAML syntax
    val parsed = try {
        YamlParser.parse(yaml)
    } catch (e: Exception) {
        throw CommandException("Invalid YAML syntax: ${e.message}")
    }
    
    // Validate command structure
    if (!isValidCommand(parsed)) {
        throw CommandException("Invalid command structure")
    }
    
    return parsed
}
```

### 7.3 File Access Restrictions

Limit screenshot access to designated directory:

```kotlin
static("/screenshot") {
    files(screenshotDirectory)
    // Don't allow directory traversal
    default("index.html")
    exclude { path -> path.contains("..") }
}
```

---

## 8. Error Handling & Resilience

### 8.1 Device Connection Errors

```kotlin
fun connectToDevice(deviceId: String): DeviceDriver {
    val maxRetries = 3
    var lastException: Exception? = null
    
    repeat(maxRetries) { attempt ->
        try {
            return DeviceDriver.connect(deviceId)
        } catch (e: Exception) {
            lastException = e
            logger.warn("Connection attempt ${attempt + 1} failed: ${e.message}")
            Thread.sleep(1000 * (attempt + 1))
        }
    }
    
    throw DeviceConnectionException(
        "Failed to connect after $maxRetries attempts",
        lastException
    )
}
```

### 8.2 Driver Crash Recovery

```kotlin
class ResilientDeviceDriver(private val baseDriver: DeviceDriver) : DeviceDriver {
    
    override fun takeScreenshot(output: File) {
        try {
            baseDriver.takeScreenshot(output)
        } catch (e: DriverCrashException) {
            logger.error("Driver crashed, restarting...")
            baseDriver.restart()
            baseDriver.takeScreenshot(output)
        }
    }
}
```

### 8.3 Frontend Error Boundaries

```typescript
class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-state">
          <h2>Something went wrong</h2>
          <button onClick={() => window.location.reload()}>
            Reload Page
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
```

---

## 9. Testing Strategy

### 9.1 Unit Tests

```kotlin
class DeviceServiceTest {
    
    @Test
    fun `should extract UI elements from hierarchy`() {
        val hierarchyXml = """
            <hierarchy>
                <node bounds="[0,0][100,100]" text="Button" resource-id="btn_submit"/>
            </hierarchy>
        """.trimIndent()
        
        val elements = extractUIElements(parseXml(hierarchyXml))
        
        assertEquals(1, elements.size)
        assertEquals("Button", elements[0].text)
        assertEquals("btn_submit", elements[0].resourceId)
    }
}
```

### 9.2 Integration Tests

```kotlin
@Test
fun `should stream device screen via SSE`() = runBlocking {
    val mockDriver = MockDeviceDriver()
    startWebServer(8080, mockDriver)
    
    val client = HttpClient()
    val response = client.get("http://localhost:8080/api/device-screen/sse")
    
    assertEquals(HttpStatusCode.OK, response.status)
    assertEquals("text/event-stream", response.contentType?.contentType)
}
```

### 9.3 End-to-End Tests

```typescript
describe('Device Viewer', () => {
  it('should display device screen', async () => {
    render(<App />);
    
    // Wait for SSE connection
    await waitFor(() => {
      expect(screen.getByAltText('Device screen')).toBeInTheDocument();
    });
    
    // Check if screenshot is loaded
    const img = screen.getByAltText('Device screen') as HTMLImageElement;
    expect(img.src).toContain('/screenshot/');
  });
  
  it('should execute tap command', async () => {
    render(<App />);
    
    const deviceScreen = await screen.findByAltText('Device screen');
    fireEvent.click(deviceScreen, { clientX: 100, clientY: 200 });
    
    await waitFor(() => {
      // Verify command was sent
      expect(fetch).toHaveBeenCalledWith('/api/run-command', expect.any(Object));
    });
  });
});
```

---

## 10. Deployment & Distribution

### 10.1 Building the Application

```bash
#!/bin/bash
# build.sh

# Build backend
./gradlew clean build

# Build frontend
cd web
npm install
npm run build

# Package everything
mkdir -p dist
cp build/libs/server.jar dist/
cp -r web/dist dist/static

echo "Build complete! Package in dist/"
```

### 10.2 Running the Application

```bash
#!/bin/bash
# start.sh

# Check for connected devices
echo "Checking for devices..."

# Start the server
java -jar dist/server.jar \
  --port 8080 \
  --platform ios \
  --device-id "AUTO"

# Server will auto-open browser
```

### 10.3 Docker Deployment (Advanced)

```dockerfile
FROM openjdk:17-slim

# Install Android SDK (for Android support)
RUN apt-get update && apt-get install -y \
    android-sdk \
    adb

# Install Xcode CLI tools (for iOS support - macOS only)
# Note: iOS support requires macOS host

COPY dist/ /app/
WORKDIR /app

EXPOSE 8080

CMD ["java", "-jar", "server.jar", "--port", "8080"]
```

---

## 11. Interactive Preview & Smooth UX

### 11.1 Making the Preview Interactive

To guarantee that every click, tap, keyboard input, or gesture in the preview propagates back to the simulator, build a dedicated **interaction loop** that treats the browser as an input device rather than a passive viewer:

1. **Pointer capture & normalization** – Capture mouse/touch/pointer events on the preview canvas, translate them to normalized coordinates, and retain modifier state (pressure, button, multi-touch ids) so that the backend can reconstruct the gesture.
2. **Action bundler** – Wrap events into a `DeviceAction` payload (type, coords, timestamp, duration) and queue them locally so rapid gestures are never dropped. Use optimistic UI state (e.g., temporary ripple/highlight) so the user sees an immediate response before the real frame arrives.
3. **Low-latency transport** – Send the queued actions through a persistent channel (WebSocket or fetch keep-alive) to avoid the overhead of establishing new HTTP connections for every tap. Compress consecutive actions of the same type to cut chatter.
4. **Driver translation** – Backend converts each action into the platform-specific call (`driver.tap`, `driver.swipe`, `driver.dispatchMultiTouch`, `driver.typeText`). Maintain an acknowledgment so the frontend knows when to clear optimistic state or retry.
5. **Feedback loop** – Prioritize a screenshot capture immediately after an interaction is acknowledged. That ensures the next SSE/WebRTC frame reflects the latest device state.

Example frontend hook:

```typescript
const createAction = (type: 'tap' | 'swipe' | 'pinch', points: Point[]) => ({
  type,
  points: points.map(p => ({
    x: Math.round(p.x * deviceScreen.width),
    y: Math.round(p.y * deviceScreen.height)
  })),
  timestamp: Date.now()
});

const socket = new WebSocket('/api/device-actions');

const sendAction = (action: DeviceAction) => {
  actionQueue.enqueue(action);
  flushQueue();
};

const flushQueue = debounce(() => {
  if (socket.readyState === WebSocket.OPEN && !actionQueue.isEmpty()) {
    socket.send(JSON.stringify(actionQueue.drain()));
  }
}, 16);
```

Backend dispatcher:

```kotlin
data class DeviceAction(
    val type: ActionType,
    val points: List<Point>,
    val timestamp: Long,
    val meta: Map<String, Any?> = emptyMap()
)

suspend fun DeviceDriver.apply(action: DeviceAction) = when (action.type) {
    ActionType.TAP -> tap(action.points.first())
    ActionType.SWIPE -> swipe(action.points[0], action.points[1], durationMs = metaDuration(action))
    ActionType.LONG_PRESS -> longPress(action.points.first(), durationMs = metaDuration(action))
    ActionType.PINCH -> multiTouch(action.points, gesture = Gesture.PINCH)
    ActionType.TYPE -> inputText(metaText(action))
}

fun Routes.deviceActionRoutes(driver: DeviceDriver) {
    webSocket("/api/device-actions") {
        for (frame in incoming) {
            val payload = (frame as? Frame.Text)?.readText() ?: continue
            val actions = json.decodeFromString<List<DeviceAction>>(payload)
            actions.forEach { action ->
                driver.apply(action)
            }
            outgoing.send(Frame.Text("ack"))
        }
    }
}
```

This pattern keeps the preview surface fully interactive, supports compound gestures, and ensures the simulator reacts as soon as the browser emits the event.

### 11.2 Making the Preview Smoother

Smoothness is a mix of **frame cadence**, **transport latency**, and **rendering efficiency**. Combine the following tactics:

- **Incremental frame delivery** – Detect dirty regions on the device (using Android `PixelCopy` diffing or iOS `IOSurface`) and send only changed rectangles. Encode them with PNG8 or even H.264 over WebRTC for higher FPS when bandwidth allows, while falling back to SSE full-frame updates when the link is slow.
- **Adaptive capture budget** – Sample at 30 FPS when the device is actively changing (during gestures or animations) and drop to 5 FPS when idle to save CPU/GPU. A simple strategy is to boost the capture cadence for 2 seconds after every user action or view hierarchy change.
- **Double buffering & pre-fetch** – Keep two screenshot buffers on the backend. While buffer A is streamed, capture into buffer B. Swap atomically to avoid tearing and show the freshest frame even if the network momentarily stalls.
- **Client-side compositing** – Scale the bitmap using CSS transforms instead of re-rendering the `<img>` element. For overlays, draw on a `<canvas>` synchronized with `requestAnimationFrame` so hit-testing stays accurate even when the main screenshot is a frame behind.
- **Compression-level tuning** – Allow the frontend to negotiate desired quality (`?quality=0.7`) so low bandwidth sessions can trade resolution for smooth scrolling, while LAN sessions can request lossless frames.

Sample adaptive streaming loop:

```kotlin
suspend fun streamFrames(driver: DeviceDriver, sink: FrameSink) {
    var frameInterval = 100L
    while (sink.isConnected()) {
        val frameStart = System.nanoTime()
        val screenshot = driver.captureDeltaFrame(maxRegionCount = 4)
        sink.send(screenshot)
        frameInterval = when {
            screenshot.changedPixelsRatio > 0.3 -> 33L  // ~30 FPS during motion
            else -> 150L                              // conserve resources when static
        }
        val elapsed = (System.nanoTime() - frameStart) / 1_000_000
        delay((frameInterval - elapsed).coerceAtLeast(0))
    }
}
```

Pair that with front-end throttling (skip rendering if the previous frame is still decoding) and you get a preview that feels close to the native simulator window.

---

## Conclusion

This architecture provides a robust, scalable solution for browser-based mobile simulator viewing and control. The key innovations include:

1. **Platform abstraction** - Unified interface for iOS and Android
2. **Real-time streaming** - SSE for continuous device state updates
3. **Interactive UI** - Direct device control from browser
4. **Element inspection** - Comprehensive view hierarchy visualization
5. **Driver architecture** - Test frameworks repurposed as RPC servers

The system can be extended to support:
- Remote device access over network
- Multi-device simultaneous viewing
- Recording and playback
- AI-powered element detection
- Cloud deployment for team collaboration

This documentation provides everything needed to build a production-ready browser-based device viewer from scratch.


