# Clean Architecture Implementation

## Architecture Overview

This project implements Clean Architecture principles with the following layers:

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                       │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   UI Widgets    │  │   Controllers   │  │   Providers  │ │
│  │                 │  │                 │  │              │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│                     DOMAIN LAYER                           │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │    Entities     │  │   Use Cases     │  │ Repositories │ │
│  │                 │  │                 │  │ (Interfaces) │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│                      DATA LAYER                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Repositories   │  │  Data Sources   │  │   External   │ │
│  │ (Implementations)│  │                 │  │   Services   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Layer Responsibilities

### Domain Layer (Core Business Logic)
- **Entities**: Core business objects (WidgetTreeNode, WidgetDependency, etc.)
- **Use Cases**: Application-specific business rules
- **Repository Interfaces**: Contracts for data access
- **Value Objects**: Immutable objects representing concepts

### Data Layer (Infrastructure)
- **Repository Implementations**: Concrete implementations of domain repositories
- **Data Sources**: External data access (VM Service, File System, etc.)
- **Mappers**: Convert between domain and data models
- **External Services**: Third-party integrations

### Presentation Layer (UI)
- **Controllers**: Handle user interactions and coordinate with use cases
- **Providers**: State management and dependency injection
- **UI Widgets**: Pure presentation components
- **ViewModels**: Prepare data for UI consumption

## Dependency Flow

Dependencies flow inward:
- Presentation → Domain ← Data
- External dependencies are injected
- Domain layer has no dependencies on external frameworks

## Benefits

1. **Testability**: Easy to mock dependencies
2. **Maintainability**: Clear separation of concerns
3. **Flexibility**: Easy to swap implementations
4. **Scalability**: New features can be added without affecting existing code
5. **SOLID Compliance**: Follows all SOLID principles
