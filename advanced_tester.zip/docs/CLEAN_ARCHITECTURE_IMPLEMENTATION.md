# Clean Architecture Implementation

## Overview

This document describes the implementation of Clean Architecture principles in the Advanced Flutter Testing Framework. The refactoring addresses scalability, maintainability, and testability concerns by implementing proper separation of concerns and dependency inversion.

## Architecture Layers

### 1. Domain Layer (`lib/domain/`)

The domain layer contains the core business logic and is independent of external frameworks.

#### Entities (`lib/domain/entities/`)
- **WidgetEntity**: Core widget representation
- **DependencyEntity**: Widget dependency information
- **TestEntity**: Test case and generation models

#### Use Cases (`lib/domain/usecases/`)
- **GetWidgetTreeUseCase**: Retrieve widget tree from VM service
- **AnalyzeDependenciesUseCase**: Analyze widget dependencies
- **GenerateTestUseCase**: Generate test code for widgets
- **ComprehensiveWidgetAnalysisUseCase**: Perform complete widget analysis

#### Repository Interfaces (`lib/domain/repositories/`)
- **WidgetRepository**: Contract for widget operations
- **DependencyRepository**: Contract for dependency analysis
- **TestRepository**: Contract for test management
- **SourceCodeRepository**: Contract for source code analysis

### 2. Data Layer (`lib/data/`)

The data layer implements the domain interfaces and handles external data sources.

#### Data Sources (`lib/data/datasources/`)
- **VmServiceDataSource**: VM Service communication
- **FileSystemDataSource**: File system operations

#### Repository Implementations (`lib/data/repositories/`)
- **WidgetRepositoryImpl**: Concrete widget repository
- **DependencyRepositoryImpl**: Concrete dependency repository
- **TestRepositoryImpl**: Concrete test repository
- **SourceCodeRepositoryImpl**: Concrete source code repository

#### Mappers (`lib/data/mappers/`)
- **WidgetMapper**: Converts between data models and domain entities

### 3. Presentation Layer (`lib/presentation/`)

The presentation layer handles UI concerns and user interactions.

#### Controllers (`lib/presentation/controllers/`)
- **WidgetTreeController**: Manages widget tree operations
- **TestGenerationController**: Manages test generation operations

#### Providers (`lib/presentation/providers/`)
- **AppProvider**: Main application state management

### 4. Core Layer (`lib/core/`)

The core layer provides cross-cutting concerns.

#### Dependency Injection (`lib/core/di/`)
- **ServiceLocator**: Simple dependency injection container
- **DependencyInjection**: Configuration and registration

#### Services (`lib/core/services/`)
- **CleanArchitectureServiceManager**: Service coordination

## Key Benefits

### 1. Separation of Concerns
- **Domain**: Pure business logic, no external dependencies
- **Data**: Infrastructure concerns, external data access
- **Presentation**: UI logic, user interactions
- **Core**: Cross-cutting concerns, dependency injection

### 2. Dependency Inversion
- High-level modules don't depend on low-level modules
- Both depend on abstractions (interfaces)
- Dependencies are injected, not hard-coded

### 3. Testability
- Easy to mock dependencies using interfaces
- Unit tests can focus on business logic
- Integration tests can test specific layers

### 4. Maintainability
- Clear boundaries between layers
- Changes in one layer don't affect others
- Easy to add new features without breaking existing code

### 5. Scalability
- New features can be added as new use cases
- External services can be swapped easily
- Multiple implementations can coexist

## Implementation Details

### Dependency Injection

The framework uses a simple service locator pattern for dependency injection:

```dart
// Register services
serviceLocator.registerSingleton<WidgetRepository>(repository);
serviceLocator.registerFactory<UseCase>(() => UseCase(repository));

// Retrieve services
final repository = serviceLocator.get<WidgetRepository>();
final useCase = serviceLocator.get<UseCase>();
```

### Use Case Pattern

Each business operation is encapsulated in a use case:

```dart
class GetWidgetTreeUseCase {
  final WidgetRepository _repository;
  
  const GetWidgetTreeUseCase(this._repository);
  
  Future<WidgetEntity?> execute() async {
    if (!_repository.isConnected) {
      throw WidgetRepositoryException('Repository not connected');
    }
    return await _repository.getRootWidgetTree();
  }
}
```

### Repository Pattern

Repositories abstract data access:

```dart
abstract class WidgetRepository {
  Future<void> connect();
  Future<WidgetEntity?> getRootWidgetTree();
  Future<List<WidgetAttribute>?> getWidgetProperties(String objectId);
}
```

### Controller Pattern

Controllers manage UI state and coordinate with use cases:

```dart
class WidgetTreeController extends ChangeNotifier {
  final GetWidgetTreeUseCase _getWidgetTreeUseCase;
  
  Future<void> loadWidgetTree() async {
    _setLoading(true);
    try {
      _rootWidget = await _getWidgetTreeUseCase.execute();
      notifyListeners();
    } catch (e) {
      _setError('Failed to load widget tree: $e');
    } finally {
      _setLoading(false);
    }
  }
}
```

## Migration from Old Architecture

### Before (Tightly Coupled)
```dart
class InspectorService {
  vm.VmService? _service;
  
  Future<WidgetTreeNode?> getRootWidgetSummaryTree() async {
    // Direct VM service calls
    // Mixed business logic and data access
    // Hard to test
  }
}
```

### After (Clean Architecture)
```dart
// Domain
class GetWidgetTreeUseCase {
  final WidgetRepository _repository;
  Future<WidgetEntity?> execute() async { ... }
}

// Data
class WidgetRepositoryImpl implements WidgetRepository {
  final VmServiceDataSource _dataSource;
  Future<WidgetEntity?> getRootWidgetTree() async { ... }
}

// Presentation
class WidgetTreeController {
  final GetWidgetTreeUseCase _useCase;
  Future<void> loadWidgetTree() async { ... }
}
```

## Testing Strategy

### Unit Tests
- Test use cases with mocked repositories
- Test entities and value objects
- Test controllers with mocked use cases

### Integration Tests
- Test repository implementations with real data sources
- Test complete use case flows
- Test dependency injection configuration

### Example Test
```dart
test('should get widget tree successfully', () async {
  // Arrange
  final mockRepository = MockWidgetRepository();
  when(mockRepository.isConnected).thenReturn(true);
  when(mockRepository.getRootWidgetTree()).thenAnswer((_) async => expectedWidget);
  
  final useCase = GetWidgetTreeUseCase(mockRepository);
  
  // Act
  final result = await useCase.execute();
  
  // Assert
  expect(result, equals(expectedWidget));
  verify(mockRepository.getRootWidgetTree()).called(1);
});
```

## Configuration

### Dependency Injection Setup
```dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Configure dependency injection
  DependencyInjection.configure();
  
  // Initialize with VM service URI
  final appProvider = AppProvider();
  await appProvider.initialize('ws://localhost:8080');
  
  runApp(MyApp(appProvider: appProvider));
}
```

### Custom Configuration
```dart
// Configure with custom VM service URI
DependencyInjection.configureWithVmServiceUri(Uri.parse('ws://custom:8080'));

// Register custom implementations
serviceLocator.registerSingleton<WidgetRepository>(CustomWidgetRepository());
```

## Best Practices

### 1. Domain Layer
- Keep entities pure (no external dependencies)
- Use value objects for complex data
- Implement proper equality and hashCode
- Use immutable objects where possible

### 2. Data Layer
- Implement repository interfaces
- Use mappers to convert between layers
- Handle external service errors gracefully
- Implement proper caching strategies

### 3. Presentation Layer
- Keep controllers focused on UI state
- Use providers for dependency injection
- Handle loading and error states
- Implement proper disposal patterns

### 4. Core Layer
- Keep dependency injection simple
- Use interfaces for all dependencies
- Implement proper service lifecycle management
- Provide clear error handling

## Future Enhancements

### 1. Advanced Dependency Injection
- Consider using `get_it` or `injectable` packages
- Implement automatic dependency resolution
- Add dependency graph validation

### 2. CQRS Pattern
- Separate command and query responsibilities
- Implement event sourcing for state changes
- Add read and write model separation

### 3. Microservices Architecture
- Split into multiple services
- Implement service-to-service communication
- Add service discovery and load balancing

### 4. Advanced Testing
- Implement property-based testing
- Add mutation testing
- Implement contract testing between services

## Conclusion

The Clean Architecture implementation provides a solid foundation for scalable, maintainable, and testable code. The clear separation of concerns, dependency inversion, and proper abstraction layers make the codebase more robust and easier to work with.

The migration from the tightly coupled architecture to Clean Architecture addresses the original scalability concerns while maintaining all existing functionality. The new structure makes it easier to add new features, test the code, and maintain the application over time.
