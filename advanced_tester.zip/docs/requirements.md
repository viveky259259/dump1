# Advanced Testing framework for flutter apps
## Tech Stack

Flutter, Dart

## Abstract
This framework is an advanced testing framework for flutter apps. 

This framework inspires by the devtools of flutter speically inspector.This framework let's user select a widget from widget tree and write its testing. The framework does heavy work of finding out parent, identifying dependencies from widget tree , navigating to the widget and then generate the setup required for test. In the end user is able to write tests by selecting the widget under test, visually.

## How it works

1. User uploads the flutter project, or provide link to folder
2. The framework run the web app
3. The framework shows the app and widget tree side by side. 
4. The framework reuses the code from devtools of flutter, to enable user select a widget on widget tree of widget from UI that is running. The framework literally uses the code and implementation from devtools to start, find, inspect and interact from devtools.
5. Once use have selected a widget, a text field window opens up for him to write widget test.
6. Framework on the spot generates the requuired dependnecies needed for the widget.  then writes the setup which included navigating to the current page from the start of the app (e.g. splash> home> profile). User writes widget tests and click on save.
7. Frameworks saves in a new folder. 
8. On click of sync, framework adds these files in test folder of the flutter project

Flutter gihtub: github.com/flutter/flutter
Devtools github : github/com/flutter/devtools
