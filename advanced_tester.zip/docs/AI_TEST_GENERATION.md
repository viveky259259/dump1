# AI-Powered Test Generation

The Advanced Flutter Testing Framework now includes AI-powered test generation capabilities using OpenAI's GPT models. This feature automatically generates comprehensive, well-structured test files for Flutter widgets.

## Features

- **AI-Generated Tests**: Uses OpenAI GPT-4 to generate comprehensive test cases
- **Intelligent Analysis**: Analyzes widget properties, children, and dependencies
- **Fallback Generation**: Falls back to basic test generation if AI is unavailable
- **Multiple Test Cases**: Generates various test scenarios including edge cases
- **Best Practices**: Follows Flutter testing conventions and best practices

## Setup

### 1. OpenAI API Key

To use the AI test generation feature, you need an OpenAI API key:

1. Sign up for an OpenAI account at [https://platform.openai.com](https://platform.openai.com)
2. Generate an API key from your account dashboard
3. Set the API key using one of these methods:

#### Method 1: Environment Variable (Recommended)
```bash
export OPENAI_API_KEY="your-api-key-here"
flutter run --dart-define OPENAI_API_KEY="your-api-key-here"
```

#### Method 2: Direct Configuration
The API key can be configured in the ServiceManager configuration:

```dart
final serviceManager = ServiceManager(
  config: ServiceManagerConfig(
    openAIApiKey: 'your-api-key-here',
    projectPath: '/path/to/your/project',
  ),
);
```

### 2. Usage

The AI test generation is automatically used when you right-click on a widget in the widget tree and select "Generate Test". The system will:

1. Analyze the selected widget and its properties
2. Send widget information to OpenAI GPT-4
3. Generate comprehensive test cases
4. Create a test file in the appropriate location
5. Show success/failure notifications

## Generated Test Features

The AI-generated tests include:

### Basic Tests
- Widget rendering tests
- Widget tree structure validation
- Property verification

### Advanced Tests
- Interaction testing (taps, gestures)
- State change testing
- Error handling scenarios
- Accessibility testing
- Performance considerations

### Example Generated Test

```dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/widgets/my_widget.dart';

void main() {
  group('MyWidget Tests', () {
    testWidgets('should render MyWidget correctly', (WidgetTester tester) async {
      // Arrange
      await tester.pumpWidget(
        MaterialApp(
          home: MyWidget(
            title: 'Test Title',
            onPressed: () {},
          ),
        ),
      );

      // Act & Assert
      expect(find.byType(MyWidget), findsOneWidget);
      expect(find.text('Test Title'), findsOneWidget);
    });

    testWidgets('should handle button press correctly', (WidgetTester tester) async {
      // Arrange
      bool wasPressed = false;
      await tester.pumpWidget(
        MaterialApp(
          home: MyWidget(
            title: 'Test Title',
            onPressed: () => wasPressed = true,
          ),
        ),
      );

      // Act
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Assert
      expect(wasPressed, isTrue);
    });

    testWidgets('should display error state correctly', (WidgetTester tester) async {
      // Arrange
      await tester.pumpWidget(
        MaterialApp(
          home: MyWidget(
            title: '',
            onPressed: () {},
          ),
        ),
      );

      // Act & Assert
      expect(find.text('Error: Title cannot be empty'), findsOneWidget);
    });
  });
}
```

## Configuration Options

### ServiceManager Configuration

```dart
const ServiceManagerConfig(
  connectionTimeout: Duration(seconds: 30),
  requestTimeout: Duration(seconds: 10),
  maxRetries: 3,
  enableLogging: true,
  enableCaching: true,
  projectPath: '/path/to/project',
  openAIApiKey: 'your-api-key',
);
```

### AI Generation Parameters

The AI test generation uses these parameters:
- **Model**: GPT-4
- **Max Tokens**: 2000
- **Temperature**: 0.3 (for consistent, focused output)
- **System Prompt**: Expert Flutter developer specializing in widget testing

## Fallback Behavior

If the AI service is unavailable (no API key, network issues, etc.), the system automatically falls back to basic test generation that includes:

- Basic widget rendering tests
- Widget tree structure validation
- Simple property testing
- Child widget verification

## Best Practices

1. **Review Generated Tests**: Always review AI-generated tests before committing
2. **Customize Tests**: Modify generated tests to match your specific requirements
3. **Add Edge Cases**: Consider adding additional edge cases not covered by AI
4. **Test Coverage**: Use AI generation as a starting point, not the final solution
5. **API Key Security**: Never commit API keys to version control

## Troubleshooting

### Common Issues

1. **"No OpenAI API key provided"**
   - Solution: Set the OPENAI_API_KEY environment variable or configure it in ServiceManager

2. **"OpenAI API error: 401"**
   - Solution: Check that your API key is valid and has sufficient credits

3. **"OpenAI API error: 429"**
   - Solution: You've hit the rate limit. Wait a moment and try again

4. **"Network error"**
   - Solution: Check your internet connection and OpenAI API status

### Debug Mode

Enable debug logging to see detailed information about the AI generation process:

```dart
const ServiceManagerConfig(
  enableLogging: true,
  // ... other config
);
```

## Cost Considerations

- OpenAI API usage is charged per token
- GPT-4 is more expensive than GPT-3.5 but provides better results
- Typical test generation costs: $0.01-0.05 per widget
- Monitor your OpenAI usage dashboard for cost tracking

## Future Enhancements

Planned improvements include:

- Support for multiple AI providers (Claude, Gemini)
- Custom prompt templates
- Test generation preferences
- Integration with CI/CD pipelines
- Batch test generation for multiple widgets
- Custom test patterns and templates

## Support

For issues or questions about AI test generation:

1. Check the troubleshooting section above
2. Review the generated test files for patterns
3. Check OpenAI API status and your account limits
4. Enable debug logging for detailed error information
