# Widget Property Extraction Guide

## Overview
This guide shows how to extract specific property values from Flutter widgets using your enhanced Inspector Service. You can now get values like the string in Text widgets, width/height in SizedBox widgets, and many other widget parameters.

## 🎯 Main Methods

### 1. `getWidgetProperties(objectId, widgetType)`
**Purpose**: Get all properties for a widget  
**Returns**: `List<WidgetAttribute>`

```dart
// Get all properties for a SizedBox
final attributes = await inspectorService.getWidgetProperties(node.objectId!, 'SizedBox');
for (final attr in attributes) {
  print('${attr.name}: ${attr.label} (value: ${attr.value})');
}
// Output: width: 100.0 (value: 100.0)
//         height: 50.0 (value: 50.0)
```

### 2. `getWidgetPropertyValue(objectId, propertyName, widgetType)`
**Purpose**: Get a specific property value  
**Returns**: `dynamic` (the actual value)

```dart
// Get the text content from a Text widget
final text = await inspectorService.getWidgetPropertyValue(objectId, 'data', 'Text');
print('Text content: "$text"');

// Get SizedBox width
final width = await inspectorService.getWidgetPropertyValue(objectId, 'width', 'SizedBox');
print('Width: $width');
```

### 3. `getBatchWidgetProperties(nodes)`
**Purpose**: Get properties for multiple widgets at once  
**Returns**: `Map<String, List<WidgetAttribute>>`

```dart
final nodes = [node1, node2, node3];
final results = await inspectorService.getBatchWidgetProperties(nodes);

results.forEach((objectId, attributes) {
  print('Widget $objectId:');
  for (final attr in attributes) {
    print('  ${attr.name}: ${attr.value}');
  }
});
```

## 📋 Supported Widget Types & Properties

### **Text Widget**
```dart
final text = await getWidgetPropertyValue(objectId, 'data', 'Text');        // "Hello World"
final fontSize = await getWidgetPropertyValue(objectId, 'fontSize', 'Text'); // 16.0
final color = await getWidgetPropertyValue(objectId, 'color', 'Text');       // Color(0xFF000000)
```

### **SizedBox Widget**
```dart
final width = await getWidgetPropertyValue(objectId, 'width', 'SizedBox');    // 100.0
final height = await getWidgetPropertyValue(objectId, 'height', 'SizedBox');  // 50.0
final hasChild = await getWidgetPropertyValue(objectId, 'hasChild', 'SizedBox'); // true/false
```

### **Container Widget** 
```dart
final width = await getWidgetPropertyValue(objectId, 'width', 'Container');    // 200.0
final height = await getWidgetPropertyValue(objectId, 'height', 'Container');  // 150.0
final color = await getWidgetPropertyValue(objectId, 'color', 'Container');    // Color(0xFF0000FF)
final padding = await getWidgetPropertyValue(objectId, 'padding', 'Container'); // EdgeInsets.all(8.0)
final margin = await getWidgetPropertyValue(objectId, 'margin', 'Container');   // EdgeInsets.symmetric(...)
```

### **Icon Widget**
```dart
final icon = await getWidgetPropertyValue(objectId, 'icon', 'Icon');          // Icons.home
```

### **Image Widget**
```dart
final image = await getWidgetPropertyValue(objectId, 'image', 'Image');       // Asset: assets/logo.png
final width = await getWidgetPropertyValue(objectId, 'width', 'Image');       // 100.0  
final height = await getWidgetPropertyValue(objectId, 'height', 'Image');     // 100.0
final fit = await getWidgetPropertyValue(objectId, 'fit', 'Image');           // BoxFit.cover
```

### **Expanded/Flexible Widget**
```dart
final flex = await getWidgetPropertyValue(objectId, 'flex', 'Expanded');      // 2
final fit = await getWidgetPropertyValue(objectId, 'fit', 'Flexible');       // FlexFit.loose
```

### **Positioned Widget**
```dart
final left = await getWidgetPropertyValue(objectId, 'left', 'Positioned');    // 10.0
final top = await getWidgetPropertyValue(objectId, 'top', 'Positioned');      // 20.0
final width = await getWidgetPropertyValue(objectId, 'width', 'Positioned');  // 100.0
final height = await getWidgetPropertyValue(objectId, 'height', 'Positioned'); // 50.0
```

### **Padding Widget**
```dart
final padding = await getWidgetPropertyValue(objectId, 'padding', 'Padding'); // EdgeInsets.all(16.0)
```

## 🛠️ Practical Usage Examples

### Example 1: Extract Text from All Text Widgets
```dart
Future<List<String>> getAllTextContents() async {
  final texts = <String>[];
  final rootNode = await inspectorService.getRootWidgetSummaryTree();
  
  await _findTextsRecursively(rootNode, texts);
  return texts;
}

Future<void> _findTextsRecursively(WidgetTreeNode? node, List<String> texts) async {
  if (node == null) return;
  
  if (node.widgetRuntimeType?.toLowerCase().contains('text') == true && 
      node.objectId != null) {
    final text = await inspectorService.getWidgetPropertyValue(
      node.objectId!, 'data', 'Text'
    );
    if (text != null) texts.add(text.toString());
  }
  
  for (final child in node.children) {
    await _findTextsRecursively(child, texts);
  }
}
```

### Example 2: Analyze Layout Dimensions
```dart
Future<Map<String, Map<String, double>>> analyzeDimensions() async {
  final dimensions = <String, Map<String, double>>{};
  final rootNode = await inspectorService.getRootWidgetSummaryTree();
  
  await _analyzeDimensionsRecursively(rootNode, dimensions);
  return dimensions;
}

Future<void> _analyzeDimensionsRecursively(
  WidgetTreeNode? node, 
  Map<String, Map<String, double>> dimensions
) async {
  if (node == null || node.objectId == null) return;
  
  final widgetType = node.widgetRuntimeType?.toLowerCase() ?? '';
  
  if (widgetType.contains('sizedbox') || widgetType.contains('container')) {
    final width = await inspectorService.getWidgetPropertyValue(
      node.objectId!, 'width', node.widgetRuntimeType
    ) as double?;
    
    final height = await inspectorService.getWidgetPropertyValue(
      node.objectId!, 'height', node.widgetRuntimeType  
    ) as double?;
    
    if (width != null || height != null) {
      dimensions[node.objectId!] = {
        'width': width ?? 0.0,
        'height': height ?? 0.0,
      };
    }
  }
  
  for (final child in node.children) {
    await _analyzeDimensionsRecursively(child, dimensions);
  }
}
```

### Example 3: Generate Test Data
```dart
Future<Map<String, dynamic>> generateWidgetTestData(String objectId, String widgetType) async {
  final attributes = await inspectorService.getWidgetProperties(objectId, widgetType);
  final testData = <String, dynamic>{};
  
  for (final attr in attributes) {
    switch (attr.name) {
      case 'data':
        testData['expectedText'] = attr.value;
        break;
      case 'width':
        testData['expectedWidth'] = attr.value;
        break;  
      case 'height':
        testData['expectedHeight'] = attr.value;
        break;
      case 'color':
        testData['expectedColor'] = attr.value;
        break;
      default:
        testData[attr.name] = attr.value;
    }
  }
  
  return testData;
}

// Usage
final testData = await generateWidgetTestData('inspector-123', 'Text');
// Result: {'expectedText': 'Hello World'}

final sizeData = await generateWidgetTestData('inspector-456', 'SizedBox'); 
// Result: {'expectedWidth': 100.0, 'expectedHeight': 50.0}
```

## 🔧 Integration with Your Advanced Tester

You can use these methods in your advanced testing framework to:

### 1. **Automatic Test Generation**
```dart
class TestGenerator {
  Future<String> generateWidgetTest(WidgetTreeNode node) async {
    final widgetType = node.widgetRuntimeType!;
    final properties = await inspectorService.getWidgetProperties(
      node.objectId!, widgetType
    );
    
    final testCode = StringBuffer();
    testCode.writeln('testWidgets(\'$widgetType test\', (tester) async {');
    
    for (final prop in properties) {
      testCode.writeln('  // Verify ${prop.name}: ${prop.label}');
      testCode.writeln('  expect(widget.${prop.name}, equals(${prop.value}));');
    }
    
    testCode.writeln('});');
    return testCode.toString();
  }
}
```

### 2. **Widget Validation**
```dart
class WidgetValidator {
  Future<bool> validateTextWidget(String objectId, String expectedText) async {
    final actualText = await inspectorService.getWidgetPropertyValue(
      objectId, 'data', 'Text'
    );
    return actualText == expectedText;
  }
  
  Future<bool> validateSizedBox(String objectId, double expectedWidth, double expectedHeight) async {
    final width = await inspectorService.getWidgetPropertyValue(objectId, 'width', 'SizedBox');
    final height = await inspectorService.getWidgetPropertyValue(objectId, 'height', 'SizedBox');
    
    return width == expectedWidth && height == expectedHeight;
  }
}
```

### 3. **Property-Based Test Scenarios**
```dart
class PropertyBasedTesting {
  Future<void> testAllTextWidgets() async {
    final rootNode = await inspectorService.getRootWidgetSummaryTree();
    await _testTextWidgetsRecursively(rootNode);
  }
  
  Future<void> _testTextWidgetsRecursively(WidgetTreeNode? node) async {
    if (node?.widgetRuntimeType?.toLowerCase().contains('text') == true) {
      final text = await inspectorService.getWidgetPropertyValue(
        node!.objectId!, 'data', 'Text'
      );
      
      // Validate text properties
      assert(text != null, 'Text widget should have content');
      assert(text.toString().isNotEmpty, 'Text should not be empty');
    }
    
    for (final child in node?.children ?? []) {
      await _testTextWidgetsRecursively(child);
    }
  }
}
```

## 🎯 Tips for Best Results

1. **Use the correct widget type string** - The extraction depends on matching widget types
2. **Handle null values** - Properties might not exist for all widgets  
3. **Cache results** - The service automatically caches property values for performance
4. **Use batch operations** - For analyzing many widgets, use `getBatchWidgetProperties()`
5. **Check `node.widgetRuntimeType`** - This gives you the exact widget type for better matching

This enhanced property extraction system now gives you direct access to all widget parameter values, making it much easier to build comprehensive testing and analysis tools!
