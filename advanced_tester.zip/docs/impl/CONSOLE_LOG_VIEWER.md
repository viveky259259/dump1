# Console Log Viewer - Implementation Guide

## Overview

This document provides a comprehensive implementation for a Console Log Viewer that displays real-time logs from:
- **Device Logs**: Android logcat, iOS syslog
- **Flutter CLI**: `flutter run`, `flutter build`, `flutter test`
- **Dart Tools**: Analyzer, formatter, compiler
- **Hot Reload/Restart**: Development feedback
- **Flutter Debug Output**: print(), debugPrint(), log()

The implementation follows Clean Architecture and integrates with the existing device management system.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Domain Layer](#domain-layer)
3. [Data Layer](#data-layer)
4. [Core Services](#core-services)
5. [Flutter Process Service](#flutter-process-service)
6. [Presentation Layer](#presentation-layer)
7. [Integration](#integration)
8. [Testing](#testing)

---

## Architecture Overview

```
lib/
├── domain/
│   ├── entities/
│   │   ├── log_entry.dart          # Log entry with multi-source parsing
│   │   ├── log_level.dart          # Log levels + LogSource enum
│   │   └── log_filter.dart         # Filter configuration
│   ├── repositories/
│   │   └── log_repository.dart
│   └── usecases/
│       └── console/
│           ├── stream_logs_usecase.dart
│           ├── filter_logs_usecase.dart
│           ├── export_logs_usecase.dart
│           └── clear_logs_usecase.dart
├── data/
│   ├── datasources/
│   │   └── log_datasource.dart     # Device + Flutter CLI log streaming
│   └── repositories/
│       └── log_repository_impl.dart
├── core/
│   └── services/
│       ├── console_log_service.dart     # Log buffering & streaming
│       └── flutter_cli_service.dart     # Flutter run/build/test execution
└── presentation/
    ├── providers/
    │   └── console_log_provider.dart
    ├── controllers/
    │   ├── flutter_run_controller.dart    # Run session management
    │   └── flutter_build_controller.dart  # Build session management
    └── widgets/
        └── console/
            ├── console_log_panel.dart
            ├── log_entry_widget.dart
            ├── log_filter_bar.dart
            └── log_search_bar.dart
```

### Log Sources Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           Console Log Viewer                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  Device Logs │  │ Flutter Run  │  │Flutter Build │  │ Flutter Test │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
│         │                 │                 │                 │          │
│         ▼                 ▼                 ▼                 ▼          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │    logcat    │  │  run output  │  │ build output │  │ test output  │ │
│  │    syslog    │  │  hot reload  │  │   gradle     │  │  pass/fail   │ │
│  │   flutter:   │  │   devtools   │  │   xcode      │  │  coverage    │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
│         │                 │                 │                 │          │
│         └─────────────────┴────────┬────────┴─────────────────┘          │
│                                    │                                     │
│                                    ▼                                     │
│                         ┌────────────────────┐                           │
│                         │   LogEntry.auto    │  ← Auto-detect parser     │
│                         │     Detect()       │                           │
│                         └─────────┬──────────┘                           │
│                                   │                                      │
│                                   ▼                                      │
│                         ┌────────────────────┐                           │
│                         │ ConsoleLogService  │  ← Buffer + Stream        │
│                         └─────────┬──────────┘                           │
│                                   │                                      │
│                                   ▼                                      │
│                         ┌────────────────────┐                           │
│                         │ ConsoleLogProvider │  ← State management       │
│                         └─────────┬──────────┘                           │
│                                   │                                      │
│                                   ▼                                      │
│                         ┌────────────────────┐                           │
│                         │  ConsoleLogPanel   │  ← UI Rendering           │
│                         └────────────────────┘                           │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Domain Layer

### 1. Log Level Enum

**File: `lib/domain/entities/log_level.dart`**

```dart
import 'package:flutter/material.dart';

/// Log severity levels
enum LogLevel {
  verbose('V', 'Verbose', Colors.grey),
  debug('D', 'Debug', Colors.blue),
  info('I', 'Info', Colors.green),
  warning('W', 'Warning', Colors.orange),
  error('E', 'Error', Colors.red),
  fatal('F', 'Fatal', Colors.purple);

  final String shortName;
  final String displayName;
  final Color color;

  const LogLevel(this.shortName, this.displayName, this.color);

  /// Parse from Android logcat level character
  static LogLevel fromLogcat(String char) {
    return switch (char.toUpperCase()) {
      'V' => LogLevel.verbose,
      'D' => LogLevel.debug,
      'I' => LogLevel.info,
      'W' => LogLevel.warning,
      'E' => LogLevel.error,
      'F' || 'A' => LogLevel.fatal,
      _ => LogLevel.info,
    };
  }

  /// Parse from iOS/unified system log level
  static LogLevel fromSyslog(String level) {
    final lower = level.toLowerCase();
    if (lower.contains('debug')) return LogLevel.debug;
    if (lower.contains('info')) return LogLevel.info;
    if (lower.contains('notice')) return LogLevel.info;
    if (lower.contains('warn')) return LogLevel.warning;
    if (lower.contains('error')) return LogLevel.error;
    if (lower.contains('fault') || lower.contains('critical')) {
      return LogLevel.fatal;
    }
    return LogLevel.verbose;
  }

  /// Parse from Flutter CLI output
  static LogLevel fromFlutterCli(String line) {
    final lower = line.toLowerCase();
    
    // Build errors
    if (lower.contains('error:') || lower.contains('exception')) {
      return LogLevel.error;
    }
    // Compiler/analyzer warnings
    if (lower.contains('warning:') || lower.contains('hint:')) {
      return LogLevel.warning;
    }
    // Build success/completion
    if (lower.contains('built ') || lower.contains('✓')) {
      return LogLevel.info;
    }
    // Hot reload/restart
    if (lower.contains('reloaded') || lower.contains('restarted')) {
      return LogLevel.info;
    }
    // Debug messages
    if (lower.contains('flutter:') || lower.contains('debug')) {
      return LogLevel.debug;
    }
    // Build progress
    if (lower.contains('running') || lower.contains('building')) {
      return LogLevel.verbose;
    }
    
    return LogLevel.info;
  }

  /// Check if this level meets minimum threshold
  bool meetsThreshold(LogLevel minimum) {
    return index >= minimum.index;
  }

  /// Get icon for this level
  IconData get icon {
    return switch (this) {
      LogLevel.verbose => Icons.more_horiz,
      LogLevel.debug => Icons.bug_report,
      LogLevel.info => Icons.info_outline,
      LogLevel.warning => Icons.warning_amber,
      LogLevel.error => Icons.error_outline,
      LogLevel.fatal => Icons.dangerous,
    };
  }
}

/// Log source types
enum LogSource {
  logcat('Android Logcat'),
  syslog('iOS Syslog'),
  flutter('Flutter Debug'),
  flutterRun('Flutter Run'),
  flutterBuild('Flutter Build'),
  flutterTest('Flutter Test'),
  dartAnalyzer('Dart Analyzer'),
  hotReload('Hot Reload'),
  system('System');

  final String displayName;
  const LogSource(this.displayName);

  /// Get icon for this source
  IconData get icon {
    return switch (this) {
      LogSource.logcat => Icons.android,
      LogSource.syslog => Icons.apple,
      LogSource.flutter => Icons.flutter_dash,
      LogSource.flutterRun => Icons.play_arrow,
      LogSource.flutterBuild => Icons.build,
      LogSource.flutterTest => Icons.check_circle,
      LogSource.dartAnalyzer => Icons.analytics,
      LogSource.hotReload => Icons.refresh,
      LogSource.system => Icons.computer,
    };
  }

  /// Get color for this source
  Color get color {
    return switch (this) {
      LogSource.logcat => Colors.green,
      LogSource.syslog => Colors.grey,
      LogSource.flutter => Colors.blue,
      LogSource.flutterRun => Colors.cyan,
      LogSource.flutterBuild => Colors.orange,
      LogSource.flutterTest => Colors.purple,
      LogSource.dartAnalyzer => Colors.teal,
      LogSource.hotReload => Colors.amber,
      LogSource.system => Colors.blueGrey,
    };
  }
}
```

### 2. Log Entry Entity

**File: `lib/domain/entities/log_entry.dart`**

```dart
import 'package:flutter/foundation.dart';
import 'log_level.dart';

/// Represents a single log entry from a device
@immutable
class LogEntry {
  final String id;
  final DateTime timestamp;
  final LogLevel level;
  final String tag;
  final String message;
  final String? processId;
  final String? threadId;
  final String? source;
  final String raw;

  const LogEntry({
    required this.id,
    required this.timestamp,
    required this.level,
    required this.tag,
    required this.message,
    this.processId,
    this.threadId,
    this.source,
    required this.raw,
  });

  /// Parse Android logcat format
  /// Format: MM-DD HH:MM:SS.mmm PID TID LEVEL TAG: MESSAGE
  factory LogEntry.fromLogcat(String line, {String? id}) {
    final logcatPattern = RegExp(
      r'^(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+(\d+)\s+(\d+)\s+([VDIWEFA])\s+(\S+)\s*:\s*(.*)$',
    );

    final match = logcatPattern.firstMatch(line);
    if (match != null) {
      return LogEntry(
        id: id ?? _generateId(),
        timestamp: _parseLogcatTimestamp(match.group(1)!),
        processId: match.group(2),
        threadId: match.group(3),
        level: LogLevel.fromLogcat(match.group(4)!),
        tag: match.group(5)!,
        message: match.group(6)!,
        source: 'logcat',
        raw: line,
      );
    }

    // Fallback for non-standard format
    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: LogLevel.info,
      tag: '',
      message: line,
      source: 'logcat',
      raw: line,
    );
  }

  /// Parse iOS unified log format
  factory LogEntry.fromSyslog(String line, {String? id}) {
    // iOS log format: timestamp process[pid]: message
    final syslogPattern = RegExp(
      r'^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d+[+-]\d{4})\s+(\S+)\[(\d+)\]:\s*(?:\((\w+)\))?\s*(.*)$',
    );

    final match = syslogPattern.firstMatch(line);
    if (match != null) {
      final levelStr = match.group(4) ?? 'info';
      return LogEntry(
        id: id ?? _generateId(),
        timestamp: DateTime.tryParse(match.group(1)!) ?? DateTime.now(),
        level: LogLevel.fromSyslog(levelStr),
        tag: match.group(2)!,
        processId: match.group(3),
        message: match.group(5)!,
        source: 'syslog',
        raw: line,
      );
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: LogLevel.info,
      tag: '',
      message: line,
      source: 'syslog',
      raw: line,
    );
  }

  /// Parse Flutter debug print format
  factory LogEntry.fromFlutter(String line, {String? id}) {
    // Flutter format: [TAG] message or flutter: message
    final flutterPattern = RegExp(r'^(?:\[(\w+)\]\s*)?(?:flutter:\s*)?(.*)$');
    
    final match = flutterPattern.firstMatch(line);
    final tag = match?.group(1) ?? 'flutter';
    final message = match?.group(2) ?? line;
    
    // Detect log level from message content
    LogLevel level = LogLevel.info;
    if (message.toLowerCase().contains('error')) {
      level = LogLevel.error;
    } else if (message.toLowerCase().contains('warning')) {
      level = LogLevel.warning;
    } else if (message.toLowerCase().contains('debug')) {
      level = LogLevel.debug;
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
      source: 'flutter',
      raw: line,
    );
  }

  /// Parse Flutter Run output
  /// Handles: launch messages, hot reload, observatory URLs, etc.
  factory LogEntry.fromFlutterRun(String line, {String? id}) {
    final lower = line.toLowerCase();
    LogLevel level = LogLevel.info;
    String tag = 'flutter run';
    String message = line;

    // Hot reload/restart messages
    if (lower.contains('reloaded') || lower.contains('hot reload')) {
      level = LogLevel.info;
      tag = 'hot reload';
      // Extract reload time if present
      final timeMatch = RegExp(r'in (\d+)ms').firstMatch(line);
      if (timeMatch != null) {
        message = '🔄 Hot reload completed in ${timeMatch.group(1)}ms';
      }
    } else if (lower.contains('restarted') || lower.contains('hot restart')) {
      level = LogLevel.info;
      tag = 'hot restart';
      message = '🔃 Hot restart completed';
    }
    // Observatory/DevTools URL
    else if (lower.contains('observatory') || lower.contains('devtools')) {
      level = LogLevel.debug;
      tag = 'devtools';
      final urlMatch = RegExp(r'(https?://[^\s]+)').firstMatch(line);
      if (urlMatch != null) {
        message = '🔧 DevTools: ${urlMatch.group(1)}';
      }
    }
    // App launched
    else if (lower.contains('launching') || lower.contains('running')) {
      level = LogLevel.info;
      tag = 'launcher';
    }
    // Syncing files
    else if (lower.contains('syncing files')) {
      level = LogLevel.verbose;
      tag = 'sync';
    }
    // Errors
    else if (lower.contains('error') || lower.contains('exception')) {
      level = LogLevel.error;
      tag = 'error';
    }
    // Warnings
    else if (lower.contains('warning')) {
      level = LogLevel.warning;
      tag = 'warning';
    }
    // Flutter framework messages
    else if (line.startsWith('flutter:')) {
      level = LogLevel.debug;
      tag = 'flutter';
      message = line.substring(8).trim();
    }
    // I/flutter messages (Android)
    else if (line.contains('I/flutter')) {
      level = LogLevel.info;
      tag = 'flutter';
      final msgMatch = RegExp(r'I/flutter\s*\(\s*\d+\):\s*(.*)').firstMatch(line);
      if (msgMatch != null) {
        message = msgMatch.group(1) ?? line;
      }
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
      source: 'flutter_run',
      raw: line,
    );
  }

  /// Parse Flutter Build output
  /// Handles: compilation progress, errors, warnings, success messages
  factory LogEntry.fromFlutterBuild(String line, {String? id}) {
    final lower = line.toLowerCase();
    LogLevel level = LogLevel.info;
    String tag = 'build';
    String message = line;

    // Build started
    if (lower.contains('building') || lower.contains('compiling')) {
      level = LogLevel.verbose;
      tag = 'compiling';
    }
    // Build success
    else if (lower.contains('built ') && lower.contains('.apk')) {
      level = LogLevel.info;
      tag = 'success';
      message = '✅ APK built successfully';
      // Extract path
      final pathMatch = RegExp(r'built\s+([^\s]+\.apk)').firstMatch(lower);
      if (pathMatch != null) {
        message = '✅ Built: ${pathMatch.group(1)}';
      }
    }
    else if (lower.contains('built ') && lower.contains('.app')) {
      level = LogLevel.info;
      tag = 'success';
      message = '✅ iOS app built successfully';
    }
    else if (lower.contains('built ') && lower.contains('.ipa')) {
      level = LogLevel.info;
      tag = 'success';
      message = '✅ IPA built successfully';
    }
    // Build size info
    else if (lower.contains('mb') && (lower.contains('size') || lower.contains('built'))) {
      level = LogLevel.info;
      tag = 'size';
    }
    // Gradle/Xcode progress
    else if (lower.contains('gradle') || lower.contains('xcodebuild')) {
      level = LogLevel.verbose;
      tag = lower.contains('gradle') ? 'gradle' : 'xcode';
    }
    // Dependency resolution
    else if (lower.contains('resolving dependencies') || lower.contains('pub get')) {
      level = LogLevel.verbose;
      tag = 'dependencies';
    }
    // Build errors
    else if (lower.contains('error:') || lower.contains('failed')) {
      level = LogLevel.error;
      tag = 'error';
      // Extract file location
      final locMatch = RegExp(r'([\w/]+\.dart):(\d+):(\d+):').firstMatch(line);
      if (locMatch != null) {
        message = '${locMatch.group(1)}:${locMatch.group(2)} - ${line.split(':').last.trim()}';
      }
    }
    // Build warnings
    else if (lower.contains('warning:')) {
      level = LogLevel.warning;
      tag = 'warning';
    }
    // Asset bundling
    else if (lower.contains('asset') || lower.contains('bundling')) {
      level = LogLevel.verbose;
      tag = 'assets';
    }
    // Code signing (iOS)
    else if (lower.contains('signing') || lower.contains('provisioning')) {
      level = LogLevel.verbose;
      tag = 'signing';
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
      source: 'flutter_build',
      raw: line,
    );
  }

  /// Parse Flutter Test output
  factory LogEntry.fromFlutterTest(String line, {String? id}) {
    final lower = line.toLowerCase();
    LogLevel level = LogLevel.info;
    String tag = 'test';
    String message = line;

    // Test passed
    if (lower.contains('✓') || lower.contains('[+]') || 
        (lower.contains('passed') && !lower.contains('failed'))) {
      level = LogLevel.info;
      tag = 'passed';
      message = '✅ $line';
    }
    // Test failed
    else if (lower.contains('✗') || lower.contains('[-]') || lower.contains('failed')) {
      level = LogLevel.error;
      tag = 'failed';
      message = '❌ $line';
    }
    // Test skipped
    else if (lower.contains('skip') || lower.contains('[~]')) {
      level = LogLevel.warning;
      tag = 'skipped';
      message = '⏭️ $line';
    }
    // Test summary
    else if (lower.contains('all tests passed') || lower.contains('tests passed')) {
      level = LogLevel.info;
      tag = 'summary';
      message = '🎉 $line';
    }
    else if (lower.contains('some tests failed')) {
      level = LogLevel.error;
      tag = 'summary';
    }
    // Test group/description
    else if (line.startsWith('  ') && line.trim().isNotEmpty) {
      level = LogLevel.verbose;
      tag = 'running';
    }
    // Expect failures
    else if (lower.contains('expected:') || lower.contains('actual:')) {
      level = LogLevel.error;
      tag = 'assertion';
    }
    // Stack trace
    else if (line.startsWith('#') || lower.contains('stack trace')) {
      level = LogLevel.debug;
      tag = 'stacktrace';
    }
    // Test coverage
    else if (lower.contains('coverage') || lower.contains('%')) {
      level = LogLevel.info;
      tag = 'coverage';
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
      source: 'flutter_test',
      raw: line,
    );
  }

  /// Parse Dart Analyzer output
  factory LogEntry.fromDartAnalyzer(String line, {String? id}) {
    final lower = line.toLowerCase();
    LogLevel level = LogLevel.info;
    String tag = 'analyzer';
    String message = line;

    // Error
    if (lower.contains('error •') || lower.contains('error:')) {
      level = LogLevel.error;
      tag = 'error';
    }
    // Warning
    else if (lower.contains('warning •') || lower.contains('warning:')) {
      level = LogLevel.warning;
      tag = 'warning';
    }
    // Info/hint
    else if (lower.contains('info •') || lower.contains('hint:')) {
      level = LogLevel.info;
      tag = 'hint';
    }
    // Lint
    else if (lower.contains('lint •')) {
      level = LogLevel.warning;
      tag = 'lint';
    }
    // No issues
    else if (lower.contains('no issues found')) {
      level = LogLevel.info;
      tag = 'success';
      message = '✅ No issues found';
    }
    // Issue count summary
    else if (lower.contains('issue') && RegExp(r'\d+').hasMatch(line)) {
      level = lower.contains('error') ? LogLevel.error : LogLevel.warning;
      tag = 'summary';
    }
    // File location
    final locMatch = RegExp(r'([\w/]+\.dart):(\d+):(\d+)').firstMatch(line);
    if (locMatch != null) {
      tag = 'location';
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
      source: 'dart_analyzer',
      raw: line,
    );
  }

  /// Parse Hot Reload/Restart messages
  factory LogEntry.fromHotReload(String line, {String? id, bool isRestart = false}) {
    LogLevel level = LogLevel.info;
    String tag = isRestart ? 'hot restart' : 'hot reload';
    String message = line;

    final lower = line.toLowerCase();

    // Reload/restart success with timing
    final timeMatch = RegExp(r'(\d+)ms').firstMatch(line);
    if (timeMatch != null) {
      final ms = timeMatch.group(1);
      message = isRestart 
          ? '🔃 Hot restart in ${ms}ms'
          : '🔄 Hot reload in ${ms}ms';
    }
    // Reload rejected
    else if (lower.contains('rejected') || lower.contains('cannot')) {
      level = LogLevel.warning;
      message = '⚠️ Hot reload rejected - try hot restart';
    }
    // Files changed
    else if (lower.contains('file') && lower.contains('changed')) {
      level = LogLevel.verbose;
      tag = 'files';
    }
    // Reassembling
    else if (lower.contains('reassembling')) {
      level = LogLevel.verbose;
      tag = 'reassemble';
    }

    return LogEntry(
      id: id ?? _generateId(),
      timestamp: DateTime.now(),
      level: level,
      tag: tag,
      message: message,
      source: 'hot_reload',
      raw: line,
    );
  }

  /// Create a system message (not from device)
  factory LogEntry.system(String message) {
    return LogEntry(
      id: _generateId(),
      timestamp: DateTime.now(),
      level: LogLevel.info,
      tag: 'SYSTEM',
      message: message,
      source: 'system',
      raw: message,
    );
  }

  /// Auto-detect and parse log line based on content
  factory LogEntry.autoDetect(String line, {String? id, String? hint}) {
    // Use hint if provided
    if (hint != null) {
      switch (hint) {
        case 'flutter_run':
          return LogEntry.fromFlutterRun(line, id: id);
        case 'flutter_build':
          return LogEntry.fromFlutterBuild(line, id: id);
        case 'flutter_test':
          return LogEntry.fromFlutterTest(line, id: id);
        case 'dart_analyzer':
          return LogEntry.fromDartAnalyzer(line, id: id);
        case 'logcat':
          return LogEntry.fromLogcat(line, id: id);
        case 'syslog':
          return LogEntry.fromSyslog(line, id: id);
      }
    }

    // Auto-detect based on content
    final lower = line.toLowerCase();

    // Logcat format detection
    if (RegExp(r'^\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3}').hasMatch(line)) {
      return LogEntry.fromLogcat(line, id: id);
    }
    // iOS syslog format
    if (RegExp(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}').hasMatch(line)) {
      return LogEntry.fromSyslog(line, id: id);
    }
    // Flutter run specific
    if (lower.contains('hot reload') || lower.contains('reloaded') ||
        lower.contains('observatory') || lower.contains('devtools')) {
      return LogEntry.fromFlutterRun(line, id: id);
    }
    // Flutter build specific
    if (lower.contains('building') || lower.contains('built ') ||
        lower.contains('gradle') || lower.contains('xcodebuild')) {
      return LogEntry.fromFlutterBuild(line, id: id);
    }
    // Flutter test specific
    if (lower.contains('✓') || lower.contains('✗') ||
        lower.contains('passed') || lower.contains('test')) {
      return LogEntry.fromFlutterTest(line, id: id);
    }
    // Analyzer specific
    if (lower.contains('• ') || lower.contains('info •') ||
        lower.contains('warning •') || lower.contains('error •')) {
      return LogEntry.fromDartAnalyzer(line, id: id);
    }
    // Flutter debug output
    if (line.startsWith('flutter:') || line.contains('I/flutter')) {
      return LogEntry.fromFlutter(line, id: id);
    }

    // Default to Flutter
    return LogEntry.fromFlutter(line, id: id);
  }

  /// Format timestamp for display
  String get formattedTime {
    return '${timestamp.hour.toString().padLeft(2, '0')}:'
        '${timestamp.minute.toString().padLeft(2, '0')}:'
        '${timestamp.second.toString().padLeft(2, '0')}.'
        '${timestamp.millisecond.toString().padLeft(3, '0')}';
  }

  /// Format full timestamp
  String get formattedTimestamp {
    return '${timestamp.year}-'
        '${timestamp.month.toString().padLeft(2, '0')}-'
        '${timestamp.day.toString().padLeft(2, '0')} '
        '$formattedTime';
  }

  /// Check if entry matches search query
  bool matchesSearch(String query) {
    final lower = query.toLowerCase();
    return message.toLowerCase().contains(lower) ||
        tag.toLowerCase().contains(lower) ||
        (processId?.contains(query) ?? false);
  }

  /// Check if entry meets filter criteria
  bool matchesFilter(LogFilter filter) {
    // Check minimum level
    if (!level.meetsThreshold(filter.minLevel)) return false;

    // Check tag filter
    if (filter.tags.isNotEmpty && !filter.tags.contains(tag)) {
      return false;
    }

    // Check excluded tags
    if (filter.excludedTags.contains(tag)) return false;

    // Check search query
    if (filter.searchQuery != null && filter.searchQuery!.isNotEmpty) {
      if (!matchesSearch(filter.searchQuery!)) return false;
    }

    // Check process ID filter
    if (filter.processId != null && processId != filter.processId) {
      return false;
    }

    // Check time range
    if (filter.startTime != null && timestamp.isBefore(filter.startTime!)) {
      return false;
    }
    if (filter.endTime != null && timestamp.isAfter(filter.endTime!)) {
      return false;
    }

    return true;
  }

  LogEntry copyWith({
    String? id,
    DateTime? timestamp,
    LogLevel? level,
    String? tag,
    String? message,
    String? processId,
    String? threadId,
    String? source,
    String? raw,
  }) {
    return LogEntry(
      id: id ?? this.id,
      timestamp: timestamp ?? this.timestamp,
      level: level ?? this.level,
      tag: tag ?? this.tag,
      message: message ?? this.message,
      processId: processId ?? this.processId,
      threadId: threadId ?? this.threadId,
      source: source ?? this.source,
      raw: raw ?? this.raw,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'timestamp': timestamp.toIso8601String(),
        'level': level.name,
        'tag': tag,
        'message': message,
        'processId': processId,
        'threadId': threadId,
        'source': source,
        'raw': raw,
      };

  factory LogEntry.fromJson(Map<String, dynamic> json) => LogEntry(
        id: json['id'] as String,
        timestamp: DateTime.parse(json['timestamp'] as String),
        level: LogLevel.values.byName(json['level'] as String),
        tag: json['tag'] as String,
        message: json['message'] as String,
        processId: json['processId'] as String?,
        threadId: json['threadId'] as String?,
        source: json['source'] as String?,
        raw: json['raw'] as String,
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is LogEntry && other.id == id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => '[$level] $tag: $message';

  static DateTime _parseLogcatTimestamp(String ts) {
    try {
      final now = DateTime.now();
      final parts = ts.split(RegExp(r'[\s.:-]'));
      return DateTime(
        now.year,
        int.parse(parts[0]),
        int.parse(parts[1]),
        int.parse(parts[2]),
        int.parse(parts[3]),
        int.parse(parts[4]),
        int.parse(parts[5]),
      );
    } catch (_) {
      return DateTime.now();
    }
  }

  static int _idCounter = 0;
  static String _generateId() => 'log_${DateTime.now().microsecondsSinceEpoch}_${_idCounter++}';
}
```

### 3. Log Filter Entity

**File: `lib/domain/entities/log_filter.dart`**

```dart
import 'package:flutter/foundation.dart';
import 'log_level.dart';

/// Filter configuration for log entries
@immutable
class LogFilter {
  final LogLevel minLevel;
  final Set<String> tags;
  final Set<String> excludedTags;
  final String? searchQuery;
  final String? processId;
  final DateTime? startTime;
  final DateTime? endTime;
  final bool showTimestamp;
  final bool showTags;
  final bool showProcessInfo;

  const LogFilter({
    this.minLevel = LogLevel.verbose,
    this.tags = const {},
    this.excludedTags = const {},
    this.searchQuery,
    this.processId,
    this.startTime,
    this.endTime,
    this.showTimestamp = true,
    this.showTags = true,
    this.showProcessInfo = false,
  });

  /// Default filter showing all logs
  static const LogFilter all = LogFilter();

  /// Filter for errors only
  static const LogFilter errorsOnly = LogFilter(minLevel: LogLevel.error);

  /// Filter for warnings and above
  static const LogFilter warningsAndAbove = LogFilter(minLevel: LogLevel.warning);

  /// Create filter for specific package
  factory LogFilter.forPackage(String packageName) {
    return LogFilter(
      tags: {packageName},
      minLevel: LogLevel.verbose,
    );
  }

  LogFilter copyWith({
    LogLevel? minLevel,
    Set<String>? tags,
    Set<String>? excludedTags,
    String? searchQuery,
    String? processId,
    DateTime? startTime,
    DateTime? endTime,
    bool? showTimestamp,
    bool? showTags,
    bool? showProcessInfo,
  }) {
    return LogFilter(
      minLevel: minLevel ?? this.minLevel,
      tags: tags ?? this.tags,
      excludedTags: excludedTags ?? this.excludedTags,
      searchQuery: searchQuery ?? this.searchQuery,
      processId: processId ?? this.processId,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      showTimestamp: showTimestamp ?? this.showTimestamp,
      showTags: showTags ?? this.showTags,
      showProcessInfo: showProcessInfo ?? this.showProcessInfo,
    );
  }

  /// Clear search query
  LogFilter clearSearch() => copyWith(searchQuery: '');

  /// Clear all filters
  LogFilter clear() => const LogFilter();

  /// Check if any filter is active
  bool get isFiltering {
    return minLevel != LogLevel.verbose ||
        tags.isNotEmpty ||
        excludedTags.isNotEmpty ||
        (searchQuery != null && searchQuery!.isNotEmpty) ||
        processId != null ||
        startTime != null ||
        endTime != null;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LogFilter &&
          other.minLevel == minLevel &&
          setEquals(other.tags, tags) &&
          setEquals(other.excludedTags, excludedTags) &&
          other.searchQuery == searchQuery &&
          other.processId == processId;

  @override
  int get hashCode => Object.hash(
        minLevel,
        Object.hashAll(tags),
        Object.hashAll(excludedTags),
        searchQuery,
        processId,
      );
}
```

### 4. Log Repository Interface

**File: `lib/domain/repositories/log_repository.dart`**

```dart
import '../entities/log_entry.dart';
import '../entities/log_filter.dart';

/// Repository interface for log operations
abstract class LogRepository {
  /// Stream logs from device
  Stream<LogEntry> streamLogs(String deviceId, {LogFilter? filter});
  
  /// Get buffered logs
  List<LogEntry> getBufferedLogs(String deviceId);
  
  /// Clear log buffer
  Future<void> clearLogs(String deviceId);
  
  /// Export logs to file
  Future<String> exportLogs(
    String deviceId, {
    required String outputPath,
    LogFilter? filter,
    String format = 'txt',
  });
  
  /// Start log capture
  Future<void> startCapture(String deviceId);
  
  /// Stop log capture
  Future<void> stopCapture(String deviceId);
  
  /// Check if capture is active
  bool isCapturing(String deviceId);
  
  /// Get unique tags from logs
  Set<String> getUniqueTags(String deviceId);
  
  /// Search logs
  List<LogEntry> searchLogs(String deviceId, String query);
}
```

---

## Data Layer

### Log Datasource

**File: `lib/data/datasources/log_datasource.dart`**

```dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import '../../core/logging/logging.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_level.dart';

/// Datasource for fetching logs from devices
class LogDatasource with LoggerMixin {
  final Map<String, Process?> _logProcesses = {};
  final Map<String, StreamController<LogEntry>> _logControllers = {};
  final Map<String, List<LogEntry>> _logBuffers = {};
  
  static const int _maxBufferSize = 10000;

  /// Stream Android logcat logs
  Stream<LogEntry> streamAndroidLogs(
    String deviceId, {
    String? adbPath,
    String? packageFilter,
    LogLevel? minLevel,
  }) async* {
    final adb = adbPath ?? 'adb';
    
    // Build logcat command
    final args = ['-s', deviceId, 'logcat', '-v', 'threadtime'];
    
    if (packageFilter != null) {
      args.addAll(['--pid', await _getPackagePid(deviceId, packageFilter, adb)]);
    }

    logger.info('Starting logcat stream', {'deviceId': deviceId});

    final process = await Process.start(adb, args);
    _logProcesses[deviceId] = process;
    
    // Initialize buffer
    _logBuffers.putIfAbsent(deviceId, () => []);

    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = LogEntry.fromLogcat(line);
        
        // Apply minimum level filter
        if (minLevel != null && !entry.level.meetsThreshold(minLevel)) {
          continue;
        }
        
        // Add to buffer
        _addToBuffer(deviceId, entry);
        
        yield entry;
      }
    }

    // Handle process errors
    process.stderr.transform(utf8.decoder).listen((error) {
      logger.error('Logcat error', error);
    });

    await process.exitCode;
    _logProcesses.remove(deviceId);
    logger.info('Logcat stream ended', {'deviceId': deviceId});
  }

  /// Stream iOS simulator logs
  Stream<LogEntry> streamIOSLogs(
    String deviceId, {
    String? bundleId,
    LogLevel? minLevel,
  }) async* {
    final args = ['simctl', 'spawn', deviceId, 'log', 'stream', '--style', 'compact'];
    
    if (bundleId != null) {
      args.addAll(['--predicate', 'subsystem == "$bundleId"']);
    }

    logger.info('Starting iOS log stream', {'deviceId': deviceId});

    final process = await Process.start('xcrun', args);
    _logProcesses[deviceId] = process;
    _logBuffers.putIfAbsent(deviceId, () => []);

    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = LogEntry.fromSyslog(line);
        
        if (minLevel != null && !entry.level.meetsThreshold(minLevel)) {
          continue;
        }
        
        _addToBuffer(deviceId, entry);
        yield entry;
      }
    }

    await process.exitCode;
    _logProcesses.remove(deviceId);
    logger.info('iOS log stream ended', {'deviceId': deviceId});
  }

  /// Stream Flutter debug logs via VM Service
  Stream<LogEntry> streamFlutterLogs(String vmServiceUri) async* {
    // This would connect to Flutter's VM Service for debug output
    // Implementation depends on vm_service package
    logger.info('Starting Flutter log stream', {'uri': vmServiceUri});
    
    // Placeholder - actual implementation would use vm_service
    yield LogEntry.system('Flutter log stream started');
  }

  /// Stream Flutter run output
  Stream<LogEntry> streamFlutterRun({
    required String projectPath,
    String? deviceId,
    String? flutterPath,
    bool release = false,
    bool profile = false,
  }) async* {
    final flutter = flutterPath ?? 'flutter';
    final args = ['run', '--verbose'];
    
    if (deviceId != null) args.addAll(['-d', deviceId]);
    if (release) args.add('--release');
    if (profile) args.add('--profile');

    logger.info('Starting flutter run', {
      'projectPath': projectPath,
      'deviceId': deviceId,
    });

    yield LogEntry.system('🚀 Starting flutter run...');

    final process = await Process.start(
      flutter, 
      args,
      workingDirectory: projectPath,
    );
    _logProcesses['flutter_run'] = process;
    _logBuffers.putIfAbsent('flutter_run', () => []);

    // Stream stdout
    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = LogEntry.fromFlutterRun(line);
        _addToBuffer('flutter_run', entry);
        yield entry;
      }
    }

    // Handle stderr
    process.stderr.transform(utf8.decoder).listen((chunk) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        final entry = LogEntry.fromFlutterRun(line).copyWith(
          level: LogLevel.error,
        );
        _addToBuffer('flutter_run', entry);
      }
    });

    final exitCode = await process.exitCode;
    yield LogEntry.system(
      exitCode == 0 
          ? '✅ Flutter run completed' 
          : '❌ Flutter run failed (exit: $exitCode)'
    );
    
    _logProcesses.remove('flutter_run');
  }

  /// Stream Flutter build output
  Stream<LogEntry> streamFlutterBuild({
    required String projectPath,
    required String target, // apk, ios, web, etc.
    String? flutterPath,
    bool release = true,
  }) async* {
    final flutter = flutterPath ?? 'flutter';
    final args = ['build', target, '--verbose'];
    
    if (release) args.add('--release');

    logger.info('Starting flutter build', {
      'projectPath': projectPath,
      'target': target,
    });

    yield LogEntry.system('🔨 Building $target...');

    final stopwatch = Stopwatch()..start();

    final process = await Process.start(
      flutter, 
      args,
      workingDirectory: projectPath,
    );
    _logProcesses['flutter_build'] = process;
    _logBuffers.putIfAbsent('flutter_build', () => []);

    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = LogEntry.fromFlutterBuild(line);
        _addToBuffer('flutter_build', entry);
        yield entry;
      }
    }

    process.stderr.transform(utf8.decoder).listen((chunk) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        final entry = LogEntry.fromFlutterBuild(line).copyWith(
          level: LogLevel.error,
        );
        _addToBuffer('flutter_build', entry);
      }
    });

    final exitCode = await process.exitCode;
    stopwatch.stop();
    
    yield LogEntry.system(
      exitCode == 0 
          ? '✅ Build completed in ${stopwatch.elapsed.inSeconds}s' 
          : '❌ Build failed (exit: $exitCode)'
    );
    
    _logProcesses.remove('flutter_build');
  }

  /// Stream Flutter test output
  Stream<LogEntry> streamFlutterTest({
    required String projectPath,
    String? testPath,
    String? flutterPath,
    bool coverage = false,
  }) async* {
    final flutter = flutterPath ?? 'flutter';
    final args = ['test'];
    
    if (testPath != null) args.add(testPath);
    if (coverage) args.add('--coverage');
    args.add('--reporter=expanded'); // For better output

    logger.info('Starting flutter test', {'projectPath': projectPath});

    yield LogEntry.system('🧪 Running tests...');

    final process = await Process.start(
      flutter, 
      args,
      workingDirectory: projectPath,
    );
    _logProcesses['flutter_test'] = process;
    _logBuffers.putIfAbsent('flutter_test', () => []);

    int passed = 0;
    int failed = 0;
    int skipped = 0;

    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = LogEntry.fromFlutterTest(line);
        _addToBuffer('flutter_test', entry);
        
        // Track test results
        if (entry.tag == 'passed') passed++;
        if (entry.tag == 'failed') failed++;
        if (entry.tag == 'skipped') skipped++;
        
        yield entry;
      }
    }

    process.stderr.transform(utf8.decoder).listen((chunk) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        final entry = LogEntry.fromFlutterTest(line).copyWith(
          level: LogLevel.error,
        );
        _addToBuffer('flutter_test', entry);
      }
    });

    final exitCode = await process.exitCode;
    
    yield LogEntry.system(
      '📊 Tests complete: $passed passed, $failed failed, $skipped skipped'
    );
    yield LogEntry.system(
      exitCode == 0 
          ? '✅ All tests passed!' 
          : '❌ Some tests failed'
    );
    
    _logProcesses.remove('flutter_test');
  }

  /// Stream Dart analyzer output
  Stream<LogEntry> streamDartAnalyzer({
    required String projectPath,
    String? flutterPath,
  }) async* {
    final flutter = flutterPath ?? 'flutter';

    logger.info('Running dart analyze', {'projectPath': projectPath});

    yield LogEntry.system('🔍 Analyzing project...');

    final process = await Process.start(
      flutter, 
      ['analyze'],
      workingDirectory: projectPath,
    );
    _logProcesses['dart_analyze'] = process;
    _logBuffers.putIfAbsent('dart_analyze', () => []);

    int errorCount = 0;
    int warningCount = 0;
    int infoCount = 0;

    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = LogEntry.fromDartAnalyzer(line);
        _addToBuffer('dart_analyze', entry);
        
        // Track issue counts
        if (entry.level == LogLevel.error) errorCount++;
        if (entry.level == LogLevel.warning) warningCount++;
        if (entry.tag == 'hint') infoCount++;
        
        yield entry;
      }
    }

    final exitCode = await process.exitCode;
    
    yield LogEntry.system(
      '📊 Analysis: $errorCount errors, $warningCount warnings, $infoCount hints'
    );
    yield LogEntry.system(
      exitCode == 0 
          ? '✅ No critical issues found' 
          : '⚠️ Issues detected'
    );
    
    _logProcesses.remove('dart_analyze');
  }

  /// Send hot reload signal to flutter run process
  void triggerHotReload() {
    final process = _logProcesses['flutter_run'];
    if (process != null) {
      process.stdin.writeln('r');
      logger.info('Triggered hot reload');
    }
  }

  /// Send hot restart signal to flutter run process
  void triggerHotRestart() {
    final process = _logProcesses['flutter_run'];
    if (process != null) {
      process.stdin.writeln('R');
      logger.info('Triggered hot restart');
    }
  }

  /// Get available Flutter devices
  Future<List<Map<String, dynamic>>> getFlutterDevices({
    String? flutterPath,
  }) async {
    final flutter = flutterPath ?? 'flutter';
    
    final result = await Process.run(
      flutter,
      ['devices', '--machine'],
      stdoutEncoding: utf8,
    );

    if (result.exitCode != 0) return [];

    try {
      final List<dynamic> devices = jsonDecode(result.stdout as String);
      return devices.cast<Map<String, dynamic>>();
    } catch (e) {
      logger.error('Failed to parse devices', e);
      return [];
    }
  }

  /// Stop log capture for device
  Future<void> stopCapture(String deviceId) async {
    final process = _logProcesses.remove(deviceId);
    if (process != null) {
      process.kill();
      logger.info('Stopped log capture', {'deviceId': deviceId});
    }
  }

  /// Get buffered logs
  List<LogEntry> getBufferedLogs(String deviceId) {
    return List.unmodifiable(_logBuffers[deviceId] ?? []);
  }

  /// Clear log buffer
  void clearBuffer(String deviceId) {
    _logBuffers[deviceId]?.clear();
    logger.debug('Cleared log buffer', {'deviceId': deviceId});
  }

  /// Check if capturing logs
  bool isCapturing(String deviceId) {
    return _logProcesses.containsKey(deviceId);
  }

  /// Export logs to file
  Future<String> exportLogs(
    String deviceId,
    String outputPath, {
    String format = 'txt',
  }) async {
    final logs = getBufferedLogs(deviceId);
    final file = File(outputPath);
    
    await file.parent.create(recursive: true);
    
    String content;
    switch (format) {
      case 'json':
        content = jsonEncode(logs.map((e) => e.toJson()).toList());
        break;
      case 'csv':
        content = _formatAsCsv(logs);
        break;
      default:
        content = logs.map((e) => e.raw).join('\n');
    }
    
    await file.writeAsString(content);
    logger.info('Exported logs', {'path': outputPath, 'count': logs.length});
    
    return outputPath;
  }

  /// Get unique tags from buffer
  Set<String> getUniqueTags(String deviceId) {
    final logs = _logBuffers[deviceId] ?? [];
    return logs.map((e) => e.tag).where((t) => t.isNotEmpty).toSet();
  }

  /// Dispose resources
  void dispose() {
    for (final process in _logProcesses.values) {
      process?.kill();
    }
    _logProcesses.clear();
    _logBuffers.clear();
    
    for (final controller in _logControllers.values) {
      controller.close();
    }
    _logControllers.clear();
  }

  void _addToBuffer(String deviceId, LogEntry entry) {
    final buffer = _logBuffers[deviceId]!;
    buffer.add(entry);
    
    // Trim buffer if too large
    if (buffer.length > _maxBufferSize) {
      buffer.removeRange(0, buffer.length - _maxBufferSize);
    }
  }

  Future<String> _getPackagePid(String deviceId, String packageName, String adb) async {
    final result = await Process.run(
      adb,
      ['-s', deviceId, 'shell', 'pidof', packageName],
    );
    return (result.stdout as String).trim();
  }

  String _formatAsCsv(List<LogEntry> logs) {
    final buffer = StringBuffer();
    buffer.writeln('timestamp,level,tag,process_id,thread_id,message');
    
    for (final log in logs) {
      final escapedMessage = log.message.replaceAll('"', '""');
      buffer.writeln(
        '${log.formattedTimestamp},${log.level.shortName},${log.tag},'
        '${log.processId ?? ""},${log.threadId ?? ""},"$escapedMessage"'
      );
    }
    
    return buffer.toString();
  }
}
```

### Log Repository Implementation

**File: `lib/data/repositories/log_repository_impl.dart`**

```dart
import 'dart:async';

import '../../core/logging/logging.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_filter.dart';
import '../../domain/repositories/log_repository.dart';
import '../datasources/log_datasource.dart';

/// Implementation of LogRepository
class LogRepositoryImpl with LoggerMixin implements LogRepository {
  final LogDatasource _datasource;
  final String? _adbPath;

  LogRepositoryImpl({
    required LogDatasource datasource,
    String? adbPath,
  })  : _datasource = datasource,
        _adbPath = adbPath;

  @override
  Stream<LogEntry> streamLogs(String deviceId, {LogFilter? filter}) async* {
    final effectiveFilter = filter ?? const LogFilter();
    
    // Determine device type and stream appropriate logs
    // For now, assume Android - would check device type in real implementation
    await for (final entry in _datasource.streamAndroidLogs(
      deviceId,
      adbPath: _adbPath,
      minLevel: effectiveFilter.minLevel,
    )) {
      if (entry.matchesFilter(effectiveFilter)) {
        yield entry;
      }
    }
  }

  @override
  List<LogEntry> getBufferedLogs(String deviceId) {
    return _datasource.getBufferedLogs(deviceId);
  }

  @override
  Future<void> clearLogs(String deviceId) async {
    _datasource.clearBuffer(deviceId);
    
    // Also clear device logcat
    try {
      await Process.run(_adbPath ?? 'adb', ['-s', deviceId, 'logcat', '-c']);
    } catch (e) {
      logger.warn('Failed to clear device logs', {'error': e.toString()});
    }
  }

  @override
  Future<String> exportLogs(
    String deviceId, {
    required String outputPath,
    LogFilter? filter,
    String format = 'txt',
  }) async {
    return await _datasource.exportLogs(deviceId, outputPath, format: format);
  }

  @override
  Future<void> startCapture(String deviceId) async {
    if (_datasource.isCapturing(deviceId)) return;
    
    // Start streaming in background
    _datasource.streamAndroidLogs(deviceId, adbPath: _adbPath).listen(
      (_) {},
      onError: (e) => logger.error('Log capture error', e),
    );
  }

  @override
  Future<void> stopCapture(String deviceId) async {
    await _datasource.stopCapture(deviceId);
  }

  @override
  bool isCapturing(String deviceId) {
    return _datasource.isCapturing(deviceId);
  }

  @override
  Set<String> getUniqueTags(String deviceId) {
    return _datasource.getUniqueTags(deviceId);
  }

  @override
  List<LogEntry> searchLogs(String deviceId, String query) {
    final logs = getBufferedLogs(deviceId);
    return logs.where((log) => log.matchesSearch(query)).toList();
  }
}
```

---

## Core Services

### Console Log Service

**File: `lib/core/services/console_log_service.dart`**

```dart
import 'dart:async';
import 'dart:collection';

import '../logging/logging.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_filter.dart';
import '../../domain/entities/log_level.dart';

/// Service for managing console log streams
class ConsoleLogService with LoggerMixin {
  final Map<String, StreamController<LogEntry>> _controllers = {};
  final Map<String, Queue<LogEntry>> _buffers = {};
  final Map<String, StreamSubscription> _subscriptions = {};
  
  static const int defaultBufferSize = 5000;
  int bufferSize;

  ConsoleLogService({this.bufferSize = defaultBufferSize});

  /// Get or create a log stream for a device
  Stream<LogEntry> getLogStream(String deviceId) {
    _controllers.putIfAbsent(
      deviceId,
      () => StreamController<LogEntry>.broadcast(),
    );
    return _controllers[deviceId]!.stream;
  }

  /// Add a log entry to the stream
  void addLogEntry(String deviceId, LogEntry entry) {
    // Add to buffer
    _buffers.putIfAbsent(deviceId, () => Queue<LogEntry>());
    final buffer = _buffers[deviceId]!;
    buffer.add(entry);
    
    // Trim buffer
    while (buffer.length > bufferSize) {
      buffer.removeFirst();
    }
    
    // Emit to stream
    final controller = _controllers[deviceId];
    if (controller != null && !controller.isClosed) {
      controller.add(entry);
    }
  }

  /// Get buffered logs
  List<LogEntry> getBuffer(String deviceId) {
    return _buffers[deviceId]?.toList() ?? [];
  }

  /// Get filtered logs from buffer
  List<LogEntry> getFilteredLogs(String deviceId, LogFilter filter) {
    final buffer = _buffers[deviceId];
    if (buffer == null) return [];
    
    return buffer.where((log) => log.matchesFilter(filter)).toList();
  }

  /// Clear buffer for device
  void clearBuffer(String deviceId) {
    _buffers[deviceId]?.clear();
    
    // Emit system message
    addLogEntry(deviceId, LogEntry.system('Console cleared'));
  }

  /// Get log statistics
  LogStatistics getStatistics(String deviceId) {
    final buffer = _buffers[deviceId]?.toList() ?? [];
    
    final levelCounts = <LogLevel, int>{};
    final tagCounts = <String, int>{};
    
    for (final log in buffer) {
      levelCounts[log.level] = (levelCounts[log.level] ?? 0) + 1;
      if (log.tag.isNotEmpty) {
        tagCounts[log.tag] = (tagCounts[log.tag] ?? 0) + 1;
      }
    }
    
    return LogStatistics(
      totalCount: buffer.length,
      levelCounts: levelCounts,
      tagCounts: tagCounts,
      oldestEntry: buffer.isNotEmpty ? buffer.first.timestamp : null,
      newestEntry: buffer.isNotEmpty ? buffer.last.timestamp : null,
    );
  }

  /// Subscribe to external log source
  void subscribeToSource(
    String deviceId,
    Stream<LogEntry> source,
  ) {
    // Cancel existing subscription
    _subscriptions[deviceId]?.cancel();
    
    _subscriptions[deviceId] = source.listen(
      (entry) => addLogEntry(deviceId, entry),
      onError: (e) => logger.error('Log source error', e),
    );
  }

  /// Unsubscribe from log source
  void unsubscribeFromSource(String deviceId) {
    _subscriptions[deviceId]?.cancel();
    _subscriptions.remove(deviceId);
  }

  /// Dispose resources for a device
  void disposeDevice(String deviceId) {
    _subscriptions[deviceId]?.cancel();
    _subscriptions.remove(deviceId);
    
    _controllers[deviceId]?.close();
    _controllers.remove(deviceId);
    
    _buffers.remove(deviceId);
  }

  /// Dispose all resources
  void dispose() {
    for (final sub in _subscriptions.values) {
      sub.cancel();
    }
    _subscriptions.clear();
    
    for (final controller in _controllers.values) {
      controller.close();
    }
    _controllers.clear();
    
    _buffers.clear();
  }
}

/// Statistics about logs
class LogStatistics {
  final int totalCount;
  final Map<LogLevel, int> levelCounts;
  final Map<String, int> tagCounts;
  final DateTime? oldestEntry;
  final DateTime? newestEntry;

  const LogStatistics({
    required this.totalCount,
    required this.levelCounts,
    required this.tagCounts,
    this.oldestEntry,
    this.newestEntry,
  });

  int get errorCount => levelCounts[LogLevel.error] ?? 0;
  int get warningCount => levelCounts[LogLevel.warning] ?? 0;
  
  Duration? get timeSpan {
    if (oldestEntry == null || newestEntry == null) return null;
    return newestEntry!.difference(oldestEntry!);
  }
}
```

---

## 5. Flutter Process Service

### Flutter CLI Service

**File: `lib/core/services/flutter_cli_service.dart`**

```dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import '../logging/logging.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_level.dart';

/// Result of a Flutter command execution
class FlutterCommandResult {
  final int exitCode;
  final List<LogEntry> logs;
  final Duration duration;
  final bool success;

  FlutterCommandResult({
    required this.exitCode,
    required this.logs,
    required this.duration,
  }) : success = exitCode == 0;

  int get errorCount => logs.where((l) => l.level == LogLevel.error).length;
  int get warningCount => logs.where((l) => l.level == LogLevel.warning).length;
}

/// Service for running Flutter CLI commands and capturing output
class FlutterCliService with LoggerMixin {
  String? _flutterPath;
  final Map<String, Process> _runningProcesses = {};
  final Map<String, StreamController<LogEntry>> _logControllers = {};

  FlutterCliService({String? flutterPath}) : _flutterPath = flutterPath;

  /// Get Flutter executable path
  Future<String> get flutterPath async {
    if (_flutterPath != null) return _flutterPath!;
    _flutterPath = await _detectFlutterPath();
    return _flutterPath!;
  }

  /// Run `flutter run` and stream logs
  Stream<LogEntry> runApp({
    required String projectPath,
    String? deviceId,
    bool release = false,
    bool profile = false,
    List<String> additionalArgs = const [],
  }) async* {
    final args = ['run'];
    
    if (deviceId != null) args.addAll(['-d', deviceId]);
    if (release) args.add('--release');
    if (profile) args.add('--profile');
    args.addAll(additionalArgs);

    yield LogEntry.system('🚀 Starting flutter run...');

    await for (final entry in _runFlutterCommand(
      args,
      projectPath: projectPath,
      processId: 'flutter_run',
      parser: LogEntry.fromFlutterRun,
    )) {
      yield entry;
    }
  }

  /// Run `flutter build` and stream logs
  Stream<LogEntry> buildApp({
    required String projectPath,
    required String target, // apk, appbundle, ios, ipa, web, macos, windows, linux
    bool release = true,
    List<String> additionalArgs = const [],
  }) async* {
    final args = ['build', target];
    
    if (release) args.add('--release');
    args.addAll(additionalArgs);

    yield LogEntry.system('🔨 Starting flutter build $target...');

    await for (final entry in _runFlutterCommand(
      args,
      projectPath: projectPath,
      processId: 'flutter_build',
      parser: LogEntry.fromFlutterBuild,
    )) {
      yield entry;
    }
  }

  /// Run `flutter test` and stream logs
  Stream<LogEntry> runTests({
    required String projectPath,
    String? testPath,
    bool coverage = false,
    String? reporter, // compact, expanded, json
    List<String> additionalArgs = const [],
  }) async* {
    final args = ['test'];
    
    if (testPath != null) args.add(testPath);
    if (coverage) args.add('--coverage');
    if (reporter != null) args.addAll(['--reporter', reporter]);
    args.addAll(additionalArgs);

    yield LogEntry.system('🧪 Starting flutter test...');

    await for (final entry in _runFlutterCommand(
      args,
      projectPath: projectPath,
      processId: 'flutter_test',
      parser: LogEntry.fromFlutterTest,
    )) {
      yield entry;
    }
  }

  /// Run `dart analyze` and stream logs
  Stream<LogEntry> analyze({
    required String projectPath,
    bool fatalInfos = false,
    bool fatalWarnings = false,
  }) async* {
    final args = ['analyze'];
    
    if (fatalInfos) args.add('--fatal-infos');
    if (fatalWarnings) args.add('--fatal-warnings');

    yield LogEntry.system('🔍 Running dart analyze...');

    await for (final entry in _runFlutterCommand(
      args,
      projectPath: projectPath,
      processId: 'dart_analyze',
      parser: LogEntry.fromDartAnalyzer,
    )) {
      yield entry;
    }
  }

  /// Run `flutter pub get`
  Stream<LogEntry> pubGet({required String projectPath}) async* {
    yield LogEntry.system('📦 Running flutter pub get...');

    await for (final entry in _runFlutterCommand(
      ['pub', 'get'],
      projectPath: projectPath,
      processId: 'pub_get',
      parser: LogEntry.fromFlutterBuild,
    )) {
      yield entry;
    }
  }

  /// Run `flutter clean`
  Stream<LogEntry> clean({required String projectPath}) async* {
    yield LogEntry.system('🧹 Running flutter clean...');

    await for (final entry in _runFlutterCommand(
      ['clean'],
      projectPath: projectPath,
      processId: 'flutter_clean',
      parser: LogEntry.fromFlutterBuild,
    )) {
      yield entry;
    }
  }

  /// Get available devices
  Future<List<Map<String, dynamic>>> getDevices() async {
    final flutter = await flutterPath;
    final result = await Process.run(
      flutter,
      ['devices', '--machine'],
      stdoutEncoding: utf8,
    );

    if (result.exitCode != 0) return [];

    try {
      final List<dynamic> devices = jsonDecode(result.stdout as String);
      return devices.cast<Map<String, dynamic>>();
    } catch (_) {
      return [];
    }
  }

  /// Trigger hot reload for a running app
  Future<void> hotReload(String processId) async {
    final process = _runningProcesses[processId];
    if (process == null) return;

    // Send 'r' to stdin for hot reload
    process.stdin.writeln('r');
    logger.info('Triggered hot reload');
  }

  /// Trigger hot restart for a running app
  Future<void> hotRestart(String processId) async {
    final process = _runningProcesses[processId];
    if (process == null) return;

    // Send 'R' to stdin for hot restart
    process.stdin.writeln('R');
    logger.info('Triggered hot restart');
  }

  /// Stop a running process
  Future<void> stopProcess(String processId) async {
    final process = _runningProcesses.remove(processId);
    if (process != null) {
      // Send 'q' to quit gracefully
      process.stdin.writeln('q');
      
      // Wait briefly for graceful shutdown
      await Future.delayed(const Duration(seconds: 1));
      
      // Force kill if still running
      process.kill();
      logger.info('Stopped process', {'processId': processId});
    }
    
    _logControllers[processId]?.close();
    _logControllers.remove(processId);
  }

  /// Stop all running processes
  Future<void> stopAll() async {
    for (final id in _runningProcesses.keys.toList()) {
      await stopProcess(id);
    }
  }

  /// Check if a process is running
  bool isRunning(String processId) {
    return _runningProcesses.containsKey(processId);
  }

  /// Get log stream for a process
  Stream<LogEntry>? getLogStream(String processId) {
    return _logControllers[processId]?.stream;
  }

  // Private methods

  Stream<LogEntry> _runFlutterCommand(
    List<String> args, {
    required String projectPath,
    required String processId,
    required LogEntry Function(String, {String? id}) parser,
  }) async* {
    final flutter = await flutterPath;
    
    logger.info('Running Flutter command', {
      'command': 'flutter ${args.join(' ')}',
      'projectPath': projectPath,
    });

    // Stop existing process with same ID
    await stopProcess(processId);

    final controller = StreamController<LogEntry>.broadcast();
    _logControllers[processId] = controller;

    try {
      final process = await Process.start(
        flutter,
        args,
        workingDirectory: projectPath,
        environment: {
          ...Platform.environment,
          'FLUTTER_SUPPRESS_ANALYTICS': 'true',
        },
      );

      _runningProcesses[processId] = process;

      // Stream stdout
      process.stdout.transform(utf8.decoder).listen((chunk) {
        for (final line in chunk.split('\n')) {
          if (line.trim().isEmpty) continue;
          final entry = parser(line);
          controller.add(entry);
        }
      });

      // Stream stderr
      process.stderr.transform(utf8.decoder).listen((chunk) {
        for (final line in chunk.split('\n')) {
          if (line.trim().isEmpty) continue;
          final entry = parser(line).copyWith(level: LogLevel.error);
          controller.add(entry);
        }
      });

      // Yield from controller
      await for (final entry in controller.stream) {
        yield entry;
      }

      // Wait for process to complete
      final exitCode = await process.exitCode;
      
      yield LogEntry.system(
        exitCode == 0 
            ? '✅ Command completed successfully'
            : '❌ Command failed with exit code $exitCode'
      );

      _runningProcesses.remove(processId);
    } catch (e) {
      yield LogEntry(
        id: LogEntry._generateId(),
        timestamp: DateTime.now(),
        level: LogLevel.error,
        tag: 'error',
        message: 'Failed to run command: $e',
        source: processId,
        raw: e.toString(),
      );
      _runningProcesses.remove(processId);
    }
  }

  Future<String> _detectFlutterPath() async {
    // Check common locations
    final locations = [
      Platform.environment['FLUTTER_ROOT'],
      '${Platform.environment['HOME']}/flutter/bin/flutter',
      '${Platform.environment['HOME']}/.flutter/bin/flutter',
      '/usr/local/flutter/bin/flutter',
      'flutter', // System PATH
    ];

    for (final path in locations) {
      if (path == null) continue;
      try {
        final result = await Process.run(path, ['--version']);
        if (result.exitCode == 0) {
          logger.info('Found Flutter at', {'path': path});
          return path;
        }
      } catch (_) {
        continue;
      }
    }

    // Default to 'flutter' and hope it's in PATH
    return 'flutter';
  }

  void dispose() {
    stopAll();
  }
}
```

### Flutter Run Controller

**File: `lib/presentation/controllers/flutter_run_controller.dart`**

```dart
import 'dart:async';
import 'package:flutter/foundation.dart';

import '../../core/services/flutter_cli_service.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_level.dart';

/// State of a Flutter run session
enum FlutterRunState {
  idle,
  starting,
  running,
  reloading,
  restarting,
  stopping,
  stopped,
  error,
}

/// Controller for managing Flutter run sessions
class FlutterRunController extends ChangeNotifier {
  final FlutterCliService _cliService;
  
  FlutterRunState _state = FlutterRunState.idle;
  String? _projectPath;
  String? _deviceId;
  final List<LogEntry> _logs = [];
  StreamSubscription? _logSubscription;
  DateTime? _startTime;
  int _reloadCount = 0;

  FlutterRunController(this._cliService);

  // Getters
  FlutterRunState get state => _state;
  String? get projectPath => _projectPath;
  String? get deviceId => _deviceId;
  List<LogEntry> get logs => List.unmodifiable(_logs);
  bool get isRunning => _state == FlutterRunState.running;
  int get reloadCount => _reloadCount;
  Duration? get uptime => _startTime != null 
      ? DateTime.now().difference(_startTime!) 
      : null;

  /// Log statistics
  int get errorCount => _logs.where((l) => l.level == LogLevel.error).length;
  int get warningCount => _logs.where((l) => l.level == LogLevel.warning).length;

  /// Start running the app
  Future<void> start({
    required String projectPath,
    String? deviceId,
    bool release = false,
    bool profile = false,
  }) async {
    if (_state == FlutterRunState.running) return;

    _projectPath = projectPath;
    _deviceId = deviceId;
    _state = FlutterRunState.starting;
    _logs.clear();
    _reloadCount = 0;
    notifyListeners();

    _logSubscription = _cliService.runApp(
      projectPath: projectPath,
      deviceId: deviceId,
      release: release,
      profile: profile,
    ).listen(
      (entry) {
        _logs.add(entry);
        
        // Detect state changes from logs
        if (entry.message.contains('Running') || 
            entry.message.contains('Launching')) {
          _state = FlutterRunState.running;
          _startTime = DateTime.now();
        }
        
        notifyListeners();
      },
      onError: (e) {
        _state = FlutterRunState.error;
        _logs.add(LogEntry.system('Error: $e'));
        notifyListeners();
      },
      onDone: () {
        _state = FlutterRunState.stopped;
        notifyListeners();
      },
    );
  }

  /// Hot reload the running app
  Future<void> hotReload() async {
    if (_state != FlutterRunState.running) return;

    _state = FlutterRunState.reloading;
    notifyListeners();

    await _cliService.hotReload('flutter_run');
    _reloadCount++;
    
    // State will update based on log output
    _state = FlutterRunState.running;
    notifyListeners();
  }

  /// Hot restart the running app
  Future<void> hotRestart() async {
    if (_state != FlutterRunState.running) return;

    _state = FlutterRunState.restarting;
    notifyListeners();

    await _cliService.hotRestart('flutter_run');
    
    _state = FlutterRunState.running;
    notifyListeners();
  }

  /// Stop the running app
  Future<void> stop() async {
    if (_state == FlutterRunState.idle || 
        _state == FlutterRunState.stopped) return;

    _state = FlutterRunState.stopping;
    notifyListeners();

    await _logSubscription?.cancel();
    await _cliService.stopProcess('flutter_run');

    _state = FlutterRunState.stopped;
    notifyListeners();
  }

  /// Clear logs
  void clearLogs() {
    _logs.clear();
    notifyListeners();
  }

  @override
  void dispose() {
    stop();
    super.dispose();
  }
}
```

### Flutter Build Controller

**File: `lib/presentation/controllers/flutter_build_controller.dart`**

```dart
import 'dart:async';
import 'package:flutter/foundation.dart';

import '../../core/services/flutter_cli_service.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_level.dart';

/// State of a Flutter build
enum FlutterBuildState {
  idle,
  building,
  success,
  failed,
}

/// Build target platforms
enum BuildTarget {
  apk('apk', 'Android APK'),
  appbundle('appbundle', 'Android App Bundle'),
  ios('ios', 'iOS App'),
  ipa('ipa', 'iOS IPA'),
  web('web', 'Web'),
  macos('macos', 'macOS'),
  windows('windows', 'Windows'),
  linux('linux', 'Linux');

  final String command;
  final String displayName;
  const BuildTarget(this.command, this.displayName);
}

/// Controller for managing Flutter builds
class FlutterBuildController extends ChangeNotifier {
  final FlutterCliService _cliService;
  
  FlutterBuildState _state = FlutterBuildState.idle;
  BuildTarget? _target;
  String? _projectPath;
  final List<LogEntry> _logs = [];
  StreamSubscription? _logSubscription;
  DateTime? _startTime;
  Duration? _buildDuration;

  FlutterBuildController(this._cliService);

  // Getters
  FlutterBuildState get state => _state;
  BuildTarget? get target => _target;
  List<LogEntry> get logs => List.unmodifiable(_logs);
  bool get isBuilding => _state == FlutterBuildState.building;
  Duration? get buildDuration => _buildDuration;

  int get errorCount => _logs.where((l) => l.level == LogLevel.error).length;
  int get warningCount => _logs.where((l) => l.level == LogLevel.warning).length;

  /// Start a build
  Future<void> build({
    required String projectPath,
    required BuildTarget target,
    bool release = true,
    List<String> additionalArgs = const [],
  }) async {
    if (_state == FlutterBuildState.building) return;

    _projectPath = projectPath;
    _target = target;
    _state = FlutterBuildState.building;
    _logs.clear();
    _startTime = DateTime.now();
    _buildDuration = null;
    notifyListeners();

    _logSubscription = _cliService.buildApp(
      projectPath: projectPath,
      target: target.command,
      release: release,
      additionalArgs: additionalArgs,
    ).listen(
      (entry) {
        _logs.add(entry);
        notifyListeners();
      },
      onError: (e) {
        _state = FlutterBuildState.failed;
        _logs.add(LogEntry.system('Build error: $e'));
        _buildDuration = DateTime.now().difference(_startTime!);
        notifyListeners();
      },
      onDone: () {
        _buildDuration = DateTime.now().difference(_startTime!);
        _state = errorCount > 0 
            ? FlutterBuildState.failed 
            : FlutterBuildState.success;
        notifyListeners();
      },
    );
  }

  /// Run flutter clean before build
  Future<void> cleanAndBuild({
    required String projectPath,
    required BuildTarget target,
    bool release = true,
  }) async {
    // Clean first
    await for (final entry in _cliService.clean(projectPath: projectPath)) {
      _logs.add(entry);
      notifyListeners();
    }

    // Then build
    await build(projectPath: projectPath, target: target, release: release);
  }

  /// Cancel the current build
  Future<void> cancel() async {
    await _logSubscription?.cancel();
    await _cliService.stopProcess('flutter_build');
    _state = FlutterBuildState.idle;
    _logs.add(LogEntry.system('Build cancelled'));
    notifyListeners();
  }

  /// Clear logs
  void clearLogs() {
    _logs.clear();
    _state = FlutterBuildState.idle;
    notifyListeners();
  }

  @override
  void dispose() {
    cancel();
    super.dispose();
  }
}
```

---

## Presentation Layer

### Console Log Provider

**File: `lib/presentation/providers/console_log_provider.dart`**

```dart
import 'dart:async';
import 'package:flutter/foundation.dart';

import '../../core/logging/logging.dart';
import '../../core/services/console_log_service.dart';
import '../../domain/entities/log_entry.dart';
import '../../domain/entities/log_filter.dart';
import '../../domain/entities/log_level.dart';
import '../../domain/repositories/log_repository.dart';

/// Provider for console log state management
class ConsoleLogProvider extends ChangeNotifier with LoggerMixin {
  final LogRepository _repository;
  final ConsoleLogService _logService;

  String? _activeDeviceId;
  LogFilter _filter = const LogFilter();
  List<LogEntry> _logs = [];
  bool _isStreaming = false;
  bool _autoScroll = true;
  bool _isPaused = false;
  StreamSubscription? _logSubscription;
  
  // Search state
  String _searchQuery = '';
  int _searchIndex = 0;
  List<int> _searchMatches = [];

  ConsoleLogProvider({
    required LogRepository repository,
    required ConsoleLogService logService,
  })  : _repository = repository,
        _logService = logService;

  // Getters
  String? get activeDeviceId => _activeDeviceId;
  LogFilter get filter => _filter;
  List<LogEntry> get logs => _filteredLogs;
  bool get isStreaming => _isStreaming;
  bool get autoScroll => _autoScroll;
  bool get isPaused => _isPaused;
  String get searchQuery => _searchQuery;
  int get searchIndex => _searchIndex;
  List<int> get searchMatches => _searchMatches;
  int get totalLogCount => _logs.length;
  int get filteredLogCount => _filteredLogs.length;

  List<LogEntry> get _filteredLogs {
    if (!_filter.isFiltering && _searchQuery.isEmpty) {
      return _logs;
    }
    
    var result = _logs.where((log) => log.matchesFilter(_filter)).toList();
    
    if (_searchQuery.isNotEmpty) {
      result = result.where((log) => log.matchesSearch(_searchQuery)).toList();
    }
    
    return result;
  }

  /// Get log statistics
  LogStatistics get statistics {
    return _logService.getStatistics(_activeDeviceId ?? '');
  }

  /// Get unique tags from current logs
  Set<String> get availableTags {
    return _logs.map((e) => e.tag).where((t) => t.isNotEmpty).toSet();
  }

  /// Start streaming logs from device
  Future<void> startStreaming(String deviceId) async {
    if (_isStreaming && _activeDeviceId == deviceId) return;
    
    await stopStreaming();
    
    _activeDeviceId = deviceId;
    _isStreaming = true;
    _isPaused = false;
    notifyListeners();
    
    logger.info('Starting log stream', {'deviceId': deviceId});
    
    // Load buffered logs first
    _logs = _logService.getBuffer(deviceId);
    notifyListeners();
    
    // Subscribe to new logs
    _logSubscription = _logService.getLogStream(deviceId).listen(
      (entry) {
        if (!_isPaused) {
          _logs.add(entry);
          _updateSearchMatches();
          notifyListeners();
        }
      },
      onError: (e) {
        logger.error('Log stream error', e);
        _isStreaming = false;
        notifyListeners();
      },
    );
    
    // Start repository stream
    _repository.streamLogs(deviceId, filter: _filter).listen(
      (entry) => _logService.addLogEntry(deviceId, entry),
      onError: (e) => logger.error('Repository stream error', e),
    );
  }

  /// Stop streaming logs
  Future<void> stopStreaming() async {
    _logSubscription?.cancel();
    _logSubscription = null;
    
    if (_activeDeviceId != null) {
      await _repository.stopCapture(_activeDeviceId!);
    }
    
    _isStreaming = false;
    notifyListeners();
  }

  /// Pause log updates (keeps buffering)
  void pause() {
    _isPaused = true;
    notifyListeners();
  }

  /// Resume log updates
  void resume() {
    if (_activeDeviceId != null) {
      _logs = _logService.getBuffer(_activeDeviceId!);
    }
    _isPaused = false;
    notifyListeners();
  }

  /// Clear all logs
  Future<void> clearLogs() async {
    if (_activeDeviceId != null) {
      _logService.clearBuffer(_activeDeviceId!);
      await _repository.clearLogs(_activeDeviceId!);
    }
    _logs.clear();
    _searchMatches.clear();
    notifyListeners();
  }

  /// Set minimum log level filter
  void setMinLevel(LogLevel level) {
    _filter = _filter.copyWith(minLevel: level);
    notifyListeners();
  }

  /// Set search query
  void setSearchQuery(String query) {
    _searchQuery = query;
    _searchIndex = 0;
    _updateSearchMatches();
    notifyListeners();
  }

  /// Go to next search match
  void nextSearchMatch() {
    if (_searchMatches.isEmpty) return;
    _searchIndex = (_searchIndex + 1) % _searchMatches.length;
    notifyListeners();
  }

  /// Go to previous search match
  void previousSearchMatch() {
    if (_searchMatches.isEmpty) return;
    _searchIndex = (_searchIndex - 1 + _searchMatches.length) % _searchMatches.length;
    notifyListeners();
  }

  /// Toggle tag filter
  void toggleTagFilter(String tag) {
    final tags = Set<String>.from(_filter.tags);
    if (tags.contains(tag)) {
      tags.remove(tag);
    } else {
      tags.add(tag);
    }
    _filter = _filter.copyWith(tags: tags);
    notifyListeners();
  }

  /// Toggle auto-scroll
  void toggleAutoScroll() {
    _autoScroll = !_autoScroll;
    notifyListeners();
  }

  /// Reset all filters
  void resetFilters() {
    _filter = const LogFilter();
    _searchQuery = '';
    _searchMatches.clear();
    notifyListeners();
  }

  /// Export logs to file
  Future<String?> exportLogs(String outputPath, {String format = 'txt'}) async {
    if (_activeDeviceId == null) return null;
    
    try {
      return await _repository.exportLogs(
        _activeDeviceId!,
        outputPath: outputPath,
        filter: _filter,
        format: format,
      );
    } catch (e) {
      logger.error('Failed to export logs', e);
      return null;
    }
  }

  void _updateSearchMatches() {
    _searchMatches.clear();
    if (_searchQuery.isEmpty) return;
    
    for (var i = 0; i < _filteredLogs.length; i++) {
      if (_filteredLogs[i].matchesSearch(_searchQuery)) {
        _searchMatches.add(i);
      }
    }
  }

  @override
  void dispose() {
    stopStreaming();
    super.dispose();
  }
}
```

### Console Log Panel Widget

**File: `lib/presentation/widgets/console/console_log_panel.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../domain/entities/log_entry.dart';
import '../../../domain/entities/log_level.dart';
import '../../providers/console_log_provider.dart';
import 'log_entry_widget.dart';
import 'log_filter_bar.dart';
import 'log_search_bar.dart';

/// Main console log viewer panel
class ConsoleLogPanel extends StatefulWidget {
  final String? deviceId;
  final bool showToolbar;
  final bool showStatusBar;
  final double? maxHeight;

  const ConsoleLogPanel({
    super.key,
    this.deviceId,
    this.showToolbar = true,
    this.showStatusBar = true,
    this.maxHeight,
  });

  @override
  State<ConsoleLogPanel> createState() => _ConsoleLogPanelState();
}

class _ConsoleLogPanelState extends State<ConsoleLogPanel> {
  final ScrollController _scrollController = ScrollController();
  bool _showSearch = false;

  @override
  void initState() {
    super.initState();
    if (widget.deviceId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<ConsoleLogProvider>().startStreaming(widget.deviceId!);
      });
    }
  }

  @override
  void didUpdateWidget(ConsoleLogPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.deviceId != oldWidget.deviceId && widget.deviceId != null) {
      context.read<ConsoleLogProvider>().startStreaming(widget.deviceId!);
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ConsoleLogProvider>(
      builder: (context, provider, _) {
        return Container(
          constraints: widget.maxHeight != null
              ? BoxConstraints(maxHeight: widget.maxHeight!)
              : null,
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E),
            border: Border.all(color: const Color(0xFF3C3C3C)),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            children: [
              if (widget.showToolbar) _buildToolbar(provider),
              if (_showSearch) LogSearchBar(provider: provider),
              LogFilterBar(provider: provider),
              Expanded(child: _buildLogList(provider)),
              if (widget.showStatusBar) _buildStatusBar(provider),
            ],
          ),
        );
      },
    );
  }

  Widget _buildToolbar(ConsoleLogProvider provider) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: const BoxDecoration(
        color: Color(0xFF2D2D2D),
        border: Border(bottom: BorderSide(color: Color(0xFF3C3C3C))),
      ),
      child: Row(
        children: [
          // Stream control
          _ToolbarButton(
            icon: provider.isStreaming
                ? (provider.isPaused
                    ? CupertinoIcons.play_fill
                    : CupertinoIcons.pause_fill)
                : CupertinoIcons.play_fill,
            tooltip: provider.isPaused ? 'Resume' : 'Pause',
            onPressed: () {
              if (provider.isPaused) {
                provider.resume();
              } else {
                provider.pause();
              }
            },
          ),
          
          // Clear button
          _ToolbarButton(
            icon: CupertinoIcons.trash,
            tooltip: 'Clear logs',
            onPressed: provider.clearLogs,
          ),
          
          const SizedBox(width: 8),
          Container(width: 1, height: 20, color: const Color(0xFF3C3C3C)),
          const SizedBox(width: 8),
          
          // Search toggle
          _ToolbarButton(
            icon: CupertinoIcons.search,
            tooltip: 'Search',
            isActive: _showSearch,
            onPressed: () => setState(() => _showSearch = !_showSearch),
          ),
          
          // Auto-scroll toggle
          _ToolbarButton(
            icon: CupertinoIcons.arrow_down_to_line,
            tooltip: 'Auto-scroll',
            isActive: provider.autoScroll,
            onPressed: provider.toggleAutoScroll,
          ),
          
          const Spacer(),
          
          // Export button
          _ToolbarButton(
            icon: CupertinoIcons.arrow_up_doc,
            tooltip: 'Export logs',
            onPressed: () => _showExportDialog(context, provider),
          ),
          
          // Level filter dropdown
          _buildLevelDropdown(provider),
        ],
      ),
    );
  }

  Widget _buildLevelDropdown(ConsoleLogProvider provider) {
    return PopupMenuButton<LogLevel>(
      tooltip: 'Minimum log level',
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: const Color(0xFF3C3C3C),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              provider.filter.minLevel.icon,
              size: 14,
              color: provider.filter.minLevel.color,
            ),
            const SizedBox(width: 4),
            Text(
              provider.filter.minLevel.displayName,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
              ),
            ),
            const Icon(
              CupertinoIcons.chevron_down,
              size: 12,
              color: Colors.white54,
            ),
          ],
        ),
      ),
      itemBuilder: (_) => LogLevel.values.map((level) {
        return PopupMenuItem(
          value: level,
          child: Row(
            children: [
              Icon(level.icon, size: 16, color: level.color),
              const SizedBox(width: 8),
              Text(level.displayName),
            ],
          ),
        );
      }).toList(),
      onSelected: provider.setMinLevel,
    );
  }

  Widget _buildLogList(ConsoleLogProvider provider) {
    final logs = provider.logs;
    
    if (logs.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              CupertinoIcons.doc_text,
              size: 48,
              color: Colors.white24,
            ),
            const SizedBox(height: 16),
            Text(
              provider.isStreaming
                  ? 'Waiting for logs...'
                  : 'No logs to display',
              style: const TextStyle(
                color: Colors.white38,
                fontSize: 14,
              ),
            ),
            if (provider.filter.isFiltering) ...[
              const SizedBox(height: 8),
              TextButton(
                onPressed: provider.resetFilters,
                child: const Text('Clear filters'),
              ),
            ],
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      itemCount: logs.length,
      itemBuilder: (context, index) {
        final log = logs[index];
        final isSearchMatch = provider.searchMatches.contains(index);
        final isCurrentMatch = provider.searchMatches.isNotEmpty &&
            provider.searchMatches[provider.searchIndex] == index;
        
        return LogEntryWidget(
          entry: log,
          isHighlighted: isSearchMatch,
          isCurrentSearchMatch: isCurrentMatch,
          showTimestamp: provider.filter.showTimestamp,
          showTag: provider.filter.showTags,
          searchQuery: provider.searchQuery,
          onTagTap: (tag) => provider.toggleTagFilter(tag),
          onCopy: () => _copyLogToClipboard(log),
        );
      },
    );
  }

  Widget _buildStatusBar(ConsoleLogProvider provider) {
    final stats = provider.statistics;
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: const BoxDecoration(
        color: Color(0xFF2D2D2D),
        border: Border(top: BorderSide(color: Color(0xFF3C3C3C))),
      ),
      child: Row(
        children: [
          // Connection status
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: provider.isStreaming
                  ? (provider.isPaused ? Colors.orange : Colors.green)
                  : Colors.red,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            provider.isStreaming
                ? (provider.isPaused ? 'Paused' : 'Streaming')
                : 'Disconnected',
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
          
          const SizedBox(width: 16),
          
          // Log counts
          Text(
            '${provider.filteredLogCount}/${provider.totalLogCount} logs',
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
          
          if (stats.errorCount > 0) ...[
            const SizedBox(width: 12),
            _StatusBadge(
              count: stats.errorCount,
              color: LogLevel.error.color,
              label: 'errors',
            ),
          ],
          
          if (stats.warningCount > 0) ...[
            const SizedBox(width: 8),
            _StatusBadge(
              count: stats.warningCount,
              color: LogLevel.warning.color,
              label: 'warnings',
            ),
          ],
          
          const Spacer(),
          
          // Search results
          if (provider.searchQuery.isNotEmpty)
            Text(
              '${provider.searchMatches.length} matches',
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
        ],
      ),
    );
  }

  void _copyLogToClipboard(LogEntry log) {
    Clipboard.setData(ClipboardData(text: log.raw));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Log copied to clipboard'),
        duration: Duration(seconds: 1),
      ),
    );
  }

  void _showExportDialog(BuildContext context, ConsoleLogProvider provider) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('Export Logs'),
        content: const Text('Choose export format'),
        actions: [
          CupertinoDialogAction(
            child: const Text('Text (.txt)'),
            onPressed: () {
              Navigator.pop(context);
              _exportLogs(provider, 'txt');
            },
          ),
          CupertinoDialogAction(
            child: const Text('JSON (.json)'),
            onPressed: () {
              Navigator.pop(context);
              _exportLogs(provider, 'json');
            },
          ),
          CupertinoDialogAction(
            child: const Text('CSV (.csv)'),
            onPressed: () {
              Navigator.pop(context);
              _exportLogs(provider, 'csv');
            },
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text('Cancel'),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  Future<void> _exportLogs(ConsoleLogProvider provider, String format) async {
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-');
    final path = 'logs/console_$timestamp.$format';
    
    final result = await provider.exportLogs(path, format: format);
    if (result != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Logs exported to $result')),
      );
    }
  }
}

class _ToolbarButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;
  final bool isActive;

  const _ToolbarButton({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
    this.isActive = false,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(4),
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: isActive ? const Color(0xFF094771) : Colors.transparent,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Icon(
            icon,
            size: 16,
            color: isActive ? Colors.white : Colors.white70,
          ),
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final int count;
  final Color color;
  final String label;

  const _StatusBadge({
    required this.count,
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        '$count $label',
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
```

### Log Entry Widget

**File: `lib/presentation/widgets/console/log_entry_widget.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../domain/entities/log_entry.dart';

/// Widget displaying a single log entry
class LogEntryWidget extends StatelessWidget {
  final LogEntry entry;
  final bool isHighlighted;
  final bool isCurrentSearchMatch;
  final bool showTimestamp;
  final bool showTag;
  final String? searchQuery;
  final void Function(String)? onTagTap;
  final VoidCallback? onCopy;

  const LogEntryWidget({
    super.key,
    required this.entry,
    this.isHighlighted = false,
    this.isCurrentSearchMatch = false,
    this.showTimestamp = true,
    this.showTag = true,
    this.searchQuery,
    this.onTagTap,
    this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onSecondaryTap: onCopy,
      onLongPress: onCopy,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        decoration: BoxDecoration(
          color: _backgroundColor,
          border: isCurrentSearchMatch
              ? Border.all(color: Colors.yellow, width: 1)
              : null,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Timestamp
            if (showTimestamp)
              SizedBox(
                width: 85,
                child: Text(
                  entry.formattedTime,
                  style: _monoStyle.copyWith(color: Colors.white38),
                ),
              ),
            
            // Level indicator
            Container(
              width: 16,
              margin: const EdgeInsets.only(right: 8),
              child: Text(
                entry.level.shortName,
                style: _monoStyle.copyWith(
                  color: entry.level.color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            
            // Tag
            if (showTag && entry.tag.isNotEmpty)
              GestureDetector(
                onTap: () => onTagTap?.call(entry.tag),
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 120),
                  margin: const EdgeInsets.only(right: 8),
                  child: Text(
                    entry.tag,
                    style: _monoStyle.copyWith(color: Colors.cyan),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            
            // Message
            Expanded(
              child: _buildMessage(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessage() {
    if (searchQuery == null || searchQuery!.isEmpty) {
      return Text(
        entry.message,
        style: _monoStyle.copyWith(color: _messageColor),
      );
    }

    // Highlight search matches
    final spans = <TextSpan>[];
    final message = entry.message;
    final query = searchQuery!.toLowerCase();
    var lastEnd = 0;

    while (true) {
      final start = message.toLowerCase().indexOf(query, lastEnd);
      if (start == -1) break;

      // Add text before match
      if (start > lastEnd) {
        spans.add(TextSpan(
          text: message.substring(lastEnd, start),
          style: _monoStyle.copyWith(color: _messageColor),
        ));
      }

      // Add highlighted match
      spans.add(TextSpan(
        text: message.substring(start, start + query.length),
        style: _monoStyle.copyWith(
          color: Colors.black,
          backgroundColor: Colors.yellow,
        ),
      ));

      lastEnd = start + query.length;
    }

    // Add remaining text
    if (lastEnd < message.length) {
      spans.add(TextSpan(
        text: message.substring(lastEnd),
        style: _monoStyle.copyWith(color: _messageColor),
      ));
    }

    return RichText(text: TextSpan(children: spans));
  }

  Color get _backgroundColor {
    if (isCurrentSearchMatch) return Colors.yellow.withOpacity(0.15);
    if (isHighlighted) return Colors.yellow.withOpacity(0.05);
    
    return switch (entry.level) {
      LogLevel.error || LogLevel.fatal => Colors.red.withOpacity(0.1),
      LogLevel.warning => Colors.orange.withOpacity(0.05),
      _ => Colors.transparent,
    };
  }

  Color get _messageColor {
    return switch (entry.level) {
      LogLevel.error || LogLevel.fatal => Colors.red[300]!,
      LogLevel.warning => Colors.orange[300]!,
      LogLevel.debug => Colors.blue[300]!,
      LogLevel.verbose => Colors.white38,
      _ => Colors.white70,
    };
  }

  static const _monoStyle = TextStyle(
    fontFamily: 'SF Mono',
    fontFamilyFallback: ['Menlo', 'Monaco', 'Consolas', 'monospace'],
    fontSize: 12,
    height: 1.4,
  );
}
```

### Log Filter Bar

**File: `lib/presentation/widgets/console/log_filter_bar.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../domain/entities/log_level.dart';
import '../../providers/console_log_provider.dart';

/// Filter bar for log level and tag filters
class LogFilterBar extends StatelessWidget {
  final ConsoleLogProvider provider;

  const LogFilterBar({super.key, required this.provider});

  @override
  Widget build(BuildContext context) {
    final filter = provider.filter;
    final activeTags = filter.tags;
    final availableTags = provider.availableTags.toList()..sort();

    if (availableTags.isEmpty && !filter.isFiltering) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: const BoxDecoration(
        color: Color(0xFF252526),
        border: Border(bottom: BorderSide(color: Color(0xFF3C3C3C))),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            // Level chips
            ...LogLevel.values.map((level) => Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: _FilterChip(
                    label: level.shortName,
                    color: level.color,
                    isActive: filter.minLevel.index <= level.index,
                    onTap: () => provider.setMinLevel(level),
                  ),
                )),
            
            if (availableTags.isNotEmpty) ...[
              Container(
                width: 1,
                height: 20,
                margin: const EdgeInsets.symmetric(horizontal: 8),
                color: const Color(0xFF3C3C3C),
              ),
              
              // Tag chips
              ...availableTags.take(10).map((tag) => Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: _FilterChip(
                      label: tag,
                      color: Colors.cyan,
                      isActive: activeTags.contains(tag),
                      onTap: () => provider.toggleTagFilter(tag),
                    ),
                  )),
            ],
            
            if (filter.isFiltering) ...[
              const SizedBox(width: 8),
              TextButton(
                onPressed: provider.resetFilters,
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  minimumSize: const Size(0, 24),
                ),
                child: const Text(
                  'Clear all',
                  style: TextStyle(fontSize: 11),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool isActive;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.color,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isActive ? color.withOpacity(0.2) : Colors.transparent,
          border: Border.all(
            color: isActive ? color : const Color(0xFF3C3C3C),
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isActive ? color : Colors.white54,
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}
```

### Log Search Bar

**File: `lib/presentation/widgets/console/log_search_bar.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../providers/console_log_provider.dart';

/// Search bar for filtering logs
class LogSearchBar extends StatefulWidget {
  final ConsoleLogProvider provider;

  const LogSearchBar({super.key, required this.provider});

  @override
  State<LogSearchBar> createState() => _LogSearchBarState();
}

class _LogSearchBarState extends State<LogSearchBar> {
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.provider.searchQuery);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = widget.provider;
    
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: const BoxDecoration(
        color: Color(0xFF252526),
        border: Border(bottom: BorderSide(color: Color(0xFF3C3C3C))),
      ),
      child: Row(
        children: [
          Expanded(
            child: CupertinoSearchTextField(
              controller: _controller,
              placeholder: 'Search logs...',
              style: const TextStyle(color: Colors.white),
              onChanged: provider.setSearchQuery,
              onSubmitted: (_) => provider.nextSearchMatch(),
            ),
          ),
          
          const SizedBox(width: 8),
          
          // Match navigation
          if (provider.searchMatches.isNotEmpty) ...[
            Text(
              '${provider.searchIndex + 1}/${provider.searchMatches.length}',
              style: const TextStyle(
                color: Colors.white54,
                fontSize: 12,
              ),
            ),
            const SizedBox(width: 4),
            IconButton(
              icon: const Icon(CupertinoIcons.chevron_up, size: 16),
              onPressed: provider.previousSearchMatch,
              tooltip: 'Previous match',
              color: Colors.white70,
              constraints: const BoxConstraints(
                minWidth: 28,
                minHeight: 28,
              ),
              padding: EdgeInsets.zero,
            ),
            IconButton(
              icon: const Icon(CupertinoIcons.chevron_down, size: 16),
              onPressed: provider.nextSearchMatch,
              tooltip: 'Next match',
              color: Colors.white70,
              constraints: const BoxConstraints(
                minWidth: 28,
                minHeight: 28,
              ),
              padding: EdgeInsets.zero,
            ),
          ],
          
          // Clear search
          if (provider.searchQuery.isNotEmpty)
            IconButton(
              icon: const Icon(CupertinoIcons.xmark_circle_fill, size: 16),
              onPressed: () {
                _controller.clear();
                provider.setSearchQuery('');
              },
              tooltip: 'Clear search',
              color: Colors.white54,
              constraints: const BoxConstraints(
                minWidth: 28,
                minHeight: 28,
              ),
              padding: EdgeInsets.zero,
            ),
        ],
      ),
    );
  }
}
```

---

## Integration

### Dependency Injection

**File: `lib/core/di/console_log_module.dart`**

```dart
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import '../../data/datasources/log_datasource.dart';
import '../../data/repositories/log_repository_impl.dart';
import '../../domain/repositories/log_repository.dart';
import '../services/console_log_service.dart';
import '../../presentation/providers/console_log_provider.dart';

/// Module for console log dependency injection
class ConsoleLogModule {
  static List<SingleChildWidget> getProviders({String? adbPath}) {
    final datasource = LogDatasource();
    final logService = ConsoleLogService();
    
    final repository = LogRepositoryImpl(
      datasource: datasource,
      adbPath: adbPath,
    );
    
    return [
      Provider<LogDatasource>.value(value: datasource),
      Provider<ConsoleLogService>.value(value: logService),
      Provider<LogRepository>.value(value: repository),
      ChangeNotifierProvider<ConsoleLogProvider>(
        create: (_) => ConsoleLogProvider(
          repository: repository,
          logService: logService,
        ),
      ),
    ];
  }
}
```

### Usage Example

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/di/console_log_module.dart';
import 'presentation/widgets/console/console_log_panel.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ...ConsoleLogModule.getProviders(),
      ],
      child: MaterialApp(
        home: DeviceLogScreen(),
      ),
    );
  }
}

class DeviceLogScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Device Logs')),
      body: Column(
        children: [
          // Device selector would go here
          Expanded(
            child: ConsoleLogPanel(
              deviceId: 'emulator-5554', // Selected device ID
              showToolbar: true,
              showStatusBar: true,
            ),
          ),
        ],
      ),
    );
  }
}
```

---

## Testing

### Unit Tests

**File: `test/unit/console/log_entry_test.dart`**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/log_entry.dart';
import 'package:advanced_tester/domain/entities/log_level.dart';
import 'package:advanced_tester/domain/entities/log_filter.dart';

void main() {
  group('LogEntry', () {
    test('parses Android logcat format correctly', () {
      const line = '01-15 10:30:45.123  1234  5678 D MyApp   : Hello World';
      
      final entry = LogEntry.fromLogcat(line);
      
      expect(entry.level, LogLevel.debug);
      expect(entry.tag, 'MyApp');
      expect(entry.message, 'Hello World');
      expect(entry.processId, '1234');
      expect(entry.threadId, '5678');
    });

    test('parses error level correctly', () {
      const line = '01-15 10:30:45.123  1234  5678 E CrashHandler: NullPointerException';
      
      final entry = LogEntry.fromLogcat(line);
      
      expect(entry.level, LogLevel.error);
      expect(entry.tag, 'CrashHandler');
    });

    test('matchesSearch finds text in message', () {
      final entry = LogEntry(
        id: '1',
        timestamp: DateTime.now(),
        level: LogLevel.info,
        tag: 'TestTag',
        message: 'User clicked button',
        raw: '',
      );

      expect(entry.matchesSearch('clicked'), true);
      expect(entry.matchesSearch('CLICKED'), true); // Case insensitive
      expect(entry.matchesSearch('tapped'), false);
    });

    test('matchesFilter respects minimum level', () {
      final entry = LogEntry(
        id: '1',
        timestamp: DateTime.now(),
        level: LogLevel.debug,
        tag: 'Test',
        message: 'Debug message',
        raw: '',
      );

      expect(
        entry.matchesFilter(const LogFilter(minLevel: LogLevel.verbose)),
        true,
      );
      expect(
        entry.matchesFilter(const LogFilter(minLevel: LogLevel.debug)),
        true,
      );
      expect(
        entry.matchesFilter(const LogFilter(minLevel: LogLevel.info)),
        false,
      );
    });

    test('matchesFilter respects tag filter', () {
      final entry = LogEntry(
        id: '1',
        timestamp: DateTime.now(),
        level: LogLevel.info,
        tag: 'MyApp',
        message: 'Message',
        raw: '',
      );

      expect(
        entry.matchesFilter(const LogFilter(tags: {'MyApp'})),
        true,
      );
      expect(
        entry.matchesFilter(const LogFilter(tags: {'OtherApp'})),
        false,
      );
      expect(
        entry.matchesFilter(const LogFilter(excludedTags: {'MyApp'})),
        false,
      );
    });
  });

  group('LogEntry - Flutter Run parsing', () {
    test('parses hot reload message', () {
      const line = 'Reloaded 3 of 450 libraries in 234ms.';
      
      final entry = LogEntry.fromFlutterRun(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'hot reload');
      expect(entry.message.contains('234ms'), true);
    });

    test('parses hot restart message', () {
      const line = 'Restarted application in 1,234ms.';
      
      final entry = LogEntry.fromFlutterRun(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'hot restart');
    });

    test('parses DevTools URL', () {
      const line = 'The Flutter DevTools debugger and profiler on iPhone 15 is available at: http://127.0.0.1:9100';
      
      final entry = LogEntry.fromFlutterRun(line);
      
      expect(entry.level, LogLevel.debug);
      expect(entry.tag, 'devtools');
      expect(entry.message.contains('http://'), true);
    });

    test('parses flutter debug output', () {
      const line = 'flutter: User tapped login button';
      
      final entry = LogEntry.fromFlutterRun(line);
      
      expect(entry.level, LogLevel.debug);
      expect(entry.tag, 'flutter');
      expect(entry.message, 'User tapped login button');
    });

    test('parses I/flutter Android format', () {
      const line = 'I/flutter (12345): User logged in successfully';
      
      final entry = LogEntry.fromFlutterRun(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'flutter');
      expect(entry.message, 'User logged in successfully');
    });
  });

  group('LogEntry - Flutter Build parsing', () {
    test('parses APK build success', () {
      const line = '✓ Built build/app/outputs/flutter-apk/app-release.apk (15.2MB)';
      
      final entry = LogEntry.fromFlutterBuild(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'success');
    });

    test('parses build error with file location', () {
      const line = 'lib/main.dart:42:10: Error: Undefined name \'widget\'.';
      
      final entry = LogEntry.fromFlutterBuild(line);
      
      expect(entry.level, LogLevel.error);
      expect(entry.tag, 'error');
    });

    test('parses Gradle progress', () {
      const line = 'Running Gradle task \'assembleRelease\'...';
      
      final entry = LogEntry.fromFlutterBuild(line);
      
      expect(entry.level, LogLevel.verbose);
      expect(entry.tag, 'gradle');
    });

    test('parses Xcode build progress', () {
      const line = 'Running Xcode build...';
      
      final entry = LogEntry.fromFlutterBuild(line);
      
      expect(entry.level, LogLevel.verbose);
      expect(entry.tag, 'xcode');
    });
  });

  group('LogEntry - Flutter Test parsing', () {
    test('parses passed test', () {
      const line = '✓ Login page renders correctly';
      
      final entry = LogEntry.fromFlutterTest(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'passed');
    });

    test('parses failed test', () {
      const line = '✗ User registration validates email';
      
      final entry = LogEntry.fromFlutterTest(line);
      
      expect(entry.level, LogLevel.error);
      expect(entry.tag, 'failed');
    });

    test('parses skipped test', () {
      const line = '~ Integration test (skip: API not available)';
      
      final entry = LogEntry.fromFlutterTest(line);
      
      expect(entry.level, LogLevel.warning);
      expect(entry.tag, 'skipped');
    });

    test('parses test summary', () {
      const line = 'All 42 tests passed!';
      
      final entry = LogEntry.fromFlutterTest(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'summary');
    });

    test('parses assertion failure details', () {
      const line = 'Expected: true';
      
      final entry = LogEntry.fromFlutterTest(line);
      
      expect(entry.level, LogLevel.error);
      expect(entry.tag, 'assertion');
    });
  });

  group('LogEntry - Dart Analyzer parsing', () {
    test('parses error', () {
      const line = 'error • lib/main.dart:10:5 • Undefined name \'foo\' • undefined_identifier';
      
      final entry = LogEntry.fromDartAnalyzer(line);
      
      expect(entry.level, LogLevel.error);
      expect(entry.tag, 'error');
    });

    test('parses warning', () {
      const line = 'warning • lib/widget.dart:25:3 • Unused variable \'x\' • unused_local_variable';
      
      final entry = LogEntry.fromDartAnalyzer(line);
      
      expect(entry.level, LogLevel.warning);
      expect(entry.tag, 'warning');
    });

    test('parses info/hint', () {
      const line = 'info • lib/utils.dart:15:1 • Prefer const constructors • prefer_const_constructors';
      
      final entry = LogEntry.fromDartAnalyzer(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'hint');
    });

    test('parses no issues found', () {
      const line = 'No issues found!';
      
      final entry = LogEntry.fromDartAnalyzer(line);
      
      expect(entry.level, LogLevel.info);
      expect(entry.tag, 'success');
    });
  });

  group('LogEntry - Auto detect', () {
    test('detects logcat format', () {
      const line = '01-15 10:30:45.123  1234  5678 I MyApp   : Message';
      
      final entry = LogEntry.autoDetect(line);
      
      expect(entry.source, 'logcat');
    });

    test('detects hot reload message', () {
      const line = 'Reloaded 3 of 450 libraries in 234ms.';
      
      final entry = LogEntry.autoDetect(line);
      
      expect(entry.source, 'flutter_run');
      expect(entry.tag, 'hot reload');
    });

    test('detects build output', () {
      const line = 'Running Gradle task \'assembleRelease\'...';
      
      final entry = LogEntry.autoDetect(line);
      
      expect(entry.source, 'flutter_build');
    });

    test('respects hint parameter', () {
      const line = 'Some message';
      
      final entry = LogEntry.autoDetect(line, hint: 'flutter_test');
      
      expect(entry.source, 'flutter_test');
    });
  });

  group('LogLevel', () {
    test('fromLogcat parses all levels', () {
      expect(LogLevel.fromLogcat('V'), LogLevel.verbose);
      expect(LogLevel.fromLogcat('D'), LogLevel.debug);
      expect(LogLevel.fromLogcat('I'), LogLevel.info);
      expect(LogLevel.fromLogcat('W'), LogLevel.warning);
      expect(LogLevel.fromLogcat('E'), LogLevel.error);
      expect(LogLevel.fromLogcat('F'), LogLevel.fatal);
    });

    test('fromFlutterCli parses common patterns', () {
      expect(LogLevel.fromFlutterCli('Error: something failed'), LogLevel.error);
      expect(LogLevel.fromFlutterCli('warning: deprecated API'), LogLevel.warning);
      expect(LogLevel.fromFlutterCli('Built app.apk'), LogLevel.info);
      expect(LogLevel.fromFlutterCli('Reloaded in 234ms'), LogLevel.info);
      expect(LogLevel.fromFlutterCli('Building...'), LogLevel.verbose);
    });

    test('meetsThreshold works correctly', () {
      expect(LogLevel.debug.meetsThreshold(LogLevel.verbose), true);
      expect(LogLevel.debug.meetsThreshold(LogLevel.debug), true);
      expect(LogLevel.debug.meetsThreshold(LogLevel.info), false);
      expect(LogLevel.error.meetsThreshold(LogLevel.warning), true);
    });
  });

  group('LogFilter', () {
    test('isFiltering detects active filters', () {
      expect(const LogFilter().isFiltering, false);
      expect(const LogFilter(minLevel: LogLevel.error).isFiltering, true);
      expect(const LogFilter(tags: {'test'}).isFiltering, true);
      expect(const LogFilter(searchQuery: 'query').isFiltering, true);
    });

    test('copyWith creates new instance', () {
      const original = LogFilter(minLevel: LogLevel.info);
      final updated = original.copyWith(minLevel: LogLevel.error);

      expect(original.minLevel, LogLevel.info);
      expect(updated.minLevel, LogLevel.error);
    });
  });
}
```

### Flutter CLI Service Tests

**File: `test/unit/console/flutter_cli_service_test.dart`**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/core/services/flutter_cli_service.dart';
import 'package:advanced_tester/domain/entities/log_level.dart';

void main() {
  group('FlutterCliService', () {
    late FlutterCliService service;

    setUp(() {
      service = FlutterCliService(flutterPath: 'flutter');
    });

    tearDown(() {
      service.dispose();
    });

    test('isRunning returns false for unknown process', () {
      expect(service.isRunning('unknown'), false);
    });

    test('getLogStream returns null for unknown process', () {
      expect(service.getLogStream('unknown'), null);
    });

    test('getDevices returns list', () async {
      // This test requires Flutter to be installed
      final devices = await service.getDevices();
      expect(devices, isA<List<Map<String, dynamic>>>());
    });
  });

  group('FlutterCommandResult', () {
    test('calculates error count', () {
      final result = FlutterCommandResult(
        exitCode: 1,
        logs: [
          LogEntry.fromFlutterBuild('error: failed'),
          LogEntry.fromFlutterBuild('warning: deprecated'),
          LogEntry.fromFlutterBuild('info: done'),
        ],
        duration: Duration(seconds: 5),
      );

      expect(result.success, false);
      expect(result.errorCount, 1);
      expect(result.warningCount, 1);
    });

    test('success is true for exit code 0', () {
      final result = FlutterCommandResult(
        exitCode: 0,
        logs: [],
        duration: Duration(seconds: 1),
      );

      expect(result.success, true);
    });
  });
}
```

### Widget Tests

**File: `test/widget/console/log_entry_widget_test.dart`**

```dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/log_entry.dart';
import 'package:advanced_tester/domain/entities/log_level.dart';
import 'package:advanced_tester/presentation/widgets/console/log_entry_widget.dart';

void main() {
  group('LogEntryWidget', () {
    final testEntry = LogEntry(
      id: 'test-1',
      timestamp: DateTime(2024, 1, 15, 10, 30, 45, 123),
      level: LogLevel.info,
      tag: 'TestTag',
      message: 'Test message content',
      raw: 'raw log line',
    );

    testWidgets('displays log message', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LogEntryWidget(entry: testEntry),
          ),
        ),
      );

      expect(find.text('Test message content'), findsOneWidget);
    });

    testWidgets('displays timestamp when enabled', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LogEntryWidget(
              entry: testEntry,
              showTimestamp: true,
            ),
          ),
        ),
      );

      expect(find.text('10:30:45.123'), findsOneWidget);
    });

    testWidgets('displays tag when enabled', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LogEntryWidget(
              entry: testEntry,
              showTag: true,
            ),
          ),
        ),
      );

      expect(find.text('TestTag'), findsOneWidget);
    });

    testWidgets('displays level indicator', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LogEntryWidget(entry: testEntry),
          ),
        ),
      );

      expect(find.text('I'), findsOneWidget);
    });

    testWidgets('highlights search matches', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LogEntryWidget(
              entry: testEntry,
              searchQuery: 'message',
            ),
          ),
        ),
      );

      // Should find RichText with highlighted spans
      expect(find.byType(RichText), findsWidgets);
    });

    testWidgets('calls onTagTap when tag tapped', (tester) async {
      String? tappedTag;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: LogEntryWidget(
              entry: testEntry,
              showTag: true,
              onTagTap: (tag) => tappedTag = tag,
            ),
          ),
        ),
      );

      await tester.tap(find.text('TestTag'));
      expect(tappedTag, 'TestTag');
    });
  });
}
```

---

## Features Summary

### Core Features
- ✅ Real-time log streaming from Android (logcat) and iOS (syslog)
- ✅ Log level filtering (Verbose, Debug, Info, Warning, Error, Fatal)
- ✅ Tag-based filtering
- ✅ Full-text search with match highlighting
- ✅ Log buffering with configurable size
- ✅ Pause/Resume log capture

### Flutter CLI Features
- ✅ `flutter run` output streaming with hot reload detection
- ✅ `flutter build` output with progress and error parsing
- ✅ `flutter test` output with pass/fail/skip tracking
- ✅ `dart analyze` output with error/warning/hint categorization
- ✅ Hot reload/restart trigger via UI
- ✅ DevTools URL detection and display
- ✅ Build time tracking and statistics
- ✅ Test coverage integration

### Flutter Log Parsing
- ✅ Android logcat format (`MM-DD HH:MM:SS.mmm PID TID LEVEL TAG: MSG`)
- ✅ iOS syslog format
- ✅ Flutter debug output (`flutter: message`, `I/flutter`)
- ✅ Build errors with file location extraction
- ✅ Test assertion failure details
- ✅ Analyzer output with lint codes
- ✅ Auto-detection of log source type

### Export Features
- ✅ Export to plain text (.txt)
- ✅ Export to JSON (.json)
- ✅ Export to CSV (.csv)

### UI Features
- ✅ Dark theme optimized for log viewing
- ✅ Monospace font for code readability
- ✅ Color-coded log levels
- ✅ Auto-scroll with toggle
- ✅ Copy log entries to clipboard
- ✅ Status bar with statistics
- ✅ Source-specific icons (Android, iOS, Flutter, etc.)

### Advanced Features
- ✅ Multiple device support
- ✅ Log statistics (error/warning counts)
- ✅ Search navigation (next/previous match)
- ✅ Filter presets (errors only, warnings+)
- ✅ Process lifecycle management (start/stop/restart)
- ✅ Uptime and reload count tracking

---

## Log Source Types

| Source | Icon | Description |
|--------|------|-------------|
| `logcat` | 🤖 | Android device logs via ADB |
| `syslog` | 🍎 | iOS simulator/device logs |
| `flutter` | 💙 | Flutter debug print output |
| `flutter_run` | ▶️ | `flutter run` command output |
| `flutter_build` | 🔨 | `flutter build` command output |
| `flutter_test` | ✅ | `flutter test` command output |
| `dart_analyzer` | 🔍 | `dart analyze` command output |
| `hot_reload` | 🔄 | Hot reload/restart messages |
| `system` | 💻 | Internal system messages |

---

## Notes

- The console uses a dark theme optimized for log readability
- Monospace fonts ensure proper alignment of structured logs
- Log buffering prevents memory issues with large log volumes
- All parsing is designed to gracefully handle malformed log lines
- The architecture supports adding new log sources (web, desktop)
- Flutter CLI integration supports automatic Flutter SDK detection
- Hot reload/restart can be triggered programmatically or via keyboard shortcuts


