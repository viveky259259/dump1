# Device Management - Implementation Plan

## Overview

This document outlines the comprehensive plan for implementing Device Management (both basic and advanced) in Dreamflow Companion. The implementation follows the existing Clean Architecture pattern used throughout the codebase.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Basic Device Management](#basic-device-management)
3. [Advanced Device Management](#advanced-device-management)
4. [Implementation Phases](#implementation-phases)
5. [Technical Details](#technical-details)
6. [UI/UX Design](#uiux-design)

---

## Architecture Overview

### Layer Structure

Following the existing Clean Architecture pattern:

```
lib/
├── domain/
│   ├── entities/
│   │   ├── device.dart              # Device entity
│   │   ├── device_capability.dart   # Device capabilities enum
│   │   ├── device_status.dart       # Device status enum
│   │   ├── device_type.dart         # Device type enum
│   │   ├── device_info.dart         # Detailed device information
│   │   ├── device_log.dart          # Device log entry
│   │   └── device_group.dart        # Device grouping/tagging
│   ├── repositories/
│   │   └── device_repository.dart   # Device repository interface (see Section 6)
│   └── usecases/
│       └── device/
│           ├── discover_devices.dart
│           ├── get_device_info.dart
│           ├── install_app.dart
│           ├── uninstall_app.dart
│           ├── launch_app.dart
│           ├── stop_app.dart
│           ├── take_screenshot.dart
│           ├── record_screen.dart
│           ├── get_device_logs.dart
│           ├── transfer_file.dart
│           ├── execute_shell_command.dart
│           ├── refresh_device_status.dart
│           ├── group_devices.dart
│           └── filter_devices.dart
├── data/
│   ├── models/
│   │   └── dto/
│   │       ├── device_dto.dart
│   │       └── device_info_dto.dart
│   ├── datasources/
│   │   ├── local/
│   │   │   ├── device_local_datasource.dart
│   │   │   └── device_cache_datasource.dart
│   │   └── remote/
│   │       ├── android_device_datasource.dart  # ADB integration
│   │       ├── ios_device_datasource.dart      # xcrun/xcodebuild
│   │       ├── simulator_datasource.dart      # iOS/Android simulators
│   │       └── web_browser_datasource.dart     # Chrome/Edge/Firefox
│   └── repositories/
│       └── device_repository_impl.dart
├── core/
│   ├── services/
│   │   ├── device_discovery_service.dart
│   │   ├── adb_service.dart
│   │   ├── ios_device_service.dart
│   │   └── device_monitor_service.dart
│   └── platform/
│       └── device_platform_service.dart
└── presentation/
    ├── providers/
    │   └── device/
    │       ├── device_providers.dart
    │       └── device_discovery_provider.dart
    ├── screens/
    │   └── device/
    │       ├── device_list_screen.dart
    │       ├── device_detail_screen.dart
    │       └── device_operations_screen.dart
    └── widgets/
        └── device/
            ├── device_card.dart
            ├── device_status_indicator.dart
            ├── device_selection_dropdown.dart
            └── device_info_panel.dart
```

---

## Basic Device Management

### 1. Device Discovery

#### 1.1 Supported Platforms

**Android Devices**
- Physical devices via ADB (Android Debug Bridge)
- Android Emulators (AVD)
- Detection via `adb devices` command
- USB debugging support
- Wireless ADB support

**iOS Devices**
- Physical devices via Xcode tools (`xcrun`, `xcodebuild`)
- iOS Simulators
- Detection via `xcrun simctl list devices`
- Requires Xcode installation
- Requires developer account for physical devices

**Web Browsers**
- Chrome/Chromium
- Edge
- Firefox
- Safari (macOS only)
- Detection via browser automation tools

**Desktop Platforms**
- macOS (current platform)
- Windows (future)
- Linux (future)

#### 1.2 Device Discovery Service

**Responsibilities:**
- Periodic device scanning (configurable interval)
- Platform-specific device detection
- Device status monitoring
- Device connection/disconnection events
- Caching discovered devices

**File: `lib/core/services/device_discovery_service.dart`**

```dart
import 'dart:async';
import '../logging/logging.dart';
import '../../domain/entities/device.dart';
import '../../domain/entities/device_type.dart';
import '../../domain/entities/device_status.dart';
import 'adb_service.dart';
import 'ios_device_service.dart';

/// Events emitted during device discovery
sealed class DeviceEvent {
  final Device device;
  final DateTime timestamp;
  DeviceEvent(this.device) : timestamp = DateTime.now();
}

class DeviceConnectedEvent extends DeviceEvent {
  DeviceConnectedEvent(super.device);
}

class DeviceDisconnectedEvent extends DeviceEvent {
  DeviceDisconnectedEvent(super.device);
}

class DeviceStatusChangedEvent extends DeviceEvent {
  final DeviceStatus previousStatus;
  DeviceStatusChangedEvent(super.device, this.previousStatus);
}

/// Service responsible for discovering and monitoring devices
class DeviceDiscoveryService with LoggerMixin {
  final AdbService _adbService;
  final IosDeviceService _iosDeviceService;
  
  final Duration _scanInterval;
  Timer? _scanTimer;
  bool _isMonitoring = false;
  
  final _devicesController = StreamController<List<Device>>.broadcast();
  final _eventsController = StreamController<DeviceEvent>.broadcast();
  final Map<String, Device> _deviceCache = {};

  DeviceDiscoveryService({
    AdbService? adbService,
    IosDeviceService? iosDeviceService,
    Duration scanInterval = const Duration(seconds: 5),
  })  : _adbService = adbService ?? AdbService(),
        _iosDeviceService = iosDeviceService ?? IosDeviceService(),
        _scanInterval = scanInterval;

  /// Stream of discovered devices
  Stream<List<Device>> get devices => _devicesController.stream;

  /// Stream of device events
  Stream<DeviceEvent> get events => _eventsController.stream;

  /// Get currently cached devices
  List<Device> get cachedDevices => List.unmodifiable(_deviceCache.values);

  /// Check if monitoring is active
  bool get isMonitoring => _isMonitoring;

  /// Scan all platforms for devices
  Future<List<Device>> scanDevices() async {
    return await logAsyncOperation('scanDevices', () async {
      final devices = <Device>[];
      
      // Scan Android devices in parallel with iOS
      final results = await Future.wait([
        _scanAndroidDevices(),
        _scanIosDevices(),
        _scanWebBrowsers(),
      ], eagerError: false);
      
      for (final result in results) {
        devices.addAll(result);
      }
      
      // Update cache and emit events
      _updateDeviceCache(devices);
      
      logger.info('Device scan complete', {'deviceCount': devices.length});
      return devices;
    });
  }

  /// Start continuous device monitoring
  void startMonitoring() {
    if (_isMonitoring) return;
    
    _isMonitoring = true;
    logger.info('Starting device monitoring', {'interval': _scanInterval});
    
    // Initial scan
    scanDevices();
    
    // Periodic scanning
    _scanTimer = Timer.periodic(_scanInterval, (_) => scanDevices());
  }

  /// Stop device monitoring
  void stopMonitoring() {
    if (!_isMonitoring) return;
    
    _isMonitoring = false;
    _scanTimer?.cancel();
    _scanTimer = null;
    logger.info('Stopped device monitoring');
  }

  /// Refresh status for a specific device
  Future<Device?> refreshDeviceStatus(String deviceId) async {
    final device = _deviceCache[deviceId];
    if (device == null) return null;
    
    try {
      Device? updatedDevice;
      
      if (device.type == DeviceType.android || 
          device.type == DeviceType.androidEmulator) {
        updatedDevice = await _adbService.getDeviceInfo(deviceId);
      } else if (device.type == DeviceType.ios || 
                 device.type == DeviceType.iosSimulator) {
        updatedDevice = await _iosDeviceService.getDeviceInfo(deviceId);
      }
      
      if (updatedDevice != null) {
        _updateSingleDevice(updatedDevice);
        return updatedDevice;
      }
    } catch (e) {
      logger.error('Failed to refresh device status', e, null, {'deviceId': deviceId});
    }
    
    return device;
  }

  Future<List<Device>> _scanAndroidDevices() async {
    try {
      return await _adbService.getConnectedDevices();
    } catch (e) {
      logger.error('Failed to scan Android devices', e);
      return [];
    }
  }

  Future<List<Device>> _scanIosDevices() async {
    try {
      return await _iosDeviceService.getConnectedDevices();
    } catch (e) {
      logger.error('Failed to scan iOS devices', e);
      return [];
    }
  }

  Future<List<Device>> _scanWebBrowsers() async {
    // Web browsers are always available
    return [
      const Device(
        id: 'chrome',
        name: 'Chrome',
        type: DeviceType.webChrome,
        status: DeviceStatus.connected,
      ),
    ];
  }

  void _updateDeviceCache(List<Device> devices) {
    final currentIds = devices.map((d) => d.id).toSet();
    final cachedIds = _deviceCache.keys.toSet();
    
    // Find disconnected devices
    for (final id in cachedIds.difference(currentIds)) {
      final device = _deviceCache.remove(id);
      if (device != null) {
        _eventsController.add(DeviceDisconnectedEvent(device));
      }
    }
    
    // Update or add devices
    for (final device in devices) {
      final existing = _deviceCache[device.id];
      
      if (existing == null) {
        // New device
        _deviceCache[device.id] = device;
        _eventsController.add(DeviceConnectedEvent(device));
      } else if (existing.status != device.status) {
        // Status changed
        _deviceCache[device.id] = device;
        _eventsController.add(DeviceStatusChangedEvent(device, existing.status));
      } else {
        // Update cached device
        _deviceCache[device.id] = device;
      }
    }
    
    _devicesController.add(cachedDevices);
  }

  void _updateSingleDevice(Device device) {
    final existing = _deviceCache[device.id];
    _deviceCache[device.id] = device;
    
    if (existing != null && existing.status != device.status) {
      _eventsController.add(DeviceStatusChangedEvent(device, existing.status));
    }
    
    _devicesController.add(cachedDevices);
  }

  /// Dispose of resources
  void dispose() {
    stopMonitoring();
    _devicesController.close();
    _eventsController.close();
    _deviceCache.clear();
  }
}
```

### 2. Device Entity Model

#### 2.1 Core Device Entity

**File: `lib/domain/entities/device.dart`**

```dart
import 'package:flutter/foundation.dart';

/// Domain entity representing a device for testing
@immutable
class Device {
  final String id;
  final String name;
  final DeviceType type;
  final DeviceStatus status;
  final String? osVersion;
  final String? sdkVersion;
  final DeviceCapabilities capabilities;
  final DateTime? lastSeen;
  final Map<String, dynamic> metadata;
  final bool isFavorite;
  final List<String> tags;

  const Device({
    required this.id,
    required this.name,
    required this.type,
    required this.status,
    this.osVersion,
    this.sdkVersion,
    this.capabilities = const DeviceCapabilities(),
    this.lastSeen,
    this.metadata = const {},
    this.isFavorite = false,
    this.tags = const [],
  });

  /// Human-readable display name with status
  String get displayName => '$name (${type.displayName})';

  /// Check if device is available for operations
  bool get isAvailable => status == DeviceStatus.connected;

  /// Check if this is a physical device
  bool get isPhysicalDevice =>
      type == DeviceType.android || type == DeviceType.ios;

  /// Check if this is a simulator/emulator
  bool get isSimulator =>
      type == DeviceType.iosSimulator || type == DeviceType.androidEmulator;

  /// Check if this is a mobile device (physical or virtual)
  bool get isMobile =>
      type == DeviceType.android ||
      type == DeviceType.androidEmulator ||
      type == DeviceType.ios ||
      type == DeviceType.iosSimulator;

  /// Check if this is a web browser
  bool get isWeb =>
      type == DeviceType.webChrome ||
      type == DeviceType.webEdge ||
      type == DeviceType.webFirefox ||
      type == DeviceType.webSafari;

  /// Check if this is a desktop platform
  bool get isDesktop =>
      type == DeviceType.macos ||
      type == DeviceType.windows ||
      type == DeviceType.linux;

  Device copyWith({
    String? id,
    String? name,
    DeviceType? type,
    DeviceStatus? status,
    String? osVersion,
    String? sdkVersion,
    DeviceCapabilities? capabilities,
    DateTime? lastSeen,
    Map<String, dynamic>? metadata,
    bool? isFavorite,
    List<String>? tags,
  }) {
    return Device(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      status: status ?? this.status,
      osVersion: osVersion ?? this.osVersion,
      sdkVersion: sdkVersion ?? this.sdkVersion,
      capabilities: capabilities ?? this.capabilities,
      lastSeen: lastSeen ?? this.lastSeen,
      metadata: metadata ?? this.metadata,
      isFavorite: isFavorite ?? this.isFavorite,
      tags: tags ?? this.tags,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Device && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => 'Device($name, $id, ${status.name})';

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type.name,
        'status': status.name,
        'osVersion': osVersion,
        'sdkVersion': sdkVersion,
        'capabilities': capabilities.toJson(),
        'lastSeen': lastSeen?.toIso8601String(),
        'metadata': metadata,
        'isFavorite': isFavorite,
        'tags': tags,
      };

  factory Device.fromJson(Map<String, dynamic> json) => Device(
        id: json['id'] as String,
        name: json['name'] as String,
        type: DeviceType.values.byName(json['type'] as String),
        status: DeviceStatus.values.byName(json['status'] as String),
        osVersion: json['osVersion'] as String?,
        sdkVersion: json['sdkVersion'] as String?,
        capabilities: json['capabilities'] != null
            ? DeviceCapabilities.fromJson(
                json['capabilities'] as Map<String, dynamic>)
            : const DeviceCapabilities(),
        lastSeen: json['lastSeen'] != null
            ? DateTime.parse(json['lastSeen'] as String)
            : null,
        metadata: (json['metadata'] as Map<String, dynamic>?) ?? {},
        isFavorite: json['isFavorite'] as bool? ?? false,
        tags: (json['tags'] as List<dynamic>?)?.cast<String>() ?? [],
      );
}
```

#### 2.2 Device Types

**File: `lib/domain/entities/device_type.dart`**

```dart
/// Enum representing all supported device types
enum DeviceType {
  android('Android Device'),
  androidEmulator('Android Emulator'),
  ios('iOS Device'),
  iosSimulator('iOS Simulator'),
  webChrome('Chrome'),
  webEdge('Edge'),
  webFirefox('Firefox'),
  webSafari('Safari'),
  macos('macOS'),
  windows('Windows'),
  linux('Linux');

  final String displayName;
  const DeviceType(this.displayName);

  /// Get platform category for grouping
  String get category {
    switch (this) {
      case DeviceType.android:
      case DeviceType.androidEmulator:
        return 'Android';
      case DeviceType.ios:
      case DeviceType.iosSimulator:
        return 'iOS';
      case DeviceType.webChrome:
      case DeviceType.webEdge:
      case DeviceType.webFirefox:
      case DeviceType.webSafari:
        return 'Web';
      case DeviceType.macos:
      case DeviceType.windows:
      case DeviceType.linux:
        return 'Desktop';
    }
  }

  /// Get icon name for this device type
  String get iconName {
    switch (this) {
      case DeviceType.android:
      case DeviceType.androidEmulator:
        return 'android';
      case DeviceType.ios:
      case DeviceType.iosSimulator:
        return 'apple';
      case DeviceType.webChrome:
        return 'chrome';
      case DeviceType.webEdge:
        return 'edge';
      case DeviceType.webFirefox:
        return 'firefox';
      case DeviceType.webSafari:
        return 'safari';
      case DeviceType.macos:
        return 'desktop_mac';
      case DeviceType.windows:
        return 'desktop_windows';
      case DeviceType.linux:
        return 'computer';
    }
  }

  /// Parse device type from Flutter's target platform string
  static DeviceType? fromTargetPlatform(String platform) {
    switch (platform.toLowerCase()) {
      case 'android-arm':
      case 'android-arm64':
      case 'android-x64':
      case 'android-x86':
        return DeviceType.android;
      case 'ios':
        return DeviceType.ios;
      case 'darwin-x64':
      case 'darwin-arm64':
        return DeviceType.macos;
      case 'windows-x64':
        return DeviceType.windows;
      case 'linux-x64':
      case 'linux-arm64':
        return DeviceType.linux;
      case 'web-javascript':
        return DeviceType.webChrome;
      default:
        return null;
    }
  }
}
```

#### 2.3 Device Status

**File: `lib/domain/entities/device_status.dart`**

```dart
/// Enum representing device connection status
enum DeviceStatus {
  connected('Connected', true),
  disconnected('Disconnected', false),
  unauthorized('Unauthorized', false),
  offline('Offline', false),
  booting('Booting...', false),
  busy('Busy', false),
  unknown('Unknown', false);

  final String displayName;
  final bool isOperational;
  
  const DeviceStatus(this.displayName, this.isOperational);

  /// Get color hint for UI display
  String get colorHint {
    switch (this) {
      case DeviceStatus.connected:
        return 'green';
      case DeviceStatus.booting:
      case DeviceStatus.busy:
        return 'orange';
      case DeviceStatus.unauthorized:
        return 'yellow';
      case DeviceStatus.disconnected:
      case DeviceStatus.offline:
      case DeviceStatus.unknown:
        return 'red';
    }
  }
}
```

#### 2.4 Device Capabilities

**File: `lib/domain/entities/device_capabilities.dart`**

```dart
import 'package:flutter/foundation.dart';

/// Represents the capabilities of a device
@immutable
class DeviceCapabilities {
  final bool supportsScreenshot;
  final bool supportsScreenRecording;
  final bool supportsFileTransfer;
  final bool supportsShellAccess;
  final bool supportsAppInstall;
  final bool supportsLogs;
  final bool supportsBatteryInfo;
  final bool supportsNetworkInfo;
  final bool supportsStorageInfo;
  final ScreenInfo? screenInfo;

  const DeviceCapabilities({
    this.supportsScreenshot = false,
    this.supportsScreenRecording = false,
    this.supportsFileTransfer = false,
    this.supportsShellAccess = false,
    this.supportsAppInstall = false,
    this.supportsLogs = false,
    this.supportsBatteryInfo = false,
    this.supportsNetworkInfo = false,
    this.supportsStorageInfo = false,
    this.screenInfo,
  });

  /// Full capabilities for Android devices
  factory DeviceCapabilities.android({ScreenInfo? screenInfo}) =>
      DeviceCapabilities(
        supportsScreenshot: true,
        supportsScreenRecording: true,
        supportsFileTransfer: true,
        supportsShellAccess: true,
        supportsAppInstall: true,
        supportsLogs: true,
        supportsBatteryInfo: true,
        supportsNetworkInfo: true,
        supportsStorageInfo: true,
        screenInfo: screenInfo,
      );

  /// Full capabilities for iOS devices
  factory DeviceCapabilities.ios({ScreenInfo? screenInfo}) =>
      DeviceCapabilities(
        supportsScreenshot: true,
        supportsScreenRecording: true,
        supportsFileTransfer: true,
        supportsShellAccess: false, // Limited shell access on iOS
        supportsAppInstall: true,
        supportsLogs: true,
        supportsBatteryInfo: true,
        supportsNetworkInfo: true,
        supportsStorageInfo: true,
        screenInfo: screenInfo,
      );

  /// Limited capabilities for web browsers
  factory DeviceCapabilities.web() => const DeviceCapabilities(
        supportsScreenshot: true,
        supportsScreenRecording: false,
        supportsFileTransfer: false,
        supportsShellAccess: false,
        supportsAppInstall: false,
        supportsLogs: true,
        supportsBatteryInfo: false,
        supportsNetworkInfo: false,
        supportsStorageInfo: false,
      );

  /// Desktop capabilities
  factory DeviceCapabilities.desktop({ScreenInfo? screenInfo}) =>
      DeviceCapabilities(
        supportsScreenshot: true,
        supportsScreenRecording: true,
        supportsFileTransfer: true,
        supportsShellAccess: true,
        supportsAppInstall: true,
        supportsLogs: true,
        supportsBatteryInfo: false,
        supportsNetworkInfo: true,
        supportsStorageInfo: true,
        screenInfo: screenInfo,
      );

  Map<String, dynamic> toJson() => {
        'supportsScreenshot': supportsScreenshot,
        'supportsScreenRecording': supportsScreenRecording,
        'supportsFileTransfer': supportsFileTransfer,
        'supportsShellAccess': supportsShellAccess,
        'supportsAppInstall': supportsAppInstall,
        'supportsLogs': supportsLogs,
        'supportsBatteryInfo': supportsBatteryInfo,
        'supportsNetworkInfo': supportsNetworkInfo,
        'supportsStorageInfo': supportsStorageInfo,
        'screenInfo': screenInfo?.toJson(),
      };

  factory DeviceCapabilities.fromJson(Map<String, dynamic> json) =>
      DeviceCapabilities(
        supportsScreenshot: json['supportsScreenshot'] as bool? ?? false,
        supportsScreenRecording:
            json['supportsScreenRecording'] as bool? ?? false,
        supportsFileTransfer: json['supportsFileTransfer'] as bool? ?? false,
        supportsShellAccess: json['supportsShellAccess'] as bool? ?? false,
        supportsAppInstall: json['supportsAppInstall'] as bool? ?? false,
        supportsLogs: json['supportsLogs'] as bool? ?? false,
        supportsBatteryInfo: json['supportsBatteryInfo'] as bool? ?? false,
        supportsNetworkInfo: json['supportsNetworkInfo'] as bool? ?? false,
        supportsStorageInfo: json['supportsStorageInfo'] as bool? ?? false,
        screenInfo: json['screenInfo'] != null
            ? ScreenInfo.fromJson(json['screenInfo'] as Map<String, dynamic>)
            : null,
      );
}

/// Screen information for a device
@immutable
class ScreenInfo {
  final int width;
  final int height;
  final double density;
  final String? orientation;

  const ScreenInfo({
    required this.width,
    required this.height,
    required this.density,
    this.orientation,
  });

  double get aspectRatio => width / height;
  String get resolution => '${width}x$height';
  bool get isPortrait => height > width;

  Map<String, dynamic> toJson() => {
        'width': width,
        'height': height,
        'density': density,
        'orientation': orientation,
      };

  factory ScreenInfo.fromJson(Map<String, dynamic> json) => ScreenInfo(
        width: json['width'] as int,
        height: json['height'] as int,
        density: (json['density'] as num).toDouble(),
        orientation: json['orientation'] as String?,
      );
}
```

### 3. Device Information

#### 3.1 Basic Information
- Device name/model
- OS version
- SDK/API level
- Device type (physical/simulator/emulator)
- Connection status

#### 3.2 Extended Information (when available)
- Screen resolution and density
- Battery level (mobile devices)
- Storage information (total/used/available)
- Network information (IP address, connection type)
- CPU architecture
- RAM information
- Device manufacturer
- Serial number/UDID

### 4. Basic Device Operations

#### 4.1 App Management
- **Install App**: Install APK/IPA to device
- **Uninstall App**: Remove app from device
- **Launch App**: Start app on device
- **Stop App**: Force stop app on device
- **List Installed Apps**: Get list of installed apps

#### 4.2 Screenshot & Recording
- **Take Screenshot**: Capture device screen
- **Record Screen**: Start/stop screen recording
- **Save Media**: Save screenshots/recordings to local storage

#### 4.3 Logs
- **View Logs**: Stream device logs (logcat for Android, syslog for iOS)
- **Filter Logs**: Filter by level, tag, package
- **Export Logs**: Export logs to file
- **Clear Logs**: Clear log buffer

### 5. Device Grouping & Organization

#### 5.1 Device Groups
- Create custom device groups
- Assign devices to groups
- Group-based filtering
- Quick actions on groups

#### 5.2 Device Tags
- Tag devices with custom labels
- Multiple tags per device
- Tag-based filtering
- Common tags: "favorite", "testing", "production", "development"

#### 5.3 Device Favorites
- Mark devices as favorites
- Quick access to favorite devices
- Favorite devices appear first in lists

---

## Advanced Device Management

### 1. Advanced Device Operations

#### 1.1 File Transfer
- **Push File**: Transfer file from host to device
- **Pull File**: Transfer file from device to host
- **Sync Directory**: Sync entire directories
- **File Browser**: Browse device file system
- **File Manager**: Full file management UI

#### 1.2 Shell Access
- **Execute Command**: Run shell commands on device
- **Interactive Shell**: Interactive terminal session
- **Command History**: Save and replay commands
- **Script Execution**: Run shell scripts

#### 1.3 Performance Monitoring
- **CPU Usage**: Monitor CPU usage per process
- **Memory Usage**: Monitor RAM usage
- **Network Activity**: Monitor network traffic
- **Battery Monitoring**: Track battery consumption
- **Performance Profiling**: Integration with Flutter DevTools

#### 1.4 Advanced Logging
- **Real-time Log Streaming**: Stream logs with filtering
- **Log Aggregation**: Aggregate logs from multiple devices
- **Log Analysis**: Analyze logs for patterns/errors
- **Log Search**: Full-text search across logs
- **Log Export Formats**: JSON, CSV, plain text

### 2. Device Configuration

#### 2.1 Device Settings
- **Developer Options**: Toggle developer settings
- **USB Debugging**: Enable/disable USB debugging
- **Wireless Debugging**: Configure wireless ADB
- **Screen Settings**: Adjust screen timeout, brightness
- **Network Settings**: Configure network preferences

#### 2.2 Build Configuration
- **Device-specific Builds**: Configure builds per device
- **Flavor Management**: Manage build flavors per device
- **Environment Variables**: Set environment variables per device
- **Build Profiles**: Debug, Profile, Release per device

### 3. Multi-Device Operations

#### 3.1 Batch Operations
- **Batch Install**: Install app on multiple devices
- **Batch Screenshot**: Take screenshots on all selected devices
- **Batch Log Collection**: Collect logs from multiple devices
- **Batch File Transfer**: Transfer files to multiple devices

#### 3.2 Device Comparison
- **Side-by-side Comparison**: Compare device screens side-by-side
- **Performance Comparison**: Compare performance metrics
- **Log Comparison**: Compare logs across devices

### 4. Device Automation

#### 4.1 Test Automation
- **Automated Testing**: Run tests on multiple devices
- **Test Reports**: Generate test reports per device
- **Screenshot Comparison**: Compare screenshots for visual regression

#### 4.2 Workflow Automation
- **Custom Workflows**: Create custom device workflows
- **Workflow Templates**: Pre-built workflow templates
- **Scheduled Tasks**: Schedule device operations
- **Event Triggers**: Trigger actions on device events

### 5. Device Monitoring & Alerts

#### 5.1 Real-time Monitoring
- **Device Health**: Monitor device health metrics
- **Connection Status**: Monitor connection stability
- **Resource Usage**: Monitor CPU, memory, storage
- **Battery Status**: Monitor battery level and charging status

#### 5.2 Alerts & Notifications
- **Device Disconnected**: Alert when device disconnects
- **Low Battery**: Alert when battery is low
- **High Resource Usage**: Alert on high CPU/memory usage
- **Storage Full**: Alert when storage is nearly full
- **Custom Alerts**: User-defined alert conditions

### 6. Integration Features

#### 6.1 Flutter Integration
- **Device Selection**: Select device for Flutter run/build
- **Hot Reload**: Trigger hot reload on selected devices
- **Hot Restart**: Trigger hot restart on selected devices
- **DevTools Integration**: Launch DevTools for device

#### 6.2 Git Integration
- **Device-specific Branches**: Manage branches per device
- **Device Tags**: Tag commits with device information
- **Device History**: Track device usage in Git history

#### 6.3 Project Integration
- **Project-Device Mapping**: Associate devices with projects
- **Device Preferences**: Save device preferences per project
- **Quick Device Switch**: Quick switch between devices per project

---

## Implementation Phases

### Phase 1: Foundation (Basic Device Management)

**Domain Layer:**
- ✅ Device entity and related entities
- ✅ Device repository interface
- ✅ Basic use cases (discover, get info, install, launch, stop, screenshot, logs)

**Data Layer:**
- ✅ Device DTOs
- ✅ Device local data source (caching)
- ✅ Android device data source (ADB)
- ✅ iOS device data source (xcrun)
- ✅ Device repository implementation

**Core Services:**
- ✅ Device discovery service
- ✅ ADB service wrapper
- ✅ iOS device service wrapper
- ✅ Device monitor service

**Presentation Layer:**
- ✅ Device list screen
- ✅ Device detail screen
- ✅ Device providers
- ✅ Basic device widgets

**Estimated Time:** 2-3 weeks

### Phase 2: Enhanced Operations (Advanced Basic Features)

**Domain Layer:**
- ✅ Advanced use cases (uninstall, record screen, file transfer, shell access)
- ✅ Device grouping use cases

**Data Layer:**
- ✅ Simulator/emulator data sources
- ✅ Web browser data source
- ✅ Enhanced device info collection

**Presentation Layer:**
- ✅ Device operations screen
- ✅ Device grouping UI
- ✅ Device filtering and search
- ✅ Enhanced device widgets

**Estimated Time:** 1-2 weeks

### Phase 3: Advanced Features

**Domain Layer:**
- ✅ Performance monitoring use cases
- ✅ Advanced logging use cases
- ✅ Multi-device operation use cases
- ✅ Automation use cases

**Data Layer:**
- ✅ Performance monitoring data sources
- ✅ Advanced logging data sources
- ✅ Device configuration data sources

**Core Services:**
- ✅ Performance monitor service
- ✅ Log aggregation service
- ✅ Device automation service

**Presentation Layer:**
- ✅ Performance monitoring screen
- ✅ Advanced logging screen
- ✅ Multi-device operations screen
- ✅ Device automation screen

**Estimated Time:** 2-3 weeks

### Phase 4: Integration & Polish

**Integration:**
- ✅ Flutter integration (device selection in run/build)
- ✅ Git integration (device tags, history)
- ✅ Project integration (device preferences)

**Polish:**
- ✅ Error handling improvements
- ✅ Performance optimizations
- ✅ UI/UX refinements
- ✅ Documentation
- ✅ Testing

**Estimated Time:** 1-2 weeks

---

## Technical Details

### 1. Android Device Integration (ADB)

#### 1.1 ADB Service

**File: `lib/core/services/adb_service.dart`**

```dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../logging/logging.dart';
import '../../domain/entities/device.dart';
import '../../domain/entities/device_type.dart';
import '../../domain/entities/device_status.dart';
import '../../domain/entities/device_capabilities.dart';

/// Exception thrown when ADB operations fail
class AdbException implements Exception {
  final String message;
  final String? command;
  final int? exitCode;
  final String? stderr;

  const AdbException(this.message, {this.command, this.exitCode, this.stderr});

  @override
  String toString() =>
      'AdbException: $message${command != null ? ' (command: $command)' : ''}';
}

/// Service for Android Debug Bridge (ADB) operations
class AdbService with LoggerMixin {
  String? _adbPath;
  static const _defaultTimeout = Duration(seconds: 30);

  AdbService({String? adbPath}) : _adbPath = adbPath;

  /// Get or detect ADB path
  Future<String> get adbPath async {
    if (_adbPath != null) return _adbPath!;
    _adbPath = await _detectAdbPath();
    return _adbPath!;
  }

  /// Get all connected Android devices
  Future<List<Device>> getConnectedDevices() async {
    final result = await _runAdb(['devices', '-l']);
    final devices = <Device>[];
    
    final lines = result.split('\n').skip(1); // Skip header
    for (final line in lines) {
      if (line.trim().isEmpty) continue;
      
      final device = _parseDeviceLine(line);
      if (device != null) {
        devices.add(device);
      }
    }
    
    return devices;
  }

  /// Get detailed device info
  Future<Device?> getDeviceInfo(String deviceId) async {
    try {
      final props = await _getDeviceProperties(deviceId);
      
      final name = props['ro.product.model'] ?? 
                   props['ro.product.name'] ?? 
                   'Android Device';
      final osVersion = props['ro.build.version.release'];
      final sdkVersion = props['ro.build.version.sdk'];
      final manufacturer = props['ro.product.manufacturer'];
      
      final isEmulator = props['ro.kernel.qemu'] == '1' ||
                         deviceId.startsWith('emulator-');
      
      // Get screen info
      final screenInfo = await _getScreenInfo(deviceId);
      
      return Device(
        id: deviceId,
        name: manufacturer != null ? '$manufacturer $name' : name,
        type: isEmulator ? DeviceType.androidEmulator : DeviceType.android,
        status: DeviceStatus.connected,
        osVersion: osVersion != null ? 'Android $osVersion' : null,
        sdkVersion: 'API $sdkVersion',
        capabilities: DeviceCapabilities.android(screenInfo: screenInfo),
        lastSeen: DateTime.now(),
        metadata: props,
      );
    } catch (e) {
      logger.error('Failed to get device info', e, null, {'deviceId': deviceId});
      return null;
    }
  }

  /// Install APK on device
  Future<void> installApp(String deviceId, String apkPath) async {
    await logAsyncOperation(
      'installApp',
      () => _runAdb(['-s', deviceId, 'install', '-r', apkPath]),
      context: {'deviceId': deviceId, 'apkPath': apkPath},
    );
  }

  /// Uninstall app from device
  Future<void> uninstallApp(String deviceId, String packageName) async {
    await logAsyncOperation(
      'uninstallApp',
      () => _runAdb(['-s', deviceId, 'uninstall', packageName]),
      context: {'deviceId': deviceId, 'packageName': packageName},
    );
  }

  /// Launch app on device
  Future<void> launchApp(String deviceId, String packageName, {String? activity}) async {
    final component = activity != null 
        ? '$packageName/$activity'
        : '$packageName/.MainActivity';
    
    await _runAdb([
      '-s', deviceId,
      'shell', 'am', 'start',
      '-n', component,
    ]);
  }

  /// Force stop app on device
  Future<void> stopApp(String deviceId, String packageName) async {
    await _runAdb(['-s', deviceId, 'shell', 'am', 'force-stop', packageName]);
  }

  /// Take screenshot and return PNG bytes
  Future<Uint8List> takeScreenshot(String deviceId) async {
    final result = await Process.run(
      await adbPath,
      ['-s', deviceId, 'exec-out', 'screencap', '-p'],
      stdoutEncoding: null,
    );
    
    if (result.exitCode != 0) {
      throw AdbException(
        'Screenshot failed',
        command: 'screencap',
        exitCode: result.exitCode,
        stderr: result.stderr?.toString(),
      );
    }
    
    return Uint8List.fromList(result.stdout as List<int>);
  }

  /// Start screen recording
  Future<Process> startScreenRecording(
    String deviceId,
    String remotePath, {
    Duration? maxDuration,
    int? bitRate,
  }) async {
    final args = ['-s', deviceId, 'shell', 'screenrecord'];
    if (maxDuration != null) {
      args.addAll(['--time-limit', '${maxDuration.inSeconds}']);
    }
    if (bitRate != null) {
      args.addAll(['--bit-rate', '$bitRate']);
    }
    args.add(remotePath);
    
    return Process.start(await adbPath, args);
  }

  /// Stream device logs
  Stream<String> getLogs(String deviceId, {String? filter, String? tag}) async* {
    final args = ['-s', deviceId, 'logcat'];
    if (filter != null) {
      args.addAll(['-s', filter]);
    }
    if (tag != null) {
      args.add('$tag:*');
    }
    
    final process = await Process.start(await adbPath, args);
    
    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      yield chunk;
    }
  }

  /// Clear logcat buffer
  Future<void> clearLogs(String deviceId) async {
    await _runAdb(['-s', deviceId, 'logcat', '-c']);
  }

  /// Push file to device
  Future<void> pushFile(String deviceId, String localPath, String remotePath) async {
    await logAsyncOperation(
      'pushFile',
      () => _runAdb(['-s', deviceId, 'push', localPath, remotePath]),
      context: {'localPath': localPath, 'remotePath': remotePath},
    );
  }

  /// Pull file from device
  Future<void> pullFile(String deviceId, String remotePath, String localPath) async {
    await logAsyncOperation(
      'pullFile',
      () => _runAdb(['-s', deviceId, 'pull', remotePath, localPath]),
      context: {'remotePath': remotePath, 'localPath': localPath},
    );
  }

  /// Execute shell command on device
  Future<String> executeShellCommand(String deviceId, String command) async {
    return await _runAdb(['-s', deviceId, 'shell', command]);
  }

  /// Get list of installed packages
  Future<List<String>> getInstalledPackages(String deviceId) async {
    final result = await _runAdb(['-s', deviceId, 'shell', 'pm', 'list', 'packages']);
    return result
        .split('\n')
        .where((line) => line.startsWith('package:'))
        .map((line) => line.substring(8).trim())
        .toList();
  }

  /// Connect to device over TCP/IP (wireless ADB)
  Future<void> connectWireless(String ipAddress, {int port = 5555}) async {
    await _runAdb(['connect', '$ipAddress:$port']);
  }

  /// Disconnect from wireless device
  Future<void> disconnectWireless(String ipAddress, {int port = 5555}) async {
    await _runAdb(['disconnect', '$ipAddress:$port']);
  }

  // Private methods

  Future<String> _runAdb(
    List<String> args, {
    Duration timeout = _defaultTimeout,
  }) async {
    final adb = await adbPath;
    logger.debug('Running ADB command', {'command': '$adb ${args.join(' ')}'});
    
    final result = await Process.run(
      adb,
      args,
      stdoutEncoding: utf8,
      stderrEncoding: utf8,
    ).timeout(timeout);
    
    if (result.exitCode != 0) {
      throw AdbException(
        'ADB command failed',
        command: args.join(' '),
        exitCode: result.exitCode,
        stderr: result.stderr as String?,
      );
    }
    
    return result.stdout as String;
  }

  Device? _parseDeviceLine(String line) {
    final parts = line.split(RegExp(r'\s+'));
    if (parts.length < 2) return null;
    
    final id = parts[0];
    final state = parts[1];
    
    // Parse additional info
    String? model;
    String? product;
    for (final part in parts.skip(2)) {
      if (part.startsWith('model:')) {
        model = part.substring(6);
      } else if (part.startsWith('product:')) {
        product = part.substring(8);
      }
    }
    
    final status = switch (state) {
      'device' => DeviceStatus.connected,
      'offline' => DeviceStatus.offline,
      'unauthorized' => DeviceStatus.unauthorized,
      'no permissions' => DeviceStatus.unauthorized,
      _ => DeviceStatus.unknown,
    };
    
    final isEmulator = id.startsWith('emulator-');
    
    return Device(
      id: id,
      name: model ?? product ?? id,
      type: isEmulator ? DeviceType.androidEmulator : DeviceType.android,
      status: status,
      lastSeen: DateTime.now(),
    );
  }

  Future<Map<String, String>> _getDeviceProperties(String deviceId) async {
    final result = await _runAdb(['-s', deviceId, 'shell', 'getprop']);
    final props = <String, String>{};
    
    for (final line in result.split('\n')) {
      final match = RegExp(r'\[(.*?)\]:\s*\[(.*?)\]').firstMatch(line);
      if (match != null) {
        props[match.group(1)!] = match.group(2)!;
      }
    }
    
    return props;
  }

  Future<ScreenInfo?> _getScreenInfo(String deviceId) async {
    try {
      final result = await _runAdb([
        '-s', deviceId, 'shell', 'wm', 'size'
      ]);
      
      final match = RegExp(r'(\d+)x(\d+)').firstMatch(result);
      if (match != null) {
        final width = int.parse(match.group(1)!);
        final height = int.parse(match.group(2)!);
        
        final densityResult = await _runAdb([
          '-s', deviceId, 'shell', 'wm', 'density'
        ]);
        final densityMatch = RegExp(r'(\d+)').firstMatch(densityResult);
        final density = densityMatch != null 
            ? int.parse(densityMatch.group(1)!) / 160.0 
            : 1.0;
        
        return ScreenInfo(
          width: width,
          height: height,
          density: density,
        );
      }
    } catch (e) {
      logger.warn('Failed to get screen info', {'error': e.toString()});
    }
    return null;
  }

  Future<String> _detectAdbPath() async {
    // Check common locations
    final locations = [
      // Android SDK from environment
      '${Platform.environment['ANDROID_HOME']}/platform-tools/adb',
      '${Platform.environment['ANDROID_SDK_ROOT']}/platform-tools/adb',
      // Flutter bundled
      '${Platform.environment['FLUTTER_ROOT']}/bin/cache/artifacts/engine/android-sdk/platform-tools/adb',
      // Common macOS locations
      '/Users/${Platform.environment['USER']}/Library/Android/sdk/platform-tools/adb',
      '/usr/local/bin/adb',
      // Try PATH
      'adb',
    ];
    
    for (final path in locations) {
      if (path.isEmpty) continue;
      try {
        final result = await Process.run(path, ['version']);
        if (result.exitCode == 0) {
          logger.info('Found ADB at', {'path': path});
          return path;
        }
      } catch (_) {
        continue;
      }
    }
    
    throw AdbException('ADB not found. Please install Android SDK.');
  }
}
```

#### 1.2 ADB Command Execution

- Use `Process.run` to execute ADB commands
- Parse command output with proper encoding
- Handle errors with `AdbException`
- Support both USB and wireless ADB via `connectWireless()`
- Timeout handling for all operations

#### 1.3 ADB Path Detection

- Check common ADB locations:
  - `ANDROID_HOME` and `ANDROID_SDK_ROOT` environment variables
  - Flutter SDK bundled ADB
  - User-specific Android SDK location
  - System PATH
- Fallback chain with logging for debugging

### 2. iOS Device Integration

#### 2.1 iOS Device Service

**File: `lib/core/services/ios_device_service.dart`**

```dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../logging/logging.dart';
import '../../domain/entities/device.dart';
import '../../domain/entities/device_type.dart';
import '../../domain/entities/device_status.dart';
import '../../domain/entities/device_capabilities.dart';

/// Exception thrown when iOS device operations fail
class IosDeviceException implements Exception {
  final String message;
  final String? command;
  final int? exitCode;

  const IosDeviceException(this.message, {this.command, this.exitCode});

  @override
  String toString() => 'IosDeviceException: $message';
}

/// Service for iOS device and simulator operations
class IosDeviceService with LoggerMixin {
  static const _xcrun = 'xcrun';
  static const _defaultTimeout = Duration(seconds: 60);

  /// Get all connected iOS devices (physical + simulators)
  Future<List<Device>> getConnectedDevices() async {
    final devices = <Device>[];
    
    // Get simulators
    devices.addAll(await getSimulators());
    
    // Get physical devices (requires libimobiledevice)
    try {
      devices.addAll(await getPhysicalDevices());
    } catch (e) {
      logger.warn('Could not detect physical iOS devices', {'error': e.toString()});
    }
    
    return devices;
  }

  /// Get all iOS simulators
  Future<List<Device>> getSimulators() async {
    try {
      final result = await Process.run(
        _xcrun,
        ['simctl', 'list', '--json'],
        stdoutEncoding: utf8,
      );

      if (result.exitCode != 0) {
        throw IosDeviceException(
          'Failed to list simulators',
          command: 'simctl list',
          exitCode: result.exitCode,
        );
      }

      final decoded = json.decode(result.stdout as String) as Map<String, dynamic>;
      final devicesJson = decoded['devices'] as Map<String, dynamic>? ?? {};
      final devices = <Device>[];

      for (final entry in devicesJson.entries) {
        final runtime = entry.key;
        if (!runtime.toLowerCase().contains('ios')) continue;
        
        // Extract iOS version from runtime
        final versionMatch = RegExp(r'iOS[- ]?([\d.]+)').firstMatch(runtime);
        final iosVersion = versionMatch?.group(1);
        
        final sims = entry.value as List<dynamic>? ?? [];

        for (final sim in sims) {
          final simMap = sim as Map<String, dynamic>;
          final udid = simMap['udid'] as String? ?? '';
          if (udid.isEmpty) continue;
          
          final isAvailable = simMap['isAvailable'] as bool? ?? false;
          final state = simMap['state'] as String? ?? 'Shutdown';
          
          final status = switch (state.toLowerCase()) {
            'booted' => DeviceStatus.connected,
            'booting' => DeviceStatus.booting,
            'shutdown' => DeviceStatus.disconnected,
            _ => DeviceStatus.unknown,
          };
          
          devices.add(Device(
            id: udid,
            name: simMap['name'] as String? ?? 'Unknown Simulator',
            type: DeviceType.iosSimulator,
            status: isAvailable ? status : DeviceStatus.offline,
            osVersion: iosVersion != null ? 'iOS $iosVersion' : null,
            capabilities: DeviceCapabilities.ios(),
            lastSeen: DateTime.now(),
            metadata: {
              'runtime': runtime,
              'state': state,
              'isAvailable': isAvailable,
            },
          ));
        }
      }

      // Sort: booted first, then by name
      devices.sort((a, b) {
        if (a.status == DeviceStatus.connected && b.status != DeviceStatus.connected) {
          return -1;
        }
        if (b.status == DeviceStatus.connected && a.status != DeviceStatus.connected) {
          return 1;
        }
        return a.name.compareTo(b.name);
      });

      return devices;
    } catch (e) {
      logger.error('Failed to list iOS simulators', e);
      return [];
    }
  }

  /// Get physical iOS devices using libimobiledevice
  Future<List<Device>> getPhysicalDevices() async {
    final devices = <Device>[];
    
    try {
      // Try idevice_id to list devices
      final result = await Process.run('idevice_id', ['-l']);
      if (result.exitCode != 0) return [];
      
      final udids = (result.stdout as String)
          .split('\n')
          .where((line) => line.trim().isNotEmpty)
          .toList();
      
      for (final udid in udids) {
        final device = await _getPhysicalDeviceInfo(udid.trim());
        if (device != null) {
          devices.add(device);
        }
      }
    } catch (e) {
      // libimobiledevice not installed
      logger.debug('libimobiledevice not available', {'error': e.toString()});
    }
    
    return devices;
  }

  /// Get detailed device info
  Future<Device?> getDeviceInfo(String deviceId) async {
    // Check if simulator
    final simulators = await getSimulators();
    final simulator = simulators.where((d) => d.id == deviceId).firstOrNull;
    if (simulator != null) return simulator;
    
    // Try physical device
    return _getPhysicalDeviceInfo(deviceId);
  }

  /// Boot a simulator
  Future<void> bootSimulator(String udid, {Duration timeout = _defaultTimeout}) async {
    // Check current state
    final device = await getDeviceInfo(udid);
    if (device?.status == DeviceStatus.connected) {
      logger.info('Simulator already booted', {'udid': udid});
      return;
    }

    logger.info('Booting iOS simulator', {'udid': udid});

    final result = await Process.run(
      _xcrun,
      ['simctl', 'boot', udid],
      stdoutEncoding: utf8,
      stderrEncoding: utf8,
    );

    if (result.exitCode != 0) {
      final stderr = result.stderr as String;
      // Ignore if already booted
      if (!stderr.contains('current state: Booted')) {
        throw IosDeviceException(
          'Failed to boot simulator',
          command: 'simctl boot',
          exitCode: result.exitCode,
        );
      }
    }

    // Wait for boot
    await _awaitSimulatorBoot(udid, timeout);

    // Open Simulator.app
    await Process.run('open', [
      '-a', 'Simulator',
      '--args', '-CurrentDeviceUDID', udid,
    ]);
  }

  /// Shutdown a simulator
  Future<void> shutdownSimulator(String udid) async {
    await Process.run(_xcrun, ['simctl', 'shutdown', udid]);
    logger.info('Simulator shutdown', {'udid': udid});
  }

  /// Install app on simulator
  Future<void> installApp(String deviceId, String appPath) async {
    await logAsyncOperation(
      'installApp',
      () async {
        final result = await Process.run(
          _xcrun,
          ['simctl', 'install', deviceId, appPath],
        );
        if (result.exitCode != 0) {
          throw IosDeviceException(
            'Failed to install app',
            command: 'simctl install',
            exitCode: result.exitCode,
          );
        }
      },
      context: {'deviceId': deviceId, 'appPath': appPath},
    );
  }

  /// Uninstall app from simulator
  Future<void> uninstallApp(String deviceId, String bundleId) async {
    await Process.run(_xcrun, ['simctl', 'uninstall', deviceId, bundleId]);
  }

  /// Launch app on simulator
  Future<void> launchApp(String deviceId, String bundleId) async {
    final result = await Process.run(
      _xcrun,
      ['simctl', 'launch', deviceId, bundleId],
    );
    if (result.exitCode != 0) {
      throw IosDeviceException(
        'Failed to launch app',
        command: 'simctl launch',
        exitCode: result.exitCode,
      );
    }
  }

  /// Terminate app on simulator
  Future<void> stopApp(String deviceId, String bundleId) async {
    await Process.run(_xcrun, ['simctl', 'terminate', deviceId, bundleId]);
  }

  /// Take screenshot of simulator
  Future<Uint8List> takeScreenshot(String deviceId) async {
    final result = await Process.run(
      _xcrun,
      ['simctl', 'io', deviceId, 'screenshot', '-'],
      stdoutEncoding: null,
      stderrEncoding: utf8,
    );

    if (result.exitCode != 0) {
      throw IosDeviceException(
        'Screenshot failed',
        command: 'simctl io screenshot',
        exitCode: result.exitCode,
      );
    }

    final stdoutBytes = result.stdout;
    if (stdoutBytes is List<int>) {
      return Uint8List.fromList(stdoutBytes);
    }
    throw const FormatException('Unexpected screenshot output type');
  }

  /// Stream simulator logs
  Stream<String> getLogs(String deviceId, {String? bundleId}) async* {
    final args = ['simctl', 'spawn', deviceId, 'log', 'stream'];
    if (bundleId != null) {
      args.addAll(['--predicate', 'subsystem == "$bundleId"']);
    }
    
    final process = await Process.start(_xcrun, args);
    await for (final chunk in process.stdout.transform(utf8.decoder)) {
      yield chunk;
    }
  }

  /// Start screen recording on simulator
  Future<Process> startScreenRecording(String deviceId, String outputPath) async {
    return Process.start(
      _xcrun,
      ['simctl', 'io', deviceId, 'recordVideo', outputPath],
    );
  }

  /// Push file to simulator
  Future<void> pushFile(String deviceId, String localPath, String remotePath) async {
    // For simulators, copy to data container
    final dataPath = await _getSimulatorDataPath(deviceId);
    if (dataPath != null) {
      await File(localPath).copy('$dataPath/$remotePath');
    }
  }

  /// Open URL on simulator
  Future<void> openUrl(String deviceId, String url) async {
    await Process.run(_xcrun, ['simctl', 'openurl', deviceId, url]);
  }

  /// Get list of installed apps on simulator
  Future<List<String>> getInstalledApps(String deviceId) async {
    final result = await Process.run(
      _xcrun,
      ['simctl', 'listapps', deviceId],
    );
    
    if (result.exitCode != 0) return [];
    
    // Parse plist output for bundle IDs
    final bundleIds = <String>[];
    final matches = RegExp(r'CFBundleIdentifier.*?=.*?"([^"]+)"')
        .allMatches(result.stdout as String);
    for (final match in matches) {
      bundleIds.add(match.group(1)!);
    }
    return bundleIds;
  }

  // Private methods

  Future<void> _awaitSimulatorBoot(String udid, Duration timeout) async {
    final sw = Stopwatch()..start();
    while (sw.elapsed < timeout) {
      final device = await getDeviceInfo(udid);
      if (device?.status == DeviceStatus.connected) {
        logger.info('Simulator booted', {'udid': udid, 'elapsed': sw.elapsed});
        return;
      }
      await Future.delayed(const Duration(milliseconds: 500));
    }
    throw TimeoutException('Simulator failed to boot within ${timeout.inSeconds}s');
  }

  Future<Device?> _getPhysicalDeviceInfo(String udid) async {
    try {
      final result = await Process.run('ideviceinfo', ['-u', udid]);
      if (result.exitCode != 0) return null;
      
      final info = <String, String>{};
      for (final line in (result.stdout as String).split('\n')) {
        final parts = line.split(':');
        if (parts.length >= 2) {
          info[parts[0].trim()] = parts.sublist(1).join(':').trim();
        }
      }
      
      return Device(
        id: udid,
        name: info['DeviceName'] ?? 'iOS Device',
        type: DeviceType.ios,
        status: DeviceStatus.connected,
        osVersion: info['ProductVersion'] != null 
            ? 'iOS ${info['ProductVersion']}' 
            : null,
        capabilities: DeviceCapabilities.ios(),
        lastSeen: DateTime.now(),
        metadata: info,
      );
    } catch (e) {
      return null;
    }
  }

  Future<String?> _getSimulatorDataPath(String deviceId) async {
    final result = await Process.run(
      _xcrun,
      ['simctl', 'get_app_container', deviceId, 'data'],
    );
    if (result.exitCode == 0) {
      return (result.stdout as String).trim();
    }
    return null;
  }
}
```

#### 2.2 Xcode Tools Integration

- Use `xcrun simctl` for all simulator operations
- Parse JSON output from `simctl list --json`
- Use `idevice_id` and `ideviceinfo` for physical devices (libimobiledevice)
- Graceful fallback when tools not available

#### 2.3 iOS Requirements

- Requires Xcode installation for simulators
- Optional: libimobiledevice for physical device support
- Automatic detection of available tools
- Status reporting for missing dependencies

### 3. Web Browser Integration

#### 3.1 Browser Detection

- Detect installed browsers on the system
- Check browser versions for compatibility
- Support Chrome DevTools Protocol (CDP)
- Support WebDriver protocol for cross-browser automation

#### 3.2 Browser Service

**File: `lib/core/services/web_browser_service.dart`**

```dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../logging/logging.dart';
import '../../domain/entities/device.dart';
import '../../domain/entities/device_type.dart';
import '../../domain/entities/device_status.dart';
import '../../domain/entities/device_capabilities.dart';

/// Service for web browser operations
class WebBrowserService with LoggerMixin {
  final Map<String, Process> _runningBrowsers = {};

  /// Get all available browsers
  Future<List<Device>> getAvailableBrowsers() async {
    final browsers = <Device>[];
    
    // Chrome
    if (await _isBrowserInstalled(_chromePaths)) {
      browsers.add(const Device(
        id: 'chrome',
        name: 'Chrome',
        type: DeviceType.webChrome,
        status: DeviceStatus.connected,
        capabilities: DeviceCapabilities(
          supportsScreenshot: true,
          supportsLogs: true,
        ),
      ));
    }
    
    // Edge
    if (await _isBrowserInstalled(_edgePaths)) {
      browsers.add(const Device(
        id: 'edge',
        name: 'Microsoft Edge',
        type: DeviceType.webEdge,
        status: DeviceStatus.connected,
        capabilities: DeviceCapabilities(
          supportsScreenshot: true,
          supportsLogs: true,
        ),
      ));
    }
    
    // Firefox
    if (await _isBrowserInstalled(_firefoxPaths)) {
      browsers.add(const Device(
        id: 'firefox',
        name: 'Firefox',
        type: DeviceType.webFirefox,
        status: DeviceStatus.connected,
        capabilities: DeviceCapabilities(
          supportsScreenshot: true,
          supportsLogs: true,
        ),
      ));
    }
    
    // Safari (macOS only)
    if (Platform.isMacOS) {
      browsers.add(const Device(
        id: 'safari',
        name: 'Safari',
        type: DeviceType.webSafari,
        status: DeviceStatus.connected,
        capabilities: DeviceCapabilities(
          supportsScreenshot: true,
          supportsLogs: true,
        ),
      ));
    }
    
    return browsers;
  }

  /// Launch browser with URL
  Future<void> launchBrowser(
    String browserId,
    String url, {
    bool headless = false,
    int? debugPort,
  }) async {
    final executable = await _getBrowserExecutable(browserId);
    if (executable == null) {
      throw Exception('Browser $browserId not found');
    }
    
    final args = <String>[url];
    
    // Chrome/Edge specific flags
    if (browserId == 'chrome' || browserId == 'edge') {
      if (headless) args.add('--headless');
      if (debugPort != null) {
        args.add('--remote-debugging-port=$debugPort');
      }
    }
    
    final process = await Process.start(executable, args);
    _runningBrowsers[browserId] = process;
    
    logger.info('Launched browser', {'browser': browserId, 'url': url});
  }

  /// Close browser
  Future<void> closeBrowser(String browserId) async {
    final process = _runningBrowsers.remove(browserId);
    process?.kill();
  }

  // Browser executable paths
  static const _chromePaths = [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  ];

  static const _edgePaths = [
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    '/usr/bin/microsoft-edge',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  ];

  static const _firefoxPaths = [
    '/Applications/Firefox.app/Contents/MacOS/firefox',
    '/usr/bin/firefox',
    'C:\\Program Files\\Mozilla Firefox\\firefox.exe',
  ];

  Future<bool> _isBrowserInstalled(List<String> paths) async {
    for (final path in paths) {
      if (await File(path).exists()) return true;
    }
    return false;
  }

  Future<String?> _getBrowserExecutable(String browserId) async {
    final paths = switch (browserId) {
      'chrome' => _chromePaths,
      'edge' => _edgePaths,
      'firefox' => _firefoxPaths,
      'safari' => ['/Applications/Safari.app/Contents/MacOS/Safari'],
      _ => <String>[],
    };
    
    for (final path in paths) {
      if (await File(path).exists()) return path;
    }
    return null;
  }
}
```

---

## 6. Repository Layer Implementation

### 6.1 Device Repository Interface

**File: `lib/domain/repositories/device_repository.dart`**

```dart
import 'dart:typed_data';
import '../entities/device.dart';

/// Repository interface for device operations
abstract class DeviceRepository {
  /// Get all discovered devices
  Future<List<Device>> getDevices();
  
  /// Get device by ID
  Future<Device?> getDeviceById(String deviceId);
  
  /// Refresh device list
  Future<List<Device>> refreshDevices();
  
  /// Get device stream for real-time updates
  Stream<List<Device>> watchDevices();
  
  /// Install app on device
  Future<void> installApp(String deviceId, String appPath);
  
  /// Uninstall app from device
  Future<void> uninstallApp(String deviceId, String packageId);
  
  /// Launch app on device
  Future<void> launchApp(String deviceId, String packageId);
  
  /// Stop app on device
  Future<void> stopApp(String deviceId, String packageId);
  
  /// Take screenshot
  Future<Uint8List> takeScreenshot(String deviceId);
  
  /// Start screen recording
  Future<void> startScreenRecording(String deviceId, String outputPath);
  
  /// Stop screen recording
  Future<void> stopScreenRecording(String deviceId);
  
  /// Get device logs stream
  Stream<String> getLogs(String deviceId, {String? filter});
  
  /// Clear device logs
  Future<void> clearLogs(String deviceId);
  
  /// Execute shell command
  Future<String> executeCommand(String deviceId, String command);
  
  /// Push file to device
  Future<void> pushFile(String deviceId, String localPath, String remotePath);
  
  /// Pull file from device
  Future<void> pullFile(String deviceId, String remotePath, String localPath);
  
  /// Toggle device favorite status
  Future<void> toggleFavorite(String deviceId);
  
  /// Add tag to device
  Future<void> addTag(String deviceId, String tag);
  
  /// Remove tag from device
  Future<void> removeTag(String deviceId, String tag);
  
  /// Boot simulator/emulator
  Future<void> bootDevice(String deviceId);
  
  /// Shutdown simulator/emulator
  Future<void> shutdownDevice(String deviceId);
}
```

### 6.2 Device Repository Implementation

**File: `lib/data/repositories/device_repository_impl.dart`**

```dart
import 'dart:async';
import 'dart:typed_data';

import '../../core/logging/logging.dart';
import '../../core/services/adb_service.dart';
import '../../core/services/ios_device_service.dart';
import '../../core/services/device_discovery_service.dart';
import '../../domain/entities/device.dart';
import '../../domain/entities/device_type.dart';
import '../../domain/repositories/device_repository.dart';
import '../datasources/local/device_local_datasource.dart';

/// Implementation of DeviceRepository
class DeviceRepositoryImpl with LoggerMixin implements DeviceRepository {
  final DeviceDiscoveryService _discoveryService;
  final AdbService _adbService;
  final IosDeviceService _iosDeviceService;
  final DeviceLocalDatasource _localDatasource;

  DeviceRepositoryImpl({
    required DeviceDiscoveryService discoveryService,
    required AdbService adbService,
    required IosDeviceService iosDeviceService,
    required DeviceLocalDatasource localDatasource,
  })  : _discoveryService = discoveryService,
        _adbService = adbService,
        _iosDeviceService = iosDeviceService,
        _localDatasource = localDatasource;

  @override
  Future<List<Device>> getDevices() async {
    return _discoveryService.cachedDevices;
  }

  @override
  Future<Device?> getDeviceById(String deviceId) async {
    return _discoveryService.cachedDevices
        .where((d) => d.id == deviceId)
        .firstOrNull;
  }

  @override
  Future<List<Device>> refreshDevices() async {
    return await _discoveryService.scanDevices();
  }

  @override
  Stream<List<Device>> watchDevices() => _discoveryService.devices;

  @override
  Future<void> installApp(String deviceId, String appPath) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.installApp(deviceId, appPath);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.installApp(deviceId, appPath);
    } else {
      throw UnsupportedOperationException('installApp', device.type);
    }
  }

  @override
  Future<void> uninstallApp(String deviceId, String packageId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.uninstallApp(deviceId, packageId);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.uninstallApp(deviceId, packageId);
    }
  }

  @override
  Future<void> launchApp(String deviceId, String packageId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.launchApp(deviceId, packageId);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.launchApp(deviceId, packageId);
    }
  }

  @override
  Future<void> stopApp(String deviceId, String packageId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.stopApp(deviceId, packageId);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.stopApp(deviceId, packageId);
    }
  }

  @override
  Future<Uint8List> takeScreenshot(String deviceId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      return await _adbService.takeScreenshot(deviceId);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      return await _iosDeviceService.takeScreenshot(deviceId);
    }
    
    throw UnsupportedOperationException('takeScreenshot', device.type);
  }

  @override
  Future<void> startScreenRecording(String deviceId, String outputPath) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.startScreenRecording(deviceId, outputPath);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.startScreenRecording(deviceId, outputPath);
    }
  }

  @override
  Future<void> stopScreenRecording(String deviceId) async {
    // Implementation depends on tracking recording process
    logger.warn('stopScreenRecording not fully implemented');
  }

  @override
  Stream<String> getLogs(String deviceId, {String? filter}) async* {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      yield* _adbService.getLogs(deviceId, filter: filter);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      yield* _iosDeviceService.getLogs(deviceId, bundleId: filter);
    }
  }

  @override
  Future<void> clearLogs(String deviceId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.clearLogs(deviceId);
    }
  }

  @override
  Future<String> executeCommand(String deviceId, String command) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      return await _adbService.executeShellCommand(deviceId, command);
    }
    
    throw UnsupportedOperationException('executeCommand', device.type);
  }

  @override
  Future<void> pushFile(String deviceId, String localPath, String remotePath) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.pushFile(deviceId, localPath, remotePath);
    } else if (device.type == DeviceType.ios || 
               device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.pushFile(deviceId, localPath, remotePath);
    }
  }

  @override
  Future<void> pullFile(String deviceId, String remotePath, String localPath) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.android || 
        device.type == DeviceType.androidEmulator) {
      await _adbService.pullFile(deviceId, remotePath, localPath);
    }
  }

  @override
  Future<void> toggleFavorite(String deviceId) async {
    await _localDatasource.toggleFavorite(deviceId);
  }

  @override
  Future<void> addTag(String deviceId, String tag) async {
    await _localDatasource.addTag(deviceId, tag);
  }

  @override
  Future<void> removeTag(String deviceId, String tag) async {
    await _localDatasource.removeTag(deviceId, tag);
  }

  @override
  Future<void> bootDevice(String deviceId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.bootSimulator(deviceId);
    }
    // Android emulator boot would require AVD manager integration
  }

  @override
  Future<void> shutdownDevice(String deviceId) async {
    final device = await getDeviceById(deviceId);
    if (device == null) throw DeviceNotFoundException(deviceId);

    if (device.type == DeviceType.iosSimulator) {
      await _iosDeviceService.shutdownSimulator(deviceId);
    }
  }
}

/// Exception thrown when device is not found
class DeviceNotFoundException implements Exception {
  final String deviceId;
  DeviceNotFoundException(this.deviceId);
  
  @override
  String toString() => 'Device not found: $deviceId';
}

/// Exception thrown when operation is not supported for device type
class UnsupportedOperationException implements Exception {
  final String operation;
  final DeviceType deviceType;
  UnsupportedOperationException(this.operation, this.deviceType);
  
  @override
  String toString() => '$operation is not supported for ${deviceType.name}';
}
```

### 4. Device Discovery & Monitoring

#### 4.1 Discovery Strategy

- **Initial Scan**: Scan all platforms on app start
- **Periodic Scan**: Scan every 5-10 seconds (configurable)
- **Event-based**: React to device connection/disconnection events
- **Manual Refresh**: User-triggered refresh

#### 4.2 Caching Strategy

- Cache device information locally
- Update cache on discovery
- Invalidate cache on device disconnect
- Persist favorite devices and groups

#### 4.3 Monitoring Service

See **Section 1.2 Device Discovery Service** for full implementation.

---

## 7. Use Cases Implementation

### 7.1 Discover Devices Use Case

**File: `lib/domain/usecases/device/discover_devices_usecase.dart`**

```dart
import '../../entities/device.dart';
import '../../repositories/device_repository.dart';
import '../../../core/logging/logging.dart';

/// Use case for discovering available devices
class DiscoverDevicesUseCase with LoggerMixin {
  final DeviceRepository _repository;

  DiscoverDevicesUseCase(this._repository);

  /// Execute device discovery
  Future<List<Device>> execute({bool forceRefresh = false}) async {
    return await logAsyncOperation(
      'discoverDevices',
      () async {
        if (forceRefresh) {
          return await _repository.refreshDevices();
        }
        return await _repository.getDevices();
      },
      context: {'forceRefresh': forceRefresh},
    );
  }

  /// Watch for device changes
  Stream<List<Device>> watch() => _repository.watchDevices();
}
```

### 7.2 Install App Use Case

**File: `lib/domain/usecases/device/install_app_usecase.dart`**

```dart
import 'dart:io';
import '../../entities/device.dart';
import '../../repositories/device_repository.dart';
import '../../../core/logging/logging.dart';

/// Result of app installation
sealed class InstallAppResult {
  const InstallAppResult();
}

class InstallAppSuccess extends InstallAppResult {
  final Device device;
  final String appPath;
  final Duration duration;
  
  const InstallAppSuccess({
    required this.device,
    required this.appPath,
    required this.duration,
  });
}

class InstallAppFailure extends InstallAppResult {
  final String error;
  final Device? device;
  
  const InstallAppFailure(this.error, {this.device});
}

/// Use case for installing apps on devices
class InstallAppUseCase with LoggerMixin {
  final DeviceRepository _repository;

  InstallAppUseCase(this._repository);

  /// Install app on a single device
  Future<InstallAppResult> execute({
    required String deviceId,
    required String appPath,
  }) async {
    final stopwatch = Stopwatch()..start();
    
    try {
      // Validate file exists
      if (!await File(appPath).exists()) {
        return InstallAppFailure('App file not found: $appPath');
      }
      
      final device = await _repository.getDeviceById(deviceId);
      if (device == null) {
        return InstallAppFailure('Device not found: $deviceId');
      }
      
      if (!device.capabilities.supportsAppInstall) {
        return InstallAppFailure(
          'Device does not support app installation',
          device: device,
        );
      }
      
      await _repository.installApp(deviceId, appPath);
      stopwatch.stop();
      
      logger.info('App installed successfully', {
        'deviceId': deviceId,
        'appPath': appPath,
        'duration': stopwatch.elapsed.inMilliseconds,
      });
      
      return InstallAppSuccess(
        device: device,
        appPath: appPath,
        duration: stopwatch.elapsed,
      );
    } catch (e) {
      logger.error('App installation failed', e, null, {
        'deviceId': deviceId,
        'appPath': appPath,
      });
      return InstallAppFailure(e.toString());
    }
  }

  /// Install app on multiple devices
  Future<Map<String, InstallAppResult>> executeOnMultiple({
    required List<String> deviceIds,
    required String appPath,
  }) async {
    final results = <String, InstallAppResult>{};
    
    // Run installations in parallel
    await Future.wait(
      deviceIds.map((deviceId) async {
        results[deviceId] = await execute(
          deviceId: deviceId,
          appPath: appPath,
        );
      }),
    );
    
    return results;
  }
}
```

### 7.3 Take Screenshot Use Case

**File: `lib/domain/usecases/device/take_screenshot_usecase.dart`**

```dart
import 'dart:io';
import 'dart:typed_data';
import 'package:path/path.dart' as path;
import '../../entities/device.dart';
import '../../repositories/device_repository.dart';
import '../../../core/logging/logging.dart';

/// Result of screenshot operation
class ScreenshotResult {
  final Device device;
  final Uint8List bytes;
  final String? savedPath;
  final DateTime timestamp;

  ScreenshotResult({
    required this.device,
    required this.bytes,
    this.savedPath,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  int get sizeInBytes => bytes.length;
  String get sizeFormatted => _formatBytes(sizeInBytes);

  static String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

/// Use case for taking device screenshots
class TakeScreenshotUseCase with LoggerMixin {
  final DeviceRepository _repository;

  TakeScreenshotUseCase(this._repository);

  /// Take screenshot and optionally save to file
  Future<ScreenshotResult> execute({
    required String deviceId,
    String? savePath,
    bool autoGenerateName = true,
  }) async {
    final device = await _repository.getDeviceById(deviceId);
    if (device == null) {
      throw Exception('Device not found: $deviceId');
    }
    
    if (!device.capabilities.supportsScreenshot) {
      throw Exception('Device does not support screenshots');
    }
    
    logger.info('Taking screenshot', {'deviceId': deviceId});
    final bytes = await _repository.takeScreenshot(deviceId);
    
    String? finalPath;
    if (savePath != null || autoGenerateName) {
      finalPath = savePath ?? _generateScreenshotPath(device);
      await _saveScreenshot(bytes, finalPath);
      logger.info('Screenshot saved', {'path': finalPath});
    }
    
    return ScreenshotResult(
      device: device,
      bytes: bytes,
      savedPath: finalPath,
    );
  }

  /// Take screenshots from multiple devices
  Future<List<ScreenshotResult>> executeOnMultiple({
    required List<String> deviceIds,
    String? saveDirectory,
  }) async {
    final results = <ScreenshotResult>[];
    
    await Future.wait(
      deviceIds.map((deviceId) async {
        try {
          final result = await execute(
            deviceId: deviceId,
            savePath: saveDirectory != null
                ? path.join(saveDirectory, '$deviceId.png')
                : null,
          );
          results.add(result);
        } catch (e) {
          logger.error('Screenshot failed for device', e, null, {
            'deviceId': deviceId,
          });
        }
      }),
    );
    
    return results;
  }

  String _generateScreenshotPath(Device device) {
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-');
    final sanitizedName = device.name.replaceAll(RegExp(r'[^\w\s-]'), '');
    return 'screenshots/${sanitizedName}_$timestamp.png';
  }

  Future<void> _saveScreenshot(Uint8List bytes, String filePath) async {
    final file = File(filePath);
    await file.parent.create(recursive: true);
    await file.writeAsBytes(bytes);
  }
}
```

### 7.4 Launch App Use Case

**File: `lib/domain/usecases/device/launch_app_usecase.dart`**

```dart
import '../../entities/device.dart';
import '../../repositories/device_repository.dart';
import '../../../core/logging/logging.dart';

/// Use case for launching apps on devices
class LaunchAppUseCase with LoggerMixin {
  final DeviceRepository _repository;

  LaunchAppUseCase(this._repository);

  /// Launch app on device
  Future<void> execute({
    required String deviceId,
    required String packageId,
  }) async {
    return await logAsyncOperation(
      'launchApp',
      () async {
        final device = await _repository.getDeviceById(deviceId);
        if (device == null) {
          throw Exception('Device not found: $deviceId');
        }
        
        await _repository.launchApp(deviceId, packageId);
      },
      context: {'deviceId': deviceId, 'packageId': packageId},
    );
  }

  /// Stop app on device
  Future<void> stop({
    required String deviceId,
    required String packageId,
  }) async {
    await _repository.stopApp(deviceId, packageId);
    logger.info('App stopped', {'deviceId': deviceId, 'packageId': packageId});
  }

  /// Restart app (stop and launch)
  Future<void> restart({
    required String deviceId,
    required String packageId,
  }) async {
    await stop(deviceId: deviceId, packageId: packageId);
    await Future.delayed(const Duration(milliseconds: 500));
    await execute(deviceId: deviceId, packageId: packageId);
    logger.info('App restarted', {'deviceId': deviceId, 'packageId': packageId});
  }
}
```

### 7.5 Get Device Logs Use Case

**File: `lib/domain/usecases/device/get_device_logs_usecase.dart`**

```dart
import 'dart:async';
import 'dart:io';
import '../../entities/device.dart';
import '../../repositories/device_repository.dart';
import '../../../core/logging/logging.dart';

/// Log entry from device
class DeviceLogEntry {
  final DateTime timestamp;
  final String level;
  final String tag;
  final String message;
  final String raw;

  DeviceLogEntry({
    required this.timestamp,
    required this.level,
    required this.tag,
    required this.message,
    required this.raw,
  });

  /// Parse Android logcat format
  factory DeviceLogEntry.fromLogcat(String line) {
    // Format: MM-DD HH:MM:SS.mmm PID TID LEVEL TAG: MESSAGE
    final match = RegExp(
      r'^(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})\s+\d+\s+\d+\s+([VDIWEF])\s+(\S+)\s*:\s*(.*)$'
    ).firstMatch(line);
    
    if (match != null) {
      return DeviceLogEntry(
        timestamp: _parseLogcatTimestamp(match.group(1)!),
        level: match.group(2)!,
        tag: match.group(3)!,
        message: match.group(4)!,
        raw: line,
      );
    }
    
    return DeviceLogEntry(
      timestamp: DateTime.now(),
      level: 'I',
      tag: '',
      message: line,
      raw: line,
    );
  }

  static DateTime _parseLogcatTimestamp(String ts) {
    try {
      final now = DateTime.now();
      final parts = ts.split(RegExp(r'[\s.:-]'));
      return DateTime(
        now.year,
        int.parse(parts[0]),
        int.parse(parts[1]),
        int.parse(parts[2]),
        int.parse(parts[3]),
        int.parse(parts[4]),
        int.parse(parts[5]),
      );
    } catch (_) {
      return DateTime.now();
    }
  }

  bool matchesFilter(String? levelFilter, String? tagFilter, String? textFilter) {
    if (levelFilter != null && !_matchesLevel(levelFilter)) return false;
    if (tagFilter != null && !tag.toLowerCase().contains(tagFilter.toLowerCase())) {
      return false;
    }
    if (textFilter != null && !message.toLowerCase().contains(textFilter.toLowerCase())) {
      return false;
    }
    return true;
  }

  bool _matchesLevel(String minLevel) {
    const levels = ['V', 'D', 'I', 'W', 'E', 'F'];
    final minIndex = levels.indexOf(minLevel);
    final currentIndex = levels.indexOf(level);
    return currentIndex >= minIndex;
  }
}

/// Use case for streaming and managing device logs
class GetDeviceLogsUseCase with LoggerMixin {
  final DeviceRepository _repository;

  GetDeviceLogsUseCase(this._repository);

  /// Stream logs from device
  Stream<DeviceLogEntry> execute({
    required String deviceId,
    String? filter,
    String? minLevel,
    String? tagFilter,
  }) async* {
    final device = await _repository.getDeviceById(deviceId);
    if (device == null) {
      throw Exception('Device not found: $deviceId');
    }
    
    if (!device.capabilities.supportsLogs) {
      throw Exception('Device does not support logs');
    }
    
    logger.info('Starting log stream', {'deviceId': deviceId});
    
    await for (final chunk in _repository.getLogs(deviceId, filter: filter)) {
      for (final line in chunk.split('\n')) {
        if (line.trim().isEmpty) continue;
        
        final entry = DeviceLogEntry.fromLogcat(line);
        if (entry.matchesFilter(minLevel, tagFilter, null)) {
          yield entry;
        }
      }
    }
  }

  /// Clear device logs
  Future<void> clearLogs(String deviceId) async {
    await _repository.clearLogs(deviceId);
    logger.info('Logs cleared', {'deviceId': deviceId});
  }

  /// Export logs to file
  Future<void> exportLogs({
    required String deviceId,
    required String outputPath,
    Duration? duration,
  }) async {
    final file = File(outputPath);
    final sink = file.openWrite();
    
    final subscription = execute(deviceId: deviceId).listen(
      (entry) => sink.writeln(entry.raw),
    );
    
    if (duration != null) {
      await Future.delayed(duration);
      await subscription.cancel();
    }
    
    await sink.close();
    logger.info('Logs exported', {'outputPath': outputPath});
  }
}
```

### 7.6 Execute Shell Command Use Case

**File: `lib/domain/usecases/device/execute_shell_command_usecase.dart`**

```dart
import '../../entities/device.dart';
import '../../repositories/device_repository.dart';
import '../../../core/logging/logging.dart';

/// Result of shell command execution
class ShellCommandResult {
  final String command;
  final String output;
  final Duration executionTime;
  final Device device;

  ShellCommandResult({
    required this.command,
    required this.output,
    required this.executionTime,
    required this.device,
  });
}

/// Use case for executing shell commands on devices
class ExecuteShellCommandUseCase with LoggerMixin {
  final DeviceRepository _repository;
  
  // Commands that are not allowed for security reasons
  static const _blockedCommands = [
    'rm -rf /',
    'mkfs',
    'dd if=/dev/',
  ];

  ExecuteShellCommandUseCase(this._repository);

  /// Execute shell command on device
  Future<ShellCommandResult> execute({
    required String deviceId,
    required String command,
  }) async {
    // Security validation
    _validateCommand(command);
    
    final stopwatch = Stopwatch()..start();
    
    final device = await _repository.getDeviceById(deviceId);
    if (device == null) {
      throw Exception('Device not found: $deviceId');
    }
    
    if (!device.capabilities.supportsShellAccess) {
      throw Exception('Device does not support shell access');
    }
    
    logger.info('Executing shell command', {
      'deviceId': deviceId,
      'command': command,
    });
    
    final output = await _repository.executeCommand(deviceId, command);
    stopwatch.stop();
    
    logger.debug('Command output', {
      'output': output.length > 200 ? '${output.substring(0, 200)}...' : output,
      'executionTime': stopwatch.elapsedMilliseconds,
    });
    
    return ShellCommandResult(
      command: command,
      output: output,
      executionTime: stopwatch.elapsed,
      device: device,
    );
  }

  void _validateCommand(String command) {
    final lowerCommand = command.toLowerCase();
    for (final blocked in _blockedCommands) {
      if (lowerCommand.contains(blocked)) {
        throw SecurityException('Command not allowed: $blocked');
      }
    }
  }
}

class SecurityException implements Exception {
  final String message;
  SecurityException(this.message);
  
  @override
  String toString() => 'SecurityException: $message';
}
```

### 5. Error Handling

#### 5.1 Common Errors

- **Device Not Found**: Device disconnected or not available
- **Unauthorized**: Device requires authorization
- **Permission Denied**: Insufficient permissions
- **Command Failed**: ADB/xcrun command failed
- **Timeout**: Operation timed out
- **Platform Not Supported**: Feature not available on platform

#### 5.2 Error Recovery

- Retry logic for transient errors
- Clear error messages for users
- Log errors for debugging
- Graceful degradation when features unavailable

---

## 8. Presentation Layer Implementation

### 8.1 Device Provider (State Management)

**File: `lib/presentation/providers/device/device_provider.dart`**

```dart
import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '../../../domain/entities/device.dart';
import '../../../domain/entities/device_status.dart';
import '../../../domain/usecases/device/discover_devices_usecase.dart';
import '../../../domain/usecases/device/install_app_usecase.dart';
import '../../../domain/usecases/device/take_screenshot_usecase.dart';
import '../../../domain/usecases/device/launch_app_usecase.dart';
import '../../../core/logging/logging.dart';

/// State for device management
enum DeviceProviderState { initial, loading, loaded, error }

/// Provider for device management operations
class DeviceProvider extends ChangeNotifier with LoggerMixin {
  final DiscoverDevicesUseCase _discoverDevicesUseCase;
  final InstallAppUseCase _installAppUseCase;
  final TakeScreenshotUseCase _takeScreenshotUseCase;
  final LaunchAppUseCase _launchAppUseCase;

  DeviceProviderState _state = DeviceProviderState.initial;
  List<Device> _devices = [];
  Device? _selectedDevice;
  String? _error;
  StreamSubscription? _deviceSubscription;

  // Filters
  String? _searchQuery;
  Set<DeviceStatus> _statusFilter = {};
  bool _showOnlyFavorites = false;

  DeviceProvider({
    required DiscoverDevicesUseCase discoverDevicesUseCase,
    required InstallAppUseCase installAppUseCase,
    required TakeScreenshotUseCase takeScreenshotUseCase,
    required LaunchAppUseCase launchAppUseCase,
  })  : _discoverDevicesUseCase = discoverDevicesUseCase,
        _installAppUseCase = installAppUseCase,
        _takeScreenshotUseCase = takeScreenshotUseCase,
        _launchAppUseCase = launchAppUseCase {
    _startWatching();
  }

  // Getters
  DeviceProviderState get state => _state;
  List<Device> get devices => _devices;
  Device? get selectedDevice => _selectedDevice;
  String? get error => _error;
  bool get isLoading => _state == DeviceProviderState.loading;

  /// Filtered and sorted device list
  List<Device> get filteredDevices {
    var result = _devices.toList();

    // Apply search filter
    if (_searchQuery != null && _searchQuery!.isNotEmpty) {
      final query = _searchQuery!.toLowerCase();
      result = result.where((d) =>
          d.name.toLowerCase().contains(query) ||
          d.id.toLowerCase().contains(query) ||
          d.type.displayName.toLowerCase().contains(query)).toList();
    }

    // Apply status filter
    if (_statusFilter.isNotEmpty) {
      result = result.where((d) => _statusFilter.contains(d.status)).toList();
    }

    // Apply favorites filter
    if (_showOnlyFavorites) {
      result = result.where((d) => d.isFavorite).toList();
    }

    // Sort: favorites first, then connected, then by name
    result.sort((a, b) {
      if (a.isFavorite != b.isFavorite) {
        return a.isFavorite ? -1 : 1;
      }
      if (a.status != b.status) {
        if (a.status == DeviceStatus.connected) return -1;
        if (b.status == DeviceStatus.connected) return 1;
      }
      return a.name.compareTo(b.name);
    });

    return result;
  }

  /// Grouped devices by type category
  Map<String, List<Device>> get devicesByCategory {
    final grouped = <String, List<Device>>{};
    for (final device in filteredDevices) {
      final category = device.type.category;
      grouped.putIfAbsent(category, () => []).add(device);
    }
    return grouped;
  }

  /// Start watching for device changes
  void _startWatching() {
    _deviceSubscription = _discoverDevicesUseCase.watch().listen(
      (devices) {
        _devices = devices;
        _state = DeviceProviderState.loaded;
        
        // Update selected device if still available
        if (_selectedDevice != null) {
          _selectedDevice = devices
              .where((d) => d.id == _selectedDevice!.id)
              .firstOrNull;
        }
        
        notifyListeners();
      },
      onError: (e) {
        logger.error('Device watch error', e);
        _error = e.toString();
        _state = DeviceProviderState.error;
        notifyListeners();
      },
    );
  }

  /// Refresh device list
  Future<void> refreshDevices() async {
    _state = DeviceProviderState.loading;
    _error = null;
    notifyListeners();

    try {
      _devices = await _discoverDevicesUseCase.execute(forceRefresh: true);
      _state = DeviceProviderState.loaded;
    } catch (e) {
      logger.error('Failed to refresh devices', e);
      _error = e.toString();
      _state = DeviceProviderState.error;
    }
    notifyListeners();
  }

  /// Select a device
  void selectDevice(Device? device) {
    _selectedDevice = device;
    notifyListeners();
  }

  /// Set search query
  void setSearchQuery(String? query) {
    _searchQuery = query;
    notifyListeners();
  }

  /// Set status filter
  void setStatusFilter(Set<DeviceStatus> statuses) {
    _statusFilter = statuses;
    notifyListeners();
  }

  /// Toggle favorites only filter
  void toggleFavoritesFilter() {
    _showOnlyFavorites = !_showOnlyFavorites;
    notifyListeners();
  }

  /// Install app on selected device
  Future<InstallAppResult> installApp(String appPath) async {
    if (_selectedDevice == null) {
      return const InstallAppFailure('No device selected');
    }
    
    return await _installAppUseCase.execute(
      deviceId: _selectedDevice!.id,
      appPath: appPath,
    );
  }

  /// Take screenshot of selected device
  Future<ScreenshotResult?> takeScreenshot({String? savePath}) async {
    if (_selectedDevice == null) return null;
    
    return await _takeScreenshotUseCase.execute(
      deviceId: _selectedDevice!.id,
      savePath: savePath,
    );
  }

  /// Launch app on selected device
  Future<void> launchApp(String packageId) async {
    if (_selectedDevice == null) return;
    
    await _launchAppUseCase.execute(
      deviceId: _selectedDevice!.id,
      packageId: packageId,
    );
  }

  /// Stop app on selected device
  Future<void> stopApp(String packageId) async {
    if (_selectedDevice == null) return;
    
    await _launchAppUseCase.stop(
      deviceId: _selectedDevice!.id,
      packageId: packageId,
    );
  }

  @override
  void dispose() {
    _deviceSubscription?.cancel();
    super.dispose();
  }
}
```

### 8.2 Device List Widget

**File: `lib/presentation/widgets/device/device_list_widget.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../domain/entities/device.dart';
import '../../../domain/entities/device_status.dart';
import '../../providers/device/device_provider.dart';
import 'device_card.dart';

/// Widget displaying list of devices
class DeviceListWidget extends StatelessWidget {
  final void Function(Device)? onDeviceSelected;
  final bool showSearch;
  final bool showFilters;
  final bool groupByCategory;

  const DeviceListWidget({
    super.key,
    this.onDeviceSelected,
    this.showSearch = true,
    this.showFilters = true,
    this.groupByCategory = true,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<DeviceProvider>(
      builder: (context, provider, _) {
        return Column(
          children: [
            if (showSearch) _buildSearchBar(context, provider),
            if (showFilters) _buildFilterChips(context, provider),
            Expanded(
              child: _buildDeviceList(context, provider),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSearchBar(BuildContext context, DeviceProvider provider) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: CupertinoSearchTextField(
        placeholder: 'Search devices...',
        onChanged: provider.setSearchQuery,
      ),
    );
  }

  Widget _buildFilterChips(BuildContext context, DeviceProvider provider) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          FilterChip(
            label: const Text('Favorites'),
            selected: provider._showOnlyFavorites,
            onSelected: (_) => provider.toggleFavoritesFilter(),
          ),
          const SizedBox(width: 8),
          FilterChip(
            label: const Text('Connected'),
            selected: provider._statusFilter.contains(DeviceStatus.connected),
            onSelected: (selected) {
              final filter = Set<DeviceStatus>.from(provider._statusFilter);
              if (selected) {
                filter.add(DeviceStatus.connected);
              } else {
                filter.remove(DeviceStatus.connected);
              }
              provider.setStatusFilter(filter);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceList(BuildContext context, DeviceProvider provider) {
    if (provider.isLoading) {
      return const Center(child: CupertinoActivityIndicator());
    }

    if (provider.error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(CupertinoIcons.exclamationmark_triangle, size: 48),
            const SizedBox(height: 16),
            Text(provider.error!),
            const SizedBox(height: 16),
            CupertinoButton(
              onPressed: provider.refreshDevices,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    final devices = provider.filteredDevices;
    if (devices.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              CupertinoIcons.device_phone_portrait,
              size: 64,
              color: CupertinoColors.systemGrey,
            ),
            const SizedBox(height: 16),
            Text(
              'No devices found',
              style: TextStyle(
                fontSize: 18,
                color: CupertinoColors.systemGrey,
              ),
            ),
            const SizedBox(height: 8),
            CupertinoButton(
              onPressed: provider.refreshDevices,
              child: const Text('Refresh'),
            ),
          ],
        ),
      );
    }

    if (groupByCategory) {
      return _buildGroupedList(context, provider);
    }

    return RefreshIndicator(
      onRefresh: provider.refreshDevices,
      child: ListView.builder(
        itemCount: devices.length,
        itemBuilder: (context, index) {
          final device = devices[index];
          return DeviceCard(
            device: device,
            isSelected: device.id == provider.selectedDevice?.id,
            onTap: () {
              provider.selectDevice(device);
              onDeviceSelected?.call(device);
            },
          );
        },
      ),
    );
  }

  Widget _buildGroupedList(BuildContext context, DeviceProvider provider) {
    final grouped = provider.devicesByCategory;
    final categories = grouped.keys.toList();

    return RefreshIndicator(
      onRefresh: provider.refreshDevices,
      child: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          final categoryDevices = grouped[category]!;

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(
                  category,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: CupertinoColors.systemGrey,
                  ),
                ),
              ),
              ...categoryDevices.map((device) => DeviceCard(
                    device: device,
                    isSelected: device.id == provider.selectedDevice?.id,
                    onTap: () {
                      provider.selectDevice(device);
                      onDeviceSelected?.call(device);
                    },
                  )),
            ],
          );
        },
      ),
    );
  }
}
```

### 8.3 Device Card Widget

**File: `lib/presentation/widgets/device/device_card.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../domain/entities/device.dart';
import '../../../domain/entities/device_status.dart';
import 'device_status_indicator.dart';

/// Card widget displaying device information
class DeviceCard extends StatelessWidget {
  final Device device;
  final bool isSelected;
  final VoidCallback? onTap;
  final VoidCallback? onFavoriteToggle;
  final List<Widget>? actions;

  const DeviceCard({
    super.key,
    required this.device,
    this.isSelected = false,
    this.onTap,
    this.onFavoriteToggle,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? CupertinoColors.activeBlue.withOpacity(0.1)
              : CupertinoColors.systemBackground,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? CupertinoColors.activeBlue
                : CupertinoColors.separator,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            _buildDeviceIcon(),
            const SizedBox(width: 12),
            Expanded(child: _buildDeviceInfo()),
            if (device.isFavorite)
              const Icon(
                CupertinoIcons.star_fill,
                color: CupertinoColors.systemYellow,
                size: 16,
              ),
            const SizedBox(width: 8),
            DeviceStatusIndicator(status: device.status),
            if (actions != null) ...actions!,
          ],
        ),
      ),
    );
  }

  Widget _buildDeviceIcon() {
    IconData icon;
    Color color;

    if (device.isMobile) {
      icon = device.isSimulator
          ? CupertinoIcons.device_phone_portrait
          : CupertinoIcons.phone;
      color = device.type.category == 'iOS'
          ? CupertinoColors.systemGrey
          : CupertinoColors.systemGreen;
    } else if (device.isWeb) {
      icon = CupertinoIcons.globe;
      color = CupertinoColors.activeBlue;
    } else {
      icon = CupertinoIcons.desktopcomputer;
      color = CupertinoColors.systemPurple;
    }

    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(icon, color: color, size: 24),
    );
  }

  Widget _buildDeviceInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          device.name,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 2),
        Text(
          device.osVersion ?? device.type.displayName,
          style: TextStyle(
            fontSize: 13,
            color: CupertinoColors.secondaryLabel,
          ),
        ),
        if (device.tags.isNotEmpty) ...[
          const SizedBox(height: 4),
          Wrap(
            spacing: 4,
            children: device.tags.take(3).map((tag) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: CupertinoColors.systemGrey5,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    tag,
                    style: const TextStyle(fontSize: 10),
                  ),
                )).toList(),
          ),
        ],
      ],
    );
  }
}
```

### 8.4 Device Status Indicator

**File: `lib/presentation/widgets/device/device_status_indicator.dart`**

```dart
import 'package:flutter/cupertino.dart';
import '../../../domain/entities/device_status.dart';

/// Widget showing device connection status
class DeviceStatusIndicator extends StatelessWidget {
  final DeviceStatus status;
  final double size;
  final bool showLabel;

  const DeviceStatusIndicator({
    super.key,
    required this.status,
    this.size = 10,
    this.showLabel = false,
  });

  Color get _color {
    switch (status) {
      case DeviceStatus.connected:
        return CupertinoColors.systemGreen;
      case DeviceStatus.booting:
      case DeviceStatus.busy:
        return CupertinoColors.systemOrange;
      case DeviceStatus.unauthorized:
        return CupertinoColors.systemYellow;
      case DeviceStatus.disconnected:
      case DeviceStatus.offline:
      case DeviceStatus.unknown:
        return CupertinoColors.systemRed;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: _color,
            shape: BoxShape.circle,
            boxShadow: [
              if (status == DeviceStatus.connected)
                BoxShadow(
                  color: _color.withOpacity(0.4),
                  blurRadius: 4,
                  spreadRadius: 1,
                ),
            ],
          ),
        ),
        if (showLabel) ...[
          const SizedBox(width: 6),
          Text(
            status.displayName,
            style: TextStyle(
              fontSize: 12,
              color: _color,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ],
    );
  }
}
```

### 8.5 Device Selection Dropdown

**File: `lib/presentation/widgets/device/device_selection_dropdown.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../domain/entities/device.dart';
import '../../providers/device/device_provider.dart';
import 'device_status_indicator.dart';

/// Dropdown for selecting a device
class DeviceSelectionDropdown extends StatelessWidget {
  final void Function(Device?)? onChanged;
  final bool showRefreshButton;

  const DeviceSelectionDropdown({
    super.key,
    this.onChanged,
    this.showRefreshButton = true,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<DeviceProvider>(
      builder: (context, provider, _) {
        final devices = provider.filteredDevices;
        final selected = provider.selectedDevice;

        return Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: CupertinoColors.separator),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<Device>(
                    value: selected,
                    isExpanded: true,
                    hint: const Text('Select device'),
                    items: devices.map((device) {
                      return DropdownMenuItem(
                        value: device,
                        child: Row(
                          children: [
                            DeviceStatusIndicator(status: device.status),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                device.name,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (device.isFavorite)
                              const Icon(
                                CupertinoIcons.star_fill,
                                size: 14,
                                color: CupertinoColors.systemYellow,
                              ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (device) {
                      provider.selectDevice(device);
                      onChanged?.call(device);
                    },
                  ),
                ),
              ),
            ),
            if (showRefreshButton) ...[
              const SizedBox(width: 8),
              CupertinoButton(
                padding: EdgeInsets.zero,
                onPressed: provider.isLoading ? null : provider.refreshDevices,
                child: provider.isLoading
                    ? const CupertinoActivityIndicator()
                    : const Icon(CupertinoIcons.refresh),
              ),
            ],
          ],
        );
      },
    );
  }
}
```

### 6. Performance Considerations

#### 6.1 Optimization Strategies

- **Lazy Loading**: Load device info only when needed
- **Caching**: Cache device information
- **Background Processing**: Run discovery in background
- **Debouncing**: Debounce rapid device status updates
- **Streaming**: Use streams for real-time updates

#### 6.2 Resource Management

- Clean up processes after operations
- Limit concurrent operations
- Timeout long-running operations
- Monitor resource usage

---

## 9. Data Layer Implementation

### 9.1 Device Local Datasource

**File: `lib/data/datasources/local/device_local_datasource.dart`**

```dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/logging/logging.dart';
import '../../../domain/entities/device.dart';

/// Local datasource for persisting device preferences
class DeviceLocalDatasource with LoggerMixin {
  static const _favoritesKey = 'device_favorites';
  static const _tagsKey = 'device_tags';
  static const _recentDevicesKey = 'recent_devices';
  
  final SharedPreferences _prefs;

  DeviceLocalDatasource(this._prefs);

  /// Get favorite device IDs
  Set<String> getFavoriteDeviceIds() {
    final json = _prefs.getString(_favoritesKey);
    if (json == null) return {};
    return Set<String>.from(jsonDecode(json) as List);
  }

  /// Toggle device favorite status
  Future<void> toggleFavorite(String deviceId) async {
    final favorites = getFavoriteDeviceIds();
    if (favorites.contains(deviceId)) {
      favorites.remove(deviceId);
    } else {
      favorites.add(deviceId);
    }
    await _prefs.setString(_favoritesKey, jsonEncode(favorites.toList()));
    logger.debug('Toggled favorite', {'deviceId': deviceId});
  }

  /// Check if device is favorite
  bool isFavorite(String deviceId) {
    return getFavoriteDeviceIds().contains(deviceId);
  }

  /// Get tags for a device
  List<String> getDeviceTags(String deviceId) {
    final json = _prefs.getString(_tagsKey);
    if (json == null) return [];
    final allTags = jsonDecode(json) as Map<String, dynamic>;
    return List<String>.from(allTags[deviceId] ?? []);
  }

  /// Add tag to device
  Future<void> addTag(String deviceId, String tag) async {
    final json = _prefs.getString(_tagsKey);
    final allTags = json != null
        ? Map<String, List<String>>.from(
            (jsonDecode(json) as Map).map(
              (k, v) => MapEntry(k, List<String>.from(v)),
            ),
          )
        : <String, List<String>>{};
    
    allTags.putIfAbsent(deviceId, () => []);
    if (!allTags[deviceId]!.contains(tag)) {
      allTags[deviceId]!.add(tag);
      await _prefs.setString(_tagsKey, jsonEncode(allTags));
    }
  }

  /// Remove tag from device
  Future<void> removeTag(String deviceId, String tag) async {
    final json = _prefs.getString(_tagsKey);
    if (json == null) return;
    
    final allTags = Map<String, List<String>>.from(
      (jsonDecode(json) as Map).map(
        (k, v) => MapEntry(k, List<String>.from(v)),
      ),
    );
    
    allTags[deviceId]?.remove(tag);
    await _prefs.setString(_tagsKey, jsonEncode(allTags));
  }

  /// Add device to recent list
  Future<void> addRecentDevice(String deviceId) async {
    final recent = getRecentDeviceIds().toList();
    recent.remove(deviceId);
    recent.insert(0, deviceId);
    
    // Keep only last 10
    if (recent.length > 10) {
      recent.removeRange(10, recent.length);
    }
    
    await _prefs.setStringList(_recentDevicesKey, recent);
  }

  /// Get recent device IDs
  List<String> getRecentDeviceIds() {
    return _prefs.getStringList(_recentDevicesKey) ?? [];
  }

  /// Enrich device with local preferences
  Device enrichWithPreferences(Device device) {
    return device.copyWith(
      isFavorite: isFavorite(device.id),
      tags: getDeviceTags(device.id),
    );
  }

  /// Clear all local data
  Future<void> clearAll() async {
    await _prefs.remove(_favoritesKey);
    await _prefs.remove(_tagsKey);
    await _prefs.remove(_recentDevicesKey);
    logger.info('Cleared all device preferences');
  }
}
```

### 9.2 Device Cache Datasource

**File: `lib/data/datasources/local/device_cache_datasource.dart`**

```dart
import 'dart:async';
import '../../../domain/entities/device.dart';
import '../../../core/logging/logging.dart';

/// In-memory cache for device data
class DeviceCacheDatasource with LoggerMixin {
  final Map<String, Device> _deviceCache = {};
  final Map<String, DateTime> _cacheTimestamps = {};
  final Duration _cacheExpiry;
  
  final _deviceStreamController = StreamController<List<Device>>.broadcast();

  DeviceCacheDatasource({
    Duration cacheExpiry = const Duration(minutes: 5),
  }) : _cacheExpiry = cacheExpiry;

  /// Get all cached devices
  List<Device> get devices => _deviceCache.values.toList();

  /// Device stream
  Stream<List<Device>> get deviceStream => _deviceStreamController.stream;

  /// Get device by ID
  Device? getDevice(String id) {
    final device = _deviceCache[id];
    if (device != null && !_isExpired(id)) {
      return device;
    }
    return null;
  }

  /// Cache a device
  void cacheDevice(Device device) {
    _deviceCache[device.id] = device;
    _cacheTimestamps[device.id] = DateTime.now();
    _notifyListeners();
  }

  /// Cache multiple devices
  void cacheDevices(List<Device> devices) {
    final now = DateTime.now();
    for (final device in devices) {
      _deviceCache[device.id] = device;
      _cacheTimestamps[device.id] = now;
    }
    _notifyListeners();
  }

  /// Remove device from cache
  void removeDevice(String id) {
    _deviceCache.remove(id);
    _cacheTimestamps.remove(id);
    _notifyListeners();
  }

  /// Update device in cache
  void updateDevice(Device device) {
    if (_deviceCache.containsKey(device.id)) {
      cacheDevice(device);
    }
  }

  /// Clear entire cache
  void clearCache() {
    _deviceCache.clear();
    _cacheTimestamps.clear();
    _notifyListeners();
    logger.debug('Device cache cleared');
  }

  /// Clear expired entries
  void clearExpired() {
    final expiredIds = _cacheTimestamps.entries
        .where((e) => _isExpiredTimestamp(e.value))
        .map((e) => e.key)
        .toList();
    
    for (final id in expiredIds) {
      _deviceCache.remove(id);
      _cacheTimestamps.remove(id);
    }
    
    if (expiredIds.isNotEmpty) {
      _notifyListeners();
      logger.debug('Cleared ${expiredIds.length} expired cache entries');
    }
  }

  bool _isExpired(String id) {
    final timestamp = _cacheTimestamps[id];
    return timestamp == null || _isExpiredTimestamp(timestamp);
  }

  bool _isExpiredTimestamp(DateTime timestamp) {
    return DateTime.now().difference(timestamp) > _cacheExpiry;
  }

  void _notifyListeners() {
    _deviceStreamController.add(devices);
  }

  void dispose() {
    _deviceStreamController.close();
  }
}
```

---

## 10. Dependency Injection Setup

**File: `lib/core/di/device_module.dart`**

```dart
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/adb_service.dart';
import '../services/ios_device_service.dart';
import '../services/device_discovery_service.dart';
import '../services/web_browser_service.dart';
import '../../data/datasources/local/device_local_datasource.dart';
import '../../data/datasources/local/device_cache_datasource.dart';
import '../../data/repositories/device_repository_impl.dart';
import '../../domain/repositories/device_repository.dart';
import '../../domain/usecases/device/discover_devices_usecase.dart';
import '../../domain/usecases/device/install_app_usecase.dart';
import '../../domain/usecases/device/take_screenshot_usecase.dart';
import '../../domain/usecases/device/launch_app_usecase.dart';
import '../../domain/usecases/device/get_device_logs_usecase.dart';
import '../../domain/usecases/device/execute_shell_command_usecase.dart';
import '../../presentation/providers/device/device_provider.dart';

/// Module for device management dependency injection
class DeviceModule {
  static Future<List<SingleChildWidget>> getProviders() async {
    final prefs = await SharedPreferences.getInstance();
    
    // Services
    final adbService = AdbService();
    final iosDeviceService = IosDeviceService();
    final webBrowserService = WebBrowserService();
    
    // Datasources
    final localDatasource = DeviceLocalDatasource(prefs);
    final cacheDatasource = DeviceCacheDatasource();
    
    // Discovery Service
    final discoveryService = DeviceDiscoveryService(
      adbService: adbService,
      iosDeviceService: iosDeviceService,
    );
    
    // Repository
    final deviceRepository = DeviceRepositoryImpl(
      discoveryService: discoveryService,
      adbService: adbService,
      iosDeviceService: iosDeviceService,
      localDatasource: localDatasource,
    );
    
    // Use Cases
    final discoverDevicesUseCase = DiscoverDevicesUseCase(deviceRepository);
    final installAppUseCase = InstallAppUseCase(deviceRepository);
    final takeScreenshotUseCase = TakeScreenshotUseCase(deviceRepository);
    final launchAppUseCase = LaunchAppUseCase(deviceRepository);
    final getDeviceLogsUseCase = GetDeviceLogsUseCase(deviceRepository);
    final executeShellCommandUseCase = ExecuteShellCommandUseCase(deviceRepository);
    
    return [
      // Services
      Provider<AdbService>.value(value: adbService),
      Provider<IosDeviceService>.value(value: iosDeviceService),
      Provider<WebBrowserService>.value(value: webBrowserService),
      Provider<DeviceDiscoveryService>.value(value: discoveryService),
      
      // Repository
      Provider<DeviceRepository>.value(value: deviceRepository),
      
      // Use Cases
      Provider<DiscoverDevicesUseCase>.value(value: discoverDevicesUseCase),
      Provider<InstallAppUseCase>.value(value: installAppUseCase),
      Provider<TakeScreenshotUseCase>.value(value: takeScreenshotUseCase),
      Provider<LaunchAppUseCase>.value(value: launchAppUseCase),
      Provider<GetDeviceLogsUseCase>.value(value: getDeviceLogsUseCase),
      Provider<ExecuteShellCommandUseCase>.value(value: executeShellCommandUseCase),
      
      // Provider (State Management)
      ChangeNotifierProvider<DeviceProvider>(
        create: (_) => DeviceProvider(
          discoverDevicesUseCase: discoverDevicesUseCase,
          installAppUseCase: installAppUseCase,
          takeScreenshotUseCase: takeScreenshotUseCase,
          launchAppUseCase: launchAppUseCase,
        )..refreshDevices(),
      ),
    ];
  }
  
  /// Start device monitoring (call after app initialization)
  static void startMonitoring(DeviceDiscoveryService service) {
    service.startMonitoring();
  }
  
  /// Stop device monitoring (call on app dispose)
  static void stopMonitoring(DeviceDiscoveryService service) {
    service.stopMonitoring();
  }
}
```

### Usage in Main App

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/di/device_module.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Get device module providers
  final deviceProviders = await DeviceModule.getProviders();
  
  runApp(
    MultiProvider(
      providers: [
        // ... other providers
        ...deviceProviders,
      ],
      child: const MyApp(),
    ),
  );
}
```

---

## UI/UX Design

### 1. Device List Screen

#### 1.1 Layout

- **Sidebar**: Device groups and filters
- **Main Area**: Grid/list view of devices
- **Toolbar**: Actions (refresh, add group, settings)
- **Status Bar**: Connection status, device count

#### 1.2 Device Card

- Device icon/thumbnail
- Device name
- Status indicator (color-coded)
- OS version
- Quick actions (screenshot, logs, launch app)
- Favorite button
- Context menu (more actions)

#### 1.3 Features

- **View Modes**: Grid view, List view
- **Sorting**: By name, type, status, last seen
- **Filtering**: By type, status, group, tags
- **Search**: Search by name, model, ID
- **Selection**: Multi-select for batch operations

### 2. Device Detail Screen

#### 2.1 Tabs

- **Overview**: Basic device information
- **Apps**: Installed apps list
- **Logs**: Device logs viewer
- **Files**: File browser
- **Performance**: Performance metrics
- **Settings**: Device configuration

#### 2.2 Overview Tab

- Device image/icon
- Device information (name, model, OS, etc.)
- Status and capabilities
- Quick actions panel
- Recent activity

#### 2.3 Apps Tab

- List of installed apps
- Search and filter apps
- Install/Uninstall actions
- Launch app button
- App details (version, size, etc.)

#### 2.4 Logs Tab

- Real-time log stream
- Log level filters
- Search logs
- Export logs
- Clear logs button
- Log highlighting

### 3. Device Operations Screen

#### 3.1 Quick Actions Panel

- Install App button
- Take Screenshot button
- Record Screen button
- View Logs button
- File Transfer button
- Shell Access button

#### 3.2 Operation Status

- Show operation progress
- Display operation results
- Handle operation errors
- Operation history

### 4. Device Selection Widget

#### 4.1 Dropdown/Selector

- Dropdown for device selection
- Show device name and status
- Group devices by type
- Show favorite devices first
- Quick refresh button

#### 4.2 Integration Points

- Flutter run/build screens
- Project detail screen
- Git operations screen

### 5. Design System Integration

- Follow Apple Design System guidelines
- Use existing theme colors
- Consistent with app design language
- Responsive layouts
- Accessibility support

---

## Database Schema

### Devices Table

```sql
CREATE TABLE devices (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL,
  os_version TEXT,
  sdk_version TEXT,
  capabilities TEXT, -- JSON
  last_seen INTEGER,
  metadata TEXT, -- JSON
  is_favorite INTEGER DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
```

### Device Groups Table

```sql
CREATE TABLE device_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
```

### Device Group Members Table

```sql
CREATE TABLE device_group_members (
  device_id TEXT NOT NULL,
  group_id TEXT NOT NULL,
  PRIMARY KEY (device_id, group_id),
  FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
  FOREIGN KEY (group_id) REFERENCES device_groups(id) ON DELETE CASCADE
);
```

### Device Tags Table

```sql
CREATE TABLE device_tags (
  device_id TEXT NOT NULL,
  tag TEXT NOT NULL,
  PRIMARY KEY (device_id, tag),
  FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
);
```

---

## Testing Strategy

### 1. Unit Tests

**File: `test/unit/device/device_entity_test.dart`**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/device.dart';
import 'package:advanced_tester/domain/entities/device_type.dart';
import 'package:advanced_tester/domain/entities/device_status.dart';
import 'package:advanced_tester/domain/entities/device_capabilities.dart';

void main() {
  group('Device Entity', () {
    test('creates device with required fields', () {
      const device = Device(
        id: 'device-123',
        name: 'Pixel 7',
        type: DeviceType.android,
        status: DeviceStatus.connected,
      );

      expect(device.id, 'device-123');
      expect(device.name, 'Pixel 7');
      expect(device.type, DeviceType.android);
      expect(device.status, DeviceStatus.connected);
      expect(device.isAvailable, true);
      expect(device.isMobile, true);
      expect(device.isPhysicalDevice, true);
    });

    test('isSimulator returns correct value', () {
      const emulator = Device(
        id: 'emulator-5554',
        name: 'Pixel 7 API 34',
        type: DeviceType.androidEmulator,
        status: DeviceStatus.connected,
      );

      const simulator = Device(
        id: 'sim-123',
        name: 'iPhone 15 Pro',
        type: DeviceType.iosSimulator,
        status: DeviceStatus.connected,
      );

      expect(emulator.isSimulator, true);
      expect(simulator.isSimulator, true);
    });

    test('copyWith creates new instance with updated fields', () {
      const device = Device(
        id: 'device-123',
        name: 'Pixel 7',
        type: DeviceType.android,
        status: DeviceStatus.connected,
      );

      final updated = device.copyWith(
        status: DeviceStatus.disconnected,
        isFavorite: true,
      );

      expect(updated.id, device.id);
      expect(updated.status, DeviceStatus.disconnected);
      expect(updated.isFavorite, true);
      expect(device.status, DeviceStatus.connected); // Original unchanged
    });

    test('serialization round-trip', () {
      const device = Device(
        id: 'device-123',
        name: 'Pixel 7',
        type: DeviceType.android,
        status: DeviceStatus.connected,
        osVersion: 'Android 14',
        sdkVersion: 'API 34',
        capabilities: DeviceCapabilities(
          supportsScreenshot: true,
          supportsLogs: true,
        ),
        tags: ['testing', 'production'],
      );

      final json = device.toJson();
      final restored = Device.fromJson(json);

      expect(restored.id, device.id);
      expect(restored.name, device.name);
      expect(restored.type, device.type);
      expect(restored.osVersion, device.osVersion);
      expect(restored.tags, device.tags);
      expect(restored.capabilities.supportsScreenshot, true);
    });

    test('equality based on id', () {
      const device1 = Device(
        id: 'device-123',
        name: 'Pixel 7',
        type: DeviceType.android,
        status: DeviceStatus.connected,
      );

      const device2 = Device(
        id: 'device-123',
        name: 'Different Name',
        type: DeviceType.android,
        status: DeviceStatus.disconnected,
      );

      expect(device1 == device2, true);
      expect(device1.hashCode, device2.hashCode);
    });
  });

  group('DeviceType', () {
    test('fromTargetPlatform parses correctly', () {
      expect(DeviceType.fromTargetPlatform('android-arm64'), DeviceType.android);
      expect(DeviceType.fromTargetPlatform('ios'), DeviceType.ios);
      expect(DeviceType.fromTargetPlatform('darwin-x64'), DeviceType.macos);
      expect(DeviceType.fromTargetPlatform('web-javascript'), DeviceType.webChrome);
      expect(DeviceType.fromTargetPlatform('unknown'), null);
    });

    test('category groups correctly', () {
      expect(DeviceType.android.category, 'Android');
      expect(DeviceType.androidEmulator.category, 'Android');
      expect(DeviceType.ios.category, 'iOS');
      expect(DeviceType.iosSimulator.category, 'iOS');
      expect(DeviceType.webChrome.category, 'Web');
      expect(DeviceType.macos.category, 'Desktop');
    });
  });

  group('DeviceCapabilities', () {
    test('android factory has full capabilities', () {
      final caps = DeviceCapabilities.android();
      
      expect(caps.supportsScreenshot, true);
      expect(caps.supportsScreenRecording, true);
      expect(caps.supportsFileTransfer, true);
      expect(caps.supportsShellAccess, true);
      expect(caps.supportsAppInstall, true);
      expect(caps.supportsLogs, true);
    });

    test('web factory has limited capabilities', () {
      final caps = DeviceCapabilities.web();
      
      expect(caps.supportsScreenshot, true);
      expect(caps.supportsScreenRecording, false);
      expect(caps.supportsFileTransfer, false);
      expect(caps.supportsShellAccess, false);
      expect(caps.supportsAppInstall, false);
    });
  });
}
```

### 2. Use Case Tests

**File: `test/unit/device/install_app_usecase_test.dart`**

```dart
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:advanced_tester/domain/entities/device.dart';
import 'package:advanced_tester/domain/entities/device_type.dart';
import 'package:advanced_tester/domain/entities/device_status.dart';
import 'package:advanced_tester/domain/entities/device_capabilities.dart';
import 'package:advanced_tester/domain/repositories/device_repository.dart';
import 'package:advanced_tester/domain/usecases/device/install_app_usecase.dart';

class MockDeviceRepository extends Mock implements DeviceRepository {}

void main() {
  late MockDeviceRepository mockRepository;
  late InstallAppUseCase useCase;

  setUp(() {
    mockRepository = MockDeviceRepository();
    useCase = InstallAppUseCase(mockRepository);
  });

  group('InstallAppUseCase', () {
    const testDevice = Device(
      id: 'device-123',
      name: 'Pixel 7',
      type: DeviceType.android,
      status: DeviceStatus.connected,
      capabilities: DeviceCapabilities(supportsAppInstall: true),
    );

    test('returns failure when app file does not exist', () async {
      final result = await useCase.execute(
        deviceId: 'device-123',
        appPath: '/non/existent/path.apk',
      );

      expect(result, isA<InstallAppFailure>());
      expect((result as InstallAppFailure).error, contains('not found'));
    });

    test('returns failure when device not found', () async {
      when(() => mockRepository.getDeviceById('device-123'))
          .thenAnswer((_) async => null);

      // Create a temp file to pass file existence check
      final tempFile = File('${Directory.systemTemp.path}/test.apk');
      await tempFile.create();

      try {
        final result = await useCase.execute(
          deviceId: 'device-123',
          appPath: tempFile.path,
        );

        expect(result, isA<InstallAppFailure>());
        expect((result as InstallAppFailure).error, contains('not found'));
      } finally {
        await tempFile.delete();
      }
    });

    test('returns success on successful installation', () async {
      when(() => mockRepository.getDeviceById('device-123'))
          .thenAnswer((_) async => testDevice);
      when(() => mockRepository.installApp('device-123', any()))
          .thenAnswer((_) async {});

      final tempFile = File('${Directory.systemTemp.path}/test.apk');
      await tempFile.create();

      try {
        final result = await useCase.execute(
          deviceId: 'device-123',
          appPath: tempFile.path,
        );

        expect(result, isA<InstallAppSuccess>());
        final success = result as InstallAppSuccess;
        expect(success.device.id, 'device-123');
        expect(success.duration, isPositive);
        
        verify(() => mockRepository.installApp('device-123', tempFile.path))
            .called(1);
      } finally {
        await tempFile.delete();
      }
    });
  });
}
```

### 3. Service Tests (with Mocks)

**File: `test/unit/device/adb_service_test.dart`**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/core/services/adb_service.dart';
import 'package:advanced_tester/domain/entities/device_type.dart';
import 'package:advanced_tester/domain/entities/device_status.dart';

void main() {
  group('AdbService', () {
    late AdbService service;

    setUp(() {
      // Use custom adb path for testing if needed
      service = AdbService();
    });

    group('_parseDeviceLine', () {
      test('parses connected device correctly', () {
        const line = 'emulator-5554          device product:sdk_gphone64_arm64 model:sdk_gphone64_arm64 device:emu64a';
        
        // This is testing a private method indirectly through getConnectedDevices
        // In real tests, you might make the parser public or test through integration
      });
    });

    // Integration test example (requires actual ADB)
    test('detectAdbPath finds ADB', () async {
      // Skip if running in CI without Android SDK
      try {
        final path = await service.adbPath;
        expect(path, isNotEmpty);
      } catch (e) {
        // Skip test if ADB not available
        markTestSkipped('ADB not available');
      }
    }, skip: 'Requires Android SDK');
  });
}
```

### 4. Widget Tests

**File: `test/widget/device/device_card_test.dart`**

```dart
import 'package:flutter/cupertino.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:advanced_tester/domain/entities/device.dart';
import 'package:advanced_tester/domain/entities/device_type.dart';
import 'package:advanced_tester/domain/entities/device_status.dart';
import 'package:advanced_tester/presentation/widgets/device/device_card.dart';

void main() {
  group('DeviceCard', () {
    const testDevice = Device(
      id: 'device-123',
      name: 'Pixel 7 Pro',
      type: DeviceType.android,
      status: DeviceStatus.connected,
      osVersion: 'Android 14',
    );

    testWidgets('displays device name', (tester) async {
      await tester.pumpWidget(
        CupertinoApp(
          home: DeviceCard(device: testDevice),
        ),
      );

      expect(find.text('Pixel 7 Pro'), findsOneWidget);
    });

    testWidgets('displays OS version', (tester) async {
      await tester.pumpWidget(
        CupertinoApp(
          home: DeviceCard(device: testDevice),
        ),
      );

      expect(find.text('Android 14'), findsOneWidget);
    });

    testWidgets('shows favorite icon when device is favorite', (tester) async {
      final favoriteDevice = testDevice.copyWith(isFavorite: true);

      await tester.pumpWidget(
        CupertinoApp(
          home: DeviceCard(device: favoriteDevice),
        ),
      );

      expect(find.byIcon(CupertinoIcons.star_fill), findsOneWidget);
    });

    testWidgets('calls onTap when tapped', (tester) async {
      var tapped = false;

      await tester.pumpWidget(
        CupertinoApp(
          home: DeviceCard(
            device: testDevice,
            onTap: () => tapped = true,
          ),
        ),
      );

      await tester.tap(find.byType(DeviceCard));
      expect(tapped, true);
    });

    testWidgets('shows selected state', (tester) async {
      await tester.pumpWidget(
        CupertinoApp(
          home: DeviceCard(
            device: testDevice,
            isSelected: true,
          ),
        ),
      );

      // Verify the border color changes for selected state
      final container = tester.widget<Container>(
        find.byType(Container).first,
      );
      // Verify decoration has selected styling
      expect(container.decoration, isNotNull);
    });

    testWidgets('displays tags', (tester) async {
      final deviceWithTags = testDevice.copyWith(
        tags: ['testing', 'production', 'ci'],
      );

      await tester.pumpWidget(
        CupertinoApp(
          home: DeviceCard(device: deviceWithTags),
        ),
      );

      expect(find.text('testing'), findsOneWidget);
      expect(find.text('production'), findsOneWidget);
      expect(find.text('ci'), findsOneWidget);
    });
  });
}
```

### 5. Integration Tests (Mocked External Commands)

**File: `test/integration/device_discovery_test.dart`**

```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:advanced_tester/core/services/device_discovery_service.dart';
import 'package:advanced_tester/core/services/adb_service.dart';
import 'package:advanced_tester/core/services/ios_device_service.dart';
import 'package:advanced_tester/domain/entities/device.dart';
import 'package:advanced_tester/domain/entities/device_type.dart';
import 'package:advanced_tester/domain/entities/device_status.dart';

class MockAdbService extends Mock implements AdbService {}
class MockIosDeviceService extends Mock implements IosDeviceService {}

void main() {
  late MockAdbService mockAdbService;
  late MockIosDeviceService mockIosDeviceService;
  late DeviceDiscoveryService discoveryService;

  setUp(() {
    mockAdbService = MockAdbService();
    mockIosDeviceService = MockIosDeviceService();
    discoveryService = DeviceDiscoveryService(
      adbService: mockAdbService,
      iosDeviceService: mockIosDeviceService,
    );
  });

  tearDown(() {
    discoveryService.dispose();
  });

  group('DeviceDiscoveryService', () {
    test('scanDevices returns combined results from all platforms', () async {
      const androidDevice = Device(
        id: 'android-123',
        name: 'Pixel 7',
        type: DeviceType.android,
        status: DeviceStatus.connected,
      );

      const iosSimulator = Device(
        id: 'ios-456',
        name: 'iPhone 15',
        type: DeviceType.iosSimulator,
        status: DeviceStatus.connected,
      );

      when(() => mockAdbService.getConnectedDevices())
          .thenAnswer((_) async => [androidDevice]);
      when(() => mockIosDeviceService.getConnectedDevices())
          .thenAnswer((_) async => [iosSimulator]);

      final devices = await discoveryService.scanDevices();

      expect(devices.length, greaterThanOrEqualTo(2)); // +1 for Chrome
      expect(devices.any((d) => d.id == 'android-123'), true);
      expect(devices.any((d) => d.id == 'ios-456'), true);
      expect(devices.any((d) => d.id == 'chrome'), true);
    });

    test('emits DeviceConnectedEvent for new devices', () async {
      when(() => mockAdbService.getConnectedDevices())
          .thenAnswer((_) async => [
                const Device(
                  id: 'new-device',
                  name: 'New Device',
                  type: DeviceType.android,
                  status: DeviceStatus.connected,
                ),
              ]);
      when(() => mockIosDeviceService.getConnectedDevices())
          .thenAnswer((_) async => []);

      expect(
        discoveryService.events,
        emits(isA<DeviceConnectedEvent>()),
      );

      await discoveryService.scanDevices();
    });

    test('emits DeviceDisconnectedEvent when device removed', () async {
      const device = Device(
        id: 'device-to-remove',
        name: 'Device',
        type: DeviceType.android,
        status: DeviceStatus.connected,
      );

      // First scan: device present
      when(() => mockAdbService.getConnectedDevices())
          .thenAnswer((_) async => [device]);
      when(() => mockIosDeviceService.getConnectedDevices())
          .thenAnswer((_) async => []);

      await discoveryService.scanDevices();

      // Second scan: device removed
      when(() => mockAdbService.getConnectedDevices())
          .thenAnswer((_) async => []);

      expect(
        discoveryService.events,
        emits(isA<DeviceDisconnectedEvent>()),
      );

      await discoveryService.scanDevices();
    });
  });
}
```

---

## Dependencies

### Required Packages

**Updated `pubspec.yaml`:**

```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # State Management (using existing provider)
  provider: ^6.1.2
  
  # Existing dependencies used
  shared_preferences: ^2.3.2
  path: ^1.9.0
  
  # New for Device Management
  process_run: ^1.0.0    # Enhanced process execution with streaming
  xml: ^6.5.0            # XML parsing (for ADB output)
  path_provider: ^2.1.0  # Platform-specific file paths
  file_picker: ^8.0.0    # File selection dialogs
  image: ^4.2.0          # Image processing for screenshots
  archive: ^3.4.10       # Existing - for APK/IPA handling
  
dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^5.0.0
  mocktail: ^1.0.4       # Mocking for tests
  fake_async: ^1.3.1     # Async testing utilities
```

### New Files to Create

```
lib/
├── domain/
│   ├── entities/
│   │   ├── device.dart                    # Device entity
│   │   ├── device_type.dart               # DeviceType enum
│   │   ├── device_status.dart             # DeviceStatus enum
│   │   └── device_capabilities.dart       # DeviceCapabilities class
│   ├── repositories/
│   │   └── device_repository.dart         # Repository interface
│   └── usecases/
│       └── device/
│           ├── discover_devices_usecase.dart
│           ├── install_app_usecase.dart
│           ├── take_screenshot_usecase.dart
│           ├── launch_app_usecase.dart
│           ├── get_device_logs_usecase.dart
│           └── execute_shell_command_usecase.dart
├── data/
│   ├── datasources/
│   │   └── local/
│   │       ├── device_local_datasource.dart
│   │       └── device_cache_datasource.dart
│   └── repositories/
│       └── device_repository_impl.dart
├── core/
│   ├── services/
│   │   ├── adb_service.dart
│   │   ├── ios_device_service.dart
│   │   ├── device_discovery_service.dart
│   │   └── web_browser_service.dart
│   └── di/
│       └── device_module.dart
└── presentation/
    ├── providers/
    │   └── device/
    │       └── device_provider.dart
    └── widgets/
        └── device/
            ├── device_list_widget.dart
            ├── device_card.dart
            ├── device_status_indicator.dart
            └── device_selection_dropdown.dart
```

### Platform-Specific Requirements

**macOS:**
- ✅ Xcode (for iOS simulator support)
- ✅ Android SDK (for ADB) - Set `ANDROID_HOME` environment variable
- 📦 Optional: libimobiledevice (for physical iOS devices)
  ```bash
  brew install libimobiledevice ideviceinstaller
  ```

**Windows (Future):**
- Android SDK (for ADB) - Set `ANDROID_HOME` environment variable
- Android Emulator via Android Studio

**Linux (Future):**
- Android SDK (for ADB) - Set `ANDROID_HOME` environment variable
- 📦 Optional: libimobiledevice (for iOS file transfer)
  ```bash
  sudo apt-get install libimobiledevice-utils
  ```

### Environment Variables

```bash
# Required for ADB detection
export ANDROID_HOME="/Users/$USER/Library/Android/sdk"
export PATH="$PATH:$ANDROID_HOME/platform-tools"

# Optional: Flutter SDK root (auto-detected usually)
export FLUTTER_ROOT="/path/to/flutter"
```

---

## Security Considerations

### 1. Device Authorization

- Handle unauthorized devices gracefully
- Request user authorization when needed
- Store authorization state securely

### 2. File Transfer Security

- Validate file paths
- Check file permissions
- Sanitize file names
- Prevent directory traversal

### 3. Shell Command Security

- Validate shell commands
- Prevent injection attacks
- Limit command execution scope
- Log all shell commands

### 4. Data Privacy

- Don't store sensitive device data
- Encrypt cached device information
- Clear device data on disconnect
- Respect user privacy preferences

---

## Future Enhancements

### 1. Cloud Device Management

- Sync devices across machines
- Remote device access
- Cloud-based device pools

### 2. Device Profiles

- Save device configurations
- Apply profiles to devices
- Share profiles with team

### 3. Device Analytics

- Track device usage
- Device performance analytics
- Usage reports

### 4. Plugin System

- Extensible device support
- Third-party device plugins
- Custom device operations

---

## Success Criteria

### Phase 1 (Basic)
- ✅ Discover Android and iOS devices
- ✅ Display device list with status
- ✅ Install and launch apps
- ✅ Take screenshots
- ✅ View device logs

### Phase 2 (Enhanced)
- ✅ Device grouping and filtering
- ✅ File transfer
- ✅ Shell access
- ✅ Screen recording

### Phase 3 (Advanced)
- ✅ Performance monitoring
- ✅ Multi-device operations
- ✅ Device automation
- ✅ Advanced logging

### Phase 4 (Integration)
- ✅ Flutter integration
- ✅ Git integration
- ✅ Project integration
- ✅ Full test coverage

---

## Quick Start Guide

### Step 1: Add Dependencies

Add to `pubspec.yaml`:
```yaml
dependencies:
  process_run: ^1.0.0
  xml: ^6.5.0
  path_provider: ^2.1.0
  mocktail: ^1.0.4  # dev dependency
```

### Step 2: Create Entity Files

Create the domain entities in order:
1. `lib/domain/entities/device_type.dart`
2. `lib/domain/entities/device_status.dart`
3. `lib/domain/entities/device_capabilities.dart`
4. `lib/domain/entities/device.dart`

### Step 3: Create Services

Create the core services:
1. `lib/core/services/adb_service.dart`
2. `lib/core/services/ios_device_service.dart`
3. `lib/core/services/device_discovery_service.dart`

### Step 4: Create Repository Layer

1. `lib/domain/repositories/device_repository.dart` (interface)
2. `lib/data/datasources/local/device_local_datasource.dart`
3. `lib/data/repositories/device_repository_impl.dart`

### Step 5: Create Use Cases

Create use cases in `lib/domain/usecases/device/`:
1. `discover_devices_usecase.dart`
2. `install_app_usecase.dart`
3. `take_screenshot_usecase.dart`
4. `launch_app_usecase.dart`

### Step 6: Create Presentation Layer

1. `lib/presentation/providers/device/device_provider.dart`
2. `lib/presentation/widgets/device/device_card.dart`
3. `lib/presentation/widgets/device/device_list_widget.dart`

### Step 7: Setup Dependency Injection

Create `lib/core/di/device_module.dart` and integrate with your app.

### Step 8: Usage Example

```dart
// In your widget
class DeviceManagementScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<DeviceProvider>(
      builder: (context, provider, _) {
        return Column(
          children: [
            // Device selector
            DeviceSelectionDropdown(
              onChanged: (device) {
                print('Selected: ${device?.name}');
              },
            ),
            
            // Device list
            Expanded(
              child: DeviceListWidget(
                onDeviceSelected: (device) {
                  provider.selectDevice(device);
                },
              ),
            ),
            
            // Actions
            if (provider.selectedDevice != null)
              Row(
                children: [
                  CupertinoButton(
                    child: Text('Screenshot'),
                    onPressed: () async {
                      final result = await provider.takeScreenshot();
                      if (result != null) {
                        print('Screenshot saved: ${result.savedPath}');
                      }
                    },
                  ),
                  CupertinoButton(
                    child: Text('Install App'),
                    onPressed: () async {
                      final result = await provider.installApp('/path/to/app.apk');
                      if (result is InstallAppSuccess) {
                        print('Installed in ${result.duration.inSeconds}s');
                      }
                    },
                  ),
                ],
              ),
          ],
        );
      },
    );
  }
}
```

---

## Notes

- All features marked with ✅ are planned for implementation
- Implementation follows existing Clean Architecture patterns in the codebase
- Uses `LoggerMixin` for consistent logging across all services
- Maintain backward compatibility with existing device detection in `device_service.dart`
- Document all public APIs with dartdoc comments
- Follow security best practices (validate inputs, sanitize commands)
- Optimize for performance (caching, lazy loading, debouncing)
- Ensure accessibility compliance in UI widgets
- All services are designed for testability with dependency injection

