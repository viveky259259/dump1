Generate a single Dart widget test file. 
Return ONLY the Dart code, no explanations or markdown.

=== FILE INFO ===
File name: <test_file_name>.dart

=== IMPORTS ===
- package:flutter_test/flutter_test.dart
- package:flutter/material.dart
- (optional) package:provider/provider.dart
- package:<your_app>/<path>.dart show <WidgetClass>, <DependenciesIfAny>

=== WIDGET UNDER TEST ===
Widget/Class: <WidgetClass>
Constructor signature: <WidgetConstructor>
Factory for test:

Widget buildTestSubject() {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true),
    home: <WrapperIfAny>(
      child: <WidgetClass>(
        key: Key('<root_key>'),
        <constructor_params>,
      ),
    ),
  );
}

=== STABLE IDENTIFIERS ===
- Root widget: Key('<root_key>')
- Important child #1: Key('<child1_key>')
- Important child #2: Key('<child2_key>')
- Interactive control (e.g., FAB): Key('<fab_key>')
- (Optional) Conditional widget: Key('<extra_key>')

=== TEST REQUIREMENTS ===
1. Group tests under `group('<WidgetClass>', ...)`.
2. Verify widget renders with all expected children.
3. Assert child properties (text values, sizes, alignment, etc.).
4. Test interactions (e.g., tapping FAB increments counter).
5. Test conditional UI state changes (if applicable).
6. Verify provider/dependency setup (if required).
7. Assert theming/config flags (e.g., `useMaterial3 == true`, `debugShowCheckedModeBanner == false`).
8. Accessibility/semantics tests if semantics labels/roles provided.
9. Use robust finders (`find.byKey`, `find.text`) and clear test names.
10. Omit performance, memory, lifecycle, or error-handling tests unless explicitly specified.

=== OUTPUT CONSTRAINTS ===
- Return one Dart test file, named `<test_file_name>.dart`.
- Contain only Dart code.
- No markdown, comments, or explanations.
