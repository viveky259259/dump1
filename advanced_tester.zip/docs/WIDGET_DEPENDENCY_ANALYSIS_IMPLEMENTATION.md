# Widget Dependency Analysis Implementation Guide

## 🎯 Overview

This guide shows how to implement an intelligent widget dependency analysis system that automatically detects and sets up all dependencies required for isolated widget testing. The system will analyze selected widgets and generate complete test wrappers with proper Provider, InheritedWidget, Theme, and other context dependencies.

## 🏗 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Advanced Tester Tool                        │
├─────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐      │
│  │ Widget Inspector│  │ Dependency      │  │ Test Generator  │      │
│  │ Service         │  │ Analyzer        │  │ Service         │      │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘      │
├─────────────────────────────────────────────────────────────────────┤
│                    Dart Code Extension APIs                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐      │
│  │ Flutter Outline │  │ LSP Analysis    │  │ Source Code     │      │
│  │ Provider        │  │ Server          │  │ Analysis        │      │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘      │
└─────────────────────────────────────────────────────────────────────┘
```

## 📁 Implementation Structure

### Core Services to Implement

1. **`DependencyAnalysisService`** - Main service for dependency detection
2. **`SourceCodeAnalyzer`** - Analyzes widget source code for dependencies
3. **`TestWrapperGenerator`** - Generates test code with proper wrappers
4. **`MockGenerator`** - Creates mock objects for dependencies
5. **`ContextDependencyDetector`** - Specialized dependency pattern detection

## 🚀 Phase 1: Basic Foundation

### Step 1: Enhanced Inspector Service Integration

First, extend your existing `InspectorService` to get source code locations:

```dart
// lib/services/inspector_service.dart - Add these methods

/// Get the source code location for a widget
Future<SourceLocation?> getWidgetSourceLocation(String objectId) async {
  final response = await invokeInspector(
    method: 'getSourceLocation',
    args: {
      'objectGroup': _getObjectGroup(),
      'objectId': objectId,
    },
  );
  
  if (response?.json != null) {
    final json = response!.json! as Map<String, dynamic>;
    return SourceLocation.fromJson(json);
  }
  return null;
}

/// Get the actual source code for a widget
Future<String?> getWidgetSourceCode(SourceLocation location) async {
  // This would use VS Code API or file system access
  try {
    final file = File(location.file);
    if (await file.exists()) {
      final content = await file.readAsString();
      final lines = content.split('\n');
      
      // Extract the relevant lines for the widget
      final startLine = location.line - 1;
      final endLine = location.endLine ?? startLine + 20; // Estimate
      
      if (startLine >= 0 && startLine < lines.length) {
        return lines.sublist(startLine, 
            math.min(endLine, lines.length)).join('\n');
      }
    }
  } catch (e) {
    print('Error reading source code: $e');
  }
  return null;
}

class SourceLocation {
  final String file;
  final int line;
  final int column;
  final int? endLine;
  final int? endColumn;
  
  SourceLocation({
    required this.file,
    required this.line,
    required this.column,
    this.endLine,
    this.endColumn,
  });
  
  factory SourceLocation.fromJson(Map<String, dynamic> json) {
    return SourceLocation(
      file: json['file'] as String,
      line: json['line'] as int,
      column: json['column'] as int,
      endLine: json['endLine'] as int?,
      endColumn: json['endColumn'] as int?,
    );
  }
}
```

### Step 2: Create Dependency Analysis Service

```dart
// lib/services/dependency_analysis_service.dart

import 'dart:io';
import 'dart:math' as math;
import 'inspector_service.dart';

class DependencyAnalysisService {
  final InspectorService _inspectorService;
  final SourceCodeAnalyzer _sourceAnalyzer = SourceCodeAnalyzer();
  final TestWrapperGenerator _testGenerator = TestWrapperGenerator();
  
  DependencyAnalysisService(this._inspectorService);
  
  /// Main method to analyze widget dependencies
  Future<WidgetDependencyInfo?> analyzeWidget(String objectId) async {
    try {
      // Step 1: Get widget details from inspector
      final widgetDetails = await _inspectorService.getWidgetDetails(objectId);
      if (widgetDetails == null) return null;
      
      // Step 2: Get source location
      final sourceLocation = await _inspectorService.getWidgetSourceLocation(objectId);
      if (sourceLocation == null) return null;
      
      // Step 3: Get source code
      final sourceCode = await _inspectorService.getWidgetSourceCode(sourceLocation);
      if (sourceCode == null) return null;
      
      // Step 4: Analyze dependencies
      final dependencies = await _sourceAnalyzer.analyzeDependencies(sourceCode, sourceLocation);
      
      // Step 5: Find required imports
      final imports = await _sourceAnalyzer.findRequiredImports(sourceLocation.file);
      
      return WidgetDependencyInfo(
        objectId: objectId,
        widgetType: widgetDetails['runtimeType']?.toString() ?? 'Unknown',
        sourceLocation: sourceLocation,
        sourceCode: sourceCode,
        dependencies: dependencies,
        requiredImports: imports,
        widgetDetails: widgetDetails,
      );
      
    } catch (e) {
      print('Error analyzing widget dependencies: $e');
      return null;
    }
  }
  
  /// Generate test code for a widget
  Future<String> generateTestCode(WidgetDependencyInfo info) async {
    return await _testGenerator.generateTestWrapper(info);
  }
}

class WidgetDependencyInfo {
  final String objectId;
  final String widgetType;
  final SourceLocation sourceLocation;
  final String sourceCode;
  final List<ContextDependency> dependencies;
  final List<String> requiredImports;
  final Map<String, dynamic> widgetDetails;
  
  WidgetDependencyInfo({
    required this.objectId,
    required this.widgetType,
    required this.sourceLocation,
    required this.sourceCode,
    required this.dependencies,
    required this.requiredImports,
    required this.widgetDetails,
  });
}
```

### Step 3: Source Code Analyzer

```dart
// lib/services/source_code_analyzer.dart

class SourceCodeAnalyzer {
  static final Map<RegExp, ContextDependencyType> _dependencyPatterns = {
    // Provider patterns
    RegExp(r'Provider\.of<(\w+)>\s*\(\s*context\s*\)'): ContextDependencyType.provider,
    RegExp(r'context\.read<(\w+)>\s*\(\s*\)'): ContextDependencyType.provider,
    RegExp(r'context\.watch<(\w+)>\s*\(\s*\)'): ContextDependencyType.provider,
    RegExp(r'Consumer<(\w+)>'): ContextDependencyType.provider,
    
    // BLoC patterns
    RegExp(r'BlocProvider\.of<(\w+)>\s*\(\s*context\s*\)'): ContextDependencyType.bloc,
    RegExp(r'context\.read<(\w+)Bloc>\s*\(\s*\)'): ContextDependencyType.bloc,
    RegExp(r'BlocBuilder<(\w+),'): ContextDependencyType.bloc,
    RegExp(r'BlocConsumer<(\w+),'): ContextDependencyType.bloc,
    
    // Flutter built-in dependencies
    RegExp(r'Theme\.of\s*\(\s*context\s*\)'): ContextDependencyType.theme,
    RegExp(r'MediaQuery\.of\s*\(\s*context\s*\)'): ContextDependencyType.mediaQuery,
    RegExp(r'Navigator\.of\s*\(\s*context\s*\)'): ContextDependencyType.navigator,
    RegExp(r'Scaffold\.of\s*\(\s*context\s*\)'): ContextDependencyType.scaffold,
    RegExp(r'DefaultTabController\.of\s*\(\s*context\s*\)'): ContextDependencyType.tabController,
    
    // Localization
    RegExp(r'Localizations\.of\s*\(\s*context\s*\)'): ContextDependencyType.localization,
    RegExp(r'AppLocalizations\.of\s*\(\s*context\s*\)'): ContextDependencyType.localization,
    
    // Form dependencies
    RegExp(r'Form\.of\s*\(\s*context\s*\)'): ContextDependencyType.form,
    
    // Custom InheritedWidget pattern (generic)
    RegExp(r'(\w+)\.of\s*\(\s*context\s*\)'): ContextDependencyType.inherited,
  };
  
  Future<List<ContextDependency>> analyzeDependencies(
    String sourceCode, 
    SourceLocation location
  ) async {
    final dependencies = <ContextDependency>[];
    final foundTypes = <String>{};
    
    // Analyze each dependency pattern
    for (final entry in _dependencyPatterns.entries) {
      final matches = entry.key.allMatches(sourceCode);
      
      for (final match in matches) {
        final dependencyType = entry.value;
        final typeParam = match.groupCount > 0 ? match.group(1) : null;
        
        // Avoid duplicates
        final key = '${dependencyType}_${typeParam ?? ''}';
        if (foundTypes.contains(key)) continue;
        foundTypes.add(key);
        
        final dependency = _createDependency(dependencyType, typeParam, match.group(0)!);
        if (dependency != null) {
          dependencies.add(dependency);
        }
      }
    }
    
    // Special analysis for constructor parameters
    final constructorDeps = await _analyzeConstructorDependencies(sourceCode);
    dependencies.addAll(constructorDeps);
    
    return dependencies;
  }
  
  ContextDependency? _createDependency(
    ContextDependencyType type, 
    String? typeParam, 
    String matchedText
  ) {
    switch (type) {
      case ContextDependencyType.provider:
        return ProviderDependency(typeParam ?? 'dynamic');
      case ContextDependencyType.bloc:
        return BlocDependency(typeParam ?? 'dynamic');
      case ContextDependencyType.theme:
        return ThemeDependency();
      case ContextDependencyType.mediaQuery:
        return MediaQueryDependency();
      case ContextDependencyType.navigator:
        return NavigatorDependency();
      case ContextDependencyType.scaffold:
        return ScaffoldDependency();
      case ContextDependencyType.localization:
        return LocalizationDependency();
      case ContextDependencyType.form:
        return FormDependency();
      case ContextDependencyType.tabController:
        return TabControllerDependency();
      case ContextDependencyType.inherited:
        return InheritedWidgetDependency(typeParam ?? 'dynamic');
    }
  }
  
  Future<List<ContextDependency>> _analyzeConstructorDependencies(String sourceCode) async {
    final dependencies = <ContextDependency>[];
    
    // Look for constructor parameters that might need mocking
    final constructorPattern = RegExp(r'(\w+)\s*\(\s*([^)]*)\s*\)');
    final matches = constructorPattern.allMatches(sourceCode);
    
    for (final match in matches) {
      final params = match.group(2);
      if (params != null && params.isNotEmpty) {
        // Analyze parameter types for potential dependencies
        // This is a simplified version - you might want more sophisticated parsing
        if (params.contains('Function') || params.contains('VoidCallback')) {
          dependencies.add(CallbackDependency());
        }
      }
    }
    
    return dependencies;
  }
  
  Future<List<String>> findRequiredImports(String filePath) async {
    final imports = <String>[];
    
    try {
      final file = File(filePath);
      if (await file.exists()) {
        final content = await file.readAsString();
        final importPattern = RegExp(r"import\s+['\"]([^'\"]+)['\"];");
        final matches = importPattern.allMatches(content);
        
        for (final match in matches) {
          final importPath = match.group(1);
          if (importPath != null) {
            imports.add(importPath);
          }
        }
      }
    } catch (e) {
      print('Error reading imports: $e');
    }
    
    return imports;
  }
}

enum ContextDependencyType {
  provider,
  bloc,
  theme,
  mediaQuery,
  navigator,
  scaffold,
  localization,
  form,
  tabController,
  inherited,
}
```

### Step 4: Context Dependencies

```dart
// lib/models/context_dependency.dart

abstract class ContextDependency {
  String get name;
  String get description;
  
  /// Wraps a widget with the necessary context provider
  String wrapWidget(String widgetCode, {int indentLevel = 2});
  
  /// Generates any required imports
  List<String> get requiredImports;
  
  /// Generates mock setup code if needed
  String generateMockSetup();
}

class ProviderDependency extends ContextDependency {
  final String providerType;
  
  ProviderDependency(this.providerType);
  
  @override
  String get name => 'Provider<$providerType>';
  
  @override
  String get description => 'Provides $providerType via Provider pattern';
  
  @override
  List<String> get requiredImports => [
    'package:provider/provider.dart',
    'package:mockito/mockito.dart',
  ];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}ChangeNotifierProvider<$providerType>(
${indent}  create: (_) => Mock$providerType(),
${indent}  child: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() {
    return '''
class Mock$providerType extends Mock implements $providerType {}

final mock${providerType} = Mock$providerType();''';
  }
}

class ThemeDependency extends ContextDependency {
  @override
  String get name => 'Theme';
  
  @override
  String get description => 'Provides Material Theme context';
  
  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}MaterialApp(
${indent}  home: Scaffold(
${indent}    body: $widgetCode,
${indent}  ),
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

class MediaQueryDependency extends ContextDependency {
  @override
  String get name => 'MediaQuery';
  
  @override
  String get description => 'Provides MediaQuery data';
  
  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}MediaQuery(
${indent}  data: const MediaQueryData(),
${indent}  child: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

class BlocDependency extends ContextDependency {
  final String blocType;
  
  BlocDependency(this.blocType);
  
  @override
  String get name => 'BlocProvider<$blocType>';
  
  @override
  String get description => 'Provides $blocType via BLoC pattern';
  
  @override
  List<String> get requiredImports => [
    'package:flutter_bloc/flutter_bloc.dart',
    'package:mockito/mockito.dart',
  ];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}BlocProvider<$blocType>(
${indent}  create: (_) => Mock$blocType(),
${indent}  child: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() {
    return '''
class Mock$blocType extends Mock implements $blocType {}

final mock$blocType = Mock$blocType();''';
  }
}

// Add more dependency types...
class NavigatorDependency extends ContextDependency {
  @override
  String get name => 'Navigator';
  @override
  String get description => 'Provides Navigator context';
  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}MaterialApp(
${indent}  home: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

class ScaffoldDependency extends ContextDependency {
  @override
  String get name => 'Scaffold';
  @override
  String get description => 'Provides Scaffold context';
  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}MaterialApp(
${indent}  home: Scaffold(
${indent}    body: $widgetCode,
${indent}  ),
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

class CallbackDependency extends ContextDependency {
  @override
  String get name => 'Callbacks';
  @override
  String get description => 'Provides mock callbacks for functions';
  @override
  List<String> get requiredImports => ['package:mockito/mockito.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) => widgetCode;
  
  @override
  String generateMockSetup() {
    return '''
// Mock callbacks
final mockCallback = MockFunction();
class MockFunction extends Mock {
  call() {}
}''';
  }
}

class LocalizationDependency extends ContextDependency {
  @override
  String get name => 'Localizations';
  @override
  String get description => 'Provides localization context';
  @override
  List<String> get requiredImports => [
    'package:flutter/material.dart',
    'package:flutter_localizations/flutter_localizations.dart',
  ];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}MaterialApp(
${indent}  localizationsDelegates: const [
${indent}    GlobalMaterialLocalizations.delegate,
${indent}    GlobalWidgetsLocalizations.delegate,
${indent}  ],
${indent}  supportedLocales: const [Locale('en', 'US')],
${indent}  home: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

// Add more dependency types as needed...
class FormDependency extends ContextDependency {
  @override
  String get name => 'Form';
  @override
  String get description => 'Provides Form context';
  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}Form(
${indent}  child: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

class TabControllerDependency extends ContextDependency {
  @override
  String get name => 'TabController';
  @override
  String get description => 'Provides TabController context';
  @override
  List<String> get requiredImports => ['package:flutter/material.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}DefaultTabController(
${indent}  length: 3,
${indent}  child: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() => '';
}

class InheritedWidgetDependency extends ContextDependency {
  final String widgetType;
  
  InheritedWidgetDependency(this.widgetType);
  
  @override
  String get name => 'InheritedWidget<$widgetType>';
  @override
  String get description => 'Provides $widgetType inherited widget';
  @override
  List<String> get requiredImports => ['package:mockito/mockito.dart'];
  
  @override
  String wrapWidget(String widgetCode, {int indentLevel = 2}) {
    final indent = '  ' * indentLevel;
    return '''
${indent}Mock$widgetType(
${indent}  child: $widgetCode,
${indent})''';
  }
  
  @override
  String generateMockSetup() {
    return '''
class Mock$widgetType extends InheritedWidget {
  const Mock$widgetType({Key? key, required Widget child}) 
    : super(key: key, child: child);
    
  @override
  bool updateShouldNotify(Mock$widgetType oldWidget) => false;
  
  static Mock$widgetType? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<Mock$widgetType>();
  }
}''';
  }
}
```

### Step 5: Test Wrapper Generator

```dart
// lib/services/test_wrapper_generator.dart

class TestWrapperGenerator {
  Future<String> generateTestWrapper(WidgetDependencyInfo info) async {
    final buffer = StringBuffer();
    
    // Generate file header
    _generateFileHeader(buffer, info);
    
    // Generate imports
    _generateImports(buffer, info);
    
    // Generate mocks
    _generateMocks(buffer, info);
    
    // Generate main test
    _generateMainTest(buffer, info);
    
    return buffer.toString();
  }
  
  void _generateFileHeader(StringBuffer buffer, WidgetDependencyInfo info) {
    buffer.writeln('// Generated test file for ${info.widgetType}');
    buffer.writeln('// Auto-generated by Advanced Tester');
    buffer.writeln('// ${DateTime.now().toIso8601String()}');
    buffer.writeln();
  }
  
  void _generateImports(StringBuffer buffer, WidgetDependencyInfo info) {
    final imports = <String>{
      'package:flutter/material.dart',
      'package:flutter_test/flutter_test.dart',
    };
    
    // Add original widget imports
    imports.addAll(info.requiredImports);
    
    // Add dependency-specific imports
    for (final dependency in info.dependencies) {
      imports.addAll(dependency.requiredImports);
    }
    
    // Write imports
    for (final import in imports) {
      buffer.writeln("import '$import';");
    }
    buffer.writeln();
  }
  
  void _generateMocks(StringBuffer buffer, WidgetDependencyInfo info) {
    buffer.writeln('// Mock objects and setup');
    
    final mockSetups = <String>{};
    for (final dependency in info.dependencies) {
      final setup = dependency.generateMockSetup();
      if (setup.isNotEmpty) {
        mockSetups.add(setup);
      }
    }
    
    for (final setup in mockSetups) {
      buffer.writeln(setup);
      buffer.writeln();
    }
  }
  
  void _generateMainTest(StringBuffer buffer, WidgetDependencyInfo info) {
    buffer.writeln('void main() {');
    buffer.writeln("  group('${info.widgetType} Tests', () {");
    buffer.writeln();
    
    // Generate basic test
    _generateBasicTest(buffer, info);
    
    // Generate dependency-specific tests
    _generateDependencyTests(buffer, info);
    
    buffer.writeln('  });');
    buffer.writeln('}');
  }
  
  void _generateBasicTest(StringBuffer buffer, WidgetDependencyInfo info) {
    buffer.writeln("    testWidgets('renders ${info.widgetType} correctly', (tester) async {");
    buffer.writeln('      // Arrange');
    buffer.writeln('      const testWidget = ${info.widgetType}();');
    buffer.writeln();
    buffer.writeln('      // Act');
    buffer.writeln('      await tester.pumpWidget(');
    
    // Wrap with dependencies
    String wrappedWidget = 'testWidget';
    for (final dependency in info.dependencies.reversed) {
      wrappedWidget = dependency.wrapWidget(wrappedWidget, indentLevel: 4);
    }
    
    buffer.writeln('        $wrappedWidget,');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Assert');
    buffer.writeln('      expect(find.byType(${info.widgetType}), findsOneWidget);');
    buffer.writeln('    });');
    buffer.writeln();
  }
  
  void _generateDependencyTests(StringBuffer buffer, WidgetDependencyInfo info) {
    // Generate specific tests based on detected dependencies
    for (final dependency in info.dependencies) {
      if (dependency is ProviderDependency) {
        _generateProviderTest(buffer, info, dependency);
      } else if (dependency is BlocDependency) {
        _generateBlocTest(buffer, info, dependency);
      }
      // Add more specific test generators as needed
    }
  }
  
  void _generateProviderTest(StringBuffer buffer, WidgetDependencyInfo info, ProviderDependency dependency) {
    buffer.writeln("    testWidgets('handles ${dependency.providerType} provider changes', (tester) async {");
    buffer.writeln('      // Arrange');
    buffer.writeln('      final mock${dependency.providerType} = Mock${dependency.providerType}();');
    buffer.writeln('      const testWidget = ${info.widgetType}();');
    buffer.writeln();
    buffer.writeln('      // Act');
    buffer.writeln('      await tester.pumpWidget(');
    buffer.writeln('        ChangeNotifierProvider<${dependency.providerType}>(');
    buffer.writeln('          create: (_) => mock${dependency.providerType},');
    buffer.writeln('          child: MaterialApp(home: testWidget),');
    buffer.writeln('        ),');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Assert');
    buffer.writeln('      expect(find.byType(${info.widgetType}), findsOneWidget);');
    buffer.writeln('      // Add specific provider interaction tests here');
    buffer.writeln('    });');
    buffer.writeln();
  }
  
  void _generateBlocTest(StringBuffer buffer, WidgetDependencyInfo info, BlocDependency dependency) {
    buffer.writeln("    testWidgets('handles ${dependency.blocType} state changes', (tester) async {");
    buffer.writeln('      // Arrange');
    buffer.writeln('      final mock${dependency.blocType} = Mock${dependency.blocType}();');
    buffer.writeln('      const testWidget = ${info.widgetType}();');
    buffer.writeln();
    buffer.writeln('      // Act');
    buffer.writeln('      await tester.pumpWidget(');
    buffer.writeln('        BlocProvider<${dependency.blocType}>(');
    buffer.writeln('          create: (_) => mock${dependency.blocType},');
    buffer.writeln('          child: MaterialApp(home: testWidget),');
    buffer.writeln('        ),');
    buffer.writeln('      );');
    buffer.writeln();
    buffer.writeln('      // Assert');
    buffer.writeln('      expect(find.byType(${info.widgetType}), findsOneWidget);');
    buffer.writeln('      // Add specific BLoC interaction tests here');
    buffer.writeln('    });');
    buffer.writeln();
  }
}
```

## 🚀 Phase 2: UI Integration

### Step 6: Update Widget Tree Panel

```dart
// lib/ui/widgets/widget_tree_panel.dart - Add dependency analysis

Future<void> _selectNode(WidgetTreeNode node) async {
  setState(() {
    _selectedNode = node;
  });

  final appState = context.read<AppState>();
  final inspectorService = appState.inspectorService as InspectorService?;
  
  if (inspectorService != null && node.objectId != null) {
    try {
      await inspectorService.selectWidget(node.objectId!);
      
      // NEW: Analyze dependencies
      final dependencyService = DependencyAnalysisService(inspectorService);
      final dependencyInfo = await dependencyService.analyzeWidget(node.objectId!);
      
      if (mounted && dependencyInfo != null) {
        _showWidgetDetailsWithDependencies(node, dependencyInfo);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to analyze widget: $e')),
        );
      }
    }
  }
}

void _showWidgetDetailsWithDependencies(WidgetTreeNode node, WidgetDependencyInfo dependencyInfo) {
  showDialog(
    context: context,
    builder: (context) => WidgetDetailsDialog(
      node: node, 
      dependencyInfo: dependencyInfo,
    ),
  );
}
```

### Step 7: Enhanced Widget Details Dialog

```dart
// lib/ui/widgets/widget_details_dialog.dart

class WidgetDetailsDialog extends StatefulWidget {
  final WidgetTreeNode node;
  final WidgetDependencyInfo? dependencyInfo;

  const WidgetDetailsDialog({
    super.key, 
    required this.node,
    this.dependencyInfo,
  });

  @override
  State<WidgetDetailsDialog> createState() => _WidgetDetailsDialogState();
}

class _WidgetDetailsDialogState extends State<WidgetDetailsDialog> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String? _generatedTestCode;
  bool _isGeneratingTest = false;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.node.type ?? 'Widget Details'),
      content: SizedBox(
        width: 800,
        height: 600,
        child: Column(
          children: [
            TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: 'Properties'),
                Tab(text: 'Dependencies'),
                Tab(text: 'Test Code'),
              ],
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildPropertiesTab(),
                  _buildDependenciesTab(),
                  _buildTestCodeTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
        if (widget.dependencyInfo != null)
          ElevatedButton.icon(
            onPressed: _generateTestCode,
            icon: const Icon(Icons.code),
            label: const Text('Generate Test'),
          ),
      ],
    );
  }
  
  Widget _buildDependenciesTab() {
    if (widget.dependencyInfo == null) {
      return const Center(
        child: Text('No dependency information available'),
      );
    }
    
    final info = widget.dependencyInfo!;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Detected Dependencies (${info.dependencies.length})',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 16),
          
          if (info.dependencies.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.green),
                    SizedBox(width: 8),
                    Text('No external dependencies detected! This widget should be easy to test.'),
                  ],
                ),
              ),
            )
          else
            ...info.dependencies.map((dep) => Card(
              child: ListTile(
                leading: Icon(_getIconForDependency(dep)),
                title: Text(dep.name),
                subtitle: Text(dep.description),
                trailing: Chip(
                  label: Text(_getDependencyComplexity(dep)),
                  backgroundColor: _getComplexityColor(dep),
                ),
              ),
            )),
            
          const SizedBox(height: 24),
          Text(
            'Required Imports (${info.requiredImports.length})',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          
          ...info.requiredImports.map((import) => Card(
            child: ListTile(
              leading: const Icon(Icons.file_copy),
              title: Text(import),
              dense: true,
            ),
          )),
        ],
      ),
    );
  }
  
  Widget _buildTestCodeTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              ElevatedButton.icon(
                onPressed: _isGeneratingTest ? null : _generateTestCode,
                icon: _isGeneratingTest 
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.auto_fix_high),
                label: Text(_isGeneratingTest ? 'Generating...' : 'Generate Test Code'),
              ),
              const Spacer(),
              if (_generatedTestCode != null)
                ElevatedButton.icon(
                  onPressed: _copyTestCode,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy to Clipboard'),
                ),
            ],
          ),
        ),
        Expanded(
          child: _generatedTestCode == null
              ? const Center(
                  child: Text('Click "Generate Test Code" to create automated tests'),
                )
              : Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: SingleChildScrollView(
                    child: SelectableText(
                      _generatedTestCode!,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
        ),
      ],
    );
  }
  
  Future<void> _generateTestCode() async {
    if (widget.dependencyInfo == null) return;
    
    setState(() {
      _isGeneratingTest = true;
    });
    
    try {
      final generator = TestWrapperGenerator();
      final testCode = await generator.generateTestWrapper(widget.dependencyInfo!);
      
      setState(() {
        _generatedTestCode = testCode;
      });
      
      // Switch to test code tab
      _tabController.animateTo(2);
      
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to generate test code: $e')),
      );
    } finally {
      setState(() {
        _isGeneratingTest = false;
      });
    }
  }
  
  Future<void> _copyTestCode() async {
    if (_generatedTestCode != null) {
      await Clipboard.setData(ClipboardData(text: _generatedTestCode!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Test code copied to clipboard!')),
      );
    }
  }
  
  IconData _getIconForDependency(ContextDependency dep) {
    if (dep is ProviderDependency) return Icons.share;
    if (dep is ThemeDependency) return Icons.palette;
    if (dep is MediaQueryDependency) return Icons.phone_android;
    if (dep is NavigatorDependency) return Icons.navigation;
    return Icons.widgets;
  }
  
  String _getDependencyComplexity(ContextDependency dep) {
    if (dep is ProviderDependency || dep is BlocDependency) return 'Complex';
    if (dep is ThemeDependency || dep is MediaQueryDependency) return 'Simple';
    return 'Medium';
  }
  
  Color _getComplexityColor(ContextDependency dep) {
    final complexity = _getDependencyComplexity(dep);
    switch (complexity) {
      case 'Simple': return Colors.green.shade100;
      case 'Medium': return Colors.orange.shade100;
      case 'Complex': return Colors.red.shade100;
      default: return Colors.grey.shade100;
    }
  }
  
  // ... rest of the existing properties tab code
}
```

## 🚀 Phase 3: Advanced Features

### Step 8: Batch Test Generation

```dart
// lib/services/batch_test_generator.dart

class BatchTestGenerator {
  final DependencyAnalysisService _dependencyService;
  
  BatchTestGenerator(this._dependencyService);
  
  /// Generate tests for multiple widgets
  Future<Map<String, String>> generateTestsForWidgets(
    List<String> objectIds
  ) async {
    final results = <String, String>{};
    
    for (final objectId in objectIds) {
      final dependencyInfo = await _dependencyService.analyzeWidget(objectId);
      if (dependencyInfo != null) {
        final testCode = await _dependencyService.generateTestCode(dependencyInfo);
        results['${dependencyInfo.widgetType}_test.dart'] = testCode;
      }
    }
    
    return results;
  }
  
  /// Generate a test suite for an entire widget tree
  Future<String> generateTestSuiteForTree(WidgetTreeNode rootNode) async {
    final buffer = StringBuffer();
    
    buffer.writeln('// Generated test suite for widget tree');
    buffer.writeln('// Root: ${rootNode.description ?? rootNode.type}');
    buffer.writeln();
    
    await _generateTestsForNode(buffer, rootNode, 0);
    
    return buffer.toString();
  }
  
  Future<void> _generateTestsForNode(
    StringBuffer buffer, 
    WidgetTreeNode node, 
    int depth
  ) async {
    if (node.objectId != null) {
      final dependencyInfo = await _dependencyService.analyzeWidget(node.objectId!);
      if (dependencyInfo != null && dependencyInfo.dependencies.isNotEmpty) {
        buffer.writeln('// Test for ${node.description ?? node.type} (depth: $depth)');
        final testCode = await _dependencyService.generateTestCode(dependencyInfo);
        buffer.writeln(testCode);
        buffer.writeln();
      }
    }
    
    // Recursively process children
    for (final child in node.children) {
      await _generateTestsForNode(buffer, child, depth + 1);
    }
  }
}
```

### Step 9: Configuration and Settings

```dart
// lib/models/dependency_analysis_config.dart

class DependencyAnalysisConfig {
  final bool detectProviders;
  final bool detectBlocs;
  final bool detectInheritedWidgets;
  final bool generateMocks;
  final bool includeImports;
  final List<String> customDependencyPatterns;
  final TestFramework testFramework;
  
  const DependencyAnalysisConfig({
    this.detectProviders = true,
    this.detectBlocs = true,
    this.detectInheritedWidgets = true,
    this.generateMocks = true,
    this.includeImports = true,
    this.customDependencyPatterns = const [],
    this.testFramework = TestFramework.flutterTest,
  });
}

enum TestFramework {
  flutterTest,
  golden,
  integration,
}
```

## 🎯 Usage Examples

### Basic Usage
```dart
final dependencyService = DependencyAnalysisService(inspectorService);
final info = await dependencyService.analyzeWidget('widget_123');
final testCode = await dependencyService.generateTestCode(info);
```

### Advanced Usage
```dart
// Analyze entire widget tree
final batchGenerator = BatchTestGenerator(dependencyService);
final testSuite = await batchGenerator.generateTestSuiteForTree(rootWidget);

// Save to file
await File('test/generated_widget_tests.dart').writeAsString(testSuite);
```

## 🔧 Implementation Checklist

- [ ] **Phase 1: Foundation**
  - [ ] Extend InspectorService with source location support
  - [ ] Create DependencyAnalysisService
  - [ ] Implement SourceCodeAnalyzer
  - [ ] Create ContextDependency models
  - [ ] Build TestWrapperGenerator

- [ ] **Phase 2: UI Integration**
  - [ ] Update WidgetTreePanel with dependency analysis
  - [ ] Enhance WidgetDetailsDialog with dependency tabs
  - [ ] Add test code generation UI
  - [ ] Implement clipboard integration

- [ ] **Phase 3: Advanced Features**
  - [ ] Add batch test generation
  - [ ] Create configuration system
  - [ ] Implement custom dependency patterns
  - [ ] Add test framework selection
  - [ ] Build test file management

## 🚀 Getting Started

1. **Start with Phase 1** - implement the core dependency analysis
2. **Test with simple widgets** - ensure basic detection works
3. **Add UI integration** - make it user-friendly
4. **Expand dependency types** - add more sophisticated detection
5. **Add advanced features** - batch generation, configuration, etc.

This implementation provides a solid foundation for automatically analyzing widget dependencies and generating comprehensive test code, making Flutter widget testing much more accessible and automated.
