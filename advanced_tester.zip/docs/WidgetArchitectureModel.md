## A class that will represent the node and its properties. This class stores info on Widgets as well as their properties in realtime. This class intelligently decides if there is a change requierd to do.

className: AdvancedWidgetTreeNode
behaviour: Non final class #Can chage its values overtime

variables:
1. node: WidgetTreeNode #Actual node instance
2. properties: Map<String,dyanmic> #Detailed node properties
3. children: List<WidgetTreeNode> # List of children the node is holding, it can be one or many
4. hashCode: int #to check if anything is changed.
5. getDetailedTree: Future<Map<String,dynamic>>  #returns the detailed nested properties that will include its self and children's properties when _hasPopulated is true otherwise waits.
6. _hasPopulated: bool #indicates completion of property population
Functions
1. populateProperties() #this function populates the properties from node and children's node using getDetailedProperties of devtools server