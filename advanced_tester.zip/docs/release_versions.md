# V1
1. Run the app [ removed webview from homepage]
2. Get details of the widget
3. Inspect the widget
4. Generate a small test code

# V2
1. Generate summary of the app using AI/LLM
2. Generate test code using AI/LLM
2. Run test cases within the app

# V3
1. Show test coverage 
2. Show all tests for the project
3. Map tests to the widget and show test coverage in widget tree

# V4
1. Add dependency to the wiget tests.