# Family Backend

A Node.js backend service for the family app that provides authentication verification and notification services using Firebase.

## Features

- **Firebase Authentication**: Verifies Firebase auth tokens using Firebase Admin SDK
- **Notification Service**: Sends notifications when users are approved to join family groups
- **Secure API**: Rate limiting, CORS, and security headers
- **Input Validation**: Request validation using Joi

## Prerequisites

- Node.js (v16 or higher)
- Firebase project with Authentication enabled
- Firebase service account key

## Setup

1. **Clone and install dependencies:**
   ```bash
   npm install
   ```

2. **Firebase Setup:**
   - Go to your Firebase Console
   - Navigate to Project Settings > Service Accounts
   - Click "Generate New Private Key"
   - Save the JSON file as `firebase-service-account.json` in the project root

3. **Environment Configuration:**
   ```bash
   cp env.example .env
   ```
   Edit `.env` with your Firebase project details.

4. **Start the server:**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## API Endpoints

### Authentication Required
All endpoints require a valid Firebase auth token in the `Authorization` header:
```
Authorization: Bearer <firebase-id-token>
```

### Endpoints

#### POST /api/notifications/send-approval
Send notification when a user is approved to join a family group.

**Request Body:**
```json
{
  "userId": "user-id-to-notify",
  "familyGroupId": "family-group-id",
  "approvedBy": "approver-user-id",
  "familyGroupName": "Family Name"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Notification sent successfully",
  "data": {
    "notificationId": "notification-id"
  }
}
```

#### GET /api/health
Health check endpoint (no authentication required).

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

## Error Responses

### Authentication Error (401)
```json
{
  "error": "Authentication failed",
  "message": "Invalid or expired token"
}
```

### Validation Error (400)
```json
{
  "error": "Validation failed",
  "message": "Request validation error",
  "details": ["field errors"]
}
```

### Server Error (500)
```json
{
  "error": "Internal server error",
  "message": "Something went wrong"
}
```

## Project Structure

```
src/
├── app.js              # Main application file
├── config/
│   ├── firebase.js     # Firebase configuration
│   └── middleware.js   # Express middleware setup
├── middleware/
│   ├── auth.js         # Authentication middleware
│   └── validation.js   # Request validation middleware
├── routes/
│   ├── notifications.js # Notification routes
│   └── health.js       # Health check routes
├── services/
│   └── notification.js # Notification service
└── utils/
    └── response.js     # Response utilities
```

## Development

- **Run tests:** `npm test`
- **Development mode:** `npm run dev` (with auto-reload)
- **Production mode:** `npm start`

## Security Features

- Firebase Admin SDK for secure token verification
- Rate limiting to prevent abuse
- CORS configuration
- Security headers with Helmet
- Input validation and sanitization 