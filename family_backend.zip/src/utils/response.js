const sendSuccess = (res, data = null, message = 'Success', statusCode = 200) => {
  const response = {
    success: true,
    message,
    timestamp: new Date().toISOString()
  };

  if (data !== null) {
    response.data = data;
  }

  return res.status(statusCode).json(response);
};

const sendError = (res, message = 'Error occurred', statusCode = 500, error = null) => {
  const response = {
    success: false,
    error: error || 'Request failed',
    message,
    timestamp: new Date().toISOString()
  };

  return res.status(statusCode).json(response);
};

const sendValidationError = (res, details) => {
  return res.status(400).json({
    success: false,
    error: 'Validation failed',
    message: 'Request validation error',
    details,
    timestamp: new Date().toISOString()
  });
};

const sendAuthError = (res, message = 'Authentication failed') => {
  return res.status(401).json({
    success: false,
    error: 'Authentication failed',
    message,
    timestamp: new Date().toISOString()
  });
};

module.exports = {
  sendSuccess,
  sendError,
  sendValidationError,
  sendAuthError
}; 