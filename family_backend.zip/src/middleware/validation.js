const Joi = require('joi');

const validateRequest = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true
    });

    if (error) {
      const errorDetails = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));

      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        message: 'Request validation error',
        details: errorDetails
      });
    }

    // Replace req.body with validated data
    req.body = value;
    next();
  };
};

// Validation schemas
const notificationSchemas = {
  sendApproval: Joi.object({
    userId: Joi.string().required().messages({
      'string.empty': 'User ID is required',
      'any.required': 'User ID is required'
    }),
    familyGroupId: Joi.string().required().messages({
      'string.empty': 'Family group ID is required',
      'any.required': 'Family group ID is required'
    }),
    approvedBy: Joi.string().required().messages({
      'string.empty': 'Approver ID is required',
      'any.required': 'Approver ID is required'
    }),
    familyGroupName: Joi.string().required().min(1).max(100).messages({
      'string.empty': 'Family group name is required',
      'string.min': 'Family group name must be at least 1 character',
      'string.max': 'Family group name must be at most 100 characters',
      'any.required': 'Family group name is required'
    })
  })
};

module.exports = {
  validateRequest,
  notificationSchemas
}; 