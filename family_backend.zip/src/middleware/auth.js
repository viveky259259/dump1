const { getAuth } = require('../config/firebase');

const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        error: 'Authentication failed',
        message: 'Authorization header is required'
      });
    }

    const token = authHeader.split(' ')[1]; // Bearer <token>
    
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Authentication failed',
        message: 'Token is required'
      });
    }

    try {
      // Verify the Firebase ID token
      const decodedToken = await getAuth().verifyIdToken(token);
      
      // Add user info to request object
      req.user = {
        uid: decodedToken.uid,
        email: decodedToken.email,
        emailVerified: decodedToken.email_verified,
        name: decodedToken.name,
        picture: decodedToken.picture
      };
      
      console.log(`✅ Authenticated user: ${req.user.email} (${req.user.uid})`);
      next();
    } catch (firebaseError) {
      console.error('❌ Firebase token verification failed:', firebaseError.message);
      
      return res.status(401).json({
        success: false,
        error: 'Authentication failed',
        message: 'Invalid or expired token'
      });
    }
  } catch (error) {
    console.error('❌ Authentication middleware error:', error);
    return res.status(500).json({
      success: false,
      error: 'Authentication error',
      message: 'Internal server error during authentication'
    });
  }
};

module.exports = {
  authenticateToken
}; 