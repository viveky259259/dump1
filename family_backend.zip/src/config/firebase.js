const admin = require('firebase-admin');
const path = require('path');

let firebaseApp = null;

const setupFirebase = () => {
  try {
    // Check if Firebase is already initialized
    if (firebaseApp) {
      console.log('✅ Firebase already initialized');
      return firebaseApp;
    }

    // In test environment, don't try to initialize Firebase
    if (process.env.NODE_ENV === 'test') {
      console.log('🧪 Test environment detected - skipping Firebase initialization');
      return null;
    }

    // Path to service account key
    const serviceAccountPath = path.join(__dirname, '../../firebase-service-account.json');
    
    // Check if service account file exists
    const fs = require('fs');
    if (!fs.existsSync(serviceAccountPath)) {
      throw new Error('Firebase service account key not found. Please download it from Firebase Console and save as "firebase-service-account.json" in the project root.');
    }

    const serviceAccount = require(serviceAccountPath);

    // Initialize Firebase Admin SDK
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      projectId: process.env.FIREBASE_PROJECT_ID || serviceAccount.project_id
    });

    console.log('✅ Firebase Admin SDK initialized successfully');
    console.log(`📁 Project ID: ${firebaseApp.options.projectId}`);
    
    return firebaseApp;
  } catch (error) {
    console.error('❌ Firebase initialization failed:', error.message);
    throw error;
  }
};

const getFirebaseApp = () => {
  if (!firebaseApp) {
    if (process.env.NODE_ENV === 'test') {
      // Return a mock app for testing
      return {
        auth: () => ({
          verifyIdToken: () => Promise.resolve({ uid: 'test-user', email: 'test@example.com' })
        }),
        firestore: () => ({
          collection: () => ({
            add: () => Promise.resolve({ id: 'test-notification-id' }),
            doc: () => ({
              get: () => Promise.resolve({ exists: false, data: () => null }),
              update: () => Promise.resolve()
            }),
            where: () => ({
              orderBy: () => ({
                limit: () => ({
                  get: () => Promise.resolve({ docs: [] })
                })
              })
            })
          })
        })
      };
    }
    throw new Error('Firebase not initialized. Call setupFirebase() first.');
  }
  return firebaseApp;
};

const getAuth = () => {
  return getFirebaseApp().auth();
};

const getFirestore = () => {
  return getFirebaseApp().firestore();
};

module.exports = {
  setupFirebase,
  getFirebaseApp,
  getAuth,
  getFirestore
}; 