const express = require('express');
const { sendSuccess } = require('../utils/response');

const router = express.Router();

// GET /api/health
router.get('/', (req, res) => {
  const healthData = {
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0'
  };

  return sendSuccess(res, healthData, 'Service is healthy');
});

module.exports = router; 