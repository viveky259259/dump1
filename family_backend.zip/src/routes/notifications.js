const express = require('express');
const { authenticateToken } = require('../middleware/auth');
const { validateRequest, notificationSchemas } = require('../middleware/validation');
const notificationService = require('../services/notification');
const { sendSuccess, sendError } = require('../utils/response');

const router = express.Router();

// Apply authentication to all notification routes
router.use(authenticateToken);

// POST /api/notifications/send-approval
router.post('/send-approval', 
  validateRequest(notificationSchemas.sendApproval),
  async (req, res) => {
    try {
      const { userId, familyGroupId, approvedBy, familyGroupName } = req.body;
      
      console.log(`📧 Processing approval notification request from user: ${req.user.email}`);
      
      const notification = await notificationService.sendApprovalNotification(
        userId,
        familyGroupId,
        approvedBy,
        familyGroupName
      );

      return sendSuccess(res, {
        notificationId: notification.notificationId,
        message: notification.message,
        sentAt: notification.createdAt
      }, 'Notification sent successfully');

    } catch (error) {
      console.error('❌ Error in send-approval route:', error);
      return sendError(res, error.message, 500, 'Notification sending failed');
    }
  }
);

// GET /api/notifications/user/:userId
router.get('/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const limit = parseInt(req.query.limit) || 20;
    
    // Ensure user can only access their own notifications
    if (req.user.uid !== userId) {
      return sendError(res, 'Unauthorized access to notifications', 403, 'Forbidden');
    }

    const notifications = await notificationService.getNotificationsByUser(userId, limit);
    
    return sendSuccess(res, {
      notifications,
      count: notifications.length,
      userId
    }, 'Notifications retrieved successfully');

  } catch (error) {
    console.error('❌ Error getting user notifications:', error);
    return sendError(res, error.message, 500, 'Failed to retrieve notifications');
  }
});

// PUT /api/notifications/:notificationId/read
router.put('/:notificationId/read', async (req, res) => {
  try {
    const { notificationId } = req.params;
    
    // TODO: Add validation to ensure user owns this notification
    // For now, we'll just mark it as read
    
    await notificationService.markNotificationAsRead(notificationId, req.user.uid);
    
    return sendSuccess(res, {
      notificationId,
      status: 'read'
    }, 'Notification marked as read');

  } catch (error) {
    console.error('❌ Error marking notification as read:', error);
    return sendError(res, error.message, 500, 'Failed to mark notification as read');
  }
});

module.exports = router; 