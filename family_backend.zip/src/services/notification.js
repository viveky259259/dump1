const { getFirestore } = require('../config/firebase');

class NotificationService {
  constructor() {
    // Don't initialize db in constructor, do it lazily when needed
    this.db = null;
  }

  _getDb() {
    if (!this.db) {
      try {
        this.db = getFirestore();
      } catch (error) {
        console.error('❌ Failed to get Firestore instance:', error.message);
        throw new Error('Database not available');
      }
    }
    return this.db;
  }

  async sendApprovalNotification(userId, familyGroupId, approvedBy, familyGroupName) {
    try {
      console.log(`📧 Sending approval notification to user: ${userId}`);
      
      // Create notification data
      const notificationData = {
        userId,
        familyGroupId,
        approvedBy,
        familyGroupName,
        type: 'family_approval',
        title: 'Family Group Approval',
        message: `You have been approved to join the family group "${familyGroupName}"`,
        status: 'unread',
        createdAt: new Date(),
        readAt: null
      };

      // Store notification in Firestore
      const db = this._getDb();
      const notificationRef = await db.collection('notifications').add(notificationData);
      
      console.log(`✅ Notification stored with ID: ${notificationRef.id}`);

      // TODO: Implement actual push notification sending
      // This would typically use Firebase Cloud Messaging (FCM)
      // For now, we'll just log that we would send a push notification
      await this.sendPushNotification(userId, notificationData);

      return {
        notificationId: notificationRef.id,
        ...notificationData
      };
    } catch (error) {
      console.error('❌ Error sending approval notification:', error);
      throw new Error(`Failed to send approval notification: ${error.message}`);
    }
  }

  async sendPushNotification(userId, notificationData) {
    try {
      // TODO: Implement FCM push notification
      // This is a placeholder for the actual FCM implementation
      console.log(`📱 Would send push notification to user ${userId}:`, {
        title: notificationData.title,
        message: notificationData.message
      });

      // Example FCM implementation (commented out):
      /*
      const userTokens = await this.getUserFCMTokens(userId);
      
      if (userTokens.length > 0) {
        const message = {
          notification: {
            title: notificationData.title,
            body: notificationData.message
          },
          data: {
            type: notificationData.type,
            familyGroupId: notificationData.familyGroupId,
            notificationId: notificationData.notificationId
          },
          tokens: userTokens
        };

        const response = await getMessaging().sendMulticast(message);
        console.log(`📱 Push notification sent to ${response.successCount} devices`);
      }
      */

      return true;
    } catch (error) {
      console.error('❌ Error sending push notification:', error);
      // Don't throw error here as the main notification was already stored
      return false;
    }
  }

  async getUserFCMTokens(userId) {
    try {
      // Get user's FCM tokens from Firestore
      const db = this._getDb();
      const userDoc = await db.collection('users').doc(userId).get();
      
      if (userDoc.exists) {
        const userData = userDoc.data();
        return userData.fcmTokens || [];
      }
      
      return [];
    } catch (error) {
      console.error('❌ Error getting user FCM tokens:', error);
      return [];
    }
  }

  async getNotificationsByUser(userId, limit = 20) {
    try {
      const db = this._getDb();
      const snapshot = await db
        .collection('notifications')
        .where('userId', '==', userId)
        .orderBy('createdAt', 'desc')
        .limit(limit)
        .get();

      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
    } catch (error) {
      console.error('❌ Error getting user notifications:', error);
      throw new Error(`Failed to get notifications: ${error.message}`);
    }
  }

  async markNotificationAsRead(notificationId, userId) {
    try {
      const db = this._getDb();
      await db
        .collection('notifications')
        .doc(notificationId)
        .update({
          status: 'read',
          readAt: new Date()
        });

      console.log(`✅ Notification ${notificationId} marked as read`);
      return true;
    } catch (error) {
      console.error('❌ Error marking notification as read:', error);
      throw new Error(`Failed to mark notification as read: ${error.message}`);
    }
  }
}

module.exports = new NotificationService(); 