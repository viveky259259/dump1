const axios = require('axios');

// Example usage of the Family Backend API
const API_BASE_URL = 'http://localhost:3000/api';

// Example Firebase ID token (you would get this from your frontend)
const EXAMPLE_FIREBASE_TOKEN = 'your-firebase-id-token-here';

// Configure axios with default headers
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${EXAMPLE_FIREBASE_TOKEN}`
  }
});

async function testHealthEndpoint() {
  try {
    console.log('🏥 Testing health endpoint...');
    const response = await axios.get(`${API_BASE_URL}/health`);
    console.log('✅ Health check response:', response.data);
  } catch (error) {
    console.error('❌ Health check failed:', error.response?.data || error.message);
  }
}

async function testSendApprovalNotification() {
  try {
    console.log('📧 Testing send approval notification...');
    
    const notificationData = {
      userId: 'user123',
      familyGroupId: 'family456',
      approvedBy: 'admin789',
      familyGroupName: 'Smith Family'
    };

    const response = await api.post('/notifications/send-approval', notificationData);
    console.log('✅ Notification sent:', response.data);
  } catch (error) {
    console.error('❌ Send notification failed:', error.response?.data || error.message);
  }
}

async function testGetUserNotifications() {
  try {
    console.log('📬 Testing get user notifications...');
    
    const userId = 'user123';
    const response = await api.get(`/notifications/user/${userId}`);
    console.log('✅ User notifications:', response.data);
  } catch (error) {
    console.error('❌ Get notifications failed:', error.response?.data || error.message);
  }
}

async function testMarkNotificationAsRead() {
  try {
    console.log('✅ Testing mark notification as read...');
    
    const notificationId = 'notification123';
    const response = await api.put(`/notifications/${notificationId}/read`);
    console.log('✅ Notification marked as read:', response.data);
  } catch (error) {
    console.error('❌ Mark as read failed:', error.response?.data || error.message);
  }
}

async function runExamples() {
  console.log('🚀 Running Family Backend API Examples\n');
  
  await testHealthEndpoint();
  console.log('');
  
  await testSendApprovalNotification();
  console.log('');
  
  await testGetUserNotifications();
  console.log('');
  
  await testMarkNotificationAsRead();
  console.log('');
  
  console.log('✨ Examples completed!');
}

// Run examples if this file is executed directly
if (require.main === module) {
  runExamples().catch(console.error);
}

module.exports = {
  testHealthEndpoint,
  testSendApprovalNotification,
  testGetUserNotifications,
  testMarkNotificationAsRead
}; 