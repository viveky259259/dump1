# Quick Setup Guide

## Prerequisites
- Node.js (v16 or higher)
- Firebase project with Authentication enabled

## 1. Install Dependencies
```bash
npm install
```

## 2. Firebase Setup
1. Go to your [Firebase Console](https://console.firebase.google.com/)
2. Select your project
3. Go to **Project Settings** > **Service Accounts**
4. Click **"Generate New Private Key"**
5. Save the JSON file as `firebase-service-account.json` in the project root

## 3. Environment Configuration
```bash
cp env.example .env
```
Edit `.env` with your Firebase project details:
```env
PORT=3000
NODE_ENV=development
FIREBASE_PROJECT_ID=your-firebase-project-id
```

## 4. Start the Server
```bash
# Development mode (with auto-reload)
npm run dev

# Production mode
npm start
```

## 5. Test the API
The server will be running at `http://localhost:3000`

### Health Check (No Auth Required)
```bash
curl http://localhost:3000/api/health
```

### Send Notification (Auth Required)
```bash
curl -X POST http://localhost:3000/api/notifications/send-approval \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_FIREBASE_ID_TOKEN" \
  -d '{
    "userId": "user123",
    "familyGroupId": "family456", 
    "approvedBy": "admin789",
    "familyGroupName": "Smith Family"
  }'
```

## 6. Run Tests
```bash
npm test
```

## 7. Run Examples
```bash
npm run example
```

## Troubleshooting

### Firebase Service Account Error
If you see "Firebase service account key not found":
- Make sure you downloaded the service account JSON from Firebase Console
- Save it as `firebase-service-account.json` in the project root
- Verify the file path is correct

### Port Already in Use
If port 3000 is busy, change the PORT in your `.env` file:
```env
PORT=3001
```

### Authentication Errors
- Ensure your Firebase project has Authentication enabled
- Verify the Firebase ID token is valid and not expired
- Check that the service account has the necessary permissions 