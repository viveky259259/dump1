const request = require('supertest');

// Mock the Firebase setup before importing the app
jest.mock('../src/config/firebase', () => ({
  setupFirebase: jest.fn(() => null),
  getFirebaseApp: jest.fn(() => ({
    auth: () => ({
      verifyIdToken: () => Promise.resolve({ 
        uid: 'test-user', 
        email: 'test@example.com',
        email_verified: true,
        name: 'Test User',
        picture: 'https://example.com/avatar.jpg'
      })
    }),
    firestore: () => ({
      collection: () => ({
        add: () => Promise.resolve({ id: 'test-notification-id' }),
        doc: () => ({
          get: () => Promise.resolve({ exists: false, data: () => null }),
          update: () => Promise.resolve()
        }),
        where: () => ({
          orderBy: () => ({
            limit: () => ({
              get: () => Promise.resolve({ docs: [] })
            })
          })
        })
      })
    })
  })),
  getAuth: jest.fn(() => ({
    verifyIdToken: () => Promise.resolve({ 
      uid: 'test-user', 
      email: 'test@example.com',
      email_verified: true,
      name: 'Test User',
      picture: 'https://example.com/avatar.jpg'
    })
  })),
  getFirestore: jest.fn(() => ({
    collection: () => ({
      add: () => Promise.resolve({ id: 'test-notification-id' }),
      doc: () => ({
        get: () => Promise.resolve({ exists: false, data: () => null }),
        update: () => Promise.resolve()
      }),
      where: () => ({
        orderBy: () => ({
          limit: () => ({
            get: () => Promise.resolve({ docs: [] })
          })
        })
      })
    })
  }))
}));

const app = require('../src/app');

describe('Notification Endpoints', () => {
  const mockToken = 'valid-firebase-token';

  describe('POST /api/notifications/send-approval', () => {
    test('should send approval notification successfully', async () => {
      const notificationData = {
        userId: 'user123',
        familyGroupId: 'family456',
        approvedBy: 'admin789',
        familyGroupName: 'Smith Family'
      };

      const response = await request(app)
        .post('/api/notifications/send-approval')
        .set('Authorization', `Bearer ${mockToken}`)
        .send(notificationData)
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('message', 'Notification sent successfully');
      expect(response.body.data).toHaveProperty('notificationId');
      expect(response.body.data).toHaveProperty('message');
      expect(response.body.data).toHaveProperty('sentAt');
    });

    test('should return 400 for invalid request data', async () => {
      const invalidData = {
        userId: '', // Invalid: empty string
        familyGroupId: 'family456',
        // Missing required fields
      };

      const response = await request(app)
        .post('/api/notifications/send-approval')
        .set('Authorization', `Bearer ${mockToken}`)
        .send(invalidData)
        .expect(400);

      expect(response.body).toHaveProperty('success', false);
      expect(response.body).toHaveProperty('error', 'Validation failed');
      expect(response.body).toHaveProperty('details');
    });

    test('should return 401 without authorization header', async () => {
      const notificationData = {
        userId: 'user123',
        familyGroupId: 'family456',
        approvedBy: 'admin789',
        familyGroupName: 'Smith Family'
      };

      const response = await request(app)
        .post('/api/notifications/send-approval')
        .send(notificationData)
        .expect(401);

      expect(response.body).toHaveProperty('success', false);
      expect(response.body).toHaveProperty('error', 'Authentication failed');
    });
  });

  describe('GET /api/notifications/user/:userId', () => {
    test('should get user notifications successfully', async () => {
      const userId = 'test-user';

      const response = await request(app)
        .get(`/api/notifications/user/${userId}`)
        .set('Authorization', `Bearer ${mockToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('message', 'Notifications retrieved successfully');
      expect(response.body.data).toHaveProperty('notifications');
      expect(response.body.data).toHaveProperty('count');
      expect(response.body.data).toHaveProperty('userId');
    });
  });
}); 