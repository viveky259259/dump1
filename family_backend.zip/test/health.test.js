const request = require('supertest');

// Mock the Firebase setup before importing the app
jest.mock('../src/config/firebase', () => ({
  setupFirebase: jest.fn(() => null),
  getFirebaseApp: jest.fn(() => ({
    auth: () => ({
      verifyIdToken: () => Promise.resolve({ uid: 'test-user', email: 'test@example.com' })
    }),
    firestore: () => ({
      collection: () => ({
        add: () => Promise.resolve({ id: 'test-notification-id' }),
        doc: () => ({
          get: () => Promise.resolve({ exists: false, data: () => null }),
          update: () => Promise.resolve()
        }),
        where: () => ({
          orderBy: () => ({
            limit: () => ({
              get: () => Promise.resolve({ docs: [] })
            })
          })
        })
      })
    })
  })),
  getAuth: jest.fn(() => ({
    verifyIdToken: () => Promise.resolve({ uid: 'test-user', email: 'test@example.com' })
  })),
  getFirestore: jest.fn(() => ({
    collection: () => ({
      add: () => Promise.resolve({ id: 'test-notification-id' }),
      doc: () => ({
        get: () => Promise.resolve({ exists: false, data: () => null }),
        update: () => Promise.resolve()
      }),
      where: () => ({
        orderBy: () => ({
          limit: () => ({
            get: () => Promise.resolve({ docs: [] })
          })
        })
      })
    })
  }))
}));

const app = require('../src/app');

describe('Health Check Endpoint', () => {
  test('GET /api/health should return 200 and health status', async () => {
    const response = await request(app)
      .get('/api/health')
      .expect(200);

    expect(response.body).toHaveProperty('success', true);
    expect(response.body).toHaveProperty('message', 'Service is healthy');
    expect(response.body.data).toHaveProperty('status', 'ok');
    expect(response.body.data).toHaveProperty('timestamp');
    expect(response.body.data).toHaveProperty('uptime');
    expect(response.body.data).toHaveProperty('environment');
    expect(response.body.data).toHaveProperty('version');
  });

  test('Health endpoint should return correct environment', async () => {
    const response = await request(app)
      .get('/api/health')
      .expect(200);

    expect(response.body.data.environment).toBe('test');
  });
}); 