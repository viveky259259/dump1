// Test setup file
process.env.NODE_ENV = 'test';
process.env.PORT = 3001;

// Mock Firebase Admin SDK
jest.mock('firebase-admin', () => ({
  initializeApp: jest.fn(() => ({
    auth: jest.fn(() => ({
      verifyIdToken: jest.fn(() => Promise.resolve({
        uid: 'test-user-id',
        email: 'test@example.com',
        email_verified: true,
        name: 'Test User',
        picture: 'https://example.com/avatar.jpg'
      }))
    })),
    firestore: jest.fn(() => ({
      collection: jest.fn(() => ({
        add: jest.fn(() => Promise.resolve({ id: 'test-notification-id' })),
        doc: jest.fn(() => ({
          get: jest.fn(() => Promise.resolve({ 
            exists: false, 
            data: () => null 
          })),
          update: jest.fn(() => Promise.resolve())
        })),
        where: jest.fn(() => ({
          orderBy: jest.fn(() => ({
            limit: jest.fn(() => ({
              get: jest.fn(() => Promise.resolve({ docs: [] }))
            }))
          }))
        }))
      }))
    }))
  })),
  credential: {
    cert: jest.fn()
  }
}));

// Mock fs module to avoid file system issues in tests
jest.mock('fs', () => ({
  existsSync: jest.fn(() => false)
})); 