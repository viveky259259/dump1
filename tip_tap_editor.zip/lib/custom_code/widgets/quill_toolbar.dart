// Automatic FlutterFlow imports
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class QuillToolbar extends StatefulWidget {
  const QuillToolbar({
    super.key,
    required this.onAction,
    this.isBold = false,
    this.isItalic = false,
    this.isUnderline = false,
    this.isStrike = false,
    this.isBlockquote = false,
    this.currentHeader = 0,
    this.currentList = 'none',
    this.currentAlign = 'left',
  });

  final Function(String action, Map<String, dynamic>? data) onAction;
  final bool isBold;
  final bool isItalic;
  final bool isUnderline;
  final bool isStrike;
  final bool isBlockquote;
  final int currentHeader;
  final String currentList;
  final String currentAlign;

  @override
  State<QuillToolbar> createState() => _QuillToolbarState();
}

class _QuillToolbarState extends State<QuillToolbar> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[100],
        border: Border(left: BorderSide(color: Colors.grey[300]!, width: 1),right: BorderSide(color: Colors.grey[300]!, width: 1),top: BorderSide(color: Colors.grey[300]!, width: 1)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            // Text formatting buttons
            _buildButtonGroup([
              _buildToggleButton(
                icon: Icons.format_bold,
                isActive: widget.isBold,
                onPressed: () => widget.onAction('format', {'format': 'bold'}),
                tooltip: 'Bold',
              ),
              _buildToggleButton(
                icon: Icons.format_italic,
                isActive: widget.isItalic,
                onPressed: () =>
                    widget.onAction('format', {'format': 'italic'}),
                tooltip: 'Italic',
              ),
              _buildToggleButton(
                icon: Icons.format_underlined,
                isActive: widget.isUnderline,
                onPressed: () =>
                    widget.onAction('format', {'format': 'underline'}),
                tooltip: 'Underline',
              ),
              _buildToggleButton(
                icon: Icons.format_strikethrough,
                isActive: widget.isStrike,
                onPressed: () =>
                    widget.onAction('format', {'format': 'strike'}),
                tooltip: 'Strikethrough',
              ),
            ]),

            _buildDivider(),

            // Font size controls
            _buildButtonGroup([
              _buildButton(
                icon: Icons.text_decrease,
                onPressed: () => widget.onAction('format', {'format': 'fontSize', 'value': 'decrease'}),
                tooltip: 'Decrease Font Size (-A)',
              ),
              _buildButton(
                icon: Icons.text_increase,
                onPressed: () => widget.onAction('format', {'format': 'fontSize', 'value': 'increase'}),
                tooltip: 'Increase Font Size (+A)',
              ),
            ]),

            _buildDivider(),

            // Lists
            _buildButtonGroup([
              _buildToggleButton(
                icon: Icons.format_list_bulleted,
                isActive: widget.currentList == 'bullet',
                onPressed: () => widget
                    .onAction('format', {'format': 'list', 'value': 'bullet'}),
                tooltip: 'Bullet List',
              ),
              _buildToggleButton(
                icon: Icons.format_list_numbered,
                isActive: widget.currentList == 'ordered',
                onPressed: () => widget
                    .onAction('format', {'format': 'orderedList', 'value': 'ordered'}),
                tooltip: 'Numbered List',
              ),
            
            ]),

           

            _buildDivider(),

            // Block formatting
            _buildButtonGroup([
              _buildToggleButton(
                icon: Icons.format_quote,
                isActive: widget.isBlockquote,
                onPressed: () =>
                    widget.onAction('format', {'format': 'blockquote'}),
                tooltip: 'Quote',
              ),
             
            ]),

            _buildDivider(),

            // Table operations
            _buildButtonGroup([
              _buildButton(
                icon: Icons.table_chart,
                onPressed: () =>
                    widget.onAction('insertTable', {'rows': 3, 'cols': 3}),
                tooltip: 'Insert Table',
              ),
            ]),

            _buildDivider(),

            // Clean formatting
            _buildButton(
              icon: Icons.format_clear,
              onPressed: () => widget.onAction('format', {'format': 'clean'}),
              tooltip: 'Clear Formatting',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButtonGroup(List<Widget> buttons) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: buttons,
    );
  }

  Widget _buildToggleButton({
    required IconData icon,
    required bool isActive,
    required VoidCallback onPressed,
    required String tooltip,
  }) {
    return Tooltip(
      message: tooltip,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        child: IconButton(
          icon: Icon(icon),
          onPressed: onPressed,
          color: isActive ? Colors.blue : Colors.grey[700],
          style: IconButton.styleFrom(
            backgroundColor:
                isActive ? Colors.blue.withOpacity(0.1) : Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildButton({
    required IconData icon,
    required VoidCallback onPressed,
    required String tooltip,
  }) {
    return Tooltip(
      message: tooltip,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        child: IconButton(
          icon: Icon(icon),
          onPressed: onPressed,
          color: Colors.grey[700],
          style: IconButton.styleFrom(
            backgroundColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdownButton({
    required dynamic value,
    required List<DropdownMenuItem> items,
    required Function(dynamic) onChanged,
    required String tooltip,
  }) {
    return Tooltip(
      message: tooltip,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        child: DropdownButtonHideUnderline(
          child: DropdownButton(
            value: value,
            items: items,
            onChanged: onChanged,
            style: TextStyle(
              color: Colors.grey[700],
              fontSize: 14,
            ),
            icon: Icon(Icons.arrow_drop_down, color: Colors.grey[700]),
          ),
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      height: 30,
      width: 1,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      color: Colors.grey[300],
    );
  }
}
