// Automatic FlutterFlow imports
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:html' as html;
import 'dart:js' as js;
import 'dart:ui_web' as ui;
import 'dart:convert';
import 'quill_toolbar.dart';

class QuillEditor extends StatefulWidget {
  const QuillEditor(
      {super.key,
      this.width,
      this.height,
      this.onMessageReceived,
      this.realOnly = false,
      this.htmlString});

  final double? width;
  final double? height;
  final Future Function(String? message)? onMessageReceived;
  final bool? realOnly;
  final String? htmlString;

  @override
  State<QuillEditor> createState() => _QuillEditorState();
}

class _QuillEditorState extends State<QuillEditor> {
  html.IFrameElement? _iframe;
  static int _viewIdCounter = 0;
  late int _viewId;

  // Toolbar state
  bool _isBold = false;
  bool _isItalic = false;
  bool _isUnderline = false;
  bool _isStrike = false;
  bool _isBlockquote = false;
  int _currentHeader = 0;
  String _currentList = 'none';
  String _currentAlign = 'left';

  @override
  void initState() {
    super.initState();
    _viewId = ++_viewIdCounter;
    _registerViewFactory();
  }

  void _registerViewFactory() {
    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory('inline-html-$_viewId',
        (int viewId) {
      _iframe = html.IFrameElement()
        ..src = '/test_tiptap.html'
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%';

      // NOTE: Iframe scroll blocking limitation
      // Iframes in browsers capture ALL pointer events when the mouse is over them,
      // which means parent page scroll is blocked. This is a browser security feature.
      // 
      // Unfortunately, there is NO complete workaround for this limitation. Attempts to
      // programmatically scroll the parent page from inside the iframe do not work reliably
      // with Flutter web's scrolling mechanism.
      //
      // Practical solutions:
      // 1. Design your page so the editor doesn't require external scrolling
      // 2. Users can move their mouse outside the editor area to scroll the page
      // 3. Make the editor smaller or adjust page layout to fit in viewport
      // 4. Accept this as expected behavior for embedded HTML content in Flutter web

      // Listen for messages from the iframe
      html.window.addEventListener('message', (event) {
        final messageEvent = event as html.MessageEvent;
        
        // Security: Verify origin to prevent XSS attacks
        // Only accept messages from the same origin (iframe)
        final expectedOrigin = Uri.base.origin;
        if (messageEvent.origin != expectedOrigin) {
          print('Rejected message from unauthorized origin: ${messageEvent.origin}');
          return;
        }

        // Handle scroll request from iframe
        if (messageEvent.data != null && 
            messageEvent.data is Map &&
            (messageEvent.data as Map)['type'] == 'scroll-request') {
          final deltaY = (messageEvent.data as Map)['deltaY'] as num?;
          print('Flutter: Received scroll request, deltaY: $deltaY');
          if (deltaY != null) {
            // Create and dispatch a wheel event to trigger Flutter's scrolling
            final scrollAmount = deltaY * 0.8;
            // Try to find and scroll the flutter app's body or main scrollable element
            js.context.callMethod('eval', [
              '''
              (function(delta) {
                // Try scrolling different elements
                var scrollable = document.body;
                if (scrollable && scrollable.scrollTop !== undefined) {
                  scrollable.scrollTop += delta;
                }
                // Also try the window scroll
                window.scrollBy(0, delta);
              })($scrollAmount);
              '''.replaceAll('\$scrollAmount', scrollAmount.toString())
            ]);
            print('Flutter: Attempted to scroll');
          }
          return;
        }
        
        // Handle overflow change message from iframe
        if (messageEvent.data != null && 
            messageEvent.data is Map &&
            (messageEvent.data as Map)['type'] == 'editor-overflow-changed') {
          // Store overflow state but can't toggle pointer-events as it breaks editing
          return;
        }

        // Only process messages from the iframe
        if (messageEvent.data != null) {
          try {
            // Check if data is already a Map (from Dart) or needs to be parsed
            Map<String, dynamic> data;
            if (messageEvent.data is Map) {
              data = Map<String, dynamic>.from(messageEvent.data as Map);
            } else {
              data = jsonDecode(messageEvent.data.toString());
            }

            // Handle different message types
            final messageType = data['type']?.toString();
            print('Message type: $messageType');

            // Safely check content type and value
            final content = data["content"];
            if (content != null) {
              print('Data content type: ${content.runtimeType}');
              // Only print content if it's a simple type
              if (content is String || content is num || content is bool) {
                print('Data content value: $content');
              } else {
                print('Data content is complex object');
              }
            }

            if (messageType == 'selectionChange') {
              _updateToolbarStateFromTiptap(data);
            } else if (messageType == 'contentChange') {
              final contentString = content?.toString() ?? '';
              print('Content string: $contentString');
              widget.onMessageReceived?.call(contentString);
            } else if (messageType == 'response') {
              // Handle responses from Tiptap
              final message = data['message'];
              final messageString = message?.toString() ?? 'No message';
              print('Tiptap response: $messageString');
            } else {
              final contentString = content?.toString() ?? '';
              print('Fallback content string: $contentString');
              widget.onMessageReceived?.call(contentString);
            }
          } catch (e) {
            // If not JSON, treat as plain string
            widget.onMessageReceived?.call(messageEvent.data.toString());
          }
        }
      });

      return _iframe!;
    });
  }

  void sendMessageToIframe(String message) {
    final targetOrigin = _getIframeOrigin();
    _iframe?.contentWindow?.postMessage(message, targetOrigin);
  }

  void sendJsonToIframe(Map<String, dynamic> data) {
    data['source'] = 'flutter';
    data['type'] = 'command';
    final jsonString = jsonEncode(data);
    final targetOrigin = _getIframeOrigin();
    _iframe?.contentWindow?.postMessage(jsonString, targetOrigin);
  }

  String _getIframeOrigin() {
    // Since the iframe loads from the same origin, use Uri.base.origin
    // For production, you could specify: return 'https://yourdomain.com';
    print('Iframe origin: ${Uri.base.origin}');
    return Uri.base.origin; // Gets the origin (protocol + host + port) of the current page
  }

  void _updateToolbarStateFromTiptap(Map<String, dynamic> data) {
    print('Updating toolbar state from Tiptap');

    // Safely extract values, handling LinkedMaps
    final selectedText = data['selectedText']?.toString() ?? '';
    final isInTable = data['isInTable'] == true;

    print('Selected text: $selectedText');
    print('Is in table: $isInTable');

    setState(() {
      // Update all states from Tiptap
      _isBold = data['isBold'] == true;
      _isItalic = data['isItalic'] == true;
      _isUnderline = data['isUnderline'] == true;
      _isStrike = data['isStrike'] == true;
      _isBlockquote = data['isBlockquote'] == true;
      
      // Update header level
      final headerValue = data['currentHeader'];
      if (headerValue is num) {
        _currentHeader = headerValue.toInt();
      } else {
        _currentHeader = 0;
      }
      
      // Update list type
      final listValue = data['currentList']?.toString();
      _currentList = listValue ?? 'none';
      
      // Alignment is not available from Tiptap yet, keep default
      _currentAlign = 'left';
      
      print('Toolbar state updated:');
      print('  Bold: $_isBold');
      print('  Italic: $_isItalic');
      print('  Underline: $_isUnderline');
      print('  Strike: $_isStrike');
      print('  Blockquote: $_isBlockquote');
      print('  Header: $_currentHeader');
      print('  List: $_currentList');
    });
  }

  void _handleToolbarAction(String action, Map<String, dynamic>? data) {
    switch (action) {
      case 'format':
        if (data != null) {
          final format = data['format'] as String;
          final value = data['value'];

          // Send format command to iframe
          sendJsonToIframe({
            'action': 'format',
            'format': format,
            'value': value,
          });
        }
        break;

      case 'insertTable':
        if (data != null) {
          sendJsonToIframe({
            'action': 'insertTable',
            'rows': data['rows'] ?? 3,
            'cols': data['cols'] ?? 3,
          });
        }
        break;

      default:
        sendJsonToIframe({
          'action': action,
          ...?data,
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    print('widget.realOnly: ${widget.realOnly}');
    if (widget.realOnly == true) {
      return ViewOnlyQuillEditor(message: widget.htmlString ?? '');
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          QuillToolbar(
            onAction: _handleToolbarAction,
            isBold: _isBold,
            isItalic: _isItalic,
            isUnderline: _isUnderline,
            isStrike: _isStrike,
            isBlockquote: _isBlockquote,
            currentHeader: _currentHeader,
            currentList: _currentList,
            currentAlign: _currentAlign,
          ),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!, width: 1),
            ),
            height: 320,
            width: 848,
            child: HtmlElementView(viewType: 'inline-html-$_viewId'),
          ),
          
        ],
      );
    }
  }
}

class ViewOnlyQuillEditor extends StatefulWidget {
  const ViewOnlyQuillEditor({super.key, required this.message});
  final String message;

  @override
  State<ViewOnlyQuillEditor> createState() => _ViewOnlyQuillEditorState();
}

class _ViewOnlyQuillEditorState extends State<ViewOnlyQuillEditor> {
  html.IFrameElement? _iframe;
  static int _viewIdCounter = 0;
  late int _viewId;

  @override
  void initState() {
    super.initState();
    _viewId = ++_viewIdCounter;
    _registerViewFactory();
  }

  void _registerViewFactory() {
    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory('viewOnly-html-$_viewId',
        (int viewId) {
      _iframe = html.IFrameElement()
        ..src = '/delta_renderer.html'
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%';

      // Listen for messages from the iframe
      // html.window.addEventListener('message', (event) {
      //   final messageEvent = event as html.MessageEvent;
      //   print('${messageEvent.source == _iframe?.contentWindow}');
      //   // Only process messages from the iframe
      //   if (messageEvent.data != null) {
      //     print('messageEvent.data: ${messageEvent.data}');
      //     try {
      //       final data = jsonDecode(messageEvent.data);
      //       widget.onMessageReceived?.call(data);
      //     } catch (e) {
      //       // If not JSON, treat as plain string
      //       widget.onMessageReceived?.call(messageEvent.data);
      //     }
      //   }
      // });

      return _iframe!;
    });
  }

  void sendMessageToIframe(String message) {
    final targetOrigin = _getIframeOrigin();
    _iframe?.contentWindow?.postMessage(message, targetOrigin);
  }

  void sendJsonToIframe(Map<String, dynamic> data) {
    data['source'] = 'flutter';
    data['type'] = 'command';
    final jsonString = jsonEncode(data);
    // Use the iframe's origin for security (same origin in this case)
    final targetOrigin = _getIframeOrigin();
    _iframe?.contentWindow?.postMessage(jsonString, targetOrigin);
  }

  String _getIframeOrigin() {
    // Since the iframe loads from the same origin, use Uri.base.origin
    // For production, you could specify: return 'https://yourdomain.com';
    return Uri.base.origin; // Gets the origin (protocol + host + port) of the current page
  }

  @override
  Widget build(BuildContext context) {
    sendMessageToIframe(widget.message);
    print('Iframe origin: ${Uri.base.origin}');
    return HtmlElementView(viewType: 'viewOnly-html-$_viewId');
  }
}

/// Helper widget to fix iframe scroll blocking issue
/// Uses a Stack with GestureDetector to detect scroll attempts
class _IframeScrollFix extends StatefulWidget {
  final Widget child;

  const _IframeScrollFix({
    required this.child,
  });

  @override
  State<_IframeScrollFix> createState() => _IframeScrollFixState();
}

class _IframeScrollFixState extends State<_IframeScrollFix> {
  bool _hasInternalOverflow = false;

  @override
  void initState() {
    super.initState();
    // Listen for overflow messages from iframe
    html.window.addEventListener('message', _handleMessage);
  }

  @override
  void dispose() {
    html.window.removeEventListener('message', _handleMessage);
    super.dispose();
  }

  void _handleMessage(html.Event event) {
    final messageEvent = event as html.MessageEvent;
    if (messageEvent.data != null &&
        messageEvent.data is Map &&
        (messageEvent.data as Map)['type'] == 'editor-overflow-changed') {
      setState(() {
        _hasInternalOverflow = (messageEvent.data as Map)['hasOverflow'] ?? true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Use Stack to overlay a GestureDetector that can capture scroll
    // Note: This is a partial workaround - the iframe will still block events
    // when actively scrolling inside it
    return Stack(
      children: [
        widget.child,
        // Overlay that tries to capture wheel events
        if (!_hasInternalOverflow)
          Positioned.fill(
            child: MouseRegion(
              opaque: false,
              child: GestureDetector(
                onPanUpdate: (_) {
                  // Try to detect scroll gestures
                  // Unfortunately, this won't work because iframe captures events first
                },
                behavior: HitTestBehavior.translucent,
                child: Container(color: Colors.transparent),
              ),
            ),
          ),
      ],
    );
  }
}
