# Tiptap Editor with Flutter Integration Guide

> **A comprehensive guide to integrating a headless Tiptap editor in Flutter Web with bidirectional communication**

---

https://tiptap.dev/  

## 📋 Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Tiptap Editor - Headless Approach](#tiptap-editor---headless-approach)
4. [Flutter Toolbar](#flutter-toolbar)
6. [HTML File Setup](#html-file-setup)
7. [Flutter Widget Implementation](#flutter-widget-implementation)
8. [Usage Examples](#usage-examples)
9. [Advanced Features](#advanced-features)

---

## 🎯 Overview

This implementation combines **Tiptap** (a headless rich text editor framework) with **Flutter Web** to create a powerful, customizable rich text editor. The solution uses:

- **Tiptap Editor** - Headless editor framework rendered in an HTML file
- **Flutter Toolbar** - Native Flutter UI for editor controls
- **Bidirectional Communication** - PostMessage API for seamless data exchange
- **Iframe Embedding** - Flutter's `HtmlElementView` to embed the editor

---

## 🏗️ Architecture

```
┌────────────────────────────────────────────────────────────┐
│                    Flutter Application                     │
│                                                            │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           Toolbar (Flutter Widget)                   │  │
│  │  [Bold] [Italic] [Header] [Table] [List] ...         │  │
│  └──────────────────────────────────────────────────────┘  │
│                        ↓ ↑ postMessage                     │
│  ┌──────────────────────────────────────────────────────┐  │
│  │       FlutterEditor (Flutter Widget with Iframe)     │  │
│  │  ┌──────────────────────────────────────────────┐    │  │
│  │  │         IFrameElement                        │    │  │
│  │  │  ┌────────────────────────────────────────┐  │    │  │
│  │  │  │    tiptap.html                         │  │    │  │
│  │  │  │    (Tiptapestra Editor Instance)       │  │    │  │
│  │  │  └────────────────────────────────────────┘  │    │  │
│  │  └──────────────────────────────────────────────┘    │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Key Components

1. **Flutter Toolbar** (`quill_toolbar.dart`)
   - Native Flutter UI controls
   - Sends commands to the editor via postMessage

2. **Flutter Editor Widget** (`quill_editor.dart`)
   - Wraps the HTML file in an iframe
   - Handles bidirectional communication
   - Manages editor lifecycle

3. **Tiptap HTML File** (`test_tiptap.html`)
   - Contains the editor instance
   - Listens for commands from Flutter
   - Sends content/selection updates back to Flutter

---

## 📝 Tiptap Editor - Headless Approach

### What is Tiptap?

**Tiptap** is a headless (UI-less) rich text editor framework built on top of ProseMirror. Unlike traditional editors, Tiptap gives you:

- **Full control** over the UI and styling
- **Extensibility** through a plugin-based architecture
- **Customizable** behavior and appearance
- **Framework agnostic** - works with any frontend framework

### Why Headless?

Traditional rich text editors bundle both the editor logic AND the UI together. With Tiptap's headless approach:

✅ **Separation of Concerns**: Editor logic is separate from UI  
✅ **Customization**: Build your own toolbar, menus, and UI components  
✅ **Framework Integration**: Use your preferred UI framework (Flutter, React, Vue, etc.)  
✅ **Performance**: Only load what you need  

### Tiptap Extensions

In our implementation, we use:

```javascript
import StarterKit from '@tiptap/starter-kit'
import Underline from '@tiptap/extension-underline'
import TextStyle from '@tiptap/extension-text-style'
import Color from '@tiptap/extension-color'
import FontSize from '@tiptap/extension-font-size'
import Table from '@tiptap/extension-table'
import TableRow from '@tiptap/extension-table-row'
import TableCell from '@tiptap/extension-table-cell'
import TableHeader from '@tiptap/extension-table-header'
```

Each extension adds specific functionality:
- **StarterKit**: Basic formatting (bold, italic, headings, lists, etc.)
- **Table extensions**: Table creation, editing, resizing
- **Color/TextStyle**: Text color and styling
- **FontSize**: Font size control

---

## 🎨 Flutter Toolbar

### Why Flutter Toolbar?

The toolbar is built in Flutter instead of HTML/JavaScript because:

1. **Native UI**: Flutter provides native-looking controls
2. **Flutter State Management**: Easy integration with Flutter's state management
3. **Consistency**: Matches the rest of your Flutter app's UI
4. **Performance**: Flutter widgets are performant and responsive
5. **Customization**: Easy to customize appearance and behavior

### Toolbar Location

The toolbar is in `lib/custom_code/widgets/quill_toolbar.dart`:

```dart
class QuillToolbar extends StatelessWidget {
  perched Function(String action)? onAction;
  final bool? isBold;
  final bool? isItalic;
  // ... other format states
  
  @override
  Widget build(BuildContext context) {
    return Container(
      // Toolbar UI with buttons
      child: Row(
        children: [
          IconButton(
            onPressed: () => onAction?.call('bold'),
            icon: Icon(Icons.format_bold),
          ),
          // ... more buttons
        ],
      ),
    );
  }
}
```

### Toolbar Actions

The toolbar sends actions to the editor:

- **Format Actions**: `bold`, `italic`, `underline`, `strike`
- **Structure**: `heading`, `bulletList`, `orderedList`, `blockquote`
- **Table**: `insertTable`
- **Clean**: Clear all formatting

---

## 🔄 Bidirectional Communication Pattern

The communication between Flutter and the Tiptap editor happens through the **PostMessage API**, allowing secure cross-origin messaging between the parent window (Flutter) and the iframe (Tiptap editor).

---

### 📤 Direction 1: Flutter → Editor (Commands)

When a user clicks a toolbar button in Flutter, a command is sent to the editor.

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUTTER APPLICATION                          │
│                                                                 │
│  User clicks "Bold" button                                      │
│         │                                                       │
│         ▼                                                       │
│  ┌──────────────────────────────────────────────────┐           │
│  │  QuillToolbar.onAction('bold')                   │           │
│  │         │                                        │           │
│  │         ▼                                        │           │
│  │  editor.sendCommand('format', format: 'bold')    │           │
│  └──────────┬───────────────────────────────────────┘           │
│             │                                                   │
│             ▼                                                   │
│  ┌──────────────────────────────────────────────────┐           │
│  │  IFrameElement.contentWindow.postMessage()       │           │
│  │  {                                               │           │
│  │    type: 'command',                              │           │
│  │    action: 'format',                             │           │
│  │    format: 'bold'                                │           │
│  │  }                                               │           │
│  └──────────┬───────────────────────────────────────┘           │
└─────────────┼───────────────────────────────────────────────────┘
              │
              │ postMessage()
              │
              ▼
┌────────────────────────────────────────────────────────────────┐
│                    TIPTAP EDITOR (Iframe)                      │
│                                                                │
│  ┌──────────────────────────────────────────────────┐          │
│  │  window.addEventListener('message', ...)         │          │
│  │         │                                        │          │
│  │         ▼                                        │          │
│  │  if (data.type === 'command') {                  │          │
│  │    switch(data.format) {                         │          │
│  │      case 'bold':                                │          │
│  │        editor.chain()                            │          │
│  │          .focus()                                │          │
│  │          .toggleBold()                           │          │
│  │          .run()                                  │          │
│  │    }                                             │          │
│  │  }                                               │          │
│  └──────────────────────────────────────────────────┘          │
│                                                                │ 
│                                                                │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

**Flutter Code:**

```dart
// Flutter: Send command to editor
void sendCommand(String action, {String? format, dynamic value}) {
  final data = {
    'type': 'command',
    'action': action,
    if (format != null) 'format': format,
    if (value != null) 'value': value,
  };
  
  _iframe?.contentWindow?.postMessage(
    jsonEncode(data),
    '*', // In production, specify origin
  );
}
```

**Tiptap Editor Code:**

```javascript
// Tiptap Editor: Receive command
window.addEventListener('message', (event) => {
  const data = event.data;
  
  if (data.type === 'command') {
    switch (data.action) {
      case 'format':
        if (data.format === 'bold') {
          editor.chain().focus().toggleBold().run();
        } else if (data.format === 'italic') {
          editor.chain().focus().toggleItalic().run();
        }
        break;
      case 'heading':
        editor.chain().focus().toggleHeading({ level: data.value }).run();
        break;
      // ... other commands
    }
  }
});
```

---

### 📥 Direction 2: Editor → Flutter (Updates)

When content changes or selection changes in the editor, it sends updates back to Flutter.

#### 2a. Content Change Flow

```
┌────────────────────────────────────────────────────────────────┐
│                    TIPTAP EDITOR (Iframe)                      │
│                                                                │
│  User types in editor or content changes                       │
│         │                                                      │
│         ▼                                                      │
│  ┌──────────────────────────────────────────────────┐          │
│  │  editor.on('update', ({ editor }) => {           │          │
│  │    const html = editor.getHTML();                │          │
│  │    const json = editor.getJSON();                │          │
│  │         │                                        │          │
│  │         ▼                                        │          │
│  │    window.parent.postMessage({                   │          │
│  │      type: 'contentChange',                      │          │
│  │      content: html,                              │          │
│  │      json: json                                  │          │
│  │    }, '*');                                      │          │
│  │  })                                              │          │
│  └──────────┬───────────────────────────────────────┘          │
└─────────────┼──────────────────────────────────────────────────┘
              │
              │ postMessage()
              │
              ▼
┌────────────────────────────────────────────────────────────────┐
│                    FLUTTER APPLICATION                         │
│                                                                │
│  ┌──────────────────────────────────────────────────┐          │
│  │  html.window.addEventListener('message', ...)    │          │
│  │         │                                        │          │
│  │         ▼                                        │          │
│  │  if (data['type'] == 'contentChange') {          │          │
│  │    String html = data['content'];                │          │
│  │         │                                        │          │
│  │         ▼                                        │          │
│  │    widget.onMessageReceived?.call(html);         │          │
│  │  }                                               │          │
│  └──────────┬───────────────────────────────────────┘          │
│             │                                                  │
│             ▼                                                  │
│  ┌──────────────────────────────────────────────────┐          │
│  │  State updates                                   │          │
│  │  - Save content                                  │          │
│  │  - Update preview                                │          │
│  │  - Trigger callbacks                             │          │
│  └──────────────────────────────────────────────────┘          │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

#### 2b. Selection Change Flow

```
┌───────────────────────────────────────────────────────────────────┐
│                    TIPTAP EDITOR (Iframe)                         │
│                                                                   │
│  User moves cursor or changes selection                           │
│         │                                                         │  
│         ▼                                                         │
│  ┌─────────────────────────────────────────────────────┐          │
│  │  editor.on('selectionUpdate', ({ editor }) => {     │          │
│  │    window.parent.postMessage({                      │          │
│  │      type: 'selectionChange',                       │          │
│  │      isBold: editor.isActive('bold'),               │          │
│  │      isItalic: editor.isActive('italic'),           │          │
│  │      currentHeader: editor.getAttributes('heading') │          │
│  │      ...                                            │          │
│  │    }, '*');                                         │          │
│  │  })                                                 │          │
│  └──────────┬──────────────────────────────────────────┘          │
└─────────────┼─────────────────────────────────────────────────────┘
              │
              │ postMessage()
              │
              ▼
┌────────────────────────────────────────────────────────────────┐
│                    FLUTTER APPLICATION                         │
│                                                                │
│  ┌──────────────────────────────────────────────────┐          │
│  │  Receive selectionChange message                 │          │
│  │         │                                        │          │
│  │         ▼                                        │          │
│  │  setState(() {                                   │          │
│  │    isBold = data['isBold'];                      │          │
│  │    isItalic = data['isItalic'];                  │          │
│  │    ...                                           │          │
│  │  })                                              │          │
│  └──────────┬───────────────────────────────────────┘          │
│             │                                                  │
│             ▼                                                  │
│  ┌──────────────────────────────────────────────────┐          │
│  │  QuillToolbar updates                            │          │
│  │  - Toggle button states                          │          │
│  │  - Highlight active formats                      │          │
│  │  - Enable/disable buttons                        │          │
│  └──────────────────────────────────────────────────┘          │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

**Tiptap Editor Code:**

```javascript
// Send content update (debounced)
editor.on('update', ({ editor }) => {
  const html = editor.getHTML();
  
  // Debounce to avoid excessive messages
  clearTimeout(window.contentUpdateTimeout);
  window.contentUpdateTimeout = setTimeout(() => {
    window.parent.postMessage({
      type: 'contentChange',
      content: html,
      timestamp: Date.now()
    }, '*');
  }, 300);
});

// Send selection update
editor.on('selectionUpdate', ({ editor }) => {
  window.parent.postMessage({
    type: 'selectionChange',
    isBold: editor.isActive('bold'),
    isItalic: editor.isActive('italic'),
    isUnderline: editor.isActive('underline'),
    currentHeader: editor.getAttributes('heading').level || 0,
    currentList: editor.isActive('bulletList') ? 'bullet' : 
                 editor.isActive('orderedList') ? 'ordered' : null,
  }, '*');
});
```

**Flutter Code:**

```dart
// Receive updates
html.window.addEventListener('message', (event) {
  final messageEvent = event as html.MessageEvent;
  
  if (messageEvent.data != null) {
    try {
      Map<String, dynamic> data = Map<String, dynamic>.from(messageEvent.data);
      
      // Handle content changes
      if (data['type'] == 'contentChange') {
        String htmlContent = data['content'] as String;
        widget.onMessageReceived?.call(htmlContent);
      }
      
      // Handle selection changes
      if (data['type'] == 'selectionChange') {
        setState(() {
          isBold = data['isBold'] ?? false;
          isItalic = data['isItalic'] ?? false;
          // ... update toolbar state
        });
      }
    } catch (e) {
      print('Error parsing message: $e');
    }
  }
});
```

---

### 🔄 Complete Bidirectional Flow Example

Here's a complete example showing both directions working together:

**Scenario: User clicks Bold button, then types text**

```
Step 1: User clicks Bold button
  Flutter Toolbar → postMessage({command: 'bold'}) → Tiptap Editor
  Tiptap Editor → editor.toggleBold() → Content updates

Step 2: Selection state syncs
  Tiptap Editor → postMessage({selectionChange: {isBold: true}}) → Flutter
  Flutter → Updates toolbar (Bold button becomes active)

Step 3: User types text
  Tiptap Editor → Content changes → Triggers onUpdate
  Tiptap Editor → postMessage({contentChange: {content: '<p><strong>New text</strong></p>'}}) → Flutter
  Flutter → Receives content → Updates state/callback

Step 4: User clicks Bold again to turn off
  Flutter Toolbar → postMessage({command: 'bold'}) → Tiptap Editor
  Tiptap Editor → editor.toggleBold() → isBold becomes false
  Tiptap Editor → postMessage({selectionChange: {isBold: false}}) → Flutter
  Flutter → Updates toolbar (Bold button becomes inactive)
```

---

## 🌐 HTML File Setup

### Simple HTML File Structure

Create `web/test_tiptap.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tiptap Editor</title>
    <style>
        /* Your custom styles */
        body {
            margin: 0;
            padding: 0;
        }
        
        #editor {
            min-height: 300px;
            padding: 10px;
        }
    </style>
</head>
<body>
    <!-- Editor container -->
    <div id="editor"></div>

    <script type="module">
        // Import Tiptap
        import { Editor } from 'https://esm.sh/@tiptap/core'
        import StarterKit from 'https://esm.sh/@tiptap/starter-kit'
        import Table from 'https://esm.sh/@tiptap/extension-table'
        // ... other imports

        // Initialize editor
        const editor = new Editor({
            element: document.querySelector('#editor'),
            extensions: [
                StarterKit,
                Table.configure({ resizable: true }),
                // ... other extensions
            ],
            content: '<p>Initial content</p>',
            
            // Listen for content changes
            onUpdate: ({ editor }) => {
                const html = editor.getHTML();
                // Send to Flutter
                window.parent.postMessage({
                    type: 'contentChange',
                    content: html
                }, '*');
            },
            
            // Listen for selection changes
            onSelectionUpdate: ({ editor }) => {
                window.parent.postMessage({
                    type: 'selectionChange',
                    isBold: editor.isActive('bold'),
                    isItalic: editor.isActive('italic'),
                    // ... other states
                }, '*');
            },
        });

        // Listen for commands from Flutter
        window.addEventListener('message', (event) => {
            const data = event.data;
            
            if (data.type === 'command') {
                switch (data.action) {
                    case 'format':
                        editor.chain().focus().toggleBold().run();
                        break;
                    // ... other commands
                }
            }
        });
    </script>
</body>
</html>
```

### Key Points

1. **ES Modules**: Use `type="module"` for modern JavaScript imports
2. **CDN Imports**: Use `https://esm.sh/` for browser-compatible imports
3. **PostMessage**: Use `window.parent.postMessage()` to send to Flutter
4. **Event Listeners**: Listen for `message` events to receive commands

---

## 📱 Flutter Widget Implementation

### Basic Editor Widget

Create `lib/custom_code/widgets/quill_editor.dart`:

```dart
import 'dart:html' as html;
import 'dart:ui_web' as ui;
import 'dart:convert';
import 'package:flutter/material.dart';

class QuillEditor extends StatefulWidget {
  final double? width;
  final double? height;
  final Function(String)? onMessageReceived;

  const QuillEditor({
    Key? key,
    this.width,
    this.height,
    this.onMessageReceived,
  }) : super(key: key);

  @override
  State<QuillEditor> createState() => _QuillEditorState();
}

class _QuillEditorState extends State<QuillEditor> {
  static int _viewIdCounter = 0;
  late final int _viewId;
  html.IFrameElement? _iframe;

  @override
  void initState() {
    super.initState();
    _viewId = _viewIdCounter++;
    _registerViewFactory();
  }

  void _registerViewFactory() {
    // Register the iframe view factory
    ui.platformViewRegistry.registerViewFactory(
      'editor-$_viewId',
      (int viewId) {
        // Create iframe element
        _iframe = html.IFrameElement()
          ..src = '/test_tiptap.html'
          ..style.border = '0'
          ..style.width = '100%'
          ..style.height = '100%';

        // Listen for messages from the iframe
        html.window.addEventListener('message', (event) {
          final messageEvent = event as html.MessageEvent;
          
          if (messageEvent.data != null) {
            try {
              Map<String, dynamic> data;
              
              // Handle both Map and String data
              if (messageEvent.data is Map) {
                data = Map<String, dynamic>.from(messageEvent.data);
              } else {
                data = jsonDecode(messageEvent.data as String);
              }

              // Handle different message types
              if (data['type'] == 'contentChange') {
                widget.onMessageReceived?.call(data['content'] as String);
              } else if (data['type'] == 'selectionChange') {
                // Update toolbar state
                // You can use a state management solution here
              }
            } catch (e) {
              print('Error parsing message: $e');
            }
          }
        });

        return _iframe!;
      },
    );
  }

  // Method to send commands to editor
  void sendCommand(String action, {String? format, dynamic value}) {
    final data = {
      'type': 'command',
      'action': action,
      if (format != null) 'format': format,
      if (value != null) 'value': value,
    };
    
    _iframe?.contentWindow?.postMessage(
      jsonEncode(data),
      '*',
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: HtmlElementView(
        viewType: 'editor-$_viewId',
      ),
    );
  }
}
```

### Complete Example with Toolbar

```dart
class EditorWithToolbar extends StatefulWidget {
  @override
  _EditorWithToolbarState createState() => _EditorWithToolbarState();
}

class _EditorWithToolbarState extends State<EditorWithToolbar> {
  String editorContent = '';
  bool isBold = false;
  bool isItalic = false;
  late QuillEditor editor;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Flutter Toolbar
        QuillToolbar(
          onAction: _handleToolbarAction,
          isBold: isBold,
          isItalic: isItalic,
        ),
        
        // Editor
        Expanded(
          child: QuillEditor(
            height: 400,
            width: 800,
            onMessageReceived: (content) {
              setState(() {
                editorContent = content;
              });
            },
          ),
        ),
      ],
    );
  }

  void _handleToolbarAction(String action) {
    // Send command to editor
    editor.sendCommand('format', format: action);
  }
}
```

---

## 🚀 Usage Examples

### Basic Usage

```dart
QuillEditor(
  width: 800,
  height: 400,
  onMessageReceived: (htmlContent) {
    print('Editor content: $htmlContent');
  },
)
```

### With Toolbar

```dart
Column(
  children: [
    QuillToolbar(
      onAction: (action) {
        editorController.sendCommand('format', format: action);
      },
    ),
    QuillEditor(
      width: 800,
      height: 400,
    ),
  ],
)
```

### Reading/Writing Content

```dart
// Read content
editor.onMessageReceived = (html) {
  print('Content updated: $html');
};

// Write content (from Flutter to editor)
editor.sendCommand('setContent', content: '<p>New content</p>');
```

---

## ⚙️ Advanced Features

### Table Features

The editor supports advanced table operations:

- **Resizable columns**: Drag column borders to resize
- **Context menu**: Right-click for table operations
  - Add/remove columns and rows
  - Merge/split cells
  - Toggle header cells
  - Cell background color
  - Font color
- **Notion-style controls**: Hover controls for adding columns/rows

### Selection Handling

- **Cell selection**: Visual highlighting of selected cells
- **Active cell**: Highlighting for cell with cursor
- **Multi-cell selection**: Select multiple cells for operations

### Styling

- Custom CSS for tables, menus, and editor
- Preserved background colors
- Custom scrollbar styling
- Responsive layout

---

## 🔧 Configuration

### Editor Configuration

In `test_tiptap.html`, configure the editor:

```javascript
const editor = new Editor({
  element: document.querySelector('#editor'),
  extensions: [
    StarterKit,
    Table.configure({
      resizable: true,
      HTMLAttributes: {
        style: 'width: 100%;',
      },
    }),
    // ... other extensions
  ],
  content: '<p>Hello Tiptap!</p>',
  onUpdate: ({ editor }) => {
    // Handle updates
  },
});
```

### Flutter Configuration

Ensure `pubspec.yaml` includes web dependencies:

```yaml
dependencies:
  flutter:
    sdk: flutter
```

The HTML file should be in the `web/` directory for Flutter Web to serve it.

---

## 📚 Key Files

### Flutter Files

- `lib/custom_code/widgets/quill_editor.dart` - Main editor widget
- `lib/custom_code/widgets/quill_toolbar.dart` - Toolbar widget
- `lib/custom_code/widgets/index.dart` - Widget exports

### HTML/JavaScript Files

- `web/test_tiptap.html` - Tiptap editor implementation
- Contains all editor logic, styling, and communication code

---

## 💡 Best Practices

1. **Debounce Updates**: Debounce content updates to avoid excessive postMessages
2. **Error Handling**: Always wrap postMessage parsing in try-catch
3. **Security**: Validate and sanitize HTML content if needed
4. **State Management**: Use Flutter state management for toolbar state sync
5. **Performance**: Debounce content updates (300ms delay is used in this implementation)

---

## 🎉 Summary

This architecture provides:

✅ **Separation of concerns**: Editor logic (HTML/JS) vs UI (Flutter)  
✅ **Bidirectional communication**: Seamless data flow  
✅ **Customizable**: Full control over appearance and behavior  
✅ **Extensible**: Easy to add new features  
✅ **Performance**: Efficient updates and rendering  

The combination of Tiptap's headless approach with Flutter's powerful UI framework creates a flexible, maintainable rich text editor solution.

