import 'package:dropdown_button2/dropdown_button2.dart';

import 'package:flutter/foundation.dart';
import 'form_field_controller.dart';
import 'package:flutter/material.dart';

class FlutterFlowDropDown<T> extends StatefulWidget {
  const FlutterFlowDropDown({
    super.key,
    this.controller,
    this.multiSelectController,
    this.hintText,
    this.searchHintText,
    required this.options,
    this.optionLabels,
    this.onChanged,
    this.onMultiSelectChanged,
    this.icon,
    this.width,
    this.height,
    this.maxHeight,
    this.searchHintTextStyle,
    this.searchTextStyle,
    this.searchCursorColor,
    required this.textStyle,
    required this.elevation,
    this.hidesUnderline = false,
    this.disabled = false,
    this.isOverButton = false,
    this.menuOffset,
    this.isSearchable = false,
    this.isMultiSelect = false,
    this.optionsHasValueKeys = false,
  }) : assert(
          isMultiSelect
              ? (controller == null &&
                  onChanged == null &&
                  multiSelectController != null &&
                  onMultiSelectChanged != null)
              : (controller != null &&
                  onChanged != null &&
                  multiSelectController == null &&
                  onMultiSelectChanged == null),
        );

  final FormFieldController<T?>? controller;
  final FormFieldController<List<T>?>? multiSelectController;
  final String? hintText;
  final String? searchHintText;
  final List<T> options;
  final List<String>? optionLabels;
  final Function(T?)? onChanged;
  final Function(List<T>?)? onMultiSelectChanged;
  final Widget? icon;
  final double? width;
  final double? height;
  final double? maxHeight;
  final TextStyle? searchHintTextStyle;
  final TextStyle? searchTextStyle;
  final Color? searchCursorColor;
  final TextStyle textStyle;
  final double elevation;
  final bool hidesUnderline;
  final bool disabled;
  final bool isOverButton;
  final Offset? menuOffset;
  final bool isSearchable;
  final bool isMultiSelect;
  final bool optionsHasValueKeys;

  @override
  State<FlutterFlowDropDown<T>> createState() => _FlutterFlowDropDownState<T>();
}

class _FlutterFlowDropDownState<T> extends State<FlutterFlowDropDown<T>> {
  bool get isMultiSelect => widget.isMultiSelect;
  FormFieldController<T?> get controller => widget.controller!;
  FormFieldController<List<T>?> get multiSelectController =>
      widget.multiSelectController!;

  T? get currentValue {
    final value = isMultiSelect
        ? multiSelectController.value?.firstOrNull
        : controller.value;
    return widget.options.contains(value) ? value : null;
  }

  Set<T> get currentValues {
    if (!isMultiSelect || multiSelectController.value == null) {
      return {};
    }
    return widget.options
        .toSet()
        .intersection(multiSelectController.value!.toSet());
  }

  Map<T, String> get optionLabels => Map.fromEntries(
        widget.options.asMap().entries.map(
              (option) => MapEntry(
                option.value,
                widget.optionLabels == null ||
                        widget.optionLabels!.length < option.key + 1
                    ? option.value.toString()
                    : widget.optionLabels![option.key],
              ),
            ),
      );

  late void Function() _listener;
  final TextEditingController _textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (isMultiSelect) {
      _listener =
          () => widget.onMultiSelectChanged!(multiSelectController.value);
      multiSelectController.addListener(_listener);
    } else {
      _listener = () => widget.onChanged!(controller.value);
      controller.addListener(_listener);
    }
  }

  @override
  void dispose() {
    if (isMultiSelect) {
      multiSelectController.removeListener(_listener);
    } else {
      controller.removeListener(_listener);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dropdownWidget = _buildDropdownWidget();
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: widget.hidesUnderline
          ? DropdownButtonHideUnderline(child: dropdownWidget)
          : dropdownWidget,
    );
  }

  Widget _buildDropdownWidget() {
    final overlayColor = WidgetStateProperty.resolveWith<Color?>((states) =>
        states.contains(WidgetState.focused) ? Colors.transparent : null);
    final iconStyleData = widget.icon != null
        ? IconStyleData(icon: widget.icon!)
        : const IconStyleData();
    return DropdownButtonFormField2<T>(
      valueListenable: isMultiSelect ? null : _singleValueListenable(),
      multiValueListenable: isMultiSelect ? _multiValueListenable() : null,
      items: isMultiSelect
          ? _createMultiselectDropdownItems()
          : _createDropdownItems(),
      hint: _createHintText(),
      onChanged: widget.disabled
          ? null
          : (isMultiSelect ? (_) {} : (value) => controller.value = value),
      iconStyleData: iconStyleData,
      isExpanded: true,
      style: widget.textStyle,
      dropdownStyleData: DropdownStyleData(
        elevation: widget.elevation.toInt(),
        isOverButton: widget.isOverButton,
        offset: widget.menuOffset ?? Offset.zero,
        maxHeight: widget.maxHeight,
      ),
      menuItemStyleData: MenuItemStyleData(
        overlayColor: overlayColor,
        padding: EdgeInsets.zero,
      ),
      decoration: InputDecoration(
        border: widget.hidesUnderline
            ? InputBorder.none
            : const UnderlineInputBorder(),
      ),
      selectedItemBuilder: (context) => widget.options
          .map(
            (item) => Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                isMultiSelect
                    ? currentValues
                        .where((v) => optionLabels.containsKey(v))
                        .map((v) => optionLabels[v])
                        .join(', ')
                    : optionLabels[item]!,
                style: widget.textStyle,
                maxLines: 1,
              ),
            ),
          )
          .toList(),
      dropdownSearchData: widget.isSearchable
          ? DropdownSearchData<T>(
              searchController: _textEditingController,
              searchBarWidgetHeight: 50,
              searchBarWidget: SizedBox(
                height: 50,
                child: TextFormField(
                  expands: true,
                  maxLines: null,
                  controller: _textEditingController,
                  cursorColor: widget.searchCursorColor,
                  style: widget.searchTextStyle,
                  decoration: InputDecoration(
                    hintText: widget.searchHintText,
                    hintStyle: widget.searchHintTextStyle,
                  ),
                ),
              ),
              searchMatchFn: (item, searchValue) {
                final value = item.value;
                return value != null &&
                    (optionLabels[value] ?? '')
                        .toLowerCase()
                        .contains(searchValue.toLowerCase());
              },
            )
          : null,
      onMenuStateChange: widget.isSearchable
          ? (isOpen) {
              if (!isOpen) {
                _textEditingController.clear();
              }
            }
          : null,
    );
  }

  Text? _createHintText() => widget.hintText != null
      ? Text(widget.hintText!, style: widget.textStyle)
      : null;

  ValueKey _getItemKey(T option) {
    final widgetKey = (widget.key as ValueKey).value;
    return ValueKey('$widgetKey ${widget.options.indexOf(option)}');
  }

  List<DropdownItem<T>> _createDropdownItems() => widget.options
      .map(
        (option) => DropdownItem<T>(
          key: widget.optionsHasValueKeys ? _getItemKey(option) : null,
          value: option,
          child: Text(
            optionLabels[option] ?? '',
            style: widget.textStyle,
          ),
        ),
      )
      .toList();

  List<DropdownItem<T>> _createMultiselectDropdownItems() => widget.options
      .map(
        (item) => DropdownItem<T>(
          key: widget.optionsHasValueKeys ? _getItemKey(item) : null,
          value: item,
          closeOnTap: false,
          onTap: () {
            multiSelectController.value ??= [];
            final isSelected =
                multiSelectController.value?.contains(item) ?? false;
            if (isSelected) {
              multiSelectController.value!.remove(item);
            } else {
              multiSelectController.value!.add(item);
            }
            multiSelectController.update();
            setState(() {});
          },
          child: ValueListenableBuilder<List<T>?>(
            valueListenable: multiSelectController,
            builder: (context, value, _) {
              final isSelected = value?.contains(item) ?? false;
              return Container(
                height: double.infinity,
                padding: EdgeInsets.zero,
                child: Row(
                  children: [
                    if (isSelected)
                      const Icon(Icons.check_box_outlined)
                    else
                      const Icon(Icons.check_box_outline_blank),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        optionLabels[item]!,
                        style: widget.textStyle,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      )
      .toList();

  /// Exposes controller value only when it exists in [widget.options],
  /// so DropdownButton2's assertion (exactly one matching item) is satisfied.
  ValueListenable<T?> _singleValueListenable() =>
      _SingleValueListenable<T>(controller, widget.options);

  ValueListenable<Iterable<T>> _multiValueListenable() =>
      _MultiValueListenable<T>(multiSelectController, widget.options);
}

/// Wraps [FormFieldController<T?>] and only exposes a value when it is in
/// [validValues], so DropdownButton2's unique-value assertion is satisfied.
class _SingleValueListenable<T> implements ValueListenable<T?> {
  _SingleValueListenable(this._controller, this._validValues);

  final FormFieldController<T?> _controller;
  final List<T> _validValues;

  @override
  T? get value {
    final v = _controller.value;
    return _validValues.contains(v) ? v : null;
  }

  @override
  void addListener(VoidCallback listener) =>
      _controller.addListener(listener);

  @override
  void removeListener(VoidCallback listener) =>
      _controller.removeListener(listener);
}

/// Wraps [FormFieldController<List<T>?>] as [ValueListenable<Iterable<T>>]
/// for DropdownButton2 multiValueListenable. Only exposes values that are in
/// [validValues] so the package's assertion is satisfied.
class _MultiValueListenable<T> implements ValueListenable<Iterable<T>> {
  _MultiValueListenable(this._controller, this._validValues);

  final FormFieldController<List<T>?> _controller;
  final List<T> _validValues;

  @override
  Iterable<T> get value {
    final list = _controller.value ?? const [];
    return list.where((v) => _validValues.contains(v));
  }

  @override
  void addListener(VoidCallback listener) =>
      _controller.addListener(listener);

  @override
  void removeListener(VoidCallback listener) =>
      _controller.removeListener(listener);
}
