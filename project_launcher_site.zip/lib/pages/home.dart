import 'package:jaspr/dom.dart';
import 'package:jaspr/jaspr.dart';

import '../constants/theme.dart';

@client
class Home extends StatelessComponent {
  const Home({super.key});

  @override
  Component build(BuildContext context) {
    return div(classes: 'landing-page', [
      // Hero Section
      section(classes: 'hero', [
        div(classes: 'hero-content', [
          h1([.text('Manage Your Dev Projects')]),
          h1(classes: 'gradient-text', [.text('Like a Pro')]),
          p(classes: 'hero-subtitle', [
            .text('Project Launcher keeps all your development projects organized, healthy, and accessible. Track project health, spot stale repos, and share your coding stats.'),
          ]),
          div(classes: 'hero-buttons', [
            a(href: '#download', classes: 'primary-btn', [.text('Download Free')]),
            a(href: 'https://github.com/ff-vivek/project-launcher', attributes: {'target': '_blank'}, classes: 'secondary-btn', [
              .text('View on GitHub'),
            ]),
          ]),
        ]),
        div(classes: 'hero-image', [
          div(classes: 'app-preview', [
            img(src: 'images/ss.png', alt: 'Project Launcher App Screenshot'),
          ]),
        ]),
      ]),

      // Features Section
      section(id: 'features', classes: 'features', [
        h2([.text('Everything You Need')]),
        p(classes: 'section-subtitle', [.text('Powerful features to keep your projects in check')]),
        div(classes: 'features-grid', [
          _featureCard(
            icon: '\u{1F4CA}',
            title: 'Health Score',
            description: 'Get a 0-100 health score for each project based on git activity, dependencies, and tests.',
          ),
          _featureCard(
            icon: '\u{23F0}',
            title: 'Stale Alerts',
            description: 'Visual indicators show which projects need attention before they become abandoned.',
          ),
          _featureCard(
            icon: '\u{1F4C8}',
            title: 'Year in Review',
            description: 'Generate beautiful, shareable cards showing your coding stats - Spotify Wrapped style.',
            isPro: true,
          ),
          _featureCard(
            icon: '\u{1F381}',
            title: 'Referral Rewards',
            description: 'Invite fellow devs and unlock exclusive dark themes for your launcher.',
          ),
          _featureCard(
            icon: '\u{26A1}',
            title: 'Native Performance',
            description: 'Built with Rust core for blazing fast git operations and file scanning.',
          ),
          _featureCard(
            icon: '\u{1F3A8}',
            title: 'Beautiful UI',
            description: 'Clean, modern interface that stays out of your way while keeping you informed.',
          ),
        ]),
      ]),

      // Pricing Section
      section(id: 'pricing', classes: 'pricing', [
        h2([.text('Simple Pricing')]),
        p(classes: 'section-subtitle', [.text('Start free, upgrade when you\'re ready')]),
        div(classes: 'pricing-grid', [
          // Free plan
          div(classes: 'pricing-card', [
            div(classes: 'pricing-header', [
              h3([.text('Free')]),
              div(classes: 'pricing-price', [
                span(classes: 'price-amount', [.text('\$0')]),
                span(classes: 'price-period', [.text('forever')]),
              ]),
            ]),
            ul(classes: 'pricing-features', [
              li([.text('Project management & organization')]),
              li([.text('Health scores for all projects')]),
              li([.text('Stale project alerts')]),
              li([.text('Light & dark themes')]),
              li([.text('Referral rewards')]),
            ]),
            a(href: '#download', classes: 'pricing-btn', [.text('Download Free')]),
          ]),
          // Pro plan
          div(classes: 'pricing-card pricing-card-pro', [
            div(classes: 'pricing-badge', [.text('PRO')]),
            div(classes: 'pricing-header', [
              h3([.text('Pro')]),
              div(classes: 'pricing-price', [
                span(classes: 'price-amount', [.text('\$19')]),
                span(classes: 'price-period', [.text('one-time')]),
              ]),
            ]),
            ul(classes: 'pricing-features', [
              li([.text('Everything in Free')]),
              li([.text('Year in Review cards')]),
              li([.text('All premium themes')]),
              li([.text('Advanced health history & trends')]),
              li([.text('Priority support')]),
            ]),
            a(href: '#download', classes: 'pricing-btn pricing-btn-pro', [.text('Get Pro')]),
          ]),
        ]),
      ]),

      // Download Section
      section(id: 'download', classes: 'download', [
        div(classes: 'download-card', [
          h2([.text('Ready to Get Started?')]),
          p([.text('Download Project Launcher for macOS. Free core features, optional Pro upgrade.')]),
          div(classes: 'download-options', [
            div(classes: 'download-method', [
              h3([.text('Homebrew')]),
              code([.text('brew install --cask project-launcher')]),
            ]),
            div(classes: 'divider', [.text('or')]),
            div(classes: 'download-method', [
              h3([.text('Direct Download')]),
              a(
                href: 'https://github.com/ff-vivek/project-launcher/releases/latest',
                classes: 'download-btn',
                attributes: {'target': '_blank'},
                [.text('Download DMG')],
              ),
            ]),
          ]),
          p(classes: 'requirements', [.text('Requires macOS 12.0 or later. Universal binary (Intel + Apple Silicon).')]),
        ]),
      ]),

      // Footer
      footer([
        div(classes: 'footer-content', [
          p([.text('\u00A9 2025 Project Launcher. Built with Flutter & Rust.')]),
          div(classes: 'footer-links', [
            a(href: 'https://github.com/ff-vivek/project-launcher', attributes: {'target': '_blank'}, [.text('GitHub')]),
            a(href: 'https://github.com/ff-vivek/project-launcher/issues', attributes: {'target': '_blank'}, [.text('Report Issue')]),
          ]),
        ]),
      ]),
    ]);
  }

  static Component _featureCard({
    required String icon,
    required String title,
    required String description,
    bool isPro = false,
  }) {
    return div(classes: 'feature-card', [
      div(classes: 'feature-card-header', [
        span(classes: 'feature-icon', [.text(icon)]),
        if (isPro)
          span(classes: 'feature-badge feature-badge-pro', [.text('PRO')])
        else
          span(classes: 'feature-badge feature-badge-free', [.text('FREE')]),
      ]),
      h3([.text(title)]),
      p([.text(description)]),
    ]);
  }

  @css
  static List<StyleRule> get styles => [
    // Landing page base
    css('.landing-page', [
      css('&').styles(
        padding: .only(top: 80.px),
      ),
    ]),

    // Hero Section
    css('.hero', [
      css('&').styles(
        display: .flex,
        minHeight: 90.vh,
        maxWidth: 1200.px,
        margin: .symmetric(horizontal: .auto),
        padding: .symmetric(horizontal: 2.em, vertical: 4.em),
        alignItems: .center,
        raw: {'gap': '4em'},
      ),
      css('.hero-content').styles(
        flex: Flex(grow: 1),
      ),
      css('h1').styles(
        fontSize: 3.5.em,
        fontWeight: .w700,
        lineHeight: 1.1.em,
        margin: .zero,
        color: lightText,
      ),
      css('.gradient-text').styles(
        raw: {
          'background': 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          'background-clip': 'text',
          '-webkit-background-clip': 'text',
          '-webkit-text-fill-color': 'transparent',
        },
      ),
      css('.hero-subtitle').styles(
        fontSize: 1.25.em,
        color: mutedText,
        lineHeight: 1.6.em,
        margin: .only(top: 1.5.em, bottom: 2.em),
        maxWidth: 500.px,
      ),
      css('.hero-buttons', [
        css('&').styles(
          display: .flex,
          raw: {'gap': '1em'},
        ),
      ]),
      css('.hero-image').styles(
        flex: Flex(grow: 1),
      ),
      css('.app-preview', [
        css('&').styles(
          width: 100.percent,
          radius: .circular(16.px),
          overflow: .hidden,
          border: Border(width: 1.px, style: .solid, color: const Color('#ffffff10')),
          raw: {'box-shadow': '0 25px 50px -12px rgba(0, 0, 0, 0.5)'},
        ),
        css('img').styles(
          width: 100.percent,
          height: .auto,
          display: .block,
        ),
      ]),
    ]),

    // Buttons
    css('.primary-btn, .secondary-btn', [
      css('&').styles(
        display: .inlineBlock,
        padding: .symmetric(horizontal: 2.em, vertical: 1.em),
        radius: .circular(8.px),
        fontWeight: .w600,
        textDecoration: TextDecoration(line: .none),
        raw: {'transition': 'all 0.2s'},
      ),
    ]),
    css('.primary-btn').styles(
      backgroundColor: primaryColor,
      color: Colors.white,
    ),
    css('.primary-btn:hover').styles(
      backgroundColor: accentColor,
    ),
    css('.secondary-btn').styles(
      raw: {'background-color': 'transparent'},
      color: lightText,
      border: Border(width: 2.px, style: .solid, color: primaryColor),
    ),
    css('.secondary-btn:hover').styles(
      backgroundColor: primaryColor,
    ),

    // Features Section
    css('.features', [
      css('&').styles(
        maxWidth: 1200.px,
        margin: .symmetric(horizontal: .auto),
        padding: .symmetric(horizontal: 2.em, vertical: 6.em),
        textAlign: .center,
      ),
      css('h2').styles(
        fontSize: 2.5.em,
        fontWeight: .w700,
        color: lightText,
        margin: .zero,
      ),
      css('.section-subtitle').styles(
        color: mutedText,
        fontSize: 1.125.em,
        margin: .only(top: 0.5.em, bottom: 3.em),
      ),
      css('.features-grid').styles(
        display: .grid,
        raw: {'grid-template-columns': 'repeat(3, 1fr)', 'gap': '2em'},
      ),
    ]),

    // Feature Card
    css('.feature-card', [
      css('&').styles(
        backgroundColor: darkSurface,
        padding: .all(2.em),
        radius: .circular(16.px),
        textAlign: .left,
        border: Border(width: 1.px, style: .solid, color: const Color('#ffffff08')),
        raw: {'transition': 'transform 0.2s, border-color 0.2s'},
      ),
      css('&:hover').styles(
        raw: {'transform': 'translateY(-4px)'},
        border: Border(width: 1.px, style: .solid, color: primaryColor),
      ),
      css('.feature-card-header').styles(
        display: .flex,
        justifyContent: .spaceBetween,
        alignItems: .start,
        margin: .only(bottom: 0.5.em),
      ),
      css('.feature-icon').styles(
        fontSize: 2.em,
        display: .block,
      ),
      css('.feature-badge').styles(
        fontSize: 0.7.em,
        fontWeight: .w700,
        padding: .symmetric(horizontal: 0.6.em, vertical: 0.2.em),
        radius: .circular(4.px),
        raw: {'letter-spacing': '0.05em'},
      ),
      css('.feature-badge-free').styles(
        color: const Color('#22C55E'),
        backgroundColor: const Color('#22C55E1a'),
      ),
      css('.feature-badge-pro').styles(
        color: const Color('#FFD700'),
        backgroundColor: const Color('#FFD7001a'),
      ),
      css('h3').styles(
        fontSize: 1.25.em,
        fontWeight: .w600,
        color: lightText,
        margin: .only(bottom: 0.5.em),
      ),
      css('p').styles(
        color: mutedText,
        lineHeight: 1.5.em,
        margin: .zero,
      ),
    ]),

    // Pricing Section
    css('.pricing', [
      css('&').styles(
        maxWidth: 1200.px,
        margin: .symmetric(horizontal: .auto),
        padding: .symmetric(horizontal: 2.em, vertical: 6.em),
        textAlign: .center,
      ),
      css('h2').styles(
        fontSize: 2.5.em,
        fontWeight: .w700,
        color: lightText,
        margin: .zero,
      ),
      css('.section-subtitle').styles(
        color: mutedText,
        fontSize: 1.125.em,
        margin: .only(top: 0.5.em, bottom: 3.em),
      ),
      css('.pricing-grid').styles(
        display: .grid,
        raw: {'grid-template-columns': 'repeat(2, 1fr)', 'gap': '2em'},
        maxWidth: 800.px,
        margin: .symmetric(horizontal: .auto),
      ),
    ]),
    css('.pricing-card', [
      css('&').styles(
        backgroundColor: darkSurface,
        padding: .all(2.5.em),
        radius: .circular(16.px),
        textAlign: .left,
        border: Border(width: 1.px, style: .solid, color: const Color('#ffffff10')),
        raw: {'position': 'relative'},
      ),
      css('.pricing-badge').styles(
        raw: {
          'position': 'absolute',
          'top': '-12px',
          'right': '24px',
          'letter-spacing': '0.1em',
        },
        backgroundColor: const Color('#FFD700'),
        color: const Color('#1A1C1E'),
        fontWeight: .w700,
        fontSize: 0.75.em,
        padding: .symmetric(horizontal: 1.em, vertical: 0.3.em),
        radius: .circular(4.px),
      ),
      css('.pricing-header').styles(
        margin: .only(bottom: 1.5.em),
      ),
      css('h3').styles(
        fontSize: 1.5.em,
        fontWeight: .w700,
        color: lightText,
        margin: .only(bottom: 0.5.em),
      ),
      css('.pricing-price').styles(
        display: .flex,
        alignItems: .baseline,
        raw: {'gap': '0.3em'},
      ),
      css('.price-amount').styles(
        fontSize: 3.em,
        fontWeight: .w700,
        color: lightText,
      ),
      css('.price-period').styles(
        color: mutedText,
        fontSize: 1.em,
      ),
      css('.pricing-features').styles(
        raw: {'list-style': 'none'},
        padding: .zero,
        margin: .only(bottom: 2.em),
      ),
      css('.pricing-features li').styles(
        padding: .symmetric(vertical: 0.5.em),
        color: mutedText,
        raw: {'border-bottom': '1px solid #ffffff08'},
      ),
      css('.pricing-features li::before').styles(
        raw: {'content': '"\\2713  "'},
        color: const Color('#22C55E'),
        fontWeight: .w700,
      ),
      css('.pricing-btn').styles(
        display: .block,
        textAlign: .center,
        padding: .symmetric(horizontal: 1.5.em, vertical: 0.75.em),
        radius: .circular(8.px),
        fontWeight: .w600,
        textDecoration: TextDecoration(line: .none),
        color: lightText,
        border: Border(width: 2.px, style: .solid, color: primaryColor),
        raw: {'transition': 'all 0.2s'},
      ),
      css('.pricing-btn:hover').styles(
        backgroundColor: primaryColor,
      ),
      css('.pricing-btn-pro').styles(
        backgroundColor: const Color('#FFD700'),
        color: const Color('#1A1C1E'),
        border: Border(width: 2.px, style: .solid, color: const Color('#FFD700')),
      ),
      css('.pricing-btn-pro:hover').styles(
        backgroundColor: const Color('#FFC000'),
        raw: {'border-color': '#FFC000'},
      ),
    ]),
    css('.pricing-card-pro').styles(
      border: Border(width: 2.px, style: .solid, color: const Color('#FFD70040')),
    ),

    // Download Section
    css('.download', [
      css('&').styles(
        maxWidth: 800.px,
        margin: .symmetric(horizontal: .auto),
        padding: .symmetric(horizontal: 2.em, vertical: 6.em),
      ),
      css('.download-card').styles(
        raw: {'background': 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'},
        padding: .all(3.em),
        radius: .circular(24.px),
        textAlign: .center,
      ),
      css('h2').styles(
        fontSize: 2.em,
        fontWeight: .w700,
        color: Colors.white,
        margin: .only(bottom: 0.5.em),
      ),
      css('p').styles(
        color: const Color('#ffffffcc'),
        fontSize: 1.125.em,
      ),
      css('.download-options').styles(
        display: .flex,
        alignItems: .center,
        justifyContent: .center,
        raw: {'gap': '2em'},
        margin: .only(top: 2.em, bottom: 1.5.em),
      ),
      css('.download-method').styles(
        textAlign: .center,
      ),
      css('.download-method h3').styles(
        color: Colors.white,
        fontSize: 1.em,
        fontWeight: .w600,
        margin: .only(bottom: 0.5.em),
      ),
      css('code').styles(
        display: .block,
        backgroundColor: const Color('#00000033'),
        padding: .symmetric(horizontal: 1.em, vertical: 0.75.em),
        radius: .circular(8.px),
        raw: {'font-family': 'monospace'},
        color: Colors.white,
      ),
      css('.divider').styles(
        color: const Color('#ffffff66'),
        fontWeight: .w500,
      ),
      css('.download-btn').styles(
        display: .inlineBlock,
        backgroundColor: Colors.white,
        color: gradientStart,
        padding: .symmetric(horizontal: 1.5.em, vertical: 0.75.em),
        radius: .circular(8.px),
        fontWeight: .w600,
        textDecoration: TextDecoration(line: .none),
        raw: {'transition': 'transform 0.2s'},
      ),
      css('.download-btn:hover').styles(
        raw: {'transform': 'scale(1.05)'},
      ),
      css('.requirements').styles(
        fontSize: 0.875.em,
        color: const Color('#ffffff99'),
        margin: .zero,
      ),
    ]),

    // Footer
    css('footer', [
      css('&').styles(
        raw: {'border-top': '1px solid #ffffff10'},
        padding: .symmetric(horizontal: 2.em, vertical: 2.em),
      ),
      css('.footer-content').styles(
        maxWidth: 1200.px,
        margin: .symmetric(horizontal: .auto),
        display: .flex,
        justifyContent: .spaceBetween,
        alignItems: .center,
      ),
      css('p').styles(
        color: mutedText,
        margin: .zero,
      ),
      css('.footer-links', [
        css('&').styles(
          display: .flex,
          raw: {'gap': '1.5em'},
        ),
        css('a').styles(
          color: mutedText,
          textDecoration: TextDecoration(line: .none),
        ),
        css('a:hover').styles(
          color: lightText,
        ),
      ]),
    ]),

    // Responsive
    css('@media (max-width: 900px)', [
      css('.hero').styles(
        flexDirection: .column,
        textAlign: .center,
      ),
      css('.hero-subtitle').styles(
        raw: {'max-width': 'none'},
      ),
      css('.hero-buttons').styles(
        justifyContent: .center,
      ),
      css('.features-grid').styles(
        raw: {'grid-template-columns': 'repeat(2, 1fr)'},
      ),
    ]),
    css('@media (max-width: 600px)', [
      css('.features-grid').styles(
        raw: {'grid-template-columns': '1fr'},
      ),
      css('.pricing-grid').styles(
        raw: {'grid-template-columns': '1fr'},
      ),
      css('.download-options').styles(
        flexDirection: .column,
      ),
    ]),
  ];
}
