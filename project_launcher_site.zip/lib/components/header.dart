import 'package:jaspr/dom.dart';
import 'package:jaspr/jaspr.dart';

import '../constants/theme.dart';

class Header extends StatelessComponent {
  const Header({super.key});

  @override
  Component build(BuildContext context) {
    return header([
      div(classes: 'header-content', [
        // Logo
        div(classes: 'logo', [
          span(classes: 'logo-icon', [.text('\u{1F680}')]),
          span([.text('Project Launcher')]),
        ]),
        // Nav links
        nav([
          a(href: '#features', [.text('Features')]),
          a(href: '#pricing', [.text('Pricing')]),
          a(href: '#download', [.text('Download')]),
          a(href: 'https://github.com/ff-vivek/project-launcher', attributes: {'target': '_blank'}, [.text('GitHub')]),
        ]),
        // CTA
        a(href: '#download', classes: 'cta-button', [.text('Download Free')]),
      ]),
    ]);
  }

  @css
  static List<StyleRule> get styles => [
    css('header', [
      css('&').styles(
        position: .fixed(),
        backgroundColor: darkBg.withOpacity(0.95),
        raw: {
          'top': '0',
          'left': '0',
          'right': '0',
          'z-index': '100',
          'backdrop-filter': 'blur(10px)',
          'border-bottom': '1px solid #ffffff10',
        },
      ),
      css('.header-content', [
        css('&').styles(
          display: .flex,
          maxWidth: 1200.px,
          margin: .symmetric(horizontal: .auto),
          padding: .symmetric(horizontal: 2.em, vertical: 1.em),
          alignItems: .center,
          justifyContent: .spaceBetween,
        ),
      ]),
      css('.logo', [
        css('&').styles(
          display: .flex,
          alignItems: .center,
          raw: {'gap': '0.5em'},
          fontSize: 1.25.em,
          fontWeight: .w700,
          color: lightText,
        ),
        css('.logo-icon').styles(
          fontSize: 1.5.em,
        ),
      ]),
      css('nav', [
        css('&').styles(
          display: .flex,
          raw: {'gap': '2em'},
        ),
        css('a').styles(
          color: mutedText,
          textDecoration: TextDecoration(line: .none),
          raw: {'transition': 'color 0.2s'},
        ),
        css('a:hover').styles(
          color: lightText,
        ),
      ]),
      css('.cta-button', [
        css('&').styles(
          display: .inlineBlock,
          padding: .symmetric(horizontal: 1.5.em, vertical: 0.75.em),
          backgroundColor: primaryColor,
          color: Colors.white,
          fontWeight: .w600,
          radius: .circular(8.px),
          textDecoration: TextDecoration(line: .none),
          raw: {'transition': 'background-color 0.2s'},
        ),
        css('&:hover').styles(
          backgroundColor: accentColor,
        ),
      ]),
    ]),
  ];
}
