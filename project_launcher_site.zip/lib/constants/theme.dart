import 'package:jaspr/dom.dart';

// Project Launcher brand colors
const primaryColor = Color('#5B7C99');
const accentColor = Color('#ACC7E3');
const darkBg = Color('#1A1C1E');
const darkSurface = Color('#2A2D31');
const lightText = Color('#E2E8F0');
const mutedText = Color('#9CA3AF');

// Gradient colors for Year in Review card
const gradientStart = Color('#667eea');
const gradientEnd = Color('#764ba2');

// Health score colors
const healthGreen = Color('#22C55E');
const healthOrange = Color('#F59E0B');
const healthRed = Color('#EF4444');
