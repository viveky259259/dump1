// dart format off
// ignore_for_file: type=lint

// GENERATED FILE, DO NOT MODIFY
// Generated with jaspr_builder

import 'package:jaspr/server.dart';
import 'package:project_launcher_site/components/header.dart' as _header;
import 'package:project_launcher_site/pages/home.dart' as _home;
import 'package:project_launcher_site/app.dart' as _app;

/// Default [ServerOptions] for use with your Jaspr project.
///
/// Use this to initialize Jaspr **before** calling [runApp].
///
/// Example:
/// ```dart
/// import 'main.server.options.dart';
///
/// void main() {
///   Jaspr.initializeApp(
///     options: defaultServerOptions,
///   );
///
///   runApp(...);
/// }
/// ```
ServerOptions get defaultServerOptions => ServerOptions(
  clientId: 'main.client.dart.js',
  clients: {_home.Home: ClientTarget<_home.Home>('home')},
  styles: () => [
    ..._header.Header.styles,
    ..._home.Home.styles,
    ..._app.App.styles,
  ],
);
