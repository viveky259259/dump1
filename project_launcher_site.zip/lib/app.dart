import 'package:jaspr/dom.dart';
import 'package:jaspr/jaspr.dart';

import 'components/header.dart';
import 'constants/theme.dart';
import 'pages/home.dart';

// The main component of your application.
class App extends StatelessComponent {
  const App({super.key});

  @override
  Component build(BuildContext context) {
    return div(classes: 'app', [
      const Header(),
      const Home(),
    ]);
  }

  @css
  static List<StyleRule> get styles => [
    // Global reset and base styles
    css('*', [
      css('&').styles(
        margin: .zero,
        padding: .zero,
        raw: {'box-sizing': 'border-box'},
      ),
    ]),
    css('html, body', [
      css('&').styles(
        raw: {
          'font-family': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, sans-serif',
          '-webkit-font-smoothing': 'antialiased',
        },
        backgroundColor: darkBg,
        color: lightText,
        lineHeight: 1.6.em,
      ),
    ]),
    css('a').styles(
      raw: {'color': 'inherit'},
    ),
    css('.app', [
      css('&').styles(
        minHeight: 100.vh,
      ),
    ]),
  ];
}
