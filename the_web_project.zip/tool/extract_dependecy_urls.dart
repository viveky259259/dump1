import 'dart:io';

/// Dart version of find_archive_urls.sh
///
/// Generates a allowlist of dependency URLs from pubspec.lock and writes
/// them to a file (default: ./allowlist_url.text).
///
/// - Hosted packages -> pub.dev/api/archives/<name>-<version>.tar.gz
/// - Git packages    -> <git_repo host-and-path only> (no scheme)
/// - Optional: parse an existing verbose log (-g/--log) and merge any
///   archive_url entries found there
/// - Optional: run a full verbose build (-a/--all) and deep-check that all
///   expected hosted URLs are observed in the logs (pub get + build)
///
/// Usage:
///   dart run tool/find_archive_urls.dart [--no-pub-get] [--lock PATH] [--output PATH] [--log PATH] [--all]
///     --no-pub-get  Do not run `flutter pub get` automatically
///     --lock, -k    Path to pubspec.lock (default: ./pubspec.lock)
///     --output      Output file path (default: ./allowlist_url.text)
///     --log, -g     Existing log file to parse archive_url entries from
Future<void> main(List<String> args) async {
  final options = _parseArgs(args);
  final bool skipPubGet = options.noPubGet;
  final String lockPath = options.lockPath;
  final String outputPath = options.outputPath;
  final String? logPath = options.logPath;

  // Ensure lock file exists or run `flutter pub get` if allowed.
  final lockFile = File(lockPath);
  if (!await lockFile.exists()) {
    if (skipPubGet) {
      _printErr(
          'pubspec.lock not found: $lockPath (run flutter pub get or omit --no-pub-get)');
      exit(2);
    }
    if (lockPath != 'pubspec.lock') {
      _printErr('pubspec.lock not found at custom path: $lockPath');
      exit(2);
    }
    await _ensureFlutter();
    _printErr('Running: flutter pub get');
    final result = await Process.run('flutter', ['pub', 'get']);
    if (result.exitCode != 0) {
      _printErr('flutter pub get failed:\n${result.stdout}${result.stderr}');
      exit(result.exitCode);
    }
    if (!await lockFile.exists()) {
      _printErr('pubspec.lock not found after flutter pub get');
      exit(2);
    }
  }

  final lines = await lockFile.readAsLines();
  final urlsSet = _extractAllowlistUrlsFromLock(lines).toSet();

  // Optional: merge archive URLs from a provided log file
  if (logPath != null && logPath.isNotEmpty) {
    final more = await _extractArchiveUrlsFromLogFile(logPath);
    urlsSet.addAll(more);
  }

  // Optional: deep check by running verbose pub get and build and verifying expected hosted URLs
  int exitCode = 0;

  // Write sorted unique list
  final urls = urlsSet.toList()..sort();
  final outFile = File(outputPath);
  await outFile.writeAsString(urls.join('\n') + (urls.isNotEmpty ? '\n' : ''));
  _printErr('Saved: $outputPath');
  if (exitCode != 0) exit(exitCode);
}

class _Options {
  final bool noPubGet;
  final String lockPath;
  final String outputPath;
  final String? logPath;
  _Options(
      {required this.noPubGet,
      required this.lockPath,
      required this.outputPath,
      required this.logPath});
}

_Options _parseArgs(List<String> args) {
  bool noPubGet = false;
  String lockPath = 'pubspec.lock';
  String outputPath = 'allowlist_url.text';
  String? logPath;

  for (int i = 0; i < args.length; i++) {
    final arg = args[i];
    switch (arg) {
      case '--no-pub-get':
        noPubGet = true;
        break;
      case '--lock':
      case '-k':
        if (i + 1 >= args.length) {
          _usage('Missing value for --lock');
        }
        lockPath = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          _usage('Missing value for --output');
        }
        outputPath = args[++i];
        break;
      case '--log':
      case '-g':
        if (i + 1 >= args.length) {
          _usage('Missing value for --log');
        }
        logPath = args[++i];
        break;
      case '-h':
      case '--help':
        _usage();
        break;
      default:
        _usage('Unknown argument: $arg');
    }
  }
  return _Options(
      noPubGet: noPubGet,
      lockPath: lockPath,
      outputPath: outputPath,
      logPath: logPath);
}

void _usage([String? error]) {
  if (error != null) {
    _printErr(error);
  }
  _printErr('''
Usage: dart run tool/find_archive_urls.dart [--no-pub-get] [--lock PATH] [--output PATH] [--log PATH] [--all]
  --no-pub-get          Do not run 'flutter pub get' automatically
  --lock, -k PATH       Path to pubspec.lock (default: ./pubspec.lock)
  --output PATH         Output file (default: ./allowlist_url.text)
  --log, -g PATH        Existing log file to merge archive_url entries from
''');
  exit(error == null ? 0 : 64);
}

Future<void> _ensureFlutter() async {
  final result = await Process.run(
    Platform.isWindows ? 'where' : 'which',
    [Platform.isWindows ? 'flutter.exe' : 'flutter'],
  );
  if (result.exitCode != 0) {
    _printErr('flutter not found on PATH');
    exit(2);
  }
}

Set<String> _extractAllowlistUrlsFromLock(List<String> lines) {
  final Set<String> urls = <String>{};

  bool inPackages = false;
  String? currentPkg;
  String source = '';
  String version = '';
  String gitUrl = '';

  void flush() {
    if (currentPkg == null) return;
    if (source == 'hosted' && version.isNotEmpty) {
      final encVersion = version.replaceAll('+', '%2B');
      urls.add(_stripScheme(
          'https://pub.dev/api/archives/${currentPkg!}-$encVersion.tar.gz'));
    } else if (source == 'git' && gitUrl.isNotEmpty) {
      urls.add(_toHostPathOnly(gitUrl));
    }
    currentPkg = null;
    source = '';
    version = '';
    gitUrl = '';
  }

  final nameRegex = RegExp(r'^\s{2}([A-Za-z0-9_]+):\s*$');
  final sourceRegex = RegExp(r'^\s{4}source:\s*([A-Za-z0-9_]+)');
  final versionRegex = RegExp(r'^\s{4}version:\s*"?([^"\s#]+)');
  final urlRegex = RegExp(r'^\s{6}url:\s*"?([^"\s]+)');

  for (final raw in lines) {
    final line = raw;

    if (line.startsWith('packages:')) {
      inPackages = true;
      continue;
    }
    if (line.startsWith('sdks:')) {
      // End of packages block
      break;
    }
    if (!inPackages) continue;

    final nameMatch = nameRegex.firstMatch(line);
    if (nameMatch != null) {
      flush();
      currentPkg = nameMatch.group(1);
      continue;
    }

    if (currentPkg != null) {
      final s = sourceRegex.firstMatch(line);
      if (s != null) {
        source = s.group(1) ?? '';
        continue;
      }
      final v = versionRegex.firstMatch(line);
      if (v != null) {
        version = v.group(1) ?? '';
        continue;
      }
      final u = urlRegex.firstMatch(line);
      if (u != null) {
        gitUrl = u.group(1) ?? '';
        continue;
      }
    }
  }

  // Flush last package
  flush();

  return urls;
}

class HostedEntry {
  final String package;
  final String version; // encoded with %2B
  String get url =>
      _stripScheme('https://pub.dev/api/archives/$package-$version.tar.gz');
  HostedEntry(this.package, this.version);
}

Future<Set<String>> _extractArchiveUrlsFromLogFile(String path) async {
  final file = File(path);
  if (!await file.exists()) {
    _printErr('Log file not found: $path');
    exit(2);
  }
  final content = await file.readAsString();
  return _extractArchiveUrlsFromContent(content);
}

Set<String> _extractArchiveUrlsFromContent(String content) {
  final Set<String> urls = {};

  String norm(String u) => _normalizeArchiveUrl(u);

  // 1) Match unescaped JSON: "archive_url":"https://pub.dev/api/archives/..."
  final regPlain = RegExp(
      r'"archive_url"\s*:\s*"(https:\/\/pub\.dev\/api\/archives\/[^"\s]+)"');
  for (final m in regPlain.allMatches(content)) {
    final u = m.group(1);
    if (u != null && u.isNotEmpty) {
      urls.add(_stripScheme(norm(u)));
    }
  }

  // 2) Match escaped JSON inside logs
  final regEscaped = RegExp(
      r'\\"archive_url\\"\s*:\s*\\"(https:\\/\\/pub\.dev\\/api\\/archives\\/[^\\"\s]+)\\"');
  for (final m in regEscaped.allMatches(content)) {
    final u = m.group(1);
    if (u != null && u.isNotEmpty) {
      urls.add(_stripScheme(norm(u)));
    }
  }

  // 3) Fallback: extract any bare archive URLs
  final regBare = RegExp(r'https:\/\/pub\.dev\/api\/archives\/[^\s\"\)]+');
  for (final m in regBare.allMatches(content)) {
    final u = m.group(0);
    if (u != null && u.isNotEmpty) {
      urls.add(_stripScheme(norm(u)));
    }
  }

  if (urls.isNotEmpty) return urls;

  // 4) Extra fallbacks if still empty
  var normalized = content;
  // strip ANSI color codes
  final ansi = RegExp(r'\x1B\[[0-9;]*m');
  normalized = normalized.replaceAll(ansi, '');
  // unescape common sequences
  normalized = normalized
      .replaceAll('\\/', '/')
      .replaceAll(' ', '')
      .replaceAll('\\u002F', '/')
      .replaceAll('\\"', '"')
      .replaceAll("\\'", "'");
  // single-quoted key/value variant
  final regSingle = RegExp(
      r"'archive_url'\s*:\s*'(?<u>https:\/\/pub\.dev\/api\/archives\/[^^'\s]+)'");
  for (final m in regSingle.allMatches(normalized)) {
    final u = m.namedGroup('u');
    if (u != null && u.isNotEmpty) {
      urls.add(_stripScheme(norm(u)));
    }
  }
  if (urls.isNotEmpty) return urls;

  // 5) Very broad: collapse newlines and scan for bare URLs again
  final collapsed = normalized.replaceAll('\n', ' ').replaceAll('\r', ' ');
  final regBareWide = RegExp(r'https://pub\.dev/api/archives/[^\s\"\)]+');
  for (final m in regBareWide.allMatches(collapsed)) {
    final u = m.group(0);
    if (u != null && u.isNotEmpty) {
      urls.add(_stripScheme(norm(u)));
    }
  }

  return urls;
}

String _normalizeArchiveUrl(String url) {
  var u = url.trim();
  // Unescape common sequences
  u = u.replaceAll('\\/', '/').replaceAll('\\u002F', '/');
  // Ensure '+' is encoded as %2B only inside the file component
  final m = RegExp(r'(/api/archives/)([^/]+)').firstMatch(u);
  if (m != null) {
    final prefix = m.group(1)!;
    final file = m.group(2)!;
    final fixedFile = file.replaceAll('+', '%2B');
    u = u.replaceFirst(prefix + file, prefix + fixedFile);
  }
  // Strip trailing punctuation that can leak from logs
  u = u.replaceAll(RegExp(r'[\),]$'), '');
  return u;
}

String _stripScheme(String url) {
  var u = url.trim();
  if (u.startsWith('http://')) return u.substring('http://'.length);
  if (u.startsWith('https://')) return u.substring('https://'.length);
  if (u.startsWith('ssh://')) return u.substring('ssh://'.length);
  if (u.startsWith('git@')) {
    // Convert scp-like form: git@host:org/repo(.git)
    final idxColon = u.indexOf(':');
    final idxAt = u.indexOf('@');
    if (idxColon > idxAt && idxAt >= 0) {
      final host = u.substring(idxAt + 1, idxColon);
      final rest = u.substring(idxColon + 1);
      return '$host/$rest';
    }
    return u.replaceFirst('git@', '');
  }
  return u;
}

String _toHostPathOnly(String url) {
  final noScheme = _stripScheme(url);
  // Convert host:path -> host/path if present
  final colonIndex = noScheme.indexOf(':');
  if (colonIndex > 0 && !noScheme.substring(0, colonIndex).contains('/')) {
    return noScheme.replaceFirst(':', '/');
  }
  return noScheme;
}

void _printErr(String msg) {
  stderr.writeln(msg);
}
