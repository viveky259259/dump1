## Allowlist URL Generation Flow

This flow shows how `extract_dependecy_urls.sh` and `tool/extract_dependecy_urls.dart` generate `allowlist_url.text` with entries formatted as host/path only (no scheme, no leading `@`), per the Zscaler guidelines: [URL format guidelines](https://help.zscaler.com/zia/url-format-guidelines).

```mermaid
flowchart TD
  A[Start] --> B{Choose tool}

  subgraph Shell[Shell: extract_dependecy_urls.sh]
    direction TB
    S1[Ensure pubspec.lock\n(run flutter pub get if needed)]
    S2[Extract hosted packages + versions]
    S3[Emit hosted URLs\npub.dev/api/archives/<name>-<ver>.tar.gz]
    S4[Extract git packages + URLs]
    S5[Normalize git URLs to host/path\nhttps/http/ssh/scp -> host/path]
    S6[Write to allowlist_url.text]
    S1 --> S2 --> S3 --> S4 --> S5 --> S6
  end

  subgraph Dart[Dart: tool/extract_dependecy_urls.dart]
    direction TB
    D1[Ensure pubspec.lock\n(optional flutter pub get)]
    D2[Parse lock: hosted + git]
    D3[Optional: parse logs for archive_url]
    D4[Normalize URLs to host/path\n(strip scheme, handle git@host:org/repo)]
    D5[Merge, sort unique]
    D6[Write to allowlist_url.text]
    D1 --> D2 --> D3 --> D4 --> D5 --> D6
  end

  B -->|Shell script| S1
  B -->|Dart tool| D1

  S6 --> Z[allowlist_url.text]
  D6 --> Z
```

### Notes
- Output entries look like `pub.dev/api/archives/<package>-<version>.tar.gz` or `github.com/org/repo.git`.
- The normalization removes `http://`, `https://`, `ssh://`, and converts `git@host:org/repo` to `host/org/repo`.


