## Analytics Prompt Library

Use these ready-to-run prompts to scaffold and extend analytics in this codebase. Replace placeholders like {{APP_ID}}, {{PROVIDER_NAME}}, {{SCREEN_NAME}}, {{EVENT_NAME}}.

### How to use this file
```text
Pick a template below, fill in placeholders, and paste into your AI/codegen tool. Prefer the shortest template that fits your task (Quick prompts → Task-specific → Examples). When editing existing code, instruct the model to modify only the minimal lines and to keep file structure and imports intact.
```

### Variable glossary
```text
{{APP_ID}}: MoEngage app id (non-empty string to enable MoEngage on mobile)
{{PROVIDER_NAME}}: Name of a new analytics SDK adapter (e.g., Firebase, Segment)
{{SCREEN_NAME}}: Stable, human-readable name (e.g., "checkout/success")
{{SCREEN_CLASS_OR_LEAVE_EMPTY}}: Optional Dart class name; defaults to screenName
{{EVENT_NAME}}: snake_case verb_noun (e.g., "purchase_completed")
{{KEY_VALUE_PROPERTIES}}: comma-separated key: value pairs for event properties
```

### Quick prompts (copy-paste)
```text
Instrument screen:
"Add a screen view for '{{SCREEN_NAME}}' using AnalyticsLocator.logScreenView with optional properties { {{KEY_VALUE_PROPERTIES}} }."

Instrument event:
"Add AnalyticsLocator.logEvent for '{{EVENT_NAME}}' with properties { {{KEY_VALUE_PROPERTIES}} }."

Identify user:
"On login success, call setUserId('{{USER_ID}}') and setUserProperties({ email: '{{EMAIL}}', name: '{{NAME}}' })."
```

### Scaffold analytics module (from scratch or sync)
```text
You are adding an analytics module identical in API and behavior to the existing design.
Implement the following Dart types and wiring:
- AnalyticsEvent: immutable with fields {name: String, properties: Map<String,dynamic> default {}, timestamp: DateTime?}
- AnalyticsProvider interface with methods:
  initialize(); setUserId(String); setUserProperty(String,Object?); setUserProperties(Map<String,Object?>);
  logEvent(AnalyticsEvent); logScreenView({required screenName, String? screenClass, Map<String,Object?> properties}); reset()
- NoOpAnalyticsProvider: implements AnalyticsProvider; methods complete successfully, count events in memory if helpful.
- AnalyticsManager: constructor takes List<AnalyticsProvider>; fans out every call to all providers in parallel; swallow individual provider errors.
- ConsoleAnalyticsProvider: uses dart:developer.log to log all calls in a readable format.
- MoEngageAnalyticsProvider: uses moengage_flutter; guard kIsWeb; set an _initialized flag in initialize(); map:
  identifyUser -> setUserId; setUserAttribute for properties; trackEvent(event.name, MoEProperties) for events;
  For screen views: trackEvent('screen_view', props with 'screen_name' and 'screen_class'). reset() -> logout().
- AnalyticsLocator.ensureInitialized({required String moengageAppId}):
  always include ConsoleAnalyticsProvider; include MoEngageAnalyticsProvider when moengageAppId is not empty AND not kIsWeb; return singleton AnalyticsManager.
- AnalyticsLocator.instance: asserts ensureInitialized() called first.

Acceptance criteria:
- Public API exactly matches: AnalyticsEvent, AnalyticsProvider, AnalyticsManager, AnalyticsLocator, ConsoleAnalyticsProvider, MoEngageAnalyticsProvider.
- Methods and parameter defaults mirror the existing implementation (esp. properties default empty map, screenClass fallback to screenName).
- Safe on web (MoEngage disabled), no provider error blocks others, compiles without lints.
```

### Initialize analytics at app start
```text
Add initialization at app startup:
- Call AnalyticsLocator.ensureInitialized(moengageAppId: '{{APP_ID}}');
- Then await AnalyticsLocator.instance.initialize();
Place this in the earliest suitable point (e.g., main() before runApp, or app bootstrap service).
```

### Set or update user identity
```text
Add code to associate the logged-in user with analytics:
- When a user logs in or is restored, call: await AnalyticsLocator.instance.setUserId('{{USER_ID}}');
- When profile data changes, call setUserProperties with a map of stable keys and simple values (Strings, nums, bools, Dates when supported):
  await AnalyticsLocator.instance.setUserProperties({
    'email': '{{EMAIL}}', 'name': '{{NAME}}', 'plan': '{{PLAN}}', 'is_paying': {{IS_PAYING}}
  });
```

### Log a custom event
```text
Instrument a custom business event. Follow naming: snake_case, verb_noun form, include key details as properties.
Add:
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent(
    '{{EVENT_NAME}}',
    properties: {
      // required context
      'source': '{{SOURCE}}',
      // event-specific fields
      {{KEY_VALUE_PROPERTIES}}
    },
  ),
);
```

### Few-shot examples
```text
Login success event
Add after a successful authentication flow:
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent(
    'login_success',
    properties: {
      'method': authProvider,
      'is_new_user': isFirstLogin,
    },
  ),
);

Product detail screen view
await AnalyticsLocator.instance.logScreenView(
  screenName: 'catalog/product_detail',
  properties: { 'product_id': product.id, 'category': product.category },
);
```

### Log a screen/view
```text
Instrument a screen view when the screen becomes visible.
Add:
await AnalyticsLocator.instance.logScreenView(
  screenName: '{{SCREEN_NAME}}',
  screenClass: '{{SCREEN_CLASS_OR_LEAVE_EMPTY}}',
  properties: { {{OPTIONAL_PROPERTIES}} },
);
Use a consistent screenName taxonomy (e.g., feature_area/screen). If screenClass is omitted, it defaults to screenName.
```

### Add a new analytics provider adapter
```text
Create {{PROVIDER_NAME}}AnalyticsProvider implementing AnalyticsProvider.
- initialize(): set up SDK; set an _initialized flag; be no-op on unsupported platforms.
- setUserId(): map to provider user identification call.
- setUserProperty()/setUserProperties(): map to provider user attribute APIs; iterate map entries.
- logEvent(): create provider properties and send event with event.name.
- logScreenView(): send an event compatible with the provider; include 'screen_name' and 'screen_class' props to match manager contract.
- reset(): map to provider logout/clear calls.
- Ensure exceptions are not thrown up; leave failures to AnalyticsManager’s guarded fan-out.
Wire it into AnalyticsLocator.ensureInitialized(...) with a flag or config.
```

### Guard web/mobile differences
```text
Ensure analytics behaves safely on Flutter Web:
- Keep ConsoleAnalyticsProvider enabled on all platforms.
- Disable SDKs not supporting web (e.g., MoEngage) by checking kIsWeb before initializing/using them.
- Maintain identical public APIs so app code is platform-agnostic.
```

### Logout/reset analytics on sign-out
```text
On user sign-out, call:
await AnalyticsLocator.instance.reset();
Then, if needed, clear local user state and reinitialize providers when a new session begins.
```

### Testing / local dev
```text
For tests and local dev where external SDKs are undesirable:
- Use NoOpAnalyticsProvider only, or rely on ConsoleAnalyticsProvider logs.
- Verify call counts and payload shapes via console output.
- Ensure no exceptions bubble when a provider fails; other providers must still receive events.
```

### Event naming and property guidelines
```text
- Use snake_case for event names (e.g., add_to_cart, purchase_completed).
- Prefer flat, primitive properties; avoid nested maps/collections unless required by provider.
- Include identifiers and quantitative values (ids, counts, amounts, currencies, durations).
- Avoid PII beyond what is explicitly allowed; use hashed values when necessary.
- Keep property keys stable; do not change semantics without a migration plan.
```

### Example: instrument checkout success
```text
At the point the checkout success screen renders or when payment is confirmed, add:
await AnalyticsLocator.instance.logEvent(
  AnalyticsEvent(
    'purchase_completed',
    properties: {
      'order_id': order.id,
      'value': order.total,
      'currency': order.currency,
      'items_count': order.items.length,
      'payment_method': order.paymentMethod,
    },
  ),
);
await AnalyticsLocator.instance.logScreenView(
  screenName: 'checkout/success',
  properties: { 'order_id': order.id },
);
```

### Guardrails for code generation
```text
- Do not reformat unrelated code. Change only the lines required for the task.
- Preserve imports and file structure; avoid moving code unless requested.
- Respect the AnalyticsProvider contract exactly. Do not rename public APIs.
- For unsupported platforms (web for MoEngage), no-op safely without throwing.
- In AnalyticsManager, swallow individual provider errors to avoid blocking others.
```

### Review checklist (use before merging)
```text
- [ ] API parity with AnalyticsProvider contract
- [ ] Platform guards (kIsWeb) in unsupported SDKs
- [ ] Fan-out errors are swallowed per provider
- [ ] Console logging is informative and structured
- [ ] Screen views include screen_name and screen_class
- [ ] Initialization occurs once and before first event
- [ ] Reset/logout is wired to sign-out flow
- [ ] Names and properties follow guidelines
```
