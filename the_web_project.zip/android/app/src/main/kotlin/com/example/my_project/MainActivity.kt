package com.mycompany.thewebproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
