// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom widgets

import 'dart:ui_web' as ui_web;
import 'package:web/web.dart' as web;
import 'dart:js_interop';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';

class HtmlElementViewExample extends StatefulWidget {
  const HtmlElementViewExample({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<HtmlElementViewExample> createState() => _HtmlElementViewExampleState();
}

class _HtmlElementViewExampleState extends State<HtmlElementViewExample> {
  final htmlViewType = 'html_element';
  @override
  void initState() {
    super.initState();
    registerHtmlFactory();
  }

  void registerHtmlFactory() {
    ui_web.platformViewRegistry.registerViewFactory(htmlViewType, (
      int viewId, {
      Object? params,
    }) {
      web.HTMLDivElement htmlDivElement = web.HTMLDivElement();
      htmlDivElement.style.width = '100%';
      htmlDivElement.style.height = '100%';
      // Insert the script before the closing body tag if it exists, otherwise append

      htmlDivElement.innerHTML = html.toJS;
      return htmlDivElement;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: widget.width,
        height: widget.height,
        child: HtmlElementView(viewType: htmlViewType));
  }

  final html = FFAppConstants.htmlContent;
}
