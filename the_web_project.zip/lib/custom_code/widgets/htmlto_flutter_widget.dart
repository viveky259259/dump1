// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom widgets

import 'package:flutter_html/flutter_html.dart';

class HtmltoFlutterWidget extends StatefulWidget {
  const HtmltoFlutterWidget({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<HtmltoFlutterWidget> createState() => _HtmltoFlutterWidgetState();
}

class _HtmltoFlutterWidgetState extends State<HtmltoFlutterWidget> {
  @override
  Widget build(BuildContext context) {
    return Html(data: FFAppConstants.htmlContent);
  }
}
