import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'webview_example_widget.dart' show WebviewExampleWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WebviewExampleModel extends FlutterFlowModel<WebviewExampleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
