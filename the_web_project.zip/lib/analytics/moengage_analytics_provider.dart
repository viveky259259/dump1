import 'package:flutter/foundation.dart';
import 'package:moengage_flutter/moengage_flutter.dart';

import 'analytics_event.dart';
import 'analytics_provider.dart';

/// MoEngage provider implementation.
class MoEngageAnalyticsProvider implements AnalyticsProvider {
  MoEngageAnalyticsProvider({required String appId})
      : _moePlugin = MoEngageFlutter(appId);

  final MoEngageFlutter _moePlugin;

  bool _initialized = false;

  @override
  Future<void> initialize() async {
    if (kIsWeb) {
      // MoEngage Flutter SDK is not supported on Flutter web as of now.
      return;
    }
    _initialized = true;
  }

  @override
  Future<void> setUserId(String userId) async {
    if (!_initialized) return;
    _moePlugin.identifyUser(userId);
  }

  @override
  Future<void> setUserProperty(String key, Object? value) async {
    if (!_initialized) return;
    _moePlugin.setUserAttribute(key, value);
  }

  @override
  Future<void> setUserProperties(Map<String, Object?> properties) async {
    if (!_initialized) return;
    for (final MapEntry<String, Object?> entry in properties.entries) {
      _moePlugin.setUserAttribute(entry.key, entry.value);
    }
  }

  @override
  Future<void> logEvent(AnalyticsEvent event) async {
    if (!_initialized) return;
    final MoEProperties props = MoEProperties();
    event.properties.forEach((String key, dynamic value) {
      props.addAttribute(key, value);
    });
    _moePlugin.trackEvent(event.name, props);
  }

  @override
  Future<void> logScreenView({
    required String screenName,
    String? screenClass,
    Map<String, Object?> properties = const <String, Object?>{},
  }) async {
    if (!_initialized) return;
    final MoEProperties props = MoEProperties();
    properties.forEach((String key, Object? value) {
      props.addAttribute(key, value);
    });
    props.addAttribute('screen_name', screenName);
    props.addAttribute('screen_class', screenClass ?? screenName);
    _moePlugin.trackEvent('screen_view', props);
  }

  @override
  Future<void> reset() async {
    if (!_initialized) return;
    _moePlugin.logout();
  }
}
