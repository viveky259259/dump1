import 'package:flutter/foundation.dart';

import 'analytics_event.dart';

/// Contract for any analytics provider (e.g., MoEngage, Firebase, Segment).
abstract class AnalyticsProvider {
  Future<void> initialize();

  Future<void> setUserId(String userId);
  Future<void> setUserProperty(String key, Object? value);
  Future<void> setUserProperties(Map<String, Object?> properties);

  Future<void> logEvent(AnalyticsEvent event);

  Future<void> logScreenView({
    required String screenName,
    String? screenClass,
    Map<String, Object?> properties,
  });

  Future<void> reset();
}

/// A no-op provider to use on unsupported platforms or for tests.
class NoOpAnalyticsProvider implements AnalyticsProvider {
  @visibleForTesting
  int eventsCount = 0;

  @override
  Future<void> initialize() async {}

  @override
  Future<void> setUserId(String userId) async {}

  @override
  Future<void> setUserProperty(String key, Object? value) async {}

  @override
  Future<void> setUserProperties(Map<String, Object?> properties) async {}

  @override
  Future<void> logEvent(AnalyticsEvent event) async {
    eventsCount++;
  }

  @override
  Future<void> logScreenView({
    required String screenName,
    String? screenClass,
    Map<String, Object?> properties = const <String, Object?>{},
  }) async {
    eventsCount++;
  }

  @override
  Future<void> reset() async {}
}
