import 'dart:developer' as developer;

import 'analytics_event.dart';
import 'analytics_provider.dart';

class ConsoleAnalyticsProvider implements AnalyticsProvider {
  @override
  Future<void> initialize() async {}

  @override
  Future<void> setUserId(String userId) async {
    developer.log('analytics setUserId: $userId', name: 'Analytics');
  }

  @override
  Future<void> setUserProperty(String key, Object? value) async {
    developer.log('analytics setUserProperty: $key=$value', name: 'Analytics');
  }

  @override
  Future<void> setUserProperties(Map<String, Object?> properties) async {
    developer.log('analytics setUserProperties: $properties',
        name: 'Analytics');
  }

  @override
  Future<void> logEvent(AnalyticsEvent event) async {
    developer.log('analytics event: ${event.name} ${event.properties}',
        name: 'Analytics');
  }

  @override
  Future<void> logScreenView({
    required String screenName,
    String? screenClass,
    Map<String, Object?> properties = const <String, Object?>{},
  }) async {
    developer.log(
      'analytics screen: $screenName class=${screenClass ?? screenName} properties=$properties',
      name: 'Analytics',
    );
  }

  @override
  Future<void> reset() async {}
}
