import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'html_element_view_page_model.dart';
export 'html_element_view_page_model.dart';

class HtmlElementViewPageWidget extends StatefulWidget {
  const HtmlElementViewPageWidget({super.key});

  static String routeName = 'HtmlElementViewPage';
  static String routePath = '/htmlElementViewPage';

  @override
  State<HtmlElementViewPageWidget> createState() =>
      _HtmlElementViewPageWidgetState();
}

class _HtmlElementViewPageWidgetState extends State<HtmlElementViewPageWidget> {
  late HtmlElementViewPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HtmlElementViewPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Container(
                  width: double.infinity,
                  height: 500.0,
                  child: custom_widgets.HtmlElementViewExample(
                    width: double.infinity,
                    height: 500.0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
