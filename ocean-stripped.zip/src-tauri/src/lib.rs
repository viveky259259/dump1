pub mod a2ui;
pub mod connectors;
pub mod db;
pub mod filesystem;
pub mod git_translate;
pub mod metrics;
pub mod pty;
pub mod session;
pub mod terminal;

use db::Database;
use filesystem::conflict::ConflictDetector;
use filesystem::FilesystemManager;
use metrics::MetricsCollector;
use parking_lot::Mutex;
use pty::PtyManager;
use session::activity::StatusChange;
use session::SessionManager;
use std::sync::Arc;
use tauri::{Emitter, Manager};

// Tauri IPC Commands

#[tauri::command]
fn create_workspace(
    name: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<db::Workspace, String> {
    session_manager.create_workspace(&name)
}

#[tauri::command]
fn respawn_sessions(
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<Vec<db::Session>, String> {
    session_manager.respawn_stale_sessions()
}

#[tauri::command]
fn list_workspaces(
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<Vec<db::Workspace>, String> {
    session_manager.list_workspaces()
}

#[tauri::command]
fn create_session(
    workspace_id: String,
    parent_id: Option<String>,
    name: Option<String>,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<db::Session, String> {
    session_manager.create_session(
        &workspace_id,
        parent_id.as_deref(),
        name.as_deref(),
    )
}

#[tauri::command]
fn close_session(
    session_id: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<(), String> {
    session_manager.close_session(&session_id)
}

#[tauri::command]
fn list_sessions(
    workspace_id: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<Vec<db::Session>, String> {
    session_manager.list_sessions(&workspace_id)
}

#[tauri::command]
fn get_session_tree(
    workspace_id: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<Vec<session::SessionTreeNode>, String> {
    session_manager.get_session_tree(&workspace_id)
}

#[tauri::command]
fn write_pty(
    session_id: String,
    data: String,
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<(), String> {
    pty_manager.write(&session_id, &data)
}

#[tauri::command]
fn resize_pty(
    session_id: String,
    cols: u16,
    rows: u16,
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<(), String> {
    pty_manager.resize(&session_id, cols, rows)
}

#[tauri::command]
async fn get_system_metrics(
    metrics_collector: tauri::State<'_, Arc<MetricsCollector>>,
) -> Result<metrics::SystemMetrics, String> {
    Ok(metrics_collector.get_system_metrics().await)
}

#[tauri::command]
async fn get_network_status(
    metrics_collector: tauri::State<'_, Arc<MetricsCollector>>,
) -> Result<metrics::NetworkStatus, String> {
    Ok(metrics_collector.get_network_status().await)
}

#[tauri::command]
async fn get_git_status(repo_path: String) -> Result<metrics::GitStatus, String> {
    tokio::task::spawn_blocking(move || MetricsCollector::get_git_status(&repo_path))
        .await
        .map_err(|e| format!("Git status task failed: {}", e))?
}

#[tauri::command]
fn watch_git_repo(
    repo_path: String,
    metrics_collector: tauri::State<'_, Arc<MetricsCollector>>,
    app_handle: tauri::AppHandle,
) -> Result<(), String> {
    let path = std::path::Path::new(&repo_path);
    if path.join(".git").exists() {
        metrics_collector.watch_git_repo(repo_path, app_handle);
        Ok(())
    } else {
        Err(format!("Not a git repository: {}", repo_path))
    }
}

#[tauri::command]
async fn get_process_metrics(
    pid: u32,
    metrics_collector: tauri::State<'_, Arc<MetricsCollector>>,
) -> Result<metrics::ProcessMetrics, String> {
    metrics_collector
        .get_process_metrics(pid)
        .await
        .ok_or_else(|| format!("No process found with PID {}", pid))
}

#[tauri::command]
fn get_annotations(
    session_id: String,
    line_start: usize,
    line_end: usize,
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<Vec<terminal::Annotation>, String> {
    let annotator = pty_manager.get_annotator();
    Ok(annotator.get_annotations(&session_id, line_start, line_end))
}

#[tauri::command]
fn rename_session(
    session_id: String,
    name: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<(), String> {
    let db = session_manager.db().lock();
    db.rename_session(&session_id, &name).map_err(|e| e.to_string())
}

#[tauri::command]
fn clear_all_sessions(
    session_manager: tauri::State<'_, Arc<SessionManager>>,
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<(), String> {
    // Close all live PTYs
    let active = session_manager.get_active_session_ids();
    for (session_id, _, _, _) in &active {
        let _ = pty_manager.close(session_id);
    }
    // Wipe the database
    let db = session_manager.db().lock();
    db.clear_all().map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn read_file(
    path: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<String, String> {
    let canonical = std::fs::canonicalize(&path)
        .map_err(|e| format!("Invalid path {}: {}", path, e))?;
    let canonical_str = canonical.to_string_lossy();

    // Allow reads within ~/.ocean/ (workspace data)
    let ocean_dir = dirs_next::home_dir()
        .unwrap_or_default()
        .join(".ocean");
    let ocean_ok = canonical.starts_with(&ocean_dir);

    // Allow reads within any known workspace repo_path
    let repo_ok = {
        let db = session_manager.db().lock();
        db.list_workspaces()
            .unwrap_or_default()
            .iter()
            .any(|ws| {
                ws.repo_path
                    .as_ref()
                    .map(|rp| canonical_str.starts_with(rp.as_str()))
                    .unwrap_or(false)
            })
    };

    if !ocean_ok && !repo_ok {
        return Err(format!(
            "Access denied: {} is outside workspace directories",
            path
        ));
    }

    std::fs::read_to_string(&canonical)
        .map_err(|e| format!("Failed to read {}: {}", path, e))
}

#[derive(serde::Serialize)]
struct FileConflictDetail {
    file_path: String,
    base_content: String,
    versions: Vec<FileVersion>,
}

#[derive(serde::Serialize)]
struct FileVersion {
    session_id: String,
    session_name: String,
    content: String,
}

#[tauri::command]
fn get_conflict_details(
    workspace_id: String,
    file_path: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
    fs_manager: tauri::State<'_, Arc<FilesystemManager>>,
) -> Result<FileConflictDetail, String> {
    let base_dir = fs_manager.base_dir_pub(&workspace_id);
    let base_file = base_dir.join(&file_path);
    let base_content = std::fs::read_to_string(&base_file)
        .unwrap_or_else(|_| "(file does not exist in base)".to_string());

    // Get all active sessions' versions of this file
    let db = session_manager.db().lock();
    let sessions = db.list_sessions(&workspace_id).map_err(|e| e.to_string())?;
    drop(db);

    let mut versions = Vec::new();
    for session in &sessions {
        if session.status != "active" && session.status != "idle" && session.status != "waiting" {
            continue;
        }
        let session_dir = fs_manager.session_dir_pub(&workspace_id, &session.id);
        let session_file = session_dir.join(&file_path);
        if session_file.exists() {
            if let Ok(content) = std::fs::read_to_string(&session_file) {
                // Only include if different from base
                if content != base_content {
                    versions.push(FileVersion {
                        session_id: session.id.clone(),
                        session_name: session.name.clone(),
                        content,
                    });
                }
            }
        }
    }

    Ok(FileConflictDetail {
        file_path,
        base_content,
        versions,
    })
}

#[tauri::command]
fn resolve_conflict(
    workspace_id: String,
    file_path: String,
    resolution: String, // "accept:<session_id>"
    fs_manager: tauri::State<'_, Arc<FilesystemManager>>,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<(), String> {
    let base_dir = fs_manager.base_dir_pub(&workspace_id);
    let base_file = base_dir.join(&file_path);

    if resolution.starts_with("accept:") {
        let session_id = resolution.strip_prefix("accept:").unwrap();
        let session_dir = fs_manager.session_dir_pub(&workspace_id, session_id);
        let session_file = session_dir.join(&file_path);

        if !session_file.exists() {
            return Err(format!(
                "Session file does not exist: {}",
                session_file.display()
            ));
        }

        // Copy session version → base snapshot
        if let Some(parent) = base_file.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Failed to create base directory: {}", e))?;
        }
        std::fs::copy(&session_file, &base_file)
            .map_err(|e| format!("Failed to copy to base: {}", e))?;

        // Also copy to the original repo so the user's project files are updated
        let db = session_manager.db().lock();
        let workspace = db.get_workspace(&workspace_id).map_err(|e| e.to_string())?;
        drop(db);

        if let Some(repo_path) = &workspace.repo_path {
            let repo_file = std::path::Path::new(repo_path).join(&file_path);
            if let Some(parent) = repo_file.parent() {
                std::fs::create_dir_all(parent)
                    .map_err(|e| format!("Failed to create repo directory: {}", e))?;
            }
            std::fs::copy(&session_file, &repo_file)
                .map_err(|e| format!("Failed to copy to repo: {}", e))?;
            log::info!(
                "Conflict resolved: {} → base + repo ({})",
                file_path,
                repo_path
            );
        } else {
            log::info!("Conflict resolved: {} → base only (no repo_path)", file_path);
        }

        // Also update the OTHER sessions' copies so they pick up the resolved version
        let db = session_manager.db().lock();
        let sessions = db.list_sessions(&workspace_id).map_err(|e| e.to_string())?;
        drop(db);

        for s in &sessions {
            if s.id == session_id {
                continue; // Skip the accepted session
            }
            if s.status != "active" && s.status != "idle" && s.status != "waiting" {
                continue;
            }
            let other_dir = fs_manager.session_dir_pub(&workspace_id, &s.id);
            let other_file = other_dir.join(&file_path);
            if other_dir.exists() {
                if let Some(parent) = other_file.parent() {
                    let _ = std::fs::create_dir_all(parent);
                }
                let _ = std::fs::copy(&session_file, &other_file);
            }
        }
    } else {
        return Err(format!(
            "Unknown resolution strategy: {}. Use 'accept:<session_id>'.",
            resolution
        ));
    }

    Ok(())
}

#[tauri::command]
fn execute_annotation_action(action_command: String) -> Result<(), String> {
    match action_command.split_once(':') {
        Some(("open_url", url)) => {
            open::that(url).map_err(|e| e.to_string())?;
        }
        Some(("open_finder", path)) => {
            std::process::Command::new("open")
                .arg("-R")
                .arg(path)
                .spawn()
                .map_err(|e| e.to_string())?;
        }
        Some(("open_editor", rest)) => {
            let editor = std::env::var("VISUAL")
                .or_else(|_| std::env::var("EDITOR"))
                .unwrap_or_else(|_| "code".to_string());
            let parts: Vec<&str> = rest.splitn(2, ':').collect();
            let path = parts[0];
            let mut cmd = std::process::Command::new(&editor);
            if editor.contains("code") {
                // VS Code: --goto path:line
                cmd.arg("--goto").arg(rest);
            } else {
                cmd.arg(path);
                if parts.len() > 1 {
                    // For vim-like: +line path
                    cmd.arg(format!("+{}", parts[1]));
                }
            }
            cmd.spawn().map_err(|e| e.to_string())?;
        }
        _ => {}
    }
    Ok(())
}

// Phase 7: A2UI — send structured UI response back to the PTY process
#[tauri::command]
fn a2ui_respond(
    session_id: String,
    component_id: String,
    action: String,
    data: serde_json::Value,
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<(), String> {
    let response = serde_json::json!({
        "ocean_a2ui_response": {
            "component_id": component_id,
            "action": action,
            "data": data,
        }
    });
    let line = format!("{}\n", response.to_string());
    pty_manager.write(&session_id, &line)
}

// Phase 4+5: COW Filesystem + Git Translation commands

#[tauri::command]
fn create_workspace_with_repo(
    name: String,
    repo_path: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<db::Workspace, String> {
    session_manager.create_workspace_with_repo(&name, &repo_path)
}

#[tauri::command]
fn get_session_delta(
    workspace_id: String,
    session_id: String,
    fs_manager: tauri::State<'_, Arc<FilesystemManager>>,
) -> Result<filesystem::DeltaInfo, String> {
    fs_manager.get_session_delta(&workspace_id, &session_id)
}

#[tauri::command]
fn merge_session(
    workspace_id: String,
    session_id: String,
    fs_manager: tauri::State<'_, Arc<FilesystemManager>>,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
    conflict_detector: tauri::State<'_, Arc<ConflictDetector>>,
) -> Result<filesystem::MergeResult, String> {
    let result = fs_manager.merge_session_to_base(&workspace_id, &session_id)?;

    // Update session state in DB
    let db = session_manager.db().lock();
    let _ = db.update_session_state_merged(&session_id, true);

    // Clear conflict tracking for this session since it's been merged
    conflict_detector.clear_session(&session_id);

    Ok(result)
}

#[tauri::command]
fn get_conflicts(
    workspace_id: String,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
    fs_manager: tauri::State<'_, Arc<FilesystemManager>>,
    conflict_detector: tauri::State<'_, Arc<ConflictDetector>>,
) -> Result<Vec<filesystem::conflict::ConflictAlert>, String> {
    // Refresh conflict data: get deltas for all active sessions in workspace
    let db = session_manager.db().lock();
    let sessions = db.list_sessions(&workspace_id).map_err(|e| e.to_string())?;
    drop(db);

    for session in &sessions {
        if session.status == "active" || session.status == "idle" || session.status == "waiting" {
            if let Ok(delta) = fs_manager.get_session_delta(&workspace_id, &session.id) {
                conflict_detector.register_delta(&session.id, &session.name, &delta);
            }
        }
    }

    Ok(conflict_detector.check_conflicts())
}

#[tauri::command]
fn translate_to_commit(
    session_id: String,
    message: Option<String>,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
    fs_manager: tauri::State<'_, Arc<FilesystemManager>>,
) -> Result<String, String> {
    let db = session_manager.db().lock();
    let session = db.get_session(&session_id).map_err(|e| e.to_string())?;
    let workspace = db.get_workspace(&session.workspace_id).map_err(|e| e.to_string())?;
    drop(db);

    let repo_path = workspace
        .base_snapshot_path
        .as_ref()
        .or(workspace.repo_path.as_ref())
        .ok_or_else(|| "Workspace has no associated repo path".to_string())?;

    // First merge session changes to base
    let merge_result = fs_manager.merge_session_to_base(&workspace.id, &session_id)?;

    if merge_result.merged_files.is_empty() && merge_result.deleted_files.is_empty() {
        return Err("No changes to commit".to_string());
    }

    // Get the delta info for the commit
    let delta = filesystem::DeltaInfo {
        workspace_id: workspace.id.clone(),
        session_id: session_id.clone(),
        modified_files: merge_result.merged_files.clone(),
        created_files: Vec::new(),
        deleted_files: merge_result.deleted_files.clone(),
        delta_size_bytes: 0,
    };

    let commit_hash = git_translate::session_to_commit(
        repo_path,
        &session_id,
        &session.name,
        &delta,
        message.as_deref(),
    )?;

    // Update session state with commit hash
    let db = session_manager.db().lock();
    let _ = db.update_session_state_git_commit(&session_id, &commit_hash);

    Ok(commit_hash)
}

#[tauri::command]
fn ship_workspace(
    workspace_id: String,
    title: String,
    body: Option<String>,
    session_manager: tauri::State<'_, Arc<SessionManager>>,
) -> Result<git_translate::ShipResult, String> {
    let db = session_manager.db().lock();
    let workspace = db.get_workspace(&workspace_id).map_err(|e| e.to_string())?;
    drop(db);

    let repo_path = workspace
        .base_snapshot_path
        .as_ref()
        .or(workspace.repo_path.as_ref())
        .ok_or_else(|| "Workspace has no associated repo path".to_string())?;

    let pr_body = body.unwrap_or_else(|| {
        format!("Created via Ocean workspace: {}", workspace.name)
    });

    let result = git_translate::create_workspace_pr(
        repo_path,
        &workspace.name,
        &title,
        &pr_body,
    )?;

    // Update workspace with git info
    let db = session_manager.db().lock();
    let _ = db.update_workspace_git(
        &workspace_id,
        Some(&result.branch_name),
        result.pr_url.as_deref(),
    );

    Ok(result)
}

// Phase 8: Parallel Execution Connectors

#[tauri::command]
fn get_connectors(
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<Vec<connectors::ConnectorGroup>, String> {
    let sessions = pty_manager.get_active_pids();
    let mut detector = connectors::detector::AutoDetector::new();
    Ok(detector.detect_connectors(&sessions))
}

#[tauri::command]
fn kill_connector_group(
    group_id: String,
    pty_manager: tauri::State<'_, Arc<PtyManager>>,
) -> Result<(), String> {
    // Find the connector group by running detection first
    let sessions = pty_manager.get_active_pids();
    let mut detector = connectors::detector::AutoDetector::new();
    let groups = detector.detect_connectors(&sessions);

    let group = groups
        .iter()
        .find(|g| g.id == group_id)
        .ok_or_else(|| format!("Connector group not found: {}", group_id))?;

    // Kill each process in the group via the `kill` command
    for process in &group.sessions {
        if process.pid > 0 {
            let _ = std::process::Command::new("kill")
                .arg("-TERM")
                .arg(process.pid.to_string())
                .output();
        }
    }

    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    env_logger::init();

    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_notification::init())
        .setup(|app| {
            let db_path = dirs_next::home_dir()
                .map(|h| h.join(".ocean").join("ocean.db"));

            let database = Database::new(db_path)
                .expect("Failed to initialize database");

            let db = Arc::new(Mutex::new(database));
            let pty = Arc::new(PtyManager::new());
            let fs = Arc::new(FilesystemManager::new());
            let conflict_detector = Arc::new(ConflictDetector::new());

            let session_manager = Arc::new(SessionManager::new(
                db.clone(),
                pty.clone(),
                fs.clone(),
                app.handle().clone(),
            ));

            app.manage(session_manager.clone());
            app.manage(pty.clone());
            app.manage(fs.clone());
            app.manage(conflict_detector.clone());

            // Respawn stale sessions BEFORE the status loop starts —
            // this prevents the race where the status loop marks them
            // "completed" before the frontend can call respawn_sessions.
            match session_manager.respawn_stale_sessions() {
                Ok(revived) if !revived.is_empty() => {
                    log::info!("Respawned {} sessions from previous run", revived.len());
                }
                Ok(_) => {
                    log::info!("No stale sessions to respawn");
                }
                Err(e) => {
                    log::error!("Failed to respawn stale sessions: {}", e);
                    // Fall back: mark remaining stale sessions as completed
                    let db_lock = db.lock();
                    let _ = db_lock.mark_stale_sessions();
                }
            }

            // Initialize and start the metrics collector
            let metrics_collector = Arc::new(MetricsCollector::new());
            metrics_collector.start(app.handle().clone());

            // Only start git watching if CWD is inside a git repo
            // (don't scan random directories — watch when the user is actually in a project)
            let cwd = std::env::current_dir().unwrap_or_default();
            // Walk up from CWD to find the nearest .git directory
            let mut check_path = Some(cwd.as_path());
            while let Some(p) = check_path {
                if p.join(".git").exists() {
                    log::info!("CWD is inside git repo, starting watcher for: {}", p.display());
                    metrics_collector.watch_git_repo(
                        p.to_string_lossy().to_string(),
                        app.handle().clone(),
                    );
                    break;
                }
                check_path = p.parent();
            }

            // Also add a Tauri command to start watching a specific repo
            // (frontend can call this when session CWD changes)

            app.manage(metrics_collector);

            // Spawn connector detection polling loop (every 5s)
            let connector_pty = pty.clone();
            let connector_app_handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                // Reuse detector (and its System instance) across iterations
                let detector = Arc::new(Mutex::new(connectors::detector::AutoDetector::new()));
                loop {
                    tokio::time::sleep(std::time::Duration::from_secs(5)).await;
                    let sessions = connector_pty.get_active_pids();
                    if sessions.is_empty() {
                        continue;
                    }
                    let det = detector.clone();
                    let groups: Result<Vec<connectors::ConnectorGroup>, _> =
                        tokio::task::spawn_blocking(move || {
                            let mut d = det.lock();
                            d.detect_connectors(&sessions)
                        })
                        .await;
                    match groups {
                        Ok(g) if !g.is_empty() => {
                            let _ = connector_app_handle.emit("connector-update", &g);
                        }
                        _ => {
                            // Emit empty array to signal no connectors detected
                            let _ = connector_app_handle.emit(
                                "connector-update",
                                &Vec::<connectors::ConnectorGroup>::new(),
                            );
                        }
                    }
                }
            });

            // Spawn session status checking loop
            let status_session_manager = session_manager;
            let status_pty = pty;
            let status_db = db;
            let status_app_handle = app.handle().clone();

            tauri::async_runtime::spawn(async move {
                use tauri_plugin_notification::NotificationExt;

                let activity_tracker = status_pty.get_activity_tracker();

                loop {
                    tokio::time::sleep(std::time::Duration::from_secs(5)).await;

                    let active_sessions = status_session_manager.get_active_session_ids();

                    for (session_id, current_status, session_name, workspace_id) in &active_sessions {
                        // Check if PTY is still alive in our map
                        let pty_alive = status_pty.is_alive(session_id);

                        if !pty_alive {
                            // Double-check: the PTY might still be initializing.
                            // Only mark as dead if the session has been around for >10 seconds.
                            let db = status_db.lock();
                            let session = match db.get_session(session_id) {
                                Ok(s) => s,
                                Err(_) => continue,
                            };
                            drop(db);

                            // Parse created_at and check age
                            let age_ok = if let Ok(created) = chrono::DateTime::parse_from_rfc3339(&session.created_at) {
                                chrono::Utc::now().signed_duration_since(created).num_seconds() > 10
                            } else {
                                true // can't parse, assume old
                            };

                            if !age_ok {
                                continue; // too young, skip — PTY may still be spawning
                            }

                            // PTY died — mark as completed if still active
                            if current_status != "completed" && current_status != "failed" {
                                let new_status = "completed";
                                if let Err(e) = status_db
                                    .lock()
                                    .update_session_status(session_id, new_status)
                                {
                                    log::error!(
                                        "Failed to update session {} status: {}",
                                        session_id,
                                        e
                                    );
                                    continue;
                                }

                                let change = StatusChange {
                                    session_id: session_id.clone(),
                                    old_status: current_status.clone(),
                                    new_status: new_status.to_string(),
                                };
                                let _ = status_app_handle.emit("session-status-changed", &change);

                                activity_tracker.remove_session(session_id);

                                // Check if all sessions in workspace are completed
                                let all_completed = active_sessions
                                    .iter()
                                    .filter(|(_, _, _, wid)| wid == workspace_id)
                                    .all(|(sid, _, _, _)| sid == session_id);

                                if all_completed {
                                    let _ = status_app_handle
                                        .notification()
                                        .builder()
                                        .title("Workspace complete")
                                        .body("All sessions in workspace have completed")
                                        .show();
                                }
                            }
                            continue;
                        }

                        // Check for AI tool detection and emit event
                        if let Some(ai_tool) = activity_tracker.get_detected_ai(session_id) {
                            let _ = status_app_handle.emit("ai-detected", serde_json::json!({
                                "session_id": session_id,
                                "ai_tool": ai_tool,
                            }));
                        }

                        // Infer status from activity patterns
                        if let Some(inferred) = activity_tracker.get_inferred_status(session_id) {
                            if &inferred != current_status {
                                if let Err(e) = status_db
                                    .lock()
                                    .update_session_status(session_id, &inferred)
                                {
                                    log::error!(
                                        "Failed to update session {} status: {}",
                                        session_id,
                                        e
                                    );
                                    continue;
                                }

                                let change = StatusChange {
                                    session_id: session_id.clone(),
                                    old_status: current_status.clone(),
                                    new_status: inferred.clone(),
                                };
                                let _ = status_app_handle.emit("session-status-changed", &change);

                                // Send notification for key transitions
                                match inferred.as_str() {
                                    "waiting" => {
                                        let _ = status_app_handle
                                            .notification()
                                            .builder()
                                            .title("Agent needs input")
                                            .body(format!(
                                                "Session \"{}\" is waiting for input",
                                                session_name
                                            ))
                                            .show();
                                    }
                                    "failed" => {
                                        let _ = status_app_handle
                                            .notification()
                                            .builder()
                                            .title("Session failed")
                                            .body(format!(
                                                "Session \"{}\" has failed",
                                                session_name
                                            ))
                                            .show();
                                    }
                                    _ => {}
                                }
                            }
                        } else {
                            // No inferred status — if session was idle/waiting but now active again, revert to active
                            if current_status == "idle" || current_status == "waiting" {
                                // Activity tracker returned None, meaning recent activity — revert to active
                                if let Err(e) = status_db
                                    .lock()
                                    .update_session_status(session_id, "active")
                                {
                                    log::error!(
                                        "Failed to update session {} status: {}",
                                        session_id,
                                        e
                                    );
                                    continue;
                                }

                                let change = StatusChange {
                                    session_id: session_id.clone(),
                                    old_status: current_status.clone(),
                                    new_status: "active".to_string(),
                                };
                                let _ = status_app_handle.emit("session-status-changed", &change);
                            }
                        }
                    }
                }
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            create_workspace,
            list_workspaces,
            respawn_sessions,
            create_session,
            close_session,
            list_sessions,
            get_session_tree,
            write_pty,
            resize_pty,
            get_system_metrics,
            get_network_status,
            get_git_status,
            get_process_metrics,
            get_annotations,
            execute_annotation_action,
            read_file,
            get_conflict_details,
            resolve_conflict,
            watch_git_repo,
            clear_all_sessions,
            rename_session,
            // Phase 7: A2UI
            a2ui_respond,
            // Phase 4+5: COW Filesystem + Git Translation
            create_workspace_with_repo,
            get_session_delta,
            merge_session,
            get_conflicts,
            translate_to_commit,
            ship_workspace,
            // Phase 8: Parallel Execution Connectors
            get_connectors,
            kill_connector_group,
        ])
        .run(tauri::generate_context!())
        .expect("error while running ocean");
}
