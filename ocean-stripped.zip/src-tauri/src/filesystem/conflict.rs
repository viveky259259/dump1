use parking_lot::Mutex;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConflictAlert {
    pub file_path: String,
    pub session_ids: Vec<String>,
    pub session_names: Vec<String>,
    /// Severity: "disjoint" (different files), "overlapping" (same file, different regions),
    /// "conflicting" (same file, potentially same regions).
    /// For V1, we only detect file-level overlap so this is always "conflicting".
    pub severity: String,
}

#[derive(Debug, Clone)]
struct SessionFileInfo {
    session_id: String,
    session_name: String,
}

pub struct ConflictDetector {
    /// Map from file_path -> list of sessions that modified it
    file_changes: Arc<Mutex<HashMap<String, Vec<SessionFileInfo>>>>,
}

impl ConflictDetector {
    pub fn new() -> Self {
        ConflictDetector {
            file_changes: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Register that a session has modified a file.
    pub fn register_file_change(
        &self,
        session_id: &str,
        session_name: &str,
        file_path: &str,
    ) {
        let mut changes = self.file_changes.lock();
        let entry = changes
            .entry(file_path.to_string())
            .or_insert_with(Vec::new);

        // Don't add duplicate entries for same session + file
        if !entry.iter().any(|info| info.session_id == session_id) {
            entry.push(SessionFileInfo {
                session_id: session_id.to_string(),
                session_name: session_name.to_string(),
            });
        }
    }

    /// Register all file changes from a DeltaInfo for a session.
    pub fn register_delta(
        &self,
        session_id: &str,
        session_name: &str,
        delta: &super::DeltaInfo,
    ) {
        for file_path in &delta.modified_files {
            self.register_file_change(session_id, session_name, file_path);
        }
        for file_path in &delta.created_files {
            self.register_file_change(session_id, session_name, file_path);
        }
        for file_path in &delta.deleted_files {
            self.register_file_change(session_id, session_name, file_path);
        }
    }

    /// Check for conflicts: files that have been modified by 2+ sessions.
    pub fn check_conflicts(&self) -> Vec<ConflictAlert> {
        let changes = self.file_changes.lock();
        let mut alerts = Vec::new();

        for (file_path, sessions) in changes.iter() {
            if sessions.len() >= 2 {
                let session_ids: Vec<String> =
                    sessions.iter().map(|s| s.session_id.clone()).collect();
                let session_names: Vec<String> =
                    sessions.iter().map(|s| s.session_name.clone()).collect();

                // Deduplicate session IDs (shouldn't happen, but safety)
                let unique_ids: HashSet<&str> =
                    session_ids.iter().map(|s| s.as_str()).collect();

                if unique_ids.len() >= 2 {
                    alerts.push(ConflictAlert {
                        file_path: file_path.clone(),
                        session_ids,
                        session_names,
                        severity: "conflicting".to_string(),
                    });
                }
            }
        }

        // Sort by file path for deterministic output
        alerts.sort_by(|a, b| a.file_path.cmp(&b.file_path));
        alerts
    }

    /// Remove all tracking data for a session (e.g., after merge or cleanup).
    pub fn clear_session(&self, session_id: &str) {
        let mut changes = self.file_changes.lock();

        // Remove the session from all file entries
        for sessions in changes.values_mut() {
            sessions.retain(|info| info.session_id != session_id);
        }

        // Remove file entries that now have no sessions
        changes.retain(|_, sessions| !sessions.is_empty());
    }

    /// Clear all tracking data.
    pub fn clear_all(&self) {
        self.file_changes.lock().clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_no_conflicts_single_session() {
        let detector = ConflictDetector::new();
        detector.register_file_change("s1", "Session 1", "src/main.rs");
        detector.register_file_change("s1", "Session 1", "src/lib.rs");

        let conflicts = detector.check_conflicts();
        assert!(conflicts.is_empty());
    }

    #[test]
    fn test_no_conflicts_different_files() {
        let detector = ConflictDetector::new();
        detector.register_file_change("s1", "Session 1", "src/main.rs");
        detector.register_file_change("s2", "Session 2", "src/lib.rs");

        let conflicts = detector.check_conflicts();
        assert!(conflicts.is_empty());
    }

    #[test]
    fn test_conflict_same_file() {
        let detector = ConflictDetector::new();
        detector.register_file_change("s1", "Session 1", "src/main.rs");
        detector.register_file_change("s2", "Session 2", "src/main.rs");

        let conflicts = detector.check_conflicts();
        assert_eq!(conflicts.len(), 1);
        assert_eq!(conflicts[0].file_path, "src/main.rs");
        assert_eq!(conflicts[0].session_ids.len(), 2);
        assert_eq!(conflicts[0].severity, "conflicting");
    }

    #[test]
    fn test_clear_session() {
        let detector = ConflictDetector::new();
        detector.register_file_change("s1", "Session 1", "src/main.rs");
        detector.register_file_change("s2", "Session 2", "src/main.rs");

        assert_eq!(detector.check_conflicts().len(), 1);

        detector.clear_session("s1");
        assert!(detector.check_conflicts().is_empty());
    }

    #[test]
    fn test_no_duplicate_registration() {
        let detector = ConflictDetector::new();
        detector.register_file_change("s1", "Session 1", "src/main.rs");
        detector.register_file_change("s1", "Session 1", "src/main.rs");
        detector.register_file_change("s1", "Session 1", "src/main.rs");

        let changes = detector.file_changes.lock();
        assert_eq!(changes.get("src/main.rs").unwrap().len(), 1);
    }
}
