pub mod conflict;

use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use walkdir::WalkDir;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeltaInfo {
    pub workspace_id: String,
    pub session_id: String,
    pub modified_files: Vec<String>,
    pub created_files: Vec<String>,
    pub deleted_files: Vec<String>,
    pub delta_size_bytes: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MergeResult {
    pub merged_files: Vec<String>,
    pub deleted_files: Vec<String>,
    pub conflicts: Vec<String>,
    pub success: bool,
}

pub struct FilesystemManager {
    ocean_dir: PathBuf,
}

impl FilesystemManager {
    pub fn new() -> Self {
        let ocean_dir = dirs_next::home_dir()
            .unwrap_or_else(|| PathBuf::from("/tmp"))
            .join(".ocean");
        FilesystemManager { ocean_dir }
    }

    /// Workspace base directory: ~/.ocean/workspaces/{workspace_id}/
    fn workspace_dir(&self, workspace_id: &str) -> PathBuf {
        self.ocean_dir.join("workspaces").join(workspace_id)
    }

    /// Base snapshot directory: ~/.ocean/workspaces/{workspace_id}/base/
    fn base_dir(&self, workspace_id: &str) -> PathBuf {
        self.workspace_dir(workspace_id).join("base")
    }

    /// Public accessor for base directory
    pub fn base_dir_pub(&self, workspace_id: &str) -> PathBuf {
        self.base_dir(workspace_id)
    }

    /// Public accessor for session directory
    pub fn session_dir_pub(&self, workspace_id: &str, session_id: &str) -> PathBuf {
        self.session_dir(workspace_id, session_id)
    }

    /// Session clone directory: ~/.ocean/workspaces/{workspace_id}/sessions/{session_id}/
    fn session_dir(&self, workspace_id: &str, session_id: &str) -> PathBuf {
        self.workspace_dir(workspace_id)
            .join("sessions")
            .join(session_id)
    }

    /// Create a workspace snapshot from a repo path using APFS clonefile (cp -Rc).
    /// Returns the base snapshot path.
    pub fn create_workspace_snapshot(
        &self,
        repo_path: &str,
        workspace_id: &str,
    ) -> Result<PathBuf, String> {
        let source = Path::new(repo_path);
        if !source.exists() {
            return Err(format!("Source repo path does not exist: {}", repo_path));
        }

        let target = self.base_dir(workspace_id);

        // Ensure parent directory exists
        if let Some(parent) = target.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Failed to create workspace directory: {}", e))?;
        }

        // Remove existing base if it exists (re-snapshot)
        if target.exists() {
            std::fs::remove_dir_all(&target)
                .map_err(|e| format!("Failed to remove existing base snapshot: {}", e))?;
        }

        // Use rsync with excludes for heavy directories. This is MUCH faster than
        // cp -Rc for large repos because we skip node_modules, .git/objects, build
        // artifacts, etc. These are either immutable (git objects) or can be
        // regenerated (npm install). We symlink them from the original repo instead.
        let source_str = source.to_string_lossy();
        let source_with_slash = if source_str.ends_with('/') {
            source_str.to_string()
        } else {
            format!("{}/", source_str)
        };

        std::fs::create_dir_all(&target)
            .map_err(|e| format!("Failed to create target directory: {}", e))?;

        let target_str = format!("{}/", target.to_string_lossy());

        // Heavy dirs to exclude from copy (symlinked instead)
        let exclude_dirs = [
            "node_modules", ".git/objects", ".git/lfs",
            "build", "dist", ".next", ".nuxt",
            "target", "__pycache__", ".dart_tool",
            ".gradle", ".build", "Pods",
            "vendor/bundle", ".venv", "venv",
        ];

        let mut cmd = std::process::Command::new("rsync");
        cmd.arg("-a").arg("--delete");

        for dir in &exclude_dirs {
            cmd.arg(format!("--exclude={}", dir));
        }

        cmd.arg(&source_with_slash).arg(&target_str);

        let output = cmd.output()
            .map_err(|e| format!("Failed to execute rsync: {}", e))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            log::warn!("rsync failed ({}), falling back to cp -R", stderr.trim());

            let _ = std::fs::remove_dir_all(&target);
            std::fs::create_dir_all(&target)
                .map_err(|e| format!("Failed to create target directory: {}", e))?;

            let fallback = std::process::Command::new("cp")
                .arg("-R")
                .arg(&source_with_slash)
                .arg(&target_str)
                .output()
                .map_err(|e| format!("Failed to execute fallback cp: {}", e))?;

            if !fallback.status.success() {
                let stderr = String::from_utf8_lossy(&fallback.stderr);
                return Err(format!("Failed to copy repo: {}", stderr));
            }
        }

        // Symlink excluded heavy directories from original repo
        // so they're accessible but not duplicated
        for dir in &exclude_dirs {
            let original = source.join(dir);
            let link = target.join(dir);

            if original.exists() {
                // Ensure parent dir exists for nested paths like .git/objects
                if let Some(parent) = link.parent() {
                    let _ = std::fs::create_dir_all(parent);
                }
                // Only create symlink if target doesn't already exist
                if !link.exists() {
                    if let Err(e) = std::os::unix::fs::symlink(&original, &link) {
                        log::warn!("Failed to symlink {}: {} (non-critical)", dir, e);
                    }
                }
            }
        }

        log::info!(
            "Created workspace snapshot: {} -> {}",
            repo_path,
            target.display()
        );
        Ok(target)
    }

    /// Create a session clone from the base snapshot (or parent session).
    /// Returns the session directory path (this becomes the PTY's CWD).
    pub fn create_session_clone(
        &self,
        workspace_id: &str,
        session_id: &str,
        parent_session_id: Option<&str>,
    ) -> Result<PathBuf, String> {
        let source = match parent_session_id {
            Some(parent_id) => {
                let parent_dir = self.session_dir(workspace_id, parent_id);
                if !parent_dir.exists() {
                    return Err(format!(
                        "Parent session directory does not exist: {}",
                        parent_dir.display()
                    ));
                }
                parent_dir
            }
            None => {
                let base = self.base_dir(workspace_id);
                if !base.exists() {
                    return Err(format!(
                        "Base snapshot does not exist: {}",
                        base.display()
                    ));
                }
                base
            }
        };

        let target = self.session_dir(workspace_id, session_id);

        // Ensure parent directory exists
        if let Some(parent) = target.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Failed to create sessions directory: {}", e))?;
        }

        // Remove existing session dir if it exists
        if target.exists() {
            std::fs::remove_dir_all(&target)
                .map_err(|e| format!("Failed to remove existing session directory: {}", e))?;
        }

        let source_str = format!("{}/", source.to_string_lossy());
        let target_str = target.to_string_lossy().to_string();

        // Create target directory
        std::fs::create_dir_all(&target)
            .map_err(|e| format!("Failed to create target directory: {}", e))?;

        // Use cp -Rc with symlink preservation (fast for APFS, symlinks stay as symlinks)
        let output = std::process::Command::new("cp")
            .arg("-Rc")
            .arg("-P") // preserve symlinks (don't follow them)
            .arg(&source_str)
            .arg(&target_str)
            .output()
            .map_err(|e| format!("Failed to execute cp: {}", e))?;

        if !output.status.success() {
            // Fallback to regular copy
            let _ = std::fs::remove_dir_all(&target);
            std::fs::create_dir_all(&target)
                .map_err(|e| format!("Failed to create target directory: {}", e))?;

            let fallback = std::process::Command::new("cp")
                .arg("-R")
                .arg(&source_str)
                .arg(&target_str)
                .output()
                .map_err(|e| format!("Failed to execute fallback cp: {}", e))?;

            if !fallback.status.success() {
                let stderr = String::from_utf8_lossy(&fallback.stderr);
                return Err(format!("Failed to clone session: {}", stderr));
            }
        }

        log::info!(
            "Created session clone: {} -> {}",
            source.display(),
            target.display()
        );
        Ok(target)
    }

    /// Compare a session directory against the base snapshot to find what changed.
    pub fn get_session_delta(
        &self,
        workspace_id: &str,
        session_id: &str,
    ) -> Result<DeltaInfo, String> {
        let base = self.base_dir(workspace_id);
        let session = self.session_dir(workspace_id, session_id);

        if !base.exists() {
            return Err(format!("Base snapshot not found: {}", base.display()));
        }
        if !session.exists() {
            return Err(format!("Session directory not found: {}", session.display()));
        }

        let mut modified_files = Vec::new();
        let mut created_files = Vec::new();
        let mut deleted_files = Vec::new();
        let mut delta_size_bytes: u64 = 0;

        // Collect all relative paths in session directory
        let session_files = collect_relative_paths(&session)?;
        let base_files = collect_relative_paths(&base)?;

        // Find modified and created files
        for rel_path in &session_files {
            let session_file = session.join(rel_path);
            let base_file = base.join(rel_path);

            if base_files.contains(rel_path) {
                // File exists in both — check if modified
                if is_file_modified(&base_file, &session_file) {
                    modified_files.push(rel_path.clone());
                    if let Ok(meta) = std::fs::metadata(&session_file) {
                        delta_size_bytes += meta.len();
                    }
                }
            } else {
                // File only in session — created
                created_files.push(rel_path.clone());
                if let Ok(meta) = std::fs::metadata(&session_file) {
                    delta_size_bytes += meta.len();
                }
            }
        }

        // Find deleted files (in base but not in session)
        for rel_path in &base_files {
            if !session_files.contains(rel_path) {
                deleted_files.push(rel_path.clone());
            }
        }

        Ok(DeltaInfo {
            workspace_id: workspace_id.to_string(),
            session_id: session_id.to_string(),
            modified_files,
            created_files,
            deleted_files,
            delta_size_bytes,
        })
    }

    /// Merge a session's changes back to the base snapshot.
    pub fn merge_session_to_base(
        &self,
        workspace_id: &str,
        session_id: &str,
    ) -> Result<MergeResult, String> {
        let delta = self.get_session_delta(workspace_id, session_id)?;

        let base = self.base_dir(workspace_id);
        let session = self.session_dir(workspace_id, session_id);

        let mut merged_files = Vec::new();
        let mut deleted = Vec::new();
        let conflicts = Vec::new();

        // Copy modified files from session to base
        for rel_path in &delta.modified_files {
            let src = session.join(rel_path);
            let dst = base.join(rel_path);

            if let Some(parent) = dst.parent() {
                std::fs::create_dir_all(parent).map_err(|e| {
                    format!("Failed to create directory for {}: {}", rel_path, e)
                })?;
            }

            std::fs::copy(&src, &dst)
                .map_err(|e| format!("Failed to copy {}: {}", rel_path, e))?;

            merged_files.push(rel_path.clone());
        }

        // Copy created files from session to base
        for rel_path in &delta.created_files {
            let src = session.join(rel_path);
            let dst = base.join(rel_path);

            if let Some(parent) = dst.parent() {
                std::fs::create_dir_all(parent).map_err(|e| {
                    format!("Failed to create directory for {}: {}", rel_path, e)
                })?;
            }

            std::fs::copy(&src, &dst)
                .map_err(|e| format!("Failed to copy {}: {}", rel_path, e))?;

            merged_files.push(rel_path.clone());
        }

        // Delete files from base that were deleted in session
        for rel_path in &delta.deleted_files {
            let dst = base.join(rel_path);
            if dst.exists() {
                std::fs::remove_file(&dst)
                    .map_err(|e| format!("Failed to delete {}: {}", rel_path, e))?;
                deleted.push(rel_path.clone());
            }
        }

        log::info!(
            "Merged session {} to base: {} files merged, {} files deleted",
            session_id,
            merged_files.len(),
            deleted.len()
        );

        Ok(MergeResult {
            merged_files,
            deleted_files: deleted,
            conflicts,
            success: true,
        })
    }

    /// Remove a session's clone directory.
    pub fn cleanup_session(
        &self,
        workspace_id: &str,
        session_id: &str,
    ) -> Result<(), String> {
        let target = self.session_dir(workspace_id, session_id);
        if target.exists() {
            std::fs::remove_dir_all(&target)
                .map_err(|e| format!("Failed to remove session directory: {}", e))?;
            log::info!("Cleaned up session directory: {}", target.display());
        }
        Ok(())
    }

    /// Remove an entire workspace directory (base + all session clones).
    pub fn cleanup_workspace(&self, workspace_id: &str) -> Result<(), String> {
        let target = self.workspace_dir(workspace_id);
        if target.exists() {
            std::fs::remove_dir_all(&target)
                .map_err(|e| format!("Failed to remove workspace directory: {}", e))?;
            log::info!("Cleaned up workspace directory: {}", target.display());
        }
        Ok(())
    }

    /// Get the base snapshot path for a workspace.
    pub fn get_base_path(&self, workspace_id: &str) -> PathBuf {
        self.base_dir(workspace_id)
    }

    /// Get the session clone path.
    pub fn get_session_path(&self, workspace_id: &str, session_id: &str) -> PathBuf {
        self.session_dir(workspace_id, session_id)
    }
}

/// Collect all file paths relative to a root directory, skipping directories themselves.
fn collect_relative_paths(root: &Path) -> Result<HashSet<String>, String> {
    let mut paths = HashSet::new();

    for entry in WalkDir::new(root)
        .into_iter()
        .filter_map(|e| e.ok())
    {
        if entry.file_type().is_file() {
            if let Ok(rel) = entry.path().strip_prefix(root) {
                paths.insert(rel.to_string_lossy().to_string());
            }
        }
    }

    Ok(paths)
}

/// Check if a file has been modified by comparing size and modification time.
fn is_file_modified(base_file: &Path, session_file: &Path) -> bool {
    let base_meta = match std::fs::metadata(base_file) {
        Ok(m) => m,
        Err(_) => return true, // Can't read base, assume modified
    };
    let session_meta = match std::fs::metadata(session_file) {
        Ok(m) => m,
        Err(_) => return true, // Can't read session, assume modified
    };

    // Quick check: different sizes means definitely modified
    if base_meta.len() != session_meta.len() {
        return true;
    }

    // Check modification time — if session file was modified after clone, it's changed.
    // On APFS clonefile, the mtime is preserved, so if the mtime differs, the file was modified.
    match (base_meta.modified(), session_meta.modified()) {
        (Ok(base_time), Ok(session_time)) => base_time != session_time,
        _ => {
            // Can't compare times, fall back to content comparison for small files
            if base_meta.len() < 1_048_576 {
                // < 1MB
                match (std::fs::read(base_file), std::fs::read(session_file)) {
                    (Ok(base_content), Ok(session_content)) => base_content != session_content,
                    _ => true,
                }
            } else {
                // Large file, can't easily compare — assume modified
                true
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    fn setup_test_dir() -> (tempfile::TempDir, FilesystemManager) {
        let tmp = tempfile::TempDir::new().unwrap();
        let mut mgr = FilesystemManager::new();
        mgr.ocean_dir = tmp.path().to_path_buf();
        (tmp, mgr)
    }

    #[test]
    fn test_collect_relative_paths() {
        let tmp = tempfile::TempDir::new().unwrap();
        let root = tmp.path();

        fs::create_dir_all(root.join("subdir")).unwrap();
        fs::write(root.join("file1.txt"), "hello").unwrap();
        fs::write(root.join("subdir/file2.txt"), "world").unwrap();

        let paths = collect_relative_paths(root).unwrap();
        assert!(paths.contains("file1.txt"));
        assert!(paths.contains("subdir/file2.txt"));
        assert_eq!(paths.len(), 2);
    }

    #[test]
    fn test_is_file_modified_same() {
        let tmp = tempfile::TempDir::new().unwrap();
        let file = tmp.path().join("test.txt");
        fs::write(&file, "content").unwrap();

        // Same file compared to itself should not be modified
        assert!(!is_file_modified(&file, &file));
    }

    #[test]
    fn test_is_file_modified_different_size() {
        let tmp = tempfile::TempDir::new().unwrap();
        let f1 = tmp.path().join("a.txt");
        let f2 = tmp.path().join("b.txt");
        fs::write(&f1, "short").unwrap();
        fs::write(&f2, "longer content").unwrap();

        assert!(is_file_modified(&f1, &f2));
    }

    #[test]
    fn test_session_delta_detects_changes() {
        let (_tmp, mgr) = setup_test_dir();
        let ws_id = "test-ws";

        // Create base with a file
        let base = mgr.base_dir(ws_id);
        fs::create_dir_all(&base).unwrap();
        fs::write(base.join("file.txt"), "original").unwrap();

        // Create session dir with modified file
        let session = mgr.session_dir(ws_id, "s1");
        fs::create_dir_all(&session).unwrap();
        fs::write(session.join("file.txt"), "modified").unwrap();

        let delta = mgr.get_session_delta(ws_id, "s1").unwrap();
        assert!(delta.modified_files.contains(&"file.txt".to_string()));
    }

    #[test]
    fn test_session_delta_detects_new_files() {
        let (_tmp, mgr) = setup_test_dir();
        let ws_id = "test-ws";

        let base = mgr.base_dir(ws_id);
        fs::create_dir_all(&base).unwrap();
        fs::write(base.join("existing.txt"), "hello").unwrap();

        let session = mgr.session_dir(ws_id, "s1");
        fs::create_dir_all(&session).unwrap();
        fs::write(session.join("existing.txt"), "hello").unwrap();
        fs::write(session.join("new_file.txt"), "brand new").unwrap();

        let delta = mgr.get_session_delta(ws_id, "s1").unwrap();
        assert!(delta.created_files.contains(&"new_file.txt".to_string()));
    }

    #[test]
    fn test_merge_session_to_base() {
        let (_tmp, mgr) = setup_test_dir();
        let ws_id = "test-ws";

        let base = mgr.base_dir(ws_id);
        fs::create_dir_all(&base).unwrap();
        fs::write(base.join("file.txt"), "original").unwrap();

        let session = mgr.session_dir(ws_id, "s1");
        fs::create_dir_all(&session).unwrap();
        fs::write(session.join("file.txt"), "session version").unwrap();

        let result = mgr.merge_session_to_base(ws_id, "s1").unwrap();
        assert!(result.success);
        assert!(result.merged_files.contains(&"file.txt".to_string()));

        // Base should now have session's content
        let base_content = fs::read_to_string(base.join("file.txt")).unwrap();
        assert_eq!(base_content, "session version");
    }

    #[test]
    fn test_conflict_resolution_copies_to_base() {
        let (_tmp, mgr) = setup_test_dir();
        let ws_id = "test-ws";

        // Setup base
        let base = mgr.base_dir(ws_id);
        fs::create_dir_all(&base).unwrap();
        fs::write(base.join("config.json"), r#"{"key":"base"}"#).unwrap();

        // Setup session s1 with a different version
        let s1_dir = mgr.session_dir(ws_id, "s1");
        fs::create_dir_all(&s1_dir).unwrap();
        fs::write(s1_dir.join("config.json"), r#"{"key":"session1"}"#).unwrap();

        // Setup session s2 with yet another version
        let s2_dir = mgr.session_dir(ws_id, "s2");
        fs::create_dir_all(&s2_dir).unwrap();
        fs::write(s2_dir.join("config.json"), r#"{"key":"session2"}"#).unwrap();

        // "Accept s1" — copy s1's version to base
        let s1_file = s1_dir.join("config.json");
        let base_file = base.join("config.json");
        fs::copy(&s1_file, &base_file).unwrap();

        let base_content = fs::read_to_string(&base_file).unwrap();
        assert_eq!(base_content, r#"{"key":"session1"}"#);

        // Verify s2 still has its own version (untouched)
        let s2_content = fs::read_to_string(s2_dir.join("config.json")).unwrap();
        assert_eq!(s2_content, r#"{"key":"session2"}"#);
    }
}
