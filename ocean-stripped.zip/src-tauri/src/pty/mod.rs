use base64::Engine;
use parking_lot::Mutex;
use portable_pty::{native_pty_system, CommandBuilder, MasterPty, PtySize};
use std::collections::HashMap;
use std::io::{Read, Write};
use std::sync::Arc;
use tauri::{AppHandle, Emitter};

use crate::a2ui::parser::A2UIParser;
use crate::session::activity::ActivityTracker;
use crate::terminal::OutputAnnotator;

/// Simple percent-decode for file:// URIs (decodes %20 etc.)
fn percent_decode(input: &str) -> String {
    let mut result = String::with_capacity(input.len());
    let mut chars = input.chars();
    while let Some(c) = chars.next() {
        if c == '%' {
            let hex: String = chars.by_ref().take(2).collect();
            if let Ok(byte) = u8::from_str_radix(&hex, 16) {
                result.push(byte as char);
            } else {
                result.push('%');
                result.push_str(&hex);
            }
        } else {
            result.push(c);
        }
    }
    result
}

pub struct PtySession {
    master: Box<dyn MasterPty + Send>,
    writer: Box<dyn Write + Send>,
    child_pid: u32,
    _child: Box<dyn portable_pty::Child + Send>,
}

pub struct PtyManager {
    sessions: Arc<Mutex<HashMap<String, PtySession>>>,
    activity_tracker: Arc<ActivityTracker>,
    annotator: Arc<OutputAnnotator>,
    line_counters: Arc<Mutex<HashMap<String, usize>>>,
    a2ui_parser: Arc<A2UIParser>,
}

impl PtyManager {
    pub fn new() -> Self {
        PtyManager {
            sessions: Arc::new(Mutex::new(HashMap::new())),
            activity_tracker: Arc::new(ActivityTracker::new()),
            annotator: Arc::new(OutputAnnotator::new()),
            line_counters: Arc::new(Mutex::new(HashMap::new())),
            a2ui_parser: Arc::new(A2UIParser::new()),
        }
    }

    pub fn get_activity_tracker(&self) -> Arc<ActivityTracker> {
        self.activity_tracker.clone()
    }

    pub fn get_annotator(&self) -> Arc<OutputAnnotator> {
        self.annotator.clone()
    }

    pub fn spawn(
        &self,
        session_id: &str,
        cols: u16,
        rows: u16,
        cwd: Option<String>,
        env_vars: Vec<(String, String)>,
        app_handle: AppHandle,
    ) -> Result<u32, String> {
        let pty_system = native_pty_system();

        let pair = pty_system
            .openpty(PtySize {
                rows,
                cols,
                pixel_width: 0,
                pixel_height: 0,
            })
            .map_err(|e| format!("Failed to open PTY: {}", e))?;

        let shell = std::env::var("SHELL").unwrap_or_else(|_| "/bin/zsh".to_string());
        let mut cmd = CommandBuilder::new(&shell);
        cmd.arg("-l"); // login shell

        if let Some(dir) = cwd {
            cmd.cwd(dir);
        } else {
            if let Some(home) = dirs_next::home_dir() {
                cmd.cwd(home);
            }
        }

        // Inject Ocean env vars
        cmd.env("TERM", "xterm-256color");
        cmd.env("COLORTERM", "truecolor");
        cmd.env("TERM_PROGRAM", "Ocean");
        cmd.env("TERM_PROGRAM_VERSION", env!("CARGO_PKG_VERSION"));
        cmd.env("OCEAN_SESSION_ID", session_id);

        for (key, value) in env_vars {
            cmd.env(key, value);
        }

        let child = pair
            .slave
            .spawn_command(cmd)
            .map_err(|e| format!("Failed to spawn shell: {}", e))?;

        let child_pid = child.process_id().unwrap_or(0);

        let writer = pair
            .master
            .take_writer()
            .map_err(|e| format!("Failed to take writer: {}", e))?;

        let mut reader = pair
            .master
            .try_clone_reader()
            .map_err(|e| format!("Failed to clone reader: {}", e))?;

        let pty_session = PtySession {
            master: pair.master,
            writer,
            child_pid,
            _child: child,
        };

        let sid = session_id.to_string();
        self.sessions.lock().insert(sid.clone(), pty_session);

        // Spawn read loop
        let event_name = format!("pty-output-{}", session_id);
        let sessions_ref = self.sessions.clone();
        let sid_clone = sid.clone();
        let tracker = self.activity_tracker.clone();
        let annotator = self.annotator.clone();
        let line_counters = self.line_counters.clone();
        let a2ui_parser = self.a2ui_parser.clone();

        // Initialize line counter for this session
        line_counters.lock().insert(sid.clone(), 0);

        std::thread::spawn(move || {
            let mut buf = [0u8; 8192];
            loop {
                match reader.read(&mut buf) {
                    Ok(0) => break,
                    Ok(n) => {
                        // Extract A2UI escape sequences before sending to xterm.js
                        let (cleaned_bytes, a2ui_components) =
                            a2ui_parser.extract_a2ui_sequences(&sid_clone, &buf[..n]);

                        // Emit A2UI components if any were found
                        if !a2ui_components.is_empty() {
                            let a2ui_event = format!("a2ui-component-{}", sid_clone);
                            let _ = app_handle.emit(&a2ui_event, &a2ui_components);
                        }

                        // Send cleaned data (without A2UI sequences) to the terminal
                        let data = base64::engine::general_purpose::STANDARD.encode(&cleaned_bytes);
                        let _ = app_handle.emit(&event_name, data);

                        // Track activity
                        tracker.record_activity(&sid_clone);

                        // Detect OSC 7 (CWD change) and git repo — use cleaned bytes
                        let text = String::from_utf8_lossy(&cleaned_bytes);

                        // OSC 7: \x1b]7;file:///path\x07 or \x1b]7;file://hostname/path\x1b\\
                        if let Some(osc7_start) = text.find("\x1b]7;") {
                            let after = &text[osc7_start + 4..];
                            let end = after.find('\x07')
                                .or_else(|| after.find("\x1b\\"))
                                .unwrap_or(after.len());
                            let uri = &after[..end];
                            // Parse file:// URI to path
                            if let Some(path_str) = uri.strip_prefix("file://") {
                                // Remove hostname part: file://hostname/path -> /path
                                let path = if let Some(slash_pos) = path_str[1..].find('/') {
                                    &path_str[slash_pos + 1..]
                                } else {
                                    path_str
                                };
                                let decoded = percent_decode(path);
                                let cwd_path = std::path::Path::new(&decoded);
                                // Check if this directory is inside a git repo
                                let mut check = Some(cwd_path);
                                while let Some(p) = check {
                                    if p.join(".git").exists() {
                                        let repo_path = p.to_string_lossy().to_string();
                                        let _ = app_handle.emit("cwd-git-detected", serde_json::json!({
                                            "session_id": sid_clone,
                                            "repo_path": repo_path,
                                        }));
                                        break;
                                    }
                                    check = p.parent();
                                }
                            }
                        }

                        // Extract text lines for prompt detection and annotation
                        let mut all_annotations = Vec::new();

                        for line in text.split('\n') {
                            let trimmed = line.replace('\r', "");
                            if !trimmed.trim().is_empty() {
                                tracker.record_output_line(&sid_clone, &trimmed);

                                // Track line number: increment for each newline in output.
                                // This counter tracks the absolute line position in the
                                // terminal's scrollback buffer (0-based, matching xterm.js
                                // buffer.active.baseY + cursorY).
                                let line_number = {
                                    let mut counters = line_counters.lock();
                                    let counter = counters.entry(sid_clone.clone()).or_insert(0);
                                    let current = *counter;
                                    *counter += 1;
                                    current
                                };

                                // Run annotation engine
                                let annotations = annotator.process_line(
                                    &sid_clone,
                                    line_number,
                                    &trimmed,
                                );

                                if !annotations.is_empty() {
                                    annotator.add_annotations(
                                        &sid_clone,
                                        line_number,
                                        annotations.clone(),
                                    );
                                    all_annotations.extend(annotations);
                                }
                            }
                        }

                        // Emit annotations event if any were found
                        if !all_annotations.is_empty() {
                            let ann_event = format!("annotations-{}", sid_clone);
                            let _ = app_handle.emit(&ann_event, &all_annotations);
                        }
                    }
                    Err(_) => break,
                }
            }

            // PTY closed — emit exit event
            let exit_code = {
                let mut sessions = sessions_ref.lock();
                if let Some(session) = sessions.get_mut(&sid_clone) {
                    session._child.wait().ok().map(|s| {
                        if s.success() { 0i32 } else { 1i32 }
                    }).unwrap_or(1)
                } else {
                    1
                }
            };

            // Clean up activity tracking, annotation data, and A2UI parser buffer on natural exit
            tracker.remove_session(&sid_clone);
            annotator.clear_session(&sid_clone);
            line_counters.lock().remove(&sid_clone);
            a2ui_parser.clear_session(&sid_clone);

            let exit_event = format!("pty-exit-{}", sid_clone);
            let _ = app_handle.emit(&exit_event, exit_code);

            sessions_ref.lock().remove(&sid_clone);
        });

        Ok(child_pid)
    }

    pub fn write(&self, session_id: &str, data: &str) -> Result<(), String> {
        let mut sessions = self.sessions.lock();
        let session = sessions
            .get_mut(session_id)
            .ok_or_else(|| format!("Session not found: {}", session_id))?;

        session
            .writer
            .write_all(data.as_bytes())
            .map_err(|e| format!("Write failed: {}", e))?;

        session
            .writer
            .flush()
            .map_err(|e| format!("Flush failed: {}", e))?;

        Ok(())
    }

    pub fn resize(&self, session_id: &str, cols: u16, rows: u16) -> Result<(), String> {
        let sessions = self.sessions.lock();
        let session = sessions
            .get(session_id)
            .ok_or_else(|| format!("Session not found: {}", session_id))?;

        session
            .master
            .resize(PtySize {
                rows,
                cols,
                pixel_width: 0,
                pixel_height: 0,
            })
            .map_err(|e| format!("Resize failed: {}", e))?;

        Ok(())
    }

    pub fn close(&self, session_id: &str) -> Result<(), String> {
        let mut sessions = self.sessions.lock();
        if let Some(mut session) = sessions.remove(session_id) {
            // Kill the child process
            let _ = session._child.kill();
        }
        Ok(())
    }

    pub fn is_alive(&self, session_id: &str) -> bool {
        self.sessions.lock().contains_key(session_id)
    }

    /// Returns a list of `(session_id, child_pid)` for all active PTY sessions.
    pub fn get_active_pids(&self) -> Vec<(String, u32)> {
        self.sessions
            .lock()
            .iter()
            .map(|(sid, session)| (sid.clone(), session.child_pid))
            .collect()
    }
}
