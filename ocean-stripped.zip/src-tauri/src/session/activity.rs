use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::Mutex;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StatusChange {
    pub session_id: String,
    pub old_status: String,
    pub new_status: String,
}

/// AI tool signatures in terminal output — if detected, the session is running an AI agent.
const AI_SIGNATURES: &[(&str, &str)] = &[
    ("claude", "claude-code"),
    ("Claude Code", "claude-code"),
    ("anthropic", "claude-code"),
    ("codex", "codex"),
    ("OpenAI Codex", "codex"),
    ("aider", "aider"),
    ("Aider v", "aider"),
    ("copilot", "copilot"),
    ("cody", "cody"),
    ("devin", "devin"),
    ("gemini", "gemini"),
];

/// Prompt patterns that indicate the session is waiting for user input.
const PROMPT_KEYWORDS: &[&str] = &[
    "[Y/n]",
    "[y/N]",
    "(yes/no)",
    "Continue?",
    "Proceed?",
    "confirm",
    "Enter password",
    "Password:",
    "passphrase",
    "(y/n)",
    "[y/n]",
    "approve",
    "permission",
];

const IDLE_TIMEOUT: Duration = Duration::from_secs(30);
const WAITING_TIMEOUT: Duration = Duration::from_secs(5);
const MAX_RECENT_LINES: usize = 5;

pub struct ActivityTracker {
    /// session_id -> last output timestamp
    last_activity: Arc<Mutex<HashMap<String, Instant>>>,
    /// session_id -> last few lines of output (ring buffer of last 5 lines)
    recent_output: Arc<Mutex<HashMap<String, Vec<String>>>>,
    /// session_id -> detected AI tool name (if any)
    detected_ai: Arc<Mutex<HashMap<String, String>>>,
}

impl ActivityTracker {
    pub fn new() -> Self {
        ActivityTracker {
            last_activity: Arc::new(Mutex::new(HashMap::new())),
            recent_output: Arc::new(Mutex::new(HashMap::new())),
            detected_ai: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Called on every PTY output to update the activity timestamp.
    pub fn record_activity(&self, session_id: &str) {
        self.last_activity
            .lock()
            .insert(session_id.to_string(), Instant::now());
    }

    /// Stores the last N lines of output for prompt detection.
    pub fn record_output_line(&self, session_id: &str, line: &str) {
        let trimmed = line.trim().to_string();
        if trimmed.is_empty() {
            return;
        }

        // Check for AI tool signatures (only if not already detected)
        {
            let detected = self.detected_ai.lock();
            if !detected.contains_key(session_id) {
                drop(detected);
                for (signature, tool_name) in AI_SIGNATURES {
                    if trimmed.contains(signature) {
                        self.detected_ai.lock().insert(
                            session_id.to_string(),
                            tool_name.to_string(),
                        );
                        log::info!("AI tool detected in session {}: {}", session_id, tool_name);
                        break;
                    }
                }
            }
        }

        let mut recent = self.recent_output.lock();
        let lines = recent
            .entry(session_id.to_string())
            .or_insert_with(Vec::new);

        lines.push(trimmed);
        if lines.len() > MAX_RECENT_LINES {
            lines.remove(0);
        }
    }

    /// Returns the detected AI tool name for a session, if any.
    pub fn get_detected_ai(&self, session_id: &str) -> Option<String> {
        self.detected_ai.lock().get(session_id).cloned()
    }

    /// Infers the session status based on output activity patterns.
    ///
    /// Returns:
    /// - `Some("waiting")` if the last output matches a prompt pattern and no activity for 5+ seconds
    /// - `Some("idle")` if no output for 30+ seconds but process is still alive
    /// - `None` if recently active (let the existing "active" status stand)
    pub fn get_inferred_status(&self, session_id: &str) -> Option<String> {
        let last_activity = {
            let activity = self.last_activity.lock();
            match activity.get(session_id) {
                Some(instant) => *instant,
                None => return None, // No activity recorded yet
            }
        };

        let elapsed = last_activity.elapsed();

        // Check for "waiting" state: prompt pattern detected + 5s idle
        if elapsed >= WAITING_TIMEOUT {
            if self.has_prompt_pattern(session_id) {
                return Some("waiting".to_string());
            }
        }

        // Check for "idle" state: no output for 30+ seconds
        if elapsed >= IDLE_TIMEOUT {
            return Some("idle".to_string());
        }

        // Recently active — don't override
        None
    }

    /// Cleanup when a session is closed.
    pub fn remove_session(&self, session_id: &str) {
        self.last_activity.lock().remove(session_id);
        self.detected_ai.lock().remove(session_id);
        self.recent_output.lock().remove(session_id);
    }

    /// Check if the last line of recent output matches a known prompt pattern.
    fn has_prompt_pattern(&self, session_id: &str) -> bool {
        let recent = self.recent_output.lock();
        if let Some(lines) = recent.get(session_id) {
            if let Some(last_line) = lines.last() {
                let lower = last_line.to_lowercase();

                // Check keyword patterns
                for pattern in PROMPT_KEYWORDS {
                    if lower.contains(&pattern.to_lowercase()) {
                        return true;
                    }
                }

                // Check if line ends with "? " (question mark followed by space)
                if last_line.ends_with("? ") {
                    return true;
                }
            }
        }
        false
    }
}
