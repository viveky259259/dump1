pub mod activity;

use crate::db::{Database, Session, Workspace};
use crate::filesystem::FilesystemManager;
use crate::pty::PtyManager;
use parking_lot::Mutex;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tauri::{AppHandle, Emitter};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionTreeNode {
    pub session: Session,
    pub children: Vec<SessionTreeNode>,
}

pub struct SessionManager {
    db: Arc<Mutex<Database>>,
    pty: Arc<PtyManager>,
    fs: Arc<FilesystemManager>,
    app_handle: AppHandle,
}

impl SessionManager {
    pub fn new(
        db: Arc<Mutex<Database>>,
        pty: Arc<PtyManager>,
        fs: Arc<FilesystemManager>,
        app_handle: AppHandle,
    ) -> Self {
        SessionManager { db, pty, fs, app_handle }
    }

    /// Get a reference to the FilesystemManager.
    pub fn fs(&self) -> &Arc<FilesystemManager> {
        &self.fs
    }

    pub fn ensure_default_workspace(&self) -> Result<Workspace, String> {
        let db = self.db.lock();
        let workspaces = db.list_workspaces().map_err(|e| e.to_string())?;

        if let Some(ws) = workspaces.first() {
            Ok(ws.clone())
        } else {
            db.create_workspace("Default").map_err(|e| e.to_string())
        }
    }

    pub fn create_workspace(&self, name: &str) -> Result<Workspace, String> {
        let db = self.db.lock();
        db.create_workspace(name).map_err(|e| e.to_string())
    }

    pub fn create_workspace_with_repo(
        &self,
        name: &str,
        repo_path: &str,
    ) -> Result<Workspace, String> {
        // Create the workspace record first to get its ID
        let workspace = {
            let db = self.db.lock();
            db.create_workspace_with_repo(name, repo_path, None, None)
                .map_err(|e| e.to_string())?
        };

        // Create the base snapshot using APFS clonefile
        let snapshot_path = self
            .fs
            .create_workspace_snapshot(repo_path, &workspace.id)?;

        // Try to get the current HEAD commit from the repo
        let base_commit = if let Ok(repo) = git2::Repository::open(repo_path) {
            repo.head()
                .ok()
                .and_then(|h| h.peel_to_commit().ok())
                .map(|c| c.id().to_string())
        } else {
            None
        };

        // Update workspace with snapshot path and commit
        {
            let db = self.db.lock();
            db.update_workspace_snapshot(
                &workspace.id,
                &snapshot_path.to_string_lossy(),
                base_commit.as_deref(),
            )
            .map_err(|e| e.to_string())?;
        }

        // Return updated workspace
        let db = self.db.lock();
        db.get_workspace(&workspace.id)
            .map_err(|e| e.to_string())
    }

    pub fn list_workspaces(&self) -> Result<Vec<Workspace>, String> {
        let db = self.db.lock();
        db.list_workspaces().map_err(|e| e.to_string())
    }

    pub fn create_session(
        &self,
        workspace_id: &str,
        parent_id: Option<&str>,
        name: Option<&str>,
    ) -> Result<Session, String> {
        let session_name = name.unwrap_or("Shell").to_string();

        let session = {
            let db = self.db.lock();
            db.create_session(workspace_id, parent_id, &session_name, "shell")
                .map_err(|e| e.to_string())?
        };

        // Check if workspace has a base snapshot (COW mode)
        let (cwd, fs_mode) = {
            let db = self.db.lock();
            let workspace = db.get_workspace(workspace_id).map_err(|e| e.to_string())?;

            if workspace.base_snapshot_path.is_some() {
                // Workspace has a base snapshot — create a COW clone for this session
                drop(db); // Release lock before filesystem operations

                let clone_path = self.fs.create_session_clone(
                    workspace_id,
                    &session.id,
                    parent_id,
                )?;

                // Create session state record
                let db = self.db.lock();
                db.create_session_state(
                    &session.id,
                    Some(&clone_path.to_string_lossy()),
                    "cow",
                )
                .map_err(|e| e.to_string())?;

                (Some(clone_path.to_string_lossy().to_string()), "cow")
            } else {
                (None, "none")
            }
        };

        // Build environment variables
        let mut env_vars = vec![
            ("OCEAN_WORKSPACE_ID".to_string(), workspace_id.to_string()),
            ("OCEAN_FS_MODE".to_string(), fs_mode.to_string()),
        ];

        if let Some(ref cwd_path) = cwd {
            env_vars.push(("OCEAN_SESSION_DIR".to_string(), cwd_path.clone()));
        }

        // Spawn PTY with CWD set to the clone directory if available
        let pid = self.pty.spawn(
            &session.id,
            80,
            24,
            cwd,
            env_vars,
            self.app_handle.clone(),
        )?;

        // Update session with PTY info
        {
            let db = self.db.lock();
            db.update_session_pty(&session.id, &session.id, pid as i64)
                .map_err(|e| e.to_string())?;
        }

        let mut updated_session = session;
        updated_session.pty_id = Some(updated_session.id.clone());
        updated_session.process_pid = Some(pid as i64);

        let _ = self.app_handle.emit("session-created", &updated_session);

        Ok(updated_session)
    }

    /// Respawn an existing session from the DB — reuse the same ID, spawn a fresh PTY.
    /// Returns the updated session record.
    pub fn respawn_session(&self, session: &Session) -> Result<Session, String> {
        // Determine CWD: use session_state mount_path if available, else workspace repo_path
        let cwd = {
            let db = self.db.lock();
            // Try session state first (COW workspace sessions have a mount_path)
            let session_cwd = db.get_session_state(&session.id)
                .ok()
                .and_then(|ss| ss.mount_path);

            if session_cwd.is_some() {
                session_cwd
            } else {
                // Fall back to workspace repo_path
                db.get_workspace(&session.workspace_id)
                    .ok()
                    .and_then(|ws| ws.repo_path)
            }
        };

        let env_vars = vec![
            ("OCEAN_WORKSPACE_ID".to_string(), session.workspace_id.clone()),
        ];

        let pid = self.pty.spawn(
            &session.id,
            80,
            24,
            cwd,
            env_vars,
            self.app_handle.clone(),
        )?;

        // Update DB with new PTY info
        {
            let db = self.db.lock();
            db.revive_session(&session.id, &session.id, pid as i64)
                .map_err(|e| e.to_string())?;
        }

        let mut revived = session.clone();
        revived.status = "active".to_string();
        revived.pty_id = Some(session.id.clone());
        revived.process_pid = Some(pid as i64);
        revived.ended_at = None;
        revived.exit_code = None;

        log::info!("Respawned session {} ({}) with PID {}", session.id, session.name, pid);
        let _ = self.app_handle.emit("session-created", &revived);

        Ok(revived)
    }

    /// Respawn all stale sessions from the DB. Returns the list of revived sessions.
    pub fn respawn_stale_sessions(&self) -> Result<Vec<Session>, String> {
        let stale = {
            let db = self.db.lock();
            db.get_stale_sessions().map_err(|e| e.to_string())?
        };

        if stale.is_empty() {
            return Ok(vec![]);
        }

        log::info!("Found {} stale sessions to respawn", stale.len());
        let mut revived = Vec::new();
        for session in &stale {
            match self.respawn_session(session) {
                Ok(s) => revived.push(s),
                Err(e) => {
                    log::error!("Failed to respawn session {} ({}): {}", session.id, session.name, e);
                    // Mark as completed if respawn fails
                    let db = self.db.lock();
                    let _ = db.update_session_status(&session.id, "completed");
                }
            }
        }

        Ok(revived)
    }

    pub fn close_session(&self, session_id: &str) -> Result<(), String> {
        // Clean up activity tracking
        self.pty.get_activity_tracker().remove_session(session_id);

        self.pty.close(session_id)?;

        let db = self.db.lock();
        db.close_session(session_id, 0).map_err(|e| e.to_string())?;

        let _ = self.app_handle.emit("session-closed", serde_json::json!({
            "session_id": session_id,
            "exit_code": 0
        }));

        Ok(())
    }

    pub fn list_sessions(&self, workspace_id: &str) -> Result<Vec<Session>, String> {
        let db = self.db.lock();
        db.list_sessions(workspace_id).map_err(|e| e.to_string())
    }

    pub fn get_session(&self, session_id: &str) -> Result<Session, String> {
        let db = self.db.lock();
        db.get_session(session_id).map_err(|e| e.to_string())
    }

    pub fn get_session_tree(&self, workspace_id: &str) -> Result<Vec<SessionTreeNode>, String> {
        let sessions = self.list_sessions(workspace_id)?;
        Ok(build_tree(&sessions, None))
    }

    /// Returns vec of (session_id, current_status, session_name, workspace_id) for all
    /// active/idle/waiting sessions across all workspaces.
    pub fn get_active_session_ids(&self) -> Vec<(String, String, String, String)> {
        let db = self.db.lock();
        let workspaces = match db.list_workspaces() {
            Ok(ws) => ws,
            Err(e) => {
                log::error!("Failed to list workspaces for activity check: {}", e);
                return vec![];
            }
        };

        let mut result = Vec::new();
        for ws in &workspaces {
            if let Ok(sessions) = db.list_sessions(&ws.id) {
                for s in sessions {
                    match s.status.as_str() {
                        "active" | "idle" | "waiting" => {
                            result.push((
                                s.id.clone(),
                                s.status.clone(),
                                s.name.clone(),
                                s.workspace_id.clone(),
                            ));
                        }
                        _ => {}
                    }
                }
            }
        }
        result
    }

    /// Get a reference to the underlying database for status updates.
    pub fn db(&self) -> &Arc<Mutex<Database>> {
        &self.db
    }
}

fn build_tree(sessions: &[Session], parent_id: Option<&str>) -> Vec<SessionTreeNode> {
    sessions
        .iter()
        .filter(|s| s.parent_id.as_deref() == parent_id)
        .map(|s| SessionTreeNode {
            session: s.clone(),
            children: build_tree(sessions, Some(&s.id)),
        })
        .collect()
}
