use serde::{Deserialize, Serialize};
use sysinfo::{Pid, System};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemMetrics {
    pub cpu_percent: f32,
    pub ram_used_bytes: u64,
    pub ram_total_bytes: u64,
    pub swap_used_bytes: u64,
    pub swap_total_bytes: u64,
    pub battery_percent: Option<f32>,
    pub battery_charging: Option<bool>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessMetrics {
    pub pid: u32,
    pub name: String,
    pub cpu_percent: f32,
    pub ram_bytes: u64,
}

pub struct SystemMetricsCollector {
    system: System,
}

impl SystemMetricsCollector {
    pub fn new() -> Self {
        Self {
            system: System::new_all(),
        }
    }

    pub fn collect(&mut self) -> SystemMetrics {
        self.system.refresh_cpu_usage();
        self.system.refresh_memory();

        let (battery_percent, battery_charging) = get_battery_info();

        SystemMetrics {
            cpu_percent: self.system.global_cpu_usage(),
            ram_used_bytes: self.system.used_memory(),
            ram_total_bytes: self.system.total_memory(),
            swap_used_bytes: self.system.used_swap(),
            swap_total_bytes: self.system.total_swap(),
            battery_percent,
            battery_charging,
        }
    }

    pub fn get_process_metrics(&self, pid: u32) -> Option<ProcessMetrics> {
        let sysinfo_pid = Pid::from(pid as usize);
        let process = self.system.process(sysinfo_pid)?;
        Some(ProcessMetrics {
            pid,
            name: process.name().to_string_lossy().to_string(),
            cpu_percent: process.cpu_usage(),
            ram_bytes: process.memory(),
        })
    }

    pub fn get_top_processes(&self, limit: usize) -> Vec<ProcessMetrics> {
        let mut processes: Vec<ProcessMetrics> = self
            .system
            .processes()
            .iter()
            .map(|(pid, process)| ProcessMetrics {
                pid: pid.as_u32(),
                name: process.name().to_string_lossy().to_string(),
                cpu_percent: process.cpu_usage(),
                ram_bytes: process.memory(),
            })
            .collect();

        processes.sort_by(|a, b| {
            b.cpu_percent
                .partial_cmp(&a.cpu_percent)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        processes.truncate(limit);
        processes
    }
}

/// Shells out to `pmset -g batt` on macOS to get battery percentage and charging status.
/// Returns (None, None) if parsing fails or the command is unavailable.
fn get_battery_info() -> (Option<f32>, Option<bool>) {
    #[cfg(target_os = "macos")]
    {
        let output = match std::process::Command::new("pmset")
            .args(["-g", "batt"])
            .output()
        {
            Ok(o) => o,
            Err(_) => return (None, None),
        };

        if !output.status.success() {
            return (None, None);
        }

        let stdout = String::from_utf8_lossy(&output.stdout);
        parse_pmset_output(&stdout)
    }

    #[cfg(not(target_os = "macos"))]
    {
        (None, None)
    }
}

/// Parses `pmset -g batt` output for battery percentage and charging status.
///
/// Example output:
/// ```text
/// Now drawing from 'Battery Power'
///  -InternalBattery-0 (id=...)	85%; discharging; 4:32 remaining
/// ```
#[cfg(target_os = "macos")]
fn parse_pmset_output(output: &str) -> (Option<f32>, Option<bool>) {
    let mut percent: Option<f32> = None;
    let mut charging: Option<bool> = None;

    for line in output.lines() {
        let trimmed = line.trim();
        // Look for the line containing the battery info (contains a percentage like "85%")
        if let Some(pct_pos) = trimmed.find('%') {
            // Walk backwards from '%' to find the start of the number
            let before_pct = &trimmed[..pct_pos];
            // The percentage number is the last token before '%', possibly preceded by a tab or space
            if let Some(num_str) = before_pct.rsplit(|c: char| !c.is_ascii_digit() && c != '.').next() {
                if let Ok(val) = num_str.parse::<f32>() {
                    percent = Some(val);
                }
            }

            // Determine charging status from keywords after the percentage
            let after_pct = &trimmed[pct_pos..];
            if after_pct.contains("charging") && !after_pct.contains("discharging") && !after_pct.contains("not charging") {
                charging = Some(true);
            } else if after_pct.contains("discharging") || after_pct.contains("not charging") {
                charging = Some(false);
            } else if after_pct.contains("charged") {
                charging = Some(false); // fully charged, not actively charging
            } else if after_pct.contains("AC attached") {
                charging = Some(true);
            }

            // Once we've found a battery line, stop
            if percent.is_some() {
                break;
            }
        }
    }

    (percent, charging)
}
