use git2::{Repository, StatusOptions};
use notify::{
    event::ModifyKind, recommended_watcher, Event, EventKind, RecursiveMode, Watcher,
};
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::time::{Duration, Instant};
use tauri::{AppHandle, Emitter};
use tokio::sync::mpsc;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GitStatus {
    pub branch: String,
    pub ahead: usize,
    pub behind: usize,
    pub staged: usize,
    pub modified: usize,
    pub untracked: usize,
    pub conflicted: usize,
    pub ci_status: Option<String>,
    pub pr_number: Option<u64>,
    pub pr_url: Option<String>,
}

impl Default for GitStatus {
    fn default() -> Self {
        Self {
            branch: String::new(),
            ahead: 0,
            behind: 0,
            staged: 0,
            modified: 0,
            untracked: 0,
            conflicted: 0,
            ci_status: None,
            pr_number: None,
            pr_url: None,
        }
    }
}

/// Simple cache for CI/PR status to avoid hammering `gh` on every status check.
struct CiCache {
    last_fetch: Option<Instant>,
    ci_status: Option<String>,
    pr_number: Option<u64>,
    pr_url: Option<String>,
}

impl CiCache {
    fn new() -> Self {
        Self {
            last_fetch: None,
            ci_status: None,
            pr_number: None,
            pr_url: None,
        }
    }

    fn is_stale(&self) -> bool {
        match self.last_fetch {
            Some(t) => t.elapsed() > Duration::from_secs(30),
            None => true,
        }
    }

    fn update(&mut self, ci_status: Option<String>, pr_number: Option<u64>, pr_url: Option<String>) {
        self.ci_status = ci_status;
        self.pr_number = pr_number;
        self.pr_url = pr_url;
        self.last_fetch = Some(Instant::now());
    }

    fn get_cached(&self) -> (Option<String>, Option<u64>, Option<String>) {
        (self.ci_status.clone(), self.pr_number, self.pr_url.clone())
    }
}

/// Global CI cache protected by a mutex. Shared across all calls to `fetch_ci_status`.
static CI_CACHE: std::sync::Mutex<Option<CiCache>> = std::sync::Mutex::new(None);

/// Fetches CI status and PR info using the `gh` CLI.
/// Results are cached for 30 seconds to avoid excessive shell-outs.
///
/// Returns (ci_status, pr_number, pr_url). All None if `gh` is not installed or fails.
fn fetch_ci_status(repo_path: &str, branch: &str) -> (Option<String>, Option<u64>, Option<String>) {
    // Check cache first
    if let Ok(mut guard) = CI_CACHE.lock() {
        let cache = guard.get_or_insert_with(CiCache::new);
        if !cache.is_stale() {
            return cache.get_cached();
        }
    }

    // Cache is stale or didn't exist — fetch fresh data
    let ci_status = fetch_ci_conclusion(repo_path, branch);
    let (pr_number, pr_url) = fetch_pr_info(repo_path);

    // Update cache
    if let Ok(mut guard) = CI_CACHE.lock() {
        let cache = guard.get_or_insert_with(CiCache::new);
        cache.update(ci_status.clone(), pr_number, pr_url.clone());
    }

    (ci_status, pr_number, pr_url)
}

/// Runs `gh run list --branch <branch> --limit 1 --json conclusion --jq '.[0].conclusion'`
/// to get the latest CI run conclusion for the given branch.
fn fetch_ci_conclusion(repo_path: &str, branch: &str) -> Option<String> {
    let output = std::process::Command::new("gh")
        .args([
            "run", "list",
            "--branch", branch,
            "--limit", "1",
            "--json", "conclusion",
            "--jq", ".[0].conclusion",
        ])
        .current_dir(repo_path)
        .output()
        .ok()?;

    if !output.status.success() {
        return None;
    }

    let conclusion = String::from_utf8_lossy(&output.stdout).trim().to_string();

    if conclusion.is_empty() || conclusion == "null" {
        return Some("pending".to_string());
    }

    // Map GitHub conclusion values to our simplified status
    match conclusion.as_str() {
        "success" => Some("success".to_string()),
        "failure" | "timed_out" | "cancelled" | "action_required" => Some("failure".to_string()),
        "neutral" | "skipped" => Some("success".to_string()),
        "" => Some("pending".to_string()),
        other => Some(other.to_string()),
    }
}

/// Runs `gh pr view --json number,url` to get PR info for the current branch.
fn fetch_pr_info(repo_path: &str) -> (Option<u64>, Option<String>) {
    let output = match std::process::Command::new("gh")
        .args(["pr", "view", "--json", "number,url"])
        .current_dir(repo_path)
        .output()
    {
        Ok(o) => o,
        Err(_) => return (None, None),
    };

    if !output.status.success() {
        return (None, None);
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    let parsed: serde_json::Value = match serde_json::from_str(stdout.trim()) {
        Ok(v) => v,
        Err(_) => return (None, None),
    };

    let pr_number = parsed.get("number").and_then(|v| v.as_u64());
    let pr_url = parsed
        .get("url")
        .and_then(|v| v.as_str())
        .map(|s| s.to_string());

    (pr_number, pr_url)
}

pub struct GitWatcher;

impl GitWatcher {
    pub fn new() -> Self {
        Self
    }

    pub fn get_status(repo_path: &str) -> Result<GitStatus, String> {
        let repo = Repository::open(repo_path).map_err(|e| format!("Failed to open repo: {}", e))?;

        // Get branch name
        let branch = match repo.head() {
            Ok(head) => {
                if head.is_branch() {
                    head.shorthand().unwrap_or("HEAD").to_string()
                } else {
                    // Detached HEAD — show short oid
                    head.target()
                        .map(|oid| format!("{:.7}", oid))
                        .unwrap_or_else(|| "HEAD".to_string())
                }
            }
            Err(_) => "HEAD".to_string(),
        };

        // Compute ahead/behind relative to upstream
        let (ahead, behind) = Self::compute_ahead_behind(&repo);

        // Get file statuses
        let mut opts = StatusOptions::new();
        opts.include_untracked(true)
            .recurse_untracked_dirs(true)
            .include_ignored(false);

        let statuses = repo
            .statuses(Some(&mut opts))
            .map_err(|e| format!("Failed to get statuses: {}", e))?;

        let mut staged = 0usize;
        let mut modified = 0usize;
        let mut untracked = 0usize;
        let mut conflicted = 0usize;

        for entry in statuses.iter() {
            let s = entry.status();

            if s.is_conflicted() {
                conflicted += 1;
                continue;
            }

            // Index (staged) changes
            if s.is_index_new()
                || s.is_index_modified()
                || s.is_index_deleted()
                || s.is_index_renamed()
                || s.is_index_typechange()
            {
                staged += 1;
            }

            // Working-tree (modified) changes
            if s.is_wt_modified()
                || s.is_wt_deleted()
                || s.is_wt_renamed()
                || s.is_wt_typechange()
            {
                modified += 1;
            }

            if s.is_wt_new() {
                untracked += 1;
            }
        }

        // Fetch CI status and PR info (cached, won't block if recently fetched)
        let (ci_status, pr_number, pr_url) = fetch_ci_status(repo_path, &branch);

        Ok(GitStatus {
            branch,
            ahead,
            behind,
            staged,
            modified,
            untracked,
            conflicted,
            ci_status,
            pr_number,
            pr_url,
        })
    }

    fn compute_ahead_behind(repo: &Repository) -> (usize, usize) {
        let head = match repo.head() {
            Ok(h) => h,
            Err(_) => return (0, 0),
        };

        let local_oid = match head.target() {
            Some(oid) => oid,
            None => return (0, 0),
        };

        // Find the upstream branch
        let branch_name = match head.shorthand() {
            Some(name) => name.to_string(),
            None => return (0, 0),
        };

        let upstream_ref = format!("refs/remotes/origin/{}", branch_name);
        let upstream_oid = match repo.refname_to_id(&upstream_ref) {
            Ok(oid) => oid,
            Err(_) => return (0, 0),
        };

        match repo.graph_ahead_behind(local_oid, upstream_oid) {
            Ok((ahead, behind)) => (ahead, behind),
            Err(_) => (0, 0),
        }
    }

    /// Watches the `.git/` directory for changes, debounces, and emits `git-status` events.
    /// Also polls every 10 seconds as a fallback (for CI status updates, etc.).
    pub fn start_watching(repo_path: String, app_handle: AppHandle) {
        tauri::async_runtime::spawn(async move {
            let (tx, mut rx) = mpsc::channel::<()>(16);

            let git_dir = Path::new(&repo_path).join(".git");
            if !git_dir.exists() {
                log::warn!("No .git directory found at {}, git watcher not starting", repo_path);
                return;
            }

            // Spawn the filesystem watcher on a blocking thread
            let git_dir_clone = git_dir.clone();
            let watcher_active = Arc::new(AtomicBool::new(true));
            let watcher_active_clone = watcher_active.clone();

            let _watcher_handle = tokio::task::spawn_blocking(move || {
                let tx = tx;
                let mut watcher = match recommended_watcher(move |result: Result<Event, notify::Error>| {
                    if let Ok(event) = result {
                        match event.kind {
                            EventKind::Modify(ModifyKind::Data(_))
                            | EventKind::Modify(ModifyKind::Name(_))
                            | EventKind::Modify(ModifyKind::Any)
                            | EventKind::Create(_)
                            | EventKind::Remove(_) => {
                                // Non-blocking send; if channel is full, that's fine — we'll
                                // coalesce anyway via debounce.
                                let _ = tx.try_send(());
                            }
                            _ => {}
                        }
                    }
                }) {
                    Ok(w) => w,
                    Err(e) => {
                        log::error!("Failed to create file watcher: {}", e);
                        return;
                    }
                };

                if let Err(e) = watcher.watch(&git_dir_clone, RecursiveMode::Recursive) {
                    log::error!("Failed to watch .git directory: {}", e);
                    return;
                }

                // Keep the watcher alive as long as the flag is set
                while watcher_active_clone.load(Ordering::Relaxed) {
                    std::thread::sleep(Duration::from_secs(1));
                }

                // Watcher is dropped here, stopping filesystem watching
            });

            // Fallback poll interval: triggers a status refresh every 10 seconds
            // (useful for CI status updates that don't touch the local filesystem)
            let mut poll_interval = tokio::time::interval(Duration::from_secs(10));
            // The first tick completes immediately — consume it so we don't
            // double-fire on startup.
            poll_interval.tick().await;

            // Debounce loop: wait for a filesystem notification OR the poll interval
            loop {
                tokio::select! {
                    recv_result = rx.recv() => {
                        if recv_result.is_none() {
                            // Channel closed — watcher thread ended
                            break;
                        }
                        // Debounce: drain any additional notifications that arrived and wait 500ms
                        tokio::time::sleep(Duration::from_millis(500)).await;
                        while rx.try_recv().is_ok() {
                            // Drain queued notifications
                        }
                    }
                    _ = poll_interval.tick() => {
                        // 10-second fallback poll fired
                    }
                }

                let path = repo_path.clone();
                let status = tokio::task::spawn_blocking(move || {
                    GitWatcher::get_status(&path)
                })
                .await;

                match status {
                    Ok(Ok(git_status)) => {
                        if let Err(e) = app_handle.emit("git-status", &git_status) {
                            log::error!("Failed to emit git-status event: {}", e);
                        }
                    }
                    Ok(Err(e)) => {
                        log::error!("Failed to get git status: {}", e);
                    }
                    Err(e) => {
                        log::error!("Git status task panicked: {}", e);
                    }
                }
            }

            watcher_active.store(false, Ordering::Relaxed);
        });
    }
}
