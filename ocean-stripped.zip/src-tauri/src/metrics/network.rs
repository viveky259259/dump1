use serde::{Deserialize, Serialize};
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkStatus {
    pub connected: bool,
    pub interface_type: String,
    pub latency_github_ms: Option<u64>,
    pub latency_npm_ms: Option<u64>,
}

pub struct NetworkMonitor;

impl NetworkMonitor {
    pub fn new() -> Self {
        Self
    }

    pub fn check_connectivity(&self) -> NetworkStatus {
        let timeout = Duration::from_secs(3);

        let latency_github_ms = Self::measure_latency("github.com:443", timeout);
        let latency_npm_ms = Self::measure_latency("registry.npmjs.org:443", timeout);

        let connected = latency_github_ms.is_some() || latency_npm_ms.is_some();

        let interface_type = detect_interface_type();

        NetworkStatus {
            connected,
            interface_type,
            latency_github_ms,
            latency_npm_ms,
        }
    }

    fn measure_latency(host: &str, timeout: Duration) -> Option<u64> {
        // Resolve DNS first so we can use connect_timeout with a SocketAddr
        let addr: SocketAddr = match host.to_socket_addrs() {
            Ok(mut addrs) => match addrs.next() {
                Some(addr) => addr,
                None => return None,
            },
            Err(_) => return None,
        };

        let start = Instant::now();
        match TcpStream::connect_timeout(&addr, timeout) {
            Ok(_stream) => {
                let elapsed = start.elapsed();
                Some(elapsed.as_millis() as u64)
            }
            Err(_) => None,
        }
    }
}

/// Detects the active network interface type on macOS by checking the default route
/// interface against the hardware ports list. Falls back to "unknown" on failure.
fn detect_interface_type() -> String {
    #[cfg(target_os = "macos")]
    {
        match detect_interface_type_macos() {
            Some(iface_type) => iface_type,
            None => "unknown".to_string(),
        }
    }

    #[cfg(not(target_os = "macos"))]
    {
        "unknown".to_string()
    }
}

#[cfg(target_os = "macos")]
fn detect_interface_type_macos() -> Option<String> {
    // Step 1: Get the active default interface name (e.g., "en0")
    let route_output = std::process::Command::new("route")
        .args(["-n", "get", "default"])
        .output()
        .ok()?;

    if !route_output.status.success() {
        return None;
    }

    let route_stdout = String::from_utf8_lossy(&route_output.stdout);
    let active_interface = route_stdout
        .lines()
        .find(|line| line.contains("interface"))?
        .split(':')
        .nth(1)?
        .trim()
        .to_string();

    if active_interface.is_empty() {
        return None;
    }

    // Step 2: Get the hardware ports list and match the active interface
    let ports_output = std::process::Command::new("networksetup")
        .args(["-listallhardwareports"])
        .output()
        .ok()?;

    if !ports_output.status.success() {
        return None;
    }

    let ports_stdout = String::from_utf8_lossy(&ports_output.stdout);

    // Parse hardware ports output. Format is:
    // Hardware Port: Wi-Fi
    // Device: en0
    // ...
    // Hardware Port: Ethernet
    // Device: en1
    let mut current_port_name: Option<String> = None;
    for line in ports_stdout.lines() {
        let trimmed = line.trim();
        if let Some(port_name) = trimmed.strip_prefix("Hardware Port:") {
            current_port_name = Some(port_name.trim().to_string());
        } else if let Some(device_name) = trimmed.strip_prefix("Device:") {
            let device = device_name.trim();
            if device == active_interface {
                if let Some(ref port) = current_port_name {
                    let lower = port.to_lowercase();
                    if lower.contains("wi-fi") || lower.contains("wifi") || lower.contains("airport") {
                        return Some("wifi".to_string());
                    } else if lower.contains("ethernet") || lower.contains("thunderbolt") {
                        return Some("ethernet".to_string());
                    } else if lower.contains("usb") {
                        return Some("usb".to_string());
                    } else if lower.contains("bluetooth") {
                        return Some("bluetooth".to_string());
                    } else {
                        return Some(port.clone());
                    }
                }
            }
        }
    }

    // If we got an active interface but couldn't match it in hardware ports,
    // make a guess based on common naming patterns
    if active_interface.starts_with("en") {
        // en0 is usually Wi-Fi on Macs
        Some("wifi".to_string())
    } else if active_interface.starts_with("bridge") || active_interface.starts_with("utun") {
        Some("vpn".to_string())
    } else {
        None
    }
}
