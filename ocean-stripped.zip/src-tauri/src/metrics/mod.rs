pub mod git;
pub mod network;
pub mod system;

pub use git::GitStatus;
pub use network::NetworkStatus;
pub use system::{ProcessMetrics, SystemMetrics};

use git::GitWatcher;
use network::NetworkMonitor;
use system::SystemMetricsCollector;

use std::sync::Arc;
use std::time::Duration;
use tauri::{AppHandle, Emitter};
use tokio::sync::Mutex;

pub struct MetricsCollector {
    system_collector: Arc<Mutex<SystemMetricsCollector>>,
    network_monitor: Arc<NetworkMonitor>,
    git_watcher: Arc<GitWatcher>,
}

impl MetricsCollector {
    pub fn new() -> Self {
        Self {
            system_collector: Arc::new(Mutex::new(SystemMetricsCollector::new())),
            network_monitor: Arc::new(NetworkMonitor::new()),
            git_watcher: Arc::new(GitWatcher::new()),
        }
    }

    /// Starts background polling tasks for system metrics and network status.
    ///
    /// - System metrics are polled every 2000ms and emitted as `metrics_update`.
    /// - Network status is polled every 5000ms and emitted as `network_update`.
    pub fn start(&self, app_handle: AppHandle) {
        // System metrics polling — every 2 seconds
        let system_collector = self.system_collector.clone();
        let system_app_handle = app_handle.clone();
        tauri::async_runtime::spawn(async move {
            let mut interval = tokio::time::interval(Duration::from_millis(2000));
            loop {
                interval.tick().await;
                let mut collector = system_collector.lock().await;
                let metrics = collector.collect();
                drop(collector); // release lock before emitting
                if let Err(e) = system_app_handle.emit("metrics_update", &metrics) {
                    log::error!("Failed to emit metrics_update: {}", e);
                }
            }
        });

        // Network status polling — every 5 seconds
        let network_monitor = self.network_monitor.clone();
        let network_app_handle = app_handle.clone();
        tauri::async_runtime::spawn(async move {
            let mut interval = tokio::time::interval(Duration::from_millis(5000));
            loop {
                interval.tick().await;
                let monitor = network_monitor.clone();
                let status = tokio::task::spawn_blocking(move || {
                    monitor.check_connectivity()
                })
                .await;
                match status {
                    Ok(net_status) => {
                        if let Err(e) = network_app_handle.emit("network_update", &net_status) {
                            log::error!("Failed to emit network_update: {}", e);
                        }
                    }
                    Err(e) => {
                        log::error!("Network check task panicked: {}", e);
                    }
                }
            }
        });
    }

    /// Convenience accessor: collect system metrics on demand.
    pub async fn get_system_metrics(&self) -> SystemMetrics {
        let mut collector = self.system_collector.lock().await;
        collector.collect()
    }

    /// Convenience accessor: check network connectivity on demand.
    pub async fn get_network_status(&self) -> NetworkStatus {
        let monitor = self.network_monitor.clone();
        tokio::task::spawn_blocking(move || monitor.check_connectivity())
            .await
            .unwrap_or_else(|_| NetworkStatus {
                connected: false,
                interface_type: "unknown".to_string(),
                latency_github_ms: None,
                latency_npm_ms: None,
            })
    }

    /// Get per-process metrics for a specific PID.
    pub async fn get_process_metrics(&self, pid: u32) -> Option<ProcessMetrics> {
        let collector = self.system_collector.lock().await;
        collector.get_process_metrics(pid)
    }

    /// Get top N processes by CPU usage.
    pub async fn get_top_processes(&self, limit: usize) -> Vec<ProcessMetrics> {
        let collector = self.system_collector.lock().await;
        collector.get_top_processes(limit)
    }

    /// Start watching a git repository for changes.
    pub fn watch_git_repo(&self, repo_path: String, app_handle: AppHandle) {
        GitWatcher::start_watching(repo_path, app_handle);
    }

    /// Get git status for a repo path (delegates to GitWatcher).
    pub fn get_git_status(repo_path: &str) -> Result<GitStatus, String> {
        GitWatcher::get_status(repo_path)
    }
}
