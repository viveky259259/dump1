use super::detector::ChildInfo;
use super::{ConnectorGroup, ConnectorProcess};

/// Detects Flutter / Dart development sessions.
///
/// Looks for:
/// - `flutter` or `dart` processes
/// - VM service port (typically 8181)
/// - DevTools port (typically 9100)
/// - `adb` process (Android debugging)
pub struct FlutterDetector;

impl FlutterDetector {
    pub fn detect(session_id: &str, children: &[ChildInfo]) -> Option<ConnectorGroup> {
        let mut processes: Vec<ConnectorProcess> = Vec::new();
        let mut found_flutter = false;

        for child in children {
            let name_lower = child.name.to_lowercase();
            let cmd_joined = child.cmd.join(" ").to_lowercase();

            let is_flutter = name_lower.contains("flutter") || cmd_joined.contains("flutter");
            let is_dart = name_lower == "dart" || name_lower.starts_with("dart");
            let is_adb = name_lower == "adb";

            if is_flutter || is_dart {
                found_flutter = true;

                // Determine port: look for VM service port (8181) or DevTools (9100+)
                let primary_port = child
                    .ports
                    .iter()
                    .find(|&&p| p == 8181 || (9100..=9199).contains(&p))
                    .copied();

                let display_name = if is_flutter {
                    "Flutter App"
                } else {
                    "Dart VM"
                };

                processes.push(ConnectorProcess {
                    session_id: Some(session_id.to_string()),
                    pid: child.pid,
                    name: display_name.to_string(),
                    status: "running".to_string(),
                    port: primary_port,
                    cpu_percent: Some(child.cpu_percent),
                    ram_bytes: Some(child.ram_bytes),
                });

                // If the dart/flutter process has multiple ports, add DevTools as a separate entry
                for &port in &child.ports {
                    let is_devtools = (9100..=9199).contains(&port);
                    if is_devtools && primary_port != Some(port) {
                        processes.push(ConnectorProcess {
                            session_id: Some(session_id.to_string()),
                            pid: child.pid,
                            name: "DevTools".to_string(),
                            status: "running".to_string(),
                            port: Some(port),
                            cpu_percent: None,
                            ram_bytes: None,
                        });
                    }
                }
            } else if is_adb {
                processes.push(ConnectorProcess {
                    session_id: Some(session_id.to_string()),
                    pid: child.pid,
                    name: "adb".to_string(),
                    status: "running".to_string(),
                    port: child.ports.first().copied(),
                    cpu_percent: Some(child.cpu_percent),
                    ram_bytes: Some(child.ram_bytes),
                });
            }
        }

        if !found_flutter {
            return None;
        }

        // Determine health: all processes running = healthy
        let health = if processes.iter().all(|p| p.status == "running") {
            "healthy"
        } else {
            "degraded"
        };

        let total_ram: u64 = processes
            .iter()
            .filter_map(|p| p.ram_bytes)
            .sum();

        Some(ConnectorGroup {
            id: format!("flutter-{}", session_id),
            name: "Flutter App".to_string(),
            connector_type: "flutter".to_string(),
            sessions: processes,
            health: health.to_string(),
            metadata: serde_json::json!({
                "total_ram_bytes": total_ram,
            }),
        })
    }
}
