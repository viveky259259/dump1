use super::{ConnectorGroup, ConnectorProcess};
use serde::Deserialize;
use std::collections::HashMap;
use sysinfo::System;

/// Detects running Docker Compose projects.
///
/// Shells out to `docker compose ps --format json` to list containers,
/// then maps container ports to host ports.
pub struct DockerDetector;

/// Minimal representation of `docker compose ps --format json` output.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "PascalCase")]
#[allow(dead_code)]
struct DockerComposeContainer {
    #[serde(alias = "ID")]
    id: Option<String>,
    name: Option<String>,
    service: Option<String>,
    state: Option<String>,
    #[serde(alias = "Publishers")]
    publishers: Option<serde_json::Value>,
}

impl DockerDetector {
    pub fn detect(
        _system: &System,
        _pid_ports: &HashMap<u32, Vec<u16>>,
    ) -> Option<ConnectorGroup> {
        // Check if docker CLI is available
        let output = match std::process::Command::new("docker")
            .args(["compose", "ps", "--format", "json"])
            .output()
        {
            Ok(o) => o,
            Err(_) => return None, // docker not installed or not in PATH
        };

        if !output.status.success() {
            return None; // No compose project running or docker daemon not running
        }

        let stdout = String::from_utf8_lossy(&output.stdout);
        let stdout = stdout.trim();
        if stdout.is_empty() {
            return None;
        }

        let containers = parse_compose_output(stdout);
        if containers.is_empty() {
            return None;
        }

        let mut processes: Vec<ConnectorProcess> = Vec::new();
        let mut any_running = false;
        let mut any_stopped = false;

        for container in &containers {
            let name = container
                .service
                .as_deref()
                .or(container.name.as_deref())
                .unwrap_or("unknown")
                .to_string();

            let state = container
                .state
                .as_deref()
                .unwrap_or("unknown")
                .to_lowercase();

            let status = if state.contains("running") || state.contains("up") {
                any_running = true;
                "running"
            } else {
                any_stopped = true;
                "stopped"
            };

            // Extract the first published host port
            let port = extract_host_port(&container.publishers);

            processes.push(ConnectorProcess {
                session_id: None,
                pid: 0, // Docker containers don't map to host PIDs directly
                name,
                status: status.to_string(),
                port,
                cpu_percent: None,
                ram_bytes: None,
            });
        }

        let health = if any_running && !any_stopped {
            "healthy"
        } else if any_running && any_stopped {
            "degraded"
        } else {
            "down"
        };

        Some(ConnectorGroup {
            id: "docker-compose".to_string(),
            name: "Docker Compose".to_string(),
            connector_type: "docker".to_string(),
            sessions: processes,
            health: health.to_string(),
            metadata: serde_json::json!({
                "container_count": containers.len(),
            }),
        })
    }
}

/// Parse `docker compose ps --format json` output.
///
/// Docker may emit one JSON object per line (NDJSON) or a JSON array.
fn parse_compose_output(stdout: &str) -> Vec<DockerComposeContainer> {
    // Try as a JSON array first
    if let Ok(containers) = serde_json::from_str::<Vec<DockerComposeContainer>>(stdout) {
        return containers;
    }

    // Try line-by-line (NDJSON)
    stdout
        .lines()
        .filter_map(|line| {
            let line = line.trim();
            if line.is_empty() {
                return None;
            }
            serde_json::from_str::<DockerComposeContainer>(line).ok()
        })
        .collect()
}

/// Extract the first published host port from a container's publishers field.
///
/// The publishers field can be an array of objects like:
/// `[{"URL":"","TargetPort":3000,"PublishedPort":3000,"Protocol":"tcp"}]`
fn extract_host_port(publishers: &Option<serde_json::Value>) -> Option<u16> {
    let publishers = publishers.as_ref()?;
    let arr = publishers.as_array()?;
    for entry in arr {
        if let Some(port) = entry
            .get("PublishedPort")
            .and_then(|v| v.as_u64())
            .map(|p| p as u16)
        {
            if port > 0 {
                return Some(port);
            }
        }
    }
    None
}
