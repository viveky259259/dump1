use super::detector::ChildInfo;
use super::{ConnectorGroup, ConnectorProcess};

/// Detects Node.js debug / inspect sessions.
///
/// Looks for:
/// - `node` processes with `--inspect` or `--inspect-brk` flags
/// - Debug port (typically 9229)
pub struct NodeDetector;

impl NodeDetector {
    pub fn detect(session_id: &str, children: &[ChildInfo]) -> Option<ConnectorGroup> {
        let mut processes: Vec<ConnectorProcess> = Vec::new();

        for child in children {
            let name_lower = child.name.to_lowercase();
            let cmd_joined = child.cmd.join(" ");

            let is_node = name_lower == "node" || name_lower.starts_with("node");

            if !is_node {
                continue;
            }

            let has_inspect = cmd_joined.contains("--inspect")
                || cmd_joined.contains("--inspect-brk");

            // Only create a connector group if there's an inspect flag or a debug port
            let debug_port = if has_inspect {
                // Look for explicit port in --inspect=host:port
                let inspect_port = cmd_joined
                    .split_whitespace()
                    .find(|s| s.starts_with("--inspect") && s.contains('='))
                    .and_then(|s| {
                        let val = s.split('=').nth(1)?;
                        // Could be host:port or just port
                        if let Some(colon) = val.rfind(':') {
                            val[colon + 1..].parse::<u16>().ok()
                        } else {
                            val.parse::<u16>().ok()
                        }
                    });

                inspect_port.or_else(|| {
                    // Default inspect port is 9229
                    if child.ports.contains(&9229) {
                        Some(9229)
                    } else {
                        child.ports.first().copied()
                    }
                })
            } else {
                // Node process without --inspect — check if it's listening on 9229 anyway
                if child.ports.contains(&9229) {
                    Some(9229)
                } else {
                    // Not a debug session — still include if listening on any port
                    child.ports.first().copied()
                }
            };

            // Only include Node processes that are listening on a port or have inspect mode
            if !has_inspect && child.ports.is_empty() {
                continue;
            }

            processes.push(ConnectorProcess {
                session_id: Some(session_id.to_string()),
                pid: child.pid,
                name: if has_inspect {
                    "Node (debug)".to_string()
                } else {
                    "Node".to_string()
                },
                status: "running".to_string(),
                port: debug_port,
                cpu_percent: Some(child.cpu_percent),
                ram_bytes: Some(child.ram_bytes),
            });
        }

        if processes.is_empty() {
            return None;
        }

        let health = if processes.iter().all(|p| p.status == "running") {
            "healthy"
        } else {
            "degraded"
        };

        let total_ram: u64 = processes.iter().filter_map(|p| p.ram_bytes).sum();

        Some(ConnectorGroup {
            id: format!("node-{}", session_id),
            name: "Node.js".to_string(),
            connector_type: "node".to_string(),
            sessions: processes,
            health: health.to_string(),
            metadata: serde_json::json!({
                "total_ram_bytes": total_ram,
            }),
        })
    }
}
