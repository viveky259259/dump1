pub mod detector;
pub mod docker;
pub mod flutter;
pub mod node;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConnectorGroup {
    pub id: String,
    pub name: String,
    pub connector_type: String, // "flutter", "node", "docker", "custom"
    pub sessions: Vec<ConnectorProcess>,
    pub health: String, // "healthy", "degraded", "down"
    pub metadata: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConnectorProcess {
    pub session_id: Option<String>,
    pub pid: u32,
    pub name: String,
    pub status: String, // "running", "stopped"
    pub port: Option<u16>,
    pub cpu_percent: Option<f32>,
    pub ram_bytes: Option<u64>,
}

/// Returns a list of (pid, port) for all TCP LISTEN sockets on this host.
/// Shells out to `lsof` on macOS; returns an empty Vec on failure.
pub fn get_listening_ports() -> Vec<(u32, u16)> {
    let output = match std::process::Command::new("lsof")
        .args(["-i", "-P", "-n", "-sTCP:LISTEN"])
        .output()
    {
        Ok(o) => o,
        Err(e) => {
            log::debug!("lsof failed: {}", e);
            return Vec::new();
        }
    };

    if !output.status.success() {
        return Vec::new();
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    parse_lsof_output(&stdout)
}

/// Parse lsof output lines into (pid, port) tuples.
///
/// Example line:
/// ```text
/// node    12345 user   23u  IPv4 0x1234  0t0  TCP *:3000 (LISTEN)
/// ```
fn parse_lsof_output(output: &str) -> Vec<(u32, u16)> {
    let mut results = Vec::new();
    for line in output.lines().skip(1) {
        // skip header
        let cols: Vec<&str> = line.split_whitespace().collect();
        if cols.len() < 9 {
            continue;
        }
        let pid: u32 = match cols[1].parse() {
            Ok(p) => p,
            Err(_) => continue,
        };
        // The address:port column is typically cols[8], e.g. "*:3000" or "127.0.0.1:8080"
        let addr_col = cols[8];
        if let Some(colon_pos) = addr_col.rfind(':') {
            let port_str = &addr_col[colon_pos + 1..];
            if let Ok(port) = port_str.parse::<u16>() {
                results.push((pid, port));
            }
        }
    }
    results
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_lsof_empty() {
        assert_eq!(parse_lsof_output(""), Vec::<(u32, u16)>::new());
    }

    #[test]
    fn test_parse_lsof_typical() {
        let output = "COMMAND     PID   USER   FD   TYPE             DEVICE SIZE/OFF NODE NAME\n\
                       node      12345  user   23u  IPv4 0xabc      0t0  TCP *:3000 (LISTEN)\n\
                       dart      67890  user   11u  IPv6 0xdef      0t0  TCP [::1]:8181 (LISTEN)";
        let result = parse_lsof_output(output);
        assert_eq!(result, vec![(12345, 3000), (67890, 8181)]);
    }
}
