use super::{get_listening_ports, ConnectorGroup};
use sysinfo::{Pid, System};
use std::collections::HashMap;

/// Scans running processes to auto-detect connector groups linked to Ocean sessions.
pub struct AutoDetector {
    system: System,
}

impl AutoDetector {
    pub fn new() -> Self {
        Self {
            system: System::new_all(),
        }
    }

    /// Detect connector groups for the given sessions.
    ///
    /// `sessions` is a list of `(session_id, shell_pid)` tuples for all active
    /// Ocean sessions.  The detector refreshes the process list, scans listening
    /// ports, and delegates to the per-technology detectors (Flutter, Node,
    /// Docker).
    pub fn detect_connectors(
        &mut self,
        sessions: &[(String, u32)],
    ) -> Vec<ConnectorGroup> {
        // Refresh process info
        self.system.refresh_processes(sysinfo::ProcessesToUpdate::All, true);

        // Get listening ports once (shared across detectors)
        let listening_ports = get_listening_ports();

        // Build a pid -> ports lookup
        let mut pid_ports: HashMap<u32, Vec<u16>> = HashMap::new();
        for &(pid, port) in &listening_ports {
            pid_ports.entry(pid).or_default().push(port);
        }

        let mut groups: Vec<ConnectorGroup> = Vec::new();

        for (session_id, shell_pid) in sessions {
            // Collect the child process tree for this session's shell PID
            let children = self.get_child_tree(*shell_pid);

            // Gather process info for each child
            let child_infos: Vec<ChildInfo> = children
                .iter()
                .filter_map(|&cpid| {
                    let proc = self.system.process(Pid::from(cpid as usize))?;
                    let name = proc.name().to_string_lossy().to_string();
                    let cmd: Vec<String> = proc
                        .cmd()
                        .iter()
                        .map(|s| s.to_string_lossy().to_string())
                        .collect();
                    let ports = pid_ports.get(&cpid).cloned().unwrap_or_default();
                    Some(ChildInfo {
                        pid: cpid,
                        name,
                        cmd,
                        ports,
                        cpu_percent: proc.cpu_usage(),
                        ram_bytes: proc.memory(),
                    })
                })
                .collect();

            // Try each detector
            if let Some(g) = super::flutter::FlutterDetector::detect(session_id, &child_infos) {
                groups.push(g);
            }

            if let Some(g) = super::node::NodeDetector::detect(session_id, &child_infos) {
                groups.push(g);
            }

            // Docker is session-independent, but we only add it once
        }

        // Docker detection: runs once, not per-session
        if let Some(g) = super::docker::DockerDetector::detect(&self.system, &pid_ports) {
            groups.push(g);
        }

        groups
    }

    /// Walk the process tree down from `root_pid` and collect all descendant PIDs.
    fn get_child_tree(&self, root_pid: u32) -> Vec<u32> {
        let mut result = Vec::new();
        let mut stack = vec![root_pid];

        while let Some(pid) = stack.pop() {
            // Don't include the root shell itself in the child list
            if pid != root_pid {
                result.push(pid);
            }
            // Find direct children of `pid`
            for (child_pid, process) in self.system.processes() {
                if let Some(parent) = process.parent() {
                    if parent.as_u32() == pid {
                        stack.push(child_pid.as_u32());
                    }
                }
            }
        }

        result
    }
}

/// Information about a child process used by technology-specific detectors.
pub struct ChildInfo {
    pub pid: u32,
    pub name: String,
    pub cmd: Vec<String>,
    pub ports: Vec<u16>,
    pub cpu_percent: f32,
    pub ram_bytes: u64,
}
