#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    ocean_lib::run()
}
