use chrono::Utc;
use rusqlite::{params, Connection, Result as SqlResult};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Workspace {
    pub id: String,
    pub name: String,
    pub created_at: String,
    pub archived_at: Option<String>,
    pub repo_path: Option<String>,
    pub base_snapshot_path: Option<String>,
    pub base_commit: Option<String>,
    pub git_branch: Option<String>,
    pub git_pr_url: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionState {
    pub session_id: String,
    pub delta_path: Option<String>,
    pub mount_path: Option<String>,
    pub fs_mode: String,
    pub modified_files: Option<String>,
    pub created_files: Option<String>,
    pub deleted_files: Option<String>,
    pub delta_size_bytes: i64,
    pub merged_to_parent: bool,
    pub merged_at: Option<String>,
    pub git_commit: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Session {
    pub id: String,
    pub workspace_id: String,
    pub parent_id: Option<String>,
    pub name: String,
    pub session_type: String,
    pub status: String,
    pub pty_id: Option<String>,
    pub process_pid: Option<i64>,
    pub created_at: String,
    pub ended_at: Option<String>,
    pub exit_code: Option<i32>,
}

pub struct Database {
    conn: Connection,
}

impl Database {
    pub fn new(path: Option<PathBuf>) -> SqlResult<Self> {
        let conn = match path {
            Some(p) => {
                if let Some(parent) = p.parent() {
                    std::fs::create_dir_all(parent).ok();
                }
                Connection::open(p)?
            }
            None => Connection::open_in_memory()?,
        };

        conn.execute_batch("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;")?;

        let db = Database { conn };
        db.run_migrations()?;
        Ok(db)
    }

    fn run_migrations(&self) -> SqlResult<()> {
        self.conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL
            );"
        )?;

        let current_version: i64 = self.conn
            .query_row("SELECT COALESCE(MAX(version), 0) FROM schema_migrations", [], |row| row.get(0))
            .unwrap_or(0);

        if current_version < 1 {
            self.conn.execute_batch(
                "CREATE TABLE workspaces (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    archived_at TEXT
                );

                CREATE TABLE sessions (
                    id TEXT PRIMARY KEY,
                    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
                    parent_id TEXT REFERENCES sessions(id),
                    name TEXT NOT NULL,
                    session_type TEXT NOT NULL DEFAULT 'shell',
                    status TEXT NOT NULL DEFAULT 'active',
                    pty_id TEXT,
                    process_pid INTEGER,
                    created_at TEXT NOT NULL,
                    ended_at TEXT,
                    exit_code INTEGER
                );

                CREATE TABLE session_links (
                    id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL REFERENCES sessions(id),
                    target_id TEXT NOT NULL REFERENCES sessions(id),
                    link_type TEXT NOT NULL
                );

                CREATE INDEX idx_sessions_workspace ON sessions(workspace_id);
                CREATE INDEX idx_sessions_parent ON sessions(parent_id);
                CREATE INDEX idx_sessions_status ON sessions(status);

                INSERT INTO schema_migrations (version, applied_at) VALUES (1, datetime('now'));"
            )?;
        }

        if current_version < 2 {
            self.conn.execute_batch(
                "ALTER TABLE workspaces ADD COLUMN repo_path TEXT;
                ALTER TABLE workspaces ADD COLUMN base_snapshot_path TEXT;
                ALTER TABLE workspaces ADD COLUMN base_commit TEXT;
                ALTER TABLE workspaces ADD COLUMN git_branch TEXT;
                ALTER TABLE workspaces ADD COLUMN git_pr_url TEXT;

                CREATE TABLE IF NOT EXISTS session_states (
                    session_id TEXT PRIMARY KEY REFERENCES sessions(id),
                    delta_path TEXT,
                    mount_path TEXT,
                    fs_mode TEXT DEFAULT 'none',
                    modified_files TEXT,
                    created_files TEXT,
                    deleted_files TEXT,
                    delta_size_bytes INTEGER DEFAULT 0,
                    merged_to_parent INTEGER DEFAULT 0,
                    merged_at TEXT,
                    git_commit TEXT
                );

                INSERT INTO schema_migrations (version, applied_at) VALUES (2, datetime('now'));"
            )?;
        }

        Ok(())
    }

    // Workspace CRUD

    pub fn create_workspace(&self, name: &str) -> SqlResult<Workspace> {
        let workspace = Workspace {
            id: Uuid::new_v4().to_string(),
            name: name.to_string(),
            created_at: Utc::now().to_rfc3339(),
            archived_at: None,
            repo_path: None,
            base_snapshot_path: None,
            base_commit: None,
            git_branch: None,
            git_pr_url: None,
        };

        self.conn.execute(
            "INSERT INTO workspaces (id, name, created_at) VALUES (?1, ?2, ?3)",
            params![workspace.id, workspace.name, workspace.created_at],
        )?;

        Ok(workspace)
    }

    pub fn create_workspace_with_repo(
        &self,
        name: &str,
        repo_path: &str,
        base_snapshot_path: Option<&str>,
        base_commit: Option<&str>,
    ) -> SqlResult<Workspace> {
        let workspace = Workspace {
            id: Uuid::new_v4().to_string(),
            name: name.to_string(),
            created_at: Utc::now().to_rfc3339(),
            archived_at: None,
            repo_path: Some(repo_path.to_string()),
            base_snapshot_path: base_snapshot_path.map(|s| s.to_string()),
            base_commit: base_commit.map(|s| s.to_string()),
            git_branch: None,
            git_pr_url: None,
        };

        self.conn.execute(
            "INSERT INTO workspaces (id, name, created_at, repo_path, base_snapshot_path, base_commit)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
            params![
                workspace.id,
                workspace.name,
                workspace.created_at,
                workspace.repo_path,
                workspace.base_snapshot_path,
                workspace.base_commit,
            ],
        )?;

        Ok(workspace)
    }

    pub fn update_workspace_snapshot(
        &self,
        workspace_id: &str,
        base_snapshot_path: &str,
        base_commit: Option<&str>,
    ) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE workspaces SET base_snapshot_path = ?1, base_commit = ?2 WHERE id = ?3",
            params![base_snapshot_path, base_commit, workspace_id],
        )?;
        Ok(())
    }

    pub fn update_workspace_git(
        &self,
        workspace_id: &str,
        git_branch: Option<&str>,
        git_pr_url: Option<&str>,
    ) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE workspaces SET git_branch = ?1, git_pr_url = ?2 WHERE id = ?3",
            params![git_branch, git_pr_url, workspace_id],
        )?;
        Ok(())
    }

    pub fn list_workspaces(&self) -> SqlResult<Vec<Workspace>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, name, created_at, archived_at, repo_path, base_snapshot_path, base_commit, git_branch, git_pr_url
             FROM workspaces WHERE archived_at IS NULL ORDER BY created_at"
        )?;

        let workspaces = stmt.query_map([], |row| {
            Ok(Workspace {
                id: row.get(0)?,
                name: row.get(1)?,
                created_at: row.get(2)?,
                archived_at: row.get(3)?,
                repo_path: row.get(4)?,
                base_snapshot_path: row.get(5)?,
                base_commit: row.get(6)?,
                git_branch: row.get(7)?,
                git_pr_url: row.get(8)?,
            })
        })?.collect::<SqlResult<Vec<_>>>()?;

        Ok(workspaces)
    }

    pub fn get_workspace(&self, id: &str) -> SqlResult<Workspace> {
        self.conn.query_row(
            "SELECT id, name, created_at, archived_at, repo_path, base_snapshot_path, base_commit, git_branch, git_pr_url
             FROM workspaces WHERE id = ?1",
            params![id],
            |row| {
                Ok(Workspace {
                    id: row.get(0)?,
                    name: row.get(1)?,
                    created_at: row.get(2)?,
                    archived_at: row.get(3)?,
                    repo_path: row.get(4)?,
                    base_snapshot_path: row.get(5)?,
                    base_commit: row.get(6)?,
                    git_branch: row.get(7)?,
                    git_pr_url: row.get(8)?,
                })
            },
        )
    }

    // Session CRUD

    pub fn create_session(
        &self,
        workspace_id: &str,
        parent_id: Option<&str>,
        name: &str,
        session_type: &str,
    ) -> SqlResult<Session> {
        let session = Session {
            id: Uuid::new_v4().to_string(),
            workspace_id: workspace_id.to_string(),
            parent_id: parent_id.map(|s| s.to_string()),
            name: name.to_string(),
            session_type: session_type.to_string(),
            status: "active".to_string(),
            pty_id: None,
            process_pid: None,
            created_at: Utc::now().to_rfc3339(),
            ended_at: None,
            exit_code: None,
        };

        self.conn.execute(
            "INSERT INTO sessions (id, workspace_id, parent_id, name, session_type, status, created_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
            params![
                session.id,
                session.workspace_id,
                session.parent_id,
                session.name,
                session.session_type,
                session.status,
                session.created_at,
            ],
        )?;

        Ok(session)
    }

    pub fn list_sessions(&self, workspace_id: &str) -> SqlResult<Vec<Session>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, workspace_id, parent_id, name, session_type, status, pty_id, process_pid, created_at, ended_at, exit_code
             FROM sessions WHERE workspace_id = ?1 ORDER BY created_at"
        )?;

        let sessions = stmt.query_map(params![workspace_id], |row| {
            Ok(Session {
                id: row.get(0)?,
                workspace_id: row.get(1)?,
                parent_id: row.get(2)?,
                name: row.get(3)?,
                session_type: row.get(4)?,
                status: row.get(5)?,
                pty_id: row.get(6)?,
                process_pid: row.get(7)?,
                created_at: row.get(8)?,
                ended_at: row.get(9)?,
                exit_code: row.get(10)?,
            })
        })?.collect::<SqlResult<Vec<_>>>()?;

        Ok(sessions)
    }

    pub fn get_session(&self, id: &str) -> SqlResult<Session> {
        self.conn.query_row(
            "SELECT id, workspace_id, parent_id, name, session_type, status, pty_id, process_pid, created_at, ended_at, exit_code
             FROM sessions WHERE id = ?1",
            params![id],
            |row| {
                Ok(Session {
                    id: row.get(0)?,
                    workspace_id: row.get(1)?,
                    parent_id: row.get(2)?,
                    name: row.get(3)?,
                    session_type: row.get(4)?,
                    status: row.get(5)?,
                    pty_id: row.get(6)?,
                    process_pid: row.get(7)?,
                    created_at: row.get(8)?,
                    ended_at: row.get(9)?,
                    exit_code: row.get(10)?,
                })
            },
        )
    }

    pub fn update_session_pty(&self, session_id: &str, pty_id: &str, pid: i64) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE sessions SET pty_id = ?1, process_pid = ?2 WHERE id = ?3",
            params![pty_id, pid, session_id],
        )?;
        Ok(())
    }

    pub fn rename_session(&self, session_id: &str, name: &str) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE sessions SET name = ?1 WHERE id = ?2",
            params![name, session_id],
        )?;
        Ok(())
    }

    pub fn update_session_status(&self, session_id: &str, status: &str) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE sessions SET status = ?1 WHERE id = ?2",
            params![status, session_id],
        )?;
        Ok(())
    }

    pub fn close_session(&self, session_id: &str, exit_code: i32) -> SqlResult<()> {
        let status = if exit_code == 0 { "completed" } else { "failed" };
        self.conn.execute(
            "UPDATE sessions SET status = ?1, exit_code = ?2, ended_at = ?3 WHERE id = ?4",
            params![status, exit_code, Utc::now().to_rfc3339(), session_id],
        )?;
        Ok(())
    }

    // Session State CRUD

    pub fn create_session_state(
        &self,
        session_id: &str,
        mount_path: Option<&str>,
        fs_mode: &str,
    ) -> SqlResult<SessionState> {
        let state = SessionState {
            session_id: session_id.to_string(),
            delta_path: None,
            mount_path: mount_path.map(|s| s.to_string()),
            fs_mode: fs_mode.to_string(),
            modified_files: None,
            created_files: None,
            deleted_files: None,
            delta_size_bytes: 0,
            merged_to_parent: false,
            merged_at: None,
            git_commit: None,
        };

        self.conn.execute(
            "INSERT INTO session_states (session_id, mount_path, fs_mode)
             VALUES (?1, ?2, ?3)",
            params![state.session_id, state.mount_path, state.fs_mode],
        )?;

        Ok(state)
    }

    pub fn get_session_state(&self, session_id: &str) -> SqlResult<SessionState> {
        self.conn.query_row(
            "SELECT session_id, delta_path, mount_path, fs_mode, modified_files,
                    created_files, deleted_files, delta_size_bytes, merged_to_parent,
                    merged_at, git_commit
             FROM session_states WHERE session_id = ?1",
            params![session_id],
            |row| {
                Ok(SessionState {
                    session_id: row.get(0)?,
                    delta_path: row.get(1)?,
                    mount_path: row.get(2)?,
                    fs_mode: row.get(3)?,
                    modified_files: row.get(4)?,
                    created_files: row.get(5)?,
                    deleted_files: row.get(6)?,
                    delta_size_bytes: row.get(7)?,
                    merged_to_parent: row.get::<_, i64>(8)? != 0,
                    merged_at: row.get(9)?,
                    git_commit: row.get(10)?,
                })
            },
        )
    }

    pub fn update_session_state_delta(
        &self,
        session_id: &str,
        modified_files: &str,
        created_files: &str,
        deleted_files: &str,
        delta_size_bytes: i64,
    ) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE session_states SET modified_files = ?1, created_files = ?2,
             deleted_files = ?3, delta_size_bytes = ?4 WHERE session_id = ?5",
            params![modified_files, created_files, deleted_files, delta_size_bytes, session_id],
        )?;
        Ok(())
    }

    pub fn update_session_state_merged(
        &self,
        session_id: &str,
        merged: bool,
    ) -> SqlResult<()> {
        let merged_at = if merged {
            Some(Utc::now().to_rfc3339())
        } else {
            None
        };
        self.conn.execute(
            "UPDATE session_states SET merged_to_parent = ?1, merged_at = ?2 WHERE session_id = ?3",
            params![merged as i64, merged_at, session_id],
        )?;
        Ok(())
    }

    pub fn update_session_state_git_commit(
        &self,
        session_id: &str,
        commit_hash: &str,
    ) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE session_states SET git_commit = ?1 WHERE session_id = ?2",
            params![commit_hash, session_id],
        )?;
        Ok(())
    }

    pub fn delete_session_state(&self, session_id: &str) -> SqlResult<()> {
        self.conn.execute(
            "DELETE FROM session_states WHERE session_id = ?1",
            params![session_id],
        )?;
        Ok(())
    }

    /// Delete all sessions and workspaces — fresh start.
    pub fn clear_all(&self) -> SqlResult<()> {
        self.conn.execute_batch(
            "DELETE FROM session_states;
             DELETE FROM session_links;
             DELETE FROM sessions;
             DELETE FROM workspaces;"
        )?;
        Ok(())
    }

    /// Mark all "active"/"idle"/"waiting" sessions as completed on startup — their PTYs are dead.
    pub fn mark_stale_sessions(&self) -> SqlResult<usize> {
        let count = self.conn.execute(
            "UPDATE sessions SET status = 'completed', exit_code = -1, ended_at = ?1
             WHERE status IN ('active', 'idle', 'waiting')",
            params![Utc::now().to_rfc3339()],
        )?;
        Ok(count)
    }

    /// Get all sessions that were active/idle/waiting when the app last closed.
    /// These are candidates for respawning.
    pub fn get_stale_sessions(&self) -> SqlResult<Vec<Session>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, workspace_id, parent_id, name, session_type, status, pty_id, process_pid, created_at, ended_at, exit_code
             FROM sessions WHERE status IN ('active', 'idle', 'waiting') ORDER BY created_at"
        )?;
        let sessions = stmt.query_map([], |row| {
            Ok(Session {
                id: row.get(0)?,
                workspace_id: row.get(1)?,
                parent_id: row.get(2)?,
                name: row.get(3)?,
                session_type: row.get(4)?,
                status: row.get(5)?,
                pty_id: row.get(6)?,
                process_pid: row.get(7)?,
                created_at: row.get(8)?,
                ended_at: row.get(9)?,
                exit_code: row.get(10)?,
            })
        })?.collect::<SqlResult<Vec<_>>>()?;
        Ok(sessions)
    }

    /// Update a session's PTY info after respawning (reuse existing session ID).
    pub fn revive_session(&self, session_id: &str, pty_id: &str, pid: i64) -> SqlResult<()> {
        self.conn.execute(
            "UPDATE sessions SET status = 'active', pty_id = ?1, process_pid = ?2, ended_at = NULL, exit_code = NULL WHERE id = ?3",
            params![pty_id, pid, session_id],
        )?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_create_workspace() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test Workspace").unwrap();
        assert_eq!(ws.name, "Test Workspace");
        assert!(ws.archived_at.is_none());
    }

    #[test]
    fn test_list_workspaces() {
        let db = Database::new(None).unwrap();
        db.create_workspace("WS1").unwrap();
        db.create_workspace("WS2").unwrap();
        let list = db.list_workspaces().unwrap();
        assert_eq!(list.len(), 2);
    }

    #[test]
    fn test_create_and_list_sessions() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s1 = db.create_session(&ws.id, None, "Shell 1", "shell").unwrap();
        let s2 = db.create_session(&ws.id, Some(&s1.id), "Child", "agent").unwrap();

        let sessions = db.list_sessions(&ws.id).unwrap();
        assert_eq!(sessions.len(), 2);
        assert_eq!(sessions[1].parent_id.as_deref(), Some(s1.id.as_str()));
    }

    #[test]
    fn test_close_session() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s = db.create_session(&ws.id, None, "Shell", "shell").unwrap();

        db.close_session(&s.id, 0).unwrap();
        let updated = db.get_session(&s.id).unwrap();
        assert_eq!(updated.status, "completed");
        assert_eq!(updated.exit_code, Some(0));
    }

    #[test]
    fn test_close_session_failed() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s = db.create_session(&ws.id, None, "Shell", "shell").unwrap();

        db.close_session(&s.id, 1).unwrap();
        let updated = db.get_session(&s.id).unwrap();
        assert_eq!(updated.status, "failed");
    }

    #[test]
    fn test_rename_session() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s = db.create_session(&ws.id, None, "Shell", "shell").unwrap();
        assert_eq!(s.name, "Shell");

        db.rename_session(&s.id, "My Custom Name").unwrap();
        let updated = db.get_session(&s.id).unwrap();
        assert_eq!(updated.name, "My Custom Name");
    }

    #[test]
    fn test_rename_session_preserves_status() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s = db.create_session(&ws.id, None, "Shell", "shell").unwrap();

        db.rename_session(&s.id, "Renamed").unwrap();
        let updated = db.get_session(&s.id).unwrap();
        assert_eq!(updated.name, "Renamed");
        assert_eq!(updated.status, "active"); // status unchanged
        assert_eq!(updated.workspace_id, ws.id); // workspace unchanged
    }

    #[test]
    fn test_get_stale_sessions() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s1 = db.create_session(&ws.id, None, "Shell 1", "shell").unwrap();
        let s2 = db.create_session(&ws.id, None, "Shell 2", "shell").unwrap();
        let s3 = db.create_session(&ws.id, None, "Shell 3", "shell").unwrap();

        // Close one session
        db.close_session(&s3.id, 0).unwrap();

        // s1 and s2 are still "active", s3 is "completed"
        let stale = db.get_stale_sessions().unwrap();
        assert_eq!(stale.len(), 2);
        assert!(stale.iter().any(|s| s.id == s1.id));
        assert!(stale.iter().any(|s| s.id == s2.id));
        assert!(!stale.iter().any(|s| s.id == s3.id));
    }

    #[test]
    fn test_revive_session() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s = db.create_session(&ws.id, None, "My Session", "shell").unwrap();

        // Simulate app restart: mark as completed
        db.mark_stale_sessions().unwrap();
        let after_mark = db.get_session(&s.id).unwrap();
        assert_eq!(after_mark.status, "completed");
        assert_eq!(after_mark.exit_code, Some(-1));

        // Revive it
        db.revive_session(&s.id, "pty-new", 12345).unwrap();
        let revived = db.get_session(&s.id).unwrap();
        assert_eq!(revived.status, "active");
        assert_eq!(revived.name, "My Session"); // name preserved
        assert_eq!(revived.process_pid, Some(12345));
        assert!(revived.ended_at.is_none());
        assert!(revived.exit_code.is_none());
    }

    #[test]
    fn test_mark_stale_includes_idle_and_waiting() {
        let db = Database::new(None).unwrap();
        let ws = db.create_workspace("Test").unwrap();
        let s1 = db.create_session(&ws.id, None, "Active", "shell").unwrap();
        let s2 = db.create_session(&ws.id, None, "Idle", "shell").unwrap();

        // Manually set statuses
        db.update_session_status(&s2.id, "idle").unwrap();

        let count = db.mark_stale_sessions().unwrap();
        assert_eq!(count, 2); // both active and idle marked

        let s1_after = db.get_session(&s1.id).unwrap();
        let s2_after = db.get_session(&s2.id).unwrap();
        assert_eq!(s1_after.status, "completed");
        assert_eq!(s2_after.status, "completed");
    }
}
