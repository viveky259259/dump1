use crate::filesystem::DeltaInfo;
use git2::{Repository, Signature};
use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ShipResult {
    pub branch_name: String,
    pub pr_url: Option<String>,
    pub commit_hash: String,
    pub success: bool,
    pub message: String,
}

/// Translate a session's delta into a git commit in the given repo.
///
/// This stages all modified/created files, removes deleted files from the index,
/// and creates a commit with Ocean metadata trailers.
pub fn session_to_commit(
    repo_path: &str,
    session_id: &str,
    session_name: &str,
    delta: &DeltaInfo,
    message: Option<&str>,
) -> Result<String, String> {
    let repo = Repository::open(repo_path)
        .map_err(|e| format!("Failed to open git repo at {}: {}", repo_path, e))?;

    let mut index = repo
        .index()
        .map_err(|e| format!("Failed to get git index: {}", e))?;

    // Stage modified and created files
    let files_to_add: Vec<&str> = delta
        .modified_files
        .iter()
        .chain(delta.created_files.iter())
        .map(|s| s.as_str())
        .collect();

    for file_path in &files_to_add {
        let full_path = Path::new(repo_path).join(file_path);
        if full_path.exists() {
            index
                .add_path(Path::new(file_path))
                .map_err(|e| format!("Failed to stage {}: {}", file_path, e))?;
        }
    }

    // Remove deleted files from the index
    for file_path in &delta.deleted_files {
        index
            .remove_path(Path::new(file_path))
            .map_err(|e| format!("Failed to unstage {}: {}", file_path, e))?;
    }

    // Write the index
    let oid = index
        .write_tree()
        .map_err(|e| format!("Failed to write index tree: {}", e))?;

    index
        .write()
        .map_err(|e| format!("Failed to write index: {}", e))?;

    let tree = repo
        .find_tree(oid)
        .map_err(|e| format!("Failed to find tree: {}", e))?;

    // Build commit message
    let auto_message = format!(
        "ocean: {} changes from session \"{}\"",
        delta.modified_files.len() + delta.created_files.len() + delta.deleted_files.len(),
        session_name,
    );
    let base_msg = message.unwrap_or(&auto_message);

    // Add Ocean trailers
    let full_message = format!(
        "{}\n\nOcean-Session-Id: {}\nOcean-Session-Name: {}\nOcean-Workspace-Id: {}",
        base_msg, session_id, session_name, delta.workspace_id,
    );

    // Create signature
    let sig = repo
        .signature()
        .or_else(|_| Signature::now("Ocean", "ocean@localhost"))
        .map_err(|e| format!("Failed to create git signature: {}", e))?;

    // Get parent commit (HEAD)
    let parent = match repo.head() {
        Ok(head) => {
            let commit = head
                .peel_to_commit()
                .map_err(|e| format!("Failed to peel HEAD to commit: {}", e))?;
            Some(commit)
        }
        Err(_) => None, // No commits yet (initial commit)
    };

    let parents: Vec<&git2::Commit> = parent.iter().collect();

    let commit_oid = repo
        .commit(Some("HEAD"), &sig, &sig, &full_message, &tree, &parents)
        .map_err(|e| format!("Failed to create commit: {}", e))?;

    let hash = commit_oid.to_string();
    log::info!(
        "Created git commit {} for session {} in {}",
        &hash[..8],
        session_id,
        repo_path
    );

    Ok(hash)
}

/// Create a branch, push it, and create a PR for a workspace.
/// Uses the `gh` CLI for PR creation.
pub fn create_workspace_pr(
    repo_path: &str,
    workspace_name: &str,
    title: &str,
    body: &str,
) -> Result<ShipResult, String> {
    // Create a slug from the workspace name
    let slug: String = workspace_name
        .to_lowercase()
        .chars()
        .map(|c| if c.is_alphanumeric() || c == '-' { c } else { '-' })
        .collect::<String>()
        .trim_matches('-')
        .to_string();
    let branch_name = format!("ocean/{}", slug);

    // Get current HEAD commit hash and create branch
    let commit_hash = {
        let repo = Repository::open(repo_path)
            .map_err(|e| format!("Failed to open repo: {}", e))?;
        let head = repo
            .head()
            .map_err(|e| format!("Failed to get HEAD: {}", e))?;
        let commit = head
            .peel_to_commit()
            .map_err(|e| format!("Failed to peel to commit: {}", e))?;
        let hash = commit.id().to_string();

        // Create the branch
        repo.branch(&branch_name, &commit, false)
            .map_err(|e| format!("Failed to create branch {}: {}", branch_name, e))?;

        // Set HEAD to the new branch
        repo.set_head(&format!("refs/heads/{}", branch_name))
            .map_err(|e| format!("Failed to set HEAD to branch: {}", e))?;

        hash
    }; // repo dropped here

    // Push to remote
    let push_output = std::process::Command::new("git")
        .args(["push", "-u", "origin", "HEAD"])
        .current_dir(repo_path)
        .output()
        .map_err(|e| format!("Failed to execute git push: {}", e))?;

    if !push_output.status.success() {
        let stderr = String::from_utf8_lossy(&push_output.stderr);
        return Ok(ShipResult {
            branch_name: branch_name.clone(),
            pr_url: None,
            commit_hash,
            success: false,
            message: format!("Push failed: {}", stderr),
        });
    }

    // Create PR via gh CLI
    let pr_output = std::process::Command::new("gh")
        .args([
            "pr",
            "create",
            "--title",
            title,
            "--body",
            body,
        ])
        .current_dir(repo_path)
        .output()
        .map_err(|e| format!("Failed to execute gh pr create: {}", e))?;

    let pr_url = if pr_output.status.success() {
        let url = String::from_utf8_lossy(&pr_output.stdout).trim().to_string();
        Some(url)
    } else {
        let stderr = String::from_utf8_lossy(&pr_output.stderr);
        log::warn!("gh pr create failed: {}", stderr);
        None
    };

    let success = pr_url.is_some();
    let message = if success {
        format!("PR created on branch {}", branch_name)
    } else {
        format!(
            "Branch {} pushed but PR creation failed (gh CLI may not be installed or authenticated)",
            branch_name
        )
    };

    Ok(ShipResult {
        branch_name,
        pr_url,
        commit_hash,
        success,
        message,
    })
}
