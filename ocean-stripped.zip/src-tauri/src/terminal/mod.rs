pub mod annotator;

pub use annotator::{Annotation, AnnotationType, OutputAnnotator};
