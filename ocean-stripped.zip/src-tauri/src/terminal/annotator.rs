use parking_lot::Mutex;
use regex::{Regex, RegexSet};
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, VecDeque};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

/// The type of pattern that was detected in terminal output.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AnnotationType {
    FilePath,
    Url,
    Error,
    GitRef,
    NetworkAddr,
    TestResult,
}

/// An action that can be performed on an annotation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnnotationAction {
    pub label: String,
    pub icon: String,
    pub command: String,
    pub shortcut: Option<String>,
}

/// A single annotation representing a detected pattern in terminal output.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Annotation {
    pub id: u64,
    pub session_id: String,
    pub line: usize,
    pub col_start: usize,
    pub col_end: usize,
    pub annotation_type: AnnotationType,
    pub value: String,
    pub metadata: serde_json::Value,
    pub actions: Vec<AnnotationAction>,
}

/// Index constants for the RegexSet patterns — must match the order they're
/// added in `build_regex_set`.
const PAT_FILE_ABSOLUTE: usize = 0;
const PAT_FILE_RELATIVE: usize = 1;
const PAT_URL_HTTP: usize = 2;
const PAT_URL_LOCALHOST: usize = 3;
const PAT_ERROR_BRACKET: usize = 4;
const PAT_ERROR_STACKTRACE: usize = 5;
const PAT_ERROR_COLON: usize = 6;
const PAT_ERROR_EXCEPTION: usize = 7;
const PAT_ERROR_PYTHON: usize = 8;
const PAT_ERROR_RUST_PANIC: usize = 9;
const PAT_ERROR_GO_GOROUTINE: usize = 10;
const PAT_ERROR_CARET: usize = 11;
const PAT_GIT_SHA_FULL: usize = 12;
const PAT_GIT_SHA_SHORT: usize = 13;
const PAT_GIT_REF: usize = 14;
const PAT_NETWORK_ADDR: usize = 15;

/// All pattern strings in the order that matches the index constants above.
fn pattern_strings() -> Vec<&'static str> {
    vec![
        // 0 — File paths (absolute)
        r#"(?:^|[\s"'`(])(/[a-zA-Z0-9_./-]+(?:\.[a-zA-Z]{1,10})(?::(\d+)(?::(\d+))?)?)"#,
        // 1 — File paths (relative)
        r#"(?:^|[\s"'`(])((?:\./|\.\./)[\w./-]+(?:\.[a-zA-Z]{1,10})(?::(\d+)(?::(\d+))?)?)(?:\s|$|[)"'`])"#,
        // 2 — URLs (http/https)
        r#"https?://[^\s"'`)<>]+"#,
        // 3 — URLs (localhost)
        r#"(?:localhost|127\.0\.0\.1|0\.0\.0\.0):\d{1,5}(?:/[^\s"'`)<>]*)?"#,
        // 4 — Errors: error[E0308]: ...
        r"(?i)^.*error\[?\w*\]?:.*$",
        // 5 — Errors: stack traces (at ...)
        r"(?i)^\s*(at\s+.+\(.+:\d+:\d+\))",
        // 6 — Errors: SomeError: message
        r"(?i)^.*Error:\s+.+$",
        // 7 — Errors: SomeException: message
        r"(?i)^.*Exception:\s+.+$",
        // 8 — Errors: Python tracebacks
        r#"^\s+File ".+", line \d+"#,
        // 9 — Errors: Rust panics
        r"^thread '.+' panicked at .+:\d+:\d+",
        // 10 — Errors: Go goroutine dumps
        r"^goroutine \d+ \[.+\]:",
        // 11 — Errors: caret markers
        r"^\s*\^+\s*$",
        // 12 — Git refs: full SHA (40 hex chars)
        r"\b[0-9a-f]{40}\b",
        // 13 — Git refs: short SHA (7-12 hex chars)
        r"\b[0-9a-f]{7,12}\b",
        // 14 — Git refs: named refs
        r"(?:origin|upstream|HEAD|refs/(?:heads|tags|remotes)/)\S+",
        // 15 — Network addresses (ip:port)
        r"(?:\d{1,3}\.){3}\d{1,3}:\d{1,5}",
    ]
}

/// Maximum number of lines of annotations to keep per session.
const MAX_LINES_PER_SESSION: usize = 10_000;

/// ANSI escape sequence stripper regex pattern.
const ANSI_ESCAPE_PATTERN: &str = r"\x1b\[[0-9;]*[a-zA-Z]|\x1b\].*?\x07|\x1b\[.*?[@-~]|\x1b[()][AB012]|\x1b[>=<]|\x1b\[\?[0-9;]*[hl]";

pub struct OutputAnnotator {
    /// Compiled RegexSet for fast parallel "which patterns match?" check.
    regex_set: RegexSet,
    /// Individual compiled regexes for extracting match positions.
    individual_regexes: Vec<Regex>,
    /// ANSI escape stripper.
    ansi_regex: Regex,
    /// Monotonically increasing annotation ID.
    next_id: AtomicU64,
    /// Per-session ring-buffer annotation store: session_id -> deque of (line_number, annotations).
    store: Arc<Mutex<HashMap<String, VecDeque<(usize, Vec<Annotation>)>>>>,
}

impl OutputAnnotator {
    /// Create a new annotator, compiling all regex patterns.
    pub fn new() -> Self {
        let patterns = pattern_strings();
        let regex_set =
            RegexSet::new(&patterns).expect("Failed to compile annotation RegexSet");
        let individual_regexes = patterns
            .iter()
            .map(|p| Regex::new(p).expect("Failed to compile individual regex"))
            .collect();
        let ansi_regex =
            Regex::new(ANSI_ESCAPE_PATTERN).expect("Failed to compile ANSI regex");

        OutputAnnotator {
            regex_set,
            individual_regexes,
            ansi_regex,
            next_id: AtomicU64::new(1),
            store: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Strip ANSI escape sequences from the input string.
    fn strip_ansi(&self, input: &str) -> String {
        self.ansi_regex.replace_all(input, "").into_owned()
    }

    /// Generate the next unique annotation ID.
    fn next_id(&self) -> u64 {
        self.next_id.fetch_add(1, Ordering::Relaxed)
    }

    /// Process a single line of terminal output, returning any annotations found.
    ///
    /// Column positions are reported relative to the ANSI-stripped text.
    pub fn process_line(
        &self,
        session_id: &str,
        line_number: usize,
        raw_line: &str,
    ) -> Vec<Annotation> {
        let clean = self.strip_ansi(raw_line);
        if clean.trim().is_empty() {
            return Vec::new();
        }

        // Fast check: which pattern indices matched at all?
        let matches: Vec<usize> = self.regex_set.matches(&clean).into_iter().collect();
        if matches.is_empty() {
            return Vec::new();
        }

        let mut annotations = Vec::new();

        for &idx in &matches {
            let regex = &self.individual_regexes[idx];
            for cap in regex.find_iter(&clean) {
                let value = cap.as_str().trim().to_string();
                if value.is_empty() {
                    continue;
                }

                let col_start = cap.start();
                let col_end = cap.end();

                let (annotation_type, cleaned_value, metadata, actions) =
                    self.classify(idx, &value, &clean);

                annotations.push(Annotation {
                    id: self.next_id(),
                    session_id: session_id.to_string(),
                    line: line_number,
                    col_start,
                    col_end,
                    annotation_type,
                    value: cleaned_value,
                    metadata,
                    actions,
                });
            }
        }

        annotations
    }

    /// Classify a match by pattern index and return (type, value, metadata, actions).
    fn classify(
        &self,
        pattern_index: usize,
        raw_value: &str,
        _full_line: &str,
    ) -> (AnnotationType, String, serde_json::Value, Vec<AnnotationAction>) {
        match pattern_index {
            PAT_FILE_ABSOLUTE | PAT_FILE_RELATIVE => {
                // Strip any leading whitespace / quote chars the lookahead captured
                let value = raw_value.trim_start_matches(|c: char| c.is_whitespace() || "\"'`(".contains(c));
                // Parse optional :line:col suffix
                let (path, line_num, col_num) = parse_file_location(value);
                let mut meta = serde_json::json!({ "path": path });
                if let Some(l) = line_num {
                    meta["line"] = serde_json::json!(l);
                }
                if let Some(c) = col_num {
                    meta["column"] = serde_json::json!(c);
                }

                let open_target = if let Some(l) = line_num {
                    format!("{}:{}", path, l)
                } else {
                    path.to_string()
                };

                let actions = vec![
                    AnnotationAction {
                        label: "View in Ocean".to_string(),
                        icon: "eye".to_string(),
                        command: format!("view_in_ocean:{}", open_target),
                        shortcut: Some("Click".to_string()),
                    },
                    AnnotationAction {
                        label: "Open in Editor".to_string(),
                        icon: "edit".to_string(),
                        command: format!("open_editor:{}", open_target),
                        shortcut: Some("Cmd+Click".to_string()),
                    },
                    AnnotationAction {
                        label: "Copy Path".to_string(),
                        icon: "clipboard".to_string(),
                        command: format!("copy:{}", path),
                        shortcut: None,
                    },
                    AnnotationAction {
                        label: "Reveal in Finder".to_string(),
                        icon: "folder".to_string(),
                        command: format!("open_finder:{}", path),
                        shortcut: None,
                    },
                ];

                (AnnotationType::FilePath, value.to_string(), meta, actions)
            }
            PAT_URL_HTTP | PAT_URL_LOCALHOST => {
                let value = raw_value.trim();
                let url = if pattern_index == PAT_URL_LOCALHOST && !value.starts_with("http") {
                    format!("http://{}", value)
                } else {
                    value.to_string()
                };
                let meta = serde_json::json!({ "url": &url });
                let actions = vec![
                    AnnotationAction {
                        label: "Open in Browser".to_string(),
                        icon: "globe".to_string(),
                        command: format!("open_url:{}", url),
                        shortcut: Some("Cmd+Click".to_string()),
                    },
                    AnnotationAction {
                        label: "Copy URL".to_string(),
                        icon: "clipboard".to_string(),
                        command: format!("copy:{}", url),
                        shortcut: None,
                    },
                ];
                (AnnotationType::Url, value.to_string(), meta, actions)
            }
            PAT_ERROR_BRACKET | PAT_ERROR_STACKTRACE | PAT_ERROR_COLON
            | PAT_ERROR_EXCEPTION | PAT_ERROR_PYTHON | PAT_ERROR_RUST_PANIC
            | PAT_ERROR_GO_GOROUTINE | PAT_ERROR_CARET => {
                let value = raw_value.trim();
                // Try to extract a file:line from the error text
                let file_loc = extract_file_from_error(value);
                let mut meta = serde_json::json!({ "raw": value });
                let mut actions = Vec::new();

                if let Some((path, line_num)) = &file_loc {
                    meta["file"] = serde_json::json!(path);
                    meta["error_line"] = serde_json::json!(line_num);
                    actions.push(AnnotationAction {
                        label: "Open File at Error".to_string(),
                        icon: "alert-circle".to_string(),
                        command: format!("open_editor:{}:{}", path, line_num),
                        shortcut: Some("Cmd+Click".to_string()),
                    });
                }

                actions.push(AnnotationAction {
                    label: "Copy Error".to_string(),
                    icon: "clipboard".to_string(),
                    command: format!("copy:{}", value),
                    shortcut: None,
                });
                actions.push(AnnotationAction {
                    label: "Ask Agent to Fix".to_string(),
                    icon: "wand".to_string(),
                    command: format!("ask_agent:{}", value),
                    shortcut: None,
                });

                (AnnotationType::Error, value.to_string(), meta, actions)
            }
            PAT_GIT_SHA_FULL | PAT_GIT_SHA_SHORT | PAT_GIT_REF => {
                let value = raw_value.trim();
                let meta = serde_json::json!({ "ref": value });
                let actions = vec![
                    AnnotationAction {
                        label: "Show Diff".to_string(),
                        icon: "git-commit".to_string(),
                        command: format!("git_diff:{}", value),
                        shortcut: None,
                    },
                    AnnotationAction {
                        label: "Copy Hash".to_string(),
                        icon: "clipboard".to_string(),
                        command: format!("copy:{}", value),
                        shortcut: None,
                    },
                ];
                (AnnotationType::GitRef, value.to_string(), meta, actions)
            }
            PAT_NETWORK_ADDR => {
                let value = raw_value.trim();
                let url = format!("http://{}", value);
                let meta = serde_json::json!({ "address": value });
                let actions = vec![
                    AnnotationAction {
                        label: "Open in Browser".to_string(),
                        icon: "globe".to_string(),
                        command: format!("open_url:{}", url),
                        shortcut: None,
                    },
                    AnnotationAction {
                        label: "Copy Address".to_string(),
                        icon: "clipboard".to_string(),
                        command: format!("copy:{}", value),
                        shortcut: None,
                    },
                ];
                (AnnotationType::NetworkAddr, value.to_string(), meta, actions)
            }
            _ => {
                // Should not happen — fallback
                (
                    AnnotationType::Error,
                    raw_value.to_string(),
                    serde_json::json!({}),
                    Vec::new(),
                )
            }
        }
    }

    // ── Annotation Store ──────────────────────────────────────────────

    /// Store annotations for a given session and line.
    pub fn add_annotations(
        &self,
        session_id: &str,
        line: usize,
        annotations: Vec<Annotation>,
    ) {
        if annotations.is_empty() {
            return;
        }
        let mut store = self.store.lock();
        let deque = store
            .entry(session_id.to_string())
            .or_insert_with(VecDeque::new);

        deque.push_back((line, annotations));

        // Evict oldest entries if over the limit
        while deque.len() > MAX_LINES_PER_SESSION {
            deque.pop_front();
        }
    }

    /// Retrieve all annotations for lines in [line_start, line_end] (inclusive).
    pub fn get_annotations(
        &self,
        session_id: &str,
        line_start: usize,
        line_end: usize,
    ) -> Vec<Annotation> {
        let store = self.store.lock();
        let Some(deque) = store.get(session_id) else {
            return Vec::new();
        };

        let mut result = Vec::new();
        for (line, annotations) in deque.iter() {
            if *line >= line_start && *line <= line_end {
                result.extend(annotations.iter().cloned());
            }
        }
        result
    }

    /// Remove all stored annotations for a session.
    pub fn clear_session(&self, session_id: &str) {
        let mut store = self.store.lock();
        store.remove(session_id);
    }
}

// ── Helper Functions ──────────────────────────────────────────────────

/// Parse a file path that may contain :line:col suffixes.
/// Returns (path, optional line, optional col).
fn parse_file_location(value: &str) -> (&str, Option<usize>, Option<usize>) {
    // Try path:line:col
    let parts: Vec<&str> = value.rsplitn(3, ':').collect();
    match parts.len() {
        3 => {
            if let (Ok(col), Ok(line)) = (parts[0].parse::<usize>(), parts[1].parse::<usize>()) {
                return (parts[2], Some(line), Some(col));
            }
            // Maybe just path:line where col part wasn't numeric
            if let Ok(line) = parts[1].parse::<usize>() {
                // Recombine: parts[2]:parts[1] was the split, so path is parts[2], line is parts[1]
                // but parts[0] isn't a valid col, so just use path:line
                return (parts[2], Some(line), None);
            }
            (value, None, None)
        }
        2 => {
            if let Ok(line) = parts[0].parse::<usize>() {
                return (parts[1], Some(line), None);
            }
            (value, None, None)
        }
        _ => (value, None, None),
    }
}

/// Try to extract a file:line reference from an error message.
fn extract_file_from_error(error_text: &str) -> Option<(String, usize)> {
    // Common patterns: "at /path/file.rs:42:10", "File "foo.py", line 42"
    let file_line_re =
        Regex::new(r#"(?:at\s+|-->?\s*|File\s+")([^\s"]+):(\d+)"#).ok()?;
    let caps = file_line_re.captures(error_text)?;
    let path = caps.get(1)?.as_str().to_string();
    let line: usize = caps.get(2)?.as_str().parse().ok()?;
    Some((path, line))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_annotator() -> OutputAnnotator {
        OutputAnnotator::new()
    }

    #[test]
    fn test_strip_ansi() {
        let a = make_annotator();
        let input = "\x1b[31merror\x1b[0m: something failed";
        let stripped = a.strip_ansi(input);
        assert_eq!(stripped, "error: something failed");
    }

    #[test]
    fn test_detect_absolute_file_path() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, "  /Users/foo/bar.rs:42:10 some text");
        assert!(!anns.is_empty());
        let file_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::FilePath))
            .collect();
        assert!(!file_anns.is_empty());
        assert!(file_anns[0].value.contains("/Users/foo/bar.rs"));
    }

    #[test]
    fn test_detect_relative_file_path() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, "  ./src/main.rs:10 warning");
        let file_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::FilePath))
            .collect();
        assert!(!file_anns.is_empty());
    }

    #[test]
    fn test_detect_url() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, "Visit https://example.com/path?q=1 for docs");
        let url_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::Url))
            .collect();
        assert!(!url_anns.is_empty());
        assert!(url_anns[0].value.contains("https://example.com"));
    }

    #[test]
    fn test_detect_localhost() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, "Server running at localhost:3000/api");
        let url_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::Url))
            .collect();
        assert!(!url_anns.is_empty());
    }

    #[test]
    fn test_detect_error() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, "error[E0308]: mismatched types");
        let err_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::Error))
            .collect();
        assert!(!err_anns.is_empty());
    }

    #[test]
    fn test_detect_rust_panic() {
        let a = make_annotator();
        let anns = a.process_line(
            "s1",
            1,
            "thread 'main' panicked at src/lib.rs:42:5",
        );
        let err_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::Error))
            .collect();
        assert!(!err_anns.is_empty());
    }

    #[test]
    fn test_detect_git_sha() {
        let a = make_annotator();
        let anns = a.process_line(
            "s1",
            1,
            "commit abc1234def5678901234567890abcdef12345678",
        );
        let git_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::GitRef))
            .collect();
        assert!(!git_anns.is_empty());
    }

    #[test]
    fn test_detect_network_addr() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, "Listening on 192.168.1.1:8080");
        let net_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::NetworkAddr))
            .collect();
        assert!(!net_anns.is_empty());
    }

    #[test]
    fn test_store_and_retrieve() {
        let a = make_annotator();
        let anns = a.process_line("s1", 5, "error[E0308]: mismatched types");
        a.add_annotations("s1", 5, anns.clone());

        let retrieved = a.get_annotations("s1", 0, 10);
        assert_eq!(retrieved.len(), anns.len());

        // Out of range should return empty
        let empty = a.get_annotations("s1", 100, 200);
        assert!(empty.is_empty());
    }

    #[test]
    fn test_clear_session() {
        let a = make_annotator();
        let anns = a.process_line("s1", 5, "error[E0308]: mismatched types");
        a.add_annotations("s1", 5, anns);

        a.clear_session("s1");
        let retrieved = a.get_annotations("s1", 0, 100);
        assert!(retrieved.is_empty());
    }

    #[test]
    fn test_unique_ids() {
        let a = make_annotator();
        let anns1 = a.process_line("s1", 1, "error: first");
        let anns2 = a.process_line("s1", 2, "error: second");
        if !anns1.is_empty() && !anns2.is_empty() {
            assert_ne!(anns1[0].id, anns2[0].id);
        }
    }

    #[test]
    fn test_ansi_stripped_before_matching() {
        let a = make_annotator();
        let anns = a.process_line(
            "s1",
            1,
            "\x1b[1;31merror\x1b[0m: \x1b[1msomething failed\x1b[0m",
        );
        let err_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::Error))
            .collect();
        assert!(!err_anns.is_empty());
    }

    #[test]
    fn test_file_path_actions() {
        let a = make_annotator();
        let anns = a.process_line("s1", 1, " /tmp/foo.rs:42 error here");
        let file_anns: Vec<_> = anns
            .iter()
            .filter(|a| matches!(a.annotation_type, AnnotationType::FilePath))
            .collect();
        if !file_anns.is_empty() {
            let actions = &file_anns[0].actions;
            assert!(actions.iter().any(|a| a.label == "Open in Editor"));
            assert!(actions.iter().any(|a| a.label == "Copy Path"));
            assert!(actions.iter().any(|a| a.label == "Reveal in Finder"));
        }
    }
}
