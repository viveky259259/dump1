use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct A2UIComponent {
    pub component_id: String,
    pub component_type: String, // "Button", "Table", "Form", "Card", etc.
    pub props: serde_json::Value,
    pub children: Vec<A2UIComponent>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct A2UIResponse {
    pub component_id: String,
    pub action: String, // "click", "submit", "select"
    pub data: serde_json::Value,
}
