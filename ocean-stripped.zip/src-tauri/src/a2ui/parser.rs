use base64::Engine;
use parking_lot::Mutex;
use std::collections::HashMap;
use std::sync::Arc;

use super::types::A2UIComponent;

/// Thread-safe buffer for partial A2UI escape sequences that may be split
/// across multiple PTY reads.
pub struct A2UIParser {
    /// Per-session partial sequence buffers
    buffers: Arc<Mutex<HashMap<String, Vec<u8>>>>,
}

/// Escape sequence format: \x1b]ocean;a2ui;<base64-encoded-json>\x07
/// - ESC ] = 0x1B 0x5D (OSC start)
/// - "ocean;a2ui;" = literal prefix
/// - base64-encoded JSON payload
/// - BEL = 0x07 (OSC terminator)
///
/// Also supports ST terminator: \x1b\\ (ESC + backslash)
const OSC_START: u8 = 0x1B;
const OSC_BRACKET: u8 = 0x5D; // ]
const BEL: u8 = 0x07;
const BACKSLASH: u8 = 0x5C; // \

const PREFIX: &[u8] = b"ocean;a2ui;";

impl A2UIParser {
    pub fn new() -> Self {
        A2UIParser {
            buffers: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Scans the byte stream for A2UI escape sequences.
    /// Returns (cleaned data with sequences stripped, parsed components).
    ///
    /// Handles:
    /// - Complete sequences within a single read
    /// - Partial sequences split across multiple reads (buffered per session)
    /// - Malformed sequences (skipped with warning)
    pub fn extract_a2ui_sequences(
        &self,
        session_id: &str,
        data: &[u8],
    ) -> (Vec<u8>, Vec<A2UIComponent>) {
        let mut buffers = self.buffers.lock();
        let partial = buffers.entry(session_id.to_string()).or_default();

        // If there's a partial buffer from a previous read, prepend it
        let input = if partial.is_empty() {
            data.to_vec()
        } else {
            let mut combined = std::mem::take(partial);
            combined.extend_from_slice(data);
            combined
        };

        let mut cleaned = Vec::with_capacity(input.len());
        let mut components = Vec::new();
        let mut i = 0;

        while i < input.len() {
            // Look for ESC ] sequence start
            if input[i] == OSC_START {
                // Check if next byte is ]
                if i + 1 < input.len() {
                    if input[i + 1] == OSC_BRACKET {
                        // Check if this is our ocean;a2ui; prefix
                        let prefix_start = i + 2;
                        if prefix_start + PREFIX.len() <= input.len()
                            && &input[prefix_start..prefix_start + PREFIX.len()] == PREFIX
                        {
                            let payload_start = prefix_start + PREFIX.len();

                            // Find the terminator: BEL (0x07) or ST (ESC \)
                            match find_osc_terminator(&input, payload_start) {
                                Some((term_pos, term_len)) => {
                                    // Extract the base64 payload
                                    let payload = &input[payload_start..term_pos];

                                    // Try to decode and parse
                                    match decode_a2ui_payload(payload) {
                                        Ok(component) => {
                                            components.push(component);
                                        }
                                        Err(e) => {
                                            log::warn!(
                                                "Malformed A2UI sequence in session {}: {}",
                                                session_id,
                                                e
                                            );
                                        }
                                    }

                                    // Skip past the entire sequence
                                    i = term_pos + term_len;
                                    continue;
                                }
                                None => {
                                    // No terminator found — this is a partial sequence.
                                    // Buffer everything from ESC onwards for next read.
                                    *partial = input[i..].to_vec();
                                    // Don't include the partial in cleaned output
                                    return (cleaned, components);
                                }
                            }
                        } else if prefix_start + PREFIX.len() > input.len() {
                            // We have ESC ] but not enough bytes to check the prefix.
                            // Could be a partial A2UI sequence. Buffer it.
                            *partial = input[i..].to_vec();
                            return (cleaned, components);
                        } else {
                            // ESC ] but not our prefix — pass through as normal OSC
                            cleaned.push(input[i]);
                            i += 1;
                        }
                    } else {
                        // ESC followed by something other than ] — pass through
                        cleaned.push(input[i]);
                        i += 1;
                    }
                } else {
                    // ESC at end of buffer — might be start of our sequence
                    *partial = input[i..].to_vec();
                    return (cleaned, components);
                }
            } else {
                cleaned.push(input[i]);
                i += 1;
            }
        }

        // No partial data left
        partial.clear();
        (cleaned, components)
    }

    /// Clear the buffer for a session (e.g., when session closes)
    pub fn clear_session(&self, session_id: &str) {
        self.buffers.lock().remove(session_id);
    }
}

/// Find the OSC terminator starting from `start`. Returns (position, length) of the terminator.
/// Supports BEL (0x07, length 1) and ST (ESC \, length 2).
fn find_osc_terminator(data: &[u8], start: usize) -> Option<(usize, usize)> {
    let mut i = start;
    while i < data.len() {
        if data[i] == BEL {
            return Some((i, 1));
        }
        if data[i] == OSC_START && i + 1 < data.len() && data[i + 1] == BACKSLASH {
            return Some((i, 2));
        }
        i += 1;
    }
    None
}

/// Decode a base64-encoded A2UI payload into an A2UIComponent.
fn decode_a2ui_payload(payload: &[u8]) -> Result<A2UIComponent, String> {
    let payload_str =
        std::str::from_utf8(payload).map_err(|e| format!("Invalid UTF-8 in payload: {}", e))?;

    let decoded = base64::engine::general_purpose::STANDARD
        .decode(payload_str.trim())
        .map_err(|e| format!("Base64 decode failed: {}", e))?;

    let json_str =
        std::str::from_utf8(&decoded).map_err(|e| format!("Decoded payload not UTF-8: {}", e))?;

    serde_json::from_str(json_str).map_err(|e| format!("JSON parse failed: {}", e))
}

/// Convenience function for use without the stateful parser (no partial buffering).
/// Suitable for unit tests and one-shot parsing.
pub fn extract_a2ui_sequences(data: &[u8]) -> (Vec<u8>, Vec<A2UIComponent>) {
    let parser = A2UIParser::new();
    parser.extract_a2ui_sequences("_oneshot", data)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn make_a2ui_sequence(component: &serde_json::Value) -> Vec<u8> {
        let json_str = serde_json::to_string(component).unwrap();
        let b64 = base64::engine::general_purpose::STANDARD.encode(json_str.as_bytes());
        let mut seq = Vec::new();
        seq.push(0x1B); // ESC
        seq.push(0x5D); // ]
        seq.extend_from_slice(b"ocean;a2ui;");
        seq.extend_from_slice(b64.as_bytes());
        seq.push(0x07); // BEL
        seq
    }

    fn sample_button() -> serde_json::Value {
        json!({
            "component_id": "btn-1",
            "component_type": "Button",
            "props": { "label": "Click me" },
            "children": []
        })
    }

    fn sample_table() -> serde_json::Value {
        json!({
            "component_id": "tbl-1",
            "component_type": "Table",
            "props": {
                "columns": ["Name", "Value"],
                "rows": [["foo", "42"], ["bar", "99"]]
            },
            "children": []
        })
    }

    #[test]
    fn test_extract_single_component() {
        let component = sample_button();
        let seq = make_a2ui_sequence(&component);

        let mut data = b"Hello ".to_vec();
        data.extend_from_slice(&seq);
        data.extend_from_slice(b" World");

        let (cleaned, components) = extract_a2ui_sequences(&data);
        assert_eq!(cleaned, b"Hello  World");
        assert_eq!(components.len(), 1);
        assert_eq!(components[0].component_id, "btn-1");
        assert_eq!(components[0].component_type, "Button");
    }

    #[test]
    fn test_extract_multiple_components() {
        let btn = sample_button();
        let tbl = sample_table();

        let mut data = b"Before ".to_vec();
        data.extend_from_slice(&make_a2ui_sequence(&btn));
        data.extend_from_slice(b" Middle ");
        data.extend_from_slice(&make_a2ui_sequence(&tbl));
        data.extend_from_slice(b" After");

        let (cleaned, components) = extract_a2ui_sequences(&data);
        assert_eq!(cleaned, b"Before  Middle  After");
        assert_eq!(components.len(), 2);
        assert_eq!(components[0].component_type, "Button");
        assert_eq!(components[1].component_type, "Table");
    }

    #[test]
    fn test_no_a2ui_sequences() {
        let data = b"Regular terminal output \x1b[31mred text\x1b[0m";
        let (cleaned, components) = extract_a2ui_sequences(data);
        assert_eq!(cleaned, data);
        assert_eq!(components.len(), 0);
    }

    #[test]
    fn test_malformed_base64_skipped() {
        let mut data = b"Hello ".to_vec();
        data.push(0x1B);
        data.push(0x5D);
        data.extend_from_slice(b"ocean;a2ui;");
        data.extend_from_slice(b"not-valid-base64!!!");
        data.push(0x07);
        data.extend_from_slice(b" World");

        let (cleaned, components) = extract_a2ui_sequences(&data);
        assert_eq!(cleaned, b"Hello  World");
        assert_eq!(components.len(), 0); // malformed skipped
    }

    #[test]
    fn test_partial_sequence_buffered() {
        let component = sample_button();
        let full_seq = make_a2ui_sequence(&component);

        // Split the sequence into two parts
        let split_point = full_seq.len() / 2;
        let part1 = &full_seq[..split_point];
        let part2 = &full_seq[split_point..];

        let parser = A2UIParser::new();

        // First read: prefix text + partial sequence
        let mut data1 = b"Hello ".to_vec();
        data1.extend_from_slice(part1);

        let (cleaned1, components1) = parser.extract_a2ui_sequences("test-session", &data1);
        assert_eq!(cleaned1, b"Hello ");
        assert_eq!(components1.len(), 0); // not yet complete

        // Second read: rest of sequence + suffix text
        let mut data2 = part2.to_vec();
        data2.extend_from_slice(b" World");

        let (cleaned2, components2) = parser.extract_a2ui_sequences("test-session", &data2);
        assert_eq!(cleaned2, b" World");
        assert_eq!(components2.len(), 1);
        assert_eq!(components2[0].component_id, "btn-1");
    }

    #[test]
    fn test_st_terminator() {
        let component = sample_button();
        let json_str = serde_json::to_string(&component).unwrap();
        let b64 = base64::engine::general_purpose::STANDARD.encode(json_str.as_bytes());

        let mut data = b"Hello ".to_vec();
        data.push(0x1B); // ESC
        data.push(0x5D); // ]
        data.extend_from_slice(b"ocean;a2ui;");
        data.extend_from_slice(b64.as_bytes());
        data.push(0x1B); // ESC (ST start)
        data.push(0x5C); // \ (ST end)
        data.extend_from_slice(b" World");

        let (cleaned, components) = extract_a2ui_sequences(&data);
        assert_eq!(cleaned, b"Hello  World");
        assert_eq!(components.len(), 1);
        assert_eq!(components[0].component_id, "btn-1");
    }

    #[test]
    fn test_other_osc_sequences_pass_through() {
        // OSC 7 (CWD change) should not be consumed
        let data = b"\x1b]7;file:///Users/test\x07Regular output";
        let (cleaned, components) = extract_a2ui_sequences(data);
        // ESC passes through, the rest is normal
        assert_eq!(components.len(), 0);
        // The ESC is passed through since it's not our prefix
        assert!(cleaned.len() > 0);
    }

    #[test]
    fn test_children_parsed() {
        let component = json!({
            "component_id": "card-1",
            "component_type": "Card",
            "props": { "title": "Test Card" },
            "children": [
                {
                    "component_id": "btn-inner",
                    "component_type": "Button",
                    "props": { "label": "OK" },
                    "children": []
                }
            ]
        });

        let seq = make_a2ui_sequence(&component);
        let (_, components) = extract_a2ui_sequences(&seq);
        assert_eq!(components.len(), 1);
        assert_eq!(components[0].children.len(), 1);
        assert_eq!(components[0].children[0].component_id, "btn-inner");
    }

    #[test]
    fn test_empty_input() {
        let (cleaned, components) = extract_a2ui_sequences(b"");
        assert!(cleaned.is_empty());
        assert!(components.is_empty());
    }

    #[test]
    fn test_clear_session_buffer() {
        let parser = A2UIParser::new();

        // Write a partial sequence
        let mut partial = vec![0x1B, 0x5D];
        partial.extend_from_slice(b"ocean;a2ui;");
        partial.extend_from_slice(b"SGVsbG8"); // partial base64

        let (_, _) = parser.extract_a2ui_sequences("sess-1", &partial);

        // Buffer should be non-empty
        assert!(!parser.buffers.lock().get("sess-1").unwrap().is_empty());

        // Clear it
        parser.clear_session("sess-1");
        assert!(parser.buffers.lock().get("sess-1").is_none());
    }
}
