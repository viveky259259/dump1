import {
  sessionState,
  createSession,
  closeSession,
  setActiveSession,
} from "../stores/sessionStore";
import { splitPane, layoutState, switchToSession, createGroup, activateGroup } from "../stores/layoutStore";
import {
  toggleSidebar,
  toggleDebugConsole,
  toggleConnectorBar,
  showShipDialog,
  showCommandPalette,
  showQuickSwitcher,
  toggleSettings,
  toggleDAGView,
} from "../stores/uiStore";
import { togglePanel } from "../stores/panelStore";
import { logInfo, logWarn } from "../stores/logStore";

type Action = () => void | Promise<void>;

const actions: Record<string, Action> = {
  "new-session": async () => {
    const workspaceId = sessionState.activeWorkspaceId;
    if (!workspaceId) return;
    const session = await createSession(workspaceId);
    setActiveSession(session.id);
    createGroup(session.id, workspaceId);
  },

  "close-session": async () => {
    const sessionId = sessionState.activeSessionId;
    if (!sessionId) return;
    await closeSession(sessionId);
  },

  "split-vertical": async () => {
    const workspaceId = sessionState.activeWorkspaceId;
    const currentSessionId = layoutState.focusedSessionId ?? sessionState.activeSessionId;
    logInfo("layout", `Cmd+D: split-vertical, focused=${currentSessionId?.slice(0, 8)}`);
    if (!workspaceId || !currentSessionId) return;
    const session = await createSession(workspaceId);
    splitPane(currentSessionId, session.id, "vertical");
    setActiveSession(session.id);
  },

  "split-horizontal": async () => {
    const workspaceId = sessionState.activeWorkspaceId;
    const currentSessionId = layoutState.focusedSessionId ?? sessionState.activeSessionId;
    logInfo("layout", `Cmd+Shift+D: split-horizontal, focused=${currentSessionId?.slice(0, 8)}`);
    if (!workspaceId || !currentSessionId) return;
    const session = await createSession(workspaceId);
    splitPane(currentSessionId, session.id, "horizontal");
    setActiveSession(session.id);
  },

  // Spawn child session from currently focused session
  "spawn-child": async () => {
    const workspaceId = sessionState.activeWorkspaceId;
    const parentId = layoutState.focusedSessionId ?? sessionState.activeSessionId;
    if (!workspaceId || !parentId) return;
    logInfo("session", `Spawning child of ${parentId.slice(0, 8)}`);
    const session = await createSession(workspaceId, parentId);
    setActiveSession(session.id);
    switchToSession(session.id);
  },

  // Navigate to previous layout group
  "prev-session": () => {
    const groups = layoutState.groups;
    if (groups.length < 2) return;
    const currentIdx = groups.findIndex((g) => g.id === layoutState.activeGroupId);
    const prevIdx = currentIdx <= 0 ? groups.length - 1 : currentIdx - 1;
    activateGroup(groups[prevIdx].id);
    const focused = groups[prevIdx].focusedSessionId;
    if (focused) setActiveSession(focused);
  },

  // Navigate to next layout group
  "next-session": () => {
    const groups = layoutState.groups;
    if (groups.length < 2) return;
    const currentIdx = groups.findIndex((g) => g.id === layoutState.activeGroupId);
    const nextIdx = currentIdx >= groups.length - 1 ? 0 : currentIdx + 1;
    activateGroup(groups[nextIdx].id);
    const focused = groups[nextIdx].focusedSessionId;
    if (focused) setActiveSession(focused);
  },

  "toggle-sidebar": () => toggleSidebar(),
  "toggle-debug": () => toggleDebugConsole(),
  "toggle-connectors": () => toggleConnectorBar(),
  "toggle-git-panel": () => togglePanel("git"),
  "toggle-system-panel": () => togglePanel("system"),
  "toggle-network-panel": () => togglePanel("network"),

  "command-palette": () => showCommandPalette(),
  "quick-switcher": () => showQuickSwitcher(),
  "settings": () => toggleSettings(),
  "dag-view": () => toggleDAGView(),

  "ship-workspace": () => {
    const wsId = sessionState.activeWorkspaceId;
    const ws = sessionState.workspaces.find((w) => w.id === wsId);
    if (wsId && ws) {
      showShipDialog(wsId, ws.name);
    }
  },
};

// Group switch by index (Cmd+1-9)
for (let i = 1; i <= 9; i++) {
  actions[`switch-group-${i}`] = () => {
    const groups = layoutState.groups;
    if (groups[i - 1]) {
      activateGroup(groups[i - 1].id);
      const focused = groups[i - 1].focusedSessionId;
      if (focused) setActiveSession(focused);
    }
  };
}

const keybindings: Keybinding[] = [
  // Sessions
  { key: "t", meta: true, action: "new-session" },
  { key: "n", meta: true, action: "spawn-child" },
  { key: "w", meta: true, action: "close-session" },
  { key: "[", meta: true, action: "prev-session" },
  { key: "]", meta: true, action: "next-session" },

  // Panes
  { key: "d", meta: true, action: "split-vertical" },
  { key: "d", meta: true, shift: true, action: "split-horizontal" },

  // Panels
  { key: "b", meta: true, action: "toggle-sidebar" },
  { key: "g", meta: true, action: "toggle-git-panel" },
  { key: "k", meta: true, action: "toggle-connectors" },
  { key: "i", meta: true, shift: true, action: "toggle-debug" },

  // Palettes
  { key: "p", meta: true, shift: true, action: "command-palette" },
  { key: "p", meta: true, action: "quick-switcher" },

  // Ship
  { key: "s", meta: true, shift: true, action: "ship-workspace" },

  // Settings & views
  { key: ",", meta: true, action: "settings" },
  { key: "g", meta: true, shift: true, action: "dag-view" },
];

// Cmd+1 through Cmd+9 — switch layout groups
for (let i = 1; i <= 9; i++) {
  keybindings.push({ key: String(i), meta: true, action: `switch-group-${i}` });
}

interface Keybinding {
  key: string;
  meta?: boolean;
  shift?: boolean;
  alt?: boolean;
  ctrl?: boolean;
  action: string;
}

// Export for command palette
export const ALL_COMMANDS: { action: string; label: string; shortcut: string }[] = [
  { action: "new-session", label: "New Session", shortcut: "Cmd+T" },
  { action: "spawn-child", label: "Spawn Child Session", shortcut: "Cmd+N" },
  { action: "close-session", label: "Close Session", shortcut: "Cmd+W" },
  { action: "prev-session", label: "Previous Session", shortcut: "Cmd+[" },
  { action: "next-session", label: "Next Session", shortcut: "Cmd+]" },
  { action: "split-vertical", label: "Split Vertical", shortcut: "Cmd+D" },
  { action: "split-horizontal", label: "Split Horizontal", shortcut: "Cmd+Shift+D" },
  { action: "toggle-sidebar", label: "Toggle Sidebar", shortcut: "Cmd+B" },
  { action: "toggle-git-panel", label: "Toggle Git Panel", shortcut: "Cmd+G" },
  { action: "toggle-connectors", label: "Toggle Connectors", shortcut: "Cmd+K" },
  { action: "toggle-debug", label: "Toggle Debug Console", shortcut: "Cmd+Shift+I" },
  { action: "command-palette", label: "Command Palette", shortcut: "Cmd+Shift+P" },
  { action: "quick-switcher", label: "Quick Session Switcher", shortcut: "Cmd+P" },
  { action: "ship-workspace", label: "Ship Workspace to PR", shortcut: "Cmd+Shift+S" },
  { action: "settings", label: "Settings", shortcut: "Cmd+," },
  { action: "dag-view", label: "Session DAG View", shortcut: "Cmd+Shift+G" },
];

export { actions };

function matchesBinding(e: KeyboardEvent, binding: Keybinding): boolean {
  if (e.key.toLowerCase() !== binding.key.toLowerCase()) return false;
  if (!!binding.meta !== e.metaKey) return false;
  if (!!binding.shift !== e.shiftKey) return false;
  if (!!binding.alt !== e.altKey) return false;
  if (!!binding.ctrl !== e.ctrlKey) return false;
  return true;
}

export function setupKeybindings() {
  document.addEventListener("keydown", (e) => {
    if (!e.metaKey && !e.ctrlKey && !e.altKey) return;

    for (const binding of keybindings) {
      if (matchesBinding(e, binding)) {
        e.preventDefault();
        e.stopPropagation();
        const action = actions[binding.action];
        if (action) action();
        return;
      }
    }
  });
}
