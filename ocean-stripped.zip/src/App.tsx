import { onMount, Show, ErrorBoundary } from "solid-js";
import type { Session } from "./stores/sessionStore";
import Sidebar from "./components/sidebar/Sidebar";
import TerminalArea from "./components/terminal/TerminalArea";
import ScrollbackViewer from "./components/terminal/ScrollbackViewer";
import FileViewer from "./components/terminal/FileViewer";
import StatusBar from "./components/statusbar/StatusBar";
import DetailPanel from "./components/statusbar/DetailPanel";
import SystemDetailPanel from "./components/statusbar/SystemDetailPanel";
import NetworkDetailPanel from "./components/statusbar/NetworkDetailPanel";
import GitDetailPanel from "./components/statusbar/GitDetailPanel";
import MergePanel from "./components/merge/MergePanel";
import ConflictBanner from "./components/merge/ConflictBanner";
import ShipDialog from "./components/ship/ShipDialog";
import ConnectorBar from "./components/connectors/ConnectorBar";
import {
  loadWorkspaces,
  createWorkspace,
  createSession,
  loadSessions,
  loadSessionTree,
  setActiveWorkspace,
  setActiveSession,
  sessionState,
  initSessionStatusListener,
} from "./stores/sessionStore";
import { restoreLayout, createGroup } from "./stores/layoutStore";
import { initMetricsListeners } from "./stores/metricsStore";
import { initConflictListener } from "./stores/workspaceStore";
import { initConnectorListeners } from "./stores/connectorStore";
import { setupKeybindings } from "./lib/keybindings";
import { activePanel, closePanel } from "./stores/panelStore";
import {
  sidebarVisible,
  scrollbackViewer,
  hideScrollbackViewer,
  debugConsoleVisible,
  toggleDebugConsole,
  connectorBarVisible,
  mergePanelState,
  hideMergePanel,
  shipDialogState,
  fileViewer,
  hideFileViewer,
  commandPaletteVisible,
  quickSwitcherVisible,
  settingsVisible,
  dagViewVisible,
  hideShipDialog,
} from "./stores/uiStore";
import DebugConsole from "./components/DebugConsole";
import CommandPalette from "./components/CommandPalette";
import QuickSwitcher from "./components/QuickSwitcher";
import SettingsPanel from "./components/SettingsPanel";
import SessionDAG from "./components/SessionDAG";
import { logInfo } from "./stores/logStore";

export default function App() {
  onMount(async () => {
    logInfo("frontend", "App.onMount — initializing Ocean");
    setupKeybindings();
    initMetricsListeners();
    initSessionStatusListener();
    initConflictListener();
    initConnectorListeners();

    // Per-session git tracking
    const { initGitListeners } = await import("./stores/gitStore");
    initGitListeners();

    let workspaces = await loadWorkspaces();

    if (workspaces.length === 0) {
      const ws = await createWorkspace("Default");
      workspaces = [ws];
    }

    const activeWorkspace = workspaces[0];
    setActiveWorkspace(activeWorkspace.id);

    // Sessions were already respawned in Rust setup() — just load the data.
    // Load sessions for ALL workspaces so sidebar shows correct names everywhere.
    for (const ws of workspaces) {
      await loadSessions(ws.id);
      await loadSessionTree(ws.id);
    }

    // Collect ALL live sessions across all workspaces
    const allLiveSessions: { session: Session; workspaceId: string }[] = [];
    for (const ws of workspaces) {
      const sessions = sessionState.sessions[ws.id] ?? [];
      for (const s of sessions) {
        if (s.status === "active" || s.status === "idle" || s.status === "waiting") {
          allLiveSessions.push({ session: s, workspaceId: ws.id });
        }
      }
    }

    logInfo("frontend", `Found ${allLiveSessions.length} live sessions across ${workspaces.length} workspaces`);

    if (allLiveSessions.length > 0) {
      // Build session→workspace lookup for layout restore migration
      const liveIds = new Set(allLiveSessions.map((s) => s.session.id));
      const sessionToWorkspace = new Map(
        allLiveSessions.map((s) => [s.session.id, s.workspaceId])
      );
      const restored = restoreLayout(liveIds, sessionToWorkspace);
      if (!restored) {
        // Layout gone — create a group per live session
        for (const { session, workspaceId } of allLiveSessions) {
          createGroup(session.id, workspaceId);
        }
      } else {
        // Layout restored — check for orphaned sessions not in any group
        const { layoutState: ls, collectLeafIds: collectIds } = await import("./stores/layoutStore");
        const groupedIds = new Set<string>();
        for (const g of ls.groups) {
          for (const id of collectIds(g.root)) {
            groupedIds.add(id);
          }
        }
        for (const { session, workspaceId } of allLiveSessions) {
          if (!groupedIds.has(session.id)) {
            logInfo("frontend", `Orphaned session ${session.id.slice(0, 8)} (${session.name}) — creating group`);
            createGroup(session.id, workspaceId);
          }
        }
      }
      // Activate the first live session's workspace
      setActiveWorkspace(allLiveSessions[0].workspaceId);
      setActiveSession(allLiveSessions[0].session.id);
    } else {
      // No sessions survived — create a fresh one
      const activeSession = await createSession(activeWorkspace.id, undefined, "Shell");
      setActiveSession(activeSession.id);
      createGroup(activeSession.id, activeWorkspace.id);
    }
  });

  return (
    <ErrorBoundary
      fallback={(err, reset) => (
        <div style={{
          display: "flex",
          "flex-direction": "column",
          "align-items": "center",
          "justify-content": "center",
          height: "100%",
          background: "var(--bg-primary)",
          color: "var(--text-primary)",
          gap: "16px",
          padding: "32px",
        }}>
          <span style={{ "font-size": "18px", "font-weight": 600 }}>Something went wrong</span>
          <pre style={{
            "max-width": "600px",
            "max-height": "200px",
            overflow: "auto",
            background: "var(--bg-secondary)",
            padding: "12px",
            "border-radius": "6px",
            "font-size": "12px",
            color: "var(--red, #f7768e)",
          }}>
            {err?.toString()}
          </pre>
          <button
            onClick={reset}
            style={{
              padding: "8px 24px",
              background: "var(--accent, #7aa2f7)",
              color: "var(--bg-primary, #1a1b26)",
              border: "none",
              "border-radius": "6px",
              cursor: "pointer",
              "font-size": "14px",
            }}
          >
            Try Again
          </button>
        </div>
      )}
    >
    <div
      style={{
        display: "flex",
        "flex-direction": "column",
        width: "100%",
        height: "100%",
        overflow: "hidden",
      }}
    >
      <StatusBar />
      <ConflictBanner />
      <div style={{ position: "relative", "flex-shrink": 0 }}>
        <Show when={activePanel() === "system"}>
          <DetailPanel onClose={closePanel} align="left">
            <SystemDetailPanel />
          </DetailPanel>
        </Show>
        <Show when={activePanel() === "network"}>
          <DetailPanel onClose={closePanel} align="left">
            <NetworkDetailPanel />
          </DetailPanel>
        </Show>
        <Show when={activePanel() === "git"}>
          <DetailPanel onClose={closePanel} align="right">
            <GitDetailPanel />
          </DetailPanel>
        </Show>
      </div>
      <div
        style={{
          display: "flex",
          flex: 1,
          overflow: "hidden",
        }}
      >
        <Show when={sidebarVisible()}>
          <Sidebar />
        </Show>

        {/* Scrollback viewer overlays the terminal area when viewing a closed session */}
        <Show
          when={scrollbackViewer()}
          fallback={<TerminalArea />}
        >
          {(viewer) => (
            <ScrollbackViewer
              sessionId={viewer().sessionId}
              sessionName={viewer().sessionName}
              exitCode={viewer().exitCode}
              onClose={hideScrollbackViewer}
            />
          )}
        </Show>
      </div>

      {/* Connector bar — toggle with Cmd+K */}
      <Show when={connectorBarVisible()}>
        <ConnectorBar />
      </Show>

      {/* Debug console — toggle with Cmd+Shift+I */}
      <Show when={debugConsoleVisible()}>
        <div style={{ height: "250px", "flex-shrink": 0, "border-top": "1px solid var(--border)" }}>
          <DebugConsole onClose={toggleDebugConsole} />
        </div>
      </Show>

      {/* Merge panel overlay */}
      <Show when={mergePanelState()}>
        {(panelState) => (
          <MergePanel
            workspaceId={panelState().workspaceId}
            sessionId={panelState().sessionId}
            sessionName={panelState().sessionName}
            onClose={hideMergePanel}
          />
        )}
      </Show>

      {/* Ship dialog overlay */}
      <Show when={shipDialogState()}>
        {(dialogState) => (
          <ShipDialog
            workspaceId={dialogState().workspaceId}
            workspaceName={dialogState().workspaceName}
            onClose={hideShipDialog}
          />
        )}
      </Show>

      {/* File viewer overlay */}
      <Show when={fileViewer()}>
        {(fv) => (
          <FileViewer
            filePath={fv().filePath}
            line={fv().line}
            onClose={hideFileViewer}
          />
        )}
      </Show>

      {/* Command palette */}
      <Show when={commandPaletteVisible()}>
        <CommandPalette />
      </Show>

      {/* Quick session switcher */}
      <Show when={quickSwitcherVisible()}>
        <QuickSwitcher />
      </Show>

      {/* Settings panel */}
      <Show when={settingsVisible()}>
        <SettingsPanel />
      </Show>

      {/* Session DAG view */}
      <Show when={dagViewVisible()}>
        <SessionDAG />
      </Show>
    </div>
    </ErrorBoundary>
  );
}
