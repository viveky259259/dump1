import { createSignal, createMemo, For, Show } from "solid-js";
import { invoke } from "@tauri-apps/api/core";
import type { Workspace, SessionTreeNode } from "../../stores/sessionStore";
import {
  sessionState,
  createSession,
  closeSession,
  loadSessionTree,
  loadSessions,
  setActiveWorkspace,
  setActiveSession,
} from "../../stores/sessionStore";
import { showShipDialog, hideScrollbackViewer, showScrollbackViewer } from "../../stores/uiStore";
import {
  layoutState,
  activateGroup,
  createGroup,
  closePane,
  collectLeafIds,
  getGroupsForWorkspace,
  type LayoutGroup,
} from "../../stores/layoutStore";
import { captureScrollback } from "../../stores/scrollbackStore";
import { disposeTerminal } from "../terminal/TerminalPane";
import SessionNode from "./SessionNode";

interface WorkspaceGroupProps {
  workspace: Workspace;
  tree: SessionTreeNode[];
  isActive: boolean;
}

const LIVE_STATUSES = new Set(["active", "idle", "waiting"]);
const CLOSED_STATUSES = new Set(["completed", "failed", "archived"]);

const STATUS_COLORS: Record<string, string> = {
  active: "var(--green)",
  idle: "var(--blue)",
  waiting: "var(--yellow)",
};

function isLive(status: string) {
  return LIVE_STATUSES.has(status);
}

/** Find the layout group that contains a given session ID */
function findGroupForSession(sessionId: string, groups: LayoutGroup[]): LayoutGroup | undefined {
  return groups.find((g) => {
    const ids = collectLeafIds(g.root);
    return ids.includes(sessionId);
  });
}

export default function WorkspaceGroup(props: WorkspaceGroupProps) {
  const [collapsed, setCollapsed] = createSignal(false);
  const [closedExpanded, setClosedExpanded] = createSignal(false);
  const [creating, setCreating] = createSignal(false);

  // Layout groups scoped to this workspace
  const groups = createMemo(() => getGroupsForWorkspace(props.workspace.id));

  // Partition tree into live roots and closed
  const liveRoots = createMemo(() =>
    props.tree.filter((n) => isLive(n.session.status))
  );
  const closedNodes = createMemo(() => {
    const closed: SessionTreeNode[] = [];
    function collect(nodes: SessionTreeNode[]) {
      for (const n of nodes) {
        if (CLOSED_STATUSES.has(n.session.status)) {
          closed.push(n);
        }
        // Also collect closed children of live parents
        if (isLive(n.session.status)) {
          collect(n.children);
        }
      }
    }
    collect(props.tree);
    return closed;
  });
  const closedCount = createMemo(() => closedNodes().length);

  const handleClick = () => {
    setActiveWorkspace(props.workspace.id);
    setCollapsed(!collapsed());
  };

  const handleNewSession = async (e: MouseEvent) => {
    e.stopPropagation();
    setCreating(true);
    try {
      const session = await createSession(props.workspace.id);
      setActiveSession(session.id);
      createGroup(session.id, props.workspace.id);
    } finally {
      setCreating(false);
    }
  };

  const handleSessionClick = (sessionId: string, status: string, name: string, exitCode: number | null) => {
    if (isLive(status)) {
      hideScrollbackViewer();
      // Find and activate the group containing this session
      const group = findGroupForSession(sessionId, groups());
      if (group) {
        activateGroup(group.id);
      }
      setActiveSession(sessionId);
    } else {
      showScrollbackViewer(sessionId, name, exitCode);
    }
  };

  const handleCloseSession = async (e: MouseEvent, sessionId: string) => {
    e.stopPropagation();
    captureScrollback(sessionId);
    closePane(sessionId);
    disposeTerminal(sessionId);
    await closeSession(sessionId);
  };

  const handleRename = async (sessionId: string, newName: string) => {
    try {
      await invoke("rename_session", { sessionId, name: newName });
    } catch (e) {
      console.error("rename failed:", e);
    }
    await loadSessions(props.workspace.id);
    await loadSessionTree(props.workspace.id);
  };

  // Recursive tree row renderer for live sessions
  function LiveTreeNode(nodeProps: { node: SessionTreeNode; depth: number; index: number }) {
    const s = () => nodeProps.node.session;
    const group = () => findGroupForSession(s().id, groups());
    const isActiveGroup = () => {
      const g = group();
      return g ? layoutState.activeGroupId === g.id : false;
    };
    const [renaming, setRenaming] = createSignal(false);
    const [renameValue, setRenameValue] = createSignal("");
    const hasChildren = () =>
      nodeProps.node.children.filter((c) => isLive(c.session.status)).length > 0;

    return (
      <div>
        <div
          class="session-row"
          onClick={() => handleSessionClick(s().id, s().status, s().name, s().exit_code)}
          style={{
            padding: `4px 8px 4px ${16 + nodeProps.depth * 16}px`,
            display: "flex",
            "align-items": "center",
            gap: "8px",
            cursor: "pointer",
            background: isActiveGroup() ? "var(--bg-active)" : "transparent",
            "border-left": isActiveGroup()
              ? "3px solid var(--accent)"
              : "3px solid transparent",
            "border-radius": "0 4px 4px 0",
            margin: "1px 4px 1px 0",
            "user-select": "none",
            transition: "background 0.15s, border-left 0.15s",
          }}
          onMouseEnter={(e) => {
            if (!isActiveGroup())
              (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
          }}
          onMouseLeave={(e) => {
            if (!isActiveGroup())
              (e.currentTarget as HTMLElement).style.background = "transparent";
          }}
        >
          {/* Tree connector for children */}
          <Show when={nodeProps.depth > 0}>
            <span style={{
              color: "var(--border)",
              "font-size": "10px",
              "margin-right": "-4px",
              "flex-shrink": 0,
            }}>
              {"\u2514"}
            </span>
          </Show>

          {/* Status dot */}
          <span style={{
            width: "8px",
            height: "8px",
            "border-radius": "50%",
            background: STATUS_COLORS[s().status] ?? "var(--green)",
            "flex-shrink": 0,
          }} />

          {/* Session name — double-click to rename */}
          <Show
            when={!renaming()}
            fallback={
              <input
                value={renameValue()}
                onInput={(e) => setRenameValue(e.currentTarget.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    const val = renameValue().trim();
                    if (val) handleRename(s().id, val);
                    setRenaming(false);
                  }
                  if (e.key === "Escape") setRenaming(false);
                }}
                onBlur={() => {
                  const val = renameValue().trim();
                  if (val) handleRename(s().id, val);
                  setRenaming(false);
                }}
                ref={(el) => setTimeout(() => el.focus(), 0)}
                onClick={(e) => e.stopPropagation()}
                style={{
                  flex: 1,
                  "font-size": "13px",
                  "font-family": "var(--font-ui)",
                  background: "var(--bg-primary)",
                  color: "var(--accent)",
                  border: "1px solid var(--accent)",
                  "border-radius": "3px",
                  padding: "0 4px",
                  outline: "none",
                  "min-width": 0,
                }}
              />
            }
          >
            <span
              onDblClick={(e) => {
                e.stopPropagation();
                setRenameValue(s().name);
                setRenaming(true);
              }}
              style={{
                flex: 1,
                "font-size": "13px",
                color: isActiveGroup() ? "var(--accent)" : "var(--text-secondary)",
                "font-weight": isActiveGroup() ? 600 : "normal",
                "white-space": "nowrap",
                overflow: "hidden",
                "text-overflow": "ellipsis",
              }}
            >
              {s().name}
            </span>
          </Show>

          {/* Child count badge */}
          <Show when={hasChildren()}>
            <span style={{
              "font-size": "9px",
              color: "var(--accent)",
              background: "rgba(122,162,247,0.1)",
              padding: "1px 5px",
              "border-radius": "8px",
              "flex-shrink": 0,
            }}>
              {nodeProps.node.children.filter((c) => isLive(c.session.status)).length}
            </span>
          </Show>

          {/* Keyboard shortcut for root-level sessions */}
          <Show when={nodeProps.depth === 0 && nodeProps.index < 9}>
            <span style={{
              "font-size": "10px",
              "font-family": "var(--font-mono)",
              color: "var(--text-muted)",
              opacity: 0.5,
              "flex-shrink": 0,
            }}>
              {"\u2318"}{nodeProps.index + 1}
            </span>
          </Show>

          {/* Close button */}
          <button
            class="session-close-btn"
            onClick={(e: MouseEvent) => handleCloseSession(e, s().id)}
            style={{
              background: "none",
              border: "none",
              color: "var(--text-muted)",
              cursor: "pointer",
              "font-size": "14px",
              "line-height": "1",
              padding: "0 2px",
              "border-radius": "3px",
              opacity: "0",
              "flex-shrink": 0,
              transition: "opacity 0.15s, color 0.15s, background 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--red)";
              (e.currentTarget as HTMLElement).style.background = "rgba(247,118,142,0.15)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
              (e.currentTarget as HTMLElement).style.background = "none";
            }}
            title="Close session"
          >
            {"\u2715"}
          </button>
        </div>

        {/* Render live children indented */}
        <For each={nodeProps.node.children.filter((c) => isLive(c.session.status))}>
          {(child, ci) => <LiveTreeNode node={child} depth={nodeProps.depth + 1} index={ci()} />}
        </For>
      </div>
    );
  }

  return (
    <div>
      {/* Workspace header */}
      <div
        onClick={handleClick}
        style={{
          padding: "6px 12px",
          display: "flex",
          "align-items": "center",
          gap: "6px",
          cursor: "pointer",
          background: props.isActive ? "var(--bg-hover)" : "transparent",
          "user-select": "none",
        }}
        onMouseEnter={(e) => {
          if (!props.isActive)
            (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
        }}
        onMouseLeave={(e) => {
          if (!props.isActive)
            (e.currentTarget as HTMLElement).style.background = "transparent";
        }}
      >
        <span style={{ "font-size": "10px", color: "var(--text-muted)", width: "12px" }}>
          {collapsed() ? "\u25B6" : "\u25BC"}
        </span>
        <span style={{
          flex: 1, "font-size": "13px", "font-weight": 500,
          color: "var(--text-primary)", "white-space": "nowrap",
          overflow: "hidden", "text-overflow": "ellipsis",
        }}>
          {props.workspace.name}
        </span>
        <Show when={props.workspace.repo_path}>
          <span style={{ "font-size": "10px", color: "var(--accent)", opacity: 0.7 }}
            title={`Repo: ${props.workspace.repo_path}`}>
            {"\uD83D\uDCC1"}
          </span>
        </Show>
        <span style={{ "font-size": "11px", color: "var(--text-muted)" }}>
          {liveRoots().length}
        </span>
        <Show when={props.workspace.repo_path}>
          <button
            onClick={(e: MouseEvent) => {
              e.stopPropagation();
              showShipDialog(props.workspace.id, props.workspace.name);
            }}
            style={{
              background: "none", border: "none", color: "var(--text-muted)",
              cursor: "pointer", "font-size": "12px", padding: "0 2px",
              "line-height": 1, "border-radius": "3px",
              transition: "color 0.15s, background 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--green)";
              (e.currentTarget as HTMLElement).style.background = "rgba(158,206,106,0.15)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
              (e.currentTarget as HTMLElement).style.background = "none";
            }}
            title="Ship workspace to PR"
          >
            {"\uD83D\uDE80"}
          </button>
        </Show>
        <button
          onClick={handleNewSession}
          disabled={creating()}
          style={{
            background: "none", border: "none",
            color: creating() ? "var(--accent)" : "var(--text-muted)",
            cursor: creating() ? "wait" : "pointer",
            "font-size": "14px", padding: "0 2px", "line-height": 1,
          }}
          title="New Session (Cmd+T)"
        >
          {creating() ? "\u23F3" : "+"}
        </button>
      </div>

      {/* Session tree + closed sessions */}
      <Show when={!collapsed()}>
        <div style={{ "padding-left": "8px" }}>
          {/* Creating indicator */}
          <Show when={creating()}>
            <div style={{
              padding: "4px 8px 4px 16px",
              display: "flex", "align-items": "center", gap: "8px",
              "user-select": "none",
            }}>
              <span style={{
                width: "8px", height: "8px", "border-radius": "50%",
                border: "2px solid var(--border)", "border-top-color": "var(--accent)",
                animation: "spin 0.8s linear infinite", "flex-shrink": 0,
              }} />
              <span style={{ "font-size": "12px", color: "var(--text-muted)", "font-style": "italic" }}>
                Creating session...
              </span>
            </div>
          </Show>

          {/* Live sessions — tree structure with indentation */}
          <For each={liveRoots()}>
            {(node, i) => <LiveTreeNode node={node} depth={0} index={i()} />}
          </For>

          <Show when={liveRoots().length === 0 && !creating()}>
            <div style={{
              padding: "8px 16px", color: "var(--text-muted)", "font-size": "12px",
            }}>
              No active sessions
            </div>
          </Show>

          {/* Closed sessions section */}
          <Show when={closedCount() > 0}>
            <div
              onClick={() => setClosedExpanded(!closedExpanded())}
              style={{
                padding: "4px 8px 4px 16px",
                display: "flex", "align-items": "center", gap: "6px",
                cursor: "pointer", "user-select": "none",
                "margin-top": "4px", "border-top": "1px solid var(--border)",
                "padding-top": "6px",
              }}
            >
              <span style={{ "font-size": "9px", color: "var(--text-muted)", width: "10px" }}>
                {closedExpanded() ? "\u25BC" : "\u25B6"}
              </span>
              <span style={{
                "font-size": "11px", color: "var(--text-muted)",
                "text-transform": "uppercase", "letter-spacing": "0.5px",
              }}>
                Closed
              </span>
              <span style={{
                "font-size": "10px", color: "var(--text-muted)",
                background: "var(--bg-hover)", "border-radius": "8px",
                padding: "0 6px",
              }}>
                {closedCount()}
              </span>
            </div>

            <Show when={closedExpanded()}>
              <For each={closedNodes()}>
                {(node) => <SessionNode node={node} depth={0} />}
              </For>
            </Show>
          </Show>
        </div>
      </Show>
    </div>
  );
}
