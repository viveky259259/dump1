import { createSignal, For, Show } from "solid-js";
import { invoke } from "@tauri-apps/api/core";
import type { SessionTreeNode } from "../../stores/sessionStore";
import {
  sessionState,
  setActiveSession,
  closeSession,
} from "../../stores/sessionStore";
import { layoutState, setFocusedSession, closePane, switchToSession } from "../../stores/layoutStore";
import { disposeTerminal } from "../terminal/TerminalPane";
import { captureScrollback } from "../../stores/scrollbackStore";
import { showScrollbackViewer, hideScrollbackViewer, showMergePanel, scrollbackViewer } from "../../stores/uiStore";

interface SessionNodeProps {
  node: SessionTreeNode;
  depth: number;
}

const STATUS_COLORS: Record<string, string> = {
  active: "var(--green)",
  idle: "var(--blue)",
  waiting: "var(--yellow)",
  failed: "var(--red)",
  completed: "var(--grey)",
  archived: "var(--text-muted)",
};

const STATUS_ICONS: Record<string, string> = {
  active: "\u25CF",    // ●
  idle: "\u25CB",      // ○
  waiting: "\u25CC",   // ◌
  failed: "\u2717",    // ✗
  completed: "\u2713", // ✓
  archived: "\u25A1",  // □
};

const isLive = (status: string) =>
  status === "active" || status === "idle" || status === "waiting";

export default function SessionNode(props: SessionNodeProps) {
  const session = () => props.node.session;
  const isActive = () => sessionState.activeSessionId === session().id;
  const isFocused = () => layoutState.focusedSessionId === session().id;
  const isViewing = () => scrollbackViewer()?.sessionId === session().id;
  // When scrollback viewer is open, suppress focus/active highlights on live sessions
  const scrollbackOpen = () => scrollbackViewer() !== null;
  const showFocused = () => isFocused() && !scrollbackOpen();
  const showActive = () => isActive() && !scrollbackOpen();
  const [renaming, setRenaming] = createSignal(false);
  const [renameValue, setRenameValue] = createSignal("");

  const handleDoubleClick = (e: MouseEvent) => {
    e.stopPropagation();
    if (!isLive(session().status)) return;
    setRenameValue(session().name);
    setRenaming(true);
  };

  const commitRename = async () => {
    const newName = renameValue().trim();
    if (newName && newName !== session().name) {
      await invoke("rename_session", { sessionId: session().id, name: newName });
      // Reload tree to reflect new name
      const { loadSessionTree } = await import("../../stores/sessionStore");
      const wsId = sessionState.activeWorkspaceId;
      if (wsId) await loadSessionTree(wsId);
    }
    setRenaming(false);
  };

  const handleClick = () => {
    if (isLive(session().status)) {
      hideScrollbackViewer(); // close scrollback viewer if open
      setActiveSession(session().id);
      switchToSession(session().id);
    } else {
      // Closed session — show scrollback viewer
      // Don't clear focusedSessionId — that would break the layout tree
      // isViewing() handles the sidebar highlight for the closed session
      showScrollbackViewer(
        session().id,
        session().name,
        session().exit_code
      );
    }
  };

  const handleClose = async (e: MouseEvent) => {
    e.stopPropagation();
    // Capture scrollback BEFORE disposing
    captureScrollback(session().id);
    // Remove pane from layout
    closePane(session().id);
    // Dispose terminal instance
    disposeTerminal(session().id);
    // Close the session (kills PTY, updates DB)
    await closeSession(session().id);
  };

  return (
    <div>
      <div
        class="session-row"
        onClick={handleClick}
        style={{
          padding: "4px 8px 4px " + (16 + props.depth * 16) + "px",
          display: "flex",
          "align-items": "center",
          gap: "8px",
          cursor: isLive(session().status) ? "pointer" : "default",
          background: (showFocused() || isViewing())
            ? "var(--bg-active)"
            : showActive()
              ? "var(--bg-hover)"
              : "transparent",
          "border-left": (showFocused() || isViewing())
            ? "3px solid var(--accent)"
            : "3px solid transparent",
          "border-radius": "0 4px 4px 0",
          margin: "1px 4px 1px 0",
          "user-select": "none",
          transition: "background 0.15s ease, border-left 0.15s ease",
          opacity: isLive(session().status) ? 1 : isViewing() ? 0.85 : 0.5,
        }}
        onMouseEnter={(e) => {
          if (!showFocused() && !isViewing())
            (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
        }}
        onMouseLeave={(e) => {
          if (!showFocused() && !showActive() && !isViewing())
            (e.currentTarget as HTMLElement).style.background = "transparent";
          else if (showActive() && !showFocused())
            (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
        }}
      >
        {/* Status indicator */}
        <span
          style={{
            color: STATUS_COLORS[session().status] ?? "var(--text-muted)",
            "font-size": "10px",
            width: "12px",
            "text-align": "center",
            "flex-shrink": 0,
            transition: "color 0.3s ease",
          }}
        >
          {STATUS_ICONS[session().status] ?? "\u25CF"}
        </span>

        {/* Session name — double-click to rename */}
        <Show
          when={!renaming()}
          fallback={
            <input
              value={renameValue()}
              onInput={(e) => setRenameValue(e.currentTarget.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitRename();
                if (e.key === "Escape") setRenaming(false);
              }}
              onBlur={commitRename}
              ref={(el) => setTimeout(() => el.focus(), 0)}
              style={{
                flex: 1,
                "font-size": "13px",
                "font-family": "var(--font-ui)",
                background: "var(--bg-primary)",
                color: "var(--accent)",
                border: "1px solid var(--accent)",
                "border-radius": "3px",
                padding: "0 4px",
                outline: "none",
                "min-width": 0,
              }}
            />
          }
        >
          <span
            onDblClick={handleDoubleClick}
            style={{
              flex: 1,
              "font-size": "13px",
              color: (showFocused() || isViewing())
                ? "var(--accent)"
                : showActive()
                  ? "var(--text-primary)"
                  : "var(--text-secondary)",
              "font-weight": (showFocused() || isViewing()) ? "600" : "normal",
              "white-space": "nowrap",
              overflow: "hidden",
              "text-overflow": "ellipsis",
            }}
          >
            {session().name}
          </span>
        </Show>

        {/* Type badge for agents */}
        <Show when={session().session_type !== "shell"}>
          <span
            style={{
              "font-size": "10px",
              color: "var(--accent)",
              opacity: 0.7,
            }}
          >
            {session().session_type}
          </span>
        </Show>

        {/* Merge button — for completed sessions in repo workspaces */}
        <Show when={session().status === "completed" && sessionState.activeWorkspaceId}>
          {(_wsId) => {
            const workspace = () =>
              sessionState.workspaces.find((w) => w.id === sessionState.activeWorkspaceId);
            return (
              <Show when={workspace()?.repo_path}>
                <button
                  class="session-close-btn"
                  onClick={(e: MouseEvent) => {
                    e.stopPropagation();
                    const wsId = sessionState.activeWorkspaceId;
                    if (wsId) {
                      showMergePanel(wsId, session().id, session().name);
                    }
                  }}
                  style={{
                    background: "none",
                    border: "none",
                    color: "var(--text-muted)",
                    cursor: "pointer",
                    "font-size": "11px",
                    "line-height": "1",
                    padding: "1px 4px",
                    "border-radius": "3px",
                    opacity: "0",
                    transition: "opacity 0.15s, color 0.15s, background 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.color = "var(--green)";
                    (e.currentTarget as HTMLElement).style.background = "rgba(158,206,106,0.15)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
                    (e.currentTarget as HTMLElement).style.background = "none";
                  }}
                  title="Merge session changes"
                >
                  Merge
                </button>
              </Show>
            );
          }}
        </Show>

        {/* Close button — only for live sessions */}
        <Show when={isLive(session().status)}>
          <button
            class="session-close-btn"
            onClick={handleClose}
            style={{
              background: "none",
              border: "none",
              color: "var(--text-muted)",
              cursor: "pointer",
              "font-size": "14px",
              "line-height": "1",
              padding: "0 2px",
              "border-radius": "3px",
              opacity: "0",
              transition: "opacity 0.15s, color 0.15s, background 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--red)";
              (e.currentTarget as HTMLElement).style.background = "rgba(247,118,142,0.15)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
              (e.currentTarget as HTMLElement).style.background = "none";
            }}
            title="Close session"
          >
            {"\u2715"}
          </button>
        </Show>
      </div>

      {/* Children */}
      <For each={props.node.children}>
        {(child) => <SessionNode node={child} depth={props.depth + 1} />}
      </For>
    </div>
  );
}
