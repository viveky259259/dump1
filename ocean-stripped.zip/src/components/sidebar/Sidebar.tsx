import { createSignal, For, Show } from "solid-js";
import {
  sessionState,
  createWorkspace,
  createWorkspaceWithRepo,
  createSession,
  setActiveWorkspace,
  setActiveSession,
  loadSessionTree,
  clearAllAndRestart,
} from "../../stores/sessionStore";
import { createGroup } from "../../stores/layoutStore";
import { hideScrollbackViewer, toggleSettings } from "../../stores/uiStore";
import { logInfo, logError } from "../../stores/logStore";
import WorkspaceGroup from "./WorkspaceGroup";
import InputDialog from "../InputDialog";

type DialogMode = null | "workspace" | "repo" | "loading";

export default function Sidebar() {
  const [dialogMode, setDialogMode] = createSignal<DialogMode>(null);
  const [loadingMessage, setLoadingMessage] = createSignal("");
  const [creatingSession, setCreatingSession] = createSignal(false);

  // Create a new SESSION in the active workspace as a new layout group
  const handleNewSession = async () => {
    const workspaceId = sessionState.activeWorkspaceId;
    if (!workspaceId) return;
    setCreatingSession(true);
    logInfo("session", "Creating new session in active workspace");
    try {
      const session = await createSession(workspaceId);
      setActiveSession(session.id);
      createGroup(session.id, workspaceId);
    } finally {
      setCreatingSession(false);
    }
  };

  const handleCreateWorkspace = async (values: string[]) => {
    const name = values[0];
    setDialogMode(null);
    logInfo("session", `Creating workspace: "${name}"`);
    const ws = await createWorkspace(name);
    setActiveWorkspace(ws.id);
    const session = await createSession(ws.id, undefined, undefined);
    setActiveSession(session.id);
    await loadSessionTree(ws.id);
    createGroup(session.id, ws.id);
  };

  const handleCreateRepoWorkspace = async (values: string[]) => {
    const [name, repoPath] = values;
    setDialogMode("loading");
    setLoadingMessage("Cloning repository...");
    try {
      logInfo("frontend", `Creating repo workspace: "${name}" at "${repoPath}"`);
      const ws = await createWorkspaceWithRepo(name, repoPath);
      setLoadingMessage("Creating session...");
      setActiveWorkspace(ws.id);
      const session = await createSession(ws.id, undefined, undefined);
      setActiveSession(session.id);
      await loadSessionTree(ws.id);
      createGroup(session.id, ws.id);
      setDialogMode(null);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logError("frontend", `Failed to create repo workspace: ${msg}`);
      setLoadingMessage(`Error: ${msg}`);
      // Show error for 3s then close
      setTimeout(() => setDialogMode(null), 3000);
    }
  };

  return (
    <>
      <div
        style={{
          width: "var(--sidebar-width)",
          "min-width": "180px",
          height: "100%",
          background: "var(--bg-sidebar)",
          "border-right": "1px solid var(--border)",
          display: "flex",
          "flex-direction": "column",
          overflow: "hidden",
          "flex-shrink": 0,
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "12px 16px 8px",
            display: "flex",
            "align-items": "center",
            "justify-content": "space-between",
            "border-bottom": "1px solid var(--border)",
          }}
        >
          <span
            style={{
              "font-weight": 600,
              "font-size": "12px",
              "text-transform": "uppercase",
              "letter-spacing": "0.5px",
              color: "var(--text-secondary)",
            }}
          >
            Sessions
          </span>
          <div style={{ display: "flex", gap: "4px" }}>
            <button
              onClick={async () => {
                hideScrollbackViewer();
                await clearAllAndRestart();
              }}
              style={{
                background: "none",
                border: "none",
                color: "var(--text-muted)",
                cursor: "pointer",
                "font-size": "11px",
                padding: "2px 6px",
                "line-height": 1,
                "border-radius": "3px",
                transition: "color 0.15s, background 0.15s",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.color = "var(--red)";
                (e.currentTarget as HTMLElement).style.background = "rgba(247,118,142,0.15)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
                (e.currentTarget as HTMLElement).style.background = "none";
              }}
              title="Clear all sessions and start fresh"
            >
              Clear
            </button>
            <button
              onClick={() => setDialogMode("repo")}
              style={{
                background: "none",
                border: "1px solid var(--border)",
                color: "var(--text-muted)",
                cursor: "pointer",
                "font-size": "10px",
                padding: "2px 6px",
                "line-height": 1,
                "border-radius": "3px",
                transition: "color 0.15s, background 0.15s, border-color 0.15s",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.color = "var(--accent)";
                (e.currentTarget as HTMLElement).style.background = "rgba(122,162,247,0.15)";
                (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
                (e.currentTarget as HTMLElement).style.background = "none";
                (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
              }}
              title="New Workspace from Repo"
            >
              Repo
            </button>
            <button
              onClick={() => setDialogMode("workspace")}
              style={{
                background: "none",
                border: "1px solid var(--border)",
                color: "var(--text-muted)",
                cursor: "pointer",
                "font-size": "10px",
                padding: "2px 6px",
                "line-height": 1,
                "border-radius": "3px",
                transition: "color 0.15s, background 0.15s",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.color = "var(--text-primary)";
                (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
                (e.currentTarget as HTMLElement).style.background = "none";
              }}
              title="New Workspace"
            >
              WS
            </button>
            <button
              onClick={handleNewSession}
              disabled={creatingSession()}
              style={{
                background: "none",
                border: "none",
                color: creatingSession() ? "var(--accent)" : "var(--text-secondary)",
                cursor: creatingSession() ? "wait" : "pointer",
                "font-size": "18px",
                padding: "0 4px",
                "line-height": 1,
              }}
              title="New Session (Cmd+T)"
            >
              {creatingSession() ? "\u23F3" : "+"}
            </button>
          </div>
        </div>

        {/* Workspace list */}
        <div
          style={{
            flex: 1,
            "overflow-y": "auto",
            padding: "4px 0",
          }}
        >
          <For each={sessionState.workspaces}>
            {(workspace) => (
              <WorkspaceGroup
                workspace={workspace}
                tree={sessionState.sessionTree[workspace.id] ?? []}
                isActive={sessionState.activeWorkspaceId === workspace.id}
              />
            )}
          </For>

          <Show when={sessionState.workspaces.length === 0}>
            <div
              style={{
                padding: "16px",
                color: "var(--text-muted)",
                "text-align": "center",
                "font-size": "12px",
              }}
            >
              No workspaces
            </div>
          </Show>
        </div>

        {/* Settings button at bottom */}
        <div
          style={{
            padding: "8px 12px",
            "border-top": "1px solid var(--border)",
            "flex-shrink": 0,
          }}
        >
          <button
            onClick={() => toggleSettings()}
            style={{
              background: "none",
              border: "none",
              color: "var(--text-muted)",
              cursor: "pointer",
              "font-size": "12px",
              "font-family": "var(--font-ui)",
              padding: "4px 8px",
              "border-radius": "4px",
              display: "flex",
              "align-items": "center",
              gap: "6px",
              width: "100%",
              transition: "color 0.15s, background 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--text-primary)";
              (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
              (e.currentTarget as HTMLElement).style.background = "none";
            }}
            title="Settings (Cmd+,)"
          >
            <span style={{ "font-size": "14px" }}>{"\u2699"}</span>
            <span>Settings</span>
          </button>
        </div>
      </div>

      {/* Input dialogs */}
      <Show when={dialogMode() === "workspace"}>
        <InputDialog
          title="New Workspace"
          fields={[{ label: "Workspace Name", placeholder: "My Project" }]}
          onSubmit={handleCreateWorkspace}
          onCancel={() => setDialogMode(null)}
        />
      </Show>

      <Show when={dialogMode() === "repo"}>
        <InputDialog
          title="New Workspace from Repository"
          fields={[
            { label: "Workspace Name", placeholder: "My Project" },
            { label: "Repository Path (absolute)", placeholder: "/Users/you/projects/my-app" },
          ]}
          onSubmit={handleCreateRepoWorkspace}
          onCancel={() => setDialogMode(null)}
        />
      </Show>

      {/* Loading overlay */}
      <Show when={dialogMode() === "loading"}>
        <div
          style={{
            position: "fixed",
            top: 0, left: 0, right: 0, bottom: 0,
            background: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            "align-items": "center",
            "justify-content": "center",
            "z-index": "1000",
          }}
        >
          <div
            style={{
              background: "var(--bg-secondary)",
              border: "1px solid var(--border)",
              "border-radius": "8px",
              padding: "24px 32px",
              "text-align": "center",
              "box-shadow": "0 8px 32px rgba(0, 0, 0, 0.4)",
            }}
          >
            <div style={{
              width: "24px",
              height: "24px",
              "border-radius": "50%",
              border: "3px solid var(--border)",
              "border-top-color": "var(--accent)",
              animation: "spin 0.8s linear infinite",
              margin: "0 auto 12px",
            }} />
            <div style={{
              "font-size": "13px",
              color: loadingMessage().startsWith("Error")
                ? "var(--red)"
                : "var(--text-primary)",
              "font-family": "var(--font-ui)",
            }}>
              {loadingMessage()}
            </div>
          </div>
        </div>
      </Show>
    </>
  );
}
