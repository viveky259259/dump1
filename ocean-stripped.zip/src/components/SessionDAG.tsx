import { createSignal, createMemo, onMount, For, Show } from "solid-js";
import { invoke } from "@tauri-apps/api/core";
import { sessionState } from "../stores/sessionStore";
import type { SessionTreeNode } from "../stores/sessionStore";
import type { DeltaInfo } from "../stores/workspaceStore";
import { showFileViewer, hideDAGView } from "../stores/uiStore";

interface NodeDelta {
  sessionId: string;
  modified: string[];
  created: string[];
  deleted: string[];
  total: number;
}

const STATUS_COLORS: Record<string, string> = {
  active: "#9ece6a",
  idle: "#7aa2f7",
  waiting: "#e0af68",
  completed: "#565f89",
  failed: "#f7768e",
};

export default function SessionDAG() {
  const [deltas, setDeltas] = createSignal<Map<string, NodeDelta>>(new Map());
  const [hoveredNode, setHoveredNode] = createSignal<string | null>(null);
  const [loading, setLoading] = createSignal(true);
  // null = show all workspaces (default)
  const [filterWsId, setFilterWsId] = createSignal<string | null>(null);

  // Tree: merge all workspaces, or filter to one
  const tree = createMemo(() => {
    const filter = filterWsId();
    if (filter) {
      return sessionState.sessionTree[filter] ?? [];
    }
    // All workspaces — concatenate trees, add workspace label nodes
    const all: SessionTreeNode[] = [];
    for (const ws of sessionState.workspaces) {
      const wsTree = sessionState.sessionTree[ws.id] ?? [];
      all.push(...wsTree);
    }
    return all;
  });

  const loadDeltas = async (filter?: string | null) => {
    setLoading(true);
    const deltaMap = new Map<string, NodeDelta>();
    const wsFilter = filter !== undefined ? filter : filterWsId();
    const targetWorkspaces = wsFilter
      ? sessionState.workspaces.filter((w) => w.id === wsFilter)
      : sessionState.workspaces;

    for (const ws of targetWorkspaces) {
      if (!ws.repo_path) continue;
      const sessions = sessionState.sessions[ws.id] ?? [];
      for (const s of sessions) {
        if (s.status === "completed" || s.status === "failed") continue;
        try {
          const delta = await invoke<DeltaInfo>("get_session_delta", {
            workspaceId: ws.id,
            sessionId: s.id,
          });
          deltaMap.set(s.id, {
            sessionId: s.id,
            modified: delta.modified_files,
            created: delta.created_files,
            deleted: delta.deleted_files,
            total: delta.modified_files.length + delta.created_files.length + delta.deleted_files.length,
          });
        } catch {
          deltaMap.set(s.id, {
            sessionId: s.id, modified: [], created: [], deleted: [], total: 0,
          });
        }
      }
    }
    setDeltas(deltaMap);
    setLoading(false);
  };

  const switchFilter = (id: string | null) => {
    setFilterWsId(id);
    loadDeltas(id);
  };

  onMount(() => loadDeltas(null));

  const getDelta = (sessionId: string) =>
    deltas().get(sessionId) ?? { sessionId, modified: [], created: [], deleted: [], total: 0 };

  const handleFileClick = (filePath: string) => {
    showFileViewer(filePath);
  };

  // Flatten tree to compute layout positions
  interface LayoutNode {
    node: SessionTreeNode;
    x: number;
    y: number;
    parentX?: number;
    parentY?: number;
    depth: number;
  }

  const layoutNodes = createMemo(() => {
    const result: LayoutNode[] = [];
    const NODE_W = 200;
    const NODE_H = 120;
    const H_GAP = 60;
    const V_GAP = 40;

    let yCounter = 0;

    function layout(nodes: SessionTreeNode[], depth: number, parentX?: number, parentY?: number) {
      for (const node of nodes) {
        const x = depth * (NODE_W + H_GAP);
        const y = yCounter * (NODE_H + V_GAP);
        result.push({ node, x, y, parentX, parentY, depth });
        yCounter++;
        if (node.children.length > 0) {
          layout(node.children, depth + 1, x + NODE_W / 2, y + NODE_H / 2);
        }
      }
    }

    layout(tree(), 0);
    return result;
  });

  const svgWidth = createMemo(() => {
    const nodes = layoutNodes();
    if (nodes.length === 0) return 400;
    return Math.max(...nodes.map((n) => n.x)) + 260;
  });

  const svgHeight = createMemo(() => {
    const nodes = layoutNodes();
    if (nodes.length === 0) return 200;
    return Math.max(...nodes.map((n) => n.y)) + 180;
  });

  return (
    <div
      style={{
        position: "fixed",
        top: 0, left: 0, right: 0, bottom: 0,
        background: "rgba(0,0,0,0.6)",
        "z-index": "1000",
        display: "flex",
        "align-items": "center",
        "justify-content": "center",
      }}
      onClick={(e) => { if (e.target === e.currentTarget) hideDAGView(); }}
    >
      <div style={{
        width: "85vw",
        "max-width": "1200px",
        height: "80vh",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "8px",
        "box-shadow": "0 8px 32px rgba(0,0,0,0.5)",
        display: "flex",
        "flex-direction": "column",
        overflow: "hidden",
      }}>
        {/* Header */}
        <div style={{
          display: "flex",
          "align-items": "center",
          padding: "10px 16px",
          "border-bottom": "1px solid var(--border)",
          gap: "10px",
          "flex-shrink": 0,
        }}>
          <span style={{
            "font-size": "14px",
            "font-weight": 600,
            color: "var(--text-primary)",
            "flex-shrink": 0,
          }}>
            Session DAG
          </span>

          {/* Workspace filter tabs */}
          <div style={{ display: "flex", gap: "4px", flex: 1, "overflow-x": "auto" }}>
            <button
              onClick={() => switchFilter(null)}
              style={{
                background: filterWsId() === null ? "var(--bg-active)" : "transparent",
                border: filterWsId() === null ? "1px solid var(--accent)" : "1px solid var(--border)",
                color: filterWsId() === null ? "var(--accent)" : "var(--text-muted)",
                cursor: "pointer",
                "font-size": "11px",
                "font-family": "var(--font-ui)",
                padding: "3px 10px",
                "border-radius": "4px",
                "white-space": "nowrap",
                transition: "all 0.15s",
              }}
            >
              All
            </button>
            <For each={sessionState.workspaces}>
              {(ws) => {
                const isSelected = () => filterWsId() === ws.id;
                const sessionCount = () =>
                  (sessionState.sessions[ws.id] ?? []).filter(
                    (s) => s.status === "active" || s.status === "idle" || s.status === "waiting"
                  ).length;
                return (
                  <button
                    onClick={() => switchFilter(ws.id)}
                    style={{
                      background: isSelected() ? "var(--bg-active)" : "transparent",
                      border: isSelected() ? "1px solid var(--accent)" : "1px solid var(--border)",
                      color: isSelected() ? "var(--accent)" : "var(--text-muted)",
                      cursor: "pointer",
                      "font-size": "11px",
                      "font-family": "var(--font-ui)",
                      padding: "3px 10px",
                      "border-radius": "4px",
                      "white-space": "nowrap",
                      transition: "all 0.15s",
                    }}
                  >
                    {ws.name}
                    <Show when={sessionCount() > 0}>
                      <span style={{ "margin-left": "4px", opacity: 0.6 }}>({sessionCount()})</span>
                    </Show>
                  </button>
                );
              }}
            </For>
          </div>
          <button
            onClick={hideDAGView}
            style={{
              background: "none", border: "none", color: "var(--text-muted)",
              cursor: "pointer", "font-size": "16px", padding: "0 4px", "flex-shrink": 0,
            }}
          >
            {"\u2715"}
          </button>
        </div>

        {/* Graph area */}
        <div style={{ flex: 1, overflow: "auto", padding: "20px", position: "relative" }}>
          <Show when={loading()}>
            <div style={{
              display: "flex", "align-items": "center", "justify-content": "center",
              height: "100%", color: "var(--text-muted)", "font-size": "13px",
            }}>
              Loading session data...
            </div>
          </Show>

          <Show when={!loading() && layoutNodes().length === 0}>
            <div style={{
              display: "flex", "align-items": "center", "justify-content": "center",
              height: "100%", color: "var(--text-muted)", "font-size": "13px",
            }}>
              No sessions to display
            </div>
          </Show>

          <Show when={!loading() && layoutNodes().length > 0}>
            <svg
              width={svgWidth()}
              height={svgHeight()}
              style={{ "min-width": "100%", "min-height": "100%" }}
            >
              {/* Connection lines */}
              <For each={layoutNodes()}>
                {(ln) => (
                  <Show when={ln.parentX !== undefined && ln.parentY !== undefined}>
                    <line
                      x1={ln.parentX!}
                      y1={ln.parentY!}
                      x2={ln.x + 100}
                      y2={ln.y + 50}
                      stroke="var(--border)"
                      stroke-width="2"
                      stroke-dasharray="6,4"
                    />
                    {/* Arrow */}
                    <circle
                      cx={ln.x + 100}
                      cy={ln.y + 50}
                      r="4"
                      fill="var(--border)"
                    />
                  </Show>
                )}
              </For>

              {/* Session nodes */}
              <For each={layoutNodes()}>
                {(ln) => {
                  const s = ln.node.session;
                  const d = getDelta(s.id);
                  const isHovered = () => hoveredNode() === s.id;
                  const statusColor = STATUS_COLORS[s.status] ?? "#565f89";

                  return (
                    <g
                      transform={`translate(${ln.x}, ${ln.y})`}
                      onMouseEnter={() => setHoveredNode(s.id)}
                      onMouseLeave={() => setHoveredNode(null)}
                      style={{ cursor: "default" }}
                    >
                      {/* Node background */}
                      <rect
                        width="200"
                        height="100"
                        rx="8"
                        fill={isHovered() ? "var(--bg-hover)" : "var(--bg-primary)"}
                        stroke={isHovered() ? "var(--accent)" : "var(--border)"}
                        stroke-width={isHovered() ? "2" : "1"}
                      />

                      {/* Status bar */}
                      <rect
                        width="200"
                        height="4"
                        rx="2"
                        fill={statusColor}
                        y="0"
                      />

                      {/* Session name */}
                      <text
                        x="10"
                        y="24"
                        fill="var(--text-primary)"
                        font-size="13"
                        font-weight="600"
                        font-family="var(--font-ui)"
                      >
                        {s.name.length > 22 ? s.name.slice(0, 20) + "..." : s.name}
                      </text>

                      {/* Status */}
                      <text
                        x="10"
                        y="40"
                        fill="var(--text-muted)"
                        font-size="10"
                        font-family="var(--font-ui)"
                      >
                        {s.status} {s.session_type !== "shell" ? `(${s.session_type})` : ""}
                      </text>

                      {/* File change counts */}
                      <Show when={d.total > 0}>
                        <text x="10" y="58" font-size="11" font-family="var(--font-mono)">
                          <tspan fill="#9ece6a">+{d.created.length}</tspan>
                          <tspan fill="var(--text-muted)"> </tspan>
                          <tspan fill="#e0af68">~{d.modified.length}</tspan>
                          <tspan fill="var(--text-muted)"> </tspan>
                          <tspan fill="#f7768e">-{d.deleted.length}</tspan>
                        </text>
                        <text
                          x="10"
                          y="72"
                          fill="var(--text-muted)"
                          font-size="10"
                          font-family="var(--font-ui)"
                        >
                          {d.total} file{d.total !== 1 ? "s" : ""} changed
                        </text>
                      </Show>

                      <Show when={d.total === 0}>
                        <text
                          x="10"
                          y="58"
                          fill="var(--text-muted)"
                          font-size="10"
                          font-family="var(--font-ui)"
                          font-style="italic"
                        >
                          No changes
                        </text>
                      </Show>

                      {/* Children count badge */}
                      <Show when={ln.node.children.length > 0}>
                        <rect
                          x="160"
                          y="10"
                          width="30"
                          height="18"
                          rx="9"
                          fill="rgba(122,162,247,0.15)"
                          stroke="rgba(122,162,247,0.3)"
                          stroke-width="1"
                        />
                        <text
                          x="175"
                          y="23"
                          fill="var(--accent)"
                          font-size="10"
                          font-family="var(--font-mono)"
                          text-anchor="middle"
                        >
                          {ln.node.children.length}
                        </text>
                      </Show>
                    </g>
                  );
                }}
              </For>
            </svg>

            {/* Hover tooltip — file list */}
            <Show when={hoveredNode()}>
              {(sid) => {
                const d = getDelta(sid());
                const allFiles = [...d.created.map(f => ({f, t: "created" as const})), ...d.modified.map(f => ({f, t: "modified" as const})), ...d.deleted.map(f => ({f, t: "deleted" as const}))];
                if (allFiles.length === 0) return null;

                return (
                  <div style={{
                    position: "fixed",
                    right: "20px",
                    top: "120px",
                    width: "280px",
                    "max-height": "400px",
                    background: "var(--bg-secondary)",
                    border: "1px solid var(--accent)",
                    "border-radius": "8px",
                    "box-shadow": "0 4px 16px rgba(0,0,0,0.5)",
                    "overflow-y": "auto",
                    "z-index": "1001",
                  }}>
                    <div style={{
                      padding: "8px 12px",
                      "border-bottom": "1px solid var(--border)",
                      "font-size": "12px",
                      "font-weight": 600,
                      color: "var(--text-primary)",
                    }}>
                      {allFiles.length} file{allFiles.length !== 1 ? "s" : ""}
                    </div>
                    <For each={allFiles.slice(0, 30)}>
                      {(item) => {
                        const color = item.t === "created" ? "var(--green)" : item.t === "modified" ? "var(--yellow)" : "var(--red)";
                        const icon = item.t === "created" ? "+" : item.t === "modified" ? "~" : "-";
                        const fileName = item.f.split("/").pop() ?? item.f;
                        return (
                          <div
                            onClick={() => handleFileClick(item.f)}
                            style={{
                              display: "flex",
                              "align-items": "center",
                              gap: "6px",
                              padding: "4px 12px",
                              cursor: "pointer",
                              transition: "background 0.1s",
                            }}
                            onMouseEnter={(e) => {
                              (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
                            }}
                            onMouseLeave={(e) => {
                              (e.currentTarget as HTMLElement).style.background = "transparent";
                            }}
                          >
                            <span style={{
                              "font-family": "var(--font-mono)",
                              "font-size": "11px",
                              color,
                              "flex-shrink": 0,
                              width: "12px",
                            }}>
                              {icon}
                            </span>
                            <span style={{
                              "font-family": "var(--font-mono)",
                              "font-size": "11px",
                              color: "var(--text-primary)",
                              "white-space": "nowrap",
                              overflow: "hidden",
                              "text-overflow": "ellipsis",
                              flex: 1,
                            }}
                            title={item.f}
                            >
                              {fileName}
                            </span>
                            <span style={{
                              "font-size": "9px",
                              color: "var(--text-muted)",
                              "flex-shrink": 0,
                            }}>
                              {item.f.split("/").slice(0, -1).join("/").slice(0, 20)}
                            </span>
                          </div>
                        );
                      }}
                    </For>
                    <Show when={allFiles.length > 30}>
                      <div style={{ padding: "4px 12px", "font-size": "10px", color: "var(--text-muted)" }}>
                        +{allFiles.length - 30} more
                      </div>
                    </Show>
                  </div>
                );
              }}
            </Show>
          </Show>
        </div>
      </div>
    </div>
  );
}
