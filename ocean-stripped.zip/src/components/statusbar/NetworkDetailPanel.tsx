import { Show } from "solid-js";
import { networkStatus } from "../../stores/metricsStore";

function latencyColor(ms: number | null): string {
  if (ms === null) return "var(--grey)";
  if (ms < 100) return "var(--green)";
  if (ms < 300) return "var(--yellow)";
  return "var(--red)";
}

function latencyLabel(ms: number | null): string {
  if (ms === null) return "\u2014"; // em dash
  return ms + "ms";
}

export default function NetworkDetailPanel() {
  const net = networkStatus;

  const labelStyle = {
    "font-family": "var(--font-ui)",
    "font-size": "12px",
    color: "var(--text-secondary)",
    "min-width": "90px",
    "flex-shrink": "0",
  };

  const valueStyle = {
    "font-family": "var(--font-mono)",
    "font-size": "13px",
    color: "var(--text-primary)",
    display: "flex",
    "align-items": "center",
    gap: "8px",
  };

  const rowStyle = {
    display: "flex",
    "align-items": "center",
    gap: "10px",
    padding: "6px 0",
  };

  const dotStyle = (color: string) => ({
    width: "7px",
    height: "7px",
    "border-radius": "50%",
    background: color,
    "flex-shrink": "0",
    display: "inline-block",
  });

  return (
    <div style={{ width: "400px", padding: "12px 16px" }}>
      {/* Header */}
      <div
        style={{
          "font-family": "var(--font-ui)",
          "font-size": "13px",
          "font-weight": "600",
          color: "var(--text-primary)",
          "padding-bottom": "8px",
          "margin-bottom": "8px",
          "border-bottom": "1px solid var(--border)",
        }}
      >
        Network Status
      </div>

      {/* Connection Status */}
      <div style={rowStyle}>
        <span style={labelStyle}>Status</span>
        <span style={valueStyle}>
          <span
            style={dotStyle(
              net().connected ? "var(--green)" : "var(--red)"
            )}
          />
          <Show
            when={net().connected}
            fallback={
              <span style={{ color: "var(--red)" }}>Disconnected</span>
            }
          >
            <span style={{ color: "var(--green)" }}>
              Connected ({net().interface_type})
            </span>
          </Show>
        </span>
      </div>

      <Show
        when={net().connected}
        fallback={
          <div
            style={{
              padding: "12px 0",
              color: "var(--text-muted)",
              "font-size": "12px",
              "text-align": "center",
            }}
          >
            No active connection
          </div>
        }
      >
        {/* GitHub Latency */}
        <div style={rowStyle}>
          <span style={labelStyle}>github.com</span>
          <span style={valueStyle}>
            <span style={dotStyle(latencyColor(net().latency_github_ms))} />
            <span
              style={{
                color: latencyColor(net().latency_github_ms),
                "font-family": "var(--font-mono)",
                "font-size": "13px",
              }}
            >
              {latencyLabel(net().latency_github_ms)}
            </span>
          </span>
        </div>

        {/* npm Latency */}
        <div style={rowStyle}>
          <span style={labelStyle}>npmjs.org</span>
          <span style={valueStyle}>
            <span style={dotStyle(latencyColor(net().latency_npm_ms))} />
            <span
              style={{
                color: latencyColor(net().latency_npm_ms),
                "font-family": "var(--font-mono)",
                "font-size": "13px",
              }}
            >
              {latencyLabel(net().latency_npm_ms)}
            </span>
          </span>
        </div>
      </Show>
    </div>
  );
}
