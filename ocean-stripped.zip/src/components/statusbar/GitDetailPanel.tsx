import { Show } from "solid-js";
import { gitStatus } from "../../stores/metricsStore";

const CI_LABELS: Record<string, string> = {
  success: "Passing",
  pending: "Pending",
  failure: "Failing",
  unknown: "Unknown",
};

const CI_COLORS: Record<string, string> = {
  success: "var(--green)",
  pending: "var(--yellow)",
  failure: "var(--red)",
  unknown: "var(--grey)",
};

export default function GitDetailPanel() {
  const git = gitStatus;

  const labelStyle = {
    "font-family": "var(--font-ui)",
    "font-size": "12px",
    color: "var(--text-secondary)",
    "min-width": "80px",
    "flex-shrink": "0",
  };

  const valueStyle = {
    "font-family": "var(--font-mono)",
    "font-size": "13px",
    color: "var(--text-primary)",
    display: "flex",
    "align-items": "center",
    gap: "8px",
  };

  const rowStyle = {
    display: "flex",
    "align-items": "center",
    gap: "10px",
    padding: "5px 0",
  };

  const dotStyle = (color: string) => ({
    width: "7px",
    height: "7px",
    "border-radius": "50%",
    background: color,
    "flex-shrink": "0",
    display: "inline-block",
  });

  return (
    <Show
      when={git()}
      fallback={
        <div
          style={{
            width: "500px",
            padding: "12px 16px",
            color: "var(--text-muted)",
            "font-size": "12px",
            "text-align": "center",
          }}
        >
          No git repository detected
        </div>
      }
    >
      {(g) => (
        <div style={{ width: "500px", padding: "12px 16px" }}>
          {/* Header */}
          <div
            style={{
              "font-family": "var(--font-ui)",
              "font-size": "13px",
              "font-weight": "600",
              color: "var(--text-primary)",
              "padding-bottom": "8px",
              "margin-bottom": "8px",
              "border-bottom": "1px solid var(--border)",
            }}
          >
            Git Status
          </div>

          {/* Branch */}
          <div style={rowStyle}>
            <span style={labelStyle}>Branch</span>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "13px",
                color: "var(--accent)",
                "word-break": "break-all",
              }}
            >
              {g().branch}
            </span>
          </div>

          {/* Upstream */}
          <div style={rowStyle}>
            <span style={labelStyle}>Upstream</span>
            <span style={valueStyle}>
              <Show
                when={g().ahead > 0 || g().behind > 0}
                fallback={
                  <span style={{ color: "var(--text-muted)" }}>In sync</span>
                }
              >
                <Show when={g().ahead > 0}>
                  <span style={{ color: "var(--green)" }}>
                    {"\u2191"}{g().ahead} ahead
                  </span>
                </Show>
                <Show when={g().behind > 0}>
                  <span style={{ color: "var(--red)" }}>
                    {"\u2193"}{g().behind} behind
                  </span>
                </Show>
              </Show>
            </span>
          </div>

          {/* CI */}
          <div style={rowStyle}>
            <span style={labelStyle}>CI</span>
            <span style={valueStyle}>
              <Show
                when={g().ci_status}
                fallback={
                  <span style={{ color: "var(--text-muted)" }}>{"\u2014"}</span>
                }
              >
                {(status) => (
                  <>
                    <span style={dotStyle(CI_COLORS[status()] ?? "var(--grey)")} />
                    <span
                      style={{
                        color: CI_COLORS[status()] ?? "var(--grey)",
                        "font-family": "var(--font-mono)",
                        "font-size": "13px",
                      }}
                    >
                      {CI_LABELS[status()] ?? status()}
                    </span>
                  </>
                )}
              </Show>
            </span>
          </div>

          {/* PR */}
          <div style={rowStyle}>
            <span style={labelStyle}>PR</span>
            <span style={valueStyle}>
              <Show
                when={g().pr_number !== null && g().pr_number !== undefined}
                fallback={
                  <span style={{ color: "var(--text-muted)" }}>{"\u2014"}</span>
                }
              >
                <span
                  style={{
                    color: "var(--accent)",
                    "font-family": "var(--font-mono)",
                    "font-size": "13px",
                  }}
                  title={g().pr_url ?? undefined}
                >
                  #{g().pr_number}
                </span>
                <Show when={g().pr_url}>
                  <span
                    style={{
                      color: "var(--text-muted)",
                      "font-size": "11px",
                      "word-break": "break-all",
                    }}
                  >
                    {g().pr_url}
                  </span>
                </Show>
              </Show>
            </span>
          </div>

          {/* Separator */}
          <div
            style={{
              "border-top": "1px solid var(--border)",
              "margin-top": "6px",
              "padding-top": "6px",
            }}
          />

          {/* Staged */}
          <div style={rowStyle}>
            <span style={labelStyle}>Staged</span>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "13px",
                color: g().staged > 0 ? "var(--green)" : "var(--text-muted)",
              }}
            >
              {g().staged} {g().staged === 1 ? "file" : "files"}
            </span>
          </div>

          {/* Modified */}
          <div style={rowStyle}>
            <span style={labelStyle}>Modified</span>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "13px",
                color: g().modified > 0 ? "var(--yellow)" : "var(--text-muted)",
              }}
            >
              {g().modified} {g().modified === 1 ? "file" : "files"}
            </span>
          </div>

          {/* Untracked */}
          <div style={rowStyle}>
            <span style={labelStyle}>Untracked</span>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "13px",
                color: g().untracked > 0 ? "var(--text-secondary)" : "var(--text-muted)",
              }}
            >
              {g().untracked} {g().untracked === 1 ? "file" : "files"}
            </span>
          </div>

          {/* Conflicts */}
          <div style={rowStyle}>
            <span style={labelStyle}>Conflicts</span>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "13px",
                color: g().conflicted > 0 ? "var(--red)" : "var(--text-muted)",
              }}
            >
              {g().conflicted}
            </span>
          </div>
        </div>
      )}
    </Show>
  );
}
