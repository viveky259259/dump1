import { For, Show, createMemo, createSignal } from "solid-js";
import {
  sessionState,
  setActiveSession,
} from "../../stores/sessionStore";
import { setFocusedSession } from "../../stores/layoutStore";
import type { SessionTreeNode } from "../../stores/sessionStore";

const STATUS_COLORS: Record<string, string> = {
  active: "var(--green)",
  idle: "var(--blue)",
  waiting: "var(--yellow)",
  failed: "var(--red)",
  completed: "var(--grey)",
  archived: "var(--text-muted)",
};

const STATUS_PRIORITY: Record<string, number> = {
  waiting: 0,
  failed: 0,
  active: 1,
  idle: 2,
  completed: 3,
  archived: 4,
};

const MAX_VISIBLE = 5;

/** Flatten the session tree to a list of all sessions. */
function flattenTree(nodes: SessionTreeNode[]): SessionTreeNode[] {
  const result: SessionTreeNode[] = [];
  for (const node of nodes) {
    result.push(node);
    if (node.children.length > 0) {
      result.push(...flattenTree(node.children));
    }
  }
  return result;
}

export default function AgentStatusRow() {
  const [expanded, setExpanded] = createSignal(false);

  const agentSessions = createMemo(() => {
    const wsId = sessionState.activeWorkspaceId;
    if (!wsId) return [];
    const tree = sessionState.sessionTree[wsId] ?? [];
    const all = flattenTree(tree);
    const sessions = all
      .filter((node) => node.session.session_type !== "shell")
      .map((node) => node.session);

    // Sort by priority: waiting/failed first, active second, idle third, completed last
    return sessions.slice().sort((a, b) => {
      const priorityA = STATUS_PRIORITY[a.status] ?? 3;
      const priorityB = STATUS_PRIORITY[b.status] ?? 3;
      return priorityA - priorityB;
    });
  });

  const visibleSessions = createMemo(() => {
    const all = agentSessions();
    if (expanded() || all.length <= MAX_VISIBLE) return all;
    return all.slice(0, MAX_VISIBLE);
  });

  const overflowCount = createMemo(() => {
    const total = agentSessions().length;
    if (total <= MAX_VISIBLE) return 0;
    return total - MAX_VISIBLE;
  });

  const handleClick = (sessionId: string) => {
    setActiveSession(sessionId);
    setFocusedSession(sessionId);
  };

  return (
    <>
      <For each={visibleSessions()}>
        {(session) => (
          <div
            onClick={() => handleClick(session.id)}
            style={{
              display: "inline-flex",
              "align-items": "center",
              gap: "4px",
              padding: "2px 8px",
              "border-radius": "10px",
              background: "var(--bg-hover)",
              cursor: "pointer",
              "user-select": "none",
              "flex-shrink": 0,
              "transition": "background 0.15s ease",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "var(--bg-active)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
            }}
          >
            {/* Status dot */}
            <span
              style={{
                width: "6px",
                height: "6px",
                "border-radius": "50%",
                background: STATUS_COLORS[session.status] ?? "var(--grey)",
                "flex-shrink": 0,
                ...(session.status === "active"
                  ? { animation: "pulse-dot 2s ease-in-out infinite" }
                  : {}),
              }}
            />
            {/* Agent name */}
            <span
              style={{
                "font-family": "var(--font-ui)",
                "font-size": "11px",
                color: "var(--text-primary)",
                "white-space": "nowrap",
                "max-width": "100px",
                overflow: "hidden",
                "text-overflow": "ellipsis",
              }}
            >
              {session.name}
            </span>
          </div>
        )}
      </For>
      <Show when={overflowCount() > 0}>
        <div
          onClick={() => setExpanded((prev) => !prev)}
          style={{
            display: "inline-flex",
            "align-items": "center",
            padding: "2px 8px",
            "border-radius": "10px",
            background: "var(--bg-hover)",
            cursor: "pointer",
            "user-select": "none",
            "flex-shrink": 0,
            "transition": "background 0.15s ease",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.background = "var(--bg-active)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
          }}
        >
          <span
            style={{
              "font-family": "var(--font-ui)",
              "font-size": "11px",
              color: "var(--text-muted)",
              "white-space": "nowrap",
            }}
          >
            {expanded() ? "Show less" : `+${overflowCount()} more`}
          </span>
        </div>
      </Show>
    </>
  );
}
