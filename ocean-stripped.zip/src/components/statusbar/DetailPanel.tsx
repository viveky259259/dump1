import { onMount, onCleanup, type JSX } from "solid-js";

interface DetailPanelProps {
  children: JSX.Element;
  onClose: () => void;
  align?: "left" | "center" | "right";
}

export default function DetailPanel(props: DetailPanelProps) {
  let panelRef: HTMLDivElement | undefined;

  const handleKeydown = (e: KeyboardEvent) => {
    if (e.key === "Escape") {
      props.onClose();
    }
  };

  const handleClickOutside = (e: MouseEvent) => {
    if (panelRef && !panelRef.contains(e.target as Node)) {
      props.onClose();
    }
  };

  onMount(() => {
    document.addEventListener("keydown", handleKeydown);
    // Delay adding click listener to avoid immediate close from the click that opened the panel
    const timer = setTimeout(() => {
      document.addEventListener("click", handleClickOutside);
    }, 0);

    onCleanup(() => {
      document.removeEventListener("keydown", handleKeydown);
      document.removeEventListener("click", handleClickOutside);
      clearTimeout(timer);
    });
  });

  const alignStyle = (): JSX.CSSProperties => {
    const align = props.align ?? "left";
    if (align === "left") return { left: "12px" };
    if (align === "right") return { right: "12px" };
    return { left: "50%", transform: "translateX(-50%)" };
  };

  return (
    <div
      ref={panelRef}
      style={{
        position: "absolute",
        top: "0",
        "z-index": 100,
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "0 0 8px 8px",
        "box-shadow": "0 4px 12px rgba(0,0,0,0.3)",
        "max-height": "60vh",
        "overflow-y": "auto",
        "font-family": "var(--font-ui)",
        "font-size": "13px",
        color: "var(--text-primary)",
        ...alignStyle(),
      }}
    >
      {props.children}
    </div>
  );
}
