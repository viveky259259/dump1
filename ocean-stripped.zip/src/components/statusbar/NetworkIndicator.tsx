import { Show } from "solid-js";
import { networkStatus } from "../../stores/metricsStore";
import { togglePanel } from "../../stores/panelStore";

function latencyColor(ms: number | null): string {
  if (ms === null) return "var(--grey)";
  if (ms < 100) return "var(--green)";
  if (ms < 300) return "var(--yellow)";
  return "var(--red)";
}

function latencyLabel(ms: number | null): string {
  if (ms === null) return "--";
  return ms + "ms";
}

export default function NetworkIndicator() {
  const net = networkStatus;

  // Pick the representative latency (prefer github, fallback npm)
  const latency = () => net().latency_github_ms ?? net().latency_npm_ms;

  return (
    <div
      onClick={() => togglePanel("network")}
      style={{
        display: "flex",
        "align-items": "center",
        gap: "6px",
        width: "80px",
        "flex-shrink": 0,
        "font-family": "var(--font-ui)",
        "font-size": "12px",
        "user-select": "none",
        cursor: "pointer",
        "border-radius": "4px",
        padding: "2px 6px",
        margin: "-2px -6px",
        transition: "background 0.15s ease",
      }}
      onMouseEnter={(e) => { e.currentTarget.style.background = "var(--bg-hover)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
    >
      {/* Connection dot */}
      <span
        style={{
          width: "7px",
          height: "7px",
          "border-radius": "50%",
          background: net().connected ? "var(--green)" : "var(--red)",
          "flex-shrink": 0,
          "box-shadow": net().connected
            ? "0 0 4px var(--green)"
            : "0 0 4px var(--red)",
        }}
      />

      <Show
        when={net().connected}
        fallback={
          <span style={{ color: "var(--red)", "font-size": "12px" }}>
            Offline
          </span>
        }
      >
        {/* Interface type */}
        <span
          style={{
            color: "var(--text-secondary)",
            "font-size": "11px",
            "white-space": "nowrap",
            overflow: "hidden",
            "text-overflow": "ellipsis",
            "max-width": "36px",
          }}
        >
          {net().interface_type}
        </span>

        {/* Latency dot */}
        <span
          style={{
            width: "5px",
            height: "5px",
            "border-radius": "50%",
            background: latencyColor(latency()),
            "flex-shrink": 0,
          }}
        />

        {/* Latency value */}
        <span
          style={{
            color: latencyColor(latency()),
            "font-family": "var(--font-mono)",
            "font-size": "11px",
            "white-space": "nowrap",
          }}
        >
          {latencyLabel(latency())}
        </span>
      </Show>
    </div>
  );
}
