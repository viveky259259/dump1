import { Show, createMemo } from "solid-js";
import { sessionState } from "../../stores/sessionStore";
import type { SessionTreeNode } from "../../stores/sessionStore";
import NetworkIndicator from "./NetworkIndicator";
import SystemMetrics from "./SystemMetrics";
import AgentStatusRow from "./AgentStatusRow";

/** Flatten the session tree to check if any agents exist. */
function flattenTree(nodes: SessionTreeNode[]): SessionTreeNode[] {
  const result: SessionTreeNode[] = [];
  for (const node of nodes) {
    result.push(node);
    if (node.children.length > 0) {
      result.push(...flattenTree(node.children));
    }
  }
  return result;
}

export default function StatusBar() {
  const hasAgents = createMemo(() => {
    const wsId = sessionState.activeWorkspaceId;
    if (!wsId) return false;
    const tree = sessionState.sessionTree[wsId] ?? [];
    const all = flattenTree(tree);
    return all.some((node) => node.session.session_type !== "shell");
  });

  return (
    <div
      style={{
        width: "100%",
        background: "var(--bg-secondary)",
        "border-bottom": "1px solid var(--border)",
        "flex-shrink": 0,
        overflow: "hidden",
      }}
    >
      {/* Row 1: Network | System Metrics | Git Status */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          "justify-content": "space-between",
          height: "28px",
          padding: "0 12px",
          gap: "12px",
        }}
      >
        <NetworkIndicator />
        <SystemMetrics />
      </div>

      {/* Row 2: Agent pills (only if agents exist) */}
      <Show when={hasAgents()}>
        <div
          style={{
            display: "flex",
            "align-items": "center",
            height: "28px",
            padding: "0 12px",
            gap: "6px",
            "border-top": "1px solid var(--border)",
            overflow: "auto",
          }}
        >
          <span
            style={{
              "font-family": "var(--font-ui)",
              "font-size": "11px",
              color: "var(--text-muted)",
              "flex-shrink": 0,
              "margin-right": "4px",
            }}
          >
            Agents
          </span>
          <AgentStatusRow />
        </div>
      </Show>
    </div>
  );
}
