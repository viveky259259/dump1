import { Show } from "solid-js";
import { systemMetrics } from "../../stores/metricsStore";

const BAR_LENGTH = 20;
const FILLED = "\u2593"; // filled block
const EMPTY = "\u2591";  // light shade block

function buildBar(ratio: number): string {
  const clamped = Math.max(0, Math.min(1, ratio));
  const filled = Math.round(clamped * BAR_LENGTH);
  const empty = BAR_LENGTH - filled;
  return FILLED.repeat(filled) + EMPTY.repeat(empty);
}

function thresholdColor(percent: number): string {
  if (percent < 60) return "var(--green)";
  if (percent < 85) return "var(--yellow)";
  return "var(--red)";
}

function bytesToGB(bytes: number): string {
  return (bytes / (1024 * 1024 * 1024)).toFixed(1);
}

function batteryColor(percent: number): string {
  if (percent > 50) return "var(--green)";
  if (percent >= 20) return "var(--yellow)";
  return "var(--red)";
}

export default function SystemDetailPanel() {
  const metrics = systemMetrics;

  const ramPercent = () => {
    const total = metrics().ram_total_bytes;
    if (total === 0) return 0;
    return (metrics().ram_used_bytes / total) * 100;
  };

  const cpuPercent = () => metrics().cpu_percent;

  const swapPercent = () => {
    const total = metrics().swap_total_bytes;
    if (total === 0) return 0;
    return (metrics().swap_used_bytes / total) * 100;
  };

  const labelStyle = {
    "font-family": "var(--font-ui)",
    "font-size": "12px",
    color: "var(--text-secondary)",
    "min-width": "56px",
    "flex-shrink": "0",
  };

  const barStyle = (color: string) => ({
    "font-family": "var(--font-mono)",
    "font-size": "13px",
    color,
    "letter-spacing": "-0.5px",
    "white-space": "nowrap",
  });

  const valueStyle = (color: string) => ({
    "font-family": "var(--font-mono)",
    "font-size": "13px",
    color,
    "white-space": "nowrap",
    "min-width": "80px",
    "text-align": "right" as const,
  });

  const rowStyle = {
    display: "flex",
    "align-items": "center",
    gap: "10px",
    padding: "6px 0",
  };

  return (
    <div style={{ width: "400px", padding: "12px 16px" }}>
      {/* Header */}
      <div
        style={{
          "font-family": "var(--font-ui)",
          "font-size": "13px",
          "font-weight": "600",
          color: "var(--text-primary)",
          "padding-bottom": "8px",
          "margin-bottom": "8px",
          "border-bottom": "1px solid var(--border)",
        }}
      >
        System Resources
      </div>

      {/* CPU */}
      <div style={rowStyle}>
        <span style={labelStyle}>CPU</span>
        <span style={barStyle(thresholdColor(cpuPercent()))}>
          {buildBar(cpuPercent() / 100)}
        </span>
        <span style={valueStyle(thresholdColor(cpuPercent()))}>
          {Math.round(cpuPercent())}%
        </span>
      </div>

      {/* RAM */}
      <div style={rowStyle}>
        <span style={labelStyle}>RAM</span>
        <span style={barStyle(thresholdColor(ramPercent()))}>
          {buildBar(ramPercent() / 100)}
        </span>
        <span style={valueStyle(thresholdColor(ramPercent()))}>
          {bytesToGB(metrics().ram_used_bytes)}/{bytesToGB(metrics().ram_total_bytes)}GB
        </span>
      </div>

      {/* Swap */}
      <div style={rowStyle}>
        <span style={labelStyle}>Swap</span>
        <span style={barStyle(thresholdColor(swapPercent()))}>
          {buildBar(swapPercent() / 100)}
        </span>
        <span style={valueStyle(thresholdColor(swapPercent()))}>
          {bytesToGB(metrics().swap_used_bytes)}/{bytesToGB(metrics().swap_total_bytes)}GB
        </span>
      </div>

      {/* Battery */}
      <Show when={metrics().battery_percent !== null}>
        <div style={rowStyle}>
          <span style={labelStyle}>Battery</span>
          <span
            style={{
              "font-family": "var(--font-mono)",
              "font-size": "13px",
              color: batteryColor(metrics().battery_percent!),
              "white-space": "nowrap",
            }}
          >
            {Math.round(metrics().battery_percent!)}%
          </span>
          <Show when={metrics().battery_charging}>
            <span
              style={{
                "font-size": "13px",
                color: "var(--yellow)",
              }}
            >
              {"\u26A1"} Charging
            </span>
          </Show>
          <Show when={!metrics().battery_charging}>
            <span
              style={{
                "font-size": "12px",
                color: "var(--text-muted)",
              }}
            >
              On Battery
            </span>
          </Show>
        </div>
      </Show>
    </div>
  );
}
