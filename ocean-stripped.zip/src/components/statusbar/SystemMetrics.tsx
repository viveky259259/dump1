import { Show } from "solid-js";
import { systemMetrics } from "../../stores/metricsStore";
import { togglePanel } from "../../stores/panelStore";

const BAR_LENGTH = 8;
const FILLED = "\u2593"; // ▓
const EMPTY = "\u2591";  // ░

function buildBar(ratio: number): string {
  const filled = Math.round(ratio * BAR_LENGTH);
  const empty = BAR_LENGTH - filled;
  return FILLED.repeat(filled) + EMPTY.repeat(empty);
}

function thresholdColor(percent: number): string {
  if (percent < 60) return "var(--green)";
  if (percent < 85) return "var(--yellow)";
  return "var(--red)";
}

function bytesToGB(bytes: number): string {
  return (bytes / (1024 * 1024 * 1024)).toFixed(1);
}

function batteryColor(percent: number): string {
  if (percent > 50) return "var(--green)";
  if (percent >= 20) return "var(--yellow)";
  return "var(--red)";
}

export default function SystemMetrics() {
  const metrics = systemMetrics;

  const ramPercent = () => {
    const total = metrics().ram_total_bytes;
    if (total === 0) return 0;
    return (metrics().ram_used_bytes / total) * 100;
  };

  const cpuPercent = () => metrics().cpu_percent;

  return (
    <div
      onClick={() => togglePanel("system")}
      style={{
        display: "flex",
        "align-items": "center",
        gap: "14px",
        "flex-shrink": 0,
        "user-select": "none",
        cursor: "pointer",
        "border-radius": "4px",
        padding: "2px 6px",
        margin: "-2px -6px",
        transition: "background 0.15s ease",
      }}
      onMouseEnter={(e) => { e.currentTarget.style.background = "var(--bg-hover)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
    >
      {/* RAM */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          gap: "4px",
        }}
      >
        <span
          style={{
            "font-family": "var(--font-ui)",
            "font-size": "12px",
            color: "var(--text-secondary)",
          }}
        >
          RAM
        </span>
        <span
          style={{
            "font-family": "var(--font-mono)",
            "font-size": "13px",
            color: thresholdColor(ramPercent()),
            "white-space": "nowrap",
            ...(ramPercent() > 90 ? { animation: "pulse 1s ease-in-out infinite" } : {}),
          }}
        >
          {bytesToGB(metrics().ram_used_bytes)}/{bytesToGB(metrics().ram_total_bytes)}GB
        </span>
        <span
          style={{
            "font-family": "var(--font-mono)",
            "font-size": "11px",
            color: thresholdColor(ramPercent()),
            "letter-spacing": "-0.5px",
          }}
        >
          {buildBar(ramPercent() / 100)}
        </span>
      </div>

      {/* CPU */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          gap: "4px",
        }}
      >
        <span
          style={{
            "font-family": "var(--font-ui)",
            "font-size": "12px",
            color: "var(--text-secondary)",
          }}
        >
          CPU
        </span>
        <span
          style={{
            "font-family": "var(--font-mono)",
            "font-size": "13px",
            color: thresholdColor(cpuPercent()),
            "white-space": "nowrap",
            "min-width": "32px",
            "text-align": "right",
            ...(cpuPercent() > 90 ? { animation: "pulse 1s ease-in-out infinite" } : {}),
          }}
        >
          {Math.round(cpuPercent())}%
        </span>
        <span
          style={{
            "font-family": "var(--font-mono)",
            "font-size": "11px",
            color: thresholdColor(cpuPercent()),
            "letter-spacing": "-0.5px",
          }}
        >
          {buildBar(cpuPercent() / 100)}
        </span>
      </div>

    </div>
  );
}
