import { Show } from "solid-js";
import { gitStatus } from "../../stores/metricsStore";
import { togglePanel } from "../../stores/panelStore";

const CI_COLORS: Record<string, string> = {
  success: "var(--green)",
  pending: "var(--yellow)",
  failure: "var(--red)",
  unknown: "var(--grey)",
};

function branchColor(git: NonNullable<ReturnType<typeof gitStatus>>): string {
  if (git.conflicted > 0) return "var(--red)";
  if (git.staged > 0 || git.modified > 0 || git.untracked > 0)
    return "var(--yellow)";
  return "var(--green)";
}

function truncate(str: string, max: number): string {
  if (str.length <= max) return str;
  return str.slice(0, max - 1) + "\u2026"; // ellipsis
}

export default function GitStatusBadge() {
  const git = gitStatus;

  return (
    <Show when={git()}>
      {(g) => (
        <div
          onClick={() => togglePanel("git")}
          style={{
            display: "flex",
            "align-items": "center",
            gap: "8px",
            width: "200px",
            "flex-shrink": 0,
            "user-select": "none",
            "justify-content": "flex-end",
            cursor: "pointer",
            "border-radius": "4px",
            padding: "2px 6px",
            margin: "-2px -6px",
            transition: "background 0.15s ease",
          }}
          onMouseEnter={(e) => { e.currentTarget.style.background = "var(--bg-hover)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
        >
          {/* CI status dot */}
          <span
            style={{
              width: "6px",
              height: "6px",
              "border-radius": "50%",
              background: (g().ci_status ? CI_COLORS[g().ci_status] : undefined) ?? "var(--grey)",
              "flex-shrink": 0,
            }}
          />

          {/* Branch name */}
          <span
            style={{
              "font-family": "var(--font-mono)",
              "font-size": "12px",
              color: branchColor(g()),
              "white-space": "nowrap",
              overflow: "hidden",
              "text-overflow": "ellipsis",
              "max-width": "120px",
            }}
            title={g().branch}
          >
            {truncate(g().branch, 20)}
          </span>

          {/* Ahead / Behind */}
          <Show when={g().ahead > 0 || g().behind > 0}>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "12px",
                color: "var(--text-secondary)",
                "white-space": "nowrap",
              }}
            >
              <Show when={g().ahead > 0}>
                <span style={{ color: "var(--green)" }}>
                  {"\u2191"}{g().ahead}
                </span>
              </Show>
              <Show when={g().ahead > 0 && g().behind > 0}>
                {" "}
              </Show>
              <Show when={g().behind > 0}>
                <span style={{ color: "var(--red)" }}>
                  {"\u2193"}{g().behind}
                </span>
              </Show>
            </span>
          </Show>

          {/* Staged / Modified counts */}
          <Show when={g().staged > 0 || g().modified > 0 || g().untracked > 0}>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "12px",
                color: "var(--text-secondary)",
                "white-space": "nowrap",
              }}
            >
              <Show when={g().staged > 0}>
                <span style={{ color: "var(--green)" }}>+{g().staged}</span>
              </Show>
              <Show when={g().staged > 0 && (g().modified > 0 || g().untracked > 0)}>
                {" "}
              </Show>
              <Show when={g().modified > 0}>
                <span style={{ color: "var(--yellow)" }}>~{g().modified}</span>
              </Show>
              <Show when={g().modified > 0 && g().untracked > 0}>
                {" "}
              </Show>
              <Show when={g().untracked > 0}>
                <span style={{ color: "var(--text-muted)" }}>?{g().untracked}</span>
              </Show>
            </span>
          </Show>

          {/* Conflicts */}
          <Show when={g().conflicted > 0}>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "12px",
                color: "var(--red)",
                "white-space": "nowrap",
              }}
            >
              !{g().conflicted}
            </span>
          </Show>

          {/* PR number */}
          <Show when={g().pr_number !== null && g().pr_number !== undefined}>
            <span
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "12px",
                color: "var(--accent)",
                "white-space": "nowrap",
                cursor: g().pr_url ? "pointer" : "default",
              }}
              title={g().pr_url ?? undefined}
            >
              PR#{g().pr_number}
            </span>
          </Show>
        </div>
      )}
    </Show>
  );
}
