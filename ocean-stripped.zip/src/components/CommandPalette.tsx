import { createSignal, createMemo, For, onMount, onCleanup } from "solid-js";
import { ALL_COMMANDS, actions } from "../lib/keybindings";
import { hideCommandPalette } from "../stores/uiStore";

export default function CommandPalette() {
  const [query, setQuery] = createSignal("");
  const [selectedIdx, setSelectedIdx] = createSignal(0);
  let inputRef!: HTMLInputElement;

  onMount(() => {
    inputRef?.focus();
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { hideCommandPalette(); return; }
    };
    document.addEventListener("keydown", handleKey);
    onCleanup(() => document.removeEventListener("keydown", handleKey));
  });

  const filtered = createMemo(() => {
    const q = query().toLowerCase();
    if (!q) return ALL_COMMANDS;
    return ALL_COMMANDS.filter(
      (cmd) => cmd.label.toLowerCase().includes(q) || cmd.action.includes(q)
    );
  });

  const handleSelect = (action: string) => {
    hideCommandPalette();
    const fn = actions[action];
    if (fn) fn();
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIdx((i) => Math.min(i + 1, filtered().length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const cmd = filtered()[selectedIdx()];
      if (cmd) handleSelect(cmd.action);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0, left: 0, right: 0, bottom: 0,
        background: "rgba(0,0,0,0.5)",
        "z-index": "1000",
        display: "flex",
        "justify-content": "center",
        "padding-top": "15vh",
      }}
      onClick={(e) => { if (e.target === e.currentTarget) hideCommandPalette(); }}
    >
      <div style={{
        width: "500px",
        "max-height": "400px",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "8px",
        "box-shadow": "0 8px 32px rgba(0,0,0,0.5)",
        display: "flex",
        "flex-direction": "column",
        overflow: "hidden",
      }}>
        <input
          ref={inputRef}
          value={query()}
          onInput={(e) => { setQuery(e.currentTarget.value); setSelectedIdx(0); }}
          onKeyDown={handleKeyDown}
          placeholder="Type a command..."
          style={{
            padding: "12px 16px",
            background: "var(--bg-primary)",
            border: "none",
            "border-bottom": "1px solid var(--border)",
            color: "var(--text-primary)",
            "font-size": "14px",
            "font-family": "var(--font-ui)",
            outline: "none",
          }}
        />
        <div style={{ flex: 1, "overflow-y": "auto", padding: "4px 0" }}>
          <For each={filtered()}>
            {(cmd, i) => (
              <div
                onClick={() => handleSelect(cmd.action)}
                style={{
                  padding: "8px 16px",
                  display: "flex",
                  "justify-content": "space-between",
                  "align-items": "center",
                  cursor: "pointer",
                  background: i() === selectedIdx() ? "var(--bg-active)" : "transparent",
                  transition: "background 0.1s",
                }}
                onMouseEnter={() => setSelectedIdx(i())}
              >
                <span style={{
                  "font-size": "13px",
                  color: i() === selectedIdx() ? "var(--text-primary)" : "var(--text-secondary)",
                }}>
                  {cmd.label}
                </span>
                <span style={{
                  "font-size": "11px",
                  "font-family": "var(--font-mono)",
                  color: "var(--text-muted)",
                  background: "var(--bg-hover)",
                  padding: "2px 6px",
                  "border-radius": "3px",
                }}>
                  {cmd.shortcut}
                </span>
              </div>
            )}
          </For>
          {filtered().length === 0 && (
            <div style={{ padding: "16px", color: "var(--text-muted)", "text-align": "center", "font-size": "13px" }}>
              No matching commands
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
