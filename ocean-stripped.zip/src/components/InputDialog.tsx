import { createSignal, onMount, Show } from "solid-js";

export interface InputDialogField {
  label: string;
  placeholder?: string;
  defaultValue?: string;
}

interface InputDialogProps {
  title: string;
  fields: InputDialogField[];
  onSubmit: (values: string[]) => void;
  onCancel: () => void;
}

export default function InputDialog(props: InputDialogProps) {
  const [values, setValues] = createSignal<string[]>(
    props.fields.map((f) => f.defaultValue ?? "")
  );
  let firstInputRef!: HTMLInputElement;

  onMount(() => {
    firstInputRef?.focus();
  });

  const handleSubmit = () => {
    const vals = values();
    if (vals.every((v) => v.trim().length > 0)) {
      props.onSubmit(vals);
    }
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter") handleSubmit();
    if (e.key === "Escape") props.onCancel();
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "rgba(0, 0, 0, 0.5)",
        display: "flex",
        "align-items": "center",
        "justify-content": "center",
        "z-index": "1000",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) props.onCancel();
      }}
    >
      <div
        style={{
          background: "var(--bg-secondary)",
          border: "1px solid var(--border)",
          "border-radius": "8px",
          padding: "20px",
          width: "400px",
          "max-width": "90vw",
          "box-shadow": "0 8px 32px rgba(0, 0, 0, 0.4)",
        }}
        onKeyDown={handleKeyDown}
      >
        <div
          style={{
            "font-size": "14px",
            "font-weight": 600,
            color: "var(--text-primary)",
            "margin-bottom": "16px",
          }}
        >
          {props.title}
        </div>

        {props.fields.map((field, i) => (
          <div style={{ "margin-bottom": "12px" }}>
            <label
              style={{
                display: "block",
                "font-size": "12px",
                color: "var(--text-secondary)",
                "margin-bottom": "4px",
              }}
            >
              {field.label}
            </label>
            <input
              ref={(el) => { if (i === 0) firstInputRef = el; }}
              value={values()[i]}
              onInput={(e) => {
                const newVals = [...values()];
                newVals[i] = e.currentTarget.value;
                setValues(newVals);
              }}
              placeholder={field.placeholder}
              style={{
                width: "100%",
                padding: "8px 10px",
                background: "var(--bg-primary)",
                border: "1px solid var(--border)",
                "border-radius": "4px",
                color: "var(--text-primary)",
                "font-size": "13px",
                "font-family": "var(--font-mono)",
                outline: "none",
                "box-sizing": "border-box",
              }}
              onFocus={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)";
              }}
              onBlur={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
              }}
            />
          </div>
        ))}

        <div
          style={{
            display: "flex",
            "justify-content": "flex-end",
            gap: "8px",
            "margin-top": "16px",
          }}
        >
          <button
            onClick={props.onCancel}
            style={{
              padding: "6px 16px",
              background: "none",
              border: "1px solid var(--border)",
              "border-radius": "4px",
              color: "var(--text-secondary)",
              cursor: "pointer",
              "font-size": "12px",
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            style={{
              padding: "6px 16px",
              background: "var(--accent)",
              border: "none",
              "border-radius": "4px",
              color: "#1a1b26",
              cursor: "pointer",
              "font-size": "12px",
              "font-weight": 600,
            }}
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
}
