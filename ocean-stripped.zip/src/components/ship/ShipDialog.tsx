import { createSignal, Show, For } from "solid-js";
import { shipWorkspace } from "../../stores/workspaceStore";
import type { ShipResult } from "../../stores/workspaceStore";
import { logInfo, logError } from "../../stores/logStore";

interface ShipDialogProps {
  workspaceId: string;
  workspaceName: string;
  onClose: () => void;
}

type ShipStep = "idle" | "creating-branch" | "pushing" | "creating-pr" | "done" | "error";

export default function ShipDialog(props: ShipDialogProps) {
  const [title, setTitle] = createSignal(props.workspaceName);
  const [step, setStep] = createSignal<ShipStep>("idle");
  const [result, setResult] = createSignal<ShipResult | null>(null);
  const [error, setError] = createSignal<string | null>(null);

  const isShipping = () => {
    const s = step();
    return s === "creating-branch" || s === "pushing" || s === "creating-pr";
  };

  const handleShip = async () => {
    const prTitle = title().trim();
    if (!prTitle) return;

    setError(null);
    try {
      setStep("creating-branch");
      logInfo("frontend", `ShipDialog: shipping workspace ${props.workspaceId.slice(0, 8)} with title "${prTitle}"`);

      // Simulate step progression — the actual backend call does it all at once,
      // but we animate through the steps for UX
      const stepTimer = setTimeout(() => setStep("pushing"), 1500);
      const stepTimer2 = setTimeout(() => setStep("creating-pr"), 3000);

      const shipResult = await shipWorkspace(props.workspaceId, prTitle);

      clearTimeout(stepTimer);
      clearTimeout(stepTimer2);

      setResult(shipResult);
      setStep("done");
      logInfo("frontend", `Ship complete: branch=${shipResult.branch_name}, pr=${shipResult.pr_url ?? "none"}, success=${shipResult.success}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logError("frontend", `ShipDialog: ship failed: ${msg}`);
      setError(msg);
      setStep("error");
    }
  };

  const handleRetry = () => {
    setStep("idle");
    setError(null);
    setResult(null);
  };

  const stepLabel = (s: ShipStep): string => {
    switch (s) {
      case "creating-branch": return "Creating branch...";
      case "pushing": return "Pushing commits...";
      case "creating-pr": return "Creating PR...";
      case "done": return "Done!";
      case "error": return "Failed";
      default: return "";
    }
  };

  const STEPS: ShipStep[] = ["creating-branch", "pushing", "creating-pr"];

  const stepStatus = (s: ShipStep): "pending" | "active" | "done" | "error" => {
    const current = step();
    if (current === "error") {
      const currentIdx = STEPS.indexOf(current);
      const sIdx = STEPS.indexOf(s);
      if (sIdx < currentIdx) return "done";
      if (sIdx === currentIdx) return "error";
      return "pending";
    }
    if (current === "done") return "done";
    const currentIdx = STEPS.indexOf(current);
    const sIdx = STEPS.indexOf(s);
    if (sIdx < currentIdx) return "done";
    if (sIdx === currentIdx) return "active";
    return "pending";
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        background: "rgba(0,0,0,0.5)",
        "z-index": 300,
        display: "flex",
        "align-items": "center",
        "justify-content": "center",
        "font-family": "var(--font-ui)",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget && !isShipping()) props.onClose();
      }}
    >
      <div
        style={{
          background: "var(--bg-secondary)",
          border: "1px solid var(--border)",
          "border-radius": "12px",
          "box-shadow": "0 8px 32px rgba(0,0,0,0.4)",
          width: "440px",
          "max-width": "90vw",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "16px 20px",
            "border-bottom": "1px solid var(--border)",
            display: "flex",
            "align-items": "center",
            "justify-content": "space-between",
          }}
        >
          <span
            style={{
              "font-weight": 600,
              "font-size": "15px",
              color: "var(--text-primary)",
            }}
          >
            Ship Workspace
          </span>
          <button
            onClick={props.onClose}
            disabled={isShipping()}
            style={{
              background: "none",
              border: "none",
              color: "var(--text-muted)",
              cursor: isShipping() ? "not-allowed" : "pointer",
              "font-size": "16px",
              "line-height": 1,
              padding: "2px 6px",
              "border-radius": "3px",
              opacity: isShipping() ? 0.4 : 1,
            }}
          >
            {"\u2715"}
          </button>
        </div>

        {/* Body */}
        <div style={{ padding: "20px" }}>
          {/* PR title input */}
          <Show when={step() === "idle"}>
            <div style={{ "margin-bottom": "16px" }}>
              <label
                style={{
                  display: "block",
                  "font-size": "12px",
                  color: "var(--text-secondary)",
                  "margin-bottom": "6px",
                  "font-weight": 500,
                }}
              >
                PR Title
              </label>
              <input
                value={title()}
                onInput={(e) => setTitle(e.currentTarget.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleShip();
                  if (e.key === "Escape") props.onClose();
                }}
                style={{
                  width: "100%",
                  padding: "8px 12px",
                  background: "var(--bg-primary)",
                  border: "1px solid var(--border)",
                  "border-radius": "6px",
                  color: "var(--text-primary)",
                  "font-size": "13px",
                  "font-family": "var(--font-ui)",
                  outline: "none",
                }}
                onFocus={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)";
                }}
                onBlur={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                }}
                ref={(el) => setTimeout(() => el.focus(), 50)}
              />
            </div>
          </Show>

          {/* Progress steps */}
          <Show when={isShipping() || step() === "done"}>
            <div style={{ "margin-bottom": "16px" }}>
              <For each={STEPS}>
                {(s) => {
                  const status = () => stepStatus(s);
                  return (
                    <div
                      style={{
                        display: "flex",
                        "align-items": "center",
                        gap: "10px",
                        padding: "6px 0",
                      }}
                    >
                      <span
                        style={{
                          width: "18px",
                          height: "18px",
                          "border-radius": "50%",
                          display: "flex",
                          "align-items": "center",
                          "justify-content": "center",
                          "font-size": "10px",
                          "flex-shrink": 0,
                          background:
                            status() === "done"
                              ? "var(--green)"
                              : status() === "active"
                                ? "var(--accent)"
                                : status() === "error"
                                  ? "var(--red)"
                                  : "var(--bg-hover)",
                          color:
                            status() === "pending"
                              ? "var(--text-muted)"
                              : "var(--bg-primary)",
                          animation:
                            status() === "active" ? "pulse 1.5s infinite" : "none",
                        }}
                      >
                        {status() === "done"
                          ? "\u2713"
                          : status() === "error"
                            ? "\u2717"
                            : status() === "active"
                              ? "\u2022"
                              : "\u2022"}
                      </span>
                      <span
                        style={{
                          "font-size": "13px",
                          color:
                            status() === "active"
                              ? "var(--accent)"
                              : status() === "done"
                                ? "var(--green)"
                                : "var(--text-muted)",
                          "font-weight": status() === "active" ? 500 : "normal",
                        }}
                      >
                        {stepLabel(s)}
                      </span>
                    </div>
                  );
                }}
              </For>
            </div>
          </Show>

          {/* Success result */}
          <Show when={result()}>
            {(r) => (
              <div>
                <div
                  style={{
                    padding: "12px",
                    background: "rgba(158,206,106,0.1)",
                    border: "1px solid var(--green)",
                    "border-radius": "6px",
                    "margin-bottom": "12px",
                  }}
                >
                  <div
                    style={{
                      "font-weight": 600,
                      color: "var(--green)",
                      "margin-bottom": "6px",
                    }}
                  >
                    Shipped successfully
                  </div>
                  <div style={{ "font-size": "12px", color: "var(--text-secondary)", "margin-bottom": "4px" }}>
                    Branch: <span style={{ "font-family": "var(--font-mono)" }}>{r().branch_name}</span>
                  </div>
                  <div style={{ "font-size": "12px", color: "var(--text-secondary)", "margin-bottom": "4px" }}>
                    Commit: <span style={{ "font-family": "var(--font-mono)" }}>{r().commit_hash.slice(0, 8)}</span>
                  </div>
                  <div style={{ "font-size": "12px", color: "var(--text-secondary)" }}>
                    {r().message}
                  </div>
                </div>

                {/* PR URL */}
                <Show when={r().pr_url}>
                  <a
                    href={r().pr_url!}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: "block",
                      padding: "10px 16px",
                      background: "var(--accent)",
                      color: "var(--bg-primary)",
                      "text-decoration": "none",
                      "border-radius": "6px",
                      "text-align": "center",
                      "font-weight": 600,
                      "font-size": "13px",
                      "margin-bottom": "8px",
                    }}
                  >
                    Open PR
                  </a>
                </Show>

                {/* Non-success message */}
                <Show when={!r().success}>
                  <div
                    style={{
                      padding: "8px 12px",
                      background: "rgba(224,175,104,0.1)",
                      border: "1px solid var(--yellow)",
                      "border-radius": "6px",
                      "font-size": "12px",
                      color: "var(--yellow)",
                    }}
                  >
                    {r().message}
                  </div>
                </Show>
              </div>
            )}
          </Show>

          {/* Error state */}
          <Show when={step() === "error" && error()}>
            <div
              style={{
                padding: "10px 12px",
                background: "rgba(247,118,142,0.1)",
                border: "1px solid var(--red)",
                "border-radius": "6px",
                "margin-bottom": "12px",
              }}
            >
              <div style={{ "font-weight": 600, color: "var(--red)", "margin-bottom": "4px" }}>
                Ship failed
              </div>
              <div style={{ "font-size": "12px", color: "var(--red)" }}>{error()}</div>
            </div>
          </Show>
        </div>

        {/* Footer */}
        <div
          style={{
            padding: "12px 20px 16px",
            display: "flex",
            gap: "8px",
            "justify-content": "flex-end",
          }}
        >
          <Show when={step() === "idle"}>
            <button
              onClick={props.onClose}
              style={{
                background: "none",
                border: "1px solid var(--border)",
                color: "var(--text-secondary)",
                padding: "8px 20px",
                "border-radius": "6px",
                cursor: "pointer",
                "font-size": "13px",
                "font-family": "var(--font-ui)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = "var(--text-muted)";
                (e.currentTarget as HTMLElement).style.color = "var(--text-primary)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                (e.currentTarget as HTMLElement).style.color = "var(--text-secondary)";
              }}
            >
              Cancel
            </button>
            <button
              onClick={handleShip}
              disabled={!title().trim()}
              style={{
                background: "var(--accent)",
                color: "var(--bg-primary)",
                border: "none",
                padding: "8px 24px",
                "border-radius": "6px",
                cursor: !title().trim() ? "not-allowed" : "pointer",
                "font-size": "13px",
                "font-weight": 600,
                "font-family": "var(--font-ui)",
                opacity: !title().trim() ? 0.5 : 1,
              }}
            >
              Ship
            </button>
          </Show>

          <Show when={step() === "error"}>
            <button
              onClick={handleRetry}
              style={{
                background: "none",
                border: "1px solid var(--border)",
                color: "var(--text-secondary)",
                padding: "8px 20px",
                "border-radius": "6px",
                cursor: "pointer",
                "font-size": "13px",
                "font-family": "var(--font-ui)",
              }}
            >
              Retry
            </button>
            <button
              onClick={props.onClose}
              style={{
                background: "none",
                border: "1px solid var(--border)",
                color: "var(--text-secondary)",
                padding: "8px 20px",
                "border-radius": "6px",
                cursor: "pointer",
                "font-size": "13px",
                "font-family": "var(--font-ui)",
              }}
            >
              Close
            </button>
          </Show>

          <Show when={step() === "done"}>
            <button
              onClick={props.onClose}
              style={{
                background: "none",
                border: "1px solid var(--border)",
                color: "var(--text-secondary)",
                padding: "8px 24px",
                "border-radius": "6px",
                cursor: "pointer",
                "font-size": "13px",
                "font-family": "var(--font-ui)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = "var(--text-muted)";
                (e.currentTarget as HTMLElement).style.color = "var(--text-primary)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
                (e.currentTarget as HTMLElement).style.color = "var(--text-secondary)";
              }}
            >
              Done
            </button>
          </Show>
        </div>
      </div>
    </div>
  );
}
