import { createSignal, createMemo, For, onMount, onCleanup } from "solid-js";
import { sessionState, setActiveSession } from "../stores/sessionStore";
import { layoutState, activateGroup, collectLeafIds, type LayoutGroup } from "../stores/layoutStore";
import { hideQuickSwitcher, hideScrollbackViewer } from "../stores/uiStore";

export default function QuickSwitcher() {
  const [query, setQuery] = createSignal("");
  const [selectedIdx, setSelectedIdx] = createSignal(0);
  let inputRef!: HTMLInputElement;

  onMount(() => {
    inputRef?.focus();
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") hideQuickSwitcher();
    };
    document.addEventListener("keydown", handleKey);
    onCleanup(() => document.removeEventListener("keydown", handleKey));
  });

  const groupLabel = (group: LayoutGroup): string => {
    const leafIds = collectLeafIds(group.root);
    const wsId = group.workspaceId;
    if (!wsId) return leafIds.map((id) => id.slice(0, 6)).join(" | ");
    const sessions = sessionState.sessions[wsId] ?? [];
    return leafIds
      .map((id) => sessions.find((s) => s.id === id)?.name ?? id.slice(0, 6))
      .join(" | ");
  };

  const allGroups = createMemo(() => layoutState.groups);

  const filtered = createMemo(() => {
    const q = query().toLowerCase();
    const groups = allGroups();
    if (!q) return groups;
    return groups.filter((g) => groupLabel(g).toLowerCase().includes(q) || g.id.includes(q));
  });

  const handleSelect = (group: LayoutGroup) => {
    hideQuickSwitcher();
    hideScrollbackViewer();
    activateGroup(group.id);
    if (group.focusedSessionId) setActiveSession(group.focusedSessionId);
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIdx((i) => Math.min(i + 1, filtered().length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const g = filtered()[selectedIdx()];
      if (g) handleSelect(g);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0, left: 0, right: 0, bottom: 0,
        background: "rgba(0,0,0,0.5)",
        "z-index": "1000",
        display: "flex",
        "justify-content": "center",
        "padding-top": "15vh",
      }}
      onClick={(e) => { if (e.target === e.currentTarget) hideQuickSwitcher(); }}
    >
      <div style={{
        width: "450px",
        "max-height": "350px",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "8px",
        "box-shadow": "0 8px 32px rgba(0,0,0,0.5)",
        display: "flex",
        "flex-direction": "column",
        overflow: "hidden",
      }}>
        <input
          ref={inputRef}
          value={query()}
          onInput={(e) => { setQuery(e.currentTarget.value); setSelectedIdx(0); }}
          onKeyDown={handleKeyDown}
          placeholder="Switch to session..."
          style={{
            padding: "12px 16px",
            background: "var(--bg-primary)",
            border: "none",
            "border-bottom": "1px solid var(--border)",
            color: "var(--text-primary)",
            "font-size": "14px",
            "font-family": "var(--font-ui)",
            outline: "none",
          }}
        />
        <div style={{ flex: 1, "overflow-y": "auto", padding: "4px 0" }}>
          <For each={filtered()}>
            {(group, i) => {
              const label = () => groupLabel(group);
              const isSplit = () => group.root.type === "split";
              const isActive = () => layoutState.activeGroupId === group.id;
              return (
                <div
                  onClick={() => handleSelect(group)}
                  style={{
                    padding: "8px 16px",
                    display: "flex",
                    "align-items": "center",
                    gap: "8px",
                    cursor: "pointer",
                    background: i() === selectedIdx() ? "var(--bg-active)" : "transparent",
                  }}
                  onMouseEnter={() => setSelectedIdx(i())}
                >
                  <span style={{
                    width: "8px", height: "8px", "border-radius": "50%",
                    background: isActive() ? "var(--accent)" : "var(--green)",
                    "flex-shrink": 0,
                  }} />
                  <span style={{
                    "font-size": "13px",
                    color: i() === selectedIdx() ? "var(--text-primary)" : "var(--text-secondary)",
                    flex: 1,
                  }}>
                    {label()}
                  </span>
                  {isSplit() && (
                    <span style={{
                      "font-size": "9px",
                      color: "var(--text-muted)",
                      background: "var(--bg-hover)",
                      padding: "1px 5px",
                      "border-radius": "3px",
                    }}>
                      split
                    </span>
                  )}
                </div>
              );
            }}
          </For>
          {filtered().length === 0 && (
            <div style={{ padding: "16px", color: "var(--text-muted)", "text-align": "center", "font-size": "13px" }}>
              No matching groups
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
