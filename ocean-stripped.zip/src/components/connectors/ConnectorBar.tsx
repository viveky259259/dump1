import { For, Show } from "solid-js";
import { connectorGroups } from "../../stores/connectorStore";
import ConnectorGroupComponent from "./ConnectorGroup";

export default function ConnectorBar() {
  const hasConnectors = () => connectorGroups().length > 0;

  return (
    <Show when={hasConnectors()}>
      <div
        style={{
          height: "36px",
          "min-height": "36px",
          display: "flex",
          "align-items": "center",
          gap: "12px",
          padding: "0 12px",
          background: "var(--bg-secondary)",
          "border-top": "1px solid var(--border)",
          overflow: "hidden",
          "flex-shrink": 0,
        }}
      >
        <span
          style={{
            color: "var(--text-muted)",
            "font-size": "10px",
            "text-transform": "uppercase",
            "letter-spacing": "0.5px",
            "white-space": "nowrap",
            "flex-shrink": 0,
          }}
        >
          Connectors
        </span>
        <div
          style={{
            display: "flex",
            "align-items": "center",
            gap: "16px",
            overflow: "auto",
            flex: 1,
          }}
        >
          <For each={connectorGroups()}>
            {(group) => <ConnectorGroupComponent group={group} />}
          </For>
        </div>
      </div>
    </Show>
  );
}
