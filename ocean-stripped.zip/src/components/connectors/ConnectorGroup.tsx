import { For, Show, createSignal } from "solid-js";
import type {
  ConnectorGroup as ConnectorGroupType,
  ConnectorProcess,
} from "../../stores/connectorStore";
import { killConnectorGroup } from "../../stores/connectorStore";
import { setActiveSession } from "../../stores/sessionStore";

interface Props {
  group: ConnectorGroupType;
}

function healthBorderColor(health: string): string {
  switch (health) {
    case "healthy":
      return "var(--green)";
    case "degraded":
      return "var(--yellow)";
    case "down":
      return "var(--red)";
    default:
      return "var(--border)";
  }
}

function statusDotColor(status: string): string {
  return status === "running" ? "var(--green)" : "var(--red)";
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)}KB`;
  if (bytes < 1024 * 1024 * 1024)
    return `${(bytes / (1024 * 1024)).toFixed(0)}MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)}GB`;
}

function ProcessPill(props: { process: ConnectorProcess }) {
  const handleClick = () => {
    if (props.process.session_id) {
      setActiveSession(props.process.session_id);
    }
  };

  return (
    <div
      onClick={handleClick}
      style={{
        display: "inline-flex",
        "align-items": "center",
        gap: "4px",
        padding: "2px 8px",
        "border-radius": "4px",
        background: "var(--bg-hover)",
        cursor: props.process.session_id ? "pointer" : "default",
        "font-size": "11px",
        "font-family": "var(--font-mono)",
        "white-space": "nowrap",
      }}
    >
      <span
        style={{
          width: "6px",
          height: "6px",
          "border-radius": "50%",
          background: statusDotColor(props.process.status),
          "flex-shrink": 0,
        }}
      />
      <span style={{ color: "var(--text-primary)" }}>{props.process.name}</span>
      <Show when={props.process.port}>
        <span style={{ color: "var(--text-secondary)" }}>
          :{props.process.port}
        </span>
      </Show>
    </div>
  );
}

export default function ConnectorGroupComponent(props: Props) {
  const [contextMenu, setContextMenu] = createSignal<{
    x: number;
    y: number;
  } | null>(null);

  const totalRam = () =>
    props.group.sessions.reduce(
      (sum, p) => sum + (p.ram_bytes ?? 0),
      0
    );

  const totalCpu = () =>
    props.group.sessions.reduce(
      (sum, p) => sum + (p.cpu_percent ?? 0),
      0
    );

  const handleContextMenu = (e: MouseEvent) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY });
    const handler = () => {
      setContextMenu(null);
      document.removeEventListener("click", handler);
    };
    document.addEventListener("click", handler);
  };

  const handleKillGroup = async () => {
    setContextMenu(null);
    await killConnectorGroup(props.group.id);
  };

  return (
    <div
      onContextMenu={handleContextMenu}
      style={{
        display: "flex",
        "align-items": "center",
        gap: "4px",
        padding: "0 8px",
        "border-left": `2px solid ${healthBorderColor(props.group.health)}`,
        position: "relative",
      }}
    >
      <For each={props.group.sessions}>
        {(process, index) => (
          <>
            <ProcessPill process={process} />
            <Show when={index() < props.group.sessions.length - 1}>
              <span
                style={{
                  color: "var(--text-muted)",
                  "font-size": "10px",
                  "user-select": "none",
                }}
              >
                {"\u2500\u2500\u25B6"}
              </span>
            </Show>
          </>
        )}
      </For>

      {/* Aggregated stats */}
      <Show when={totalRam() > 0}>
        <span
          style={{
            color: "var(--text-secondary)",
            "font-size": "10px",
            "margin-left": "8px",
            "font-family": "var(--font-mono)",
          }}
        >
          RAM: {formatBytes(totalRam())}
        </span>
      </Show>
      <Show when={totalCpu() > 0}>
        <span
          style={{
            color: "var(--text-secondary)",
            "font-size": "10px",
            "font-family": "var(--font-mono)",
          }}
        >
          CPU: {totalCpu().toFixed(1)}%
        </span>
      </Show>

      {/* Context menu */}
      <Show when={contextMenu()}>
        {(menu) => (
          <div
            style={{
              position: "fixed",
              left: `${menu().x}px`,
              top: `${menu().y}px`,
              background: "var(--bg-secondary)",
              border: "1px solid var(--border)",
              "border-radius": "4px",
              padding: "4px 0",
              "z-index": 1000,
              "min-width": "120px",
              "box-shadow": "0 4px 12px rgba(0,0,0,0.4)",
            }}
          >
            <div
              onClick={handleKillGroup}
              style={{
                padding: "4px 12px",
                cursor: "pointer",
                "font-size": "12px",
                color: "var(--red)",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "var(--bg-hover)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "transparent")
              }
            >
              Kill Group
            </div>
          </div>
        )}
      </Show>
    </div>
  );
}
