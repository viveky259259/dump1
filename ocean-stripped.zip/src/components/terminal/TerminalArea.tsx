import { Show, Switch, Match, For, createMemo } from "solid-js";
import {
  layoutState,
  type LayoutNode,
  type SplitNode,
  setFocusedSession,
  updateSplitRatio,
  resizePaneToWidth,
  closePane,
  countLeaves,
  collectLeafIds,
  MIN_PANE_WIDTH,
  MIN_PANE_HEIGHT,
} from "../../stores/layoutStore";
import { closeSession } from "../../stores/sessionStore";
import { captureScrollback } from "../../stores/scrollbackStore";
import { disposeTerminal } from "./TerminalPane";
import { createSignal } from "solid-js";
import { sessionState } from "../../stores/sessionStore";
import { getSessionGit } from "../../stores/gitStore";
import TerminalPane from "./TerminalPane";
import PaneDivider from "./PaneDivider";
import { settings } from "../../stores/settingsStore";
import GitInfoDropdown from "./GitInfoDropdown";
import A2UIRenderer from "../a2ui/A2UIRenderer";

/** Search all workspaces for a session by ID */
function findSession(sessionId: string) {
  for (const wsId of Object.keys(sessionState.sessions)) {
    const found = sessionState.sessions[wsId]?.find((s) => s.id === sessionId);
    if (found) return found;
  }
  return undefined;
}

function getSessionName(sessionId: string): string {
  return findSession(sessionId)?.name ?? sessionId.slice(0, 8);
}

function getSessionStatus(sessionId: string): string {
  return findSession(sessionId)?.status ?? "unknown";
}

function getSessionType(sessionId: string): string {
  return findSession(sessionId)?.session_type ?? "shell";
}

const STATUS_DOT_COLORS: Record<string, string> = {
  active: "var(--green)",
  idle: "var(--blue)",
  waiting: "var(--yellow)",
  failed: "var(--red)",
  completed: "var(--grey)",
};

const CI_COLORS: Record<string, string> = {
  success: "var(--green)",
  pending: "var(--yellow)",
  failure: "var(--red)",
  unknown: "var(--grey)",
};

// AI tool detection — checks session name and common AI CLI tool names
const AI_TOOLS: Record<string, { label: string; color: string }> = {
  claude: { label: "Claude", color: "#D97706" },
  "claude-code": { label: "Claude", color: "#D97706" },
  codex: { label: "Codex", color: "#10B981" },
  aider: { label: "Aider", color: "#8B5CF6" },
  cursor: { label: "Cursor", color: "#3B82F6" },
  copilot: { label: "Copilot", color: "#6366F1" },
  "github-copilot": { label: "Copilot", color: "#6366F1" },
  cody: { label: "Cody", color: "#FF6B6B" },
  devin: { label: "Devin", color: "#14B8A6" },
  sweep: { label: "Sweep", color: "#F59E0B" },
  gpt: { label: "GPT", color: "#10B981" },
  gemini: { label: "Gemini", color: "#4285F4" },
};

function detectAI(sessionName: string, sessionType: string): { label: string; color: string } | null {
  if (sessionType === "agent") return { label: "AI", color: "var(--accent)" };
  const lower = sessionName.toLowerCase();
  for (const [key, info] of Object.entries(AI_TOOLS)) {
    if (lower.includes(key)) return info;
  }
  return null;
}

const DIVIDER_SIZE = 6; // px

/** Isolated leaf pane component — prevents stale reads during layout transitions */
function LeafPaneWrapper(props: { sessionId: string }) {
  const isFocused = () => layoutState.focusedSessionId === props.sessionId;
  const name = () => getSessionName(props.sessionId);
  const status = () => getSessionStatus(props.sessionId);
  const sessionType = () => getSessionType(props.sessionId);
  const aiInfo = () => detectAI(name(), sessionType());
  const sessionGit = () => getSessionGit(props.sessionId);
  const [gitDropdownOpen, setGitDropdownOpen] = createSignal(false);
  const [exited, setExited] = createSignal(false);

  // Listen for PTY exit to show close button
  import("@tauri-apps/api/event").then(({ listen }) => {
    listen<number>(`pty-exit-${props.sessionId}`, () => {
      setExited(true);
    });
  });

  const isExited = () => exited() || status() === "completed" || status() === "failed";

  const handleClosePane = () => {
    captureScrollback(props.sessionId);
    closePane(props.sessionId);
    disposeTerminal(props.sessionId);
    closeSession(props.sessionId);
  };

  return (
    <div
      data-session-id={props.sessionId}
      style={{
        "min-width": `${MIN_PANE_WIDTH}px`,
        "min-height": `${MIN_PANE_HEIGHT}px`,
        width: "100%",
        height: "100%",
        display: "flex",
        "flex-direction": "column",
      }}
    >
      {/* Pane header — session info + git context */}
      <div
        onClick={() => setFocusedSession(props.sessionId)}
        style={{
          display: "flex",
          "align-items": "center",
          gap: "8px",
          padding: "3px 10px",
          height: "26px",
          "flex-shrink": 0,
          background: isFocused() ? "var(--bg-secondary)" : "var(--bg-primary)",
          "border-bottom": isFocused()
            ? "2px solid var(--accent)"
            : "2px solid var(--border)",
          cursor: "pointer",
          "user-select": "none",
          transition: "background 0.15s, border-color 0.15s",
        }}
      >
        {/* Status dot */}
        <span
          style={{
            width: "7px",
            height: "7px",
            "border-radius": "50%",
            background: STATUS_DOT_COLORS[status()] ?? "var(--grey)",
            "flex-shrink": 0,
          }}
        />
        {/* Session name */}
        <span
          style={{
            "font-family": "var(--font-ui)",
            "font-size": "11px",
            color: isFocused() ? "var(--text-primary)" : "var(--text-muted)",
            "font-weight": isFocused() ? "600" : "normal",
            "white-space": "nowrap",
            overflow: "hidden",
            "text-overflow": "ellipsis",
            "max-width": "120px",
          }}
        >
          {name()}
        </span>

        {/* AI tool badge */}
        <Show when={aiInfo()}>
          {(ai) => (
            <span
              style={{
                display: "inline-flex",
                "align-items": "center",
                gap: "3px",
                padding: "1px 6px",
                "border-radius": "8px",
                background: `${ai().color}20`,
                border: `1px solid ${ai().color}40`,
                "flex-shrink": 0,
              }}
            >
              <span style={{ "font-size": "9px", "line-height": 1 }}>{"*"}</span>
              <span style={{
                "font-family": "var(--font-ui)",
                "font-size": "9px",
                "font-weight": 600,
                color: ai().color,
                "letter-spacing": "0.3px",
              }}>
                {ai().label}
              </span>
            </span>
          )}
        </Show>

        {/* Git info — per session */}
        {(() => {
          const sg = sessionGit();
          const isLoading = sg.loading;
          const git = sg.status;

          return (
            <>
              <Show when={isLoading && !git}>
                <span style={{ width: "1px", height: "12px", background: "var(--border)", "flex-shrink": 0 }} />
                <span style={{
                  "font-family": "var(--font-mono)", "font-size": "10px",
                  color: "var(--text-muted)", animation: "pulse 1.5s ease-in-out infinite",
                }}>git...</span>
              </Show>

              <Show when={git}>
                <span style={{ width: "1px", height: "12px", background: "var(--border)", "flex-shrink": 0 }} />
                <div
                  onClick={(e) => { e.stopPropagation(); setGitDropdownOpen(!gitDropdownOpen()); }}
                  style={{
                    display: "flex", "align-items": "center", gap: "6px",
                    cursor: "pointer", padding: "1px 4px", "border-radius": "3px",
                    transition: "background 0.15s", position: "relative",
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
                >
                  <Show when={isLoading}>
                    <span style={{
                      width: "8px", height: "8px", "border-radius": "50%",
                      border: "1.5px solid var(--text-muted)", "border-top-color": "var(--accent)",
                      animation: "spin 0.8s linear infinite", "flex-shrink": 0,
                    }} />
                  </Show>
                  <span style={{
                    "font-family": "var(--font-mono)", "font-size": "10px",
                    color: git!.conflicted > 0 ? "var(--red)" : (git!.staged > 0 || git!.modified > 0) ? "var(--yellow)" : "var(--green)",
                    "white-space": "nowrap", "max-width": "100px", overflow: "hidden", "text-overflow": "ellipsis",
                  }}>{git!.branch}</span>
                  <Show when={git!.ahead > 0 || git!.behind > 0}>
                    <span style={{ "font-family": "var(--font-mono)", "font-size": "10px" }}>
                      <Show when={git!.ahead > 0}><span style={{ color: "var(--green)" }}>{"\u2191"}{git!.ahead}</span></Show>
                      <Show when={git!.behind > 0}><span style={{ color: "var(--red)" }}>{"\u2193"}{git!.behind}</span></Show>
                    </span>
                  </Show>
                  <Show when={git!.staged > 0 || git!.modified > 0 || git!.untracked > 0}>
                    <span style={{ "font-family": "var(--font-mono)", "font-size": "10px" }}>
                      <Show when={git!.staged > 0}><span style={{ color: "var(--green)" }}>+{git!.staged}</span>{" "}</Show>
                      <Show when={git!.modified > 0}><span style={{ color: "var(--yellow)" }}>~{git!.modified}</span>{" "}</Show>
                      <Show when={git!.untracked > 0}><span style={{ color: "var(--text-muted)" }}>?{git!.untracked}</span></Show>
                    </span>
                  </Show>
                  <Show when={git!.ci_status}>
                    <span style={{ width: "6px", height: "6px", "border-radius": "50%", background: CI_COLORS[git!.ci_status!] ?? "var(--grey)", "flex-shrink": 0 }} />
                  </Show>
                  <Show when={gitDropdownOpen()}>
                    <GitInfoDropdown git={git!} repoPath={sg.repoPath} onClose={() => setGitDropdownOpen(false)} />
                  </Show>
                </div>
              </Show>
            </>
          );
        })()}

        {/* Spacer */}
        <div style={{ flex: 1 }} />

        {/* Auto-resize button — only in split layouts */}
        <Show when={layoutState.root?.type === "split"}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              let el: HTMLElement | null = e.currentTarget as HTMLElement;
              while (el && !el.hasAttribute("data-split-container")) {
                el = el.parentElement;
              }
              const containerWidth = el?.clientWidth ?? window.innerWidth;
              resizePaneToWidth(props.sessionId, settings.paneResizeWidth, containerWidth);
            }}
            style={{
              background: "none",
              border: "1px solid var(--border)",
              color: "var(--text-muted)",
              cursor: "pointer",
              "font-size": "10px",
              "font-family": "var(--font-mono)",
              padding: "0px 5px",
              "border-radius": "3px",
              "flex-shrink": 0,
              "line-height": "16px",
              transition: "color 0.15s, background 0.15s, border-color 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--accent)";
              (e.currentTarget as HTMLElement).style.background = "rgba(122,162,247,0.1)";
              (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.color = "var(--text-muted)";
              (e.currentTarget as HTMLElement).style.background = "none";
              (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
            }}
            title={`Auto-resize to ${settings.paneResizeWidth}px`}
          >
            {"\u21D4"}
          </button>
        </Show>

        {/* Close pane button — visible when shell exited */}
        <Show when={isExited()}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleClosePane();
            }}
            style={{
              background: "rgba(247, 118, 142, 0.15)",
              border: "1px solid rgba(247, 118, 142, 0.3)",
              color: "var(--red)",
              cursor: "pointer",
              "font-size": "10px",
              "font-family": "var(--font-ui)",
              padding: "1px 8px",
              "border-radius": "3px",
              "flex-shrink": 0,
              transition: "background 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(247, 118, 142, 0.3)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = "rgba(247, 118, 142, 0.15)";
            }}
            title="Close this pane"
          >
            Close Pane
          </button>
        </Show>
      </div>

      {/* A2UI components — rendered between header and terminal */}
      <A2UIRenderer sessionId={props.sessionId} />

      {/* Terminal */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        <TerminalPane
          sessionId={props.sessionId}
          focused={isFocused()}
          onFocus={() => setFocusedSession(props.sessionId)}
        />
      </div>
    </div>
  );
}

function RenderNode(props: { node: LayoutNode }) {
  return (
    <Switch>
      <Match when={props.node.type === "leaf"}>
        {/* Keyed Show forces remount when sessionId changes (e.g. group switch),
            preventing stale PTY exit listeners and other closure-captured state */}
        <Show when={(props.node as { type: "leaf"; sessionId: string }).sessionId} keyed>
          {(sid) => <LeafPaneWrapper sessionId={sid} />}
        </Show>
      </Match>
      <Match when={props.node.type === "split"}>
        <SplitPaneWrapper node={props.node as SplitNode} />
      </Match>
    </Switch>
  );
}

/** Isolated split pane — prevents stale reads during layout transitions */
function SplitPaneWrapper(props: { node: SplitNode }) {
  let containerRef!: HTMLDivElement;
  const isVertical = () => props.node.direction === "vertical";

  // Both panes use explicit calc'd sizes that together with the divider = 100%.
  // No flex-shrink:0, so they CAN shrink if the container is tight.
  const firstSize = () => `calc(${props.node.ratio * 100}% - ${DIVIDER_SIZE / 2}px)`;
  const secondSize = () => `calc(${(1 - props.node.ratio) * 100}% - ${DIVIDER_SIZE / 2}px)`;

  return (
    <div
      ref={containerRef}
      data-split-container
      style={{
        display: "flex",
        "flex-direction": isVertical() ? "row" : "column",
        width: "100%",
        height: "100%",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          [isVertical() ? "width" : "height"]: firstSize(),
          [isVertical() ? "height" : "width"]: "100%",
          overflow: "hidden",
          "flex-shrink": 1,
          "flex-grow": 0,
        }}
      >
        <RenderNode node={props.node.first} />
      </div>

      <PaneDivider
        direction={props.node.direction as "horizontal" | "vertical"}
        onResize={(delta) => {
          if (!containerRef) return;
          const size = isVertical() ? containerRef.clientWidth : containerRef.clientHeight;
          if (size === 0) return;
          const firstLeafId = props.node.first.type === "leaf"
            ? props.node.first.sessionId
            : collectLeafIds(props.node.first)[0];
          updateSplitRatio(firstLeafId, props.node.ratio + delta / size);
        }}
      />

      <div
        style={{
          [isVertical() ? "width" : "height"]: secondSize(),
          [isVertical() ? "height" : "width"]: "100%",
          overflow: "hidden",
          "flex-shrink": 1,
          "flex-grow": 0,
        }}
      >
        <RenderNode node={props.node.second} />
      </div>
    </div>
  );
}

export default function TerminalArea() {
  const rootNode = createMemo(() => layoutState.root);

  // Calculate if we need horizontal scroll
  const leafCount = createMemo(() => countLeaves(layoutState.root));
  const needsScroll = createMemo(() => leafCount() > 2);

  // Compute the minimum content width needed so no pane is squished below MIN_PANE_WIDTH.
  // Walk the tree: each leaf needs MIN_PANE_WIDTH, each split adds a divider.
  // A split distributes space by ratio, so the total must be large enough that
  // the smallest slice (by ratio) still gets MIN_PANE_WIDTH.
  const contentWidth = createMemo(() => {
    if (!layoutState.root || !needsScroll()) return "100%";
    return `${computeMinWidth(layoutState.root)}px`;
  });

  function computeMinWidth(node: LayoutNode): number {
    if (node.type === "leaf") return MIN_PANE_WIDTH;
    if (node.direction === "horizontal") {
      // Horizontal split stacks vertically — width is max of children
      return Math.max(computeMinWidth(node.first), computeMinWidth(node.second));
    }
    // Vertical split — side by side
    const firstMin = computeMinWidth(node.first);
    const secondMin = computeMinWidth(node.second);
    // Total width must satisfy: total * ratio >= firstMin AND total * (1-ratio) >= secondMin
    const fromFirst = firstMin / node.ratio;
    const fromSecond = secondMin / (1 - node.ratio);
    return Math.ceil(Math.max(fromFirst, fromSecond)) + DIVIDER_SIZE;
  }

  let scrollContainerRef!: HTMLDivElement;

  // Pane names for scroll indicator (truncated to 7 chars)
  const paneNames = createMemo(() => {
    if (!layoutState.root) return [];
    return collectLeafIds(layoutState.root).map((sid) => ({
      sid,
      name: getSessionName(sid).slice(0, 7),
      focused: layoutState.focusedSessionId === sid,
    }));
  });

  const scrollToPane = (sessionId: string) => {
    setFocusedSession(sessionId);
    // Find the pane's DOM element and scroll it into view
    if (scrollContainerRef) {
      const paneEl = scrollContainerRef.querySelector(`[data-session-id="${sessionId}"]`);
      if (paneEl) paneEl.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
    }
  };

  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        "flex-direction": "column",
        overflow: "hidden",
        background: "var(--bg-primary)",
        position: "relative",
      }}
    >
      {/* Scroll indicator bar for >2 splits — shows pane names */}
      <Show when={needsScroll()}>
        <div
          style={{
            display: "flex",
            "align-items": "center",
            gap: "4px",
            padding: "3px 10px",
            background: "var(--bg-secondary)",
            "border-bottom": "1px solid var(--border)",
            "flex-shrink": 0,
            "overflow-x": "auto",
          }}
        >
          <span style={{
            "font-size": "10px",
            color: "var(--text-muted)",
            "font-family": "var(--font-ui)",
            "flex-shrink": 0,
          }}>
            {leafCount()} panes
          </span>
          <span style={{ color: "var(--border)", "font-size": "10px", "flex-shrink": 0 }}>|</span>
          <For each={paneNames()}>
            {(pane, i) => (
              <>
                <Show when={i() > 0}>
                  <span style={{ color: "var(--border)", "font-size": "9px", "flex-shrink": 0 }}>{"\u00B7"}</span>
                </Show>
                <span
                  onClick={() => scrollToPane(pane.sid)}
                  style={{
                    "font-size": "10px",
                    "font-family": "var(--font-mono)",
                    color: pane.focused ? "var(--accent)" : "var(--text-muted)",
                    "font-weight": pane.focused ? 600 : "normal",
                    "white-space": "nowrap",
                    "flex-shrink": 0,
                    cursor: "pointer",
                    padding: "1px 4px",
                    "border-radius": "3px",
                    background: pane.focused ? "rgba(122,162,247,0.1)" : "transparent",
                    transition: "background 0.15s, color 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    if (!pane.focused) (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
                  }}
                  onMouseLeave={(e) => {
                    if (!pane.focused) (e.currentTarget as HTMLElement).style.background = "transparent";
                  }}
                >
                  {pane.name}
                </span>
              </>
            )}
          </For>
          <span style={{ "font-size": "10px", color: "var(--text-muted)", "flex-shrink": 0, "margin-left": "4px" }}>
            {"\u2190\u2192"}
          </span>
        </div>
      </Show>

      <div
        ref={scrollContainerRef}
        style={{
          flex: 1,
          overflow: needsScroll() ? "auto" : "hidden",
          "overflow-y": "hidden",
        }}
      >
        <Show
          when={rootNode()}
          fallback={
            <div
              style={{
                display: "flex",
                "align-items": "center",
                "justify-content": "center",
                height: "100%",
                color: "var(--text-muted)",
              }}
            >
              No active session
            </div>
          }
        >
          {(root) => (
            <div
              style={{
                width: contentWidth(),
                "min-width": needsScroll() ? contentWidth() : "100%",
                height: "100%",
              }}
            >
              <RenderNode node={root()} />
            </div>
          )}
        </Show>
      </div>
    </div>
  );
}
