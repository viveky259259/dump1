interface PaneDividerProps {
  direction: "horizontal" | "vertical";
  onResize: (delta: number) => void;
}

export default function PaneDivider(props: PaneDividerProps) {
  let startPos = 0;

  const onMouseDown = (e: MouseEvent) => {
    e.preventDefault();
    startPos = props.direction === "vertical" ? e.clientX : e.clientY;

    const onMouseMove = (e: MouseEvent) => {
      const current =
        props.direction === "vertical" ? e.clientX : e.clientY;
      const delta = current - startPos;
      startPos = current;
      props.onResize(delta);
    };

    const onMouseUp = () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };

    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    document.body.style.cursor =
      props.direction === "vertical" ? "col-resize" : "row-resize";
    document.body.style.userSelect = "none";
  };

  const isVertical = () => props.direction === "vertical";

  return (
    <div
      onMouseDown={onMouseDown}
      style={{
        [isVertical() ? "width" : "height"]: "6px",
        [isVertical() ? "height" : "width"]: "100%",
        background: "var(--border)",
        cursor: isVertical() ? "col-resize" : "row-resize",
        "flex-shrink": "0",
        transition: "background 0.15s",
        display: "flex",
        "align-items": "center",
        "justify-content": "center",
        position: "relative",
      }}
      onMouseEnter={(e) =>
        ((e.currentTarget as HTMLElement).style.background = "var(--accent)")
      }
      onMouseLeave={(e) =>
        ((e.currentTarget as HTMLElement).style.background = "var(--border)")
      }
    >
      {/* Visible grip dots */}
      <div
        style={{
          [isVertical() ? "width" : "height"]: "2px",
          [isVertical() ? "height" : "width"]: "30px",
          "border-radius": "1px",
          background: "var(--text-muted)",
          opacity: "0.5",
          "pointer-events": "none",
        }}
      />
    </div>
  );
}
