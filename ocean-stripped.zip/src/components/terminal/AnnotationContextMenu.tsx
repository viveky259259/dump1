import { createSignal, onMount, onCleanup, For } from "solid-js";
import type { Annotation } from "../../stores/annotationStore";
import { executeAction } from "../../stores/annotationStore";

interface AnnotationContextMenuProps {
  annotation: Annotation;
  x: number;
  y: number;
  onClose: () => void;
}

export default function AnnotationContextMenu(props: AnnotationContextMenuProps) {
  let menuRef!: HTMLDivElement;
  const [highlightedIndex, setHighlightedIndex] = createSignal(0);

  const actions = () => props.annotation.actions;

  const handleKeyDown = (e: KeyboardEvent) => {
    switch (e.key) {
      case "Escape":
        e.preventDefault();
        props.onClose();
        break;
      case "ArrowDown":
        e.preventDefault();
        setHighlightedIndex((i) => (i + 1) % actions().length);
        break;
      case "ArrowUp":
        e.preventDefault();
        setHighlightedIndex((i) => (i - 1 + actions().length) % actions().length);
        break;
      case "Enter":
        e.preventDefault();
        handleItemClick(actions()[highlightedIndex()].command);
        break;
    }
  };

  const handleOutsideClick = (e: MouseEvent) => {
    if (menuRef && !menuRef.contains(e.target as Node)) {
      props.onClose();
    }
  };

  onMount(() => {
    document.addEventListener("keydown", handleKeyDown);
    // Delay attaching click listener to avoid immediately closing from the
    // right-click event that opened the menu
    requestAnimationFrame(() => {
      document.addEventListener("mousedown", handleOutsideClick);
    });
  });

  onCleanup(() => {
    document.removeEventListener("keydown", handleKeyDown);
    document.removeEventListener("mousedown", handleOutsideClick);
  });

  const handleItemClick = async (command: string) => {
    try {
      await executeAction(command);
    } catch (err) {
      console.error("Failed to execute annotation action:", err);
    }
    props.onClose();
  };

  // Adjust position so the menu doesn't overflow the window
  const menuX = () => Math.min(props.x, window.innerWidth - 260);
  const menuY = () => {
    // Estimate menu height: roughly 32px per item + 12px padding
    const estimatedHeight = actions().length * 32 + 12;
    if (props.y + estimatedHeight > window.innerHeight - 10) {
      return props.y - estimatedHeight;
    }
    return props.y;
  };

  return (
    <div
      ref={menuRef}
      style={{
        position: "fixed",
        left: `${menuX()}px`,
        top: `${menuY()}px`,
        "min-width": "180px",
        "max-width": "250px",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "6px",
        "box-shadow": "0 4px 16px rgba(0, 0, 0, 0.5)",
        padding: "4px 0",
        "z-index": "10002",
        "font-family": "var(--font-ui)",
        "font-size": "13px",
        overflow: "hidden",
      }}
    >
      <For each={actions()}>
        {(action, index) => {
          // Insert a separator before clipboard-like actions (actions after index 0
          // whose label contains "Copy" or "Clipboard")
          const showSeparator = () => {
            if (index() === 0) return false;
            const label = action.label.toLowerCase();
            const prevLabel = actions()[index() - 1].label.toLowerCase();
            const isCopyAction = label.includes("copy") || label.includes("clipboard");
            const prevIsCopyAction = prevLabel.includes("copy") || prevLabel.includes("clipboard");
            return isCopyAction && !prevIsCopyAction;
          };

          return (
            <>
              {showSeparator() && (
                <div
                  style={{
                    height: "1px",
                    background: "var(--border)",
                    margin: "4px 0",
                  }}
                />
              )}
              <div
                style={{
                  display: "flex",
                  "align-items": "center",
                  "justify-content": "space-between",
                  padding: "6px 12px",
                  cursor: "pointer",
                  color:
                    highlightedIndex() === index()
                      ? "var(--text-primary)"
                      : "var(--text-secondary)",
                  background:
                    highlightedIndex() === index()
                      ? "var(--bg-hover)"
                      : "transparent",
                  transition: "background 0.1s, color 0.1s",
                }}
                onMouseEnter={() => setHighlightedIndex(index())}
                onClick={() => handleItemClick(action.command)}
              >
                <span style={{ "white-space": "nowrap", overflow: "hidden", "text-overflow": "ellipsis" }}>
                  {action.label}
                </span>
                {action.shortcut && (
                  <span
                    style={{
                      "margin-left": "16px",
                      "font-size": "11px",
                      color: "var(--text-muted)",
                      "font-family": "var(--font-mono)",
                      "flex-shrink": "0",
                    }}
                  >
                    {action.shortcut}
                  </span>
                )}
              </div>
            </>
          );
        }}
      </For>
      {actions().length === 0 && (
        <div
          style={{
            padding: "8px 12px",
            color: "var(--text-muted)",
            "font-style": "italic",
          }}
        >
          No actions available
        </div>
      )}
    </div>
  );
}
