import { onMount, onCleanup } from "solid-js";
import type { Annotation } from "../../stores/annotationStore";

interface AnnotationTooltipProps {
  annotation: Annotation;
  x: number;
  y: number;
  onClose: () => void;
}

function getTypeLabel(type: Annotation["annotation_type"]): string {
  switch (type) {
    case "FilePath": return "File";
    case "Url": return "URL";
    case "Error": return "Error";
    case "GitRef": return "Git Ref";
    case "NetworkAddr": return "Network";
    case "TestResult": return "Test";
  }
}

function getTypeColor(type: Annotation["annotation_type"]): string {
  switch (type) {
    case "FilePath": return "var(--blue)";
    case "Url": return "var(--accent)";
    case "Error": return "var(--red)";
    case "GitRef": return "var(--green)";
    case "NetworkAddr": return "var(--yellow)";
    case "TestResult": return "var(--accent)";
  }
}

export default function AnnotationTooltip(props: AnnotationTooltipProps) {
  let tooltipRef!: HTMLDivElement;
  let dismissTimer: ReturnType<typeof setTimeout> | null = null;

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Escape") {
      props.onClose();
    }
  };

  onMount(() => {
    document.addEventListener("keydown", handleKeyDown);

    // Auto-dismiss after 5 seconds
    dismissTimer = setTimeout(() => {
      props.onClose();
    }, 5000);
  });

  onCleanup(() => {
    document.removeEventListener("keydown", handleKeyDown);
    if (dismissTimer !== null) {
      clearTimeout(dismissTimer);
    }
  });

  // Calculate position: prefer above, fall back to below
  const tooltipY = () => {
    if (props.y - 40 < 10) {
      return props.y + 20;
    }
    return props.y - 40;
  };

  // Clamp X so tooltip doesn't overflow the right edge
  const tooltipX = () => {
    return Math.min(props.x, window.innerWidth - 360);
  };

  // Build display text based on annotation type
  const displayContent = () => {
    const a = props.annotation;
    let detail = a.value;

    if (a.annotation_type === "FilePath" && a.metadata) {
      const line = a.metadata.line as number | undefined;
      const col = a.metadata.col as number | undefined;
      if (line !== undefined) {
        detail += `:${line}`;
        if (col !== undefined) {
          detail += `:${col}`;
        }
      }
    }

    return detail;
  };

  return (
    <div
      ref={tooltipRef}
      onMouseLeave={() => props.onClose()}
      style={{
        position: "fixed",
        left: `${tooltipX()}px`,
        top: `${tooltipY()}px`,
        "max-width": "350px",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "6px",
        "box-shadow": "0 4px 12px rgba(0, 0, 0, 0.4)",
        padding: "6px 10px",
        "z-index": "10001",
        "font-family": "var(--font-mono)",
        "font-size": "12px",
        "line-height": "1.4",
        "pointer-events": "auto",
      }}
    >
      <div
        style={{
          display: "flex",
          "align-items": "center",
          gap: "6px",
          "margin-bottom": "2px",
        }}
      >
        <span
          style={{
            "font-size": "10px",
            "font-family": "var(--font-ui)",
            color: getTypeColor(props.annotation.annotation_type),
            "text-transform": "uppercase",
            "font-weight": "600",
            "letter-spacing": "0.5px",
          }}
        >
          {getTypeLabel(props.annotation.annotation_type)}
        </span>
      </div>
      <div
        style={{
          color: "var(--text-primary)",
          "word-break": "break-all",
          overflow: "hidden",
          display: "-webkit-box",
          "-webkit-line-clamp": "4",
          "-webkit-box-orient": "vertical",
        }}
      >
        {displayContent()}
      </div>
    </div>
  );
}
