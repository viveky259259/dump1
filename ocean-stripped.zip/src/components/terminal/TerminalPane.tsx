import { onMount, onCleanup, createEffect } from "solid-js";
import { Terminal } from "@xterm/xterm";
import { WebglAddon } from "@xterm/addon-webgl";
import { FitAddon } from "@xterm/addon-fit";
import { SearchAddon } from "@xterm/addon-search";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import "@xterm/xterm/css/xterm.css";
import { initAnnotationListener } from "../../stores/annotationStore";
import { initA2UIListener } from "../../stores/a2uiStore";
import { captureScrollback } from "../../stores/scrollbackStore";
import { logInfo, logDebug, logWarn } from "../../stores/logStore";
import { sessionState } from "../../stores/sessionStore";
import AnnotationOverlay from "./AnnotationOverlay";

interface TerminalPaneProps {
  sessionId: string;
  focused: boolean;
  onFocus?: () => void;
}

// Global terminal instance cache — exported for AnnotationOverlay access
export const terminalCache = new Map<
  string,
  { terminal: Terminal; fitAddon: FitAddon; wrapper: HTMLDivElement }
>();

// Persistent event listeners that survive component unmount/remount
// (keyed by sessionId so we don't double-subscribe)
const activeListeners = new Map<string, UnlistenFn[]>();

export default function TerminalPane(props: TerminalPaneProps) {
  let containerRef!: HTMLDivElement;
  let resizeObserver: ResizeObserver | null = null;
  let previousSessionId: string | null = null;
  let disposed = false;

  onMount(() => {
    logInfo("frontend", `TerminalPane.onMount(${props.sessionId.slice(0, 8)}...)`);

    // The createEffect below handles terminal creation and wrapper mounting.
    // onMount just sets up the resize observer.
    resizeObserver = new ResizeObserver(() => {
      const cached = terminalCache.get(props.sessionId);
      if (cached) {
        requestAnimationFrame(() => {
          try {
            cached.fitAddon.fit();
            invoke("resize_pty", {
              sessionId: props.sessionId,
              cols: cached.terminal.cols,
              rows: cached.terminal.rows,
            }).catch(() => {});
          } catch {}
        });
      }
    });
    resizeObserver.observe(containerRef);
  });

  // Watch for sessionId changes (happens when switchToSession replaces the leaf)
  // SolidJS reuses the component, so onMount won't re-run — we need this effect
  createEffect(() => {
    if (disposed) return;
    const sid = props.sessionId; // track this reactively
    if (!sid) return;
    logInfo("frontend", `TerminalPane.effect: sessionId changed to ${sid.slice(0, 8)}`);

    // Ensure terminal exists for this session
    let cached = terminalCache.get(sid);
    if (!cached) {
      // New session that hasn't been seen before — create terminal
      logInfo("frontend", `Creating terminal on-the-fly for ${sid.slice(0, 8)}`);

      const wrapper = document.createElement("div");
      wrapper.style.width = "100%";
      wrapper.style.height = "100%";

      const terminal = new Terminal({
        fontFamily: "'JetBrains Mono', 'Fira Code', Menlo, monospace",
        fontSize: 14,
        lineHeight: 1.2,
        theme: {
          background: "#1a1b26",
          foreground: "#c0caf5",
          cursor: "#c0caf5",
          cursorAccent: "#1a1b26",
          selectionBackground: "#33467c",
          selectionForeground: "#c0caf5",
          black: "#15161e",
          red: "#f7768e",
          green: "#9ece6a",
          yellow: "#e0af68",
          blue: "#7aa2f7",
          magenta: "#bb9af7",
          cyan: "#7dcfff",
          white: "#a9b1d6",
          brightBlack: "#414868",
          brightRed: "#f7768e",
          brightGreen: "#9ece6a",
          brightYellow: "#e0af68",
          brightBlue: "#7aa2f7",
          brightMagenta: "#bb9af7",
          brightCyan: "#7dcfff",
          brightWhite: "#c0caf5",
        },
        cursorBlink: true,
        cursorStyle: "block",
        scrollback: 10000,
        allowProposedApi: true,
      });

      const fitAddon = new FitAddon();
      terminal.loadAddon(fitAddon);
      terminal.loadAddon(new SearchAddon());
      terminal.open(wrapper);

      try {
        const webglAddon = new WebglAddon();
        webglAddon.onContextLoss(() => webglAddon.dispose());
        terminal.loadAddon(webglAddon);
      } catch {}

      cached = { terminal, fitAddon, wrapper };
      terminalCache.set(sid, cached);

      terminal.onData((data) => {
        invoke("write_pty", { sessionId: sid, data }).catch(console.error);
      });

      if (!activeListeners.has(sid)) {
        const unlisteners: Promise<UnlistenFn>[] = [];
        unlisteners.push(
          listen<string>(`pty-output-${sid}`, (event) => {
            const entry = terminalCache.get(sid);
            if (!entry) return;
            const bytes = Uint8Array.from(atob(event.payload), (c) => c.charCodeAt(0));
            entry.terminal.write(bytes);
          })
        );
        unlisteners.push(
          listen<number>(`pty-exit-${sid}`, (event) => {
            const entry = terminalCache.get(sid);
            if (!entry) return;
            entry.terminal.writeln(`\r\n\x1b[90m[Process exited with code ${event.payload}]\x1b[0m`);
          })
        );
        // Store resolved unlisten functions
        Promise.all(unlisteners).then((fns) => {
          activeListeners.set(sid, fns);
        });
        initAnnotationListener(sid);
        initA2UIListener(sid);
      }
    }

    // Capture scrollback from the previous session before swapping
    if (previousSessionId && previousSessionId !== sid) {
      logDebug("frontend", `Capturing scrollback for ${previousSessionId.slice(0, 8)} before swap`);
      captureScrollback(previousSessionId);
    }
    previousSessionId = sid;

    // Clear container and move this session's wrapper in
    if (containerRef) {
      while (containerRef.firstChild) {
        containerRef.removeChild(containerRef.firstChild);
      }
      containerRef.appendChild(cached.wrapper);

      // Fit after DOM update
      requestAnimationFrame(() => {
        try {
          cached!.fitAddon.fit();
          invoke("resize_pty", {
            sessionId: sid,
            cols: cached!.terminal.cols,
            rows: cached!.terminal.rows,
          }).catch(() => {});
        } catch {}
        cached!.terminal.focus();
      });
    }
  });

  createEffect(() => {
    if (disposed) return;
    if (props.focused) {
      const cached = terminalCache.get(props.sessionId);
      if (cached) {
        cached.terminal.focus();
      }
    }
  });

  onCleanup(() => {
    disposed = true;
    logDebug("frontend", `TerminalPane.onCleanup(${props.sessionId.slice(0, 8)}...)`);
    resizeObserver?.disconnect();

    // Capture scrollback before detaching
    captureScrollback(props.sessionId);

    const cached = terminalCache.get(props.sessionId);
    if (cached && cached.wrapper.parentElement) {
      cached.wrapper.parentElement.removeChild(cached.wrapper);
      logDebug("frontend", `Detached wrapper for ${props.sessionId.slice(0, 8)}`);
    }
  });

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        overflow: "hidden",
      }}
      onClick={() => props.onFocus?.()}
    >
      <div
        ref={containerRef}
        style={{
          width: "100%",
          height: "100%",
        }}
      />
      <AnnotationOverlay sessionId={props.sessionId} />
    </div>
  );
}

export function disposeTerminal(sessionId: string) {
  const cached = terminalCache.get(sessionId);
  if (cached) {
    cached.terminal.dispose();
    terminalCache.delete(sessionId);
  }
  // Clean up event listeners
  const unlisteners = activeListeners.get(sessionId);
  if (unlisteners) {
    for (const unlisten of unlisteners) {
      unlisten();
    }
    activeListeners.delete(sessionId);
  }
}
