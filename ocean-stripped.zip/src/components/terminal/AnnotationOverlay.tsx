import { createSignal, createEffect, onCleanup, Show, For } from "solid-js";
import type { Terminal } from "@xterm/xterm";
import { getAllAnnotations, executeAction } from "../../stores/annotationStore";
import type { Annotation } from "../../stores/annotationStore";
import { terminalCache } from "./TerminalPane";
import AnnotationContextMenu from "./AnnotationContextMenu";
import AnnotationTooltip from "./AnnotationTooltip";

interface AnnotationOverlayProps {
  sessionId: string;
}

function getAnnotationClass(type: Annotation["annotation_type"]): string {
  switch (type) {
    case "FilePath": return "annotation-mark annotation-file-path";
    case "Url": return "annotation-mark annotation-url";
    case "Error": return "annotation-mark annotation-error";
    case "GitRef": return "annotation-mark annotation-git-ref";
    case "NetworkAddr": return "annotation-mark annotation-network";
    case "TestResult": return "annotation-mark annotation-url";
  }
}

interface CellDimensions {
  width: number;
  height: number;
}

function getCellDimensions(terminal: Terminal): CellDimensions | null {
  // Try xterm.js internal API for accurate cell dimensions
  try {
    const core = (terminal as any)?._core;
    const css = core?._renderService?.dimensions?.css?.cell;
    if (css && css.width > 0 && css.height > 0) {
      return { width: css.width, height: css.height };
    }
  } catch {
    // Fall through to fallback
  }

  // Fallback: measure a character in the DOM
  try {
    const xtermScreen = (terminal as any)?.element?.querySelector(".xterm-screen");
    if (xtermScreen) {
      const measurer = document.createElement("span");
      measurer.style.cssText =
        "position:absolute;visibility:hidden;white-space:pre;font-family:'JetBrains Mono','Fira Code',Menlo,monospace;font-size:14px;line-height:1.2;";
      measurer.textContent = "W";
      xtermScreen.appendChild(measurer);
      const rect = measurer.getBoundingClientRect();
      xtermScreen.removeChild(measurer);
      if (rect.width > 0 && rect.height > 0) {
        return { width: rect.width, height: rect.height };
      }
    }
  } catch {
    // Fall through
  }

  return null;
}

export default function AnnotationOverlay(props: AnnotationOverlayProps) {
  const [viewportY, setViewportY] = createSignal(0);
  const [cellDims, setCellDims] = createSignal<CellDimensions | null>(null);
  const [contextMenu, setContextMenu] = createSignal<{
    annotation: Annotation;
    x: number;
    y: number;
  } | null>(null);
  const [tooltip, setTooltip] = createSignal<{
    annotation: Annotation;
    x: number;
    y: number;
  } | null>(null);

  let scrollDisposable: { dispose(): void } | null = null;
  let debounceTimer: ReturnType<typeof setTimeout> | null = null;
  let hoverTimer: ReturnType<typeof setTimeout> | null = null;

  // Get the terminal from the shared cache and set up scroll listener
  // Retry with interval since terminal may not be ready immediately
  let retryTimer: ReturnType<typeof setInterval> | null = null;

  createEffect(() => {
    const cached = terminalCache.get(props.sessionId);
    if (!cached) {
      // Terminal not ready yet — retry every 500ms
      if (!retryTimer) {
        retryTimer = setInterval(() => {
          const c = terminalCache.get(props.sessionId);
          if (c) {
            clearInterval(retryTimer!);
            retryTimer = null;
            setupTerminalListeners(c.terminal);
          }
        }, 500);
      }
      return;
    }

    setupTerminalListeners(cached.terminal);
  });

  function setupTerminalListeners(terminal: Terminal) {
    // Read cell dimensions — retry if not available yet
    const tryDims = () => {
      const dims = getCellDimensions(terminal);
      if (dims) {
        setCellDims(dims);
        return true;
      }
      return false;
    };

    if (!tryDims()) {
      // Dimensions not ready — retry after render
      const dimRetry = setInterval(() => {
        if (tryDims()) clearInterval(dimRetry);
      }, 200);
      // Stop trying after 5s
      setTimeout(() => clearInterval(dimRetry), 5000);
    }

    // Read initial viewport offset
    setViewportY(terminal.buffer.active.viewportY);

    // Listen for scroll events with debounce
    scrollDisposable = terminal.onScroll(() => {
      if (debounceTimer !== null) {
        clearTimeout(debounceTimer);
      }
      debounceTimer = setTimeout(() => {
        setViewportY(terminal.buffer.active.viewportY);

        // Re-check cell dimensions on scroll (they may have changed after resize)
        const d = getCellDimensions(terminal);
        if (d) setCellDims(d);
      }, 50);
    });
  }

  onCleanup(() => {
    scrollDisposable?.dispose();
    if (retryTimer !== null) clearInterval(retryTimer);
    if (debounceTimer !== null) clearTimeout(debounceTimer);
    if (hoverTimer !== null) clearTimeout(hoverTimer);
  });

  // Positioned annotations: find where each annotation's text actually appears
  // in the xterm.js buffer, rather than trusting backend line numbers
  const positionedAnnotations = () => {
    const cached = terminalCache.get(props.sessionId);
    if (!cached) return [];

    const terminal = cached.terminal;
    const buffer = terminal.buffer.active;
    const vY = buffer.viewportY;
    const rows = terminal.rows;

    // Get all annotations for this session (not filtered by line)
    const allAnnotations = getAllAnnotations(props.sessionId);
    if (allAnnotations.length === 0) return [];

    // Search visible buffer lines for annotation values
    const results: { annotation: Annotation; bufferLine: number; colStart: number; colEnd: number }[] = [];

    for (let row = 0; row < rows; row++) {
      const bufferLineIndex = vY + row;
      const line = buffer.getLine(bufferLineIndex);
      if (!line) continue;

      const lineText = line.translateToString(true); // trim trailing whitespace

      for (const ann of allAnnotations) {
        const idx = lineText.indexOf(ann.value);
        if (idx !== -1) {
          results.push({
            annotation: ann,
            bufferLine: row, // row relative to viewport (0-based)
            colStart: idx,
            colEnd: idx + ann.value.length,
          });
        }
      }
    }

    return results;
  };

  const handleClick = (annotation: Annotation, e?: MouseEvent) => {
    if (annotation.actions.length === 0) return;

    // Cmd+Click → execute second action (Open in Editor) if available
    if (e?.metaKey && annotation.actions.length > 1) {
      executeAction(annotation.actions[1].command).catch(console.error);
    } else {
      // Regular click → first action (View in Ocean for files)
      executeAction(annotation.actions[0].command).catch(console.error);
    }
  };

  const handleContextMenu = (e: MouseEvent, annotation: Annotation) => {
    e.preventDefault();
    e.stopPropagation();
    setTooltip(null); // dismiss tooltip if shown
    setContextMenu({ annotation, x: e.clientX, y: e.clientY });
  };

  const handleMouseEnter = (e: MouseEvent, annotation: Annotation) => {
    if (contextMenu()) return; // don't show tooltip while context menu is open
    if (hoverTimer !== null) clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => {
      setTooltip({ annotation, x: e.clientX, y: e.clientY });
    }, 300);
  };

  const handleMouseLeave = () => {
    if (hoverTimer !== null) {
      clearTimeout(hoverTimer);
      hoverTimer = null;
    }
    // Tooltip's own onClose handles dismissal on mouse leave from the tooltip itself
  };

  return (
    <>
      <div
        style={{
          position: "absolute",
          top: "0",
          left: "0",
          width: "100%",
          height: "100%",
          "pointer-events": "none",
          "z-index": "10",
          overflow: "hidden",
        }}
      >
        <Show when={cellDims()}>
          {(dims) => (
            <For each={positionedAnnotations()}>
              {(item) => {
                const d = dims();
                const top = item.bufferLine * d.height;
                const left = item.colStart * d.width;
                const width = Math.max(
                  (item.colEnd - item.colStart) * d.width,
                  d.width * 4
                );

                return (
                  <div
                    class={getAnnotationClass(item.annotation.annotation_type)}
                    style={{
                      top: `${top}px`,
                      left: `${left}px`,
                      width: `${width}px`,
                      height: `${d.height}px`,
                    }}
                    onClick={(e) => handleClick(item.annotation, e)}
                    onContextMenu={(e) => handleContextMenu(e, item.annotation)}
                    onMouseEnter={(e) => handleMouseEnter(e, item.annotation)}
                    onMouseLeave={handleMouseLeave}
                  />
                );
              }}
            </For>
          )}
        </Show>
      </div>

      {/* Context menu portal - rendered outside the overlay so pointer-events work */}
      <Show when={contextMenu()}>
        {(menu) => (
          <AnnotationContextMenu
            annotation={menu().annotation}
            x={menu().x}
            y={menu().y}
            onClose={() => setContextMenu(null)}
          />
        )}
      </Show>

      {/* Tooltip portal */}
      <Show when={tooltip()}>
        {(tip) => (
          <AnnotationTooltip
            annotation={tip().annotation}
            x={tip().x}
            y={tip().y}
            onClose={() => setTooltip(null)}
          />
        )}
      </Show>
    </>
  );
}
