import { Show, onMount, onCleanup, createSignal } from "solid-js";
import type { GitStatus } from "../../stores/gitStore";

interface GitInfoDropdownProps {
  git: GitStatus;
  repoPath: string | null;
  onClose: () => void;
}

export default function GitInfoDropdown(props: GitInfoDropdownProps) {
  let ref!: HTMLDivElement;
  const [pos, setPos] = createSignal({ top: 0, left: 0 });

  onMount(() => {
    // Position the dropdown below the git section in the pane header
    // Find the parent clickable div and position relative to it
    if (ref?.parentElement) {
      const rect = ref.parentElement.getBoundingClientRect();
      const dropdownWidth = 280;
      let left = rect.left;
      // Don't overflow right edge
      if (left + dropdownWidth > window.innerWidth) {
        left = window.innerWidth - dropdownWidth - 8;
      }
      // Don't go behind sidebar (left edge)
      if (left < 260) left = 260;
      setPos({ top: rect.bottom + 2, left });
    }

    const handleClick = (e: MouseEvent) => {
      if (ref && !ref.contains(e.target as Node)) props.onClose();
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") props.onClose();
    };
    setTimeout(() => {
      document.addEventListener("click", handleClick);
      document.addEventListener("keydown", handleKey);
    }, 0);
    onCleanup(() => {
      document.removeEventListener("click", handleClick);
      document.removeEventListener("keydown", handleKey);
    });
  });

  const g = () => props.git;

  const row = (label: string, value: string | number, color?: string) => (
    <div style={{ display: "flex", "justify-content": "space-between", padding: "4px 0" }}>
      <span style={{ color: "var(--text-muted)", "font-size": "11px" }}>{label}</span>
      <span style={{
        "font-family": "var(--font-mono)",
        "font-size": "11px",
        color: color ?? "var(--text-primary)",
      }}>{value}</span>
    </div>
  );

  return (
    <div
      ref={ref}
      style={{
        position: "fixed",
        top: `${pos().top}px`,
        left: `${pos().left}px`,
        width: "280px",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "0 0 8px 8px",
        "box-shadow": "0 4px 16px rgba(0,0,0,0.3)",
        padding: "12px",
        "z-index": "999",
        "font-family": "var(--font-ui)",
      }}
    >
      {/* Header */}
      <div style={{
        "font-size": "11px",
        "font-weight": 600,
        color: "var(--text-secondary)",
        "text-transform": "uppercase",
        "letter-spacing": "0.5px",
        "margin-bottom": "8px",
        "padding-bottom": "6px",
        "border-bottom": "1px solid var(--border)",
      }}>
        Git Status
      </div>

      {/* Branch */}
      {row("Branch", g().branch, g().conflicted > 0 ? "var(--red)" : g().modified > 0 ? "var(--yellow)" : "var(--green)")}

      {/* Upstream */}
      <Show when={g().ahead > 0 || g().behind > 0}>
        <div style={{ display: "flex", "justify-content": "space-between", padding: "4px 0" }}>
          <span style={{ color: "var(--text-muted)", "font-size": "11px" }}>Upstream</span>
          <span style={{ "font-family": "var(--font-mono)", "font-size": "11px" }}>
            <Show when={g().ahead > 0}>
              <span style={{ color: "var(--green)" }}>{"\u2191"}{g().ahead} ahead</span>
            </Show>
            <Show when={g().ahead > 0 && g().behind > 0}>{" "}</Show>
            <Show when={g().behind > 0}>
              <span style={{ color: "var(--red)" }}>{"\u2193"}{g().behind} behind</span>
            </Show>
          </span>
        </div>
      </Show>

      {/* Separator */}
      <div style={{ height: "1px", background: "var(--border)", margin: "6px 0" }} />

      {/* File counts */}
      <Show when={g().staged > 0}>
        {row("Staged", `${g().staged} files`, "var(--green)")}
      </Show>
      <Show when={g().modified > 0}>
        {row("Modified", `${g().modified} files`, "var(--yellow)")}
      </Show>
      <Show when={g().untracked > 0}>
        {row("Untracked", `${g().untracked} files`, "var(--text-muted)")}
      </Show>
      <Show when={g().conflicted > 0}>
        {row("Conflicts", `${g().conflicted} files`, "var(--red)")}
      </Show>
      <Show when={g().staged === 0 && g().modified === 0 && g().untracked === 0 && g().conflicted === 0}>
        <div style={{ padding: "4px 0", "font-size": "11px", color: "var(--green)" }}>
          Working tree clean
        </div>
      </Show>

      {/* CI */}
      <Show when={g().ci_status}>
        <div style={{ height: "1px", background: "var(--border)", margin: "6px 0" }} />
        {row("CI", g().ci_status === "success" ? "Passing" : g().ci_status === "failure" ? "Failing" : g().ci_status === "pending" ? "Pending" : "Unknown",
          g().ci_status === "success" ? "var(--green)" : g().ci_status === "failure" ? "var(--red)" : "var(--yellow)")}
      </Show>

      {/* PR */}
      <Show when={g().pr_number}>
        {row("Pull Request", `#${g().pr_number}`, "var(--accent)")}
      </Show>

      {/* Repo path */}
      <Show when={props.repoPath}>
        <div style={{ height: "1px", background: "var(--border)", margin: "6px 0" }} />
        <div style={{
          "font-size": "10px",
          color: "var(--text-muted)",
          "font-family": "var(--font-mono)",
          "word-break": "break-all",
        }}>
          {props.repoPath}
        </div>
      </Show>
    </div>
  );
}
