import { createSignal, onMount, onCleanup, Show } from "solid-js";
import { invoke } from "@tauri-apps/api/core";

interface FileViewerProps {
  filePath: string;
  line?: number;
  onClose: () => void;
}

export default function FileViewer(props: FileViewerProps) {
  const [content, setContent] = createSignal<string | null>(null);
  const [error, setError] = createSignal<string | null>(null);
  const [loading, setLoading] = createSignal(true);
  let scrollRef!: HTMLDivElement;

  onMount(async () => {
    try {
      const text = await invoke<string>("read_file", { path: props.filePath });
      setContent(text);
    } catch (e) {
      setError(String(e));
    }
    setLoading(false);

    // Scroll to line if specified
    if (props.line && scrollRef) {
      requestAnimationFrame(() => {
        const lineEl = scrollRef.querySelector(`[data-line="${props.line}"]`);
        if (lineEl) {
          lineEl.scrollIntoView({ block: "center" });
        }
      });
    }

    // Escape to close
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") props.onClose();
    };
    document.addEventListener("keydown", handleKey);
    onCleanup(() => document.removeEventListener("keydown", handleKey));
  });

  const fileName = () => {
    const parts = props.filePath.split("/");
    return parts[parts.length - 1];
  };

  const dirPath = () => {
    const parts = props.filePath.split("/");
    parts.pop();
    return parts.join("/");
  };

  const lines = () => content()?.split("\n") ?? [];

  const ext = () => {
    const name = fileName();
    const dot = name.lastIndexOf(".");
    return dot > 0 ? name.slice(dot + 1) : "";
  };

  // Simple syntax color hints based on extension
  const langLabel = () => {
    const e = ext();
    const map: Record<string, string> = {
      rs: "Rust", ts: "TypeScript", tsx: "TSX", js: "JavaScript",
      jsx: "JSX", py: "Python", go: "Go", rb: "Ruby",
      java: "Java", kt: "Kotlin", swift: "Swift", dart: "Dart",
      css: "CSS", html: "HTML", json: "JSON", yaml: "YAML",
      yml: "YAML", toml: "TOML", md: "Markdown", sh: "Shell",
      bash: "Bash", zsh: "Zsh", sql: "SQL", xml: "XML",
    };
    return map[e] ?? (e.toUpperCase() || "Text");
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0, left: 0, right: 0, bottom: 0,
        background: "rgba(0, 0, 0, 0.6)",
        "z-index": "1000",
        display: "flex",
        "align-items": "center",
        "justify-content": "center",
      }}
      onClick={(e) => { if (e.target === e.currentTarget) props.onClose(); }}
    >
      <div
        style={{
          width: "80vw",
          "max-width": "900px",
          height: "80vh",
          background: "var(--bg-secondary)",
          border: "1px solid var(--border)",
          "border-radius": "8px",
          "box-shadow": "0 8px 32px rgba(0, 0, 0, 0.5)",
          display: "flex",
          "flex-direction": "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            "align-items": "center",
            padding: "8px 12px",
            background: "var(--bg-primary)",
            "border-bottom": "1px solid var(--border)",
            gap: "8px",
            "flex-shrink": 0,
          }}
        >
          <span style={{
            "font-family": "var(--font-mono)",
            "font-size": "13px",
            color: "var(--accent)",
            "font-weight": 600,
          }}>
            {fileName()}
          </span>
          <span style={{
            "font-family": "var(--font-mono)",
            "font-size": "11px",
            color: "var(--text-muted)",
            flex: 1,
            overflow: "hidden",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
          }}>
            {dirPath()}
          </span>
          <span style={{
            "font-size": "10px",
            color: "var(--text-muted)",
            background: "var(--bg-hover)",
            padding: "1px 6px",
            "border-radius": "3px",
          }}>
            {langLabel()}
          </span>
          <Show when={props.line}>
            <span style={{
              "font-size": "10px",
              color: "var(--yellow)",
              background: "rgba(224, 175, 104, 0.15)",
              padding: "1px 6px",
              "border-radius": "3px",
            }}>
              Line {props.line}
            </span>
          </Show>
          <span style={{
            "font-size": "10px",
            color: "var(--text-muted)",
          }}>
            {lines().length} lines
          </span>
          <button
            onClick={props.onClose}
            style={{
              background: "none",
              border: "none",
              color: "var(--text-muted)",
              cursor: "pointer",
              "font-size": "16px",
              padding: "0 4px",
            }}
          >
            {"\u2715"}
          </button>
        </div>

        {/* Content */}
        <div
          ref={scrollRef}
          style={{
            flex: 1,
            "overflow-y": "auto",
            "font-family": "var(--font-mono)",
            "font-size": "13px",
            "line-height": "1.5",
          }}
        >
          <Show when={loading()}>
            <div style={{ padding: "24px", color: "var(--text-muted)", "text-align": "center" }}>
              Loading...
            </div>
          </Show>

          <Show when={error()}>
            <div style={{ padding: "24px", color: "var(--red)", "text-align": "center" }}>
              {error()}
            </div>
          </Show>

          <Show when={content() !== null}>
            <table style={{ "border-collapse": "collapse", width: "100%" }}>
              <tbody>
                {lines().map((line, i) => {
                  const lineNum = i + 1;
                  const isTarget = props.line === lineNum;
                  return (
                    <tr
                      data-line={lineNum}
                      style={{
                        background: isTarget
                          ? "rgba(122, 162, 247, 0.15)"
                          : "transparent",
                      }}
                    >
                      <td style={{
                        "text-align": "right",
                        padding: "0 12px 0 8px",
                        color: isTarget ? "var(--accent)" : "var(--text-muted)",
                        "user-select": "none",
                        "white-space": "nowrap",
                        "border-right": isTarget
                          ? "2px solid var(--accent)"
                          : "1px solid var(--border)",
                        "font-size": "11px",
                        "min-width": "40px",
                        "vertical-align": "top",
                      }}>
                        {lineNum}
                      </td>
                      <td style={{
                        padding: "0 12px",
                        color: "var(--text-primary)",
                        "white-space": "pre",
                        "overflow-x": "auto",
                      }}>
                        {line || " "}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Show>
        </div>
      </div>
    </div>
  );
}
