import { onMount, onCleanup, Show } from "solid-js";
import { Terminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import { SearchAddon } from "@xterm/addon-search";
import "@xterm/xterm/css/xterm.css";
import { getScrollback } from "../../stores/scrollbackStore";

interface ScrollbackViewerProps {
  sessionId: string;
  sessionName: string;
  exitCode?: number | null;
  onClose: () => void;
}

export default function ScrollbackViewer(props: ScrollbackViewerProps) {
  let containerRef!: HTMLDivElement;
  let terminal: Terminal | null = null;
  let fitAddon: FitAddon | null = null;
  let resizeObserver: ResizeObserver | null = null;

  onMount(() => {
    const content = getScrollback(props.sessionId);
    if (!content) return;

    terminal = new Terminal({
      fontFamily: "'JetBrains Mono', 'Fira Code', Menlo, monospace",
      fontSize: 14,
      lineHeight: 1.2,
      theme: {
        background: "#1a1b26",
        foreground: "#c0caf5",
        cursor: "#c0caf5",
        cursorAccent: "#1a1b26",
        selectionBackground: "#33467c",
        selectionForeground: "#c0caf5",
        black: "#15161e",
        red: "#f7768e",
        green: "#9ece6a",
        yellow: "#e0af68",
        blue: "#7aa2f7",
        magenta: "#bb9af7",
        cyan: "#7dcfff",
        white: "#a9b1d6",
        brightBlack: "#414868",
        brightRed: "#f7768e",
        brightGreen: "#9ece6a",
        brightYellow: "#e0af68",
        brightBlue: "#7aa2f7",
        brightMagenta: "#bb9af7",
        brightCyan: "#7dcfff",
        brightWhite: "#c0caf5",
      },
      cursorBlink: false,
      cursorStyle: "block",
      scrollback: 50000,
      disableStdin: true,
    });

    fitAddon = new FitAddon();
    terminal.loadAddon(fitAddon);

    const searchAddon = new SearchAddon();
    terminal.loadAddon(searchAddon);

    terminal.open(containerRef);

    // Write saved content
    terminal.write(content.replace(/\n/g, "\r\n"));

    // Add end marker
    const statusColor = props.exitCode === 0 ? "32" : "31"; // green or red
    const statusText = props.exitCode === 0 ? "completed" : `exited (${props.exitCode ?? "?"})`;
    terminal.write(
      `\r\n\r\n\x1b[${statusColor};1m--- Session ${statusText} ---\x1b[0m\r\n`
    );

    requestAnimationFrame(() => {
      fitAddon?.fit();
      // Scroll to bottom to show end state
      terminal?.scrollToBottom();
    });

    resizeObserver = new ResizeObserver(() => {
      requestAnimationFrame(() => fitAddon?.fit());
    });
    resizeObserver.observe(containerRef);
  });

  onCleanup(() => {
    resizeObserver?.disconnect();
    terminal?.dispose();
  });

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        "flex-direction": "column",
        background: "var(--bg-primary)",
      }}
    >
      {/* Header bar */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          padding: "6px 12px",
          background: "var(--bg-secondary)",
          "border-bottom": "1px solid var(--border)",
          gap: "8px",
          "flex-shrink": 0,
        }}
      >
        <span
          style={{
            width: "8px",
            height: "8px",
            "border-radius": "50%",
            background: props.exitCode === 0 ? "var(--grey)" : "var(--red)",
            "flex-shrink": 0,
          }}
        />
        <span
          style={{
            flex: 1,
            "font-size": "12px",
            color: "var(--text-secondary)",
            "font-family": "var(--font-mono)",
          }}
        >
          {props.sessionName}
          <span style={{ color: "var(--text-muted)", "margin-left": "8px" }}>
            (read-only)
          </span>
        </span>
        <span
          style={{
            "font-size": "11px",
            color: "var(--text-muted)",
            "font-family": "var(--font-ui)",
          }}
        >
          Cmd+F to search
        </span>
        <button
          onClick={props.onClose}
          style={{
            background: "none",
            border: "none",
            color: "var(--text-muted)",
            cursor: "pointer",
            "font-size": "16px",
            padding: "0 4px",
            "border-radius": "3px",
            transition: "color 0.15s",
          }}
          onMouseEnter={(e) =>
            ((e.currentTarget as HTMLElement).style.color = "var(--text-primary)")
          }
          onMouseLeave={(e) =>
            ((e.currentTarget as HTMLElement).style.color = "var(--text-muted)")
          }
          title="Close viewer"
        >
          {"\u2715"}
        </button>
      </div>

      {/* Terminal content */}
      <div
        ref={containerRef}
        style={{
          flex: 1,
          overflow: "hidden",
        }}
      />

      <Show when={!getScrollback(props.sessionId)}>
        <div
          style={{
            display: "flex",
            "align-items": "center",
            "justify-content": "center",
            height: "100%",
            color: "var(--text-muted)",
            "font-size": "13px",
          }}
        >
          No scrollback saved for this session
        </div>
      </Show>
    </div>
  );
}
