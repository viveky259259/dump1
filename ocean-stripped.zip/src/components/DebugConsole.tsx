import { createSignal, createMemo, For, Show, onMount, onCleanup } from "solid-js";
import { getLogs, clearLogs, type LogLevel, type LogSource, type LogEntry } from "../stores/logStore";

const LEVEL_COLORS: Record<LogLevel, string> = {
  debug: "var(--text-muted)",
  info: "var(--blue)",
  warn: "var(--yellow)",
  error: "var(--red)",
};

const SOURCE_COLORS: Record<string, string> = {
  frontend: "var(--accent)",
  backend: "var(--green)",
  ipc: "var(--cyan, #7dcfff)",
  pty: "var(--magenta, #bb9af7)",
  layout: "var(--yellow)",
  session: "var(--green)",
  metrics: "var(--blue)",
  annotation: "var(--red)",
};

export default function DebugConsole(props: { onClose: () => void }) {
  let scrollRef!: HTMLDivElement;
  const [levelFilter, setLevelFilter] = createSignal<LogLevel | "all">("all");
  const [sourceFilter, setSourceFilter] = createSignal<LogSource | "all">("all");
  const [autoScroll, setAutoScroll] = createSignal(true);

  const filteredLogs = createMemo(() => {
    const level = levelFilter();
    const source = sourceFilter();
    return getLogs({
      level: level === "all" ? undefined : level,
      source: source === "all" ? undefined : source as LogSource,
    });
  });

  // Auto-scroll to bottom
  let scrollInterval: ReturnType<typeof setInterval>;
  onMount(() => {
    scrollInterval = setInterval(() => {
      if (autoScroll() && scrollRef) {
        scrollRef.scrollTop = scrollRef.scrollHeight;
      }
    }, 200);
  });

  onCleanup(() => clearInterval(scrollInterval));

  const filterBtn = (label: string, active: boolean, onClick: () => void) => (
    <button
      onClick={onClick}
      style={{
        background: active ? "var(--bg-active)" : "none",
        border: "1px solid " + (active ? "var(--accent)" : "var(--border)"),
        color: active ? "var(--accent)" : "var(--text-muted)",
        cursor: "pointer",
        "font-size": "10px",
        padding: "1px 6px",
        "border-radius": "3px",
        "font-family": "var(--font-mono)",
      }}
    >
      {label}
    </button>
  );

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        "flex-direction": "column",
        background: "var(--bg-secondary)",
        "border-top": "2px solid var(--accent)",
      }}
    >
      {/* Toolbar */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          padding: "4px 8px",
          gap: "6px",
          "border-bottom": "1px solid var(--border)",
          "flex-shrink": 0,
          "flex-wrap": "wrap",
        }}
      >
        <span
          style={{
            "font-size": "11px",
            "font-weight": 600,
            color: "var(--accent)",
            "text-transform": "uppercase",
            "letter-spacing": "0.5px",
            "margin-right": "8px",
          }}
        >
          Debug
        </span>

        {/* Level filters */}
        {filterBtn("All", levelFilter() === "all", () => setLevelFilter("all"))}
        {filterBtn("Debug", levelFilter() === "debug", () => setLevelFilter("debug"))}
        {filterBtn("Info", levelFilter() === "info", () => setLevelFilter("info"))}
        {filterBtn("Warn", levelFilter() === "warn", () => setLevelFilter("warn"))}
        {filterBtn("Error", levelFilter() === "error", () => setLevelFilter("error"))}

        <span style={{ width: "1px", height: "14px", background: "var(--border)", margin: "0 4px" }} />

        {/* Source filters */}
        {filterBtn("All Src", sourceFilter() === "all", () => setSourceFilter("all"))}
        {filterBtn("IPC", sourceFilter() === "ipc", () => setSourceFilter("ipc"))}
        {filterBtn("PTY", sourceFilter() === "pty", () => setSourceFilter("pty"))}
        {filterBtn("Layout", sourceFilter() === "layout", () => setSourceFilter("layout"))}
        {filterBtn("Session", sourceFilter() === "session", () => setSourceFilter("session"))}

        <div style={{ flex: 1 }} />

        <span style={{ "font-size": "10px", color: "var(--text-muted)" }}>
          {filteredLogs().length} entries
        </span>

        <button
          onClick={() => setAutoScroll(!autoScroll())}
          style={{
            background: autoScroll() ? "var(--bg-active)" : "none",
            border: "1px solid var(--border)",
            color: autoScroll() ? "var(--accent)" : "var(--text-muted)",
            cursor: "pointer",
            "font-size": "10px",
            padding: "1px 6px",
            "border-radius": "3px",
          }}
        >
          Auto-scroll
        </button>

        <button
          onClick={clearLogs}
          style={{
            background: "none",
            border: "1px solid var(--border)",
            color: "var(--text-muted)",
            cursor: "pointer",
            "font-size": "10px",
            padding: "1px 6px",
            "border-radius": "3px",
          }}
        >
          Clear
        </button>

        <button
          onClick={props.onClose}
          style={{
            background: "none",
            border: "none",
            color: "var(--text-muted)",
            cursor: "pointer",
            "font-size": "14px",
            padding: "0 4px",
          }}
        >
          {"\u2715"}
        </button>
      </div>

      {/* Log entries */}
      <div
        ref={scrollRef}
        style={{
          flex: 1,
          "overflow-y": "auto",
          "font-family": "var(--font-mono)",
          "font-size": "11px",
          "line-height": "1.6",
          padding: "4px 0",
        }}
      >
        <For each={filteredLogs()}>
          {(entry) => (
            <div
              style={{
                padding: "1px 8px",
                display: "flex",
                gap: "8px",
                "border-bottom": "1px solid rgba(41, 46, 66, 0.3)",
                background: entry.level === "error"
                  ? "rgba(247, 118, 142, 0.05)"
                  : entry.level === "warn"
                    ? "rgba(224, 175, 104, 0.03)"
                    : "transparent",
              }}
            >
              <span style={{ color: "var(--text-muted)", "flex-shrink": 0, width: "75px" }}>
                {entry.timestamp}
              </span>
              <span
                style={{
                  color: LEVEL_COLORS[entry.level],
                  "flex-shrink": 0,
                  width: "40px",
                  "text-transform": "uppercase",
                  "font-weight": entry.level === "error" ? "bold" : "normal",
                }}
              >
                {entry.level}
              </span>
              <span
                style={{
                  color: SOURCE_COLORS[entry.source] ?? "var(--text-secondary)",
                  "flex-shrink": 0,
                  width: "72px",
                }}
              >
                [{entry.source}]
              </span>
              <span style={{ color: "var(--text-primary)", flex: 1, "word-break": "break-word" }}>
                {entry.message}
                <Show when={entry.data !== undefined}>
                  <span style={{ color: "var(--text-muted)", "margin-left": "8px" }}>
                    {typeof entry.data === "string" ? entry.data : JSON.stringify(entry.data)}
                  </span>
                </Show>
              </span>
            </div>
          )}
        </For>

        <Show when={filteredLogs().length === 0}>
          <div style={{ padding: "16px", color: "var(--text-muted)", "text-align": "center" }}>
            No log entries
          </div>
        </Show>
      </div>
    </div>
  );
}
