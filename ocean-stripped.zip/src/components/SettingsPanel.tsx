import { createSignal, onMount, onCleanup } from "solid-js";
import { settings, updateSetting } from "../stores/settingsStore";
import { hideSettings } from "../stores/uiStore";

export default function SettingsPanel() {
  const [paneWidth, setPaneWidth] = createSignal(String(settings.paneResizeWidth));
  let inputRef!: HTMLInputElement;

  onMount(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") hideSettings();
    };
    document.addEventListener("keydown", handleKey);
    onCleanup(() => document.removeEventListener("keydown", handleKey));
  });

  const handleSave = () => {
    const val = parseInt(paneWidth(), 10);
    if (!isNaN(val) && val >= 200 && val <= 2000) {
      updateSetting("paneResizeWidth", val);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0, left: 0, right: 0, bottom: 0,
        background: "rgba(0,0,0,0.5)",
        "z-index": "1000",
        display: "flex",
        "justify-content": "center",
        "padding-top": "10vh",
      }}
      onClick={(e) => { if (e.target === e.currentTarget) hideSettings(); }}
    >
      <div style={{
        width: "480px",
        "max-height": "500px",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "8px",
        "box-shadow": "0 8px 32px rgba(0,0,0,0.5)",
        display: "flex",
        "flex-direction": "column",
        overflow: "hidden",
      }}>
        {/* Header */}
        <div style={{
          display: "flex",
          "align-items": "center",
          "justify-content": "space-between",
          padding: "12px 16px",
          "border-bottom": "1px solid var(--border)",
        }}>
          <span style={{
            "font-size": "14px",
            "font-weight": 600,
            color: "var(--text-primary)",
            "font-family": "var(--font-ui)",
          }}>
            Settings
          </span>
          <button
            onClick={hideSettings}
            style={{
              background: "none",
              border: "none",
              color: "var(--text-muted)",
              cursor: "pointer",
              "font-size": "16px",
              padding: "0 4px",
            }}
          >
            {"\u2715"}
          </button>
        </div>

        {/* Body */}
        <div style={{ padding: "16px", display: "flex", "flex-direction": "column", gap: "16px", "overflow-y": "auto" }}>

          {/* Section: Layout */}
          <div>
            <div style={{
              "font-size": "11px",
              "text-transform": "uppercase",
              "letter-spacing": "0.5px",
              color: "var(--text-muted)",
              "margin-bottom": "10px",
              "font-family": "var(--font-ui)",
            }}>
              Layout
            </div>

            {/* Pane resize width */}
            <div style={{
              display: "flex",
              "align-items": "center",
              "justify-content": "space-between",
              gap: "12px",
            }}>
              <div>
                <div style={{
                  "font-size": "13px",
                  color: "var(--text-primary)",
                  "font-family": "var(--font-ui)",
                }}>
                  Auto-resize width
                </div>
                <div style={{
                  "font-size": "11px",
                  color: "var(--text-muted)",
                  "margin-top": "2px",
                }}>
                  Target width in px when clicking the resize icon on split panes
                </div>
              </div>
              <div style={{ display: "flex", "align-items": "center", gap: "6px", "flex-shrink": 0 }}>
                <input
                  ref={inputRef}
                  type="number"
                  min="200"
                  max="2000"
                  step="50"
                  value={paneWidth()}
                  onInput={(e) => setPaneWidth(e.currentTarget.value)}
                  onChange={handleSave}
                  onKeyDown={(e) => { if (e.key === "Enter") handleSave(); }}
                  style={{
                    width: "70px",
                    padding: "4px 8px",
                    background: "var(--bg-primary)",
                    border: "1px solid var(--border)",
                    "border-radius": "4px",
                    color: "var(--text-primary)",
                    "font-size": "13px",
                    "font-family": "var(--font-mono)",
                    "text-align": "right",
                    outline: "none",
                  }}
                  onFocus={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "var(--accent)"; }}
                  onBlur={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "var(--border)"; handleSave(); }}
                />
                <span style={{ "font-size": "11px", color: "var(--text-muted)" }}>px</span>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div style={{ height: "1px", background: "var(--border)" }} />

          {/* Info */}
          <div style={{
            "font-size": "11px",
            color: "var(--text-muted)",
            "font-family": "var(--font-ui)",
          }}>
            Settings are saved to localStorage automatically.
          </div>
        </div>
      </div>
    </div>
  );
}
