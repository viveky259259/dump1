import { createSignal, onMount, Show, For } from "solid-js";
import { getSessionDelta, mergeSession, translateToCommit } from "../../stores/workspaceStore";
import type { DeltaInfo, MergeResult } from "../../stores/workspaceStore";
import { logInfo, logError } from "../../stores/logStore";

interface MergePanelProps {
  workspaceId: string;
  sessionId: string;
  sessionName: string;
  onClose: () => void;
}

export default function MergePanel(props: MergePanelProps) {
  const [loading, setLoading] = createSignal(true);
  const [delta, setDelta] = createSignal<DeltaInfo | null>(null);
  const [error, setError] = createSignal<string | null>(null);
  const [merging, setMerging] = createSignal(false);
  const [mergeResult, setMergeResult] = createSignal<MergeResult | null>(null);
  const [commitHash, setCommitHash] = createSignal<string | null>(null);
  const [committing, setCommitting] = createSignal(false);

  onMount(async () => {
    try {
      logInfo("frontend", `MergePanel: loading delta for session ${props.sessionId.slice(0, 8)}`);
      const d = await getSessionDelta(props.workspaceId, props.sessionId);
      setDelta(d);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logError("frontend", `MergePanel: failed to load delta: ${msg}`);
      setError(msg);
    } finally {
      setLoading(false);
    }
  });

  const handleMerge = async () => {
    setMerging(true);
    setError(null);
    try {
      logInfo("frontend", `MergePanel: merging session ${props.sessionId.slice(0, 8)}`);
      const result = await mergeSession(props.workspaceId, props.sessionId);
      setMergeResult(result);
      logInfo("frontend", `Merge result: success=${result.success}, ${result.merged_files.length} files`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logError("frontend", `MergePanel: merge failed: ${msg}`);
      setError(msg);
    } finally {
      setMerging(false);
    }
  };

  const handleTranslateToCommit = async () => {
    setCommitting(true);
    setError(null);
    try {
      const hash = await translateToCommit(props.sessionId);
      setCommitHash(hash);
      logInfo("frontend", `Commit created: ${hash}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logError("frontend", `MergePanel: commit failed: ${msg}`);
      setError(msg);
    } finally {
      setCommitting(false);
    }
  };

  const formatBytes = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const fileCount = () => {
    const d = delta();
    if (!d) return 0;
    return d.modified_files.length + d.created_files.length + d.deleted_files.length;
  };

  return (
    <div style={{
      position: "fixed", top: 0, right: 0, width: "400px", height: "100%",
      background: "var(--bg-secondary)", "border-left": "1px solid var(--border)",
      "box-shadow": "-4px 0 12px rgba(0,0,0,0.3)", "z-index": 200,
      display: "flex", "flex-direction": "column",
      "font-family": "var(--font-ui)", "font-size": "13px", color: "var(--text-primary)",
    }}>
      {/* Header */}
      <div style={{
        padding: "12px 16px", display: "flex", "align-items": "center",
        "justify-content": "space-between", "border-bottom": "1px solid var(--border)", "flex-shrink": 0,
      }}>
        <span style={{ "font-weight": 600, "font-size": "14px" }}>Merge: {props.sessionName}</span>
        <button onClick={props.onClose} style={{
          background: "none", border: "none", color: "var(--text-muted)",
          cursor: "pointer", "font-size": "16px", padding: "2px 6px", "border-radius": "3px",
        }}>{"\u2715"}</button>
      </div>

      {/* Content */}
      <div style={{ flex: 1, "overflow-y": "auto", padding: "12px 16px" }}>
        <Show when={loading()}>
          <div style={{ padding: "24px", "text-align": "center", color: "var(--text-muted)" }}>
            <span style={{ animation: "pulse 1.5s infinite" }}>Loading delta...</span>
          </div>
        </Show>

        <Show when={error()}>
          <div style={{
            padding: "10px 12px", background: "rgba(247,118,142,0.1)",
            border: "1px solid var(--red)", "border-radius": "6px",
            color: "var(--red)", "font-size": "12px", "margin-bottom": "12px",
          }}>{error()}</div>
        </Show>

        {/* Delta info */}
        <Show when={delta() && !mergeResult()}>
          <div>
            <div style={{
              padding: "8px 12px", background: "var(--bg-hover)", "border-radius": "6px",
              "margin-bottom": "12px", "font-size": "12px", color: "var(--text-secondary)",
            }}>
              {fileCount()} file{fileCount() !== 1 ? "s" : ""} changed, {formatBytes(delta()!.delta_size_bytes)}
            </div>

            <Show when={delta()!.modified_files.length > 0}>
              <div style={{ "margin-bottom": "12px" }}>
                <div style={{ "font-size": "11px", "text-transform": "uppercase", color: "var(--yellow)", "margin-bottom": "4px", "font-weight": 600 }}>
                  Modified ({delta()!.modified_files.length})
                </div>
                <For each={delta()!.modified_files}>
                  {(file) => (
                    <div style={{ padding: "3px 8px", "font-family": "var(--font-mono)", "font-size": "12px", display: "flex", "align-items": "center", gap: "6px" }}>
                      <span style={{ color: "var(--yellow)", "font-size": "10px" }}>{"\u25CF"}</span>
                      <span style={{ overflow: "hidden", "text-overflow": "ellipsis", "white-space": "nowrap" }}>{file}</span>
                    </div>
                  )}
                </For>
              </div>
            </Show>

            <Show when={delta()!.created_files.length > 0}>
              <div style={{ "margin-bottom": "12px" }}>
                <div style={{ "font-size": "11px", "text-transform": "uppercase", color: "var(--green)", "margin-bottom": "4px", "font-weight": 600 }}>
                  Created ({delta()!.created_files.length})
                </div>
                <For each={delta()!.created_files}>
                  {(file) => (
                    <div style={{ padding: "3px 8px", "font-family": "var(--font-mono)", "font-size": "12px", display: "flex", "align-items": "center", gap: "6px" }}>
                      <span style={{ color: "var(--green)", "font-size": "10px" }}>{"\u25CF"}</span>
                      <span style={{ overflow: "hidden", "text-overflow": "ellipsis", "white-space": "nowrap" }}>{file}</span>
                    </div>
                  )}
                </For>
              </div>
            </Show>

            <Show when={delta()!.deleted_files.length > 0}>
              <div style={{ "margin-bottom": "12px" }}>
                <div style={{ "font-size": "11px", "text-transform": "uppercase", color: "var(--red)", "margin-bottom": "4px", "font-weight": 600 }}>
                  Deleted ({delta()!.deleted_files.length})
                </div>
                <For each={delta()!.deleted_files}>
                  {(file) => (
                    <div style={{ padding: "3px 8px", "font-family": "var(--font-mono)", "font-size": "12px", display: "flex", "align-items": "center", gap: "6px" }}>
                      <span style={{ color: "var(--red)", "font-size": "10px" }}>{"\u25CF"}</span>
                      <span style={{ overflow: "hidden", "text-overflow": "ellipsis", "white-space": "nowrap", "text-decoration": "line-through", opacity: 0.7 }}>{file}</span>
                    </div>
                  )}
                </For>
              </div>
            </Show>

            <Show when={fileCount() === 0}>
              <div style={{ padding: "16px", color: "var(--text-muted)", "text-align": "center" }}>
                No changes detected
              </div>
            </Show>
          </div>
        </Show>

        {/* Merge result */}
        <Show when={mergeResult()}>
          {(result) => (
            <div>
              <div style={{
                padding: "10px 12px",
                background: result().success ? "rgba(158,206,106,0.1)" : "rgba(224,175,104,0.1)",
                border: result().success ? "1px solid var(--green)" : "1px solid var(--yellow)",
                "border-radius": "6px", "margin-bottom": "12px",
              }}>
                <div style={{ "font-weight": 600, "margin-bottom": "4px", color: result().success ? "var(--green)" : "var(--yellow)" }}>
                  {result().success ? "Merge successful" : "Merge completed with conflicts"}
                </div>
                <div style={{ "font-size": "12px", color: "var(--text-secondary)" }}>
                  {result().merged_files.length} file{result().merged_files.length !== 1 ? "s" : ""} merged
                </div>
              </div>

              <Show when={result().conflicts.length > 0}>
                <div style={{ "margin-bottom": "12px" }}>
                  <div style={{ "font-size": "11px", "text-transform": "uppercase", color: "var(--yellow)", "margin-bottom": "4px", "font-weight": 600 }}>
                    Conflicts ({result().conflicts.length})
                  </div>
                  <For each={result().conflicts}>
                    {(file) => (
                      <div style={{ padding: "4px 8px", "font-family": "var(--font-mono)", "font-size": "12px", color: "var(--yellow)" }}>
                        {file}
                      </div>
                    )}
                  </For>
                </div>
              </Show>

              <Show when={result().success && !commitHash()}>
                <button onClick={handleTranslateToCommit} disabled={committing()} style={{
                  background: "var(--accent)", color: "var(--bg-primary)", border: "none",
                  padding: "8px 16px", "border-radius": "6px", cursor: committing() ? "wait" : "pointer",
                  "font-size": "13px", "font-weight": 500, width: "100%", opacity: committing() ? 0.6 : 1,
                }}>
                  {committing() ? "Creating commit..." : "Translate to Commit"}
                </button>
              </Show>

              <Show when={commitHash()}>
                <div style={{
                  padding: "10px 12px", background: "rgba(158,206,106,0.1)",
                  border: "1px solid var(--green)", "border-radius": "6px", "margin-top": "8px",
                }}>
                  <div style={{ "font-weight": 600, color: "var(--green)", "margin-bottom": "4px" }}>Commit created</div>
                  <div style={{ "font-family": "var(--font-mono)", "font-size": "12px", color: "var(--text-secondary)" }}>
                    {commitHash()}
                  </div>
                </div>
              </Show>
            </div>
          )}
        </Show>
      </div>

      {/* Footer */}
      <Show when={!mergeResult()}>
        <div style={{ padding: "12px 16px", "border-top": "1px solid var(--border)", display: "flex", gap: "8px", "flex-shrink": 0 }}>
          <button onClick={props.onClose} style={{
            flex: 1, background: "none", border: "1px solid var(--border)",
            color: "var(--text-secondary)", padding: "8px 16px", "border-radius": "6px", cursor: "pointer", "font-size": "13px",
          }}>Cancel</button>
          <button onClick={handleMerge} disabled={loading() || merging() || !!error() || fileCount() === 0} style={{
            flex: 1, background: "var(--green)", color: "var(--bg-primary)", border: "none",
            padding: "8px 16px", "border-radius": "6px",
            cursor: (loading() || merging()) ? "wait" : "pointer",
            "font-size": "13px", "font-weight": 600, opacity: (loading() || merging() || !!error()) ? 0.5 : 1,
          }}>
            {merging() ? "Merging..." : "Merge All"}
          </button>
        </div>
      </Show>

      <Show when={mergeResult()}>
        <div style={{ padding: "12px 16px", "border-top": "1px solid var(--border)", "flex-shrink": 0 }}>
          <button onClick={props.onClose} style={{
            width: "100%", background: "none", border: "1px solid var(--border)",
            color: "var(--text-secondary)", padding: "8px 16px", "border-radius": "6px", cursor: "pointer", "font-size": "13px",
          }}>Done</button>
        </div>
      </Show>
    </div>
  );
}
