import { createSignal, Show, For } from "solid-js";
import { activeConflicts, clearConflict, clearAllConflicts } from "../../stores/workspaceStore";
import { invoke } from "@tauri-apps/api/core";
import { sessionState } from "../../stores/sessionStore";
import { logInfo, logError } from "../../stores/logStore";

interface FileVersion {
  session_id: string;
  session_name: string;
  content: string;
}

interface ConflictDetail {
  file_path: string;
  base_content: string;
  versions: FileVersion[];
}

export default function ConflictBanner() {
  const [expandedFile, setExpandedFile] = createSignal<string | null>(null);
  const [detail, setDetail] = createSignal<ConflictDetail | null>(null);
  const [loading, setLoading] = createSignal(false);
  const [resolving, setResolving] = createSignal(false);
  const [resolvedContent, setResolvedContent] = createSignal<{ filePath: string; content: string } | null>(null);

  const conflicts = activeConflicts;

  const handleExpand = async (filePath: string) => {
    if (expandedFile() === filePath) {
      setExpandedFile(null);
      setDetail(null);
      return;
    }
    setExpandedFile(filePath);
    setLoading(true);
    setDetail(null);
    try {
      const wsId = sessionState.activeWorkspaceId;
      if (!wsId) return;
      const result = await invoke<ConflictDetail>("get_conflict_details", {
        workspaceId: wsId, filePath,
      });
      setDetail(result);
    } catch (e) {
      logError("frontend", `Failed to get conflict details: ${e}`);
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (filePath: string, resolution: string) => {
    setResolving(true);
    try {
      const wsId = sessionState.activeWorkspaceId;
      if (!wsId) return;
      await invoke("resolve_conflict", { workspaceId: wsId, filePath, resolution });
      logInfo("frontend", `Conflict resolved: ${filePath} -> ${resolution}`);
      clearConflict(filePath);
      setExpandedFile(null);
      setDetail(null);
    } catch (e) {
      logError("frontend", `Failed to resolve conflict: ${e}`);
    } finally {
      setResolving(false);
    }
  };

  const diffLines = (base: string, version: string) => {
    const baseLines = base.split("\n");
    const versionLines = version.split("\n");
    const result: { type: "same" | "added" | "removed"; text: string }[] = [];
    const maxLen = Math.max(baseLines.length, versionLines.length);
    for (let i = 0; i < maxLen; i++) {
      const b = baseLines[i];
      const v = versionLines[i];
      if (b === v) {
        result.push({ type: "same", text: b ?? "" });
      } else {
        if (b !== undefined) result.push({ type: "removed", text: b });
        if (v !== undefined) result.push({ type: "added", text: v });
      }
    }
    return result;
  };

  return (
    <Show when={conflicts().length > 0}>
      <div style={{
        background: "rgba(224, 175, 104, 0.08)",
        "border-bottom": "1px solid var(--yellow)",
        "flex-shrink": 0,
        "max-height": expandedFile() ? "60vh" : "auto",
        "overflow-y": "auto",
        "font-family": "var(--font-ui)",
      }}>
        <div style={{ display: "flex", "align-items": "center", padding: "6px 12px", gap: "8px" }}>
          <span style={{ color: "var(--yellow)", "font-size": "12px", "font-weight": 600 }}>
            {"\u26A0"} {conflicts().length} conflict{conflicts().length > 1 ? "s" : ""} — click to resolve
          </span>
          <div style={{ flex: 1 }} />
          <button onClick={clearAllConflicts} style={{
            background: "none", border: "none", color: "var(--text-muted)",
            cursor: "pointer", "font-size": "10px",
          }}>Dismiss</button>
        </div>

        <For each={conflicts()}>
          {(conflict) => (
            <div style={{ "border-top": "1px solid rgba(224, 175, 104, 0.15)" }}>
              <div onClick={() => handleExpand(conflict.file_path)} style={{
                display: "flex", "align-items": "center", padding: "4px 12px 4px 20px",
                gap: "8px", cursor: "pointer",
              }}>
                <span style={{ color: "var(--text-muted)", "font-size": "10px", width: "12px" }}>
                  {expandedFile() === conflict.file_path ? "\u25BC" : "\u25B6"}
                </span>
                <span style={{ "font-family": "var(--font-mono)", "font-size": "12px", color: "var(--yellow)", flex: 1 }}>
                  {conflict.file_path}
                </span>
                <span style={{ "font-size": "10px", color: "var(--text-muted)" }}>
                  {conflict.session_names.join(" vs ")}
                </span>
              </div>

              <Show when={expandedFile() === conflict.file_path}>
                <div style={{ padding: "8px 12px 12px 32px" }}>
                  <Show when={loading()}>
                    <div style={{ color: "var(--text-muted)", "font-size": "12px", padding: "8px 0" }}>Loading...</div>
                  </Show>

                  <Show when={detail()}>
                    {(d) => (
                      <div>
                        {/* Resolution buttons */}
                        <div style={{ display: "flex", gap: "6px", "margin-bottom": "10px", "flex-wrap": "wrap" }}>
                          <For each={d().versions}>
                            {(v) => (
                              <button
                                onClick={() => handleResolve(conflict.file_path, `accept:${v.session_id}`)}
                                disabled={resolving()}
                                style={{
                                  background: "rgba(122,162,247,0.15)", border: "1px solid rgba(122,162,247,0.3)",
                                  color: "var(--accent)", "border-radius": "4px", padding: "4px 10px",
                                  cursor: "pointer", "font-size": "11px",
                                }}
                              >
                                Accept {v.session_name}
                              </button>
                            )}
                          </For>
                          {/* Merge All removed — needs proper 3-way merge implementation (TD-009) */}
                        </div>

                        {/* Diff per version */}
                        <For each={d().versions}>
                          {(version) => {
                            const diff = () => diffLines(d().base_content, version.content);
                            const changed = () => diff().filter((l) => l.type !== "same");
                            return (
                              <div style={{ "margin-bottom": "8px" }}>
                                <div style={{ "font-size": "11px", "font-weight": 600, color: "var(--text-secondary)", "margin-bottom": "3px" }}>
                                  {version.session_name}
                                  <span style={{ color: "var(--text-muted)", "font-weight": "normal", "margin-left": "6px" }}>
                                    ({changed().length} line{changed().length !== 1 ? "s" : ""})
                                  </span>
                                </div>
                                <div style={{
                                  "font-family": "var(--font-mono)", "font-size": "11px",
                                  background: "var(--bg-primary)", "border-radius": "4px",
                                  border: "1px solid var(--border)", "max-height": "150px", "overflow-y": "auto",
                                }}>
                                  <For each={changed().slice(0, 20)}>
                                    {(line) => (
                                      <div style={{
                                        padding: "1px 8px", "white-space": "pre",
                                        background: line.type === "added" ? "rgba(158,206,106,0.1)" : "rgba(247,118,142,0.1)",
                                        color: line.type === "added" ? "var(--green)" : "var(--red)",
                                      }}>
                                        {line.type === "added" ? "+" : "-"} {line.text}
                                      </div>
                                    )}
                                  </For>
                                  <Show when={changed().length > 20}>
                                    <div style={{ padding: "4px 8px", color: "var(--text-muted)", "font-size": "10px" }}>
                                      ...{changed().length - 20} more
                                    </div>
                                  </Show>
                                </div>
                              </div>
                            );
                          }}
                        </For>
                      </div>
                    )}
                  </Show>
                </div>
              </Show>
            </div>
          )}
        </For>
      </div>
    </Show>
  );
}
