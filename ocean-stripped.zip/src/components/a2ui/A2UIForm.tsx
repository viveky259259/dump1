import { For, createSignal } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";
import { sendA2UIResponse } from "../../stores/a2uiStore";

interface FormField {
  type: string; // "text", "number", "select", "checkbox", "textarea"
  name: string;
  label: string;
  placeholder?: string;
  options?: string[]; // for select
  default_value?: string;
}

interface A2UIFormProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UIForm(props: A2UIFormProps) {
  const fields = () => (props.component.props.fields as FormField[]) ?? [];
  const submitLabel = () => (props.component.props.submit_label as string) ?? "Submit";

  // Initialize form values from defaults
  const [values, setValues] = createSignal<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    for (const field of fields()) {
      initial[field.name] = field.default_value ?? "";
    }
    return initial;
  });

  const updateField = (name: string, value: string) => {
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    sendA2UIResponse(props.sessionId, props.component.component_id, "submit", values());
  };

  const inputStyle = {
    background: "var(--bg-primary)",
    border: "1px solid var(--border)",
    color: "var(--text-primary)",
    padding: "6px 10px",
    "border-radius": "4px",
    "font-family": "var(--font-mono)",
    "font-size": "12px",
    width: "100%",
    outline: "none",
  };

  return (
    <div style={{ display: "flex", "flex-direction": "column", gap: "10px" }}>
      <For each={fields()}>
        {(field) => (
          <div style={{ display: "flex", "flex-direction": "column", gap: "4px" }}>
            <label
              style={{
                "font-family": "var(--font-ui)",
                "font-size": "11px",
                color: "var(--text-secondary)",
                "font-weight": 600,
              }}
            >
              {field.label}
            </label>

            {field.type === "select" ? (
              <select
                style={inputStyle}
                value={values()[field.name] ?? ""}
                onChange={(e) => updateField(field.name, e.currentTarget.value)}
              >
                <For each={field.options ?? []}>
                  {(opt) => <option value={opt}>{opt}</option>}
                </For>
              </select>
            ) : field.type === "textarea" ? (
              <textarea
                style={{ ...inputStyle, "min-height": "60px", resize: "vertical" }}
                placeholder={field.placeholder ?? ""}
                value={values()[field.name] ?? ""}
                onInput={(e) => updateField(field.name, e.currentTarget.value)}
              />
            ) : field.type === "checkbox" ? (
              <label style={{ display: "flex", "align-items": "center", gap: "6px", cursor: "pointer" }}>
                <input
                  type="checkbox"
                  checked={values()[field.name] === "true"}
                  onChange={(e) => updateField(field.name, e.currentTarget.checked ? "true" : "false")}
                  style={{ "accent-color": "var(--accent)" }}
                />
                <span style={{ "font-family": "var(--font-mono)", "font-size": "12px", color: "var(--text-primary)" }}>
                  {field.placeholder ?? ""}
                </span>
              </label>
            ) : (
              <input
                type={field.type === "number" ? "number" : "text"}
                style={inputStyle}
                placeholder={field.placeholder ?? ""}
                value={values()[field.name] ?? ""}
                onInput={(e) => updateField(field.name, e.currentTarget.value)}
              />
            )}
          </div>
        )}
      </For>

      <button
        onClick={handleSubmit}
        style={{
          background: "var(--accent)",
          color: "var(--bg-primary)",
          border: "none",
          padding: "8px 20px",
          "border-radius": "4px",
          "font-family": "var(--font-mono)",
          "font-size": "12px",
          "font-weight": 600,
          cursor: "pointer",
          "align-self": "flex-start",
          transition: "opacity 0.15s",
        }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.opacity = "0.8"; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.opacity = "1"; }}
      >
        {submitLabel()}
      </button>
    </div>
  );
}
