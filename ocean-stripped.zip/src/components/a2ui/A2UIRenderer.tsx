import { Show, For, Switch, Match } from "solid-js";
import {
  getA2UIComponents,
  dismissA2UIComponent,
  type A2UIComponent,
} from "../../stores/a2uiStore";
import A2UIButton from "./A2UIButton";
import A2UITable from "./A2UITable";
import A2UIForm from "./A2UIForm";
import A2UICard from "./A2UICard";
import A2UIProgressBar from "./A2UIProgressBar";
import A2UICodeBlock from "./A2UICodeBlock";
import A2UIDiff from "./A2UIDiff";

interface A2UIRendererProps {
  sessionId: string;
}

function A2UIComponentView(props: { component: A2UIComponent; sessionId: string }) {
  return (
    <div
      style={{
        position: "relative",
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "6px",
        padding: "12px 14px",
        "margin-bottom": "6px",
      }}
    >
      {/* A2UI badge + dismiss button */}
      <div
        style={{
          position: "absolute",
          top: "6px",
          right: "8px",
          display: "flex",
          "align-items": "center",
          gap: "6px",
        }}
      >
        <span
          style={{
            "font-family": "var(--font-mono)",
            "font-size": "9px",
            color: "var(--text-muted)",
            background: "var(--bg-primary)",
            padding: "1px 5px",
            "border-radius": "3px",
            border: "1px solid var(--border)",
            "letter-spacing": "0.5px",
          }}
        >
          A2UI
        </span>
        <button
          onClick={() => dismissA2UIComponent(props.sessionId, props.component.component_id)}
          style={{
            background: "transparent",
            border: "none",
            color: "var(--text-muted)",
            cursor: "pointer",
            "font-size": "14px",
            "line-height": 1,
            padding: "0 2px",
            transition: "color 0.15s",
          }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = "var(--red)"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = "var(--text-muted)"; }}
          title="Dismiss"
        >
          x
        </button>
      </div>

      {/* Component content */}
      <div style={{ "padding-right": "60px" }}>
        <Switch
          fallback={
            <div
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "12px",
                color: "var(--text-secondary)",
              }}
            >
              Unknown component: {props.component.component_type}
            </div>
          }
        >
          <Match when={props.component.component_type === "Button" || props.component.component_type === "ButtonGroup"}>
            <A2UIButton component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "Table"}>
            <A2UITable component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "Form"}>
            <A2UIForm component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "Card" || props.component.component_type === "CardGroup"}>
            <A2UICard component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "ProgressBar"}>
            <A2UIProgressBar component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "CodeBlock"}>
            <A2UICodeBlock component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "Diff"}>
            <A2UIDiff component={props.component} sessionId={props.sessionId} />
          </Match>
          <Match when={props.component.component_type === "Text"}>
            <div
              style={{
                "font-family": "var(--font-mono)",
                "font-size": "12px",
                color: "var(--text-primary)",
                "white-space": "pre-wrap",
                "line-height": "1.5",
              }}
            >
              {(props.component.props.text as string) ?? ""}
            </div>
          </Match>
          <Match when={props.component.component_type === "Heading"}>
            <div
              style={{
                "font-family": "var(--font-ui)",
                "font-size": (props.component.props.level as number) === 1 ? "16px" :
                             (props.component.props.level as number) === 2 ? "14px" : "13px",
                "font-weight": 600,
                color: "var(--text-primary)",
              }}
            >
              {(props.component.props.text as string) ?? ""}
            </div>
          </Match>
        </Switch>
      </div>

      {/* Render children recursively */}
      <Show when={props.component.children.length > 0}>
        <div style={{ "margin-top": "8px", "padding-left": "8px" }}>
          <For each={props.component.children}>
            {(child) => (
              <A2UIComponentView component={child} sessionId={props.sessionId} />
            )}
          </For>
        </div>
      </Show>
    </div>
  );
}

export default function A2UIRenderer(props: A2UIRendererProps) {
  const components = () => getA2UIComponents(props.sessionId);

  return (
    <Show when={components().length > 0}>
      <div
        style={{
          "max-height": "40vh",
          "overflow-y": "auto",
          padding: "6px 10px",
          "border-bottom": "1px solid var(--border)",
          background: "var(--bg-primary)",
          "flex-shrink": 0,
        }}
      >
        <For each={components()}>
          {(component) => (
            <A2UIComponentView component={component} sessionId={props.sessionId} />
          )}
        </For>
      </div>
    </Show>
  );
}
