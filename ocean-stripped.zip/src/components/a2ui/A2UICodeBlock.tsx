import { createSignal, For, Show } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";

interface A2UICodeBlockProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UICodeBlock(props: A2UICodeBlockProps) {
  const code = () => (props.component.props.code as string) ?? "";
  const language = () => (props.component.props.language as string) ?? "";
  const title = () => (props.component.props.title as string) ?? "";
  const [copied, setCopied] = createSignal(false);

  const lines = () => code().split("\n");

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback: no-op
    }
  };

  return (
    <div
      style={{
        background: "var(--bg-primary)",
        border: "1px solid var(--border)",
        "border-radius": "6px",
        overflow: "hidden",
      }}
    >
      {/* Header bar */}
      <div
        style={{
          display: "flex",
          "align-items": "center",
          "justify-content": "space-between",
          padding: "4px 12px",
          background: "var(--bg-secondary)",
          "border-bottom": "1px solid var(--border)",
        }}
      >
        <span
          style={{
            "font-family": "var(--font-ui)",
            "font-size": "11px",
            color: "var(--text-muted)",
          }}
        >
          {title() || language() || "code"}
        </span>
        <button
          onClick={handleCopy}
          style={{
            background: "transparent",
            border: "1px solid var(--border)",
            color: copied() ? "var(--green)" : "var(--text-secondary)",
            padding: "2px 8px",
            "border-radius": "3px",
            "font-family": "var(--font-ui)",
            "font-size": "10px",
            cursor: "pointer",
            transition: "color 0.15s",
          }}
        >
          {copied() ? "Copied" : "Copy"}
        </button>
      </div>

      {/* Code content with line numbers */}
      <div style={{ overflow: "auto", "max-height": "400px", padding: "8px 0" }}>
        <For each={lines()}>
          {(line, i) => (
            <div style={{ display: "flex", "min-height": "20px" }}>
              <span
                style={{
                  "min-width": "40px",
                  "text-align": "right",
                  padding: "0 12px 0 8px",
                  color: "var(--text-muted)",
                  "font-family": "var(--font-mono)",
                  "font-size": "12px",
                  "line-height": "20px",
                  "user-select": "none",
                  "flex-shrink": 0,
                }}
              >
                {i() + 1}
              </span>
              <span
                style={{
                  "font-family": "var(--font-mono)",
                  "font-size": "12px",
                  "line-height": "20px",
                  color: "var(--text-primary)",
                  "white-space": "pre",
                  "padding-right": "12px",
                }}
              >
                {line}
              </span>
            </div>
          )}
        </For>
      </div>
    </div>
  );
}
