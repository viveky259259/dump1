import { Show } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";

interface A2UIProgressBarProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UIProgressBar(props: A2UIProgressBarProps) {
  const value = () => {
    const v = props.component.props.value as number;
    return Math.max(0, Math.min(100, v ?? 0));
  };
  const label = () => (props.component.props.label as string) ?? "";
  const color = () => {
    const v = value();
    if (v === 100) return "var(--green)";
    if (v >= 75) return "var(--accent)";
    if (v >= 50) return "var(--yellow)";
    return "var(--blue)";
  };

  return (
    <div style={{ display: "flex", "flex-direction": "column", gap: "4px" }}>
      <Show when={label()}>
        <div
          style={{
            display: "flex",
            "justify-content": "space-between",
            "align-items": "center",
          }}
        >
          <span
            style={{
              "font-family": "var(--font-ui)",
              "font-size": "11px",
              color: "var(--text-secondary)",
            }}
          >
            {label()}
          </span>
          <span
            style={{
              "font-family": "var(--font-mono)",
              "font-size": "11px",
              color: "var(--text-muted)",
            }}
          >
            {value()}%
          </span>
        </div>
      </Show>
      <div
        style={{
          width: "100%",
          height: "8px",
          background: "var(--bg-primary)",
          "border-radius": "4px",
          overflow: "hidden",
          border: "1px solid var(--border)",
        }}
      >
        <div
          style={{
            width: `${value()}%`,
            height: "100%",
            background: color(),
            "border-radius": "3px",
            transition: "width 0.3s ease",
          }}
        />
      </div>
    </div>
  );
}
