import { For, Show } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";
import { sendA2UIResponse } from "../../stores/a2uiStore";

interface CardAction {
  label: string;
  value?: string;
  variant?: string;
}

interface A2UICardProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UICard(props: A2UICardProps) {
  const title = () => (props.component.props.title as string) ?? "";
  const body = () => (props.component.props.body as string) ?? "";
  const actions = () => (props.component.props.actions as CardAction[]) ?? [];

  // CardGroup: render multiple cards from props.cards
  const cards = () => {
    const c = props.component.props.cards as Array<{
      title: string;
      body: string;
      actions?: CardAction[];
    }> | undefined;
    return c;
  };

  const handleAction = (actionLabel: string, actionValue?: string) => {
    sendA2UIResponse(props.sessionId, props.component.component_id, "click", {
      button: actionLabel,
      value: actionValue ?? actionLabel,
    });
  };

  const renderSingleCard = (
    cardTitle: string,
    cardBody: string,
    cardActions: CardAction[],
  ) => (
    <div
      style={{
        background: "var(--bg-secondary)",
        border: "1px solid var(--border)",
        "border-radius": "6px",
        padding: "12px 16px",
        display: "flex",
        "flex-direction": "column",
        gap: "8px",
        "min-width": "200px",
      }}
    >
      <Show when={cardTitle}>
        <div
          style={{
            "font-family": "var(--font-ui)",
            "font-size": "13px",
            "font-weight": 600,
            color: "var(--text-primary)",
          }}
        >
          {cardTitle}
        </div>
      </Show>
      <Show when={cardBody}>
        <div
          style={{
            "font-family": "var(--font-mono)",
            "font-size": "12px",
            color: "var(--text-secondary)",
            "line-height": "1.5",
            "white-space": "pre-wrap",
          }}
        >
          {cardBody}
        </div>
      </Show>
      <Show when={cardActions.length > 0}>
        <div style={{ display: "flex", gap: "8px", "margin-top": "4px" }}>
          <For each={cardActions}>
            {(action) => (
              <button
                onClick={() => handleAction(action.label, action.value)}
                style={{
                  background: action.variant === "primary" ? "var(--accent)" : "transparent",
                  color: action.variant === "primary" ? "var(--bg-primary)" : "var(--accent)",
                  border: action.variant === "primary" ? "none" : "1px solid var(--accent)",
                  padding: "4px 12px",
                  "border-radius": "4px",
                  "font-family": "var(--font-mono)",
                  "font-size": "11px",
                  cursor: "pointer",
                  transition: "opacity 0.15s",
                }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.opacity = "0.8"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.opacity = "1"; }}
              >
                {action.label}
              </button>
            )}
          </For>
        </div>
      </Show>
    </div>
  );

  return (
    <>
      {cards() ? (
        <div style={{ display: "flex", gap: "12px", "flex-wrap": "wrap" }}>
          <For each={cards()}>
            {(card) => renderSingleCard(card.title, card.body, card.actions ?? [])}
          </For>
        </div>
      ) : (
        renderSingleCard(title(), body(), actions())
      )}
    </>
  );
}
