import { For } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";
import { sendA2UIResponse } from "../../stores/a2uiStore";

interface A2UIButtonProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UIButton(props: A2UIButtonProps) {
  const label = () => (props.component.props.label as string) ?? "Button";
  const variant = () => (props.component.props.variant as string) ?? "default";
  const buttons = () => {
    // ButtonGroup: render multiple buttons from props.buttons
    const btns = props.component.props.buttons as Array<{ label: string; value?: string }> | undefined;
    return btns;
  };

  const handleClick = (buttonLabel: string, value?: string) => {
    sendA2UIResponse(props.sessionId, props.component.component_id, "click", {
      button: buttonLabel,
      value: value ?? buttonLabel,
    });
  };

  const buttonStyle = (v: string) => ({
    background: v === "primary" ? "var(--accent)" :
                v === "danger" ? "var(--red)" :
                "transparent",
    color: v === "primary" ? "var(--bg-primary)" :
           v === "danger" ? "#fff" :
           "var(--text-primary)",
    border: v === "primary" || v === "danger" ? "none" : "1px solid var(--border)",
    padding: "6px 16px",
    "border-radius": "4px",
    "font-family": "var(--font-mono)",
    "font-size": "12px",
    cursor: "pointer",
    transition: "opacity 0.15s",
  });

  return (
    <>
      {buttons() ? (
        <div style={{ display: "flex", gap: "8px", "flex-wrap": "wrap" }}>
          <For each={buttons()}>
            {(btn) => (
              <button
                style={buttonStyle((btn as Record<string, string>).variant ?? "default")}
                onClick={() => handleClick(btn.label, btn.value)}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.opacity = "0.8"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.opacity = "1"; }}
              >
                {btn.label}
              </button>
            )}
          </For>
        </div>
      ) : (
        <button
          style={buttonStyle(variant())}
          onClick={() => handleClick(label())}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.opacity = "0.8"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.opacity = "1"; }}
        >
          {label()}
        </button>
      )}
    </>
  );
}
