import { For, createSignal } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";
import { sendA2UIResponse } from "../../stores/a2uiStore";

interface A2UITableProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UITable(props: A2UITableProps) {
  const columns = () => (props.component.props.columns as string[]) ?? [];
  const rows = () => (props.component.props.rows as string[][]) ?? [];
  const selectable = () => (props.component.props.selectable as boolean) ?? false;

  const [sortCol, setSortCol] = createSignal<number | null>(null);
  const [sortAsc, setSortAsc] = createSignal(true);

  const sortedRows = () => {
    const col = sortCol();
    if (col === null) return rows();
    const asc = sortAsc();
    return [...rows()].sort((a, b) => {
      const va = a[col] ?? "";
      const vb = b[col] ?? "";
      const cmp = va.localeCompare(vb, undefined, { numeric: true });
      return asc ? cmp : -cmp;
    });
  };

  const handleSort = (colIndex: number) => {
    if (sortCol() === colIndex) {
      setSortAsc(!sortAsc());
    } else {
      setSortCol(colIndex);
      setSortAsc(true);
    }
  };

  const handleRowClick = (row: string[], rowIndex: number) => {
    if (!selectable()) return;
    sendA2UIResponse(props.sessionId, props.component.component_id, "select", {
      row,
      rowIndex,
    });
  };

  return (
    <div style={{ overflow: "auto", "max-height": "300px" }}>
      <table
        style={{
          width: "100%",
          "border-collapse": "collapse",
          "font-family": "var(--font-mono)",
          "font-size": "12px",
        }}
      >
        <thead>
          <tr>
            <For each={columns()}>
              {(col, i) => (
                <th
                  onClick={() => handleSort(i())}
                  style={{
                    "text-align": "left",
                    padding: "6px 12px",
                    "border-bottom": "1px solid var(--border)",
                    color: "var(--text-secondary)",
                    "font-weight": 600,
                    cursor: "pointer",
                    "user-select": "none",
                    "white-space": "nowrap",
                  }}
                >
                  {col}
                  {sortCol() === i() ? (sortAsc() ? " \u2191" : " \u2193") : ""}
                </th>
              )}
            </For>
          </tr>
        </thead>
        <tbody>
          <For each={sortedRows()}>
            {(row, rowIdx) => (
              <tr
                onClick={() => handleRowClick(row, rowIdx())}
                style={{
                  background: rowIdx() % 2 === 0 ? "transparent" : "rgba(255,255,255,0.02)",
                  cursor: selectable() ? "pointer" : "default",
                  transition: "background 0.1s",
                }}
                onMouseEnter={(e) => {
                  if (selectable()) (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background =
                    rowIdx() % 2 === 0 ? "transparent" : "rgba(255,255,255,0.02)";
                }}
              >
                <For each={row}>
                  {(cell) => (
                    <td
                      style={{
                        padding: "5px 12px",
                        "border-bottom": "1px solid rgba(41, 46, 66, 0.5)",
                        color: "var(--text-primary)",
                        "white-space": "nowrap",
                      }}
                    >
                      {cell}
                    </td>
                  )}
                </For>
              </tr>
            )}
          </For>
        </tbody>
      </table>
    </div>
  );
}
