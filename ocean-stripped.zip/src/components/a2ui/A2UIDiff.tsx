import { For } from "solid-js";
import type { A2UIComponent } from "../../stores/a2uiStore";

interface A2UIDiffProps {
  component: A2UIComponent;
  sessionId: string;
}

export default function A2UIDiff(props: A2UIDiffProps) {
  const diff = () => (props.component.props.diff as string) ?? "";
  const title = () => (props.component.props.title as string) ?? "Diff";

  const lines = () => diff().split("\n");

  const lineColor = (line: string): string => {
    if (line.startsWith("+++") || line.startsWith("---")) return "var(--text-muted)";
    if (line.startsWith("+")) return "var(--green)";
    if (line.startsWith("-")) return "var(--red)";
    if (line.startsWith("@@")) return "var(--blue)";
    return "var(--text-primary)";
  };

  const lineBg = (line: string): string => {
    if (line.startsWith("+") && !line.startsWith("+++")) return "rgba(158, 206, 106, 0.08)";
    if (line.startsWith("-") && !line.startsWith("---")) return "rgba(247, 118, 142, 0.08)";
    if (line.startsWith("@@")) return "rgba(122, 162, 247, 0.08)";
    return "transparent";
  };

  return (
    <div
      style={{
        background: "var(--bg-primary)",
        border: "1px solid var(--border)",
        "border-radius": "6px",
        overflow: "hidden",
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "4px 12px",
          background: "var(--bg-secondary)",
          "border-bottom": "1px solid var(--border)",
        }}
      >
        <span
          style={{
            "font-family": "var(--font-ui)",
            "font-size": "11px",
            color: "var(--text-muted)",
          }}
        >
          {title()}
        </span>
      </div>

      {/* Diff content */}
      <div style={{ overflow: "auto", "max-height": "400px", padding: "4px 0" }}>
        <For each={lines()}>
          {(line, i) => (
            <div
              style={{
                display: "flex",
                background: lineBg(line),
                "min-height": "20px",
              }}
            >
              <span
                style={{
                  "min-width": "40px",
                  "text-align": "right",
                  padding: "0 12px 0 8px",
                  color: "var(--text-muted)",
                  "font-family": "var(--font-mono)",
                  "font-size": "12px",
                  "line-height": "20px",
                  "user-select": "none",
                  "flex-shrink": 0,
                }}
              >
                {i() + 1}
              </span>
              <span
                style={{
                  "font-family": "var(--font-mono)",
                  "font-size": "12px",
                  "line-height": "20px",
                  color: lineColor(line),
                  "white-space": "pre",
                  "padding-right": "12px",
                }}
              >
                {line}
              </span>
            </div>
          )}
        </For>
      </div>
    </div>
  );
}
