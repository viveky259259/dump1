import { createStore } from "solid-js/store";

const STORAGE_KEY = "ocean:settings";

export interface OceanSettings {
  /** Target width in px when clicking the auto-resize icon on split panes */
  paneResizeWidth: number;
}

const DEFAULTS: OceanSettings = {
  paneResizeWidth: 800,
};

function loadFromStorage(): OceanSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULTS };
    return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULTS };
  }
}

const [settings, setSettings] = createStore<OceanSettings>(loadFromStorage());

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {}
}

export function updateSetting<K extends keyof OceanSettings>(key: K, value: OceanSettings[K]) {
  setSettings(key, value);
  persist();
}

export { settings };
