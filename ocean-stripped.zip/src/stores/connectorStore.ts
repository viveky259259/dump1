import { createSignal } from "solid-js";
import { listen } from "@tauri-apps/api/event";
import { invoke } from "@tauri-apps/api/core";

export interface ConnectorProcess {
  session_id: string | null;
  pid: number;
  name: string;
  status: string; // "running" | "stopped"
  port: number | null;
  cpu_percent: number | null;
  ram_bytes: number | null;
}

export interface ConnectorGroup {
  id: string;
  name: string;
  connector_type: string; // "flutter" | "node" | "docker" | "custom"
  sessions: ConnectorProcess[];
  health: string; // "healthy" | "degraded" | "down"
  metadata: Record<string, unknown>;
}

const [connectorGroups, setConnectorGroups] = createSignal<ConnectorGroup[]>(
  []
);

export { connectorGroups };

export function initConnectorListeners() {
  listen<ConnectorGroup[]>("connector-update", (event) => {
    setConnectorGroups(event.payload);
  });
}

export async function fetchConnectors(): Promise<ConnectorGroup[]> {
  return invoke("get_connectors");
}

export async function killConnectorGroup(groupId: string) {
  await invoke("kill_connector_group", { groupId });
}
