import { createSignal } from "solid-js";
import { listen } from "@tauri-apps/api/event";

export interface SystemMetrics {
  cpu_percent: number;
  ram_used_bytes: number;
  ram_total_bytes: number;
  swap_used_bytes: number;
  swap_total_bytes: number;
  battery_percent: number | null;
  battery_charging: boolean | null;
}

export interface NetworkStatus {
  connected: boolean;
  interface_type: string;
  latency_github_ms: number | null;
  latency_npm_ms: number | null;
}

export interface GitStatus {
  branch: string;
  ahead: number;
  behind: number;
  staged: number;
  modified: number;
  untracked: number;
  conflicted: number;
  ci_status: string | null;  // "success", "failure", "pending", "unknown", or null
  pr_number: number | null;
  pr_url: string | null;
}

const [systemMetrics, setSystemMetrics] = createSignal<SystemMetrics>({
  cpu_percent: 0,
  ram_used_bytes: 0,
  ram_total_bytes: 0,
  swap_used_bytes: 0,
  swap_total_bytes: 0,
  battery_percent: null,
  battery_charging: null,
});

const [networkStatus, setNetworkStatus] = createSignal<NetworkStatus>({
  connected: true,
  interface_type: "unknown",
  latency_github_ms: null,
  latency_npm_ms: null,
});

const [gitStatus, setGitStatus] = createSignal<GitStatus | null>(null);

export { systemMetrics, networkStatus, gitStatus };

// Track which repo paths we've already started watching
const watchedRepoPaths = new Set<string>();

export async function initMetricsListeners() {
  await listen<SystemMetrics>("metrics_update", (event) => {
    setSystemMetrics(event.payload);
  });

  await listen<NetworkStatus>("network_update", (event) => {
    setNetworkStatus(event.payload);
  });

  // git-status and cwd-git-detected events are handled by gitStore.ts (per-session)
  // Don't duplicate listeners here
}
