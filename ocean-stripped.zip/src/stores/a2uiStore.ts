import { createSignal } from "solid-js";
import { listen } from "@tauri-apps/api/event";
import { invoke } from "@tauri-apps/api/core";

export interface A2UIComponent {
  component_id: string;
  component_type: string;
  props: Record<string, unknown>;
  children: A2UIComponent[];
}

const sessionComponents = new Map<string, A2UIComponent[]>();
const [a2uiVersion, setA2UIVersion] = createSignal(0);

// Track which sessions have active listeners to avoid duplicates
const a2uiListeners = new Set<string>();

export function getA2UIComponents(sessionId: string): A2UIComponent[] {
  a2uiVersion(); // subscribe to reactive changes
  return sessionComponents.get(sessionId) ?? [];
}

export function initA2UIListener(sessionId: string) {
  if (a2uiListeners.has(sessionId)) return;
  a2uiListeners.add(sessionId);

  listen<A2UIComponent[]>(`a2ui-component-${sessionId}`, (event) => {
    const existing = sessionComponents.get(sessionId) ?? [];
    sessionComponents.set(sessionId, [...existing, ...event.payload]);
    setA2UIVersion((v) => v + 1);
  });
}

export async function sendA2UIResponse(
  sessionId: string,
  componentId: string,
  action: string,
  data: unknown,
) {
  await invoke("a2ui_respond", { sessionId, componentId, action, data });
}

export function clearA2UIComponents(sessionId: string) {
  sessionComponents.delete(sessionId);
  setA2UIVersion((v) => v + 1);
}

export function dismissA2UIComponent(sessionId: string, componentId: string) {
  const existing = sessionComponents.get(sessionId) ?? [];
  const filtered = existing.filter((c) => c.component_id !== componentId);
  if (filtered.length === 0) {
    sessionComponents.delete(sessionId);
  } else {
    sessionComponents.set(sessionId, filtered);
  }
  setA2UIVersion((v) => v + 1);
}
