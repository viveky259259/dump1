import { createStore, unwrap } from "solid-js/store";
import { logInfo, logDebug } from "./logStore";

const LAYOUT_STORAGE_KEY = "ocean:layout-groups";

export type LayoutDirection = "horizontal" | "vertical";

// Minimum size in pixels for each terminal pane
export const MIN_PANE_WIDTH = 400;
export const MIN_PANE_HEIGHT = 200;

export interface LeafNode {
  type: "leaf";
  sessionId: string;
}

export interface SplitNode {
  type: "split";
  direction: LayoutDirection;
  ratio: number; // 0-1, position of divider
  first: LayoutNode;
  second: LayoutNode;
}

export type LayoutNode = LeafNode | SplitNode;

export interface LayoutGroup {
  id: string;
  workspaceId: string;
  root: LayoutNode;
  focusedSessionId: string | null;
}

interface LayoutState {
  // Active view — consumed by TerminalArea (no changes needed there)
  root: LayoutNode | null;
  focusedSessionId: string | null;
  // Multi-group model
  groups: LayoutGroup[];
  activeGroupId: string | null;
}

const [state, setState] = createStore<LayoutState>({
  root: null,
  focusedSessionId: null,
  groups: [],
  activeGroupId: null,
});

let nextGroupId = 1;
function genGroupId(): string {
  return `g-${nextGroupId++}`;
}

// ── Sync helpers ────────────────────────────────────────────────

/** Deep clone a layout node to break SolidJS store proxy aliasing */
function cloneRoot(root: LayoutNode): LayoutNode {
  return JSON.parse(JSON.stringify(unwrap(root)));
}

/** Save current root/focused back to the active group */
function syncToActiveGroup() {
  const gid = state.activeGroupId;
  if (!gid || !state.root) return;
  const idx = state.groups.findIndex((g) => g.id === gid);
  if (idx === -1) return;
  setState("groups", idx, "root", cloneRoot(state.root));
  setState("groups", idx, "focusedSessionId", state.focusedSessionId);
}

/** Load a group's tree into the active view */
function loadGroup(group: LayoutGroup) {
  setState("root", cloneRoot(group.root));
  setState("focusedSessionId", group.focusedSessionId);
  setState("activeGroupId", group.id);
}

// ── Public API ──────────────────────────────────────────────────

/** Create a new layout group with a single session and make it active */
export function createGroup(sessionId: string, workspaceId?: string): string {
  // Save current group before switching
  syncToActiveGroup();

  const id = genGroupId();
  const group: LayoutGroup = {
    id,
    workspaceId: workspaceId ?? "",
    root: { type: "leaf", sessionId },
    focusedSessionId: sessionId,
  };

  logInfo("layout", `createGroup(${id}, session=${sessionId.slice(0, 8)})`);
  setState("groups", (prev) => [...prev, group]);
  loadGroup(group);
  persistLayout();
  return id;
}

/** Switch to an existing group by ID */
export function activateGroup(groupId: string) {
  if (groupId === state.activeGroupId) return;
  const group = state.groups.find((g) => g.id === groupId);
  if (!group) return;

  logInfo("layout", `activateGroup(${groupId})`);
  syncToActiveGroup();
  loadGroup(group);
  persistLayout();
}

/** Reset all layout state — used by clearAllAndRestart */
export function resetLayout() {
  setState("groups", []);
  setState("activeGroupId", null);
  setState("root", null);
  setState("focusedSessionId", null);
  localStorage.removeItem(LAYOUT_STORAGE_KEY);
  nextGroupId = 1;
}

/** Get groups for a specific workspace */
export function getGroupsForWorkspace(workspaceId: string): LayoutGroup[] {
  return state.groups.filter((g) => g.workspaceId === workspaceId);
}

/** Legacy: init with a single group */
export function initLayout(sessionId: string) {
  logInfo("layout", `initLayout(${sessionId.slice(0, 8)}...)`);
  resetLayout();
  createGroup(sessionId);
}

const MAX_PANES = 5;

/** Split a pane within the active group. No-op if already at MAX_PANES. */
export function splitPane(
  targetSessionId: string,
  newSessionId: string,
  direction: LayoutDirection
) {
  if (countLeaves(state.root) >= MAX_PANES) {
    logInfo("layout", `splitPane blocked — already at ${MAX_PANES} panes`);
    return;
  }

  logInfo("layout", `splitPane(target=${targetSessionId.slice(0, 8)}, new=${newSessionId.slice(0, 8)}, dir=${direction})`);

  let actualTarget = targetSessionId;
  if (state.root && !findSessionInTree(state.root, targetSessionId)) {
    const firstLeaf = findFirstLeaf(state.root);
    if (firstLeaf) {
      actualTarget = firstLeaf;
    }
  }

  setState("root", (root) => {
    if (!root) return root;
    return splitNode(root, actualTarget, newSessionId, direction);
  });
  setState("focusedSessionId", newSessionId);
  syncToActiveGroup();
  persistLayout();
}

/** Close a pane within the active group. Removes the group if empty. */
export function closePane(sessionId: string) {
  logInfo("layout", `closePane(${sessionId.slice(0, 8)}...)`);
  setState("root", (root) => {
    if (!root) return root;
    return removeNode(root, sessionId);
  });

  // If root became null, remove this group entirely
  if (!state.root) {
    const gid = state.activeGroupId;
    setState("groups", (prev) => prev.filter((g) => g.id !== gid));
    // Activate the next available group
    if (state.groups.length > 0) {
      loadGroup(state.groups[0]);
    } else {
      setState("activeGroupId", null);
      setState("focusedSessionId", null);
    }
  } else {
    // Update focused to first remaining leaf if current is gone
    if (state.focusedSessionId === sessionId) {
      setState("focusedSessionId", findFirstLeaf(state.root));
    }
    syncToActiveGroup();
  }
  persistLayout();
}

export function setFocusedSession(sessionId: string) {
  setState("focusedSessionId", sessionId);
  syncToActiveGroup();
}

/**
 * Switch the currently focused pane to show a different session.
 * If the session is already visible in a pane, just focus it.
 * Otherwise, replace the focused pane's session with the new one.
 */
export function switchToSession(sessionId: string) {
  logInfo("layout", `switchToSession(${sessionId.slice(0, 8)}...)`);

  // Check if this session is in ANY group — if so, activate that group
  for (const group of state.groups) {
    if (findSessionInTree(group.root, sessionId)) {
      activateGroup(group.id);
      setState("focusedSessionId", sessionId);
      syncToActiveGroup();
      persistLayout();
      return;
    }
  }

  // Session not in any group — replace focused pane in active group
  const focusedId = state.focusedSessionId;
  if (!focusedId || !state.root) {
    setState("root", { type: "leaf", sessionId });
    setState("focusedSessionId", sessionId);
    syncToActiveGroup();
    persistLayout();
    return;
  }

  setState("root", (root) => {
    if (!root) return root;
    return replaceSessionInTree(root, focusedId, sessionId);
  });
  setState("focusedSessionId", sessionId);
  syncToActiveGroup();
  persistLayout();
}

/** @deprecated Use updateSplitRatio instead */
export function updateRootRatio(ratio: number) {
  updateSplitRatio(null, ratio);
}

/**
 * Update the ratio of a specific split node in the tree.
 * `targetNode` identifies the split by matching its first child's leaf sessionId.
 * Pass null to update the root split (backward compat).
 */
export function updateSplitRatio(targetFirstLeafId: string | null, ratio: number) {
  const clamped = Math.max(0.15, Math.min(0.85, ratio));
  setState("root", (root) => {
    if (!root || root.type !== "split") return root;
    if (targetFirstLeafId === null) {
      return { ...root, ratio: clamped };
    }
    return updateRatioInTree(root, targetFirstLeafId, clamped);
  });
  syncToActiveGroup();
  persistLayout();
}

function updateRatioInTree(node: LayoutNode, targetFirstLeafId: string, ratio: number): LayoutNode {
  if (node.type === "leaf") return node;
  // Match: this split's first subtree contains the target leaf as its leftmost leaf
  if (findFirstLeaf(node.first) === targetFirstLeafId) {
    return { ...node, ratio };
  }
  return {
    ...node,
    first: updateRatioInTree(node.first, targetFirstLeafId, ratio),
    second: updateRatioInTree(node.second, targetFirstLeafId, ratio),
  };
}

/**
 * Resize a single pane to a fixed pixel width without affecting any other pane's size.
 *
 * Strategy:
 * 1. Compute every leaf's current px width from the tree ratios + container width
 * 2. Override only the target leaf's width
 * 3. Rebuild all ratios bottom-up from the new widths
 */
export function resizePaneToWidth(sessionId: string, targetWidth: number, containerPx: number) {
  if (!state.root || state.root.type !== "split") return;

  // Step 1: compute current leaf widths
  const widths = new Map<string, number>();
  computeLeafWidths(state.root, containerPx, widths);

  // Step 2: override the target
  if (!widths.has(sessionId)) return;
  widths.set(sessionId, targetWidth);

  // Step 3: rebuild tree with new ratios
  setState("root", (root) => {
    if (!root || root.type !== "split") return root;
    return rebuildRatios(root, widths);
  });
  syncToActiveGroup();
  persistLayout();
}

/** Walk the tree and record each leaf's current pixel width */
function computeLeafWidths(node: LayoutNode, availablePx: number, out: Map<string, number>) {
  if (node.type === "leaf") {
    out.set(node.sessionId, availablePx);
    return;
  }
  if (node.direction === "vertical") {
    const divider = 6;
    const usable = availablePx - divider;
    computeLeafWidths(node.first, usable * node.ratio, out);
    computeLeafWidths(node.second, usable * (1 - node.ratio), out);
  } else {
    // Horizontal split — both children get the full width (they stack vertically)
    computeLeafWidths(node.first, availablePx, out);
    computeLeafWidths(node.second, availablePx, out);
  }
}

/** Sum the desired widths of all leaves in a subtree */
function subtreeWidth(node: LayoutNode, widths: Map<string, number>): number {
  if (node.type === "leaf") {
    return widths.get(node.sessionId) ?? MIN_PANE_WIDTH;
  }
  if (node.direction === "vertical") {
    return subtreeWidth(node.first, widths) + 6 + subtreeWidth(node.second, widths);
  }
  // Horizontal — max of children
  return Math.max(subtreeWidth(node.first, widths), subtreeWidth(node.second, widths));
}

/** Rebuild ratios from desired leaf widths (bottom-up) */
function rebuildRatios(node: LayoutNode, widths: Map<string, number>): LayoutNode {
  if (node.type === "leaf") return node;

  const first = rebuildRatios(node.first, widths);
  const second = rebuildRatios(node.second, widths);

  if (node.direction === "vertical") {
    const fw = subtreeWidth(first, widths);
    const sw = subtreeWidth(second, widths);
    const total = fw + sw;
    const ratio = total > 0 ? Math.max(0.05, Math.min(0.95, fw / total)) : 0.5;
    return { ...node, ratio, first, second };
  }
  // Horizontal — ratio doesn't affect width, keep it
  return { ...node, first, second };
}

// ── Tree helpers (pure) ─────────────────────────────────────────

function splitNode(
  node: LayoutNode,
  targetSessionId: string,
  newSessionId: string,
  direction: LayoutDirection
): LayoutNode {
  if (node.type === "leaf") {
    if (node.sessionId === targetSessionId) {
      return {
        type: "split",
        direction,
        ratio: 0.5,
        first: { type: "leaf", sessionId: targetSessionId },
        second: { type: "leaf", sessionId: newSessionId },
      };
    }
    return node;
  }
  return {
    ...node,
    first: splitNode(node.first, targetSessionId, newSessionId, direction),
    second: splitNode(node.second, targetSessionId, newSessionId, direction),
  };
}

function removeNode(node: LayoutNode, sessionId: string): LayoutNode | null {
  if (node.type === "leaf") {
    return node.sessionId === sessionId ? null : node;
  }
  const first = removeNode(node.first, sessionId);
  const second = removeNode(node.second, sessionId);
  if (!first) return second;
  if (!second) return first;
  return { ...node, first, second };
}

function findFirstLeaf(node: LayoutNode): string | null {
  if (node.type === "leaf") return node.sessionId;
  return findFirstLeaf(node.first) ?? findFirstLeaf(node.second);
}

function findSessionInTree(node: LayoutNode, sessionId: string): boolean {
  if (node.type === "leaf") return node.sessionId === sessionId;
  return findSessionInTree(node.first, sessionId) || findSessionInTree(node.second, sessionId);
}

function replaceSessionInTree(node: LayoutNode, oldId: string, newId: string): LayoutNode {
  if (node.type === "leaf") {
    return node.sessionId === oldId ? { type: "leaf", sessionId: newId } : node;
  }
  return {
    ...node,
    first: replaceSessionInTree(node.first, oldId, newId),
    second: replaceSessionInTree(node.second, oldId, newId),
  };
}

/** Count total leaf panes in the tree */
export function countLeaves(node: LayoutNode | null): number {
  if (!node) return 0;
  if (node.type === "leaf") return 1;
  return countLeaves(node.first) + countLeaves(node.second);
}

/** Collect all leaf session IDs from a layout tree */
export function collectLeafIds(node: LayoutNode): string[] {
  if (node.type === "leaf") return [node.sessionId];
  return [...collectLeafIds(node.first), ...collectLeafIds(node.second)];
}

// ── Persistence ─────────────────────────────────────────────────

function persistLayout() {
  try {
    syncToActiveGroup();
    const data = JSON.stringify({
      groups: state.groups,
      activeGroupId: state.activeGroupId,
    });
    localStorage.setItem(LAYOUT_STORAGE_KEY, data);
  } catch {}
}

/**
 * Restore layout groups from localStorage.
 * `sessionToWorkspace` maps session IDs to their workspace IDs — used to
 * fix groups that were saved without a workspaceId (migration).
 */
export function restoreLayout(
  activeSessionIds: Set<string>,
  sessionToWorkspace?: Map<string, string>,
): boolean {
  try {
    const raw = localStorage.getItem(LAYOUT_STORAGE_KEY);
    if (!raw) return false;
    const { groups, activeGroupId } = JSON.parse(raw) as {
      groups: LayoutGroup[];
      activeGroupId: string | null;
    };
    if (!groups || groups.length === 0) return false;

    // Prune dead sessions from each group, drop empty groups
    const validGroups: LayoutGroup[] = [];
    for (const g of groups) {
      const pruned = pruneDeadSessions(g.root, activeSessionIds);
      if (pruned) {
        const focused = g.focusedSessionId && activeSessionIds.has(g.focusedSessionId)
          ? g.focusedSessionId
          : findFirstLeaf(pruned);
        // Preserve workspaceId, or infer from session data
        let wsId = g.workspaceId || "";
        if (!wsId && sessionToWorkspace) {
          const firstLeaf = findFirstLeaf(pruned);
          if (firstLeaf) wsId = sessionToWorkspace.get(firstLeaf) ?? "";
        }
        validGroups.push({ id: g.id, workspaceId: wsId, root: pruned, focusedSessionId: focused });
      }
    }
    if (validGroups.length === 0) return false;

    // Restore group ID counter
    nextGroupId = Math.max(nextGroupId, ...validGroups.map((g) => {
      const n = parseInt(g.id.replace("g-", ""), 10);
      return isNaN(n) ? 0 : n + 1;
    }));

    setState("groups", validGroups);
    const active = validGroups.find((g) => g.id === activeGroupId) ?? validGroups[0];
    loadGroup(active);

    logInfo("layout", `Restored ${validGroups.length} layout groups`);
    return true;
  } catch {
    return false;
  }
}

function pruneDeadSessions(node: LayoutNode, alive: Set<string>): LayoutNode | null {
  if (node.type === "leaf") {
    return alive.has(node.sessionId) ? node : null;
  }
  const first = pruneDeadSessions(node.first, alive);
  const second = pruneDeadSessions(node.second, alive);
  if (!first) return second;
  if (!second) return first;
  return { ...node, first, second };
}

export { state as layoutState };
