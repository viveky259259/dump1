import { createSignal } from "solid-js";
import { invoke } from "@tauri-apps/api/core";
import { logInfo, logError } from "./logStore";

export interface DeltaInfo {
  workspace_id: string;
  session_id: string;
  modified_files: string[];
  created_files: string[];
  deleted_files: string[];
  delta_size_bytes: number;
}

export interface MergeResult {
  merged_files: string[];
  deleted_files: string[];
  conflicts: string[];
  success: boolean;
}

export interface ConflictAlert {
  file_path: string;
  session_ids: string[];
  session_names: string[];
  severity: string;
}

export interface ShipResult {
  branch_name: string;
  pr_url: string | null;
  commit_hash: string;
  success: boolean;
  message: string;
}

export async function getSessionDelta(workspaceId: string, sessionId: string): Promise<DeltaInfo> {
  logInfo("session", `getSessionDelta(ws=${workspaceId.slice(0, 8)}, session=${sessionId.slice(0, 8)})`);
  return invoke("get_session_delta", { workspaceId, sessionId });
}

export async function mergeSession(workspaceId: string, sessionId: string): Promise<MergeResult> {
  logInfo("session", `mergeSession(ws=${workspaceId.slice(0, 8)}, session=${sessionId.slice(0, 8)})`);
  return invoke("merge_session", { workspaceId, sessionId });
}

export async function getConflicts(workspaceId: string): Promise<ConflictAlert[]> {
  logInfo("session", `getConflicts(ws=${workspaceId.slice(0, 8)})`);
  return invoke("get_conflicts", { workspaceId });
}

export async function translateToCommit(sessionId: string, message?: string): Promise<string> {
  logInfo("session", `translateToCommit(session=${sessionId.slice(0, 8)})`);
  return invoke("translate_to_commit", { sessionId, message: message ?? null });
}

export async function shipWorkspace(workspaceId: string, title: string): Promise<ShipResult> {
  logInfo("session", `shipWorkspace(ws=${workspaceId.slice(0, 8)}, title="${title}")`);
  return invoke("ship_workspace", { workspaceId, title });
}

// Active conflicts signal
const [activeConflicts, setActiveConflicts] = createSignal<ConflictAlert[]>([]);
export { activeConflicts };

export function clearConflict(filePath: string) {
  setActiveConflicts((prev) => prev.filter((c) => c.file_path !== filePath));
}

export function clearAllConflicts() {
  setActiveConflicts([]);
}

let conflictListenerInitialized = false;

export function initConflictListener() {
  if (conflictListenerInitialized) return;
  conflictListenerInitialized = true;
  logInfo("frontend", "initConflictListener — setting up conflict polling + event listener");

  // Listen for backend-emitted conflict events
  import("@tauri-apps/api/event").then(({ listen }) => {
    listen<ConflictAlert>("conflict-detected", (event) => {
      logInfo("frontend", `Conflict detected (event): ${event.payload.file_path}`);
      setActiveConflicts((prev) => {
        const existing = prev.findIndex((c) => c.file_path === event.payload.file_path);
        if (existing >= 0) {
          const updated = [...prev];
          updated[existing] = event.payload;
          return updated;
        }
        return [...prev, event.payload];
      });
    });
  }).catch((err) => {
    logError("frontend", `Failed to init conflict listener: ${err}`);
  });

  // Poll for conflicts every 10 seconds for repo workspaces
  setInterval(async () => {
    try {
      const { sessionState } = await import("./sessionStore");
      const wsId = sessionState.activeWorkspaceId;
      if (!wsId) return;

      // Only check repo workspaces
      const ws = sessionState.workspaces.find((w) => w.id === wsId);
      if (!ws?.repo_path) return;

      // Check for active sessions (need at least 2 for conflicts)
      const sessions = sessionState.sessions[wsId];
      const activeSessions = sessions?.filter(
        (s) => s.status === "active" || s.status === "idle" || s.status === "waiting"
      );
      if (!activeSessions || activeSessions.length < 2) return;

      const conflicts = await getConflicts(wsId);
      if (conflicts.length > 0) {
        logInfo("frontend", `Conflict poll: found ${conflicts.length} conflicts`);
        setActiveConflicts(conflicts);
      } else if (activeConflicts().length > 0) {
        // Clear stale conflicts
        setActiveConflicts([]);
      }
    } catch {
      // Silently ignore polling errors
    }
  }, 10000);
}
