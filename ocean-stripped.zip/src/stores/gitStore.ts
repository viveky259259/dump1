import { createSignal } from "solid-js";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import { logInfo, logDebug } from "./logStore";

export interface GitStatus {
  branch: string;
  ahead: number;
  behind: number;
  staged: number;
  modified: number;
  untracked: number;
  conflicted: number;
  ci_status: string | null;
  pr_number: number | null;
  pr_url: string | null;
}

interface SessionGitState {
  status: GitStatus | null;
  loading: boolean;
  repoPath: string | null;
}

// Per-session git state — keyed by sessionId, never shared between sessions
const sessionGitMap = new Map<string, SessionGitState>();
const [gitVersion, setGitVersion] = createSignal(0);

// Track which repos are already being watched
const watchedRepos = new Set<string>();

// Map repo path -> set of session IDs using that repo
const repoToSessions = new Map<string, Set<string>>();

export function getSessionGit(sessionId: string): SessionGitState {
  gitVersion(); // subscribe to changes
  return sessionGitMap.get(sessionId) ?? { status: null, loading: false, repoPath: null };
}

async function fetchGitStatus(sessionId: string, repoPath: string) {
  const current = sessionGitMap.get(sessionId) ?? { status: null, loading: false, repoPath: null };
  sessionGitMap.set(sessionId, { ...current, loading: true, repoPath });
  setGitVersion((v) => v + 1);

  try {
    const status = await invoke<GitStatus>("get_git_status", { repoPath });
    // Only update THIS session — don't touch others
    sessionGitMap.set(sessionId, { status, loading: false, repoPath });
  } catch (e) {
    sessionGitMap.set(sessionId, { ...current, loading: false, repoPath });
  }
  setGitVersion((v) => v + 1);
}

export function initGitListeners() {
  // When a session's CWD enters a git repo
  listen<{ session_id: string; repo_path: string }>("cwd-git-detected", async (event) => {
    const { session_id, repo_path } = event.payload;
    logInfo("frontend", `Git repo detected for session ${session_id.slice(0, 8)}: ${repo_path}`);

    // Track which sessions use which repo
    if (!repoToSessions.has(repo_path)) {
      repoToSessions.set(repo_path, new Set());
    }
    repoToSessions.get(repo_path)!.add(session_id);

    // Fetch git status for THIS session only
    await fetchGitStatus(session_id, repo_path);

    // Start watching if not already
    if (!watchedRepos.has(repo_path)) {
      watchedRepos.add(repo_path);
      try {
        await invoke("watch_git_repo", { repoPath: repo_path });
      } catch {
        // ok
      }
    }
  });

  // When git watcher emits updates, only refresh sessions using THAT specific repo
  listen<GitStatus>("git-status", (event) => {
    const newStatus = event.payload;

    // Find which repo this update is for by matching the branch name
    // against sessions that have a status with the same branch
    for (const [sid, state] of sessionGitMap.entries()) {
      if (!state.repoPath || !state.status) continue;

      // Only update if the branch matches — this prevents cross-repo contamination
      if (state.status.branch === newStatus.branch) {
        sessionGitMap.set(sid, { ...state, status: newStatus, loading: false });
      }
    }
    setGitVersion((v) => v + 1);
  });
}

export function clearSessionGit(sessionId: string) {
  // Remove from repo tracking
  for (const [, sessions] of repoToSessions.entries()) {
    sessions.delete(sessionId);
  }
  sessionGitMap.delete(sessionId);
  setGitVersion((v) => v + 1);
}

export async function refreshSessionGit(sessionId: string) {
  const state = sessionGitMap.get(sessionId);
  if (state?.repoPath) {
    await fetchGitStatus(sessionId, state.repoPath);
  }
}
