import { createSignal } from "solid-js";
import { terminalCache } from "../components/terminal/TerminalPane";

// Saved scrollback content per session
const scrollbackMap = new Map<string, string>();
const [scrollbackVersion, setScrollbackVersion] = createSignal(0);

/**
 * Capture the full scrollback content from a live terminal before it's disposed.
 * Call this BEFORE disposeTerminal().
 */
export function captureScrollback(sessionId: string): void {
  const cached = terminalCache.get(sessionId);
  if (!cached) return;

  const terminal = cached.terminal;
  const buffer = terminal.buffer.active;
  const lines: string[] = [];

  // Read every line from the buffer (scrollback + visible)
  const totalLines = buffer.baseY + terminal.rows;
  for (let i = 0; i <= totalLines; i++) {
    const line = buffer.getLine(i);
    if (line) {
      lines.push(line.translateToString(true));
    }
  }

  // Trim trailing empty lines
  while (lines.length > 0 && lines[lines.length - 1].trim() === "") {
    lines.pop();
  }

  const content = lines.join("\n");
  if (content.trim().length > 0) {
    scrollbackMap.set(sessionId, content);
    setScrollbackVersion((v) => v + 1);
  }
}

/**
 * Get saved scrollback for a closed session.
 */
export function getScrollback(sessionId: string): string | null {
  scrollbackVersion(); // reactive
  return scrollbackMap.get(sessionId) ?? null;
}

/**
 * Check if scrollback exists for a session.
 */
export function hasScrollback(sessionId: string): boolean {
  scrollbackVersion();
  return scrollbackMap.has(sessionId);
}
