import { createSignal } from "solid-js";
import { listen } from "@tauri-apps/api/event";
import { invoke } from "@tauri-apps/api/core";

export interface AnnotationAction {
  label: string;
  icon: string;
  command: string;
  shortcut: string | null;
}

export interface Annotation {
  id: number;
  session_id: string;
  line: number;
  col_start: number;
  col_end: number;
  annotation_type: "FilePath" | "Url" | "Error" | "GitRef" | "NetworkAddr" | "TestResult";
  value: string;
  metadata: Record<string, unknown>;
  actions: AnnotationAction[];
}

// Per-session annotation storage
const annotationsBySession = new Map<string, Annotation[]>();
// Signal to trigger re-renders when annotations change
const [annotationVersion, setAnnotationVersion] = createSignal(0);

export function initAnnotationListener(sessionId: string) {
  listen<Annotation[]>(`annotations-${sessionId}`, (event) => {
    const existing = annotationsBySession.get(sessionId) ?? [];
    // Append new annotations, keep last 5000
    const merged = [...existing, ...event.payload].slice(-5000);
    annotationsBySession.set(sessionId, merged);
    setAnnotationVersion((v) => v + 1); // trigger reactivity
  });
}

export function getAnnotationsForViewport(
  sessionId: string,
  lineStart: number,
  lineEnd: number
): Annotation[] {
  annotationVersion(); // subscribe to changes
  const all = annotationsBySession.get(sessionId) ?? [];
  // Widen the range a bit to account for line counting mismatches
  // between the PTY output counter and xterm.js buffer
  return all.filter((a) => a.line >= lineStart - 5 && a.line <= lineEnd + 5);
}

export function getAllAnnotations(sessionId: string): Annotation[] {
  annotationVersion();
  return annotationsBySession.get(sessionId) ?? [];
}

export async function executeAction(command: string) {
  // "View in Ocean" — show file in the in-app overlay viewer
  if (command.startsWith("view_in_ocean:")) {
    const rest = command.slice("view_in_ocean:".length);
    const parts = rest.split(":");
    const filePath = parts[0];
    const line = parts[1] ? parseInt(parts[1], 10) : undefined;

    const { showFileViewer } = await import("./uiStore");
    showFileViewer(filePath, line);
    return;
  }

  // "Open in Editor" — delegate to backend (opens $EDITOR / VS Code)
  await invoke("execute_annotation_action", { actionCommand: command });
}

export function clearAnnotations(sessionId: string) {
  annotationsBySession.delete(sessionId);
  setAnnotationVersion((v) => v + 1);
}
