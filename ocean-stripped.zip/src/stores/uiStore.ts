import { createSignal } from "solid-js";

// Sidebar visibility
const [sidebarVisible, setSidebarVisible] = createSignal(true);

export function toggleSidebar() {
  setSidebarVisible((v) => !v);
}

export { sidebarVisible };

// Debug console visibility
const [debugConsoleVisible, setDebugConsoleVisible] = createSignal(false);

export function toggleDebugConsole() {
  setDebugConsoleVisible((v) => !v);
}

export { debugConsoleVisible };

// Scrollback viewer state
export interface ScrollbackViewerState {
  sessionId: string;
  sessionName: string;
  exitCode: number | null;
}

const [scrollbackViewer, setScrollbackViewer] =
  createSignal<ScrollbackViewerState | null>(null);

export function showScrollbackViewer(
  sessionId: string,
  sessionName: string,
  exitCode: number | null | undefined
) {
  // Force remount by setting null first, then the new value on next microtask
  // This ensures SolidJS destroys the old ScrollbackViewer and creates a new one
  setScrollbackViewer(null);
  queueMicrotask(() => {
    setScrollbackViewer({
      sessionId,
      sessionName,
      exitCode: exitCode ?? null,
    });
  });
}

export function hideScrollbackViewer() {
  setScrollbackViewer(null);
}

export { scrollbackViewer };

// Merge panel state
export interface MergePanelState {
  workspaceId: string;
  sessionId: string;
  sessionName: string;
}

const [mergePanelState, setMergePanelState] = createSignal<MergePanelState | null>(null);

export function showMergePanel(workspaceId: string, sessionId: string, sessionName: string) {
  setMergePanelState({ workspaceId, sessionId, sessionName });
}

export function hideMergePanel() {
  setMergePanelState(null);
}

export { mergePanelState };

// Ship dialog state
export interface ShipDialogState {
  workspaceId: string;
  workspaceName: string;
}

const [shipDialogState, setShipDialogState] = createSignal<ShipDialogState | null>(null);

export function showShipDialog(workspaceId: string, workspaceName: string) {
  setShipDialogState({ workspaceId, workspaceName });
}

export function hideShipDialog() {
  setShipDialogState(null);
}

export { shipDialogState };

// Connector bar visibility (toggle with Cmd+K)
const [connectorBarVisible, setConnectorBarVisible] = createSignal(true);

export function toggleConnectorBar() {
  setConnectorBarVisible((v) => !v);
}

export { connectorBarVisible };

// File viewer state
export interface FileViewerState {
  filePath: string;
  line?: number;
}

const [fileViewer, setFileViewer] = createSignal<FileViewerState | null>(null);

export function showFileViewer(filePath: string, line?: number) {
  setFileViewer({ filePath, line });
}

export function hideFileViewer() {
  setFileViewer(null);
}

export { fileViewer };

// Command palette
const [commandPaletteVisible, setCommandPaletteVisible] = createSignal(false);
export function showCommandPalette() { setCommandPaletteVisible(true); }
export function hideCommandPalette() { setCommandPaletteVisible(false); }
export { commandPaletteVisible };

// Quick session switcher
const [quickSwitcherVisible, setQuickSwitcherVisible] = createSignal(false);
export function showQuickSwitcher() { setQuickSwitcherVisible(true); }
export function hideQuickSwitcher() { setQuickSwitcherVisible(false); }
export { quickSwitcherVisible };

// Settings panel
const [settingsVisible, setSettingsVisible] = createSignal(false);
export function showSettings() { setSettingsVisible(true); }
export function hideSettings() { setSettingsVisible(false); }
export function toggleSettings() { setSettingsVisible((v) => !v); }
export { settingsVisible };

// DAG view
const [dagViewVisible, setDagViewVisible] = createSignal(false);
export function showDAGView() { setDagViewVisible(true); }
export function hideDAGView() { setDagViewVisible(false); }
export function toggleDAGView() { setDagViewVisible((v) => !v); }
export { dagViewVisible };
