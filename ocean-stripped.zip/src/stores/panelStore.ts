import { createSignal } from "solid-js";

export type PanelType = "system" | "network" | "git" | null;

const [activePanel, setActivePanel] = createSignal<PanelType>(null);

export function togglePanel(panel: PanelType) {
  setActivePanel((current) => (current === panel ? null : panel));
}

export function closePanel() {
  setActivePanel(null);
}

export { activePanel };
