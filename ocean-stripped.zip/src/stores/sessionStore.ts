import { createStore } from "solid-js/store";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import { logInfo, logError, logDebug, logWarn } from "./logStore";

export interface Workspace {
  id: string;
  name: string;
  created_at: string;
  archived_at: string | null;
  repo_path: string | null;
  base_snapshot_path: string | null;
  base_commit: string | null;
  git_branch: string | null;
  git_pr_url: string | null;
}

export interface Session {
  id: string;
  workspace_id: string;
  parent_id: string | null;
  name: string;
  session_type: string;
  status: string;
  pty_id: string | null;
  process_pid: number | null;
  created_at: string;
  ended_at: string | null;
  exit_code: number | null;
}

export interface SessionTreeNode {
  session: Session;
  children: SessionTreeNode[];
}

interface SessionStoreState {
  workspaces: Workspace[];
  sessions: Record<string, Session[]>;
  sessionTree: Record<string, SessionTreeNode[]>;
  activeWorkspaceId: string | null;
  activeSessionId: string | null;
}

const [state, setState] = createStore<SessionStoreState>({
  workspaces: [],
  sessions: {},
  sessionTree: {},
  activeWorkspaceId: null,
  activeSessionId: null,
});

let sessionCounter = 0;

export function getNextSessionName(): string {
  sessionCounter++;
  return `Shell ${sessionCounter}`;
}

export async function loadWorkspaces() {
  logDebug("session", "loadWorkspaces()");
  const workspaces = await invoke<Workspace[]>("list_workspaces");
  logInfo("session", `Loaded ${workspaces.length} workspaces`);
  setState("workspaces", workspaces);
  return workspaces;
}

export async function createWorkspace(name: string): Promise<Workspace> {
  logInfo("session", `createWorkspace("${name}")`);
  const workspace = await invoke<Workspace>("create_workspace", { name });
  logInfo("session", `Workspace created: ${workspace.id}`);
  setState("workspaces", (prev) => [...prev, workspace]);
  return workspace;
}

export async function createWorkspaceWithRepo(name: string, repoPath: string): Promise<Workspace> {
  logInfo("session", `createWorkspaceWithRepo("${name}", "${repoPath}")`);
  const workspace = await invoke<Workspace>("create_workspace_with_repo", { name, repoPath });
  logInfo("session", `Workspace with repo created: ${workspace.id} repo=${repoPath}`);
  setState("workspaces", (prev) => [...prev, workspace]);
  return workspace;
}

export async function loadSessions(workspaceId: string) {
  logDebug("session", `loadSessions(${workspaceId.slice(0, 8)}...)`);
  const sessions = await invoke<Session[]>("list_sessions", {
    workspaceId,
  });
  logInfo("session", `Loaded ${sessions.length} sessions`, sessions.map(s => ({ id: s.id.slice(0, 8), name: s.name, status: s.status })));
  setState("sessions", workspaceId, sessions);
  return sessions;
}

export async function loadSessionTree(workspaceId: string) {
  logDebug("session", `loadSessionTree(${workspaceId.slice(0, 8)}...)`);
  const tree = await invoke<SessionTreeNode[]>("get_session_tree", {
    workspaceId,
  });
  logInfo("session", `Session tree: ${tree.length} root nodes`);
  setState("sessionTree", workspaceId, tree);
  return tree;
}

export async function createSession(
  workspaceId: string,
  parentId?: string,
  name?: string
): Promise<Session> {
  const sessionName = name ?? getNextSessionName();
  logInfo("session", `createSession(ws=${workspaceId.slice(0, 8)}, parent=${parentId?.slice(0, 8) ?? "none"}, name="${sessionName}")`);
  try {
    const session = await invoke<Session>("create_session", {
      workspaceId,
      parentId: parentId ?? null,
      name: sessionName,
    });

    logInfo("session", `Session created: ${session.id.slice(0, 8)} pid=${session.process_pid}`, { id: session.id, status: session.status });

    setState("sessions", workspaceId, (prev) =>
      prev ? [...prev, session] : [session]
    );

    await loadSessionTree(workspaceId);
    return session;
  } catch (e) {
    logError("session", `createSession failed: ${e}`);
    throw e;
  }
}

export async function closeSession(sessionId: string) {
  logInfo("session", `closeSession(${sessionId.slice(0, 8)}...)`);
  try {
    await invoke("close_session", { sessionId });
  } catch (e) {
    logError("session", `closeSession IPC failed: ${e}`);
  }

  const workspaceId = state.activeWorkspaceId;
  if (workspaceId) {
    // Mark as completed locally (don't remove — it moves to Closed section)
    setState("sessions", workspaceId, (prev) =>
      prev
        ? prev.map((s) =>
            s.id === sessionId ? { ...s, status: "completed" } : s
          )
        : []
    );
    await loadSessionTree(workspaceId);
  }

  if (state.activeSessionId === sessionId) {
    const remaining =
      workspaceId && state.sessions[workspaceId]
        ? state.sessions[workspaceId].filter(
            (s) => s.id !== sessionId && (s.status === "active" || s.status === "idle")
          )
        : [];
    const nextId = remaining[0]?.id ?? null;
    logInfo("session", `Active session closed, switching to: ${nextId?.slice(0, 8) ?? "none"}`);
    setState("activeSessionId", nextId);
  }
}

export function setActiveWorkspace(id: string) {
  logDebug("session", `setActiveWorkspace(${id.slice(0, 8)}...)`);
  setState("activeWorkspaceId", id);
}

export function setActiveSession(id: string) {
  logInfo("session", `setActiveSession(${id.slice(0, 8)}...)`);
  setState("activeSessionId", id);
}

/** Default shell name pattern — sessions matching this are considered "unnamed" */
const UNNAMED_PATTERN = /^Shell(\s+\d+)?$/;

/**
 * Clear unnamed shells and closed sessions. Named sessions are kept alive.
 * If no named sessions remain, creates a fresh "Shell" session.
 */
export async function clearAllAndRestart(): Promise<void> {
  const wsId = state.activeWorkspaceId;
  if (!wsId) return;

  const sessions = state.sessions[wsId] ?? [];
  const { closePane, resetLayout, createGroup, collectLeafIds, layoutState } = await import("./layoutStore");
  const { disposeTerminal } = await import("../components/terminal/TerminalPane");
  const { captureScrollback } = await import("./scrollbackStore");

  const toClose: Session[] = [];
  const toKeep: Session[] = [];

  for (const s of sessions) {
    const isClosed = s.status === "completed" || s.status === "failed" || s.status === "archived";
    const isUnnamed = UNNAMED_PATTERN.test(s.name);
    const isLive = s.status === "active" || s.status === "idle" || s.status === "waiting";

    if (isClosed || (isLive && isUnnamed)) {
      toClose.push(s);
    } else if (isLive) {
      toKeep.push(s);
    }
  }

  // Close the targeted sessions
  for (const s of toClose) {
    const isLive = s.status === "active" || s.status === "idle" || s.status === "waiting";
    if (isLive) {
      captureScrollback(s.id);
      closePane(s.id);
      disposeTerminal(s.id);
    }
    try {
      await invoke("close_session", { sessionId: s.id });
    } catch {}
  }

  // Reload from backend
  await loadSessions(wsId);
  await loadSessionTree(wsId);

  // Rebuild layout groups for kept sessions
  resetLayout();

  if (toKeep.length > 0) {
    for (const s of toKeep) {
      createGroup(s.id, wsId);
    }
    setActiveSession(toKeep[0].id);
  } else {
    // Nothing kept — create a fresh shell
    const session = await invoke<Session>("create_session", {
      workspaceId: wsId,
      parentId: null,
      name: "Shell",
    });
    setState("sessions", wsId, (prev) => prev ? [...prev, session] : [session]);
    await loadSessionTree(wsId);
    setActiveSession(session.id);
    createGroup(session.id, wsId);
  }
}

interface StatusChange {
  session_id: string;
  old_status: string;
  new_status: string;
}

/**
 * Initialize a Tauri event listener for session status changes.
 * Call this once from App.tsx onMount.
 */
export function initSessionStatusListener() {
  // Listen for AI tool detection — update session name to include AI badge
  listen<{ session_id: string; ai_tool: string }>("ai-detected", (event) => {
    const { session_id, ai_tool } = event.payload;
    logInfo("session", `AI detected in session ${session_id.slice(0, 8)}: ${ai_tool}`);

    // Update session_type to "agent" in local state so the pane header shows the AI badge
    const workspaceIds = Object.keys(state.sessions);
    for (const wid of workspaceIds) {
      const sessions = state.sessions[wid];
      if (!sessions) continue;
      const idx = sessions.findIndex((s) => s.id === session_id);
      if (idx !== -1 && sessions[idx].session_type === "shell") {
        setState("sessions", wid, idx, "session_type", "agent");
      }
    }
  });

  // Debounce tree reloads — multiple rapid status changes coalesce into one reload per workspace
  const pendingTreeReloads = new Map<string, ReturnType<typeof setTimeout>>();

  listen<StatusChange>("session-status-changed", (event) => {
    const { session_id, new_status } = event.payload;

    // Update status in the flat sessions record for all workspaces
    const workspaceIds = Object.keys(state.sessions);
    for (const wid of workspaceIds) {
      const sessions = state.sessions[wid];
      if (!sessions) continue;

      const idx = sessions.findIndex((s) => s.id === session_id);
      if (idx !== -1) {
        setState("sessions", wid, idx, "status", new_status);
        // Debounced tree reload — coalesces rapid status bursts into one backend call
        const existing = pendingTreeReloads.get(wid);
        if (existing) clearTimeout(existing);
        pendingTreeReloads.set(wid, setTimeout(() => {
          pendingTreeReloads.delete(wid);
          loadSessionTree(wid);
        }, 300));
      }
    }
  });
}

export { state as sessionState };
