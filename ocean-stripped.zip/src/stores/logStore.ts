import { createSignal } from "solid-js";

export type LogLevel = "debug" | "info" | "warn" | "error";
export type LogSource = "frontend" | "backend" | "ipc" | "pty" | "layout" | "session" | "metrics" | "annotation";

export interface LogEntry {
  id: number;
  timestamp: string;
  level: LogLevel;
  source: LogSource;
  message: string;
  data?: unknown;
}

const MAX_LOGS = 500;
let logId = 0;
let logEntries: LogEntry[] = [];
const [logVersion, setLogVersion] = createSignal(0);

function now(): string {
  return new Date().toISOString().slice(11, 23); // HH:mm:ss.SSS
}

export function log(level: LogLevel, source: LogSource, message: string, data?: unknown) {
  const entry: LogEntry = {
    id: ++logId,
    timestamp: now(),
    level,
    source,
    message,
    data,
  };

  logEntries.push(entry);
  if (logEntries.length > MAX_LOGS) {
    logEntries = logEntries.slice(-MAX_LOGS);
  }

  setLogVersion((v) => v + 1);

  // Also log to browser console for dev tools
  const prefix = `[${entry.timestamp}] [${source}]`;
  switch (level) {
    case "error": console.error(prefix, message, data ?? ""); break;
    case "warn": console.warn(prefix, message, data ?? ""); break;
    case "info": console.info(prefix, message, data ?? ""); break;
    default: console.debug(prefix, message, data ?? "");
  }
}

export function getLogs(filter?: { level?: LogLevel; source?: LogSource }): LogEntry[] {
  logVersion(); // subscribe to changes
  let result = logEntries;
  if (filter?.level) {
    result = result.filter((e) => e.level === filter.level);
  }
  if (filter?.source) {
    result = result.filter((e) => e.source === filter.source);
  }
  return result;
}

export function clearLogs() {
  logEntries = [];
  setLogVersion((v) => v + 1);
}

// Convenience helpers
export const logDebug = (source: LogSource, msg: string, data?: unknown) => log("debug", source, msg, data);
export const logInfo = (source: LogSource, msg: string, data?: unknown) => log("info", source, msg, data);
export const logWarn = (source: LogSource, msg: string, data?: unknown) => log("warn", source, msg, data);
export const logError = (source: LogSource, msg: string, data?: unknown) => log("error", source, msg, data);
