# Phase 2: PLAN — Ocean Design Document

## 1. Product Vision

**Ocean** is the terminal reimagined as a control plane for agentic development.

Traditional terminals are built around a paradigm: human types command → shell executes → output streams. Agentic coding flips this: multiple AI agents execute autonomously, spawn sub-tasks, run parallel processes, and produce rich output that demands human oversight, not human typing.

Ocean doesn't add AI to a terminal. It builds a terminal around AI workflows.

### Design Principles

1. **Tasks, not tabs.** Sessions are grouped by what you're working on, not by when you opened them.
2. **Sessions are code state.** Spawning a session forks the codebase. Completing a session merges it back. The Session DAG is the version graph for the agentic working phase — git handles the rest.
3. **Ambient awareness.** Git status, system health, network state, agent status — always visible, never queried.
4. **Output is interactive.** Every file path, URL, error, and stack trace is clickable and actionable.
5. **Agents are first-class.** Agent sessions have lifecycle management, heartbeats, and semantic relationships.
6. **Progressive disclosure.** Simple by default (looks like a great terminal), powerful on demand (reveals the full orchestration surface).

---

## 2. Feature Architecture

### 2.1 Session DAG — Ocean's Core Primitive

The Session DAG is not just a UI feature — it is **Ocean's central nervous system**. Each session in the DAG has both a terminal AND a filesystem layer. Spawning a child session forks the parent's code state via copy-on-write. The DAG is simultaneously the session graph, the version graph, and the isolation layer.

**The fundamental insight:** Git was designed for sequential human intent (branch → commit → merge). Agentic development is parallel autonomous mutation. Git worktrees are a workaround that costs ~2GB per agent, requires `npm install` per worktree, causes port conflicts, and detects conflicts only at merge time. The Session DAG replaces this entire pattern.

```
                    ┌─────────────────────────┐
                    │  Workspace: "Auth Fix"   │
                    │  base_state: repo@abc123 │ ◄── snapshot of repo (read-only)
                    └───────────┬──────────────┘
                                │
              ┌─────────────────┼─────────────────┐
              │ fork            │ fork             │ fork
              ▼                 ▼                  ▼
        ┌───────────────┐ ┌───────────┐ ┌────────────────┐
        │ Session 1      │ │ Session 2  │ │ Session 3       │
        │ Claude Agent   │ │ Dev Server │ │ Test Watcher    │
        │ COW layer: Δ1  │ │ (shared)   │ │ COW layer: Δ3   │
        │ Δ: 3 files     │ │ no writes  │ │ Δ: 1 file       │
        └──────┬─────┬──┘ └───────────┘ └────────────────┘
               │     │
          fork │     │ fork
               ▼     ▼
        ┌─────────┐ ┌──────────┐
        │ Child 1  │ │ Child 2   │
        │ Sub-agent│ │ Build     │
        │ COW: Δ1a │ │ COW: Δ1b  │   ◄── stacked on Δ1
        │ reads Δ1 │ │ reads Δ1  │       (sees parent's changes)
        └─────────┘ └──────────┘
```

#### 2.1.1 How Code State Isolation Works

Each session sees a layered filesystem:

```
Read path (bottom-up):    Write path:
┌──────────────┐          ┌──────────────┐
│ Session delta │ ◄─ 1st  │ Session delta │ ◄── ALL writes go here
├──────────────┤          └──────────────┘
│ Parent delta  │ ◄─ 2nd  (copy-on-write: file copied
├──────────────┤           to delta on first write)
│ Base snapshot │ ◄─ 3rd
└──────────────┘
```

- **Base layer**: Read-only snapshot of the repo at workspace creation time
- **Delta layer**: Per-session, stores only modified/created/deleted files
- **Stacked deltas**: Child sessions read through parent's delta, then base. Writes always go to their own delta.

**Cost comparison with git worktrees:**

| | Git Worktrees | Session DAG + COW |
|---|---|---|
| Isolation cost | Full directory copy (~2GB) | Only deltas (~KB-MB) |
| Setup time | `git worktree add` + `npm install` (minutes) | Instant (COW overlay, shared `node_modules`) |
| Branching | Explicit: name it, track it, clean it | Implicit: spawn session = fork state |
| Merging | `git merge` (text-level, dumb) | Task-aware: Ocean knows what each agent did |
| Conflict detection | At merge time (too late) | **Real-time**: Ocean watches all deltas |
| Dependencies | Separate per worktree | Shared base (read-only `node_modules/`) |
| Port management | Manual / collisions | Ocean auto-assigns ports per session |
| Cleanup | Manual `git worktree remove` | Session ends → delta discarded or promoted |

#### 2.1.2 Real-Time Conflict Detection (Killer Feature)

Because Ocean controls the filesystem layer, it knows **in real-time** when two sessions modify the same file — before merge, before commit, the moment it happens:

```
┌─ Ocean Conflict Alert ────────────────────────────────────┐
│                                                           │
│  ⚠ OVERLAP DETECTED                                      │
│                                                           │
│  Agent 1 (auth middleware) and Agent 2 (session handler)  │
│  are both modifying:                                      │
│                                                           │
│    src/auth/session.ts                                    │
│    ├── Agent 1: lines 42-67 (token validation)           │
│    └── Agent 2: lines 55-80 (session expiry)             │
│                                                           │
│  Overlapping region: lines 55-67                          │
│                                                           │
│  [Pause Agent 2]  [Let Both Continue]  [Merge Now]       │
│  [Show Both Diffs Side-by-Side]                           │
│                                                           │
└───────────────────────────────────────────────────────────┘
```

Conflict severity levels:
- **Disjoint**: Same file, different regions → auto-mergeable, just notify
- **Overlapping**: Same file, overlapping lines → warn, offer side-by-side
- **Conflicting**: Same lines, incompatible changes → pause agent, require human decision

#### 2.1.3 Session Lifecycle = Version Control Operations

| Session action | Code state effect | Git equivalent |
|----------------|-------------------|----------------|
| Create workspace | Snapshot repo state (base layer) | `git stash` + `git checkout -b` |
| Spawn session | Create COW overlay on base | `git worktree add` (but instant, ~0 disk) |
| Spawn child session | Create COW overlay stacked on parent | Nested branch (git can't do this natively) |
| Session completes | Delta ready for merge-up | `git add` + `git commit` on branch |
| Merge to workspace | Apply delta to workspace state | `git merge` (but with task context) |
| Workspace completes | Translate to git commit + PR | `git commit` + `gh pr create` |
| Discard session | Delete delta, no trace | `git worktree remove` + `git branch -d` |

#### 2.1.4 Translation to Git

Session DAG doesn't replace git — it manages the chaotic **working phase**, then translates clean results back:

```
┌─────────────────────────────────────┐
│  Human world: git                    │
│  (commits, PRs, reviews, CI/CD)     │
├─────────────────────────────────────┤
│  Agent world: Session DAG + COW     │  ◄── Ocean manages this layer
│  (parallel work, live isolation,     │
│   real-time conflict detection)      │
├─────────────────────────────────────┤
│  Translation layer                   │
│  Session completes → git commit      │
│  Workspace completes → PR            │
│  DAG history → commit metadata       │
└─────────────────────────────────────┘
```

Translation operations:
- **Session → Commit**: When a session merges to workspace, Ocean can auto-create a git commit with the delta, including agent identity and task context in the commit message
- **Workspace → PR**: When a workspace is "done", Ocean creates a PR with the full DAG history as context (which agents worked on what, in what order, with what conflicts)
- **DAG metadata → Commit trailers**: Agent name, session relationships, conflict resolutions stored as git trailers

#### 2.1.5 Implementation Strategy (Filesystem Layer)

| Platform | Approach | Tradeoffs |
|----------|----------|-----------|
| **macOS** | NFS loopback overlay (AgentFS approach) | No kernel extension needed, ~5% overhead |
| **Linux** | OverlayFS (kernel) with FUSE fallback | Fastest option, needs mount namespace |
| **Both** | Shared read-only mounts for `node_modules/`, `.dart_tool/`, `build/` | Zero duplication of deps |
| **Storage** | SQLite-backed delta tracking | Auditable, queryable, inspectable |

#### 2.1.6 Key Concepts

- **Workspace** — top-level grouping tied to a task/goal (e.g., "Auth Refactor", "Fix #423"). Owns the base snapshot.
- **Session** — a terminal session with its own COW filesystem layer. Can be:
  - `root` — manually created by user, COW on workspace base
  - `child` — spawned by a parent session, COW stacked on parent's delta
  - `linked` — related but no filesystem relationship (devtools ↔ app server)
  - `shared` — read-only access to base, no writes (e.g., dev servers, log watchers)
- **Edge types:**
  - `spawned` — parent created child (filesystem: stacked COW)
  - `linked` — user or auto-detected relationship (no filesystem link)
  - `depends` — child needs parent to be alive

**UX:**
- Left sidebar shows the session tree with per-session delta indicators (Δ: 3 files)
- Clicking a node focuses that session's terminal AND its filesystem context
- Right-click → "Spawn child session" forks code state + creates terminal
- Graph view shows the full DAG with delta sizes and conflict indicators
- Merge panel appears when a session completes, showing changes to apply
- Conflict alerts appear in real-time with actionable options

**Auto-detection:**
- When Claude Code spawns a sub-agent, Ocean detects the new process, auto-creates a child session, and gives it a stacked COW layer
- When `flutter run` starts, Ocean gives it a `shared` session (read-only, no COW needed)
- Process forks optionally tracked as children with their own deltas

---

### 2.2 Interactive Terminal Output

Terminal output becomes a rich, interactive surface. Ocean parses output in real-time and annotates actionable elements.

```
┌─────────────────────────────────────────────────────────────┐
│ $ flutter run                                               │
│                                                             │
│ Launching lib/main.dart on iPhone 15 Pro...                 │
│                                                             │
│ ✗ Error: lib/src/auth/login_page.dart:42:15               │
│   ┌──────────────────────────────────────────┐              │
│   │ [Open File]  [Ask Agent to Fix]  [Copy]  │              │
│   └──────────────────────────────────────────┘              │
│                                                             │
│ An Observatory debugger is available at:                     │
│   http://127.0.0.1:8181/abc123=/                           │
│   ┌──────────────────────────────────┐                      │
│   │ [Open in Browser]  [Open DevTools]│                      │
│   └──────────────────────────────────┘                      │
│                                                             │
│ Flutter DevTools available at:                               │
│   http://127.0.0.1:9100?uri=...                            │
│   ┌─────────────────────────────────────────┐              │
│   │ [Connect DevTools Panel]  [Open Extern] │              │
│   └─────────────────────────────────────────┘              │
└─────────────────────────────────────────────────────────────┘
```

**Pattern recognition engine:**

| Pattern | Detection | Action |
|---------|-----------|--------|
| File paths | `/path/to/file.ext:line:col` | Open in editor, show preview |
| URLs | `http(s)://...` | Open in browser, inline preview |
| Errors/stack traces | Language-specific regex | Open file at line, offer AI fix |
| Git refs | `commit abc123`, `branch feature/x` | Show diff, checkout |
| IP:Port | `localhost:3000` | Open in browser, health check |
| Docker containers | `container_id` | Show logs, exec into |
| Package versions | `package@1.2.3` | Show changelog, update |
| Test results | `PASS/FAIL test_name` | Re-run, show details |

**Interaction modes:**
- **Hover** — shows a tooltip with context
- **Click** — primary action (open file, navigate URL)
- **Right-click** — context menu with all available actions
- **Cmd+Click** — secondary action (copy path, open in finder)

**Implementation:** A real-time ANSI/output parser runs in a background thread, applying pattern matchers to each line as it arrives. Matches are stored as annotations on the terminal buffer, rendered as overlay elements.

---

### 2.3 A2UI Integration (Agent-to-UI)

Ocean natively renders A2UI components inline in terminal output. When an AI agent wants to show a form, chart, table, or interactive widget, it emits A2UI JSON and Ocean renders it as a native component.

```
┌─────────────────────────────────────────────────────────────┐
│ Claude: I've analyzed the dependencies. Here's what needs   │
│ updating:                                                    │
│                                                             │
│ ┌─ A2UI: DependencyTable ───────────────────────────────┐  │
│ │ Package        Current   Latest   Risk    Action      │  │
│ │ ─────────────────────────────────────────────────────  │  │
│ │ express        4.18.2    5.0.1    ⚠ Major  [Update]  │  │
│ │ typescript     5.3.2     5.7.0    ✓ Minor  [Update]  │  │
│ │ prisma         5.8.0     6.1.0    ⚠ Major  [Update]  │  │
│ │                                                       │  │
│ │        [Update All Safe]  [Update All]  [Skip]        │  │
│ └───────────────────────────────────────────────────────┘  │
│                                                             │
│ Claude: Should I proceed with the safe updates?             │
└─────────────────────────────────────────────────────────────┘
```

**How it works:**
1. Agent outputs a special escape sequence: `\x1b]ocean;a2ui;<json>\x07`
2. Ocean's terminal parser detects the sequence
3. JSON is parsed and validated against A2UI schema
4. Native components are rendered inline in the terminal buffer
5. User interactions (button clicks, form inputs) are sent back to the agent via stdin or a side-channel

**Supported A2UI components (V1):**
- Text, Heading, Paragraph
- Button, ButtonGroup
- Table (sortable, filterable)
- Form (inputs, selects, checkboxes)
- Card, CardGroup
- ProgressBar, Spinner
- Chart (bar, line — via sparklines or embedded canvas)
- Image (via Kitty graphics protocol)
- CodeBlock (with syntax highlighting and copy)
- Diff (inline diff viewer)
- Tree (collapsible tree view)

**Ocean-specific extensions to A2UI:**
- `SessionLink` — renders a clickable link to another Ocean session
- `ProcessStatus` — shows live status of a running process
- `GitWidget` — inline git status/diff viewer
- `MetricsChart` — live-updating system metrics

---

### 2.4 Parallel Execution Connectors

Connectors visualize relationships between parallel processes and provide unified monitoring.

```
┌─ Connectors ────────────────────────────────────────────────┐
│                                                             │
│  ┌─────────┐    ┌───────────┐    ┌──────────┐             │
│  │ Flutter  │───▶│  DevTools  │    │ adb      │             │
│  │ App      │    │  (linked)  │    │ logcat   │             │
│  │ ● Active │    │ ● Active   │    │ ● Active │             │
│  └─────────┘    └───────────┘    └──────────┘             │
│       │                                │                    │
│       └────────────────────────────────┘                    │
│              (same device: Pixel 7)                         │
│                                                             │
│  Health: ✓ All 3 processes running                          │
│  Memory: Flutter 234MB | DevTools 89MB | adb 12MB           │
└─────────────────────────────────────────────────────────────┘
```

**Connector types:**

| Type | Detection | Example |
|------|-----------|---------|
| **Flutter** | `flutter run` → detects VM service URL + devtools | App ↔ DevTools ↔ adb |
| **Node.js** | `node --inspect` → detects debug port | Server ↔ Chrome DevTools |
| **Docker** | `docker compose up` → detects container network | Container ↔ Container |
| **Kubernetes** | `kubectl port-forward` → detects forwarded ports | Pod ↔ Local port |
| **Custom** | User defines via `ocean connect <pid1> <pid2>` | Any ↔ Any |

**Features:**
- Auto-detect known process relationships via port scanning and process tree analysis
- Show aggregated resource consumption per connector group
- Click any node to focus its session
- "Kill group" terminates all connected processes
- Log aggregation — view merged logs from all connected processes in one stream

---

### 2.5 Status Bar (Ambient Awareness Layer)

A persistent top bar showing system state, git status, and agent health at a glance.

```
┌─────────────────────────────────────────────────────────────────────────┐
│ ● WiFi 5G  │ RAM 8.2/16GB ██████░░ │ CPU 34% ███░░ │ main ↑2 +3 ~1 ●CI│
├─────────────────────────────────────────────────────────────────────────┤
│ Agents: Claude ● (active) │ Agent-2 ○ (idle) │ Agent-3 ◌ (waiting)    │
└─────────────────────────────────────────────────────────────────────────┘
```

**Top bar sections:**

| Section | Content | Update Frequency |
|---------|---------|-----------------|
| **Network** | WiFi/Ethernet status, signal strength, latency to common endpoints (GitHub, npm) | 5s |
| **System** | RAM usage (with bar), CPU usage (with bar), swap, battery | 2s |
| **Git** | Branch, ahead/behind, staged/modified/untracked counts, CI status | On file change |
| **Agents** | Per-agent status: active/idle/waiting/error with name | Real-time (process watch) |

**Agent status indicators:**
- `●` Active — agent is executing commands or generating output
- `○` Idle — agent is running but no recent output
- `◌` Waiting — agent is waiting for user input (approval, question)
- `✗` Error — agent process has errored or crashed
- `◻` Done — agent has completed its task

**Interaction:**
- Click network → show detailed connectivity (ping to GitHub, npm, Docker Hub)
- Click RAM/CPU → show per-process breakdown (like Activity Monitor)
- Click git section → show full git status, recent commits, PR state
- Click agent → focus that agent's session

---

### 2.6 Active/Inactive Session Status

Sessions have clear visual states that reduce cognitive load.

```
┌── Session Tree ──────────────┐
│                              │
│ ▼ Auth Refactor (workspace)  │
│   ● Claude Agent    [3m ago] │ ← Active: green dot, streaming
│   ○ Dev Server      [stable] │ ← Running but quiet: dim
│   ◌ Test Watcher    [paused] │ ← Paused: grey
│   ✗ Build           [failed] │ ← Failed: red
│                              │
│ ▶ Bug Fix #423 (workspace)   │ ← Collapsed, 2 active inside
│   (2 active, 1 idle)         │
│                              │
│ ▷ Old Experiment             │ ← All sessions dead, dimmed
│   (archived)                 │
│                              │
└──────────────────────────────┘
```

**Session states:**

| State | Visual | Meaning |
|-------|--------|---------|
| **Active** | Green `●`, bright text, live indicator | Process producing output |
| **Idle** | Blue `○`, normal text | Process alive, no recent output (>30s) |
| **Waiting** | Yellow `◌`, pulsing | Process blocked on user input |
| **Failed** | Red `✗`, error badge | Process exited non-zero |
| **Completed** | Grey `✓` | Process exited zero |
| **Archived** | Dimmed, collapsed | Old workspace, can be reopened |

**Smart notifications:**
- When a background agent transitions to "Waiting" → notification: "Agent needs input"
- When a build transitions to "Failed" → notification with error summary
- When all agents in a workspace are "Completed" → notification: "Workspace done"

---

### 2.7 Inline Git Integration

Git status is not a command you run — it's ambient information woven into the terminal.

```
┌─ Git Panel (toggle: Cmd+G) ──────────────────────────────────────────┐
│                                                                      │
│  Branch: feature/auth-refactor  ← main (3 behind, 2 ahead)         │
│  PR: #47 "Refactor auth middleware" — ✓ 2 approvals, CI passing     │
│                                                                      │
│  Staged (2):                                                         │
│    M src/auth/middleware.ts         [Unstage] [Diff]                 │
│    A src/auth/tokens.ts             [Unstage] [Diff]                 │
│                                                                      │
│  Modified (1):                                                       │
│    M src/auth/session.ts            [Stage] [Diff] [Revert]         │
│                                                                      │
│  Recent Commits:                                                     │
│    abc1234 refactor: extract token validation (2h ago)               │
│    def5678 fix: session expiry edge case (5h ago)                    │
│                                                                      │
│  Actions: [Commit] [Push] [Pull] [Stash] [Branch]                   │
└──────────────────────────────────────────────────────────────────────┘
```

**Ambient git indicators (always visible in status bar):**
- Branch name with color (green = clean, yellow = dirty, red = conflicts)
- Ahead/behind count
- CI status (fetched from GitHub API)
- PR status if branch has one

**File-level git awareness:**
- When a file path appears in terminal output, Ocean shows its git status inline
- Modified files get a yellow indicator, new files green, deleted red
- Hover on any file path shows last commit that touched it

---

## 3. Technology Stack

### Recommended Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Ocean Application                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Tauri v2 App Shell (Rust)               │   │
│  │  ┌───────────────────┐  ┌────────────────────────┐  │   │
│  │  │  Frontend (WebView)│  │  Native Terminal Panes │  │   │
│  │  │  - React/Solid     │  │  - xterm.js + WebGL    │  │   │
│  │  │  - Session tree    │  │  - A2UI renderer       │  │   │
│  │  │  - Status bar      │  │  - Pattern annotator   │  │   │
│  │  │  - Connectors UI   │  │  - Interactive overlay  │  │   │
│  │  │  - Git panel       │  │                        │  │   │
│  │  └───────────────────┘  └────────────────────────┘  │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Rust Backend (Tauri Core)                │   │
│  │  ┌──────────┐ ┌──────────┐ ┌────────────────────┐  │   │
│  │  │ Session   │ │ Process  │ │ System Metrics     │  │   │
│  │  │ Manager   │ │ Monitor  │ │ Collector          │  │   │
│  │  │ (DAG)     │ │ (ptrace) │ │ (sysinfo crate)   │  │   │
│  │  └──────────┘ └──────────┘ └────────────────────┘  │   │
│  │  ┌──────────┐ ┌──────────┐ ┌────────────────────┐  │   │
│  │  │ Git       │ │ Network  │ │ A2UI Protocol      │  │   │
│  │  │ Watcher   │ │ Monitor  │ │ Handler            │  │   │
│  │  │ (git2-rs) │ │ (ping)   │ │ (JSON parser)      │  │   │
│  │  └──────────┘ └──────────┘ └────────────────────┘  │   │
│  │  ┌──────────────────────────────────────────────┐   │   │
│  │  │ PTY Manager (portable-pty / libghostty-vt)   │   │   │
│  │  └──────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │         COW Filesystem Layer (Code State)             │   │
│  │  ┌──────────────┐ ┌─────────────┐ ┌──────────────┐ │   │
│  │  │ Filesystem    │ │ Conflict    │ │ Git          │ │   │
│  │  │ Manager       │ │ Detector    │ │ Translator   │ │   │
│  │  │ (overlay/NFS) │ │ (real-time) │ │ (DAG→commit) │ │   │
│  │  └──────────────┘ └─────────────┘ └──────────────┘ │   │
│  │  macOS: NFS loopback | Linux: OverlayFS/FUSE       │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Storage Layer                            │   │
│  │  SQLite (sessions, workspaces, config, deltas)       │   │
│  │  Filesystem (terminal scrollback, logs, snapshots)    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Stack Choices

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| **App shell** | Tauri v2 (Rust) | 10x lighter than Electron (WaveTerm), native system access, IPC |
| **Frontend** | SolidJS + TypeScript | Smaller bundle than React, fine-grained reactivity for real-time updates |
| **Terminal rendering** | xterm.js + WebGL addon | Proven, GPU-accelerated, battle-tested in VS Code, WaveTerm, Warp web |
| **Terminal emulation** | portable-pty (Rust) → migrate to libghostty-vt when stable | PTY management in Rust, future-proof with libghostty path |
| **Output parsing** | Custom Rust library | Real-time pattern matching on terminal output stream |
| **A2UI rendering** | Custom SolidJS components | Render A2UI JSON as native web components inline in terminal |
| **COW filesystem (macOS)** | NFS loopback + SQLite delta tracking | No kernel extension, AgentFS-proven approach |
| **COW filesystem (Linux)** | OverlayFS / FUSE fallback | Kernel-fast when available, FUSE for unprivileged |
| **Conflict detection** | Custom Rust (file write watcher) | Real-time overlap detection across all active sessions |
| **Git translation** | git2-rs + gh CLI | Convert DAG state to commits/PRs |
| **Session storage** | SQLite (via rusqlite) | Lightweight, embedded, perfect for session DAG + workspace data |
| **Git integration** | git2-rs (libgit2 bindings) | No shelling out to git, fast, reliable |
| **System metrics** | sysinfo crate (Rust) | Cross-platform CPU, RAM, disk, network stats |
| **Network monitoring** | Custom Rust (socket checks + ICMP) | Lightweight ping + port checks |
| **Process monitoring** | sysinfo + procfs/libproc | Process tree, resource usage per process |
| **IPC** | Tauri commands + events | Frontend ↔ Backend communication |

### Why not Electron?

WaveTerm uses Electron. Ocean uses Tauri because:
- **Memory:** Tauri app ~30-60MB vs Electron ~200-400MB. For a terminal that's always open, this matters.
- **Binary size:** Tauri ~5-10MB vs Electron ~150MB+
- **Performance:** Rust backend is natively fast for process monitoring, git watching, output parsing
- **Security:** No full Node.js runtime exposed, smaller attack surface

### Why xterm.js over a custom terminal renderer?

xterm.js is the terminal renderer used by VS Code, Eclipse Theia, and many others. It supports:
- WebGL acceleration (smooth 60fps scrolling)
- Unicode, ligatures, true color
- Add-on ecosystem (search, fit, image, webgl)
- Custom renderers and decorations (for our interactive overlays)

Building a custom GPU renderer would take 6-12 months. xterm.js gets us there immediately with the option to swap in libghostty's renderer later.

---

## 4. Data Model

### Session DAG (with Code State)

```
Workspace {
  id: UUID
  name: string               // "Auth Refactor"
  created_at: timestamp
  status: active | archived
  metadata: JSON              // user-defined tags, notes
  base_snapshot: string       // path to read-only repo snapshot
  base_commit: string         // git commit hash at snapshot time
  merged_state: string        // path to workspace's accumulated merged state
  git_branch: string | null   // git branch created when translating to git
  git_pr: string | null       // PR URL if workspace was shipped
}

Session {
  id: UUID
  workspace_id: UUID          // belongs to workspace
  parent_id: UUID | null      // null = root session
  edge_type: spawned | linked | depends
  name: string               // "Claude Agent" or auto-generated
  type: shell | agent | process
  fs_mode: cow | shared | none  // cow = has delta layer, shared = read-only base, none = unmanaged
  agent_type: string | null   // "claude-code", "cursor", "aider"
  pid: int | null
  pty_id: string
  status: active | idle | waiting | failed | completed | archived
  started_at: timestamp
  ended_at: timestamp | null
  exit_code: int | null
  cwd: string                // working directory (points into COW mount)
  env_snapshot: JSON          // captured environment vars
  scrollback_path: string     // file path to scrollback buffer
}

SessionState {
  session_id: UUID
  delta_path: string          // path to this session's COW delta directory
  parent_delta_id: UUID | null  // for stacked overlays (child sessions)
  mount_path: string          // where the merged view is mounted for this session
  modified_files: [string]    // tracked for conflict detection
  created_files: [string]
  deleted_files: [string]
  delta_size_bytes: int       // total size of delta (for UI indicators)
  merged_to_parent: boolean
  merged_at: timestamp | null
  git_commit: string | null   // set when translated to git
}

ConflictWatch {
  file_path: string
  sessions: [UUID]            // which sessions have touched this file
  overlap_ranges: [{line_start: int, line_end: int, session_id: UUID}]
  severity: disjoint | overlapping | conflicting
  detected_at: timestamp
  resolved: boolean
  resolution: string | null   // "auto-merged" | "agent-1-wins" | "manual"
}

SessionLink {
  id: UUID
  source_id: UUID             // session A
  target_id: UUID             // session B
  link_type: spawned | linked | depends
  auto_detected: boolean
  metadata: JSON              // e.g., { port: 8181, protocol: "dart-vm" }
}

ConnectorGroup {
  id: UUID
  workspace_id: UUID
  name: string               // "Flutter Development"
  connector_type: flutter | node | docker | kubernetes | custom
  sessions: [UUID]           // member session IDs
  health: healthy | degraded | down
}
```

### Interactive Annotations

```
Annotation {
  session_id: UUID
  line_start: int
  col_start: int
  line_end: int
  col_end: int
  type: file_path | url | error | git_ref | port | container | test_result
  value: string              // the matched text
  metadata: JSON             // parsed details (file, line, col, etc.)
  actions: [Action]          // available actions for this annotation
}

Action {
  label: string              // "Open File"
  icon: string               // "file-open"
  command: string            // internal command to execute
  shortcut: string | null    // keyboard shortcut
}
```

### A2UI State

```
A2UIComponent {
  session_id: UUID
  component_id: string       // from A2UI JSON
  line_position: int         // where in terminal buffer it's anchored
  component_type: string     // "Table", "Form", "Button", etc.
  props: JSON                // A2UI component properties
  data_bindings: JSON        // reactive data model references
  state: rendered | collapsed | dismissed
}
```

---

## 5. Component Design (Deep Dive)

### 5.1 Session Manager (Rust Backend)

The brain of Ocean. Manages the session DAG, process lifecycle, code state isolation, and auto-detection.

```
SessionManager
├── create_workspace(name, repo_path) → Workspace
│   └── Snapshots repo state as read-only base layer
├── create_session(workspace_id, parent_id?, type, fs_mode) → Session
│   ├── fs_mode=cow: Creates COW delta layer, mounts overlay
│   ├── fs_mode=shared: Mounts read-only view of base
│   └── fs_mode=none: Uses host filesystem directly
├── spawn_pty(session_id, command, env) → PtyHandle
│   └── Sets CWD to session's mount_path (isolated view)
├── merge_session(session_id, target: parent | workspace) → MergeResult
│   ├── Applies delta to target
│   ├── Detects conflicts with other sessions' deltas
│   └── Returns: clean | conflicts(Vec<ConflictInfo>)
├── translate_to_git(workspace_id) → GitResult
│   ├── Creates git commit(s) from workspace's merged state
│   └── Optionally creates PR via gh CLI
├── kill_session(session_id)
│   └── Unmounts overlay, optionally preserves delta
├── kill_workspace(workspace_id)
├── get_session_tree(workspace_id) → Tree<Session>
├── get_conflicts(workspace_id) → Vec<ConflictWatch>
├── detect_child_processes(session_id) → Vec<ProcessInfo>
├── auto_link_sessions()
└── archive_workspace(workspace_id)
```

```
FilesystemManager (COW layer)
├── create_snapshot(repo_path) → SnapshotPath
│   └── Hard-links or reflinks the repo (instant, zero-copy)
├── create_overlay(base, parent_delta?) → MountPath
│   ├── macOS: NFS loopback with SQLite delta tracking
│   └── Linux: OverlayFS mount with FUSE fallback
├── get_delta(session_id) → DeltaInfo { modified, created, deleted, size }
├── watch_writes(session_id) → Stream<FileWriteEvent>
│   └── Powers real-time conflict detection
├── merge_deltas(source_delta, target) → MergeResult
├── unmount_overlay(session_id)
└── cleanup_snapshot(workspace_id)
```

```
ConflictDetector
├── register_session(session_id)
├── on_file_write(session_id, file_path, line_range) → Option<ConflictAlert>
│   ├── Checks all other active sessions' modified_files
│   ├── If same file: compute line overlap
│   └── If overlap: emit ConflictAlert to frontend
├── get_active_conflicts() → Vec<ConflictWatch>
└── resolve_conflict(conflict_id, resolution: Resolution)
```

**Auto-detection algorithm:**
1. Every 2 seconds, scan process tree under each session's PID
2. If a new child process is detected that matches known patterns (node, python, flutter, adb):
   - Create a child session automatically (with stacked COW if agent-type)
   - Detect if it's a known connector type (shared fs_mode for devtools/servers)
3. Scan listening ports for known service patterns:
   - Dart VM service → link to Flutter session
   - Chrome DevTools protocol → link to Node debug session
   - Docker API → link to docker compose session

### 5.2 Output Annotator (Rust Backend)

Real-time pattern matching engine that runs on terminal output.

```
OutputAnnotator
├── register_pattern(name, regex, action_template)
├── process_line(session_id, line: &str) → Vec<Annotation>
├── process_ansi(session_id, data: &[u8]) → Option<A2UIComponent>
├── get_annotations(session_id, line_range) → Vec<Annotation>
└── clear_annotations(session_id)
```

**Built-in patterns (priority ordered):**
1. A2UI escape sequences (highest priority)
2. Error patterns (compiler errors, stack traces)
3. File paths with line:col
4. URLs
5. Git references
6. Network addresses (IP:port)
7. Test results
8. Docker/container IDs

**Performance target:** <1ms per line annotation. Uses compiled regex set (regex crate's RegexSet for parallel matching).

### 5.3 System Metrics Collector (Rust Backend)

Lightweight poller for system and process metrics.

```
MetricsCollector
├── get_system_metrics() → SystemMetrics { cpu, ram, swap, battery, disk }
├── get_network_status() → NetworkStatus { connected, type, signal, latency }
├── get_process_metrics(pid) → ProcessMetrics { cpu, ram, threads, fds }
├── get_git_status(path) → GitStatus { branch, ahead, behind, staged, modified }
└── subscribe(interval_ms) → Stream<MetricsEvent>
```

**Polling intervals:**
- System metrics: 2000ms
- Network status: 5000ms (with event-based wake on change)
- Process metrics: 3000ms
- Git status: on filesystem watch (fsnotify) + 10000ms fallback

### 5.4 Frontend Component Tree

```
App
├── StatusBar                          // Top bar: network, system, git, agents
│   ├── NetworkIndicator
│   ├── SystemMetrics (RAM, CPU bars)
│   ├── GitStatusBadge
│   └── AgentStatusRow
├── MainLayout
│   ├── SessionSidebar                 // Left: session tree
│   │   ├── WorkspaceGroup
│   │   │   └── SessionNode (recursive)
│   │   └── WorkspaceActions
│   ├── TerminalArea                   // Center: terminal panes
│   │   ├── TerminalPane (xterm.js)
│   │   │   ├── AnnotationOverlay     // Clickable elements on top of terminal
│   │   │   └── A2UIRenderer          // Inline A2UI components
│   │   └── PaneSplitter
│   └── DetailPanel (optional, right)  // Right: git panel, connector details
│       ├── GitPanel
│       ├── ConnectorPanel
│       └── ProcessDetails
└── ConnectorBar                       // Bottom: connector status
    └── ConnectorGroup
        └── ProcessNode
```

---

## 6. UX Mockups

### 6.1 Full Application Layout

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ ● WiFi │ RAM 8.2/16 ██████░░ │ CPU 34% ███░░ │ main ↑2 +3 ~1 │ ●CI ✓ PR#47   │
│ Agents: [● Claude] [○ Agent-2] [◌ Agent-3]                                     │
├───────────┬─────────────────────────────────────────────────────┬───────────────┤
│           │                                                     │               │
│ Sessions  │  Terminal Output                                    │  Git Panel    │
│           │                                                     │               │
│ ▼ Auth    │  ~/projects/app $ flutter run                       │  feature/auth │
│  ● Claude │  Launching on iPhone 15...                          │  ← main (↓3)  │
│  ○ Server │                                                     │               │
│  ◌ Tests  │  ✗ lib/auth/login.dart:42                          │  Staged:      │
│    ↳ sub1 │    ┌─────────────────────────────┐                  │  M middleware │
│           │    │ [Open] [AI Fix] [Copy Path] │                  │  A tokens.ts  │
│ ▶ Bug#423 │    └─────────────────────────────┘                  │               │
│  (2/1)    │                                                     │  Modified:    │
│           │  Observatory at http://127.0.0.1:8181               │  M session.ts │
│           │    [Connect DevTools ↗]                              │               │
│           │                                                     │  [Commit]     │
│           │  ┌─ A2UI ──────────────────────────┐               │  [Push]       │
│           │  │ Agent suggests:                  │               │               │
│           │  │ ┌─────────┐ ┌──────────────────┐│               │               │
│           │  │ │ Fix auth │ │ Skip & continue  ││               │               │
│           │  │ └─────────┘ └──────────────────┘│               │               │
│           │  └─────────────────────────────────┘               │               │
│           │                                                     │               │
├───────────┴─────────────────────────────────────────────────────┴───────────────┤
│ Connectors: [Flutter App ●]──[DevTools ●]──[adb ●]  Health: ✓ All running      │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 Graph View (Toggle with Cmd+Shift+G)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│ ● WiFi │ RAM 8.2/16 ██████░░ │ CPU 34% ███░░ │ main ↑2 +3 ~1 │ ●CI ✓         │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│                          SESSION GRAPH VIEW                                     │
│                                                                                 │
│          ┌──────────────────────┐                                               │
│          │  Auth Refactor       │                                               │
│          │  (workspace)         │                                               │
│          └──────┬───────┬──────┘                                               │
│                 │       │       \                                                │
│           ┌─────▼─┐ ┌──▼────┐  ┌▼────────┐                                    │
│           │Claude │ │Server │  │Tests    │                                      │
│           │Agent  │ │flutter│  │jest     │                                      │
│           │● 3m   │ │○ 12m  │  │◌ paused │                                    │
│           └──┬──┬─┘ └───────┘  └─────────┘                                    │
│              │  │                                                                │
│        ┌─────▼┐ ┌▼──────┐                                                       │
│        │sub-1 │ │sub-2  │     Legend:                                           │
│        │test  │ │build  │     ● Active  ○ Idle  ◌ Waiting                      │
│        │● 1m  │ │✗ fail │     ✗ Failed  ✓ Done                                 │
│        └──────┘ └───────┘     ── spawned  ╌╌ linked  ═══ depends               │
│                                                                                 │
│          ┌──────────────────────┐                                               │
│          │  Bug Fix #423        │                                               │
│          │  (workspace)         │                                               │
│          └──────┬───────────────┘                                               │
│                 │                                                                │
│           ┌─────▼─┐ ┌─────────┐                                                │
│           │Agent  │╌╌│Repro   │                                                │
│           │● 5m   │  │server  │                                                │
│           └───────┘  │○ idle  │                                                │
│                      └────────┘                                                 │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 6.3 Connector Detail View

```
┌─ Flutter Development Connector ─────────────────────────────────────┐
│                                                                     │
│  ┌─────────┐     port:8181      ┌───────────┐     usb      ┌─────┐│
│  │ flutter │─────────────────▶ │  DevTools  │────────────▶│ adb ││
│  │ run     │                    │  inspector │              │     ││
│  │ PID:421 │                    │  PID: 890  │              │PID: ││
│  │ RAM:234M│                    │  RAM: 89M  │              │1201 ││
│  │ CPU: 12%│                    │  CPU:  3%  │              │RAM: ││
│  │ ● Active│                    │  ● Active  │              │12M  ││
│  └─────────┘                    └───────────┘              │●    ││
│                                                             └─────┘│
│                                                                     │
│  Aggregated: RAM 335MB | CPU 15% | Uptime 23m                      │
│  Device: iPhone 15 Pro (Simulator)                                  │
│                                                                     │
│  [Kill All] [Restart Flutter] [Hot Reload] [Merge Logs]            │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 7. Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd+T` | New session in current workspace |
| `Cmd+Shift+T` | New workspace |
| `Cmd+N` | Spawn child session from current |
| `Cmd+W` | Close current session |
| `Cmd+G` | Toggle git panel |
| `Cmd+Shift+G` | Toggle graph view |
| `Cmd+K` | Toggle connector panel |
| `Cmd+1-9` | Switch to session by index |
| `Cmd+[` / `Cmd+]` | Navigate session tree (prev/next) |
| `Cmd+Shift+A` | Focus agent status bar |
| `Cmd+Click` | Secondary action on annotation |
| `Cmd+Shift+M` | Toggle system metrics detail |
| `Cmd+P` | Quick session switcher (like Cmd+P in VS Code) |
| `Cmd+Shift+P` | Command palette |

---

## 8. Implementation Roadmap

### Phase 1: Foundation (Weeks 1-6)
**Goal:** Working terminal with session tree

- [ ] Tauri v2 project scaffolding with SolidJS frontend
- [ ] xterm.js integration with WebGL renderer
- [ ] PTY management via portable-pty in Rust
- [ ] Basic session model (create, close, list)
- [ ] Session sidebar with tree view
- [ ] Tab/pane splitting
- [ ] Basic keyboard shortcuts

**Deliverable:** A working terminal app that can run shells, with a session tree sidebar.

### Phase 2: Ambient Awareness (Weeks 7-10)
**Goal:** Status bar with live metrics

- [ ] System metrics collector (RAM, CPU, battery)
- [ ] Network status monitor
- [ ] Git status watcher (git2-rs + fsnotify)
- [ ] Status bar UI with all sections
- [ ] Active/inactive session detection
- [ ] Session status indicators (●○◌✗✓)

**Deliverable:** Terminal with live system metrics, git status, and session health indicators.

### Phase 3: Interactive Output (Weeks 11-15)
**Goal:** Clickable, actionable terminal output

- [ ] Output annotator engine (Rust, regex-based)
- [ ] File path detection and actions
- [ ] URL detection and actions
- [ ] Error/stack trace detection
- [ ] Annotation overlay renderer (SolidJS on xterm.js)
- [ ] Context menus for annotations
- [ ] Hover tooltips

**Deliverable:** Terminal where file paths, URLs, and errors are clickable with context actions.

### Phase 4: Code State Isolation — COW Filesystem (Weeks 16-22)
**Goal:** Session DAG with filesystem-level code isolation

- [ ] Workspace model with base snapshot creation (hard-links/reflinks)
- [ ] COW overlay implementation — macOS (NFS loopback + SQLite delta)
- [ ] COW overlay implementation — Linux (OverlayFS + FUSE fallback)
- [ ] Shared read-only mounts for `node_modules/`, `.dart_tool/`, `build/`
- [ ] Session spawn → auto-creates COW layer, sets CWD to mount
- [ ] Child session stacked overlays (reads parent delta → base)
- [ ] File write watcher for real-time conflict detection
- [ ] Conflict alert UI (severity levels: disjoint/overlapping/conflicting)
- [ ] Merge panel: session completes → review delta → merge to workspace
- [ ] Graph view showing DAG with delta sizes and conflict indicators

**Deliverable:** Sessions with isolated code state. Agents can work in parallel on the same repo with zero setup, real-time conflict detection, and clean merge.

### Phase 5: Git Translation Layer (Weeks 23-25)
**Goal:** Translate Session DAG state back to git

- [ ] Session → git commit translation (delta → commit with agent metadata)
- [ ] Workspace → PR creation (full DAG context in PR body)
- [ ] DAG metadata → git trailers (agent identity, session relationships)
- [ ] "Ship workspace" command: merge all → commit → push → PR
- [ ] Scrollback + terminal history preserved as workspace artifact

**Deliverable:** Complete round-trip: repo → workspace → agents → sessions → deltas → git commits → PR.

### Phase 6: A2UI & Connectors (Weeks 26-30)
**Goal:** Rich UI in terminal and process connectors

- [ ] A2UI escape sequence parser
- [ ] A2UI component renderer (SolidJS)
- [ ] Core A2UI components (Table, Form, Button, Card, Code, Diff)
- [ ] Ocean-specific A2UI extensions
- [ ] Connector auto-detection engine
- [ ] Flutter connector (auto-detect devtools + adb)
- [ ] Node.js connector (auto-detect debug port)
- [ ] Docker connector
- [ ] Connector bar UI
- [ ] Merged log view

**Deliverable:** Full Ocean V1 with all features.

---

## 9. Open Questions & Risks

### Technical Risks

| Risk | Mitigation |
|------|-----------|
| COW filesystem complexity on macOS (no native OverlayFS) | NFS loopback approach proven by AgentFS; SQLite delta tracking is well-understood |
| File write watcher performance at scale (many sessions) | Use kqueue/inotify per mount, not polling. Batch conflict checks. |
| Stacked overlay depth (child of child of child) | Cap at 3-4 levels; auto-flatten by merging intermediate deltas |
| xterm.js + annotation overlay performance | Benchmark early; fallback to canvas-based overlay |
| A2UI spec is v0.8, may change | Abstract renderer; pin to specific version |
| libghostty-vt not stable yet | Use portable-pty now, design for swap later |
| Process auto-detection is platform-specific | Start macOS-only, Linux next. Use sysinfo crate for abstraction |
| Tauri WebView GPU rendering limitations | xterm.js WebGL addon handles terminal; measure latency |

### Product Questions

1. **Should Ocean support remote sessions (SSH)?** — Defer to V2, but architect the session model to support it
2. **Should workspaces persist across app restarts?** — Yes, via SQLite. Include scrollback restoration.
3. **Should Ocean integrate with specific agents (Claude Code, Cursor)?** — Yes, but through generic process detection, not hard-coded integrations
4. **Should the A2UI channel be stdin/stdout or a side-channel (WebSocket)?** — Support both. stdout via escape sequences for simplicity; WebSocket for complex interactions
5. **Cross-platform priority?** — macOS first (your primary platform), Linux second, Windows third

---

## 10. Competitive Moat

What makes Ocean defensible:

1. **Session DAG as code state is a new paradigm.** Not a feature — a fundamentally different model for how agents work on code. Spawning = branching. Completing = merging. Real-time conflict detection is impossible in any git-based workflow.
2. **Zero-cost isolation kills git worktrees.** ~KB delta layers vs ~GB worktrees. Instant spawn vs minutes of setup. Shared dependencies vs duplicated `node_modules`. This alone is a reason to use Ocean.
3. **A2UI-native terminal.** First terminal to render A2UI components. As agents adopt A2UI, Ocean becomes the natural rendering surface.
4. **Interactive output protocol.** If Ocean defines how agents annotate output (via escape sequences), other terminals will follow the standard.
5. **Open source with opinionated UX.** Like Ghostty — fast, correct, beautiful, open. Not a platform play (Warp), not a kitchen sink (WaveTerm).

---

## Decisions Made

1. **Scope:** A+B merged — platform + terminal
2. **Persona:** Universal (solo vibe coder, mobile/fullstack dev, power engineer)
3. **Core primitive:** Session DAG is code state — spawning = branching, completing = merging
4. **Isolation:** COW filesystem layers (macOS: NFS loopback, Linux: OverlayFS/FUSE)
5. **Git relationship:** Session DAG manages working phase, translates to git for sharing
6. **Stack:** Tauri v2 + SolidJS + xterm.js + Rust backend
7. **Terminal engine:** portable-pty now, libghostty-vt migration path
8. **UI framework:** SolidJS (not React) for performance
9. **Storage:** SQLite for session DAG + delta tracking, filesystem for snapshots + scrollback
10. **A2UI:** Adopt Google's A2UI protocol, extend with Ocean-specific components
11. **Platform:** macOS first, Linux second, Windows third
