# Problem Statement

WaveTerm (https://github.com/wavetermdev/waveterm) is a great terminal solution that provides improvements over existing terminals. However, it does not solve the UX challenges of vibe coding / agentic coding.

## User's Initial Ideas
1. **Internet connection status** — show connectivity state
2. **Concurrent sessions** — multiple sessions running simultaneously
3. **Child sessions (session tree)** — sessions derived from parent sessions, maintaining a graph/tree of session relationships
4. **A2UI-like UI elements** — rich UI elements rendered directly in the terminal
5. **Interactive terminal** — click, select, and interact with any element in terminal output
6. **Parallel execution connectors** — show connected parallel processes (e.g., Flutter devtools + adb)
7. **macOS perf bar** — RAM consumption and system metrics in the top bar
8. **Active/inactive terminal status** — visual indicators for session state
9. **Inline git status** — git information displayed within the terminal itself
10. **Features that take vibe coding to the next level**

## Type: explore
## Pipeline: THINK → PLAN
## Started: 2026-03-15
