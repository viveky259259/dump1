# Phase 1: THINK — Session Persistence

## Problem (restated)
When Ocean restarts, all sessions are lost. Users who named sessions ("Frontend", "Backend")
or arranged them in layout groups must recreate everything manually. The DB has the session
records but marks them completed. No PTY respawn happens.

## Scope Decision: HOLD SCOPE
Don't try to restore terminal scrollback history or running processes — just restore
the session shells with their names, CWD, and layout arrangement.

## Key Insights
1. Sessions already persist in SQLite with name, workspace_id, parent_id, status
2. `mark_stale_sessions()` kills them on startup — we need to REVIVE instead of kill
3. Layout groups persist in localStorage with session IDs — if we respawn sessions
   with the SAME IDs, layout restore works for free
4. CWD can be stored in session_states table (already has mount_path)

## What Already Exists
- DB has full session metadata (name, workspace, parent, type)
- `mark_stale_sessions()` runs on startup — can be changed to respawn instead
- Layout persistence already saves/restores group trees
- `create_session` in session/mod.rs already spawns PTYs

## Approach
Instead of marking stale sessions as completed, **respawn them**:
1. On startup, find sessions that were "active" when the app closed
2. For each, spawn a new PTY with the same session ID, name, and CWD
3. Update the session record to point to the new PTY PID
4. Layout groups reference the same session IDs — they restore automatically

## Deferred
- Terminal scrollback restoration (would need to persist scrollback buffer)
- Running process restoration (impossible without checkpointing)
- Session environment variable restoration
