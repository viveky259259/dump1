# Ocean — Context Summary

Ocean is a next-generation terminal and control plane purpose-built for agentic/vibe coding. It reimagines the terminal around AI agent orchestration rather than retrofitting AI onto traditional terminal paradigms.

Core innovations: **Session DAG as code state manager** (the central primitive — spawning a session forks code via COW filesystem, completing merges it back, with real-time conflict detection across all active agents), Interactive Output (every file path/URL/error is clickable), A2UI rendering (agents can emit rich UI components inline), Parallel Execution Connectors (visualize related processes like Flutter+devtools+adb), Ambient Awareness (system metrics, git status, agent health always visible), and Git Translation Layer (DAG state → git commits → PRs).

Tech stack: Tauri v2 (Rust) + SolidJS + xterm.js (WebGL) + SQLite + COW filesystem (macOS: NFS loopback, Linux: OverlayFS). Designed for macOS first. Uses portable-pty with migration path to libghostty-vt.

User wants comprehensive design document (explore type). Not building code yet. All personas targeted.
