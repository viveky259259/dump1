import 'package:flutter_test/flutter_test.dart';

// Import all test files
import 'blocs/auth_bloc_test.dart' as auth_bloc_tests;
import 'blocs/invoice_bloc_test.dart' as invoice_bloc_tests;
import 'blocs/user_bloc_test.dart' as user_bloc_tests;
import 'models/data_models_test.dart' as data_models_tests;
import 'models/user_test.dart' as user_model_tests;
import 'services/auth_service_test.dart' as auth_service_tests;
import 'services/invoice_service_test.dart' as invoice_service_tests;
import 'services/pdf_service_test.dart' as pdf_service_tests;
import 'utils/constants_test.dart' as constants_tests;
import 'widgets/common_widgets_test.dart' as widgets_tests;

/// Main test runner that executes all tests in the project
/// 
/// Run with: flutter test test/all_tests.dart
/// Run with coverage: flutter test --coverage test/all_tests.dart
void main() {
  group('TownSquare App - Complete Test Suite', () {
    group('Model Tests', () {
      user_model_tests.main();
      data_models_tests.main();
    });

    group('Service Tests', () {
      auth_service_tests.main();
      invoice_service_tests.main();
      pdf_service_tests.main();
    });

    group('BLoC Tests', () {
      auth_bloc_tests.main();
      invoice_bloc_tests.main();
      user_bloc_tests.main();
    });

    group('Utility Tests', () {
      constants_tests.main();
    });

    group('Widget Tests', () {
      widgets_tests.main();
    });
  });
}

/// Integration test configuration
/// 
/// This can be used to run integration tests that require
/// multiple components working together
class IntegrationTestConfig {
  static const bool runIntegrationTests = false;
  
  static void runIntegrationTestSuite() {
    if (!runIntegrationTests) return;
    
    group('Integration Tests', () {
      testWidgets('Complete user authentication flow', (tester) async {
        // Test complete sign-in -> dashboard -> sign-out flow
        // This would require setting up the full app with mocked services
      });

      testWidgets('Invoice generation and PDF creation flow', (tester) async {
        // Test invoice creation -> PDF generation -> sharing flow
      });

      testWidgets('User role-based access control', (tester) async {
        // Test that different user roles see appropriate content
      });
    });
  }
}

/// Performance test configuration
/// 
/// Tests for performance-critical components
class PerformanceTestConfig {
  static const bool runPerformanceTests = false;
  
  static void runPerformanceTestSuite() {
    if (!runPerformanceTests) return;
    
    group('Performance Tests', () {
      test('PDF generation should complete within time limit', () async {
        // Test PDF generation performance
      });

      test('Large user list should render efficiently', () async {
        // Test list rendering with many items
      });

      test('BLoC state changes should be efficient', () async {
        // Test BLoC performance under heavy load
      });
    });
  }
}