import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:townsquare/blocs/auth/auth_bloc.dart';
import 'package:townsquare/blocs/auth/auth_state.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/widgets/common_widgets.dart';

import '../mocks.dart';
void main() {
  group('Common Widgets Tests', () {
    late MockAuthBloc mockAuthBloc;

    setUp(() {
      mockAuthBloc = MockAuthBloc();
    });

    group('AppCard Widget Tests', () {
      testWidgets('should render with default padding', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: AppCard(
                child: Text('Test Content'),
              ),
            ),
          ),
        );

        expect(find.byType(Card), findsOneWidget);
        expect(find.text('Test Content'), findsOneWidget);
      });

      testWidgets('should render with custom padding', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: AppCard(
                padding: EdgeInsets.all(8),
                child: Text('Test Content'),
              ),
            ),
          ),
        );

        final padding = tester.widget<Padding>(find.byType(Padding).last);
        expect(padding.padding, EdgeInsets.all(8));
      });

      testWidgets('should handle tap when onTap is provided', (tester) async {
        bool tapped = false;
        
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: AppCard(
                onTap: () => tapped = true,
                child: Text('Tappable Card'),
              ),
            ),
          ),
        );

        await tester.tap(find.byType(InkWell));
        expect(tapped, true);
      });

      testWidgets('should not be tappable when onTap is null', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: AppCard(
                child: Text('Non-tappable Card'),
              ),
            ),
          ),
        );

        final inkWell = tester.widget<InkWell>(find.byType(InkWell));
        expect(inkWell.onTap, isNull);
      });

      testWidgets('should have correct border radius', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: AppCard(
                child: Text('Test'),
              ),
            ),
          ),
        );

        final card = tester.widget<Card>(find.byType(Card));
        final shape = card.shape as RoundedRectangleBorder;
        expect(shape.borderRadius, BorderRadius.circular(16));
      });
    });

    group('CategoryChip Widget Tests', () {
      testWidgets('should render with label and emoji', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: CategoryChip(
                label: 'General',
                emoji: '📢',
              ),
            ),
          ),
        );

        expect(find.text('📢 General'), findsOneWidget);
      });

      testWidgets('should show selected state correctly', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: CategoryChip(
                label: 'Urgent',
                emoji: '🚨',
                isSelected: true,
              ),
            ),
          ),
        );

        final filterChip = tester.widget<FilterChip>(find.byType(FilterChip));
        expect(filterChip.selected, true);
      });

      testWidgets('should handle tap when onTap is provided', (tester) async {
        bool tapped = false;
        
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: CategoryChip(
                label: 'Event',
                emoji: '🎉',
                onTap: () => tapped = true,
              ),
            ),
          ),
        );

        await tester.tap(find.byType(FilterChip));
        expect(tapped, true);
      });

      testWidgets('should not be tappable when onTap is null', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: CategoryChip(
                label: 'Maintenance',
                emoji: '🔧',
              ),
            ),
          ),
        );

        final filterChip = tester.widget<FilterChip>(find.byType(FilterChip));
        expect(filterChip.onSelected, isNull);
      });

      testWidgets('should use custom background color when provided', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: CategoryChip(
                label: 'Custom',
                emoji: '✨',
                backgroundColor: Colors.purple,
                isSelected: true,
              ),
            ),
          ),
        );

        final filterChip = tester.widget<FilterChip>(find.byType(FilterChip));
        expect(filterChip.selectedColor, Colors.purple);
      });
    });

    group('RoleIndicator Widget Tests', () {
      testWidgets('should render admin role correctly', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: RoleIndicator(role: UserRole.admin),
            ),
          ),
        );

        expect(find.byIcon(Icons.admin_panel_settings), findsOneWidget);
        expect(find.text('Admin'), findsOneWidget);
      });

      testWidgets('should render resident role correctly', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: RoleIndicator(role: UserRole.resident),
            ),
          ),
        );

        expect(find.byIcon(Icons.home), findsOneWidget);
        expect(find.text('Resident'), findsOneWidget);
      });

      testWidgets('should render staff role correctly', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: RoleIndicator(role: UserRole.staff),
            ),
          ),
        );

        expect(find.byIcon(Icons.build), findsOneWidget);
        expect(find.text('Staff'), findsOneWidget);
      });

      testWidgets('should render security role correctly', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: RoleIndicator(role: UserRole.security),
            ),
          ),
        );

        expect(find.byIcon(Icons.security), findsOneWidget);
        expect(find.text('Security'), findsOneWidget);
      });

      testWidgets('should hide label when showLabel is false', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: RoleIndicator(
                role: UserRole.admin,
                showLabel: false,
              ),
            ),
          ),
        );

        expect(find.byIcon(Icons.admin_panel_settings), findsOneWidget);
        expect(find.text('Admin'), findsNothing);
      });
    });

    group('StatusBadge Widget Tests', () {
      testWidgets('should render with label and color', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: StatusBadge(
                label: 'Active',
                color: Colors.green,
              ),
            ),
          ),
        );

        expect(find.text('Active'), findsOneWidget);
      });

      testWidgets('should render with icon when provided', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: StatusBadge(
                label: 'Completed',
                color: Colors.blue,
                icon: Icons.check_circle,
              ),
            ),
          ),
        );

        expect(find.text('Completed'), findsOneWidget);
        expect(find.byIcon(Icons.check_circle), findsOneWidget);
      });

      testWidgets('should not render icon when not provided', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: StatusBadge(
                label: 'Pending',
                color: Colors.orange,
              ),
            ),
          ),
        );

        expect(find.text('Pending'), findsOneWidget);
        expect(find.byType(Icon), findsNothing);
      });
    });

    group('SectionHeader Widget Tests', () {
      testWidgets('should render title', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: SectionHeader(title: 'Recent Activities'),
            ),
          ),
        );

        expect(find.text('Recent Activities'), findsOneWidget);
      });

      testWidgets('should render subtitle when provided', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: SectionHeader(
                title: 'Notifications',
                subtitle: 'Last 7 days',
              ),
            ),
          ),
        );

        expect(find.text('Notifications'), findsOneWidget);
        expect(find.text('Last 7 days'), findsOneWidget);
      });

      testWidgets('should render action widget when provided', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: SectionHeader(
                title: 'Tasks',
                action: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {},
                ),
              ),
            ),
          ),
        );

        expect(find.text('Tasks'), findsOneWidget);
        expect(find.byIcon(Icons.add), findsOneWidget);
        expect(find.byType(IconButton), findsOneWidget);
      });
    });

    group('EmptyState Widget Tests', () {
      testWidgets('should render icon, title, and subtitle', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: EmptyState(
                icon: Icons.inbox,
                title: 'No messages',
                subtitle: 'You have no new messages',
              ),
            ),
          ),
        );

        expect(find.byIcon(Icons.inbox), findsOneWidget);
        expect(find.text('No messages'), findsOneWidget);
        expect(find.text('You have no new messages'), findsOneWidget);
      });

      testWidgets('should render action button when provided', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: EmptyState(
                icon: Icons.add_task,
                title: 'No tasks',
                subtitle: 'Create your first task',
                action: ElevatedButton(
                  onPressed: () {},
                  child: Text('Add Task'),
                ),
              ),
            ),
          ),
        );

        expect(find.text('No tasks'), findsOneWidget);
        expect(find.text('Add Task'), findsOneWidget);
        expect(find.byType(ElevatedButton), findsOneWidget);
      });

      testWidgets('should center content', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: EmptyState(
                icon: Icons.info,
                title: 'Empty',
                subtitle: 'Nothing here',
              ),
            ),
          ),
        );

        expect(find.byType(Center), findsOneWidget);
      });
    });

    group('LoadingOverlay Widget Tests', () {
      testWidgets('should render with default message', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: LoadingOverlay(),
            ),
          ),
        );

        expect(find.text('Loading...'), findsOneWidget);
        expect(find.byType(CircularProgressIndicator), findsOneWidget);
      });

      testWidgets('should render with custom message', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: LoadingOverlay(message: 'Saving data...'),
            ),
          ),
        );

        expect(find.text('Saving data...'), findsOneWidget);
        expect(find.byType(CircularProgressIndicator), findsOneWidget);
      });

      testWidgets('should have semi-transparent background', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: LoadingOverlay(),
            ),
          ),
        );

        final container = tester.widget<Container>(find.byType(Container).first);
        expect(container.color, Colors.black.withOpacity(0.5));
      });
    });

    group('UserSwitcher Widget Tests', () {
      testWidgets('should render user avatar when authenticated', (tester) async {
        final testUser = User(
          id: 'user-123',
          name: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1234567890',
          flatNumber: 'A-101',
          role: UserRole.resident,
          createdAt: DateTime(2023, 1, 1),
        );

        when(mockAuthBloc.state).thenReturn(AuthAuthenticated(testUser));
        when(mockAuthBloc.stream).thenAnswer((_) => Stream.value(AuthAuthenticated(testUser)));

        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: BlocProvider<AuthBloc>.value(
                value: mockAuthBloc,
                child: UserSwitcher(),
              ),
            ),
          ),
        );

        expect(find.byType(CircleAvatar), findsOneWidget);
        expect(find.text('J'), findsOneWidget); // First letter of name
        expect(find.byType(PopupMenuButton), findsOneWidget);
      });

      testWidgets('should render default avatar when not authenticated', (tester) async {
        when(mockAuthBloc.state).thenReturn(const AuthUnauthenticated());
        when(mockAuthBloc.stream).thenAnswer((_) => Stream.value(const AuthUnauthenticated()));

        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: BlocProvider<AuthBloc>.value(
                value: mockAuthBloc,
                child: UserSwitcher(),
              ),
            ),
          ),
        );

        expect(find.byType(CircleAvatar), findsOneWidget);
        expect(find.text('U'), findsOneWidget); // Default letter
      });

      testWidgets('should show popup menu on tap', (tester) async {
        final testUser = User(
          id: 'user-123',
          name: 'Alice Smith',
          email: 'alice.smith@example.com',
          phone: '+1234567890',
          flatNumber: 'B-202',
          role: UserRole.admin,
          createdAt: DateTime(2023, 1, 1),
        );

        when(mockAuthBloc.state).thenReturn(AuthAuthenticated(testUser));
        when(mockAuthBloc.stream).thenAnswer((_) => Stream.value(AuthAuthenticated(testUser)));

        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: BlocProvider<AuthBloc>.value(
                value: mockAuthBloc,
                child: UserSwitcher(),
              ),
            ),
          ),
        );

        // Tap the popup menu button
        await tester.tap(find.byType(PopupMenuButton));
        await tester.pumpAndSettle();

        expect(find.text('Alice Smith'), findsOneWidget);
        expect(find.text('alice.smith@example.com'), findsOneWidget);
        expect(find.text('Sign Out'), findsOneWidget);
        expect(find.byType(RoleIndicator), findsOneWidget);
      });

      testWidgets('should show sign out confirmation dialog', (tester) async {
        final testUser = User(
          id: 'user-123',
          name: 'Bob Johnson',
          email: 'bob.johnson@example.com',
          phone: '+1234567890',
          flatNumber: 'C-303',
          role: UserRole.security,
          createdAt: DateTime(2023, 1, 1),
        );

        when(mockAuthBloc.state).thenReturn(AuthAuthenticated(testUser));
        when(mockAuthBloc.stream).thenAnswer((_) => Stream.value(AuthAuthenticated(testUser)));

        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: BlocProvider<AuthBloc>.value(
                value: mockAuthBloc,
                child: UserSwitcher(),
              ),
            ),
          ),
        );

        // Tap the popup menu button
        await tester.tap(find.byType(PopupMenuButton));
        await tester.pumpAndSettle();

        // Tap the sign out option
        await tester.tap(find.text('Sign Out'));
        await tester.pumpAndSettle();

        // Should show confirmation dialog
        expect(find.byType(AlertDialog), findsOneWidget);
        expect(find.text('Are you sure you want to sign out?'), findsOneWidget);
        expect(find.text('Cancel'), findsOneWidget);
        expect(find.text('Sign Out'), findsNWidgets(2)); // One in menu, one in dialog
      });
    });

    group('Widget Accessibility Tests', () {
      testWidgets('StatusBadge should have accessible text', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: StatusBadge(
                label: 'Complete',
                color: Colors.green,
                icon: Icons.done,
              ),
            ),
          ),
        );

        // Test that text is readable
        final textWidget = tester.widget<Text>(find.text('Complete'));
        expect(textWidget.style?.fontWeight, FontWeight.w600);
      });

      testWidgets('AppCard should be focusable when tappable', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: AppCard(
                onTap: () {},
                child: Text('Tappable'),
              ),
            ),
          ),
        );

        final inkWell = tester.widget<InkWell>(find.byType(InkWell));
        expect(inkWell.onTap, isNotNull);
      });
    });

    group('Theme Integration Tests', () {
      testWidgets('widgets should adapt to dark theme', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            theme: ThemeData.dark(),
            home: Scaffold(
              body: Column(
                children: [
                  AppCard(child: Text('Dark theme test')),
                  StatusBadge(label: 'Status', color: Colors.blue),
                  RoleIndicator(role: UserRole.admin),
                ],
              ),
            ),
          ),
        );

        await tester.pumpAndSettle();

        // Widgets should render without throwing errors in dark theme
        expect(find.byType(AppCard), findsOneWidget);
        expect(find.byType(StatusBadge), findsOneWidget);
        expect(find.byType(RoleIndicator), findsOneWidget);
      });

      testWidgets('widgets should adapt to light theme', (tester) async {
        await tester.pumpWidget(
          MaterialApp(
            theme: ThemeData.light(),
            home: Scaffold(
              body: Column(
                children: [
                  AppCard(child: Text('Light theme test')),
                  StatusBadge(label: 'Status', color: Colors.red),
                  RoleIndicator(role: UserRole.resident),
                ],
              ),
            ),
          ),
        );

        await tester.pumpAndSettle();

        // Widgets should render without throwing errors in light theme
        expect(find.byType(AppCard), findsOneWidget);
        expect(find.byType(StatusBadge), findsOneWidget);
        expect(find.byType(RoleIndicator), findsOneWidget);
      });
    });
  });
}