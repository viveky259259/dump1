# TownSquare Test Suite

This directory contains comprehensive unit tests for the TownSquare Flutter application. The test suite covers models, services, BLoCs, utilities, and widgets with a focus on business logic, state management, and UI behavior.

## 📁 Test Structure

```
test/
├── README.md                    # This file
├── all_tests.dart              # Main test runner
├── test_helpers.dart           # Shared test utilities and helpers
├── blocs/                      # BLoC tests
│   ├── auth_bloc_test.dart
│   ├── invoice_bloc_test.dart
│   └── user_bloc_test.dart
├── models/                     # Data model tests
│   ├── data_models_test.dart
│   └── user_test.dart
├── services/                   # Service layer tests
│   ├── auth_service_test.dart
│   ├── invoice_service_test.dart
│   └── pdf_service_test.dart
├── utils/                      # Utility tests
│   └── constants_test.dart
└── widgets/                    # Widget tests
    └── common_widgets_test.dart
```

## 🧪 Test Categories

### Model Tests (`test/models/`)
- **Data serialization/deserialization**: JSON to model conversion
- **Data validation**: Field validation and constraints
- **Business logic**: Computed properties and methods
- **Edge cases**: Null handling, invalid data formats
- **Enum extensions**: Display names, emojis, permissions

**Key Coverage:**
- User model with role-based permissions
- Invoice models with status calculations
- Community models (Notice, Poll, Ticket)
- Apartment management models

### Service Tests (`test/services/`)
- **Authentication service**: Sign-in/out, user management
- **Invoice service**: Generation, payment processing, notifications
- **PDF service**: Document generation, platform-specific saving
- **External API integration**: Supabase interactions
- **Error handling**: Network failures, invalid responses

**Key Coverage:**
- Mocked external dependencies (Supabase)
- Business rule validation
- Data transformation and processing
- Platform-specific implementations

### BLoC Tests (`test/blocs/`)
- **State management**: State transitions and emissions
- **Event handling**: User interactions and side effects
- **Async operations**: Loading states and error handling
- **Stream management**: User authentication streams
- **Business logic**: Invoice calculations, user filtering

**Key Coverage:**
- Authentication flow (sign-in, sign-up, sign-out)
- Invoice management (generation, payment, filtering)
- User management (loading by role, profile management)

### Widget Tests (`test/widgets/`)
- **UI rendering**: Visual components and layouts
- **User interactions**: Tap, scroll, form input
- **Theme integration**: Light/dark mode support
- **Accessibility**: Screen reader support, contrast
- **State display**: Loading, error, empty states

**Key Coverage:**
- Common UI components (cards, chips, badges)
- User interface elements (role indicators, status badges)
- Interactive components (user switcher, category filters)

### Utility Tests (`test/utils/`)
- **Constants validation**: App configuration values
- **Helper functions**: Utility methods and extensions
- **Theme configuration**: Color schemes, typography
- **Route definitions**: Navigation paths and hierarchy

## 🚀 Running Tests

### All Tests
```bash
flutter test
```

### Specific Test File
```bash
flutter test test/models/user_test.dart
```

### With Coverage Report
```bash
flutter test --coverage
genhtml coverage/lcov.info -o coverage/html
open coverage/html/index.html
```

### Test Runner
```bash
flutter test test/all_tests.dart
```

### Verbose Output
```bash
flutter test --verbose
```

## 📋 Test Dependencies

The following testing packages are required:

```yaml
dev_dependencies:
  flutter_test:
    sdk: flutter
  bloc_test: ^9.1.7      # BLoC testing utilities
  mockito: ^5.4.4        # Mocking framework
  build_runner: ^2.4.8   # Code generation
  mocktail: ^1.0.3       # Alternative mocking
```

### Generating Mocks
```bash
dart run build_runner build
```

## 🎯 Testing Patterns

### Model Tests
```dart
group('User Model Tests', () {
  test('should serialize correctly', () {
    final user = User(...);
    final json = user.toJson();
    expect(json['name'], user.name);
  });

  test('should handle edge cases', () {
    expect(() => User.fromJson(invalidData), throwsA(isA<Exception>()));
  });
});
```

### Service Tests
```dart
group('AuthService Tests', () {
  setUp(() {
    mockClient = MockSupabaseClient();
    authService = AuthService();
  });

  test('should authenticate user', () async {
    when(mockClient.auth.signIn(...)).thenAnswer((_) async => mockResponse);
    final result = await authService.signIn(email, password);
    expect(result, 'success');
  });
});
```

### BLoC Tests
```dart
blocTest<AuthBloc, AuthState>(
  'emits authenticated when sign in succeeds',
  build: () => AuthBloc(mockAuthService),
  act: (bloc) => bloc.add(SignInRequested(email, password)),
  expect: () => [AuthLoading(), AuthAuthenticated(user)],
);
```

### Widget Tests
```dart
testWidgets('should render user name', (tester) async {
  await tester.pumpWidget(MaterialApp(
    home: UserCard(user: testUser),
  ));
  
  expect(find.text(testUser.name), findsOneWidget);
});
```

## 🛡️ Test Best Practices

### 1. **Isolation**
- Each test should be independent
- Use `setUp()` and `tearDown()` for clean state
- Mock external dependencies

### 2. **Coverage**
- Aim for >90% code coverage
- Test both happy path and error cases
- Include edge cases and boundary conditions

### 3. **Readability**
- Use descriptive test names
- Group related tests together
- Include arrange-act-assert comments

### 4. **Performance**
- Keep tests fast (<1s each)
- Use `pumpAndSettle()` appropriately
- Avoid unnecessary animations in tests

### 5. **Maintainability**
- Use test helpers for common setup
- Extract test data to constants
- Keep tests simple and focused

## 🐛 Common Issues & Solutions

### Mock Generation Issues
```bash
# Clean and regenerate
flutter clean
dart run build_runner clean
dart run build_runner build --delete-conflicting-outputs
```

### Widget Test Failures
- Ensure `MaterialApp` wrapper for widgets
- Use `pumpAndSettle()` for animations
- Check for proper `find` selectors

### BLoC Test Issues
- Mock all dependencies properly
- Use `blocTest` for state transitions
- Verify event calls with `verify()`

### Async Test Problems
- Use `await` for all async operations
- Handle `Stream` subscriptions properly
- Clean up resources in `tearDown()`

## 📊 Coverage Goals

| Component | Target Coverage | Current Status |
|-----------|----------------|----------------|
| Models    | 95%+          | ✅ Complete    |
| Services  | 90%+          | ✅ Complete    |
| BLoCs     | 95%+          | ✅ Complete    |
| Widgets   | 85%+          | ✅ Complete    |
| Utils     | 90%+          | ✅ Complete    |

## 🔄 Continuous Integration

Tests are configured to run on:
- Pull requests
- Main branch pushes
- Nightly builds

### GitHub Actions Example
```yaml
- name: Run tests
  run: flutter test --coverage
- name: Upload coverage
  uses: codecov/codecov-action@v1
```

## 📝 Contributing

When adding new features:

1. **Write tests first** (TDD approach)
2. **Ensure >90% coverage** for new code
3. **Update existing tests** if APIs change
4. **Add integration tests** for complex flows
5. **Document test scenarios** in code comments

### Test Checklist
- [ ] Unit tests for new models
- [ ] Service tests with mocked dependencies
- [ ] BLoC tests for state management
- [ ] Widget tests for UI components
- [ ] Edge case coverage
- [ ] Error scenario testing
- [ ] Performance considerations
- [ ] Accessibility testing

## 🎯 Future Improvements

1. **Integration Tests**: Full user journey testing
2. **Performance Tests**: Load testing and benchmarks
3. **Visual Tests**: Screenshot comparison testing
4. **Accessibility Tests**: Comprehensive a11y validation
5. **End-to-End Tests**: Real device testing

---

For questions or issues with the test suite, please refer to the [main project documentation](../README.md) or open an issue in the repository.