import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:townsquare/blocs/auth/auth_bloc.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';

/// Test helpers and utilities for the TownSquare app tests
class TestHelpers {
  /// Creates a test user with default values
  static User createTestUser({
    String id = 'test-user-123',
    String name = 'Test User',
    String email = 'test@example.com',
    String phone = '+1234567890',
    String flatNumber = 'A-101',
    UserRole role = UserRole.resident,
    DateTime? createdAt,
  }) {
    return User(
      id: id,
      name: name,
      email: email,
      phone: phone,
      flatNumber: flatNumber,
      role: role,
      createdAt: createdAt ?? DateTime(2023, 1, 1),
    );
  }

  /// Creates a list of test users with different roles
  static List<User> createTestUsers() {
    return [
      createTestUser(
        id: 'admin-1',
        name: 'Admin User',
        email: 'admin@example.com',
        role: UserRole.admin,
        flatNumber: 'ADMIN',
      ),
      createTestUser(
        id: 'resident-1',
        name: 'John Doe',
        email: 'john.doe@example.com',
        role: UserRole.resident,
        flatNumber: 'A-101',
      ),
      createTestUser(
        id: 'resident-2',
        name: 'Jane Smith',
        email: 'jane.smith@example.com',
        role: UserRole.resident,
        flatNumber: 'B-202',
      ),
      createTestUser(
        id: 'security-1',
        name: 'Security Guard',
        email: 'security@example.com',
        role: UserRole.security,
        flatNumber: 'SECURITY',
      ),
      createTestUser(
        id: 'staff-1',
        name: 'Maintenance Staff',
        email: 'staff@example.com',
        role: UserRole.staff,
        flatNumber: 'STAFF',
      ),
    ];
  }

  /// Creates a widget wrapped with MaterialApp for testing
  static Widget createTestApp({
    required Widget home,
    List<BlocProvider>? providers,
    ThemeData? theme,
  }) {
    Widget app = MaterialApp(
      home: home,
      theme: theme,
    );

    if (providers != null && providers.isNotEmpty) {
      app = MultiBlocProvider(
        providers: providers,
        child: app,
      );
    }

    return app;
  }

  /// Pumps a widget with standard test setup
  static Future<void> pumpTestWidget(
    WidgetTester tester,
    Widget widget, {
    List<BlocProvider>? providers,
    ThemeData? theme,
  }) async {
    await tester.pumpWidget(createTestApp(
      home: widget,
      providers: providers,
      theme: theme,
    ));
  }

  /// Creates a mock AuthBloc with common behavior
  static AuthBloc createMockAuthBloc({User? currentUser}) {
    final authBloc = MockAuthBloc();
    // Add common mock behavior here if needed
    return authBloc;
  }

  /// Verifies that a widget handles different theme modes correctly
  static Future<void> testWidgetInBothThemes(
    WidgetTester tester,
    Widget Function() createWidget,
  ) async {
    // Test in light theme
    await tester.pumpWidget(createTestApp(
      home: Scaffold(body: createWidget()),
      theme: ThemeData.light(),
    ));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);

    // Test in dark theme
    await tester.pumpWidget(createTestApp(
      home: Scaffold(body: createWidget()),
      theme: ThemeData.dark(),
    ));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  }

  /// Waits for all animations and async operations to complete
  static Future<void> pumpAndSettle(WidgetTester tester) async {
    await tester.pumpAndSettle(const Duration(seconds: 5));
  }

  /// Verifies that a widget is accessible
  static Future<void> verifyAccessibility(WidgetTester tester) async {
    final SemanticsHandle handle = tester.ensureSemantics();
    await expectLater(tester, meetsGuideline(androidTapTargetGuideline));
    await expectLater(tester, meetsGuideline(textContrastGuideline));
    handle.dispose();
  }

  /// Creates test data for different scenarios
  static Map<String, dynamic> createTestInvoiceData({
    String id = 'inv-123',
    String invoiceNumber = 'INV-2023-06-0001',
    String status = 'unpaid',
    double amount = 5000.0,
  }) {
    return {
      'id': id,
      'invoice_number': invoiceNumber,
      'apartment_id': 'apt-123',
      'resident_id': 'user-123',
      'flat_number': 'A-101',
      'invoice_month': 6,
      'invoice_year': 2023,
      'maintenance_amount': amount.toString(),
      'due_date': '2023-06-25',
      'status': status,
      'late_fee': '0.0',
      'total_amount': amount.toString(),
      'generated_by': 'admin-123',
      'created_at': '2023-06-01T00:00:00.000',
      'updated_at': '2023-06-01T00:00:00.000',
    };
  }

  /// Creates test data for apartments
  static Map<String, dynamic> createTestApartmentData({
    String id = 'apt-123',
    String flatNumber = 'A-101',
    String bhkType = '2BHK',
    double maintenanceAmount = 5000.0,
    bool isOccupied = true,
  }) {
    return {
      'id': id,
      'flat_number': flatNumber,
      'owner_id': 'owner-123',
      'tenant_id': isOccupied ? 'user-123' : null,
      'maintenance_amount': maintenanceAmount.toString(),
      'floor_number': 1,
      'bhk_type': bhkType,
      'carpet_area': '1200.0',
      'is_occupied': isOccupied,
      'created_at': '2023-01-01T00:00:00.000',
      'updated_at': '2023-01-01T00:00:00.000',
    };
  }
}

/// Mock class for AuthBloc - will be generated by mockito
class MockAuthBloc extends Mock implements AuthBloc {}

/// Mock class for AuthService - will be generated by mockito  
class MockAuthService extends Mock implements AuthService {}

/// Custom matchers for tests
class CustomMatchers {
  /// Matches a widget that contains specific text
  static Matcher hasText(String text) {
    return isA<Widget>().having(
      (widget) => widget.toString().contains(text),
      'contains text',
      true,
    );
  }

  /// Matches a color with specific properties
  static Matcher isColorWithOpacity(Color color, double opacity) {
    return isA<Color>()
        .having((c) => c.red, 'red', color.red)
        .having((c) => c.green, 'green', color.green)
        .having((c) => c.blue, 'blue', color.blue)
        .having((c) => c.opacity, 'opacity', closeTo(opacity, 0.01));
  }

  /// Matches a user with specific role
  static Matcher isUserWithRole(UserRole role) {
    return isA<User>().having((user) => user.role, 'role', role);
  }
}

/// Test constants
class TestConstants {
  static const Duration defaultTestTimeout = Duration(seconds: 10);
  static const Duration shortDelay = Duration(milliseconds: 100);
  static const Duration mediumDelay = Duration(milliseconds: 300);
  static const Duration longDelay = Duration(milliseconds: 500);

  static const String testEmail = 'test@example.com';
  static const String testPassword = 'testpassword123';
  static const String testName = 'Test User';
  static const String testPhone = '+1234567890';
  static const String testFlatNumber = 'A-101';

  static const Map<String, String> validEmails = {
    'simple': 'test@example.com',
    'subdomain': 'user@mail.example.com',
    'numbers': 'user123@test123.com',
    'dashes': 'test-user@example-domain.com',
  };

  static const Map<String, String> invalidEmails = {
    'no_at': 'testexample.com',
    'no_domain': 'test@',
    'no_tld': 'test@example',
    'spaces': 'test @example.com',
  };
}