import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/pdf_service.dart';

void main() {
  group('PdfService Tests', () {
    late MaintenanceInvoice testInvoice;
    late User testResident;

    setUp(() {
      testInvoice = MaintenanceInvoice(
        id: 'inv-123',
        invoiceNumber: 'INV-2023-06-0001',
        apartmentId: 'apt-123',
        residentId: 'user-123',
        flatNumber: 'A-101',
        invoiceMonth: 6,
        invoiceYear: 2023,
        maintenanceAmount: 5000.0,
        dueDate: DateTime(2023, 6, 25),
        status: InvoiceStatus.unpaid,
        lateFee: 0.0,
        totalAmount: 5000.0,
        generatedBy: 'admin-123',
        createdAt: DateTime(2023, 6, 1),
        updatedAt: DateTime(2023, 6, 1),
      );

      testResident = User(
        id: 'user-123',
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1234567890',
        flatNumber: 'A-101',
        role: UserRole.resident,
        createdAt: DateTime(2023, 1, 1),
      );
    });

    group('PDF Generation Tests', () {
      test('should generate PDF bytes successfully', () async {
        // Act
        final pdfBytes = await PdfService.generateInvoicePdf(testInvoice);

        // Assert
        expect(pdfBytes, isA<Uint8List>());
        expect(pdfBytes.isNotEmpty, true);
        // PDF files start with %PDF
        expect(String.fromCharCodes(pdfBytes.take(4)), '%PDF');
      });

      test('should generate PDF with resident info', () async {
        // Act
        final pdfBytes = await PdfService.generateInvoicePdf(
          testInvoice, 
          residentInfo: testResident,
        );

        // Assert
        expect(pdfBytes, isA<Uint8List>());
        expect(pdfBytes.isNotEmpty, true);
        expect(String.fromCharCodes(pdfBytes.take(4)), '%PDF');
      });

      test('should generate PDF for paid invoice', () async {
        // Arrange
        final paidInvoice = MaintenanceInvoice(
          id: 'inv-123',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 5000.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.paid,
          paymentDate: DateTime(2023, 6, 20),
          paymentMethod: 'Online Banking',
          lateFee: 0.0,
          totalAmount: 5000.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 20),
        );

        // Act
        final pdfBytes = await PdfService.generateInvoicePdf(paidInvoice);

        // Assert
        expect(pdfBytes, isA<Uint8List>());
        expect(pdfBytes.isNotEmpty, true);
      });

      test('should generate PDF for invoice with late fee', () async {
        // Arrange
        final lateInvoice = MaintenanceInvoice(
          id: 'inv-123',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 5000.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.overdue,
          lateFee: 500.0,
          totalAmount: 5500.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        );

        // Act
        final pdfBytes = await PdfService.generateInvoicePdf(lateInvoice);

        // Assert
        expect(pdfBytes, isA<Uint8List>());
        expect(pdfBytes.isNotEmpty, true);
      });
    });

    group('PDF Color Tests', () {
      test('should return correct status colors', () {
        // This would test private methods, so we'd need to make them public or test through public interfaces
        // For now, we test that the PDF generation works with different statuses
        
        final statuses = [
          InvoiceStatus.paid,
          InvoiceStatus.unpaid,
          InvoiceStatus.overdue,
        ];

        for (final status in statuses) {
          expect(
            () async {
              final invoice = MaintenanceInvoice(
                id: 'inv-123',
                invoiceNumber: 'INV-2023-06-0001',
                apartmentId: 'apt-123',
                residentId: 'user-123',
                flatNumber: 'A-101',
                invoiceMonth: 6,
                invoiceYear: 2023,
                maintenanceAmount: 5000.0,
                dueDate: DateTime(2023, 6, 25),
                status: status,
                lateFee: 0.0,
                totalAmount: 5000.0,
                generatedBy: 'admin-123',
                createdAt: DateTime(2023, 6, 1),
                updatedAt: DateTime(2023, 6, 1),
              );
              await PdfService.generateInvoicePdf(invoice);
            },
            returnsNormally,
          );
        }
      });
    });

    group('Edge Cases Tests', () {
      test('should handle invoice with no resident info', () async {
        // Act
        final pdfBytes = await PdfService.generateInvoicePdf(testInvoice);

        // Assert
        expect(pdfBytes, isA<Uint8List>());
        expect(pdfBytes.isNotEmpty, true);
      });

      test('should handle invoice with null payment date', () async {
        // Arrange
        final invoice = MaintenanceInvoice(
          id: 'inv-123',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 5000.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.unpaid,
          paymentDate: null,
          lateFee: 0.0,
          totalAmount: 5000.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        );

        // Act & Assert
        expect(
          () => PdfService.generateInvoicePdf(invoice),
          returnsNormally,
        );
      });

      test('should handle zero amounts', () async {
        // Arrange
        final zeroAmountInvoice = MaintenanceInvoice(
          id: 'inv-123',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 0.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.unpaid,
          lateFee: 0.0,
          totalAmount: 0.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        );

        // Act & Assert
        expect(
          () => PdfService.generateInvoicePdf(zeroAmountInvoice),
          returnsNormally,
        );
      });

      test('should handle large amounts', () async {
        // Arrange
        final largeAmountInvoice = MaintenanceInvoice(
          id: 'inv-123',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 999999.99,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.unpaid,
          lateFee: 0.0,
          totalAmount: 999999.99,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        );

        // Act & Assert
        expect(
          () => PdfService.generateInvoicePdf(largeAmountInvoice),
          returnsNormally,
        );
      });
    });

    group('Date Formatting Tests', () {
      test('should handle different date formats correctly', () async {
        // Test with various dates throughout the year
        for (int month = 1; month <= 12; month++) {
          final invoice = MaintenanceInvoice(
            id: 'inv-$month',
            invoiceNumber: 'INV-2023-${month.toString().padLeft(2, '0')}-0001',
            apartmentId: 'apt-123',
            residentId: 'user-123',
            flatNumber: 'A-101',
            invoiceMonth: month,
            invoiceYear: 2023,
            maintenanceAmount: 5000.0,
            dueDate: DateTime(2023, month, 25),
            status: InvoiceStatus.unpaid,
            lateFee: 0.0,
            totalAmount: 5000.0,
            generatedBy: 'admin-123',
            createdAt: DateTime(2023, month, 1),
            updatedAt: DateTime(2023, month, 1),
          );

          // Act & Assert
          expect(
            () => PdfService.generateInvoicePdf(invoice),
            returnsNormally,
          );
        }
      });
    });

    // Note: The following tests would require platform-specific testing
    // and are commented out as they may not work in all test environments

    /*
    group('Platform-specific Tests', () {
      testWidgets('should save PDF on mobile platforms', (tester) async {
        // This test would require a real device/emulator
        // and proper file system permissions
      });

      testWidgets('should download PDF on web platform', (tester) async {
        // This test would require a web browser environment
      });

      testWidgets('should share PDF successfully', (tester) async {
        // This test would require the sharing functionality to be available
      });

      testWidgets('should print PDF successfully', (tester) async {
        // This test would require a printer or print preview functionality
      });
    });
    */
  });
}