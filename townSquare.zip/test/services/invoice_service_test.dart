import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/services/invoice_service.dart';

import '../mocks.dart';

void main() {
  group('InvoiceService Tests', () {
    late MockInvoiceService mockInvoiceService;
    late List<MaintenanceInvoice> testInvoices;

    setUp(() {
      mockInvoiceService = MockInvoiceService();

      testInvoices = [
        MaintenanceInvoice(
          id: 'invoice-1',
          invoiceNumber: 'INV-2024-01-0001',
          apartmentId: 'apt-1',
          residentId: 'user-1',
          flatNumber: 'A-101',
          invoiceMonth: 1,
          invoiceYear: 2024,
          maintenanceAmount: 15000.0,
          dueDate: DateTime(2024, 2, 15),
          status: InvoiceStatus.unpaid,
          totalAmount: 15000.0,
          generatedBy: 'admin-1',
          createdAt: DateTime(2024, 1, 15),
          updatedAt: DateTime(2024, 1, 15),
        ),
        MaintenanceInvoice(
          id: 'invoice-2',
          invoiceNumber: 'INV-2024-01-0002',
          apartmentId: 'apt-2',
          residentId: 'user-2',
          flatNumber: 'B-202',
          invoiceMonth: 1,
          invoiceYear: 2024,
          maintenanceAmount: 12000.0,
          dueDate: DateTime(2024, 2, 10),
          status: InvoiceStatus.paid,
          totalAmount: 12000.0,
          generatedBy: 'admin-1',
          createdAt: DateTime(2024, 1, 10),
          updatedAt: DateTime(2024, 1, 25),
        ),
      ];
    });

    group('Get Invoices Tests', () {
      test('should get all invoices successfully', () async {
        // Arrange
        when(mockInvoiceService.getInvoices())
            .thenAnswer((_) async => testInvoices);

        // Act
        final result = await mockInvoiceService.getInvoices();

        // Assert
        expect(result, equals(testInvoices));
        verify(mockInvoiceService.getInvoices()).called(1);
      });

      test('should get invoices for specific resident', () async {
        // Arrange
        final userInvoices = testInvoices.where((inv) => inv.residentId == 'user-1').toList();
        when(mockInvoiceService.getInvoices(residentId: 'user-1'))
            .thenAnswer((_) async => userInvoices);

        // Act
        final result = await mockInvoiceService.getInvoices(residentId: 'user-1');

        // Assert
        expect(result, equals(userInvoices));
        verify(mockInvoiceService.getInvoices(residentId: 'user-1')).called(1);
      });

      test('should handle database errors when getting invoices', () async {
        // Arrange
        when(mockInvoiceService.getInvoices())
            .thenThrow(Exception('Database connection failed'));

        // Act & Assert
        expect(() => mockInvoiceService.getInvoices(), throwsException);
      });
    });

    group('Generate Invoices Tests', () {
      test('should generate monthly invoices successfully', () async {
        // Arrange
        when(mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1'))
            .thenAnswer((_) async => testInvoices);

        // Act
        final result = await mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1');

        // Assert
        expect(result, equals(testInvoices));
        verify(mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1')).called(1);
      });

      test('should handle errors when generating invoices', () async {
        // Arrange
        when(mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1'))
            .thenThrow(Exception('Failed to generate invoices'));

        // Act & Assert
        expect(
          () => mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1'),
          throwsException,
        );
      });
    });

    group('Update Invoice Tests', () {
      test('should mark invoice as paid successfully', () async {
        // Arrange
        final updatedInvoice = testInvoices.first.copyWith(status: InvoiceStatus.paid);
        when(mockInvoiceService.markInvoiceAsPaid('invoice-1', 'credit_card'))
            .thenAnswer((_) async => updatedInvoice);

        // Act
        final result = await mockInvoiceService.markInvoiceAsPaid('invoice-1', 'credit_card');

        // Assert
        expect(result.status, equals(InvoiceStatus.paid));
      });

      test('should handle errors when updating non-existent invoice', () async {
        // Arrange
        when(mockInvoiceService.markInvoiceAsPaid('non-existent', 'cash'))
            .thenThrow(Exception('Invoice not found'));

        // Act & Assert
        expect(
          () => mockInvoiceService.markInvoiceAsPaid('non-existent', 'cash'),
          throwsException,
        );
      });
    });

    group('Generate Single Invoice Tests', () {
      test('should generate invoice for apartment successfully', () async {
        // Arrange
        when(mockInvoiceService.generateInvoiceForApartment('apt-1', 2, 2024, 'admin-1'))
            .thenAnswer((_) async => testInvoices.first);

        // Act
        final result = await mockInvoiceService.generateInvoiceForApartment('apt-1', 2, 2024, 'admin-1');

        // Assert
        expect(result, equals(testInvoices.first));
        verify(mockInvoiceService.generateInvoiceForApartment('apt-1', 2, 2024, 'admin-1')).called(1);
      });
    });

    group('Notification Tests', () {
      test('should send invoice notification successfully', () async {
        // Arrange
        when(mockInvoiceService.sendInvoiceNotification(
          'invoice-1', 
          NotificationType.reminder, 
          SentVia.inApp,
        )).thenAnswer((_) async {});

        // Act
        await mockInvoiceService.sendInvoiceNotification(
          'invoice-1',
          NotificationType.reminder,
          SentVia.inApp,
        );

        // Assert
        verify(mockInvoiceService.sendInvoiceNotification(
          'invoice-1',
          NotificationType.reminder,
          SentVia.inApp,
        )).called(1);
      });

      test('should handle errors when sending notifications', () async {
        // Arrange
        when(mockInvoiceService.sendInvoiceNotification(
          'invalid-id',
          NotificationType.reminder,
          SentVia.email,
        )).thenThrow(Exception('Notification service error'));

        // Act & Assert
        expect(
          () => mockInvoiceService.sendInvoiceNotification(
            'invalid-id',
            NotificationType.reminder,
            SentVia.email,
          ),
          throwsException,
        );
      });
    });

    group('Apartment Management Tests', () {
      test('should get apartments successfully', () async {
        // Arrange
        final apartments = <Apartment>[];
        when(mockInvoiceService.getApartments())
            .thenAnswer((_) async => apartments);

        // Act
        final result = await mockInvoiceService.getApartments();

        // Assert
        expect(result, equals(apartments));
        verify(mockInvoiceService.getApartments()).called(1);
      });

      test('should update apartment maintenance amount successfully', () async {
        // Arrange
        final apartment = Apartment(
          id: 'apt-1',
          flatNumber: 'A-101',
          ownerId: 'owner-1',
          maintenanceAmount: 16000.0,
          floorNumber: 1,
          bhkType: BhkType.bhk2,
          carpetArea: 1200.0,
          isOccupied: true,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );

        when(mockInvoiceService.updateApartmentMaintenanceAmount('apt-1', 16000.0))
            .thenAnswer((_) async => apartment);

        // Act
        final result = await mockInvoiceService.updateApartmentMaintenanceAmount('apt-1', 16000.0);

        // Assert
        expect(result.maintenanceAmount, equals(16000.0));
      });
    });

    group('Notification History Tests', () {
      test('should get invoice notifications successfully', () async {
        // Arrange
        final notifications = <InvoiceNotification>[];
        when(mockInvoiceService.getInvoiceNotifications('user-1'))
            .thenAnswer((_) async => notifications);

        // Act
        final result = await mockInvoiceService.getInvoiceNotifications('user-1');

        // Assert
        expect(result, equals(notifications));
        verify(mockInvoiceService.getInvoiceNotifications('user-1')).called(1);
      });
    });

    group('Edge Cases and Error Handling', () {
      test('should handle network timeout errors', () async {
        // Arrange
        when(mockInvoiceService.getInvoices())
            .thenThrow(Exception('Connection timeout'));

        // Act & Assert
        expect(() => mockInvoiceService.getInvoices(), throwsException);
      });

      test('should handle permission denied errors', () async {
        // Arrange
        when(mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1'))
            .thenThrow(Exception('Permission denied'));

        // Act & Assert
        expect(
          () => mockInvoiceService.generateInvoicesForMonth(2, 2024, 'admin-1'),
          throwsException,
        );
      });

      test('should handle malformed data errors', () async {
        // Arrange
        when(mockInvoiceService.getInvoices())
            .thenThrow(const FormatException('Invalid invoice data'));

        // Act & Assert
        expect(
          () => mockInvoiceService.getInvoices(),
          throwsA(isA<FormatException>()),
        );
      });
    });
  });
}