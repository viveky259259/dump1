import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';

import '../mocks.dart';

void main() {
  group('AuthService Tests', () {
    late MockAuthService mockAuthService;
    late List<User> testUsers;

    setUp(() {
      mockAuthService = MockAuthService();

      testUsers = [
        User(
          id: 'user-1',
          name: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1234567890',
          flatNumber: 'A-101',
          role: UserRole.resident,
          createdAt: DateTime(2023, 1, 1),
        ),
        User(
          id: 'admin-1',
          name: 'Admin User',
          email: 'admin@example.com',
          phone: '+1111111111',
          flatNumber: 'ADMIN',
          role: UserRole.admin,
          createdAt: DateTime(2023, 1, 1),
        ),
      ];
    });

    group('Sign In Tests', () {
      test('should return success on successful sign in', () async {
        // Arrange
        when(mockAuthService.signIn('test@example.com', 'password'))
            .thenAnswer((_) async => 'Success');

        // Act
        final result = await mockAuthService.signIn('test@example.com', 'password');

        // Assert
        expect(result, equals('Success'));
        verify(mockAuthService.signIn('test@example.com', 'password')).called(1);
      });

      test('should handle invalid credentials', () async {
        // Arrange
        when(mockAuthService.signIn('invalid@example.com', 'wrongpassword'))
            .thenThrow(Exception('Invalid credentials'));

        // Act & Assert
        expect(
          () => mockAuthService.signIn('invalid@example.com', 'wrongpassword'),
          throwsException,
        );
      });
    });

    group('User Management Tests', () {
      test('should get all users successfully', () async {
        // Arrange
        when(mockAuthService.getAllUsers())
            .thenAnswer((_) async => testUsers);

        // Act
        final result = await mockAuthService.getAllUsers();

        // Assert
        expect(result, equals(testUsers));
        verify(mockAuthService.getAllUsers()).called(1);
      });

      test('should get users by role successfully', () async {
        // Arrange
        final residents = testUsers.where((user) => user.role == UserRole.resident).toList();
        when(mockAuthService.getUsersByRole(UserRole.resident))
            .thenAnswer((_) async => residents);

        // Act
        final result = await mockAuthService.getUsersByRole(UserRole.resident);

        // Assert
        expect(result, equals(residents));
        verify(mockAuthService.getUsersByRole(UserRole.resident)).called(1);
      });

      test('should get user by id successfully', () async {
        // Arrange
        when(mockAuthService.getUserById('user-1'))
            .thenAnswer((_) async => testUsers.first);

        // Act
        final result = await mockAuthService.getUserById('user-1');

        // Assert
        expect(result, equals(testUsers.first));
        verify(mockAuthService.getUserById('user-1')).called(1);
      });

      test('should return null for non-existent user id', () async {
        // Arrange
        when(mockAuthService.getUserById('non-existent'))
            .thenAnswer((_) async => null);

        // Act
        final result = await mockAuthService.getUserById('non-existent');

        // Assert
        expect(result, isNull);
      });
    });

    group('Authentication State Tests', () {
      test('should check if user is admin', () {
        // Arrange
        when(mockAuthService.isAdmin).thenReturn(true);

        // Act
        final result = mockAuthService.isAdmin;

        // Assert
        expect(result, isTrue);
      });

      test('should get current user', () {
        // Arrange
        when(mockAuthService.currentUser).thenReturn(testUsers.first);

        // Act
        final result = mockAuthService.currentUser;

        // Assert
        expect(result, equals(testUsers.first));
      });
    });

    group('Error Handling Tests', () {
      test('should handle authentication timeout', () async {
        // Arrange
        when(mockAuthService.signIn('test@example.com', 'password'))
            .thenThrow(Exception('Request timeout'));

        // Act & Assert
        expect(
          () => mockAuthService.signIn('test@example.com', 'password'),
          throwsException,
        );
      });

      test('should handle malformed user data', () async {
        // Arrange
        when(mockAuthService.getUserById('malformed-user'))
            .thenThrow(const FormatException('Invalid user data'));

        // Act & Assert
        expect(
          () => mockAuthService.getUserById('malformed-user'),
          throwsA(isA<FormatException>()),
        );
      });

      test('should handle permission denied errors', () async {
        // Arrange
        when(mockAuthService.getUsersByRole(UserRole.admin))
            .thenThrow(Exception('Permission denied'));

        // Act & Assert
        expect(
          () => mockAuthService.getUsersByRole(UserRole.admin),
          throwsException,
        );
      });
    });
  });
}