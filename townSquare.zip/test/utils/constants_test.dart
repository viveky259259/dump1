import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:townsquare/utils/constants.dart';

void main() {
  group('AppConstants Tests', () {
    test('should have correct app information', () {
      expect(AppConstants.appName, 'TownSquare');
      expect(AppConstants.appVersion, '1.0.0');
    });

    test('should have consistent dimension values', () {
      expect(AppConstants.defaultPadding, 16.0);
      expect(AppConstants.cardBorderRadius, 16.0);
      expect(AppConstants.buttonBorderRadius, 12.0);
      
      // Ensure card border radius is not smaller than button border radius
      expect(AppConstants.cardBorderRadius >= AppConstants.buttonBorderRadius, true);
    });

    test('should have reasonable animation durations', () {
      expect(AppConstants.shortAnimation, const Duration(milliseconds: 200));
      expect(AppConstants.mediumAnimation, const Duration(milliseconds: 300));
      expect(AppConstants.longAnimation, const Duration(milliseconds: 500));
      
      // Ensure durations are in ascending order
      expect(AppConstants.shortAnimation < AppConstants.mediumAnimation, true);
      expect(AppConstants.mediumAnimation < AppConstants.longAnimation, true);
    });

    test('should have appropriate panic button delay', () {
      expect(AppConstants.panicButtonActivationDelay, const Duration(seconds: 3));
      
      // Panic button delay should be reasonable (not too short or too long)
      expect(AppConstants.panicButtonActivationDelay.inSeconds >= 2, true);
      expect(AppConstants.panicButtonActivationDelay.inSeconds <= 5, true);
    });

    test('should have valid contact information', () {
      expect(AppConstants.emergencyContactNumber, '911');
      expect(AppConstants.managementEmail, 'admin@townsquare.com');
      
      // Validate email format (basic check)
      expect(AppConstants.managementEmail.contains('@'), true);
      expect(AppConstants.managementEmail.contains('.'), true);
    });
  });

  group('AppIcons Tests', () {
    test('should have all required navigation icons', () {
      expect(AppIcons.home, Icons.home_rounded);
      expect(AppIcons.notices, Icons.campaign_rounded);
      expect(AppIcons.tickets, Icons.support_agent_rounded);
      expect(AppIcons.security, Icons.security_rounded);
      expect(AppIcons.profile, Icons.account_circle_rounded);
    });

    test('should have all action icons', () {
      expect(AppIcons.add, Icons.add_rounded);
      expect(AppIcons.filter, Icons.filter_list_rounded);
      expect(AppIcons.search, Icons.search_rounded);
      expect(AppIcons.emergency, Icons.emergency_rounded);
    });

    test('should have all communication icons', () {
      expect(AppIcons.like, Icons.favorite_rounded);
      expect(AppIcons.comment, Icons.chat_bubble_rounded);
      expect(AppIcons.attachment, Icons.attach_file_rounded);
      expect(AppIcons.camera, Icons.camera_alt_rounded);
    });

    test('should have all utility icons', () {
      expect(AppIcons.qrCode, Icons.qr_code_rounded);
      expect(AppIcons.pin, Icons.push_pin_rounded);
      expect(AppIcons.calendar, Icons.calendar_month_rounded);
      expect(AppIcons.clock, Icons.access_time_rounded);
    });

    test('should have all contact icons', () {
      expect(AppIcons.person, Icons.person_rounded);
      expect(AppIcons.phone, Icons.phone_rounded);
      expect(AppIcons.email, Icons.email_rounded);
      expect(AppIcons.location, Icons.location_on_rounded);
    });

    test('should have all settings and action icons', () {
      expect(AppIcons.settings, Icons.settings_rounded);
      expect(AppIcons.logout, Icons.logout_rounded);
      expect(AppIcons.check, Icons.check_rounded);
      expect(AppIcons.close, Icons.close_rounded);
    });

    test('should have all status icons', () {
      expect(AppIcons.info, Icons.info_rounded);
      expect(AppIcons.warning, Icons.warning_rounded);
      expect(AppIcons.error, Icons.error_rounded);
      expect(AppIcons.success, Icons.check_circle_rounded);
    });

    test('should use consistent icon style (rounded)', () {
      // All icon names should contain 'rounded' for consistency
      const iconNames = [
        'home_rounded',
        'campaign_rounded',
        'support_agent_rounded',
        'security_rounded',
        'account_circle_rounded',
      ];
      
      // This is a basic check - in a real test you might want to inspect
      // the actual IconData objects more thoroughly
      expect(iconNames.every((name) => name.contains('rounded')), true);
    });
  });

  group('AppColors Tests', () {
    test('should have valid status colors', () {
      expect(AppColors.success, const Color(0xFF4CAF50));
      expect(AppColors.warning, const Color(0xFFFF9800));
      expect(AppColors.error, const Color(0xFFF44336));
      expect(AppColors.info, const Color(0xFF2196F3));
      
      // Colors should be opaque
      expect(AppColors.success.alpha, 255);
      expect(AppColors.warning.alpha, 255);
      expect(AppColors.error.alpha, 255);
      expect(AppColors.info.alpha, 255);
    });

    test('should have appropriate ticket status colors', () {
      expect(AppColors.ticketOpen, const Color(0xFFE3F2FD));
      expect(AppColors.ticketInProgress, const Color(0xFFFFF3E0));
      expect(AppColors.ticketResolved, const Color(0xFFE8F5E8));
      expect(AppColors.ticketClosed, const Color(0xFFF5F5F5));
      
      // Ticket status colors should be light (background colors)
      expect(AppColors.ticketOpen.computeLuminance() > 0.5, true);
      expect(AppColors.ticketInProgress.computeLuminance() > 0.5, true);
      expect(AppColors.ticketResolved.computeLuminance() > 0.5, true);
      expect(AppColors.ticketClosed.computeLuminance() > 0.5, true);
    });

    test('should have appropriate emergency colors', () {
      expect(AppColors.emergency, const Color(0xFFD32F2F));
      expect(AppColors.emergencyBackground, const Color(0xFFFFEBEE));
      
      // Emergency color should be dark (foreground), background should be light
      expect(AppColors.emergency.computeLuminance() < 0.5, true);
      expect(AppColors.emergencyBackground.computeLuminance() > 0.5, true);
    });

    test('should have good contrast between related colors', () {
      // Emergency colors should have good contrast
      final contrastRatio = _calculateContrastRatio(
        AppColors.emergency,
        AppColors.emergencyBackground,
      );
      expect(contrastRatio > 4.5, true); // WCAG AA standard
    });
  });

  group('AppTexts Tests', () {
    test('should have all navigation labels', () {
      expect(AppTexts.homeTab, 'Home');
      expect(AppTexts.noticesTab, 'Notices');
      expect(AppTexts.ticketsTab, 'Tickets');
      expect(AppTexts.securityTab, 'Security');
    });

    test('should have consistent home screen texts', () {
      expect(AppTexts.welcomeMessage, 'Welcome to TownSquare');
      expect(AppTexts.quickActions, 'Quick Actions');
      
      // Welcome message should contain app name
      expect(AppTexts.welcomeMessage.contains('TownSquare'), true);
    });

    test('should have all notices-related texts', () {
      expect(AppTexts.noticeBoard, 'Notice Board');
      expect(AppTexts.createNotice, 'Create Notice');
      expect(AppTexts.allNotices, 'All Notices');
      expect(AppTexts.pinnedNotices, 'Pinned Notices');
    });

    test('should have all tickets-related texts', () {
      expect(AppTexts.myTickets, 'My Tickets');
      expect(AppTexts.createTicket, 'Create Ticket');
      expect(AppTexts.ticketHistory, 'Ticket History');
      expect(AppTexts.assignTicket, 'Assign Ticket');
    });

    test('should have all security-related texts', () {
      expect(AppTexts.visitorManagement, 'Visitor Management');
      expect(AppTexts.preApproveVisitor, 'Pre-approve Visitor');
      expect(AppTexts.visitorHistory, 'Visitor History');
      expect(AppTexts.emergencyAlert, 'Emergency Alert');
      expect(AppTexts.panicButton, 'PANIC');
    });

    test('should have all form-related texts', () {
      expect(AppTexts.required, 'Required');
      expect(AppTexts.optional, 'Optional');
      expect(AppTexts.submit, 'Submit');
      expect(AppTexts.cancel, 'Cancel');
      expect(AppTexts.save, 'Save');
      expect(AppTexts.edit, 'Edit');
      expect(AppTexts.delete, 'Delete');
    });

    test('should have appropriate user feedback messages', () {
      expect(AppTexts.noDataAvailable, 'No data available');
      expect(AppTexts.loadingData, 'Loading data...');
      expect(AppTexts.errorOccurred, 'An error occurred');
      expect(AppTexts.successMessage, 'Operation completed successfully');
      
      // Loading message should end with ellipsis
      expect(AppTexts.loadingData.endsWith('...'), true);
    });

    test('should have emergency-related texts', () {
      expect(AppTexts.panicAlertSent, 'Panic alert sent to security');
      expect(AppTexts.panicConfirmation, 'Hold for 3 seconds to send emergency alert');
      expect(AppTexts.emergencyHelpText, 'This will notify security and management immediately');
      
      // Panic confirmation should mention the delay duration
      expect(AppTexts.panicConfirmation.contains('3 seconds'), true);
    });

    test('should have consistent text formatting', () {
      // Button texts should be title case
      expect(AppTexts.submit[0], AppTexts.submit[0].toUpperCase());
      expect(AppTexts.cancel[0], AppTexts.cancel[0].toUpperCase());
      expect(AppTexts.save[0], AppTexts.save[0].toUpperCase());
      
      // Tab labels should be title case
      expect(AppTexts.homeTab[0], AppTexts.homeTab[0].toUpperCase());
      expect(AppTexts.noticesTab[0], AppTexts.noticesTab[0].toUpperCase());
    });
  });

  group('AppRoutes Tests', () {
    test('should have all main navigation routes', () {
      expect(AppRoutes.home, '/');
      expect(AppRoutes.notices, '/notices');
      expect(AppRoutes.tickets, '/tickets');
      expect(AppRoutes.security, '/security');
      expect(AppRoutes.profile, '/profile');
    });

    test('should have all sub-routes', () {
      expect(AppRoutes.createNotice, '/notices/create');
      expect(AppRoutes.createTicket, '/tickets/create');
      expect(AppRoutes.ticketDetail, '/tickets/detail');
      expect(AppRoutes.preApproveVisitor, '/security/preapprove');
    });

    test('should have consistent route naming', () {
      // All routes should start with '/'
      const routes = [
        AppRoutes.home,
        AppRoutes.notices,
        AppRoutes.createNotice,
        AppRoutes.tickets,
        AppRoutes.createTicket,
        AppRoutes.ticketDetail,
        AppRoutes.security,
        AppRoutes.preApproveVisitor,
        AppRoutes.profile,
      ];
      
      for (final route in routes) {
        expect(route.startsWith('/'), true);
      }
    });

    test('should have logical route hierarchy', () {
      // Sub-routes should contain their parent route
      expect(AppRoutes.createNotice.startsWith(AppRoutes.notices), true);
      expect(AppRoutes.createTicket.startsWith(AppRoutes.tickets), true);
      expect(AppRoutes.ticketDetail.startsWith(AppRoutes.tickets), true);
      expect(AppRoutes.preApproveVisitor.startsWith(AppRoutes.security), true);
    });

    test('should not have duplicate routes', () {
      const routes = [
        AppRoutes.home,
        AppRoutes.notices,
        AppRoutes.createNotice,
        AppRoutes.tickets,
        AppRoutes.createTicket,
        AppRoutes.ticketDetail,
        AppRoutes.security,
        AppRoutes.preApproveVisitor,
        AppRoutes.profile,
      ];
      
      final uniqueRoutes = routes.toSet();
      expect(uniqueRoutes.length, routes.length);
    });
  });
}

// Helper function to calculate contrast ratio between two colors
double _calculateContrastRatio(Color foreground, Color background) {
  final fgLuminance = foreground.computeLuminance();
  final bgLuminance = background.computeLuminance();
  
  final lighter = fgLuminance > bgLuminance ? fgLuminance : bgLuminance;
  final darker = fgLuminance > bgLuminance ? bgLuminance : fgLuminance;
  
  return (lighter + 0.05) / (darker + 0.05);
}