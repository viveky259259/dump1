// Shared mock classes for testing
// In a real project, these would be generated using build_runner and mockito

import 'package:mockito/mockito.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User;
import 'package:supabase_flutter/supabase_flutter.dart' as supabase show User;
import 'package:townsquare/blocs/auth/auth_bloc.dart';
import 'package:townsquare/services/auth_service.dart';
import 'package:townsquare/services/invoice_service.dart';

// Supabase Mocks
class MockSupabaseClient extends Mock implements SupabaseClient {}
class MockGoTrueClient extends Mock implements GoTrueClient {}
class MockPostgrestQueryBuilder extends Mock implements PostgrestQueryBuilder {}
class MockPostgrestFilterBuilder extends Mock implements PostgrestFilterBuilder<PostgrestList> {}
class MockPostgrestTransformBuilder extends Mock implements PostgrestTransformBuilder<PostgrestMap> {}
class MockAuthResponse extends Mock implements AuthResponse {}
class MockUser extends Mock implements supabase.User {}

// Extended Supabase Query Builder Mock
class MockSupabaseQueryBuilder extends Mock implements SupabaseQueryBuilder {}

// PostgrestList and PostgrestMap type aliases for better compatibility
typedef PostgrestList = List<Map<String, dynamic>>;
typedef PostgrestMap = Map<String, dynamic>;

// Service Mocks
class MockAuthService extends Mock implements AuthService {}
class MockInvoiceService extends Mock implements InvoiceService {}

// BLoC Mocks
class MockAuthBloc extends Mock implements AuthBloc {}