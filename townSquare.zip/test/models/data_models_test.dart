import 'package:flutter_test/flutter_test.dart';
import 'package:townsquare/models/data_models.dart';

void main() {
  group('Data Models Tests', () {
    group('Notice Model Tests', () {
      late Notice testNotice;
      late Map<String, dynamic> testNoticeJson;

      setUp(() {
        testNotice = Notice(
          id: 'notice-123',
          title: 'Community Event',
          content: 'Annual community gathering next weekend',
          category: NoticeCategory.event,
          authorId: 'user-123',
          publishDate: DateTime(2023, 6, 1),
          expiryDate: DateTime(2023, 6, 30),
          isPinned: true,
          attachments: ['image1.jpg', 'document.pdf'],
        );

        testNoticeJson = {
          'id': 'notice-123',
          'title': 'Community Event',
          'content': 'Annual community gathering next weekend',
          'category': 'NoticeCategory.event',
          'authorId': 'user-123',
          'publishDate': '2023-06-01T00:00:00.000',
          'expiryDate': '2023-06-30T00:00:00.000',
          'isPinned': true,
          'attachments': ['image1.jpg', 'document.pdf'],
        };
      });

      test('should serialize Notice correctly', () {
        final json = testNotice.toJson();
        expect(json['id'], testNotice.id);
        expect(json['title'], testNotice.title);
        expect(json['content'], testNotice.content);
        expect(json['category'], testNotice.category.toString());
        expect(json['isPinned'], testNotice.isPinned);
        expect(json['attachments'], testNotice.attachments);
      });

      test('should deserialize Notice correctly', () {
        final notice = Notice.fromJson(testNoticeJson);
        expect(notice.id, testNotice.id);
        expect(notice.title, testNotice.title);
        expect(notice.content, testNotice.content);
        expect(notice.category, testNotice.category);
        expect(notice.isPinned, testNotice.isPinned);
        expect(notice.attachments, testNotice.attachments);
      });

      test('should handle optional fields', () {
        final minimalNoticeJson = {
          'id': 'notice-123',
          'title': 'Simple Notice',
          'content': 'Simple content',
          'category': 'NoticeCategory.general',
          'authorId': 'user-123',
          'publishDate': '2023-06-01T00:00:00.000',
        };

        final notice = Notice.fromJson(minimalNoticeJson);
        expect(notice.expiryDate, isNull);
        expect(notice.isPinned, false);
        expect(notice.attachments, isEmpty);
      });
    });

    group('NoticeCategory Extension Tests', () {
      test('should have correct display names', () {
        expect(NoticeCategory.general.displayName, 'General');
        expect(NoticeCategory.maintenance.displayName, 'Maintenance');
        expect(NoticeCategory.event.displayName, 'Event');
        expect(NoticeCategory.urgent.displayName, 'Urgent');
      });

      test('should have correct emojis', () {
        expect(NoticeCategory.general.emoji, '📢');
        expect(NoticeCategory.maintenance.emoji, '🔧');
        expect(NoticeCategory.event.emoji, '🎉');
        expect(NoticeCategory.urgent.emoji, '🚨');
      });
    });

    group('MaintenanceInvoice Model Tests', () {
      late MaintenanceInvoice testInvoice;
      late Map<String, dynamic> testInvoiceJson;

      setUp(() {
        testInvoice = MaintenanceInvoice(
          id: 'inv-123',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 5000.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.unpaid,
          lateFee: 0.0,
          totalAmount: 5000.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        );

        testInvoiceJson = {
          'id': 'inv-123',
          'invoice_number': 'INV-2023-06-0001',
          'apartment_id': 'apt-123',
          'resident_id': 'user-123',
          'flat_number': 'A-101',
          'invoice_month': 6,
          'invoice_year': 2023,
          'maintenance_amount': '5000.0',
          'due_date': '2023-06-25',
          'status': 'unpaid',
          'late_fee': '0.0',
          'total_amount': '5000.0',
          'generated_by': 'admin-123',
          'created_at': '2023-06-01T00:00:00.000',
          'updated_at': '2023-06-01T00:00:00.000',
        };
      });

      test('should serialize MaintenanceInvoice correctly', () {
        final json = testInvoice.toJson();
        expect(json['invoice_number'], testInvoice.invoiceNumber);
        expect(json['apartment_id'], testInvoice.apartmentId);
        expect(json['flat_number'], testInvoice.flatNumber);
        expect(json['invoice_month'], testInvoice.invoiceMonth);
        expect(json['invoice_year'], testInvoice.invoiceYear);
        expect(json['status'], testInvoice.status.name);
      });

      test('should deserialize MaintenanceInvoice correctly', () {
        final invoice = MaintenanceInvoice.fromJson(testInvoiceJson);
        expect(invoice.id, testInvoice.id);
        expect(invoice.invoiceNumber, testInvoice.invoiceNumber);
        expect(invoice.apartmentId, testInvoice.apartmentId);
        expect(invoice.flatNumber, testInvoice.flatNumber);
        expect(invoice.maintenanceAmount, testInvoice.maintenanceAmount);
        expect(invoice.status, testInvoice.status);
      });

      test('should calculate month name correctly', () {
        expect(testInvoice.monthName, 'June');
        
        final januaryInvoice = testInvoice.copyWith(invoiceMonth: 1);
        expect(januaryInvoice.monthName, 'January');
      });

      test('should determine overdue status correctly', () {
        final currentDate = DateTime.now();
        
        // Future due date - not overdue
        final futureInvoice = testInvoice.copyWith(
          dueDate: currentDate.add(const Duration(days: 5)),
          status: InvoiceStatus.unpaid,
        );
        expect(futureInvoice.isOverdue, false);
        
        // Past due date with unpaid status - overdue
        final overdueInvoice = testInvoice.copyWith(
          dueDate: currentDate.subtract(const Duration(days: 5)),
          status: InvoiceStatus.unpaid,
        );
        expect(overdueInvoice.isOverdue, true);
        
        // Past due date but paid - not overdue
        final paidInvoice = testInvoice.copyWith(
          dueDate: currentDate.subtract(const Duration(days: 5)),
          status: InvoiceStatus.paid,
        );
        expect(paidInvoice.isOverdue, false);
      });
    });

    group('Poll Model Tests', () {
      late Poll testPoll;
      late Map<String, dynamic> testPollJson;

      setUp(() {
        testPoll = Poll(
          id: 'poll-123',
          question: 'What amenity should we prioritize?',
          options: ['Swimming Pool', 'Gym', 'Garden', 'Playground'],
          startDate: DateTime(2023, 6, 1),
          endDate: DateTime(2023, 6, 30),
          votes: {
            'Swimming Pool': ['user1', 'user2'],
            'Gym': ['user3'],
            'Garden': ['user4', 'user5', 'user6'],
          },
          allowMultiple: false,
        );

        testPollJson = {
          'id': 'poll-123',
          'question': 'What amenity should we prioritize?',
          'options': ['Swimming Pool', 'Gym', 'Garden', 'Playground'],
          'startDate': '2023-06-01T00:00:00.000',
          'endDate': '2023-06-30T00:00:00.000',
          'votes': {
            'Swimming Pool': ['user1', 'user2'],
            'Gym': ['user3'],
            'Garden': ['user4', 'user5', 'user6'],
          },
          'allowMultiple': false,
        };
      });

      test('should serialize Poll correctly', () {
        final json = testPoll.toJson();
        expect(json['question'], testPoll.question);
        expect(json['options'], testPoll.options);
        expect(json['votes'], testPoll.votes);
        expect(json['allowMultiple'], testPoll.allowMultiple);
      });

      test('should deserialize Poll correctly', () {
        final poll = Poll.fromJson(testPollJson);
        expect(poll.question, testPoll.question);
        expect(poll.options, testPoll.options);
        expect(poll.votes, testPoll.votes);
        expect(poll.allowMultiple, testPoll.allowMultiple);
      });

      test('should calculate total votes correctly', () {
        expect(testPoll.getTotalVotes(), 6); // 2 + 1 + 3 = 6 votes
      });

      test('should determine if poll is active', () {
        final currentDate = DateTime.now();
        
        // Active poll (current date between start and end)
        final activePoll = testPoll.copyWith(
          startDate: currentDate.subtract(const Duration(days: 1)),
          endDate: currentDate.add(const Duration(days: 1)),
        );
        expect(activePoll.isActive, true);
        
        // Inactive poll (current date after end)
        final expiredPoll = testPoll.copyWith(
          startDate: currentDate.subtract(const Duration(days: 5)),
          endDate: currentDate.subtract(const Duration(days: 1)),
        );
        expect(expiredPoll.isActive, false);
        
        // Inactive poll (current date before start)
        final futurePoll = testPoll.copyWith(
          startDate: currentDate.add(const Duration(days: 1)),
          endDate: currentDate.add(const Duration(days: 5)),
        );
        expect(futurePoll.isActive, false);
      });
    });

    group('Ticket Model Tests', () {
      late Ticket testTicket;
      late Map<String, dynamic> testTicketJson;

      setUp(() {
        testTicket = Ticket(
          id: 'ticket-123',
          residentId: 'user-123',
          flatNumber: 'A-101',
          category: TicketCategory.plumbing,
          description: 'Kitchen sink is leaking',
          attachments: ['leak_photo.jpg'],
          status: TicketStatus.open,
          createdAt: DateTime(2023, 6, 1),
          assignedTo: 'staff-123',
        );

        testTicketJson = {
          'id': 'ticket-123',
          'residentId': 'user-123',
          'flatNumber': 'A-101',
          'category': 'TicketCategory.plumbing',
          'description': 'Kitchen sink is leaking',
          'attachments': ['leak_photo.jpg'],
          'status': 'TicketStatus.open',
          'createdAt': '2023-06-01T00:00:00.000',
          'assignedTo': 'staff-123',
          'updates': [],
        };
      });

      test('should serialize Ticket correctly', () {
        final json = testTicket.toJson();
        expect(json['id'], testTicket.id);
        expect(json['category'], testTicket.category.toString());
        expect(json['status'], testTicket.status.toString());
        expect(json['attachments'], testTicket.attachments);
      });

      test('should deserialize Ticket correctly', () {
        final ticket = Ticket.fromJson(testTicketJson);
        expect(ticket.id, testTicket.id);
        expect(ticket.category, testTicket.category);
        expect(ticket.status, testTicket.status);
        expect(ticket.description, testTicket.description);
      });
    });

    group('TicketCategory Extension Tests', () {
      test('should have correct display names', () {
        expect(TicketCategory.plumbing.displayName, 'Plumbing');
        expect(TicketCategory.electrical.displayName, 'Electrical');
        expect(TicketCategory.security.displayName, 'Security');
        expect(TicketCategory.housekeeping.displayName, 'Housekeeping');
        expect(TicketCategory.commonArea.displayName, 'Common Area');
      });

      test('should have correct emojis', () {
        expect(TicketCategory.plumbing.emoji, '🔧');
        expect(TicketCategory.electrical.emoji, '⚡');
        expect(TicketCategory.security.emoji, '🛡️');
        expect(TicketCategory.housekeeping.emoji, '🧹');
        expect(TicketCategory.commonArea.emoji, '🏢');
      });
    });

    group('Apartment Model Tests', () {
      late Apartment testApartment;
      late Map<String, dynamic> testApartmentJson;

      setUp(() {
        testApartment = Apartment(
          id: 'apt-123',
          flatNumber: 'A-101',
          ownerId: 'owner-123',
          tenantId: 'tenant-123',
          maintenanceAmount: 5000.0,
          floorNumber: 1,
          bhkType: BhkType.bhk2,
          carpetArea: 1200.0,
          isOccupied: true,
          createdAt: DateTime(2023, 1, 1),
          updatedAt: DateTime(2023, 6, 1),
        );

        testApartmentJson = {
          'id': 'apt-123',
          'flat_number': 'A-101',
          'owner_id': 'owner-123',
          'tenant_id': 'tenant-123',
          'maintenance_amount': '5000.0',
          'floor_number': 1,
          'bhk_type': '2BHK',
          'carpet_area': '1200.0',
          'is_occupied': true,
          'created_at': '2023-01-01T00:00:00.000',
          'updated_at': '2023-06-01T00:00:00.000',
        };
      });

      test('should serialize Apartment correctly', () {
        final json = testApartment.toJson();
        expect(json['flat_number'], testApartment.flatNumber);
        expect(json['bhk_type'], 'BHK2');
        expect(json['maintenance_amount'], testApartment.maintenanceAmount);
        expect(json['is_occupied'], testApartment.isOccupied);
      });

      test('should deserialize Apartment correctly', () {
        final apartment = Apartment.fromJson(testApartmentJson);
        expect(apartment.flatNumber, testApartment.flatNumber);
        expect(apartment.bhkType, testApartment.bhkType);
        expect(apartment.maintenanceAmount, testApartment.maintenanceAmount);
        expect(apartment.isOccupied, testApartment.isOccupied);
      });

      test('should determine resident ID correctly', () {
        // Tenant takes priority over owner
        expect(testApartment.residentId, 'tenant-123');
        
        // Owner when no tenant
        final ownerOnlyApartment = testApartment.copyWith(tenantId: null);
        expect(ownerOnlyApartment.residentId, 'owner-123');
        
        // Empty when neither
        final emptyApartment = testApartment.copyWith(
          tenantId: null,
          ownerId: null,
        );
        expect(emptyApartment.residentId, '');
      });

      test('should parse BHK types correctly', () {
        final testCases = {
          '1BHK': BhkType.bhk1,
          '2BHK': BhkType.bhk2,
          '3BHK': BhkType.bhk3,
          '4BHK': BhkType.bhk4,
          'STUDIO': BhkType.studio,
          'PENTHOUSE': BhkType.penthouse,
          'UNKNOWN': BhkType.bhk2, // default fallback
        };

        testCases.forEach((input, expected) {
          final json = {...testApartmentJson, 'bhk_type': input};
          final apartment = Apartment.fromJson(json);
          expect(apartment.bhkType, expected);
        });
      });
    });

    group('BhkType Extension Tests', () {
      test('should have correct display names', () {
        expect(BhkType.bhk1.displayName, '1BHK');
        expect(BhkType.bhk2.displayName, '2BHK');
        expect(BhkType.bhk3.displayName, '3BHK');
        expect(BhkType.bhk4.displayName, '4BHK');
        expect(BhkType.studio.displayName, 'Studio');
        expect(BhkType.penthouse.displayName, 'Penthouse');
      });
    });
  });
}

// Extension to add copyWith method for testing
extension MaintenanceInvoiceCopyWith on MaintenanceInvoice {
  MaintenanceInvoice copyWith({
    String? id,
    String? invoiceNumber,
    String? apartmentId,
    String? residentId,
    String? flatNumber,
    int? invoiceMonth,
    int? invoiceYear,
    double? maintenanceAmount,
    DateTime? dueDate,
    InvoiceStatus? status,
    DateTime? paymentDate,
    String? paymentMethod,
    double? lateFee,
    double? totalAmount,
    String? generatedBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return MaintenanceInvoice(
      id: id ?? this.id,
      invoiceNumber: invoiceNumber ?? this.invoiceNumber,
      apartmentId: apartmentId ?? this.apartmentId,
      residentId: residentId ?? this.residentId,
      flatNumber: flatNumber ?? this.flatNumber,
      invoiceMonth: invoiceMonth ?? this.invoiceMonth,
      invoiceYear: invoiceYear ?? this.invoiceYear,
      maintenanceAmount: maintenanceAmount ?? this.maintenanceAmount,
      dueDate: dueDate ?? this.dueDate,
      status: status ?? this.status,
      paymentDate: paymentDate ?? this.paymentDate,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      lateFee: lateFee ?? this.lateFee,
      totalAmount: totalAmount ?? this.totalAmount,
      generatedBy: generatedBy ?? this.generatedBy,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

extension PollCopyWith on Poll {
  Poll copyWith({
    String? id,
    String? question,
    List<String>? options,
    DateTime? startDate,
    DateTime? endDate,
    Map<String, List<String>>? votes,
    bool? allowMultiple,
  }) {
    return Poll(
      id: id ?? this.id,
      question: question ?? this.question,
      options: options ?? this.options,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      votes: votes ?? this.votes,
      allowMultiple: allowMultiple ?? this.allowMultiple,
    );
  }
}

extension ApartmentCopyWith on Apartment {
  Apartment copyWith({
    String? id,
    String? flatNumber,
    String? ownerId,
    String? tenantId,
    double? maintenanceAmount,
    int? floorNumber,
    BhkType? bhkType,
    double? carpetArea,
    bool? isOccupied,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Apartment(
      id: id ?? this.id,
      flatNumber: flatNumber ?? this.flatNumber,
      ownerId: ownerId ?? this.ownerId,
      tenantId: tenantId ?? this.tenantId,
      maintenanceAmount: maintenanceAmount ?? this.maintenanceAmount,
      floorNumber: floorNumber ?? this.floorNumber,
      bhkType: bhkType ?? this.bhkType,
      carpetArea: carpetArea ?? this.carpetArea,
      isOccupied: isOccupied ?? this.isOccupied,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}