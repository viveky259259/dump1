import 'package:flutter_test/flutter_test.dart';
import 'package:townsquare/models/user.dart';

void main() {
  group('User Model Tests', () {
    late User testUser;
    late Map<String, dynamic> testUserJson;

    setUp(() {
      testUser = User(
        id: 'user-123',
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1234567890',
        flatNumber: 'A-101',
        role: UserRole.resident,
        createdAt: DateTime(2023, 1, 15),
      );

      testUserJson = {
        'id': 'user-123',
        'name': 'John Doe',
        'email': 'john.doe@example.com',
        'phone': '+1234567890',
        'flat_number': 'A-101',
        'role': 'resident',
        'created_at': '2023-01-15T00:00:00.000',
      };
    });

    group('Serialization Tests', () {
      test('should convert User to JSON correctly', () {
        final json = testUser.toJson();
        
        expect(json['id'], testUser.id);
        expect(json['name'], testUser.name);
        expect(json['email'], testUser.email);
        expect(json['phone'], testUser.phone);
        expect(json['flat_number'], testUser.flatNumber);
        expect(json['role'], testUser.role.name);
        expect(json['created_at'], testUser.createdAt.toIso8601String());
      });

      test('should create User from JSON correctly', () {
        final user = User.fromJson(testUserJson);
        
        expect(user.id, testUserJson['id']);
        expect(user.name, testUserJson['name']);
        expect(user.email, testUserJson['email']);
        expect(user.phone, testUserJson['phone']);
        expect(user.flatNumber, testUserJson['flat_number']);
        expect(user.role, UserRole.resident);
        expect(user.createdAt, DateTime(2023, 1, 15));
      });

      test('should create User from Supabase data correctly', () {
        final user = User.fromSupabaseData(testUserJson);
        
        expect(user.id, testUserJson['id']);
        expect(user.name, testUserJson['name']);
        expect(user.email, testUserJson['email']);
        expect(user.phone, testUserJson['phone']);
        expect(user.flatNumber, testUserJson['flat_number']);
        expect(user.role, UserRole.resident);
        expect(user.createdAt, DateTime(2023, 1, 15));
      });

      test('should handle alternative JSON key formats', () {
        final alternativeJson = {
          'id': 'user-123',
          'name': 'John Doe',
          'email': 'john.doe@example.com',
          'phone': '+1234567890',
          'flatNumber': 'A-101', // Alternative key format
          'role': 'UserRole.resident', // Alternative role format
          'createdAt': '2023-01-15T00:00:00.000', // Alternative key format
        };

        final user = User.fromJson(alternativeJson);
        
        expect(user.flatNumber, 'A-101');
        expect(user.role, UserRole.resident);
        expect(user.createdAt, DateTime(2023, 1, 15));
      });
    });

    group('UserRole Enum Tests', () {
      test('should have correct display names', () {
        expect(UserRole.admin.displayName, 'Admin');
        expect(UserRole.resident.displayName, 'Resident');
        expect(UserRole.staff.displayName, 'Staff');
        expect(UserRole.security.displayName, 'Security');
      });

      test('should have correct permissions', () {
        expect(UserRole.admin.canCreateNotices, true);
        expect(UserRole.resident.canCreateNotices, false);
        expect(UserRole.staff.canCreateNotices, false);
        expect(UserRole.security.canCreateNotices, false);

        expect(UserRole.admin.canAssignTickets, true);
        expect(UserRole.resident.canAssignTickets, false);
        expect(UserRole.staff.canAssignTickets, false);
        expect(UserRole.security.canAssignTickets, false);

        expect(UserRole.admin.canManageVisitors, true);
        expect(UserRole.security.canManageVisitors, true);
        expect(UserRole.resident.canManageVisitors, false);
        expect(UserRole.staff.canManageVisitors, false);
      });
    });

    group('Edge Cases', () {
      test('should handle missing optional fields in JSON', () {
        final minimalJson = {
          'id': 'user-123',
          'name': 'John Doe',
          'email': 'john.doe@example.com',
          'phone': '+1234567890',
          'role': 'resident',
          'created_at': '2023-01-15T00:00:00.000',
        };

        expect(() => User.fromJson(minimalJson), throwsA(isA<TypeError>()));
      });

      test('should handle invalid role enum', () {
        final invalidRoleJson = {
          ...testUserJson,
          'role': 'invalid_role',
        };

        expect(() => User.fromJson(invalidRoleJson), throwsA(isA<StateError>()));
      });

      test('should handle invalid date format', () {
        final invalidDateJson = {
          ...testUserJson,
          'created_at': 'invalid-date',
        };

        expect(() => User.fromJson(invalidDateJson), throwsA(isA<FormatException>()));
      });
    });
  });
}