import 'package:bloc_test/bloc_test.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:townsquare/blocs/auth/auth_bloc.dart';
import 'package:townsquare/blocs/auth/auth_event.dart';
import 'package:townsquare/blocs/auth/auth_state.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';

import '../mocks.dart';
void main() {
  group('AuthBloc Tests', () {
    late AuthBloc authBloc;
    late MockAuthService mockAuthService;
    late User testUser;

    setUp(() {
      mockAuthService = MockAuthService();
      authBloc = AuthBloc(authService: mockAuthService);
      
      testUser = User(
        id: 'user-123',
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1234567890',
        flatNumber: 'A-101',
        role: UserRole.resident,
        createdAt: DateTime(2023, 1, 1),
      );
    });

    tearDown(() {
      authBloc.close();
    });

    test('initial state is AuthInitial', () {
      expect(authBloc.state, equals(const AuthInitial()));
    });

    group('AuthInitialized Event', () {
      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthAuthenticated] when initialization succeeds with authenticated user',
        build: () {
          when(mockAuthService.initialize()).thenAnswer((_) async {});
          when(mockAuthService.userStream).thenAnswer(
            (_) => Stream.fromIterable([testUser]),
          );
          when(mockAuthService.currentUser).thenReturn(testUser);
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthInitialized()),
        expect: () => [
          const AuthLoading(),
          AuthAuthenticated(testUser),
        ],
        verify: (_) {
          verify(mockAuthService.initialize()).called(1);
        },
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthUnauthenticated] when initialization succeeds with no user',
        build: () {
          when(mockAuthService.initialize()).thenAnswer((_) async {});
          when(mockAuthService.userStream).thenAnswer(
            (_) => Stream.fromIterable([null]),
          );
          when(mockAuthService.currentUser).thenReturn(null);
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthInitialized()),
        expect: () => [
          const AuthLoading(),
          const AuthUnauthenticated(),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] when initialization fails',
        build: () {
          when(mockAuthService.initialize())
              .thenThrow(Exception('Database connection failed'));
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthInitialized()),
        expect: () => [
          const AuthLoading(),
          const AuthError('Failed to initialize authentication: Exception: Database connection failed'),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] with specific message for credentials error',
        build: () {
          when(mockAuthService.initialize())
              .thenThrow(Exception('credentials not configured'));
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthInitialized()),
        expect: () => [
          const AuthLoading(),
          const AuthError('Supabase credentials not configured. Please contact your administrator to set up the database connection.'),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] with specific message for already initialized error',
        build: () {
          when(mockAuthService.initialize())
              .thenThrow(Exception('This instance is already initialized'));
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthInitialized()),
        expect: () => [
          const AuthLoading(),
          const AuthError('Authentication service initialization conflict. Please restart the app.'),
        ],
      );
    });

    group('AuthSignInRequested Event', () {
      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading] when sign in succeeds',
        build: () {
          when(mockAuthService.signIn('test@example.com', 'password'))
              .thenAnswer((_) async => 'success');
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignInRequested(
          email: 'test@example.com',
          password: 'password',
        )),
        expect: () => [
          const AuthLoading(),
        ],
        verify: (_) {
          verify(mockAuthService.signIn('test@example.com', 'password')).called(1);
        },
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] when sign in fails',
        build: () {
          when(mockAuthService.signIn('test@example.com', 'wrong-password'))
              .thenAnswer((_) async => 'Invalid credentials');
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignInRequested(
          email: 'test@example.com',
          password: 'wrong-password',
        )),
        expect: () => [
          const AuthLoading(),
          const AuthError('Invalid credentials'),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] when sign in throws exception',
        build: () {
          when(mockAuthService.signIn('test@example.com', 'password'))
              .thenThrow(Exception('Network error'));
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignInRequested(
          email: 'test@example.com',
          password: 'password',
        )),
        expect: () => [
          const AuthLoading(),
          const AuthError('Sign in failed: Exception: Network error'),
        ],
      );
    });

    group('AuthSignUpRequested Event', () {
      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading] when sign up succeeds',
        build: () {
          when(mockAuthService.signUp(
            email: 'test@example.com',
            password: 'password',
            name: 'John Doe',
            phone: '+1234567890',
            flatNumber: 'A-101',
            role: UserRole.resident,
          )).thenAnswer((_) async => 'success');
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignUpRequested(
          email: 'test@example.com',
          password: 'password',
          name: 'John Doe',
          phone: '+1234567890',
          flatNumber: 'A-101',
          role: UserRole.resident,
        )),
        expect: () => [
          const AuthLoading(),
        ],
        verify: (_) {
          verify(mockAuthService.signUp(
            email: 'test@example.com',
            password: 'password',
            name: 'John Doe',
            phone: '+1234567890',
            flatNumber: 'A-101',
            role: UserRole.resident,
          )).called(1);
        },
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] when sign up fails',
        build: () {
          when(mockAuthService.signUp(
            email: 'test@example.com',
            password: 'weak',
            name: 'John Doe',
            phone: '+1234567890',
            flatNumber: 'A-101',
            role: UserRole.resident,
          )).thenAnswer((_) async => 'Password too weak');
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignUpRequested(
          email: 'test@example.com',
          password: 'weak',
          name: 'John Doe',
          phone: '+1234567890',
          flatNumber: 'A-101',
          role: UserRole.resident,
        )),
        expect: () => [
          const AuthLoading(),
          const AuthError('Password too weak'),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] when sign up throws exception',
        build: () {
          when(mockAuthService.signUp(
            email: 'test@example.com',
            password: 'password',
            name: 'John Doe',
            phone: '+1234567890',
            flatNumber: 'A-101',
            role: UserRole.resident,
          )).thenThrow(Exception('Email already in use'));
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignUpRequested(
          email: 'test@example.com',
          password: 'password',
          name: 'John Doe',
          phone: '+1234567890',
          flatNumber: 'A-101',
          role: UserRole.resident,
        )),
        expect: () => [
          const AuthLoading(),
          const AuthError('Sign up failed: Exception: Email already in use'),
        ],
      );
    });

    group('AuthSignOutRequested Event', () {
      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading] when sign out succeeds',
        build: () {
          when(mockAuthService.signOut()).thenAnswer((_) async {});
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignOutRequested()),
        expect: () => [
          const AuthLoading(),
        ],
        verify: (_) {
          verify(mockAuthService.signOut()).called(1);
        },
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthLoading, AuthError] when sign out fails',
        build: () {
          when(mockAuthService.signOut())
              .thenThrow(Exception('Network error'));
          return authBloc;
        },
        act: (bloc) => bloc.add(const AuthSignOutRequested()),
        expect: () => [
          const AuthLoading(),
          const AuthError('Sign out failed: Exception: Network error'),
        ],
      );
    });

    group('AuthUserChanged Event', () {
      blocTest<AuthBloc, AuthState>(
        'emits [AuthAuthenticated] when user is provided',
        build: () => authBloc,
        act: (bloc) => bloc.add(AuthUserChanged(testUser)),
        expect: () => [
          AuthAuthenticated(testUser),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'emits [AuthUnauthenticated] when user is null',
        build: () => authBloc,
        act: (bloc) => bloc.add(const AuthUserChanged(null)),
        expect: () => [
          const AuthUnauthenticated(),
        ],
      );
    });

    group('State Transitions', () {
      blocTest<AuthBloc, AuthState>(
        'should handle multiple state changes correctly',
        build: () {
          when(mockAuthService.signIn('test@example.com', 'password'))
              .thenAnswer((_) async => 'success');
          when(mockAuthService.signOut()).thenAnswer((_) async {});
          return authBloc;
        },
        act: (bloc) {
          bloc.add(const AuthSignInRequested(
            email: 'test@example.com',
            password: 'password',
          ));
          bloc.add(AuthUserChanged(testUser));
          bloc.add(const AuthSignOutRequested());
          bloc.add(const AuthUserChanged(null));
        },
        expect: () => [
          const AuthLoading(),
          AuthAuthenticated(testUser),
          const AuthLoading(),
          const AuthUnauthenticated(),
        ],
      );
    });

    group('Edge Cases', () {
      blocTest<AuthBloc, AuthState>(
        'should handle rapid consecutive sign in attempts',
        build: () {
          when(mockAuthService.signIn('test@example.com', 'password'))
              .thenAnswer((_) async => 'success');
          return authBloc;
        },
        act: (bloc) {
          // Rapid consecutive sign in attempts
          bloc.add(const AuthSignInRequested(
            email: 'test@example.com',
            password: 'password',
          ));
          bloc.add(const AuthSignInRequested(
            email: 'test@example.com',
            password: 'password',
          ));
        },
        expect: () => [
          const AuthLoading(),
          const AuthLoading(),
        ],
      );

      blocTest<AuthBloc, AuthState>(
        'should handle sign out when already signed out',
        build: () {
          when(mockAuthService.signOut()).thenAnswer((_) async {});
          return authBloc;
        },
        seed: () => const AuthUnauthenticated(),
        act: (bloc) => bloc.add(const AuthSignOutRequested()),
        expect: () => [
          const AuthLoading(),
        ],
      );
    });
  });
}