import 'package:bloc_test/bloc_test.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide User;
import 'package:supabase_flutter/supabase_flutter.dart' as supabase show User;
import 'package:townsquare/blocs/invoice/invoice_bloc.dart';
import 'package:townsquare/blocs/invoice/invoice_event.dart';
import 'package:townsquare/blocs/invoice/invoice_state.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/services/invoice_service.dart';

import '../mocks.dart';
void main() {
  group('InvoiceBloc Tests', () {
    late InvoiceBloc invoiceBloc;
    late MockInvoiceService mockInvoiceService;
    late MockSupabaseClient mockSupabaseClient;
    late MockGoTrueClient mockAuth;
    late MockUser mockUser;
    late List<MaintenanceInvoice> testInvoices;
    late List<Apartment> testApartments;

    setUp(() {
      mockInvoiceService = MockInvoiceService();
      mockSupabaseClient = MockSupabaseClient();
      mockAuth = MockGoTrueClient();
      mockUser = MockUser();
      
      when(mockSupabaseClient.auth).thenReturn(mockAuth);
      when(mockAuth.currentUser).thenReturn(mockUser);
      when(mockUser.id).thenReturn('admin-123');

      // Override the Supabase instance for testing
      Supabase.initialize(
        url: 'https://test.supabase.co',
        anonKey: 'test-key',
      );

      invoiceBloc = InvoiceBloc(mockInvoiceService);

      testInvoices = [
        MaintenanceInvoice(
          id: 'inv-1',
          invoiceNumber: 'INV-2023-06-0001',
          apartmentId: 'apt-1',
          residentId: 'user-1',
          flatNumber: 'A-101',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 5000.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.unpaid,
          lateFee: 0.0,
          totalAmount: 5000.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        ),
        MaintenanceInvoice(
          id: 'inv-2',
          invoiceNumber: 'INV-2023-06-0002',
          apartmentId: 'apt-2',
          residentId: 'user-2',
          flatNumber: 'A-102',
          invoiceMonth: 6,
          invoiceYear: 2023,
          maintenanceAmount: 6000.0,
          dueDate: DateTime(2023, 6, 25),
          status: InvoiceStatus.paid,
          lateFee: 0.0,
          totalAmount: 6000.0,
          generatedBy: 'admin-123',
          createdAt: DateTime(2023, 6, 1),
          updatedAt: DateTime(2023, 6, 1),
        ),
      ];

      testApartments = [
        Apartment(
          id: 'apt-1',
          flatNumber: 'A-101',
          ownerId: 'owner-1',
          tenantId: 'user-1',
          maintenanceAmount: 5000.0,
          floorNumber: 1,
          bhkType: BhkType.bhk2,
          isOccupied: true,
          createdAt: DateTime(2023, 1, 1),
          updatedAt: DateTime(2023, 1, 1),
        ),
        Apartment(
          id: 'apt-2',
          flatNumber: 'A-102',
          ownerId: 'owner-2',
          tenantId: 'user-2',
          maintenanceAmount: 6000.0,
          floorNumber: 1,
          bhkType: BhkType.bhk3,
          isOccupied: true,
          createdAt: DateTime(2023, 1, 1),
          updatedAt: DateTime(2023, 1, 1),
        ),
      ];
    });

    tearDown(() {
      invoiceBloc.close();
    });

    test('initial state is InvoiceInitial', () {
      expect(invoiceBloc.state, equals(InvoiceInitial()));
    });

    group('LoadInvoices Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceLoading, InvoicesLoaded] when loading succeeds',
        build: () {
          when(mockInvoiceService.getInvoices()).thenAnswer((_) async => testInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const LoadInvoices()),
        expect: () => [
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
        verify: (_) {
          verify(mockInvoiceService.getInvoices()).called(1);
          verify(mockInvoiceService.getApartments()).called(1);
        },
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceLoading, InvoicesLoaded] when loading for specific resident succeeds',
        build: () {
          final residentInvoices = [testInvoices.first];
          when(mockInvoiceService.getInvoices(residentId: 'user-1'))
              .thenAnswer((_) async => residentInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const LoadInvoices(residentId: 'user-1')),
        expect: () => [
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: [testInvoices.first],
            apartments: testApartments,
          ),
        ],
        verify: (_) {
          verify(mockInvoiceService.getInvoices(residentId: 'user-1')).called(1);
        },
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceLoading, InvoiceError] when loading fails',
        build: () {
          when(mockInvoiceService.getInvoices())
              .thenThrow(Exception('Database connection failed'));
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const LoadInvoices()),
        expect: () => [
          InvoiceLoading(),
          const InvoiceError(error: 'Exception: Database connection failed'),
        ],
      );
    });

    group('LoadApartments Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceLoading, InvoicesLoaded] when loading apartments succeeds',
        build: () {
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const LoadApartments()),
        expect: () => [
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: const [],
            apartments: testApartments,
          ),
        ],
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'maintains existing invoices when loading apartments from InvoicesLoaded state',
        build: () {
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        seed: () => InvoicesLoaded(
          invoices: testInvoices,
          apartments: const [],
        ),
        act: (bloc) => bloc.add(const LoadApartments()),
        expect: () => [
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
      );
    });

    group('GenerateInvoicesForMonth Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceGenerationInProgress, InvoicesGenerated, InvoiceLoading, InvoicesLoaded] when generation succeeds',
        build: () {
          when(mockInvoiceService.generateInvoicesForMonth(6, 2023, 'admin-123'))
              .thenAnswer((_) async => [testInvoices.first]);
          when(mockInvoiceService.getInvoices()).thenAnswer((_) async => testInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const GenerateInvoicesForMonth(month: 6, year: 2023)),
        expect: () => [
          InvoiceGenerationInProgress(),
          const InvoicesGenerated(
            generatedCount: 1,
            message: 'Generated 1 invoices for June 2023',
          ),
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
        verify: (_) {
          verify(mockInvoiceService.generateInvoicesForMonth(6, 2023, 'admin-123')).called(1);
        },
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceGenerationInProgress, InvoiceError] when user not authenticated',
        build: () {
          when(mockAuth.currentUser).thenReturn(null);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const GenerateInvoicesForMonth(month: 6, year: 2023)),
        expect: () => [
          InvoiceGenerationInProgress(),
          const InvoiceError(error: 'User not authenticated'),
        ],
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceGenerationInProgress, InvoiceError] when generation fails',
        build: () {
          when(mockInvoiceService.generateInvoicesForMonth(6, 2023, 'admin-123'))
              .thenThrow(Exception('No apartments found for invoice generation'));
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const GenerateInvoicesForMonth(month: 6, year: 2023)),
        expect: () => [
          InvoiceGenerationInProgress(),
          const InvoiceError(error: 'Exception: No apartments found for invoice generation'),
        ],
      );
    });

    group('GenerateInvoiceForApartment Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceGenerationInProgress, InvoicesGenerated, InvoiceLoading, InvoicesLoaded] when generation succeeds',
        build: () {
          when(mockInvoiceService.generateInvoiceForApartment('apt-1', 6, 2023, 'admin-123'))
              .thenAnswer((_) async => testInvoices.first);
          when(mockInvoiceService.getInvoices()).thenAnswer((_) async => testInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const GenerateInvoiceForApartment(
          apartmentId: 'apt-1',
          month: 6,
          year: 2023,
        )),
        expect: () => [
          InvoiceGenerationInProgress(),
          const InvoicesGenerated(
            generatedCount: 1,
            message: 'Invoice generated for flat A-101',
          ),
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
      );
    });

    group('MarkInvoiceAsPaid Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoicePaymentUpdated, InvoiceLoading, InvoicesLoaded] when marking as paid succeeds',
        build: () {
          final paidInvoice = MaintenanceInvoice(
            id: 'inv-1',
            invoiceNumber: 'INV-2023-06-0001',
            apartmentId: 'apt-1',
            residentId: 'user-1',
            flatNumber: 'A-101',
            invoiceMonth: 6,
            invoiceYear: 2023,
            maintenanceAmount: 5000.0,
            dueDate: DateTime(2023, 6, 25),
            status: InvoiceStatus.paid,
            paymentDate: DateTime(2023, 6, 20),
            paymentMethod: 'Online Banking',
            lateFee: 0.0,
            totalAmount: 5000.0,
            generatedBy: 'admin-123',
            createdAt: DateTime(2023, 6, 1),
            updatedAt: DateTime(2023, 6, 20),
          );
          when(mockInvoiceService.markInvoiceAsPaid('inv-1', 'Online Banking'))
              .thenAnswer((_) async => paidInvoice);
          when(mockInvoiceService.getInvoices()).thenAnswer((_) async => testInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const MarkInvoiceAsPaid(
          invoiceId: 'inv-1',
          paymentMethod: 'Online Banking',
        )),
        expect: () => [
          predicate<InvoicePaymentUpdated>((state) => 
            state.message == 'Invoice marked as paid'),
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
        verify: (_) {
          verify(mockInvoiceService.markInvoiceAsPaid('inv-1', 'Online Banking')).called(1);
        },
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceError] when marking as paid fails',
        build: () {
          when(mockInvoiceService.markInvoiceAsPaid('inv-1', 'Online Banking'))
              .thenThrow(Exception('Invoice not found'));
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const MarkInvoiceAsPaid(
          invoiceId: 'inv-1',
          paymentMethod: 'Online Banking',
        )),
        expect: () => [
          const InvoiceError(error: 'Exception: Invoice not found'),
        ],
      );
    });

    group('SendInvoiceNotification Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [NotificationSent] when sending notification succeeds',
        build: () {
          when(mockInvoiceService.sendInvoiceNotification(
            'inv-1',
            NotificationType.reminder,
            SentVia.email,
          )).thenAnswer((_) async {});
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const SendInvoiceNotification(
          invoiceId: 'inv-1',
          notificationType: NotificationType.reminder,
          sentVia: SentVia.email,
        )),
        expect: () => [
          const NotificationSent(message: 'Notification sent successfully'),
        ],
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoiceError] when sending notification fails',
        build: () {
          when(mockInvoiceService.sendInvoiceNotification(
            'inv-1',
            NotificationType.reminder,
            SentVia.email,
          )).thenThrow(Exception('Email service unavailable'));
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const SendInvoiceNotification(
          invoiceId: 'inv-1',
          notificationType: NotificationType.reminder,
          sentVia: SentVia.email,
        )),
        expect: () => [
          const InvoiceError(error: 'Exception: Email service unavailable'),
        ],
      );
    });

    group('UpdateApartmentMaintenanceAmount Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [ApartmentUpdated, InvoiceLoading, InvoicesLoaded] when update succeeds',
        build: () {
          final updatedApartment = Apartment(
            id: 'apt-1',
            flatNumber: 'A-101',
            ownerId: 'owner-1',
            tenantId: 'user-1',
            maintenanceAmount: 5500.0, // Updated amount
            floorNumber: 1,
            bhkType: BhkType.bhk2,
            isOccupied: true,
            createdAt: DateTime(2023, 1, 1),
            updatedAt: DateTime.now(),
          );
          when(mockInvoiceService.updateApartmentMaintenanceAmount('apt-1', 5500.0))
              .thenAnswer((_) async => updatedApartment);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const UpdateApartmentMaintenanceAmount(
          apartmentId: 'apt-1',
          newAmount: 5500.0,
        )),
        expect: () => [
          predicate<ApartmentUpdated>((state) => 
            state.message == 'Maintenance amount updated for flat A-101'),
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: const [],
            apartments: testApartments,
          ),
        ],
      );
    });

    group('FilterInvoices Event', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'emits [InvoicesLoaded] with filters when current state is InvoicesLoaded',
        build: () => invoiceBloc,
        seed: () => InvoicesLoaded(
          invoices: testInvoices,
          apartments: testApartments,
        ),
        act: (bloc) => bloc.add(const FilterInvoices(
          status: InvoiceStatus.paid,
          month: 6,
          year: 2023,
        )),
        expect: () => [
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
            filterStatus: InvoiceStatus.paid,
            filterMonth: 6,
            filterYear: 2023,
          ),
        ],
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'does not emit when current state is not InvoicesLoaded',
        build: () => invoiceBloc,
        act: (bloc) => bloc.add(const FilterInvoices(
          status: InvoiceStatus.paid,
          month: 6,
          year: 2023,
        )),
        expect: () => [],
      );
    });

    group('Edge Cases', () {
      blocTest<InvoiceBloc, InvoiceState>(
        'should handle multiple consecutive load events',
        build: () {
          when(mockInvoiceService.getInvoices()).thenAnswer((_) async => testInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) {
          bloc.add(const LoadInvoices());
          bloc.add(const LoadInvoices());
        },
        expect: () => [
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
      );

      blocTest<InvoiceBloc, InvoiceState>(
        'should handle generation with different month names',
        build: () {
          when(mockInvoiceService.generateInvoicesForMonth(1, 2023, 'admin-123'))
              .thenAnswer((_) async => [testInvoices.first]);
          when(mockInvoiceService.getInvoices()).thenAnswer((_) async => testInvoices);
          when(mockInvoiceService.getApartments()).thenAnswer((_) async => testApartments);
          return invoiceBloc;
        },
        act: (bloc) => bloc.add(const GenerateInvoicesForMonth(month: 1, year: 2023)),
        expect: () => [
          InvoiceGenerationInProgress(),
          const InvoicesGenerated(
            generatedCount: 1,
            message: 'Generated 1 invoices for January 2023',
          ),
          InvoiceLoading(),
          InvoicesLoaded(
            invoices: testInvoices,
            apartments: testApartments,
          ),
        ],
      );
    });
  });
}