import 'package:bloc_test/bloc_test.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:townsquare/blocs/user/user_bloc.dart';
import 'package:townsquare/blocs/user/user_event.dart';
import 'package:townsquare/blocs/user/user_state.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';

import '../mocks.dart';
void main() {
  group('UserBloc Tests', () {
    late UserBloc userBloc;
    late MockAuthService mockAuthService;
    late List<User> testUsers;

    setUp(() {
      mockAuthService = MockAuthService();
      userBloc = UserBloc(authService: mockAuthService);

      testUsers = [
        User(
          id: 'user-1',
          name: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1234567890',
          flatNumber: 'A-101',
          role: UserRole.resident,
          createdAt: DateTime(2023, 1, 1),
        ),
        User(
          id: 'admin-1',
          name: 'Admin User',
          email: 'admin@example.com',
          phone: '+1111111111',
          flatNumber: 'ADMIN',
          role: UserRole.admin,
          createdAt: DateTime(2023, 1, 1),
        ),
        User(
          id: 'security-1',
          name: 'Security Guard',
          email: 'security@example.com',
          phone: '+2222222222',
          flatNumber: 'SECURITY',
          role: UserRole.security,
          createdAt: DateTime(2023, 1, 1),
        ),
        User(
          id: 'staff-1',
          name: 'Staff Member',
          email: 'staff@example.com',
          phone: '+3333333333',
          flatNumber: 'STAFF',
          role: UserRole.staff,
          createdAt: DateTime(2023, 1, 1),
        ),
      ];
    });

    tearDown(() {
      userBloc.close();
    });

    test('initial state is UserInitial', () {
      expect(userBloc.state, equals(const UserInitial()));
    });

    group('UserLoadAllRequested Event', () {
      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] when loading all users succeeds',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => testUsers);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadAllRequested()),
        expect: () => [
          const UserLoading(),
          UserLoaded(testUsers),
        ],
        verify: (_) {
          verify(mockAuthService.getAllUsers()).called(1);
        },
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserError] when loading all users fails',
        build: () {
          when(mockAuthService.getAllUsers())
              .thenThrow(Exception('Database connection failed'));
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadAllRequested()),
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load users: Exception: Database connection failed'),
        ],
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] with empty list when no users found',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => []);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadAllRequested()),
        expect: () => [
          const UserLoading(),
          const UserLoaded([]),
        ],
      );
    });

    group('UserLoadByRoleRequested Event', () {
      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] when loading users by role succeeds',
        build: () {
          final residents = testUsers.where((user) => user.role == UserRole.resident).toList();
          when(mockAuthService.getUsersByRole(UserRole.resident))
              .thenAnswer((_) async => residents);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.resident)),
        expect: () => [
          const UserLoading(),
          UserLoaded([testUsers.first]), // Only the resident user
        ],
        verify: (_) {
          verify(mockAuthService.getUsersByRole(UserRole.resident)).called(1);
        },
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] for admin role',
        build: () {
          final admins = testUsers.where((user) => user.role == UserRole.admin).toList();
          when(mockAuthService.getUsersByRole(UserRole.admin))
              .thenAnswer((_) async => admins);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.admin)),
        expect: () => [
          const UserLoading(),
          UserLoaded([testUsers[1]]), // Only the admin user
        ],
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] for security role',
        build: () {
          final securityUsers = testUsers.where((user) => user.role == UserRole.security).toList();
          when(mockAuthService.getUsersByRole(UserRole.security))
              .thenAnswer((_) async => securityUsers);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.security)),
        expect: () => [
          const UserLoading(),
          UserLoaded([testUsers[2]]), // Only the security user
        ],
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] for staff role',
        build: () {
          final staffUsers = testUsers.where((user) => user.role == UserRole.staff).toList();
          when(mockAuthService.getUsersByRole(UserRole.staff))
              .thenAnswer((_) async => staffUsers);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.staff)),
        expect: () => [
          const UserLoading(),
          UserLoaded([testUsers[3]]), // Only the staff user
        ],
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserError] when loading users by role fails',
        build: () {
          when(mockAuthService.getUsersByRole(UserRole.resident))
              .thenThrow(Exception('Permission denied'));
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.resident)),
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load users by role: Exception: Permission denied'),
        ],
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] with empty list when no users found for role',
        build: () {
          when(mockAuthService.getUsersByRole(UserRole.resident))
              .thenAnswer((_) async => []);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.resident)),
        expect: () => [
          const UserLoading(),
          const UserLoaded([]),
        ],
      );
    });

    group('UserLoadByIdRequested Event', () {
      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserSingleLoaded] when loading user by id succeeds',
        build: () {
          when(mockAuthService.getUserById('user-1'))
              .thenAnswer((_) async => testUsers.first);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByIdRequested('user-1')),
        expect: () => [
          const UserLoading(),
          UserSingleLoaded(testUsers.first),
        ],
        verify: (_) {
          verify(mockAuthService.getUserById('user-1')).called(1);
        },
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserError] when user not found',
        build: () {
          when(mockAuthService.getUserById('nonexistent'))
              .thenAnswer((_) async => null);
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByIdRequested('nonexistent')),
        expect: () => [
          const UserLoading(),
          const UserError('User not found'),
        ],
      );

      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserError] when loading user by id fails',
        build: () {
          when(mockAuthService.getUserById('user-1'))
              .thenThrow(Exception('Database error'));
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByIdRequested('user-1')),
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load user: Exception: Database error'),
        ],
      );
    });

    group('UserRefreshRequested Event', () {
      blocTest<UserBloc, UserState>(
        'emits [UserLoading, UserLoaded] when current state is UserLoaded',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => testUsers);
          return userBloc;
        },
        seed: () => UserLoaded(testUsers),
        act: (bloc) => bloc.add(const UserRefreshRequested()),
        expect: () => [
          const UserLoading(),
          UserLoaded(testUsers),
        ],
        verify: (_) {
          verify(mockAuthService.getAllUsers()).called(1);
        },
      );

      blocTest<UserBloc, UserState>(
        'does nothing when current state is not UserLoaded',
        build: () => userBloc,
        seed: () => const UserInitial(),
        act: (bloc) => bloc.add(const UserRefreshRequested()),
        expect: () => [],
        verify: (_) {
          verifyNever(mockAuthService.getAllUsers());
        },
      );

      blocTest<UserBloc, UserState>(
        'does nothing when current state is UserError',
        build: () => userBloc,
        seed: () => const UserError('Previous error'),
        act: (bloc) => bloc.add(const UserRefreshRequested()),
        expect: () => [],
      );

      blocTest<UserBloc, UserState>(
        'does nothing when current state is UserSingleLoaded',
        build: () => userBloc,
        seed: () => UserSingleLoaded(testUsers.first),
        act: (bloc) => bloc.add(const UserRefreshRequested()),
        expect: () => [],
      );
    });

    group('State Transitions', () {
      blocTest<UserBloc, UserState>(
        'should handle multiple consecutive load events',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => testUsers);
          return userBloc;
        },
        act: (bloc) {
          bloc.add(const UserLoadAllRequested());
          bloc.add(const UserLoadAllRequested());
        },
        expect: () => [
          const UserLoading(),
          UserLoaded(testUsers),
          const UserLoading(),
          UserLoaded(testUsers),
        ],
      );

      blocTest<UserBloc, UserState>(
        'should handle transition from loading all users to loading by role',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => testUsers);
          final residents = testUsers.where((user) => user.role == UserRole.resident).toList();
          when(mockAuthService.getUsersByRole(UserRole.resident))
              .thenAnswer((_) async => residents);
          return userBloc;
        },
        act: (bloc) {
          bloc.add(const UserLoadAllRequested());
          bloc.add(const UserLoadByRoleRequested(UserRole.resident));
        },
        expect: () => [
          const UserLoading(),
          UserLoaded(testUsers),
          const UserLoading(),
          UserLoaded([testUsers.first]),
        ],
      );

      blocTest<UserBloc, UserState>(
        'should handle transition from loading users to loading single user',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => testUsers);
          when(mockAuthService.getUserById('user-1'))
              .thenAnswer((_) async => testUsers.first);
          return userBloc;
        },
        act: (bloc) {
          bloc.add(const UserLoadAllRequested());
          bloc.add(const UserLoadByIdRequested('user-1'));
        },
        expect: () => [
          const UserLoading(),
          UserLoaded(testUsers),
          const UserLoading(),
          UserSingleLoaded(testUsers.first),
        ],
      );
    });

    group('Edge Cases', () {
      blocTest<UserBloc, UserState>(
        'should handle network timeout errors',
        build: () {
          when(mockAuthService.getAllUsers())
              .thenThrow(Exception('Connection timeout'));
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadAllRequested()),
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load users: Exception: Connection timeout'),
        ],
      );

      blocTest<UserBloc, UserState>(
        'should handle permission denied errors',
        build: () {
          when(mockAuthService.getUsersByRole(UserRole.admin))
              .thenThrow(Exception('Access denied'));
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByRoleRequested(UserRole.admin)),
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load users by role: Exception: Access denied'),
        ],
      );

      blocTest<UserBloc, UserState>(
        'should handle malformed user data errors',
        build: () {
          when(mockAuthService.getUserById('malformed-user'))
              .thenThrow(const FormatException('Invalid date format'));
          return userBloc;
        },
        act: (bloc) => bloc.add(const UserLoadByIdRequested('malformed-user')),
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load user: FormatException: Invalid date format'),
        ],
      );

      blocTest<UserBloc, UserState>(
        'should handle rapid consecutive requests gracefully',
        build: () {
          when(mockAuthService.getAllUsers()).thenAnswer((_) async => testUsers);
          when(mockAuthService.getUserById('user-1'))
              .thenAnswer((_) async => testUsers.first);
          return userBloc;
        },
        act: (bloc) {
          bloc.add(const UserLoadAllRequested());
          bloc.add(const UserLoadByIdRequested('user-1'));
          bloc.add(const UserRefreshRequested()); // Should not trigger since state will be UserSingleLoaded
        },
        expect: () => [
          const UserLoading(),
          UserLoaded(testUsers),
          const UserLoading(),
          UserSingleLoaded(testUsers.first),
        ],
      );
    });

    group('Error Recovery', () {
      blocTest<UserBloc, UserState>(
        'should recover from error state when new request succeeds',
        build: () {
          when(mockAuthService.getAllUsers())
              .thenThrow(Exception('Database error'));
          when(mockAuthService.getAllUsers())
              .thenAnswer((_) async => testUsers);
          return userBloc;
        },
        act: (bloc) {
          bloc.add(const UserLoadAllRequested()); // Will fail
          bloc.add(const UserLoadAllRequested()); // Will succeed
        },
        expect: () => [
          const UserLoading(),
          const UserError('Failed to load users: Exception: Database error'),
          const UserLoading(),
          UserLoaded(testUsers),
        ],
      );
    });
  });
}