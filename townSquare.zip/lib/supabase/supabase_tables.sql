-- TownSquare Database Schema

-- Users table (linked to auth.users)
CREATE TABLE users (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT NOT NULL,
    flat_number TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'resident', 'staff', 'security')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- User profiles table for additional information
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bio TEXT,
    emergency_contact TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Groups table for community communication
CREATE TABLE groups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    created_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notices table for community announcements
CREATE TABLE notices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT NOT NULL,
    author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    publish_date TIMESTAMPTZ DEFAULT NOW(),
    expiry_date TIMESTAMPTZ,
    is_pinned BOOLEAN DEFAULT FALSE,
    attachments JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Posts table for group discussions
CREATE TABLE posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    group_id UUID NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    attachments JSONB DEFAULT '[]',
    likes_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Comments table for post replies
CREATE TABLE comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Polls table for community voting
CREATE TABLE polls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question TEXT NOT NULL,
    options JSONB NOT NULL,
    start_date TIMESTAMPTZ DEFAULT NOW(),
    end_date TIMESTAMPTZ NOT NULL,
    voters JSONB DEFAULT '[]',
    results JSONB DEFAULT '{}',
    created_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tickets table for helpdesk management
CREATE TABLE tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resident_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    flat_number TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    attachments JSONB DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
    assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
    priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ticket updates table for tracking ticket history
CREATE TABLE ticket_updates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
    update_type TEXT NOT NULL CHECK (update_type IN ('comment', 'status_change', 'assignment')),
    content TEXT NOT NULL,
    updated_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Visitor approvals table for pre-approved visitors
CREATE TABLE visitor_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resident_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    visitor_name TEXT NOT NULL,
    visitor_type TEXT NOT NULL CHECK (visitor_type IN ('guest', 'delivery', 'service', 'contractor')),
    expected_arrival TIMESTAMPTZ NOT NULL,
    entry_code TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'expired', 'used')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Visitor logs table for actual visitor entries
CREATE TABLE visitor_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visitor_name TEXT NOT NULL,
    phone TEXT,
    vehicle TEXT,
    flat_visited TEXT NOT NULL,
    entry_time TIMESTAMPTZ DEFAULT NOW(),
    exit_time TIMESTAMPTZ,
    guard_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    approval_id UUID REFERENCES visitor_approvals(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Panic alerts table for emergency situations
CREATE TABLE panic_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resident_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    flat_number TEXT NOT NULL,
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by UUID REFERENCES users(id) ON DELETE SET NULL,
    acknowledged_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Apartments table for flat management and maintenance charges
CREATE TABLE apartments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flat_number TEXT NOT NULL UNIQUE,
    owner_id UUID REFERENCES users(id) ON DELETE SET NULL,
    tenant_id UUID REFERENCES users(id) ON DELETE SET NULL,
    maintenance_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    floor_number INTEGER NOT NULL,
    bhk_type TEXT NOT NULL CHECK (bhk_type IN ('1BHK', '2BHK', '3BHK', '4BHK', 'STUDIO', 'PENTHOUSE')),
    carpet_area DECIMAL(8,2),
    is_occupied BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Maintenance invoices table for billing management
CREATE TABLE maintenance_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number TEXT NOT NULL UNIQUE,
    apartment_id UUID NOT NULL REFERENCES apartments(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    flat_number TEXT NOT NULL,
    invoice_month INTEGER NOT NULL CHECK (invoice_month BETWEEN 1 AND 12),
    invoice_year INTEGER NOT NULL,
    maintenance_amount DECIMAL(10,2) NOT NULL,
    due_date DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid', 'paid', 'overdue')),
    payment_date TIMESTAMPTZ,
    payment_method TEXT,
    late_fee DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    generated_by UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Invoice notifications table for tracking sent notifications
CREATE TABLE invoice_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID NOT NULL REFERENCES maintenance_invoices(id) ON DELETE CASCADE,
    resident_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    notification_type TEXT NOT NULL CHECK (notification_type IN ('generated', 'reminder', 'overdue')),
    sent_via TEXT NOT NULL CHECK (sent_via IN ('in_app', 'email', 'sms')),
    status TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'failed')),
    message TEXT NOT NULL,
    sent_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_notices_author_id ON notices(author_id);
CREATE INDEX idx_notices_publish_date ON notices(publish_date);
CREATE INDEX idx_posts_group_id ON posts(group_id);
CREATE INDEX idx_posts_author_id ON posts(author_id);
CREATE INDEX idx_comments_post_id ON comments(post_id);
CREATE INDEX idx_tickets_resident_id ON tickets(resident_id);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_assigned_to ON tickets(assigned_to);
CREATE INDEX idx_ticket_updates_ticket_id ON ticket_updates(ticket_id);
CREATE INDEX idx_visitor_approvals_resident_id ON visitor_approvals(resident_id);
CREATE INDEX idx_visitor_logs_guard_id ON visitor_logs(guard_id);
CREATE INDEX idx_panic_alerts_resident_id ON panic_alerts(resident_id);
CREATE INDEX idx_apartments_flat_number ON apartments(flat_number);
CREATE INDEX idx_apartments_owner_id ON apartments(owner_id);
CREATE INDEX idx_apartments_tenant_id ON apartments(tenant_id);
CREATE INDEX idx_maintenance_invoices_apartment_id ON maintenance_invoices(apartment_id);
CREATE INDEX idx_maintenance_invoices_resident_id ON maintenance_invoices(resident_id);
CREATE INDEX idx_maintenance_invoices_status ON maintenance_invoices(status);
CREATE INDEX idx_maintenance_invoices_month_year ON maintenance_invoices(invoice_month, invoice_year);
CREATE INDEX idx_invoice_notifications_invoice_id ON invoice_notifications(invoice_id);
CREATE INDEX idx_invoice_notifications_resident_id ON invoice_notifications(resident_id);