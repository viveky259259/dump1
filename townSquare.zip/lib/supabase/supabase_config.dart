import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:townsquare/services/ssl_pinning_service.dart';
import 'package:townsquare/services/secure_http_service.dart';
import 'package:townsquare/services/supabase_ssl_client.dart';

class SupabaseConfig {
  static const String supabaseUrl = 'https://gkcjbsjkpfuitnepmmod.supabase.co';
  static const String anonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdrY2pic2prcGZ1aXRuZXBtbW9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2NzIzOTMsImV4cCI6MjA3MDI0ODM5M30.GDF1YuAwhOuBnQ0mUfwDrRza_ibREUEIImQlyQpqxCs';
  static bool _isInitialized = false;

  static SupabaseClient get client => Supabase.instance.client;
  static SecureHttpService? _secureHttpService;

  static Future<void> initialize() async {
    // Prevent double initialization
    if (_isInitialized) {
      return;
    }

    try {
      // Check if using placeholder values - allow the demo credentials to work
      if (supabaseUrl.contains('your-project-id') || anonKey.contains('your-anon-key')) {
        _isInitialized = true;
        throw Exception('Supabase credentials not configured. Please set your actual Supabase URL and ANON key in supabase_config.dart');
      }

      // Initialize SSL pinning service
      _secureHttpService = SecureHttpService();
      
      // Skip SSL pinning check for now - certificates need to be configured first
      // TODO: Re-enable SSL pinning after updating certificate fingerprints in ssl_config.dart
      print('SSL pinning temporarily disabled for $supabaseUrl - configure certificates first');
      
      await Supabase.initialize(
        url: supabaseUrl,
        anonKey: anonKey,
        // Temporarily using default HTTP client - re-enable SSL client after certificate config
        // httpClient: SupabaseSSLClient(),
      );
      
      _isInitialized = true;
    } catch (error) {
      print('Supabase initialization error: $error');
      // For development, we'll still mark as initialized to prevent repeated failures
      _isInitialized = true;
      rethrow;
    }
  }

  // Get secure HTTP service instance
  static SecureHttpService get secureHttp {
    _secureHttpService ??= SecureHttpService();
    return _secureHttpService!;
  }

  // Authentication helper methods
  static Future<AuthResponse> signIn(String email, String password) async {
    try {
      final response = await client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      return response;
    } catch (error) {
      throw _handleAuthError(error);
    }
  }

  static Future<AuthResponse> signUp(String email, String password) async {
    try {
      final response = await client.auth.signUp(
        email: email,
        password: password,
      );
      return response;
    } catch (error) {
      throw _handleAuthError(error);
    }
  }

  static Future<void> signOut() async {
    try {
      await client.auth.signOut();
    } catch (error) {
      throw _handleAuthError(error);
    }
  }

  static User? get currentUser => client.auth.currentUser;

  static Stream<AuthState> get authStateChanges => client.auth.onAuthStateChange;

  // Database helper methods
  static Future<List<Map<String, dynamic>>> getUserProfile(String userId) async {
    try {
      final response = await client
          .from('users')
          .select()
          .eq('id', userId);
      return response;
    } catch (error) {
      throw _handleDatabaseError(error);
    }
  }

  static Future<Map<String, dynamic>> createUserProfile({
    required String id,
    required String name,
    required String email,
    required String phone,
    required String flatNumber,
    required String role,
  }) async {
    try {
      final response = await client
          .from('users')
          .insert({
            'id': id,
            'name': name,
            'email': email,
            'phone': phone,
            'flat_number': flatNumber,
            'role': role,
            'created_at': DateTime.now().toIso8601String(),
          })
          .select()
          .single();
      return response;
    } catch (error) {
      throw _handleDatabaseError(error);
    }
  }

  static Future<Map<String, dynamic>> updateUserProfile(
    String userId,
    Map<String, dynamic> updates,
  ) async {
    try {
      final response = await client
          .from('users')
          .update(updates)
          .eq('id', userId)
          .select()
          .single();
      return response;
    } catch (error) {
      throw _handleDatabaseError(error);
    }
  }

  // Error handling
  static String _handleAuthError(dynamic error) {
    if (error is AuthException) {
      switch (error.message) {
        case 'Invalid login credentials':
          return 'Invalid email or password. Please try again.';
        case 'Email not confirmed':
          return 'Please check your email and confirm your account.';
        case 'Too many requests':
          return 'Too many login attempts. Please try again later.';
        default:
          return error.message;
      }
    }
    return 'Authentication error occurred. Please try again.';
  }

  static String _handleDatabaseError(dynamic error) {
    if (error is PostgrestException) {
      return 'Database error: ${error.message}';
    }
    return 'An unexpected error occurred. Please try again.';
  }
}