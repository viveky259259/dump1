-- Sample Data for TownSquare App

-- Create helper function for inserting users to auth.users
CREATE OR REPLACE FUNCTION insert_user_to_auth(
    email text,
    password text
) RETURNS UUID AS $$
DECLARE
  user_id uuid;
  encrypted_pw text;
BEGIN
  user_id := gen_random_uuid();
  encrypted_pw := crypt(password, gen_salt('bf'));
  
  INSERT INTO auth.users
    (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, recovery_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at, confirmation_token, email_change, email_change_token_new, recovery_token)
  VALUES
    (gen_random_uuid(), user_id, 'authenticated', 'authenticated', email, encrypted_pw, '2023-05-03 19:41:43.585805+00', '2023-04-22 13:10:03.275387+00', '2023-04-22 13:10:31.458239+00', '{"provider":"email","providers":["email"]}', '{}', '2023-05-03 19:41:43.580424+00', '2023-05-03 19:41:43.585948+00', '', '', '', '');
  
  INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
  VALUES
    (gen_random_uuid(), user_id, format('{"sub":"%s","email":"%s"}', user_id::text, email)::jsonb, 'email', '2023-05-03 19:41:43.582456+00', '2023-05-03 19:41:43.582497+00', '2023-05-03 19:41:43.582497+00');
  
  RETURN user_id;
END;
$$ LANGUAGE plpgsql;

-- Insert sample users to auth.users and get their IDs
DO $$
DECLARE
    admin_id uuid;
    resident1_id uuid;
    resident2_id uuid;
    staff_id uuid;
    security_id uuid;
BEGIN
    admin_id := insert_user_to_auth('admin@townsquare.com', 'admin123');
    resident1_id := insert_user_to_auth('michael.chen@email.com', 'resident123');
    resident2_id := insert_user_to_auth('emily.davis@email.com', 'resident123');
    staff_id := insert_user_to_auth('david.maintenance@townsquare.com', 'staff123');
    security_id := insert_user_to_auth('james.security@townsquare.com', 'security123');

    -- Insert users data
    INSERT INTO users (id, name, email, phone, flat_number, role, created_at) VALUES
    (admin_id, 'Sarah Johnson', 'admin@townsquare.com', '+1 (555) 123-4567', 'A-101', 'admin', NOW() - interval '30 days'),
    (resident1_id, 'Michael Chen', 'michael.chen@email.com', '+1 (555) 234-5678', 'B-205', 'resident', NOW() - interval '25 days'),
    (resident2_id, 'Emily Davis', 'emily.davis@email.com', '+1 (555) 567-8901', 'C-302', 'resident', NOW() - interval '10 days'),
    (staff_id, 'David Rodriguez', 'david.maintenance@townsquare.com', '+1 (555) 345-6789', 'Staff Quarters', 'staff', NOW() - interval '20 days'),
    (security_id, 'James Wilson', 'james.security@townsquare.com', '+1 (555) 456-7890', 'Security Office', 'security', NOW() - interval '15 days');

    -- Insert user profiles
    INSERT INTO user_profiles (user_id, bio, emergency_contact) VALUES
    (admin_id, 'Community Administrator with 5+ years experience in residential management.', '+1 (555) 111-2222'),
    (resident1_id, 'Software engineer working from home. Love community events!', '+1 (555) 999-8888'),
    (resident2_id, 'Teacher at local elementary school. Happy to help with community activities.', '+1 (555) 777-6666'),
    (staff_id, 'Maintenance specialist with expertise in plumbing and electrical work.', '+1 (555) 555-4444'),
    (security_id, 'Security guard with 10+ years experience. Available 24/7 for emergencies.', '+1 (555) 333-2222');

    -- Insert default community group
    INSERT INTO groups (name, description, created_by, is_default) VALUES
    ('General Community', 'Main community discussion group for all residents', admin_id, true),
    ('Maintenance Updates', 'Updates and discussions about building maintenance', admin_id, false),
    ('Social Events', 'Planning and coordination of community social events', admin_id, false);

    -- Insert sample notices
    INSERT INTO notices (title, content, category, author_id, publish_date, expiry_date, is_pinned) VALUES
    ('Welcome to TownSquare Community Portal', 'We are excited to launch our new digital community platform! This portal will help us stay connected, manage requests, and enhance our community experience. Please explore all the features and let us know your feedback.', 'General', admin_id, NOW() - interval '3 days', NOW() + interval '30 days', true),
    ('Monthly Maintenance Schedule - December 2024', 'Dear Residents, Please note the following maintenance activities scheduled for this month: Dec 15: Elevator maintenance (Building A), Dec 20: Water tank cleaning, Dec 25: Holiday - No maintenance. Thank you for your cooperation.', 'Maintenance', admin_id, NOW() - interval '2 days', NOW() + interval '25 days', false),
    ('Community Holiday Party - December 31st', 'Join us for our annual community holiday party! Date: December 31st, Time: 7:00 PM - 11:00 PM, Venue: Community Hall. Food, music, and fun activities for all ages. RSVP required.', 'Events', admin_id, NOW() - interval '1 day', NOW() + interval '20 days', true),
    ('New Parking Guidelines Effective January 1st', 'Important updates to our parking policy: 1) Visitor parking limited to 4 hours, 2) Monthly parking passes now available, 3) Electric vehicle charging stations installed. Full details attached.', 'Rules', admin_id, NOW(), NOW() + interval '45 days', false);

    -- Insert sample tickets
    INSERT INTO tickets (resident_id, flat_number, category, description, status, priority) VALUES
    (resident1_id, 'B-205', 'Plumbing', 'Kitchen sink faucet is leaking. Water drips continuously even when turned off completely. Need urgent repair.', 'open', 'high'),
    (resident2_id, 'C-302', 'Electrical', 'Living room ceiling fan making loud noise and wobbling. Seems unsafe to use.', 'in_progress', 'medium'),
    (resident1_id, 'B-205', 'Internet', 'WiFi connection in apartment is very slow. Speed test shows only 10% of promised speed.', 'resolved', 'low'),
    (resident2_id, 'C-302', 'Maintenance', 'Balcony door handle is broken. Cannot open or close the door properly.', 'open', 'medium');

    -- Insert ticket updates
    INSERT INTO ticket_updates (ticket_id, update_type, content, updated_by) VALUES
    ((SELECT id FROM tickets WHERE description LIKE '%ceiling fan%'), 'status_change', 'Ticket assigned to maintenance team. Scheduled for repair tomorrow.', staff_id),
    ((SELECT id FROM tickets WHERE description LIKE '%WiFi%'), 'comment', 'Contacted ISP. Issue resolved by replacing router in building network room.', staff_id),
    ((SELECT id FROM tickets WHERE description LIKE '%WiFi%'), 'status_change', 'Issue resolved. Internet speed restored to normal.', staff_id);

    -- Insert sample visitor approvals
    INSERT INTO visitor_approvals (resident_id, visitor_name, visitor_type, expected_arrival, entry_code, status) VALUES
    (resident1_id, 'John Smith', 'guest', NOW() + interval '2 hours', 'VIS2024001', 'approved'),
    (resident2_id, 'Amazon Delivery', 'delivery', NOW() + interval '1 hour', 'DEL2024001', 'pending'),
    (resident1_id, 'Cable Technician', 'service', NOW() + interval '4 hours', 'SRV2024001', 'approved');

    -- Insert sample visitor logs
    INSERT INTO visitor_logs (visitor_name, phone, vehicle, flat_visited, entry_time, exit_time, guard_id) VALUES
    ('Pizza Delivery', '+1 (555) 123-4567', 'Bike', 'B-205', NOW() - interval '2 hours', NOW() - interval '1 hour 45 minutes', security_id),
    ('Maria Rodriguez', '+1 (555) 987-6543', 'Honda Civic', 'C-302', NOW() - interval '3 hours', NULL, security_id);

    -- Insert sample polls
    INSERT INTO polls (question, options, start_date, end_date, voters, results, created_by) VALUES
    ('What time should our community gym be open?', '["6 AM - 10 PM", "5 AM - 11 PM", "24/7 Access", "7 AM - 9 PM"]', NOW() - interval '2 days', NOW() + interval '5 days', '[]', '{"6 AM - 10 PM": 12, "5 AM - 11 PM": 8, "24/7 Access": 15, "7 AM - 9 PM": 5}', admin_id),
    ('Which community event would you like to see next?', '["Movie Night", "BBQ Party", "Fitness Class", "Book Club"]', NOW() - interval '1 day', NOW() + interval '6 days', '[]', '{"Movie Night": 18, "BBQ Party": 22, "Fitness Class": 14, "Book Club": 6}', admin_id);

    -- Insert sample apartments
    INSERT INTO apartments (flat_number, owner_id, tenant_id, maintenance_amount, floor_number, bhk_type, carpet_area, is_occupied) VALUES
    ('A-101', admin_id, NULL, 2500.00, 1, '2BHK', 1200.0, true),
    ('A-102', NULL, NULL, 2500.00, 1, '2BHK', 1200.0, false),
    ('B-205', resident1_id, NULL, 3500.00, 2, '3BHK', 1500.0, true),
    ('B-206', NULL, NULL, 3500.00, 2, '3BHK', 1500.0, false),
    ('C-302', resident2_id, NULL, 2800.00, 3, '2BHK', 1300.0, true),
    ('C-303', NULL, NULL, 2800.00, 3, '2BHK', 1300.0, false),
    ('D-401', NULL, NULL, 4200.00, 4, '4BHK', 1800.0, false),
    ('D-402', NULL, NULL, 4200.00, 4, '4BHK', 1800.0, false);

    -- Insert sample maintenance invoices
    INSERT INTO maintenance_invoices (
        invoice_number, apartment_id, resident_id, flat_number, 
        invoice_month, invoice_year, maintenance_amount, due_date, 
        status, payment_date, payment_method, late_fee, total_amount, generated_by
    ) VALUES
    -- November 2024 invoices (paid)
    ('INV-2024-11-0001', 
     (SELECT id FROM apartments WHERE flat_number = 'A-101'), 
     admin_id, 'A-101', 
     11, 2024, 2500.00, '2024-11-25', 
     'paid', '2024-11-20 10:30:00', 'UPI', 0.00, 2500.00, admin_id),
    
    ('INV-2024-11-0002', 
     (SELECT id FROM apartments WHERE flat_number = 'B-205'), 
     resident1_id, 'B-205', 
     11, 2024, 3500.00, '2024-11-25', 
     'paid', '2024-11-22 14:15:00', 'Bank Transfer', 0.00, 3500.00, admin_id),
    
    ('INV-2024-11-0003', 
     (SELECT id FROM apartments WHERE flat_number = 'C-302'), 
     resident2_id, 'C-302', 
     11, 2024, 2800.00, '2024-11-25', 
     'paid', '2024-11-18 09:45:00', 'Cash', 0.00, 2800.00, admin_id),
    
    -- December 2024 invoices (current month - some paid, some pending)
    ('INV-2024-12-0001', 
     (SELECT id FROM apartments WHERE flat_number = 'A-101'), 
     admin_id, 'A-101', 
     12, 2024, 2500.00, '2024-12-25', 
     'unpaid', NULL, NULL, 0.00, 2500.00, admin_id),
    
    ('INV-2024-12-0002', 
     (SELECT id FROM apartments WHERE flat_number = 'B-205'), 
     resident1_id, 'B-205', 
     12, 2024, 3500.00, '2024-12-25', 
     'paid', '2024-12-15 16:20:00', 'Online', 0.00, 3500.00, admin_id),
    
    ('INV-2024-12-0003', 
     (SELECT id FROM apartments WHERE flat_number = 'C-302'), 
     resident2_id, 'C-302', 
     12, 2024, 2800.00, '2024-12-25', 
     'unpaid', NULL, NULL, 0.00, 2800.00, admin_id),
    
    -- October 2024 invoices (one overdue)
    ('INV-2024-10-0001', 
     (SELECT id FROM apartments WHERE flat_number = 'A-101'), 
     admin_id, 'A-101', 
     10, 2024, 2500.00, '2024-10-25', 
     'overdue', NULL, NULL, 250.00, 2750.00, admin_id);

    -- Insert sample invoice notifications
    INSERT INTO invoice_notifications (invoice_id, resident_id, notification_type, sent_via, message) VALUES
    ((SELECT id FROM maintenance_invoices WHERE invoice_number = 'INV-2024-12-0001'), admin_id, 'generated', 'in_app', 'New maintenance invoice generated for December 2024. Amount: ₹2500.00'),
    ((SELECT id FROM maintenance_invoices WHERE invoice_number = 'INV-2024-12-0002'), resident1_id, 'generated', 'in_app', 'New maintenance invoice generated for December 2024. Amount: ₹3500.00'),
    ((SELECT id FROM maintenance_invoices WHERE invoice_number = 'INV-2024-12-0003'), resident2_id, 'generated', 'in_app', 'New maintenance invoice generated for December 2024. Amount: ₹2800.00'),
    ((SELECT id FROM maintenance_invoices WHERE invoice_number = 'INV-2024-10-0001'), admin_id, 'overdue', 'in_app', 'OVERDUE: Your maintenance payment for October 2024 was due on 25/10/2024');

END $$;