-- Enable Row Level Security for all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE polls ENABLE ROW LEVEL SECURITY;
ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitor_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitor_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE panic_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE apartments ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_notifications ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can be created on signup" ON users
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view all users" ON users
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can update their own profile" ON users
  FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can delete their own profile" ON users
  FOR DELETE USING (auth.uid() = id);

-- User profiles table policies
CREATE POLICY "Authenticated users can manage user profiles" ON user_profiles
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Groups table policies
CREATE POLICY "Authenticated users can manage groups" ON groups
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Notices table policies
CREATE POLICY "Authenticated users can manage notices" ON notices
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Posts table policies
CREATE POLICY "Authenticated users can manage posts" ON posts
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Comments table policies
CREATE POLICY "Authenticated users can manage comments" ON comments
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Polls table policies
CREATE POLICY "Authenticated users can manage polls" ON polls
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Tickets table policies
CREATE POLICY "Authenticated users can manage tickets" ON tickets
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Ticket updates table policies
CREATE POLICY "Authenticated users can manage ticket updates" ON ticket_updates
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Visitor approvals table policies
CREATE POLICY "Authenticated users can manage visitor approvals" ON visitor_approvals
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Visitor logs table policies
CREATE POLICY "Authenticated users can manage visitor logs" ON visitor_logs
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Panic alerts table policies
CREATE POLICY "Authenticated users can manage panic alerts" ON panic_alerts
  FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Apartments table policies
CREATE POLICY "Authenticated users can view apartments" ON apartments
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Admins can manage apartments" ON apartments
  FOR ALL USING (
    auth.role() = 'authenticated' AND 
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    auth.role() = 'authenticated' AND 
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
  );

-- Maintenance invoices table policies
CREATE POLICY "Users can view their own invoices" ON maintenance_invoices
  FOR SELECT USING (
    auth.role() = 'authenticated' AND 
    (resident_id = auth.uid() OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'))
  );

CREATE POLICY "Admins can manage all invoices" ON maintenance_invoices
  FOR ALL USING (
    auth.role() = 'authenticated' AND 
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    auth.role() = 'authenticated' AND 
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
  );

-- Invoice notifications table policies
CREATE POLICY "Users can view their own notifications" ON invoice_notifications
  FOR SELECT USING (
    auth.role() = 'authenticated' AND 
    (resident_id = auth.uid() OR EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'))
  );

CREATE POLICY "Admins can manage all notifications" ON invoice_notifications
  FOR ALL USING (
    auth.role() = 'authenticated' AND 
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    auth.role() = 'authenticated' AND 
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
  );