import 'package:flutter/material.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';
import 'package:townsquare/services/storage_service.dart';
import 'package:townsquare/widgets/common_widgets.dart';
import 'package:townsquare/utils/constants.dart';
import 'package:intl/intl.dart';

class TicketsScreen extends StatefulWidget {
  const TicketsScreen({super.key});

  @override
  State<TicketsScreen> createState() => _TicketsScreenState();
}

class _TicketsScreenState extends State<TicketsScreen> {
  TicketStatus? _selectedStatus;

  @override
  Widget build(BuildContext context) {
    final currentUser = AuthService.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppTexts.myTickets),
        actions: [
          IconButton(
            icon: const Icon(AppIcons.filter),
            onPressed: _showFilterDialog,
          ),
          const UserSwitcher(),
        ],
      ),
      body: Column(
        children: [
          _buildStatusFilter(),
          Expanded(child: _buildTicketsList()),
        ],
      ),
      floatingActionButton: currentUser?.role == UserRole.resident
          ? FloatingActionButton(
              onPressed: () => _showCreateTicketDialog(context),
              child: const Icon(AppIcons.add),
            )
          : null,
    );
  }

  Widget _buildStatusFilter() {
    return Container(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            CategoryChip(
              label: 'All',
              emoji: '📋',
              isSelected: _selectedStatus == null,
              onTap: () => setState(() => _selectedStatus = null),
            ),
            const SizedBox(width: 8),
            ...TicketStatus.values.map((status) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: CategoryChip(
                    label: status.displayName,
                    emoji: _getStatusEmoji(status),
                    isSelected: _selectedStatus == status,
                    onTap: () => setState(() => _selectedStatus = status),
                  ),
                )),
          ],
        ),
      ),
    );
  }

  String _getStatusEmoji(TicketStatus status) {
    switch (status) {
      case TicketStatus.open:
        return '🔓';
      case TicketStatus.inProgress:
        return '⚙️';
      case TicketStatus.resolved:
        return '✅';
      case TicketStatus.closed:
        return '🔒';
    }
  }

  Widget _buildTicketsList() {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return const SizedBox.shrink();

    List<Ticket> tickets;
    
    if (AuthService.instance.isAdmin) {
      tickets = StorageService.instance.tickets;
    } else {
      switch (currentUser.role) {
        case UserRole.staff:
          tickets = StorageService.instance.getTicketsForStaff(currentUser.id);
          break;
        case UserRole.resident:
        case UserRole.security:
        default:
          tickets = StorageService.instance.getTicketsForResident(currentUser.id);
          break;
      }
    }

    if (_selectedStatus != null) {
      tickets = tickets.where((ticket) => ticket.status == _selectedStatus).toList();
    }

    if (tickets.isEmpty) {
      return EmptyState(
        icon: AppIcons.tickets,
        title: 'No Tickets Found',
        subtitle: _selectedStatus != null
            ? 'No tickets with ${_selectedStatus!.displayName.toLowerCase()} status'
            : 'Your tickets will appear here',
        action: currentUser.role == UserRole.resident
            ? ElevatedButton.icon(
                onPressed: () => _showCreateTicketDialog(context),
                icon: const Icon(AppIcons.add),
                label: const Text('Create Ticket'),
              )
            : null,
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      itemCount: tickets.length,
      itemBuilder: (context, index) {
        final ticket = tickets[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: _TicketCard(
            ticket: ticket,
            onTap: () => _showTicketDetail(context, ticket),
          ),
        );
      },
    );
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Filter Tickets'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('All Tickets'),
              leading: Radio<TicketStatus?>(
                value: null,
                groupValue: _selectedStatus,
                onChanged: (value) {
                  setState(() => _selectedStatus = value);
                  Navigator.pop(context);
                },
              ),
            ),
            ...TicketStatus.values.map((status) => ListTile(
                  title: Text(status.displayName),
                  leading: Radio<TicketStatus?>(
                    value: status,
                    groupValue: _selectedStatus,
                    onChanged: (value) {
                      setState(() => _selectedStatus = value);
                      Navigator.pop(context);
                    },
                  ),
                )),
          ],
        ),
      ),
    );
  }

  void _showTicketDetail(BuildContext context, Ticket ticket) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _TicketDetailSheet(
        ticket: ticket,
        onTicketUpdated: () => setState(() {}),
      ),
    );
  }

  void _showCreateTicketDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _CreateTicketSheet(
        onTicketCreated: () => setState(() {}),
      ),
    );
  }
}

class _TicketCard extends StatelessWidget {
  final Ticket ticket;
  final VoidCallback onTap;

  const _TicketCard({
    required this.ticket,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(ticket.residentId),
      builder: (context, residentSnapshot) {
        final resident = residentSnapshot.data;
        
        if (ticket.assignedTo != null) {
          return FutureBuilder<User?>(
            future: AuthService.instance.getUserById(ticket.assignedTo!),
            builder: (context, staffSnapshot) {
              final assignedStaff = staffSnapshot.data;
              return _buildCard(context, theme, resident, assignedStaff);
            },
          );
        } else {
          return _buildCard(context, theme, resident, null);
        }
      },
    );
  }

  Widget _buildCard(BuildContext context, ThemeData theme, User? resident, User? assignedStaff) {
    return AppCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: ticket.category.emoji == '🔧'
                      ? Colors.blue.withValues(alpha: 0.1)
                      : ticket.category.emoji == '⚡'
                          ? Colors.orange.withValues(alpha: 0.1)
                          : Colors.green.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${ticket.category.emoji} ${ticket.category.displayName}',
                  style: theme.textTheme.labelSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const Spacer(),
              StatusBadge(
                label: ticket.status.displayName,
                color: _getStatusColor(ticket.status),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'ID: ${ticket.id.substring(ticket.id.length - 6)}',
                  style: theme.textTheme.labelSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Flat ${ticket.flatNumber}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            ticket.description,
            style: theme.textTheme.bodyMedium,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Icon(AppIcons.person, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              const SizedBox(width: 4),
              Text(
                resident?.name ?? 'Unknown',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
              const Spacer(),
              Icon(AppIcons.calendar, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              const SizedBox(width: 4),
              Text(
                DateFormat('MMM dd').format(ticket.createdAt),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
          if (assignedStaff != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.person_outline, size: 16, color: theme.colorScheme.primary),
                const SizedBox(width: 4),
                Text(
                  'Assigned to ${assignedStaff.name}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Color _getStatusColor(TicketStatus status) {
    switch (status) {
      case TicketStatus.open:
        return AppColors.info;
      case TicketStatus.inProgress:
        return AppColors.warning;
      case TicketStatus.resolved:
        return AppColors.success;
      case TicketStatus.closed:
        return Colors.grey;
    }
  }
}

class _TicketDetailSheet extends StatefulWidget {
  final Ticket ticket;
  final VoidCallback onTicketUpdated;

  const _TicketDetailSheet({
    required this.ticket,
    required this.onTicketUpdated,
  });

  @override
  State<_TicketDetailSheet> createState() => _TicketDetailSheetState();
}

class _TicketDetailSheetState extends State<_TicketDetailSheet> {
  late Ticket _ticket;
  final _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _ticket = widget.ticket;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final currentUser = AuthService.instance.currentUser;
    final canManage = AuthService.instance.isAdmin || currentUser?.role == UserRole.staff;
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(_ticket.residentId),
      builder: (context, snapshot) {
        final resident = snapshot.data;
        return _buildDetailSheet(context, theme, resident, canManage);
      },
    );
  }

  Widget _buildDetailSheet(BuildContext context, ThemeData theme, User? resident, bool canManage) {
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(AppIcons.close),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              'Ticket #${_ticket.id.substring(_ticket.id.length - 6)}',
                              style: theme.textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace',
                              ),
                            ),
                          ),
                          const Spacer(),
                          StatusBadge(
                            label: _ticket.status.displayName,
                            color: _getStatusColor(_ticket.status),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  '${_ticket.category.emoji} ${_ticket.category.displayName}',
                                  style: theme.textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const Spacer(),
                                Text(
                                  'Flat ${_ticket.flatNumber}',
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Reported by ${resident?.name ?? 'Unknown'}',
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              DateFormat('MMM dd, yyyy • h:mm a').format(_ticket.createdAt),
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Description',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _ticket.description,
                        style: theme.textTheme.bodyLarge?.copyWith(height: 1.6),
                      ),
                      if (canManage) ...[
                        const SizedBox(height: 24),
                        _buildManagementSection(theme),
                      ],
                      const SizedBox(height: 24),
                      Text(
                        'Timeline',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _buildTimeline(theme),
                      if (canManage) ...[
                        const SizedBox(height: 24),
                        _buildAddCommentSection(theme),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildManagementSection(ThemeData theme) {
    return FutureBuilder<List<User>>(
      future: AuthService.instance.getUsersByRole(UserRole.staff),
      builder: (context, snapshot) {
        final staffMembers = snapshot.data ?? [];
        return _buildManagementContainer(theme, staffMembers);
      },
    );
  }

  Widget _buildManagementContainer(ThemeData theme, List<User> staffMembers) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.primary.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Management Actions',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
              color: theme.colorScheme.primary,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<TicketStatus>(
                  value: _ticket.status,
                  decoration: const InputDecoration(
                    labelText: 'Status',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  items: TicketStatus.values.map((status) => DropdownMenuItem(
                        value: status,
                        child: Text(status.displayName),
                      )).toList(),
                  onChanged: (status) {
                    if (status != null) {
                      _updateTicketStatus(status);
                    }
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButtonFormField<String?>(
                  value: _ticket.assignedTo,
                  decoration: const InputDecoration(
                    labelText: 'Assign to',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  items: [
                    const DropdownMenuItem<String?>(
                      value: null,
                      child: Text('Unassigned'),
                    ),
                    ...staffMembers.map((staff) => DropdownMenuItem(
                          value: staff.id,
                          child: Text(staff.name),
                        )),
                  ],
                  onChanged: (staffId) => _assignTicket(staffId),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTimeline(ThemeData theme) {
    final allUpdates = [
      TicketUpdate(
        id: 'initial',
        ticketId: _ticket.id,
        updateType: 'created',
        content: 'Ticket created',
        updatedBy: _ticket.residentId,
        timestamp: _ticket.createdAt,
      ),
      ..._ticket.updates,
    ];

    return Column(
      children: allUpdates.map((update) {
        return FutureBuilder<User?>(
          future: AuthService.instance.getUserById(update.updatedBy),
          builder: (context, snapshot) {
            final user = snapshot.data;
            return _buildTimelineItem(theme, update, user);
          },
        );
      }).toList(),
    );
  }

  Widget _buildTimelineItem(ThemeData theme, TicketUpdate update, User? user) {
    return Container(
          margin: const EdgeInsets.only(bottom: 16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _getUpdateIcon(update.updateType),
                  size: 16,
                  color: theme.colorScheme.onPrimary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      update.content,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${user?.name ?? 'Unknown'} • ${DateFormat('MMM dd, h:mm a').format(update.timestamp)}',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
  }

  Widget _buildAddCommentSection(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Add Update',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _commentController,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Add a comment or update...',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _addComment,
              child: const Text('Add Update'),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getUpdateIcon(String updateType) {
    switch (updateType) {
      case 'created':
        return Icons.create;
      case 'status_change':
        return Icons.update;
      case 'assignment':
        return Icons.person_add;
      case 'comment':
        return Icons.chat;
      default:
        return Icons.info;
    }
  }

  Color _getStatusColor(TicketStatus status) {
    switch (status) {
      case TicketStatus.open:
        return AppColors.info;
      case TicketStatus.inProgress:
        return AppColors.warning;
      case TicketStatus.resolved:
        return AppColors.success;
      case TicketStatus.closed:
        return Colors.grey;
    }
  }

  void _updateTicketStatus(TicketStatus newStatus) async {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return;

    final update = TicketUpdate(
      id: 'update_${DateTime.now().millisecondsSinceEpoch}',
      ticketId: _ticket.id,
      updateType: 'status_change',
      content: 'Status changed to ${newStatus.displayName}',
      updatedBy: currentUser.id,
      timestamp: DateTime.now(),
    );

    final updatedTicket = Ticket(
      id: _ticket.id,
      residentId: _ticket.residentId,
      flatNumber: _ticket.flatNumber,
      category: _ticket.category,
      description: _ticket.description,
      attachments: _ticket.attachments,
      status: newStatus,
      createdAt: _ticket.createdAt,
      assignedTo: _ticket.assignedTo,
      updates: [..._ticket.updates, update],
    );

    await StorageService.instance.updateTicket(updatedTicket);
    setState(() => _ticket = updatedTicket);
    widget.onTicketUpdated();
  }

  void _assignTicket(String? staffId) async {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return;

    final staff = staffId != null ? await AuthService.instance.getUserById(staffId) : null;
    final updateContent = staffId != null
        ? 'Assigned to ${staff?.name ?? 'Unknown'}'
        : 'Unassigned';

    final update = TicketUpdate(
      id: 'update_${DateTime.now().millisecondsSinceEpoch}',
      ticketId: _ticket.id,
      updateType: 'assignment',
      content: updateContent,
      updatedBy: currentUser.id,
      timestamp: DateTime.now(),
    );

    final updatedTicket = Ticket(
      id: _ticket.id,
      residentId: _ticket.residentId,
      flatNumber: _ticket.flatNumber,
      category: _ticket.category,
      description: _ticket.description,
      attachments: _ticket.attachments,
      status: _ticket.status,
      createdAt: _ticket.createdAt,
      assignedTo: staffId,
      updates: [..._ticket.updates, update],
    );

    await StorageService.instance.updateTicket(updatedTicket);
    setState(() => _ticket = updatedTicket);
    widget.onTicketUpdated();
  }

  void _addComment() async {
    if (_commentController.text.trim().isEmpty) return;

    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return;

    final update = TicketUpdate(
      id: 'update_${DateTime.now().millisecondsSinceEpoch}',
      ticketId: _ticket.id,
      updateType: 'comment',
      content: _commentController.text.trim(),
      updatedBy: currentUser.id,
      timestamp: DateTime.now(),
    );

    final updatedTicket = Ticket(
      id: _ticket.id,
      residentId: _ticket.residentId,
      flatNumber: _ticket.flatNumber,
      category: _ticket.category,
      description: _ticket.description,
      attachments: _ticket.attachments,
      status: _ticket.status,
      createdAt: _ticket.createdAt,
      assignedTo: _ticket.assignedTo,
      updates: [..._ticket.updates, update],
    );

    await StorageService.instance.updateTicket(updatedTicket);
    setState(() {
      _ticket = updatedTicket;
      _commentController.clear();
    });
    widget.onTicketUpdated();
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }
}

class _CreateTicketSheet extends StatefulWidget {
  final VoidCallback onTicketCreated;

  const _CreateTicketSheet({required this.onTicketCreated});

  @override
  State<_CreateTicketSheet> createState() => _CreateTicketSheetState();
}

class _CreateTicketSheetState extends State<_CreateTicketSheet> {
  final _formKey = GlobalKey<FormState>();
  final _descriptionController = TextEditingController();
  TicketCategory _selectedCategory = TicketCategory.plumbing;
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  const Spacer(),
                  Text(
                    'Create Ticket',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _createTicket,
                    child: _isLoading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Submit'),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Category',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: TicketCategory.values.map((category) => CategoryChip(
                            label: category.displayName,
                            emoji: category.emoji,
                            isSelected: _selectedCategory == category,
                            onTap: () => setState(() => _selectedCategory = category),
                          )).toList(),
                    ),
                    const SizedBox(height: 24),
                    TextFormField(
                      controller: _descriptionController,
                      maxLines: 6,
                      decoration: const InputDecoration(
                        labelText: 'Description *',
                        hintText: 'Please describe the issue in detail...',
                        border: OutlineInputBorder(),
                        alignLabelWithHint: true,
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Description is required';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(AppIcons.info, color: theme.colorScheme.primary),
                              const SizedBox(width: 8),
                              Text(
                                'What happens next?',
                                style: theme.textTheme.titleSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: theme.colorScheme.primary,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '• Your ticket will be reviewed by the management team\n'
                            '• You will receive updates on the status\n'
                            '• Assigned staff will contact you if needed\n'
                            '• You can track progress in this app',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _createTicket() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final currentUser = AuthService.instance.currentUser;
      if (currentUser == null) return;

      final ticket = Ticket(
        id: 'ticket_${DateTime.now().millisecondsSinceEpoch}',
        residentId: currentUser.id,
        flatNumber: currentUser.flatNumber,
        category: _selectedCategory,
        description: _descriptionController.text.trim(),
        status: TicketStatus.open,
        createdAt: DateTime.now(),
      );

      await StorageService.instance.addTicket(ticket);

      if (mounted) {
        Navigator.pop(context);
        widget.onTicketCreated();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(AppIcons.success, color: Colors.white),
                const SizedBox(width: 8),
                Text('Ticket #${ticket.id.substring(ticket.id.length - 6)} created successfully'),
              ],
            ),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }
}