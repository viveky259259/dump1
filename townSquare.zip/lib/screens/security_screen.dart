import 'package:flutter/material.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';
import 'package:townsquare/services/storage_service.dart';
import 'package:townsquare/widgets/common_widgets.dart';
import 'package:townsquare/utils/constants.dart';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'dart:math';

class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});

  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = AuthService.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppTexts.securityTab),
        actions: const [UserSwitcher()],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Visitors', icon: Icon(Icons.people)),
            Tab(text: 'Pre-approve', icon: Icon(Icons.add_circle)),
            Tab(text: 'Emergency', icon: Icon(Icons.emergency)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _VisitorListTab(),
          _PreApproveTab(onVisitorAdded: () => setState(() {})),
          const _EmergencyTab(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}

class _VisitorListTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return const SizedBox.shrink();

    List<VisitorApproval> visitors;
    String title;

    if (currentUser.role == UserRole.security || AuthService.instance.isAdmin) {
      visitors = StorageService.instance.getTodaysVisitorApprovals();
      title = 'Today\'s Approved Visitors';
    } else {
      visitors = StorageService.instance.getVisitorApprovalsForResident(currentUser.id);
      title = 'My Approved Visitors';
    }

    if (visitors.isEmpty) {
      return EmptyState(
        icon: AppIcons.security,
        title: 'No Visitors Found',
        subtitle: currentUser.role == UserRole.security
            ? 'No approved visitors for today'
            : 'Your approved visitors will appear here',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      itemCount: visitors.length,
      itemBuilder: (context, index) {
        final visitor = visitors[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: _VisitorCard(
            visitor: visitor,
            showResident: currentUser.role == UserRole.security || AuthService.instance.isAdmin,
            onTap: () => _showVisitorDetail(context, visitor),
          ),
        );
      },
    );
  }

  void _showVisitorDetail(BuildContext context, VisitorApproval visitor) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _VisitorDetailSheet(visitor: visitor),
    );
  }
}

class _VisitorCard extends StatelessWidget {
  final VisitorApproval visitor;
  final bool showResident;
  final VoidCallback onTap;

  const _VisitorCard({
    required this.visitor,
    this.showResident = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(visitor.residentId),
      builder: (context, snapshot) {
        final resident = snapshot.data;
        return _buildCard(context, theme, resident);
      },
    );
  }

  Widget _buildCard(BuildContext context, ThemeData theme, User? resident) {
    return AppCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getVisitorTypeColor(visitor.visitorType).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _getVisitorTypeColor(visitor.visitorType).withValues(alpha: 0.3),
                  ),
                ),
                child: Text(
                  '${visitor.visitorType.emoji} ${visitor.visitorType.displayName}',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: _getVisitorTypeColor(visitor.visitorType),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const Spacer(),
              StatusBadge(
                label: _getStatusDisplayName(visitor.status),
                color: _getStatusColor(visitor.status),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            visitor.visitorName,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          if (visitor.company != null) ...[
            const SizedBox(height: 4),
            Text(
              visitor.company!,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              if (showResident) ...[
                Icon(AppIcons.home, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
                const SizedBox(width: 4),
                Text(
                  '${resident?.name ?? 'Unknown'} • Flat ${visitor.flatNumber}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
              ] else ...[
                Icon(AppIcons.home, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
                const SizedBox(width: 4),
                Text(
                  'Flat ${visitor.flatNumber}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
              ],
              const Spacer(),
              Icon(AppIcons.calendar, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              const SizedBox(width: 4),
              Text(
                DateFormat('MMM dd, h:mm a').format(visitor.expectedArrival),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
          if (visitor.vehicleNumber != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.directions_car, size: 16, color: theme.colorScheme.primary),
                const SizedBox(width: 4),
                Text(
                  visitor.vehicleNumber!,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Color _getVisitorTypeColor(VisitorType type) {
    switch (type) {
      case VisitorType.guest:
        return Colors.blue;
      case VisitorType.delivery:
        return Colors.orange;
      case VisitorType.cab:
        return Colors.green;
      case VisitorType.other:
        return Colors.purple;
    }
  }

  String _getStatusDisplayName(VisitorStatus status) {
    switch (status) {
      case VisitorStatus.expected:
        return 'Expected';
      case VisitorStatus.arrived:
        return 'Arrived';
      case VisitorStatus.departed:
        return 'Departed';
    }
  }

  Color _getStatusColor(VisitorStatus status) {
    switch (status) {
      case VisitorStatus.expected:
        return AppColors.info;
      case VisitorStatus.arrived:
        return AppColors.success;
      case VisitorStatus.departed:
        return Colors.grey;
    }
  }
}

class _VisitorDetailSheet extends StatelessWidget {
  final VisitorApproval visitor;

  const _VisitorDetailSheet({required this.visitor});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(visitor.residentId),
      builder: (context, snapshot) {
        final resident = snapshot.data;
        return _buildDetailSheet(context, theme, resident);
      },
    );
  }

  Widget _buildDetailSheet(BuildContext context, ThemeData theme, User? resident) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(AppIcons.close),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Column(
                          children: [
                            Container(
                              width: 200,
                              height: 200,
                              decoration: BoxDecoration(
                                color: theme.colorScheme.surface,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: theme.colorScheme.outline.withValues(alpha: 0.3),
                                ),
                              ),
                              child: QrImageView(
                                data: visitor.entryCode,
                                version: QrVersions.auto,
                                size: 180,
                                backgroundColor: theme.colorScheme.surface,
                                foregroundColor: theme.colorScheme.onSurface,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                'Entry Code: ${visitor.entryCode}',
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'monospace',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 32),
                      _buildInfoSection(context, 'Visitor Details', [
                        _InfoRow(
                          icon: Icons.person,
                          label: 'Name',
                          value: visitor.visitorName,
                        ),
                        _InfoRow(
                          icon: Icons.category,
                          label: 'Type',
                          value: '${visitor.visitorType.emoji} ${visitor.visitorType.displayName}',
                        ),
                        if (visitor.company != null)
                          _InfoRow(
                            icon: Icons.business,
                            label: 'Company',
                            value: visitor.company!,
                          ),
                        if (visitor.vehicleNumber != null)
                          _InfoRow(
                            icon: Icons.directions_car,
                            label: 'Vehicle',
                            value: visitor.vehicleNumber!,
                          ),
                      ]),
                      const SizedBox(height: 24),
                      _buildInfoSection(context, 'Visit Details', [
                        _InfoRow(
                          icon: AppIcons.home,
                          label: 'Flat',
                          value: visitor.flatNumber,
                        ),
                        _InfoRow(
                          icon: AppIcons.person,
                          label: 'Host',
                          value: resident?.name ?? 'Unknown',
                        ),
                        _InfoRow(
                          icon: AppIcons.calendar,
                          label: 'Expected Arrival',
                          value: DateFormat('MMM dd, yyyy • h:mm a').format(visitor.expectedArrival),
                        ),
                        _InfoRow(
                          icon: Icons.info,
                          label: 'Status',
                          value: _getStatusDisplayName(visitor.status),
                        ),
                      ]),
                      const SizedBox(height: 32),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(AppIcons.info, color: theme.colorScheme.primary),
                                const SizedBox(width: 8),
                                Text(
                                  'Instructions for Security',
                                  style: theme.textTheme.titleSmall?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: theme.colorScheme.primary,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '• Scan the QR code or enter the entry code\n'
                              '• Verify visitor identity if required\n'
                              '• Contact host if visitor seems unexpected\n'
                              '• Log entry time upon arrival',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInfoSection(BuildContext context, String title, List<_InfoRow> rows) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: rows.map((row) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Icon(row.icon, size: 20, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
                  const SizedBox(width: 12),
                  Text(
                    row.label,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    row.value,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            )).toList(),
          ),
        ),
      ],
    );
  }

  String _getStatusDisplayName(VisitorStatus status) {
    switch (status) {
      case VisitorStatus.expected:
        return 'Expected';
      case VisitorStatus.arrived:
        return 'Arrived';
      case VisitorStatus.departed:
        return 'Departed';
    }
  }
}

class _InfoRow {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });
}

class _PreApproveTab extends StatefulWidget {
  final VoidCallback onVisitorAdded;

  const _PreApproveTab({required this.onVisitorAdded});

  @override
  State<_PreApproveTab> createState() => _PreApproveTabState();
}

class _PreApproveTabState extends State<_PreApproveTab> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _companyController = TextEditingController();
  final _vehicleController = TextEditingController();
  VisitorType _selectedType = VisitorType.guest;
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(
              title: 'Pre-approve Visitor',
              subtitle: 'Generate entry code for expected visitors',
            ),
            const SizedBox(height: 16),
            Text(
              'Visitor Type',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: VisitorType.values.map((type) => CategoryChip(
                    label: type.displayName,
                    emoji: type.emoji,
                    isSelected: _selectedType == type,
                    onTap: () => setState(() => _selectedType = type),
                  )).toList(),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Visitor Name *',
                hintText: 'Enter visitor\'s full name',
                border: OutlineInputBorder(),
                prefixIcon: Icon(AppIcons.person),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Visitor name is required';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            if (_selectedType == VisitorType.delivery || _selectedType == VisitorType.cab)
              Column(
                children: [
                  TextFormField(
                    controller: _companyController,
                    decoration: InputDecoration(
                      labelText: _selectedType == VisitorType.delivery
                          ? 'Delivery Company'
                          : 'Cab Company',
                      hintText: _selectedType == VisitorType.delivery
                          ? 'e.g., Amazon, Swiggy'
                          : 'e.g., Ola, Uber',
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.business),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            if (_selectedType == VisitorType.cab || _selectedType == VisitorType.guest)
              Column(
                children: [
                  TextFormField(
                    controller: _vehicleController,
                    decoration: const InputDecoration(
                      labelText: 'Vehicle Number',
                      hintText: 'e.g., KA01AB1234',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.directions_car),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            Row(
              children: [
                Expanded(
                  child: ListTile(
                    leading: Icon(AppIcons.calendar, color: theme.colorScheme.primary),
                    title: const Text('Date'),
                    subtitle: Text(DateFormat('MMM dd, yyyy').format(_selectedDate)),
                    onTap: _selectDate,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
                Expanded(
                  child: ListTile(
                    leading: Icon(AppIcons.clock, color: theme.colorScheme.primary),
                    title: const Text('Time'),
                    subtitle: Text(_selectedTime.format(context)),
                    onTap: _selectTime,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _preApproveVisitor,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppConstants.buttonBorderRadius),
                  ),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator()
                    : Text(
                        'Generate Entry Code',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.onPrimary,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(AppIcons.info, color: theme.colorScheme.primary),
                      const SizedBox(width: 8),
                      Text(
                        'How it works',
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '• Generate a unique entry code for your visitor\n'
                    '• Share the code or QR code with your visitor\n'
                    '• Security can verify and grant entry using the code\n'
                    '• You\'ll be notified when your visitor arrives',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate() async {
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );

    if (selectedDate != null) {
      setState(() => _selectedDate = selectedDate);
    }
  }

  Future<void> _selectTime() async {
    final selectedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );

    if (selectedTime != null) {
      setState(() => _selectedTime = selectedTime);
    }
  }

  String _generateEntryCode() {
    final random = Random();
    return (1000 + random.nextInt(9000)).toString();
  }

  Future<void> _preApproveVisitor() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final currentUser = AuthService.instance.currentUser;
      if (currentUser == null) return;

      final expectedArrival = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );

      final visitor = VisitorApproval(
        id: 'visitor_${DateTime.now().millisecondsSinceEpoch}',
        residentId: currentUser.id,
        flatNumber: currentUser.flatNumber,
        visitorName: _nameController.text.trim(),
        visitorType: _selectedType,
        expectedArrival: expectedArrival,
        entryCode: _generateEntryCode(),
        company: _companyController.text.trim().isNotEmpty ? _companyController.text.trim() : null,
        vehicleNumber: _vehicleController.text.trim().isNotEmpty ? _vehicleController.text.trim() : null,
      );

      await StorageService.instance.addVisitorApproval(visitor);

      if (mounted) {
        widget.onVisitorAdded();
        
        // Clear form
        _nameController.clear();
        _companyController.clear();
        _vehicleController.clear();
        setState(() {
          _selectedType = VisitorType.guest;
          _selectedDate = DateTime.now();
          _selectedTime = TimeOfDay.now();
        });

        // Show success dialog with QR code
        _showSuccessDialog(context, visitor);
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSuccessDialog(BuildContext context, VisitorApproval visitor) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(AppIcons.success, color: AppColors.success),
            const SizedBox(width: 8),
            const Text('Visitor Pre-approved'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Entry code generated for ${visitor.visitorName}'),
            const SizedBox(height: 16),
            // Show QR code and entry code
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: QrImageView(
                data: visitor.entryCode,
                version: QrVersions.auto,
                size: 140,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Entry Code: ${visitor.entryCode}',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Done'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showVisitorDetail(context, visitor);
            },
            child: const Text('View Details'),
          ),
        ],
      ),
    );
  }

  void _showVisitorDetail(BuildContext context, VisitorApproval visitor) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _VisitorDetailSheet(visitor: visitor),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _companyController.dispose();
    _vehicleController.dispose();
    super.dispose();
  }
}

class _EmergencyTab extends StatefulWidget {
  const _EmergencyTab();

  @override
  State<_EmergencyTab> createState() => _EmergencyTabState();
}

class _EmergencyTabState extends State<_EmergencyTab> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
    _pulseController.repeat(reverse: true);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final panicAlerts = StorageService.instance.panicAlerts;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Column(
        children: [
          const SectionHeader(
            title: 'Emergency Alert',
            subtitle: 'Use only in case of genuine emergency',
          ),
          const SizedBox(height: 32),
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: GestureDetector(
                  onLongPressStart: (_) => setState(() => _isPressed = true),
                  onLongPressEnd: (_) {
                    setState(() => _isPressed = false);
                    _sendPanicAlert();
                  },
                  onLongPressCancel: () => setState(() => _isPressed = false),
                  child: Container(
                    width: 200,
                    height: 200,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isPressed
                          ? AppColors.emergency.withValues(alpha: 0.8)
                          : AppColors.emergency,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.emergency.withValues(alpha: 0.3),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          AppIcons.emergency,
                          size: 64,
                          color: Colors.white,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          AppTexts.panicButton,
                          style: theme.textTheme.headlineSmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Hold for 3s',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.white.withValues(alpha: 0.8),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.emergencyBackground,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppColors.emergency.withValues(alpha: 0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(AppIcons.warning, color: AppColors.emergency),
                    const SizedBox(width: 8),
                    Text(
                      'Important Instructions',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.emergency,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  '• Hold the button for 3 seconds to activate\n'
                  '• Security and management will be notified immediately\n'
                  '• Use only for genuine emergencies\n'
                  '• False alarms may result in penalties',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: AppColors.emergency,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Emergency Contacts',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                _ContactTile(
                  icon: AppIcons.phone,
                  title: 'Emergency Services',
                  subtitle: AppConstants.emergencyContactNumber,
                ),
                _ContactTile(
                  icon: AppIcons.security,
                  title: 'Security Office',
                  subtitle: '+1 (555) 999-0000',
                ),
                _ContactTile(
                  icon: AppIcons.email,
                  title: 'Management',
                  subtitle: AppConstants.managementEmail,
                ),
              ],
            ),
          ),
          if (panicAlerts.isNotEmpty) ...[
            const SizedBox(height: 24),
            SectionHeader(
              title: 'Recent Alerts',
              subtitle: '${panicAlerts.length} alert${panicAlerts.length > 1 ? 's' : ''} sent',
            ),
            const SizedBox(height: 8),
            ...panicAlerts.take(3).map((alert) => _AlertHistoryCard(alert: alert)),
          ],
        ],
      ),
    );
  }

  Future<void> _sendPanicAlert() async {
    final currentUser = AuthService.instance.currentUser;
    if (currentUser == null) return;

    final alert = PanicAlert(
      id: 'alert_${DateTime.now().millisecondsSinceEpoch}',
      residentId: currentUser.id,
      flatNumber: currentUser.flatNumber,
      timestamp: DateTime.now(),
    );

    await StorageService.instance.addPanicAlert(alert);

    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(AppIcons.success, color: Colors.white),
              const SizedBox(width: 8),
              const Text(AppTexts.panicAlertSent),
            ],
          ),
          backgroundColor: AppColors.success,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }
}

class _ContactTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _ContactTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return ListTile(
      leading: Icon(icon, color: theme.colorScheme.primary),
      title: Text(title),
      subtitle: Text(subtitle),
      contentPadding: EdgeInsets.zero,
      dense: true,
    );
  }
}

class _AlertHistoryCard extends StatelessWidget {
  final PanicAlert alert;

  const _AlertHistoryCard({required this.alert});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(alert.residentId),
      builder: (context, snapshot) {
        final resident = snapshot.data;
        return _buildCard(context, theme, resident);
      },
    );
  }

  Widget _buildCard(BuildContext context, ThemeData theme, User? resident) {
    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Icon(
            AppIcons.emergency,
            color: AppColors.emergency,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Alert from ${resident?.name ?? 'Unknown'} • Flat ${alert.flatNumber}',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  DateFormat('MMM dd, h:mm a').format(alert.timestamp),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
          ),
          StatusBadge(
            label: alert.acknowledged ? 'Acknowledged' : 'Pending',
            color: alert.acknowledged ? AppColors.success : AppColors.warning,
          ),
        ],
      ),
    );
  }
}