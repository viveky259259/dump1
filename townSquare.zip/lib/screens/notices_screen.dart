import 'package:flutter/material.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';
import 'package:townsquare/services/storage_service.dart';
import 'package:townsquare/widgets/common_widgets.dart';
import 'package:townsquare/utils/constants.dart';
import 'package:intl/intl.dart';

class NoticesScreen extends StatefulWidget {
  const NoticesScreen({super.key});

  @override
  State<NoticesScreen> createState() => _NoticesScreenState();
}

class _NoticesScreenState extends State<NoticesScreen> {
  NoticeCategory? _selectedCategory;
  bool _showPinnedOnly = false;

  @override
  Widget build(BuildContext context) {
    final currentUser = AuthService.instance.currentUser;
    final canCreateNotices = AuthService.instance.isAdmin;

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppTexts.noticeBoard),
        actions: [
          IconButton(
            icon: Icon(_showPinnedOnly ? Icons.push_pin : Icons.push_pin_outlined),
            onPressed: () => setState(() => _showPinnedOnly = !_showPinnedOnly),
            tooltip: _showPinnedOnly ? 'Show All' : 'Show Pinned Only',
          ),
          const UserSwitcher(),
        ],
      ),
      body: Column(
        children: [
          _buildCategoryFilter(),
          Expanded(child: _buildNoticesList()),
        ],
      ),
      floatingActionButton: canCreateNotices
          ? FloatingActionButton(
              onPressed: () => _showCreateNoticeDialog(context),
              child: const Icon(AppIcons.add),
            )
          : null,
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            CategoryChip(
              label: 'All',
              emoji: '📋',
              isSelected: _selectedCategory == null,
              onTap: () => setState(() => _selectedCategory = null),
            ),
            const SizedBox(width: 8),
            ...NoticeCategory.values.map((category) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: CategoryChip(
                    label: category.displayName,
                    emoji: category.emoji,
                    isSelected: _selectedCategory == category,
                    onTap: () => setState(() => _selectedCategory = category),
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildNoticesList() {
    List<Notice> notices = _showPinnedOnly
        ? StorageService.instance.getPinnedNotices()
        : StorageService.instance.getActiveNotices();

    if (_selectedCategory != null) {
      notices = notices.where((notice) => notice.category == _selectedCategory).toList();
    }

    if (notices.isEmpty) {
      return EmptyState(
        icon: AppIcons.notices,
        title: _showPinnedOnly ? 'No Pinned Notices' : 'No Notices Available',
        subtitle: _showPinnedOnly
            ? 'Pinned notices will appear here'
            : 'New notices will appear here when published',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      itemCount: notices.length,
      itemBuilder: (context, index) {
        final notice = notices[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: _NoticeCard(
            notice: notice,
            onTap: () => _showNoticeDetail(context, notice),
          ),
        );
      },
    );
  }

  void _showNoticeDetail(BuildContext context, Notice notice) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _NoticeDetailSheet(notice: notice),
    );
  }

  void _showCreateNoticeDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _CreateNoticeSheet(
        onNoticeCreated: () => setState(() {}),
      ),
    );
  }
}

class _NoticeCard extends StatelessWidget {
  final Notice notice;
  final VoidCallback onTap;

  const _NoticeCard({
    required this.notice,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isExpiringSoon = notice.expiryDate != null &&
        notice.expiryDate!.difference(DateTime.now()).inDays <= 1;
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(notice.authorId),
      builder: (context, snapshot) {
        final author = snapshot.data;
        return _buildCard(context, theme, author, isExpiringSoon);
      },
    );
  }

  Widget _buildCard(BuildContext context, ThemeData theme, User? author, bool isExpiringSoon) {
    return AppCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CategoryChip(
                label: notice.category.displayName,
                emoji: notice.category.emoji,
                isSelected: true,
              ),
              const Spacer(),
              if (notice.isPinned)
                Icon(AppIcons.pin, size: 16, color: theme.colorScheme.primary),
              if (isExpiringSoon) ...[
                const SizedBox(width: 8),
                Icon(AppIcons.warning, size: 16, color: AppColors.warning),
              ],
            ],
          ),
          const SizedBox(height: 12),
          Text(
            notice.title,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            notice.content,
            style: theme.textTheme.bodyMedium,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Icon(AppIcons.person, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              const SizedBox(width: 4),
              Text(
                author?.name ?? 'Unknown',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
              const Spacer(),
              Icon(AppIcons.calendar, size: 16, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
              const SizedBox(width: 4),
              Text(
                DateFormat('MMM dd, yyyy').format(notice.publishDate),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
          if (notice.attachments.isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(AppIcons.attachment, size: 16, color: theme.colorScheme.primary),
                const SizedBox(width: 4),
                Text(
                  '${notice.attachments.length} attachment${notice.attachments.length > 1 ? 's' : ''}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _NoticeDetailSheet extends StatelessWidget {
  final Notice notice;

  const _NoticeDetailSheet({required this.notice});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return FutureBuilder<User?>(
      future: AuthService.instance.getUserById(notice.authorId),
      builder: (context, snapshot) {
        final author = snapshot.data;
        return _buildDetailSheet(context, theme, author);
      },
    );
  }

  Widget _buildDetailSheet(BuildContext context, ThemeData theme, User? author) {
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(AppIcons.close),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CategoryChip(
                            label: notice.category.displayName,
                            emoji: notice.category.emoji,
                            isSelected: true,
                          ),
                          const Spacer(),
                          if (notice.isPinned)
                            StatusBadge(
                              label: 'Pinned',
                              color: theme.colorScheme.primary,
                              icon: AppIcons.pin,
                            ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        notice.title,
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: theme.colorScheme.primary,
                              radius: 20,
                              child: Text(
                                author?.name.substring(0, 1).toUpperCase() ?? 'A',
                                style: TextStyle(
                                  color: theme.colorScheme.onPrimary,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    author?.name ?? 'Unknown Author',
                                    style: theme.textTheme.titleSmall?.copyWith(
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  Text(
                                    DateFormat('MMM dd, yyyy • h:mm a').format(notice.publishDate),
                                    style: theme.textTheme.bodySmall?.copyWith(
                                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        notice.content,
                        style: theme.textTheme.bodyLarge?.copyWith(
                          height: 1.6,
                        ),
                      ),
                      if (notice.expiryDate != null) ...[
                        const SizedBox(height: 24),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppColors.warning.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppColors.warning.withValues(alpha: 0.3),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(AppIcons.clock, color: AppColors.warning),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'Expires on ${DateFormat('MMM dd, yyyy').format(notice.expiryDate!)}',
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: AppColors.warning,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      if (notice.attachments.isNotEmpty) ...[
                        const SizedBox(height: 24),
                        Text(
                          'Attachments',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        ...notice.attachments.map((attachment) => ListTile(
                              leading: Icon(AppIcons.attachment, color: theme.colorScheme.primary),
                              title: Text(attachment),
                              trailing: Icon(AppIcons.info, color: theme.colorScheme.onSurface.withValues(alpha: 0.6)),
                              contentPadding: EdgeInsets.zero,
                            )),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _CreateNoticeSheet extends StatefulWidget {
  final VoidCallback onNoticeCreated;

  const _CreateNoticeSheet({required this.onNoticeCreated});

  @override
  State<_CreateNoticeSheet> createState() => _CreateNoticeSheetState();
}

class _CreateNoticeSheetState extends State<_CreateNoticeSheet> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  NoticeCategory _selectedCategory = NoticeCategory.general;
  bool _isPinned = false;
  DateTime? _expiryDate;
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  const Spacer(),
                  Text(
                    'Create Notice',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _createNotice,
                    child: _isLoading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Publish'),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextFormField(
                      controller: _titleController,
                      decoration: const InputDecoration(
                        labelText: 'Notice Title *',
                        hintText: 'Enter a clear, descriptive title',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Title is required';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _contentController,
                      maxLines: 6,
                      decoration: const InputDecoration(
                        labelText: 'Notice Content *',
                        hintText: 'Enter the full notice content',
                        border: OutlineInputBorder(),
                        alignLabelWithHint: true,
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Content is required';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Category',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: NoticeCategory.values.map((category) => CategoryChip(
                            label: category.displayName,
                            emoji: category.emoji,
                            isSelected: _selectedCategory == category,
                            onTap: () => setState(() => _selectedCategory = category),
                          )).toList(),
                    ),
                    const SizedBox(height: 24),
                    SwitchListTile(
                      title: const Text('Pin to Top'),
                      subtitle: const Text('Make this notice appear at the top'),
                      value: _isPinned,
                      onChanged: (value) => setState(() => _isPinned = value),
                      contentPadding: EdgeInsets.zero,
                    ),
                    const SizedBox(height: 16),
                    ListTile(
                      leading: Icon(AppIcons.calendar, color: theme.colorScheme.primary),
                      title: const Text('Expiry Date'),
                      subtitle: Text(_expiryDate != null
                          ? DateFormat('MMM dd, yyyy').format(_expiryDate!)
                          : 'No expiry date set'),
                      trailing: TextButton(
                        onPressed: _selectExpiryDate,
                        child: Text(_expiryDate != null ? 'Change' : 'Set Date'),
                      ),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectExpiryDate() async {
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: _expiryDate ?? DateTime.now().add(const Duration(days: 7)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (selectedDate != null) {
      setState(() => _expiryDate = selectedDate);
    }
  }

  Future<void> _createNotice() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final currentUser = AuthService.instance.currentUser;
      if (currentUser == null) return;

      final notice = Notice(
        id: 'notice_${DateTime.now().millisecondsSinceEpoch}',
        title: _titleController.text.trim(),
        content: _contentController.text.trim(),
        category: _selectedCategory,
        authorId: currentUser.id,
        publishDate: DateTime.now(),
        expiryDate: _expiryDate,
        isPinned: _isPinned,
      );

      await StorageService.instance.addNotice(notice);
      
      if (mounted) {
        Navigator.pop(context);
        widget.onNoticeCreated();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Notice published successfully'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }
}