import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:townsquare/services/ssl_pinning_service.dart';
import 'package:townsquare/utils/ssl_pinning_utils.dart';
import 'package:townsquare/config/ssl_config.dart';

/// Debug screen for SSL pinning configuration and testing
/// Only shown in debug builds
class SSLDebugScreen extends StatefulWidget {
  const SSLDebugScreen({super.key});

  @override
  State<SSLDebugScreen> createState() => _SSLDebugScreenState();
}

class _SSLDebugScreenState extends State<SSLDebugScreen> {
  Map<String, bool> _testResults = {};
  bool _isLoading = false;
  String _logs = '';
  final TextEditingController _urlController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadCurrentConfig();
  }

  void _loadCurrentConfig() {
    final config = SSLPinningService.getCurrentConfiguration();
    final platform = kIsWeb ? 'Web' : 'Mobile';
    final sslMethod = kIsWeb ? 'HTTPS Enforcement + Browser Validation' : 'Certificate Fingerprint Pinning';
    
    setState(() {
      _logs = 'Current SSL Configuration:\n'
          'Platform: $platform\n'
          'Method: $sslMethod\n'
          'Enabled: ${config.enablePinning}\n'
          'Strict Mode: ${config.strictMode}\n'
          'Timeout: ${config.timeoutSeconds}s\n'
          'Log Level: ${config.logLevel.name}\n\n';
    });
  }

  Future<void> _runTests() async {
    setState(() {
      _isLoading = true;
      _logs += 'Running SSL pinning tests...\n\n';
    });

    try {
      final results = await SSLPinningService.testConfiguration();
      setState(() {
        _testResults = results;
        _logs += 'Test Results:\n';
        results.forEach((key, value) {
          _logs += '$key: ${value ? 'PASS ✅' : 'FAIL ❌'}\n';
        });
        _logs += '\n';
      });
    } catch (e) {
      setState(() {
        _logs += 'Test failed: $e\n\n';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _testCustomUrl() async {
    if (_urlController.text.isEmpty) return;

    setState(() {
      _isLoading = true;
      _logs += 'Testing custom URL: ${_urlController.text}\n';
    });

    try {
      final isSecure = await SSLPinningService.checkSSLPinning(_urlController.text);
      setState(() {
        _logs += 'Result: ${isSecure ? 'SECURE ✅' : 'FAILED ❌'}\n\n';
      });
    } catch (e) {
      setState(() {
        _logs += 'Error: $e\n\n';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _getCertificateInfo() async {
    if (_urlController.text.isEmpty) return;

    setState(() {
      _isLoading = true;
      _logs += 'Getting certificate info for: ${_urlController.text}\n';
    });

    try {
      final domain = _urlController.text.replaceAll(RegExp(r'https?://'), '').split('/')[0];
      final results = await SSLPinningUtils.extractCertificateFingerprints(domain);
      
      setState(() {
        _logs += 'Certificate Info:\n';
        results.forEach((key, value) {
          _logs += '$key: ${value ?? 'N/A'}\n';
        });
        _logs += '\n';
      });
    } catch (e) {
      setState(() {
        _logs += 'Error getting certificate info: $e\n\n';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _clearLogs() {
    setState(() {
      _logs = '';
      _testResults.clear();
    });
  }

  void _copyLogsToClipboard() {
    Clipboard.setData(ClipboardData(text: _logs));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Logs copied to clipboard')),
    );
  }

  void _showInstructions() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('SSL Pinning Setup'),
        content: const SingleChildScrollView(
          child: Text(
            SSLSetupInstructions.instructions,
            style: TextStyle(fontSize: 12, fontFamily: 'monospace'),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SSL Pinning Debug'),
        actions: [
          IconButton(
            icon: const Icon(Icons.help),
            onPressed: _showInstructions,
          ),
          IconButton(
            icon: const Icon(Icons.copy),
            onPressed: _copyLogsToClipboard,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Configuration Info Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Current Configuration',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Builder(
                      builder: (context) {
                        final config = SSLPinningService.getCurrentConfiguration();
                        final platform = kIsWeb ? 'Web' : 'Mobile';
                        final sslMethod = kIsWeb ? 'HTTPS + Browser' : 'Certificate Pinning';
                        
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Platform: $platform'),
                            Text('Method: $sslMethod'),
                            Text('Enabled: ${config.enablePinning}'),
                            Text('Strict Mode: ${config.strictMode}'),
                            Text('Timeout: ${config.timeoutSeconds}s'),
                            Text('Log Level: ${config.logLevel.name}'),
                          ].map((text) => 
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 2),
                              child: text,
                            )
                          ).toList(),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Test Controls
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _runTests,
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Run Tests'),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: _clearLogs,
                  icon: const Icon(Icons.clear),
                  label: const Text('Clear'),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Custom URL Testing
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _urlController,
                    decoration: const InputDecoration(
                      labelText: 'Test Custom URL',
                      hintText: 'https://example.com',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  children: [
                    ElevatedButton(
                      onPressed: _isLoading ? null : _testCustomUrl,
                      child: const Text('Test'),
                    ),
                    const SizedBox(height: 4),
                    ElevatedButton(
                      onPressed: (_isLoading || kIsWeb) ? null : _getCertificateInfo,
                      child: Text(kIsWeb ? 'Info*' : 'Info'),
                    ),
                  ],
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Test Results
            if (_testResults.isNotEmpty) ...[
              Text(
                'Test Results',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: _testResults.entries.map((entry) {
                      return ListTile(
                        dense: true,
                        title: Text(entry.key),
                        trailing: Icon(
                          entry.value ? Icons.check_circle : Icons.error,
                          color: entry.value ? Colors.green : Colors.red,
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
            
            // Logs
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Logs',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(12.0),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(8.0),
                        color: Colors.grey.shade50,
                      ),
                      child: SingleChildScrollView(
                        child: Text(
                          _logs.isEmpty ? 'No logs yet...' : _logs,
                          style: const TextStyle(
                            fontSize: 12,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8.0),
                child: LinearProgressIndicator(),
              ),
            
            if (kIsWeb)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Card(
                  color: Colors.orange.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      children: [
                        Icon(Icons.info, color: Colors.orange.shade700, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Web Platform: Certificate info (*) not available. SSL validation relies on browser security.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.orange.shade700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}