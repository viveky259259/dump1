import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/blocs/auth/auth_bloc.dart';
import 'package:townsquare/blocs/auth/auth_state.dart';
import 'package:townsquare/services/auth_service.dart';
import 'package:townsquare/services/storage_service.dart';
import 'package:townsquare/widgets/common_widgets.dart';
import 'package:townsquare/utils/constants.dart';
import 'package:townsquare/screens/notices_screen.dart';
import 'package:townsquare/screens/tickets_screen.dart';
import 'package:townsquare/screens/security_screen.dart';
import 'package:townsquare/screens/ssl_debug_screen.dart';
import 'package:townsquare/screens/invoices_screen.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  bool _isLoading = true;

  final List<Widget> _screens = [
    const HomeContent(),
    const NoticesScreen(),
    const TicketsScreen(),
    const InvoicesScreen(),
    const SecurityScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _initializeServices();
  }

  Future<void> _initializeServices() async {
    try {
      await StorageService.instance.initialize();
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(AppIcons.home),
            label: AppTexts.homeTab,
          ),
          NavigationDestination(
            icon: Icon(AppIcons.notices),
            label: AppTexts.noticesTab,
          ),
          NavigationDestination(
            icon: Icon(AppIcons.tickets),
            label: AppTexts.ticketsTab,
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            label: 'Invoices',
          ),
          NavigationDestination(
            icon: Icon(AppIcons.security),
            label: AppTexts.securityTab,
          ),
        ],
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, state) {
        final currentUser = state is AuthAuthenticated ? state.user : null;
    
        return Scaffold(
          appBar: AppBar(
            title: Text(AppConstants.appName),
            actions: [
              // Show SSL debug menu only in debug mode
              if (kDebugMode)
                PopupMenuButton<String>(
                  icon: const Icon(Icons.bug_report),
                  onSelected: (value) {
                    if (value == 'ssl_debug') {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SSLDebugScreen(),
                        ),
                      );
                    }
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'ssl_debug',
                      child: ListTile(
                        leading: Icon(Icons.security),
                        title: Text('SSL Debug'),
                        subtitle: Text('Test SSL pinning'),
                      ),
                    ),
                  ],
                ),
              const UserSwitcher(),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(AppConstants.defaultPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildWelcomeCard(context, currentUser),
                const SizedBox(height: 24),
                _buildQuickActions(context, currentUser),
                const SizedBox(height: 24),
                _buildRecentActivity(context),
                const SizedBox(height: 24),
                _buildEmergencySection(context),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildWelcomeCard(BuildContext context, User? user) {
    final theme = Theme.of(context);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                child: Text(
                  user?.name.substring(0, 1).toUpperCase() ?? 'U',
                  style: TextStyle(
                    color: theme.colorScheme.onPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome back!',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                    Text(
                      user?.name ?? 'User',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              RoleIndicator(role: user?.role ?? UserRole.resident),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  AppIcons.home,
                  color: theme.colorScheme.primary,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Flat ${user?.flatNumber ?? 'N/A'}',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                Text(
                  DateFormat('MMM dd, yyyy').format(DateTime.now()),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context, User? currentUser) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppTexts.quickActions,
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1.3,
          children: [
            _QuickActionCard(
              icon: AppIcons.notices,
              title: 'Latest Notices',
              subtitle: '${StorageService.instance.getActiveNotices().length} active',
              color: theme.colorScheme.primary,
              onTap: () => _navigateToTab(context, 1),
            ),
            _QuickActionCard(
              icon: AppIcons.tickets,
              title: 'My Tickets',
              subtitle: currentUser != null
                  ? '${StorageService.instance.getTicketsForResident(currentUser.id).length} tickets'
                  : '0 tickets',
              color: theme.colorScheme.tertiary,
              onTap: () => _navigateToTab(context, 2),
            ),
            _QuickActionCard(
              icon: Icons.receipt_long_outlined,
              title: 'Maintenance Invoices',
              subtitle: 'View & pay invoices',
              color: Colors.green,
              onTap: () => _navigateToTab(context, 3),
            ),
            _QuickActionCard(
              icon: AppIcons.security,
              title: 'Visitor Management',
              subtitle: currentUser != null
                  ? '${StorageService.instance.getVisitorApprovalsForResident(currentUser.id).length} approved'
                  : '0 approved',
              color: theme.colorScheme.secondary,
              onTap: () => _navigateToTab(context, 4),
            ),
            if (AuthService.instance.isAdmin)
              _QuickActionCard(
                icon: AppIcons.add,
                title: 'Create Notice',
                subtitle: 'Admin action',
                color: theme.colorScheme.error,
                onTap: () => _navigateToTab(context, 1),
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildRecentActivity(BuildContext context) {
    final theme = Theme.of(context);
    final recentNotices = StorageService.instance.getActiveNotices().take(3).toList();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Notices',
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        if (recentNotices.isEmpty)
          const EmptyState(
            icon: AppIcons.notices,
            title: 'No Recent Notices',
            subtitle: 'New notices will appear here',
          )
        else
          ...recentNotices.map((notice) => _NoticePreviewCard(notice: notice)),
      ],
    );
  }

  Widget _buildEmergencySection(BuildContext context) {
    final theme = Theme.of(context);
    
    return AppCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Icon(
            AppIcons.emergency,
            size: 48,
            color: AppColors.emergency,
          ),
          const SizedBox(height: 16),
          Text(
            'Emergency Alert',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.emergency,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            AppTexts.emergencyHelpText,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _showEmergencyDialog(context),
              icon: Icon(AppIcons.emergency, color: Colors.white),
              label: Text(
                AppTexts.panicButton,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.emergency,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppConstants.buttonBorderRadius),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToTab(BuildContext context, int index) {
    final homeState = context.findAncestorStateOfType<_HomeScreenState>();
    homeState?.setState(() => homeState._currentIndex = index);
  }

  void _showEmergencyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        icon: Icon(AppIcons.warning, color: AppColors.warning, size: 48),
        title: const Text('Emergency Alert'),
        content: const Text(
          'This will immediately notify security and management. Only use in case of genuine emergency.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _sendEmergencyAlert(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.emergency),
            child: Text('Send Alert', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _sendEmergencyAlert(BuildContext context) async {
    final authState = context.read<AuthBloc>().state;
    if (authState is! AuthAuthenticated) return;
    
    final currentUser = authState.user;

    final alert = PanicAlert(
      id: 'alert_${DateTime.now().millisecondsSinceEpoch}',
      residentId: currentUser.id,
      flatNumber: currentUser.flatNumber,
      timestamp: DateTime.now(),
    );

    await StorageService.instance.addPanicAlert(alert);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(AppIcons.success, color: Colors.white),
              const SizedBox(width: 8),
              const Text(AppTexts.panicAlertSent),
            ],
          ),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 12),
          Text(
            title,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class _NoticePreviewCard extends StatelessWidget {
  final Notice notice;

  const _NoticePreviewCard({required this.notice});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return AppCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CategoryChip(
                label: notice.category.displayName,
                emoji: notice.category.emoji,
                isSelected: true,
              ),
              const Spacer(),
              if (notice.isPinned)
                Icon(AppIcons.pin, size: 16, color: theme.colorScheme.primary),
              const SizedBox(width: 8),
              Text(
                DateFormat('MMM dd').format(notice.publishDate),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            notice.title,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          Text(
            notice.content,
            style: theme.textTheme.bodyMedium,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}