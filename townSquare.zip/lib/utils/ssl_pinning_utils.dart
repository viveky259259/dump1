import 'dart:convert';
import 'dart:io';
import 'package:http_certificate_pinning/http_certificate_pinning.dart';

class SSLPinningUtils {
  
  /// Helper method to extract certificate fingerprint from a domain
  /// This is useful for getting the actual certificate fingerprints
  /// during development and testing
  static Future<Map<String, String?>> extractCertificateFingerprints(String domain) async {
    final results = <String, String?>{};
    
    try {
      // Try to get certificate info using openssl (if available)
      final result = await Process.run('openssl', [
        's_client',
        '-servername',
        domain,
        '-connect',
        '$domain:443',
        '-showcerts'
      ]);
      
      if (result.exitCode == 0) {
        results['openssl_output'] = result.stdout as String;
      } else {
        results['openssl_error'] = result.stderr as String;
      }
    } catch (e) {
      results['openssl_error'] = 'OpenSSL not available: $e';
    }
    
    // Try to get fingerprint using http_certificate_pinning package
    try {
      final testResult = await HttpCertificatePinning.check(
        serverURL: 'https://$domain',
        headerHttp: {},
        sha: SHA.SHA256,
        allowedSHAFingerprints: [], // Empty to just test connection
        timeout: 10,
      );
      results['pinning_test'] = testResult;
    } catch (e) {
      results['pinning_error'] = e.toString();
    }
    
    return results;
  }
  
  /// Validate SSL pinning configuration for multiple domains
  static Future<Map<String, bool>> validateSSLPinningForDomains(
    List<String> domains,
    List<String> allowedFingerprints,
  ) async {
    final results = <String, bool>{};
    
    for (final domain in domains) {
      try {
        final result = await HttpCertificatePinning.check(
          serverURL: 'https://$domain',
          headerHttp: {},
          sha: SHA.SHA256,
          allowedSHAFingerprints: allowedFingerprints,
          timeout: 30,
        );
        results[domain] = result.contains('CONNECTION_SECURE');
      } catch (e) {
        print('SSL validation failed for $domain: $e');
        results[domain] = false;
      }
    }
    
    return results;
  }
  
  /// Generate SSL pinning configuration for common domains
  static Map<String, List<String>> getCommonSSLFingerprints() {
    return {
      'supabase.co': [
        // These are example fingerprints - replace with actual ones
        '25847d668eb4f04fdd40b12b6b0740c567da7d024308eb6c2c96fe41d9de218d',
      ],
      'googleapis.com': [
        'EB04CF5EB1F39AFA762F2BB120F296CBA520C1B97DB1589565B81CB9A17B7244',
      ],
      'firebase.googleapis.com': [
        '4348A0E9444C78CB265E058D5E8944B4D84F9662BD26DB257F8934A443C70161',
      ],
    };
  }
  
  /// Parse certificate from PEM format
  static List<String> parseCertificatesFromPEM(String pemData) {
    final certificates = <String>[];
    final lines = LineSplitter.split(pemData);
    
    String? currentCert;
    bool inCert = false;
    
    for (final line in lines) {
      if (line.contains('-----BEGIN CERTIFICATE-----')) {
        inCert = true;
        currentCert = '';
        continue;
      }
      
      if (line.contains('-----END CERTIFICATE-----')) {
        if (currentCert != null && currentCert.isNotEmpty) {
          certificates.add(currentCert);
        }
        inCert = false;
        currentCert = null;
        continue;
      }
      
      if (inCert && currentCert != null) {
        currentCert += line.trim();
      }
    }
    
    return certificates;
  }
  
  /// Create a test method to verify SSL pinning is working
  static Future<SSLPinningTestResult> testSSLPinning({
    required String url,
    required List<String> expectedFingerprints,
    int timeoutSeconds = 30,
  }) async {
    try {
      final result = await HttpCertificatePinning.check(
        serverURL: url,
        headerHttp: {'User-Agent': 'TownSquare-Flutter-App'},
        sha: SHA.SHA256,
        allowedSHAFingerprints: expectedFingerprints,
        timeout: timeoutSeconds,
      );
      
      return SSLPinningTestResult(
        success: result.contains('CONNECTION_SECURE'),
        url: url,
        result: result,
        error: null,
      );
    } catch (e) {
      return SSLPinningTestResult(
        success: false,
        url: url,
        result: null,
        error: e.toString(),
      );
    }
  }
}

class SSLPinningTestResult {
  final bool success;
  final String url;
  final String? result;
  final String? error;
  
  const SSLPinningTestResult({
    required this.success,
    required this.url,
    this.result,
    this.error,
  });
  
  @override
  String toString() {
    return 'SSLPinningTestResult(success: $success, url: $url, result: $result, error: $error)';
  }
}