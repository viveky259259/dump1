import 'package:flutter/material.dart';

class AppConstants {
  // App Info
  static const String appName = 'TownSquare';
  static const String appVersion = '1.0.0';

  // Dimensions
  static const double defaultPadding = 16.0;
  static const double cardBorderRadius = 16.0;
  static const double buttonBorderRadius = 12.0;

  // Animation Durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 300);
  static const Duration longAnimation = Duration(milliseconds: 500);

  // Emergency
  static const Duration panicButtonActivationDelay = Duration(seconds: 3);

  // Strings
  static const String emergencyContactNumber = '911';
  static const String managementEmail = 'admin@townsquare.com';
}

class AppIcons {
  static const IconData home = Icons.home_rounded;
  static const IconData notices = Icons.campaign_rounded;
  static const IconData tickets = Icons.support_agent_rounded;
  static const IconData security = Icons.security_rounded;
  static const IconData profile = Icons.account_circle_rounded;
  static const IconData emergency = Icons.emergency_rounded;
  static const IconData add = Icons.add_rounded;
  static const IconData filter = Icons.filter_list_rounded;
  static const IconData search = Icons.search_rounded;
  static const IconData like = Icons.favorite_rounded;
  static const IconData comment = Icons.chat_bubble_rounded;
  static const IconData attachment = Icons.attach_file_rounded;
  static const IconData camera = Icons.camera_alt_rounded;
  static const IconData qrCode = Icons.qr_code_rounded;
  static const IconData pin = Icons.push_pin_rounded;
  static const IconData calendar = Icons.calendar_month_rounded;
  static const IconData clock = Icons.access_time_rounded;
  static const IconData person = Icons.person_rounded;
  static const IconData phone = Icons.phone_rounded;
  static const IconData email = Icons.email_rounded;
  static const IconData location = Icons.location_on_rounded;
  static const IconData settings = Icons.settings_rounded;
  static const IconData logout = Icons.logout_rounded;
  static const IconData check = Icons.check_rounded;
  static const IconData close = Icons.close_rounded;
  static const IconData info = Icons.info_rounded;
  static const IconData warning = Icons.warning_rounded;
  static const IconData error = Icons.error_rounded;
  static const IconData success = Icons.check_circle_rounded;
}

class AppColors {
  // Status Colors
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFF9800);
  static const Color error = Color(0xFFF44336);
  static const Color info = Color(0xFF2196F3);

  // Ticket Status Colors
  static const Color ticketOpen = Color(0xFFE3F2FD);
  static const Color ticketInProgress = Color(0xFFFFF3E0);
  static const Color ticketResolved = Color(0xFFE8F5E8);
  static const Color ticketClosed = Color(0xFFF5F5F5);

  // Emergency
  static const Color emergency = Color(0xFFD32F2F);
  static const Color emergencyBackground = Color(0xFFFFEBEE);
}

class AppTexts {
  // Navigation
  static const String homeTab = 'Home';
  static const String noticesTab = 'Notices';
  static const String ticketsTab = 'Tickets';
  static const String securityTab = 'Security';

  // Home Screen
  static const String welcomeMessage = 'Welcome to TownSquare';
  static const String quickActions = 'Quick Actions';

  // Notices
  static const String noticeBoard = 'Notice Board';
  static const String createNotice = 'Create Notice';
  static const String allNotices = 'All Notices';
  static const String pinnedNotices = 'Pinned Notices';

  // Tickets
  static const String myTickets = 'My Tickets';
  static const String createTicket = 'Create Ticket';
  static const String ticketHistory = 'Ticket History';
  static const String assignTicket = 'Assign Ticket';

  // Security
  static const String visitorManagement = 'Visitor Management';
  static const String preApproveVisitor = 'Pre-approve Visitor';
  static const String visitorHistory = 'Visitor History';
  static const String emergencyAlert = 'Emergency Alert';
  static const String panicButton = 'PANIC';

  // Forms
  static const String required = 'Required';
  static const String optional = 'Optional';
  static const String submit = 'Submit';
  static const String cancel = 'Cancel';
  static const String save = 'Save';
  static const String edit = 'Edit';
  static const String delete = 'Delete';

  // Messages
  static const String noDataAvailable = 'No data available';
  static const String loadingData = 'Loading data...';
  static const String errorOccurred = 'An error occurred';
  static const String successMessage = 'Operation completed successfully';

  // Emergency
  static const String panicAlertSent = 'Panic alert sent to security';
  static const String panicConfirmation = 'Hold for 3 seconds to send emergency alert';
  static const String emergencyHelpText = 'This will notify security and management immediately';
}

class AppRoutes {
  static const String home = '/';
  static const String notices = '/notices';
  static const String createNotice = '/notices/create';
  static const String tickets = '/tickets';
  static const String createTicket = '/tickets/create';
  static const String ticketDetail = '/tickets/detail';
  static const String security = '/security';
  static const String preApproveVisitor = '/security/preapprove';
  static const String profile = '/profile';
}