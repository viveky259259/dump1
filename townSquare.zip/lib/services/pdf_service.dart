import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';

// Platform-specific imports
import 'package:path_provider/path_provider.dart';
import 'package:universal_html/html.dart' as web_html;

// Conditional imports for mobile-only classes
import 'dart:io' if (dart.library.js) '_pdf_service_stub.dart';

class PdfService {
  static const PdfColor primaryColor = PdfColor.fromInt(0xFF2196F3);
  static const PdfColor secondaryColor = PdfColor.fromInt(0xFF37474F);
  static const PdfColor accentColor = PdfColor.fromInt(0xFF4CAF50);

  static Future<Uint8List> generateInvoicePdf(MaintenanceInvoice invoice, {User? residentInfo}) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (pw.Context context) {
          return [
            _buildHeader(),
            pw.SizedBox(height: 30),
            _buildInvoiceTitle(invoice),
            pw.SizedBox(height: 20),
            _buildInvoiceInfo(invoice),
            pw.SizedBox(height: 30),
            _buildResidentInfo(invoice, residentInfo),
            pw.SizedBox(height: 30),
            _buildAmountDetails(invoice),
            pw.SizedBox(height: 30),
            _buildPaymentInstructions(),
            pw.SizedBox(height: 40),
            _buildFooter(),
          ];
        },
      ),
    );

    return pdf.save();
  }

  static pw.Widget _buildHeader() {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(
              'TownSquare',
              style: pw.TextStyle(
                fontSize: 28,
                fontWeight: pw.FontWeight.bold,
                color: primaryColor,
              ),
            ),
            pw.Text(
              'Community Management',
              style: pw.TextStyle(
                fontSize: 14,
                color: secondaryColor,
              ),
            ),
          ],
        ),
        pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            pw.Text(
              'MAINTENANCE INVOICE',
              style: pw.TextStyle(
                fontSize: 20,
                fontWeight: pw.FontWeight.bold,
                color: secondaryColor,
              ),
            ),
            pw.Text(
              'Generated: ${_formatDate(DateTime.now())}',
              style: const pw.TextStyle(fontSize: 12),
            ),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildInvoiceTitle(MaintenanceInvoice invoice) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(20),
      decoration: pw.BoxDecoration(
        color: PdfColor.fromInt(0xFFE3F2FD),
        borderRadius: pw.BorderRadius.circular(8),
        border: pw.Border.all(color: primaryColor, width: 1),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'Invoice Number',
                style: const pw.TextStyle(fontSize: 12),
              ),
              pw.Text(
                invoice.invoiceNumber,
                style: pw.TextStyle(
                  fontSize: 18,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ],
          ),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: pw.BoxDecoration(
              color: _getStatusColor(invoice.status),
              borderRadius: pw.BorderRadius.circular(20),
            ),
            child: pw.Text(
              invoice.status.displayName.toUpperCase(),
              style: pw.TextStyle(
                color: PdfColors.white,
                fontSize: 12,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildInvoiceInfo(MaintenanceInvoice invoice) {
    return pw.Container(
      width: double.infinity,
      child: pw.Table(
        columnWidths: {
          0: const pw.FlexColumnWidth(1),
          1: const pw.FlexColumnWidth(1),
          2: const pw.FlexColumnWidth(1),
          3: const pw.FlexColumnWidth(1),
        },
        children: [
          pw.TableRow(
            children: [
              _buildInfoCell('Billing Period', '${invoice.monthName} ${invoice.invoiceYear}'),
              _buildInfoCell('Issue Date', _formatDate(invoice.createdAt)),
              _buildInfoCell('Due Date', _formatDate(invoice.dueDate)),
              _buildInfoCell('Flat Number', invoice.flatNumber),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildInfoCell(String label, String value) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(4),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            label,
            style: pw.TextStyle(
              fontSize: 10,
              color: secondaryColor,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            value,
            style: const pw.TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildResidentInfo(MaintenanceInvoice invoice, User? residentInfo) {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Bill To:',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
              color: secondaryColor,
            ),
          ),
          pw.SizedBox(height: 8),
          if (residentInfo != null) ...[
            pw.Text('Name: ${residentInfo.name}'),
            pw.Text('Email: ${residentInfo.email}'),
            pw.Text('Phone: ${residentInfo.phone}'),
          ] else
            pw.Text('Resident ID: ${invoice.residentId}'),
          pw.Text('Flat Number: ${invoice.flatNumber}'),
        ],
      ),
    );
  }

  static pw.Widget _buildAmountDetails(MaintenanceInvoice invoice) {
    return pw.Container(
      width: double.infinity,
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        children: [
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(16),
            decoration: const pw.BoxDecoration(
              color: PdfColors.grey100,
              borderRadius: pw.BorderRadius.only(
                topLeft: pw.Radius.circular(8),
                topRight: pw.Radius.circular(8),
              ),
            ),
            child: pw.Text(
              'Amount Details',
              style: pw.TextStyle(
                fontSize: 18,
                fontWeight: pw.FontWeight.bold,
                color: secondaryColor,
              ),
            ),
          ),
          pw.Padding(
            padding: const pw.EdgeInsets.all(16),
            child: pw.Column(
              children: [
                _buildAmountRow('Maintenance Charges', invoice.maintenanceAmount),
                if (invoice.lateFee > 0) ...[
                  pw.SizedBox(height: 8),
                  _buildAmountRow('Late Fee', invoice.lateFee),
                ],
                pw.SizedBox(height: 16),
                pw.Divider(thickness: 2),
                pw.SizedBox(height: 8),
                _buildAmountRow(
                  'Total Amount',
                  invoice.totalAmount,
                  isTotal: true,
                ),
                if (invoice.paymentDate != null) ...[
                  pw.SizedBox(height: 12),
                  pw.Container(
                    width: double.infinity,
                    padding: const pw.EdgeInsets.all(12),
                    decoration: pw.BoxDecoration(
                      color: PdfColor.fromInt(0xFFE8F5E8),
                      borderRadius: pw.BorderRadius.circular(4),
                    ),
                    child: pw.Column(
                      children: [
                        pw.Text(
                          'PAID',
                          style: pw.TextStyle(
                            fontSize: 16,
                            fontWeight: pw.FontWeight.bold,
                            color: accentColor,
                          ),
                        ),
                        pw.Text(
                          'Payment Date: ${_formatDate(invoice.paymentDate!)}',
                          style: const pw.TextStyle(fontSize: 12),
                        ),
                        if (invoice.paymentMethod != null)
                          pw.Text(
                            'Method: ${invoice.paymentMethod}',
                            style: const pw.TextStyle(fontSize: 12),
                          ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildAmountRow(String description, double amount, {bool isTotal = false}) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text(
          description,
          style: pw.TextStyle(
            fontSize: isTotal ? 16 : 14,
            fontWeight: isTotal ? pw.FontWeight.bold : pw.FontWeight.normal,
          ),
        ),
        pw.Text(
          '₹${amount.toStringAsFixed(2)}',
          style: pw.TextStyle(
            fontSize: isTotal ? 18 : 14,
            fontWeight: pw.FontWeight.bold,
            color: isTotal ? primaryColor : PdfColors.black,
          ),
        ),
      ],
    );
  }

  static pw.Widget _buildPaymentInstructions() {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        color: PdfColor.fromInt(0xFFE3F2FD),
        border: pw.Border.all(color: primaryColor),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'Payment Instructions',
            style: pw.TextStyle(
              fontSize: 16,
              fontWeight: pw.FontWeight.bold,
              color: primaryColor,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.Text(
            '• Pay online through the building management portal\n'
            '• Contact the office for cash payments\n'
            '• Keep payment receipt for your records\n'
            '• Late payments may incur additional charges\n'
            '• For queries, contact the management office',
            style: const pw.TextStyle(fontSize: 12, height: 1.5),
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildFooter() {
    return pw.Container(
      width: double.infinity,
      padding: const pw.EdgeInsets.all(16),
      decoration: const pw.BoxDecoration(
        border: pw.Border(
          top: pw.BorderSide(color: PdfColors.grey300, width: 1),
        ),
      ),
      child: pw.Column(
        children: [
          pw.Text(
            'Thank you for your prompt payment!',
            style: pw.TextStyle(
              fontSize: 14,
              fontWeight: pw.FontWeight.bold,
              color: secondaryColor,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.Text(
            'This is a computer-generated invoice and does not require a signature.',
            style: const pw.TextStyle(fontSize: 10),
          ),
        ],
      ),
    );
  }

  static String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  static PdfColor _getStatusColor(InvoiceStatus status) {
    switch (status) {
      case InvoiceStatus.paid:
        return accentColor;
      case InvoiceStatus.unpaid:
        return const PdfColor.fromInt(0xFFFF9800);
      case InvoiceStatus.overdue:
        return const PdfColor.fromInt(0xFFF44336);
    }
  }

  static Future<String> saveInvoicePdf(MaintenanceInvoice invoice, {User? residentInfo}) async {
    final pdfData = await generateInvoicePdf(invoice, residentInfo: residentInfo);
    final fileName = 'invoice_${invoice.invoiceNumber.replaceAll('-', '_')}.pdf';
    
    if (kIsWeb) {
      // Web platform: trigger browser download
      _downloadFileWeb(pdfData, fileName);
      return 'Downloaded: $fileName';
    } else {
      // Mobile platform: save to device storage
      return await _savePdfMobile(pdfData, fileName);
    }
  }
  
  static void _downloadFileWeb(Uint8List data, String fileName) {
    final blob = web_html.Blob([data], 'application/pdf');
    final url = web_html.Url.createObjectUrlFromBlob(blob);
    final anchor = web_html.document.createElement('a') as web_html.AnchorElement
      ..href = url
      ..style.display = 'none'
      ..download = fileName;
    web_html.document.body?.children.add(anchor);
    anchor.click();
    web_html.document.body?.children.remove(anchor);
    web_html.Url.revokeObjectUrl(url);
  }
  
  static Future<String> _savePdfMobile(Uint8List pdfData, String fileName) async {
    try {
      if (!kIsWeb) {
        final directory = await getApplicationDocumentsDirectory();
        final invoicesPath = '${directory.path}/invoices';
        
        // Create directory if it doesn't exist (mobile only)
        final invoicesDir = Directory(invoicesPath);
        if (!await invoicesDir.exists()) {
          await invoicesDir.create(recursive: true);
        }
        
        // Save file (mobile only)
        final file = File('$invoicesPath/$fileName');
        await file.writeAsBytes(pdfData);
        return 'Saved to: ${file.path}';
      } else {
        // This should not be called on web, but just in case
        return 'Mobile save not available on web platform';
      }
    } catch (e) {
      throw Exception('Failed to save PDF: $e');
    }
  }

  static Future<void> shareInvoicePdf(MaintenanceInvoice invoice, {User? residentInfo}) async {
    final pdfData = await generateInvoicePdf(invoice, residentInfo: residentInfo);
    
    await Printing.sharePdf(
      bytes: pdfData,
      filename: 'invoice_${invoice.invoiceNumber.replaceAll('-', '_')}.pdf',
    );
  }

  static Future<void> printInvoice(MaintenanceInvoice invoice, {User? residentInfo}) async {
    final pdfData = await generateInvoicePdf(invoice, residentInfo: residentInfo);
    
    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfData,
      name: 'invoice_${invoice.invoiceNumber.replaceAll('-', '_')}.pdf',
    );
  }

  static Future<void> previewInvoice(MaintenanceInvoice invoice, {User? residentInfo}) async {
    final pdfData = await generateInvoicePdf(invoice, residentInfo: residentInfo);
    
    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfData,
      name: 'invoice_${invoice.invoiceNumber.replaceAll('-', '_')}.pdf',
    );
  }
}