import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';

class InvoiceService {
  final SupabaseClient _supabase = Supabase.instance.client;

  // Generate invoice number in format: INV-YYYY-MM-XXXX
  String _generateInvoiceNumber(int year, int month) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final sequenceNumber = (timestamp % 10000).toString().padLeft(4, '0');
    return 'INV-$year-${month.toString().padLeft(2, '0')}-$sequenceNumber';
  }

  Future<List<Apartment>> getApartments() async {
    try {
      final response = await _supabase
          .from('apartments')
          .select()
          .order('flat_number');

      return (response as List)
          .map((json) => Apartment.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to load apartments: $e');
    }
  }

  Future<List<MaintenanceInvoice>> getInvoices({String? residentId}) async {
    try {
      var query = _supabase
          .from('maintenance_invoices')
          .select();

      if (residentId != null) {
        query = query.eq('resident_id', residentId);
      }

      final response = await query.order('created_at', ascending: false);

      return (response as List)
          .map((json) => MaintenanceInvoice.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to load invoices: $e');
    }
  }

  Future<List<MaintenanceInvoice>> generateInvoicesForMonth(
    int month,
    int year,
    String generatedBy,
  ) async {
    try {
      // Get all occupied apartments
      final apartmentsResponse = await _supabase
          .from('apartments')
          .select()
          .eq('is_occupied', true);

      final apartments = (apartmentsResponse as List)
          .map((json) => Apartment.fromJson(json))
          .toList();

      // Check for existing invoices for this month/year
      final existingInvoicesResponse = await _supabase
          .from('maintenance_invoices')
          .select('apartment_id')
          .eq('invoice_month', month)
          .eq('invoice_year', year);

      final existingApartmentIds = (existingInvoicesResponse as List)
          .map((invoice) => invoice['apartment_id'] as String)
          .toSet();

      // Filter apartments that don't have invoices yet
      final apartmentsToInvoice = apartments
          .where((apt) => !existingApartmentIds.contains(apt.id))
          .where((apt) => apt.residentId.isNotEmpty)
          .toList();

      if (apartmentsToInvoice.isEmpty) {
        throw Exception('No apartments found for invoice generation or all invoices already generated');
      }

      final generatedInvoices = <MaintenanceInvoice>[];
      final now = DateTime.now();
      final dueDate = DateTime(year, month, 25); // Due on 25th of the month

      for (final apartment in apartmentsToInvoice) {
        final invoiceNumber = _generateInvoiceNumber(year, month);
        final totalAmount = apartment.maintenanceAmount;

        final invoiceData = {
          'invoice_number': invoiceNumber,
          'apartment_id': apartment.id,
          'resident_id': apartment.residentId,
          'flat_number': apartment.flatNumber,
          'invoice_month': month,
          'invoice_year': year,
          'maintenance_amount': apartment.maintenanceAmount,
          'due_date': dueDate.toIso8601String().split('T')[0],
          'status': 'unpaid',
          'late_fee': 0.0,
          'total_amount': totalAmount,
          'generated_by': generatedBy,
          'created_at': now.toIso8601String(),
          'updated_at': now.toIso8601String(),
        };

        final response = await _supabase
            .from('maintenance_invoices')
            .insert(invoiceData)
            .select()
            .single();

        generatedInvoices.add(MaintenanceInvoice.fromJson(response));

        // Send notification
        await _sendInvoiceNotification(
          MaintenanceInvoice.fromJson(response),
          NotificationType.generated,
          SentVia.inApp,
        );
      }

      return generatedInvoices;
    } catch (e) {
      throw Exception('Failed to generate invoices: $e');
    }
  }

  Future<MaintenanceInvoice> generateInvoiceForApartment(
    String apartmentId,
    int month,
    int year,
    String generatedBy,
  ) async {
    try {
      // Get apartment details
      final apartmentResponse = await _supabase
          .from('apartments')
          .select()
          .eq('id', apartmentId)
          .single();

      final apartment = Apartment.fromJson(apartmentResponse);

      if (apartment.residentId.isEmpty) {
        throw Exception('Apartment has no resident assigned');
      }

      // Check if invoice already exists
      final existingInvoice = await _supabase
          .from('maintenance_invoices')
          .select()
          .eq('apartment_id', apartmentId)
          .eq('invoice_month', month)
          .eq('invoice_year', year)
          .maybeSingle();

      if (existingInvoice != null) {
        throw Exception('Invoice already exists for this apartment and month');
      }

      final invoiceNumber = _generateInvoiceNumber(year, month);
      final now = DateTime.now();
      final dueDate = DateTime(year, month, 25);
      final totalAmount = apartment.maintenanceAmount;

      final invoiceData = {
        'invoice_number': invoiceNumber,
        'apartment_id': apartment.id,
        'resident_id': apartment.residentId,
        'flat_number': apartment.flatNumber,
        'invoice_month': month,
        'invoice_year': year,
        'maintenance_amount': apartment.maintenanceAmount,
        'due_date': dueDate.toIso8601String().split('T')[0],
        'status': 'unpaid',
        'late_fee': 0.0,
        'total_amount': totalAmount,
        'generated_by': generatedBy,
        'created_at': now.toIso8601String(),
        'updated_at': now.toIso8601String(),
      };

      final response = await _supabase
          .from('maintenance_invoices')
          .insert(invoiceData)
          .select()
          .single();

      final invoice = MaintenanceInvoice.fromJson(response);

      // Send notification
      await _sendInvoiceNotification(
        invoice,
        NotificationType.generated,
        SentVia.inApp,
      );

      return invoice;
    } catch (e) {
      throw Exception('Failed to generate invoice: $e');
    }
  }

  Future<MaintenanceInvoice> markInvoiceAsPaid(
    String invoiceId,
    String paymentMethod,
  ) async {
    try {
      final now = DateTime.now();
      
      final response = await _supabase
          .from('maintenance_invoices')
          .update({
            'status': 'paid',
            'payment_date': now.toIso8601String(),
            'payment_method': paymentMethod,
            'updated_at': now.toIso8601String(),
          })
          .eq('id', invoiceId)
          .select()
          .single();

      return MaintenanceInvoice.fromJson(response);
    } catch (e) {
      throw Exception('Failed to mark invoice as paid: $e');
    }
  }

  Future<void> sendInvoiceNotification(
    String invoiceId,
    NotificationType notificationType,
    SentVia sentVia,
  ) async {
    try {
      final invoiceResponse = await _supabase
          .from('maintenance_invoices')
          .select()
          .eq('id', invoiceId)
          .single();

      final invoice = MaintenanceInvoice.fromJson(invoiceResponse);
      await _sendInvoiceNotification(invoice, notificationType, sentVia);
    } catch (e) {
      throw Exception('Failed to send notification: $e');
    }
  }

  Future<void> _sendInvoiceNotification(
    MaintenanceInvoice invoice,
    NotificationType notificationType,
    SentVia sentVia,
  ) async {
    try {
      String message;
      switch (notificationType) {
        case NotificationType.generated:
          message = 'New maintenance invoice generated for ${invoice.monthName} ${invoice.invoiceYear}. Amount: ₹${invoice.totalAmount.toStringAsFixed(2)}';
          break;
        case NotificationType.reminder:
          message = 'Reminder: Your maintenance payment for ${invoice.monthName} ${invoice.invoiceYear} is due on ${invoice.dueDate.day}/${invoice.dueDate.month}/${invoice.dueDate.year}';
          break;
        case NotificationType.overdue:
          message = 'OVERDUE: Your maintenance payment for ${invoice.monthName} ${invoice.invoiceYear} was due on ${invoice.dueDate.day}/${invoice.dueDate.month}/${invoice.dueDate.year}';
          break;
      }

      // Convert enum values to match database constraints
      String convertSentViaToDb(SentVia sentVia) {
        switch (sentVia) {
          case SentVia.inApp:
            return 'in_app';
          case SentVia.email:
            return 'email';
          case SentVia.sms:
            return 'sms';
        }
      }

      final notificationData = {
        'invoice_id': invoice.id,
        'resident_id': invoice.residentId,
        'notification_type': notificationType.name,
        'sent_via': convertSentViaToDb(sentVia),
        'status': 'sent',
        'message': message,
        'sent_at': DateTime.now().toIso8601String(),
      };

      await _supabase
          .from('invoice_notifications')
          .insert(notificationData);

      // In a real app, you would also send email/SMS here
      // For now, we'll just store in-app notifications
    } catch (e) {
      throw Exception('Failed to send notification: $e');
    }
  }

  Future<Apartment> updateApartmentMaintenanceAmount(
    String apartmentId,
    double newAmount,
  ) async {
    try {
      final response = await _supabase
          .from('apartments')
          .update({
            'maintenance_amount': newAmount,
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('id', apartmentId)
          .select()
          .single();

      return Apartment.fromJson(response);
    } catch (e) {
      throw Exception('Failed to update maintenance amount: $e');
    }
  }

  Future<List<InvoiceNotification>> getInvoiceNotifications(String residentId) async {
    try {
      final response = await _supabase
          .from('invoice_notifications')
          .select()
          .eq('resident_id', residentId)
          .order('sent_at', ascending: false);

      return (response as List)
          .map((json) => InvoiceNotification.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to load notifications: $e');
    }
  }
}