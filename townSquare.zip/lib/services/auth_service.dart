import 'package:supabase_flutter/supabase_flutter.dart' hide User;
import 'package:supabase_flutter/supabase_flutter.dart' as supabase show User;
import 'package:townsquare/models/user.dart';
import 'package:townsquare/supabase/supabase_config.dart';
import 'dart:async';

class AuthService {
  static AuthService? _instance;
  static AuthService get instance {
    _instance ??= AuthService._();
    return _instance!;
  }

  AuthService._();

  User? _currentUser;
  StreamSubscription<AuthState>? _authSubscription;
  final StreamController<User?> _userController = StreamController<User?>.broadcast();

  Stream<User?> get userStream => _userController.stream;

  Future<void> initialize() async {
    try {
      await SupabaseConfig.initialize();
      
      // Listen to auth state changes
      _authSubscription = SupabaseConfig.authStateChanges.listen((AuthState data) {
        _handleAuthStateChange(data);
      });

      // Check if user is already logged in
      final currentAuthUser = SupabaseConfig.currentUser;
      if (currentAuthUser != null) {
        await _loadUserProfile(currentAuthUser.id);
      }
    } catch (error) {
      print('Auth service initialization error: $error');
      rethrow;
    }
  }

  void _handleAuthStateChange(AuthState authState) async {
    final authUser = authState.session?.user;
    
    if (authUser != null) {
      // User signed in, load their profile
      await _loadUserProfile(authUser.id);
    } else {
      // User signed out
      _currentUser = null;
      _userController.add(null);
    }
  }

  Future<void> _loadUserProfile(String userId) async {
    try {
      final userData = await SupabaseConfig.getUserProfile(userId);
      if (userData.isNotEmpty) {
        _currentUser = User.fromSupabaseData(userData.first);
        _userController.add(_currentUser);
      }
    } catch (error) {
      print('Error loading user profile: $error');
    }
  }

  Future<String> signIn(String email, String password) async {
    try {
      final response = await SupabaseConfig.signIn(email, password);
      
      if (response.user != null) {
        // Don't load user profile immediately, let auth state change handle it
        return 'success';
      } else {
        return 'Sign in failed. Please try again.';
      }
    } catch (error) {
      return error.toString();
    }
  }

  Future<String> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String flatNumber,
    required UserRole role,
  }) async {
    try {
      final response = await SupabaseConfig.signUp(email, password);
      
      if (response.user != null) {
        // Create user profile in users table
        await SupabaseConfig.createUserProfile(
          id: response.user!.id,
          name: name,
          email: email,
          phone: phone,
          flatNumber: flatNumber,
          role: role.name,
        );
        
        return 'success';
      } else {
        return 'Sign up failed. Please try again.';
      }
    } catch (error) {
      return error.toString();
    }
  }

  Future<void> signOut() async {
    try {
      await SupabaseConfig.signOut();
      _currentUser = null;
      _userController.add(null);
    } catch (error) {
      print('Error signing out: $error');
    }
  }

  Future<List<User>> getAllUsers() async {
    try {
      final response = await SupabaseConfig.client
          .from('users')
          .select();
      
      return response.map((userData) => User.fromSupabaseData(userData)).toList();
    } catch (error) {
      print('Error fetching users: $error');
      return [];
    }
  }

  Future<List<User>> getUsersByRole(UserRole role) async {
    try {
      final response = await SupabaseConfig.client
          .from('users')
          .select()
          .eq('role', role.name);
      
      return response.map((userData) => User.fromSupabaseData(userData)).toList();
    } catch (error) {
      print('Error fetching users by role: $error');
      return [];
    }
  }

  Future<User?> getUserById(String id) async {
    try {
      final response = await SupabaseConfig.client
          .from('users')
          .select()
          .eq('id', id)
          .single();
      
      return User.fromSupabaseData(response);
    } catch (error) {
      print('Error fetching user by id: $error');
      return null;
    }
  }

  User? get currentUser => _currentUser;

  bool get isLoggedIn => _currentUser != null;
  bool get isAdmin => _currentUser?.role == UserRole.admin;
  bool get isResident => _currentUser?.role == UserRole.resident;
  bool get isStaff => _currentUser?.role == UserRole.staff;
  bool get isSecurity => _currentUser?.role == UserRole.security;

  void dispose() {
    _authSubscription?.cancel();
    _userController.close();
  }
}