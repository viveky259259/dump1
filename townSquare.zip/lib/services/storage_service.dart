import 'package:shared_preferences/shared_preferences.dart';
import 'package:townsquare/models/data_models.dart';
import 'package:townsquare/models/user.dart';
import 'package:townsquare/services/auth_service.dart';
import 'dart:convert';
import 'dart:math';

class StorageService {
  static const String _noticesKey = 'notices';
  static const String _groupsKey = 'community_groups';
  static const String _postsKey = 'posts';
  static const String _pollsKey = 'polls';
  static const String _ticketsKey = 'tickets';
  static const String _visitorApprovalsKey = 'visitor_approvals';
  static const String _panicAlertsKey = 'panic_alerts';

  static StorageService? _instance;
  static StorageService get instance {
    _instance ??= StorageService._();
    return _instance!;
  }

  StorageService._();

  List<Notice> _notices = [];
  List<CommunityGroup> _groups = [];
  List<Post> _posts = [];
  List<Poll> _polls = [];
  List<Ticket> _tickets = [];
  List<VisitorApproval> _visitorApprovals = [];
  List<PanicAlert> _panicAlerts = [];

  Future<void> initialize() async {
    await _loadAllData();
    await _initializeSampleData();
  }

  Future<void> _loadAllData() async {
    final prefs = await SharedPreferences.getInstance();

    // Load notices
    final noticesJson = prefs.getStringList(_noticesKey) ?? [];
    _notices = noticesJson.map((str) => Notice.fromJson(json.decode(str))).toList();

    // Load groups
    final groupsJson = prefs.getStringList(_groupsKey) ?? [];
    _groups = groupsJson.map((str) => CommunityGroup.fromJson(json.decode(str))).toList();

    // Load posts
    final postsJson = prefs.getStringList(_postsKey) ?? [];
    _posts = postsJson.map((str) => Post.fromJson(json.decode(str))).toList();

    // Load polls
    final pollsJson = prefs.getStringList(_pollsKey) ?? [];
    _polls = pollsJson.map((str) => Poll.fromJson(json.decode(str))).toList();

    // Load tickets
    final ticketsJson = prefs.getStringList(_ticketsKey) ?? [];
    _tickets = ticketsJson.map((str) => Ticket.fromJson(json.decode(str))).toList();

    // Load visitor approvals
    final visitorsJson = prefs.getStringList(_visitorApprovalsKey) ?? [];
    _visitorApprovals = visitorsJson.map((str) => VisitorApproval.fromJson(json.decode(str))).toList();

    // Load panic alerts
    final alertsJson = prefs.getStringList(_panicAlertsKey) ?? [];
    _panicAlerts = alertsJson.map((str) => PanicAlert.fromJson(json.decode(str))).toList();
  }

  Future<void> _initializeSampleData() async {
    if (_notices.isEmpty) {
      await _createSampleNotices();
      await _createSampleGroups();
      await _createSamplePosts();
      await _createSamplePolls();
      await _createSampleTickets();
      await _createSampleVisitorApprovals();
    }
  }

  Future<void> _createSampleNotices() async {
    final admins = await AuthService.instance.getUsersByRole(UserRole.admin);
    if (admins.isEmpty) return;
    final adminId = admins.first.id;
    final sampleNotices = [
      Notice(
        id: 'notice_001',
        title: 'Monthly Maintenance Schedule',
        content: 'Dear Residents,\n\nWe will be conducting routine maintenance of the elevators on Saturday, December 21st from 9:00 AM to 2:00 PM. Please plan accordingly and use the stairs during this time.\n\nThank you for your cooperation.',
        category: NoticeCategory.maintenance,
        authorId: adminId,
        publishDate: DateTime.now().subtract(const Duration(days: 2)),
        expiryDate: DateTime.now().add(const Duration(days: 5)),
        isPinned: true,
      ),
      Notice(
        id: 'notice_002',
        title: 'Holiday Party - December 24th',
        content: 'Join us for our annual holiday celebration! 🎄\n\n📅 Date: December 24th\n🕒 Time: 6:00 PM - 10:00 PM\n📍 Location: Community Hall\n\nLight refreshments will be provided. Please RSVP by December 22nd.',
        category: NoticeCategory.event,
        authorId: adminId,
        publishDate: DateTime.now().subtract(const Duration(days: 5)),
        expiryDate: DateTime.now().add(const Duration(days: 10)),
        isPinned: false,
      ),
      Notice(
        id: 'notice_003',
        title: 'Water Supply Interruption',
        content: 'URGENT: Water supply will be interrupted tomorrow (December 20th) from 6:00 AM to 10:00 AM due to pipeline maintenance work.\n\nPlease store water in advance. We apologize for the inconvenience.',
        category: NoticeCategory.urgent,
        authorId: adminId,
        publishDate: DateTime.now().subtract(const Duration(hours: 8)),
        expiryDate: DateTime.now().add(const Duration(days: 1)),
        isPinned: true,
      ),
      Notice(
        id: 'notice_004',
        title: 'Parking Guidelines Reminder',
        content: 'Please ensure that:\n• Vehicles are parked only in designated spots\n• Visitor parking passes are displayed\n• No parking in fire lanes\n\nViolations will result in towing at owner\'s expense.',
        category: NoticeCategory.general,
        authorId: adminId,
        publishDate: DateTime.now().subtract(const Duration(days: 7)),
        expiryDate: DateTime.now().add(const Duration(days: 30)),
        isPinned: false,
      ),
    ];

    _notices = sampleNotices;
    await _saveNotices();
  }

  Future<void> _createSampleGroups() async {
    final admins = await AuthService.instance.getUsersByRole(UserRole.admin);
    if (admins.isEmpty) return;
    final adminId = admins.first.id;
    final sampleGroups = [
      CommunityGroup(
        id: 'group_001',
        name: 'General Chat',
        description: 'General discussions for all residents',
        createdBy: adminId,
        isDefault: true,
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
      ),
      CommunityGroup(
        id: 'group_002',
        name: 'Buy/Sell/Rent',
        description: 'Marketplace for residents',
        createdBy: adminId,
        isDefault: true,
        createdAt: DateTime.now().subtract(const Duration(days: 25)),
      ),
      CommunityGroup(
        id: 'group_003',
        name: 'Lost & Found',
        description: 'Report lost items or found items',
        createdBy: adminId,
        isDefault: true,
        createdAt: DateTime.now().subtract(const Duration(days: 20)),
      ),
    ];

    _groups = sampleGroups;
    await _saveGroups();
  }

  Future<void> _createSamplePosts() async {
    final residents = await AuthService.instance.getUsersByRole(UserRole.resident);
    if (residents.isEmpty) return;
    final samplePosts = [
      Post(
        id: 'post_001',
        groupId: 'group_001',
        authorId: residents[0].id,
        content: 'The new gym equipment looks amazing! Thank you to the management for the upgrade. 💪',
        timestamp: DateTime.now().subtract(const Duration(hours: 4)),
        likesCount: 8,
        likedBy: ['admin_001', 'resident_002', 'staff_001'],
      ),
      Post(
        id: 'post_002',
        groupId: 'group_002',
        authorId: residents[1].id,
        content: 'Selling a barely used microwave oven. Perfect condition, asking \$80. Contact me if interested!',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        likesCount: 3,
        likedBy: ['resident_001'],
      ),
      Post(
        id: 'post_003',
        groupId: 'group_003',
        authorId: residents[0].id,
        content: 'Found a pair of reading glasses near the mailboxes. They have a brown frame. Please contact me if they\'re yours.',
        timestamp: DateTime.now().subtract(const Duration(days: 2)),
        likesCount: 5,
        likedBy: ['admin_001', 'resident_002'],
      ),
    ];

    _posts = samplePosts;
    await _savePosts();
  }

  Future<void> _createSamplePolls() async {
    final admins = await AuthService.instance.getUsersByRole(UserRole.admin);
    if (admins.isEmpty) return;
    final adminId = admins.first.id;
    final samplePolls = [
      Poll(
        id: 'poll_001',
        question: 'What time should the community pool open during winter?',
        options: ['7:00 AM', '8:00 AM', '9:00 AM', '10:00 AM'],
        startDate: DateTime.now().subtract(const Duration(days: 3)),
        endDate: DateTime.now().add(const Duration(days: 4)),
        votes: {
          '7:00 AM': ['resident_001'],
          '8:00 AM': ['admin_001', 'resident_002'],
          '9:00 AM': ['staff_001'],
          '10:00 AM': [],
        },
        allowMultiple: false,
      ),
    ];

    _polls = samplePolls;
    await _savePolls();
  }

  Future<void> _createSampleTickets() async {
    final residents = await AuthService.instance.getUsersByRole(UserRole.resident);
    if (residents.isEmpty) return;
    final staff = await AuthService.instance.getUsersByRole(UserRole.staff);
    if (staff.isEmpty) return;
    final staffId = staff.first.id;
    
    final sampleTickets = [
      Ticket(
        id: 'ticket_001',
        residentId: residents[0].id,
        flatNumber: residents[0].flatNumber,
        category: TicketCategory.plumbing,
        description: 'Kitchen sink is leaking. Water is dripping constantly from the faucet.',
        status: TicketStatus.inProgress,
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
        assignedTo: staffId,
        updates: [
          TicketUpdate(
            id: 'update_001',
            ticketId: 'ticket_001',
            updateType: 'status_change',
            content: 'Assigned to maintenance team',
            updatedBy: 'admin_001',
            timestamp: DateTime.now().subtract(const Duration(days: 2, hours: 2)),
          ),
          TicketUpdate(
            id: 'update_002',
            ticketId: 'ticket_001',
            updateType: 'comment',
            content: 'Parts ordered. Will fix tomorrow morning.',
            updatedBy: staffId,
            timestamp: DateTime.now().subtract(const Duration(days: 1)),
          ),
        ],
      ),
      Ticket(
        id: 'ticket_002',
        residentId: residents[1].id,
        flatNumber: residents[1].flatNumber,
        category: TicketCategory.electrical,
        description: 'Hallway light on 3rd floor is not working.',
        status: TicketStatus.open,
        createdAt: DateTime.now().subtract(const Duration(hours: 6)),
        updates: [],
      ),
      Ticket(
        id: 'ticket_003',
        residentId: residents[0].id,
        flatNumber: residents[0].flatNumber,
        category: TicketCategory.housekeeping,
        description: 'Gym area needs deep cleaning. Equipment is dusty.',
        status: TicketStatus.resolved,
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
        assignedTo: staffId,
        updates: [
          TicketUpdate(
            id: 'update_003',
            ticketId: 'ticket_003',
            updateType: 'status_change',
            content: 'Cleaning completed. Gym is ready for use.',
            updatedBy: staffId,
            timestamp: DateTime.now().subtract(const Duration(days: 1)),
          ),
        ],
      ),
    ];

    _tickets = sampleTickets;
    await _saveTickets();
  }

  Future<void> _createSampleVisitorApprovals() async {
    final residents = await AuthService.instance.getUsersByRole(UserRole.resident);
    if (residents.isEmpty) return;
    final sampleApprovals = [
      VisitorApproval(
        id: 'visitor_001',
        residentId: residents[0].id,
        flatNumber: residents[0].flatNumber,
        visitorName: 'John Smith',
        visitorType: VisitorType.guest,
        expectedArrival: DateTime.now().add(const Duration(hours: 2)),
        entryCode: _generateEntryCode(),
        status: VisitorStatus.expected,
      ),
      VisitorApproval(
        id: 'visitor_002',
        residentId: residents[1].id,
        flatNumber: residents[1].flatNumber,
        visitorName: 'Amazon Delivery',
        visitorType: VisitorType.delivery,
        expectedArrival: DateTime.now().add(const Duration(hours: 4)),
        entryCode: _generateEntryCode(),
        status: VisitorStatus.expected,
        company: 'Amazon',
      ),
    ];

    _visitorApprovals = sampleApprovals;
    await _saveVisitorApprovals();
  }

  String _generateEntryCode() {
    final random = Random();
    return (1000 + random.nextInt(9000)).toString();
  }

  // Getters
  List<Notice> get notices => List.unmodifiable(_notices);
  List<CommunityGroup> get groups => List.unmodifiable(_groups);
  List<Post> get posts => List.unmodifiable(_posts);
  List<Poll> get polls => List.unmodifiable(_polls);
  List<Ticket> get tickets => List.unmodifiable(_tickets);
  List<VisitorApproval> get visitorApprovals => List.unmodifiable(_visitorApprovals);
  List<PanicAlert> get panicAlerts => List.unmodifiable(_panicAlerts);

  // Save methods
  Future<void> _saveNotices() async {
    final prefs = await SharedPreferences.getInstance();
    final noticesJson = _notices.map((notice) => json.encode(notice.toJson())).toList();
    await prefs.setStringList(_noticesKey, noticesJson);
  }

  Future<void> _saveGroups() async {
    final prefs = await SharedPreferences.getInstance();
    final groupsJson = _groups.map((group) => json.encode(group.toJson())).toList();
    await prefs.setStringList(_groupsKey, groupsJson);
  }

  Future<void> _savePosts() async {
    final prefs = await SharedPreferences.getInstance();
    final postsJson = _posts.map((post) => json.encode(post.toJson())).toList();
    await prefs.setStringList(_postsKey, postsJson);
  }

  Future<void> _savePolls() async {
    final prefs = await SharedPreferences.getInstance();
    final pollsJson = _polls.map((poll) => json.encode(poll.toJson())).toList();
    await prefs.setStringList(_pollsKey, pollsJson);
  }

  Future<void> _saveTickets() async {
    final prefs = await SharedPreferences.getInstance();
    final ticketsJson = _tickets.map((ticket) => json.encode(ticket.toJson())).toList();
    await prefs.setStringList(_ticketsKey, ticketsJson);
  }

  Future<void> _saveVisitorApprovals() async {
    final prefs = await SharedPreferences.getInstance();
    final visitorsJson = _visitorApprovals.map((visitor) => json.encode(visitor.toJson())).toList();
    await prefs.setStringList(_visitorApprovalsKey, visitorsJson);
  }

  Future<void> _savePanicAlerts() async {
    final prefs = await SharedPreferences.getInstance();
    final alertsJson = _panicAlerts.map((alert) => json.encode(alert.toJson())).toList();
    await prefs.setStringList(_panicAlertsKey, alertsJson);
  }

  // CRUD operations for notices
  Future<void> addNotice(Notice notice) async {
    _notices.insert(0, notice);
    await _saveNotices();
  }

  // CRUD operations for tickets
  Future<void> addTicket(Ticket ticket) async {
    _tickets.insert(0, ticket);
    await _saveTickets();
  }

  Future<void> updateTicket(Ticket updatedTicket) async {
    final index = _tickets.indexWhere((t) => t.id == updatedTicket.id);
    if (index != -1) {
      _tickets[index] = updatedTicket;
      await _saveTickets();
    }
  }

  // CRUD operations for visitor approvals
  Future<void> addVisitorApproval(VisitorApproval approval) async {
    _visitorApprovals.insert(0, approval);
    await _saveVisitorApprovals();
  }

  // CRUD operations for panic alerts
  Future<void> addPanicAlert(PanicAlert alert) async {
    _panicAlerts.insert(0, alert);
    await _savePanicAlerts();
  }

  // Filter methods
  List<Notice> getActiveNotices() {
    final now = DateTime.now();
    return _notices.where((notice) {
      return notice.expiryDate == null || notice.expiryDate!.isAfter(now);
    }).toList();
  }

  List<Notice> getPinnedNotices() {
    return getActiveNotices().where((notice) => notice.isPinned).toList();
  }

  List<Ticket> getTicketsForResident(String residentId) {
    return _tickets.where((ticket) => ticket.residentId == residentId).toList();
  }

  List<Ticket> getTicketsForStaff(String staffId) {
    return _tickets.where((ticket) => ticket.assignedTo == staffId).toList();
  }

  List<VisitorApproval> getVisitorApprovalsForResident(String residentId) {
    return _visitorApprovals.where((approval) => approval.residentId == residentId).toList();
  }

  List<VisitorApproval> getTodaysVisitorApprovals() {
    final today = DateTime.now();
    return _visitorApprovals.where((approval) {
      return approval.expectedArrival.year == today.year &&
          approval.expectedArrival.month == today.month &&
          approval.expectedArrival.day == today.day;
    }).toList();
  }
}