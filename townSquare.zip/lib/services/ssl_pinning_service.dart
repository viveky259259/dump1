import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:http_certificate_pinning/http_certificate_pinning.dart';
import 'package:townsquare/config/ssl_config.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
  
class SSLPinningService {
  static Dio? _dioInstance;
  static SSLEnvironmentConfig? _currentConfig;
  
  static Dio get dioInstance {
    _dioInstance ??= _createDioWithPinning();
    return _dioInstance!;
  }
  
  static Dio _createDioWithPinning() {
    final dio = Dio();
    final config = _currentConfig ?? SSLConfig.getCurrentConfig();
    
    // Only add SSL pinning in production or when explicitly enabled
    if (config.enablePinning) {
      if (kIsWeb) {
        // Web-specific SSL validation
        dio.interceptors.add(WebSSLValidationInterceptor());
      } else {
        // Mobile-specific certificate pinning
        dio.interceptors.add(
          CertificatePinningInterceptor(
            allowedSHAFingerprints: SSLConfig.allAllowedFingerprints,
          ),
        );
      }
    }
    
    // Configure timeout based on config
    final timeoutDuration = Duration(seconds: config.timeoutSeconds);
    dio.options.connectTimeout = timeoutDuration;
    dio.options.receiveTimeout = timeoutDuration;
    dio.options.sendTimeout = timeoutDuration;
    
    // Add logging interceptor based on log level
    if (config.logLevel != SSLLogLevel.none) {
      dio.interceptors.add(LogInterceptor(
        requestBody: config.logLevel == SSLLogLevel.verbose,
        responseBody: config.logLevel == SSLLogLevel.verbose,
        requestHeader: config.logLevel == SSLLogLevel.verbose,
        responseHeader: false,
        error: true,
        logPrint: (log) {
          if (config.logLevel == SSLLogLevel.verbose || 
              (config.logLevel == SSLLogLevel.info && !log.toString().contains('DioException')) ||
              (config.logLevel == SSLLogLevel.error && log.toString().contains('ERROR'))) {
            print('[SSL Pinning] $log');
          }
        },
      ));
    }
    
    return dio;
  }
  
  // Helper method to check SSL pinning for a specific URL
  static Future<bool> checkSSLPinning(String url) async {
    final config = _currentConfig ?? SSLConfig.getCurrentConfig();
    
    // Skip SSL pinning check if disabled
    if (!config.enablePinning) {
      return true;
    }
    
    try {
      if (kIsWeb) {
        // Web-specific SSL validation
        return await _checkWebSSL(url, config);
      } else {
        // Mobile-specific certificate pinning
        final result = await HttpCertificatePinning.check(
          serverURL: url,
          headerHttp: {'User-Agent': 'TownSquare-Flutter-App'},
          sha: SHA.SHA256,
          allowedSHAFingerprints: SSLConfig.allAllowedFingerprints,
          timeout: config.timeoutSeconds,
        );
        final isSecure = result.contains('CONNECTION_SECURE');
        
        if (config.logLevel != SSLLogLevel.none) {
          print('[SSL Pinning] Check for $url: ${isSecure ? 'SECURE' : 'FAILED'} - $result');
        }
        
        return isSecure;
      }
    } catch (e) {
      if (config.logLevel != SSLLogLevel.none) {
        print('[SSL Pinning] Check failed for $url: $e');
      }
      
      // In strict mode, fail on any error
      return !config.strictMode;
    }
  }
  
  // Method to get certificate fingerprint for a domain
  static Future<String?> getCertificateFingerprint(String domain) async {
    try {
      final result = await Process.run('openssl', [
        's_client',
        '-servername',
        domain,
        '-connect',
        '$domain:443',
        '-showcerts'
      ]);
      
      if (result.exitCode == 0) {
        // Parse the certificate and extract fingerprint
        // This is a simplified implementation - in production you might want more robust parsing
        final output = result.stdout as String;
        print('Certificate info for $domain: $output');
        return null; // Return actual fingerprint parsing logic here
      }
    } catch (e) {
      print('Failed to get certificate for $domain: $e');
    }
    return null;
  }
  
  // Set custom SSL configuration
  static void setConfiguration(SSLEnvironmentConfig config) {
    _currentConfig = config;
    resetDioInstance(); // Force recreation with new config
  }
  
  // Get current SSL configuration
  static SSLEnvironmentConfig getCurrentConfiguration() {
    return _currentConfig ?? SSLConfig.getCurrentConfig();
  }
  
  // Test SSL pinning configuration
  static Future<Map<String, bool>> testConfiguration() async {
    final results = <String, bool>{};
    
    // Test Supabase connection
    results['supabase'] = await checkSSLPinning('https://${SSLConfig.supabaseUrl}');
    
    // Test common endpoints
    results['google'] = await checkSSLPinning('https://www.google.com');
    results['github'] = await checkSSLPinning('https://api.github.com');
    
    return results;
  }
  
  // Web-specific SSL validation
  static Future<bool> _checkWebSSL(String url, SSLEnvironmentConfig config) async {
    try {
      // For web, we can only perform basic HTTPS validation
      // The actual certificate pinning is handled by the browser
      final dio = Dio();
      dio.options.connectTimeout = Duration(seconds: config.timeoutSeconds);
      
      final response = await dio.head(url);
      final isSecure = response.statusCode != null && response.statusCode! < 400;
      
      if (config.logLevel != SSLLogLevel.none) {
        print('[Web SSL] Check for $url: ${isSecure ? 'SECURE' : 'FAILED'} - Status: ${response.statusCode}');
      }
      
      return isSecure;
    } catch (e) {
      if (config.logLevel != SSLLogLevel.none) {
        print('[Web SSL] Check failed for $url: $e');
      }
      return !config.strictMode;
    }
  }
  
  // Reset Dio instance (useful for testing or configuration changes)
  static void resetDioInstance() {
    _dioInstance?.close();
    _dioInstance = null;
  }
}

// Web-specific SSL validation interceptor
class WebSSLValidationInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    // Ensure we're only making HTTPS requests on web
    if (!options.uri.isScheme('HTTPS')) {
      handler.reject(
        DioException(
          requestOptions: options,
          message: 'Only HTTPS connections are allowed',
          type: DioExceptionType.connectionError,
        ),
      );
      return;
    }
    
    // Add security headers for web requests
    options.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
    options.headers['X-Content-Type-Options'] = 'nosniff';
    options.headers['X-Frame-Options'] = 'DENY';
    options.headers['X-XSS-Protection'] = '1; mode=block';
    
    super.onRequest(options, handler);
  }
  
  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    // Log successful HTTPS connection on web
    print('[Web SSL] Secure connection established to ${response.requestOptions.uri.host}');
    super.onResponse(response, handler);
  }
  
  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    // Log SSL/TLS errors on web
    if (err.type == DioExceptionType.connectionError) {
      print('[Web SSL] Connection error - possible SSL/TLS issue: ${err.message}');
    }
    super.onError(err, handler);
  }
}