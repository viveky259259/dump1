// Web stub for dart:io classes
class Directory {
  final String path;
  Directory(this.path);
  
  Future<bool> exists() async => false;
  Future<Directory> create({bool recursive = false}) async => this;
}

class File {
  final String path;
  File(this.path);
  
  Future<void> writeAsBytes(List<int> bytes) async {
    // No-op for web
  }
}