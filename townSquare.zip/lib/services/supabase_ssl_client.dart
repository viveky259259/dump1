import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:townsquare/services/ssl_pinning_service.dart';
import 'package:townsquare/config/ssl_config.dart';

/// Custom HTTP client for Supabase with SSL pinning support
class SupabaseSSLClient extends http.BaseClient {
  final http.Client _inner = http.Client();
  
  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    final config = SSLConfig.getCurrentConfig();
    
    // If SSL pinning is enabled, validate the certificate first
    if (config.enablePinning) {
      final isValid = await SSLPinningService.checkSSLPinning(request.url.toString());
      if (!isValid && config.strictMode) {
        throw const HttpException('SSL certificate validation failed');
      }
    }
    
    // Add custom headers
    request.headers['User-Agent'] = 'TownSquare-Flutter-App';
    
    return _inner.send(request);
  }
  
  @override
  void close() {
    _inner.close();
    super.close();
  }
}