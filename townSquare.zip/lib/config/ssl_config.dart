/// SSL Certificate Pinning Configuration
/// 
/// IMPORTANT: You need to replace these fingerprints with actual ones from your Supabase instance
/// 
/// To get the actual certificate fingerprints for your Supabase project:
/// 
/// 1. Using OpenSSL command line:
///    openssl s_client -servername YOUR_SUPABASE_URL -connect YOUR_SUPABASE_URL:443 -showcerts | openssl x509 -fingerprint -sha256 -noout
/// 
/// 2. Using online tools:
///    - Visit https://www.ssllabs.com/ssltest/ and analyze your Supabase URL
///    - Look for the SHA-256 fingerprint in the certificate details
/// 
/// 3. Using browser:
///    - Visit your Supabase URL in Chrome/Firefox
///    - Click the lock icon -> Certificate -> Details -> SHA-256 fingerprint
/// 
/// Remember to:
/// - Update fingerprints when certificates are renewed
/// - Include backup certificates if available
/// - Test thoroughly before deploying to production

class SSLConfig {
  // Your Supabase project's certificate fingerprints
  // Updated to match your actual Supabase project URL
  static const String supabaseUrl = 'gkcjbsjkpfuitnepmmod.supabase.co';
  
  // Primary certificate fingerprints for your Supabase instance
  // SSL PINNING IS CURRENTLY DISABLED - TO ENABLE:
  // 1. Get your certificate fingerprint using: 
  //    openssl s_client -servername gkcjbsjkpfuitnepmmod.supabase.co -connect gkcjbsjkpfuitnepmmod.supabase.co:443 -showcerts | openssl x509 -fingerprint -sha256 -noout
  // 2. Replace the example fingerprint below with your actual one
  // 3. Change enablePinning to true in staging/production configs
  static const List<String> supabaseFingerprints = [
    // Example fingerprint - REPLACE WITH YOUR ACTUAL SUPABASE CERTIFICATE FINGERPRINT
    '0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF',
    // Add backup/intermediate certificate fingerprints if needed
  ];
  
  // Common root CA certificates used by major hosting providers
  // These provide fallback security for various services
  static const List<String> trustedRootCAFingerprints = [
    // Let's Encrypt Authority X3 (widely used)
    '25847D668EB4F04FDD40B12B6B0740C567DA7D024308EB6C2C96FE41D9DE218D',
    
    // DigiCert Global Root CA
    '4348A0E9444C78CB265E058D5E8944B4D84F9662BD26DB257F8934A443C70161',
    
    // GlobalSign Root CA - R3
    'EB04CF5EB1F39AFA762F2BB120F296CBA520C1B97DB1589565B81CB9A17B7244',
    
    // Amazon Root CA 1 (for AWS services)
    '8ECE37A21E7AD0425044C2AB5F2FC3CB5DBE5EA2CDF0BBD0C2A4F2DC67A3D1B5',
    
    // Google Trust Services GlobalSign Root CA-R2
    '75E0ABB6138512271C04F85FDDDE38503271989BFEAF6CFD82ADE0D11C6A1AD6',
  ];
  
  // All allowed fingerprints (combines your specific certs with trusted roots)
  static List<String> get allAllowedFingerprints => [
    ...supabaseFingerprints,
    ...trustedRootCAFingerprints,
  ];
  
  // Configuration for different environments
  static SSLEnvironmentConfig get development => const SSLEnvironmentConfig(
    enablePinning: true, // Enable SSL validation in all environments
    strictMode: false,
    timeoutSeconds: 30,
    logLevel: SSLLogLevel.verbose,
  );
  
  static SSLEnvironmentConfig get staging => const SSLEnvironmentConfig(
    enablePinning: true, // Enable SSL validation for staging
    strictMode: false,
    timeoutSeconds: 30,
    logLevel: SSLLogLevel.info,
  );
  
  static SSLEnvironmentConfig get production => const SSLEnvironmentConfig(
    enablePinning: true, // Enable SSL validation for production
    strictMode: true, // Strict mode for production security
    timeoutSeconds: 15,
    logLevel: SSLLogLevel.error,
  );
  
  // Get configuration based on build mode
  static SSLEnvironmentConfig getCurrentConfig() {
    // You can customize this logic based on your build configuration
    const bool isProduction = bool.fromEnvironment('dart.vm.product');
    const bool isStaging = bool.fromEnvironment('STAGING');
    
    if (isProduction) return production;
    if (isStaging) return staging;
    return development;
  }
}

class SSLEnvironmentConfig {
  final bool enablePinning;
  final bool strictMode;
  final int timeoutSeconds;
  final SSLLogLevel logLevel;
  
  const SSLEnvironmentConfig({
    required this.enablePinning,
    required this.strictMode,
    required this.timeoutSeconds,
    required this.logLevel,
  });
}

enum SSLLogLevel {
  none,
  error,
  info,
  verbose,
}

// Instructions for getting certificate fingerprints
class SSLSetupInstructions {
  static const String instructions = '''
🔐 SSL Certificate Pinning Setup Instructions

📱 MOBILE PLATFORMS (Android/iOS):
Certificate pinning validates against specific certificate fingerprints.

🌐 WEB PLATFORM:
SSL validation relies on browser security and HTTPS enforcement.
Certificate pinning is not supported due to browser limitations.

1. GET YOUR SUPABASE CERTIFICATE FINGERPRINT (Mobile Only):
   
   Method 1 - Using OpenSSL (Recommended):
   openssl s_client -servername YOUR_PROJECT.supabase.co -connect YOUR_PROJECT.supabase.co:443 -showcerts | openssl x509 -fingerprint -sha256 -noout
   
   Method 2 - Using Browser:
   • Go to https://YOUR_PROJECT.supabase.co
   • Click the lock icon next to the URL
   • Click "Certificate" -> "Details" 
   • Look for "SHA-256 fingerprint"
   
   Method 3 - Using SSL Labs:
   • Go to https://www.ssllabs.com/ssltest/
   • Enter your Supabase URL
   • Check the certificate chain for SHA-256 fingerprint

2. UPDATE THE CONFIGURATION:
   • Replace YOUR_SUPABASE_URL in SSLConfig.supabaseUrl
   • Replace the example fingerprint in SSLConfig.supabaseFingerprints
   • Test in development first with enablePinning: false
   
3. TESTING:
   • Use the SSL pinning test utility in your app
   • Verify connections work in all environments
   • Test certificate rotation scenarios

4. PRODUCTION DEPLOYMENT:
   • Ensure you have backup certificate fingerprints (Mobile)
   • Monitor for certificate renewal dates
   • Have a rollback plan if SSL pinning fails
   • Web platform uses browser-based SSL validation

5. PLATFORM-SPECIFIC BEHAVIOR:
   📱 MOBILE: Certificate fingerprint validation
   🌐 WEB: HTTPS enforcement + security headers + browser validation

⚠️  IMPORTANT WARNINGS:
   • Wrong fingerprints will block ALL network requests (Mobile)
   • Certificate changes will require app updates (Mobile)
   • Web platform relies on browser security policies
   • Test thoroughly before production deployment
''';
}