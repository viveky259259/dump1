import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as supabase;
import 'package:townsquare/blocs/auth/auth_event.dart';
import 'package:townsquare/blocs/auth/auth_state.dart';
import 'package:townsquare/services/auth_service.dart';
import 'package:townsquare/models/user.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthService _authService;
  StreamSubscription<User?>? _userSubscription;

  AuthBloc({AuthService? authService})
      : _authService = authService ?? AuthService.instance,
        super(const AuthInitial()) {
    on<AuthInitialized>(_onAuthInitialized);
    on<AuthSignInRequested>(_onAuthSignInRequested);
    on<AuthSignUpRequested>(_onAuthSignUpRequested);
    on<AuthSignOutRequested>(_onAuthSignOutRequested);
    on<AuthUserChanged>(_onAuthUserChanged);
  }

  Future<void> _onAuthInitialized(
    AuthInitialized event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());
    
    try {
      await _authService.initialize();
      
      // Listen to user stream changes
      _userSubscription = _authService.userStream.listen((user) {
        add(AuthUserChanged(user));
      });
      
      // Check initial auth state
      final currentUser = _authService.currentUser;
      if (currentUser != null) {
        emit(AuthAuthenticated(currentUser));
      } else {
        emit(const AuthUnauthenticated());
      }
    } catch (error) {
      String errorMessage = 'Failed to initialize authentication';
      
      if (error.toString().contains('credentials not configured')) {
        errorMessage = 'Supabase credentials not configured. Please contact your administrator to set up the database connection.';
      } else if (error.toString().contains('This instance is already initialized')) {
        errorMessage = 'Authentication service initialization conflict. Please restart the app.';
      } else {
        errorMessage = 'Failed to initialize authentication: ${error.toString()}';
      }
      
      emit(AuthError(errorMessage));
    }
  }

  Future<void> _onAuthSignInRequested(
    AuthSignInRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());
    
    try {
      final result = await _authService.signIn(event.email, event.password);
      
      if (result == 'success') {
        // AuthUserChanged event will be triggered by user stream
        // Don't emit state here as it will be handled by user stream
      } else {
        emit(AuthError(result));
      }
    } catch (error) {
      emit(AuthError('Sign in failed: $error'));
    }
  }

  Future<void> _onAuthSignUpRequested(
    AuthSignUpRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());
    
    try {
      final result = await _authService.signUp(
        email: event.email,
        password: event.password,
        name: event.name,
        phone: event.phone,
        flatNumber: event.flatNumber,
        role: event.role,
      );
      
      if (result == 'success') {
        // AuthUserChanged event will be triggered by user stream
        // Don't emit state here as it will be handled by user stream
      } else {
        emit(AuthError(result));
      }
    } catch (error) {
      emit(AuthError('Sign up failed: $error'));
    }
  }

  Future<void> _onAuthSignOutRequested(
    AuthSignOutRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthLoading());
    
    try {
      await _authService.signOut();
      // AuthUserChanged event will be triggered by user stream
    } catch (error) {
      emit(AuthError('Sign out failed: $error'));
    }
  }

  void _onAuthUserChanged(
    AuthUserChanged event,
    Emitter<AuthState> emit,
  ) {
    if (event.user != null) {
      emit(AuthAuthenticated(event.user!));
    } else {
      emit(const AuthUnauthenticated());
    }
  }

  @override
  Future<void> close() {
    _userSubscription?.cancel();
    return super.close();
  }
}