import 'package:equatable/equatable.dart';
import 'package:townsquare/models/user.dart';

abstract class UserEvent extends Equatable {
  const UserEvent();

  @override
  List<Object?> get props => [];
}

class UserLoadAllRequested extends UserEvent {
  const UserLoadAllRequested();
}

class UserLoadByRoleRequested extends UserEvent {
  final UserRole role;

  const UserLoadByRoleRequested(this.role);

  @override
  List<Object?> get props => [role];
}

class UserLoadByIdRequested extends UserEvent {
  final String id;

  const UserLoadByIdRequested(this.id);

  @override
  List<Object?> get props => [id];
}

class UserRefreshRequested extends UserEvent {
  const UserRefreshRequested();
}