import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:townsquare/blocs/user/user_event.dart';
import 'package:townsquare/blocs/user/user_state.dart';
import 'package:townsquare/services/auth_service.dart';

class UserBloc extends Bloc<UserEvent, UserState> {
  final AuthService _authService;

  UserBloc({AuthService? authService})
      : _authService = authService ?? AuthService.instance,
        super(const UserInitial()) {
    on<UserLoadAllRequested>(_onUserLoadAllRequested);
    on<UserLoadByRoleRequested>(_onUserLoadByRoleRequested);
    on<UserLoadByIdRequested>(_onUserLoadByIdRequested);
    on<UserRefreshRequested>(_onUserRefreshRequested);
  }

  Future<void> _onUserLoadAllRequested(
    UserLoadAllRequested event,
    Emitter<UserState> emit,
  ) async {
    emit(const UserLoading());
    
    try {
      final users = await _authService.getAllUsers();
      emit(UserLoaded(users));
    } catch (error) {
      emit(UserError('Failed to load users: $error'));
    }
  }

  Future<void> _onUserLoadByRoleRequested(
    UserLoadByRoleRequested event,
    Emitter<UserState> emit,
  ) async {
    emit(const UserLoading());
    
    try {
      final users = await _authService.getUsersByRole(event.role);
      emit(UserLoaded(users));
    } catch (error) {
      emit(UserError('Failed to load users by role: $error'));
    }
  }

  Future<void> _onUserLoadByIdRequested(
    UserLoadByIdRequested event,
    Emitter<UserState> emit,
  ) async {
    emit(const UserLoading());
    
    try {
      final user = await _authService.getUserById(event.id);
      if (user != null) {
        emit(UserSingleLoaded(user));
      } else {
        emit(const UserError('User not found'));
      }
    } catch (error) {
      emit(UserError('Failed to load user: $error'));
    }
  }

  Future<void> _onUserRefreshRequested(
    UserRefreshRequested event,
    Emitter<UserState> emit,
  ) async {
    // Refresh the current state by re-emitting the same data
    if (state is UserLoaded) {
      add(const UserLoadAllRequested());
    }
  }
}