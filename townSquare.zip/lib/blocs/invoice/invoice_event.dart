import 'package:equatable/equatable.dart';
import 'package:townsquare/models/data_models.dart';

abstract class InvoiceEvent extends Equatable {
  const InvoiceEvent();

  @override
  List<Object?> get props => [];
}

class LoadInvoices extends InvoiceEvent {
  final String? residentId; // null for admin to load all invoices
  
  const LoadInvoices({this.residentId});

  @override
  List<Object?> get props => [residentId];
}

class GenerateInvoicesForMonth extends InvoiceEvent {
  final int month;
  final int year;
  
  const GenerateInvoicesForMonth({
    required this.month,
    required this.year,
  });

  @override
  List<Object> get props => [month, year];
}

class GenerateInvoiceForApartment extends InvoiceEvent {
  final String apartmentId;
  final int month;
  final int year;
  
  const GenerateInvoiceForApartment({
    required this.apartmentId,
    required this.month,
    required this.year,
  });

  @override
  List<Object> get props => [apartmentId, month, year];
}

class MarkInvoiceAsPaid extends InvoiceEvent {
  final String invoiceId;
  final String paymentMethod;
  
  const MarkInvoiceAsPaid({
    required this.invoiceId,
    required this.paymentMethod,
  });

  @override
  List<Object> get props => [invoiceId, paymentMethod];
}

class SendInvoiceNotification extends InvoiceEvent {
  final String invoiceId;
  final NotificationType notificationType;
  final SentVia sentVia;
  
  const SendInvoiceNotification({
    required this.invoiceId,
    required this.notificationType,
    required this.sentVia,
  });

  @override
  List<Object> get props => [invoiceId, notificationType, sentVia];
}

class LoadApartments extends InvoiceEvent {
  const LoadApartments();
}

class UpdateApartmentMaintenanceAmount extends InvoiceEvent {
  final String apartmentId;
  final double newAmount;
  
  const UpdateApartmentMaintenanceAmount({
    required this.apartmentId,
    required this.newAmount,
  });

  @override
  List<Object> get props => [apartmentId, newAmount];
}

class FilterInvoices extends InvoiceEvent {
  final InvoiceStatus? status;
  final int? month;
  final int? year;
  
  const FilterInvoices({
    this.status,
    this.month,
    this.year,
  });

  @override
  List<Object?> get props => [status, month, year];
}