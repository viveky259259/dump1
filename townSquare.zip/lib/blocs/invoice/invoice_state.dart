import 'package:equatable/equatable.dart';
import 'package:townsquare/models/data_models.dart';

abstract class InvoiceState extends Equatable {
  const InvoiceState();

  @override
  List<Object?> get props => [];
}

class InvoiceInitial extends InvoiceState {}

class InvoiceLoading extends InvoiceState {}

class InvoicesLoaded extends InvoiceState {
  final List<MaintenanceInvoice> invoices;
  final List<Apartment> apartments;
  final InvoiceStatus? filterStatus;
  final int? filterMonth;
  final int? filterYear;

  const InvoicesLoaded({
    required this.invoices,
    this.apartments = const [],
    this.filterStatus,
    this.filterMonth,
    this.filterYear,
  });

  @override
  List<Object?> get props => [invoices, apartments, filterStatus, filterMonth, filterYear];

  List<MaintenanceInvoice> get filteredInvoices {
    var filtered = invoices.toList();
    
    if (filterStatus != null) {
      filtered = filtered.where((invoice) => invoice.status == filterStatus).toList();
    }
    
    if (filterMonth != null) {
      filtered = filtered.where((invoice) => invoice.invoiceMonth == filterMonth).toList();
    }
    
    if (filterYear != null) {
      filtered = filtered.where((invoice) => invoice.invoiceYear == filterYear).toList();
    }
    
    return filtered;
  }

  double get totalUnpaidAmount {
    return filteredInvoices
        .where((invoice) => invoice.status == InvoiceStatus.unpaid)
        .fold(0.0, (sum, invoice) => sum + invoice.totalAmount);
  }

  double get totalPaidAmount {
    return filteredInvoices
        .where((invoice) => invoice.status == InvoiceStatus.paid)
        .fold(0.0, (sum, invoice) => sum + invoice.totalAmount);
  }

  int get overdueCount {
    return filteredInvoices
        .where((invoice) => invoice.isOverdue)
        .length;
  }
}

class InvoiceGenerationInProgress extends InvoiceState {}

class InvoicesGenerated extends InvoiceState {
  final int generatedCount;
  final String message;

  const InvoicesGenerated({
    required this.generatedCount,
    required this.message,
  });

  @override
  List<Object> get props => [generatedCount, message];
}

class InvoicePaymentUpdated extends InvoiceState {
  final MaintenanceInvoice updatedInvoice;
  final String message;

  const InvoicePaymentUpdated({
    required this.updatedInvoice,
    required this.message,
  });

  @override
  List<Object> get props => [updatedInvoice, message];
}

class NotificationSent extends InvoiceState {
  final String message;

  const NotificationSent({required this.message});

  @override
  List<Object> get props => [message];
}

class ApartmentUpdated extends InvoiceState {
  final Apartment updatedApartment;
  final String message;

  const ApartmentUpdated({
    required this.updatedApartment,
    required this.message,
  });

  @override
  List<Object> get props => [updatedApartment, message];
}

class InvoiceError extends InvoiceState {
  final String error;

  const InvoiceError({required this.error});

  @override
  List<Object> get props => [error];
}