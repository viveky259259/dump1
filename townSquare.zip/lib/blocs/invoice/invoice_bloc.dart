import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:townsquare/blocs/invoice/invoice_event.dart';
import 'package:townsquare/blocs/invoice/invoice_state.dart';
import 'package:townsquare/services/invoice_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InvoiceBloc extends Bloc<InvoiceEvent, InvoiceState> {
  final InvoiceService _invoiceService;

  InvoiceBloc(this._invoiceService) : super(InvoiceInitial()) {
    on<LoadInvoices>(_onLoadInvoices);
    on<LoadApartments>(_onLoadApartments);
    on<GenerateInvoicesForMonth>(_onGenerateInvoicesForMonth);
    on<GenerateInvoiceForApartment>(_onGenerateInvoiceForApartment);
    on<MarkInvoiceAsPaid>(_onMarkInvoiceAsPaid);
    on<SendInvoiceNotification>(_onSendInvoiceNotification);
    on<UpdateApartmentMaintenanceAmount>(_onUpdateApartmentMaintenanceAmount);
    on<FilterInvoices>(_onFilterInvoices);
  }

  Future<void> _onLoadInvoices(
    LoadInvoices event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      emit(InvoiceLoading());
      
      final invoices = await _invoiceService.getInvoices(residentId: event.residentId);
      final apartments = await _invoiceService.getApartments();
      
      emit(InvoicesLoaded(
        invoices: invoices,
        apartments: apartments,
      ));
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onLoadApartments(
    LoadApartments event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      emit(InvoiceLoading());
      
      final apartments = await _invoiceService.getApartments();
      final currentState = state;
      
      if (currentState is InvoicesLoaded) {
        emit(InvoicesLoaded(
          invoices: currentState.invoices,
          apartments: apartments,
          filterStatus: currentState.filterStatus,
          filterMonth: currentState.filterMonth,
          filterYear: currentState.filterYear,
        ));
      } else {
        emit(InvoicesLoaded(
          invoices: const [],
          apartments: apartments,
        ));
      }
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onGenerateInvoicesForMonth(
    GenerateInvoicesForMonth event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      emit(InvoiceGenerationInProgress());
      
      final currentUser = Supabase.instance.client.auth.currentUser;
      if (currentUser == null) {
        emit(const InvoiceError(error: 'User not authenticated'));
        return;
      }
      final currentUserId = currentUser.id;
      
      final generatedInvoices = await _invoiceService.generateInvoicesForMonth(
        event.month,
        event.year,
        currentUserId,
      );
      
      emit(InvoicesGenerated(
        generatedCount: generatedInvoices.length,
        message: 'Generated ${generatedInvoices.length} invoices for ${_getMonthName(event.month)} ${event.year}',
      ));
      
      // Reload invoices to show updated data
      add(const LoadInvoices());
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onGenerateInvoiceForApartment(
    GenerateInvoiceForApartment event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      emit(InvoiceGenerationInProgress());
      
      final currentUser = Supabase.instance.client.auth.currentUser;
      if (currentUser == null) {
        emit(const InvoiceError(error: 'User not authenticated'));
        return;
      }
      final currentUserId = currentUser.id;
      
      final invoice = await _invoiceService.generateInvoiceForApartment(
        event.apartmentId,
        event.month,
        event.year,
        currentUserId,
      );
      
      emit(InvoicesGenerated(
        generatedCount: 1,
        message: 'Invoice generated for flat ${invoice.flatNumber}',
      ));
      
      // Reload invoices to show updated data
      add(const LoadInvoices());
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onMarkInvoiceAsPaid(
    MarkInvoiceAsPaid event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      final updatedInvoice = await _invoiceService.markInvoiceAsPaid(
        event.invoiceId,
        event.paymentMethod,
      );
      
      emit(InvoicePaymentUpdated(
        updatedInvoice: updatedInvoice,
        message: 'Invoice marked as paid',
      ));
      
      // Reload invoices to show updated data
      add(const LoadInvoices());
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onSendInvoiceNotification(
    SendInvoiceNotification event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      await _invoiceService.sendInvoiceNotification(
        event.invoiceId,
        event.notificationType,
        event.sentVia,
      );
      
      emit(const NotificationSent(
        message: 'Notification sent successfully',
      ));
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onUpdateApartmentMaintenanceAmount(
    UpdateApartmentMaintenanceAmount event,
    Emitter<InvoiceState> emit,
  ) async {
    try {
      final updatedApartment = await _invoiceService.updateApartmentMaintenanceAmount(
        event.apartmentId,
        event.newAmount,
      );
      
      emit(ApartmentUpdated(
        updatedApartment: updatedApartment,
        message: 'Maintenance amount updated for flat ${updatedApartment.flatNumber}',
      ));
      
      // Reload apartments to show updated data
      add(const LoadApartments());
    } catch (e) {
      emit(InvoiceError(error: e.toString()));
    }
  }

  Future<void> _onFilterInvoices(
    FilterInvoices event,
    Emitter<InvoiceState> emit,
  ) async {
    final currentState = state;
    if (currentState is InvoicesLoaded) {
      emit(InvoicesLoaded(
        invoices: currentState.invoices,
        apartments: currentState.apartments,
        filterStatus: event.status,
        filterMonth: event.month,
        filterYear: event.year,
      ));
    }
  }

  String _getMonthName(int month) {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[month - 1];
  }
}