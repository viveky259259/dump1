class User {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String flatNumber;
  final UserRole role;
  final DateTime createdAt;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.flatNumber,
    required this.role,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'phone': phone,
        'flat_number': flatNumber,
        'role': role.name,
        'created_at': createdAt.toIso8601String(),
      };

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json['id'],
        name: json['name'],
        email: json['email'],
        phone: json['phone'],
        flatNumber: json['flat_number'] ?? json['flatNumber'],
        role: UserRole.values.firstWhere(
          (e) => e.name == json['role'] || e.toString() == json['role'],
        ),
        createdAt: DateTime.parse(json['created_at'] ?? json['createdAt']),
      );

  // Factory constructor for creating User from Supabase auth user
  factory User.fromSupabaseData(Map<String, dynamic> userData) => User(
        id: userData['id'],
        name: userData['name'],
        email: userData['email'],
        phone: userData['phone'],
        flatNumber: userData['flat_number'],
        role: UserRole.values.firstWhere(
          (e) => e.name == userData['role'],
        ),
        createdAt: DateTime.parse(userData['created_at']),
      );
}

enum UserRole { admin, resident, staff, security }

extension UserRoleExtension on UserRole {
  String get displayName {
    switch (this) {
      case UserRole.admin:
        return 'Admin';
      case UserRole.resident:
        return 'Resident';
      case UserRole.staff:
        return 'Staff';
      case UserRole.security:
        return 'Security';
    }
  }

  bool get canCreateNotices => this == UserRole.admin;
  bool get canAssignTickets => this == UserRole.admin;
  bool get canManageVisitors => this == UserRole.security || this == UserRole.admin;
}