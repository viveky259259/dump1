// Notice Board Models
class Notice {
  final String id;
  final String title;
  final String content;
  final NoticeCategory category;
  final String authorId;
  final DateTime publishDate;
  final DateTime? expiryDate;
  final bool isPinned;
  final List<String> attachments;

  Notice({
    required this.id,
    required this.title,
    required this.content,
    required this.category,
    required this.authorId,
    required this.publishDate,
    this.expiryDate,
    this.isPinned = false,
    this.attachments = const [],
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'content': content,
        'category': category.toString(),
        'authorId': authorId,
        'publishDate': publishDate.toIso8601String(),
        'expiryDate': expiryDate?.toIso8601String(),
        'isPinned': isPinned,
        'attachments': attachments,
      };

  factory Notice.fromJson(Map<String, dynamic> json) => Notice(
        id: json['id'],
        title: json['title'],
        content: json['content'],
        category: NoticeCategory.values.firstWhere(
          (e) => e.toString() == json['category'],
        ),
        authorId: json['authorId'],
        publishDate: DateTime.parse(json['publishDate']),
        expiryDate: json['expiryDate'] != null
            ? DateTime.parse(json['expiryDate'])
            : null,
        isPinned: json['isPinned'] ?? false,
        attachments: List<String>.from(json['attachments'] ?? []),
      );
}

enum NoticeCategory { general, maintenance, event, urgent }

extension NoticeCategoryExtension on NoticeCategory {
  String get displayName {
    switch (this) {
      case NoticeCategory.general:
        return 'General';
      case NoticeCategory.maintenance:
        return 'Maintenance';
      case NoticeCategory.event:
        return 'Event';
      case NoticeCategory.urgent:
        return 'Urgent';
    }
  }

  String get emoji {
    switch (this) {
      case NoticeCategory.general:
        return '📢';
      case NoticeCategory.maintenance:
        return '🔧';
      case NoticeCategory.event:
        return '🎉';
      case NoticeCategory.urgent:
        return '🚨';
    }
  }
}

// Community Forum Models
class CommunityGroup {
  final String id;
  final String name;
  final String description;
  final String createdBy;
  final bool isDefault;
  final DateTime createdAt;

  CommunityGroup({
    required this.id,
    required this.name,
    required this.description,
    required this.createdBy,
    this.isDefault = false,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'createdBy': createdBy,
        'isDefault': isDefault,
        'createdAt': createdAt.toIso8601String(),
      };

  factory CommunityGroup.fromJson(Map<String, dynamic> json) => CommunityGroup(
        id: json['id'],
        name: json['name'],
        description: json['description'],
        createdBy: json['createdBy'],
        isDefault: json['isDefault'] ?? false,
        createdAt: DateTime.parse(json['createdAt']),
      );
}

class Post {
  final String id;
  final String groupId;
  final String authorId;
  final String content;
  final List<String> attachments;
  final DateTime timestamp;
  final int likesCount;
  final List<String> likedBy;

  Post({
    required this.id,
    required this.groupId,
    required this.authorId,
    required this.content,
    this.attachments = const [],
    required this.timestamp,
    this.likesCount = 0,
    this.likedBy = const [],
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'groupId': groupId,
        'authorId': authorId,
        'content': content,
        'attachments': attachments,
        'timestamp': timestamp.toIso8601String(),
        'likesCount': likesCount,
        'likedBy': likedBy,
      };

  factory Post.fromJson(Map<String, dynamic> json) => Post(
        id: json['id'],
        groupId: json['groupId'],
        authorId: json['authorId'],
        content: json['content'],
        attachments: List<String>.from(json['attachments'] ?? []),
        timestamp: DateTime.parse(json['timestamp']),
        likesCount: json['likesCount'] ?? 0,
        likedBy: List<String>.from(json['likedBy'] ?? []),
      );
}

class Poll {
  final String id;
  final String question;
  final List<String> options;
  final DateTime startDate;
  final DateTime endDate;
  final Map<String, List<String>> votes; // option -> list of voter IDs
  final bool allowMultiple;

  Poll({
    required this.id,
    required this.question,
    required this.options,
    required this.startDate,
    required this.endDate,
    this.votes = const {},
    this.allowMultiple = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'question': question,
        'options': options,
        'startDate': startDate.toIso8601String(),
        'endDate': endDate.toIso8601String(),
        'votes': votes,
        'allowMultiple': allowMultiple,
      };

  factory Poll.fromJson(Map<String, dynamic> json) => Poll(
        id: json['id'],
        question: json['question'],
        options: List<String>.from(json['options']),
        startDate: DateTime.parse(json['startDate']),
        endDate: DateTime.parse(json['endDate']),
        votes: Map<String, List<String>>.from(
          json['votes']?.map((k, v) => MapEntry(k, List<String>.from(v))) ?? {},
        ),
        allowMultiple: json['allowMultiple'] ?? false,
      );

  bool get isActive {
    final now = DateTime.now();
    return now.isAfter(startDate) && now.isBefore(endDate);
  }

  int getTotalVotes() => votes.values.fold(0, (sum, voters) => sum + voters.length);
}

// Ticket System Models
class Ticket {
  final String id;
  final String residentId;
  final String flatNumber;
  final TicketCategory category;
  final String description;
  final List<String> attachments;
  final TicketStatus status;
  final DateTime createdAt;
  final String? assignedTo;
  final List<TicketUpdate> updates;

  Ticket({
    required this.id,
    required this.residentId,
    required this.flatNumber,
    required this.category,
    required this.description,
    this.attachments = const [],
    this.status = TicketStatus.open,
    required this.createdAt,
    this.assignedTo,
    this.updates = const [],
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'residentId': residentId,
        'flatNumber': flatNumber,
        'category': category.toString(),
        'description': description,
        'attachments': attachments,
        'status': status.toString(),
        'createdAt': createdAt.toIso8601String(),
        'assignedTo': assignedTo,
        'updates': updates.map((u) => u.toJson()).toList(),
      };

  factory Ticket.fromJson(Map<String, dynamic> json) => Ticket(
        id: json['id'],
        residentId: json['residentId'],
        flatNumber: json['flatNumber'],
        category: TicketCategory.values.firstWhere(
          (e) => e.toString() == json['category'],
        ),
        description: json['description'],
        attachments: List<String>.from(json['attachments'] ?? []),
        status: TicketStatus.values.firstWhere(
          (e) => e.toString() == json['status'],
        ),
        createdAt: DateTime.parse(json['createdAt']),
        assignedTo: json['assignedTo'],
        updates: (json['updates'] as List<dynamic>?)
                ?.map((u) => TicketUpdate.fromJson(u))
                .toList() ??
            [],
      );
}

class TicketUpdate {
  final String id;
  final String ticketId;
  final String updateType;
  final String content;
  final String updatedBy;
  final DateTime timestamp;

  TicketUpdate({
    required this.id,
    required this.ticketId,
    required this.updateType,
    required this.content,
    required this.updatedBy,
    required this.timestamp,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'ticketId': ticketId,
        'updateType': updateType,
        'content': content,
        'updatedBy': updatedBy,
        'timestamp': timestamp.toIso8601String(),
      };

  factory TicketUpdate.fromJson(Map<String, dynamic> json) => TicketUpdate(
        id: json['id'],
        ticketId: json['ticketId'],
        updateType: json['updateType'],
        content: json['content'],
        updatedBy: json['updatedBy'],
        timestamp: DateTime.parse(json['timestamp']),
      );
}

enum TicketCategory { plumbing, electrical, security, housekeeping, commonArea }

extension TicketCategoryExtension on TicketCategory {
  String get displayName {
    switch (this) {
      case TicketCategory.plumbing:
        return 'Plumbing';
      case TicketCategory.electrical:
        return 'Electrical';
      case TicketCategory.security:
        return 'Security';
      case TicketCategory.housekeeping:
        return 'Housekeeping';
      case TicketCategory.commonArea:
        return 'Common Area';
    }
  }

  String get emoji {
    switch (this) {
      case TicketCategory.plumbing:
        return '🔧';
      case TicketCategory.electrical:
        return '⚡';
      case TicketCategory.security:
        return '🛡️';
      case TicketCategory.housekeeping:
        return '🧹';
      case TicketCategory.commonArea:
        return '🏢';
    }
  }
}

enum TicketStatus { open, inProgress, resolved, closed }

extension TicketStatusExtension on TicketStatus {
  String get displayName {
    switch (this) {
      case TicketStatus.open:
        return 'Open';
      case TicketStatus.inProgress:
        return 'In Progress';
      case TicketStatus.resolved:
        return 'Resolved';
      case TicketStatus.closed:
        return 'Closed';
    }
  }
}

// Visitor Management Models
class VisitorApproval {
  final String id;
  final String residentId;
  final String flatNumber;
  final String visitorName;
  final VisitorType visitorType;
  final DateTime expectedArrival;
  final String entryCode;
  final VisitorStatus status;
  final String? company;
  final String? vehicleNumber;

  VisitorApproval({
    required this.id,
    required this.residentId,
    required this.flatNumber,
    required this.visitorName,
    required this.visitorType,
    required this.expectedArrival,
    required this.entryCode,
    this.status = VisitorStatus.expected,
    this.company,
    this.vehicleNumber,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'residentId': residentId,
        'flatNumber': flatNumber,
        'visitorName': visitorName,
        'visitorType': visitorType.toString(),
        'expectedArrival': expectedArrival.toIso8601String(),
        'entryCode': entryCode,
        'status': status.toString(),
        'company': company,
        'vehicleNumber': vehicleNumber,
      };

  factory VisitorApproval.fromJson(Map<String, dynamic> json) => VisitorApproval(
        id: json['id'],
        residentId: json['residentId'],
        flatNumber: json['flatNumber'],
        visitorName: json['visitorName'],
        visitorType: VisitorType.values.firstWhere(
          (e) => e.toString() == json['visitorType'],
        ),
        expectedArrival: DateTime.parse(json['expectedArrival']),
        entryCode: json['entryCode'],
        status: VisitorStatus.values.firstWhere(
          (e) => e.toString() == json['status'],
        ),
        company: json['company'],
        vehicleNumber: json['vehicleNumber'],
      );
}

enum VisitorType { guest, delivery, cab, other }

extension VisitorTypeExtension on VisitorType {
  String get displayName {
    switch (this) {
      case VisitorType.guest:
        return 'Guest';
      case VisitorType.delivery:
        return 'Delivery';
      case VisitorType.cab:
        return 'Cab';
      case VisitorType.other:
        return 'Other';
    }
  }

  String get emoji {
    switch (this) {
      case VisitorType.guest:
        return '👥';
      case VisitorType.delivery:
        return '📦';
      case VisitorType.cab:
        return '🚗';
      case VisitorType.other:
        return '🔄';
    }
  }
}

enum VisitorStatus { expected, arrived, departed }

class PanicAlert {
  final String id;
  final String residentId;
  final String flatNumber;
  final DateTime timestamp;
  final bool acknowledged;
  final String? acknowledgedBy;
  final DateTime? acknowledgedAt;

  PanicAlert({
    required this.id,
    required this.residentId,
    required this.flatNumber,
    required this.timestamp,
    this.acknowledged = false,
    this.acknowledgedBy,
    this.acknowledgedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'residentId': residentId,
        'flatNumber': flatNumber,
        'timestamp': timestamp.toIso8601String(),
        'acknowledged': acknowledged,
        'acknowledgedBy': acknowledgedBy,
        'acknowledgedAt': acknowledgedAt?.toIso8601String(),
      };

  factory PanicAlert.fromJson(Map<String, dynamic> json) => PanicAlert(
        id: json['id'],
        residentId: json['residentId'],
        flatNumber: json['flatNumber'],
        timestamp: DateTime.parse(json['timestamp']),
        acknowledged: json['acknowledged'] ?? false,
        acknowledgedBy: json['acknowledgedBy'],
        acknowledgedAt: json['acknowledgedAt'] != null
            ? DateTime.parse(json['acknowledgedAt'])
            : null,
      );
}

// Apartment Management Models
class Apartment {
  final String id;
  final String flatNumber;
  final String? ownerId;
  final String? tenantId;
  final double maintenanceAmount;
  final int floorNumber;
  final BhkType bhkType;
  final double? carpetArea;
  final bool isOccupied;
  final DateTime createdAt;
  final DateTime updatedAt;

  Apartment({
    required this.id,
    required this.flatNumber,
    this.ownerId,
    this.tenantId,
    required this.maintenanceAmount,
    required this.floorNumber,
    required this.bhkType,
    this.carpetArea,
    this.isOccupied = false,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'flat_number': flatNumber,
        'owner_id': ownerId,
        'tenant_id': tenantId,
        'maintenance_amount': maintenanceAmount,
        'floor_number': floorNumber,
        'bhk_type': bhkType.name.toUpperCase(),
        'carpet_area': carpetArea,
        'is_occupied': isOccupied,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory Apartment.fromJson(Map<String, dynamic> json) => Apartment(
        id: json['id'],
        flatNumber: json['flat_number'],
        ownerId: json['owner_id'],
        tenantId: json['tenant_id'],
        maintenanceAmount: double.parse(json['maintenance_amount'].toString()),
        floorNumber: json['floor_number'],
        bhkType: _parseBhkType(json['bhk_type']),
        carpetArea: json['carpet_area'] != null
            ? double.parse(json['carpet_area'].toString())
            : null,
        isOccupied: json['is_occupied'] ?? false,
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  String get residentId => tenantId ?? ownerId ?? '';

  static BhkType _parseBhkType(String bhkString) {
    switch (bhkString.toUpperCase()) {
      case '1BHK':
        return BhkType.bhk1;
      case '2BHK':
        return BhkType.bhk2;
      case '3BHK':
        return BhkType.bhk3;
      case '4BHK':
        return BhkType.bhk4;
      case 'STUDIO':
        return BhkType.studio;
      case 'PENTHOUSE':
        return BhkType.penthouse;
      default:
        return BhkType.bhk2; // default fallback
    }
  }
}

enum BhkType { bhk1, bhk2, bhk3, bhk4, studio, penthouse }

extension BhkTypeExtension on BhkType {
  String get displayName {
    switch (this) {
      case BhkType.bhk1:
        return '1BHK';
      case BhkType.bhk2:
        return '2BHK';
      case BhkType.bhk3:
        return '3BHK';
      case BhkType.bhk4:
        return '4BHK';
      case BhkType.studio:
        return 'Studio';
      case BhkType.penthouse:
        return 'Penthouse';
    }
  }
}

// Invoice Management Models
class MaintenanceInvoice {
  final String id;
  final String invoiceNumber;
  final String apartmentId;
  final String residentId;
  final String flatNumber;
  final int invoiceMonth;
  final int invoiceYear;
  final double maintenanceAmount;
  final DateTime dueDate;
  final InvoiceStatus status;
  final DateTime? paymentDate;
  final String? paymentMethod;
  final double lateFee;
  final double totalAmount;
  final String generatedBy;
  final DateTime createdAt;
  final DateTime updatedAt;

  MaintenanceInvoice({
    required this.id,
    required this.invoiceNumber,
    required this.apartmentId,
    required this.residentId,
    required this.flatNumber,
    required this.invoiceMonth,
    required this.invoiceYear,
    required this.maintenanceAmount,
    required this.dueDate,
    this.status = InvoiceStatus.unpaid,
    this.paymentDate,
    this.paymentMethod,
    this.lateFee = 0.0,
    required this.totalAmount,
    required this.generatedBy,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'invoice_number': invoiceNumber,
        'apartment_id': apartmentId,
        'resident_id': residentId,
        'flat_number': flatNumber,
        'invoice_month': invoiceMonth,
        'invoice_year': invoiceYear,
        'maintenance_amount': maintenanceAmount,
        'due_date': dueDate.toIso8601String().split('T')[0],
        'status': status.name,
        'payment_date': paymentDate?.toIso8601String(),
        'payment_method': paymentMethod,
        'late_fee': lateFee,
        'total_amount': totalAmount,
        'generated_by': generatedBy,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory MaintenanceInvoice.fromJson(Map<String, dynamic> json) => MaintenanceInvoice(
        id: json['id'],
        invoiceNumber: json['invoice_number'],
        apartmentId: json['apartment_id'],
        residentId: json['resident_id'],
        flatNumber: json['flat_number'],
        invoiceMonth: json['invoice_month'],
        invoiceYear: json['invoice_year'],
        maintenanceAmount: double.parse(json['maintenance_amount'].toString()),
        dueDate: DateTime.parse(json['due_date']),
        status: InvoiceStatus.values.firstWhere(
          (e) => e.name == json['status'],
          orElse: () => InvoiceStatus.unpaid,
        ),
        paymentDate: json['payment_date'] != null
            ? DateTime.parse(json['payment_date'])
            : null,
        paymentMethod: json['payment_method'],
        lateFee: double.parse((json['late_fee'] ?? 0).toString()),
        totalAmount: double.parse(json['total_amount'].toString()),
        generatedBy: json['generated_by'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
      );

  String get monthName {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[invoiceMonth - 1];
  }

  bool get isOverdue => status == InvoiceStatus.unpaid && DateTime.now().isAfter(dueDate);

  MaintenanceInvoice copyWith({
    String? id,
    String? invoiceNumber,
    String? apartmentId,
    String? residentId,
    String? flatNumber,
    int? invoiceMonth,
    int? invoiceYear,
    double? maintenanceAmount,
    DateTime? dueDate,
    InvoiceStatus? status,
    DateTime? paymentDate,
    String? paymentMethod,
    double? lateFee,
    double? totalAmount,
    String? generatedBy,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return MaintenanceInvoice(
      id: id ?? this.id,
      invoiceNumber: invoiceNumber ?? this.invoiceNumber,
      apartmentId: apartmentId ?? this.apartmentId,
      residentId: residentId ?? this.residentId,
      flatNumber: flatNumber ?? this.flatNumber,
      invoiceMonth: invoiceMonth ?? this.invoiceMonth,
      invoiceYear: invoiceYear ?? this.invoiceYear,
      maintenanceAmount: maintenanceAmount ?? this.maintenanceAmount,
      dueDate: dueDate ?? this.dueDate,
      status: status ?? this.status,
      paymentDate: paymentDate ?? this.paymentDate,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      lateFee: lateFee ?? this.lateFee,
      totalAmount: totalAmount ?? this.totalAmount,
      generatedBy: generatedBy ?? this.generatedBy,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

enum InvoiceStatus { unpaid, paid, overdue }

extension InvoiceStatusExtension on InvoiceStatus {
  String get displayName {
    switch (this) {
      case InvoiceStatus.unpaid:
        return 'Unpaid';
      case InvoiceStatus.paid:
        return 'Paid';
      case InvoiceStatus.overdue:
        return 'Overdue';
    }
  }
}

class InvoiceNotification {
  final String id;
  final String invoiceId;
  final String residentId;
  final NotificationType notificationType;
  final SentVia sentVia;
  final NotificationStatus status;
  final String message;
  final DateTime sentAt;

  InvoiceNotification({
    required this.id,
    required this.invoiceId,
    required this.residentId,
    required this.notificationType,
    required this.sentVia,
    this.status = NotificationStatus.sent,
    required this.message,
    required this.sentAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'invoice_id': invoiceId,
        'resident_id': residentId,
        'notification_type': notificationType.name,
        'sent_via': _convertSentViaToDb(sentVia),
        'status': status.name,
        'message': message,
        'sent_at': sentAt.toIso8601String(),
      };

  static String _convertSentViaToDb(SentVia sentVia) {
    switch (sentVia) {
      case SentVia.inApp:
        return 'in_app';
      case SentVia.email:
        return 'email';
      case SentVia.sms:
        return 'sms';
    }
  }

  factory InvoiceNotification.fromJson(Map<String, dynamic> json) => InvoiceNotification(
        id: json['id'],
        invoiceId: json['invoice_id'],
        residentId: json['resident_id'],
        notificationType: NotificationType.values.firstWhere(
          (e) => e.name == json['notification_type'],
        ),
        sentVia: _convertDbToSentVia(json['sent_via']),
        status: NotificationStatus.values.firstWhere(
          (e) => e.name == json['status'],
          orElse: () => NotificationStatus.sent,
        ),
        message: json['message'],
        sentAt: DateTime.parse(json['sent_at']),
      );

  static SentVia _convertDbToSentVia(String dbValue) {
    switch (dbValue) {
      case 'in_app':
        return SentVia.inApp;
      case 'email':
        return SentVia.email;
      case 'sms':
        return SentVia.sms;
      default:
        return SentVia.inApp; // fallback
    }
  }
}

enum NotificationType { generated, reminder, overdue }
enum SentVia { inApp, email, sms }
enum NotificationStatus { sent, delivered, failed }