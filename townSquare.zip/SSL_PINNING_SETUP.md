# SSL Pinning Setup Guide

## 🔐 Overview

SSL Certificate Pinning has been implemented in your TownSquare Flutter app to protect against man-in-the-middle attacks. This guide will help you configure it properly.

## 📋 Current Status

✅ **Implemented Components:**
- SSL Pinning Service with Dio HTTP client
- Certificate validation using `http_certificate_pinning` package
- Environment-based configuration (development/staging/production)
- Debug tools for testing and validation
- Secure HTTP service wrapper

⚠️ **Requires Configuration:**
- Your Supabase project's certificate fingerprints
- Production environment testing

## 🚀 Quick Setup

### 1. Get Your Supabase Certificate Fingerprint

**Method A - Using OpenSSL (Recommended):**
```bash
openssl s_client -servername YOUR_PROJECT.supabase.co -connect YOUR_PROJECT.supabase.co:443 -showcerts | openssl x509 -fingerprint -sha256 -noout
```

**Method B - Using Browser:**
1. Visit your Supabase dashboard URL: `https://YOUR_PROJECT.supabase.co`
2. Click the lock icon in the address bar
3. Click "Certificate" → "Details"
4. Copy the SHA-256 fingerprint

**Method C - Using SSL Labs:**
1. Go to https://www.ssllabs.com/ssltest/
2. Enter your Supabase URL
3. Find the SHA-256 fingerprint in certificate details

### 2. Update Configuration

Edit `lib/config/ssl_config.dart`:

```dart
class SSLConfig {
  // Replace with your actual Supabase URL
  static const String supabaseUrl = 'YOUR_PROJECT.supabase.co';
  
  // Replace with your actual certificate fingerprint
  static const List<String> supabaseFingerprints = [
    'YOUR_ACTUAL_CERTIFICATE_FINGERPRINT_HERE',
    // Add backup certificates if available
  ];
}
```

### 3. Test the Configuration

**In Debug Mode:**
1. Run the app in debug mode
2. Look for the bug icon (🐛) in the AppBar
3. Tap "SSL Debug" to access testing tools
4. Run tests to verify configuration

**Programmatically:**
```dart
// Test SSL pinning
final results = await SSLPinningService.testConfiguration();
print('SSL Tests: $results');
```

## 🏗️ Architecture

### Environment Configuration

- **Development**: SSL pinning disabled for easier testing
- **Staging**: SSL pinning enabled with warnings
- **Production**: SSL pinning enforced strictly

### Key Files

```
lib/
├── config/ssl_config.dart          # Certificate fingerprints and settings
├── services/ssl_pinning_service.dart # Core SSL pinning implementation
├── services/secure_http_service.dart # HTTP client wrapper
├── utils/ssl_pinning_utils.dart     # Utility functions
└── screens/ssl_debug_screen.dart    # Debug tools (debug builds only)
```

## 🔧 Configuration Options

### SSL Environment Settings

```dart
// lib/config/ssl_config.dart
static SSLEnvironmentConfig get production => const SSLEnvironmentConfig(
  enablePinning: true,    // Enable SSL pinning
  strictMode: true,       // Fail if certificate doesn't match
  timeoutSeconds: 15,     # Connection timeout
  logLevel: SSLLogLevel.error, # Logging level
);
```

### Custom Configuration

```dart
// Set custom SSL configuration
SSLPinningService.setConfiguration(SSLEnvironmentConfig(
  enablePinning: true,
  strictMode: false,
  timeoutSeconds: 30,
  logLevel: SSLLogLevel.verbose,
));
```

## 🧪 Testing

### Debug Tools

Access the SSL Debug Screen through:
1. Debug menu (🐛 icon) in development builds
2. Navigate to `SSLDebugScreen` programmatically

**Available Tests:**
- Supabase connection validation
- Custom URL testing
- Certificate fingerprint extraction
- Configuration verification

### Manual Testing

```dart
// Test specific URL
final isSecure = await SSLPinningService.checkSSLPinning('https://example.com');

// Test all configured endpoints
final results = await SSLPinningService.testConfiguration();

// Get certificate info
final fingerprints = await SSLPinningUtils.extractCertificateFingerprints('example.com');
```

## 🚨 Important Warnings

### Certificate Lifecycle Management

⚠️ **CRITICAL**: SSL certificates expire and get renewed regularly (typically every 90 days for Let's Encrypt).

**Best Practices:**
1. **Monitor certificate expiration dates**
2. **Have backup/intermediate certificate fingerprints**
3. **Test certificate updates in staging first**
4. **Plan for emergency certificate updates**

### Production Deployment

✅ **Before deploying to production:**
1. Test SSL pinning with actual production certificates
2. Verify all network requests work correctly
3. Have a rollback plan if SSL pinning fails
4. Monitor app connectivity post-deployment

❌ **Never:**
- Deploy without testing certificate fingerprints
- Use development certificates in production
- Ignore SSL pinning test failures

## 🆘 Troubleshooting

### Common Issues

**1. "SSL certificate validation failed"**
- Check if certificate fingerprints are correct
- Verify the Supabase URL is accessible
- Ensure certificates haven't expired

**2. "Connection error - SSL pinning may have failed"**
- Test with SSL pinning disabled first
- Check network connectivity
- Verify certificate fingerprints match

**3. All network requests failing**
- Wrong certificate fingerprints
- Certificate has been renewed
- Network connectivity issues

### Debug Steps

1. **Check logs**: Look for `[SSL Pinning]` messages
2. **Use debug tools**: Access SSL Debug Screen
3. **Test manually**: Use browser to verify certificate
4. **Disable temporarily**: Set `enablePinning: false` for testing

### Emergency Disable

If SSL pinning is blocking all requests in production:

```dart
// Temporary fix - disable SSL pinning
SSLPinningService.setConfiguration(SSLEnvironmentConfig(
  enablePinning: false,
  strictMode: false,
  timeoutSeconds: 30,
  logLevel: SSLLogLevel.error,
));
```

## 📞 Support

For issues with SSL pinning implementation:
1. Check the debug screen for detailed error messages
2. Verify certificate fingerprints using multiple methods
3. Test with different network conditions
4. Review server certificate configuration

Remember: SSL pinning enhances security but requires careful certificate lifecycle management.