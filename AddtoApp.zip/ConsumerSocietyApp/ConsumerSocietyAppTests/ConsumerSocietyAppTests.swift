//
//  ConsumerSocietyAppTests.swift
//  ConsumerSocietyAppTests
//
//  Created by Vivek Yadav on 27/06/25.
//

import Testing

struct ConsumerSocietyAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
