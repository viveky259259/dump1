//
//  ConsumerSocietyAppApp.swift
//  ConsumerSocietyApp
//
//  Created by Vivek Yadav on 27/06/25.
//

import SwiftUI

import Flutter
// The following library connects plugins with iOS platform code to this app.
import FlutterPluginRegistrant

@Observable
class FlutterDependencies {
 let flutterEngine = FlutterEngine(name: "my flutter engine")
 init() {
   // Runs the default Dart entrypoint with a default Flutter route.
   flutterEngine.run()
   // Connects plugins with iOS platform code to this app.
   GeneratedPluginRegistrant.register(with: self.flutterEngine);
 }
}
@Observable
class AppDelegate: FlutterAppDelegate {
  let flutterEngine = FlutterEngine(name: "my flutter engine")

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      // Runs the default Dart entrypoint with a default Flutter route.
      flutterEngine.run();
      // Used to connect plugins (only if you have plugins with iOS platform code).
      GeneratedPluginRegistrant.register(with: self.flutterEngine);
      return true;
    }
}

@main
struct ConsumerSocietyAppApp: App {
    // flutterDependencies will be injected through the view environment.
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    @State var flutterDependencies = FlutterDependencies()
    var body: some Scene {
        WindowGroup {
            ContentView()
                     .environment(flutterDependencies)
        }
    }
}
