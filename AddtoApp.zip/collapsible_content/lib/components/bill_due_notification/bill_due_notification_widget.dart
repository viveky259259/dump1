import '/components/primary_button/primary_button_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'bill_due_notification_model.dart';
export 'bill_due_notification_model.dart';

class BillDueNotificationWidget extends StatefulWidget {
  const BillDueNotificationWidget({super.key});

  @override
  State<BillDueNotificationWidget> createState() =>
      _BillDueNotificationWidgetState();
}

class _BillDueNotificationWidgetState extends State<BillDueNotificationWidget> {
  late BillDueNotificationModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BillDueNotificationModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: Image.network(
            'https://picsum.photos/seed/109/600',
            width: 48.0,
            height: 48.0,
            fit: BoxFit.cover,
          ),
        ),
        Text(
          '₹ 45000 Maintenance Bill',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                font: GoogleFonts.spaceGrotesk(
                  fontWeight:
                      FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                ),
                letterSpacing: 0.0,
                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
              ),
        ),
        Text(
          'Due in 3 Days',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                font: GoogleFonts.spaceGrotesk(
                  fontWeight:
                      FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                ),
                letterSpacing: 0.0,
                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
              ),
        ),
        wrapWithModel(
          model: _model.primaryButtonModel,
          updateCallback: () => safeSetState(() {}),
          child: PrimaryButtonWidget(),
        ),
      ],
    );
  }
}
