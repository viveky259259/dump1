import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/society_action_item/society_action_item_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'homepage_society_action_model.dart';
export 'homepage_society_action_model.dart';

class HomepageSocietyActionWidget extends StatefulWidget {
  const HomepageSocietyActionWidget({super.key});

  @override
  State<HomepageSocietyActionWidget> createState() =>
      _HomepageSocietyActionWidgetState();
}

class _HomepageSocietyActionWidgetState
    extends State<HomepageSocietyActionWidget> with TickerProviderStateMixin {
  late HomepageSocietyActionModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomepageSocietyActionModel());

    animationsMap.addAll({
      'gridViewOnActionTriggerAnimation': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.easeOut,
            delay: 0.0.ms,
            duration: 340.0.ms,
            begin: Offset(1.0, 1.0),
            end: Offset(1.0, 1.1),
          ),
          ScaleEffect(
            curve: Curves.easeIn,
            delay: 0.0.ms,
            duration: 340.0.ms,
            begin: Offset(1.0, 1.1),
            end: Offset(1.0, 0.9),
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Padding(
      padding: EdgeInsets.all(12.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              blurRadius: 4.0,
              color: Color(0x33000000),
              offset: Offset(
                0.0,
                2.0,
              ),
            )
          ],
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Society Actions',
                    style: FlutterFlowTheme.of(context).titleLarge.override(
                          font: GoogleFonts.plusJakartaSans(
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontStyle,
                          ),
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleLarge
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleLarge.fontStyle,
                        ),
                  ),
                  InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      context.pushNamed(SocietyActionPageWidget.routeName);
                    },
                    child: Text(
                      'See All',
                      style: FlutterFlowTheme.of(context).labelLarge.override(
                            font: GoogleFonts.spaceGrotesk(
                              fontWeight: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .fontStyle,
                            ),
                            letterSpacing: 0.0,
                            fontWeight: FlutterFlowTheme.of(context)
                                .labelLarge
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .labelLarge
                                .fontStyle,
                          ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                child: Builder(
                  builder: (context) {
                    final eachSocietyAction = (_model.isCollapsed
                            ? functions.addExpansionItem(
                                FFAppState().societyActions.take(7).toList(),
                                FFAppState().societyActionExpansionItem)
                            : FFAppState().societyActions)
                        .toList();

                    return GridView.builder(
                      padding: EdgeInsets.zero,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        crossAxisSpacing: 16.0,
                        mainAxisSpacing: 16.0,
                        childAspectRatio: 0.6,
                      ),
                      primary: false,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      itemCount: eachSocietyAction.length,
                      itemBuilder: (context, eachSocietyActionIndex) {
                        final eachSocietyActionItem =
                            eachSocietyAction[eachSocietyActionIndex];
                        return SocietyActionItemWidget(
                          key: Key(
                              'Keyrp0_${eachSocietyActionIndex}_of_${eachSocietyAction.length}'),
                          societyAction: eachSocietyActionItem,
                          onTap: () async {
                            if (eachSocietyActionItem.type ==
                                SocietyActionType.expansion) {
                              _model.isCollapsed = false;
                              safeSetState(() {});
                              if (animationsMap[
                                      'gridViewOnActionTriggerAnimation'] !=
                                  null) {
                                await animationsMap[
                                        'gridViewOnActionTriggerAnimation']!
                                    .controller
                                    .forward(from: 0.0);
                              }
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Coming soon...',
                                    style: TextStyle(
                                      color: FlutterFlowTheme.of(context)
                                          .primaryText,
                                    ),
                                  ),
                                  duration: Duration(milliseconds: 4000),
                                  backgroundColor:
                                      FlutterFlowTheme.of(context).secondary,
                                ),
                              );
                            }
                          },
                        );
                      },
                    ).animateOnActionTrigger(
                      animationsMap['gridViewOnActionTriggerAnimation']!,
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
