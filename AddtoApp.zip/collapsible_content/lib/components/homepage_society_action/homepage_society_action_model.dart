import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/components/society_action_item/society_action_item_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'homepage_society_action_widget.dart' show HomepageSocietyActionWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomepageSocietyActionModel
    extends FlutterFlowModel<HomepageSocietyActionWidget> {
  ///  Local state fields for this component.

  bool isCollapsed = true;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
