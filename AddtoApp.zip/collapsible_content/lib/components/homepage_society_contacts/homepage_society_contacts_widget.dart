import '/backend/schema/structs/index.dart';
import '/components/choice_chips/choice_chips_widget.dart';
import '/components/society_contact_item/society_contact_item_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'homepage_society_contacts_model.dart';
export 'homepage_society_contacts_model.dart';

class HomepageSocietyContactsWidget extends StatefulWidget {
  const HomepageSocietyContactsWidget({super.key});

  @override
  State<HomepageSocietyContactsWidget> createState() =>
      _HomepageSocietyContactsWidgetState();
}

class _HomepageSocietyContactsWidgetState
    extends State<HomepageSocietyContactsWidget> {
  late HomepageSocietyContactsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomepageSocietyContactsModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(12.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              blurRadius: 4.0,
              color: Color(0x33000000),
              offset: Offset(
                0.0,
                2.0,
              ),
            )
          ],
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 16.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Society contacts',
                      style: FlutterFlowTheme.of(context).titleLarge.override(
                            font: GoogleFonts.plusJakartaSans(
                              fontWeight: FlutterFlowTheme.of(context)
                                  .titleLarge
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .titleLarge
                                  .fontStyle,
                            ),
                            letterSpacing: 0.0,
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontStyle,
                          ),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        context.pushNamed(SocietyContactsPageWidget.routeName);
                      },
                      child: Text(
                        'See All',
                        style: FlutterFlowTheme.of(context).labelLarge.override(
                              font: GoogleFonts.spaceGrotesk(
                                fontWeight: FlutterFlowTheme.of(context)
                                    .labelLarge
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .labelLarge
                                    .fontStyle,
                              ),
                              letterSpacing: 0.0,
                              fontWeight: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .fontStyle,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 16.0),
                child: wrapWithModel(
                  model: _model.choiceChipsModel,
                  updateCallback: () => safeSetState(() {}),
                  child: ChoiceChipsWidget(
                    choices: functions
                        .getContacts(FFAppConstants.contactsData)
                        .map((e) => e.contactGroup)
                        .toList(),
                  ),
                ),
              ),
              Builder(
                builder: (context) {
                  final eachContact = functions
                      .getContacts(FFAppConstants.contactsData)
                      .toList()
                      .take(3)
                      .toList();

                  return Column(
                    mainAxisSize: MainAxisSize.max,
                    children:
                        List.generate(eachContact.length, (eachContactIndex) {
                      final eachContactItem = eachContact[eachContactIndex];
                      return SocietyContactItemWidget(
                        key: Key(
                            'Keyj7s_${eachContactIndex}_of_${eachContact.length}'),
                        contact: eachContactItem,
                      );
                    })
                            .divide(SizedBox(height: 16.0))
                            .around(SizedBox(height: 16.0)),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
