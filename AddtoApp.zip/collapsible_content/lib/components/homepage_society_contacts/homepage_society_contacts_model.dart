import '/backend/schema/structs/index.dart';
import '/components/choice_chips/choice_chips_widget.dart';
import '/components/society_contact_item/society_contact_item_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'homepage_society_contacts_widget.dart'
    show HomepageSocietyContactsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomepageSocietyContactsModel
    extends FlutterFlowModel<HomepageSocietyContactsWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for ChoiceChips component.
  late ChoiceChipsModel choiceChipsModel;

  @override
  void initState(BuildContext context) {
    choiceChipsModel = createModel(context, () => ChoiceChipsModel());
  }

  @override
  void dispose() {
    choiceChipsModel.dispose();
  }
}
