import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'society_action_item_model.dart';
export 'society_action_item_model.dart';

class SocietyActionItemWidget extends StatefulWidget {
  const SocietyActionItemWidget({
    super.key,
    required this.societyAction,
    required this.onTap,
  });

  final SocietyActionModelStruct? societyAction;
  final Future Function()? onTap;

  @override
  State<SocietyActionItemWidget> createState() =>
      _SocietyActionItemWidgetState();
}

class _SocietyActionItemWidgetState extends State<SocietyActionItemWidget> {
  late SocietyActionItemModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SocietyActionItemModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        await widget.onTap?.call();
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
            child: Builder(
              builder: (context) {
                if (widget!.societyAction?.type ==
                    SocietyActionType.expansion) {
                  return FaIcon(
                    FontAwesomeIcons.caretSquareDown,
                    color: FlutterFlowTheme.of(context).primaryText,
                    size: 24.0,
                  );
                } else {
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.network(
                      widget!.societyAction!.icon,
                      width: 24.0,
                      height: 24.0,
                      fit: BoxFit.fill,
                    ),
                  );
                }
              },
            ),
          ),
          Text(
            widget!.societyAction!.name,
            textAlign: TextAlign.center,
            maxLines: 2,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  font: GoogleFonts.spaceGrotesk(
                    fontWeight:
                        FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                ),
          ),
        ],
      ),
    );
  }
}
