import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'choice_chips_model.dart';
export 'choice_chips_model.dart';

/// Create a component like choice chips
///
class ChoiceChipsWidget extends StatefulWidget {
  const ChoiceChipsWidget({
    super.key,
    required this.choices,
  });

  final List<String>? choices;

  @override
  State<ChoiceChipsWidget> createState() => _ChoiceChipsWidgetState();
}

class _ChoiceChipsWidgetState extends State<ChoiceChipsWidget> {
  late ChoiceChipsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChoiceChipsModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 36.0,
      decoration: BoxDecoration(),
      child: Builder(
        builder: (context) {
          final eachChoice = widget!.choices!.toList();

          return ListView.separated(
            padding: EdgeInsets.zero,
            primary: false,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: eachChoice.length,
            separatorBuilder: (_, __) => SizedBox(width: 16.0),
            itemBuilder: (context, eachChoiceIndex) {
              final eachChoiceItem = eachChoice[eachChoiceIndex];
              return InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  _model.selectedChoice = eachChoiceItem;
                  safeSetState(() {});
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: _model.selectedChoice == eachChoiceItem
                        ? Color(0x510299FF)
                        : Color(0x00FFFFFF),
                    borderRadius: BorderRadius.circular(24.0),
                    border: Border.all(
                      color: _model.selectedChoice == eachChoiceItem
                          ? Color(0xA90299FF)
                          : Color(0x53677681),
                    ),
                  ),
                  child: Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 4.0, 24.0, 4.0),
                      child: Text(
                        eachChoiceItem,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.spaceGrotesk(
                                fontWeight: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontStyle,
                              ),
                              letterSpacing: 0.0,
                              fontWeight: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
