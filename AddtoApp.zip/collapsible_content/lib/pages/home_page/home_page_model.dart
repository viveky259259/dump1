import '/components/homepage_society_action/homepage_society_action_widget.dart';
import '/components/homepage_society_contacts/homepage_society_contacts_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  bool isCollapsed = true;

  int? itemsPerRow = 4;

  ///  State fields for stateful widgets in this page.

  // Model for HomepageSocietyAction component.
  late HomepageSocietyActionModel homepageSocietyActionModel;
  // Model for HomepageSocietyContacts component.
  late HomepageSocietyContactsModel homepageSocietyContactsModel;

  @override
  void initState(BuildContext context) {
    homepageSocietyActionModel =
        createModel(context, () => HomepageSocietyActionModel());
    homepageSocietyContactsModel =
        createModel(context, () => HomepageSocietyContactsModel());
  }

  @override
  void dispose() {
    homepageSocietyActionModel.dispose();
    homepageSocietyContactsModel.dispose();
  }
}
