import '/backend/schema/structs/index.dart';
import '/components/society_contact_item/society_contact_item_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'society_contacts_page_model.dart';
export 'society_contacts_page_model.dart';

class SocietyContactsPageWidget extends StatefulWidget {
  const SocietyContactsPageWidget({super.key});

  static String routeName = 'SocietyContactsPage';
  static String routePath = '/societyContactsPage';

  @override
  State<SocietyContactsPageWidget> createState() =>
      _SocietyContactsPageWidgetState();
}

class _SocietyContactsPageWidgetState extends State<SocietyContactsPageWidget> {
  late SocietyContactsPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SocietyContactsPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Contacts',
            style: FlutterFlowTheme.of(context).headlineLarge.override(
                  font: GoogleFonts.plusJakartaSans(
                    fontWeight: FontWeight.w600,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineLarge.fontStyle,
                  ),
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.w600,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineLarge.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
            child: Builder(
              builder: (context) {
                final eachContact =
                    functions.getContacts(FFAppConstants.contactsData).toList();

                return ListView.separated(
                  padding: EdgeInsets.symmetric(vertical: 16.0),
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  itemCount: eachContact.length,
                  separatorBuilder: (_, __) => SizedBox(height: 16.0),
                  itemBuilder: (context, eachContactIndex) {
                    final eachContactItem = eachContact[eachContactIndex];
                    return SocietyContactItemWidget(
                      key: Key(
                          'Keyfzd_${eachContactIndex}_of_${eachContact.length}'),
                      contact: eachContactItem,
                    );
                  },
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
