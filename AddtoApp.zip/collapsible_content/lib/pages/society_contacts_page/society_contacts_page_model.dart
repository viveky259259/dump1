import '/backend/schema/structs/index.dart';
import '/components/society_contact_item/society_contact_item_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'society_contacts_page_widget.dart' show SocietyContactsPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SocietyContactsPageModel
    extends FlutterFlowModel<SocietyContactsPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
