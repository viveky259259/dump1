import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';

List<SocietyActionModelStruct> addExpansionItem(
  List<SocietyActionModelStruct> societyActions,
  SocietyActionModelStruct expansionItem,
) {
  return [...societyActions, expansionItem];
}

List<SocietyContactModelStruct> getContacts(String contactString) {
  try {
    // Parse the JSON string
    List<dynamic> contactsJson = jsonDecode(contactString);

    List<SocietyContactModelStruct> societyContacts =
        contactsJson.map((contactJson) {
      return SocietyContactModelStruct.fromSerializableMap({
        'image_url': contactJson['image_url'] ?? '', // Using image_url as name
        'label_text':
            contactJson['label_text'] ?? '', // Using phone as URL field
        'contact_name': contactJson['contact_name'] ?? '',

        'contact_number': contactJson['contact_number'],
        'contact_group': contactJson['contact_group'],
      });
    }).toList();

    return societyContacts;
  } catch (e) {
    throw Exception('Failed to convert contacts data: $e');
  }
}

String convertStringToImagePath(String url) {
  return url;
}
