import 'package:collection/collection.dart';

enum SocietyActionType {
  external_url,
  internal_navigation,
  expansion,
}

enum CtaAction {
  payment,
  navigation,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (SocietyActionType):
      return SocietyActionType.values.deserialize(value) as T?;
    case (CtaAction):
      return CtaAction.values.deserialize(value) as T?;
    default:
      return null;
  }
}
