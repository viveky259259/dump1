// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SocietyContactModelStruct extends BaseStruct {
  SocietyContactModelStruct({
    String? imageUrl,
    String? labelText,
    String? contactName,
    String? contactNumber,
    String? contactGroup,
  })  : _imageUrl = imageUrl,
        _labelText = labelText,
        _contactName = contactName,
        _contactNumber = contactNumber,
        _contactGroup = contactGroup;

  // "image_url" field.
  String? _imageUrl;
  String get imageUrl => _imageUrl ?? '';
  set imageUrl(String? val) => _imageUrl = val;

  bool hasImageUrl() => _imageUrl != null;

  // "label_text" field.
  String? _labelText;
  String get labelText => _labelText ?? '';
  set labelText(String? val) => _labelText = val;

  bool hasLabelText() => _labelText != null;

  // "contact_name" field.
  String? _contactName;
  String get contactName => _contactName ?? '';
  set contactName(String? val) => _contactName = val;

  bool hasContactName() => _contactName != null;

  // "contact_number" field.
  String? _contactNumber;
  String get contactNumber => _contactNumber ?? '';
  set contactNumber(String? val) => _contactNumber = val;

  bool hasContactNumber() => _contactNumber != null;

  // "contact_group" field.
  String? _contactGroup;
  String get contactGroup => _contactGroup ?? '';
  set contactGroup(String? val) => _contactGroup = val;

  bool hasContactGroup() => _contactGroup != null;

  static SocietyContactModelStruct fromMap(Map<String, dynamic> data) =>
      SocietyContactModelStruct(
        imageUrl: data['image_url'] as String?,
        labelText: data['label_text'] as String?,
        contactName: data['contact_name'] as String?,
        contactNumber: data['contact_number'] as String?,
        contactGroup: data['contact_group'] as String?,
      );

  static SocietyContactModelStruct? maybeFromMap(dynamic data) => data is Map
      ? SocietyContactModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'image_url': _imageUrl,
        'label_text': _labelText,
        'contact_name': _contactName,
        'contact_number': _contactNumber,
        'contact_group': _contactGroup,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'image_url': serializeParam(
          _imageUrl,
          ParamType.String,
        ),
        'label_text': serializeParam(
          _labelText,
          ParamType.String,
        ),
        'contact_name': serializeParam(
          _contactName,
          ParamType.String,
        ),
        'contact_number': serializeParam(
          _contactNumber,
          ParamType.String,
        ),
        'contact_group': serializeParam(
          _contactGroup,
          ParamType.String,
        ),
      }.withoutNulls;

  static SocietyContactModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      SocietyContactModelStruct(
        imageUrl: deserializeParam(
          data['image_url'],
          ParamType.String,
          false,
        ),
        labelText: deserializeParam(
          data['label_text'],
          ParamType.String,
          false,
        ),
        contactName: deserializeParam(
          data['contact_name'],
          ParamType.String,
          false,
        ),
        contactNumber: deserializeParam(
          data['contact_number'],
          ParamType.String,
          false,
        ),
        contactGroup: deserializeParam(
          data['contact_group'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SocietyContactModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SocietyContactModelStruct &&
        imageUrl == other.imageUrl &&
        labelText == other.labelText &&
        contactName == other.contactName &&
        contactNumber == other.contactNumber &&
        contactGroup == other.contactGroup;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([imageUrl, labelText, contactName, contactNumber, contactGroup]);
}

SocietyContactModelStruct createSocietyContactModelStruct({
  String? imageUrl,
  String? labelText,
  String? contactName,
  String? contactNumber,
  String? contactGroup,
}) =>
    SocietyContactModelStruct(
      imageUrl: imageUrl,
      labelText: labelText,
      contactName: contactName,
      contactNumber: contactNumber,
      contactGroup: contactGroup,
    );
