// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SocietyActionModelStruct extends BaseStruct {
  SocietyActionModelStruct({
    String? name,
    String? url,
    String? icon,
    SocietyActionType? type,
  })  : _name = name,
        _url = url,
        _icon = icon,
        _type = type;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "url" field.
  String? _url;
  String get url => _url ?? '';
  set url(String? val) => _url = val;

  bool hasUrl() => _url != null;

  // "icon" field.
  String? _icon;
  String get icon => _icon ?? '';
  set icon(String? val) => _icon = val;

  bool hasIcon() => _icon != null;

  // "type" field.
  SocietyActionType? _type;
  SocietyActionType? get type => _type;
  set type(SocietyActionType? val) => _type = val;

  bool hasType() => _type != null;

  static SocietyActionModelStruct fromMap(Map<String, dynamic> data) =>
      SocietyActionModelStruct(
        name: data['name'] as String?,
        url: data['url'] as String?,
        icon: data['icon'] as String?,
        type: data['type'] is SocietyActionType
            ? data['type']
            : deserializeEnum<SocietyActionType>(data['type']),
      );

  static SocietyActionModelStruct? maybeFromMap(dynamic data) => data is Map
      ? SocietyActionModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'url': _url,
        'icon': _icon,
        'type': _type?.serialize(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'url': serializeParam(
          _url,
          ParamType.String,
        ),
        'icon': serializeParam(
          _icon,
          ParamType.String,
        ),
        'type': serializeParam(
          _type,
          ParamType.Enum,
        ),
      }.withoutNulls;

  static SocietyActionModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      SocietyActionModelStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        url: deserializeParam(
          data['url'],
          ParamType.String,
          false,
        ),
        icon: deserializeParam(
          data['icon'],
          ParamType.String,
          false,
        ),
        type: deserializeParam<SocietyActionType>(
          data['type'],
          ParamType.Enum,
          false,
        ),
      );

  @override
  String toString() => 'SocietyActionModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SocietyActionModelStruct &&
        name == other.name &&
        url == other.url &&
        icon == other.icon &&
        type == other.type;
  }

  @override
  int get hashCode => const ListEquality().hash([name, url, icon, type]);
}

SocietyActionModelStruct createSocietyActionModelStruct({
  String? name,
  String? url,
  String? icon,
  SocietyActionType? type,
}) =>
    SocietyActionModelStruct(
      name: name,
      url: url,
      icon: icon,
      type: type,
    );
