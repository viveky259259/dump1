// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NotificationModelStruct extends BaseStruct {
  NotificationModelStruct({
    String? leadingIcon,
    String? title,
    String? subTitle,
    String? ctaText,
    CtaAction? ctaAction,
  })  : _leadingIcon = leadingIcon,
        _title = title,
        _subTitle = subTitle,
        _ctaText = ctaText,
        _ctaAction = ctaAction;

  // "leadingIcon" field.
  String? _leadingIcon;
  String get leadingIcon => _leadingIcon ?? '';
  set leadingIcon(String? val) => _leadingIcon = val;

  bool hasLeadingIcon() => _leadingIcon != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "subTitle" field.
  String? _subTitle;
  String get subTitle => _subTitle ?? '';
  set subTitle(String? val) => _subTitle = val;

  bool hasSubTitle() => _subTitle != null;

  // "cta_text" field.
  String? _ctaText;
  String get ctaText => _ctaText ?? '';
  set ctaText(String? val) => _ctaText = val;

  bool hasCtaText() => _ctaText != null;

  // "cta_action" field.
  CtaAction? _ctaAction;
  CtaAction? get ctaAction => _ctaAction;
  set ctaAction(CtaAction? val) => _ctaAction = val;

  bool hasCtaAction() => _ctaAction != null;

  static NotificationModelStruct fromMap(Map<String, dynamic> data) =>
      NotificationModelStruct(
        leadingIcon: data['leadingIcon'] as String?,
        title: data['title'] as String?,
        subTitle: data['subTitle'] as String?,
        ctaText: data['cta_text'] as String?,
        ctaAction: data['cta_action'] is CtaAction
            ? data['cta_action']
            : deserializeEnum<CtaAction>(data['cta_action']),
      );

  static NotificationModelStruct? maybeFromMap(dynamic data) => data is Map
      ? NotificationModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'leadingIcon': _leadingIcon,
        'title': _title,
        'subTitle': _subTitle,
        'cta_text': _ctaText,
        'cta_action': _ctaAction?.serialize(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'leadingIcon': serializeParam(
          _leadingIcon,
          ParamType.String,
        ),
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'subTitle': serializeParam(
          _subTitle,
          ParamType.String,
        ),
        'cta_text': serializeParam(
          _ctaText,
          ParamType.String,
        ),
        'cta_action': serializeParam(
          _ctaAction,
          ParamType.Enum,
        ),
      }.withoutNulls;

  static NotificationModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      NotificationModelStruct(
        leadingIcon: deserializeParam(
          data['leadingIcon'],
          ParamType.String,
          false,
        ),
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        subTitle: deserializeParam(
          data['subTitle'],
          ParamType.String,
          false,
        ),
        ctaText: deserializeParam(
          data['cta_text'],
          ParamType.String,
          false,
        ),
        ctaAction: deserializeParam<CtaAction>(
          data['cta_action'],
          ParamType.Enum,
          false,
        ),
      );

  @override
  String toString() => 'NotificationModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is NotificationModelStruct &&
        leadingIcon == other.leadingIcon &&
        title == other.title &&
        subTitle == other.subTitle &&
        ctaText == other.ctaText &&
        ctaAction == other.ctaAction;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([leadingIcon, title, subTitle, ctaText, ctaAction]);
}

NotificationModelStruct createNotificationModelStruct({
  String? leadingIcon,
  String? title,
  String? subTitle,
  String? ctaText,
  CtaAction? ctaAction,
}) =>
    NotificationModelStruct(
      leadingIcon: leadingIcon,
      title: title,
      subTitle: subTitle,
      ctaText: ctaText,
      ctaAction: ctaAction,
    );
