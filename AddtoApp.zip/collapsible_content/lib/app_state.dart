import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<SocietyActionModelStruct> _societyActions = [
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Maintenance Bills\",\"url\":\"/maintenance\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Forum\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Helpdesk\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Notices\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Amenities\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Rent Payment\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Directory\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Gate Pass\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Meter consumption\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"CCTV\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Services\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Contact Committee\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}')),
    SocietyActionModelStruct.fromSerializableMap(jsonDecode(
        '{\"name\":\"Call Guard\",\"url\":\"Hello World\",\"icon\":\"https://storage.googleapis.com/flutterflow-enterprise-india.appspot.com/projects/collapsible-content-03tfa6/assets/v51wgduvg319/tool.png\",\"type\":\"internal_navigation\"}'))
  ];
  List<SocietyActionModelStruct> get societyActions => _societyActions;
  set societyActions(List<SocietyActionModelStruct> value) {
    _societyActions = value;
  }

  void addToSocietyActions(SocietyActionModelStruct value) {
    societyActions.add(value);
  }

  void removeFromSocietyActions(SocietyActionModelStruct value) {
    societyActions.remove(value);
  }

  void removeAtIndexFromSocietyActions(int index) {
    societyActions.removeAt(index);
  }

  void updateSocietyActionsAtIndex(
    int index,
    SocietyActionModelStruct Function(SocietyActionModelStruct) updateFn,
  ) {
    societyActions[index] = updateFn(_societyActions[index]);
  }

  void insertAtIndexInSocietyActions(
      int index, SocietyActionModelStruct value) {
    societyActions.insert(index, value);
  }

  SocietyActionModelStruct _societyActionExpansionItem =
      SocietyActionModelStruct.fromSerializableMap(jsonDecode(
          '{\"name\":\"More\",\"url\":\"expand\",\"icon\":\"\",\"type\":\"expansion\"}'));
  SocietyActionModelStruct get societyActionExpansionItem =>
      _societyActionExpansionItem;
  set societyActionExpansionItem(SocietyActionModelStruct value) {
    _societyActionExpansionItem = value;
  }

  void updateSocietyActionExpansionItemStruct(
      Function(SocietyActionModelStruct) updateFn) {
    updateFn(_societyActionExpansionItem);
  }
}
