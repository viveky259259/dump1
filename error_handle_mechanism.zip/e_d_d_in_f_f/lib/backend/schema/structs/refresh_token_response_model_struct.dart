// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RefreshTokenResponseModelStruct extends BaseStruct {
  RefreshTokenResponseModelStruct({
    String? accessToken,
    int? accessTokenExpiresAt,
  })  : _accessToken = accessToken,
        _accessTokenExpiresAt = accessTokenExpiresAt;

  // "accessToken" field.
  String? _accessToken;
  String get accessToken => _accessToken ?? '';
  set accessToken(String? val) => _accessToken = val;

  bool hasAccessToken() => _accessToken != null;

  // "accessTokenExpiresAt" field.
  int? _accessTokenExpiresAt;
  int get accessTokenExpiresAt => _accessTokenExpiresAt ?? 0;
  set accessTokenExpiresAt(int? val) => _accessTokenExpiresAt = val;

  void incrementAccessTokenExpiresAt(int amount) =>
      accessTokenExpiresAt = accessTokenExpiresAt + amount;

  bool hasAccessTokenExpiresAt() => _accessTokenExpiresAt != null;

  static RefreshTokenResponseModelStruct fromMap(Map<String, dynamic> data) =>
      RefreshTokenResponseModelStruct(
        accessToken: data['accessToken'] as String?,
        accessTokenExpiresAt: castToType<int>(data['accessTokenExpiresAt']),
      );

  static RefreshTokenResponseModelStruct? maybeFromMap(dynamic data) => data
          is Map
      ? RefreshTokenResponseModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'accessToken': _accessToken,
        'accessTokenExpiresAt': _accessTokenExpiresAt,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'accessToken': serializeParam(
          _accessToken,
          ParamType.String,
        ),
        'accessTokenExpiresAt': serializeParam(
          _accessTokenExpiresAt,
          ParamType.int,
        ),
      }.withoutNulls;

  static RefreshTokenResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      RefreshTokenResponseModelStruct(
        accessToken: deserializeParam(
          data['accessToken'],
          ParamType.String,
          false,
        ),
        accessTokenExpiresAt: deserializeParam(
          data['accessTokenExpiresAt'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'RefreshTokenResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is RefreshTokenResponseModelStruct &&
        accessToken == other.accessToken &&
        accessTokenExpiresAt == other.accessTokenExpiresAt;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([accessToken, accessTokenExpiresAt]);
}

RefreshTokenResponseModelStruct createRefreshTokenResponseModelStruct({
  String? accessToken,
  int? accessTokenExpiresAt,
}) =>
    RefreshTokenResponseModelStruct(
      accessToken: accessToken,
      accessTokenExpiresAt: accessTokenExpiresAt,
    );
