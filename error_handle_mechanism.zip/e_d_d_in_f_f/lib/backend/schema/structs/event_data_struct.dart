// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EventDataStruct extends BaseStruct {
  EventDataStruct({
    EventType? eventType,
    String? authExpirationMessage,
    int? serverErrorStatusCode,
    String? serverErrorMessage,
  })  : _eventType = eventType,
        _authExpirationMessage = authExpirationMessage,
        _serverErrorStatusCode = serverErrorStatusCode,
        _serverErrorMessage = serverErrorMessage;

  // "eventType" field.
  EventType? _eventType;
  EventType? get eventType => _eventType;
  set eventType(EventType? val) => _eventType = val;

  bool hasEventType() => _eventType != null;

  // "authExpirationMessage" field.
  String? _authExpirationMessage;
  String get authExpirationMessage => _authExpirationMessage ?? '';
  set authExpirationMessage(String? val) => _authExpirationMessage = val;

  bool hasAuthExpirationMessage() => _authExpirationMessage != null;

  // "serverErrorStatusCode" field.
  int? _serverErrorStatusCode;
  int get serverErrorStatusCode => _serverErrorStatusCode ?? 0;
  set serverErrorStatusCode(int? val) => _serverErrorStatusCode = val;

  void incrementServerErrorStatusCode(int amount) =>
      serverErrorStatusCode = serverErrorStatusCode + amount;

  bool hasServerErrorStatusCode() => _serverErrorStatusCode != null;

  // "serverErrorMessage" field.
  String? _serverErrorMessage;
  String get serverErrorMessage => _serverErrorMessage ?? '';
  set serverErrorMessage(String? val) => _serverErrorMessage = val;

  bool hasServerErrorMessage() => _serverErrorMessage != null;

  static EventDataStruct fromMap(Map<String, dynamic> data) => EventDataStruct(
        eventType: data['eventType'] is EventType
            ? data['eventType']
            : deserializeEnum<EventType>(data['eventType']),
        authExpirationMessage: data['authExpirationMessage'] as String?,
        serverErrorStatusCode: castToType<int>(data['serverErrorStatusCode']),
        serverErrorMessage: data['serverErrorMessage'] as String?,
      );

  static EventDataStruct? maybeFromMap(dynamic data) => data is Map
      ? EventDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'eventType': _eventType?.serialize(),
        'authExpirationMessage': _authExpirationMessage,
        'serverErrorStatusCode': _serverErrorStatusCode,
        'serverErrorMessage': _serverErrorMessage,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'eventType': serializeParam(
          _eventType,
          ParamType.Enum,
        ),
        'authExpirationMessage': serializeParam(
          _authExpirationMessage,
          ParamType.String,
        ),
        'serverErrorStatusCode': serializeParam(
          _serverErrorStatusCode,
          ParamType.int,
        ),
        'serverErrorMessage': serializeParam(
          _serverErrorMessage,
          ParamType.String,
        ),
      }.withoutNulls;

  static EventDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      EventDataStruct(
        eventType: deserializeParam<EventType>(
          data['eventType'],
          ParamType.Enum,
          false,
        ),
        authExpirationMessage: deserializeParam(
          data['authExpirationMessage'],
          ParamType.String,
          false,
        ),
        serverErrorStatusCode: deserializeParam(
          data['serverErrorStatusCode'],
          ParamType.int,
          false,
        ),
        serverErrorMessage: deserializeParam(
          data['serverErrorMessage'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'EventDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is EventDataStruct &&
        eventType == other.eventType &&
        authExpirationMessage == other.authExpirationMessage &&
        serverErrorStatusCode == other.serverErrorStatusCode &&
        serverErrorMessage == other.serverErrorMessage;
  }

  @override
  int get hashCode => const ListEquality().hash([
        eventType,
        authExpirationMessage,
        serverErrorStatusCode,
        serverErrorMessage
      ]);
}

EventDataStruct createEventDataStruct({
  EventType? eventType,
  String? authExpirationMessage,
  int? serverErrorStatusCode,
  String? serverErrorMessage,
}) =>
    EventDataStruct(
      eventType: eventType,
      authExpirationMessage: authExpirationMessage,
      serverErrorStatusCode: serverErrorStatusCode,
      serverErrorMessage: serverErrorMessage,
    );
