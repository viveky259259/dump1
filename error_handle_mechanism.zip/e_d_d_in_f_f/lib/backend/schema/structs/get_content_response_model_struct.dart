// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GetContentResponseModelStruct extends BaseStruct {
  GetContentResponseModelStruct({
    String? content,
  }) : _content = content;

  // "content" field.
  String? _content;
  String get content => _content ?? '';
  set content(String? val) => _content = val;

  bool hasContent() => _content != null;

  static GetContentResponseModelStruct fromMap(Map<String, dynamic> data) =>
      GetContentResponseModelStruct(
        content: data['content'] as String?,
      );

  static GetContentResponseModelStruct? maybeFromMap(dynamic data) =>
      data is Map
          ? GetContentResponseModelStruct.fromMap(data.cast<String, dynamic>())
          : null;

  Map<String, dynamic> toMap() => {
        'content': _content,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'content': serializeParam(
          _content,
          ParamType.String,
        ),
      }.withoutNulls;

  static GetContentResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      GetContentResponseModelStruct(
        content: deserializeParam(
          data['content'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'GetContentResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is GetContentResponseModelStruct && content == other.content;
  }

  @override
  int get hashCode => const ListEquality().hash([content]);
}

GetContentResponseModelStruct createGetContentResponseModelStruct({
  String? content,
}) =>
    GetContentResponseModelStruct(
      content: content,
    );
