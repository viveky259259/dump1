// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AuthTokenDataModelStruct extends BaseStruct {
  AuthTokenDataModelStruct({
    String? accessToken,
    int? accessTokenExpiresAt,
    String? refreshToken,
    int? refreshTokenExpiresAt,
  })  : _accessToken = accessToken,
        _accessTokenExpiresAt = accessTokenExpiresAt,
        _refreshToken = refreshToken,
        _refreshTokenExpiresAt = refreshTokenExpiresAt;

  // "accessToken" field.
  String? _accessToken;
  String get accessToken => _accessToken ?? '';
  set accessToken(String? val) => _accessToken = val;

  bool hasAccessToken() => _accessToken != null;

  // "accessTokenExpiresAt" field.
  int? _accessTokenExpiresAt;
  int get accessTokenExpiresAt => _accessTokenExpiresAt ?? 0;
  set accessTokenExpiresAt(int? val) => _accessTokenExpiresAt = val;

  void incrementAccessTokenExpiresAt(int amount) =>
      accessTokenExpiresAt = accessTokenExpiresAt + amount;

  bool hasAccessTokenExpiresAt() => _accessTokenExpiresAt != null;

  // "refreshToken" field.
  String? _refreshToken;
  String get refreshToken => _refreshToken ?? '';
  set refreshToken(String? val) => _refreshToken = val;

  bool hasRefreshToken() => _refreshToken != null;

  // "refreshTokenExpiresAt" field.
  int? _refreshTokenExpiresAt;
  int get refreshTokenExpiresAt => _refreshTokenExpiresAt ?? 0;
  set refreshTokenExpiresAt(int? val) => _refreshTokenExpiresAt = val;

  void incrementRefreshTokenExpiresAt(int amount) =>
      refreshTokenExpiresAt = refreshTokenExpiresAt + amount;

  bool hasRefreshTokenExpiresAt() => _refreshTokenExpiresAt != null;

  static AuthTokenDataModelStruct fromMap(Map<String, dynamic> data) =>
      AuthTokenDataModelStruct(
        accessToken: data['accessToken'] as String?,
        accessTokenExpiresAt: castToType<int>(data['accessTokenExpiresAt']),
        refreshToken: data['refreshToken'] as String?,
        refreshTokenExpiresAt: castToType<int>(data['refreshTokenExpiresAt']),
      );

  static AuthTokenDataModelStruct? maybeFromMap(dynamic data) => data is Map
      ? AuthTokenDataModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'accessToken': _accessToken,
        'accessTokenExpiresAt': _accessTokenExpiresAt,
        'refreshToken': _refreshToken,
        'refreshTokenExpiresAt': _refreshTokenExpiresAt,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'accessToken': serializeParam(
          _accessToken,
          ParamType.String,
        ),
        'accessTokenExpiresAt': serializeParam(
          _accessTokenExpiresAt,
          ParamType.int,
        ),
        'refreshToken': serializeParam(
          _refreshToken,
          ParamType.String,
        ),
        'refreshTokenExpiresAt': serializeParam(
          _refreshTokenExpiresAt,
          ParamType.int,
        ),
      }.withoutNulls;

  static AuthTokenDataModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      AuthTokenDataModelStruct(
        accessToken: deserializeParam(
          data['accessToken'],
          ParamType.String,
          false,
        ),
        accessTokenExpiresAt: deserializeParam(
          data['accessTokenExpiresAt'],
          ParamType.int,
          false,
        ),
        refreshToken: deserializeParam(
          data['refreshToken'],
          ParamType.String,
          false,
        ),
        refreshTokenExpiresAt: deserializeParam(
          data['refreshTokenExpiresAt'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'AuthTokenDataModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AuthTokenDataModelStruct &&
        accessToken == other.accessToken &&
        accessTokenExpiresAt == other.accessTokenExpiresAt &&
        refreshToken == other.refreshToken &&
        refreshTokenExpiresAt == other.refreshTokenExpiresAt;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [accessToken, accessTokenExpiresAt, refreshToken, refreshTokenExpiresAt]);
}

AuthTokenDataModelStruct createAuthTokenDataModelStruct({
  String? accessToken,
  int? accessTokenExpiresAt,
  String? refreshToken,
  int? refreshTokenExpiresAt,
}) =>
    AuthTokenDataModelStruct(
      accessToken: accessToken,
      accessTokenExpiresAt: accessTokenExpiresAt,
      refreshToken: refreshToken,
      refreshTokenExpiresAt: refreshTokenExpiresAt,
    );
