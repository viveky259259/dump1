// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserProfileModelStruct extends BaseStruct {
  UserProfileModelStruct({
    String? name,
    String? email,
    String? role,
    int? id,
  })  : _name = name,
        _email = email,
        _role = role,
        _id = id;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;

  bool hasEmail() => _email != null;

  // "role" field.
  String? _role;
  String get role => _role ?? '';
  set role(String? val) => _role = val;

  bool hasRole() => _role != null;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  set id(int? val) => _id = val;

  void incrementId(int amount) => id = id + amount;

  bool hasId() => _id != null;

  static UserProfileModelStruct fromMap(Map<String, dynamic> data) =>
      UserProfileModelStruct(
        name: data['name'] as String?,
        email: data['email'] as String?,
        role: data['role'] as String?,
        id: castToType<int>(data['id']),
      );

  static UserProfileModelStruct? maybeFromMap(dynamic data) => data is Map
      ? UserProfileModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'email': _email,
        'role': _role,
        'id': _id,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'role': serializeParam(
          _role,
          ParamType.String,
        ),
        'id': serializeParam(
          _id,
          ParamType.int,
        ),
      }.withoutNulls;

  static UserProfileModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      UserProfileModelStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        role: deserializeParam(
          data['role'],
          ParamType.String,
          false,
        ),
        id: deserializeParam(
          data['id'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'UserProfileModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UserProfileModelStruct &&
        name == other.name &&
        email == other.email &&
        role == other.role &&
        id == other.id;
  }

  @override
  int get hashCode => const ListEquality().hash([name, email, role, id]);
}

UserProfileModelStruct createUserProfileModelStruct({
  String? name,
  String? email,
  String? role,
  int? id,
}) =>
    UserProfileModelStruct(
      name: name,
      email: email,
      role: role,
      id: id,
    );
