// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LoginResponseModelStruct extends BaseStruct {
  LoginResponseModelStruct({
    AuthTokenDataModelStruct? authTokenData,
    UserProfileModelStruct? profile,
  })  : _authTokenData = authTokenData,
        _profile = profile;

  // "authTokenData" field.
  AuthTokenDataModelStruct? _authTokenData;
  AuthTokenDataModelStruct get authTokenData =>
      _authTokenData ?? AuthTokenDataModelStruct();
  set authTokenData(AuthTokenDataModelStruct? val) => _authTokenData = val;

  void updateAuthTokenData(Function(AuthTokenDataModelStruct) updateFn) {
    updateFn(_authTokenData ??= AuthTokenDataModelStruct());
  }

  bool hasAuthTokenData() => _authTokenData != null;

  // "profile" field.
  UserProfileModelStruct? _profile;
  UserProfileModelStruct get profile => _profile ?? UserProfileModelStruct();
  set profile(UserProfileModelStruct? val) => _profile = val;

  void updateProfile(Function(UserProfileModelStruct) updateFn) {
    updateFn(_profile ??= UserProfileModelStruct());
  }

  bool hasProfile() => _profile != null;

  static LoginResponseModelStruct fromMap(Map<String, dynamic> data) =>
      LoginResponseModelStruct(
        authTokenData: data['authTokenData'] is AuthTokenDataModelStruct
            ? data['authTokenData']
            : AuthTokenDataModelStruct.maybeFromMap(data['authTokenData']),
        profile: data['profile'] is UserProfileModelStruct
            ? data['profile']
            : UserProfileModelStruct.maybeFromMap(data['profile']),
      );

  static LoginResponseModelStruct? maybeFromMap(dynamic data) => data is Map
      ? LoginResponseModelStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'authTokenData': _authTokenData?.toMap(),
        'profile': _profile?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'authTokenData': serializeParam(
          _authTokenData,
          ParamType.DataStruct,
        ),
        'profile': serializeParam(
          _profile,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static LoginResponseModelStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      LoginResponseModelStruct(
        authTokenData: deserializeStructParam(
          data['authTokenData'],
          ParamType.DataStruct,
          false,
          structBuilder: AuthTokenDataModelStruct.fromSerializableMap,
        ),
        profile: deserializeStructParam(
          data['profile'],
          ParamType.DataStruct,
          false,
          structBuilder: UserProfileModelStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'LoginResponseModelStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is LoginResponseModelStruct &&
        authTokenData == other.authTokenData &&
        profile == other.profile;
  }

  @override
  int get hashCode => const ListEquality().hash([authTokenData, profile]);
}

LoginResponseModelStruct createLoginResponseModelStruct({
  AuthTokenDataModelStruct? authTokenData,
  UserProfileModelStruct? profile,
}) =>
    LoginResponseModelStruct(
      authTokenData: authTokenData ?? AuthTokenDataModelStruct(),
      profile: profile ?? UserProfileModelStruct(),
    );
