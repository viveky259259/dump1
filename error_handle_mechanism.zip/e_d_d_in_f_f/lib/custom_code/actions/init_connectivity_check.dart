// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:connectivity_plus/connectivity_plus.dart';

Future initConnectivityCheck() async {
  final List<ConnectivityResult> connectivityResult =
      await (Connectivity().checkConnectivity());
  _checkResultAndTriggerConnectivityEvent(connectivityResult);

  // Now that the initial check is complete
  // Start a listener to continuously keep track of when network connectivity changes
  Connectivity()
      .onConnectivityChanged
      .listen(_checkResultAndTriggerConnectivityEvent);
}

void _checkResultAndTriggerConnectivityEvent(
    List<ConnectivityResult> connectivityResult) {
  bool isConnected = false;

  if (connectivityResult.contains(ConnectivityResult.none)) {
    // No network connection is available
    isConnected = false;
  } else if (connectivityResult.isNotEmpty) {
    // Network connection is available
    isConnected = true;
  }

  FFAppState().update(() {
    FFAppState().isConnectedToInternet = isConnected;
  });
}
