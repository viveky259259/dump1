// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/backend/api_requests/api_calls.dart';
import 'dart:async';

Future refreshToken() async {
  await RefreshTokenManager.instance.refresh();
}

class RefreshTokenManager {
  static final RefreshTokenManager _instance = RefreshTokenManager._internal();

  static RefreshTokenManager get instance => _instance;

  RefreshTokenManager._internal();

  final _refreshSemaphore = Semaphore(1);

  Future<void> refresh() async {
    await _refreshSemaphore.acquire();

    try {
      // Check again if access token is expired
      // (in case it was refreshed while waiting)
      final _accessTokenExpiresAt =
          FFAppState().authTokenData.accessTokenExpiresAt;
      final _now = DateTime.now();
      if (_now.secondsSinceEpoch < _accessTokenExpiresAt) {
        // Access token is valid, no need to refresh
        return;
      }

      // It is possible that while some refresh calls were waiting
      // a logout event was triggered because a refresh call failed
      // Check if the authTokenData is even present, if not, this ends here
      final _refreshToken = FFAppState().authTokenData.refreshToken;
      if (_refreshToken.isEmpty) {
        return;
      }

      // It is also possible that while waiting the refresh token also expired
      // so we need to check for that use case as well
      final _refreshTokenExpiresAt =
          FFAppState().authTokenData.refreshTokenExpiresAt;
      if (_now.secondsSinceEpoch >= _refreshTokenExpiresAt) {
        // Perform logout logic here
        throw AuthException('Refresh token has expired. Please login again.');
      }

      // Make the refresh token API call
      final _refreshTokenResponse = await RefreshTokenCall.call(
        refreshToken: _refreshToken,
      );

      if (_refreshTokenResponse.succeeded) {
        // API Call was a success
        final _refreshTokenResponseData =
            RefreshTokenResponseModelStruct.maybeFromMap(
          _refreshTokenResponse.jsonBody ?? '',
        );
        if (_refreshTokenResponseData?.accessToken != null &&
            _refreshTokenResponseData!.accessToken.isNotEmpty) {
          // New Access token received, update in app state
          final _existingAuthTokenData = FFAppState().authTokenData;
          // Update app state with new data
          FFAppState().authTokenData = AuthTokenDataModelStruct(
            accessToken: _refreshTokenResponseData.accessToken,
            accessTokenExpiresAt:
                _refreshTokenResponseData.accessTokenExpiresAt,
            refreshToken: _existingAuthTokenData.refreshToken,
            refreshTokenExpiresAt: _existingAuthTokenData.refreshTokenExpiresAt,
          );
        }
      } else {
        // Handle refresh failure
        // logout needs to be triggered
        throw AuthException('Failed to refresh token.');
      }
    } finally {
      _refreshSemaphore.release();
    }
  }
}

class Semaphore {
  final int _maxConcurrent;
  int _currentCount = 0;
  final List<Completer<void>> _waiters = [];

  Semaphore(this._maxConcurrent);

  Future<void> acquire() {
    if (_currentCount < _maxConcurrent) {
      _currentCount++;
      return Future.value();
    } else {
      final completer = Completer<void>();
      _waiters.add(completer);
      return completer.future;
    }
  }

  void release() {
    if (_waiters.isNotEmpty) {
      final completer = _waiters.removeAt(0);
      completer.complete();
    } else {
      _currentCount--;
    }
  }
}

class AuthException implements Exception {
  final String message;

  AuthException(this.message);

  @override
  String toString() {
    return "AuthException: $message";
  }
}
