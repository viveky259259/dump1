// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/backend/api_requests/api_interceptor.dart';
import '/custom_code/actions/refresh_token.dart';

class AuthInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    // Perform any necessary calls or modifications to the [options] before
    // the API call is made.

    // This is the place where we can Check for auth validity
    bool _shouldLogout = false;

    final _authTokenData = FFAppState().authTokenData;
    final _accessTokenExpiresAt = _authTokenData.accessTokenExpiresAt;

    final _now = DateTime.now();

    if (_now.secondsSinceEpoch >= _accessTokenExpiresAt) {
      // Access Token has expired
      // Check if refresh token is valid
      final _refreshTokenExpiresAt = _authTokenData.refreshTokenExpiresAt;
      if (_now.secondsSinceEpoch >= _refreshTokenExpiresAt) {
        // Refresh token is also expired, we should logout the user
        _shouldLogout = true;
      } else {
        // Refresh token is valid, attempt to get new access token
        try {
          await refreshToken();
        } catch (e) {
          if (e is AuthException) {
            _triggerLogout(message: e.message);
          }
        }
      }
    }

    if (_shouldLogout) {
      _triggerLogout();
    } else {
      // Add auth header to API call
      final _accessToken = FFAppState().authTokenData.accessToken;
      options.headers['authorization'] = 'Bearer $_accessToken';
    }

    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Perform any necessary calls or modifications to the [response] prior
    // to returning it.
    return response;
  }

  void _triggerLogout({String? message}) {
    // Terminate the flow and trigger event for auth expiration
    const _message = 'Your session has expired';
    addEvent(
      EventDataStruct(
        eventType: EventType.AuthExpiredEvent,
        authExpirationMessage: _message,
      ),
    );

    // Throw an exception to cancel this API call
    throw Exception(message ?? _message);
  }
}
