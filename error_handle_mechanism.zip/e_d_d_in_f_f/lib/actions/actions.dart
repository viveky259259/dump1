import '/backend/api_requests/api_calls.dart';
import '/backend/api_requests/api_manager.dart';
import '/backend/schema/enums/enums.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/actions/actions.dart' as action_blocks;
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Future onEventHandler(
  BuildContext context, {
  required EventDataStruct? event,
}) async {
  if (event?.eventType == EventType.NoInternetAPIEvent) {
    // handleConnectivityEvent
    await action_blocks.handleConnecitivityEvent(
      context,
      event: event,
    );
    return;
  } else if (event?.eventType == EventType.ServerErrorAPIEvent) {
    // handleServerErrorEvent
    await action_blocks.handleServerErrorEvent(
      context,
      event: event,
    );
    return;
  } else if (event?.eventType == EventType.AuthExpiredEvent) {
    // handleAuthExpired
    await action_blocks.logout(
      context,
      authExpirationEvent: event,
    );
    return;
  } else {
    return;
  }
}

Future handleConnecitivityEvent(
  BuildContext context, {
  required EventDataStruct? event,
}) async {
  // showNoInternetMessage
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        'API Request cannot be made. No internet connection.',
        style: TextStyle(
          color: FlutterFlowTheme.of(context).alternate,
        ),
      ),
      duration: Duration(milliseconds: 2000),
      backgroundColor: FlutterFlowTheme.of(context).error,
    ),
  );
}

Future handleServerErrorEvent(
  BuildContext context, {
  required EventDataStruct? event,
}) async {
  // showServerErrorMessage
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        '${event?.serverErrorStatusCode?.toString()} : ${event?.serverErrorMessage}',
        style: TextStyle(
          color: FlutterFlowTheme.of(context).alternate,
        ),
      ),
      duration: Duration(milliseconds: 4000),
      backgroundColor: FlutterFlowTheme.of(context).warning,
    ),
  );
}

Future login(BuildContext context) async {
  ApiCallResponse? loginResponseModel;

  // makeLoginAPiCall
  loginResponseModel = await LoginCall.call();

  if ((loginResponseModel?.succeeded ?? true) &&
      (LoginResponseModelStruct.maybeFromMap(
                      (loginResponseModel?.jsonBody ?? ''))
                  ?.authTokenData
                  ?.accessToken !=
              null &&
          LoginResponseModelStruct.maybeFromMap(
                      (loginResponseModel?.jsonBody ?? ''))
                  ?.authTokenData
                  ?.accessToken !=
              '')) {
    // setAppState
    FFAppState().authTokenData = LoginResponseModelStruct.maybeFromMap(
            (loginResponseModel?.jsonBody ?? ''))!
        .authTokenData;
    FFAppState().authenticatedUserProfile =
        LoginResponseModelStruct.maybeFromMap(
                (loginResponseModel?.jsonBody ?? ''))!
            .profile;
    FFAppState().update(() {});
    // closePreLoginEventStream
    await actions.closeEventStream();
    // goHome

    context.goNamed(HomePageWidget.routeName);

    return;
  } else {
    // showLoginFailed
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Login failed.',
          style: TextStyle(
            color: FlutterFlowTheme.of(context).alternate,
          ),
        ),
        duration: Duration(milliseconds: 2000),
        backgroundColor: FlutterFlowTheme.of(context).error,
      ),
    );
    return;
  }
}

Future logout(
  BuildContext context, {
  EventDataStruct? authExpirationEvent,
}) async {
  if (FFAppState().authTokenData.accessToken != null &&
      FFAppState().authTokenData.accessToken != '') {
    // clearAuthValue
    FFAppState().deleteAuthTokenData();
    FFAppState().authTokenData = AuthTokenDataModelStruct();

    FFAppState().deleteAuthenticatedUserProfile();
    FFAppState().authenticatedUserProfile = UserProfileModelStruct();

    // navigateToLogin

    context.goNamed(LoginScreenWidget.routeName);

    if (authExpirationEvent?.authExpirationMessage != null &&
        authExpirationEvent?.authExpirationMessage != '') {
      // showExceptionMessage
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            authExpirationEvent!.authExpirationMessage,
            style: TextStyle(),
          ),
          duration: Duration(milliseconds: 2000),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    } else {
      return;
    }
  } else {
    return;
  }
}
