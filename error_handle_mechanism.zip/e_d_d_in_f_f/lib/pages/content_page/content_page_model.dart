import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'content_page_widget.dart' show ContentPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ContentPageModel extends FlutterFlowModel<ContentPageWidget> {
  ///  Local state fields for this page.

  GetContentResponseModelStruct? contentDataA;
  void updateContentDataAStruct(
      Function(GetContentResponseModelStruct) updateFn) {
    updateFn(contentDataA ??= GetContentResponseModelStruct());
  }

  GetContentResponseModelStruct? contentDataB;
  void updateContentDataBStruct(
      Function(GetContentResponseModelStruct) updateFn) {
    updateFn(contentDataB ??= GetContentResponseModelStruct());
  }

  GetContentResponseModelStruct? contentDataC;
  void updateContentDataCStruct(
      Function(GetContentResponseModelStruct) updateFn) {
    updateFn(contentDataC ??= GetContentResponseModelStruct());
  }

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Action Block - getContentFromAPI] action in ContentPage widget.
  GetContentResponseModelStruct? getContentA;
  // Stores action output result for [Action Block - getContentFromAPI] action in ContentPage widget.
  GetContentResponseModelStruct? getContentB;
  // Stores action output result for [Action Block - getContentFromAPI] action in ContentPage widget.
  GetContentResponseModelStruct? getContentC;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Action blocks.
  Future<GetContentResponseModelStruct> getContentFromAPI(
      BuildContext context) async {
    ApiCallResponse? getContentResponse;

    getContentResponse = await GetContentCall.call();

    if ((getContentResponse?.succeeded ?? true)) {
      return GetContentResponseModelStruct.maybeFromMap(
          (getContentResponse?.jsonBody ?? ''))!;
    }

    return GetContentResponseModelStruct();
  }
}
