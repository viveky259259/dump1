import '/components/screen_loading_view_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/actions/actions.dart' as action_blocks;
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'login_screen_widget.dart' show LoginScreenWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoginScreenModel extends FlutterFlowModel<LoginScreenWidget> {
  ///  Local state fields for this page.

  bool showLoginContent = false;

  ///  State fields for stateful widgets in this page.

  // Model for ScreenLoadingView component.
  late ScreenLoadingViewModel screenLoadingViewModel;

  @override
  void initState(BuildContext context) {
    screenLoadingViewModel =
        createModel(context, () => ScreenLoadingViewModel());
  }

  @override
  void dispose() {
    screenLoadingViewModel.dispose();
  }
}
