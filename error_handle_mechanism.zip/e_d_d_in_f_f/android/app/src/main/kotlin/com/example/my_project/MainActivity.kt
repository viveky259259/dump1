package io.flutterflow.eddinff

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
