// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:async';
import 'dart:collection';

class EventService {
  static final EventService _instance = EventService._internal();

  static EventService get instance => _instance;

  Future Function(EventDataStruct eventData)? onEventHandled;
  Map<EventType, Future Function(EventDataStruct eventData)> _eventHandlers =
      {};
  StreamController<EventDataStruct> _controller =
      StreamController<EventDataStruct>();
  Queue<EventDataStruct> _eventQueue = Queue<EventDataStruct>();

  void init() {
    if (_controller.isClosed) {
      _controller = StreamController<EventDataStruct>();
      _eventQueue = Queue<EventDataStruct>();
    }
    _controller.stream.listen((event) {
      _eventQueue.add(event);
      if (_eventQueue.length == 1) {
        _processNextEvent();
      }
    });

    print(
        'Event stream is ${_controller.hasListener ? 'listening' : 'not listening'}');

    _controller.onPause = () {
      print('Event stream is paused');
    };
  }

  EventService._internal() {
    // init();
  }

  void addEvent(EventDataStruct event) {
    if (_controller.isClosed) {
      print(
          'Event of type: ${event.eventType} was dropped because the stream is closed.');
    } else {
      _controller.add(event);
    }
  }

  Future<void> _processNextEvent() async {
    while (_eventQueue.isNotEmpty) {
      final event = _eventQueue.first;
      await _handleEvent(event);
      await onEventHandled?.call(event);
      _eventQueue.removeFirst();
    }
  }

  Future<void> _handleEvent(EventDataStruct event) async {
    // Async operation which maybe required in common
    print('Processing event: ${event.eventType}');
    if (_eventHandlers.containsKey(event.eventType)) {
      _eventHandlers[event.eventType!]!(event);
    }
  }

  void registerEventHandler(
    EventType eventType,
    Future Function(EventDataStruct eventData) onEventHandled,
  ) {
    _eventHandlers[eventType] = onEventHandled;
  }

  void handleEvent(EventDataStruct event) {
    _eventHandlers[event.eventType]?.call(event);
  }

  void closeEventStream() {
    if (!_controller.isClosed) {
      _controller.close();
    }
  }
}
