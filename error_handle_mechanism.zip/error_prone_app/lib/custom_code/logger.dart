class Logger {
  static final Logger _instance = Logger._internal();

  static Logger get instance => _instance;
  Logger._internal();

  Future<void> logEvent(Map data) async {
    // simulating logging
    print('logging: $data');
  }
}
