// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import '/backend/api_requests/api_interceptor.dart';
import 'dart:convert';

class EncryptionInterceptor extends FFApiInterceptor {
  // Secret key for encryption (in production, this should be securely managed)
  static const String _secretKey = 'MySecretKey123!@#';

  // Simple XOR encryption function
  String _encrypt(String data) {
    final keyBytes = utf8.encode(_secretKey);
    final dataBytes = utf8.encode(data);
    final encryptedBytes = <int>[];

    for (int i = 0; i < dataBytes.length; i++) {
      encryptedBytes.add(dataBytes[i] ^ keyBytes[i % keyBytes.length]);
    }

    return base64.encode(encryptedBytes);
  }

  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    var body = options.body;

    // Encrypt request body if it exists
    if (options.body != null && options.body!.isNotEmpty) {
      try {
        // Encrypt the request body
        body = _encrypt(options.body!);
      } catch (e) {
        throw Exception('Failed to encrypt request: $e');
      }
    }

    // Update the options with encrypted body
    options = options.copyWith(
      body: body,
      headers: {
        ...options.headers,
        'Content-Type': 'application/json',
        'X-Encrypted': 'true', // Header to indicate encrypted content
      },
    );

    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    return response;
  }
}
