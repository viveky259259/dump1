// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/backend/api_requests/api_interceptor.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class InternetInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    // Check internet connectivity before making the API call
    final connectivityResult = await Connectivity().checkConnectivity();

    // Check if device has any form of connectivity
    if (connectivityResult.contains(ConnectivityResult.none)) {
      addEvent(
        EventDataStruct(
          eventType: EventType.NoInternetEvent,
        ),
      );
      throw Exception(
          'No internet connection available. Please check your network settings and try again.');
    }

    // If we have connectivity, proceed with the original options
    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Perform any necessary calls or modifications to the [response] prior
    // to returning it.
    return response;
  }
}
