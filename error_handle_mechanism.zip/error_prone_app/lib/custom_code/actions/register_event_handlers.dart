// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import '../../flutter_flow/nav/nav.dart';

import '../../index.dart';
import '../../custom_code/actions/auth_error_handler.dart';

Future registerEventHandlers() async {
  // Add your function code here!
  registerEvent(EventType.NoInternetEvent, (data) async {
    appNavigatorKey.currentContext?.goNamed(ErrorGatingWidget.routeName);
  });
  registerEvent(EventType.UnexpectedState, (data) async {
    appNavigatorKey.currentContext?.goNamed(ErrorGatingWidget.routeName);
  });
  registerEvent(EventType.LogEvent, (data) async {
    logEvent(data.toMap());
  });
  authErrorHandler();
  securityBreachHandler();
  userErrorHandler();
}
