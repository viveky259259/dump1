// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import '/backend/api_requests/api_interceptor.dart';
import '../../custom_code/event_service.dart';

class GlobalAppInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    // Perform any necessary calls or modifications to the [options] before
    // the API call is made.
    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Perform any necessary calls or modifications to the [response] prior
    // to returning it.

    // Check if status 470: custom code for security breach
    if (response.statusCode == 470) {
      try {
        // Parse the response body to check for token expired error
        final responseData = jsonDecode(response.bodyText);

        // Check if this is specifically a token expired error
        if (responseData is Map<String, dynamic>) {
          EventService.instance.addEvent(
            EventDataStruct(
                eventType: EventType.SecurityBreachEvent,
                data: {
                  'error': responseData['error'],
                  'message': responseData['message'],
                }.toString()),
          );
        }
      } catch (e) {
        // If JSON parsing fails, fall back to generic 401 handling

        EventService.instance.addEvent(
          EventDataStruct(
              eventType: EventType.ApiParsingErrorEvent,
              data: {
                'error': e.toString(),
                'message': e.toString(),
              }.toString()),
        );
      }
    }

    // Return the original response if no authorization errors detected
    return response;
  }
}
