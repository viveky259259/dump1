// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/event_service.dart';
import 'index.dart'; // Imports other custom actions

import 'index.dart'; // Imports other custom actions

import '/backend/api_requests/api_interceptor.dart';
import 'dart:convert';

class AuthenticationInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    // Perform any necessary calls or modifications to the [options] before
    // the API call is made.
    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Check if this is an invalid user error (403 status code)
    if (response.statusCode == 403) {
      try {
        // Parse the response body to check for invalid user error
        final responseData = jsonDecode(response.bodyText);

        // Check if this is specifically an invalid user error
        if (responseData is Map<String, dynamic> &&
            responseData['code'] == 'INVALID_USER_PERMISSION') {
          // Log the invalid user error for debugging
          print('Authentication Error: Invalid user detected');
          print('Error Details: ${responseData['error']}');
          print('Message: ${responseData['message']}');
          print('Timestamp: ${responseData['timestamp']}');

          // You can add custom handling here, such as:
          // - Clearing stored authentication tokens
          // - Redirecting to login page
          // - Showing specific error messages
          // - Triggering re-authentication flow

          // For now, we'll throw a custom exception with clear messaging

          EventService.instance.addEvent(
            EventDataStruct(
                eventType: EventType.LoginInvalidEvent,
                data: {
                  'error': responseData['error'],
                  'message': responseData['message'],
                }.toString()),
          );

          // EventService.instance.addEvent(
          //   EventDataStruct(
          //       eventType: EventType.LogEvent,
          //       data: {
          //         'error': responseData['error'],
          //         'message': responseData['message'],
          //       }.toString()),
          // );

          // throw Exception(
          //     'Authentication failed: ${responseData['error'] ?? 'Invalid user'}. '
          //     'Please check your credentials and try again.');
        }

        // If it's a 403 but not an invalid user error, handle generically
        if (responseData is Map<String, dynamic> &&
            responseData['success'] == false) {
          throw Exception(
              'Access forbidden: ${responseData['message'] ?? 'You do not have permission to access this resource.'}');
        }
      } catch (e) {
        // If JSON parsing fails, fall back to generic 403 handling
        if (e is Exception && e.toString().contains('Authentication failed')) {
          // Re-throw our custom authentication exception
          rethrow;
        }

        // For other parsing errors, provide a generic 403 message
        // throw Exception(
        //     'Access forbidden (403). You do not have permission to access this resource.');
      }
    }

    // For other error status codes, you might want to handle them too
    if (response.statusCode == 401) {
      try {
        final responseData = jsonDecode(response.bodyText);
        if (responseData is Map<String, dynamic> &&
            responseData['code'] == 'TOKEN_EXPIRED') {
          print('Authentication Error: Token expired');
          print('Error Details: ${responseData['error']}');

          throw Exception(
              'Your session has expired. Please log in again to continue.');
        }
      } catch (e) {
        // Generic 401 handling
        throw Exception(
            'Authentication required. Please log in to access this resource.');
      }
    }

    // Return the original response if no authentication errors detected
    return response;
  }
}
