// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import 'index.dart'; // Imports other custom actions

import '/backend/api_requests/api_interceptor.dart';
import 'dart:convert';
import '../../custom_code/event_service.dart';

class AuthorizationInterceptor extends FFApiInterceptor {
  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    // Perform any necessary calls or modifications to the [options] before
    // the API call is made.
    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Check if this is a token expired error (401 status code)
    if (response.statusCode == 401) {
      try {
        // Parse the response body to check for token expired error
        final responseData = jsonDecode(response.bodyText);

        // Check if this is specifically a token expired error
        if (responseData is Map<String, dynamic> &&
            responseData['code'] == 'TOKEN_EXPIRED') {
          // Log the token expired error for debugging
          print('Authorization Error: Token expired detected');
          print('Error Details: ${responseData['error']}');
          print('Message: ${responseData['message']}');
          print('Timestamp: ${responseData['timestamp']}');

          // Here you can add custom handling such as:
          // - Clear stored authentication tokens
          // - Refresh the token automatically
          // - Redirect to login page
          // - Show re-authentication dialog
          // - Trigger token refresh flow

          // For demonstration, we'll clear any stored tokens and throw an exception
          await _handleTokenExpired();
          // return retry();
        }

        // If it's a 401 but not a token expired error, handle generically
        if (responseData is Map<String, dynamic> &&
            responseData['success'] == false) {
          // Handle this case

          EventService.instance.addEvent(
            EventDataStruct(
                eventType: EventType.ApiParsingErrorEvent,
                data: {
                  'error': responseData['error'],
                  'message': responseData['message'],
                }.toString()),
          );
        }
      } catch (e) {
        // If JSON parsing fails, fall back to generic 401 handling

        EventService.instance.addEvent(
          EventDataStruct(
              eventType: EventType.ApiParsingErrorEvent,
              data: {
                'error': e.toString(),
                'message': e.toString(),
              }.toString()),
        );
      }
    }

    // Return the original response if no authorization errors detected
    return response;
  }

  /// Handle token expiration by clearing stored tokens and preparing for re-authentication
  Future<void> _handleTokenExpired() async {
    // token api call
    // After getting token, retry the existing api call
  }
}
