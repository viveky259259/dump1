// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import '/backend/api_requests/api_interceptor.dart';
import 'dart:convert';

class DecryptionInterceptor extends FFApiInterceptor {
  // Secret key for encryption (in production, this should be securely managed)
  static const String _secretKey = 'MySecretKey123!@#';

  // Simple XOR decryption function
  String _decrypt(String encryptedData) {
    try {
      final keyBytes = utf8.encode(_secretKey);
      final encryptedBytes = base64.decode(encryptedData);
      final decryptedBytes = <int>[];

      for (int i = 0; i < encryptedBytes.length; i++) {
        decryptedBytes.add(encryptedBytes[i] ^ keyBytes[i % keyBytes.length]);
      }

      return utf8.decode(decryptedBytes);
    } catch (e) {
      throw Exception('Failed to decrypt data: $e');
    }
  }

  @override
  Future<ApiCallOptions> onRequest({
    required ApiCallOptions options,
  }) async {
    return options;
  }

  @override
  Future<ApiCallResponse> onResponse({
    required ApiCallResponse response,
    required Future<ApiCallResponse> Function() retryFn,
  }) async {
    // Check if response is encrypted
    final isEncrypted = response.headers['x-encrypted'] == 'true' ||
        response.headers['X-Encrypted'] == 'true';

    if (isEncrypted && response.bodyText.isNotEmpty) {
      try {
        // Decrypt the response body
        final decryptedBody = (response.jsonBody['data'] ?? '').isNotEmpty
            ? _decrypt(response.jsonBody['data'])
            : '';

        // Return new response with decrypted body
        return ApiCallResponse(
          jsonDecode(decryptedBody),
          response.headers,
          response.statusCode,
          exception: response.exception,
        );
      } catch (e) {
        throw Exception('Failed to decrypt response: $e');
      }
    }

    return response;
  }
}
