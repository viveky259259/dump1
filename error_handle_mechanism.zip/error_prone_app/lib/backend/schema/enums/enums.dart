import 'package:collection/collection.dart';

enum EventType {
  NoInternetEvent,
  EncryptionEvent,
  LoginInvalidEvent,
  LogEvent,
  UnexpectedState,
  ApiParsingErrorEvent,
  SecurityBreachEvent,
  UserAlreadyExistsEvent,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (EventType):
      return EventType.values.deserialize(value) as T?;
    default:
      return null;
  }
}
