// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EventDataStruct extends BaseStruct {
  EventDataStruct({
    EventType? eventType,
    String? data,
  })  : _eventType = eventType,
        _data = data;

  // "eventType" field.
  EventType? _eventType;
  EventType? get eventType => _eventType;
  set eventType(EventType? val) => _eventType = val;

  bool hasEventType() => _eventType != null;

  // "data" field.
  String? _data;
  String get data => _data ?? '';
  set data(String? val) => _data = val;

  bool hasData() => _data != null;

  static EventDataStruct fromMap(Map<String, dynamic> data) => EventDataStruct(
        eventType: data['eventType'] is EventType
            ? data['eventType']
            : deserializeEnum<EventType>(data['eventType']),
        data: data['data'] as String?,
      );

  static EventDataStruct? maybeFromMap(dynamic data) => data is Map
      ? EventDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'eventType': _eventType?.serialize(),
        'data': _data,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'eventType': serializeParam(
          _eventType,
          ParamType.Enum,
        ),
        'data': serializeParam(
          _data,
          ParamType.String,
        ),
      }.withoutNulls;

  static EventDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      EventDataStruct(
        eventType: deserializeParam<EventType>(
          data['eventType'],
          ParamType.Enum,
          false,
        ),
        data: deserializeParam(
          data['data'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'EventDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is EventDataStruct &&
        eventType == other.eventType &&
        data == other.data;
  }

  @override
  int get hashCode => const ListEquality().hash([eventType, data]);
}

EventDataStruct createEventDataStruct({
  EventType? eventType,
  String? data,
}) =>
    EventDataStruct(
      eventType: eventType,
      data: data,
    );
