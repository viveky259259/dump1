// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserValidationErrorStruct extends BaseStruct {
  UserValidationErrorStruct({
    bool? success,
    String? message,
    String? error,
    String? code,
    List<FieldValidationErrorStruct>? details,
    String? timestamp,
  })  : _success = success,
        _message = message,
        _error = error,
        _code = code,
        _details = details,
        _timestamp = timestamp;

  // "success" field.
  bool? _success;
  bool get success => _success ?? false;
  set success(bool? val) => _success = val;

  bool hasSuccess() => _success != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "error" field.
  String? _error;
  String get error => _error ?? '';
  set error(String? val) => _error = val;

  bool hasError() => _error != null;

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  set code(String? val) => _code = val;

  bool hasCode() => _code != null;

  // "details" field.
  List<FieldValidationErrorStruct>? _details;
  List<FieldValidationErrorStruct> get details => _details ?? const [];
  set details(List<FieldValidationErrorStruct>? val) => _details = val;

  void updateDetails(Function(List<FieldValidationErrorStruct>) updateFn) {
    updateFn(_details ??= []);
  }

  bool hasDetails() => _details != null;

  // "timestamp" field.
  String? _timestamp;
  String get timestamp => _timestamp ?? '';
  set timestamp(String? val) => _timestamp = val;

  bool hasTimestamp() => _timestamp != null;

  static UserValidationErrorStruct fromMap(Map<String, dynamic> data) =>
      UserValidationErrorStruct(
        success: data['success'] as bool?,
        message: data['message'] as String?,
        error: data['error'] as String?,
        code: data['code'] as String?,
        details: getStructList(
          data['details'],
          FieldValidationErrorStruct.fromMap,
        ),
        timestamp: data['timestamp'] as String?,
      );

  static UserValidationErrorStruct? maybeFromMap(dynamic data) => data is Map
      ? UserValidationErrorStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'success': _success,
        'message': _message,
        'error': _error,
        'code': _code,
        'details': _details?.map((e) => e.toMap()).toList(),
        'timestamp': _timestamp,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'success': serializeParam(
          _success,
          ParamType.bool,
        ),
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'error': serializeParam(
          _error,
          ParamType.String,
        ),
        'code': serializeParam(
          _code,
          ParamType.String,
        ),
        'details': serializeParam(
          _details,
          ParamType.DataStruct,
          isList: true,
        ),
        'timestamp': serializeParam(
          _timestamp,
          ParamType.String,
        ),
      }.withoutNulls;

  static UserValidationErrorStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      UserValidationErrorStruct(
        success: deserializeParam(
          data['success'],
          ParamType.bool,
          false,
        ),
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        error: deserializeParam(
          data['error'],
          ParamType.String,
          false,
        ),
        code: deserializeParam(
          data['code'],
          ParamType.String,
          false,
        ),
        details: deserializeStructParam<FieldValidationErrorStruct>(
          data['details'],
          ParamType.DataStruct,
          true,
          structBuilder: FieldValidationErrorStruct.fromSerializableMap,
        ),
        timestamp: deserializeParam(
          data['timestamp'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'UserValidationErrorStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is UserValidationErrorStruct &&
        success == other.success &&
        message == other.message &&
        error == other.error &&
        code == other.code &&
        listEquality.equals(details, other.details) &&
        timestamp == other.timestamp;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([success, message, error, code, details, timestamp]);
}

UserValidationErrorStruct createUserValidationErrorStruct({
  bool? success,
  String? message,
  String? error,
  String? code,
  String? timestamp,
}) =>
    UserValidationErrorStruct(
      success: success,
      message: message,
      error: error,
      code: code,
      timestamp: timestamp,
    );
