// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FieldValidationErrorStruct extends BaseStruct {
  FieldValidationErrorStruct({
    String? field,
    String? error,
    String? extendedError,
  })  : _field = field,
        _error = error,
        _extendedError = extendedError;

  // "field" field.
  String? _field;
  String get field => _field ?? '';
  set field(String? val) => _field = val;

  bool hasField() => _field != null;

  // "error" field.
  String? _error;
  String get error => _error ?? '';
  set error(String? val) => _error = val;

  bool hasError() => _error != null;

  // "extendedError" field.
  String? _extendedError;
  String get extendedError => _extendedError ?? '';
  set extendedError(String? val) => _extendedError = val;

  bool hasExtendedError() => _extendedError != null;

  static FieldValidationErrorStruct fromMap(Map<String, dynamic> data) =>
      FieldValidationErrorStruct(
        field: data['field'] as String?,
        error: data['error'] as String?,
        extendedError: data['extendedError'] as String?,
      );

  static FieldValidationErrorStruct? maybeFromMap(dynamic data) => data is Map
      ? FieldValidationErrorStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'field': _field,
        'error': _error,
        'extendedError': _extendedError,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'field': serializeParam(
          _field,
          ParamType.String,
        ),
        'error': serializeParam(
          _error,
          ParamType.String,
        ),
        'extendedError': serializeParam(
          _extendedError,
          ParamType.String,
        ),
      }.withoutNulls;

  static FieldValidationErrorStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      FieldValidationErrorStruct(
        field: deserializeParam(
          data['field'],
          ParamType.String,
          false,
        ),
        error: deserializeParam(
          data['error'],
          ParamType.String,
          false,
        ),
        extendedError: deserializeParam(
          data['extendedError'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'FieldValidationErrorStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is FieldValidationErrorStruct &&
        field == other.field &&
        error == other.error &&
        extendedError == other.extendedError;
  }

  @override
  int get hashCode => const ListEquality().hash([field, error, extendedError]);
}

FieldValidationErrorStruct createFieldValidationErrorStruct({
  String? field,
  String? error,
  String? extendedError,
}) =>
    FieldValidationErrorStruct(
      field: field,
      error: error,
      extendedError: extendedError,
    );
