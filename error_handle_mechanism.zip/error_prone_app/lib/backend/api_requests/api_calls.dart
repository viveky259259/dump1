import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';
import 'interceptors.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start Features Group Code

class FeaturesGroup {
  static String getBaseUrl() => 'http://localhost:3000/api';
  static Map<String, String> headers = {};
  static ProductsCall productsCall = ProductsCall();
  static UserRegistrationCall userRegistrationCall = UserRegistrationCall();

  static final interceptors = [
    InternetInterceptor(),
    EncryptionInterceptor(),
    GlobalAppInterceptor(),
    AuthorizationInterceptor(),
    AuthenticationInterceptor(),
    UserInterceptor(),
    DecryptionInterceptor(),
  ];
}

class ProductsCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = FeaturesGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Products',
        apiUrl: '${baseUrl}/products',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      FeaturesGroup.interceptors,
    );
  }
}

class UserRegistrationCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = FeaturesGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'User Registration',
        apiUrl: '${baseUrl}/register',
        callType: ApiCallType.POST,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        bodyType: BodyType.JSON,
        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      FeaturesGroup.interceptors,
    );
  }
}

/// End Features Group Code

/// Start Error Prone APIs Group Code

class ErrorProneAPIsGroup {
  static String getBaseUrl() => 'http://localhost:3000/api/error';
  static Map<String, String> headers = {};
  static InternalCall internalCall = InternalCall();
  static APIRateLimitingCall aPIRateLimitingCall = APIRateLimitingCall();
  static BadRequestCall badRequestCall = BadRequestCall();
  static NotFoundCall notFoundCall = NotFoundCall();
  static UnauthorizedCall unauthorizedCall = UnauthorizedCall();
  static UserExistsCall userExistsCall = UserExistsCall();

  static final interceptors = [
    InternetInterceptor(),
    EncryptionInterceptor(),
    GlobalAppInterceptor(),
    AuthenticationInterceptor(),
    UserInterceptor(),
    AuthorizationInterceptor(),
    DecryptionInterceptor(),
  ];
}

class InternalCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ErrorProneAPIsGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Internal ',
        apiUrl: '${baseUrl}/internal',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ErrorProneAPIsGroup.interceptors,
    );
  }
}

class APIRateLimitingCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ErrorProneAPIsGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'API Rate Limiting',
        apiUrl: '${baseUrl}/rate-limit',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ErrorProneAPIsGroup.interceptors,
    );
  }
}

class BadRequestCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ErrorProneAPIsGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Bad Request',
        apiUrl: '${baseUrl}/bad-request',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ErrorProneAPIsGroup.interceptors,
    );
  }
}

class NotFoundCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ErrorProneAPIsGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Not Found',
        apiUrl: '${baseUrl}/not-found',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ErrorProneAPIsGroup.interceptors,
    );
  }
}

class UnauthorizedCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ErrorProneAPIsGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Unauthorized',
        apiUrl: '${baseUrl}/unauthorized',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ErrorProneAPIsGroup.interceptors,
    );
  }
}

class UserExistsCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ErrorProneAPIsGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'User Exists',
        apiUrl: '${baseUrl}/user-exists',
        callType: ApiCallType.GET,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ErrorProneAPIsGroup.interceptors,
    );
  }
}

/// End Error Prone APIs Group Code

/// Start Control Group Code

class ControlGroup {
  static String getBaseUrl() => 'http://localhost/api';
  static Map<String, String> headers = {};
  static StopFailingCall stopFailingCall = StopFailingCall();

  static final interceptors = [
    EncryptionInterceptor(),
    UserInterceptor(),
    GlobalAppInterceptor(),
    AuthorizationInterceptor(),
    AuthenticationInterceptor(),
    InternetInterceptor(),
    DecryptionInterceptor(),
  ];
}

class StopFailingCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ControlGroup.getBaseUrl();

    return FFApiInterceptor.makeApiCall(
      // ignore: prefer_const_constructors - can be mutated by interceptors
      ApiCallOptions(
        callName: 'Stop Failing',
        apiUrl: '${baseUrl}/control/stop-failing',
        callType: ApiCallType.POST,
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        headers: {},
        // ignore: prefer_const_literals_to_create_immutables - can be mutated by interceptors
        params: {},

        bodyType: BodyType.JSON,
        returnBody: true,
        encodeBodyUtf8: false,
        decodeUtf8: false,
        cache: false,
        isStreamingApi: false,
        alwaysAllowBody: false,
      ),

      ControlGroup.interceptors,
    );
  }
}

/// End Control Group Code

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
