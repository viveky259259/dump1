import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/custom_functions.dart' as functions;
import 'user_registration_widget.dart' show UserRegistrationWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class UserRegistrationModel extends FlutterFlowModel<UserRegistrationWidget> {
  ///  Local state fields for this page.

  String? emailErrorMessage;

  String? passwordErrorMessage;

  String? phoneError;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for FullName widget.
  FocusNode? fullNameFocusNode;
  TextEditingController? fullNameTextController;
  String? Function(BuildContext, String?)? fullNameTextControllerValidator;
  // State field(s) for EmailAddress widget.
  FocusNode? emailAddressFocusNode;
  TextEditingController? emailAddressTextController;
  String? Function(BuildContext, String?)? emailAddressTextControllerValidator;
  // State field(s) for PhoneNumber widget.
  FocusNode? phoneNumberFocusNode;
  TextEditingController? phoneNumberTextController;
  String? Function(BuildContext, String?)? phoneNumberTextControllerValidator;
  // State field(s) for Password widget.
  FocusNode? passwordFocusNode;
  TextEditingController? passwordTextController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? passwordTextControllerValidator;
  // State field(s) for ConfirmPassword widget.
  FocusNode? confirmPasswordFocusNode;
  TextEditingController? confirmPasswordTextController;
  late bool confirmPasswordVisibility;
  String? Function(BuildContext, String?)?
      confirmPasswordTextControllerValidator;
  // State field(s) for Checkbox widget.
  bool? checkboxValue;
  // Stores action output result for [Backend Call - API (User Registration)] action in Button widget.
  ApiCallResponse? userRegistrationResponse;

  @override
  void initState(BuildContext context) {
    passwordVisibility = false;
    confirmPasswordVisibility = false;
  }

  @override
  void dispose() {
    fullNameFocusNode?.dispose();
    fullNameTextController?.dispose();

    emailAddressFocusNode?.dispose();
    emailAddressTextController?.dispose();

    phoneNumberFocusNode?.dispose();
    phoneNumberTextController?.dispose();

    passwordFocusNode?.dispose();
    passwordTextController?.dispose();

    confirmPasswordFocusNode?.dispose();
    confirmPasswordTextController?.dispose();
  }

  /// Action blocks.
  Future updateFieldErrors(
    BuildContext context, {
    UserValidationErrorStruct? userValidationError,
  }) async {
    emailErrorMessage = userValidationError!.details
            .where((e) => e.field == 'email')
            .toList()
            .firstOrNull!
            .hasError()
        ? userValidationError?.details
            ?.where((e) => e.field == 'email')
            .toList()
            ?.firstOrNull
            ?.error
        : '';
    phoneError = userValidationError!.details
            .where((e) => e.field == 'phone')
            .toList()
            .firstOrNull!
            .hasError()
        ? userValidationError?.details
            ?.where((e) => e.field == 'phone')
            .toList()
            ?.firstOrNull
            ?.error
        : '';
    passwordErrorMessage = userValidationError!.details
            .where((e) => e.field == 'password')
            .toList()
            .firstOrNull!
            .hasError()
        ? userValidationError?.details
            ?.where((e) => e.field == 'password')
            .toList()
            ?.firstOrNull
            ?.error
        : '';
  }

  Future clearErorrMessages(BuildContext context) async {
    emailErrorMessage = null;
    passwordErrorMessage = null;
    phoneError = null;
  }
}
