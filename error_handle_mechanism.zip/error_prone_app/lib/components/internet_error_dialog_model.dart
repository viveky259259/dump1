import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'internet_error_dialog_widget.dart' show InternetErrorDialogWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InternetErrorDialogModel
    extends FlutterFlowModel<InternetErrorDialogWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
