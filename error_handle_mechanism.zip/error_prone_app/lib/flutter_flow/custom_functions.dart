import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/schema/structs/index.dart';
import '/backend/schema/enums/enums.dart';

String? getErrorMessage(dynamic apiResponse) {
  Map<String, dynamic> mappedResponse = {};
  try {
    if (apiResponse is String) {
      mappedResponse = jsonDecode(apiResponse);
    }
    if (mappedResponse.containsKey('message')) {
      return mappedResponse['message'];
    }
  } catch (e) {
    return 'Something went wrong!';
  }
  return 'Something went wrong!';
}

String? getErrorCode(dynamic apiResponse) {
  if (apiResponse is Map<String, dynamic> && apiResponse.containsKey('code')) {
    return apiResponse['code'];
  }
  return 'Something went wrong!';
}
