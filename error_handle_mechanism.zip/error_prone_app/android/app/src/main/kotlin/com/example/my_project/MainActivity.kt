package com.mycompany.errorproneapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
