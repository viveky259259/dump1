const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Logging configuration
const ENABLE_DETAILED_LOGGING = process.env.DETAILED_LOGGING !== 'false'; // Default enabled
const LOG_SENSITIVE_DATA = process.env.LOG_SENSITIVE_DATA === 'true'; // Default disabled

// Middleware
app.use(cors());

// Standard HTTP Headers Middleware - Add at least 10 standard headers
app.use((req, res, next) => {
  // 1. X-Content-Type-Options - Prevents MIME type sniffing
  res.set('X-Content-Type-Options', 'nosniff');
  
  // 2. X-Frame-Options - Prevents clickjacking attacks
  res.set('X-Frame-Options', 'DENY');
  
  // 3. X-XSS-Protection - Enables XSS filtering in browsers
  res.set('X-XSS-Protection', '1; mode=block');
  
  // 4. Strict-Transport-Security - Enforces HTTPS (if using HTTPS)
  res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  
  // 5. Content-Security-Policy - Prevents XSS and other injection attacks
  res.set('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; font-src 'self'; object-src 'none'; media-src 'self'; frame-src 'none';");
  
  // 6. Referrer-Policy - Controls referrer information
  res.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // 7. Permissions-Policy - Controls browser features
  res.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
  
  // 8. Cache-Control - Controls caching behavior
  res.set('Cache-Control', 'no-cache, no-store, must-revalidate, private');
  
  // 9. Pragma - HTTP/1.0 cache control
  res.set('Pragma', 'no-cache');
  
  // 10. Expires - Sets expiration date for caching
  res.set('Expires', '0');
  
  // 11. X-Powered-By - Remove default Express header and set custom
  res.removeHeader('X-Powered-By');
  res.set('X-Powered-By', 'Error-Handle-Mechanism-Demo-Server/1.0');
  
  // 12. Server - Custom server identification
  res.set('Server', 'Demo-API-Server/1.0');
  
  // 13. X-API-Version - API version information
  res.set('X-API', '1.0.0');
  res.set("Access-Control-Expose-Headers", "*");
  
  // 14. X-Response-Time - Will be set after request processing
  req.startTime = Date.now();
  
  // 15. X-Request-ID - Unique request identifier for tracking
  const requestId = req.headers['x-request-id'] || Math.random().toString(36).substring(2, 15);
  res.set('X-Request-ID', requestId);
  req.requestId = requestId;
  
  // Override res.end to add response time header
  const originalEnd = res.end;
  res.end = function(...args) {
    const responseTime = Date.now() - req.startTime;
    res.set('X-Response-Time', `${responseTime}ms`);
    return originalEnd.apply(this, args);
  };
  
  next();
});

// Request/Response Logging Middleware
app.use((req, res, next) => {
  if (!ENABLE_DETAILED_LOGGING) {
    return next();
  }
  
  const startTime = Date.now();
  const requestId = Math.random().toString(36).substring(2, 15);
  
  // Helper function to sanitize sensitive data
  function sanitizeData(data) {
    if (!LOG_SENSITIVE_DATA && data && typeof data === 'object') {
      const sanitized = { ...data };
      const sensitiveFields = ['password', 'token', 'authorization', 'secret', 'key', 'auth'];
      
      for (const field of sensitiveFields) {
        if (sanitized[field]) {
          sanitized[field] = '***REDACTED***';
        }
      }
      return sanitized;
    }
    return data;
  }
  
  // Helper function to sanitize headers
  function sanitizeHeaders(headers) {
    if (!LOG_SENSITIVE_DATA && headers) {
      const sanitized = { ...headers };
      const sensitiveHeaders = ['authorization', 'cookie', 'x-api-key', 'x-auth-token'];
      
      for (const header of sensitiveHeaders) {
        if (sanitized[header]) {
          sanitized[header] = '***REDACTED***';
        }
      }
      return sanitized;
    }
    return headers;
  }
  
  // Log incoming request
  console.log('\n' + '='.repeat(80));
  console.log(`📥 INCOMING REQUEST [${requestId}]`);
  console.log(`🕐 Time: ${new Date().toISOString()}`);
  console.log(`🔗 ${req.method} ${req.originalUrl}`);
  console.log(`📍 IP: ${req.ip || req.connection.remoteAddress}`);
  console.log(`🌐 User-Agent: ${req.headers['user-agent'] || 'Unknown'}`);
  console.log(`📨 Headers:`, JSON.stringify(sanitizeHeaders(req.headers), null, 2));
  
  if (req.body && Object.keys(req.body).length > 0) {
    console.log(`📦 Body:`, JSON.stringify(sanitizeData(req.body), null, 2));
  }
  
  if (req.query && Object.keys(req.query).length > 0) {
    console.log(`🔍 Query:`, JSON.stringify(sanitizeData(req.query), null, 2));
  }
  
  // Store original res.json and res.send to intercept responses
  const originalJson = res.json;
  const originalSend = res.send;
  const originalEnd = res.end;
  
  res.json = function(data) {
    const duration = Date.now() - startTime;
    
    console.log('\n' + '-'.repeat(80));
    console.log(`📤 OUTGOING RESPONSE [${requestId}]`);
    console.log(`🕐 Duration: ${duration}ms`);
    console.log(`📊 Status: ${res.statusCode} ${getStatusText(res.statusCode)}`);
    console.log(`⚡ Performance: ${duration < 100 ? '🟢 Fast' : duration < 500 ? '🟡 Medium' : '🔴 Slow'}`);
    console.log(`📨 Headers:`, JSON.stringify(sanitizeHeaders(res.getHeaders()), null, 2));
    console.log(`📦 Response Body:`, JSON.stringify(sanitizeData(data), null, 2));
    console.log('='.repeat(80) + '\n');
    
    return originalJson.call(this, data);
  };
  
  res.send = function(data) {
    const duration = Date.now() - startTime;
    
    console.log('\n' + '-'.repeat(80));
    console.log(`📤 OUTGOING RESPONSE [${requestId}]`);
    console.log(`🕐 Duration: ${duration}ms`);
    console.log(`📊 Status: ${res.statusCode} ${getStatusText(res.statusCode)}`);
    console.log(`⚡ Performance: ${duration < 100 ? '🟢 Fast' : duration < 500 ? '🟡 Medium' : '🔴 Slow'}`);
    console.log(`📨 Headers:`, JSON.stringify(sanitizeHeaders(res.getHeaders()), null, 2));
    console.log(`📦 Response Body:`, typeof data === 'string' ? data : JSON.stringify(sanitizeData(data), null, 2));
    console.log('='.repeat(80) + '\n');
    
    return originalSend.call(this, data);
  };
  
  res.end = function(data) {
    const duration = Date.now() - startTime;
    
    if (!res.headersSent) {
      console.log('\n' + '-'.repeat(80));
      console.log(`📤 OUTGOING RESPONSE [${requestId}]`);
      console.log(`🕐 Duration: ${duration}ms`);
      console.log(`📊 Status: ${res.statusCode} ${getStatusText(res.statusCode)}`);
      console.log(`⚡ Performance: ${duration < 100 ? '🟢 Fast' : duration < 500 ? '🟡 Medium' : '🔴 Slow'}`);
      console.log(`📨 Headers:`, JSON.stringify(sanitizeHeaders(res.getHeaders()), null, 2));
      console.log(`📦 Response Body: ${data || '(empty)'}`);
      console.log('='.repeat(80) + '\n');
    }
    
    return originalEnd.call(this, data);
  };
  
  next();
});

// Helper function to get status text
function getStatusText(statusCode) {
  const statusTexts = {
    200: 'OK',
    201: 'Created',
    400: 'Bad Request',
    401: 'Unauthorized',
    403: 'Forbidden',
    404: 'Not Found',
    409: 'Conflict',
    422: 'Unprocessable Entity',
    429: 'Too Many Requests',
    500: 'Internal Server Error',
    503: 'Service Unavailable',
    504: 'Gateway Timeout',
    507: 'Insufficient Storage'
  };
  return statusTexts[statusCode] || 'Unknown';
}

// Encryption/Decryption utilities
const SECRET_KEY = 'MySecretKey123!@#'; // Should match Flutter app key

// Simple XOR encryption function (matching Flutter implementation)
function encrypt(data) {
  const keyBytes = Buffer.from(SECRET_KEY, 'utf8');
  const dataBytes = Buffer.from(data, 'utf8');
  const encryptedBytes = [];
  
  for (let i = 0; i < dataBytes.length; i++) {
    encryptedBytes.push(dataBytes[i] ^ keyBytes[i % keyBytes.length]);
  }
  
  return Buffer.from(encryptedBytes).toString('base64');
}

// Simple XOR decryption function (matching Flutter implementation)
function decrypt(encryptedData) {
  try {
    const keyBytes = Buffer.from(SECRET_KEY, 'utf8');
    const encryptedBytes = Buffer.from(encryptedData, 'base64');
    const decryptedBytes = [];
    
    for (let i = 0; i < encryptedBytes.length; i++) {
      decryptedBytes.push(encryptedBytes[i] ^ keyBytes[i % keyBytes.length]);
    }
    
    return Buffer.from(decryptedBytes).toString('utf8');
  } catch (error) {
    throw new Error(`Failed to decrypt data: ${error.message}`);
  }
}

// Middleware to handle encrypted requests
app.use((req, res, next) => {
  // Check if request is encrypted
  if (req.headers['x-encrypted'] === 'true') {
    let body = '';
    
    req.on('data', chunk => {
      body += chunk.toString();
    });
    
    req.on('end', () => {
      try {
        // Decrypt the request body
        const decryptedBody = decrypt(body);
        console.log('decryptedBody', decryptedBody);
        // Parse as JSON if possible
        try {
          req.body = JSON.parse(decryptedBody);
        } catch (parseError) {
          req.body = decryptedBody;
        }
        
        next();
      } catch (error) {
        console.error('Decryption error:', error);
        res.status(400).json({
          success: false,
          message: 'Failed to decrypt request',
          error: error.message
        });
      }
    });
  } else {
    // Handle normal requests
    express.json()(req, res, next);
  }
});

app.use(express.urlencoded({ extended: true }));

// Middleware to encrypt responses
app.use((req, res, next) => {
  // Store original json method
  const originalJson = res.json;
  
  // Override json method to encrypt response if needed
  console.log('req.headers', req.headers);
  res.json = function(data) {
    console.log('adding headers to response');
    if (req.headers['x-encrypted'] === 'true') {
      try {
        // Encrypt the response
        const jsonString = JSON.stringify(data);
        const encryptedData = encrypt(jsonString);
        
        // Set encryption header
        res.set('X-Encrypted', 'true');
        res.set('x-encrypted', 'true');
        res.set('x-encrypted-data', 'true');
        res.set('Content-Type', 'application/json');
        
        
        // Send encrypted response as proper JSON
        const encryptedResponse = {
          success: true,
          encrypted: true,
          data: encryptedData,
          timestamp: new Date().toISOString()
        };
        
        return originalJson.call(this, encryptedResponse);
      } catch (error) {
        console.error('Encryption error:', error);
        return originalJson.call(this, {
          success: false,
          message: 'Failed to encrypt response',
          error: error.message
        });
      }
    } else {
      // Send normal JSON response
      console.log('res headers2', res.headers);
      return originalJson.call(this, data);
    }
  };
  
  next();
});

// Fake products data
const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 99.99,
    category: "Electronics",
    description: "High-quality wireless headphones with noise cancellation",
    stock: 50,
    brand: "TechSound"
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 249.99,
    category: "Electronics",
    description: "Feature-rich smartwatch with health tracking",
    stock: 30,
    brand: "FitTech"
  },
  {
    id: 3,
    name: "Coffee Maker",
    price: 79.99,
    category: "Home & Kitchen",
    description: "Programmable coffee maker with timer",
    stock: 25,
    brand: "BrewMaster"
  },
  {
    id: 4,
    name: "Running Shoes",
    price: 129.99,
    category: "Sports",
    description: "Comfortable running shoes with excellent grip",
    stock: 40,
    brand: "RunFast"
  },
  {
    id: 5,
    name: "Laptop Stand",
    price: 39.99,
    category: "Office",
    description: "Adjustable laptop stand for better ergonomics",
    stock: 60,
    brand: "DeskPro"
  }
];

// Store registered users (in memory for demo)
const users = [];

// Failure simulation flag
let startFailing = false;

let tryLaterError = false;

let tokenExpiredError = false;
let invalidUserError = false;

let serviceUnavailableError = false;

let securityBreachError = false;

let userAlreadyExistsError = false;

let userFieldValidationError = true;

// Routes

// Health check endpoint
app.get('/', (req, res) => {
  // Add additional headers for the health check endpoint
  res.set('X-Rate-Limit-Limit', '1000');
  res.set('X-Rate-Limit-Remaining', '999');
  res.set('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 3600);
  res.set('X-Content-Language', 'en-US');
  res.set('X-Robots-Tag', 'noindex, nofollow');
  
  res.json({ 
    message: 'Error Handle Mechanism Demo Server',
    status: 'running',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    headers: {
      security: [
        'X-Content-Type-Options: nosniff',
        'X-Frame-Options: DENY', 
        'X-XSS-Protection: 1; mode=block',
        'Strict-Transport-Security: max-age=31536000; includeSubDomains; preload',
        'Content-Security-Policy: default-src \'self\'; ...',
        'Referrer-Policy: strict-origin-when-cross-origin',
        'Permissions-Policy: camera=(), microphone=(), ...'
      ],
      performance: [
        'Cache-Control: no-cache, no-store, must-revalidate, private',
        'Pragma: no-cache',
        'Expires: 0',
        'X-Response-Time: (dynamic)'
      ],
      api: [
        'X-API-Version: 1.0.0',
        'X-Request-ID: (unique per request)',
        'X-Powered-By: Error-Handle-Mechanism-Demo-Server/1.0',
        'Server: Demo-API-Server/1.0',
        'X-Rate-Limit-*: (rate limiting info)',
        'X-Content-Language: en-US',
        'X-Robots-Tag: noindex, nofollow'
      ]
    },
    encryption: 'Add "X-Encrypted: true" header to encrypt request/response',
    endpoints: {
      products: 'GET /api/products',
      register: 'POST /api/register',
      users: 'GET /api/users',
      encryption: 'POST /api/test-encryption (for testing encryption)',
      headers: 'GET /api/test-headers (for testing all headers)',
      control: {
        status: 'GET /api/control/status',
        startFailing: 'POST /api/control/start-failing',
        stopFailing: 'POST /api/control/stop-failing',
        register: {
          tryLaterError: 'POST /api/control/register/try-later-error',
          tokenExpiredError: 'POST /api/control/register/token-expired-error',
          invalidUserError: 'POST /api/control/register/invalid-user-error',
          serviceUnavailableError: 'POST /api/control/register/service-unavailable-error',
          passwordPolicyError: 'POST /api/control/register/password-policy-error',
          resetAllErrors: 'POST /api/control/register/reset-all-errors'
        },
        security: {
          securityBreachError: 'POST /api/control/security-breach-error',
          userAlreadyExistsError: 'POST /api/control/user-already-exists-error'
        },
        logging: {
          status: 'GET /api/control/logging/status',
          info: 'POST /api/control/logging/detailed'
        }
      },
      errors: {
        internal: 'GET /api/error/internal',
        rateLimit: 'GET /api/error/rate-limit',
        badRequest: 'GET /api/error/bad-request',
        notFound: 'GET /api/error/not-found',
        unauthorized: 'GET /api/error/unauthorized',
        userExists: 'GET /api/error/user-exists',
        securityBreach: 'GET /api/error/security-breach'
      }
    }
  });
});

// Test encryption endpoint
app.post('/api/test-encryption', (req, res) => {
  // Add rate limiting headers
  res.set('X-Rate-Limit-Limit', '100');
  res.set('X-Rate-Limit-Remaining', '95');
  res.set('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 3600);
  
  res.json({
    success: true,
    message: 'Encryption test successful',
    received: req.body,
    encrypted: req.headers['x-encrypted'] === 'true',
    timestamp: new Date().toISOString()
  });
});

// Test headers endpoint - Shows all headers being set
app.get('/api/test-headers', (req, res) => {
  // Add specific headers for this endpoint
  res.set('X-Rate-Limit-Limit', '500');
  res.set('X-Rate-Limit-Remaining', '499');
  res.set('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 3600);
  res.set('X-Content-Language', 'en-US');
  res.set('X-Robots-Tag', 'noindex, nofollow');
  res.set('X-Custom-Header', 'HeaderTestEndpoint');
  
  // Get all current response headers
  const responseHeaders = res.getHeaders();
  
  res.json({
    success: true,
    message: 'Headers test endpoint - All standard headers are being set',
    timestamp: new Date().toISOString(),
    requestHeaders: req.headers,
    responseHeaders: responseHeaders,
    headerCount: Object.keys(responseHeaders).length,
    standardHeaders: {
      security: {
        'X-Content-Type-Options': responseHeaders['x-content-type-options'],
        'X-Frame-Options': responseHeaders['x-frame-options'],
        'X-XSS-Protection': responseHeaders['x-xss-protection'],
        'Strict-Transport-Security': responseHeaders['strict-transport-security'],
        'Content-Security-Policy': responseHeaders['content-security-policy'],
        'Referrer-Policy': responseHeaders['referrer-policy'],
        'Permissions-Policy': responseHeaders['permissions-policy']
      },
      performance: {
        'Cache-Control': responseHeaders['cache-control'],
        'Pragma': responseHeaders['pragma'],
        'Expires': responseHeaders['expires'],
        'X-Response-Time': responseHeaders['x-response-time']
      },
      api: {
        'X-API-Version': responseHeaders['x-api-version'],
        'X-Request-ID': responseHeaders['x-request-id'],
        'X-Powered-By': responseHeaders['x-powered-by'],
        'Server': responseHeaders['server'],
        'X-Rate-Limit-Limit': responseHeaders['x-rate-limit-limit'],
        'X-Rate-Limit-Remaining': responseHeaders['x-rate-limit-remaining'],
        'X-Rate-Limit-Reset': responseHeaders['x-rate-limit-reset'],
        'X-Content-Language': responseHeaders['x-content-language'],
        'X-Robots-Tag': responseHeaders['x-robots-tag']
      }
    }
  });
});

// 1. Get list of products
app.get('/api/products', (req, res) => {
  try {
    // Add rate limiting headers
    res.set('X-Rate-Limit-Limit', '200');
    res.set('X-Rate-Limit-Remaining', '199');
    res.set('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 3600);
    res.set('X-Content-Language', 'en-US');
    
    // Check if we should simulate failure
    if (securityBreachError) {
      return res.status(470).json({
        success: false,
        message: 'Security Breach Detected',
        error: 'Potential security threat detected. Access has been temporarily restricted.',
        code: 'SECURITY_BREACH',
        details: {
          threatLevel: 'HIGH',
          actionRequired: 'Contact administrator immediately',
          incidentId: `SB-${Date.now()}`,
          blockedAt: new Date().toISOString()
        },
        timestamp: new Date().toISOString()
      });
    }

    if (userAlreadyExistsError) {
      return res.status(409).json({
        success: false,
        message: 'User Already Exists',
        error: 'A user with this configuration is already registered in the system',
        code: 'USER_ALREADY_EXISTS',
        details: {
          conflictField: 'system_access',
          conflictValue: 'products_access_denied'
        },
        timestamp: new Date().toISOString()
      });
    }

    if (startFailing) {
      return res.status(500).json({
        success: false,
        message: 'Internal Server Error',
        error: 'Something went wrong while retrieving products',
        code: 'INTERNAL_ERROR',
        timestamp: new Date().toISOString()
      });
    }

    if (tokenExpiredError) {
      return res.status(401).json({
        success: false,
        message: 'Unauthorized',
        error: 'Token expired',
        code: 'TOKEN_EXPIRED',
        timestamp: new Date().toISOString()
      });
    }

    if (invalidUserError) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden',
        error: 'Invalid user',
        code: 'INVALID_USER',
        timestamp: new Date().toISOString()
      });
    }

    if (serviceUnavailableError) {
      return res.status(503).json({
        success: false,
        message: 'Service Unavailable',
        error: 'Service unavailable',
        code: 'SERVICE_UNAVAILABLE',
        timestamp: new Date().toISOString()
      });
    }

    // Simulate some processing time
    setTimeout(() => {
      res.json({
        success: true,
        data: products,
        count: products.length,
        message: 'Products retrieved successfully'
      });
    }, 100);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve products',
      error: error.message
    });
  }
});

// 2. Register user
app.post('/api/register', (req, res) => {
  try {
    // Add rate limiting headers
    res.set('X-Rate-Limit-Limit', '50');
    res.set('X-Rate-Limit-Remaining', '49');
    res.set('X-Rate-Limit-Reset', Math.floor(Date.now() / 1000) + 3600);
    res.set('X-Content-Language', 'en-US');
    
    const { username, email, password, firstName, lastName } = req.body;

    // Error Test Cases - Check error flags first
    
    // 1. Security Breach Error (470) - highest priority
    if (securityBreachError) {
      return res.status(470).json({
        success: false,
        message: 'Security Breach Detected',
        error: 'Potential security threat detected. Registration has been temporarily disabled.',
        code: 'SECURITY_BREACH',
        details: {
          threatLevel: 'HIGH',
          actionRequired: 'Contact administrator immediately',
          incidentId: `SB-${Date.now()}`,
          blockedAt: new Date().toISOString()
        },
        timestamp: new Date().toISOString()
      });
    }
    
    // 1.5. Password Policy and User Registration Error (422) - validation errors
    if (userFieldValidationError) {
      return res.status(422).json({
        success: false,
        message: 'Registration Failed - Multiple Validation Errors',
        error: 'Password does not meet security policy requirements and user credentials are already registered',
        code: 'VALIDATION_FAILED',
        details: [
          {
            field: 'password',
            error: 'Password does not meet security policy requirements',
            extendedError: 'Must be at least 8 characters long;Must contain at least one uppercase letter;Must contain at least one lowercase letter;Must contain at least one number;Must contain at least one special character (!@#$%^&*);Cannot contain common patterns or dictionary words',
          },
          {
            field: 'email',
            error: 'Email address is already registered in the system',
          },
          {
            field: 'phone',
            error: 'Phone number is already associated with an existing account',
          },
        ],
        timestamp: new Date().toISOString()
      });
    }
    
    // 2. User Already Exists Error (409) - simulated conflict
    if (userAlreadyExistsError) {
      return res.status(409).json({
        success: false,
        message: 'User Already Exists',
        error: 'A user with this email or username is already registered in the system',
        code: 'USER_ALREADY_EXISTS',
        details: {
          conflictField: 'simulated_conflict',
          conflictValue: 'registration_blocked'
        },
        timestamp: new Date().toISOString()
      });
    }
    
    // 3. Service Unavailable Error (503)
    if (serviceUnavailableError) {
      return res.status(503).json({
        success: false,
        message: 'Service Unavailable',
        error: 'Registration service is temporarily unavailable. Please try again later.',
        code: 'SERVICE_UNAVAILABLE',
        retryAfter: 300, // 5 minutes
        timestamp: new Date().toISOString()
      });
    }

    // 4. Rate Limit Error (429) - triggered by tryLaterError flag
    if (tryLaterError) {
      return res.status(429).json({
        success: false,
        message: 'Too Many Requests',
        error: 'Too many registration attempts. Please try again later.',
        code: 'RATE_LIMIT_EXCEEDED',
        retryAfter: 60, // 1 minute
        timestamp: new Date().toISOString()
      });
    }

    // 5. Token Expired Error (401) - if registration requires authentication
    if (tokenExpiredError) {
      return res.status(401).json({
        success: false,
        message: 'Authentication Required',
        error: 'Your session has expired. Please login again to register.',
        code: 'TOKEN_EXPIRED',
        timestamp: new Date().toISOString()
      });
    }

    // 6. Invalid User Error (403) - user not authorized to register
    if (invalidUserError) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden',
        error: 'You are not authorized to register new users.',
        code: 'INVALID_USER_PERMISSION',
        timestamp: new Date().toISOString()
      });
    }

    // 7. Internal Server Error (500) - triggered by startFailing flag
    if (startFailing) {
      return res.status(500).json({
        success: false,
        message: 'Internal Server Error',
        error: 'An unexpected error occurred during registration.',
        code: 'INTERNAL_ERROR',
        timestamp: new Date().toISOString()
      });
    }

    // Basic validation
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields',
        errors: {
          username: !username ? 'Username is required' : null,
          email: !email ? 'Email is required' : null,
          password: !password ? 'Password is required' : null
        },
        code: 'VALIDATION_ERROR',
        timestamp: new Date().toISOString()
      });
    }

    // Password strength validation
    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password too weak',
        error: 'Password must be at least 6 characters long',
        code: 'WEAK_PASSWORD',
        timestamp: new Date().toISOString()
      });
    }

    // Username length validation
    if (username.length < 3) {
      return res.status(400).json({
        success: false,
        message: 'Invalid username',
        error: 'Username must be at least 3 characters long',
        code: 'INVALID_USERNAME',
        timestamp: new Date().toISOString()
      });
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format',
        error: 'Please provide a valid email address',
        code: 'INVALID_EMAIL',
        timestamp: new Date().toISOString()
      });
    }

    // Check for banned email domains
    const bannedDomains = ['tempmail.com', 'throwaway.email', 'guerrillamail.com'];
    const emailDomain = email.split('@')[1];
    if (bannedDomains.includes(emailDomain)) {
      return res.status(422).json({
        success: false,
        message: 'Email Not Allowed',
        error: 'Temporary email addresses are not allowed for registration',
        code: 'BANNED_EMAIL_DOMAIN',
        timestamp: new Date().toISOString()
      });
    }

    // Check if user already exists
    const existingUser = users.find(user => user.email === email || user.username === username);
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'User already exists',
        error: 'A user with this email or username is already registered',
        code: 'USER_ALREADY_EXISTS',
        conflictField: existingUser.email === email ? 'email' : 'username',
        timestamp: new Date().toISOString()
      });
    }

    // Simulate database connection timeout (if a special username is used)
    if (username === 'timeout_test') {
      return res.status(504).json({
        success: false,
        message: 'Gateway Timeout',
        error: 'Database connection timeout. Please try again.',
        code: 'DATABASE_TIMEOUT',
        timestamp: new Date().toISOString()
      });
    }

    // Simulate insufficient storage (if a special username is used)
    if (username === 'storage_test') {
      return res.status(507).json({
        success: false,
        message: 'Insufficient Storage',
        error: 'Unable to create user account due to insufficient storage space',
        code: 'INSUFFICIENT_STORAGE',
        timestamp: new Date().toISOString()
      });
    }

    // Create new user
    const newUser = {
      id: users.length + 1,
      username,
      email,
      firstName: firstName || '',
      lastName: lastName || '',
      createdAt: new Date().toISOString(),
      status: 'active'
    };

    users.push(newUser);

    // Return user data (without password)
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: newUser,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Registration failed',
      error: error.message,
      code: 'UNEXPECTED_ERROR',
      timestamp: new Date().toISOString()
    });
  }
});

// Error endpoints for testing

// 3. Internal Server Error (500)
app.get('/api/error/internal', (req, res) => {
  res.status(500).json({
    success: false,
    message: 'Internal Server Error',
    error: 'Something went wrong on the server side',
    code: 'INTERNAL_ERROR',
    timestamp: new Date().toISOString()
  });
});

// 4. Rate Limit Error (429)
app.get('/api/error/rate-limit', (req, res) => {
  res.status(429).json({
    success: false,
    message: 'Too Many Requests',
    error: 'Rate limit exceeded. Please try again later.',
    code: 'RATE_LIMIT_EXCEEDED',
    retryAfter: 60,
    timestamp: new Date().toISOString()
  });
});

// 5. Bad Request Error (400)
app.get('/api/error/bad-request', (req, res) => {
  res.status(400).json({
    success: false,
    message: 'Bad Request',
    error: 'The request was malformed or contained invalid parameters',
    code: 'BAD_REQUEST',
    details: 'Missing required query parameters or invalid data format',
    timestamp: new Date().toISOString()
  });
});

// 6. Not Found Error (404)
app.get('/api/error/not-found', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'Resource Not Found',
    error: 'The requested resource could not be found',
    code: 'NOT_FOUND',
    timestamp: new Date().toISOString()
  });
});

// 7. Unauthorized Error (401)
app.get('/api/error/unauthorized', (req, res) => {
  res.status(401).json({
    success: false,
    message: 'Unauthorized',
    error: 'Authentication required to access this resource',
    code: 'UNAUTHORIZED',
    timestamp: new Date().toISOString()
  });
});

// 8. User Already Exists Error (409 Conflict)
app.get('/api/error/user-exists', (req, res) => {
  res.status(409).json({
    success: false,
    message: 'User Already Exists',
    error: 'A user with this email or username is already registered',
    code: 'USER_ALREADY_EXISTS',
    details: {
      conflictField: 'email',
      conflictValue: 'john@example.com'
    },
    timestamp: new Date().toISOString()
  });
});

// 9. Security Breach Error (470)
app.get('/api/error/security-breach', (req, res) => {
  res.status(470).json({
    success: false,
    message: 'Security Breach Detected',
    error: 'Potential security threat detected. Access has been temporarily restricted.',
    code: 'SECURITY_BREACH',
    details: {
      threatLevel: 'HIGH',
      actionRequired: 'Contact administrator immediately',
      incidentId: `SB-${Date.now()}`,
      blockedAt: new Date().toISOString()
    },
    timestamp: new Date().toISOString()
  });
});

// Get registered users (for testing purposes)
app.get('/api/users', (req, res) => {
  // Check if we should simulate failure
  if (securityBreachError) {
    return res.status(470).json({
      success: false,
      message: 'Security Breach Detected',
      error: 'Potential security threat detected. User data access has been temporarily restricted.',
      code: 'SECURITY_BREACH',
      details: {
        threatLevel: 'HIGH',
        actionRequired: 'Contact administrator immediately',
        incidentId: `SB-${Date.now()}`,
        blockedAt: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    });
  }

  if (userAlreadyExistsError) {
    return res.status(409).json({
      success: false,
      message: 'User Already Exists',
      error: 'A user with this configuration is already registered in the system',
      code: 'USER_ALREADY_EXISTS',
      details: {
        conflictField: 'user_access',
        conflictValue: 'user_data_access_denied'
      },
      timestamp: new Date().toISOString()
    });
  }

  if (startFailing) {
    return res.status(409).json({
      success: false,
      message: 'User Already Exists',
      error: 'A user with this email or username is already registered',
      code: 'USER_ALREADY_EXISTS',
      details: {
        conflictField: 'email',
        conflictValue: 'simulated@example.com'
      },
      timestamp: new Date().toISOString()
    });
  }

  if (tryLaterError) {
    return res.status(429).json({
      success: false,
      message: 'Too Many Requests',
      error: 'Too Many Requests',
      code: 'TOO_MANY_REQUESTS',
      timestamp: new Date().toISOString()
    });
  }

  res.json({
    success: true,
    data: users,
    count: users.length,
    message: 'Users retrieved successfully'
  });
});

// Control endpoints for failure simulation

// Enable failure mode
app.post('/api/control/start-failing', (req, res) => {
  startFailing = true;
  res.json({
    success: true,
    message: 'Failure mode enabled',
    data: {
      startFailing: startFailing,
      effects: [
        'GET /api/products will return 500 Internal Server Error',
        'GET /api/users will return 409 User Already Exists'
      ]
    },
    timestamp: new Date().toISOString()
  });
});

// Disable failure mode
app.post('/api/control/stop-failing', (req, res) => {
  startFailing = false;
  res.json({
    success: true,
    message: 'Failure mode disabled',
    data: {
      startFailing: startFailing,
      effects: [
        'All APIs will work normally'
      ]
    },
    timestamp: new Date().toISOString()
  });
});

// Check failure mode status
app.get('/api/control/status', (req, res) => {
  res.json({
    success: true,
    data: {
      startFailing: startFailing,
      tryLaterError: tryLaterError,
      tokenExpiredError: tokenExpiredError,
      invalidUserError: invalidUserError,
      serviceUnavailableError: serviceUnavailableError,
      securityBreachError: securityBreachError,
      userAlreadyExistsError: userAlreadyExistsError,
      passwordPolicyError: userFieldValidationError,
      status: 'Error simulation flags status',
      currentEffects: {
        products: securityBreachError ? 'Returns 470 Security Breach' : (userAlreadyExistsError ? 'Returns 409 User Already Exists' : (startFailing ? 'Returns 500 Internal Server Error' : 'Works normally')),
        users: securityBreachError ? 'Returns 470 Security Breach' : (userAlreadyExistsError ? 'Returns 409 User Already Exists' : (startFailing ? 'Returns 409 User Already Exists' : 'Works normally')),
        register: getRegisterEffects()
      }
    },
    timestamp: new Date().toISOString()
  });
});

// Helper function to describe register API effects
function getRegisterEffects() {
  const effects = [];
  if (securityBreachError) effects.push('Returns 470 Security Breach');
  if (userFieldValidationError) effects.push('Returns 422 Password Policy & User Registration Error');
  if (userAlreadyExistsError) effects.push('Returns 409 User Already Exists');
  if (serviceUnavailableError) effects.push('Returns 503 Service Unavailable');
  if (tryLaterError) effects.push('Returns 429 Rate Limit Exceeded');
  if (tokenExpiredError) effects.push('Returns 401 Token Expired');
  if (invalidUserError) effects.push('Returns 403 Forbidden');
  if (startFailing) effects.push('Returns 500 Internal Server Error');
  
  return effects.length > 0 ? effects : ['Works normally'];
}

// Register API Error Control Endpoints

// Enable/Disable Try Later Error (429)
app.post('/api/control/register/try-later-error', (req, res) => {
  const { enable } = req.body;
  tryLaterError = enable === true;
  res.json({
    success: true,
    message: `Try Later Error ${tryLaterError ? 'enabled' : 'disabled'} for register API`,
    data: { tryLaterError },
    effect: tryLaterError ? 'POST /api/register will return 429 Rate Limit' : 'Register API will work normally for this error',
    timestamp: new Date().toISOString()
  });
});

// Enable/Disable Token Expired Error (401)
app.post('/api/control/register/token-expired-error', (req, res) => {
  const { enable } = req.body;
  tokenExpiredError = enable === true;
  res.json({
    success: true,
    message: `Token Expired Error ${tokenExpiredError ? 'enabled' : 'disabled'} for register API`,
    data: { tokenExpiredError },
    effect: tokenExpiredError ? 'POST /api/register will return 401 Token Expired' : 'Register API will work normally for this error',
    timestamp: new Date().toISOString()
  });
});

// Enable/Disable Invalid User Error (403)
app.post('/api/control/register/invalid-user-error', (req, res) => {
  const { enable } = req.body;
  invalidUserError = enable === true;
  res.json({
    success: true,
    message: `Invalid User Error ${invalidUserError ? 'enabled' : 'disabled'} for register API`,
    data: { invalidUserError },
    effect: invalidUserError ? 'POST /api/register will return 403 Forbidden' : 'Register API will work normally for this error',
    timestamp: new Date().toISOString()
  });
});

// Enable/Disable Service Unavailable Error (503)
app.post('/api/control/register/service-unavailable-error', (req, res) => {
  const { enable } = req.body;
  serviceUnavailableError = enable === true;
  res.json({
    success: true,
    message: `Service Unavailable Error ${serviceUnavailableError ? 'enabled' : 'disabled'} for register API`,
    data: { serviceUnavailableError },
    effect: serviceUnavailableError ? 'POST /api/register will return 503 Service Unavailable' : 'Register API will work normally for this error',
    timestamp: new Date().toISOString()
  });
});

// Enable/Disable Security Breach Error (470)
app.post('/api/control/security-breach-error', (req, res) => {
  const { enable } = req.body;
  securityBreachError = enable === true;
  res.json({
    success: true,
    message: `Security Breach Error ${securityBreachError ? 'enabled' : 'disabled'} for all APIs`,
    data: { securityBreachError },
    effect: securityBreachError ? 'All APIs will return 470 Security Breach' : 'APIs will work normally for security breach error',
    timestamp: new Date().toISOString()
  });
});

// Enable/Disable User Already Exists Error (409)
app.post('/api/control/user-already-exists-error', (req, res) => {
  const { enable } = req.body;
  userAlreadyExistsError = enable === true;
  res.json({
    success: true,
    message: `User Already Exists Error ${userAlreadyExistsError ? 'enabled' : 'disabled'} for all APIs`,
    data: { userAlreadyExistsError },
    effect: userAlreadyExistsError ? 'All APIs will return 409 User Already Exists' : 'APIs will work normally for user already exists error',
    timestamp: new Date().toISOString()
  });
});

// Enable/Disable Password Policy Error (422)
app.post('/api/control/register/password-policy-error', (req, res) => {
  const { enable } = req.body;
  userFieldValidationError = enable === true;
  res.json({
    success: true,
    message: `Password Policy Error ${userFieldValidationError ? 'enabled' : 'disabled'} for register API`,
    data: { passwordPolicyError: userFieldValidationError },
    effect: userFieldValidationError ? 'POST /api/register will return 422 Password Policy & User Registration Error' : 'Register API will work normally for password policy validation',
    timestamp: new Date().toISOString()
  });
});

// Reset all register API error flags
app.post('/api/control/register/reset-all-errors', (req, res) => {
  tryLaterError = false;
  tokenExpiredError = false;
  invalidUserError = false;
  serviceUnavailableError = false;
  securityBreachError = false;
  userAlreadyExistsError = false;
  userFieldValidationError = false;
  
  res.json({
    success: true,
    message: 'All register API error flags have been reset',
    data: {
      tryLaterError,
      tokenExpiredError,
      invalidUserError,
      serviceUnavailableError,
      securityBreachError,
      userAlreadyExistsError,
      passwordPolicyError: userFieldValidationError
    },
    effect: 'POST /api/register will work normally for all error types',
    timestamp: new Date().toISOString()
  });
});

// Logging Control Endpoints

// Get current logging settings
app.get('/api/control/logging/status', (req, res) => {
  res.json({
    success: true,
    data: {
      detailedLogging: ENABLE_DETAILED_LOGGING,
      logSensitiveData: LOG_SENSITIVE_DATA,
      description: {
        detailedLogging: 'Controls whether request/response details are logged',
        logSensitiveData: 'Controls whether sensitive data (passwords, tokens) are shown in logs'
      }
    },
    timestamp: new Date().toISOString()
  });
});

// Toggle detailed logging
app.post('/api/control/logging/detailed', (req, res) => {
  // Note: This doesn't actually change the middleware behavior since it's set at startup
  // This is for informational purposes only
  res.json({
    success: true,
    message: 'Logging settings information',
    data: {
      current: {
        detailedLogging: ENABLE_DETAILED_LOGGING,
        logSensitiveData: LOG_SENSITIVE_DATA
      },
      note: 'To change logging settings, restart the server with environment variables:',
      environment: {
        disableLogging: 'DETAILED_LOGGING=false npm start',
        enableSensitiveLogging: 'LOG_SENSITIVE_DATA=true npm start'
      }
    },
    timestamp: new Date().toISOString()
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    message: 'An unexpected error occurred',
    error: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
  });
});

// Handle 404 for undefined routes
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found',
    error: `Cannot ${req.method} ${req.originalUrl}`,
    availableEndpoints: [
      'GET /',
      'GET /api/products',
      'POST /api/register',
      'GET /api/users',
      'POST /api/test-encryption',
      'GET /api/test-headers',
      'GET /api/control/status',
      'POST /api/control/start-failing',
      'POST /api/control/stop-failing',
      'POST /api/control/register/try-later-error',
      'POST /api/control/register/token-expired-error',
      'POST /api/control/register/invalid-user-error',
      'POST /api/control/register/service-unavailable-error',
      'POST /api/control/register/password-policy-error',
      'POST /api/control/register/reset-all-errors',
      'POST /api/control/security-breach-error',
      'POST /api/control/user-already-exists-error',
      'GET /api/error/internal',
      'GET /api/error/rate-limit',
      'GET /api/error/bad-request',
      'GET /api/error/not-found',
      'GET /api/error/unauthorized',
      'GET /api/error/user-exists',
      'GET /api/error/security-breach'
    ]
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
  console.log(`🔐 Encryption: Add "X-Encrypted: true" header to encrypt requests/responses`);
  console.log(`📝 Logging: ${ENABLE_DETAILED_LOGGING ? '✅ Detailed logging ENABLED' : '❌ Detailed logging DISABLED'}`);
  console.log(`🔒 Sensitive Data: ${LOG_SENSITIVE_DATA ? '⚠️  Logging sensitive data ENABLED' : '🔐 Sensitive data PROTECTED'}`);
  console.log(`📋 Available endpoints:`);
  console.log(`   GET  /                     - API documentation`);
  console.log(`   GET  /api/products         - List all products`);
  console.log(`   POST /api/register         - Register new user`);
  console.log(`   GET  /api/users            - List registered users`);
  console.log(`   POST /api/test-encryption  - Test encryption functionality`);
  console.log(`   GET  /api/test-headers     - Test all HTTP headers`);
  console.log(`   GET  /api/control/status   - Check failure mode status`);
  console.log(`   POST /api/control/start-failing - Enable failure mode`);
  console.log(`   POST /api/control/stop-failing  - Disable failure mode`);
  console.log(`   🔧 Register API Error Controls:`);
  console.log(`   POST /api/control/register/try-later-error - Toggle 429 error`);
  console.log(`   POST /api/control/register/token-expired-error - Toggle 401 error`);
  console.log(`   POST /api/control/register/invalid-user-error - Toggle 403 error`);
  console.log(`   POST /api/control/register/service-unavailable-error - Toggle 503 error`);
  console.log(`   POST /api/control/register/password-policy-error - Toggle 422 password policy error`);
  console.log(`   POST /api/control/register/reset-all-errors - Reset all register errors`);
  console.log(`   🔒 Security Controls:`);
  console.log(`   POST /api/control/security-breach-error - Toggle 470 security breach error`);
  console.log(`   POST /api/control/user-already-exists-error - Toggle 409 user already exists error`);
  console.log(`   📝 Logging Controls:`);
  console.log(`   GET  /api/control/logging/status - Check logging settings`);
  console.log(`   POST /api/control/logging/detailed - Get logging configuration info`);
  console.log(`   GET  /api/error/internal   - Trigger 500 error`);
  console.log(`   GET  /api/error/rate-limit - Trigger 429 error`);
  console.log(`   GET  /api/error/bad-request- Trigger 400 error`);
  console.log(`   GET  /api/error/not-found  - Trigger 404 error`);
  console.log(`   GET  /api/error/unauthorized- Trigger 401 error`);
  console.log(`   GET  /api/error/user-exists - Trigger 409 error`);
  console.log(`   GET  /api/error/security-breach - Trigger 470 error`);
});

module.exports = app;
