# Error Handle Mechanism Demo Server

A Node.js Express server demonstrating error handling mechanisms with product listing and user registration functionality.

## Features

- ✅ List products with fake data
- ✅ User registration with validation
- ✅ Multiple error endpoints for testing (500, 429, 400, 401, 404)
- ✅ CORS enabled
- ✅ JSON request/response handling
- ✅ Global error handling

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the server:
```bash
# Production mode
npm start

# Development mode (with auto-restart)
npm run dev
```

The server will start on `http://localhost:3000`

## API Endpoints

### Main Endpoints

#### GET `/`
Returns API documentation and available endpoints.

**Response:**
```json
{
  "message": "Error Handle Mechanism Demo Server",
  "status": "running",
  "endpoints": { ... }
}
```

#### GET `/api/products`
Returns a list of fake products.

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Wireless Headphones",
      "price": 99.99,
      "category": "Electronics",
      "description": "High-quality wireless headphones with noise cancellation",
      "stock": 50,
      "brand": "TechSound"
    }
  ],
  "count": 5,
  "message": "Products retrieved successfully"
}
```

#### POST `/api/register`
Register a new user.

**Request Body:**
```json
{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response (Success - 201):**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "id": 1,
    "username": "johndoe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "createdAt": "2025-09-10T...",
    "status": "active"
  }
}
```

**Response (Validation Error - 400):**
```json
{
  "success": false,
  "message": "Missing required fields",
  "errors": {
    "username": "Username is required",
    "email": null,
    "password": null
  }
}
```

#### GET `/api/users`
Returns list of registered users (for testing purposes).

### Error Testing Endpoints

#### GET `/api/error/internal`
Returns 500 Internal Server Error

**Response:**
```json
{
  "success": false,
  "message": "Internal Server Error",
  "error": "Something went wrong on the server side",
  "code": "INTERNAL_ERROR",
  "timestamp": "2025-09-10T..."
}
```

#### GET `/api/error/rate-limit`
Returns 429 Too Many Requests Error

**Response:**
```json
{
  "success": false,
  "message": "Too Many Requests",
  "error": "Rate limit exceeded. Please try again later.",
  "code": "RATE_LIMIT_EXCEEDED",
  "retryAfter": 60,
  "timestamp": "2025-09-10T..."
}
```

#### GET `/api/error/bad-request`
Returns 400 Bad Request Error

**Response:**
```json
{
  "success": false,
  "message": "Bad Request",
  "error": "The request was malformed or contained invalid parameters",
  "code": "BAD_REQUEST",
  "details": "Missing required query parameters or invalid data format",
  "timestamp": "2025-09-10T..."
}
```

#### GET `/api/error/not-found`
Returns 404 Not Found Error

#### GET `/api/error/unauthorized`
Returns 401 Unauthorized Error

## Testing the API

### Using curl

1. **Get products:**
```bash
curl http://localhost:3000/api/products
```

2. **Register a user:**
```bash
curl -X POST http://localhost:3000/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "firstName": "Test",
    "lastName": "User"
  }'
```

3. **Test error endpoints:**
```bash
# 500 Error
curl http://localhost:3000/api/error/internal

# 429 Error
curl http://localhost:3000/api/error/rate-limit

# 400 Error
curl http://localhost:3000/api/error/bad-request
```

### Using a REST client

You can also use tools like Postman, Insomnia, or VS Code REST Client to test the endpoints.

## Project Structure

```
error_handle_mechanism/
├── package.json          # Dependencies and scripts
├── server.js            # Main server file
└── README.md           # This file
```

## Error Handling Features

- **Global Error Handler**: Catches unhandled errors
- **404 Handler**: Handles undefined routes
- **Validation Errors**: Input validation with detailed error messages
- **Consistent Error Format**: All errors follow the same JSON structure
- **HTTP Status Codes**: Proper status codes for different error types
- **Timestamp Logging**: All errors include timestamps

## Notes

- This is a demo project and doesn't include a real database
- User data is stored in memory and will be lost when the server restarts
- All product data is fake and hardcoded
- Error endpoints are for testing purposes only
