# ShaadiSathi - Architecture Plan

## Overview
ShaadiSathi is a wedding planning platform with Firebase backend, multi-admin support, and role-based access control (RBAC). It includes Google Sign-In, phone authentication, guest management, task tracking, budget management, gift tracking, and push notifications.

## Technical Stack
- **Framework**: Flutter with Material 3
- **Backend**: Firebase (Firestore, Authentication, Cloud Messaging)
- **State Management**: Provider
- **Authentication**: Google Sign-In, Phone Authentication
- **Design**: Custom elegant design with generous spacing (non-Material Design aesthetic)

## User Roles
1. **Admin**: Full access to all features
2. **Sub-Admin**: Limited access (cannot modify admins or critical settings)
3. **Guest**: View-only access to specific features

## Data Models (lib/models/)

### 1. UserModel
- id (String)
- name (String)
- email (String?)
- phone (String?)
- role (String) - "admin", "sub-admin", "guest"
- photoUrl (String?)
- createdAt (DateTime)
- updatedAt (DateTime)

### 2. GuestModel
- id (String)
- name (String)
- tags (List<String>) - ["family", "friend", "office", "relative", "colleague"]
- contactInfo (String)
- email (String?)
- addedBy (String) - userId
- rsvpStatus (String?) - "pending", "confirmed", "declined"
- createdAt (DateTime)
- updatedAt (DateTime)

### 3. TaskModel
- id (String)
- title (String)
- description (String)
- assignedTo (String?) - userId
- status (String) - "todo", "in_progress", "done"
- createdBy (String) - userId
- dueDate (DateTime?)
- priority (String?) - "low", "medium", "high"
- createdAt (DateTime)
- updatedAt (DateTime)

### 4. BudgetItemModel
- id (String)
- itemName (String)
- category (String) - "venue", "catering", "decoration", "photography", "attire", "entertainment", "other"
- cost (double)
- isPaid (bool)
- createdBy (String) - userId
- notes (String?)
- createdAt (DateTime)
- updatedAt (DateTime)

### 5. GiftModel
- id (String)
- giverName (String)
- guestId (String?)
- description (String)
- estimatedValue (double)
- receivedBy (String) - userId
- receivedDate (DateTime)
- category (String?) - "cash", "jewelry", "household", "other"
- createdAt (DateTime)
- updatedAt (DateTime)

## Services (lib/services/)

### 1. AuthService
- Sign in with Google
- Sign in with phone number
- Sign out
- Get current user
- Stream user authentication state
- Update user profile

### 2. UserService
- Create/update user in Firestore
- Get user by ID
- Get all users by role
- Stream users
- Update user role (admin only)

### 3. GuestService
- Add guest (with tags)
- Update guest
- Delete guest
- Get all guests
- Stream guests
- Filter guests by tags
- Update RSVP status

### 4. TaskService
- Create task
- Update task
- Delete task
- Assign task to user
- Update task status
- Stream tasks
- Filter tasks by status/assignee

### 5. BudgetService
- Add budget item
- Update budget item
- Delete budget item
- Calculate total budget
- Calculate spent amount
- Calculate remaining budget
- Stream budget items
- Filter by category

### 6. GiftService
- Add gift
- Update gift
- Delete gift
- Stream gifts
- Calculate total gift value
- Get gifts by guest

### 7. NotificationService
- Initialize FCM
- Request notification permissions
- Handle foreground notifications
- Handle background notifications
- Send notifications (task assignments, RSVP reminders)

## UI Screens (lib/screens/)

### 1. Authentication
- **LoginScreen**: Google Sign-In and Phone Auth options, elegant welcome screen
- **PhoneAuthScreen**: Phone number input and OTP verification

### 2. Main Navigation
- **DashboardScreen**: Overview with stats (guests count, tasks summary, budget overview, recent gifts)
  - Welcome message with user name
  - Quick stats cards
  - Recent activity feed
  - Quick action buttons

### 3. Guest Management
- **GuestListScreen**: 
  - List/grid view of all guests
  - Tag filtering (family, friend, office, etc.)
  - Search functionality
  - Add guest button (admin/sub-admin)
  - RSVP status indicators
- **GuestDetailScreen**: View/edit guest details, assign tags
- **AddEditGuestScreen**: Form to add/edit guest information

### 4. Task Management
- **TaskBoardScreen**: 
  - Kanban-style board (To Do, In Progress, Done)
  - Drag-and-drop functionality (or tap to change status)
  - Filter by assignee
  - Color-coded by priority
- **TaskDetailScreen**: View/edit task, assign to user
- **AddEditTaskScreen**: Form to create/edit tasks

### 5. Budget Management
- **BudgetScreen**:
  - Total budget overview
  - Spent vs remaining visualization (progress bar/chart)
  - Category breakdown
  - List of budget items
  - Add expense button (admin/sub-admin)
- **AddEditBudgetItemScreen**: Form to add/edit expenses

### 6. Gift Tracker
- **GiftListScreen**:
  - List of all gifts received
  - Total value calculation
  - Filter by category
  - Link to guest who gave the gift
- **AddEditGiftScreen**: Form to record gifts

### 7. Settings
- **SettingsScreen**:
  - User profile
  - Role management (admin only)
  - Notification preferences
  - Sign out option
  - About app

## Widget Components (lib/widgets/)
- CustomAppBar: Elegant app bar with gradient
- StatCard: Dashboard stat display
- GuestCard: Guest list item with tags
- TaskCard: Task item with status and priority
- BudgetItemCard: Budget expense item
- GiftCard: Gift item display
- TagChip: Color-coded tag chip
- EmptyStateWidget: Beautiful empty state illustrations
- LoadingWidget: Custom loading indicator
- CustomButton: Elegant button styles
- CustomTextField: Styled text input

## Color Palette (Elegant & Modern)
- Primary: Soft Rose Gold (#D4A5A5) / Deep Burgundy (#8B3A62)
- Secondary: Ivory Cream (#F8F4F0) / Charcoal (#2C2C2E)
- Accent: Gold (#D4AF37)
- Success: Sage Green (#A4C2A5)
- Warning: Amber (#FFB74D)
- Error: Coral Red (#FF6B6B)
- Background Light: Off-white (#FAFAFA)
- Background Dark: Deep Navy (#1A1A2E)
- Text Primary: Charcoal (#2C2C2E) / Off-white (#F5F5F5)
- Text Secondary: Gray (#757575) / Light Gray (#B0B0B0)

## Firebase Security Rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAdmin() {
      return request.auth != null && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    function isSubAdmin() {
      return request.auth != null && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'sub-admin';
    }
    
    function isAuthenticated() {
      return request.auth != null;
    }
    
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create: if isAuthenticated();
      allow update: if isAdmin() || request.auth.uid == userId;
      allow delete: if isAdmin();
    }
    
    match /guests/{guestId} {
      allow read: if isAuthenticated();
      allow create: if isAdmin() || isSubAdmin();
      allow update: if isAdmin() || isSubAdmin();
      allow delete: if isAdmin() || isSubAdmin();
    }
    
    match /tasks/{taskId} {
      allow read: if isAuthenticated();
      allow create: if isAdmin() || isSubAdmin();
      allow update: if isAuthenticated();
      allow delete: if isAdmin() || isSubAdmin();
    }
    
    match /budget/{budgetId} {
      allow read: if isAuthenticated();
      allow create: if isAdmin() || isSubAdmin();
      allow update: if isAdmin() || isSubAdmin();
      allow delete: if isAdmin();
    }
    
    match /gifts/{giftId} {
      allow read: if isAuthenticated();
      allow create: if isAuthenticated();
      allow update: if isAuthenticated();
      allow delete: if isAdmin();
    }
  }
}
```

## Implementation Steps

### Phase 1: Setup & Authentication
1. Add Firebase dependencies and configure
2. Update theme with elegant color palette
3. Create data models with Firestore serialization
4. Implement AuthService with Google & Phone auth
5. Create LoginScreen and PhoneAuthScreen
6. Set up navigation and routing

### Phase 2: Core Services
7. Implement UserService
8. Implement GuestService
9. Implement TaskService
10. Implement BudgetService
11. Implement GiftService
12. Set up NotificationService for FCM

### Phase 3: UI Screens
13. Create DashboardScreen with stats
14. Build GuestListScreen and guest management UI
15. Build TaskBoardScreen with kanban layout
16. Build BudgetScreen with visualization
17. Build GiftListScreen
18. Create SettingsScreen

### Phase 4: Polish & Testing
19. Add empty states and loading indicators
20. Implement error handling
21. Add animations and transitions
22. Test RBAC permissions
23. Run compile_project to verify

## Dependencies Required
- firebase_core
- firebase_auth
- cloud_firestore
- firebase_messaging
- google_sign_in
- provider
- intl (for date formatting)
- flutter_svg (for icons)
