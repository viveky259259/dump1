
Maestro Test Suite for ShaadiSathi

This folder contains a structured, DRY Maestro test suite targeting stable accessibility labels (Semantics/Tooltips) defined in lib/testing/test_ids.dart and applied with lib/testing/test_semantics.dart.

Structure
- maestro/config.yaml: App configuration (edit appId and optional startup delay as needed)
- maestro/env.yaml.example: Environment variables for tests (copy to env.yaml locally)
- maestro/flows/: Reusable flows organized by domain
  - common/: launch, navigation helpers
  - auth/: auth paths and error cases
  - crud/: create/edit happy paths (admin-only)
  - navigation/: bottom nav and settings/logout
- maestro/smoke/: Composed scenarios using runFlow

Preconditions
- Ensure Firebase test phone numbers are configured in Firebase Console for Phone Auth (testing) with a stable OTP code. See https://firebase.google.com/docs/auth
- Configure maestro/env.yaml with:
  - TEST_PHONE_E164: e.g. "+14155552671"
  - TEST_OTP_CODE: e.g. "123456"
- Admin-only CRUD flows require the signed-in user to have role = admin or sub-admin in Firestore (UserModel.role). Use an admin test account (Google or Phone) or pre-seed Firestore.

Selectors
- Tests primarily target Semantics/Tooltip labels via Maestro `label:` selectors.
- Bottom tabs are tapped by visible text (Home, Guests, Tasks, Budget, Gifts) for maximum cross-platform stability.

Running
- Use smoke/smoke_guest_happy.yaml for a guest-user happy-path navigation + logout.
- Use smoke/smoke_admin_crud.yaml for CRUD happy paths after authenticating an admin account (via phone flow or pre-auth).

For Maestro syntax and tooling, see https://maestro.dev