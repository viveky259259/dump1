import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shaadisathi/models/user_model.dart';

class UserService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'users';

  Future<void> createUser(UserModel user) async {
    await _firestore.collection(_collection).doc(user.id).set(user.toJson());
  }

  Future<void> updateUser(UserModel user) async {
    await _firestore.collection(_collection).doc(user.id).update(
      user.copyWith(updatedAt: DateTime.now()).toJson(),
    );
  }

  Future<UserModel?> getUserById(String userId) async {
    final doc = await _firestore.collection(_collection).doc(userId).get();
    if (!doc.exists) return null;
    return UserModel.fromJson(doc.data()!);
  }

  Stream<UserModel?> streamUser(String userId) {
    return _firestore.collection(_collection).doc(userId).snapshots().map((doc) {
      if (!doc.exists) return null;
      return UserModel.fromJson(doc.data()!);
    });
  }

  Stream<List<UserModel>> streamAllUsers() {
    return _firestore.collection(_collection).orderBy('name').snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => UserModel.fromJson(doc.data())).toList(),
    );
  }

  Future<List<UserModel>> getUsersByRole(String role) async {
    final snapshot = await _firestore.collection(_collection).where('role', isEqualTo: role).get();
    return snapshot.docs.map((doc) => UserModel.fromJson(doc.data())).toList();
  }

  Future<void> updateUserRole(String userId, String newRole) async {
    await _firestore.collection(_collection).doc(userId).update({
      'role': newRole,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }
}
