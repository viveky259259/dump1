import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shaadisathi/models/gift_model.dart';

class GiftService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'gifts';

  Future<void> addGift(GiftModel gift) async {
    await _firestore.collection(_collection).doc(gift.id).set(gift.toJson());
  }

  Future<void> updateGift(GiftModel gift) async {
    await _firestore.collection(_collection).doc(gift.id).update(
      gift.copyWith(updatedAt: DateTime.now()).toJson(),
    );
  }

  Future<void> deleteGift(String giftId) async {
    await _firestore.collection(_collection).doc(giftId).delete();
  }

  Stream<List<GiftModel>> streamGifts() {
    return _firestore.collection(_collection).orderBy('receivedDate', descending: true).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => GiftModel.fromJson(doc.data())).toList(),
    );
  }

  Stream<List<GiftModel>> streamGiftsByCategory(String category) {
    return _firestore.collection(_collection).where('category', isEqualTo: category).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => GiftModel.fromJson(doc.data())).toList(),
    );
  }

  Future<List<GiftModel>> getGiftsByGuest(String guestId) async {
    final snapshot = await _firestore.collection(_collection).where('guestId', isEqualTo: guestId).get();
    return snapshot.docs.map((doc) => GiftModel.fromJson(doc.data())).toList();
  }

  Future<double> calculateTotalGiftValue() async {
    final snapshot = await _firestore.collection(_collection).get();
    double total = 0.0;
    for (var doc in snapshot.docs) {
      final gift = GiftModel.fromJson(doc.data());
      total += gift.estimatedValue;
    }
    return total;
  }

  Future<Map<String, double>> getCategoryBreakdown() async {
    final snapshot = await _firestore.collection(_collection).get();
    final Map<String, double> breakdown = {};
    
    for (var doc in snapshot.docs) {
      final gift = GiftModel.fromJson(doc.data());
      final category = gift.category ?? 'other';
      breakdown[category] = (breakdown[category] ?? 0) + gift.estimatedValue;
    }
    
    return breakdown;
  }
}
