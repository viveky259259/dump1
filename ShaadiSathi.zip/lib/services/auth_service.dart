import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth_platform_interface/firebase_auth_platform_interface.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shaadisathi/services/user_service.dart';
import 'package:shaadisathi/models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final UserService _userService = UserService();
  // Holds the web confirmation result for phone auth (web-only)
  ConfirmationResult? _webConfirmationResult;

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserCredential?> signInAnonymously() async {
    try {
      final credential = await _auth.signInAnonymously();

      if (credential.user != null) {
        final uid = credential.user!.uid;
        final existingUser = await _userService.getUserById(uid);
        if (existingUser == null) {
          final newUser = UserModel(
            id: uid,
            name: 'Guest',
            email: null,
            phone: null,
            role: 'guest',
            photoUrl: null,
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          );
          await _userService.createUser(newUser);
        }
      }

      return credential;
    } catch (e) {
      throw Exception('Anonymous sign-in failed: $e');
    }
  }

  Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleAuthProvider googleProvider = GoogleAuthProvider();
      googleProvider.setCustomParameters({'prompt': 'select_account'});
      
      final credential = await _auth.signInWithProvider(googleProvider);

      if (credential.user != null) {
        final existingUser = await _userService.getUserById(credential.user!.uid);
        if (existingUser == null) {
          final newUser = UserModel(
            id: credential.user!.uid,
            name: credential.user!.displayName ?? 'User',
            email: credential.user!.email,
            phone: credential.user!.phoneNumber,
            role: 'guest',
            photoUrl: credential.user!.photoURL,
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          );
          await _userService.createUser(newUser);
        }
      }

      return credential;
    } catch (e) {
      throw Exception('Google sign-in failed: $e');
    }
  }

  Future<void> signInWithPhone(String verificationId, String smsCode) async {
    try {
      UserCredential userCredential;

      if (kIsWeb && _webConfirmationResult != null) {
        // On web, confirm via ConfirmationResult instead of manual credential
        userCredential = await _webConfirmationResult!.confirm(smsCode);
        // Clear after use
        _webConfirmationResult = null;
      } else {
        final credential = PhoneAuthProvider.credential(
          verificationId: verificationId,
          smsCode: smsCode,
        );
        userCredential = await _auth.signInWithCredential(credential);
      }
      
      if (userCredential.user != null) {
        final existingUser = await _userService.getUserById(userCredential.user!.uid);
        if (existingUser == null) {
          final newUser = UserModel(
            id: userCredential.user!.uid,
            name: 'User',
            email: userCredential.user!.email,
            phone: userCredential.user!.phoneNumber,
            role: 'guest',
            photoUrl: userCredential.user!.photoURL,
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          );
          await _userService.createUser(newUser);
        }
      }
    } catch (e) {
      throw Exception('Phone sign-in failed: $e');
    }
  }

  Future<void> verifyPhoneNumber(String phoneNumber, Function(String) onCodeSent, Function(String) onError) async {
    // Enforce E.164 format to avoid web auth/argument-error
    final raw = phoneNumber.trim();
    final isE164 = RegExp(r'^\+[1-9]\d{6,14}$').hasMatch(raw);
    if (!isE164) {
      onError('Please enter a valid phone number in E.164 format (e.g., +14155552671).');
      return;
    }

    try {
      if (kIsWeb) {
        // Use RecaptchaVerifier (invisible) on web; bind to hidden container
        final platformAuth = FirebaseAuthPlatform.instance;
        final verifier = RecaptchaVerifier(
          auth: platformAuth,
          container: 'recaptcha-container',
          size: RecaptchaVerifierSize.normal,
        );

        _webConfirmationResult = await _auth.signInWithPhoneNumber(
          raw,
          verifier,
        );

        // Simulate codeSent callback for consistent UI flow
        onCodeSent('web');
      } else {
        await _auth.verifyPhoneNumber(
          phoneNumber: raw,
          verificationCompleted: (PhoneAuthCredential credential) async {
            await _auth.signInWithCredential(credential);
          },
          verificationFailed: (FirebaseAuthException e) {
            onError(e.message ?? 'Verification failed: ${e.code}');
          },
          codeSent: (String verificationId, int? resendToken) {
            onCodeSent(verificationId);
          },
          codeAutoRetrievalTimeout: (String verificationId) {},
        );
      }
    } on FirebaseAuthException catch (e) {
      onError('Verification failed: ${e.code}${e.message != null ? ' - ${e.message}' : ''}');
    } catch (e) {
      onError('Phone verification failed: $e');
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }
}
