import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shaadisathi/models/budget_item_model.dart';

class BudgetService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'budget';

  Future<void> addBudgetItem(BudgetItemModel item) async {
    await _firestore.collection(_collection).doc(item.id).set(item.toJson());
  }

  Future<void> updateBudgetItem(BudgetItemModel item) async {
    await _firestore.collection(_collection).doc(item.id).update(
      item.copyWith(updatedAt: DateTime.now()).toJson(),
    );
  }

  Future<void> deleteBudgetItem(String itemId) async {
    await _firestore.collection(_collection).doc(itemId).delete();
  }

  Stream<List<BudgetItemModel>> streamBudgetItems() {
    return _firestore.collection(_collection).orderBy('createdAt', descending: true).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => BudgetItemModel.fromJson(doc.data())).toList(),
    );
  }

  Stream<List<BudgetItemModel>> streamBudgetItemsByCategory(String category) {
    return _firestore.collection(_collection).where('category', isEqualTo: category).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => BudgetItemModel.fromJson(doc.data())).toList(),
    );
  }

  Future<double> calculateTotalBudget() async {
    final snapshot = await _firestore.collection(_collection).get();
    double total = 0.0;
    for (var doc in snapshot.docs) {
      final item = BudgetItemModel.fromJson(doc.data());
      total += item.cost;
    }
    return total;
  }

  Future<double> calculateSpentAmount() async {
    final snapshot = await _firestore.collection(_collection).where('isPaid', isEqualTo: true).get();
    double spent = 0.0;
    for (var doc in snapshot.docs) {
      final item = BudgetItemModel.fromJson(doc.data());
      spent += item.cost;
    }
    return spent;
  }

  Future<double> calculateRemainingBudget() async {
    final total = await calculateTotalBudget();
    final spent = await calculateSpentAmount();
    return total - spent;
  }

  Future<Map<String, double>> getCategoryBreakdown() async {
    final snapshot = await _firestore.collection(_collection).get();
    final Map<String, double> breakdown = {};
    
    for (var doc in snapshot.docs) {
      final item = BudgetItemModel.fromJson(doc.data());
      breakdown[item.category] = (breakdown[item.category] ?? 0) + item.cost;
    }
    
    return breakdown;
  }
}
