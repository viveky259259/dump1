import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shaadisathi/models/guest_model.dart';

class GuestService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'guests';

  Future<void> addGuest(GuestModel guest) async {
    await _firestore.collection(_collection).doc(guest.id).set(guest.toJson());
  }

  Future<void> updateGuest(GuestModel guest) async {
    await _firestore.collection(_collection).doc(guest.id).update(
      guest.copyWith(updatedAt: DateTime.now()).toJson(),
    );
  }

  Future<void> deleteGuest(String guestId) async {
    await _firestore.collection(_collection).doc(guestId).delete();
  }

  Future<GuestModel?> getGuestById(String guestId) async {
    final doc = await _firestore.collection(_collection).doc(guestId).get();
    if (!doc.exists) return null;
    return GuestModel.fromJson(doc.data()!);
  }

  Stream<List<GuestModel>> streamGuests() {
    return _firestore.collection(_collection).orderBy('name').snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => GuestModel.fromJson(doc.data())).toList(),
    );
  }

  Stream<List<GuestModel>> streamGuestsByTag(String tag) {
    return _firestore.collection(_collection).where('tags', arrayContains: tag).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => GuestModel.fromJson(doc.data())).toList(),
    );
  }

  Future<void> updateRsvpStatus(String guestId, String status) async {
    await _firestore.collection(_collection).doc(guestId).update({
      'rsvpStatus': status,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  Future<List<GuestModel>> searchGuests(String query) async {
    final snapshot = await _firestore.collection(_collection).get();
    return snapshot.docs
        .map((doc) => GuestModel.fromJson(doc.data()))
        .where((guest) => guest.name.toLowerCase().contains(query.toLowerCase()))
        .toList();
  }
}
