import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart'
    show kIsWeb, defaultTargetPlatform, TargetPlatform;

class NotificationService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  Future<void> initialize() async {
    // On web, FCM may not be supported (e.g., no service worker/iframe). Guard gracefully.
    if (kIsWeb) {
      final bool supported = await FirebaseMessaging.instance.isSupported();
      if (!supported) {
        debugPrint(
            'Firebase Messaging not supported in this web environment. Skipping.');
        return;
      }
    }
    try {
      // Ensure auto init is enabled so FCM can register for notifications on iOS.
      await _messaging.setAutoInitEnabled(true);

      final NotificationSettings settings = await _messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: true,
      );

      // iOS/macOS: show foreground notifications
      if (_isApplePlatform) {
        await _messaging.setForegroundNotificationPresentationOptions(
          alert: true,
          badge: true,
          sound: true,
        );
      }

      if (settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional) {
        // Safely fetch token. On iOS, wait for APNs to be ready.
        final String? token = await _getTokenSafely();
        debugPrint('FCM Token: $token');

        // Listen for token refreshes
        _messaging.onTokenRefresh.listen((String newToken) {
          debugPrint('FCM token refreshed: $newToken');
          // TODO: send the new token to your backend if needed.
        });

        // Foreground message handling
        FirebaseMessaging.onMessage.listen((RemoteMessage message) {
          debugPrint('Got a message whilst in the foreground!');
          debugPrint('Message data: ${message.data}');

          if (message.notification != null) {
            debugPrint(
                'Message also contained a notification: ${message.notification}');
          }
        });

        // App opened from background via notification
        FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
          debugPrint('A new onMessageOpenedApp event was published!');
        });
      } else {
        debugPrint(
            'Push notifications not authorized: ${settings.authorizationStatus}');
      }
    } catch (e, st) {
      debugPrint('NotificationService.initialize failed: $e\n$st');
      // Do not rethrow; avoid crashing app if notifications fail to initialize.
    }
  }

  Future<String?> getToken() async => _getTokenSafely();

  bool get _isApplePlatform =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.iOS ||
          defaultTargetPlatform == TargetPlatform.macOS);

  Future<String?> _getTokenSafely(
      {Duration timeout = const Duration(seconds: 20)}) async {
    // On non-Apple platforms or web, just get the token.
    if (!_isApplePlatform) {
      try {
        return await _messaging.getToken();
      } catch (e) {
        debugPrint('Failed to get FCM token: $e');
        return null;
      }
    }

    // On iOS/macOS, the APNs token may not be ready immediately after requesting permission.
    // Retry getToken until APNs is ready or timeout.
    final DateTime deadline = DateTime.now().add(timeout);
    int attempt = 0;
    while (DateTime.now().isBefore(deadline)) {
      attempt++;
      try {
        final String? token = await _messaging.getToken();
        if (token != null && token.isNotEmpty) {
          return token;
        }
      } on FirebaseException catch (fe) {
        // The firebase_messaging plugin throws [firebase_messaging/apns-token-not-set] until APNs is ready.
        if (fe.code != 'apns-token-not-set') {
          debugPrint(
              'getToken failed with non-APNS error: ${fe.code} ${fe.message}');
        }
      } catch (e) {
        debugPrint('getToken attempt $attempt failed: $e');
      }
      await Future.delayed(const Duration(milliseconds: 600));
    }
    debugPrint(
        'FCM token not available before timeout. Will continue without token.');
    return null;
  }
}
