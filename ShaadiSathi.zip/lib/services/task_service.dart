import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shaadisathi/models/task_model.dart';

class TaskService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'tasks';

  Future<void> createTask(TaskModel task) async {
    await _firestore.collection(_collection).doc(task.id).set(task.toJson());
  }

  Future<void> updateTask(TaskModel task) async {
    await _firestore.collection(_collection).doc(task.id).update(
      task.copyWith(updatedAt: DateTime.now()).toJson(),
    );
  }

  Future<void> deleteTask(String taskId) async {
    await _firestore.collection(_collection).doc(taskId).delete();
  }

  Future<TaskModel?> getTaskById(String taskId) async {
    final doc = await _firestore.collection(_collection).doc(taskId).get();
    if (!doc.exists) return null;
    return TaskModel.fromJson(doc.data()!);
  }

  Stream<List<TaskModel>> streamTasks() {
    return _firestore.collection(_collection).orderBy('createdAt', descending: true).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => TaskModel.fromJson(doc.data())).toList(),
    );
  }

  Stream<List<TaskModel>> streamTasksByStatus(String status) {
    return _firestore.collection(_collection).where('status', isEqualTo: status).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => TaskModel.fromJson(doc.data())).toList(),
    );
  }

  Stream<List<TaskModel>> streamTasksByAssignee(String userId) {
    return _firestore.collection(_collection).where('assignedTo', isEqualTo: userId).snapshots().map(
      (snapshot) => snapshot.docs.map((doc) => TaskModel.fromJson(doc.data())).toList(),
    );
  }

  Future<void> updateTaskStatus(String taskId, String newStatus) async {
    await _firestore.collection(_collection).doc(taskId).update({
      'status': newStatus,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  Future<void> assignTask(String taskId, String userId) async {
    await _firestore.collection(_collection).doc(taskId).update({
      'assignedTo': userId,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }
}
