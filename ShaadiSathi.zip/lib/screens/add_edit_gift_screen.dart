import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/gift_service.dart';
import 'package:shaadisathi/services/guest_service.dart';
import 'package:shaadisathi/models/gift_model.dart';
import 'package:shaadisathi/models/guest_model.dart';
import 'package:intl/intl.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class AddEditGiftScreen extends StatefulWidget {
  final GiftModel? gift;

  const AddEditGiftScreen({super.key, this.gift});

  @override
  State<AddEditGiftScreen> createState() => _AddEditGiftScreenState();
}

class _AddEditGiftScreenState extends State<AddEditGiftScreen> {
  final GiftService _giftService = GiftService();
  final GuestService _guestService = GuestService();
  final _formKey = GlobalKey<FormState>();
  final _giverNameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _valueController = TextEditingController();
  
  String _category = 'cash';
  DateTime _receivedDate = DateTime.now();
  String? _guestId;
  List<GuestModel> _guests = [];

  @override
  void initState() {
    super.initState();
    _loadGuests();
    if (widget.gift != null) {
      _giverNameController.text = widget.gift!.giverName;
      _descriptionController.text = widget.gift!.description;
      _valueController.text = widget.gift!.estimatedValue.toString();
      _category = widget.gift!.category ?? 'cash';
      _receivedDate = widget.gift!.receivedDate;
      _guestId = widget.gift!.guestId;
    }
  }

  Future<void> _loadGuests() async {
    _guestService.streamGuests().listen((guests) {
      setState(() => _guests = guests);
    });
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _receivedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date != null) {
      setState(() => _receivedDate = date);
    }
  }

  Future<void> _saveGift() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) return;

      final now = DateTime.now();
      final gift = GiftModel(
        id: widget.gift?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        giverName: _giverNameController.text.trim(),
        description: _descriptionController.text.trim(),
        estimatedValue: double.parse(_valueController.text.trim()),
        category: _category,
        guestId: _guestId,
        receivedDate: _receivedDate,
        receivedBy: widget.gift?.receivedBy ?? currentUser.uid,
        createdAt: widget.gift?.createdAt ?? now,
        updatedAt: now,
      );

      if (widget.gift == null) {
        await _giftService.addGift(gift);
      } else {
        await _giftService.updateGift(gift);
      }

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gift ${widget.gift == null ? 'added' : 'updated'} successfully')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        leading: TestIconButton(
          id: TestIds.backButton,
          icon: Icons.arrow_back,
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(widget.gift == null ? 'Add Gift' : 'Edit Gift', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: TestSemantics(
            id: TestIds.screenAddEditGift,
            child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TestSemantics(
                  id: TestIds.giftDescriptionField,
                  child: TextFormField(
                  controller: _giverNameController,
                  decoration: InputDecoration(
                    labelText: 'Giver Name *',
                    prefixIcon: Icon(Icons.person, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) => value?.isEmpty == true ? 'Giver name is required' : null,
                ),
                ),
                const SizedBox(height: 20),
                TestSemantics(
                  id: TestIds.giftRecipientField,
                  child: DropdownButtonFormField<String>(
                  value: _guestId,
                  decoration: InputDecoration(
                    labelText: 'Link to Guest (Optional)',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  items: [
                    DropdownMenuItem(value: null, child: Text('None')),
                    ..._guests.map((guest) => DropdownMenuItem(value: guest.id, child: Text(guest.name))),
                  ],
                  onChanged: (value) => setState(() => _guestId = value),
                ),
                ),
                const SizedBox(height: 20),
                TestSemantics(
                  id: TestIds.giftNameField,
                  child: TextFormField(
                  controller: _descriptionController,
                  maxLines: 3,
                  decoration: InputDecoration(
                    labelText: 'Description *',
                    alignLabelWithHint: true,
                    prefixIcon: Padding(
                      padding: const EdgeInsets.only(bottom: 50),
                      child: Icon(Icons.description, color: theme.colorScheme.primary),
                    ),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) => value?.isEmpty == true ? 'Description is required' : null,
                ),
                ),
                const SizedBox(height: 20),
                TestSemantics(
                  id: TestIds.giftPriceField,
                  child: TextFormField(
                  controller: _valueController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Estimated Value *',
                    prefixIcon: Icon(Icons.attach_money, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) {
                    if (value?.isEmpty == true) return 'Value is required';
                    if (double.tryParse(value!) == null) return 'Enter a valid number';
                    return null;
                  },
                ),
                ),
                const SizedBox(height: 20),
                Text('Category', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _category,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  items: ['cash', 'jewelry', 'household', 'other']
                      .map((cat) => DropdownMenuItem(
                            value: cat,
                            child: Text(cat[0].toUpperCase() + cat.substring(1)),
                          ))
                      .toList(),
                  onChanged: (value) => setState(() => _category = value!),
                ),
                const SizedBox(height: 20),
                Text('Received Date', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                InkWell(
                  onTap: _selectDate,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      border: Border.all(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today, color: theme.colorScheme.primary),
                        const SizedBox(width: 12),
                        Text(DateFormat('MMM dd, yyyy').format(_receivedDate), style: theme.textTheme.bodyLarge),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: TestSemantics(
                    id: TestIds.saveButton,
                    isButton: true,
                    child: ElevatedButton(
                    onPressed: _saveGift,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: Text(widget.gift == null ? 'Add Gift' : 'Update Gift', style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onPrimary,
                    )),
                  ),
                  ),
                ),
                if (widget.gift != null) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: OutlinedButton(
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Delete Gift'),
                            content: const Text('Are you sure you want to delete this gift record?'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: Text('Delete', style: TextStyle(color: theme.colorScheme.error)),
                              ),
                            ],
                          ),
                        );
                        if (confirm == true) {
                          await _giftService.deleteGift(widget.gift!.id);
                          if (mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Gift deleted')),
                            );
                          }
                        }
                      },
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: theme.colorScheme.error, width: 2),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text('Delete Gift', style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.error,
                      )),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
      ),
    );
  }

  @override
  void dispose() {
    _giverNameController.dispose();
    _descriptionController.dispose();
    _valueController.dispose();
    super.dispose();
  }
}
