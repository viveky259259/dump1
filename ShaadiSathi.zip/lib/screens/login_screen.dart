import 'package:flutter/material.dart';
import 'package:shaadisathi/services/auth_service.dart';
import 'package:shaadisathi/screens/phone_auth_screen.dart';
import 'package:shaadisathi/screens/dashboard_screen.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService _authService = AuthService();
  bool _isLoading = false;

  Future<void> _handleGoogleSignIn() async {
    setState(() => _isLoading = true);
    try {
      final result = await _authService.signInWithGoogle();
      if (result != null && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DashboardScreen()),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Sign in failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _handleAnonymousSignIn() async {
    setState(() => _isLoading = true);
    try {
      final result = await _authService.signInAnonymously();
      if (result != null && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DashboardScreen()),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Continue as guest failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _navigateToPhoneAuth() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const PhoneAuthScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: TestSemantics(
              id: TestIds.screenLogin,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                const SizedBox(height: 60),
                Icon(Icons.favorite, size: 80, color: theme.colorScheme.primary),
                const SizedBox(height: 24),
                Text('ShaadiSathi', style: theme.textTheme.displaySmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.primary,
                )),
                const SizedBox(height: 12),
                Text('Your Perfect Wedding Companion', style: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                )),
                const SizedBox(height: 80),
                Text('Welcome', style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                )),
                const SizedBox(height: 12),
                Text('Sign in to start planning your dream wedding', style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                ), textAlign: TextAlign.center),
                const SizedBox(height: 48),
                if (_isLoading)
                  const CircularProgressIndicator()
                else ...[
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: TestSemantics(
                      id: TestIds.loginSubmitButton,
                      isButton: true,
                      child: ElevatedButton.icon(
                      onPressed: _handleGoogleSignIn,
                      icon: Icon(Icons.g_mobiledata, color: theme.colorScheme.onPrimary),
                      label: Text('Continue with Google', style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onPrimary,
                      )),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: theme.colorScheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: TestSemantics(
                      id: TestIds.loginWithPhoneButton,
                      isButton: true,
                      child: OutlinedButton.icon(
                      onPressed: _navigateToPhoneAuth,
                      icon: Icon(Icons.phone, color: theme.colorScheme.primary),
                      label: Text('Continue with Phone', style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.primary,
                      )),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: theme.colorScheme.primary, width: 2),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TestSemantics(
                    id: TestIds.continueAsGuestButton,
                    isButton: true,
                    child: TextButton(
                      onPressed: _handleAnonymousSignIn,
                      child: Text(
                        'Continue as Guest',
                        style: TextStyle(
                          color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 60),
              ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
