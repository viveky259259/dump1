import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/guest_service.dart';
import 'package:shaadisathi/services/user_service.dart';
import 'package:shaadisathi/models/guest_model.dart';
import 'package:shaadisathi/models/user_model.dart';
import 'package:shaadisathi/widgets/tag_chip.dart';
import 'package:shaadisathi/widgets/empty_state_widget.dart';
import 'package:shaadisathi/screens/add_edit_guest_screen.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class GuestListScreen extends StatefulWidget {
  const GuestListScreen({super.key});

  @override
  State<GuestListScreen> createState() => _GuestListScreenState();
}

class _GuestListScreenState extends State<GuestListScreen> {
  final GuestService _guestService = GuestService();
  final UserService _userService = UserService();
  String? _selectedTag;
  String _searchQuery = '';
  UserModel? _currentUser;

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  Future<void> _loadCurrentUser() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userModel = await _userService.getUserById(user.uid);
      setState(() => _currentUser = userModel);
    }
  }

  void _filterByTag(String? tag) {
    setState(() => _selectedTag = tag == _selectedTag ? null : tag);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final canAddGuests = _currentUser?.isAdmin == true || _currentUser?.isSubAdmin == true;

    return Scaffold(
      appBar: AppBar(
        title: Text('Guest List', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
        actions: canAddGuests ? [
          TestIconButton(
            id: TestIds.addFab,
            icon: Icons.add,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddEditGuestScreen()),
            ),
          ),
        ] : null,
      ),
      body: TestSemantics(
        id: TestIds.screenGuestList,
        child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TestSemantics(
                  id: TestIds.searchField,
                  child: TextField(
                  onChanged: (value) => setState(() => _searchQuery = value),
                  decoration: InputDecoration(
                    hintText: 'Search guests...',
                    prefixIcon: Icon(Icons.search, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                ),
                ),
                const SizedBox(height: 16),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: ['family', 'friend', 'office', 'relative', 'colleague']
                        .map((tag) => Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: TagChip(
                                label: tag,
                                isSelected: _selectedTag == tag,
                                onTap: () => _filterByTag(tag),
                              ),
                            ))
                        .toList(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<List<GuestModel>>(
              stream: _selectedTag != null
                  ? _guestService.streamGuestsByTag(_selectedTag!)
                  : _guestService.streamGuests(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return EmptyStateWidget(
                    icon: Icons.people_outline,
                    title: 'No Guests Yet',
                    message: 'Start adding guests to your wedding',
                    actionLabel: canAddGuests ? 'Add First Guest' : null,
                    actionTestId: canAddGuests ? TestIds.emptyAddFirstGuestButton : null,
                    onActionPressed: canAddGuests
                        ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddEditGuestScreen()))
                        : null,
                  );
                }

                var guests = snapshot.data!;
                if (_searchQuery.isNotEmpty) {
                  guests = guests.where((g) => g.name.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: guests.length,
                  itemBuilder: (context, index) {
                    final guest = guests[index];
                    return TestSemantics(
                      id: TestIds.listItem('guest', guest.id),
                      child: _GuestCard(guest: guest, canEdit: canAddGuests),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      ),
    );
  }
}

class _GuestCard extends StatelessWidget {
  final GuestModel guest;
  final bool canEdit;

  const _GuestCard({required this.guest, required this.canEdit});

  Color _getRsvpColor(String? status) {
    switch (status) {
      case 'confirmed':
        return Colors.green;
      case 'declined':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary,
                child: Text(guest.name[0].toUpperCase(), style: TextStyle(
                  color: theme.colorScheme.onPrimary,
                  fontWeight: FontWeight.bold,
                )),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(guest.name, style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.onPrimaryContainer,
                    )),
                    Text(guest.contactInfo, style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                    )),
                  ],
                ),
              ),
              if (guest.rsvpStatus != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: _getRsvpColor(guest.rsvpStatus).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(guest.rsvpStatus!.toUpperCase(), style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: _getRsvpColor(guest.rsvpStatus),
                  )),
                ),
            ],
          ),
          if (guest.tags.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: guest.tags.map((tag) => TagChip(label: tag)).toList(),
            ),
          ],
          if (canEdit) ...[
            const SizedBox(height: 12),
            InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddEditGuestScreen(guest: guest)),
              ),
              child: Text('Edit', style: TextStyle(
                color: theme.colorScheme.primary,
                fontWeight: FontWeight.w600,
              )),
            ),
          ],
        ],
      ),
    );
  }
}
