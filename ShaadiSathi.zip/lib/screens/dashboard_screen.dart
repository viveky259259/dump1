import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/user_service.dart';
import 'package:shaadisathi/services/guest_service.dart';
import 'package:shaadisathi/services/task_service.dart';
import 'package:shaadisathi/services/budget_service.dart';
import 'package:shaadisathi/services/gift_service.dart';
import 'package:shaadisathi/models/user_model.dart';
import 'package:shaadisathi/widgets/stat_card.dart';
import 'package:shaadisathi/screens/guest_list_screen.dart';
import 'package:shaadisathi/screens/task_board_screen.dart';
import 'package:shaadisathi/screens/budget_screen.dart';
import 'package:shaadisathi/screens/gift_list_screen.dart';
import 'package:shaadisathi/screens/settings_screen.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final UserService _userService = UserService();
  final GuestService _guestService = GuestService();
  final TaskService _taskService = TaskService();
  final BudgetService _budgetService = BudgetService();
  final GiftService _giftService = GiftService();

  int _selectedIndex = 0;
  UserModel? _currentUser;

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  Future<void> _loadCurrentUser() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userModel = await _userService.getUserById(user.uid);
      setState(() => _currentUser = userModel);
    }
  }

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = [
      _DashboardContent(
        userService: _userService,
        guestService: _guestService,
        taskService: _taskService,
        budgetService: _budgetService,
        giftService: _giftService,
        currentUser: _currentUser,
      ),
      const GuestListScreen(),
      const TaskBoardScreen(),
      const BudgetScreen(),
      const GiftListScreen(),
    ];

    final theme = Theme.of(context);

    return Scaffold(
      body: TestSemantics(
        id: TestIds.screenDashboard,
        child: screens[_selectedIndex],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(top: BorderSide(
            color: theme.colorScheme.onSurface.withValues(alpha: 0.1),
            width: 1,
          )),
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          backgroundColor: theme.scaffoldBackgroundColor,
          selectedItemColor: theme.colorScheme.primary,
          unselectedItemColor: theme.colorScheme.onSurface.withValues(alpha: 0.5),
          elevation: 0,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home),
              label: 'Home',
              tooltip: TestIds.bottomNavHome,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.people),
              label: 'Guests',
              tooltip: TestIds.bottomNavGuests,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.task),
              label: 'Tasks',
              tooltip: TestIds.bottomNavTasks,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.account_balance_wallet),
              label: 'Budget',
              tooltip: TestIds.bottomNavBudget,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.card_giftcard),
              label: 'Gifts',
              tooltip: TestIds.bottomNavGifts,
            ),
          ],
        ),
      ),
    );
  }
}

class _DashboardContent extends StatelessWidget {
  final UserService userService;
  final GuestService guestService;
  final TaskService taskService;
  final BudgetService budgetService;
  final GiftService giftService;
  final UserModel? currentUser;

  const _DashboardContent({
    required this.userService,
    required this.guestService,
    required this.taskService,
    required this.budgetService,
    required this.giftService,
    this.currentUser,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('ShaadiSathi', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
        actions: [
          TestIconButton(
            id: TestIds.navToSettingsButton,
            icon: Icons.settings,
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Welcome back,', style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
              )),
              const SizedBox(height: 4),
              Text(currentUser?.name ?? 'User', style: theme.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              )),
              const SizedBox(height: 32),
              StreamBuilder(
                stream: guestService.streamGuests(),
                builder: (context, guestSnapshot) {
                  final guestCount = guestSnapshot.data?.length ?? 0;
                  return StreamBuilder(
                    stream: taskService.streamTasks(),
                    builder: (context, taskSnapshot) {
                      final tasks = taskSnapshot.data ?? [];
                      final todoCount = tasks.where((t) => t.status == 'todo').length;
                      return GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        childAspectRatio: 1.3,
                        children: [
                          StatCard(
                            icon: Icons.people,
                            iconColor: theme.colorScheme.tertiary,
                            title: 'Guests',
                            value: guestCount.toString(),
                          ),
                          StatCard(
                            icon: Icons.task_alt,
                            iconColor: theme.colorScheme.secondary,
                            title: 'Pending Tasks',
                            value: todoCount.toString(),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
              const SizedBox(height: 16),
              FutureBuilder<double>(
                future: budgetService.calculateTotalBudget(),
                builder: (context, budgetSnapshot) {
                  return FutureBuilder<double>(
                    future: giftService.calculateTotalGiftValue(),
                    builder: (context, giftSnapshot) {
                      return GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        childAspectRatio: 1.3,
                        children: [
                          StatCard(
                            icon: Icons.attach_money,
                            iconColor: Colors.green,
                            title: 'Total Budget',
                            value: '\$${budgetSnapshot.data?.toStringAsFixed(0) ?? '0'}',
                          ),
                          StatCard(
                            icon: Icons.card_giftcard,
                            iconColor: Colors.purple,
                            title: 'Gifts Value',
                            value: '\$${giftSnapshot.data?.toStringAsFixed(0) ?? '0'}',
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
              const SizedBox(height: 32),
              Text('Quick Actions', style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              )),
              const SizedBox(height: 16),
              if (currentUser?.isAdmin == true || currentUser?.isSubAdmin == true) ...[
                _QuickActionButton(
                  icon: Icons.person_add,
                  label: 'Add Guest',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GuestListScreen())),
                  testId: TestIds.navToGuestsButton,
                ),
                const SizedBox(height: 12),
                _QuickActionButton(
                  icon: Icons.add_task,
                  label: 'Create Task',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TaskBoardScreen())),
                  testId: TestIds.navToTasksButton,
                ),
                const SizedBox(height: 12),
                _QuickActionButton(
                  icon: Icons.add_circle,
                  label: 'Add Expense',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BudgetScreen())),
                  testId: TestIds.navToBudgetButton,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final String? testId;

  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.testId,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final content = Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: theme.colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(icon, color: theme.colorScheme.primary, size: 28),
            const SizedBox(width: 16),
            Text(label, style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onPrimaryContainer,
            )),
          ],
        ),
      );

    final tappable = InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: content,
    );

    if (testId == null) return tappable;
    return TestSemantics(id: testId!, isButton: true, child: tappable);
  }
}
