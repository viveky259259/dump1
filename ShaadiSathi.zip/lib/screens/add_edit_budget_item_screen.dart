import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/budget_service.dart';
import 'package:shaadisathi/models/budget_item_model.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class AddEditBudgetItemScreen extends StatefulWidget {
  final BudgetItemModel? item;

  const AddEditBudgetItemScreen({super.key, this.item});

  @override
  State<AddEditBudgetItemScreen> createState() => _AddEditBudgetItemScreenState();
}

class _AddEditBudgetItemScreenState extends State<AddEditBudgetItemScreen> {
  final BudgetService _budgetService = BudgetService();
  final _formKey = GlobalKey<FormState>();
  final _itemNameController = TextEditingController();
  final _costController = TextEditingController();
  final _notesController = TextEditingController();
  
  String _category = 'venue';
  bool _isPaid = false;

  @override
  void initState() {
    super.initState();
    if (widget.item != null) {
      _itemNameController.text = widget.item!.itemName;
      _costController.text = widget.item!.cost.toString();
      _notesController.text = widget.item!.notes ?? '';
      _category = widget.item!.category;
      _isPaid = widget.item!.isPaid;
    }
  }

  Future<void> _saveItem() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) return;

      final now = DateTime.now();
      final item = BudgetItemModel(
        id: widget.item?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        itemName: _itemNameController.text.trim(),
        cost: double.parse(_costController.text.trim()),
        category: _category,
        isPaid: _isPaid,
        notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
        createdBy: widget.item?.createdBy ?? currentUser.uid,
        createdAt: widget.item?.createdAt ?? now,
        updatedAt: now,
      );

      if (widget.item == null) {
        await _budgetService.addBudgetItem(item);
      } else {
        await _budgetService.updateBudgetItem(item);
      }

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Budget item ${widget.item == null ? 'added' : 'updated'} successfully')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        leading: TestIconButton(
          id: TestIds.backButton,
          icon: Icons.arrow_back,
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(widget.item == null ? 'Add Expense' : 'Edit Expense', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: TestSemantics(
            id: TestIds.screenAddEditBudgetItem,
            child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TestSemantics(
                  id: TestIds.budgetTitleField,
                  child: TextFormField(
                  controller: _itemNameController,
                  decoration: InputDecoration(
                    labelText: 'Item Name *',
                    prefixIcon: Icon(Icons.shopping_bag, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) => value?.isEmpty == true ? 'Item name is required' : null,
                ),
                ),
                const SizedBox(height: 20),
                TestSemantics(
                  id: TestIds.budgetAmountField,
                  child: TextFormField(
                  controller: _costController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Cost *',
                    prefixIcon: Icon(Icons.attach_money, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) {
                    if (value?.isEmpty == true) return 'Cost is required';
                    if (double.tryParse(value!) == null) return 'Enter a valid number';
                    return null;
                  },
                ),
                ),
                const SizedBox(height: 20),
                Text('Category', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _category,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  items: ['venue', 'catering', 'decoration', 'photography', 'attire', 'entertainment', 'other']
                      .map((cat) => DropdownMenuItem(
                            value: cat,
                            child: Text(cat[0].toUpperCase() + cat.substring(1)),
                          ))
                      .toList(),
                  onChanged: (value) => setState(() => _category = value!),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _notesController,
                  maxLines: 3,
                  decoration: InputDecoration(
                    labelText: 'Notes (Optional)',
                    alignLabelWithHint: true,
                    prefixIcon: Padding(
                      padding: const EdgeInsets.only(bottom: 50),
                      child: Icon(Icons.note, color: theme.colorScheme.primary),
                    ),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                CheckboxListTile(
                  title: Text('Mark as Paid', style: theme.textTheme.titleMedium),
                  value: _isPaid,
                  onChanged: (value) => setState(() => _isPaid = value ?? false),
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: TestSemantics(
                    id: TestIds.saveButton,
                    isButton: true,
                    child: ElevatedButton(
                    onPressed: _saveItem,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: Text(widget.item == null ? 'Add Expense' : 'Update Expense', style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onPrimary,
                    )),
                  ),
                  ),
                ),
                if (widget.item != null) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: OutlinedButton(
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Delete Expense'),
                            content: const Text('Are you sure you want to delete this expense?'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: Text('Delete', style: TextStyle(color: theme.colorScheme.error)),
                              ),
                            ],
                          ),
                        );
                        if (confirm == true) {
                          await _budgetService.deleteBudgetItem(widget.item!.id);
                          if (mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Expense deleted')),
                            );
                          }
                        }
                      },
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: theme.colorScheme.error, width: 2),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text('Delete Expense', style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.error,
                      )),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
      ),
    );
  }

  @override
  void dispose() {
    _itemNameController.dispose();
    _costController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}
