import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/task_service.dart';
import 'package:shaadisathi/services/user_service.dart';
import 'package:shaadisathi/models/task_model.dart';
import 'package:shaadisathi/models/user_model.dart';
import 'package:shaadisathi/widgets/empty_state_widget.dart';
import 'package:shaadisathi/screens/add_edit_task_screen.dart';
import 'package:intl/intl.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class TaskBoardScreen extends StatefulWidget {
  const TaskBoardScreen({super.key});

  @override
  State<TaskBoardScreen> createState() => _TaskBoardScreenState();
}

class _TaskBoardScreenState extends State<TaskBoardScreen> {
  final TaskService _taskService = TaskService();
  final UserService _userService = UserService();
  UserModel? _currentUser;

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  Future<void> _loadCurrentUser() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userModel = await _userService.getUserById(user.uid);
      setState(() => _currentUser = userModel);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final canAddTasks = _currentUser?.isAdmin == true || _currentUser?.isSubAdmin == true;

    return Scaffold(
      appBar: AppBar(
        title: Text('Task Board', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
        actions: canAddTasks ? [
          TestIconButton(
            id: TestIds.addFab,
            icon: Icons.add,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddEditTaskScreen()),
            ),
          ),
        ] : null,
      ),
      body: TestSemantics(
        id: TestIds.screenTaskBoard,
        child: StreamBuilder<List<TaskModel>>(
        stream: _taskService.streamTasks(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return EmptyStateWidget(
              icon: Icons.task_outlined,
              title: 'No Tasks Yet',
              message: 'Create tasks to manage your wedding planning',
              actionLabel: canAddTasks ? 'Create First Task' : null,
              actionTestId: canAddTasks ? TestIds.emptyCreateFirstTaskButton : null,
              onActionPressed: canAddTasks
                  ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddEditTaskScreen()))
                  : null,
            );
          }

          final tasks = snapshot.data!;
          final todoTasks = tasks.where((t) => t.status == 'todo').toList();
          final inProgressTasks = tasks.where((t) => t.status == 'in_progress').toList();
          final doneTasks = tasks.where((t) => t.status == 'done').toList();

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _TaskColumn(
                  title: 'To Do',
                  tasks: todoTasks,
                  color: Colors.orange,
                  canEdit: canAddTasks,
                ),
                const SizedBox(height: 24),
                _TaskColumn(
                  title: 'In Progress',
                  tasks: inProgressTasks,
                  color: Colors.blue,
                  canEdit: canAddTasks,
                ),
                const SizedBox(height: 24),
                _TaskColumn(
                  title: 'Done',
                  tasks: doneTasks,
                  color: Colors.green,
                  canEdit: canAddTasks,
                ),
              ],
            ),
          );
        },
      ),
      ),
    );
  }
}

class _TaskColumn extends StatelessWidget {
  final String title;
  final List<TaskModel> tasks;
  final Color color;
  final bool canEdit;

  const _TaskColumn({
    required this.title,
    required this.tasks,
    required this.color,
    required this.canEdit,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 24,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 12),
            Text(title, style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            )),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text('${tasks.length}', style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: color,
              )),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (tasks.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.1),
                width: 1,
              ),
            ),
            child: Center(
              child: Text('No tasks', style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
              )),
            ),
          )
        else
          ...tasks.map((task) => TestSemantics(
                id: TestIds.listItem('task', task.id),
                child: _TaskCard(task: task, canEdit: canEdit),
              )),
      ],
    );
  }
}

class _TaskCard extends StatelessWidget {
  final TaskModel task;
  final bool canEdit;

  const _TaskCard({required this.task, required this.canEdit});

  Color _getPriorityColor(String? priority) {
    switch (priority) {
      case 'high':
        return Colors.red;
      case 'medium':
        return Colors.orange;
      case 'low':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(task.title, style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.onPrimaryContainer,
                )),
              ),
              if (task.priority != null)
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _getPriorityColor(task.priority),
                    shape: BoxShape.circle,
                  ),
                ),
            ],
          ),
          if (task.description.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(task.description, style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
            ), maxLines: 2, overflow: TextOverflow.ellipsis),
          ],
          if (task.dueDate != null) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(Icons.calendar_today, size: 14, color: theme.colorScheme.secondary),
                const SizedBox(width: 6),
                Text(DateFormat('MMM dd, yyyy').format(task.dueDate!), style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                )),
              ],
            ),
          ],
          if (canEdit) ...[
            const SizedBox(height: 12),
            InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddEditTaskScreen(task: task)),
              ),
              child: Text('Edit', style: TextStyle(
                color: theme.colorScheme.primary,
                fontWeight: FontWeight.w600,
              )),
            ),
          ],
        ],
      ),
    );
  }
}
