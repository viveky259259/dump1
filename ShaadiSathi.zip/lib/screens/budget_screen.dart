import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/budget_service.dart';
import 'package:shaadisathi/services/user_service.dart';
import 'package:shaadisathi/models/budget_item_model.dart';
import 'package:shaadisathi/models/user_model.dart';
import 'package:shaadisathi/widgets/empty_state_widget.dart';
import 'package:shaadisathi/screens/add_edit_budget_item_screen.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class BudgetScreen extends StatefulWidget {
  const BudgetScreen({super.key});

  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  final BudgetService _budgetService = BudgetService();
  final UserService _userService = UserService();
  UserModel? _currentUser;
  String? _selectedCategory;

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  Future<void> _loadCurrentUser() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userModel = await _userService.getUserById(user.uid);
      setState(() => _currentUser = userModel);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final canAddBudget = _currentUser?.isAdmin == true || _currentUser?.isSubAdmin == true;

    return Scaffold(
      appBar: AppBar(
        title: Text('Budget Manager', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
        actions: canAddBudget ? [
          TestIconButton(
            id: TestIds.addFab,
            icon: Icons.add,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddEditBudgetItemScreen()),
            ),
          ),
        ] : null,
      ),
      body: TestSemantics(
        id: TestIds.screenBudget,
        child: Column(
        children: [
          FutureBuilder<double>(
            future: _budgetService.calculateTotalBudget(),
            builder: (context, totalSnapshot) {
              return FutureBuilder<double>(
                future: _budgetService.calculateSpentAmount(),
                builder: (context, spentSnapshot) {
                  final total = totalSnapshot.data ?? 0;
                  final spent = spentSnapshot.data ?? 0;
                  final remaining = total - spent;
                  final percentage = total > 0 ? (spent / total) : 0.0;

                  return Container(
                    margin: const EdgeInsets.all(16),
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Text('Total Budget', style: theme.textTheme.titleMedium?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                        )),
                        const SizedBox(height: 8),
                        Text('\$${total.toStringAsFixed(2)}', style: theme.textTheme.displaySmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.onPrimaryContainer,
                        )),
                        const SizedBox(height: 24),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: LinearProgressIndicator(
                            value: percentage,
                            minHeight: 12,
                            backgroundColor: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.2),
                            valueColor: AlwaysStoppedAnimation<Color>(
                              percentage > 0.9 ? Colors.red : percentage > 0.7 ? Colors.orange : Colors.green,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Spent', style: theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                                )),
                                Text('\$${spent.toStringAsFixed(2)}', style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: theme.colorScheme.onPrimaryContainer,
                                )),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('Remaining', style: theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                                )),
                                Text('\$${remaining.toStringAsFixed(2)}', style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: theme.colorScheme.onPrimaryContainer,
                                )),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ['All', 'venue', 'catering', 'decoration', 'photography', 'attire', 'entertainment', 'other']
                    .map((cat) => Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: FilterChip(
                            label: Text(cat == 'All' ? cat : cat[0].toUpperCase() + cat.substring(1)),
                            selected: cat == 'All' ? _selectedCategory == null : _selectedCategory == cat,
                            onSelected: (selected) {
                              setState(() => _selectedCategory = cat == 'All' ? null : cat);
                            },
                          ),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: StreamBuilder<List<BudgetItemModel>>(
              stream: _selectedCategory != null
                  ? _budgetService.streamBudgetItemsByCategory(_selectedCategory!)
                  : _budgetService.streamBudgetItems(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return EmptyStateWidget(
                    icon: Icons.account_balance_wallet_outlined,
                    title: 'No Budget Items',
                    message: 'Start adding expenses to track your wedding budget',
                    actionLabel: canAddBudget ? 'Add First Expense' : null,
                    actionTestId: canAddBudget ? TestIds.emptyAddFirstExpenseButton : null,
                    onActionPressed: canAddBudget
                        ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddEditBudgetItemScreen()))
                        : null,
                  );
                }

                final items = snapshot.data!;
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return TestSemantics(
                      id: TestIds.listItem('budget', item.id),
                      child: _BudgetItemCard(item: item, canEdit: canAddBudget),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      ),
    );
  }
}

class _BudgetItemCard extends StatelessWidget {
  final BudgetItemModel item;
  final bool canEdit;

  const _BudgetItemCard({required this.item, required this.canEdit});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: item.isPaid ? Colors.green.withValues(alpha: 0.15) : Colors.orange.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              item.isPaid ? Icons.check_circle : Icons.pending,
              color: item.isPaid ? Colors.green : Colors.orange,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.itemName, style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.onPrimaryContainer,
                )),
                Text(item.category.toUpperCase(), style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.6),
                )),
                if (item.notes != null && item.notes!.isNotEmpty)
                  Text(item.notes!, style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                  ), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('\$${item.cost.toStringAsFixed(2)}', style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.onPrimaryContainer,
              )),
              if (canEdit)
                InkWell(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => AddEditBudgetItemScreen(item: item)),
                  ),
                  child: Text('Edit', style: TextStyle(
                    fontSize: 12,
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  )),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
