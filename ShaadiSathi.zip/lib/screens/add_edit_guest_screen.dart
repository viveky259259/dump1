import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shaadisathi/services/guest_service.dart';
import 'package:shaadisathi/models/guest_model.dart';
import 'package:shaadisathi/widgets/tag_chip.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class AddEditGuestScreen extends StatefulWidget {
  final GuestModel? guest;

  const AddEditGuestScreen({super.key, this.guest});

  @override
  State<AddEditGuestScreen> createState() => _AddEditGuestScreenState();
}

class _AddEditGuestScreenState extends State<AddEditGuestScreen> {
  final GuestService _guestService = GuestService();
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _contactController = TextEditingController();
  final _emailController = TextEditingController();
  
  final List<String> _availableTags = ['family', 'friend', 'office', 'relative', 'colleague'];
  final List<String> _selectedTags = [];
  String _rsvpStatus = 'pending';

  @override
  void initState() {
    super.initState();
    if (widget.guest != null) {
      _nameController.text = widget.guest!.name;
      _contactController.text = widget.guest!.contactInfo;
      _emailController.text = widget.guest!.email ?? '';
      _selectedTags.addAll(widget.guest!.tags);
      _rsvpStatus = widget.guest!.rsvpStatus ?? 'pending';
    }
  }

  Future<void> _saveGuest() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) return;

      final now = DateTime.now();
      final guest = GuestModel(
        id: widget.guest?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        contactInfo: _contactController.text.trim(),
        email: _emailController.text.trim().isEmpty ? null : _emailController.text.trim(),
        tags: _selectedTags,
        addedBy: widget.guest?.addedBy ?? currentUser.uid,
        rsvpStatus: _rsvpStatus,
        createdAt: widget.guest?.createdAt ?? now,
        updatedAt: now,
      );

      if (widget.guest == null) {
        await _guestService.addGuest(guest);
      } else {
        await _guestService.updateGuest(guest);
      }

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Guest ${widget.guest == null ? 'added' : 'updated'} successfully')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  void _toggleTag(String tag) {
    setState(() {
      if (_selectedTags.contains(tag)) {
        _selectedTags.remove(tag);
      } else {
        _selectedTags.add(tag);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        leading: TestIconButton(
          id: TestIds.backButton,
          icon: Icons.arrow_back,
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(widget.guest == null ? 'Add Guest' : 'Edit Guest', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: TestSemantics(
            id: TestIds.screenAddEditGuest,
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                TestSemantics(
                  id: TestIds.guestNameField,
                  child: TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'Full Name *',
                    prefixIcon: Icon(Icons.person, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) => value?.isEmpty == true ? 'Name is required' : null,
                ),
                ),
                const SizedBox(height: 20),
                TestSemantics(
                  id: TestIds.guestPhoneField,
                  child: TextFormField(
                  controller: _contactController,
                  decoration: InputDecoration(
                    labelText: 'Contact Info *',
                    prefixIcon: Icon(Icons.phone, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) => value?.isEmpty == true ? 'Contact is required' : null,
                ),
                ),
                const SizedBox(height: 20),
                TestSemantics(
                  id: TestIds.guestEmailField,
                  child: TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email (Optional)',
                    prefixIcon: Icon(Icons.email, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                ),
                ),
                const SizedBox(height: 24),
                Text('Tags', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _availableTags.map((tag) => TagChip(
                    label: tag,
                    isSelected: _selectedTags.contains(tag),
                    onTap: () => _toggleTag(tag),
                  )).toList(),
                ),
                const SizedBox(height: 24),
                Text('RSVP Status', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _rsvpStatus,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  items: ['pending', 'confirmed', 'declined'].map((status) => DropdownMenuItem(
                    value: status,
                    child: Text(status.toUpperCase()),
                  )).toList(),
                  onChanged: (value) => setState(() => _rsvpStatus = value!),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: TestSemantics(
                    id: TestIds.saveButton,
                    isButton: true,
                    child: ElevatedButton(
                    onPressed: _saveGuest,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: Text(widget.guest == null ? 'Add Guest' : 'Update Guest', style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onPrimary,
                    )),
                  ),
                  ),
                ),
                if (widget.guest != null) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: OutlinedButton(
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Delete Guest'),
                            content: const Text('Are you sure you want to delete this guest?'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: Text('Delete', style: TextStyle(color: theme.colorScheme.error)),
                              ),
                            ],
                          ),
                        );
                        if (confirm == true) {
                          await _guestService.deleteGuest(widget.guest!.id);
                          if (mounted) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Guest deleted')),
                            );
                          }
                        }
                      },
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: theme.colorScheme.error, width: 2),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text('Delete Guest', style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.error,
                      )),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _contactController.dispose();
    _emailController.dispose();
    super.dispose();
  }
}
