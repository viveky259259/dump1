import 'package:flutter/material.dart';
import 'package:shaadisathi/services/gift_service.dart';
import 'package:shaadisathi/models/gift_model.dart';
import 'package:shaadisathi/widgets/empty_state_widget.dart';
import 'package:shaadisathi/screens/add_edit_gift_screen.dart';
import 'package:intl/intl.dart';
import 'package:shaadisathi/testing/test_ids.dart';
import 'package:shaadisathi/testing/test_semantics.dart';

class GiftListScreen extends StatefulWidget {
  const GiftListScreen({super.key});

  @override
  State<GiftListScreen> createState() => _GiftListScreenState();
}

class _GiftListScreenState extends State<GiftListScreen> {
  final GiftService _giftService = GiftService();
  String? _selectedCategory;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Gift Tracker', style: TextStyle(
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.onSurface,
        )),
        actions: [
          TestIconButton(
            id: TestIds.addFab,
            icon: Icons.add,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddEditGiftScreen()),
            ),
          ),
        ],
      ),
      body: TestSemantics(
        id: TestIds.screenGiftList,
        child: Column(
        children: [
          FutureBuilder<double>(
            future: _giftService.calculateTotalGiftValue(),
            builder: (context, snapshot) {
              final totalValue = snapshot.data ?? 0;
              return Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Total Gift Value', style: theme.textTheme.titleMedium?.copyWith(
                          color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                        )),
                        const SizedBox(height: 8),
                        Text('\$${totalValue.toStringAsFixed(2)}', style: theme.textTheme.displaySmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.onPrimaryContainer,
                        )),
                      ],
                    ),
                    Icon(Icons.card_giftcard, size: 60, color: theme.colorScheme.secondary.withValues(alpha: 0.5)),
                  ],
                ),
              );
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ['All', 'cash', 'jewelry', 'household', 'other']
                    .map((cat) => Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: FilterChip(
                            label: Text(cat == 'All' ? cat : cat[0].toUpperCase() + cat.substring(1)),
                            selected: cat == 'All' ? _selectedCategory == null : _selectedCategory == cat,
                            onSelected: (selected) {
                              setState(() => _selectedCategory = cat == 'All' ? null : cat);
                            },
                          ),
                        ))
                    .toList(),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: StreamBuilder<List<GiftModel>>(
              stream: _selectedCategory != null
                  ? _giftService.streamGiftsByCategory(_selectedCategory!)
                  : _giftService.streamGifts(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return EmptyStateWidget(
                    icon: Icons.card_giftcard_outlined,
                    title: 'No Gifts Recorded',
                    message: 'Start recording gifts received from guests',
                    actionLabel: 'Add First Gift',
                    actionTestId: TestIds.emptyAddFirstGiftButton,
                    onActionPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const AddEditGiftScreen()),
                    ),
                  );
                }

                final gifts = snapshot.data!;
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: gifts.length,
                  itemBuilder: (context, index) {
                    final gift = gifts[index];
                    return TestSemantics(
                      id: TestIds.listItem('gift', gift.id),
                      child: _GiftCard(gift: gift),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      ),
    );
  }
}

class _GiftCard extends StatelessWidget {
  final GiftModel gift;

  const _GiftCard({required this.gift});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.purple.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.card_giftcard, color: Colors.purple),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(gift.giverName, style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.onPrimaryContainer,
                )),
                Text(gift.description, style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.7),
                ), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(DateFormat('MMM dd, yyyy').format(gift.receivedDate), style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer.withValues(alpha: 0.6),
                )),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('\$${gift.estimatedValue.toStringAsFixed(2)}', style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.onPrimaryContainer,
              )),
              if (gift.category != null)
                Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(gift.category!.toUpperCase(), style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.secondary,
                  )),
                ),
              InkWell(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => AddEditGiftScreen(gift: gift)),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('Edit', style: TextStyle(
                    fontSize: 12,
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  )),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
