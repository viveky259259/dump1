import 'package:flutter/material.dart';

/// Wraps a widget with Semantics and Tooltip using a shared testId.
/// Maestro can target these via accessibility label/tooltip reliably across platforms.
class TestSemantics extends StatelessWidget {
  final String id;
  final Widget child;
  final bool isButton;
  final bool enabled;

  const TestSemantics({
    super.key,
    required this.id,
    required this.child,
    this.isButton = false,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: id,
      button: isButton,
      enabled: enabled,
      child: Tooltip(
        message: id,
        child: child,
      ),
    );
  }
}

/// Convenience builder for IconButton/FAB etc.
class TestIconButton extends StatelessWidget {
  final String id;
  final VoidCallback? onPressed;
  final IconData icon;
  final String? tooltip;

  const TestIconButton({
    super.key,
    required this.id,
    required this.icon,
    this.onPressed,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return TestSemantics(
      id: id,
      isButton: true,
      enabled: onPressed != null,
      child: IconButton(
        icon: Icon(icon),
        onPressed: onPressed,
        tooltip: tooltip ?? id,
      ),
    );
  }
}

class TestButton extends StatelessWidget {
  final String id;
  final VoidCallback? onPressed;
  final Widget child;

  const TestButton({
    super.key,
    required this.id,
    required this.child,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return TestSemantics(
      id: id,
      isButton: true,
      enabled: onPressed != null,
      child: ElevatedButton(
        onPressed: onPressed,
        child: child,
      ),
    );
  }
}
