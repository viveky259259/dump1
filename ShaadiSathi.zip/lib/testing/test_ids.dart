/// Centralized test IDs for Maestro and accessibility labels.
/// Use these IDs as Semantics labels and Tooltips to create stable selectors.
class TestIds {
  // Auth
  static const screenLogin = 'screen_login';
  static const loginEmailField = 'login_email_field';
  static const loginPasswordField = 'login_password_field';
  static const loginSubmitButton = 'login_submit_button';
  static const loginWithPhoneButton = 'login_with_phone_button';
  static const continueAsGuestButton = 'continue_as_guest_button';

  static const screenPhoneAuth = 'screen_phone_auth';
  static const phoneInputField = 'phone_input_field';
  static const sendOtpButton = 'send_otp_button';
  static const otpInputField = 'otp_input_field';
  static const verifyOtpButton = 'verify_otp_button';

  // Dashboard
  static const screenDashboard = 'screen_dashboard';
  static const navToGuestsButton = 'nav_to_guests_button';
  static const navToTasksButton = 'nav_to_tasks_button';
  static const navToGiftsButton = 'nav_to_gifts_button';
  static const navToBudgetButton = 'nav_to_budget_button';
  static const navToSettingsButton = 'nav_to_settings_button';
  
  // Bottom navigation items
  static const bottomNavHome = 'bottom_nav_home';
  static const bottomNavGuests = 'bottom_nav_guests';
  static const bottomNavTasks = 'bottom_nav_tasks';
  static const bottomNavBudget = 'bottom_nav_budget';
  static const bottomNavGifts = 'bottom_nav_gifts';

  // Generic
  static const backButton = 'back_button';
  static const saveButton = 'save_button';
  static const cancelButton = 'cancel_button';
  static const addFab = 'add_fab';

  // Lists
  static const screenGuestList = 'screen_guest_list';
  static const screenTaskBoard = 'screen_task_board';
  static const screenGiftList = 'screen_gift_list';
  static const screenBudget = 'screen_budget';
  static const searchField = 'search_field';
  static String listItem(String entity, String id) => 'list_item_${entity}_$id';

  // Guest form
  static const screenAddEditGuest = 'screen_add_edit_guest';
  static const guestNameField = 'guest_name_field';
  static const guestPhoneField = 'guest_phone_field';
  static const guestEmailField = 'guest_email_field';

  // Task form
  static const screenAddEditTask = 'screen_add_edit_task';
  static const taskTitleField = 'task_title_field';
  static const taskDescField = 'task_desc_field';
  static const taskDueDateField = 'task_duedate_field';

  // Gift form
  static const screenAddEditGift = 'screen_add_edit_gift';
  static const giftNameField = 'gift_name_field';
  static const giftDescriptionField = 'gift_description_field';
  static const giftPriceField = 'gift_price_field';
  static const giftRecipientField = 'gift_recipient_field';

  // Budget form
  static const screenAddEditBudgetItem = 'screen_add_edit_budget_item';
  static const budgetTitleField = 'budget_title_field';
  static const budgetAmountField = 'budget_amount_field';

  // Settings
  static const screenSettings = 'screen_settings';
  static const notificationsToggle = 'notifications_toggle';
  static const logoutButton = 'logout_button';
  
  // Empty states actions
  static const emptyAddFirstGuestButton = 'empty_add_first_guest_button';
  static const emptyCreateFirstTaskButton = 'empty_create_first_task_button';
  static const emptyAddFirstExpenseButton = 'empty_add_first_expense_button';
  static const emptyAddFirstGiftButton = 'empty_add_first_gift_button';
}
