import 'package:cloud_firestore/cloud_firestore.dart';

class GiftModel {
  final String id;
  final String giverName;
  final String? guestId;
  final String description;
  final double estimatedValue;
  final String receivedBy;
  final DateTime receivedDate;
  final String? category;
  final DateTime createdAt;
  final DateTime updatedAt;

  GiftModel({
    required this.id,
    required this.giverName,
    this.guestId,
    required this.description,
    required this.estimatedValue,
    required this.receivedBy,
    required this.receivedDate,
    this.category,
    required this.createdAt,
    required this.updatedAt,
  });

  factory GiftModel.fromJson(Map<String, dynamic> json) => GiftModel(
    id: json['id'] as String,
    giverName: json['giverName'] as String,
    guestId: json['guestId'] as String?,
    description: json['description'] as String,
    estimatedValue: (json['estimatedValue'] as num).toDouble(),
    receivedBy: json['receivedBy'] as String,
    receivedDate: (json['receivedDate'] as Timestamp).toDate(),
    category: json['category'] as String?,
    createdAt: (json['createdAt'] as Timestamp).toDate(),
    updatedAt: (json['updatedAt'] as Timestamp).toDate(),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'giverName': giverName,
    'guestId': guestId,
    'description': description,
    'estimatedValue': estimatedValue,
    'receivedBy': receivedBy,
    'receivedDate': Timestamp.fromDate(receivedDate),
    'category': category,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
  };

  GiftModel copyWith({
    String? id,
    String? giverName,
    String? guestId,
    String? description,
    double? estimatedValue,
    String? receivedBy,
    DateTime? receivedDate,
    String? category,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => GiftModel(
    id: id ?? this.id,
    giverName: giverName ?? this.giverName,
    guestId: guestId ?? this.guestId,
    description: description ?? this.description,
    estimatedValue: estimatedValue ?? this.estimatedValue,
    receivedBy: receivedBy ?? this.receivedBy,
    receivedDate: receivedDate ?? this.receivedDate,
    category: category ?? this.category,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
