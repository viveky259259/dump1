import 'package:cloud_firestore/cloud_firestore.dart';

class TaskModel {
  final String id;
  final String title;
  final String description;
  final String? assignedTo;
  final String status;
  final String createdBy;
  final DateTime? dueDate;
  final String? priority;
  final DateTime createdAt;
  final DateTime updatedAt;

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    this.assignedTo,
    required this.status,
    required this.createdBy,
    this.dueDate,
    this.priority,
    required this.createdAt,
    required this.updatedAt,
  });

  factory TaskModel.fromJson(Map<String, dynamic> json) => TaskModel(
    id: json['id'] as String,
    title: json['title'] as String,
    description: json['description'] as String,
    assignedTo: json['assignedTo'] as String?,
    status: json['status'] as String,
    createdBy: json['createdBy'] as String,
    dueDate: json['dueDate'] != null ? (json['dueDate'] as Timestamp).toDate() : null,
    priority: json['priority'] as String?,
    createdAt: (json['createdAt'] as Timestamp).toDate(),
    updatedAt: (json['updatedAt'] as Timestamp).toDate(),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'assignedTo': assignedTo,
    'status': status,
    'createdBy': createdBy,
    'dueDate': dueDate != null ? Timestamp.fromDate(dueDate!) : null,
    'priority': priority,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
  };

  TaskModel copyWith({
    String? id,
    String? title,
    String? description,
    String? assignedTo,
    String? status,
    String? createdBy,
    DateTime? dueDate,
    String? priority,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => TaskModel(
    id: id ?? this.id,
    title: title ?? this.title,
    description: description ?? this.description,
    assignedTo: assignedTo ?? this.assignedTo,
    status: status ?? this.status,
    createdBy: createdBy ?? this.createdBy,
    dueDate: dueDate ?? this.dueDate,
    priority: priority ?? this.priority,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
