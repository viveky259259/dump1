import 'package:cloud_firestore/cloud_firestore.dart';

class GuestModel {
  final String id;
  final String name;
  final List<String> tags;
  final String contactInfo;
  final String? email;
  final String addedBy;
  final String? rsvpStatus;
  final DateTime createdAt;
  final DateTime updatedAt;

  GuestModel({
    required this.id,
    required this.name,
    required this.tags,
    required this.contactInfo,
    this.email,
    required this.addedBy,
    this.rsvpStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  factory GuestModel.fromJson(Map<String, dynamic> json) => GuestModel(
    id: json['id'] as String,
    name: json['name'] as String,
    tags: List<String>.from(json['tags'] as List),
    contactInfo: json['contactInfo'] as String,
    email: json['email'] as String?,
    addedBy: json['addedBy'] as String,
    rsvpStatus: json['rsvpStatus'] as String?,
    createdAt: (json['createdAt'] as Timestamp).toDate(),
    updatedAt: (json['updatedAt'] as Timestamp).toDate(),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'tags': tags,
    'contactInfo': contactInfo,
    'email': email,
    'addedBy': addedBy,
    'rsvpStatus': rsvpStatus,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
  };

  GuestModel copyWith({
    String? id,
    String? name,
    List<String>? tags,
    String? contactInfo,
    String? email,
    String? addedBy,
    String? rsvpStatus,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => GuestModel(
    id: id ?? this.id,
    name: name ?? this.name,
    tags: tags ?? this.tags,
    contactInfo: contactInfo ?? this.contactInfo,
    email: email ?? this.email,
    addedBy: addedBy ?? this.addedBy,
    rsvpStatus: rsvpStatus ?? this.rsvpStatus,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
