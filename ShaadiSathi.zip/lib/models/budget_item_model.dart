import 'package:cloud_firestore/cloud_firestore.dart';

class BudgetItemModel {
  final String id;
  final String itemName;
  final String category;
  final double cost;
  final bool isPaid;
  final String createdBy;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  BudgetItemModel({
    required this.id,
    required this.itemName,
    required this.category,
    required this.cost,
    required this.isPaid,
    required this.createdBy,
    this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  factory BudgetItemModel.fromJson(Map<String, dynamic> json) => BudgetItemModel(
    id: json['id'] as String,
    itemName: json['itemName'] as String,
    category: json['category'] as String,
    cost: (json['cost'] as num).toDouble(),
    isPaid: json['isPaid'] as bool,
    createdBy: json['createdBy'] as String,
    notes: json['notes'] as String?,
    createdAt: (json['createdAt'] as Timestamp).toDate(),
    updatedAt: (json['updatedAt'] as Timestamp).toDate(),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'itemName': itemName,
    'category': category,
    'cost': cost,
    'isPaid': isPaid,
    'createdBy': createdBy,
    'notes': notes,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
  };

  BudgetItemModel copyWith({
    String? id,
    String? itemName,
    String? category,
    double? cost,
    bool? isPaid,
    String? createdBy,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => BudgetItemModel(
    id: id ?? this.id,
    itemName: itemName ?? this.itemName,
    category: category ?? this.category,
    cost: cost ?? this.cost,
    isPaid: isPaid ?? this.isPaid,
    createdBy: createdBy ?? this.createdBy,
    notes: notes ?? this.notes,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
