import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/theme.dart';
import '../main.dart';
import '../services/storage_service.dart';
import '../services/analytics_service.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({Key? key}) : super(key: key);

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> with TickerProviderStateMixin {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _incomeController = TextEditingController();
  final StorageService _storageService = StorageService();
  final AnalyticsService _analyticsService = AnalyticsService();
  
  late TabController _tabController;
  late PageController _pageController;
  late AnimationController _animationController;
  
  int _currentPage = 0;
  final int _totalPages = 4;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _totalPages, vsync: this);
    _pageController = PageController();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _animationController.forward();
    
    // Log onboarding start for analytics
    _analyticsService.logEvent(
      name: 'onboarding_started',
      parameters: {
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      },
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _incomeController.dispose();
    _tabController.dispose();
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
      _tabController.animateTo(page);
    });
    
    // Log page change for analytics
    _analyticsService.logEvent(
      name: 'onboarding_page_viewed',
      parameters: {
        'page_index': page,
        'page_name': _getPageName(page),
      },
    );
  }

  String _getPageName(int page) {
    switch (page) {
      case 0: return 'welcome';
      case 1: return 'features';
      case 2: return 'personalize';
      case 3: return 'income_setup';
      default: return 'unknown';
    }
  }

  void _nextPage() {
    if (_currentPage < _totalPages - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _completeOnboarding() async {
    final provider = Provider.of<TransactionsProvider>(context, listen: false);
    
    // Save username if provided
    final name = _nameController.text.trim();
    if (name.isNotEmpty) {
      await provider.setUsername(name);
    }
    
    // Save income if provided
    final incomeText = _incomeController.text.trim();
    if (incomeText.isNotEmpty) {
      try {
        final income = double.parse(incomeText);
        await provider.setIncome(income);
      } catch (_) {}
    }
    
    // Save onboarding completion flag
    await _storageService.setOnboardingCompleted(true);
    
    // Log onboarding completion
    _analyticsService.logEvent(
      name: 'onboarding_completed',
      parameters: {
        'provided_name': name.isNotEmpty,
        'provided_income': incomeText.isNotEmpty,
      },
    );
    
    // Navigate to main app
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const MainScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Progress indicator
          Container(
            padding: const EdgeInsets.only(top: 60, bottom: 20),
            color: AppTheme.primaryColor,
            child: Column(
              children: [
                TabPageSelector(
                  controller: _tabController,
                  selectedColor: Colors.white,
                  color: Colors.white.withOpacity(0.3),
                ),
                const SizedBox(height: 8),
                Text(
                  _getStepText(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          // Page content
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: _onPageChanged,
              children: [
                _buildWelcomePage(),
                _buildFeaturesPage(),
                _buildPersonalizePage(),
                _buildIncomePage(),
              ],
            ),
          ),
          // Navigation buttons
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  offset: const Offset(0, -2),
                  blurRadius: 10,
                ),
              ],
            ),
            child: SafeArea(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _currentPage > 0
                      ? TextButton(
                          onPressed: _previousPage,
                          child: const Text('Back'),
                        )
                      : const SizedBox(width: 80),
                  ElevatedButton(
                    onPressed: _currentPage == _totalPages - 1
                        ? _completeOnboarding
                        : _nextPage,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 12,
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      _currentPage == _totalPages - 1 ? 'Get Started' : 'Next',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getStepText() {
    return 'STEP ${_currentPage + 1} OF $_totalPages';
  }

  Widget _buildWelcomePage() {
    return FadeTransition(
      opacity: _animationController,
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // App Icon/Logo
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: const Center(
                child: Icon(
                  Icons.attach_money,
                  color: Colors.white,
                  size: 60,
                ),
              ),
            ),
            const SizedBox(height: 40),
            // Welcome Text
            Text(
              'Welcome to CashGuru',
              style: Theme.of(context).textTheme.displayMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryTextColor,
                  ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              'Your GenZ Financial Bestie',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppTheme.primaryColor,
                    fontWeight: FontWeight.w500,
                  ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            Text(
              'Ready to slay your finances and level up your money game? We got you, bestie! 💅',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppTheme.secondaryTextColor,
                    height: 1.5,
                  ),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            // Skip button
            TextButton(
              onPressed: _completeOnboarding,
              child: const Text('Skip Intro'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturesPage() {
    final features = [
      {
        'title': 'Track That Coin',
        'description': 'See where your money is going in real-time with easy expense tracking',
        'icon': Icons.trending_up,
      },
      {
        'title': 'Financial Tea',
        'description': 'Get personalized money advice from our AI bestie in GenZ language',
        'icon': Icons.chat_bubble_outline,
      },
      {
        'title': 'Budget Vibe Check',
        'description': 'Create budgets that match your lifestyle and help you reach goals',
        'icon': Icons.pie_chart_outline,
      },
      {
        'title': 'Money Challenges',
        'description': 'Level up your savings with fun challenges and rewards',
        'icon': Icons.emoji_events_outlined,
      },
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 40),
          Text(
            'Why CashGuru is Giving Main Character Energy ✨',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryTextColor,
                ),
          ),
          const SizedBox(height: 32),
          ...features.map((feature) => _buildFeatureItem(
                title: feature['title'] as String,
                description: feature['description'] as String,
                icon: feature['icon'] as IconData,
              )),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildFeatureItem({
    required String title,
    required String description,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: AppTheme.primaryColor,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(height: 8),
                Text(
                  description,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.secondaryTextColor,
                        height: 1.5,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalizePage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 40),
          Text(
            'Let\'s Make This App Yours',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryTextColor,
                ),
          ),
          const SizedBox(height: 16),
          Text(
            'What should we call you? 👋',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppTheme.secondaryTextColor,
                ),
          ),
          const SizedBox(height: 32),
          _buildNameInput(),
          const SizedBox(height: 40),
          Center(
            child: Column(
              children: [
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Icon(
                      Icons.person_outline,
                      size: 80,
                      color: AppTheme.primaryColor.withOpacity(0.7),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  'Your financial bestie is ready to help you slay!',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: AppTheme.primaryColor,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNameInput() {
    return TextFormField(
      controller: _nameController,
      decoration: InputDecoration(
        labelText: 'Your Name',
        hintText: 'Enter your name (or what to call you)',
        prefixIcon: const Icon(Icons.person_outline, color: AppTheme.primaryColor),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.grey.withOpacity(0.1),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
      textCapitalization: TextCapitalization.words,
      onChanged: (value) {
        // Track input changes for analytics if needed
      },
    );
  }

  Widget _buildIncomePage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 40),
          Text(
            'Last Step: Set Your Income',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryTextColor,
                ),
          ),
          const SizedBox(height: 16),
          Text(
            'This helps us create personalized budgets and savings goals for you',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppTheme.secondaryTextColor,
                ),
          ),
          const SizedBox(height: 32),
          _buildIncomeInput(),
          const SizedBox(height: 16),
          Text(
            'Don\'t worry, this info stays on your device and is totally private',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.secondaryTextColor,
                  fontStyle: FontStyle.italic,
                ),
          ),
          const SizedBox(height: 40),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Row(
                  children: const [
                    Icon(
                      Icons.lightbulb_outline,
                      color: AppTheme.primaryColor,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'Pro Tip',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Setting your income helps CashGuru give you personalized financial advice that\'s actually on point for your situation.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        height: 1.5,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIncomeInput() {
    return TextFormField(
      controller: _incomeController,
      decoration: InputDecoration(
        labelText: 'Monthly Income',
        hintText: 'How much do you make each month?',
        prefixIcon: const Icon(Icons.account_balance_wallet_outlined, color: AppTheme.primaryColor),
        prefixText: '\$ ',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.grey.withOpacity(0.1),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onChanged: (value) {
        // Track input changes for analytics if needed
      },
    );
  }
}