import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';
import '../theme/theme.dart';
import 'dart:math';

class Subscription {
  final String id;
  final String name;
  final double amount;
  final String cycle; // monthly, yearly, weekly
  final DateTime nextBillingDate;
  final String category;
  final String? logoPath; // can be null for custom subscriptions

  Subscription({
    required this.id,
    required this.name,
    required this.amount,
    required this.cycle,
    required this.nextBillingDate,
    required this.category,
    this.logoPath,
  });
}

class SubscriptionProvider extends ChangeNotifier {
  final List<Subscription> _subscriptions = [
    Subscription(
      id: '1',
      name: 'Spotify',
      amount: 9.99,
      cycle: 'monthly',
      nextBillingDate: DateTime.now().add(const Duration(days: 12)),
      category: 'Entertainment',
      logoPath: 'spotify',
    ),
    Subscription(
      id: '2',
      name: 'Netflix',
      amount: 15.49,
      cycle: 'monthly',
      nextBillingDate: DateTime.now().add(const Duration(days: 5)),
      category: 'Entertainment',
      logoPath: 'netflix',
    ),
    Subscription(
      id: '3',
      name: 'Gym Membership',
      amount: 29.99,
      cycle: 'monthly',
      nextBillingDate: DateTime.now().add(const Duration(days: 20)),
      category: 'Health',
      logoPath: null,
    ),
  ];

  List<Subscription> get subscriptions => [..._subscriptions];

  double get totalMonthly {
    double total = 0;
    for (var sub in _subscriptions) {
      switch (sub.cycle) {
        case 'monthly':
          total += sub.amount;
          break;
        case 'yearly':
          total += sub.amount / 12;
          break;
        case 'weekly':
          total += sub.amount * 4.33; // average weeks per month
          break;
      }
    }
    return total;
  }

  double get totalYearly {
    double total = 0;
    for (var sub in _subscriptions) {
      switch (sub.cycle) {
        case 'monthly':
          total += sub.amount * 12;
          break;
        case 'yearly':
          total += sub.amount;
          break;
        case 'weekly':
          total += sub.amount * 52; // weeks per year
          break;
      }
    }
    return total;
  }

  void addSubscription(Subscription subscription) {
    _subscriptions.add(subscription);
    notifyListeners();
  }

  void removeSubscription(String id) {
    _subscriptions.removeWhere((sub) => sub.id == id);
    notifyListeners();
  }

  List<Subscription> getUpcomingBillings() {
    final now = DateTime.now();
    final oneWeekLater = now.add(const Duration(days: 7));
    
    final upcoming = _subscriptions
        .where((sub) => 
            sub.nextBillingDate.isAfter(now) && 
            sub.nextBillingDate.isBefore(oneWeekLater))
        .toList();
    
    upcoming.sort((a, b) => a.nextBillingDate.compareTo(b.nextBillingDate));
    
    return upcoming;
  }
}

class SubscriptionTrackerScreen extends StatefulWidget {
  const SubscriptionTrackerScreen({Key? key}) : super(key: key);

  @override
  _SubscriptionTrackerScreenState createState() => _SubscriptionTrackerScreenState();
}

class _SubscriptionTrackerScreenState extends State<SubscriptionTrackerScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _amountController = TextEditingController();
  String _selectedCycle = 'monthly';
  final DateTime _selectedDate = DateTime.now().add(const Duration(days: 30));
  String _selectedCategory = 'Entertainment';
  bool _showAddForm = false;
  
  final List<String> _categories = [
    'Entertainment',
    'Health',
    'Shopping',
    'Software',
    'Food',
    'Utilities',
    'Other',
  ];
  
  final List<String> _cycles = ['monthly', 'yearly', 'weekly'];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _nameController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _toggleAddForm() {
    setState(() {
      _showAddForm = !_showAddForm;
      if (!_showAddForm) {
        _resetForm();
      }
    });
  }

  void _resetForm() {
    _nameController.clear();
    _amountController.clear();
    setState(() {
      _selectedCycle = 'monthly';
      _selectedCategory = 'Entertainment';
    });
  }

  void _addSubscription() {
    if (_formKey.currentState!.validate()) {
      final provider = Provider.of<SubscriptionProvider>(context, listen: false);
      
      final newSubscription = Subscription(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text,
        amount: double.parse(_amountController.text),
        cycle: _selectedCycle,
        nextBillingDate: _selectedDate,
        category: _selectedCategory,
      );
      
      provider.addSubscription(newSubscription);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${_nameController.text} added to your subscriptions!'),
          backgroundColor: AppTheme.primaryColor,
          behavior: SnackBarBehavior.floating,
        ),
      );
      
      _toggleAddForm();
    }
  }

  String _formatDate(DateTime date) {
    return '${date.month}/${date.day}/${date.year}';
  }

  String _getDaysUntil(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now).inDays;
    
    if (difference == 0) {
      return 'Today';
    } else if (difference == 1) {
      return 'Tomorrow';
    } else {
      return 'In $difference days';
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Entertainment':
        return Icons.movie_outlined;
      case 'Health':
        return Icons.fitness_center_outlined;
      case 'Shopping':
        return Icons.shopping_bag_outlined;
      case 'Software':
        return Icons.laptop_mac_outlined;
      case 'Food':
        return Icons.restaurant_outlined;
      case 'Utilities':
        return Icons.electrical_services_outlined;
      default:
        return Icons.category_outlined;
    }
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Entertainment':
        return Colors.purple;
      case 'Health':
        return Colors.green;
      case 'Shopping':
        return Colors.orange;
      case 'Software':
        return Colors.blue;
      case 'Food':
        return Colors.red;
      case 'Utilities':
        return Colors.teal;
      default:
        return AppTheme.primaryColor;
    }
  }

  String _formatCycle(String cycle, double amount) {
    switch (cycle) {
      case 'monthly':
        return '${amount}/month';
      case 'yearly':
        return '${amount}/year';
      case 'weekly':
        return '${amount}/week';
      default:
        return '${amount}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SubscriptionProvider(),
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Subscription Tracker 📅',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppTheme.lightTextColor,
                ),
          ),
          actions: [
            IconButton(
              icon: Icon(_showAddForm ? Icons.close : Icons.add, color: Colors.white),
              onPressed: _toggleAddForm,
            ),
          ],
        ),
        body: Consumer<SubscriptionProvider>(
          builder: (context, provider, child) {
            return _showAddForm
                ? _buildAddSubscriptionForm()
                : _buildSubscriptionsList(provider);
          },
        ),
      ),
    );
  }

  Widget _buildSubscriptionsList(SubscriptionProvider provider) {
    final subscriptions = provider.subscriptions;
    final upcomingBillings = provider.getUpcomingBillings();
    
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSubscriptionSummary(provider),
            const SizedBox(height: 24),
            if (upcomingBillings.isNotEmpty) ...[  
              _buildUpcomingBillings(upcomingBillings),
              const SizedBox(height: 24),
            ],
            Text(
              'Your Subscriptions (${subscriptions.length})',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            if (subscriptions.isEmpty)
              _buildEmptyState()
            else
              ...subscriptions.map((sub) => _buildSubscriptionItem(sub, provider)).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.subscriptions_outlined,
            size: 64,
            color: AppTheme.primaryColor.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
          Text(
            'No subscriptions yet',
            style: Theme.of(context).textTheme.titleMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            'Add your subscriptions to track them and avoid surprise charges',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.secondaryTextColor,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _toggleAddForm,
            icon: const Icon(Icons.add),
            label: const Text('Add Subscription'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubscriptionSummary(SubscriptionProvider provider) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Subscription Summary',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                    ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.timeline,
                      color: Colors.white,
                      size: 16,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'Monthly',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            '${provider.totalMonthly.toStringAsFixed(2)}',
            style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(
                'Yearly: ',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withOpacity(0.8),
                    ),
              ),
              Text(
                '${provider.totalYearly.toStringAsFixed(2)}',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.lightbulb_outline,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  "That's ${(provider.totalMonthly / 8).toStringAsFixed(1)} iced lattes a month!",
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white,
                      ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUpcomingBillings(List<Subscription> upcomingBillings) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Upcoming Charges',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: upcomingBillings.length,
            separatorBuilder: (context, index) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final sub = upcomingBillings[index];
              return ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _getCategoryColor(sub.category).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _getCategoryIcon(sub.category),
                    color: _getCategoryColor(sub.category),
                  ),
                ),
                title: Text(sub.name),
                subtitle: Text(_getDaysUntil(sub.nextBillingDate)),
                trailing: Text(
                  '${sub.amount.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSubscriptionItem(Subscription subscription, SubscriptionProvider provider) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Dismissible(
        key: Key(subscription.id),
        direction: DismissDirection.endToStart,
        background: Container(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20.0),
          decoration: BoxDecoration(
            color: Colors.red,
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Icon(
            Icons.delete_outline,
            color: Colors.white,
            size: 30,
          ),
        ),
        confirmDismiss: (direction) async {
          return await showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Confirm Deletion'),
              content: Text('Are you sure you want to remove ${subscription.name}?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text(
                    'Delete',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          );
        },
        onDismissed: (direction) {
          provider.removeSubscription(subscription.id);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${subscription.name} removed'),
              action: SnackBarAction(
                label: 'UNDO',
                onPressed: () {
                  provider.addSubscription(subscription);
                },
              ),
              backgroundColor: AppTheme.secondaryTextColor,
              behavior: SnackBarBehavior.floating,
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: _getCategoryColor(subscription.category).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Icon(
                    _getCategoryIcon(subscription.category),
                    color: _getCategoryColor(subscription.category),
                    size: 24,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      subscription.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${subscription.category} • Next: ${_formatDate(subscription.nextBillingDate)}',
                      style: TextStyle(
                        color: AppTheme.secondaryTextColor,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${subscription.amount.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subscription.cycle,
                    style: TextStyle(
                      color: AppTheme.secondaryTextColor,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAddSubscriptionForm() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Add New Subscription',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Subscription Name',
                  prefixIcon: Icon(Icons.text_fields),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Amount',
                  prefixIcon: Icon(Icons.attach_money),
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an amount';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Please enter a valid number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              Text(
                'Billing Cycle',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                children: _cycles.map((cycle) {
                  return ChoiceChip(
                    label: Text(cycle),
                    selected: _selectedCycle == cycle,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() {
                          _selectedCycle = cycle;
                        });
                      }
                    },
                    selectedColor: AppTheme.primaryColor,
                    labelStyle: TextStyle(
                      color: _selectedCycle == cycle ? Colors.white : AppTheme.primaryTextColor,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              Text(
                'Category',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: _categories.map((category) {
                  return ChoiceChip(
                    avatar: Icon(
                      _getCategoryIcon(category),
                      size: 18,
                      color: _selectedCategory == category ? Colors.white : _getCategoryColor(category),
                    ),
                    label: Text(category),
                    selected: _selectedCategory == category,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() {
                          _selectedCategory = category;
                        });
                      }
                    },
                    selectedColor: _getCategoryColor(category),
                    labelStyle: TextStyle(
                      color: _selectedCategory == category ? Colors.white : AppTheme.primaryTextColor,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 32),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _toggleAddForm,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _addSubscription,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: const Text('Add Subscription'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}