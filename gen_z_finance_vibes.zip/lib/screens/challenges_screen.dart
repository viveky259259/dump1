import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/theme.dart';
import '../main.dart';
import 'dart:math';

class Challenge {
  final String id;
  final String title;
  final String description;
  final String emoji;
  final int durationDays;
  final double targetAmount;
  bool isActive;
  double currentProgress;
  DateTime? startDate;

  Challenge({
    required this.id,
    required this.title,
    required this.description,
    required this.emoji,
    required this.durationDays,
    required this.targetAmount,
    this.isActive = false,
    this.currentProgress = 0.0,
    this.startDate,
  });

  Challenge copyWith({
    String? id,
    String? title,
    String? description,
    String? emoji,
    int? durationDays,
    double? targetAmount,
    bool? isActive,
    double? currentProgress,
    DateTime? startDate,
  }) {
    return Challenge(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      emoji: emoji ?? this.emoji,
      durationDays: durationDays ?? this.durationDays,
      targetAmount: targetAmount ?? this.targetAmount,
      isActive: isActive ?? this.isActive,
      currentProgress: currentProgress ?? this.currentProgress,
      startDate: startDate ?? this.startDate,
    );
  }
}

class ChallengesProvider extends ChangeNotifier {
  final List<Challenge> _challenges = [
    Challenge(
      id: '1',
      title: 'No Coffee Challenge',
      description: 'Skip your daily coffee shop runs and save that cash!',
      emoji: '☕',
      durationDays: 7,
      targetAmount: 35.0,
    ),
    Challenge(
      id: '2',
      title: 'No Online Shopping',
      description: 'Put down the phone and stop those impulse buys!',
      emoji: '🛍️',
      durationDays: 14,
      targetAmount: 150.0,
    ),
    Challenge(
      id: '3',
      title: 'Meal Prep Master',
      description: 'Pack lunch every day instead of eating out!',
      emoji: '🥪',
      durationDays: 5,
      targetAmount: 60.0,
    ),
    Challenge(
      id: '4',
      title: 'Power Saver',
      description: 'Reduce your electricity usage for a week!',
      emoji: '⚡',
      durationDays: 7,
      targetAmount: 25.0,
    ),
    Challenge(
      id: '5',
      title: 'Entertainment Budget',
      description: 'Set a strict entertainment budget and stick to it!',
      emoji: '🎬',
      durationDays: 30,
      targetAmount: 100.0,
    ),
    Challenge(
      id: '6',
      title: 'Public Transit Only',
      description: 'Use only public transportation and skip the rideshares!',
      emoji: '🚌',
      durationDays: 10,
      targetAmount: 75.0,
    ),
  ];

  List<Challenge> get challenges => _challenges;

  List<Challenge> get activeChallenge => _challenges.where((challenge) => challenge.isActive).toList();

  void startChallenge(String id) {
    final index = _challenges.indexWhere((challenge) => challenge.id == id);
    if (index != -1) {
      _challenges[index] = _challenges[index].copyWith(
        isActive: true,
        startDate: DateTime.now(),
        currentProgress: 0.0,
      );
      notifyListeners();
    }
  }

  void updateChallengeProgress(String id, double progress) {
    final index = _challenges.indexWhere((challenge) => challenge.id == id);
    if (index != -1) {
      _challenges[index] = _challenges[index].copyWith(
        currentProgress: progress,
      );
      notifyListeners();
    }
  }

  void completeChallenge(String id) {
    final index = _challenges.indexWhere((challenge) => challenge.id == id);
    if (index != -1) {
      _challenges[index] = _challenges[index].copyWith(
        isActive: false,
        currentProgress: _challenges[index].targetAmount,
      );
      notifyListeners();
    }
  }

  void resetChallenge(String id) {
    final index = _challenges.indexWhere((challenge) => challenge.id == id);
    if (index != -1) {
      _challenges[index] = _challenges[index].copyWith(
        isActive: false,
        currentProgress: 0.0,
        startDate: null,
      );
      notifyListeners();
    }
  }
}

class ChallengesScreen extends StatefulWidget {
  const ChallengesScreen({Key? key}) : super(key: key);

  @override
  _ChallengesScreenState createState() => _ChallengesScreenState();
}

class _ChallengesScreenState extends State<ChallengesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ChallengesProvider(),
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Money Challenges 💪',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppTheme.lightTextColor,
                ),
          ),
          elevation: 0,
          bottom: TabBar(
            controller: _tabController,
            labelColor: Colors.white,
            labelStyle: const TextStyle(fontWeight: FontWeight.bold),
            unselectedLabelColor: Colors.white.withOpacity(0.7),
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            tabs: const [
              Tab(text: 'Available 🎯'),
              Tab(text: 'My Challenges 🔥'),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            _buildAvailableChallenges(),
            _buildActiveChallenges(),
          ],
        ),
      ),
    );
  }

  Widget _buildAvailableChallenges() {
    return Consumer<ChallengesProvider>(
      builder: (context, provider, child) {
        final availableChallenges = provider.challenges.where((c) => !c.isActive).toList();
        
        if (availableChallenges.isEmpty) {
          return _buildEmptyState('No available challenges',
              'You\'re crushing all the challenges right now! Check the "My Challenges" tab to see your progress.');
        }
        
        return FadeTransition(
          opacity: _fadeAnimation,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: availableChallenges.length,
            itemBuilder: (context, index) {
              final challenge = availableChallenges[index];
              return _buildChallengeCard(challenge, provider);
            },
          ),
        );
      },
    );
  }

  Widget _buildActiveChallenges() {
    return Consumer<ChallengesProvider>(
      builder: (context, provider, child) {
        final activeChallenge = provider.activeChallenge;
        
        if (activeChallenge.isEmpty) {
          return _buildEmptyState('No active challenges',
              'Start a challenge from the "Available" tab to begin saving money!');
        }
        
        return FadeTransition(
          opacity: _fadeAnimation,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: activeChallenge.length,
            itemBuilder: (context, index) {
              final challenge = activeChallenge[index];
              return _buildActiveChallengeCard(challenge, provider);
            },
          ),
        );
      },
    );
  }

  Widget _buildEmptyState(String title, String message) {
    return Center(
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.flag_outlined,
                size: 80,
                color: AppTheme.primaryColor.withOpacity(0.3),
              ),
              const SizedBox(height: 24),
              Text(
                title,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                message.replaceAll("challenges", "money moves").replaceAll("Available", "Vibe List"),
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppTheme.secondaryTextColor,
                    ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChallengeCard(Challenge challenge, ChallengesProvider provider) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.primaryColor,
                  AppTheme.secondaryColor,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      challenge.emoji,
                      style: const TextStyle(fontSize: 28),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        challenge.title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${challenge.durationDays} days • Save up to ${challenge.targetAmount.toStringAsFixed(2)}',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white.withOpacity(0.8),
                            ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  challenge.description,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          provider.startChallenge(challenge.id);
                          
                          // Show toast
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('${challenge.title} started! Let\'s get this bread! 🍞'),
                              backgroundColor: AppTheme.primaryColor,
                              behavior: SnackBarBehavior.floating,
                            ),
                          );
                          
                          // Switch to active tab
                          _tabController.animateTo(1);
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text('Accept Challenge'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveChallengeCard(Challenge challenge, ChallengesProvider provider) {
    // Calculate days remaining
    int daysRemaining = 0;
    if (challenge.startDate != null) {
      final endDate = challenge.startDate!.add(Duration(days: challenge.durationDays));
      daysRemaining = endDate.difference(DateTime.now()).inDays;
      daysRemaining = daysRemaining < 0 ? 0 : daysRemaining;
    }
    
    // Calculate progress percentage
    final progressPercentage = challenge.currentProgress / challenge.targetAmount;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.primaryColor,
                  AppTheme.secondaryColor,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      challenge.emoji,
                      style: const TextStyle(fontSize: 28),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        challenge.title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '$daysRemaining days left • ${challenge.currentProgress.toStringAsFixed(2)} saved',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white.withOpacity(0.8),
                            ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  challenge.description,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                // Progress bar
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Goal: ${challenge.targetAmount.toStringAsFixed(2)}',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                        Text(
                          '${(progressPercentage * 100).toStringAsFixed(0)}%',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: AppTheme.primaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Stack(
                      children: [
                        Container(
                          height: 12,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        FractionallySizedBox(
                          widthFactor: progressPercentage.clamp(0.0, 1.0),
                          child: Container(
                            height: 12,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Update progress button
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          _showUpdateProgressDialog(context, challenge, provider);
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text('Update Progress'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.cancel_outlined, color: Colors.red),
                        onPressed: () {
                          _showCancelDialog(context, challenge, provider);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showUpdateProgressDialog(BuildContext context, Challenge challenge, ChallengesProvider provider) {
    final TextEditingController progressController = TextEditingController(
      text: challenge.currentProgress.toStringAsFixed(2),
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Update ${challenge.title}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'How much have you saved so far?',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: progressController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.attach_money),
                hintText: '0.00',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (progressController.text.isNotEmpty) {
                try {
                  final progress = double.parse(progressController.text);
                  provider.updateChallengeProgress(challenge.id, progress);
                  
                  // Check if target reached
                  if (progress >= challenge.targetAmount) {
                    provider.completeChallenge(challenge.id);
                    
                    // Show completion dialog after dismissing this one
                    Navigator.pop(context);
                    _showCompletionDialog(context, challenge);
                  } else {
                    Navigator.pop(context);
                    
                    // Show toast
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Progress updated! Keep going! 🔥'),
                        backgroundColor: AppTheme.primaryColor,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  }
                } catch (e) {
                  // Show error for invalid input
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please enter a valid amount'),
                      backgroundColor: Colors.red,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                }
              }
            },
            child: const Text('Update'),
          ),
        ],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ).then((_) {
      progressController.dispose();
    });
  }

  void _showCancelDialog(BuildContext context, Challenge challenge, ChallengesProvider provider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Cancel Challenge?'),
        content: Text(
          'Are you sure you want to cancel "${challenge.title}"? Your progress will be lost.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('No, Keep Going'),
          ),
          TextButton(
            onPressed: () {
              provider.resetChallenge(challenge.id);
              Navigator.pop(context);
              
              // Show toast
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Challenge canceled. No worries, you can try again later!'),
                  backgroundColor: AppTheme.secondaryTextColor,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
            child: const Text('Yes, Cancel', style: TextStyle(color: Colors.red)),
          ),
        ],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  void _showCompletionDialog(BuildContext context, Challenge challenge) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('🎉 Challenge Complete! 🎉'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: AppTheme.primaryColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  challenge.emoji,
                  style: const TextStyle(fontSize: 50),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'You absolutely crushed the "${challenge.title}" challenge!',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 12),
            Text(
              'You saved ${challenge.targetAmount.toStringAsFixed(2)}! Your wallet is LIVING for this!',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _tabController.animateTo(0);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
            ),
            child: const Text('Find Another Money Move'),
          ),
        ],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }
}