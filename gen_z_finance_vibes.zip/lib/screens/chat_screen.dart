import 'package:flutter/material.dart';
import '../services/ai_service.dart';
import '../services/storage_service.dart';
import '../services/analytics_service.dart';
import '../theme/theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with TickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final AIService _aiService = AIService();
  final StorageService _storageService = StorageService();
  final AnalyticsService _analyticsService = AnalyticsService();
  final List<ChatMessage> _messages = [];
  bool _isTyping = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
  }
  
  Future<void> _loadChatHistory() async {
    setState(() {
      _isLoading = true;
    });
    
    // Load messages from local storage
    final savedMessages = await _storageService.loadChatMessages();
    
    if (savedMessages.isEmpty) {
      // If no saved messages, add the greeting message
      _addBotMessage(
        'Hey bestie! 👋 I\'m CashGuru, your money bestie. Ask me anything about your finances, budgeting, or how to stack that cash! No cap, I\'m here to help your wallet thrive.',
        saveToStorage: true
      );
    } else {
      // Convert saved messages to ChatMessage objects
      for (var msg in savedMessages) {
        final chatMessage = ChatMessage(
          text: msg['text'],
          isUser: msg['isUser'],
          animationController: AnimationController(
            duration: const Duration(milliseconds: 0),
            vsync: this,
          ),
        );
        
        setState(() {
          _messages.add(chatMessage);
        });
        
        chatMessage.animationController.forward();
      }
      
      // Scroll to bottom after loading messages
      Future.delayed(const Duration(milliseconds: 100), _scrollToBottom);
    }
    
    setState(() {
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _handleSubmitted(String text) async {
    _messageController.clear();
    if (text.trim().isEmpty) return;

    // Log user query to analytics
    _analyticsService.logAIInteraction(
      feature: 'chatbot_query',
      details: {
        'query_text': text,
        'query_length': text.length,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      } as Map<String, Object>,
    );

    // Add user message
    ChatMessage userMessage = ChatMessage(
      text: text,
      isUser: true,
      animationController: AnimationController(
        duration: const Duration(milliseconds: 300),
        vsync: this,
      ),
    );

    setState(() {
      _messages.add(userMessage);
      _isTyping = true;
    });

    // Save user message to storage
    await _storageService.addChatMessage({
      'text': text,
      'isUser': true,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });

    userMessage.animationController.forward();
    _scrollToBottom();

    // Get AI response
    try {
      final startTime = DateTime.now().millisecondsSinceEpoch;
      final response = await _aiService.getFinancialAdvice(text);
      final endTime = DateTime.now().millisecondsSinceEpoch;
      
      // Log successful API response to analytics
      _analyticsService.logAIInteraction(
        feature: 'chatbot_response',
        details: {
          'response_length': response.length,
          'response_time_ms': endTime - startTime,
          'success': true,
        } as Map<String, Object>,
      );
      
      _addBotMessage(response);
    } catch (e) {
      // Log error to analytics
      _analyticsService.logError(
        error: 'AI service error: $e',
        stackTrace: StackTrace.current,
      );
      
      _addBotMessage(
        'Oof, the vibes are off right now! Can\'t connect to the financial galaxy. Try again later? 💸',
      );
    }

    setState(() {
      _isTyping = false;
    });
    _scrollToBottom();
  }

  void _addBotMessage(String text, {bool saveToStorage = true}) {
    ChatMessage botMessage = ChatMessage(
      text: text,
      isUser: false,
      animationController: AnimationController(
        duration: const Duration(milliseconds: 300),
        vsync: this,
      ),
    );

    setState(() {
      _messages.add(botMessage);
    });
    
    // Save bot message to storage if specified
    if (saveToStorage) {
      _storageService.addChatMessage({
        'text': text,
        'isUser': false,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      });
    }

    botMessage.animationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Money Tea 🍵',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: AppTheme.lightTextColor,
              ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.white),
            onPressed: () {
              _showClearChatDialog();
            },
          ),
          IconButton(
            icon: const Icon(Icons.info_outline, color: Colors.white),
            onPressed: () {
              _showInfoDialog();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.backgroundColor,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppTheme.primaryColor.withOpacity(0.05),
                    AppTheme.backgroundColor,
                  ],
                ),
              ),
              child: _buildMessageList(),
            ),
          ),
          _buildTypingIndicator(),
          _buildMessageComposer(),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: AppTheme.primaryColor),
            const SizedBox(height: 16),
            Text(
              'Loading your financial tea...',
              style: TextStyle(color: AppTheme.secondaryTextColor),
            ),
          ],
        ),
      );
    }
    
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        return FadeTransition(
          opacity: _messages[index].animationController,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.0, 0.5),
              end: Offset.zero,
            ).animate(CurvedAnimation(
              parent: _messages[index].animationController,
              curve: Curves.easeOut,
            )),
            child: _messages[index],
          ),
        );
      },
    );
  }

  Widget _buildTypingIndicator() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: _isTyping ? 40.0 : 0.0,
      color: Colors.transparent,
      child: _isTyping
          ? Padding(
              padding: const EdgeInsets.only(left: 22.0),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        const SizedBox(width: 4),
                        _buildPulsingDot(0),
                        _buildPulsingDot(300),
                        _buildPulsingDot(600),
                        const SizedBox(width: 4),
                      ],
                    ),
                  ),
                ],
              ),
            )
          : null,
    );
  }

  Widget _buildPulsingDot(int delay) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0.0, end: 1.0),
        duration: const Duration(milliseconds: 1000),
        curve: Curves.easeInOut,
        builder: (context, value, child) {
          return Transform.scale(
            scale: 0.5 + 0.5 * (value < 0.5 ? value * 2 : (1.0 - value) * 2),
            child: Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: AppTheme.primaryColor,
                shape: BoxShape.circle,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMessageComposer() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, -2),
            blurRadius: 6,
            color: Colors.black.withOpacity(0.05),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(24.0),
                ),
                child: TextField(
                  controller: _messageController,
                  decoration: const InputDecoration(
                    hintText: 'Ask about your money moves...',
                    border: InputBorder.none,
                    fillColor: Colors.transparent,
                    hintStyle: TextStyle(color: AppTheme.secondaryTextColor),
                  ),
                  onSubmitted: _handleSubmitted,
                  textInputAction: TextInputAction.send,
                ),
              ),
            ),
            const SizedBox(width: 8.0),
            Container(
              decoration: BoxDecoration(
                color: AppTheme.primaryColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: IconButton(
                icon: const Icon(Icons.send_rounded, color: Colors.white),
                onPressed: () => _handleSubmitted(_messageController.text),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showClearChatDialog() {
    // Log dialog open event
    _analyticsService.logEvent(
      name: 'clear_chat_dialog_open',
      parameters: {
        'message_count': _messages.length,
      },
    );
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Chat History'),
        content: const Text(
          'This will delete all your conversation history with CashGuru. This action cannot be undone. Are you sure?',
        ),
        actions: [
          TextButton(
            onPressed: () {
              // Log dialog cancel
              _analyticsService.logEvent(
                name: 'clear_chat_dialog_cancel',
              );
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              // Log chat history cleared
              _analyticsService.logEvent(
                name: 'clear_chat_history',
                parameters: {
                  'message_count': _messages.length,
                },
              );
              
              // Close the dialog
              Navigator.pop(context);
              
              // Show loading indicator
              setState(() {
                _isLoading = true;
              });
              
              // Clear chat history from storage
              await _storageService.clearChatHistory();
              
              // Clear messages from state
              setState(() {
                for (var message in _messages) {
                  message.animationController.dispose();
                }
                _messages.clear();
              });
              
              // Add greeting message again
              _addBotMessage(
                'Hey bestie! 👋 I\'m CashGuru, your money bestie. Ask me anything about your finances, budgeting, or how to stack that cash! No cap, I\'m here to help your wallet thrive.',
                saveToStorage: true
              );
              
              setState(() {
                _isLoading = false;
              });
              
              // Show confirmation
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Chat history cleared!'),
                  backgroundColor: AppTheme.primaryColor,
                  duration: Duration(seconds: 2),
                ),
              );
            },
            child: const Text('Clear History', style: TextStyle(color: Colors.red)),
          ),
        ],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('About CashGuru'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'CashGuru is your Gen Z financial bestie! 👋',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 12),
            Text(
              'Try asking about:',
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            _buildSuggestionItem('How to budget like a pro?'),
            _buildSuggestionItem('Should I invest in crypto?'),
            _buildSuggestionItem('How to save for a new phone?'),
            _buildSuggestionItem('What\'s a credit score and why care?'),
            _buildSuggestionItem('Side hustle ideas?'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it!'),
          ),
        ],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  Widget _buildSuggestionItem(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Icon(
            Icons.chat_bubble_outline,
            size: 16,
            color: AppTheme.primaryColor,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text),
          ),
        ],
      ),
    );
  }
}

class ChatMessage extends StatelessWidget {
  final String text;
  final bool isUser;
  final AnimationController animationController;

  const ChatMessage({
    Key? key,
    required this.text,
    required this.isUser,
    required this.animationController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) _buildAvatar(),
          const SizedBox(width: 8),
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              decoration: BoxDecoration(
                color: isUser ? AppTheme.primaryColor : Colors.white,
                borderRadius: BorderRadius.circular(20).copyWith(
                  bottomLeft: isUser ? const Radius.circular(20) : const Radius.circular(0),
                  bottomRight: !isUser ? const Radius.circular(20) : const Radius.circular(0),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                text,
                style: TextStyle(
                  color: isUser ? Colors.white : AppTheme.primaryTextColor,
                  height: 1.4,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          if (isUser) _buildUserAvatar(),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(0.1),
        shape: BoxShape.circle,
        border: Border.all(color: AppTheme.primaryColor, width: 1.5),
      ),
      child: const Center(
        child: Text(
          '🤑',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }

  Widget _buildUserAvatar() {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: AppTheme.secondaryColor.withOpacity(0.1),
        shape: BoxShape.circle,
        border: Border.all(color: AppTheme.secondaryColor, width: 1.5),
      ),
      child: const Center(
        child: Text(
          '😎',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }

  @override
  void dispose() {
    animationController.dispose();
  }
}