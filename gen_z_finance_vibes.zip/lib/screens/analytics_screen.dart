import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../theme/theme.dart';
import '../services/ai_service.dart';
import '../main.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({Key? key}) : super(key: key);

  @override
  _AnalyticsScreenState createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final AIService _aiService = AIService();
  String _aiInsight = "Loading your financial tea...";
  bool _isLoadingInsight = true;
  Map<String, double> _budget = {};
  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _savingsGoalController = TextEditingController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _animationController.forward();
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _incomeController.dispose();
    _savingsGoalController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final provider = Provider.of<TransactionsProvider>(context, listen: false);
    final transactions = provider.transactions;
    _budget = provider.budget;
    
    // Set the income controller value
    final income = provider.income;
    _incomeController.text = income > 0 ? income.toString() : '';
    
    // Set the savings goal controller value
    final savingsGoal = provider.savingsGoal;
    _savingsGoalController.text = savingsGoal > 0 ? savingsGoal.toString() : '';

    // Get AI insights if there are transactions
    if (transactions.isNotEmpty) {
      setState(() {
        _isLoadingInsight = true;
      });
      
      try {
        // Convert transactions to a list of maps
        final transactionsForAI = transactions.map((tx) => {
          'amount': tx.amount,
          'category': tx.category,
          'date': tx.formattedDate,
          'description': tx.description,
          'isExpense': tx.isExpense,
        }).toList();
        
        final insight = await _aiService.analyzeSpending(transactionsForAI);
        
        setState(() {
          _aiInsight = insight;
          _isLoadingInsight = false;
        });
      } catch (e) {
        setState(() {
          _aiInsight = "Oof, couldn't read your financial vibe right now. Try again later! 😬";
          _isLoadingInsight = false;
        });
      }
    } else {
      setState(() {
        _aiInsight = "No transactions yet, bestie! Add some to get the financial tea. ✨";
        _isLoadingInsight = false;
      });
    }
  }

  Future<void> _generateBudget() async {
    final provider = Provider.of<TransactionsProvider>(context, listen: false);
    final incomeText = _incomeController.text;
    
    if (incomeText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter your income first, bestie! 💸'),
          backgroundColor: AppTheme.primaryColor,
        ),
      );
      return;
    }
    
    final income = double.parse(incomeText);
    provider.setIncome(income);
    
    // Set savings goal if provided
    final savingsGoalText = _savingsGoalController.text;
    if (savingsGoalText.isNotEmpty) {
      final savingsGoal = double.parse(savingsGoalText);
      provider.setSavingsGoal(savingsGoal);
    }
    
    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(color: AppTheme.primaryColor),
      ),
    );
    
    try {
      // Generate budget with AI
      final generatedBudget = await _aiService.generateBudget(
        income,
        ['Food', 'Shopping', 'Transportation', 'Entertainment', 'Bills', 'Savings'],
      );
      
      // Update the budget in the provider
      if (!generatedBudget.containsKey('error')) {
        final Map<String, double> budget = {};
        generatedBudget.forEach((key, value) {
          budget[key] = (value is int) ? value.toDouble() : (value as double);
        });
        
        await provider.setBudget(budget);
        setState(() {
          _budget = budget;
        });
      }
      
      // Close loading dialog
      Navigator.pop(context);
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Budget is giving main character energy! 💅'),
          backgroundColor: AppTheme.primaryColor,
        ),
      );
    } catch (e) {
      // Close loading dialog
      Navigator.pop(context);
      
      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Big yikes! Could not create budget right now.'),
          backgroundColor: AppTheme.errorColor,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Vibe Check Your Coins 📊',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: AppTheme.lightTextColor,
              ),
        ),
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold),
          unselectedLabelColor: Colors.white.withOpacity(0.7),
          indicatorColor: Colors.white,
          indicatorWeight: 3,
          tabs: const [
            Tab(text: 'Insights 👀'),
            Tab(text: 'Budget 💸'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildInsightsTab(),
          _buildBudgetTab(),
        ],
      ),
    );
  }

  Widget _buildInsightsTab() {
    final provider = Provider.of<TransactionsProvider>(context);
    final transactions = provider.transactions;

    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildAIInsightCard(),
            const SizedBox(height: 24),
            _buildSpendingTrendCard(transactions),
            const SizedBox(height: 24),
            _buildTop5Spending(transactions),
            const SizedBox(height: 24),
            _buildMonthlyComparison(),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildAIInsightCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.psychology_outlined,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'CashGuru Says',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _isLoadingInsight
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Colors.white,
                  ),
                )
              : Text(
                  _aiInsight,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Colors.white,
                        height: 1.5,
                      ),
                ),
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerRight,
            child: OutlinedButton(
              onPressed: _loadData,
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: const BorderSide(color: Colors.white),
              ),
              child: const Text('Refresh Vibes'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSpendingTrendCard(List<dynamic> transactions) {
    // Filter transactions to only include expenses from the last 7 days
    final now = DateTime.now();
    final last7Days = transactions
        .where((tx) =>
            tx.isExpense &&
            tx.date.isAfter(now.subtract(const Duration(days: 7))))
        .toList();

    // Group by day
    final Map<int, double> dailySpending = {};
    for (var i = 0; i < 7; i++) {
      dailySpending[i] = 0;
    }

    for (var tx in last7Days) {
      final daysAgo = now.difference(tx.date).inDays;
      if (daysAgo < 7) {
        dailySpending[daysAgo] = (dailySpending[daysAgo] ?? 0) + tx.amount;
      }
    }

    final List<String> dayLabels = [
      'Today',
      'Yday',
      '${_getDayName(now.subtract(const Duration(days: 2)))}',
      '${_getDayName(now.subtract(const Duration(days: 3)))}',
      '${_getDayName(now.subtract(const Duration(days: 4)))}',
      '${_getDayName(now.subtract(const Duration(days: 5)))}',
      '${_getDayName(now.subtract(const Duration(days: 6)))}',
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'This Week\'s Vibe 📈',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Last 7 Days',
                  style: TextStyle(
                    color: AppTheme.primaryColor,
                    fontWeight: FontWeight.w500,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: LineChart(
              LineChartData(
                lineTouchData: LineTouchData(enabled: false),
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        int index = 6 - value.toInt();
                        return index >= 0 && index < dayLabels.length
                            ? Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  dayLabels[index],
                                  style: const TextStyle(fontSize: 10),
                                ),
                              )
                            : const Text('');
                      },
                      reservedSize: 30,
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: [
                      for (int i = 6; i >= 0; i--)
                        FlSpot(i.toDouble(), dailySpending[6 - i] ?? 0),
                    ],
                    isCurved: true,
                    color: AppTheme.primaryColor,
                    barWidth: 3,
                    isStrokeCapRound: true,
                    dotData: FlDotData(
                      show: true,
                      getDotPainter: (spot, percent, barData, index) {
                        return FlDotCirclePainter(
                          radius: 4,
                          color: AppTheme.primaryColor,
                          strokeWidth: 2,
                          strokeColor: Colors.white,
                        );
                      },
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      color: AppTheme.primaryColor.withOpacity(0.2),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getDayName(DateTime date) {
    final weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return weekdays[date.weekday - 1];
  }

  Widget _buildTop5Spending(List<dynamic> transactions) {
    // Filter to only include expenses
    final expenses = transactions.where((tx) => tx.isExpense).toList();

    // Sort by amount in descending order
    expenses.sort((a, b) => b.amount.compareTo(a.amount));

    // Take top 5 or less if there aren't 5 transactions
    final top5 = expenses.take(5).toList();

    if (top5.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: Text(
            'No transactions yet, bestie! Time to start tracking your cash. ✨',
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Top Coin Yeets 💅',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 16),
          ...top5.map((tx) => _buildTopSpendingItem(tx)).toList(),
        ],
      ),
    );
  }

  Widget _buildTopSpendingItem(dynamic transaction) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _getCategoryColor(transaction.category).withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              transaction.getCategoryIcon(),
              color: _getCategoryColor(transaction.category),
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction.description,
                  style: Theme.of(context).textTheme.titleSmall,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  '${transaction.category} • ${transaction.formattedDate}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.secondaryTextColor,
                      ),
                ),
              ],
            ),
          ),
          Text(
            '-${transaction.formattedAmount}',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
          ),
        ],
      ),
    );
  }

  Color _getCategoryColor(String category) {
    if (AppTheme.categoryColors.containsKey(category)) {
      return AppTheme.categoryColors[category]!;
    }
    return AppTheme.primaryColor;
  }

  Widget _buildMonthlyComparison() {
    final provider = Provider.of<TransactionsProvider>(context);
    final transactions = provider.transactions;
    final now = DateTime.now();
    
    // Get the last 6 months
    List<DateTime> months = [];
    for (int i = 0; i < 6; i++) {
      months.add(DateTime(now.year, now.month - i, 1));
    }
    months = months.reversed.toList(); // Sort chronologically
    
    // Initialize data for each month
    Map<String, Map<String, double>> monthlyData = {};
    for (var month in months) {
      String monthKey = '${month.year}-${month.month.toString().padLeft(2, '0')}';
      monthlyData[monthKey] = {'income': 0.0, 'expense': 0.0};
    }
    
    // Calculate monthly income and expenses
    for (var tx in transactions) {
      String monthKey = '${tx.date.year}-${tx.date.month.toString().padLeft(2, '0')}';
      if (monthlyData.containsKey(monthKey)) {
        if (tx.isExpense) {
          monthlyData[monthKey]!['expense'] = (monthlyData[monthKey]!['expense'] ?? 0) + tx.amount;
        } else {
          monthlyData[monthKey]!['income'] = (monthlyData[monthKey]!['income'] ?? 0) + tx.amount;
        }
      }
    }
    
    // Create bar groups from real data
    List<BarChartGroupData> barGroups = [];
    List<String> monthLabels = [];
    double maxAmount = 0.0;
    
    int index = 0;
    for (var month in months) {
      String monthKey = '${month.year}-${month.month.toString().padLeft(2, '0')}';
      double income = monthlyData[monthKey]?['income'] ?? 0;
      double expense = monthlyData[monthKey]?['expense'] ?? 0;
      
      // Update max amount for chart scaling
      maxAmount = [maxAmount, income, expense].reduce((curr, next) => curr > next ? curr : next);
      
      barGroups.add(_makeBarGroup(index, income, expense));
      monthLabels.add(_getMonthAbbr(month.month));
      index++;
    }
    
    // If there's no data, show placeholder
    if (transactions.isEmpty) {
      return _buildEmptyMonthlyComparison();
    }
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Monthly Glow Up 🌟',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: maxAmount * 1.2, // Add 20% padding to the top
                barTouchData: BarTouchData(
                  enabled: true,
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= 0 && value.toInt() < monthLabels.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(
                              monthLabels[value.toInt()],
                              style: const TextStyle(fontSize: 10),
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                gridData: FlGridData(show: false),
                barGroups: barGroups,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildLegendItem('Income', AppTheme.secondaryColor),
              const SizedBox(width: 24),
              _buildLegendItem('Expenses', AppTheme.primaryColor),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildEmptyMonthlyComparison() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Monthly Glow Up 🌟',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 180,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.show_chart,
                    size: 64,
                    color: AppTheme.primaryColor.withOpacity(0.3),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No transactions yet to show monthly trends!',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.secondaryTextColor,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Add some transactions to see your financial glow up.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.secondaryTextColor,
                          fontStyle: FontStyle.italic,
                        ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  String _getMonthAbbr(int month) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return months[month - 1];
  }

  BarChartGroupData _makeBarGroup(int x, double income, double expense) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          toY: income,
          color: AppTheme.secondaryColor,
          width: 12,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(6),
            topRight: Radius.circular(6),
          ),
        ),
        BarChartRodData(
          toY: expense,
          color: AppTheme.primaryColor,
          width: 12,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(6),
            topRight: Radius.circular(6),
          ),
        ),
      ],
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _buildBudgetTab() {
    final provider = Provider.of<TransactionsProvider>(context);
    final income = provider.income;
    final savingsGoal = provider.savingsGoal;

    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBudgetInputCard(income, savingsGoal),
            const SizedBox(height: 24),
            _buildBudgetBreakdownCard(),
            const SizedBox(height: 24),
            _buildSavingsGoalCard(savingsGoal),
          ],
        ),
      ),
    );
  }

  Widget _buildBudgetInputCard(double currentIncome, double savingsGoal) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Secure The Bag 💰',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Monthly Cheddar (Income) 💵',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _incomeController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.attach_money, color: AppTheme.primaryColor),
                  hintText: 'How much do you make?',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Savings Goal 🎯',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _savingsGoalController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.savings_outlined, color: AppTheme.primaryColor),
                  hintText: 'How much you tryna save?',
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _generateBudget,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text(
                'Generate Budget Vibe',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBudgetBreakdownCard() {
    if (_budget.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Budget Breakdown 📝',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 20),
            Center(
              child: Column(
                children: [
                  const Icon(
                    Icons.account_balance_wallet_outlined,
                    size: 60,
                    color: AppTheme.secondaryColor,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No budget yet, bestie!',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Enter your income and hit Generate Budget Vibe to get started.',
                    style: Theme.of(context).textTheme.bodyMedium,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Budget Breakdown 📝',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          // Budget pie chart
          SizedBox(
            height: 200,
            child: PieChart(
              PieChartData(
                sectionsSpace: 2,
                centerSpaceRadius: 40,
                sections: _getBudgetSections(),
                pieTouchData: PieTouchData(
                  touchCallback: (event, response) {},
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          // Budget categories list
          ..._budget.entries.map((entry) => _buildBudgetItem(entry.key, entry.value)).toList(),
        ],
      ),
    );
  }

  List<PieChartSectionData> _getBudgetSections() {
    final List<PieChartSectionData> sections = [];
    final List<Color> colors = [
      AppTheme.primaryColor,
      AppTheme.secondaryColor,
      Colors.orangeAccent,
      Colors.purpleAccent,
      Colors.blueAccent,
      Colors.pinkAccent,
      Colors.tealAccent,
    ];

    int colorIndex = 0;
    _budget.forEach((category, amount) {
      sections.add(
        PieChartSectionData(
          value: amount,
          title: '${(amount / _budget.values.reduce((a, b) => a + b) * 100).toStringAsFixed(0)}%',
          radius: 80,
          titleStyle: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
          color: colors[colorIndex % colors.length],
        ),
      );
      colorIndex++;
    });

    return sections;
  }

  Widget _buildBudgetItem(String category, double amount) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: _getCategoryColorForBudget(category),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              category,
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
          Text(
            '\$${amount.toStringAsFixed(2)}',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
        ],
      ),
    );
  }

  Color _getCategoryColorForBudget(String category) {
    final List<Color> colors = [
      AppTheme.primaryColor,
      AppTheme.secondaryColor,
      Colors.orangeAccent,
      Colors.purpleAccent,
      Colors.blueAccent,
      Colors.pinkAccent,
      Colors.tealAccent,
    ];

    final categories = _budget.keys.toList();
    final index = categories.indexOf(category);
    return colors[index % colors.length];
  }

  Widget _buildSavingsGoalCard(double savingsGoal) {
    if (savingsGoal <= 0) {
      return const SizedBox.shrink();
    }

    // Calculate current savings and progress
    final provider = Provider.of<TransactionsProvider>(context);
    final transactions = provider.transactions;
    final now = DateTime.now();
    final thisMonthSavings = transactions.where((tx) =>
        !tx.isExpense &&
        tx.category == 'Savings' &&
        tx.date.month == now.month &&
        tx.date.year == now.year);

    double currentSavings = 0;
    for (var tx in thisMonthSavings) {
      currentSavings += tx.amount;
    }

    final progress = savingsGoal > 0 ? (currentSavings / savingsGoal) : 0.0;
    final cappedProgress = progress > 1.0 ? 1.0 : progress;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Savings Goal 🏆',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Current: \$${currentSavings.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Goal: \$${savingsGoal.toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
              Text(
                '${(cappedProgress * 100).toStringAsFixed(0)}%',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Stack(
            children: [
              Container(
                height: 12,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              FractionallySizedBox(
                widthFactor: cappedProgress,
                child: Container(
                  height: 12,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            cappedProgress >= 1.0
                ? 'Slayyy! You hit your savings goal! 💅'
                : 'Keep stacking that coin, bestie! 🔥',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontStyle: FontStyle.italic,
                ),
          ),
        ],
      ),
    );
  }
}