import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/theme.dart';
import 'dart:math';

class BillSplitScreen extends StatefulWidget {
  const BillSplitScreen({Key? key}) : super(key: key);

  @override
  _BillSplitScreenState createState() => _BillSplitScreenState();
}

class _BillSplitScreenState extends State<BillSplitScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _friendsController = TextEditingController(text: '2');
  int _numFriends = 2;
  double _totalAmount = 0;
  double _perPersonAmount = 0;
  List<String> _friendNames = [];
  List<bool> _friendPaid = [];
  final List<TextEditingController> _nameControllers = [];
  bool _showResult = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _animationController.forward();
    _updateFriendsList();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    _friendsController.dispose();
    for (var controller in _nameControllers) {
      controller.dispose();
    }
    _animationController.dispose();
    super.dispose();
  }

  void _updateFriendsList() {
    setState(() {
      try {
        _numFriends = max(1, int.parse(_friendsController.text));
      } catch (e) {
        _numFriends = 2; // Default to 2 if parsing fails
      }
      
      // Add more name controllers if needed
      while (_nameControllers.length < _numFriends) {
        _nameControllers.add(TextEditingController(
          text: 'Bestie ${_nameControllers.length + 1}',
        ));
      }

      // Remove extra controllers if number was decreased
      if (_nameControllers.length > _numFriends) {
        for (int i = _nameControllers.length - 1; i >= _numFriends; i--) {
          _nameControllers[i].dispose();
          _nameControllers.removeAt(i);
        }
      }
    });
  }

  void _calculateSplit() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _totalAmount = double.parse(_amountController.text);
        _perPersonAmount = _totalAmount / (_numFriends + 1); // +1 for yourself
        _friendNames = _nameControllers.map((controller) => controller.text).toList();
        _friendPaid = List.filled(_numFriends, false);
        _showResult = true;
      });
    }
  }

  void _resetForm() {
    setState(() {
      _showResult = false;
      _amountController.clear();
      _descriptionController.clear();
    });
  }

  String _getRandomEmojiForPerson(int index) {
    final emojis = ['😎', '🤩', '🥳', '😊', '🤪', '😇', '🤓', '😍'];
    return emojis[index % emojis.length];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Split The Bag 💸',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: AppTheme.lightTextColor,
              ),
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: _showResult ? _buildResultView() : _buildInputForm(),
        ),
      ),
    );
  }

  Widget _buildInputForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Bill Tea 📝',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 24),
          // Amount input
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'How much coin? 💰',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  prefixIcon: const Icon(
                    Icons.attach_money,
                    color: AppTheme.primaryColor,
                  ),
                  hintText: '0.00',
                ),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                ],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Drop the digits, bestie!';
                  }
                  if (double.tryParse(value) == null) {
                    return "That's not giving valid amount vibes";
                  }
                  if (double.parse(value) <= 0) {
                    return "Need an amount that's a vibe (> 0)";
                  }
                  return null;
                },
              ),
            ],
          ),
          const SizedBox(height: 20),
          // Description input
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "What's the vibe? 🍕",
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  prefixIcon: Icon(
                    Icons.description_outlined,
                    color: AppTheme.primaryColor,
                  ),
                  hintText: 'Brunch, movie night, whatever slaps...',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Spill the tea on what this was for';
                  }
                  return null;
                },
              ),
            ],
          ),
          const SizedBox(height: 20),
          // Number of friends input
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'How many besties? 👯',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _friendsController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(
                          Icons.people_outline,
                          color: AppTheme.primaryColor,
                        ),
                        hintText: 'Squad size',
                      ),
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                      ],
                      onChanged: (value) {
                        _updateFriendsList();
                      },
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Need your bestie count!';
                        }
                        if (int.tryParse(value) == null) {
                          return "That's not a vibe, enter a real number";
                        }
                        if (int.parse(value) < 1) {
                          return 'Need at least 1 bestie to split with';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 16),
                  Container(
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.remove, color: Colors.white),
                      onPressed: () {
                        if (_numFriends > 1) {
                          _friendsController.text = (_numFriends - 1).toString();
                          _updateFriendsList();
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.add, color: Colors.white),
                      onPressed: () {
                        _friendsController.text = (_numFriends + 1).toString();
                        _updateFriendsList();
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 24),
          // Friend names input
          Text(
            "Who's in the squad?",
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 16),
          ...List.generate(_numFriends, (index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12.0),
              child: TextFormField(
                controller: _nameControllers[index],
                decoration: InputDecoration(
                  prefixIcon: Text(
                    _getRandomEmojiForPerson(index),
                    style: const TextStyle(fontSize: 24),
                    textAlign: TextAlign.center,
                  ),
                  hintText: 'Bestie ${index + 1}',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Add your bestie's name";
                  }
                  return null;
                },
              ),
            );
          }),
          const SizedBox(height: 32),
          // Calculate button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _calculateSplit,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.calculate_outlined),
                  SizedBox(width: 8),
                  Text(
                    'Split The Bag',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'The Vibe Check',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            IconButton(
              icon: const Icon(Icons.refresh, color: AppTheme.primaryColor),
              onPressed: _resetForm,
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                _descriptionController.text,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                '${_totalAmount.toStringAsFixed(2)}',
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  'Each bestie drops: ${_perPersonAmount.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                      ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        Text(
          "Who's Paid The Vibes?",
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 16),
        // Your card
        _buildPersonCard('You', 0, null),
        const SizedBox(height: 16),
        // Friends list
        ...List.generate(_numFriends, (index) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: _buildPersonCard(_friendNames[index], index + 1, index),
          );
        }),
        const SizedBox(height: 32),
        // Share button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.share, color: Colors.white),
            label: const Text(
              'Tell The Squad',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Spilling the tea to ${_friendNames.join(", ")}! 💅'),
                  backgroundColor: AppTheme.primaryColor,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            icon: const Icon(Icons.payment, color: AppTheme.primaryColor),
            label: const Text(
              'Everyone Ate and Paid',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: () {
              setState(() {
                for (int i = 0; i < _friendPaid.length; i++) {
                  _friendPaid[i] = true;
                }
              });
              
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("The squad came through! No one's on the struggle bus! 💯"),
                  backgroundColor: AppTheme.primaryColor,
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildPersonCard(String name, int displayIndex, int? index) {
    final bool isPaid = index != null ? _friendPaid[index] : true;
    final emoji = displayIndex == 0 ? '😎' : _getRandomEmojiForPerson(displayIndex);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                emoji,
                style: const TextStyle(fontSize: 20),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Text(
                  '${_perPersonAmount.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.secondaryTextColor,
                      ),
                ),
              ],
            ),
          ),
          if (index != null)
            Switch(
              value: isPaid,
              activeColor: AppTheme.primaryColor,
              onChanged: (bool value) {
                setState(() {
                  _friendPaid[index] = value;
                });
              },
            )
          else
            const Chip(
              label: Text('You'),
              backgroundColor: AppTheme.primaryColor,
              labelStyle: TextStyle(color: Colors.white),
            ),
        ],
      ),
    );
  }
}