import 'package:dreamflow/suspension_bridge/analytics_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'theme/theme.dart';
import 'services/storage_service.dart';
import 'services/analytics_service.dart';
import 'firebase_options.dart';
import 'screens/dashboard_screen.dart';
import 'screens/expense_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/bill_split_screen.dart';
import 'screens/challenges_screen.dart';
import 'screens/dark_mode_theme_screen.dart';
import 'screens/subscription_tracker_screen.dart';
import 'screens/more_screen.dart';
import 'screens/onboarding_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
// import 'package:awesome_app/pages/home_page/home_page_widget.dart';

// Provider for transaction data
class TransactionsProvider extends ChangeNotifier {
  final StorageService _storageService = StorageService();
  final AnalyticsService _analyticsService = AnalyticsService();
  List<dynamic> _transactions = [];
  Map<String, double> _budget = {};
  double _income = 0.0;
  double _savingsGoal = 0.0;
  String _username = 'bestie';

  List<dynamic> get transactions => _transactions;
  Map<String, double> get budget => _budget;
  double get income => _income;
  double get savingsGoal => _savingsGoal;
  String get username => _username;

  TransactionsProvider() {
    _loadData();
  }

  Future<void> _loadData() async {
    _transactions = await _storageService.loadTransactions();
    _budget = await _storageService.loadBudget();
    _income = await _storageService.loadIncome();
    _savingsGoal = await _storageService.loadSavingsGoal();
    _username = await _storageService.loadUsername();

    // Log user profile data to Analytics
    _analyticsService.setUserProperty(
      name: 'has_transactions',
      value: _transactions.isNotEmpty ? 'true' : 'false',
    );

    _analyticsService.setUserProperty(
      name: 'has_budget',
      value: _budget.isNotEmpty ? 'true' : 'false',
    );

    _analyticsService.setUserProperty(
      name: 'has_income',
      value: _income > 0 ? 'true' : 'false',
    );

    _analyticsService.setUserProperty(
      name: 'has_savings_goal',
      value: _savingsGoal > 0 ? 'true' : 'false',
    );

    notifyListeners();
  }

  // Add transaction
  Future<void> addTransaction(dynamic transaction) async {
    await _storageService.addTransaction(transaction);

    // Log transaction event to Analytics
    _analyticsService.logFinancialAction(
      action: 'add_transaction',
      details: {
        'category': transaction.category,
        'amount': transaction.amount,
        'is_expense': transaction.isExpense,
        'date': transaction.date.toString(),
      },
    );

    // Also log as a transaction event
    _analyticsService.logTransaction(
      id: transaction.id,
      value: transaction.amount,
      currency: 'USD',
      category: transaction.category,
      isExpense: transaction.isExpense,
    );

    await _loadData(); // Reload data
  }

  // Delete transaction
  Future<void> deleteTransaction(String id) async {
    // Get the transaction before deleting it for analytics
    final transaction =
        _transactions.firstWhere((t) => t.id == id, orElse: () => null);

    await _storageService.deleteTransaction(id);

    if (transaction != null) {
      // Log deletion event to Analytics
      _analyticsService.logFinancialAction(
        action: 'delete_transaction',
        details: {
          'transaction_id': id,
          'category': transaction.category,
          'amount': transaction.amount,
        },
      );
    }

    await _loadData(); // Reload data
  }

  // Update transaction
  Future<void> updateTransaction(dynamic transaction) async {
    await _storageService.updateTransaction(transaction);

    // Log update event to Analytics
    _analyticsService.logFinancialAction(
      action: 'update_transaction',
      details: {
        'transaction_id': transaction.id,
        'category': transaction.category,
        'amount': transaction.amount,
        'is_expense': transaction.isExpense,
      },
    );

    await _loadData(); // Reload data
  }

  // Set budget
  Future<void> setBudget(Map<String, double> newBudget) async {
    await _storageService.saveBudget(newBudget);
    _budget = newBudget;

    // Log budget creation/update to Analytics
    _analyticsService.logFinancialAction(
      action: 'set_budget',
      details: {
        'budget_size': newBudget.length,
        'budget_total':
            newBudget.values.fold<double>(0.0, (sum, amount) => sum + amount),
        'categories': newBudget.keys.join(','),
      },
    );

    notifyListeners();
  }

  // Set income
  Future<void> setIncome(double newIncome) async {
    await _storageService.saveIncome(newIncome);
    _income = newIncome;

    // Log income setting to Analytics
    _analyticsService.logFinancialAction(
      action: 'set_income',
      details: {
        'income_amount': newIncome,
      },
    );

    notifyListeners();
  }

  // Set savings goal
  Future<void> setSavingsGoal(double goal) async {
    await _storageService.saveSavingsGoal(goal);
    _savingsGoal = goal;

    // Log savings goal setting to Analytics
    _analyticsService.logFinancialAction(
      action: 'set_savings_goal',
      details: {
        'goal_amount': goal,
      },
    );

    notifyListeners();
  }

  // Set username
  Future<void> setUsername(String name) async {
    await _storageService.saveUsername(name);
    _username = name;

    // Log username change to Analytics
    _analyticsService.logEvent(
      name: 'set_username',
      parameters: {
        'has_custom_name': name != 'bestie',
      },
    );

    notifyListeners();
  }

  // Get financial summary for dashboard
  Future<Map<String, dynamic>> getFinancialSummary() async {
    final summary = await _storageService.getTransactionsSummary();

    // Log dashboard view with summary data
    _analyticsService.logEvent(
      name: 'view_financial_summary',
      parameters: {
        'total_income': summary['totalIncome'],
        'total_expenses': summary['totalExpenses'],
        'balance': summary['balance'],
        'category_count':
            (summary['spendingByCategory'] as Map<String, dynamic>).length,
      },
    );

    return summary;
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SharedPreferences.getInstance(); // Initialize shared preferences
  ExternalAnalyticsService();
  // Initialize Firebase
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    // Initialize Analytics Service
    final analyticsService = AnalyticsService();
    await analyticsService.init();
  } catch (e) {
    debugPrint('Firebase initialization failed: $e');
  }

  // Check if onboarding is completed
  final storageService = StorageService();
  final bool onboardingCompleted = await storageService.isOnboardingCompleted();

  runApp(MyApp(onboardingCompleted: onboardingCompleted));
}

class MyApp extends StatelessWidget {
  final bool onboardingCompleted;

  const MyApp({Key? key, this.onboardingCompleted = false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get the analytics service for navigation tracking
    final analyticsService = AnalyticsService();
    return ChangeNotifierProvider(
      create: (context) => TransactionsProvider(),
      child: MaterialApp(
        title: 'CashGuru | Financial Vibe Check',
        theme: AppTheme.lightTheme(),
        home:
            onboardingCompleted ? const MainScreen() : const OnboardingScreen(),
        debugShowCheckedModeBanner: false,
        navigatorObservers: [
          // Add Firebase Analytics observer to track screen views
          analyticsService.observer,
        ],
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  final AnalyticsService _analyticsService = AnalyticsService();

  final List<Widget> _screens = [
    const DashboardScreen(),
    const ExpenseScreen(),
    const AnalyticsScreen(),
    const ChatScreen(),
    const MoreScreen(),
  ];

  final List<String> _screenNames = [
    'Dashboard_Home',
    'Add_Expense',
    'Financial_Analytics',
    'AI_Chat_Assistant',
    'More_Options',
  ];

  @override
  void initState() {
    super.initState();
    // Log initial screen view
    _logCurrentScreenView();
  }

  void _logCurrentScreenView() {
    _analyticsService.logScreenView(
      screenName: _screenNames[_selectedIndex],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      floatingActionButton: FloatingActionButton(onPressed: () {
        // Navigator.of(context).pushReplacement(
        //   MaterialPageRoute(builder: (context) => const HomePageWidget()),
        // );
      }),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });

          // Log screen change with Analytics
          _analyticsService.logEvent(
            name: 'tab_change',
            parameters: {
              'from_tab': _screenNames[_selectedIndex],
              'to_tab': _screenNames[index],
              'tab_index': index,
            },
          );

          // Log screen view
          _analyticsService.logScreenView(
            screenName: _screenNames[index],
          );
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Vibe',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            activeIcon: Icon(Icons.add_circle),
            label: 'Add Coin',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.show_chart),
            activeIcon: Icon(Icons.candlestick_chart),
            label: 'Stonks',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_bubble_outline),
            activeIcon: Icon(Icons.chat_bubble),
            label: 'Money Tea',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu_outlined),
            activeIcon: Icon(Icons.menu),
            label: 'More',
          ),
        ],
      ),
    );
  }
}
