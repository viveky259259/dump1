import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Primary colors - based on green palette for GenZ financial app
  static const Color primaryColor = Color(0xFF00BF63); // Vibrant green
  static const Color secondaryColor = Color(0xFF17D7A0); // Teal accent
  static const Color accentColor = Color(0xFF00F5A0); // Neon green
  static const Color backgroundColor = Color(0xFFF2FFF5); // Light mint background
  static const Color darkBackgroundColor = Color(0xFF022C1A); // Dark green background
  
  // Text colors
  static const Color primaryTextColor = Color(0xFF1E1E1E);
  static const Color secondaryTextColor = Color(0xFF686868);
  static const Color lightTextColor = Color(0xFFF2FFF5);
  
  // Additional UI colors
  static const Color successColor = Color(0xFF00E676);
  static const Color errorColor = Color(0xFFFF5252);
  static const Color warningColor = Color(0xFFFFD600);
  static const Color cardColor = Color(0xFFFFFFFF);
  static const Color dividerColor = Color(0xFFE0E0E0);
  
  // Category colors for spending
  static const Map<String, Color> categoryColors = {
    'Food': Color(0xFF00BF63),
    'Shopping': Color(0xFFFF9E80),
    'Transportation': Color(0xFF80D8FF),
    'Entertainment': Color(0xFFEA80FC),
    'Bills': Color(0xFFFFD180),
    'Other': Color(0xFF8C9EFF),
  };
  
  static ThemeData lightTheme() {
    return ThemeData(
      primaryColor: primaryColor,
      scaffoldBackgroundColor: backgroundColor,
      colorScheme: ColorScheme.light(
        primary: primaryColor,
        secondary: secondaryColor,
        background: backgroundColor,
        error: errorColor,
        surface: cardColor,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: primaryColor,
        foregroundColor: lightTextColor,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: cardColor,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      textTheme: GoogleFonts.poppinsTextTheme().copyWith(
        displayLarge: GoogleFonts.poppins(
          fontSize: 26, 
          fontWeight: FontWeight.bold, 
          color: primaryTextColor,
        ),
        displayMedium: GoogleFonts.poppins(
          fontSize: 22, 
          fontWeight: FontWeight.bold, 
          color: primaryTextColor,
        ),
        titleLarge: GoogleFonts.poppins(
          fontSize: 20, 
          fontWeight: FontWeight.w600, 
          color: primaryTextColor,
        ),
        titleMedium: GoogleFonts.poppins(
          fontSize: 16, 
          fontWeight: FontWeight.w600, 
          color: primaryTextColor,
        ),
        bodyLarge: GoogleFonts.poppins(
          fontSize: 16, 
          color: primaryTextColor,
        ),
        bodyMedium: GoogleFonts.poppins(
          fontSize: 14, 
          color: secondaryTextColor,
        ),
        labelLarge: GoogleFonts.poppins(
          fontSize: 14, 
          fontWeight: FontWeight.w500, 
          color: primaryColor,
        ),
      ),
      iconTheme: const IconThemeData(
        color: primaryColor,
        size: 24,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryColor,
          side: const BorderSide(color: primaryColor, width: 2),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primaryColor,
          textStyle: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        fillColor: Colors.white,
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primaryColor, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        hintStyle: GoogleFonts.poppins(
          fontSize: 14,
          color: secondaryTextColor.withOpacity(0.5),
        ),
      ),
      dividerTheme: const DividerThemeData(
        color: dividerColor,
        thickness: 1,
        space: 24,
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: primaryColor,
        unselectedItemColor: secondaryTextColor,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
      ),
    );
  }
  
  // GenZ Financial Slangs & Phrases for the app
  static const Map<String, String> genzSlangs = {
    'save': 'stack that cash',
    'money': 'cheddar',
    'expensive': 'boujee',
    'broke': 'down bad',
    'rich': 'ballin',
    'budget': 'vibe check your cash',
    'investment': 'future bag',
    'paycheck': 'the bag',
    'bank account': 'coin stash',
    'credit score': 'financial drip',
    'debt': 'financial tea',
    'spend': 'yeet your cash',
    'good deal': 'bussin deal',
    'bad investment': 'sus move',
    'great': 'fire',
    'awesome': 'slaps',
    'excited': 'hype',
    'cool': 'lit',
    'difficult': 'struggle bus',
    'easy': 'ez',
  };
  
  // Message templates using GenZ slang
  static String getRandomSuccessMessage() {
    final messages = [
      "You're slaying your financial goals!",
      "Big W on your money moves!",
      "No cap, your finances are looking fire!",
      "Secured the bag this month!",
      "Your budget game is straight bussin!",
      "Living for this financial growth!",
    ];
    return messages[DateTime.now().microsecond % messages.length];
  }
  
  static String getRandomSavingTip() {
    final tips = [
      "Lowkey, making coffee at home is a money hack!",
      "Vibe check before impulse buying, bestie!",
      "Meal prep = more cheddar in your wallet, no cap!",
      "That subscription? It's giving unnecessary expense.",
      "Side hustle era is the move for extra coins!",
      "Thrift fits hit different AND save that cash!",
    ];
    return tips[DateTime.now().microsecond % tips.length];
  }
}