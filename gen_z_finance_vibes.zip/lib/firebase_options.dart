import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // NOTE: Replace the placeholders below with your actual Firebase configuration
  // You can obtain these by running the FlutterFire CLI

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAjeCFa4tH02U22N57CUMSu8D72CrQgzz8',
    appId: '1:207596404714:web:908950ad2a9de80d983c93',
    messagingSenderId: '207596404714',
    projectId: 'genz-money',
    authDomain: 'genz-money.firebaseapp.com',
    storageBucket: 'genz-money.firebasestorage.app',
    measurementId: 'G-M9HBCTXR7N',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAjeCFa4tH02U22N57CUMSu8D72CrQgzz8',
    appId: '1:2075964047142:android:908950ad2a9de80d983c93',
    messagingSenderId: '207596404714',
    projectId: 'genz-money',
    storageBucket: 'genz-money.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAjeCFa4tH02U22N57CUMSu8D72CrQgzz8',
    appId: '1:2075964047142:ios:908950ad2a9de80d983c93',
    messagingSenderId: '207596404714',
    projectId: 'genz-money',
    storageBucket: 'genz-money.firebasestorage.app',
    iosClientId:
        '123456789012-abcdef1234567890abcdef.apps.googleusercontent.com',
    iosBundleId: 'com.example.dreamflow',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyAjeCFa4tH02U22N57CUMSu8D72CrQgzz8',
    appId: '1:2075964047142:ios:908950ad2a9de80d983c93',
    messagingSenderId: '207596404714',
    projectId: 'genz-money',
    storageBucket: 'genz-money.firebasestorage.app',
    iosClientId:
        '123456789012-abcdef1234567890abcdef.apps.googleusercontent.com',
    iosBundleId: 'com.example.dreamflow',
  );
}
