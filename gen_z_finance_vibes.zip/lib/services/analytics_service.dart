import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class AnalyticsService {
  static final AnalyticsService _instance = AnalyticsService._internal();
  late final FirebaseAnalytics _analytics;
  late final FirebaseAnalyticsObserver observer;
  bool _initialized = false;

  // Singleton pattern
  factory AnalyticsService() => _instance;

  AnalyticsService._internal();

  Future<void> init() async {
    if (_initialized) return;
    
    try {
      await Firebase.initializeApp();
      _analytics = FirebaseAnalytics.instance;
      observer = FirebaseAnalyticsObserver(analytics: _analytics);
      _initialized = true;
      
      // Enable analytics collection
      await _analytics.setAnalyticsCollectionEnabled(true);
      
      if (kDebugMode) {
        print('Firebase Analytics initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to initialize Firebase Analytics: $e');
      }
      _initialized = false;
    }
  }

  // Log page views
  Future<void> logScreenView({required String screenName, String? screenClass}) async {
    if (!_initialized) return;

    try {
      await _analytics.logScreenView(
        screenName: screenName,
        screenClass: screenClass ?? 'Flutter',
      );
      if (kDebugMode) {
        print('Logged screen view: $screenName');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to log screen view: $e');
      }
    }
  }

  // Log custom events
  Future<void> logEvent({
    required String name,
    Map<String, Object>? parameters,
  }) async {
    if (!_initialized) return;

    try {
      await _analytics.logEvent(
        name: name,
        parameters: parameters,
      );
      if (kDebugMode) {
        print('Logged event: $name with params: $parameters');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to log event: $e');
      }
    }
  }

  // Log financial transactions
  Future<void> logTransaction({
    required String id,
    required double value,
    required String currency,
    String? category,
    bool? isExpense,
  }) async {
    if (!_initialized) return;

    try {
      await _analytics.logPurchase(
        currency: currency,
        value: value,
        transactionId: id,
        items: [],
        coupon: category,
        shipping: isExpense == true ? 1.0 : 0.0,
      );
      if (kDebugMode) {
        print('Logged transaction: $id, value: $value');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to log transaction: $e');
      }
    }
  }

  // Log user properties
  Future<void> setUserProperty({
    required String name,
    required String? value,
  }) async {
    if (!_initialized) return;

    try {
      await _analytics.setUserProperty(
        name: name,
        value: value,
      );
      if (kDebugMode) {
        print('Set user property: $name=$value');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to set user property: $e');
      }
    }
  }

  // Log financial events related to GenZ app
  Future<void> logFinancialAction({
    required String action,
    required Map<String, Object> details,
  }) async {
    if (!_initialized) return;

    try {
      await _analytics.logEvent(
        name: 'financial_action',
        parameters: {
          'action_type': action,
          ...details,
        },
      );
      if (kDebugMode) {
        print('Logged financial action: $action with details: $details');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to log financial action: $e');
      }
    }
  }

  // Log usage of AI features
  Future<void> logAIInteraction({
    required String feature,
    Map<String, Object>? details,
  }) async {
    if (!_initialized) return;

    try {
      await _analytics.logEvent(
        name: 'ai_interaction',
        parameters: {
          'feature': feature,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          ...?details,
        },
      );
      if (kDebugMode) {
        print('Logged AI interaction: $feature');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to log AI interaction: $e');
      }
    }
  }
  
  // Log app errors
  Future<void> logError({
    required String error,
    StackTrace? stackTrace,
  }) async {
    if (!_initialized) return;

    try {
      await _analytics.logEvent(
        name: 'app_error',
        parameters: {
          'error_description': error,
          'stack_trace': stackTrace?.toString() ?? 'Not available',
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        },
      );
      if (kDebugMode) {
        print('Logged error: $error');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Failed to log error: $e');
      }
    }
  }
}