import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/transaction.dart';

class StorageService {
  static const String _transactionsKey = 'transactions';
  static const String _userBudgetKey = 'user_budget';
  static const String _userIncomeKey = 'user_income';
  static const String _goalKey = 'savings_goal';
  static const String _usernameKey = 'username';
  static const String _chatMessagesKey = 'chat_messages';
  static const String _onboardingCompletedKey = 'onboarding_completed';
  
  // Save transactions to local storage
  Future<void> saveTransactions(List<Transaction> transactions) async {
    final prefs = await SharedPreferences.getInstance();
    final transactionsJson = transactions.map((t) => t.toMap()).toList();
    await prefs.setString(_transactionsKey, jsonEncode(transactionsJson));
  }
  
  // Load transactions from local storage
  Future<List<Transaction>> loadTransactions() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final transactionsJson = prefs.getString(_transactionsKey);
      
      if (transactionsJson == null) {
        return [];
      }
      
      final List<dynamic> decodedList = jsonDecode(transactionsJson);
      return decodedList.map((item) => Transaction.fromMap(item)).toList();
    } catch (e) {
      // If there's an error, return an empty list
      return [];
    }
  }
  
  // Save user budget
  Future<void> saveBudget(Map<String, double> budget) async {
    final prefs = await SharedPreferences.getInstance();
    final budgetMap = {};
    budget.forEach((key, value) {
      budgetMap[key] = value;
    });
    await prefs.setString(_userBudgetKey, jsonEncode(budgetMap));
  }
  
  // Load user budget
  Future<Map<String, double>> loadBudget() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final budgetJson = prefs.getString(_userBudgetKey);
      
      if (budgetJson == null) {
        return {};
      }
      
      final Map<String, dynamic> decodedMap = jsonDecode(budgetJson);
      final Map<String, double> budget = {};
      decodedMap.forEach((key, value) {
        budget[key] = (value as num).toDouble();
      });
      return budget;
    } catch (e) {
      return {};
    }
  }
  
  // Save monthly income
  Future<void> saveIncome(double income) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_userIncomeKey, income);
  }
  
  // Load monthly income
  Future<double> loadIncome() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_userIncomeKey) ?? 0.0;
  }
  
  // Save savings goal
  Future<void> saveSavingsGoal(double goal) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_goalKey, goal);
  }
  
  // Load savings goal
  Future<double> loadSavingsGoal() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_goalKey) ?? 0.0;
  }
  
  // Save username
  Future<void> saveUsername(String username) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_usernameKey, username);
  }
  
  // Load username
  Future<String> loadUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_usernameKey) ?? 'bestie';
  }
  
  // Add a transaction
  Future<void> addTransaction(Transaction transaction) async {
    final transactions = await loadTransactions();
    transactions.add(transaction);
    await saveTransactions(transactions);
  }
  
  // Delete a transaction
  Future<void> deleteTransaction(String id) async {
    final transactions = await loadTransactions();
    transactions.removeWhere((t) => t.id == id);
    await saveTransactions(transactions);
  }
  
  // Update a transaction
  Future<void> updateTransaction(Transaction updatedTransaction) async {
    final transactions = await loadTransactions();
    final index = transactions.indexWhere((t) => t.id == updatedTransaction.id);
    if (index != -1) {
      transactions[index] = updatedTransaction;
      await saveTransactions(transactions);
    }
  }
  
  // Get transactions summary for dashboard
  Future<Map<String, dynamic>> getTransactionsSummary() async {
    final transactions = await loadTransactions();
    
    // Calculate total income and expenses this month
    final now = DateTime.now();
    final thisMonth = transactions.where((t) => 
      t.date.month == now.month && t.date.year == now.year);
    
    double totalIncome = 0;
    double totalExpenses = 0;
    
    for (var transaction in thisMonth) {
      if (transaction.isExpense) {
        totalExpenses += transaction.amount;
      } else {
        totalIncome += transaction.amount;
      }
    }
    
    // Calculate spending by category this month
    final Map<String, double> spendingByCategory = {};
    for (var transaction in thisMonth) {
      if (transaction.isExpense) {
        if (spendingByCategory.containsKey(transaction.category)) {
          spendingByCategory[transaction.category] = 
              spendingByCategory[transaction.category]! + transaction.amount;
        } else {
          spendingByCategory[transaction.category] = transaction.amount;
        }
      }
    }
    
    return {
      'totalIncome': totalIncome,
      'totalExpenses': totalExpenses,
      'balance': totalIncome - totalExpenses,
      'spendingByCategory': spendingByCategory,
    };
  }
  
  // Save chat messages to local storage
  Future<void> saveChatMessages(List<Map<String, dynamic>> messages) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_chatMessagesKey, jsonEncode(messages));
  }
  
  // Load chat messages from local storage
  Future<List<Map<String, dynamic>>> loadChatMessages() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final messagesJson = prefs.getString(_chatMessagesKey);
      
      if (messagesJson == null) {
        return [];
      }
      
      final List<dynamic> decodedList = jsonDecode(messagesJson);
      return decodedList.map((item) => Map<String, dynamic>.from(item)).toList();
    } catch (e) {
      // If there's an error, return an empty list
      return [];
    }
  }
  
  // Add a chat message to storage
  Future<void> addChatMessage(Map<String, dynamic> message) async {
    final messages = await loadChatMessages();
    messages.add(message);
    await saveChatMessages(messages);
  }
  
  // Clear all chat messages
  Future<void> clearChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_chatMessagesKey);
  }
  
  // Check if onboarding is completed
  Future<bool> isOnboardingCompleted() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_onboardingCompletedKey) ?? false;
  }
  
  // Set onboarding completed flag
  Future<void> setOnboardingCompleted(bool completed) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_onboardingCompletedKey, completed);
  }
}