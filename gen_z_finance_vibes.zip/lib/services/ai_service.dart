import 'dart:convert';
import 'package:http/http.dart' as http;

class AIService {
  static const String _apiKey = 'OPENAI-API-KEY';
  static const String _baseUrl = 'https://api.openai.com/v1/chat/completions';

  // Get financial advice from OpenAI
  Future<String> getFinancialAdvice(String question) async {
    try {
      final response = await _makeOpenAIRequest(
        [
          {
            "role": "system",
            "content": "You are a Gen Z financial advisor named 'CashGuru'. Use Gen Z slang and emojis. Keep responses short, direct, and easy to understand. Focus on practical financial advice for young adults. Be supportive but real about financial challenges. Use phrases like 'no cap', 'lowkey', 'vibe check', 'slay', etc. Speak like you're texting a friend."
          },
          {
            "role": "user",
            "content": question
          }
        ],
      );

      // Extract and return the assistant's message
      final responseData = jsonDecode(utf8.decode(response.bodyBytes));
      return responseData['choices'][0]['message']['content'];
    } catch (e) {
      return "Oof, the vibes are off right now! Can't connect to the financial galaxy. Try again later? 💸";
    }
  }

  // Analyze spending patterns and provide insights
  Future<String> analyzeSpending(List<Map<String, dynamic>> transactions) async {
    try {
      // Convert transactions to a simple format for the AI
      final transactionText = transactions.map((t) => 
        "${t['amount']} on ${t['category']} (${t['date']}): ${t['description']}"
      ).join("\n");

      final response = await _makeOpenAIRequest(
        [
          {
            "role": "system",
            "content": "You are a Gen Z financial analyst named 'CashGuru'. Analyze the spending data and provide insights in Gen Z language. Use slang like 'no cap', 'lowkey', 'vibe check', 'slay', etc. Be supportive but honest. Focus on actionable tips. Include emojis. Limit to 3-4 main insights in bullet points."
          },
          {
            "role": "user",
            "content": "Here are my recent transactions, please analyze and give me financial advice:\n$transactionText"
          }
        ],
      );

      // Extract and return the assistant's message
      final responseData = jsonDecode(utf8.decode(response.bodyBytes));
      return responseData['choices'][0]['message']['content'];
    } catch (e) {
      return "Big yikes! Couldn't analyze your spending rn. The data's not giving what it's supposed to give! 😭";
    }
  }

  // Generate a budget suggestion based on income and expense categories
  Future<Map<String, dynamic>> generateBudget(double income, List<String> expenseCategories) async {
    try {
      final response = await _makeOpenAIRequest(
        [
          {
            "role": "system",
            "content": "You are a Gen Z financial planner. Create a monthly budget based on income and expense categories. Return ONLY a valid JSON object with category names as keys and recommended amounts as values. Include a 'savings' category. Do not include any explanatory text."
          },
          {
            "role": "user",
            "content": "My monthly income is \$${income.toStringAsFixed(2)}. Create a budget for these categories: ${expenseCategories.join(', ')}. Return the result as JSON."
          }
        ],
        isJson: true,
      );

      // Extract and return the budget as a Map
      final responseData = jsonDecode(utf8.decode(response.bodyBytes));
      String jsonString = responseData['choices'][0]['message']['content'];
      return jsonDecode(jsonString);
    } catch (e) {
      // Return a simple fallback budget
      return {
        "error": "Couldn't generate a custom budget right now. Try again later!"
      };
    }
  }

  // General helper method for making requests to OpenAI
  Future<http.Response> _makeOpenAIRequest(List<Map<String, String>> messages, {bool isJson = false}) async {
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_apiKey',
    };

    final body = {
      'model': 'gpt-4o',
      'messages': messages,
      if (isJson) 'response_format': {'type': 'json_object'},
    };

    return await http.post(
      Uri.parse(_baseUrl),
      headers: headers,
      body: jsonEncode(body),
    );
  }
}