import 'package:flutter/material.dart';

class Transaction {
  final String id;
  final double amount;
  final String category;
  final DateTime date;
  final String description;
  final bool isExpense;

  Transaction({
    required this.id,
    required this.amount,
    required this.category,
    required this.date,
    required this.description,
    this.isExpense = true,
  });

  // Convert Transaction to Map for storage
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'amount': amount,
      'category': category,
      'date': date.millisecondsSinceEpoch,
      'description': description,
      'isExpense': isExpense,
    };
  }

  // Create Transaction from Map
  factory Transaction.fromMap(Map<String, dynamic> map) {
    return Transaction(
      id: map['id'],
      amount: map['amount'],
      category: map['category'],
      date: DateTime.fromMillisecondsSinceEpoch(map['date']),
      description: map['description'],
      isExpense: map['isExpense'] ?? true,
    );
  }

  // Copy with method for updating transactions
  Transaction copyWith({
    String? id,
    double? amount,
    String? category,
    DateTime? date,
    String? description,
    bool? isExpense,
  }) {
    return Transaction(
      id: id ?? this.id,
      amount: amount ?? this.amount,
      category: category ?? this.category,
      date: date ?? this.date,
      description: description ?? this.description,
      isExpense: isExpense ?? this.isExpense,
    );
  }

  // Helper methods for the Finance app
  String get formattedAmount => '\$${amount.toStringAsFixed(2)}';

  String get formattedDate {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final transactionDate = DateTime(date.year, date.month, date.day);

    if (transactionDate == today) {
      return 'Today';
    } else if (transactionDate == yesterday) {
      return 'Yesterday';
    } else {
      return '${date.month}/${date.day}/${date.year}';
    }
  }

  // Get GenZ description of the transaction
  String getGenzDescription() {
    if (isExpense) {
      switch (category) {
        case 'Food':
          return 'Spent $formattedAmount on some munchies';
        case 'Shopping':
          return 'Yeet $formattedAmount for the drip';
        case 'Transportation':
          return 'Drop $formattedAmount on the go';
        case 'Entertainment':
          return 'Vibed away $formattedAmount for fun';
        case 'Bills':
          return 'Adult tax: $formattedAmount paid';
        default:
          return 'Yeeted $formattedAmount';
      }
    } else {
      return 'Secured the bag: $formattedAmount';
    }
  }

  // Get emoji for transaction category
  IconData getCategoryIcon() {
    switch (category) {
      case 'Food':
        return Icons.restaurant;
      case 'Shopping':
        return Icons.shopping_bag;
      case 'Transportation':
        return Icons.directions_car;
      case 'Entertainment':
        return Icons.movie;
      case 'Bills':
        return Icons.receipt_long;
      case 'Income':
        return Icons.account_balance_wallet;
      default:
        return Icons.attach_money;
    }
  }
}