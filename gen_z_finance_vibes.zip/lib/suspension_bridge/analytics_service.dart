import 'package:suspension_bridge/suspension_bridge.dart';

class ExternalAnalyticsService {
  ExternalAnalyticsService() {
    _registerSuspensionBridge();
  }
  void _registerSuspensionBridge() {
    print('analytics: registering suspension bridge');
    SuspensionBridge()
        .registerMethodCallHandler('analytics', _onAnalyticsCallHandler);
  }

  void _onAnalyticsCallHandler(SuspensionBridgeMethod method) {
    print('analytics: method called: ${method.methodName}');
    switch (method.methodName) {
      case 'pageLoad':
        final screenName = method.methodData['screenName'] as String;
        print('Analytics: Page loaded: $screenName');
        break;
    }
  }
}
