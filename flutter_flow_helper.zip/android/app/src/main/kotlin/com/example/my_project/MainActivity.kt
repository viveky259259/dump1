package io.flutterflow.helper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
