// Automatic FlutterFlow imports
import 'package:flutter_flow_helper/main.dart';

import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';

// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future changeFont(BuildContext context, String fontName) async {
  // Add your function code here!
  if (fontName == 'Mukta') {
    MyApp.of(context).changeFont(Mukta());
  } else if (fontName == 'Inter') {
    MyApp.of(context).changeFont(Inter());
  }
  print('Font updated to $fontName');
}