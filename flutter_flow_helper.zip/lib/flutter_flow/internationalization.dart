import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'hi'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? hiText = '',
  }) =>
      [enText, hiText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // LandingPage
  {
    '3rj006j1': {
      'en': 'Helper',
      'hi': 'सहायक',
    },
    '4if2efqh': {
      'en': 'Home',
      'hi': 'घर',
    },
  },
  // FaqPage
  {
    'ehivpy9c': {
      'en': 'FAQ',
      'hi': 'सामान्य प्रश्न',
    },
    'xr10y3j9': {
      'en': 'Frequently Asked Questions',
      'hi': 'अक्सर पूछे जाने वाले प्रश्नों',
    },
    'lqh3rskv': {
      'en': 'Find answers to common questions about our service',
      'hi': 'हमारी सेवा के बारे में सामान्य प्रश्नों के उत्तर पाएँ',
    },
    'tom02s10': {
      'en': 'How do I reset my password?',
      'hi': 'मैं अपना पासवर्ड कैसे रीसेट करूं?',
    },
    'hyv0onpb': {
      'en':
          'Click \'Forgot Password\' on the login screen and follow the instructions sent to your email.',
      'hi':
          'लॉगिन स्क्रीन पर \'पासवर्ड भूल गए\' पर क्लिक करें और अपने ईमेल पर भेजे गए निर्देशों का पालन करें।',
    },
    '22savtyz': {
      'en': 'Can I change my subscription plan?',
      'hi': 'क्या मैं अपनी सदस्यता योजना बदल सकता हूँ?',
    },
    'b638et2c': {
      'en':
          'Yes, you can upgrade or downgrade your plan at any time from your account settings.',
      'hi':
          'हां, आप किसी भी समय अपनी खाता सेटिंग से अपनी योजना को अपग्रेड या डाउनग्रेड कर सकते हैं।',
    },
    'eh6i5d6g': {
      'en': 'How do I contact customer support?',
      'hi': 'मैं ग्राहक सहायता से कैसे संपर्क करूं?',
    },
    'dzc5ecb6': {
      'en':
          'You can reach our support team through the Help Center or email us at support@example.com',
      'hi':
          'आप सहायता केंद्र के माध्यम से हमारी सहायता टीम तक पहुँच सकते हैं या हमें support@example.com पर ईमेल कर सकते हैं',
    },
    'ypr8sfe3': {
      'en': 'What payment methods do you accept?',
      'hi': 'आप कौन सी भुगतान पद्धतियां स्वीकार करते हैं?',
    },
    'm7nwe4li': {
      'en': 'We accept all major credit cards, PayPal, and bank transfers.',
      'hi':
          'हम सभी प्रमुख क्रेडिट कार्ड, पेपैल और बैंक हस्तांतरण स्वीकार करते हैं।',
    },
    'yw537ify': {
      'en': 'Is my data secure?',
      'hi': 'क्या मेरा डेटा सुरक्षित है?',
    },
    's25xztdw': {
      'en':
          'Yes, we use industry-standard encryption and security measures to protect your information.',
      'hi':
          'हां, हम आपकी जानकारी की सुरक्षा के लिए उद्योग-मानक एन्क्रिप्शन और सुरक्षा उपायों का उपयोग करते हैं।',
    },
    '7h2o7fgb': {
      'en': 'Still have questions?',
      'hi': 'अभी भी प्रश्न हैं?',
    },
    'a7za1bww': {
      'en':
          'Can\'t find the answer you\'re looking for? Please chat with our friendly team.',
      'hi':
          'क्या आपको वह उत्तर नहीं मिल रहा है जिसकी आपको तलाश है? कृपया हमारी मित्रवत टीम से चैट करें।',
    },
    'eb053e4h': {
      'en': 'Contact Support',
      'hi': 'समर्थन से संपर्क करें',
    },
  },
  // History
  {
    '49io990h': {
      'en': 'Chat History',
      'hi': 'चैट का इतिहास',
    },
    'njtntyip': {
      'en': 'Recent Conversations',
      'hi': 'हाल की बातचीत',
    },
    'nlsjyroq': {
      'en': 'Your previous chats with AI Assistant',
      'hi': 'AI Assistant के साथ आपकी पिछली चैट',
    },
    'ndzoip4p': {
      'en': 'Bible Study Discussion',
      'hi': 'बाइबल अध्ययन चर्चा',
    },
    '8rr6asyg': {
      'en': 'Last chat: 2 hours ago',
      'hi': 'अंतिम बातचीत: 2 घंटे पहले',
    },
    '1ian05iu': {
      'en': 'Prayer Guidance',
      'hi': 'प्रार्थना मार्गदर्शन',
    },
    'trhzmq8k': {
      'en': 'Last chat: Yesterday',
      'hi': 'अंतिम चैट: कल',
    },
    'kug35jmb': {
      'en': 'Faith Questions',
      'hi': 'आस्था संबंधी प्रश्न',
    },
    'gkvusegp': {
      'en': 'Last chat: 3 days ago',
      'hi': 'अंतिम बातचीत: 3 दिन पहले',
    },
    'uejfnr5y': {
      'en': 'Scripture Analysis',
      'hi': 'शास्त्र विश्लेषण',
    },
    'q1f9kfsg': {
      'en': 'Last chat: 1 week ago',
      'hi': 'अंतिम बातचीत: 1 सप्ताह पहले',
    },
    'mrb90gtz': {
      'en': 'Daily Devotional',
      'hi': 'दैनिक भक्ति',
    },
    'ysxips8t': {
      'en': 'Last chat: 2 weeks ago',
      'hi': 'अंतिम बातचीत: 2 सप्ताह पहले',
    },
    '6mwcbbrr': {
      'en': 'Start a New Conversation',
      'hi': 'नई बातचीत शुरू करें',
    },
    '9fv35pt9': {
      'en':
          'Have questions about faith? Start a new chat with our AI Assistant.',
      'hi':
          'क्या आपके पास आस्था के बारे में कोई प्रश्न है? हमारे AI सहायक के साथ एक नई चैट शुरू करें।',
    },
    'w5imhwrs': {
      'en': 'New Chat',
      'hi': 'नई चैट',
    },
  },
  // Miscellaneous
  {
    '9dlv5cv4': {
      'en': 'Hello World',
      'hi': '',
    },
    'gf327nwx': {
      'en': '',
      'hi': '',
    },
    'is9fmkft': {
      'en': '',
      'hi': '',
    },
    'rs0yslkh': {
      'en': '',
      'hi': '',
    },
    'zt5axhin': {
      'en': '',
      'hi': '',
    },
    '5nx4x3am': {
      'en': '',
      'hi': '',
    },
    '9znpujs5': {
      'en': '',
      'hi': '',
    },
    '77tttnn1': {
      'en': '',
      'hi': '',
    },
    'jcfdtiem': {
      'en': '',
      'hi': '',
    },
    'zznrve2q': {
      'en': '',
      'hi': '',
    },
    '51izm2wy': {
      'en': '',
      'hi': '',
    },
    '0xxrhj66': {
      'en': '',
      'hi': '',
    },
    'k8ztwvk0': {
      'en': '',
      'hi': '',
    },
    'fsb6f534': {
      'en': '',
      'hi': '',
    },
    '81guou1j': {
      'en': '',
      'hi': '',
    },
    'c5u0k3hy': {
      'en': '',
      'hi': '',
    },
    'gs7p56fd': {
      'en': '',
      'hi': '',
    },
    'jjv23m5d': {
      'en': '',
      'hi': '',
    },
    'aptua4jt': {
      'en': '',
      'hi': '',
    },
    '7iz2nk6g': {
      'en': '',
      'hi': '',
    },
    '6jl2lwkc': {
      'en': '',
      'hi': '',
    },
    'aery72p8': {
      'en': '',
      'hi': '',
    },
    '3wofdmdy': {
      'en': '',
      'hi': '',
    },
    '22ee8n0l': {
      'en': '',
      'hi': '',
    },
    'okdc3krr': {
      'en': '',
      'hi': '',
    },
    's8gu7ggs': {
      'en': '',
      'hi': '',
    },
  },
].reduce((a, b) => a..addAll(b));
