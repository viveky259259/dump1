# SpendRail Admin Dashboard

A professional, responsive admin dashboard for **SpendRail Labourverse** – an enterprise expense management system.

## 🚀 Features

- **Authentication** - Secure email/password login with Firebase Auth
- **Dashboard Overview** - Real-time stats for pending requests, expenses, and flagged items
- **Request Management** - Approve/reject pending expense requests with batch actions
- **Employee Directory** - View all employees with AI-powered risk indicators
- **Analytics** - Spending patterns, category breakdowns, and anomaly detection

## 📦 Tech Stack

- **React 18** with Vite
- **Tailwind CSS** for styling
- **Firebase** (Auth, Firestore)
- **React Router** for navigation
- **Recharts** for data visualization
- **TanStack Table** for data grids
- **Radix UI** primitives (shadcn/ui style)
- **Lucide React** for icons

## 🏗️ Project Structure

```
src/
├── components/
│   ├── atoms/           # Basic UI elements (RiskBadge, etc.)
│   ├── layout/          # Layout components (Sidebar, Topbar)
│   └── ui/              # shadcn-style UI components
├── context/
│   └── AuthContext.jsx  # Authentication context
├── hooks/
│   ├── useAnalytics.js         # Analytics data hook
│   ├── useDashboardStats.js    # Dashboard stats hook
│   ├── useEmployees.js         # Employee data hook
│   ├── usePendingRequests.js   # Pending requests hook
│   └── useRecentTransactions.js # Recent transactions hook
├── lib/
│   ├── firebase.js      # Firebase configuration
│   └── utils.js         # Utility functions
├── pages/
│   ├── Analytics.jsx    # Analytics & charts page
│   ├── Dashboard.jsx    # Main dashboard page
│   ├── Employees.jsx    # Employee directory page
│   ├── Login.jsx        # Login page
│   └── Requests.jsx     # Pending requests page
├── App.jsx              # Main app with routing
├── main.jsx             # Entry point
└── index.css            # Global styles
```

## 🔥 Firebase Schema

The app expects the following Firestore collections:

### `users/{uid}`
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "role": "Employee",
  "department": "Engineering",
  "risk_score": 25,
  "photoURL": "https://..."
}
```

### `transactions/{txId}`
```json
{
  "userId": "user_id_here",
  "amount": 5000,
  "category": "Travel",
  "status": "pending",
  "timestamp": "Firestore Timestamp",
  "risk_flag": false,
  "risk_score": 15
}
```

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ installed
- Firebase project set up

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm run dev
   ```

3. **Open in browser:**
   Navigate to `http://localhost:5173`

### Build for Production

```bash
npm run build
```

## 🎨 Design System

### Colors

- **Primary**: Green (#22c55e) - SpendRail brand color
- **Background**: Near black (#0a0a0a)
- **Card**: Dark gray (#0d0d0d)
- **Border**: Subtle gray borders

### Risk Indicators

| Risk Level | Score Range | Color |
|------------|-------------|-------|
| Low | 0-30 | Green |
| Medium | 31-70 | Yellow |
| High | 71+ | Red |

### Animations

- Fade-in animations on page load
- Staggered list animations
- Hover effects on cards and buttons
- Pulse animations for live indicators

## 📱 Responsive Design

- **Desktop**: Full sidebar navigation
- **Tablet**: Collapsible sidebar
- **Mobile**: Bottom sheet navigation

## 🔐 Security

- Protected routes require authentication
- Firebase security rules should be configured
- Session management handled by Firebase

## 📄 License

MIT License - © 2024 SpendRail Labourverse

