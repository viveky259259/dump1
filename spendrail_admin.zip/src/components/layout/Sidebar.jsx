import { NavLink } from 'react-router-dom'
import { 
  LayoutDashboard, 
  ClipboardList, 
  Users, 
  UserPlus,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Wallet
} from 'lucide-react'
import { cn } from '@/lib/utils'

const navItems = [
  {
    title: 'Dashboard',
    href: '/',
    icon: LayoutDashboard
  },
  {
    title: 'Requests',
    href: '/requests',
    icon: ClipboardList
  },
  {
    title: 'Employees',
    href: '/employees',
    icon: Users
  },
  {
    title: 'Add Employee',
    href: '/employees/add',
    icon: UserPlus
  },
  {
    title: 'Analytics',
    href: '/analytics',
    icon: BarChart3
  }
]

export default function Sidebar({ collapsed, onToggle }) {
  return (
    <aside 
      className={cn(
        "fixed left-0 top-0 z-40 h-screen bg-card border-r border-border transition-all duration-300 flex flex-col",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Logo Section */}
      <div className="flex items-center h-16 px-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/20">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          {!collapsed && (
            <div className="flex flex-col animate-fade-in">
              <span className="font-semibold text-sm text-foreground">SpendRail</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Labourverse</span>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
        {navItems.map((item, index) => (
          <NavLink
            key={item.href}
            to={item.href}
            end={item.href === '/'}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group",
                "opacity-0 animate-slide-in-left",
                collapsed ? "justify-center" : "",
                isActive
                  ? "bg-primary/10 text-primary shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )
            }
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <item.icon className={cn(
              "w-5 h-5 transition-transform",
              "group-hover:scale-110"
            )} />
            {!collapsed && <span>{item.title}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Toggle Button */}
      <div className="p-3 border-t border-border">
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4" />
              <span className="text-sm">Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  )
}

