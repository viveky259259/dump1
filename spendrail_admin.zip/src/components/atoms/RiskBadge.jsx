import { AlertTriangle, Shield, ShieldAlert } from 'lucide-react'
import { cn, getRiskLevel, getRiskColor } from '@/lib/utils'

export default function RiskBadge({ score, showScore = true, size = 'default' }) {
  const level = getRiskLevel(score)
  const colors = getRiskColor(score)
  
  const icons = {
    low: Shield,
    medium: AlertTriangle,
    high: ShieldAlert
  }
  
  const Icon = icons[level]
  
  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-[10px] gap-1',
    default: 'px-2 py-1 text-xs gap-1.5',
    lg: 'px-3 py-1.5 text-sm gap-2'
  }
  
  const iconSizes = {
    sm: 'w-3 h-3',
    default: 'w-3.5 h-3.5',
    lg: 'w-4 h-4'
  }

  return (
    <div 
      className={cn(
        "inline-flex items-center rounded-full font-medium capitalize transition-all",
        colors.bg,
        colors.text,
        `border ${colors.border}/30`,
        sizeClasses[size]
      )}
    >
      <Icon className={iconSizes[size]} />
      <span>{level}</span>
      {showScore && (
        <span className="opacity-70">({score})</span>
      )}
    </div>
  )
}

// Card variant with glow effect for employee cards
export function RiskIndicator({ score, className }) {
  const colors = getRiskColor(score)
  const level = getRiskLevel(score)
  
  return (
    <div 
      className={cn(
        "absolute inset-0 rounded-xl pointer-events-none transition-all duration-300",
        `border-2 ${colors.border}/50`,
        level === 'high' && 'border-red-500/50',
        level === 'medium' && 'border-yellow-500/50',
        level === 'low' && 'border-green-500/50',
        className
      )}
    >
      {/* Glow effect */}
      <div 
        className={cn(
          "absolute inset-0 rounded-xl opacity-20 blur-xl transition-opacity",
          level === 'high' && 'bg-red-500',
          level === 'medium' && 'bg-yellow-500',
          level === 'low' && 'bg-green-500'
        )} 
      />
    </div>
  )
}

