import { useState, useEffect, useCallback } from 'react'
import { 
  collection, 
  getDocs, 
  doc, 
  getDoc,
  updateDoc,
  writeBatch,
  serverTimestamp
} from 'firebase/firestore'
import { db } from '@/lib/firebase'

export function usePendingRequests() {
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [processing, setProcessing] = useState(false)

  const fetchRequests = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      
      // Fetch ALL requests from 'requests' collection
      const snapshot = await getDocs(collection(db, 'requests'))
      const requestList = []
      
      // Batch fetch user data
      const userCache = {}
      
      for (const docSnapshot of snapshot.docs) {
        const data = docSnapshot.data()
        
        // Fetch user data if not cached
        let userName = 'Unknown User'
        let userRiskScore = 0
        let userPhone = 'N/A'
        
        if (data.userId) {
          if (!userCache[data.userId]) {
            try {
              const userDoc = await getDoc(doc(db, 'users', data.userId))
              if (userDoc.exists()) {
                const userData = userDoc.data()
                userCache[data.userId] = {
                  name: userData.name || 'Unknown User',
                  risk_score: userData.risk_score || 0,
                  department: userData.department || 'N/A',
                  phone: userData.phone || 'N/A'
                }
              }
            } catch (e) {
              console.error('Error fetching user:', e)
            }
          }
          
          if (userCache[data.userId]) {
            userName = userCache[data.userId].name
            userRiskScore = userCache[data.userId].risk_score
            userPhone = userCache[data.userId].phone
          }
        }
        
        requestList.push({
          id: docSnapshot.id,
          ...data,
          userName,
          userRiskScore,
          userPhone
        })
      }
      
      // Sort by createdAt descending (client-side)
      requestList.sort((a, b) => {
        const dateA = a.createdAt?.toDate?.() || new Date(0)
        const dateB = b.createdAt?.toDate?.() || new Date(0)
        return dateB - dateA
      })
      
      setRequests(requestList)
      console.log('Fetched all requests:', requestList.length)
    } catch (err) {
      console.error('Error fetching requests:', err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchRequests()
  }, [fetchRequests])

  const approveRequest = async (requestId) => {
    try {
      setProcessing(true)
      const requestRef = doc(db, 'requests', requestId)
      await updateDoc(requestRef, {
        status: 'transaction_approved',
        approvedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      })
      
      // Update local state
      setRequests(prev => prev.map(r => 
        r.id === requestId 
          ? { ...r, status: 'transaction_approved' }
          : r
      ))
      return true
    } catch (err) {
      console.error('Error approving request:', err)
      throw err
    } finally {
      setProcessing(false)
    }
  }

  const rejectRequest = async (requestId, reason) => {
    try {
      setProcessing(true)
      const requestRef = doc(db, 'requests', requestId)
      await updateDoc(requestRef, {
        status: 'transaction_disapproved',
        rejectionReason: reason,
        rejectedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      })
      
      // Update local state
      setRequests(prev => prev.map(r => 
        r.id === requestId 
          ? { ...r, status: 'transaction_disapproved', rejectionReason: reason }
          : r
      ))
      return true
    } catch (err) {
      console.error('Error rejecting request:', err)
      throw err
    } finally {
      setProcessing(false)
    }
  }

  const batchApprove = async (requestIds) => {
    try {
      setProcessing(true)
      const batch = writeBatch(db)
      
      requestIds.forEach(id => {
        const requestRef = doc(db, 'requests', id)
        batch.update(requestRef, {
          status: 'transaction_approved',
          approvedAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        })
      })
      
      await batch.commit()
      
      // Update local state
      setRequests(prev => prev.map(r => 
        requestIds.includes(r.id)
          ? { ...r, status: 'transaction_approved' }
          : r
      ))
      return true
    } catch (err) {
      console.error('Error batch approving:', err)
      throw err
    } finally {
      setProcessing(false)
    }
  }

  const batchReject = async (requestIds, reason) => {
    try {
      setProcessing(true)
      const batch = writeBatch(db)
      
      requestIds.forEach(id => {
        const requestRef = doc(db, 'requests', id)
        batch.update(requestRef, {
          status: 'transaction_disapproved',
          rejectionReason: reason,
          rejectedAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        })
      })
      
      await batch.commit()
      
      // Update local state
      setRequests(prev => prev.map(r => 
        requestIds.includes(r.id)
          ? { ...r, status: 'transaction_disapproved', rejectionReason: reason }
          : r
      ))
      return true
    } catch (err) {
      console.error('Error batch rejecting:', err)
      throw err
    } finally {
      setProcessing(false)
    }
  }

  return { 
    requests, 
    loading, 
    error, 
    processing,
    approveRequest, 
    rejectRequest,
    batchApprove,
    batchReject,
    refetch: fetchRequests
  }
}
