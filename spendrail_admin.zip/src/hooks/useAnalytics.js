import { useState, useEffect } from 'react'
import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore'
import { db } from '@/lib/firebase'

export function useSpendingAnalytics() {
  const [data, setData] = useState({
    dailySpending: [],
    categoryBreakdown: [],
    anomalies: [],
    weeklyTrend: []
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function fetchAnalytics() {
      try {
        setLoading(true)
        
        // Get date ranges
        const now = new Date()
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
        const thirtyDaysTimestamp = Timestamp.fromDate(thirtyDaysAgo)
        
        // Fetch all transactions from last 30 days
        const txQuery = query(
          collection(db, 'transactions'),
          where('timestamp', '>=', thirtyDaysTimestamp)
        )
        
        const snapshot = await getDocs(txQuery)
        const transactions = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }))
        
        // Calculate daily spending
        const dailyMap = {}
        const categoryMap = {}
        const categoryAvg = {}
        
        transactions.forEach(tx => {
          if (tx.status !== 'approved') return
          
          const date = tx.timestamp?.toDate?.() || new Date(tx.timestamp)
          const dateKey = date.toISOString().split('T')[0]
          const category = tx.category || 'Other'
          
          // Daily spending
          if (!dailyMap[dateKey]) {
            dailyMap[dateKey] = 0
          }
          dailyMap[dateKey] += tx.amount || 0
          
          // Category breakdown
          if (!categoryMap[category]) {
            categoryMap[category] = 0
          }
          categoryMap[category] += tx.amount || 0
          
          // Category count for average calculation
          if (!categoryAvg[category]) {
            categoryAvg[category] = { total: 0, count: 0 }
          }
          categoryAvg[category].total += tx.amount || 0
          categoryAvg[category].count += 1
        })
        
        // Format daily spending for chart
        const dailySpending = Object.entries(dailyMap)
          .map(([date, amount]) => ({
            date,
            amount,
            displayDate: new Date(date).toLocaleDateString('en-IN', { 
              day: 'numeric', 
              month: 'short' 
            })
          }))
          .sort((a, b) => new Date(a.date) - new Date(b.date))
          .slice(-14) // Last 14 days
        
        // Format category breakdown for pie chart
        const colors = [
          '#22c55e', // Green
          '#3b82f6', // Blue
          '#8b5cf6', // Purple
          '#f59e0b', // Amber
          '#ec4899', // Pink
          '#06b6d4', // Cyan
          '#6b7280', // Gray
        ]
        
        const categoryBreakdown = Object.entries(categoryMap)
          .map(([name, value], index) => ({
            name,
            value,
            color: colors[index % colors.length]
          }))
          .sort((a, b) => b.value - a.value)
        
        // Detect anomalies (transactions > 200% of category average)
        const anomalies = transactions.filter(tx => {
          const category = tx.category || 'Other'
          if (!categoryAvg[category] || categoryAvg[category].count < 2) return false
          
          const avg = categoryAvg[category].total / categoryAvg[category].count
          return tx.amount > avg * 2
        }).map(tx => ({
          ...tx,
          categoryAvg: categoryAvg[tx.category]?.total / categoryAvg[tx.category]?.count || 0
        }))
        
        // Weekly trend (last 8 weeks)
        const weeklyMap = {}
        transactions.forEach(tx => {
          if (tx.status !== 'approved') return
          const date = tx.timestamp?.toDate?.() || new Date(tx.timestamp)
          const weekStart = new Date(date)
          weekStart.setDate(weekStart.getDate() - weekStart.getDay())
          const weekKey = weekStart.toISOString().split('T')[0]
          
          if (!weeklyMap[weekKey]) {
            weeklyMap[weekKey] = 0
          }
          weeklyMap[weekKey] += tx.amount || 0
        })
        
        const weeklyTrend = Object.entries(weeklyMap)
          .map(([week, amount]) => ({
            week,
            amount,
            displayWeek: `Week of ${new Date(week).toLocaleDateString('en-IN', { 
              day: 'numeric', 
              month: 'short' 
            })}`
          }))
          .sort((a, b) => new Date(a.week) - new Date(b.week))
          .slice(-8)
        
        setData({
          dailySpending,
          categoryBreakdown,
          anomalies,
          weeklyTrend
        })
      } catch (err) {
        console.error('Error fetching analytics:', err)
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchAnalytics()
  }, [])

  return { ...data, loading, error }
}

