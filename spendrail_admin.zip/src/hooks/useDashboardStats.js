import { useState, useEffect } from 'react'
import { collection, query, where, getDocs } from 'firebase/firestore'
import { db } from '@/lib/firebase'

export function useDashboardStats() {
  const [stats, setStats] = useState({
    pendingCount: 0,
    totalExpenses: 0,
    flaggedCount: 0,
    employeeCount: 0,
    pendingChange: 0,
    expenseChange: 0,
    employeeChange: 0
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function fetchStats() {
      try {
        setLoading(true)

        // Fetch pending transactions count (waiting_on_manual_approval)
        const pendingQuery = query(
          collection(db, 'transactions'),
          where('status', '==', 'waiting_on_manual_approval')
        )
        const pendingSnapshot = await getDocs(pendingQuery)
        const pendingCount = pendingSnapshot.size

        // Fetch all approved transactions for total
        const approvedQuery = query(
          collection(db, 'transactions'),
          where('status', '==', 'transaction_approved')
        )
        const approvedSnapshot = await getDocs(approvedQuery)
        let totalExpenses = 0
        approvedSnapshot.forEach(doc => {
          totalExpenses += doc.data().amount || 0
        })

        // Fetch flagged/high amount items (transactions over 50000)
        let flaggedCount = 0
        pendingSnapshot.forEach(doc => {
          const amount = doc.data().amount || 0
          if (amount > 50000) flaggedCount++
        })

        // Fetch employee count
        const usersSnapshot = await getDocs(collection(db, 'users'))
        const employeeCount = usersSnapshot.size

        setStats({
          pendingCount,
          totalExpenses,
          flaggedCount,
          employeeCount,
          pendingChange: 12,
          expenseChange: 8,
          employeeChange: 3
        })
        
        console.log('Dashboard stats:', { pendingCount, totalExpenses, flaggedCount, employeeCount })
      } catch (err) {
        console.error('Error fetching dashboard stats:', err)
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  return { stats, loading, error }
}
