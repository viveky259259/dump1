import { useState, useEffect, useCallback } from 'react'
import { collection, getDocs, query, where } from 'firebase/firestore'
import { db } from '@/lib/firebase'

export function useEmployees() {
  const [employees, setEmployees] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchEmployees = useCallback(async () => {
    try {
      setLoading(true)
      
      // Fetch all users
      const usersSnapshot = await getDocs(collection(db, 'users'))
      const usersList = []
      
      for (const docSnapshot of usersSnapshot.docs) {
        const userData = docSnapshot.data()
        
        // Fetch pending amount for each user
        let pendingAmount = 0
        try {
          const pendingQuery = query(
            collection(db, 'transactions'),
            where('userId', '==', docSnapshot.id),
            where('status', '==', 'pending')
          )
          const pendingSnapshot = await getDocs(pendingQuery)
          pendingSnapshot.forEach(tx => {
            pendingAmount += tx.data().amount || 0
          })
        } catch (e) {
          console.error('Error fetching pending amount:', e)
        }
        
        usersList.push({
          id: docSnapshot.id,
          ...userData,
          pendingAmount
        })
      }
      
      setEmployees(usersList)
    } catch (err) {
      console.error('Error fetching employees:', err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchEmployees()
  }, [fetchEmployees])

  return { employees, loading, error, refetch: fetchEmployees }
}

// Get unique departments from employees
export function useDepartments(employees) {
  const departments = [...new Set(
    employees
      .map(e => e.department)
      .filter(Boolean)
  )].sort()
  
  return departments
}

