import { useState, useEffect } from 'react'
import { collection, getDocs, doc, getDoc } from 'firebase/firestore'
import { db } from '@/lib/firebase'

export function useRecentTransactions(count = 10) {
  const [transactions, setTransactions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function fetchTransactions() {
      try {
        setLoading(true)
        
        // Fetch ALL transactions from 'transactions' collection
        const snapshot = await getDocs(collection(db, 'transactions'))
        const txList = []
        
        for (const docSnapshot of snapshot.docs) {
          const data = docSnapshot.data()
          
          // Fetch user data if userId exists
          let userName = 'Unknown User'
          let risk_score = 0
          
          if (data.userId) {
            try {
              const userDoc = await getDoc(doc(db, 'users', data.userId))
              if (userDoc.exists()) {
                const userData = userDoc.data()
                userName = userData.name || 'Unknown User'
                risk_score = userData.risk_score || 0
              }
            } catch (e) {
              console.error('Error fetching user:', e)
            }
          }
          
          txList.push({
            id: docSnapshot.id,
            ...data,
            userName,
            risk_score,
            timestamp: data.createdAt
          })
        }
        
        // Sort by createdAt descending and limit to count
        txList.sort((a, b) => {
          const dateA = a.createdAt?.toDate?.() || new Date(0)
          const dateB = b.createdAt?.toDate?.() || new Date(0)
          return dateB - dateA
        })
        
        setTransactions(txList.slice(0, count))
        console.log('Recent transactions fetched:', txList.length, 'showing:', Math.min(txList.length, count))
      } catch (err) {
        console.error('Error fetching recent transactions:', err)
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchTransactions()
  }, [count])

  return { transactions, loading, error }
}
