import { useNavigate } from 'react-router-dom'
import { 
  ClipboardList, 
  Wallet, 
  AlertTriangle, 
  Users,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Clock,
  IndianRupee
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useDashboardStats } from '@/hooks/useDashboardStats'
import { useRecentTransactions } from '@/hooks/useRecentTransactions'
import { formatCurrency, formatDateTime } from '@/lib/utils'
import { cn } from '@/lib/utils'

function StatsCard({ title, value, description, icon: Icon, trend, trendValue, color, delay }) {
  return (
    <Card className={cn(
      "opacity-0 animate-fade-in overflow-hidden relative group",
      color === 'primary' && "border-primary/20 hover:border-primary/40",
      color === 'warning' && "border-yellow-500/20 hover:border-yellow-500/40",
      color === 'danger' && "border-red-500/20 hover:border-red-500/40"
    )} style={{ animationDelay: delay }}>
      {/* Glow effect */}
      <div className={cn(
        "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500",
        color === 'primary' && "bg-gradient-to-br from-primary/5 to-transparent",
        color === 'warning' && "bg-gradient-to-br from-yellow-500/5 to-transparent",
        color === 'danger' && "bg-gradient-to-br from-red-500/5 to-transparent"
      )} />
      
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={cn(
          "p-2 rounded-lg",
          color === 'primary' && "bg-primary/10 text-primary",
          color === 'warning' && "bg-yellow-500/10 text-yellow-500",
          color === 'danger' && "bg-red-500/10 text-red-500"
        )}>
          <Icon className="w-4 h-4" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-2 mt-1">
          {trend && (
            <span className={cn(
              "flex items-center text-xs font-medium",
              trend === 'up' ? "text-green-500" : "text-red-500"
            )}>
              {trend === 'up' ? (
                <ArrowUpRight className="w-3 h-3" />
              ) : (
                <ArrowDownRight className="w-3 h-3" />
              )}
              {trendValue}
            </span>
          )}
          <span className="text-xs text-muted-foreground">{description}</span>
        </div>
      </CardContent>
    </Card>
  )
}

function TransactionStatusBadge({ status }) {
  const statusConfig = {
    waiting_on_approval: { label: 'Waiting', color: 'text-yellow-500 bg-yellow-500/10' },
    waiting_on_manual_approval: { label: 'Manual Review', color: 'text-orange-500 bg-orange-500/10' },
    transaction_approved: { label: 'Approved', color: 'text-green-500 bg-green-500/10' },
    transaction_disapproved: { label: 'Disapproved', color: 'text-red-500 bg-red-500/10' }
  }
  
  const config = statusConfig[status] || { label: status || 'Unknown', color: 'text-muted-foreground bg-muted' }
  
  return (
    <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-medium", config.color)}>
      {config.label}
    </span>
  )
}

function RecentActivity({ transactions, loading }) {
  return (
    <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.4s' }}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              Recent Transactions
            </CardTitle>
            <CardDescription>Latest 10 transactions (all statuses)</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 animate-pulse">
                <div className="w-10 h-10 rounded-full bg-muted" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-1/3" />
                  <div className="h-3 bg-muted rounded w-1/4" />
                </div>
                <div className="h-4 bg-muted rounded w-20" />
              </div>
            ))}
          </div>
        ) : transactions?.length > 0 ? (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {transactions.map((tx, index) => (
              <div 
                key={tx.id} 
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                style={{ animationDelay: `${0.5 + index * 0.05}s` }}
              >
                {/* Avatar */}
                <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-medium shrink-0">
                  {tx.userName?.charAt(0) || '?'}
                </div>
                
                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium truncate">{tx.userName || 'Unknown User'}</p>
                    <TransactionStatusBadge status={tx.status} />
                  </div>
                  <p className="text-xs text-muted-foreground truncate">
                    {tx.category || tx.note || 'Transaction'}
                  </p>
                </div>
                
                {/* Amount & Date */}
                <div className="text-right shrink-0">
                  <p className="text-sm font-semibold font-mono flex items-center justify-end gap-0.5">
                    <IndianRupee className="w-3 h-3" />
                    {tx.amount?.toLocaleString('en-IN') || '0'}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{formatDateTime(tx.timestamp)}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <ClipboardList className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No transactions found</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default function Dashboard() {
  const navigate = useNavigate()
  const { stats, loading: statsLoading } = useDashboardStats()
  const { transactions, loading: txLoading } = useRecentTransactions(10)

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-1 opacity-0 animate-fade-in">
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back! Here's an overview of your expense management.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Pending Review"
          value={statsLoading ? '...' : stats.pendingCount}
          description="Manual approval needed"
          icon={ClipboardList}
          color="warning"
          delay="0.1s"
        />
        <StatsCard
          title="Total Approved"
          value={statsLoading ? '...' : formatCurrency(stats.totalExpenses)}
          description="All time"
          icon={Wallet}
          color="primary"
          delay="0.15s"
        />
        <StatsCard
          title="High Value"
          value={statsLoading ? '...' : stats.flaggedCount}
          description="Over ₹50,000"
          icon={AlertTriangle}
          color="danger"
          delay="0.2s"
        />
        <StatsCard
          title="Total Workers"
          value={statsLoading ? '...' : stats.employeeCount}
          description="Registered"
          icon={Users}
          color="primary"
          delay="0.25s"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity - Takes 2 columns */}
        <div className="lg:col-span-2">
          <RecentActivity transactions={transactions} loading={txLoading} />
        </div>

        {/* Quick Actions */}
        <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Quick Actions
            </CardTitle>
            <CardDescription>Navigate to key areas</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-4 group"
              onClick={() => navigate('/requests')}
            >
              <div className="p-2 rounded-lg bg-orange-500/10 text-orange-500 mr-3 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                <ClipboardList className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="font-medium">Review Transactions</p>
                <p className="text-xs text-muted-foreground">Manual approval queue</p>
              </div>
              <ArrowUpRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Button>

            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-4 group"
              onClick={() => navigate('/employees')}
            >
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-500 mr-3 group-hover:bg-blue-500 group-hover:text-white transition-colors">
                <Users className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="font-medium">Worker Directory</p>
                <p className="text-xs text-muted-foreground">View all workers</p>
              </div>
              <ArrowUpRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Button>

            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-4 group"
              onClick={() => navigate('/employees/add')}
            >
              <div className="p-2 rounded-lg bg-primary/10 text-primary mr-3 group-hover:bg-primary group-hover:text-white transition-colors">
                <Users className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="font-medium">Add Worker</p>
                <p className="text-xs text-muted-foreground">Register new worker</p>
              </div>
              <ArrowUpRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Button>

            <Button 
              variant="outline" 
              className="w-full justify-start h-auto py-4 group"
              onClick={() => navigate('/analytics')}
            >
              <div className="p-2 rounded-lg bg-purple-500/10 text-purple-500 mr-3 group-hover:bg-purple-500 group-hover:text-white transition-colors">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="font-medium">Analytics</p>
                <p className="text-xs text-muted-foreground">View spending patterns</p>
              </div>
              <ArrowUpRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
