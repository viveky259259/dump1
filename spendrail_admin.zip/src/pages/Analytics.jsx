import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from 'recharts'
import { 
  BarChart3, 
  PieChart as PieChartIcon, 
  TrendingUp, 
  AlertTriangle,
  ArrowUpRight
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useSpendingAnalytics } from '@/hooks/useAnalytics'
import { formatCurrency, formatDate, cn } from '@/lib/utils'

// Custom tooltip component for charts
function CustomTooltip({ active, payload, label, formatter }) {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="text-sm font-medium mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {formatter ? formatter(entry.value) : entry.value}
          </p>
        ))}
      </div>
    )
  }
  return null
}

function SpendingBarChart({ data, loading }) {
  if (loading) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis 
          dataKey="displayDate" 
          stroke="hsl(var(--muted-foreground))"
          fontSize={12}
          tickLine={false}
          axisLine={false}
        />
        <YAxis 
          stroke="hsl(var(--muted-foreground))"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`}
        />
        <Tooltip 
          content={<CustomTooltip formatter={(v) => formatCurrency(v)} />}
          cursor={{ fill: 'hsl(var(--primary) / 0.1)' }}
        />
        <Bar 
          dataKey="amount" 
          fill="hsl(var(--primary))"
          radius={[4, 4, 0, 0]}
          name="Spending"
        />
      </BarChart>
    </ResponsiveContainer>
  )
}

function CategoryPieChart({ data, loading }) {
  if (loading) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="h-[300px] flex items-center justify-center text-muted-foreground">
        No data available
      </div>
    )
  }

  const total = data.reduce((sum, item) => sum + item.value, 0)

  return (
    <div className="flex items-center gap-4">
      <ResponsiveContainer width="50%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            paddingAngle={2}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip 
            content={<CustomTooltip formatter={(v) => formatCurrency(v)} />}
          />
        </PieChart>
      </ResponsiveContainer>
      
      {/* Legend */}
      <div className="flex-1 space-y-2">
        {data.slice(0, 5).map((item, index) => (
          <div key={index} className="flex items-center gap-3">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: item.color }}
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{item.name}</p>
              <p className="text-xs text-muted-foreground">
                {((item.value / total) * 100).toFixed(1)}%
              </p>
            </div>
            <p className="text-sm font-mono font-medium">
              {formatCurrency(item.value)}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

function WeeklyTrendChart({ data, loading }) {
  if (loading) {
    return (
      <div className="h-[300px] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis 
          dataKey="displayWeek" 
          stroke="hsl(var(--muted-foreground))"
          fontSize={12}
          tickLine={false}
          axisLine={false}
        />
        <YAxis 
          stroke="hsl(var(--muted-foreground))"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`}
        />
        <Tooltip 
          content={<CustomTooltip formatter={(v) => formatCurrency(v)} />}
        />
        <Line 
          type="monotone"
          dataKey="amount" 
          stroke="hsl(var(--primary))"
          strokeWidth={2}
          dot={{ fill: 'hsl(var(--primary))', strokeWidth: 0, r: 4 }}
          activeDot={{ r: 6, strokeWidth: 0 }}
          name="Weekly Total"
        />
      </LineChart>
    </ResponsiveContainer>
  )
}

function AnomalyList({ anomalies, loading }) {
  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex items-center gap-4 p-3 animate-pulse">
            <div className="w-10 h-10 rounded-full bg-muted" />
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-muted rounded w-1/3" />
              <div className="h-3 bg-muted rounded w-1/4" />
            </div>
            <div className="h-4 bg-muted rounded w-20" />
          </div>
        ))}
      </div>
    )
  }

  if (!anomalies || anomalies.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <AlertTriangle className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>No anomalies detected</p>
        <p className="text-sm">All transactions are within normal ranges.</p>
      </div>
    )
  }

  return (
    <div className="space-y-2 max-h-[400px] overflow-y-auto">
      {anomalies.map((tx, index) => {
        const percentOver = ((tx.amount / tx.categoryAvg - 1) * 100).toFixed(0)
        
        return (
          <div 
            key={tx.id || index}
            className="flex items-center gap-4 p-3 rounded-lg bg-red-500/5 border border-red-500/20 hover:bg-red-500/10 transition-colors"
          >
            <div className="p-2 rounded-full bg-red-500/10">
              <AlertTriangle className="w-4 h-4 text-red-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">{tx.category}</p>
              <p className="text-xs text-muted-foreground">
                {formatDate(tx.timestamp)} • {percentOver}% above average
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold font-mono text-red-500">
                {formatCurrency(tx.amount)}
              </p>
              <p className="text-xs text-muted-foreground">
                Avg: {formatCurrency(tx.categoryAvg)}
              </p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default function Analytics() {
  const { 
    dailySpending, 
    categoryBreakdown, 
    anomalies, 
    weeklyTrend,
    loading 
  } = useSpendingAnalytics()

  const totalSpending = categoryBreakdown.reduce((sum, c) => sum + c.value, 0)

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-1 opacity-0 animate-fade-in">
        <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
        <p className="text-muted-foreground">
          Spending patterns, trends, and anomaly detection.
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 opacity-0 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{formatCurrency(totalSpending)}</p>
              <p className="text-xs text-muted-foreground">Total (30 days)</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-500">
              <PieChartIcon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{categoryBreakdown.length}</p>
              <p className="text-xs text-muted-foreground">Categories</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-red-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-500/10 text-red-500">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-red-500">{anomalies.length}</p>
              <p className="text-xs text-muted-foreground">Anomalies Detected</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Spending Bar Chart */}
        <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.15s' }}>
          <CardHeader>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              <div>
                <CardTitle>Daily Spending</CardTitle>
                <CardDescription>Last 14 days expense volume</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <SpendingBarChart data={dailySpending} loading={loading} />
          </CardContent>
        </Card>

        {/* Category Breakdown Pie Chart */}
        <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <CardHeader>
            <div className="flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-purple-500" />
              <div>
                <CardTitle>Category Breakdown</CardTitle>
                <CardDescription>Expenses by category</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <CategoryPieChart data={categoryBreakdown} loading={loading} />
          </CardContent>
        </Card>

        {/* Weekly Trend */}
        <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.25s' }}>
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              <div>
                <CardTitle>Weekly Trend</CardTitle>
                <CardDescription>Spending pattern over weeks</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <WeeklyTrendChart data={weeklyTrend} loading={loading} />
          </CardContent>
        </Card>

        {/* Anomaly Detection */}
        <Card className="opacity-0 animate-fade-in border-red-500/20" style={{ animationDelay: '0.3s' }}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <div>
                  <CardTitle>Anomaly Detection</CardTitle>
                  <CardDescription>Transactions exceeding 200% of category average</CardDescription>
                </div>
              </div>
              {anomalies.length > 0 && (
                <Badge variant="danger">{anomalies.length} flagged</Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <AnomalyList anomalies={anomalies} loading={loading} />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

