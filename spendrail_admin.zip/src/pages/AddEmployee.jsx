import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { doc, setDoc, serverTimestamp, collection, query, where, getDocs } from 'firebase/firestore'
import { 
  UserPlus, 
  User, 
  Phone, 
  Building2, 
  Briefcase,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Smartphone
} from 'lucide-react'
import { db } from '@/lib/firebase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select'
import { toast } from '@/components/ui/use-toast'
import { cn } from '@/lib/utils'

const departments = [
  'Construction',
  'Electrical',
  'Plumbing',
  'Carpentry',
  'Painting',
  'Masonry',
  'Welding',
  'HVAC',
  'Roofing',
  'Flooring',
  'Landscaping',
  'Cleaning',
  'Warehouse',
  'Loading & Unloading',
  'Transportation',
  'Security',
  'Maintenance',
  'General Labour',
  'Other'
]

const roles = [
  'Helper',
  'Worker',
  'Skilled Worker',
  'Technician',
  'Foreman',
  'Supervisor',
  'Site Incharge',
  'Contractor'
]

export default function AddEmployee() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    department: '',
    role: 'Worker'
  })
  
  const [errors, setErrors] = useState({})

  const validateForm = () => {
    const newErrors = {}
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required'
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Name must be at least 2 characters'
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required'
    } else if (!/^[0-9]{10}$/.test(formData.phone.replace(/\s/g, ''))) {
      newErrors.phone = 'Please enter a valid 10-digit phone number'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }))
    }
  }

  const checkPhoneExists = async (phone) => {
    const phoneNumber = `+91${phone.replace(/\s/g, '')}`
    const q = query(collection(db, 'users'), where('phone', '==', phoneNumber))
    const snapshot = await getDocs(q)
    return !snapshot.empty
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setLoading(true)
    
    try {
      const phoneNumber = `+91${formData.phone.replace(/\s/g, '')}`
      
      // Check if phone number already exists
      const phoneExists = await checkPhoneExists(formData.phone)
      if (phoneExists) {
        setErrors(prev => ({ ...prev, phone: 'This phone number is already registered' }))
        toast({
          title: 'Phone Already Registered',
          description: 'A worker with this phone number already exists.',
          variant: 'destructive'
        })
        setLoading(false)
        return
      }
      
      // Create user document in Firestore
      // Using phone number as document ID (without + sign for valid Firestore ID)
      const docId = phoneNumber.replace('+', '')
      
      const userDoc = {
        name: formData.name.trim(),
        phone: phoneNumber,
        department: formData.department || 'General Labour',
        role: formData.role,
        risk_score: 0, // Default low risk for new employees
        createdAt: serverTimestamp(),
        status: 'active',
        authMethod: 'phone'
      }
      
      // Use phone-based ID for the document
      await setDoc(doc(db, 'users', docId), userDoc)
      
      setSuccess(true)
      toast({
        title: 'Employee Added Successfully',
        description: `${formData.name} can now login using phone: ${phoneNumber}`,
        variant: 'success'
      })
      
      // Reset form after short delay
      setTimeout(() => {
        setFormData({
          name: '',
          phone: '',
          department: '',
          role: 'Worker'
        })
        setSuccess(false)
      }, 2000)
      
    } catch (error) {
      console.error('Error adding employee:', error)
      toast({
        title: 'Error',
        description: 'Failed to add employee. Please try again.',
        variant: 'destructive'
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      {/* Page Header */}
      <div className="flex items-center gap-4 opacity-0 animate-fade-in">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate('/employees')}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Add New Worker</h1>
          <p className="text-muted-foreground">
            Register a new worker with phone login.
          </p>
        </div>
      </div>

      {/* Form Card */}
      <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-primary/10">
              <UserPlus className="w-6 h-6 text-primary" />
            </div>
            <div>
              <CardTitle>Worker Details</CardTitle>
              <CardDescription>Enter the worker's information for phone-based login</CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name Field */}
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium flex items-center gap-2">
                <User className="w-4 h-4 text-muted-foreground" />
                Full Name <span className="text-red-500">*</span>
              </label>
              <Input
                id="name"
                placeholder="Enter worker's full name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                className={cn(
                  "bg-secondary/30",
                  errors.name && "border-red-500 focus-visible:ring-red-500"
                )}
              />
              {errors.name && (
                <p className="text-xs text-red-500 animate-fade-in">{errors.name}</p>
              )}
            </div>

            {/* Phone Field */}
            <div className="space-y-2">
              <label htmlFor="phone" className="text-sm font-medium flex items-center gap-2">
                <Phone className="w-4 h-4 text-muted-foreground" />
                Phone Number <span className="text-red-500">*</span>
              </label>
              <div className="flex">
                <div className="flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-muted-foreground text-sm font-mono">
                  +91
                </div>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter 10-digit number"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className={cn(
                    "bg-secondary/30 font-mono rounded-l-none",
                    errors.phone && "border-red-500 focus-visible:ring-red-500"
                  )}
                />
              </div>
              {errors.phone ? (
                <p className="text-xs text-red-500 animate-fade-in">{errors.phone}</p>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Worker will receive OTP on this number to login
                </p>
              )}
            </div>

            {/* Department Field */}
            <div className="space-y-2">
              <label htmlFor="department" className="text-sm font-medium flex items-center gap-2">
                <Building2 className="w-4 h-4 text-muted-foreground" />
                Department
              </label>
              <Select 
                value={formData.department} 
                onValueChange={(value) => handleChange('department', value)}
              >
                <SelectTrigger className="bg-secondary/30">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Role Field */}
            <div className="space-y-2">
              <label htmlFor="role" className="text-sm font-medium flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-muted-foreground" />
                Role
              </label>
              <Select 
                value={formData.role} 
                onValueChange={(value) => handleChange('role', value)}
              >
                <SelectTrigger className="bg-secondary/30">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(role => (
                    <SelectItem key={role} value={role}>{role}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Submit Button */}
            <div className="flex items-center gap-3 pt-4 border-t border-border/50">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/employees')}
                disabled={loading}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={loading || success}
                className={cn(
                  "flex-1 transition-all",
                  success && "bg-green-500 hover:bg-green-500"
                )}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Adding Worker...
                  </>
                ) : success ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    Worker Added!
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    Add Worker
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Info Cards */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="opacity-0 animate-fade-in border-primary/20" style={{ animationDelay: '0.2s' }}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-primary/10 text-primary mt-0.5">
                <Smartphone className="w-4 h-4" />
              </div>
              <div className="text-sm">
                <p className="font-medium">Phone OTP Login</p>
                <p className="text-muted-foreground">
                  Worker will login using OTP sent to their phone number.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="opacity-0 animate-fade-in border-blue-500/20" style={{ animationDelay: '0.25s' }}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-500 mt-0.5">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div className="text-sm">
                <p className="font-medium">Low Risk by Default</p>
                <p className="text-muted-foreground">
                  AI risk score will be calculated based on transactions.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
