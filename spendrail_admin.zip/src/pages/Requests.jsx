import { useState, useMemo } from 'react'
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  flexRender,
} from '@tanstack/react-table'
import { 
  Check, 
  X, 
  ChevronUp, 
  ChevronDown,
  Search,
  RefreshCw,
  Loader2,
  FileText,
  IndianRupee,
  QrCode
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import RiskBadge from '@/components/atoms/RiskBadge'
import { usePendingRequests } from '@/hooks/usePendingRequests'
import { formatCurrency, formatDateTime, cn } from '@/lib/utils'
import { toast } from '@/components/ui/use-toast'

function TransactionStatusBadge({ status }) {
  const statusConfig = {
    waiting_on_approval: { label: 'Waiting', color: 'text-yellow-500 bg-yellow-500/10' },
    waiting_on_manual_approval: { label: 'Manual Review', color: 'text-orange-500 bg-orange-500/10' },
    transaction_approved: { label: 'Approved', color: 'text-green-500 bg-green-500/10' },
    transaction_disapproved: { label: 'Disapproved', color: 'text-red-500 bg-red-500/10' }
  }
  
  const config = statusConfig[status] || { label: status || 'Unknown', color: 'text-muted-foreground bg-muted' }
  
  return (
    <span className={cn("px-2 py-1 rounded-full text-xs font-medium", config.color)}>
      {config.label}
    </span>
  )
}

function CategoryBadge({ category }) {
  const categoryColors = {
    food: 'text-orange-500 bg-orange-500/10',
    travel: 'text-blue-500 bg-blue-500/10',
    supplies: 'text-purple-500 bg-purple-500/10',
    equipment: 'text-cyan-500 bg-cyan-500/10',
    utilities: 'text-amber-500 bg-amber-500/10',
    other: 'text-gray-500 bg-gray-500/10'
  }
  
  const color = categoryColors[category?.toLowerCase()] || categoryColors.other
  
  return (
    <span className={cn("px-2 py-1 rounded-full text-xs font-medium capitalize", color)}>
      {category || 'Other'}
    </span>
  )
}

export default function Requests() {
  const { 
    requests, 
    loading, 
    error,
    processing,
    approveRequest, 
    rejectRequest,
    batchApprove,
    batchReject,
    refetch 
  } = usePendingRequests()
  
  const [rowSelection, setRowSelection] = useState({})
  const [sorting, setSorting] = useState([{ id: 'createdAt', desc: true }])
  const [globalFilter, setGlobalFilter] = useState('')
  
  // Rejection modal state
  const [rejectModalOpen, setRejectModalOpen] = useState(false)
  const [rejectingId, setRejectingId] = useState(null)
  const [rejectReason, setRejectReason] = useState('')
  const [isBatchReject, setIsBatchReject] = useState(false)

  // Detail modal state
  const [detailModalOpen, setDetailModalOpen] = useState(false)
  const [selectedRequest, setSelectedRequest] = useState(null)

  const columns = useMemo(() => [
    {
      id: 'select',
      header: ({ table }) => (
        <Checkbox
          checked={table.getIsAllPageRowsSelected()}
          onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
          aria-label="Select all"
        />
      ),
      cell: ({ row }) => (
        <Checkbox
          checked={row.getIsSelected()}
          onCheckedChange={(value) => row.toggleSelected(!!value)}
          aria-label="Select row"
        />
      ),
      enableSorting: false,
      enableHiding: false,
    },
    {
      accessorKey: 'userName',
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="-ml-4"
        >
          Worker
          {column.getIsSorted() === 'asc' ? (
            <ChevronUp className="ml-1 h-4 w-4" />
          ) : column.getIsSorted() === 'desc' ? (
            <ChevronDown className="ml-1 h-4 w-4" />
          ) : null}
        </Button>
      ),
      cell: ({ row }) => (
        <div>
          <div className="font-medium">{row.getValue('userName')}</div>
          <div className="text-xs text-muted-foreground">{row.original.userPhone}</div>
        </div>
      )
    },
    {
      accessorKey: 'category',
      header: 'Category',
      cell: ({ row }) => (
        <CategoryBadge category={row.getValue('category')} />
      )
    },
    {
      accessorKey: 'note',
      header: 'Note',
      cell: ({ row }) => {
        const note = row.getValue('note')
        return (
          <div className="max-w-[150px] truncate text-muted-foreground text-sm" title={note}>
            {note || '-'}
          </div>
        )
      }
    },
    {
      accessorKey: 'createdAt',
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="-ml-4"
        >
          Date
          {column.getIsSorted() === 'asc' ? (
            <ChevronUp className="ml-1 h-4 w-4" />
          ) : column.getIsSorted() === 'desc' ? (
            <ChevronDown className="ml-1 h-4 w-4" />
          ) : null}
        </Button>
      ),
      cell: ({ row }) => (
        <div className="text-muted-foreground text-sm">
          {formatDateTime(row.getValue('createdAt'))}
        </div>
      )
    },
    {
      accessorKey: 'amount',
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
          className="-ml-4"
        >
          Amount
          {column.getIsSorted() === 'asc' ? (
            <ChevronUp className="ml-1 h-4 w-4" />
          ) : column.getIsSorted() === 'desc' ? (
            <ChevronDown className="ml-1 h-4 w-4" />
          ) : null}
        </Button>
      ),
      cell: ({ row }) => (
        <div className="font-semibold font-mono flex items-center gap-1">
          <IndianRupee className="w-3 h-3" />
          {row.getValue('amount')?.toLocaleString('en-IN') || '0'}
        </div>
      )
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => (
        <TransactionStatusBadge status={row.getValue('status')} />
      )
    },
    {
      accessorKey: 'qrData',
      header: 'UPI',
      cell: ({ row }) => {
        const qrData = row.getValue('qrData')
        return qrData ? (
          <Button
            size="sm"
            variant="ghost"
            className="h-8 w-8 p-0 text-purple-500"
            onClick={() => {
              setSelectedRequest(row.original)
              setDetailModalOpen(true)
            }}
            title="View UPI Details"
          >
            <QrCode className="w-4 h-4" />
          </Button>
        ) : (
          <span className="text-muted-foreground text-xs">-</span>
        )
      }
    },
    {
      accessorKey: 'userRiskScore',
      header: 'Risk',
      cell: ({ row }) => (
        <RiskBadge score={row.getValue('userRiskScore')} showScore={false} size="sm" />
      )
    },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => {
        const status = row.original.status
        const canApprove = status === 'waiting_on_manual_approval' || status === 'waiting_on_approval'
        
        return (
          <div className="flex items-center gap-1">
            {canApprove ? (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 w-8 p-0 text-green-500 hover:text-green-400 hover:bg-green-500/10"
                  onClick={() => handleApprove(row.original.id)}
                  disabled={processing}
                  title="Approve Transaction"
                >
                  <Check className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 w-8 p-0 text-red-500 hover:text-red-400 hover:bg-red-500/10"
                  onClick={() => openRejectModal(row.original.id)}
                  disabled={processing}
                  title="Disapprove Transaction"
                >
                  <X className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <span className="text-xs text-muted-foreground px-2">
                {status === 'transaction_approved' ? '✓ Done' : '✗ Done'}
              </span>
            )}
            <Button
              size="sm"
              variant="ghost"
              className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
              onClick={() => openDetailModal(row.original)}
              title="View Details"
            >
              <FileText className="w-4 h-4" />
            </Button>
          </div>
        )
      }
    }
  ], [processing])

  const table = useReactTable({
    data: requests,
    columns,
    state: {
      sorting,
      globalFilter,
      rowSelection,
    },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onRowSelectionChange: setRowSelection,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    enableRowSelection: true,
  })

  const selectedIds = useMemo(() => {
    return Object.keys(rowSelection)
      .filter(key => rowSelection[key])
      .map(key => requests[parseInt(key)]?.id)
      .filter(Boolean)
  }, [rowSelection, requests])

  const handleApprove = async (id) => {
    try {
      await approveRequest(id)
      toast({
        title: 'Transaction Approved',
        description: 'Status updated to transaction_approved.',
        variant: 'success'
      })
    } catch (err) {
      toast({
        title: 'Error',
        description: 'Failed to approve transaction. Please try again.',
        variant: 'destructive'
      })
    }
  }

  const openRejectModal = (id, batch = false) => {
    setRejectingId(id)
    setIsBatchReject(batch)
    setRejectReason('')
    setRejectModalOpen(true)
  }

  const openDetailModal = (request) => {
    setSelectedRequest(request)
    setDetailModalOpen(true)
  }

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast({
        title: 'Reason Required',
        description: 'Please provide a reason for disapproval.',
        variant: 'destructive'
      })
      return
    }

    try {
      if (isBatchReject) {
        await batchReject(selectedIds, rejectReason)
        setRowSelection({})
        toast({
          title: 'Transactions Disapproved',
          description: `${selectedIds.length} transactions marked as transaction_disapproved.`,
          variant: 'success'
        })
      } else {
        await rejectRequest(rejectingId, rejectReason)
        toast({
          title: 'Transaction Disapproved',
          description: 'Status updated to transaction_disapproved.',
          variant: 'success'
        })
      }
      setRejectModalOpen(false)
    } catch (err) {
      toast({
        title: 'Error',
        description: 'Failed to disapprove transaction(s). Please try again.',
        variant: 'destructive'
      })
    }
  }

  const handleBatchApprove = async () => {
    try {
      await batchApprove(selectedIds)
      setRowSelection({})
      toast({
        title: 'Transactions Approved',
        description: `${selectedIds.length} transactions marked as transaction_approved.`,
        variant: 'success'
      })
    } catch (err) {
      toast({
        title: 'Error',
        description: 'Failed to approve transactions. Please try again.',
        variant: 'destructive'
      })
    }
  }

  // Parse UPI data from qrData string
  const parseUpiData = (qrData) => {
    if (!qrData) return null
    try {
      const url = new URL(qrData)
      const params = new URLSearchParams(url.search)
      return {
        pa: params.get('pa') || 'N/A',
        pn: params.get('pn') || 'N/A',
        aid: params.get('aid') || null
      }
    } catch {
      return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-1 opacity-0 animate-fade-in">
        <h1 className="text-2xl font-bold tracking-tight">All Requests</h1>
        <p className="text-muted-foreground">
          View and manage all requests sorted by latest.
        </p>
      </div>

      {/* Main Card */}
      <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.05s' }}>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Transaction List</CardTitle>
              <CardDescription>
                {loading ? 'Loading...' : `${requests.length} total requests`}
              </CardDescription>
            </div>
            
            {/* Actions Bar */}
            <div className="flex items-center gap-2">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  value={globalFilter ?? ''}
                  onChange={(e) => setGlobalFilter(e.target.value)}
                  className="pl-9 w-[180px]"
                />
              </div>
              
              {/* Refresh */}
              <Button 
                variant="outline" 
                size="icon"
                onClick={refetch}
                disabled={loading}
              >
                <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
              </Button>
            </div>
          </div>

          {/* Batch Actions */}
          {selectedIds.length > 0 && (
            <div className="flex items-center gap-2 pt-4 border-t border-border/50 animate-fade-in">
              <span className="text-sm text-muted-foreground">
                {selectedIds.length} selected
              </span>
              <Button
                size="sm"
                variant="outline"
                className="text-green-500 border-green-500/20 hover:bg-green-500/10"
                onClick={handleBatchApprove}
                disabled={processing}
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Check className="w-4 h-4 mr-1" />}
                Approve All
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-red-500 border-red-500/20 hover:bg-red-500/10"
                onClick={() => openRejectModal(null, true)}
                disabled={processing}
              >
                <X className="w-4 h-4 mr-1" />
                Disapprove All
              </Button>
            </div>
          )}
        </CardHeader>

        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center gap-4 p-4 animate-pulse">
                  <div className="w-4 h-4 rounded bg-muted" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-1/4" />
                    <div className="h-3 bg-muted rounded w-1/6" />
                  </div>
                  <div className="h-4 bg-muted rounded w-20" />
                  <div className="h-6 bg-muted rounded w-16" />
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <X className="w-12 h-12 mx-auto mb-4 text-red-500 opacity-50" />
              <h3 className="text-lg font-medium text-red-500">Error Loading Transactions</h3>
              <p className="text-muted-foreground mb-4">{error}</p>
              <Button variant="outline" onClick={refetch}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            </div>
          ) : requests.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-medium">No Requests Found</h3>
              <p className="text-muted-foreground">
                No requests in the database yet.
              </p>
            </div>
          ) : (
            <div className="rounded-lg border border-border overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full data-grid">
                  <thead>
                    {table.getHeaderGroups().map((headerGroup) => (
                      <tr key={headerGroup.id}>
                        {headerGroup.headers.map((header) => (
                          <th key={header.id} className="px-4 py-3 text-left">
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                  header.column.columnDef.header,
                                  header.getContext()
                                )}
                          </th>
                        ))}
                      </tr>
                    ))}
                  </thead>
                  <tbody>
                    {table.getRowModel().rows.map((row) => (
                      <tr 
                        key={row.id}
                        className={cn(
                          row.getIsSelected() && "bg-primary/5"
                        )}
                      >
                        {row.getVisibleCells().map((cell) => (
                          <td key={cell.id} className="px-4 py-3">
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Pagination */}
          {!loading && requests.length > 0 && (
            <div className="flex items-center justify-between pt-4">
              <div className="text-sm text-muted-foreground">
                Page {table.getState().pagination.pageIndex + 1} of{' '}
                {table.getPageCount()}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => table.previousPage()}
                  disabled={!table.getCanPreviousPage()}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => table.nextPage()}
                  disabled={!table.getCanNextPage()}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Rejection Modal */}
      <Dialog open={rejectModalOpen} onOpenChange={setRejectModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Disapprove Transaction</DialogTitle>
            <DialogDescription>
              {isBatchReject 
                ? `You are about to disapprove ${selectedIds.length} transactions. Please provide a reason.`
                : 'Please provide a reason for disapproving this transaction.'}
            </DialogDescription>
          </DialogHeader>
          
          <Textarea
            placeholder="Enter reason for disapproval..."
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            className="min-h-[100px]"
          />
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleReject}
              disabled={processing || !rejectReason.trim()}
            >
              {processing && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Disapprove
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Modal */}
      <Dialog open={detailModalOpen} onOpenChange={setDetailModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Transaction Details</DialogTitle>
          </DialogHeader>
          
          {selectedRequest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Worker</p>
                  <p className="font-medium">{selectedRequest.userName}</p>
                  <p className="text-xs text-muted-foreground">{selectedRequest.userPhone}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="font-medium font-mono text-lg">
                    {formatCurrency(selectedRequest.amount)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Category</p>
                  <CategoryBadge category={selectedRequest.category} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Status</p>
                  <TransactionStatusBadge status={selectedRequest.status} />
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Created At</p>
                  <p className="font-medium">{formatDateTime(selectedRequest.createdAt)}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Note</p>
                  <p className="font-medium">{selectedRequest.note || 'No note'}</p>
                </div>
                
                {/* UPI Payment Details */}
                {selectedRequest.qrData && (
                  <div className="col-span-2 p-3 rounded-lg bg-purple-500/5 border border-purple-500/20">
                    <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                      <QrCode className="w-3 h-3" /> UPI Payment Details
                    </p>
                    {(() => {
                      const upi = parseUpiData(selectedRequest.qrData)
                      return upi ? (
                        <div className="space-y-1">
                          <p className="text-sm"><span className="text-muted-foreground">UPI ID:</span> <span className="font-mono">{upi.pa}</span></p>
                          <p className="text-sm"><span className="text-muted-foreground">Name:</span> {upi.pn}</p>
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground">Unable to parse UPI data</p>
                      )
                    })()}
                  </div>
                )}

                {/* Rejection Reason */}
                {selectedRequest.rejectionReason && (
                  <div className="col-span-2 p-3 rounded-lg bg-red-500/5 border border-red-500/20">
                    <p className="text-xs text-muted-foreground mb-1">Rejection Reason</p>
                    <p className="text-sm">{selectedRequest.rejectionReason}</p>
                  </div>
                )}

                {/* Voice Note */}
                {selectedRequest.voiceNoteUrl && (
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground mb-2">Voice Note</p>
                    <audio controls className="w-full">
                      <source src={selectedRequest.voiceNoteUrl} type="audio/webm" />
                      Your browser does not support audio.
                    </audio>
                  </div>
                )}
              </div>
              
              {(selectedRequest.status === 'waiting_on_manual_approval' || selectedRequest.status === 'waiting_on_approval') && (
                <div className="flex gap-2 pt-4 border-t border-border">
                  <Button
                    className="flex-1"
                    variant="outline"
                    onClick={() => {
                      setDetailModalOpen(false)
                      openRejectModal(selectedRequest.id)
                    }}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Disapprove
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={() => {
                      handleApprove(selectedRequest.id)
                      setDetailModalOpen(false)
                    }}
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
