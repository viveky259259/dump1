import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { 
  Search, 
  RefreshCw, 
  Users, 
  UserPlus,
  Building2,
  Wallet,
  Filter
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import RiskBadge, { RiskIndicator } from '@/components/atoms/RiskBadge'
import { useEmployees, useDepartments } from '@/hooks/useEmployees'
import { formatCurrency, getInitials, getRiskLevel, cn } from '@/lib/utils'

function EmployeeCard({ employee, index }) {
  const riskLevel = getRiskLevel(employee.risk_score || 0)
  
  return (
    <Card 
      className={cn(
        "relative opacity-0 animate-fade-in overflow-hidden group hover:shadow-lg transition-all duration-300",
        riskLevel === 'high' && "border-red-500/30",
        riskLevel === 'medium' && "border-yellow-500/30",
        riskLevel === 'low' && "border-green-500/30"
      )}
      style={{ animationDelay: `${0.05 * index}s` }}
    >
      {/* Risk indicator border/glow */}
      <RiskIndicator score={employee.risk_score || 0} className="group-hover:opacity-100" />
      
      <CardContent className="p-4 relative z-10">
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <Avatar className={cn(
            "w-12 h-12 border-2 transition-all",
            riskLevel === 'high' && "border-red-500/50",
            riskLevel === 'medium' && "border-yellow-500/50",
            riskLevel === 'low' && "border-green-500/50"
          )}>
            <AvatarImage src={employee.photoURL} />
            <AvatarFallback className={cn(
              "text-sm font-medium",
              riskLevel === 'high' && "bg-red-500/10 text-red-500",
              riskLevel === 'medium' && "bg-yellow-500/10 text-yellow-500",
              riskLevel === 'low' && "bg-green-500/10 text-green-500"
            )}>
              {getInitials(employee.name)}
            </AvatarFallback>
          </Avatar>
          
          {/* Info */}
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold truncate">{employee.name || 'Unknown'}</h3>
            <p className="text-sm text-muted-foreground truncate">{employee.role || 'Employee'}</p>
            
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Building2 className="w-3 h-3" />
                <span>{employee.department || 'N/A'}</span>
              </div>
            </div>
          </div>
          
          {/* Risk Badge */}
          <RiskBadge score={employee.risk_score || 0} size="sm" />
        </div>
        
        {/* Bottom Stats */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50">
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Pending:</span>
          </div>
          <span className={cn(
            "font-semibold font-mono text-sm",
            employee.pendingAmount > 0 && "text-yellow-500"
          )}>
            {formatCurrency(employee.pendingAmount || 0)}
          </span>
        </div>
      </CardContent>
    </Card>
  )
}

export default function Employees() {
  const navigate = useNavigate()
  const { employees, loading, refetch } = useEmployees()
  const departments = useDepartments(employees)
  
  const [searchQuery, setSearchQuery] = useState('')
  const [departmentFilter, setDepartmentFilter] = useState('all')
  
  // Filtered employees
  const filteredEmployees = useMemo(() => {
    return employees.filter(employee => {
      // Search filter
      const matchesSearch = !searchQuery || 
        employee.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        employee.email?.toLowerCase().includes(searchQuery.toLowerCase())
      
      // Department filter
      const matchesDepartment = departmentFilter === 'all' || 
        employee.department === departmentFilter
      
      return matchesSearch && matchesDepartment
    })
  }, [employees, searchQuery, departmentFilter])
  
  // Stats
  const stats = useMemo(() => {
    const highRisk = employees.filter(e => getRiskLevel(e.risk_score || 0) === 'high').length
    const mediumRisk = employees.filter(e => getRiskLevel(e.risk_score || 0) === 'medium').length
    const lowRisk = employees.filter(e => getRiskLevel(e.risk_score || 0) === 'low').length
    
    return { highRisk, mediumRisk, lowRisk }
  }, [employees])

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 opacity-0 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Employee Directory</h1>
          <p className="text-muted-foreground">
            Manage employees and monitor AI risk indicators.
          </p>
        </div>
        <Button onClick={() => navigate('/employees/add')}>
          <UserPlus className="w-4 h-4" />
          Add Employee
        </Button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 opacity-0 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <Card className="border-border/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{employees.length}</p>
              <p className="text-xs text-muted-foreground">Total Employees</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-green-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/10 text-green-500">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-500">{stats.lowRisk}</p>
              <p className="text-xs text-muted-foreground">Low Risk</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-yellow-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-yellow-500/10 text-yellow-500">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-500">{stats.mediumRisk}</p>
              <p className="text-xs text-muted-foreground">Medium Risk</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-red-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-500/10 text-red-500">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-red-500">{stats.highRisk}</p>
              <p className="text-xs text-muted-foreground">High Risk</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="opacity-0 animate-fade-in" style={{ animationDelay: '0.15s' }}>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            
            {/* Department Filter */}
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="All Departments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {/* Refresh */}
            <Button 
              variant="outline" 
              size="icon"
              onClick={refetch}
              disabled={loading}
            >
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Employee Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-muted" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-1/2" />
                    <div className="h-3 bg-muted rounded w-1/3" />
                  </div>
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50">
                  <div className="h-4 bg-muted rounded w-1/4" />
                  <div className="h-4 bg-muted rounded w-1/4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredEmployees.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-medium">No Employees Found</h3>
            <p className="text-muted-foreground">
              {searchQuery || departmentFilter !== 'all' 
                ? 'Try adjusting your search or filter criteria.'
                : 'No employees have been added yet.'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEmployees.map((employee, index) => (
            <EmployeeCard key={employee.id} employee={employee} index={index} />
          ))}
        </div>
      )}
    </div>
  )
}

