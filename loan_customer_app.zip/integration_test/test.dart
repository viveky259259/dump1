import 'dart:io';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:integration_test/integration_test.dart';
import 'package:loan_customer_app/flutter_flow/flutter_flow_icon_button.dart';
import 'package:loan_customer_app/flutter_flow/flutter_flow_widgets.dart';
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:loan_customer_app/index.dart';
import 'package:loan_customer_app/main.dart';
import 'package:loan_customer_app/flutter_flow/flutter_flow_util.dart';

import 'package:provider/provider.dart';

void main() async {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {});

  setUp(() async {
    FFAppState.reset();
    final appState = FFAppState();
    await appState.initializePersistedState();
  });

  testWidgets('Check Retail', (WidgetTester tester) async {
    _overrideOnError();

    await tester.pumpWidget(MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => FFAppState(),
        ),
      ],
      child: MyApp(
        entryPage: LoginPageWidget(),
      ),
    ));
    await GoogleFonts.pendingFonts();

    await tester.enterText(
        find.byKey(const ValueKey('email_9g8z')), 'ayush@flutterflow.io');
    await tester.pumpAndSettle();
    await tester.enterText(
        find.byKey(const ValueKey('password_j198')), '123456');
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('SignInButton_2hfj')));
    await tester.pumpAndSettle(
      const Duration(milliseconds: 2000),
      EnginePhase.sendSemanticsUpdate,
      const Duration(milliseconds: 3000),
    );
    expect(find.text('Retail'), findsOneWidget);
  });

  testWidgets('Check Corporate', (WidgetTester tester) async {
    _overrideOnError();

    await tester.pumpWidget(MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => FFAppState(),
        ),
      ],
      child: MyApp(
        entryPage: LoginPageWidget(),
      ),
    ));
    await GoogleFonts.pendingFonts();

    await tester.enterText(
        find.byKey(const ValueKey('email_9g8z')), 'vivek@flutterflow.io');
    await tester.pumpAndSettle();
    await tester.enterText(
        find.byKey(const ValueKey('password_j198')), '123456');
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('isCorporate_98y2')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('SignInButton_2hfj')));
    await tester.pumpAndSettle(
      const Duration(milliseconds: 2000),
      EnginePhase.sendSemanticsUpdate,
      const Duration(milliseconds: 3000),
    );
    expect(find.text('Corporate'), findsOneWidget);
  });
}

// There are certain types of errors that can happen during tests but
// should not break the test.
void _overrideOnError() {
  final originalOnError = FlutterError.onError!;
  FlutterError.onError = (errorDetails) {
    if (_shouldIgnoreError(errorDetails.toString())) {
      return;
    }
    originalOnError(errorDetails);
  };
}

bool _shouldIgnoreError(String error) {
  // It can fail to decode some SVGs - this should not break the test.
  if (error.contains('ImageCodecException')) {
    return true;
  }
  // Overflows happen all over the place,
  // but they should not break tests.
  if (error.contains('overflowed by')) {
    return true;
  }
  // Sometimes some images fail to load, it generally does not break the test.
  if (error.contains('No host specified in URI') ||
      error.contains('EXCEPTION CAUGHT BY IMAGE RESOURCE SERVICE')) {
    return true;
  }
  // These errors should be avoided, but they should not break the test.
  if (error.contains('setState() called after dispose()')) {
    return true;
  }
  // Web-specific error when interacting with TextInputType.emailAddress
  if (error.contains('setSelectionRange') &&
      error.contains('HTMLInputElement')) {
    return true;
  }

  return false;
}
