// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserAuthStruct extends BaseStruct {
  UserAuthStruct({
    String? accessToken,
    String? tokenType,
    int? expiresIn,
    String? refreshToken,
    UserStruct? user,
  })  : _accessToken = accessToken,
        _tokenType = tokenType,
        _expiresIn = expiresIn,
        _refreshToken = refreshToken,
        _user = user;

  // "accessToken" field.
  String? _accessToken;
  String get accessToken => _accessToken ?? '';
  set accessToken(String? val) => _accessToken = val;

  bool hasAccessToken() => _accessToken != null;

  // "tokenType" field.
  String? _tokenType;
  String get tokenType => _tokenType ?? '';
  set tokenType(String? val) => _tokenType = val;

  bool hasTokenType() => _tokenType != null;

  // "expiresIn" field.
  int? _expiresIn;
  int get expiresIn => _expiresIn ?? 0;
  set expiresIn(int? val) => _expiresIn = val;

  void incrementExpiresIn(int amount) => expiresIn = expiresIn + amount;

  bool hasExpiresIn() => _expiresIn != null;

  // "refreshToken" field.
  String? _refreshToken;
  String get refreshToken => _refreshToken ?? '';
  set refreshToken(String? val) => _refreshToken = val;

  bool hasRefreshToken() => _refreshToken != null;

  // "user" field.
  UserStruct? _user;
  UserStruct get user => _user ?? UserStruct();
  set user(UserStruct? val) => _user = val;

  void updateUser(Function(UserStruct) updateFn) {
    updateFn(_user ??= UserStruct());
  }

  bool hasUser() => _user != null;

  static UserAuthStruct fromMap(Map<String, dynamic> data) => UserAuthStruct(
        accessToken: data['accessToken'] as String?,
        tokenType: data['tokenType'] as String?,
        expiresIn: castToType<int>(data['expiresIn']),
        refreshToken: data['refreshToken'] as String?,
        user: data['user'] is UserStruct
            ? data['user']
            : UserStruct.maybeFromMap(data['user']),
      );

  static UserAuthStruct? maybeFromMap(dynamic data) =>
      data is Map ? UserAuthStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'accessToken': _accessToken,
        'tokenType': _tokenType,
        'expiresIn': _expiresIn,
        'refreshToken': _refreshToken,
        'user': _user?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'accessToken': serializeParam(
          _accessToken,
          ParamType.String,
        ),
        'tokenType': serializeParam(
          _tokenType,
          ParamType.String,
        ),
        'expiresIn': serializeParam(
          _expiresIn,
          ParamType.int,
        ),
        'refreshToken': serializeParam(
          _refreshToken,
          ParamType.String,
        ),
        'user': serializeParam(
          _user,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static UserAuthStruct fromSerializableMap(Map<String, dynamic> data) =>
      UserAuthStruct(
        accessToken: deserializeParam(
          data['accessToken'],
          ParamType.String,
          false,
        ),
        tokenType: deserializeParam(
          data['tokenType'],
          ParamType.String,
          false,
        ),
        expiresIn: deserializeParam(
          data['expiresIn'],
          ParamType.int,
          false,
        ),
        refreshToken: deserializeParam(
          data['refreshToken'],
          ParamType.String,
          false,
        ),
        user: deserializeStructParam(
          data['user'],
          ParamType.DataStruct,
          false,
          structBuilder: UserStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'UserAuthStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UserAuthStruct &&
        accessToken == other.accessToken &&
        tokenType == other.tokenType &&
        expiresIn == other.expiresIn &&
        refreshToken == other.refreshToken &&
        user == other.user;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([accessToken, tokenType, expiresIn, refreshToken, user]);
}

UserAuthStruct createUserAuthStruct({
  String? accessToken,
  String? tokenType,
  int? expiresIn,
  String? refreshToken,
  UserStruct? user,
}) =>
    UserAuthStruct(
      accessToken: accessToken,
      tokenType: tokenType,
      expiresIn: expiresIn,
      refreshToken: refreshToken,
      user: user ?? UserStruct(),
    );
