// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AccountStatusStruct extends BaseStruct {
  AccountStatusStruct({
    String? accountStatus,
    int? amountSaction,
  })  : _accountStatus = accountStatus,
        _amountSaction = amountSaction;

  // "account_status" field.
  String? _accountStatus;
  String get accountStatus => _accountStatus ?? '';
  set accountStatus(String? val) => _accountStatus = val;

  bool hasAccountStatus() => _accountStatus != null;

  // "amount_saction" field.
  int? _amountSaction;
  int get amountSaction => _amountSaction ?? 0;
  set amountSaction(int? val) => _amountSaction = val;

  void incrementAmountSaction(int amount) =>
      amountSaction = amountSaction + amount;

  bool hasAmountSaction() => _amountSaction != null;

  static AccountStatusStruct fromMap(Map<String, dynamic> data) =>
      AccountStatusStruct(
        accountStatus: data['account_status'] as String?,
        amountSaction: castToType<int>(data['amount_saction']),
      );

  static AccountStatusStruct? maybeFromMap(dynamic data) => data is Map
      ? AccountStatusStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'account_status': _accountStatus,
        'amount_saction': _amountSaction,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'account_status': serializeParam(
          _accountStatus,
          ParamType.String,
        ),
        'amount_saction': serializeParam(
          _amountSaction,
          ParamType.int,
        ),
      }.withoutNulls;

  static AccountStatusStruct fromSerializableMap(Map<String, dynamic> data) =>
      AccountStatusStruct(
        accountStatus: deserializeParam(
          data['account_status'],
          ParamType.String,
          false,
        ),
        amountSaction: deserializeParam(
          data['amount_saction'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'AccountStatusStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AccountStatusStruct &&
        accountStatus == other.accountStatus &&
        amountSaction == other.amountSaction;
  }

  @override
  int get hashCode => const ListEquality().hash([accountStatus, amountSaction]);
}

AccountStatusStruct createAccountStatusStruct({
  String? accountStatus,
  int? amountSaction,
}) =>
    AccountStatusStruct(
      accountStatus: accountStatus,
      amountSaction: amountSaction,
    );
