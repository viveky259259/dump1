// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserStruct extends BaseStruct {
  UserStruct({
    String? id,
    String? username,
    String? email,
    String? name,
    String? type,
    String? accountStatus,
    int? sactionAmount,
  })  : _id = id,
        _username = username,
        _email = email,
        _name = name,
        _type = type,
        _accountStatus = accountStatus,
        _sactionAmount = sactionAmount;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  set id(String? val) => _id = val;

  bool hasId() => _id != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  set username(String? val) => _username = val;

  bool hasUsername() => _username != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;

  bool hasEmail() => _email != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  set type(String? val) => _type = val;

  bool hasType() => _type != null;

  // "account_status" field.
  String? _accountStatus;
  String get accountStatus => _accountStatus ?? '';
  set accountStatus(String? val) => _accountStatus = val;

  bool hasAccountStatus() => _accountStatus != null;

  // "saction_amount" field.
  int? _sactionAmount;
  int get sactionAmount => _sactionAmount ?? 0;
  set sactionAmount(int? val) => _sactionAmount = val;

  void incrementSactionAmount(int amount) =>
      sactionAmount = sactionAmount + amount;

  bool hasSactionAmount() => _sactionAmount != null;

  static UserStruct fromMap(Map<String, dynamic> data) => UserStruct(
        id: data['id'] as String?,
        username: data['username'] as String?,
        email: data['email'] as String?,
        name: data['name'] as String?,
        type: data['type'] as String?,
        accountStatus: data['account_status'] as String?,
        sactionAmount: castToType<int>(data['saction_amount']),
      );

  static UserStruct? maybeFromMap(dynamic data) =>
      data is Map ? UserStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'id': _id,
        'username': _username,
        'email': _email,
        'name': _name,
        'type': _type,
        'account_status': _accountStatus,
        'saction_amount': _sactionAmount,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'id': serializeParam(
          _id,
          ParamType.String,
        ),
        'username': serializeParam(
          _username,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'type': serializeParam(
          _type,
          ParamType.String,
        ),
        'account_status': serializeParam(
          _accountStatus,
          ParamType.String,
        ),
        'saction_amount': serializeParam(
          _sactionAmount,
          ParamType.int,
        ),
      }.withoutNulls;

  static UserStruct fromSerializableMap(Map<String, dynamic> data) =>
      UserStruct(
        id: deserializeParam(
          data['id'],
          ParamType.String,
          false,
        ),
        username: deserializeParam(
          data['username'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        type: deserializeParam(
          data['type'],
          ParamType.String,
          false,
        ),
        accountStatus: deserializeParam(
          data['account_status'],
          ParamType.String,
          false,
        ),
        sactionAmount: deserializeParam(
          data['saction_amount'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'UserStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UserStruct &&
        id == other.id &&
        username == other.username &&
        email == other.email &&
        name == other.name &&
        type == other.type &&
        accountStatus == other.accountStatus &&
        sactionAmount == other.sactionAmount;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([id, username, email, name, type, accountStatus, sactionAmount]);
}

UserStruct createUserStruct({
  String? id,
  String? username,
  String? email,
  String? name,
  String? type,
  String? accountStatus,
  int? sactionAmount,
}) =>
    UserStruct(
      id: id,
      username: username,
      email: email,
      name: name,
      type: type,
      accountStatus: accountStatus,
      sactionAmount: sactionAmount,
    );
