import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'package:ff_commons/api_requests/api_manager.dart';

import 'package:ff_commons/api_requests/api_paging_params.dart';

export 'package:ff_commons/api_requests/api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start Auth Group Code

class AuthGroup {
  static String getBaseUrl() => 'https://mocki.io/v1';
  static Map<String, String> headers = {};
  static LoginCorporateCall loginCorporateCall = LoginCorporateCall();
  static LoginRetailCall loginRetailCall = LoginRetailCall();
}

class LoginCorporateCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = AuthGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Login  Corporate',
      apiUrl: '${baseUrl}/95bf2166-1a51-462e-bf0d-8710aca57734',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class LoginRetailCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = AuthGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Login Retail',
      apiUrl: '${baseUrl}/393d44ac-d5b7-4735-8788-d37e07b401bc',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End Auth Group Code

/// Start Account Group Code

class AccountGroup {
  static String getBaseUrl() => 'https://mocki.io/v1';
  static Map<String, String> headers = {};
  static AccountStatusCorporateCall accountStatusCorporateCall =
      AccountStatusCorporateCall();
  static AccountStatusRetailCall accountStatusRetailCall =
      AccountStatusRetailCall();
}

class AccountStatusCorporateCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = AccountGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Account Status Corporate',
      apiUrl: '${baseUrl}/4289e877-7e96-4108-83f7-a59282d5d448',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class AccountStatusRetailCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = AccountGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Account Status Retail',
      apiUrl: '${baseUrl}/60c3dc4e-2b00-41db-a9f5-6663b7ca5093',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End Account Group Code

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
