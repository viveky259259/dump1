import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:convert';
import 'dart:ui';
import '/index.dart';
import 'package:loan_u_i_components_jviats/components/account_verification_component_widget.dart'
    as loan_u_i_components_jviats;
import 'package:loan_u_i_components_jviats/components/apply_loan_component_widget.dart'
    as loan_u_i_components_jviats;
import 'package:loan_u_i_components_jviats/flutter_flow/flutter_flow_util.dart'
    as loan_u_i_components_jviats_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dashboard_page_model.dart';
export 'dashboard_page_model.dart';

class DashboardPageWidget extends StatefulWidget {
  const DashboardPageWidget({super.key});

  static String routeName = 'DashboardPage';
  static String routePath = '/dashboardPage';

  @override
  State<DashboardPageWidget> createState() => _DashboardPageWidgetState();
}

class _DashboardPageWidgetState extends State<DashboardPageWidget> {
  late DashboardPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DashboardPageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      if (FFAppState().LoggedInUser.type == 'corporate') {
        // CorporateAPI
        _model.corporateApiResponse =
            await AccountGroup.accountStatusCorporateCall.call();

        if ((_model.corporateApiResponse?.succeeded ?? true)) {
          FFAppState().updateLoggedInUserStruct(
            (e) => e
              ..accountStatus = AccountStatusStruct.maybeFromMap(
                      (_model.corporateApiResponse?.jsonBody ?? ''))
                  ?.accountStatus
              ..sactionAmount = AccountStatusStruct.maybeFromMap(
                      (_model.corporateApiResponse?.jsonBody ?? ''))
                  ?.amountSaction,
          );
          safeSetState(() {});
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Something went wrong!',
                style: TextStyle(
                  color: FlutterFlowTheme.of(context).primaryText,
                ),
              ),
              duration: Duration(milliseconds: 4000),
              backgroundColor: FlutterFlowTheme.of(context).secondary,
            ),
          );
        }
      } else {
        // Retail API
        _model.retailApiResponse =
            await AccountGroup.accountStatusRetailCall.call();

        if ((_model.retailApiResponse?.succeeded ?? true)) {
          FFAppState().updateLoggedInUserStruct(
            (e) => e
              ..accountStatus = AccountStatusStruct.maybeFromMap(
                      (_model.retailApiResponse?.jsonBody ?? ''))
                  ?.accountStatus
              ..sactionAmount = AccountStatusStruct.maybeFromMap(
                      (_model.retailApiResponse?.jsonBody ?? ''))
                  ?.amountSaction,
          );
          safeSetState(() {});
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Something went wrong!',
                style: TextStyle(
                  color: FlutterFlowTheme.of(context).primaryText,
                ),
              ),
              duration: Duration(milliseconds: 4000),
              backgroundColor: FlutterFlowTheme.of(context).secondary,
            ),
          );
        }
      }
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Welcome. ${FFAppState().LoggedInUser.name} !',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  font: GoogleFonts.interTight(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                  ),
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                ),
          ),
          actions: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 16.0, 0.0),
              child: FlutterFlowIconButton(
                borderRadius: 8.0,
                buttonSize: 40.0,
                fillColor: FlutterFlowTheme.of(context).primary,
                icon: Icon(
                  Icons.login,
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  size: 24.0,
                ),
                onPressed: () async {
                  FFAppState().deleteLoggedInUser();
                  FFAppState().LoggedInUser = UserStruct();

                  FFAppState().deleteLoggedInUserAuthDetails();
                  FFAppState().LoggedInUserAuthDetails = UserAuthStruct();

                  safeSetState(() {});
                  if (Navigator.of(context).canPop()) {
                    context.pop();
                  }
                  context.pushNamed(LoginPageWidget.routeName);
                },
              ),
            ),
          ],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                  child: loan_u_i_components_jviats_util.wrapWithModel(
                    model: _model.accountVerificationComponentModel,
                    updateCallback: () => safeSetState(() {}),
                    child: loan_u_i_components_jviats
                        .AccountVerificationComponentWidget(
                      name: FFAppState().LoggedInUser.name,
                      email: FFAppState().LoggedInUser.email,
                      userName: FFAppState().LoggedInUser.username,
                      accountType: FFAppState().LoggedInUser.type,
                      accountStatus: FFAppState().LoggedInUser.accountStatus,
                    ),
                  ),
                ),
                if (FFAppState().LoggedInUser.accountStatus == 'approved')
                  loan_u_i_components_jviats_util.wrapWithModel(
                    model: _model.applyLoanComponentModel,
                    updateCallback: () => safeSetState(() {}),
                    child:
                        loan_u_i_components_jviats.ApplyLoanComponentWidget(),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
