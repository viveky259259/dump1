import '/backend/api_requests/api_calls.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:convert';
import 'dart:ui';
import '/index.dart';
import 'dashboard_page_widget.dart' show DashboardPageWidget;
import 'package:loan_u_i_components_jviats/components/account_verification_component_widget.dart'
    as loan_u_i_components_jviats;
import 'package:loan_u_i_components_jviats/components/apply_loan_component_widget.dart'
    as loan_u_i_components_jviats;
import 'package:loan_u_i_components_jviats/flutter_flow/flutter_flow_util.dart'
    as loan_u_i_components_jviats_util
    show wrapWithModel, createModel, FlutterFlowDynamicModels;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DashboardPageModel extends FlutterFlowModel<DashboardPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Account Status Corporate)] action in DashboardPage widget.
  ApiCallResponse? corporateApiResponse;
  // Stores action output result for [Backend Call - API (Account Status Retail)] action in DashboardPage widget.
  ApiCallResponse? retailApiResponse;
  // Model for AccountVerificationComponent component.
  late loan_u_i_components_jviats.AccountVerificationComponentModel
      accountVerificationComponentModel;
  // Model for ApplyLoanComponent component.
  late loan_u_i_components_jviats.ApplyLoanComponentModel
      applyLoanComponentModel;

  @override
  void initState(BuildContext context) {
    accountVerificationComponentModel =
        loan_u_i_components_jviats_util.createModel(
            context,
            () =>
                loan_u_i_components_jviats.AccountVerificationComponentModel());
    applyLoanComponentModel = loan_u_i_components_jviats_util.createModel(
        context, () => loan_u_i_components_jviats.ApplyLoanComponentModel());
  }

  @override
  void dispose() {
    accountVerificationComponentModel.dispose();
    applyLoanComponentModel.dispose();
  }
}
