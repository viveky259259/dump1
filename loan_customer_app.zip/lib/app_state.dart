import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:ff_commons/api_requests/api_manager.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = FlutterSecureStorage();
    await _safeInitAsync(() async {
      if (await secureStorage.read(key: 'ff_LoggedInUser') != null) {
        try {
          final serializedData =
              await secureStorage.getString('ff_LoggedInUser') ?? '{}';
          _LoggedInUser =
              UserStruct.fromSerializableMap(jsonDecode(serializedData));
        } catch (e) {
          print("Can't decode persisted data type. Error: $e.");
        }
      }
    });
    await _safeInitAsync(() async {
      if (await secureStorage.read(key: 'ff_LoggedInUserAuthDetails') != null) {
        try {
          final serializedData =
              await secureStorage.getString('ff_LoggedInUserAuthDetails') ??
                  '{}';
          _LoggedInUserAuthDetails =
              UserAuthStruct.fromSerializableMap(jsonDecode(serializedData));
        } catch (e) {
          print("Can't decode persisted data type. Error: $e.");
        }
      }
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  UserStruct _LoggedInUser = UserStruct();
  UserStruct get LoggedInUser => _LoggedInUser;
  set LoggedInUser(UserStruct value) {
    _LoggedInUser = value;
    secureStorage.setString('ff_LoggedInUser', value.serialize());
  }

  void deleteLoggedInUser() {
    secureStorage.delete(key: 'ff_LoggedInUser');
  }

  void updateLoggedInUserStruct(Function(UserStruct) updateFn) {
    updateFn(_LoggedInUser);
    secureStorage.setString('ff_LoggedInUser', _LoggedInUser.serialize());
  }

  UserAuthStruct _LoggedInUserAuthDetails = UserAuthStruct();
  UserAuthStruct get LoggedInUserAuthDetails => _LoggedInUserAuthDetails;
  set LoggedInUserAuthDetails(UserAuthStruct value) {
    _LoggedInUserAuthDetails = value;
    secureStorage.setString('ff_LoggedInUserAuthDetails', value.serialize());
  }

  void deleteLoggedInUserAuthDetails() {
    secureStorage.delete(key: 'ff_LoggedInUserAuthDetails');
  }

  void updateLoggedInUserAuthDetailsStruct(Function(UserAuthStruct) updateFn) {
    updateFn(_LoggedInUserAuthDetails);
    secureStorage.setString(
        'ff_LoggedInUserAuthDetails', _LoggedInUserAuthDetails.serialize());
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: ListToCsvConverter().convert([value]));
}
