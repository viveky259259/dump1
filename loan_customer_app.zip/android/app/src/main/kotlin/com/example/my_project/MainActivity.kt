package com.mycompany.loancustomerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
