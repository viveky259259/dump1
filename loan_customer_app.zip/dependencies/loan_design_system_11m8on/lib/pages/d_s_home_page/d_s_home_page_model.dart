import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'd_s_home_page_widget.dart' show DSHomePageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DSHomePageModel extends FlutterFlowModel<DSHomePageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
