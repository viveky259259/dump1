import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'u_i_components_home_page_widget.dart' show UIComponentsHomePageWidget;
import 'package:ff_theme/flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class UIComponentsHomePageModel
    extends FlutterFlowModel<UIComponentsHomePageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
