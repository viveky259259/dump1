#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/vivekyadav/Library/Application Support/io.flutterflow.prod.mac/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/vivekyadav/Documents/dreamflow/family_and_household/family_household_management_app"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/vivekyadav/Documents/dreamflow/family_and_household/family_household_management_app/test/test_analytics.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1.0.0"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/vivekyadav/Documents/dreamflow/family_and_household/family_household_management_app/.dart_tool/package_config.json"
