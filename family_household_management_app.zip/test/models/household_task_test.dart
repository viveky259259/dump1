import 'package:flutter_test/flutter_test.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/models/household_task.dart';

void main() {
  group('HouseholdTask', () {
    late HouseholdTask testTask;
    late DateTime testDate;
    late DateTime dueDate;

    setUp(() {
      testDate = DateTime(2024, 1, 15, 10, 30);
      dueDate = DateTime(2024, 1, 20, 14, 0);
      testTask = HouseholdTask(
        id: 'task-123',
        title: 'Clean the kitchen',
        description: 'Wash dishes and clean countertops',
        assignedMemberId: 'member-1',
        dueDate: dueDate,
        category: 'Cleaning',
        priority: 'High',
        isCompleted: false,
        isRecurring: true,
        recurringPattern: 'Weekly',
        createdAt: testDate,
      );
    });

    group('Constructor', () {
      test('should create HouseholdTask with all required fields', () {
        expect(testTask.id, equals('task-123'));
        expect(testTask.title, equals('Clean the kitchen'));
        expect(
            testTask.description, equals('Wash dishes and clean countertops'));
        expect(testTask.assignedMemberId, equals('member-1'));
        expect(testTask.dueDate, equals(dueDate));
        expect(testTask.category, equals('Cleaning'));
        expect(testTask.priority, equals('High'));
        expect(testTask.isCompleted, isFalse);
        expect(testTask.completedAt, isNull);
        expect(testTask.completedByMemberId, isNull);
        expect(testTask.isRecurring, isTrue);
        expect(testTask.recurringPattern, equals('Weekly'));
        expect(testTask.createdAt, equals(testDate));
      });

      test('should create completed task with completion details', () {
        final completedDate = DateTime(2024, 1, 18, 16, 30);
        final completedTask = HouseholdTask(
          id: 'task-456',
          title: 'Take out trash',
          description: 'Weekly garbage pickup',
          assignedMemberId: 'member-2',
          dueDate: dueDate,
          category: 'Cleaning',
          priority: 'Medium',
          isCompleted: true,
          completedAt: completedDate,
          completedByMemberId: 'member-2',
          isRecurring: true,
          recurringPattern: 'Weekly',
          createdAt: testDate,
        );

        expect(completedTask.isCompleted, isTrue);
        expect(completedTask.completedAt, equals(completedDate));
        expect(completedTask.completedByMemberId, equals('member-2'));
      });
    });

    group('toJson', () {
      test('should convert HouseholdTask to JSON correctly', () {
        final json = testTask.toJson();

        expect(json['id'], equals('task-123'));
        expect(json['title'], equals('Clean the kitchen'));
        expect(
            json['description'], equals('Wash dishes and clean countertops'));
        expect(json['assignedMemberId'], equals('member-1'));
        expect(json['dueDate'], equals(dueDate.toIso8601String()));
        expect(json['category'], equals('Cleaning'));
        expect(json['priority'], equals('High'));
        expect(json['isCompleted'], isFalse);
        expect(json['completedAt'], isNull);
        expect(json['completedByMemberId'], isNull);
        expect(json['isRecurring'], isTrue);
        expect(json['recurringPattern'], equals('Weekly'));
        expect(json['createdAt'], equals(testDate.toIso8601String()));
      });

      test('should handle completed task in JSON', () {
        final completedDate = DateTime(2024, 1, 18, 16, 30);
        final completedTask = testTask.copyWith(
          isCompleted: true,
          completedAt: completedDate,
          completedByMemberId: 'member-1',
        );

        final json = completedTask.toJson();

        expect(json['isCompleted'], isTrue);
        expect(json['completedAt'], equals(completedDate.toIso8601String()));
        expect(json['completedByMemberId'], equals('member-1'));
      });
    });

    group('fromJson', () {
      test('should create HouseholdTask from JSON correctly', () {
        final json = {
          'id': 'task-123',
          'title': 'Clean the kitchen',
          'description': 'Wash dishes and clean countertops',
          'assignedMemberId': 'member-1',
          'dueDate': dueDate.toIso8601String(),
          'category': 'Cleaning',
          'priority': 'High',
          'isCompleted': false,
          'completedAt': null,
          'completedByMemberId': null,
          'isRecurring': true,
          'recurringPattern': 'Weekly',
          'createdAt': testDate.toIso8601String(),
        };

        final task = HouseholdTask.fromJson(json);

        expect(task.id, equals('task-123'));
        expect(task.title, equals('Clean the kitchen'));
        expect(task.description, equals('Wash dishes and clean countertops'));
        expect(task.assignedMemberId, equals('member-1'));
        expect(task.dueDate, equals(dueDate));
        expect(task.category, equals('Cleaning'));
        expect(task.priority, equals('High'));
        expect(task.isCompleted, isFalse);
        expect(task.completedAt, isNull);
        expect(task.completedByMemberId, isNull);
        expect(task.isRecurring, isTrue);
        expect(task.recurringPattern, equals('Weekly'));
        expect(task.createdAt, equals(testDate));
      });

      test('should handle completed task from JSON', () {
        final completedDate = DateTime(2024, 1, 18, 16, 30);
        final json = {
          'id': 'task-123',
          'title': 'Clean the kitchen',
          'description': 'Wash dishes and clean countertops',
          'assignedMemberId': 'member-1',
          'dueDate': dueDate.toIso8601String(),
          'category': 'Cleaning',
          'priority': 'High',
          'isCompleted': true,
          'completedAt': completedDate.toIso8601String(),
          'completedByMemberId': 'member-1',
          'isRecurring': true,
          'recurringPattern': 'Weekly',
          'createdAt': testDate.toIso8601String(),
        };

        final task = HouseholdTask.fromJson(json);

        expect(task.isCompleted, isTrue);
        expect(task.completedAt, equals(completedDate));
        expect(task.completedByMemberId, equals('member-1'));
      });
    });

    group('toFirestore', () {
      test('should convert HouseholdTask to Firestore format', () {
        final firestoreData = testTask.toFirestore();

        expect(firestoreData['title'], equals('Clean the kitchen'));
        expect(firestoreData['description'],
            equals('Wash dishes and clean countertops'));
        expect(firestoreData['assignedMemberId'], equals('member-1'));
        expect(firestoreData['dueDate'], isA<Timestamp>());
        expect(
            (firestoreData['dueDate'] as Timestamp).toDate(), equals(dueDate));
        expect(firestoreData['category'], equals('Cleaning'));
        expect(firestoreData['priority'], equals('High'));
        expect(firestoreData['isCompleted'], isFalse);
        expect(firestoreData['completedAt'], isNull);
        expect(firestoreData['completedByMemberId'], isNull);
        expect(firestoreData['isRecurring'], isTrue);
        expect(firestoreData['recurringPattern'], equals('Weekly'));
        // Note: createdAt is not included in toFirestore
        expect(firestoreData.containsKey('createdAt'), isFalse);
      });

      test('should handle completed task in Firestore format', () {
        final completedDate = DateTime(2024, 1, 18, 16, 30);
        final completedTask = testTask.copyWith(
          isCompleted: true,
          completedAt: completedDate,
          completedByMemberId: 'member-1',
        );

        final firestoreData = completedTask.toFirestore();

        expect(firestoreData['isCompleted'], isTrue);
        expect(firestoreData['completedAt'], isA<Timestamp>());
        expect((firestoreData['completedAt'] as Timestamp).toDate(),
            equals(completedDate));
        expect(firestoreData['completedByMemberId'], equals('member-1'));
      });
    });

    group('fromFirestore', () {
      test('should create HouseholdTask from Firestore data', () {
        final firestoreData = {
          'title': 'Clean the kitchen',
          'description': 'Wash dishes and clean countertops',
          'assignedMemberId': 'member-1',
          'dueDate': Timestamp.fromDate(dueDate),
          'category': 'Cleaning',
          'priority': 'High',
          'isCompleted': false,
          'completedAt': null,
          'completedByMemberId': null,
          'isRecurring': true,
          'recurringPattern': 'Weekly',
          'createdAt': Timestamp.fromDate(testDate),
        };

        final task = HouseholdTask.fromFirestore('task-123', firestoreData);

        expect(task.id, equals('task-123'));
        expect(task.title, equals('Clean the kitchen'));
        expect(task.description, equals('Wash dishes and clean countertops'));
        expect(task.assignedMemberId, equals('member-1'));
        expect(task.dueDate, equals(dueDate));
        expect(task.category, equals('Cleaning'));
        expect(task.priority, equals('High'));
        expect(task.isCompleted, isFalse);
        expect(task.completedAt, isNull);
        expect(task.completedByMemberId, isNull);
        expect(task.isRecurring, isTrue);
        expect(task.recurringPattern, equals('Weekly'));
        expect(task.createdAt, equals(testDate));
      });

      test('should handle missing Firestore data with defaults', () {
        final firestoreData = <String, dynamic>{};

        final task = HouseholdTask.fromFirestore('task-123', firestoreData);

        expect(task.id, equals('task-123'));
        expect(task.title, equals(''));
        expect(task.description, equals(''));
        expect(task.assignedMemberId, equals(''));
        expect(task.category, equals('Other'));
        expect(task.priority, equals('Medium'));
        expect(task.isCompleted, isFalse);
        expect(task.completedAt, isNull);
        expect(task.completedByMemberId, isNull);
        expect(task.isRecurring, isFalse);
        expect(task.recurringPattern, isNull);
        expect(task.createdAt.year, equals(DateTime.now().year));
      });
    });

    group('copyWith', () {
      test('should create a copy with updated fields', () {
        final updatedTask = testTask.copyWith(
          title: 'Deep clean the kitchen',
          priority: 'Urgent',
          isCompleted: true,
          completedAt: DateTime.now(),
          completedByMemberId: 'member-1',
        );

        expect(updatedTask.id, equals(testTask.id));
        expect(updatedTask.title, equals('Deep clean the kitchen'));
        expect(updatedTask.priority, equals('Urgent'));
        expect(updatedTask.isCompleted, isTrue);
        expect(updatedTask.completedAt, isNotNull);
        expect(updatedTask.completedByMemberId, equals('member-1'));
        expect(updatedTask.description, equals(testTask.description));
        expect(updatedTask.assignedMemberId, equals(testTask.assignedMemberId));
        expect(updatedTask.dueDate, equals(testTask.dueDate));
        expect(updatedTask.category, equals(testTask.category));
        expect(updatedTask.isRecurring, equals(testTask.isRecurring));
        expect(updatedTask.recurringPattern, equals(testTask.recurringPattern));
        expect(updatedTask.createdAt, equals(testTask.createdAt));
      });
    });

    group('Static properties', () {
      test('should return correct categories', () {
        final categories = HouseholdTask.categories;

        expect(categories, contains('Cleaning'));
        expect(categories, contains('Kitchen'));
        expect(categories, contains('Laundry'));
        expect(categories, contains('Yard Work'));
        expect(categories, contains('Maintenance'));
        expect(categories, contains('Shopping'));
        expect(categories, contains('Pet Care'));
        expect(categories, contains('Organization'));
        expect(categories, contains('Bills & Finance'));
        expect(categories, contains('Other'));
        expect(categories, hasLength(10));
      });

      test('should return correct priorities', () {
        final priorities = HouseholdTask.priorities;

        expect(priorities, contains('Low'));
        expect(priorities, contains('Medium'));
        expect(priorities, contains('High'));
        expect(priorities, contains('Urgent'));
        expect(priorities, hasLength(4));
      });
    });

    group('isOverdue', () {
      test('should return true for overdue incomplete task', () {
        final overdueTask = testTask.copyWith(
          dueDate: DateTime.now().subtract(const Duration(days: 1)),
        );

        expect(overdueTask.isOverdue, isTrue);
      });

      test('should return false for future incomplete task', () {
        final futureTask = testTask.copyWith(
          dueDate: DateTime.now().add(const Duration(days: 1)),
        );

        expect(futureTask.isOverdue, isFalse);
      });

      test('should return false for completed task even if overdue', () {
        final completedOverdueTask = testTask.copyWith(
          dueDate: DateTime.now().subtract(const Duration(days: 1)),
          isCompleted: true,
        );

        expect(completedOverdueTask.isOverdue, isFalse);
      });
    });

    group('getSampleTasks', () {
      test('should return a list of sample tasks', () {
        final sampleTasks = HouseholdTask.getSampleTasks();

        expect(sampleTasks, hasLength(greaterThan(0)));
        expect(sampleTasks[0].title, equals('Take out trash'));
        expect(sampleTasks[0].category, equals('Cleaning'));
        expect(sampleTasks[0].isRecurring, isTrue);
        expect(sampleTasks[0].recurringPattern, equals('Weekly'));
      });

      test('should have unique IDs for sample tasks', () {
        final sampleTasks = HouseholdTask.getSampleTasks();
        final ids = sampleTasks.map((task) => task.id).toSet();

        expect(ids.length, equals(sampleTasks.length));
      });
    });
  });
}
