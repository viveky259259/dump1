import 'package:flutter_test/flutter_test.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/models/emergency_contact.dart';

void main() {
  group('EmergencyContact', () {
    late EmergencyContact testContact;
    late DateTime testDate;

    setUp(() {
      testDate = DateTime(2024, 1, 15, 10, 30);
      testContact = EmergencyContact(
        id: 'contact-123',
        name: 'Dr. Johnson',
        phoneNumber: '(555) 123-4567',
        relationship: 'Doctor',
        contactType: 'Medical',
        email: 'dr.johnson@familyhealth.com',
        address: '123 Medical Center Dr, City, ST 12345',
        notes: 'Family physician - Emma and Jake\'s pediatrician',
        isPrimary: true,
        createdAt: testDate,
      );
    });

    group('Constructor', () {
      test('should create EmergencyContact with all required fields', () {
        expect(testContact.id, equals('contact-123'));
        expect(testContact.name, equals('Dr. Johnson'));
        expect(testContact.phoneNumber, equals('(555) 123-4567'));
        expect(testContact.relationship, equals('Doctor'));
        expect(testContact.contactType, equals('Medical'));
        expect(testContact.email, equals('dr.johnson@familyhealth.com'));
        expect(testContact.address,
            equals('123 Medical Center Dr, City, ST 12345'));
        expect(testContact.notes,
            equals('Family physician - Emma and Jake\'s pediatrician'));
        expect(testContact.isPrimary, isTrue);
        expect(testContact.createdAt, equals(testDate));
      });

      test('should create EmergencyContact with minimal fields', () {
        final minimalContact = EmergencyContact(
          name: 'Emergency Services',
          phoneNumber: '911',
          relationship: 'Emergency Contact',
          contactType: 'Emergency Services',
          createdAt: testDate,
        );

        expect(minimalContact.id, isNull);
        expect(minimalContact.name, equals('Emergency Services'));
        expect(minimalContact.phoneNumber, equals('911'));
        expect(minimalContact.relationship, equals('Emergency Contact'));
        expect(minimalContact.contactType, equals('Emergency Services'));
        expect(minimalContact.email, isNull);
        expect(minimalContact.address, isNull);
        expect(minimalContact.notes, isNull);
        expect(minimalContact.isPrimary, isFalse);
        expect(minimalContact.createdAt, equals(testDate));
      });

      test('should create primary contact', () {
        final primaryContact = EmergencyContact(
          name: 'Grandma Betty',
          phoneNumber: '(555) 987-6543',
          relationship: 'Grandparent',
          contactType: 'Family',
          isPrimary: true,
          createdAt: testDate,
        );

        expect(primaryContact.isPrimary, isTrue);
      });
    });

    group('toJson', () {
      test('should convert EmergencyContact to JSON correctly', () {
        final json = testContact.toJson();

        expect(json['id'], equals('contact-123'));
        expect(json['name'], equals('Dr. Johnson'));
        expect(json['phoneNumber'], equals('(555) 123-4567'));
        expect(json['relationship'], equals('Doctor'));
        expect(json['contactType'], equals('Medical'));
        expect(json['email'], equals('dr.johnson@familyhealth.com'));
        expect(
            json['address'], equals('123 Medical Center Dr, City, ST 12345'));
        expect(json['notes'],
            equals('Family physician - Emma and Jake\'s pediatrician'));
        expect(json['isPrimary'], isTrue);
        expect(json['createdAt'], equals(testDate.toIso8601String()));
      });

      test('should handle contact without optional fields in JSON', () {
        final minimalContact = EmergencyContact(
          name: 'Emergency Services',
          phoneNumber: '911',
          relationship: 'Emergency Contact',
          contactType: 'Emergency Services',
          createdAt: testDate,
        );

        final json = minimalContact.toJson();

        expect(json['email'], isNull);
        expect(json['address'], isNull);
        expect(json['notes'], isNull);
        expect(json['isPrimary'], isFalse);
      });
    });

    group('fromJson', () {
      test('should create EmergencyContact from JSON correctly', () {
        final json = {
          'id': 'contact-123',
          'name': 'Dr. Johnson',
          'phoneNumber': '(555) 123-4567',
          'relationship': 'Doctor',
          'contactType': 'Medical',
          'email': 'dr.johnson@familyhealth.com',
          'address': '123 Medical Center Dr, City, ST 12345',
          'notes': 'Family physician - Emma and Jake\'s pediatrician',
          'isPrimary': true,
          'createdAt': testDate.toIso8601String(),
        };

        final contact = EmergencyContact.fromJson(json);

        expect(contact.id, equals('contact-123'));
        expect(contact.name, equals('Dr. Johnson'));
        expect(contact.phoneNumber, equals('(555) 123-4567'));
        expect(contact.relationship, equals('Doctor'));
        expect(contact.contactType, equals('Medical'));
        expect(contact.email, equals('dr.johnson@familyhealth.com'));
        expect(
            contact.address, equals('123 Medical Center Dr, City, ST 12345'));
        expect(contact.notes,
            equals('Family physician - Emma and Jake\'s pediatrician'));
        expect(contact.isPrimary, isTrue);
        expect(contact.createdAt, equals(testDate));
      });

      test('should handle missing optional fields from JSON', () {
        final json = {
          'id': 'contact-123',
          'name': 'Emergency Services',
          'phoneNumber': '911',
          'relationship': 'Emergency Contact',
          'contactType': 'Emergency Services',
          'email': null,
          'address': null,
          'notes': null,
          'isPrimary': false,
          'createdAt': testDate.toIso8601String(),
        };

        final contact = EmergencyContact.fromJson(json);

        expect(contact.email, isNull);
        expect(contact.address, isNull);
        expect(contact.notes, isNull);
        expect(contact.isPrimary, isFalse);
      });
    });

    group('toFirestore', () {
      test('should convert EmergencyContact to Firestore format', () {
        final firestoreData = testContact.toFirestore();

        expect(firestoreData['name'], equals('Dr. Johnson'));
        expect(firestoreData['phoneNumber'], equals('(555) 123-4567'));
        expect(firestoreData['relationship'], equals('Doctor'));
        expect(firestoreData['contactType'], equals('Medical'));
        expect(firestoreData['email'], equals('dr.johnson@familyhealth.com'));
        expect(firestoreData['address'],
            equals('123 Medical Center Dr, City, ST 12345'));
        expect(firestoreData['notes'],
            equals('Family physician - Emma and Jake\'s pediatrician'));
        expect(firestoreData['isPrimary'], isTrue);
        // Note: createdAt is not included in toFirestore
        expect(firestoreData.containsKey('createdAt'), isFalse);
      });
    });

    group('fromFirestore', () {
      test('should create EmergencyContact from Firestore data', () {
        final firestoreData = {
          'name': 'Dr. Johnson',
          'phoneNumber': '(555) 123-4567',
          'relationship': 'Doctor',
          'contactType': 'Medical',
          'email': 'dr.johnson@familyhealth.com',
          'address': '123 Medical Center Dr, City, ST 12345',
          'notes': 'Family physician - Emma and Jake\'s pediatrician',
          'isPrimary': true,
          'createdAt': Timestamp.fromDate(testDate),
        };

        final contact =
            EmergencyContact.fromFirestore('contact-123', firestoreData);

        expect(contact.id, equals('contact-123'));
        expect(contact.name, equals('Dr. Johnson'));
        expect(contact.phoneNumber, equals('(555) 123-4567'));
        expect(contact.relationship, equals('Doctor'));
        expect(contact.contactType, equals('Medical'));
        expect(contact.email, equals('dr.johnson@familyhealth.com'));
        expect(
            contact.address, equals('123 Medical Center Dr, City, ST 12345'));
        expect(contact.notes,
            equals('Family physician - Emma and Jake\'s pediatrician'));
        expect(contact.isPrimary, isTrue);
        expect(contact.createdAt, equals(testDate));
      });

      test('should handle missing Firestore data with defaults', () {
        final firestoreData = <String, dynamic>{};

        final contact =
            EmergencyContact.fromFirestore('contact-123', firestoreData);

        expect(contact.id, equals('contact-123'));
        expect(contact.name, equals(''));
        expect(contact.phoneNumber, equals(''));
        expect(contact.relationship, equals(''));
        expect(contact.contactType, equals('Personal'));
        expect(contact.email, isNull);
        expect(contact.address, isNull);
        expect(contact.notes, isNull);
        expect(contact.isPrimary, isFalse);
        expect(contact.createdAt.year, equals(DateTime.now().year));
      });
    });

    group('copyWith', () {
      test('should create a copy with updated fields', () {
        final updatedContact = testContact.copyWith(
          name: 'Dr. Smith',
          phoneNumber: '(555) 999-8888',
          email: 'dr.smith@familyhealth.com',
          isPrimary: false,
        );

        expect(updatedContact.id, equals(testContact.id));
        expect(updatedContact.name, equals('Dr. Smith'));
        expect(updatedContact.phoneNumber, equals('(555) 999-8888'));
        expect(updatedContact.email, equals('dr.smith@familyhealth.com'));
        expect(updatedContact.isPrimary, isFalse);
        expect(updatedContact.relationship, equals(testContact.relationship));
        expect(updatedContact.contactType, equals(testContact.contactType));
        expect(updatedContact.address, equals(testContact.address));
        expect(updatedContact.notes, equals(testContact.notes));
        expect(updatedContact.createdAt, equals(testContact.createdAt));
      });

      test('should keep original values when fields are not specified', () {
        final updatedContact = testContact.copyWith(name: 'Dr. Smith');

        expect(updatedContact.id, equals(testContact.id));
        expect(updatedContact.name, equals('Dr. Smith'));
        expect(updatedContact.phoneNumber, equals(testContact.phoneNumber));
        expect(updatedContact.relationship, equals(testContact.relationship));
        expect(updatedContact.contactType, equals(testContact.contactType));
        expect(updatedContact.email, equals(testContact.email));
        expect(updatedContact.address, equals(testContact.address));
        expect(updatedContact.notes, equals(testContact.notes));
        expect(updatedContact.isPrimary, equals(testContact.isPrimary));
        expect(updatedContact.createdAt, equals(testContact.createdAt));
      });
    });

    group('Static properties', () {
      test('should return correct contact types', () {
        final contactTypes = EmergencyContact.contactTypes;

        expect(contactTypes, contains('Emergency Services'));
        expect(contactTypes, contains('Medical'));
        expect(contactTypes, contains('Family'));
        expect(contactTypes, contains('Friend'));
        expect(contactTypes, contains('Neighbor'));
        expect(contactTypes, contains('Workplace'));
        expect(contactTypes, contains('School'));
        expect(contactTypes, contains('Service Provider'));
        expect(contactTypes, contains('Other'));
        expect(contactTypes, hasLength(9));
      });

      test('should return correct relationships', () {
        final relationships = EmergencyContact.relationships;

        expect(relationships, contains('Parent'));
        expect(relationships, contains('Sibling'));
        expect(relationships, contains('Grandparent'));
        expect(relationships, contains('Aunt/Uncle'));
        expect(relationships, contains('Cousin'));
        expect(relationships, contains('Friend'));
        expect(relationships, contains('Neighbor'));
        expect(relationships, contains('Doctor'));
        expect(relationships, contains('Emergency Contact'));
        expect(relationships, contains('Other'));
        expect(relationships, hasLength(10));
      });
    });

    group('getSampleContacts', () {
      test('should return a list of sample contacts', () {
        final sampleContacts = EmergencyContact.getSampleContacts();

        expect(sampleContacts, hasLength(6));
        expect(sampleContacts[0].name, equals('Emergency Services'));
        expect(sampleContacts[0].contactType, equals('Emergency Services'));
        expect(sampleContacts[0].isPrimary, isTrue);
        expect(sampleContacts[1].name, equals('Dr. Johnson'));
        expect(sampleContacts[1].contactType, equals('Medical'));
        expect(sampleContacts[2].name, equals('Grandma Betty'));
        expect(sampleContacts[2].contactType, equals('Family'));
        expect(sampleContacts[3].name, equals('Tom Wilson'));
        expect(sampleContacts[3].contactType, equals('Neighbor'));
        expect(sampleContacts[4].name, equals('Poison Control'));
        expect(sampleContacts[4].contactType, equals('Emergency Services'));
        expect(sampleContacts[5].name, equals('Emma\'s School'));
        expect(sampleContacts[5].contactType, equals('School'));
      });

      test('should have unique IDs for sample contacts', () {
        final sampleContacts = EmergencyContact.getSampleContacts();
        final ids = sampleContacts.map((contact) => contact.id).toSet();

        expect(ids, hasLength(6));
        expect(ids.contains('1'), isTrue);
        expect(ids.contains('2'), isTrue);
        expect(ids.contains('3'), isTrue);
        expect(ids.contains('4'), isTrue);
        expect(ids.contains('5'), isTrue);
        expect(ids.contains('6'), isTrue);
      });

      test('should have primary contacts', () {
        final sampleContacts = EmergencyContact.getSampleContacts();
        final primaryContacts =
            sampleContacts.where((contact) => contact.isPrimary).toList();

        expect(primaryContacts, hasLength(3));
        expect(primaryContacts[0].name, equals('Emergency Services'));
        expect(primaryContacts[1].name, equals('Dr. Johnson'));
        expect(primaryContacts[2].name, equals('Grandma Betty'));
      });

      test('should have contacts with different types', () {
        final sampleContacts = EmergencyContact.getSampleContacts();
        final contactTypes =
            sampleContacts.map((contact) => contact.contactType).toSet();

        expect(contactTypes, contains('Emergency Services'));
        expect(contactTypes, contains('Medical'));
        expect(contactTypes, contains('Family'));
        expect(contactTypes, contains('Neighbor'));
        expect(contactTypes, contains('School'));
        expect(contactTypes, hasLength(5));
      });
    });
  });
}
