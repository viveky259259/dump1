// This file imports and runs all model tests
// Run with: flutter test test/models/models_test.dart

import 'family_member_test.dart' as family_member_test;
import 'household_task_test.dart' as household_task_test;
import 'item_tracker_test.dart' as item_tracker_test;
import 'calendar_event_test.dart' as calendar_event_test;
import 'emergency_contact_test.dart' as emergency_contact_test;

void main() {
  // Run all model tests
  family_member_test.main();
  household_task_test.main();
  item_tracker_test.main();
  calendar_event_test.main();
  emergency_contact_test.main();
}
