import 'package:flutter_test/flutter_test.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/models/item_tracker.dart';

void main() {
  group('TrackedItem', () {
    late TrackedItem testItem;
    late DateTime testDate;
    late DateTime borrowedDate;

    setUp(() {
      testDate = DateTime(2024, 1, 15, 10, 30);
      borrowedDate = DateTime(2024, 1, 18, 14, 0);
      testItem = TrackedItem(
        id: 'item-123',
        name: 'iPad Pro',
        description: 'Family tablet for entertainment and homework',
        currentLocation: 'Living Room',
        borrowedByMemberId: 'member-3',
        borrowedAt: borrowedDate,
        category: 'Electronics',
        status: 'Borrowed',
        imageUrl: 'https://example.com/ipad.jpg',
        history: [
          ItemHistory(
            id: 'history-1',
            action: 'Borrowed',
            memberId: 'member-3',
            location: 'Living Room',
            timestamp: borrowedDate,
            notes: 'For homework project',
          ),
        ],
        createdAt: testDate,
      );
    });

    group('Constructor', () {
      test('should create TrackedItem with all required fields', () {
        expect(testItem.id, equals('item-123'));
        expect(testItem.name, equals('iPad Pro'));
        expect(testItem.description,
            equals('Family tablet for entertainment and homework'));
        expect(testItem.currentLocation, equals('Living Room'));
        expect(testItem.borrowedByMemberId, equals('member-3'));
        expect(testItem.borrowedAt, equals(borrowedDate));
        expect(testItem.returnedAt, isNull);
        expect(testItem.category, equals('Electronics'));
        expect(testItem.status, equals('Borrowed'));
        expect(testItem.imageUrl, equals('https://example.com/ipad.jpg'));
        expect(testItem.history, hasLength(1));
        expect(testItem.createdAt, equals(testDate));
      });

      test('should create available item without borrowing details', () {
        final availableItem = TrackedItem(
          id: 'item-456',
          name: 'Coffee Maker',
          description: 'Kitchen appliance',
          currentLocation: 'Kitchen',
          category: 'Kitchen Items',
          status: 'Available',
          history: [],
          createdAt: testDate,
        );

        expect(availableItem.borrowedByMemberId, isNull);
        expect(availableItem.borrowedAt, isNull);
        expect(availableItem.returnedAt, isNull);
        expect(availableItem.status, equals('Available'));
        expect(availableItem.history, isEmpty);
      });
    });

    group('toJson', () {
      test('should convert TrackedItem to JSON correctly', () {
        final json = testItem.toJson();

        expect(json['id'], equals('item-123'));
        expect(json['name'], equals('iPad Pro'));
        expect(json['description'],
            equals('Family tablet for entertainment and homework'));
        expect(json['currentLocation'], equals('Living Room'));
        expect(json['borrowedByMemberId'], equals('member-3'));
        expect(json['borrowedAt'], equals(borrowedDate.toIso8601String()));
        expect(json['returnedAt'], isNull);
        expect(json['category'], equals('Electronics'));
        expect(json['status'], equals('Borrowed'));
        expect(json['imageUrl'], equals('https://example.com/ipad.jpg'));
        expect(json['history'], hasLength(1));
        expect(json['createdAt'], equals(testDate.toIso8601String()));
      });

      test('should handle returned item in JSON', () {
        final returnedDate = DateTime(2024, 1, 19, 16, 30);
        final returnedItem = testItem.copyWith(
          status: 'Available',
          returnedAt: returnedDate,
          borrowedByMemberId: null,
          borrowedAt: null,
        );

        final json = returnedItem.toJson();

        expect(json['status'], equals('Available'));
        expect(json['returnedAt'], equals(returnedDate.toIso8601String()));
        expect(json['borrowedByMemberId'], isNull);
        expect(json['borrowedAt'], isNull);
      });
    });

    group('fromJson', () {
      test('should create TrackedItem from JSON correctly', () {
        final json = {
          'id': 'item-123',
          'name': 'iPad Pro',
          'description': 'Family tablet for entertainment and homework',
          'currentLocation': 'Living Room',
          'borrowedByMemberId': 'member-3',
          'borrowedAt': borrowedDate.toIso8601String(),
          'returnedAt': null,
          'category': 'Electronics',
          'status': 'Borrowed',
          'imageUrl': 'https://example.com/ipad.jpg',
          'history': [
            {
              'id': 'history-1',
              'action': 'Borrowed',
              'memberId': 'member-3',
              'location': 'Living Room',
              'timestamp': borrowedDate.toIso8601String(),
              'notes': 'For homework project',
            }
          ],
          'createdAt': testDate.toIso8601String(),
        };

        final item = TrackedItem.fromJson(json);

        expect(item.id, equals('item-123'));
        expect(item.name, equals('iPad Pro'));
        expect(item.description,
            equals('Family tablet for entertainment and homework'));
        expect(item.currentLocation, equals('Living Room'));
        expect(item.borrowedByMemberId, equals('member-3'));
        expect(item.borrowedAt, equals(borrowedDate));
        expect(item.returnedAt, isNull);
        expect(item.category, equals('Electronics'));
        expect(item.status, equals('Borrowed'));
        expect(item.imageUrl, equals('https://example.com/ipad.jpg'));
        expect(item.history, hasLength(1));
        expect(item.createdAt, equals(testDate));
      });
    });

    group('toFirestore', () {
      test('should convert TrackedItem to Firestore format', () {
        final firestoreData = testItem.toFirestore();

        expect(firestoreData['name'], equals('iPad Pro'));
        expect(firestoreData['description'],
            equals('Family tablet for entertainment and homework'));
        expect(firestoreData['currentLocation'], equals('Living Room'));
        expect(firestoreData['borrowedByMemberId'], equals('member-3'));
        expect(firestoreData['borrowedAt'], isA<Timestamp>());
        expect((firestoreData['borrowedAt'] as Timestamp).toDate(),
            equals(borrowedDate));
        expect(firestoreData['returnedAt'], isNull);
        expect(firestoreData['category'], equals('Electronics'));
        expect(firestoreData['status'], equals('Borrowed'));
        expect(
            firestoreData['imageUrl'], equals('https://example.com/ipad.jpg'));
        expect(firestoreData['history'], hasLength(1));
        // Note: createdAt is not included in toFirestore
        expect(firestoreData.containsKey('createdAt'), isFalse);
      });
    });

    group('fromFirestore', () {
      test('should create TrackedItem from Firestore data', () {
        final firestoreData = {
          'name': 'iPad Pro',
          'description': 'Family tablet for entertainment and homework',
          'currentLocation': 'Living Room',
          'borrowedByMemberId': 'member-3',
          'borrowedAt': Timestamp.fromDate(borrowedDate),
          'returnedAt': null,
          'category': 'Electronics',
          'status': 'Borrowed',
          'imageUrl': 'https://example.com/ipad.jpg',
          'history': [
            {
              'action': 'Borrowed',
              'memberId': 'member-3',
              'location': 'Living Room',
              'timestamp': Timestamp.fromDate(borrowedDate),
              'notes': 'For homework project',
            }
          ],
          'createdAt': Timestamp.fromDate(testDate),
        };

        final item = TrackedItem.fromFirestore('item-123', firestoreData);

        expect(item.id, equals('item-123'));
        expect(item.name, equals('iPad Pro'));
        expect(item.description,
            equals('Family tablet for entertainment and homework'));
        expect(item.currentLocation, equals('Living Room'));
        expect(item.borrowedByMemberId, equals('member-3'));
        expect(item.borrowedAt, equals(borrowedDate));
        expect(item.returnedAt, isNull);
        expect(item.category, equals('Electronics'));
        expect(item.status, equals('Borrowed'));
        expect(item.imageUrl, equals('https://example.com/ipad.jpg'));
        expect(item.history, hasLength(1));
        expect(item.createdAt, equals(testDate));
      });

      test('should handle missing Firestore data with defaults', () {
        final firestoreData = <String, dynamic>{};

        final item = TrackedItem.fromFirestore('item-123', firestoreData);

        expect(item.id, equals('item-123'));
        expect(item.name, equals(''));
        expect(item.description, equals(''));
        expect(item.currentLocation, equals(''));
        expect(item.borrowedByMemberId, isNull);
        expect(item.borrowedAt, isNull);
        expect(item.returnedAt, isNull);
        expect(item.category, equals('Other'));
        expect(item.status, equals('Available'));
        expect(item.imageUrl, isNull);
        expect(item.history, isEmpty);
        expect(item.createdAt.year, equals(DateTime.now().year));
      });
    });

    group('copyWith', () {
      test('should create a copy with updated fields', () {
        final returnedDate = DateTime(2024, 1, 19, 16, 30);
        final updatedItem = testItem.copyWith(
          status: 'Available',
          returnedAt: returnedDate,
          borrowedByMemberId: null,
          borrowedAt: null,
          currentLocation: 'Kitchen',
        );

        expect(updatedItem.id, equals(testItem.id));
        expect(updatedItem.status, equals('Available'));
        expect(updatedItem.returnedAt, equals(returnedDate));
        expect(updatedItem.borrowedByMemberId, isNull);
        expect(updatedItem.borrowedAt, isNull);
        expect(updatedItem.currentLocation, equals('Kitchen'));
        expect(updatedItem.name, equals(testItem.name));
        expect(updatedItem.description, equals(testItem.description));
        expect(updatedItem.category, equals(testItem.category));
        expect(updatedItem.imageUrl, equals(testItem.imageUrl));
        expect(updatedItem.history, equals(testItem.history));
        expect(updatedItem.createdAt, equals(testItem.createdAt));
      });
    });

    group('Static properties', () {
      test('should return correct categories', () {
        final categories = TrackedItem.categories;

        expect(categories, contains('Electronics'));
        expect(categories, contains('Tools'));
        expect(categories, contains('Books'));
        expect(categories, contains('Sports Equipment'));
        expect(categories, contains('Kitchen Items'));
        expect(categories, contains('Clothing'));
        expect(categories, contains('Toys & Games'));
        expect(categories, contains('Documents'));
        expect(categories, contains('Other'));
        expect(categories, hasLength(9));
      });

      test('should return correct statuses', () {
        final statuses = TrackedItem.statuses;

        expect(statuses, contains('Available'));
        expect(statuses, contains('Borrowed'));
        expect(statuses, contains('In Use'));
        expect(statuses, contains('Lost'));
        expect(statuses, contains('Maintenance'));
        expect(statuses, hasLength(5));
      });

      test('should return correct locations', () {
        final locations = TrackedItem.locations;

        expect(locations, contains('Living Room'));
        expect(locations, contains('Kitchen'));
        expect(locations, contains('Master Bedroom'));
        expect(locations, contains('Kids Room'));
        expect(locations, contains('Garage'));
        expect(locations, contains('Basement'));
        expect(locations, contains('Office'));
        expect(locations, contains('Bathroom'));
        expect(locations, contains('Attic'));
        expect(locations, contains('Outside'));
        expect(locations, contains('Car'));
        expect(locations, contains('Unknown'));
        expect(locations, hasLength(12));
      });
    });

    group('isBorrowed', () {
      test('should return true for borrowed item', () {
        expect(testItem.isBorrowed, isTrue);
      });

      test('should return false for available item', () {
        final availableItem = testItem.copyWith(
          status: 'Available',
          borrowedByMemberId: null,
        );

        expect(availableItem.isBorrowed, isFalse);
      });

      test('should return false for borrowed status without member ID', () {
        final borrowedWithoutMember = testItem.copyWith(
          borrowedByMemberId: null,
        );

        expect(borrowedWithoutMember.isBorrowed, isFalse);
      });
    });

    group('getSampleItems', () {
      test('should return a list of sample items', () {
        final sampleItems = TrackedItem.getSampleItems();

        expect(sampleItems, hasLength(greaterThan(0)));
        expect(sampleItems[0].name, equals('iPad Pro'));
        expect(sampleItems[0].category, equals('Electronics'));
        expect(sampleItems[0].status, equals('Borrowed'));
      });

      test('should have unique IDs for sample items', () {
        final sampleItems = TrackedItem.getSampleItems();
        final ids = sampleItems.map((item) => item.id).toSet();

        expect(ids.length, equals(sampleItems.length));
      });
    });
  });

  group('ItemHistory', () {
    late ItemHistory testHistory;
    late DateTime testDate;

    setUp(() {
      testDate = DateTime(2024, 1, 18, 14, 0);
      testHistory = ItemHistory(
        id: 'history-1',
        action: 'Borrowed',
        memberId: 'member-3',
        location: 'Living Room',
        timestamp: testDate,
        notes: 'For homework project',
      );
    });

    group('Constructor', () {
      test('should create ItemHistory with all fields', () {
        expect(testHistory.id, equals('history-1'));
        expect(testHistory.action, equals('Borrowed'));
        expect(testHistory.memberId, equals('member-3'));
        expect(testHistory.location, equals('Living Room'));
        expect(testHistory.timestamp, equals(testDate));
        expect(testHistory.notes, equals('For homework project'));
      });
    });

    group('toJson', () {
      test('should convert ItemHistory to JSON correctly', () {
        final json = testHistory.toJson();

        expect(json['id'], equals('history-1'));
        expect(json['action'], equals('Borrowed'));
        expect(json['memberId'], equals('member-3'));
        expect(json['location'], equals('Living Room'));
        expect(json['timestamp'], equals(testDate.toIso8601String()));
        expect(json['notes'], equals('For homework project'));
      });
    });

    group('fromJson', () {
      test('should create ItemHistory from JSON correctly', () {
        final json = {
          'id': 'history-1',
          'action': 'Borrowed',
          'memberId': 'member-3',
          'location': 'Living Room',
          'timestamp': testDate.toIso8601String(),
          'notes': 'For homework project',
        };

        final history = ItemHistory.fromJson(json);

        expect(history.id, equals('history-1'));
        expect(history.action, equals('Borrowed'));
        expect(history.memberId, equals('member-3'));
        expect(history.location, equals('Living Room'));
        expect(history.timestamp, equals(testDate));
        expect(history.notes, equals('For homework project'));
      });
    });

    group('toFirestore', () {
      test('should convert ItemHistory to Firestore format', () {
        final firestoreData = testHistory.toFirestore();

        expect(firestoreData['action'], equals('Borrowed'));
        expect(firestoreData['memberId'], equals('member-3'));
        expect(firestoreData['location'], equals('Living Room'));
        expect(firestoreData['timestamp'], isA<Timestamp>());
        expect((firestoreData['timestamp'] as Timestamp).toDate(),
            equals(testDate));
        expect(firestoreData['notes'], equals('For homework project'));
        // Note: id is not included in toFirestore
        expect(firestoreData.containsKey('id'), isFalse);
      });
    });

    group('fromFirestore', () {
      test('should create ItemHistory from Firestore data', () {
        final firestoreData = {
          'action': 'Borrowed',
          'memberId': 'member-3',
          'location': 'Living Room',
          'timestamp': Timestamp.fromDate(testDate),
          'notes': 'For homework project',
        };

        final history = ItemHistory.fromFirestore(firestoreData);

        expect(history.action, equals('Borrowed'));
        expect(history.memberId, equals('member-3'));
        expect(history.location, equals('Living Room'));
        expect(history.timestamp, equals(testDate));
        expect(history.notes, equals('For homework project'));
        // Note: id is not set in fromFirestore
        expect(history.id, isNull);
      });
    });
  });
}
