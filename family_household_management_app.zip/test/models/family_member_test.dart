import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/models/family_member.dart';

void main() {
  group('FamilyMember', () {
    late FamilyMember testMember;
    late DateTime testDate;

    setUp(() {
      testDate = DateTime(2024, 1, 15, 10, 30);
      testMember = FamilyMember(
        id: 'test-id-123',
        name: 'John Doe',
        role: 'Father',
        color: const Color(0xFF6F61EF),
        profileImageUrl: 'https://example.com/avatar.jpg',
        userId: 'user-123',
        email: 'john@example.com',
        isOwner: true,
        createdAt: testDate,
      );
    });

    group('Constructor', () {
      test('should create FamilyMember with all required fields', () {
        expect(testMember.id, equals('test-id-123'));
        expect(testMember.name, equals('John Doe'));
        expect(testMember.role, equals('Father'));
        expect(testMember.color, equals(const Color(0xFF6F61EF)));
        expect(testMember.profileImageUrl,
            equals('https://example.com/avatar.jpg'));
        expect(testMember.userId, equals('user-123'));
        expect(testMember.email, equals('john@example.com'));
        expect(testMember.isOwner, isTrue);
        expect(testMember.createdAt, equals(testDate));
      });

      test('should create FamilyMember with minimal fields', () {
        final minimalMember = FamilyMember(
          name: 'Jane Doe',
          role: 'Mother',
          color: const Color(0xFF39D2C0),
          createdAt: testDate,
        );

        expect(minimalMember.id, isNull);
        expect(minimalMember.name, equals('Jane Doe'));
        expect(minimalMember.role, equals('Mother'));
        expect(minimalMember.color, equals(const Color(0xFF39D2C0)));
        expect(minimalMember.profileImageUrl, isNull);
        expect(minimalMember.userId, isNull);
        expect(minimalMember.email, isNull);
        expect(minimalMember.isOwner, isFalse);
        expect(minimalMember.createdAt, equals(testDate));
      });
    });

    group('toJson', () {
      test('should convert FamilyMember to JSON correctly', () {
        final json = testMember.toJson();

        expect(json['id'], equals('test-id-123'));
        expect(json['name'], equals('John Doe'));
        expect(json['role'], equals('Father'));
        expect(json['colorValue'], equals(0xFF6F61EF));
        expect(
            json['profileImageUrl'], equals('https://example.com/avatar.jpg'));
        expect(json['userId'], equals('user-123'));
        expect(json['email'], equals('john@example.com'));
        expect(json['isOwner'], isTrue);
        expect(json['createdAt'], equals(testDate.toIso8601String()));
      });
    });

    group('fromJson', () {
      test('should create FamilyMember from JSON correctly', () {
        final json = {
          'id': 'test-id-123',
          'name': 'John Doe',
          'role': 'Father',
          'colorValue': 0xFF6F61EF,
          'profileImageUrl': 'https://example.com/avatar.jpg',
          'userId': 'user-123',
          'email': 'john@example.com',
          'isOwner': true,
          'createdAt': testDate.toIso8601String(),
        };

        final member = FamilyMember.fromJson(json);

        expect(member.id, equals('test-id-123'));
        expect(member.name, equals('John Doe'));
        expect(member.role, equals('Father'));
        expect(member.color, equals(const Color(0xFF6F61EF)));
        expect(
            member.profileImageUrl, equals('https://example.com/avatar.jpg'));
        expect(member.userId, equals('user-123'));
        expect(member.email, equals('john@example.com'));
        expect(member.isOwner, isTrue);
        expect(member.createdAt, equals(testDate));
      });

      test('should handle missing optional fields', () {
        final json = {
          'id': 'test-id-123',
          'name': 'John Doe',
          'role': 'Father',
          'colorValue': 0xFF6F61EF,
          'createdAt': testDate.toIso8601String(),
        };

        final member = FamilyMember.fromJson(json);

        expect(member.profileImageUrl, isNull);
        expect(member.userId, isNull);
        expect(member.email, isNull);
        expect(member.isOwner, isFalse);
      });
    });

    group('toFirestore', () {
      test('should convert FamilyMember to Firestore format', () {
        final firestoreData = testMember.toFirestore();

        expect(firestoreData['name'], equals('John Doe'));
        expect(firestoreData['role'], equals('Father'));
        expect(firestoreData['colorValue'], equals(0xFF6F61EF));
        expect(firestoreData['profileImageUrl'],
            equals('https://example.com/avatar.jpg'));
        expect(firestoreData['userId'], equals('user-123'));
        expect(firestoreData['email'], equals('john@example.com'));
        expect(firestoreData['isOwner'], isTrue);
        // Note: createdAt is not included in toFirestore
        expect(firestoreData.containsKey('createdAt'), isFalse);
      });
    });

    group('fromFirestore', () {
      test('should create FamilyMember from Firestore data', () {
        final firestoreData = {
          'name': 'John Doe',
          'role': 'Father',
          'colorValue': 0xFF6F61EF,
          'profileImageUrl': 'https://example.com/avatar.jpg',
          'userId': 'user-123',
          'email': 'john@example.com',
          'isOwner': true,
          'createdAt': Timestamp.fromDate(testDate),
        };

        final member = FamilyMember.fromFirestore('test-id-123', firestoreData);

        expect(member.id, equals('test-id-123'));
        expect(member.name, equals('John Doe'));
        expect(member.role, equals('Father'));
        expect(member.color, equals(const Color(0xFF6F61EF)));
        expect(
            member.profileImageUrl, equals('https://example.com/avatar.jpg'));
        expect(member.userId, equals('user-123'));
        expect(member.email, equals('john@example.com'));
        expect(member.isOwner, isTrue);
        expect(member.createdAt, equals(testDate));
      });

      test('should handle missing Firestore data with defaults', () {
        final firestoreData = <String, dynamic>{};

        final member = FamilyMember.fromFirestore('test-id-123', firestoreData);

        expect(member.id, equals('test-id-123'));
        expect(member.name, equals(''));
        expect(member.role, equals(''));
        expect(member.color, equals(const Color(0xFF6F61EF))); // default color
        expect(member.profileImageUrl, isNull);
        expect(member.userId, isNull);
        expect(member.email, isNull);
        expect(member.isOwner, isFalse);
        expect(member.createdAt.year,
            equals(DateTime.now().year)); // should be current time
      });
    });

    group('copyWith', () {
      test('should create a copy with updated fields', () {
        final updatedMember = testMember.copyWith(
          name: 'Jane Doe',
          role: 'Mother',
          color: const Color(0xFF39D2C0),
          isOwner: false,
        );

        expect(updatedMember.id, equals(testMember.id));
        expect(updatedMember.name, equals('Jane Doe'));
        expect(updatedMember.role, equals('Mother'));
        expect(updatedMember.color, equals(const Color(0xFF39D2C0)));
        expect(updatedMember.isOwner, isFalse);
        expect(updatedMember.createdAt, equals(testMember.createdAt));
      });

      test('should keep original values when fields are not specified', () {
        final updatedMember = testMember.copyWith(name: 'Jane Doe');

        expect(updatedMember.id, equals(testMember.id));
        expect(updatedMember.name, equals('Jane Doe'));
        expect(updatedMember.role, equals(testMember.role));
        expect(updatedMember.color, equals(testMember.color));
        expect(
            updatedMember.profileImageUrl, equals(testMember.profileImageUrl));
        expect(updatedMember.userId, equals(testMember.userId));
        expect(updatedMember.email, equals(testMember.email));
        expect(updatedMember.isOwner, equals(testMember.isOwner));
        expect(updatedMember.createdAt, equals(testMember.createdAt));
      });
    });

    group('getSampleMembers', () {
      test('should return a list of sample family members', () {
        final sampleMembers = FamilyMember.getSampleMembers();

        expect(sampleMembers, hasLength(4));
        expect(sampleMembers[0].name, equals('Sarah'));
        expect(sampleMembers[0].role, equals('Mom'));
        expect(sampleMembers[0].isOwner, isTrue);
        expect(sampleMembers[1].name, equals('Mike'));
        expect(sampleMembers[1].role, equals('Dad'));
        expect(sampleMembers[2].name, equals('Emma'));
        expect(sampleMembers[2].role, equals('Daughter'));
        expect(sampleMembers[3].name, equals('Jake'));
        expect(sampleMembers[3].role, equals('Son'));
      });

      test('should have unique IDs for sample members', () {
        final sampleMembers = FamilyMember.getSampleMembers();
        final ids = sampleMembers.map((member) => member.id).toSet();

        expect(ids, hasLength(4));
        expect(ids.contains('1'), isTrue);
        expect(ids.contains('2'), isTrue);
        expect(ids.contains('3'), isTrue);
        expect(ids.contains('4'), isTrue);
      });
    });
  });
}
