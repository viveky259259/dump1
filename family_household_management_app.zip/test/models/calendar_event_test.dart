import 'package:flutter_test/flutter_test.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/models/calendar_event.dart';

void main() {
  group('CalendarEvent', () {
    late CalendarEvent testEvent;
    late DateTime testDate;
    late DateTime eventDate;
    late DateTime reminderDate;

    setUp(() {
      testDate = DateTime(2024, 1, 15, 10, 30);
      eventDate = DateTime(2024, 1, 20, 14, 0);
      reminderDate = DateTime(2024, 1, 20, 13, 0);
      testEvent = CalendarEvent(
        id: 'event-123',
        title: 'Family Movie Night',
        description: 'Weekly family bonding time',
        date: eventDate,
        assignedMemberId: 'member-1',
        category: 'Family Activity',
        hasReminder: true,
        reminderTime: reminderDate,
        isCompleted: false,
        createdAt: testDate,
      );
    });

    group('Constructor', () {
      test('should create CalendarEvent with all required fields', () {
        expect(testEvent.id, equals('event-123'));
        expect(testEvent.title, equals('Family Movie Night'));
        expect(testEvent.description, equals('Weekly family bonding time'));
        expect(testEvent.date, equals(eventDate));
        expect(testEvent.assignedMemberId, equals('member-1'));
        expect(testEvent.category, equals('Family Activity'));
        expect(testEvent.hasReminder, isTrue);
        expect(testEvent.reminderTime, equals(reminderDate));
        expect(testEvent.isCompleted, isFalse);
        expect(testEvent.createdAt, equals(testDate));
      });

      test('should create CalendarEvent with minimal fields', () {
        final minimalEvent = CalendarEvent(
          title: 'Simple Event',
          description: 'A simple event',
          date: eventDate,
          assignedMemberId: 'member-2',
          category: 'Personal',
          createdAt: testDate,
        );

        expect(minimalEvent.id, isNull);
        expect(minimalEvent.title, equals('Simple Event'));
        expect(minimalEvent.description, equals('A simple event'));
        expect(minimalEvent.date, equals(eventDate));
        expect(minimalEvent.assignedMemberId, equals('member-2'));
        expect(minimalEvent.category, equals('Personal'));
        expect(minimalEvent.hasReminder, isFalse);
        expect(minimalEvent.reminderTime, isNull);
        expect(minimalEvent.isCompleted, isFalse);
        expect(minimalEvent.createdAt, equals(testDate));
      });

      test('should create completed event', () {
        final completedEvent = CalendarEvent(
          id: 'event-456',
          title: 'Completed Event',
          description: 'An event that is done',
          date: eventDate,
          assignedMemberId: 'member-3',
          category: 'Work',
          isCompleted: true,
          createdAt: testDate,
        );

        expect(completedEvent.isCompleted, isTrue);
      });
    });

    group('toJson', () {
      test('should convert CalendarEvent to JSON correctly', () {
        final json = testEvent.toJson();

        expect(json['id'], equals('event-123'));
        expect(json['title'], equals('Family Movie Night'));
        expect(json['description'], equals('Weekly family bonding time'));
        expect(json['date'], equals(eventDate.toIso8601String()));
        expect(json['assignedMemberId'], equals('member-1'));
        expect(json['category'], equals('Family Activity'));
        expect(json['hasReminder'], isTrue);
        expect(json['reminderTime'], equals(reminderDate.toIso8601String()));
        expect(json['isCompleted'], isFalse);
        expect(json['createdAt'], equals(testDate.toIso8601String()));
      });

      test('should handle event without reminder in JSON', () {
        final eventWithoutReminder = testEvent.copyWith(
          hasReminder: false,
          reminderTime: null,
        );

        final json = eventWithoutReminder.toJson();

        expect(json['hasReminder'], isFalse);
        expect(json['reminderTime'], isNull);
      });

      test('should handle completed event in JSON', () {
        final completedEvent = testEvent.copyWith(isCompleted: true);

        final json = completedEvent.toJson();

        expect(json['isCompleted'], isTrue);
      });
    });

    group('fromJson', () {
      test('should create CalendarEvent from JSON correctly', () {
        final json = {
          'id': 'event-123',
          'title': 'Family Movie Night',
          'description': 'Weekly family bonding time',
          'date': eventDate.toIso8601String(),
          'assignedMemberId': 'member-1',
          'category': 'Family Activity',
          'hasReminder': true,
          'reminderTime': reminderDate.toIso8601String(),
          'isCompleted': false,
          'createdAt': testDate.toIso8601String(),
        };

        final event = CalendarEvent.fromJson(json);

        expect(event.id, equals('event-123'));
        expect(event.title, equals('Family Movie Night'));
        expect(event.description, equals('Weekly family bonding time'));
        expect(event.date, equals(eventDate));
        expect(event.assignedMemberId, equals('member-1'));
        expect(event.category, equals('Family Activity'));
        expect(event.hasReminder, isTrue);
        expect(event.reminderTime, equals(reminderDate));
        expect(event.isCompleted, isFalse);
        expect(event.createdAt, equals(testDate));
      });

      test('should handle event without reminder from JSON', () {
        final json = {
          'id': 'event-123',
          'title': 'Simple Event',
          'description': 'A simple event',
          'date': eventDate.toIso8601String(),
          'assignedMemberId': 'member-2',
          'category': 'Personal',
          'hasReminder': false,
          'reminderTime': null,
          'isCompleted': false,
          'createdAt': testDate.toIso8601String(),
        };

        final event = CalendarEvent.fromJson(json);

        expect(event.hasReminder, isFalse);
        expect(event.reminderTime, isNull);
      });

      test('should handle completed event from JSON', () {
        final json = {
          'id': 'event-123',
          'title': 'Completed Event',
          'description': 'An event that is done',
          'date': eventDate.toIso8601String(),
          'assignedMemberId': 'member-3',
          'category': 'Work',
          'hasReminder': false,
          'reminderTime': null,
          'isCompleted': true,
          'createdAt': testDate.toIso8601String(),
        };

        final event = CalendarEvent.fromJson(json);

        expect(event.isCompleted, isTrue);
      });
    });

    group('toFirestore', () {
      test('should convert CalendarEvent to Firestore format', () {
        final firestoreData = testEvent.toFirestore();

        expect(firestoreData['title'], equals('Family Movie Night'));
        expect(
            firestoreData['description'], equals('Weekly family bonding time'));
        expect(firestoreData['date'], isA<Timestamp>());
        expect(
            (firestoreData['date'] as Timestamp).toDate(), equals(eventDate));
        expect(firestoreData['assignedMemberId'], equals('member-1'));
        expect(firestoreData['category'], equals('Family Activity'));
        expect(firestoreData['hasReminder'], isTrue);
        expect(firestoreData['reminderTime'], isA<Timestamp>());
        expect((firestoreData['reminderTime'] as Timestamp).toDate(),
            equals(reminderDate));
        expect(firestoreData['isCompleted'], isFalse);
        // Note: createdAt is not included in toFirestore
        expect(firestoreData.containsKey('createdAt'), isFalse);
      });

      test('should handle event without reminder in Firestore format', () {
        final eventWithoutReminder = testEvent.copyWith(
          hasReminder: false,
          reminderTime: null,
        );

        final firestoreData = eventWithoutReminder.toFirestore();

        expect(firestoreData['hasReminder'], isFalse);
        expect(firestoreData['reminderTime'], isNull);
      });
    });

    group('fromFirestore', () {
      test('should create CalendarEvent from Firestore data', () {
        final firestoreData = {
          'title': 'Family Movie Night',
          'description': 'Weekly family bonding time',
          'date': Timestamp.fromDate(eventDate),
          'assignedMemberId': 'member-1',
          'category': 'Family Activity',
          'hasReminder': true,
          'reminderTime': Timestamp.fromDate(reminderDate),
          'isCompleted': false,
          'createdAt': Timestamp.fromDate(testDate),
        };

        final event = CalendarEvent.fromFirestore('event-123', firestoreData);

        expect(event.id, equals('event-123'));
        expect(event.title, equals('Family Movie Night'));
        expect(event.description, equals('Weekly family bonding time'));
        expect(event.date, equals(eventDate));
        expect(event.assignedMemberId, equals('member-1'));
        expect(event.category, equals('Family Activity'));
        expect(event.hasReminder, isTrue);
        expect(event.reminderTime, equals(reminderDate));
        expect(event.isCompleted, isFalse);
        expect(event.createdAt, equals(testDate));
      });

      test('should handle missing Firestore data with defaults', () {
        final firestoreData = <String, dynamic>{};

        final event = CalendarEvent.fromFirestore('event-123', firestoreData);

        expect(event.id, equals('event-123'));
        expect(event.title, equals(''));
        expect(event.description, equals(''));
        expect(event.assignedMemberId, equals(''));
        expect(event.category, equals('Other'));
        expect(event.hasReminder, isFalse);
        expect(event.reminderTime, isNull);
        expect(event.isCompleted, isFalse);
        expect(event.date.year, equals(DateTime.now().year));
        expect(event.createdAt.year, equals(DateTime.now().year));
      });
    });

    group('copyWith', () {
      test('should create a copy with updated fields', () {
        final newEventDate = DateTime(2024, 1, 25, 15, 0);
        final newReminderDate = DateTime(2024, 1, 25, 14, 0);
        final updatedEvent = testEvent.copyWith(
          title: 'Updated Movie Night',
          date: newEventDate,
          reminderTime: newReminderDate,
          isCompleted: true,
        );

        expect(updatedEvent.id, equals(testEvent.id));
        expect(updatedEvent.title, equals('Updated Movie Night'));
        expect(updatedEvent.date, equals(newEventDate));
        expect(updatedEvent.reminderTime, equals(newReminderDate));
        expect(updatedEvent.isCompleted, isTrue);
        expect(updatedEvent.description, equals(testEvent.description));
        expect(
            updatedEvent.assignedMemberId, equals(testEvent.assignedMemberId));
        expect(updatedEvent.category, equals(testEvent.category));
        expect(updatedEvent.hasReminder, equals(testEvent.hasReminder));
        expect(updatedEvent.createdAt, equals(testEvent.createdAt));
      });

      test('should keep original values when fields are not specified', () {
        final updatedEvent = testEvent.copyWith(title: 'New Title');

        expect(updatedEvent.id, equals(testEvent.id));
        expect(updatedEvent.title, equals('New Title'));
        expect(updatedEvent.description, equals(testEvent.description));
        expect(updatedEvent.date, equals(testEvent.date));
        expect(
            updatedEvent.assignedMemberId, equals(testEvent.assignedMemberId));
        expect(updatedEvent.category, equals(testEvent.category));
        expect(updatedEvent.hasReminder, equals(testEvent.hasReminder));
        expect(updatedEvent.reminderTime, equals(testEvent.reminderTime));
        expect(updatedEvent.isCompleted, equals(testEvent.isCompleted));
        expect(updatedEvent.createdAt, equals(testEvent.createdAt));
      });
    });

    group('Static properties', () {
      test('should return correct categories', () {
        final categories = CalendarEvent.categories;

        expect(categories, contains('Birthday'));
        expect(categories, contains('Anniversary'));
        expect(categories, contains('Appointment'));
        expect(categories, contains('School Event'));
        expect(categories, contains('Family Activity'));
        expect(categories, contains('Work'));
        expect(categories, contains('Personal'));
        expect(categories, contains('Holiday'));
        expect(categories, contains('Reminder'));
        expect(categories, contains('Other'));
        expect(categories, hasLength(10));
      });
    });

    group('getSampleEvents', () {
      test('should return a list of sample events', () {
        final sampleEvents = CalendarEvent.getSampleEvents();

        expect(sampleEvents, hasLength(5));
        expect(sampleEvents[0].title, equals('Emma\'s Soccer Practice'));
        expect(sampleEvents[0].category, equals('School Event'));
        expect(sampleEvents[0].hasReminder, isTrue);
        expect(sampleEvents[1].title, equals('Family Movie Night'));
        expect(sampleEvents[1].category, equals('Family Activity'));
        expect(sampleEvents[2].title, equals('Jake\'s Birthday Party'));
        expect(sampleEvents[2].category, equals('Birthday'));
        expect(sampleEvents[3].title, equals('Doctor Appointment'));
        expect(sampleEvents[3].category, equals('Appointment'));
        expect(sampleEvents[4].title, equals('Parent-Teacher Conference'));
        expect(sampleEvents[4].category, equals('School Event'));
      });

      test('should have unique IDs for sample events', () {
        final sampleEvents = CalendarEvent.getSampleEvents();
        final ids = sampleEvents.map((event) => event.id).toSet();

        expect(ids, hasLength(5));
        expect(ids.contains('1'), isTrue);
        expect(ids.contains('2'), isTrue);
        expect(ids.contains('3'), isTrue);
        expect(ids.contains('4'), isTrue);
        expect(ids.contains('5'), isTrue);
      });

      test('should have events with reminders', () {
        final sampleEvents = CalendarEvent.getSampleEvents();
        final eventsWithReminders =
            sampleEvents.where((event) => event.hasReminder).toList();

        expect(eventsWithReminders, hasLength(5));
        expect(eventsWithReminders.every((event) => event.reminderTime != null),
            isTrue);
      });
    });
  });
}
