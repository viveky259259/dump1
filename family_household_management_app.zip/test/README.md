# Family Household Management App - Test Suite

This directory contains comprehensive unit tests for the Family Household Management App.

## Test Structure

```
test/
├── models/                    # Model unit tests
│   ├── family_member_test.dart
│   ├── household_task_test.dart
│   ├── item_tracker_test.dart
│   ├── calendar_event_test.dart
│   ├── emergency_contact_test.dart
│   └── models_test.dart       # Model test runner
├── services/                  # Service unit tests
│   └── navigation_service_test.dart
├── widget_test.dart           # Widget integration tests
├── all_tests.dart            # Comprehensive test runner
└── README.md                 # This file
```

## Running Tests

### Run All Tests
```bash
flutter test test/all_tests.dart
```

### Run Specific Test Categories

#### Model Tests Only
```bash
flutter test test/models/models_test.dart
```

#### Individual Model Tests
```bash
flutter test test/models/family_member_test.dart
flutter test test/models/household_task_test.dart
flutter test test/models/item_tracker_test.dart
flutter test test/models/calendar_event_test.dart
flutter test test/models/emergency_contact_test.dart
```

#### Service Tests
```bash
flutter test test/services/navigation_service_test.dart
```

#### Widget Tests
```bash
flutter test test/widget_test.dart
```

### Run Tests with Coverage
```bash
flutter test --coverage
```

### Run Tests with Verbose Output
```bash
flutter test --verbose
```

## Test Coverage

### Model Tests
- **FamilyMember**: Tests constructor, JSON serialization, Firestore conversion, copyWith, and static methods
- **HouseholdTask**: Tests constructor, JSON serialization, Firestore conversion, copyWith, static properties, and business logic
- **TrackedItem**: Tests constructor, JSON serialization, Firestore conversion, copyWith, static properties, and item status logic
- **ItemHistory**: Tests constructor, JSON serialization, and Firestore conversion
- **CalendarEvent**: Tests constructor, JSON serialization, Firestore conversion, copyWith, and static properties
- **EmergencyContact**: Tests constructor, JSON serialization, Firestore conversion, copyWith, and static properties

### Service Tests
- **NavigationService**: Tests singleton pattern, tab navigation, state management, and change notification

### Widget Tests
- **App Integration**: Tests app initialization, navigation, theme, and provider setup
- **Responsiveness**: Tests app behavior on different screen sizes
- **Navigation Integration**: Tests UI updates when navigation service changes

## Test Features

### Comprehensive Coverage
- Constructor validation
- JSON serialization/deserialization
- Firestore data conversion
- Business logic validation
- Edge cases and error handling
- Static properties and methods
- State management
- UI integration

### Test Organization
- Grouped by functionality
- Clear test descriptions
- Proper setup and teardown
- Isolated test cases
- Meaningful assertions

### Best Practices
- Uses `setUp()` for test initialization
- Tests both success and failure scenarios
- Validates data integrity
- Tests edge cases and boundary conditions
- Uses descriptive test names
- Follows AAA pattern (Arrange, Act, Assert)

## Adding New Tests

### For New Models
1. Create a new test file in `test/models/`
2. Follow the existing pattern with groups for different aspects
3. Test constructor, JSON methods, Firestore methods, and business logic
4. Add to `test/models/models_test.dart`

### For New Services
1. Create a new test file in `test/services/`
2. Test public methods, state changes, and error handling
3. Mock dependencies as needed

### For New Widgets
1. Add widget tests to `test/widget_test.dart` or create a new file
2. Test widget rendering, user interactions, and state changes
3. Test integration with services and providers

## Test Dependencies

The tests use the following Flutter testing packages:
- `flutter_test`: Core testing framework
- `provider`: For testing provider integration
- `cloud_firestore`: For testing Firestore data conversion

## Continuous Integration

These tests are designed to run in CI/CD pipelines and provide:
- Fast execution
- Reliable results
- Clear failure messages
- Good coverage reporting

## Troubleshooting

### Common Issues
1. **Firebase not initialized**: Tests handle missing Firebase gracefully
2. **Provider not found**: Ensure all required providers are set up in test widgets
3. **Async operations**: Use `pumpAndSettle()` for async widget tests

### Debugging Tests
```bash
# Run with debug output
flutter test --verbose

# Run specific test with debug
flutter test test/models/family_member_test.dart --verbose

# Run with coverage report
flutter test --coverage && genhtml coverage/lcov.info -o coverage/html
``` 