// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:dreamflow/main.dart';
import 'package:dreamflow/services/navigation_service.dart';
import 'package:dreamflow/providers/firebase_data_provider.dart';

void main() {
  group('App Widget Tests', () {
    testWidgets('App should start and show home page',
        (WidgetTester tester) async {
      // Build our app and trigger a frame.
      await tester.pumpWidget(const FamilyHubApp());

      // Verify that the app starts and shows the home page
      expect(find.byType(MaterialApp), findsOneWidget);

      // Wait for the app to fully load
      await tester.pumpAndSettle();

      // Verify that the main navigation is present
      expect(find.byType(BottomNavigationBar), findsOneWidget);

      // Verify that we're on the home tab initially
      expect(find.text('Home'), findsOneWidget);
    });

    testWidgets('Navigation between tabs should work',
        (WidgetTester tester) async {
      await tester.pumpWidget(const FamilyHubApp());
      await tester.pumpAndSettle();

      // Test navigation to Calendar tab
      await tester.tap(find.text('Calendar'));
      await tester.pumpAndSettle();
      expect(find.text('Calendar'), findsOneWidget);

      // Test navigation to Tasks tab
      await tester.tap(find.text('Tasks'));
      await tester.pumpAndSettle();
      expect(find.text('Tasks'), findsOneWidget);

      // Test navigation to Items tab
      await tester.tap(find.text('Items'));
      await tester.pumpAndSettle();
      expect(find.text('Items'), findsOneWidget);

      // Test navigation back to Home tab
      await tester.tap(find.text('Home'));
      await tester.pumpAndSettle();
      expect(find.text('Home'), findsOneWidget);
    });

    testWidgets('App should have proper theme and styling',
        (WidgetTester tester) async {
      await tester.pumpWidget(const FamilyHubApp());
      await tester.pumpAndSettle();

      // Verify that the app has a proper theme
      final MaterialApp app = tester.widget(find.byType(MaterialApp));
      expect(app.theme, isNotNull);
      expect(app.theme!.colorScheme, isNotNull);
    });

    testWidgets('App should handle provider dependencies',
        (WidgetTester tester) async {
      await tester.pumpWidget(const FamilyHubApp());
      await tester.pumpAndSettle();

      // Verify that providers are properly set up
      expect(find.byType(ChangeNotifierProvider<NavigationService>),
          findsOneWidget);
    });
  });

  group('Navigation Service Integration', () {
    testWidgets('Navigation service should update UI when tab changes',
        (WidgetTester tester) async {
      await tester.pumpWidget(const FamilyHubApp());
      await tester.pumpAndSettle();

      // Get the navigation service instance
      final navigationService = NavigationService.instance;

      // Change tab programmatically
      navigationService.setMainTab(NavigationService.calendarTab);
      await tester.pumpAndSettle();

      // Verify UI reflects the change
      expect(find.text('Calendar'), findsOneWidget);

      // Change to another tab
      navigationService.setMainTab(NavigationService.tasksTab);
      await tester.pumpAndSettle();

      // Verify UI reflects the change
      expect(find.text('Tasks'), findsOneWidget);
    });
  });

  group('App Responsiveness', () {
    testWidgets('App should handle different screen sizes',
        (WidgetTester tester) async {
      // Test with a smaller screen size
      tester.binding.window.physicalSizeTestValue = const Size(320, 568);
      tester.binding.window.devicePixelRatioTestValue = 1.0;

      await tester.pumpWidget(const FamilyHubApp());
      await tester.pumpAndSettle();

      // Verify app still works on smaller screen
      expect(find.byType(MaterialApp), findsOneWidget);
      expect(find.byType(BottomNavigationBar), findsOneWidget);

      // Reset to default size
      tester.binding.window.clearPhysicalSizeTestValue();
      tester.binding.window.clearDevicePixelRatioTestValue();
    });
  });

  group('App Initialization', () {
    testWidgets('App should initialize without errors',
        (WidgetTester tester) async {
      // This test ensures the app can be built without throwing exceptions
      expect(() async {
        await tester.pumpWidget(const FamilyHubApp());
        await tester.pumpAndSettle();
      }, returnsNormally);
    });

    testWidgets('App should show loading state initially',
        (WidgetTester tester) async {
      await tester.pumpWidget(const FamilyHubApp());

      // The app should show some initial content
      expect(find.byType(MaterialApp), findsOneWidget);

      // Wait for the app to settle
      await tester.pumpAndSettle();

      // Should show the main navigation
      expect(find.byType(BottomNavigationBar), findsOneWidget);
    });
  });
}
