import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:dreamflow/services/navigation_service.dart';

void main() {
  group('NavigationService', () {
    late NavigationService navigationService;

    setUp(() {
      navigationService = NavigationService.instance;
      // Reset to home tab before each test
      navigationService.setMainTab(NavigationService.homeTab);
    });

    group('Singleton Pattern', () {
      test('should return the same instance', () {
        final instance1 = NavigationService.instance;
        final instance2 = NavigationService.instance;

        expect(identical(instance1, instance2), isTrue);
      });
    });

    group('Initial State', () {
      test('should start at home tab', () {
        expect(navigationService.currentMainTab,
            equals(NavigationService.homeTab));
      });

      test('should return correct initial tab name', () {
        expect(navigationService.currentTabName, equals('Home'));
      });

      test('should return correct initial tab icon', () {
        expect(navigationService.currentTabIcon, equals(Icons.home_rounded));
      });
    });

    group('setMainTab', () {
      test('should change to calendar tab', () {
        navigationService.setMainTab(NavigationService.calendarTab);

        expect(navigationService.currentMainTab,
            equals(NavigationService.calendarTab));
        expect(navigationService.currentTabName, equals('Calendar'));
        expect(navigationService.currentTabIcon,
            equals(Icons.calendar_month_rounded));
      });

      test('should change to tasks tab', () {
        navigationService.setMainTab(NavigationService.tasksTab);

        expect(navigationService.currentMainTab,
            equals(NavigationService.tasksTab));
        expect(navigationService.currentTabName, equals('Tasks'));
        expect(
            navigationService.currentTabIcon, equals(Icons.task_alt_rounded));
      });

      test('should change to items tab', () {
        navigationService.setMainTab(NavigationService.itemsTab);

        expect(navigationService.currentMainTab,
            equals(NavigationService.itemsTab));
        expect(navigationService.currentTabName, equals('Items'));
        expect(navigationService.currentTabIcon,
            equals(Icons.inventory_2_rounded));
      });

      test('should not change when setting same tab', () {
        final initialTab = navigationService.currentMainTab;
        navigationService.setMainTab(initialTab);

        expect(navigationService.currentMainTab, equals(initialTab));
      });

      test('should not change when setting invalid negative index', () {
        final initialTab = navigationService.currentMainTab;
        navigationService.setMainTab(-1);

        expect(navigationService.currentMainTab, equals(initialTab));
      });

      test('should not change when setting invalid high index', () {
        final initialTab = navigationService.currentMainTab;
        navigationService.setMainTab(10);

        expect(navigationService.currentMainTab, equals(initialTab));
      });
    });

    group('Navigation Methods', () {
      test('navigateToHome should set home tab', () {
        navigationService.setMainTab(NavigationService.calendarTab);
        navigationService.navigateToHome();

        expect(navigationService.currentMainTab,
            equals(NavigationService.homeTab));
        expect(navigationService.currentTabName, equals('Home'));
        expect(navigationService.currentTabIcon, equals(Icons.home_rounded));
      });

      test('navigateToCalendar should set calendar tab', () {
        navigationService.navigateToCalendar();

        expect(navigationService.currentMainTab,
            equals(NavigationService.calendarTab));
        expect(navigationService.currentTabName, equals('Calendar'));
        expect(navigationService.currentTabIcon,
            equals(Icons.calendar_month_rounded));
      });

      test('navigateToTasks should set tasks tab', () {
        navigationService.navigateToTasks();

        expect(navigationService.currentMainTab,
            equals(NavigationService.tasksTab));
        expect(navigationService.currentTabName, equals('Tasks'));
        expect(
            navigationService.currentTabIcon, equals(Icons.task_alt_rounded));
      });

      test('navigateToItems should set items tab', () {
        navigationService.navigateToItems();

        expect(navigationService.currentMainTab,
            equals(NavigationService.itemsTab));
        expect(navigationService.currentTabName, equals('Items'));
        expect(navigationService.currentTabIcon,
            equals(Icons.inventory_2_rounded));
      });
    });

    group('Tab Properties', () {
      test('should return correct tab names for all tabs', () {
        final expectedNames = ['Home', 'Calendar', 'Tasks', 'Items'];

        for (int i = 0; i < expectedNames.length; i++) {
          navigationService.setMainTab(i);
          expect(navigationService.currentTabName, equals(expectedNames[i]));
        }
      });

      test('should return correct tab icons for all tabs', () {
        final expectedIcons = [
          Icons.home_rounded,
          Icons.calendar_month_rounded,
          Icons.task_alt_rounded,
          Icons.inventory_2_rounded,
        ];

        for (int i = 0; i < expectedIcons.length; i++) {
          navigationService.setMainTab(i);
          expect(navigationService.currentTabIcon, equals(expectedIcons[i]));
        }
      });

      test('should return default values for invalid tab index', () {
        // Set to an invalid index (this shouldn't happen in normal usage)
        navigationService.setMainTab(999);

        expect(navigationService.currentTabName, equals('Home'));
        expect(navigationService.currentTabIcon, equals(Icons.home_rounded));
      });
    });

    group('Tab Constants', () {
      test('should have correct tab index constants', () {
        expect(NavigationService.homeTab, equals(0));
        expect(NavigationService.calendarTab, equals(1));
        expect(NavigationService.tasksTab, equals(2));
        expect(NavigationService.itemsTab, equals(3));
      });
    });

    group('Change Notifier', () {
      test('should notify listeners when tab changes', () {
        bool listenerCalled = false;
        navigationService.addListener(() {
          listenerCalled = true;
        });

        navigationService.setMainTab(NavigationService.calendarTab);

        expect(listenerCalled, isTrue);
      });

      test('should not notify listeners when tab does not change', () {
        bool listenerCalled = false;
        navigationService.addListener(() {
          listenerCalled = true;
        });

        navigationService
            .setMainTab(NavigationService.homeTab); // Already at home

        expect(listenerCalled, isFalse);
      });
    });

    group('Tab Navigation Flow', () {
      test('should navigate through all tabs correctly', () {
        // Start at home
        expect(navigationService.currentMainTab,
            equals(NavigationService.homeTab));

        // Navigate to calendar
        navigationService.navigateToCalendar();
        expect(navigationService.currentMainTab,
            equals(NavigationService.calendarTab));

        // Navigate to tasks
        navigationService.navigateToTasks();
        expect(navigationService.currentMainTab,
            equals(NavigationService.tasksTab));

        // Navigate to items
        navigationService.navigateToItems();
        expect(navigationService.currentMainTab,
            equals(NavigationService.itemsTab));

        // Navigate back to home
        navigationService.navigateToHome();
        expect(navigationService.currentMainTab,
            equals(NavigationService.homeTab));
      });

      test('should maintain correct state through multiple navigation calls',
          () {
        // Navigate to calendar
        navigationService.navigateToCalendar();
        expect(navigationService.currentMainTab,
            equals(NavigationService.calendarTab));

        // Call navigateToCalendar again (should not change)
        navigationService.navigateToCalendar();
        expect(navigationService.currentMainTab,
            equals(NavigationService.calendarTab));

        // Navigate to tasks
        navigationService.navigateToTasks();
        expect(navigationService.currentMainTab,
            equals(NavigationService.tasksTab));

        // Navigate to calendar again
        navigationService.navigateToCalendar();
        expect(navigationService.currentMainTab,
            equals(NavigationService.calendarTab));
      });
    });
  });
}
