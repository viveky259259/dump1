// Comprehensive test runner for the Family Household Management App
// Run with: flutter test test/all_tests.dart

// Model tests
import 'models/family_member_test.dart' as family_member_test;
import 'models/household_task_test.dart' as household_task_test;
import 'models/item_tracker_test.dart' as item_tracker_test;
import 'models/calendar_event_test.dart' as calendar_event_test;
import 'models/emergency_contact_test.dart' as emergency_contact_test;

// Service tests
import 'services/navigation_service_test.dart' as navigation_service_test;

// Widget tests
import 'widget_test.dart' as widget_test;

void main() {
  // Run all model tests
  print('Running Model Tests...');
  family_member_test.main();
  household_task_test.main();
  item_tracker_test.main();
  calendar_event_test.main();
  emergency_contact_test.main();

  // Run all service tests
  print('Running Service Tests...');
  navigation_service_test.main();

  // Run all widget tests
  print('Running Widget Tests...');
  widget_test.main();

  print('All tests completed!');
}
