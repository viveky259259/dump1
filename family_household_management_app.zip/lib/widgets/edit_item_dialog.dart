import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../models/item_tracker.dart';
import '../models/family_member.dart';
import '../services/firebase_data_sync_service.dart';
import '../services/data_service.dart';


class EditItemDialog extends StatefulWidget {
  final TrackedItem item;
  final List<FamilyMember> familyMembers;

  const EditItemDialog({
    super.key,
    required this.item,
    required this.familyMembers,
  });

  @override
  State<EditItemDialog> createState() => _EditItemDialogState();
}

class _EditItemDialogState extends State<EditItemDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _descriptionController;
  late final TextEditingController _locationController;
  
  late String _selectedStatus;
  late String _selectedCategory;
  String? _selectedBorrowedBy;
  String? _currentImageUrl;
  bool _isLoadingImage = false;
  bool _isUpdating = false;

  final List<String> _statuses = ['Available', 'Borrowed', 'In Use', 'Maintenance'];
  final List<String> _categories = [
    'Electronics',
    'Books',
    'Tools',
    'Sports',
    'Kitchen',
    'Clothing',
    'Toys',
    'Other'
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.item.name);
    _descriptionController = TextEditingController(text: widget.item.description);
    _locationController = TextEditingController(text: widget.item.currentLocation);
    _selectedStatus = widget.item.status;
    _selectedCategory = widget.item.category;
    _selectedBorrowedBy = widget.item.borrowedByMemberId;
    _loadItemImage();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  Future<void> _loadItemImage() async {
    setState(() => _isLoadingImage = true);
    try {
      // Generate image based on item category and name
      final imageUrl = await "https://upload.wikimedia.org/wikipedia/commons/3/3f/Dash_the_dart_mascot.png";
      setState(() {
        _currentImageUrl = imageUrl;
        _isLoadingImage = false;
      });
    } catch (e) {
      setState(() => _isLoadingImage = false);
    }
  }

  Future<void> _refreshImage() async {
    setState(() => _isLoadingImage = true);
    try {
      // Generate new image with updated details
      final imageUrl = await "https://upload.wikimedia.org/wikipedia/commons/3/3f/Dash_the_dart_mascot.png";
      setState(() {
        _currentImageUrl = imageUrl;
        _isLoadingImage = false;
      });
    } catch (e) {
      setState(() => _isLoadingImage = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Dialog(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500, maxHeight: 700),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer.withOpacity(0.3),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.edit_rounded,
                    color: theme.colorScheme.primary,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Edit Item',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded),
                    style: IconButton.styleFrom(
                      backgroundColor: theme.colorScheme.surface,
                    ),
                  ),
                ],
              ),
            ),
            
            // Content
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Item Image
                      Center(
                        child: Stack(
                          children: [
                            Container(
                              width: 120,
                              height: 120,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: theme.colorScheme.outline.withOpacity(0.2),
                                ),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: _isLoadingImage
                                    ? Container(
                                        color: theme.colorScheme.surfaceContainerHighest,
                                        child: const Center(
                                          child: CircularProgressIndicator(),
                                        ),
                                      )
                                    : _currentImageUrl != null
                                        ? Image.network(
                                            _currentImageUrl!,
                                            fit: BoxFit.cover,
                                            errorBuilder: (context, error, stackTrace) {
                                              return Container(
                                                color: theme.colorScheme.surfaceContainerHighest,
                                                child: Icon(
                                                  Icons.inventory_2_rounded,
                                                  size: 40,
                                                  color: theme.colorScheme.onSurface.withOpacity(0.3),
                                                ),
                                              );
                                            },
                                          )
                                        : Container(
                                            color: theme.colorScheme.surfaceContainerHighest,
                                            child: Icon(
                                              Icons.inventory_2_rounded,
                                              size: 40,
                                              color: theme.colorScheme.onSurface.withOpacity(0.3),
                                            ),
                                          ),
                              ),
                            ),
                            Positioned(
                              bottom: 4,
                              right: 4,
                              child: GestureDetector(
                                onTap: _refreshImage,
                                child: Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: theme.colorScheme.primary,
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.2),
                                        blurRadius: 4,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                  child: Icon(
                                    Icons.refresh_rounded,
                                    size: 16,
                                    color: theme.colorScheme.onPrimary,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Item Name
                      _buildTextField(
                        controller: _nameController,
                        label: 'Item Name *',
                        icon: Icons.inventory_2_rounded,
                        validator: (value) =>
                            value?.isEmpty ?? true ? 'Please enter item name' : null,
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Description
                      _buildTextField(
                        controller: _descriptionController,
                        label: 'Description',
                        icon: Icons.description_rounded,
                        maxLines: 3,
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Location
                      _buildTextField(
                        controller: _locationController,
                        label: 'Current Location *',
                        icon: Icons.location_on_rounded,
                        validator: (value) =>
                            value?.isEmpty ?? true ? 'Please enter location' : null,
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Category
                      _buildDropdown<String>(
                        value: _selectedCategory,
                        label: 'Category',
                        icon: Icons.category_rounded,
                        items: _categories,
                        onChanged: (value) {
                          setState(() => _selectedCategory = value!);
                          _refreshImage(); // Refresh image when category changes
                        },
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Status
                      _buildDropdown<String>(
                        value: _selectedStatus,
                        label: 'Status',
                        icon: Icons.info_rounded,
                        items: _statuses,
                        onChanged: (value) {
                          setState(() {
                            _selectedStatus = value!;
                            if (value != 'Borrowed') {
                              _selectedBorrowedBy = null;
                            }
                          });
                        },
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Borrowed by (only show if status is Borrowed)
                      if (_selectedStatus == 'Borrowed') ...[
                        _buildNullableDropdown<String>(
                          value: _selectedBorrowedBy,
                          label: 'Borrowed By',
                          icon: Icons.person_rounded,
                          items: widget.familyMembers.where((m) => m.id != null).map((m) => m.id!).toList(),
                          itemBuilder: (memberId) {
                            final member = widget.familyMembers.firstWhere((m) => m.id == memberId);
                            return member.name;
                          },
                          onChanged: (value) => setState(() => _selectedBorrowedBy = value),
                        ),
                        const SizedBox(height: 16),
                      ],
                      
                      // Item History Summary
                      if (widget.item.history.isNotEmpty) ...[
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.history_rounded,
                                    size: 18,
                                    color: theme.colorScheme.primary,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Recent Activity',
                                    style: theme.textTheme.labelLarge?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: theme.colorScheme.primary,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              ...widget.item.history.take(3).map((history) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 4),
                                  child: Text(
                                    '${history.action} - ${DateFormat('MMM d, yyyy').format(history.timestamp)}',
                                    style: theme.textTheme.bodySmall?.copyWith(
                                      color: theme.colorScheme.onSurface.withOpacity(0.7),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ],
                  ),
                ),
              ),
            ),
            
            // Actions
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
                border: Border(
                  top: BorderSide(
                    color: theme.colorScheme.outline.withOpacity(0.2),
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: _isUpdating ? null : () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 12),
                  FilledButton(
                    onPressed: _isUpdating ? null : _updateItem,
                    child: _isUpdating
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Update Item'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          validator: validator,
          maxLines: maxLines,
          decoration: InputDecoration(
            prefixIcon: Icon(icon, size: 20),
            hintText: 'Enter $label'.toLowerCase(),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown<T>({
    required T value,
    required String label,
    required IconData icon,
    required List<T> items,
    required void Function(T?) onChanged,
    String Function(T)? itemBuilder,
  }) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<T>(
          value: value,
          onChanged: onChanged,
          decoration: InputDecoration(
            prefixIcon: Icon(icon, size: 20),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          items: items.map((item) {
            return DropdownMenuItem<T>(
              value: item,
              child: Text(itemBuilder?.call(item) ?? item.toString()),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildNullableDropdown<T>({
    required T? value,
    required String label,
    required IconData icon,
    required List<T> items,
    required void Function(T?) onChanged,
    String Function(T)? itemBuilder,
  }) {
    final theme = Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<T>(
          value: value,
          onChanged: onChanged,
          decoration: InputDecoration(
            prefixIcon: Icon(icon, size: 20),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          items: items.map((item) {
            return DropdownMenuItem<T>(
              value: item,
              child: Text(itemBuilder?.call(item) ?? item.toString()),
            );
          }).toList(),
        ),
      ],
    );
  }

  Future<void> _updateItem() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() => _isUpdating = true);
    
    try {
      // Create updated item with history entry
      final updatedItem = widget.item.copyWith(
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        currentLocation: _locationController.text.trim(),
        category: _selectedCategory,
        status: _selectedStatus,
        borrowedByMemberId: _selectedStatus == 'Borrowed' ? _selectedBorrowedBy : null,
        borrowedAt: _selectedStatus == 'Borrowed' && widget.item.status != 'Borrowed'
            ? DateTime.now()
            : (_selectedStatus != 'Borrowed' ? null : widget.item.borrowedAt),
        returnedAt: _selectedStatus != 'Borrowed' && widget.item.status == 'Borrowed'
            ? DateTime.now()
            : null,
      );

      // Add history entry for the update
      final newHistory = List<ItemHistory>.from(updatedItem.history);
      newHistory.add(
        ItemHistory(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          action: 'Updated',
          memberId: 'current_user', // This should be the current user ID
          location: _locationController.text.trim(),
          timestamp: DateTime.now(),
          notes: 'Item details updated',
        ),
      );

      final finalItem = TrackedItem(
        id: updatedItem.id,
        name: updatedItem.name,
        description: updatedItem.description,
        currentLocation: updatedItem.currentLocation,
        borrowedByMemberId: updatedItem.borrowedByMemberId,
        borrowedAt: updatedItem.borrowedAt,
        returnedAt: updatedItem.returnedAt,
        category: updatedItem.category,
        status: updatedItem.status,
        history: newHistory,
        createdAt: updatedItem.createdAt,
      );

      // Update via Firebase Data Sync Service if available, otherwise use DataService
      try {
        final firebaseDataSyncService = Provider.of<FirebaseDataSyncService>(context, listen: false);
        await firebaseDataSyncService.updateTrackedItem(finalItem);
      } catch (e) {
        // Fallback to DataService
        final dataService = Provider.of<DataService>(context, listen: false);
        await dataService.updateTrackedItem(finalItem);
      }

      if (mounted) {
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${finalItem.name} updated successfully!'),
            backgroundColor: Theme.of(context).colorScheme.primary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating item: $e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    } finally {
      setState(() => _isUpdating = false);
    }
  }
}