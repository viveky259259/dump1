import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/family_member.dart';
import '../services/quick_add_service.dart';
import '../services/data_service.dart';
import '../theme.dart';

class QuickAddDialog extends StatefulWidget {
  final QuickAddType type;
  
  const QuickAddDialog({
    super.key,
    required this.type,
  });

  @override
  State<QuickAddDialog> createState() => _QuickAddDialogState();
}

enum QuickAddType { event, task, item }

class _QuickAddDialogState extends State<QuickAddDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  
  String? _selectedMember;
  String? _selectedCategory;
  String? _selectedPriority;
  String? _selectedLocation;
  String? _selectedStatus;
  DateTime _selectedDate = DateTime.now();
  bool _hasReminder = false;
  bool _isRecurring = false;
  String? _recurringPattern;
  
  late QuickAddService _quickAddService;
  late DataService _dataService;
  
  @override
  void initState() {
    super.initState();
    _quickAddService = QuickAddService.instance;
    _dataService = DataService.instance;
    
    // Set default date for tasks (tomorrow) and events (today)
    if (widget.type == QuickAddType.task) {
      _selectedDate = DateTime.now().add(const Duration(days: 1));
    }
  }
  
  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Consumer2<QuickAddService, DataService>(
      builder: (context, quickAddService, dataService, child) {
        return AlertDialog(
          backgroundColor: colorScheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: [
              Icon(
                _getTypeIcon(),
                color: colorScheme.primary,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Quick Add ${_getTypeTitle()}',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          content: SizedBox(
            width: MediaQuery.of(context).size.width * 0.9,
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (quickAddService.error != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: colorScheme.errorContainer,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.error_outline,
                              color: colorScheme.onErrorContainer,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                quickAddService.error!,
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: colorScheme.onErrorContainer,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    _buildTitleField(),
                    const SizedBox(height: 16),
                    _buildDescriptionField(),
                    const SizedBox(height: 16),
                    _buildMemberSelector(dataService),
                    const SizedBox(height: 16),
                    _buildCategorySelector(),
                    const SizedBox(height: 16),
                    if (widget.type != QuickAddType.item) ...[
                      _buildDateSelector(),
                      const SizedBox(height: 16),
                    ],
                    if (widget.type == QuickAddType.task) ...[
                      _buildPrioritySelector(),
                      const SizedBox(height: 16),
                      _buildRecurringOptions(),
                      const SizedBox(height: 16),
                    ],
                    if (widget.type == QuickAddType.event) ...[
                      _buildReminderOptions(),
                      const SizedBox(height: 16),
                    ],
                    if (widget.type == QuickAddType.item) ...[
                      _buildLocationSelector(),
                      const SizedBox(height: 16),
                      _buildStatusSelector(),
                      const SizedBox(height: 16),
                    ],
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: quickAddService.isLoading ? null : () {
                quickAddService.clearError();
                Navigator.of(context).pop();
              },
              child: Text(
                'Cancel',
                style: TextStyle(color: colorScheme.onSurface),
              ),
            ),
            ElevatedButton(
              onPressed: quickAddService.isLoading ? null : _submitForm,
              style: ElevatedButton.styleFrom(
                backgroundColor: colorScheme.primary,
                foregroundColor: colorScheme.onPrimary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: quickAddService.isLoading
                  ? SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: colorScheme.onPrimary,
                      ),
                    )
                  : Text('Add ${_getTypeTitle()}'),
            ),
          ],
        );
      },
    );
  }
  
  Widget _buildTitleField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Title *',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _titleController,
          decoration: InputDecoration(
            hintText: 'Enter ${widget.type.name} title...',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return 'Title is required';
            }
            return null;
          },
          onChanged: (value) {
            // Auto-suggest category based on title
            if (_selectedCategory == null && value.isNotEmpty) {
              setState(() {
                switch (widget.type) {
                  case QuickAddType.event:
                    _selectedCategory = _quickAddService.getDefaultEventCategory(value);
                    break;
                  case QuickAddType.task:
                    _selectedCategory = _quickAddService.getDefaultTaskCategory(value);
                    _selectedPriority = _quickAddService.getDefaultTaskPriority(value);
                    break;
                  case QuickAddType.item:
                    _selectedCategory = _quickAddService.getDefaultItemCategory(value);
                    break;
                }
              });
            }
          },
        ),
      ],
    );
  }
  
  Widget _buildDescriptionField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Description',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: _descriptionController,
          maxLines: 2,
          decoration: InputDecoration(
            hintText: 'Optional description...',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
        ),
      ],
    );
  }
  
  Widget _buildMemberSelector(DataService dataService) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.type == QuickAddType.item ? 'Owner' : 'Assigned to *',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedMember,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
          hint: Text('Select family member'),
          items: dataService.familyMembers.map((member) {
            return DropdownMenuItem<String>(
              value: member.id,
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 12,
                    backgroundColor: member.color,
                    child: Text(
                      member.name.isNotEmpty ? member.name[0].toUpperCase() : '?',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(member.name),
                ],
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedMember = value;
            });
          },
          validator: widget.type != QuickAddType.item ? (value) {
            if (value == null) {
              return 'Please select a family member';
            }
            return null;
          } : null,
        ),
      ],
    );
  }
  
  Widget _buildCategorySelector() {
    List<String> categories = [];
    switch (widget.type) {
      case QuickAddType.event:
        categories = ['Birthday', 'Anniversary', 'Appointment', 'School Event', 'Family Activity', 'Work', 'Personal', 'Holiday', 'Reminder', 'Other'];
        break;
      case QuickAddType.task:
        categories = ['Cleaning', 'Kitchen', 'Laundry', 'Yard Work', 'Maintenance', 'Shopping', 'Pet Care', 'Organization', 'Bills & Finance', 'Other'];
        break;
      case QuickAddType.item:
        categories = ['Electronics', 'Tools', 'Books', 'Sports Equipment', 'Kitchen Items', 'Clothing', 'Toys & Games', 'Documents', 'Other'];
        break;
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Category',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedCategory,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
          hint: const Text('Select category'),
          items: categories.map((category) {
            return DropdownMenuItem<String>(
              value: category,
              child: Text(category),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedCategory = value;
            });
          },
        ),
      ],
    );
  }
  
  Widget _buildDateSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.type == QuickAddType.task ? 'Due Date *' : 'Date *',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        InkWell(
          onTap: () async {
            final date = await showDatePicker(
              context: context,
              initialDate: _selectedDate,
              firstDate: DateTime.now(),
              lastDate: DateTime.now().add(const Duration(days: 365)),
            );
            if (date != null) {
              final time = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.fromDateTime(_selectedDate),
              );
              if (time != null) {
                setState(() {
                  _selectedDate = DateTime(
                    date.year,
                    date.month,
                    date.day,
                    time.hour,
                    time.minute,
                  );
                });
              }
            }
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).dividerColor),
              borderRadius: BorderRadius.circular(8),
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
            ),
            child: Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  color: Theme.of(context).colorScheme.primary,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Text(
                  '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year} at ${TimeOfDay.fromDateTime(_selectedDate).format(context)}',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildPrioritySelector() {
    const priorities = ['Low', 'Medium', 'High', 'Urgent'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Priority',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedPriority ?? 'Medium',
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
          items: priorities.map((priority) {
            return DropdownMenuItem<String>(
              value: priority,
              child: Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: _getPriorityColor(priority),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(priority),
                ],
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedPriority = value;
            });
          },
        ),
      ],
    );
  }
  
  Widget _buildRecurringOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CheckboxListTile(
          title: const Text('Recurring Task'),
          value: _isRecurring,
          onChanged: (value) {
            setState(() {
              _isRecurring = value ?? false;
              if (!_isRecurring) {
                _recurringPattern = null;
              }
            });
          },
          contentPadding: EdgeInsets.zero,
        ),
        if (_isRecurring) ...[
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _recurringPattern,
            decoration: InputDecoration(
              labelText: 'Frequency',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
            ),
            items: ['Daily', 'Weekly', 'Bi-weekly', 'Monthly'].map((pattern) {
              return DropdownMenuItem<String>(
                value: pattern,
                child: Text(pattern),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _recurringPattern = value;
              });
            },
          ),
        ],
      ],
    );
  }
  
  Widget _buildReminderOptions() {
    return CheckboxListTile(
      title: const Text('Set Reminder'),
      subtitle: _hasReminder ? Text('1 hour before') : null,
      value: _hasReminder,
      onChanged: (value) {
        setState(() {
          _hasReminder = value ?? false;
        });
      },
      contentPadding: EdgeInsets.zero,
    );
  }
  
  Widget _buildLocationSelector() {
    const locations = [
      'Living Room', 'Kitchen', 'Master Bedroom', 'Kids Room', 'Garage',
      'Basement', 'Office', 'Bathroom', 'Attic', 'Outside', 'Car', 'Unknown'
    ];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Location *',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedLocation,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
          hint: const Text('Select location'),
          items: locations.map((location) {
            return DropdownMenuItem<String>(
              value: location,
              child: Text(location),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedLocation = value;
            });
          },
          validator: (value) {
            if (value == null) {
              return 'Please select a location';
            }
            return null;
          },
        ),
      ],
    );
  }
  
  Widget _buildStatusSelector() {
    const statuses = ['Available', 'Borrowed', 'In Use', 'Lost', 'Maintenance'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Status',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedStatus ?? 'Available',
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          ),
          items: statuses.map((status) {
            return DropdownMenuItem<String>(
              value: status,
              child: Text(status),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedStatus = value;
              // If status is borrowed, require member selection
              if (value == 'Borrowed' && _selectedMember == null) {
                // This will be validated in the form
              }
            });
          },
        ),
      ],
    );
  }
  
  IconData _getTypeIcon() {
    switch (widget.type) {
      case QuickAddType.event:
        return Icons.event;
      case QuickAddType.task:
        return Icons.task_alt;
      case QuickAddType.item:
        return Icons.inventory_2;
    }
  }
  
  String _getTypeTitle() {
    switch (widget.type) {
      case QuickAddType.event:
        return 'Event';
      case QuickAddType.task:
        return 'Task';
      case QuickAddType.item:
        return 'Item';
    }
  }
  
  Color _getPriorityColor(String priority) {
    switch (priority) {
      case 'Low':
        return Colors.green;
      case 'Medium':
        return Colors.orange;
      case 'High':
        return Colors.red;
      case 'Urgent':
        return Colors.deepPurple;
      default:
        return Colors.grey;
    }
  }
  
  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;
    
    final title = _titleController.text.trim();
    final description = _descriptionController.text.trim();
    
    bool success = false;
    
    switch (widget.type) {
      case QuickAddType.event:
        success = await _quickAddService.quickAddEvent(
          title: title,
          description: description,
          date: _selectedDate,
          assignedMemberId: _selectedMember!,
          category: _selectedCategory ?? 'Other',
          hasReminder: _hasReminder,
          reminderTime: _hasReminder ? _selectedDate.subtract(const Duration(hours: 1)) : null,
        );
        break;
      
      case QuickAddType.task:
        success = await _quickAddService.quickAddTask(
          title: title,
          description: description,
          assignedMemberId: _selectedMember!,
          dueDate: _selectedDate,
          category: _selectedCategory ?? 'Other',
          priority: _selectedPriority ?? 'Medium',
          isRecurring: _isRecurring,
          recurringPattern: _recurringPattern,
        );
        break;
      
      case QuickAddType.item:
        success = await _quickAddService.quickAddItem(
          name: title,
          description: description,
          currentLocation: _selectedLocation!,
          category: _selectedCategory ?? 'Other',
          status: _selectedStatus ?? 'Available',
          borrowedByMemberId: (_selectedStatus == 'Borrowed') ? _selectedMember : null,
        );
        break;
    }
    
    if (success && mounted) {
      Navigator.of(context).pop(true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${_getTypeTitle()} added successfully!'),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
      );
    }
  }
}