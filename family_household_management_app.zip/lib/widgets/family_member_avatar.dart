import 'package:flutter/material.dart';
import '../models/family_member.dart';
import '../theme.dart';

class FamilyMemberAvatar extends StatelessWidget {
  final FamilyMember member;
  final double size;
  final bool showName;
  final bool showRole;
  final VoidCallback? onTap;

  const FamilyMemberAvatar({
    super.key,
    required this.member,
    this.size = 40,
    this.showName = false,
    this.showRole = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    Widget avatar = GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: member.color,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: member.color.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: member.profileImageUrl != null
            ? ClipOval(
                child: Image.network(
                  member.profileImageUrl!,
                  width: size,
                  height: size,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => _buildInitialsAvatar(theme),
                ),
              )
            : _buildInitialsAvatar(theme),
      ),
    );

    if (!showName && !showRole) {
      return avatar;
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        avatar,
        if (showName || showRole) ...[
          const SizedBox(height: 8),
          if (showName)
            Text(
              member.name,
              style: theme.textTheme.labelMedium?.copyWith(
                color: theme.colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          if (showRole)
            Text(
              member.role,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ],
    );
  }

  Widget _buildInitialsAvatar(ThemeData theme) {
    final initials = member.name.isNotEmpty
        ? member.name.split(' ').map((name) => name[0]).take(2).join()
        : '?';
    
    return Center(
      child: Text(
        initials.toUpperCase(),
        style: theme.textTheme.titleMedium?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: size * 0.4,
        ),
      ),
    );
  }
}

class FamilyMemberSelector extends StatelessWidget {
  final List<FamilyMember> members;
  final String? selectedMemberId;
  final Function(FamilyMember) onMemberSelected;
  final bool showNames;

  const FamilyMemberSelector({
    super.key,
    required this.members,
    this.selectedMemberId,
    required this.onMemberSelected,
    this.showNames = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Assign to Family Member',
            style: theme.textTheme.titleSmall?.copyWith(
              color: theme.colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: members.map((member) {
              final isSelected = member.id == selectedMemberId;
              
              return GestureDetector(
                onTap: () => onMemberSelected(member),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isSelected 
                        ? member.color.withOpacity(0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected 
                          ? member.color
                          : theme.colorScheme.outline.withOpacity(0.3),
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      FamilyMemberAvatar(
                        member: member,
                        size: 36,
                      ),
                      if (showNames) ...[
                        const SizedBox(height: 4),
                        Text(
                          member.name,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: isSelected 
                                ? member.color
                                : theme.colorScheme.onSurface,
                            fontWeight: isSelected 
                                ? FontWeight.w600
                                : FontWeight.normal,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class FamilyMemberChip extends StatelessWidget {
  final FamilyMember member;
  final VoidCallback? onTap;
  final bool isSelected;

  const FamilyMemberChip({
    super.key,
    required this.member,
    this.onTap,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isSelected 
                ? member.color.withOpacity(0.15)
                : theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected 
                  ? member.color
                  : theme.colorScheme.outline.withOpacity(0.3),
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              FamilyMemberAvatar(
                member: member,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                member.name,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: isSelected 
                      ? member.color
                      : theme.colorScheme.onSurface,
                  fontWeight: isSelected 
                      ? FontWeight.w600
                      : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}