import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import '../services/firebase_service.dart';

class FamilySelector extends StatelessWidget {
  const FamilySelector({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthService>(
      builder: (context, authService, child) {
        if (authService.userFamilyIds.length <= 1) {
          return const SizedBox.shrink();
        }

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Theme.of(context).primaryColor.withOpacity(0.3),
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.family_restroom,
                color: Theme.of(context).primaryColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: StreamBuilder<DocumentSnapshot>(
                  stream: authService.currentFamilyId != null
                      ? FirebaseService.instance.watchFamily(authService.currentFamilyId!)
                      : null,
                  builder: (context, snapshot) {
                    final familyName = snapshot.hasData && snapshot.data!.exists
                        ? (snapshot.data!.data() as Map<String, dynamic>)['name'] ?? 'Unknown Family'
                        : 'No Family';

                    return Text(
                      familyName,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).primaryColor,
                      ),
                    );
                  },
                ),
              ),
              PopupMenuButton<String>(
                icon: Icon(
                  Icons.swap_horiz,
                  color: Theme.of(context).primaryColor,
                  size: 20,
                ),
                tooltip: 'Switch Family',
                onSelected: (familyId) async {
                  await authService.setCurrentFamily(familyId);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Switched family successfully'),
                        backgroundColor: Colors.green,
                        duration: Duration(seconds: 2),
                      ),
                    );
                  }
                },
                itemBuilder: (context) {
                  return authService.userFamilyIds.map((familyId) {
                    return PopupMenuItem<String>(
                      value: familyId,
                      enabled: familyId != authService.currentFamilyId,
                      child: StreamBuilder<DocumentSnapshot>(
                        stream: FirebaseService.instance.watchFamily(familyId),
                        builder: (context, snapshot) {
                          final familyName = snapshot.hasData && snapshot.data!.exists
                              ? (snapshot.data!.data() as Map<String, dynamic>)['name'] ?? 'Unknown Family'
                              : 'Loading...';

                          final isCurrentFamily = familyId == authService.currentFamilyId;

                          return Row(
                            children: [
                              Icon(
                                isCurrentFamily ? Icons.check_circle : Icons.family_restroom,
                                size: 16,
                                color: isCurrentFamily 
                                    ? Theme.of(context).primaryColor 
                                    : Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  familyName,
                                  style: TextStyle(
                                    fontWeight: isCurrentFamily ? FontWeight.bold : FontWeight.normal,
                                    color: isCurrentFamily 
                                        ? Theme.of(context).primaryColor 
                                        : null,
                                  ),
                                ),
                              ),
                              if (isCurrentFamily)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).primaryColor,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Current',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                            ],
                          );
                        },
                      ),
                    );
                  }).toList();
                },
              ),
            ],
          ),
        );
      },
    );
  }
}