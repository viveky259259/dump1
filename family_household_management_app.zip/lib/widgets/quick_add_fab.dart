import 'package:flutter/material.dart';
import 'quick_add_dialog.dart';
import 'quick_add_bottom_sheet.dart';

class QuickAddFAB extends StatelessWidget {
  final QuickAddType? defaultType;
  final bool useBottomSheet;
  
  const QuickAddFAB({
    super.key,
    this.defaultType,
    this.useBottomSheet = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (defaultType != null) {
      // Single type FAB
      return FloatingActionButton(
        onPressed: () => _showQuickAddDialog(context, defaultType!),
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        child: Icon(_getTypeIcon(defaultType!)),
      );
    }
    
    if (useBottomSheet) {
      // Extended FAB with bottom sheet
      return FloatingActionButton.extended(
        onPressed: () => _showQuickAddBottomSheet(context),
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        icon: const Icon(Icons.add),
        label: const Text('Quick Add'),
      );
    }
    
    // Multi-type FAB with speed dial
    return QuickAddSpeedDial();
  }
  
  IconData _getTypeIcon(QuickAddType type) {
    switch (type) {
      case QuickAddType.event:
        return Icons.event_outlined;
      case QuickAddType.task:
        return Icons.task_alt_outlined;
      case QuickAddType.item:
        return Icons.inventory_2_outlined;
    }
  }
  
  void _showQuickAddDialog(BuildContext context, QuickAddType type) {
    showDialog(
      context: context,
      builder: (context) => QuickAddDialog(type: type),
    );
  }
  
  void _showQuickAddBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const QuickAddBottomSheet(),
    );
  }
}

class QuickAddSpeedDial extends StatefulWidget {
  const QuickAddSpeedDial({super.key});

  @override
  State<QuickAddSpeedDial> createState() => _QuickAddSpeedDialState();
}

class _QuickAddSpeedDialState extends State<QuickAddSpeedDial>
    with TickerProviderStateMixin {
  bool _isOpen = false;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    _scaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));
    
    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 0.75,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() {
      _isOpen = !_isOpen;
      if (_isOpen) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  void _close() {
    if (_isOpen) {
      setState(() {
        _isOpen = false;
        _animationController.reverse();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Stack(
      alignment: Alignment.bottomRight,
      children: [
        // Background overlay
        if (_isOpen)
          Positioned.fill(
            child: GestureDetector(
              onTap: _close,
              child: Container(
                color: Colors.black.withOpacity(0.3),
              ),
            ),
          ),
        
        // Speed dial options
        ...List.generate(3, (index) {
          final types = [QuickAddType.event, QuickAddType.task, QuickAddType.item];
          final type = types[index];
          
          return AnimatedBuilder(
            animation: _scaleAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: Container(
                  margin: EdgeInsets.only(
                    bottom: 80.0 + (index * 70.0),
                    right: 4.0,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Label
                      if (_isOpen)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          margin: const EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                            color: colorScheme.surface,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            _getTypeLabel(type),
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: colorScheme.onSurface,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      
                      // Button
                      FloatingActionButton.small(
                        onPressed: () {
                          _close();
                          _showQuickAddDialog(context, type);
                        },
                        backgroundColor: _getTypeColor(type, colorScheme),
                        foregroundColor: Colors.white,
                        heroTag: 'quick_add_${type.name}',
                        child: Icon(_getTypeIcon(type)),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }),
        
        // Main FAB
        FloatingActionButton(
          onPressed: _toggle,
          backgroundColor: colorScheme.primary,
          foregroundColor: colorScheme.onPrimary,
          child: AnimatedBuilder(
            animation: _rotationAnimation,
            builder: (context, child) {
              return Transform.rotate(
                angle: _rotationAnimation.value * 2 * 3.14159,
                child: Icon(
                  _isOpen ? Icons.close : Icons.add,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
  
  IconData _getTypeIcon(QuickAddType type) {
    switch (type) {
      case QuickAddType.event:
        return Icons.event_outlined;
      case QuickAddType.task:
        return Icons.task_alt_outlined;
      case QuickAddType.item:
        return Icons.inventory_2_outlined;
    }
  }
  
  String _getTypeLabel(QuickAddType type) {
    switch (type) {
      case QuickAddType.event:
        return 'Add Event';
      case QuickAddType.task:
        return 'Add Task';
      case QuickAddType.item:
        return 'Add Item';
    }
  }
  
  Color _getTypeColor(QuickAddType type, ColorScheme colorScheme) {
    switch (type) {
      case QuickAddType.event:
        return Colors.blue;
      case QuickAddType.task:
        return Colors.green;
      case QuickAddType.item:
        return Colors.orange;
    }
  }
  
  void _showQuickAddDialog(BuildContext context, QuickAddType type) {
    showDialog(
      context: context,
      builder: (context) => QuickAddDialog(type: type),
    );
  }
}