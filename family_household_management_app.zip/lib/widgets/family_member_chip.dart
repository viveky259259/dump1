import 'package:flutter/material.dart';
import '../models/family_member.dart';
import 'family_member_avatar.dart';

class FamilyMemberChip extends StatelessWidget {
  final FamilyMember member;
  final bool isSelected;
  final VoidCallback onTap;
  final bool showName;

  const FamilyMemberChip({
    super.key,
    required this.member,
    required this.isSelected,
    required this.onTap,
    this.showName = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? member.color.withOpacity(0.2)
                : theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected
                  ? member.color
                  : theme.colorScheme.outline.withOpacity(0.3),
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              FamilyMemberAvatar(
                member: member,
                size: 24,
              ),
              if (showName) ...[
                const SizedBox(width: 8),
                Text(
                  member.name,
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: isSelected
                        ? member.color
                        : theme.colorScheme.onSurface,
                    fontWeight: isSelected
                        ? FontWeight.w600
                        : FontWeight.normal,
                  ),
                ),
              ],
              if (isSelected) ...[
                const SizedBox(width: 4),
                Icon(
                  Icons.check_circle,
                  size: 16,
                  color: member.color,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}