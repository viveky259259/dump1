import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/quick_add_service.dart';
import '../services/data_service.dart';
import '../models/family_member.dart';
import 'quick_add_dialog.dart';

class QuickAddBottomSheet extends StatefulWidget {
  const QuickAddBottomSheet({super.key});

  @override
  State<QuickAddBottomSheet> createState() => _QuickAddBottomSheetState();
}

class _QuickAddBottomSheetState extends State<QuickAddBottomSheet> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  
  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final mediaQuery = MediaQuery.of(context);
    
    return Container(
      height: mediaQuery.size.height * 0.85,
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: colorScheme.onSurface.withOpacity(0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          
          // Header with tabs
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  'Quick Add',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: colorScheme.onSurface,
                  ),
                ),
                const Spacer(),
                Row(
                  children: List.generate(3, (index) {
                    final isSelected = index == _currentPage;
                    return GestureDetector(
                      onTap: () {
                        _pageController.animateToPage(
                          index,
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        );
                      },
                      child: Container(
                        width: 8,
                        height: 8,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          color: isSelected 
                              ? colorScheme.primary 
                              : colorScheme.onSurface.withOpacity(0.3),
                          shape: BoxShape.circle,
                        ),
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Content pages
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (page) {
                setState(() {
                  _currentPage = page;
                });
              },
              children: [
                _buildQuickActionsPage(),
                _buildSuggestionsPage(),
                _buildTemplatesPage(),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildQuickActionsPage() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quick Actions',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 16),
          
          // Quick action cards
          Row(
            children: [
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.event_outlined,
                  title: 'Add Event',
                  subtitle: 'Calendar event',
                  color: Colors.blue,
                  onTap: () => _showQuickAddDialog(QuickAddType.event),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.task_alt_outlined,
                  title: 'Add Task',
                  subtitle: 'Household task',
                  color: Colors.green,
                  onTap: () => _showQuickAddDialog(QuickAddType.task),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          Row(
            children: [
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.inventory_2_outlined,
                  title: 'Add Item',
                  subtitle: 'Track item',
                  color: Colors.orange,
                  onTap: () => _showQuickAddDialog(QuickAddType.item),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.mic_outlined,
                  title: 'Voice Add',
                  subtitle: 'Coming soon',
                  color: Colors.purple,
                  onTap: () => _showComingSoon(),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 24),
          
          // Recent activity
          Text(
            'Recent Activity',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: colorScheme.onSurface,
            ),
          ),
          
          const SizedBox(height: 12),
          
          Expanded(
            child: Consumer<DataService>(
              builder: (context, dataService, child) {
                final recentItems = <Map<String, dynamic>>[];
                
                // Add recent events
                final recentEvents = dataService.calendarEvents
                    .where((e) => e.createdAt.isAfter(DateTime.now().subtract(const Duration(days: 7))))
                    .take(3)
                    .map((e) => {
                          'type': 'Event',
                          'title': e.title,
                          'icon': Icons.event,
                          'color': Colors.blue,
                          'time': e.createdAt,
                        });
                recentItems.addAll(recentEvents);
                
                // Add recent tasks
                final recentTasks = dataService.householdTasks
                    .where((t) => t.createdAt.isAfter(DateTime.now().subtract(const Duration(days: 7))))
                    .take(3)
                    .map((t) => {
                          'type': 'Task',
                          'title': t.title,
                          'icon': Icons.task_alt,
                          'color': Colors.green,
                          'time': t.createdAt,
                        });
                recentItems.addAll(recentTasks);
                
                // Add recent items
                final recentTrackedItems = dataService.trackedItems
                    .where((i) => i.createdAt.isAfter(DateTime.now().subtract(const Duration(days: 7))))
                    .take(3)
                    .map((i) => {
                          'type': 'Item',
                          'title': i.name,
                          'icon': Icons.inventory_2,
                          'color': Colors.orange,
                          'time': i.createdAt,
                        });
                recentItems.addAll(recentTrackedItems);
                
                // Sort by time
                recentItems.sort((a, b) => (b['time'] as DateTime).compareTo(a['time'] as DateTime));
                
                if (recentItems.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.history,
                          size: 48,
                          color: colorScheme.onSurface.withOpacity(0.5),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No recent activity',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: colorScheme.onSurface.withOpacity(0.7),
                          ),
                        ),
                      ],
                    ),
                  );
                }
                
                return ListView.builder(
                  itemCount: recentItems.take(5).length,
                  itemBuilder: (context, index) {
                    final item = recentItems[index];
                    return ListTile(
                      leading: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: (item['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          item['icon'] as IconData,
                          color: item['color'] as Color,
                          size: 20,
                        ),
                      ),
                      title: Text(
                        item['title'] as String,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        item['type'] as String,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: colorScheme.onSurface.withOpacity(0.7),
                        ),
                      ),
                      trailing: Text(
                        _formatRelativeTime(item['time'] as DateTime),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: colorScheme.onSurface.withOpacity(0.5),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSuggestionsPage() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Consumer<QuickAddService>(
      builder: (context, quickAddService, child) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Smart Suggestions',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 16),
              
              Expanded(
                child: DefaultTabController(
                  length: 3,
                  child: Column(
                    children: [
                      TabBar(
                        labelColor: colorScheme.primary,
                        unselectedLabelColor: colorScheme.onSurface.withOpacity(0.6),
                        indicatorColor: colorScheme.primary,
                        tabs: const [
                          Tab(text: 'Events'),
                          Tab(text: 'Tasks'),
                          Tab(text: 'Items'),
                        ],
                      ),
                      
                      const SizedBox(height: 16),
                      
                      Expanded(
                        child: TabBarView(
                          children: [
                            _buildSuggestionsList(
                              quickAddService.getEventSuggestions(),
                              QuickAddType.event,
                              Icons.event_outlined,
                              Colors.blue,
                            ),
                            _buildSuggestionsList(
                              quickAddService.getTaskSuggestions(),
                              QuickAddType.task,
                              Icons.task_alt_outlined,
                              Colors.green,
                            ),
                            _buildSuggestionsList(
                              quickAddService.getItemSuggestions(),
                              QuickAddType.item,
                              Icons.inventory_2_outlined,
                              Colors.orange,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
  
  Widget _buildTemplatesPage() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Templates',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Quick templates for common items',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Coming soon placeholder
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.construction,
                    size: 64,
                    color: colorScheme.onSurface.withOpacity(0.3),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Templates Coming Soon',
                    style: theme.textTheme.headlineSmall?.copyWith(
                      color: colorScheme.onSurface.withOpacity(0.7),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Save your frequently used items as templates for quick access',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurface.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildQuickActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: theme.textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.onSurface,
              ),
            ),
            Text(
              subtitle,
              style: theme.textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildSuggestionsList(
    List<String> suggestions,
    QuickAddType type,
    IconData icon,
    Color color,
  ) {
    final theme = Theme.of(context);
    
    return ListView.builder(
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final suggestion = suggestions[index];
        return ListTile(
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          title: Text(
            suggestion,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
          trailing: Icon(
            Icons.add_circle_outline,
            color: color,
          ),
          onTap: () => _showQuickAddDialogWithTitle(type, suggestion),
        );
      },
    );
  }
  
  void _showQuickAddDialog(QuickAddType type) {
    Navigator.of(context).pop(); // Close bottom sheet
    showDialog(
      context: context,
      builder: (context) => QuickAddDialog(type: type),
    );
  }
  
  void _showQuickAddDialogWithTitle(QuickAddType type, String title) {
    Navigator.of(context).pop(); // Close bottom sheet
    showDialog(
      context: context,
      builder: (context) => QuickAddDialog(type: type),
    );
    // Note: In a more advanced implementation, we would pass the title
    // to pre-fill the dialog
  }
  
  void _showComingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Voice input coming soon!'),
        duration: Duration(seconds: 2),
      ),
    );
  }
  
  String _formatRelativeTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}