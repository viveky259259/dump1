import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/family_member.dart';
import '../models/calendar_event.dart';
import '../models/household_task.dart';
import '../models/item_tracker.dart';
import '../models/emergency_contact.dart';
import 'auth_service.dart';

class StorageService {
  static const String _familyMembersKey = 'family_members';
  static const String _calendarEventsKey = 'calendar_events';
  static const String _householdTasksKey = 'household_tasks';
  static const String _trackedItemsKey = 'tracked_items';
  static const String _emergencyContactsKey = 'emergency_contacts';
  static const String _hasInitializedKey = 'has_initialized';

  static SharedPreferences? _prefs;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  static Future<void> init() async {
    print("StorageService.init() called");
    if (kIsWeb) {
      print("Initializing storage for web platform");
      // For web, we'll use Firestore
      try {
        await Firebase.initializeApp(
          options: const FirebaseOptions(
              apiKey: "AIzaSyD3CbdqSF-3V4HanAQ5R2lfrdM-kNl0mi4",
              authDomain: "family-hosehold-management-pro.firebaseapp.com",
              projectId: "family-hosehold-management-pro",
              storageBucket: "family-hosehold-management-pro.appspot.com",
              messagingSenderId: "963076663974",
              appId: "1:963076663974:web:7b175ba9ba109a66dca267"),
        );
        print("Firebase initialized for web storage");
      } catch (e) {
        print("Error initializing Firebase for web storage: $e");
        rethrow;
      }
    } else {
      print("Initializing storage for mobile platform");
      // For mobile, we'll use SharedPreferences
      _prefs = await SharedPreferences.getInstance();

      // Initialize with sample data if first time
      if (!(_prefs!.getBool(_hasInitializedKey) ?? false)) {
        await _initializeSampleData();
        await _prefs!.setBool(_hasInitializedKey, true);
      }
    }
    print("Storage initialization completed");
  }

  static Future<void> _initializeSampleData() async {
    if (kIsWeb) {
      // Initialize sample data in Firestore
      final batch = _firestore.batch();

      // Add sample family members
      for (var member in FamilyMember.getSampleMembers()) {
        batch.set(_firestore.collection('family_members').doc(member.id),
            member.toJson());
      }

      // Add sample calendar events
      for (var event in CalendarEvent.getSampleEvents()) {
        batch.set(_firestore.collection('calendar_events').doc(event.id),
            event.toJson());
      }

      // Add sample household tasks
      for (var task in HouseholdTask.getSampleTasks()) {
        batch.set(_firestore.collection('household_tasks').doc(task.id),
            task.toJson());
      }

      // Add sample tracked items
      for (var item in TrackedItem.getSampleItems()) {
        batch.set(
            _firestore.collection('tracked_items').doc(item.id), item.toJson());
      }

      // Add sample emergency contacts
      for (var contact in EmergencyContact.getSampleContacts()) {
        batch.set(_firestore.collection('emergency_contacts').doc(contact.id),
            contact.toJson());
      }

      await batch.commit();
    } else {
      // Initialize sample data in SharedPreferences
      await saveFamilyMembers(FamilyMember.getSampleMembers());
      await saveCalendarEvents(CalendarEvent.getSampleEvents());
      await saveHouseholdTasks(HouseholdTask.getSampleTasks());
      await saveTrackedItems(TrackedItem.getSampleItems());
      await saveEmergencyContacts(EmergencyContact.getSampleContacts());
    }
  }

  // Family Members
  static Future<List<FamilyMember>> getFamilyMembers() async {
    if (kIsWeb) {
      final snapshot = await _firestore.collection('family_members').get();
      return snapshot.docs
          .map((doc) => FamilyMember.fromJson(doc.data()))
          .toList();
    } else {
      final String? jsonString = _prefs!.getString(_familyMembersKey);
      if (jsonString == null) return [];
      final List<dynamic> jsonList = json.decode(jsonString);
      return jsonList.map((json) => FamilyMember.fromJson(json)).toList();
    }
  }

  static Future<void> saveFamilyMembers(List<FamilyMember> members) async {
    if (kIsWeb) {
      final batch = _firestore.batch();
      for (var member in members) {
        batch.set(_firestore.collection('family_members').doc(member.id),
            member.toJson());
      }
      await batch.commit();
    } else {
      final String jsonString =
          json.encode(members.map((m) => m.toJson()).toList());
      await _prefs!.setString(_familyMembersKey, jsonString);
    }
  }

  static Future<void> addFamilyMember(FamilyMember member) async {
    final members = await getFamilyMembers();
    members.add(member);
    await saveFamilyMembers(members);
  }

  static Future<void> updateFamilyMember(FamilyMember member) async {
    final members = await getFamilyMembers();
    final index = members.indexWhere((m) => m.id == member.id);
    if (index != -1) {
      members[index] = member;
      await saveFamilyMembers(members);
    }
  }

  static Future<void> deleteFamilyMember(String id) async {
    final members = await getFamilyMembers();
    members.removeWhere((m) => m.id == id);
    await saveFamilyMembers(members);
  }

  // Calendar Events
  static Future<List<CalendarEvent>> getCalendarEvents() async {
    if (kIsWeb) {
      final snapshot = await _firestore.collection('calendar_events').get();
      return snapshot.docs
          .map((doc) => CalendarEvent.fromJson(doc.data()))
          .toList();
    } else {
      final String? jsonString = _prefs!.getString(_calendarEventsKey);
      if (jsonString == null) return [];
      final List<dynamic> jsonList = json.decode(jsonString);
      return jsonList.map((json) => CalendarEvent.fromJson(json)).toList();
    }
  }

  static Future<void> saveCalendarEvents(List<CalendarEvent> events) async {
    if (kIsWeb) {
      final batch = _firestore.batch();
      for (var event in events) {
        batch.set(_firestore.collection('calendar_events').doc(event.id),
            event.toJson());
      }
      await batch.commit();
    } else {
      final String jsonString =
          json.encode(events.map((e) => e.toJson()).toList());
      await _prefs!.setString(_calendarEventsKey, jsonString);
    }
  }

  static Future<void> addCalendarEvent(CalendarEvent event) async {
    final events = await getCalendarEvents();
    events.add(event);
    await saveCalendarEvents(events);
  }

  static Future<void> updateCalendarEvent(CalendarEvent event) async {
    final events = await getCalendarEvents();
    final index = events.indexWhere((e) => e.id == event.id);
    if (index != -1) {
      events[index] = event;
      await saveCalendarEvents(events);
    }
  }

  static Future<void> deleteCalendarEvent(String id) async {
    final events = await getCalendarEvents();
    events.removeWhere((e) => e.id == id);
    await saveCalendarEvents(events);
  }

  // Household Tasks
  static Future<List<HouseholdTask>> getHouseholdTasks() async {
    if (kIsWeb) {
      final snapshot = await _firestore.collection('household_tasks').get();
      return snapshot.docs
          .map((doc) => HouseholdTask.fromJson(doc.data()))
          .toList();
    } else {
      final String? jsonString = _prefs!.getString(_householdTasksKey);
      if (jsonString == null) return [];
      final List<dynamic> jsonList = json.decode(jsonString);
      return jsonList.map((json) => HouseholdTask.fromJson(json)).toList();
    }
  }

  static Future<void> saveHouseholdTasks(List<HouseholdTask> tasks) async {
    if (kIsWeb) {
      final batch = _firestore.batch();
      for (var task in tasks) {
        batch.set(_firestore.collection('household_tasks').doc(task.id),
            task.toJson());
      }
      await batch.commit();
    } else {
      final String jsonString =
          json.encode(tasks.map((t) => t.toJson()).toList());
      await _prefs!.setString(_householdTasksKey, jsonString);
    }
  }

  static Future<void> addHouseholdTask(HouseholdTask task) async {
    final tasks = await getHouseholdTasks();
    tasks.add(task);
    await saveHouseholdTasks(tasks);
  }

  static Future<void> updateHouseholdTask(HouseholdTask task) async {
    final tasks = await getHouseholdTasks();
    final index = tasks.indexWhere((t) => t.id == task.id);
    if (index != -1) {
      tasks[index] = task;
      await saveHouseholdTasks(tasks);
    }
  }

  static Future<void> deleteHouseholdTask(String id) async {
    final tasks = await getHouseholdTasks();
    tasks.removeWhere((t) => t.id == id);
    await saveHouseholdTasks(tasks);
  }

  // Tracked Items
  static Future<List<TrackedItem>> getTrackedItems() async {
    if (kIsWeb) {
      final snapshot = await _firestore.collection('tracked_items').get();
      return snapshot.docs
          .map((doc) => TrackedItem.fromJson(doc.data()))
          .toList();
    } else {
      final String? jsonString = _prefs!.getString(_trackedItemsKey);
      if (jsonString == null) return [];
      final List<dynamic> jsonList = json.decode(jsonString);
      return jsonList.map((json) => TrackedItem.fromJson(json)).toList();
    }
  }

  static Future<void> saveTrackedItems(List<TrackedItem> items) async {
    if (kIsWeb) {
      final batch = _firestore.batch();
      for (var item in items) {
        batch.set(
            _firestore.collection('tracked_items').doc(item.id), item.toJson());
      }
      await batch.commit();
    } else {
      final String jsonString =
          json.encode(items.map((i) => i.toJson()).toList());
      await _prefs!.setString(_trackedItemsKey, jsonString);
    }
  }

  static Future<void> addTrackedItem(TrackedItem item) async {
    final items = await getTrackedItems();
    items.add(item);
    await saveTrackedItems(items);
  }

  static Future<void> updateTrackedItem(TrackedItem item) async {
    final items = await getTrackedItems();
    final index = items.indexWhere((i) => i.id == item.id);
    if (index != -1) {
      items[index] = item;
      await saveTrackedItems(items);
    }
  }

  static Future<void> deleteTrackedItem(String id) async {
    final items = await getTrackedItems();
    items.removeWhere((i) => i.id == id);
    await saveTrackedItems(items);
  }

  // Emergency Contacts
  static Future<List<EmergencyContact>> getEmergencyContacts() async {
    if (kIsWeb) {
      final snapshot = await _firestore.collection('emergency_contacts').get();
      return snapshot.docs
          .map((doc) => EmergencyContact.fromJson(doc.data()))
          .toList();
    } else {
      final String? jsonString = _prefs!.getString(_emergencyContactsKey);
      if (jsonString == null) return [];
      final List<dynamic> jsonList = json.decode(jsonString);
      return jsonList.map((json) => EmergencyContact.fromJson(json)).toList();
    }
  }

  static Future<void> saveEmergencyContacts(
      List<EmergencyContact> contacts) async {
    if (kIsWeb) {
      final batch = _firestore.batch();
      for (var contact in contacts) {
        batch.set(_firestore.collection('emergency_contacts').doc(contact.id),
            contact.toJson());
      }
      await batch.commit();
    } else {
      final String jsonString =
          json.encode(contacts.map((c) => c.toJson()).toList());
      await _prefs!.setString(_emergencyContactsKey, jsonString);
    }
  }

  static Future<void> addEmergencyContact(EmergencyContact contact) async {
    final contacts = await getEmergencyContacts();
    contacts.add(contact);
    await saveEmergencyContacts(contacts);
  }

  static Future<void> updateEmergencyContact(EmergencyContact contact) async {
    final contacts = await getEmergencyContacts();
    final index = contacts.indexWhere((c) => c.id == contact.id);
    if (index != -1) {
      contacts[index] = contact;
      await saveEmergencyContacts(contacts);
    }
  }

  static Future<void> deleteEmergencyContact(String id) async {
    final contacts = await getEmergencyContacts();
    contacts.removeWhere((c) => c.id == id);
    await saveEmergencyContacts(contacts);
  }

  // Utility methods
  static Future<void> clearAllData() async {
    if (kIsWeb) {
      final batch = _firestore.batch();
      // Delete all documents from each collection
      for (var collection in [
        'family_members',
        'calendar_events',
        'household_tasks',
        'tracked_items',
        'emergency_contacts'
      ]) {
        final snapshot = await _firestore.collection(collection).get();
        for (var doc in snapshot.docs) {
          batch.delete(doc.reference);
        }
      }
      await batch.commit();
    } else {
      await _prefs!.clear();
    }
  }

  static Future<Map<String, dynamic>> exportData() async {
    if (kIsWeb) {
      return {
        'familyMembers':
            (await getFamilyMembers()).map((m) => m.toJson()).toList(),
        'calendarEvents':
            (await getCalendarEvents()).map((e) => e.toJson()).toList(),
        'householdTasks':
            (await getHouseholdTasks()).map((t) => t.toJson()).toList(),
        'trackedItems':
            (await getTrackedItems()).map((i) => i.toJson()).toList(),
        'emergencyContacts':
            (await getEmergencyContacts()).map((c) => c.toJson()).toList(),
      };
    } else {
      return {
        'familyMembers':
            (await getFamilyMembers()).map((m) => m.toJson()).toList(),
        'calendarEvents':
            (await getCalendarEvents()).map((e) => e.toJson()).toList(),
        'householdTasks':
            (await getHouseholdTasks()).map((t) => t.toJson()).toList(),
        'trackedItems':
            (await getTrackedItems()).map((i) => i.toJson()).toList(),
        'emergencyContacts':
            (await getEmergencyContacts()).map((c) => c.toJson()).toList(),
      };
    }
  }
}
