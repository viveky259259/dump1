import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/family_member.dart';
import '../models/calendar_event.dart';
import '../models/household_task.dart';
import '../models/item_tracker.dart';
import '../models/emergency_contact.dart';
import 'firebase_service.dart';
import 'auth_service.dart';

class FirebaseDataSyncService extends ChangeNotifier {
  static FirebaseDataSyncService? _instance;
  static FirebaseDataSyncService get instance => _instance ??= FirebaseDataSyncService._();
  
  FirebaseDataSyncService._();
  
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Data state
  List<FamilyMember> _familyMembers = [];
  List<CalendarEvent> _calendarEvents = [];
  List<HouseholdTask> _householdTasks = [];
  List<TrackedItem> _trackedItems = [];
  List<EmergencyContact> _emergencyContacts = [];
  
  bool _isLoading = false;
  bool _isInitialized = false;
  String? _error;
  
  // Stream subscriptions for real-time updates
  List<StreamSubscription> _subscriptions = [];
  
  // Getters
  List<FamilyMember> get familyMembers => _familyMembers;
  List<CalendarEvent> get calendarEvents => _calendarEvents;
  List<HouseholdTask> get householdTasks => _householdTasks;
  List<TrackedItem> get trackedItems => _trackedItems;
  List<EmergencyContact> get emergencyContacts => _emergencyContacts;
  bool get isLoading => _isLoading;
  bool get isInitialized => _isInitialized;
  String? get error => _error;
  
  Future<void> initialize() async {
    if (_isInitialized) return;
    
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      final authService = AuthService.instance;
      if (authService.isAuthenticated && authService.currentFamilyId != null) {
        await _setupRealtimeListeners(authService.currentFamilyId!);
        _isInitialized = true;
      }
    } catch (e) {
      _error = e.toString();
      print('Firebase data sync initialization error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  
  Future<void> _setupRealtimeListeners(String familyId) async {
    // Clear existing subscriptions
    await _clearSubscriptions();
    
    // Family members listener
    _subscriptions.add(
      _firestore
          .collection('families')
          .doc(familyId)
          .collection('members')
          .snapshots()
          .listen(
        (snapshot) {
          try {
            _familyMembers = snapshot.docs
                .map((doc) => FamilyMember.fromJson({...doc.data(), 'id': doc.id}))
                .toList();
            _familyMembers.sort((a, b) => a.name.compareTo(b.name));
            notifyListeners();
          } catch (e) {
            print('Error processing family members: $e');
          }
        },
        onError: (error) {
          print('Family members listener error: $error');
          _error = error.toString();
          notifyListeners();
        },
      ),
    );
    
    // Calendar events listener
    _subscriptions.add(
      _firestore
          .collection('families')
          .doc(familyId)
          .collection('events')
          .snapshots()
          .listen(
        (snapshot) {
          try {
            _calendarEvents = snapshot.docs
                .map((doc) => CalendarEvent.fromJson({...doc.data(), 'id': doc.id}))
                .toList();
            _calendarEvents.sort((a, b) => a.date.compareTo(b.date));
            notifyListeners();
          } catch (e) {
            print('Error processing calendar events: $e');
          }
        },
        onError: (error) {
          print('Calendar events listener error: $error');
          _error = error.toString();
          notifyListeners();
        },
      ),
    );
    
    // Household tasks listener
    _subscriptions.add(
      _firestore
          .collection('families')
          .doc(familyId)
          .collection('tasks')
          .snapshots()
          .listen(
        (snapshot) {
          try {
            _householdTasks = snapshot.docs
                .map((doc) => HouseholdTask.fromJson({...doc.data(), 'id': doc.id}))
                .toList();
            _householdTasks.sort((a, b) => a.dueDate.compareTo(b.dueDate));
            notifyListeners();
          } catch (e) {
            print('Error processing household tasks: $e');
          }
        },
        onError: (error) {
          print('Household tasks listener error: $error');
          _error = error.toString();
          notifyListeners();
        },
      ),
    );
    
    // Tracked items listener
    _subscriptions.add(
      _firestore
          .collection('families')
          .doc(familyId)
          .collection('items')
          .snapshots()
          .listen(
        (snapshot) {
          try {
            _trackedItems = snapshot.docs
                .map((doc) => TrackedItem.fromJson({...doc.data(), 'id': doc.id}))
                .toList();
            _trackedItems.sort((a, b) => a.name.compareTo(b.name));
            notifyListeners();
          } catch (e) {
            print('Error processing tracked items: $e');
          }
        },
        onError: (error) {
          print('Tracked items listener error: $error');
          _error = error.toString();
          notifyListeners();
        },
      ),
    );
    
    // Emergency contacts listener
    _subscriptions.add(
      _firestore
          .collection('families')
          .doc(familyId)
          .collection('emergencyContacts')
          .snapshots()
          .listen(
        (snapshot) {
          try {
            _emergencyContacts = snapshot.docs
                .map((doc) => EmergencyContact.fromJson({...doc.data(), 'id': doc.id}))
                .toList();
            _emergencyContacts.sort((a, b) => a.name.compareTo(b.name));
            notifyListeners();
          } catch (e) {
            print('Error processing emergency contacts: $e');
          }
        },
        onError: (error) {
          print('Emergency contacts listener error: $error');
          _error = error.toString();
          notifyListeners();
        },
      ),
    );
  }
  
  Future<void> _clearSubscriptions() async {
    for (final subscription in _subscriptions) {
      await subscription.cancel();
    }
    _subscriptions.clear();
  }
  
  Future<void> switchFamily(String newFamilyId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    
    try {
      await _setupRealtimeListeners(newFamilyId);
    } catch (e) {
      _error = e.toString();
      print('Error switching family: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  
  void dispose() {
    _clearSubscriptions();
    super.dispose();
  }
  
  // CRUD Operations with optimistic updates
  
  Future<void> addFamilyMember(FamilyMember member) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('members')
          .add(member.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> updateFamilyMember(FamilyMember member) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('members')
          .doc(member.id)
          .update(member.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> deleteFamilyMember(String memberId) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('members')
          .doc(memberId)
          .delete();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> addCalendarEvent(CalendarEvent event) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('events')
          .add(event.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> updateCalendarEvent(CalendarEvent event) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('events')
          .doc(event.id)
          .update(event.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> deleteCalendarEvent(String eventId) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('events')
          .doc(eventId)
          .delete();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> addHouseholdTask(HouseholdTask task) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('tasks')
          .add(task.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> updateHouseholdTask(HouseholdTask task) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('tasks')
          .doc(task.id)
          .update(task.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> deleteHouseholdTask(String taskId) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('tasks')
          .doc(taskId)
          .delete();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> addTrackedItem(TrackedItem item) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('items')
          .add(item.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> updateTrackedItem(TrackedItem item) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('items')
          .doc(item.id)
          .update(item.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> deleteTrackedItem(String itemId) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('items')
          .doc(itemId)
          .delete();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> addEmergencyContact(EmergencyContact contact) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('emergencyContacts')
          .add(contact.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> updateEmergencyContact(EmergencyContact contact) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('emergencyContacts')
          .doc(contact.id)
          .update(contact.toJson());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  Future<void> deleteEmergencyContact(String contactId) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      await _firestore
          .collection('families')
          .doc(authService.currentFamilyId!)
          .collection('emergencyContacts')
          .doc(contactId)
          .delete();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
  
  // Batch operations for better performance
  Future<void> batchUpdate(List<Map<String, dynamic>> operations) async {
    try {
      final authService = AuthService.instance;
      if (authService.currentFamilyId == null) throw Exception('No active family');
      
      final batch = _firestore.batch();
      
      for (final operation in operations) {
        final collection = operation['collection'] as String;
        final docId = operation['docId'] as String?;
        final data = operation['data'] as Map<String, dynamic>;
        final type = operation['type'] as String; // 'add', 'update', 'delete'
        
        final docRef = docId != null
            ? _firestore
                .collection('families')
                .doc(authService.currentFamilyId!)
                .collection(collection)
                .doc(docId)
            : _firestore
                .collection('families')
                .doc(authService.currentFamilyId!)
                .collection(collection)
                .doc();
        
        switch (type) {
          case 'add':
            batch.set(docRef, data);
            break;
          case 'update':
            batch.update(docRef, data);
            break;
          case 'delete':
            batch.delete(docRef);
            break;
        }
      }
      
      await batch.commit();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
}