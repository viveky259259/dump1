import 'package:flutter/foundation.dart';
import 'auth_service.dart';
import 'data_service.dart';
import 'firebase_service.dart';

/// Service to handle synchronization of family data with Firebase
/// and ensure proper loading on app startup
class FamilySyncService extends ChangeNotifier {
  static FamilySyncService? _instance;
  static FamilySyncService get instance => _instance ??= FamilySyncService._();
  
  FamilySyncService._();
  
  bool _isInitialized = false;
  bool _isSyncing = false;
  String? _currentFamilyId;
  String? _lastSyncError;
  DateTime? _lastSyncTime;
  
  // Getters
  bool get isInitialized => _isInitialized;
  bool get isSyncing => _isSyncing;
  String? get currentFamilyId => _currentFamilyId;
  String? get lastSyncError => _lastSyncError;
  DateTime? get lastSyncTime => _lastSyncTime;
  
  /// Initialize the family sync service
  Future<void> initialize() async {
    try {
      // Wait for auth service to be ready
      await _waitForAuthService();
      
      // Set up callback with auth service
      final authService = AuthService.instance;
      authService.setFamilyLoadedCallback((familyId) async {
        print('Family loaded callback triggered for: $familyId');
        await syncFamilyData(familyId);
      });
      
      // Check if user has a family and sync if needed
      if (authService.isAuthenticated && authService.currentFamilyId != null) {
        await syncFamilyData(authService.currentFamilyId!);
      }
      
      _isInitialized = true;
      notifyListeners();
    } catch (e) {
      print('Family sync service initialization error: $e');
      _lastSyncError = e.toString();
      _isInitialized = true;
      notifyListeners();
    }
  }
  
  /// Wait for auth service to be initialized
  Future<void> _waitForAuthService() async {
    final authService = AuthService.instance;
    
    // Wait up to 10 seconds for auth service to initialize
    int attempts = 0;
    while (!authService.isInitialized && attempts < 100) {
      await Future.delayed(const Duration(milliseconds: 100));
      attempts++;
    }
    
    if (!authService.isInitialized) {
      throw Exception('Auth service failed to initialize within timeout');
    }
  }
  
  /// Sync family data from Firebase
  Future<void> syncFamilyData(String familyId) async {
    if (_isSyncing && _currentFamilyId == familyId) {
      print('Already syncing family data for: $familyId');
      return;
    }
    
    _isSyncing = true;
    _currentFamilyId = familyId;
    _lastSyncError = null;
    notifyListeners();
    
    try {
      print('Starting family data sync for: $familyId');
      
      // Verify family exists
      final familyDoc = await FirebaseService.instance.getFamily(familyId);
      if (!familyDoc.exists) {
        throw Exception('Family not found: $familyId');
      }
      
      // Get family information
      final familyData = familyDoc.data() as Map<String, dynamic>;
      print('Found family: ${familyData['name']}');
      
      // Switch data service to Firebase
      final dataService = DataService.instance;
      await dataService.switchToFirebase(familyId);
      
      _lastSyncTime = DateTime.now();
      print('Family data sync completed for: $familyId');
      
    } catch (e) {
      print('Family data sync error: $e');
      _lastSyncError = e.toString();
    } finally {
      _isSyncing = false;
      notifyListeners();
    }
  }
  
  /// Force refresh family data
  Future<void> refreshFamilyData() async {
    if (_currentFamilyId != null) {
      await syncFamilyData(_currentFamilyId!);
    }
  }
  
  /// Clear sync state (called on logout)
  void clearSyncState() {
    _currentFamilyId = null;
    _lastSyncError = null;
    _lastSyncTime = null;
    _isSyncing = false;
    notifyListeners();
  }
  
  /// Get family sync status
  Map<String, dynamic> getSyncStatus() {
    return {
      'isInitialized': _isInitialized,
      'isSyncing': _isSyncing,
      'currentFamilyId': _currentFamilyId,
      'lastSyncError': _lastSyncError,
      'lastSyncTime': _lastSyncTime?.toIso8601String(),
    };
  }
}