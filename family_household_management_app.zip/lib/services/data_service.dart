import 'package:flutter/foundation.dart';
import '../models/family_member.dart';
import '../models/calendar_event.dart';
import '../models/household_task.dart';
import '../models/item_tracker.dart';
import '../models/emergency_contact.dart';
import 'firebase_service.dart';
import 'storage_service.dart';
import 'auth_service.dart';

class DataService extends ChangeNotifier {
  static DataService? _instance;
  static DataService get instance => _instance ??= DataService._();
  
  DataService._() {
    _initializeService();
  }
  
  bool _useFirebase = false;
  bool _isLoading = false;
  bool _isLoadingFamilyData = false;
  String? _error;
  
  List<FamilyMember> _familyMembers = [];
  List<CalendarEvent> _calendarEvents = [];
  List<HouseholdTask> _householdTasks = [];
  List<TrackedItem> _trackedItems = [];
  List<EmergencyContact> _emergencyContacts = [];
  
  // Getters
  bool get useFirebase => _useFirebase;
  bool get isLoading => _isLoading;
  bool get isLoadingFamilyData => _isLoadingFamilyData;
  String? get error => _error;
  List<FamilyMember> get familyMembers => _familyMembers;
  List<CalendarEvent> get calendarEvents => _calendarEvents;
  List<HouseholdTask> get householdTasks => _householdTasks;
  List<TrackedItem> get trackedItems => _trackedItems;
  List<EmergencyContact> get emergencyContacts => _emergencyContacts;
  
  Future<void> _initializeService() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      // Try to initialize Firebase
      final authService = AuthService.instance;
      if (authService.isAuthenticated && authService.currentFamilyId != null) {
        _useFirebase = true;
        await _loadFirebaseData(authService.currentFamilyId!);
      } else {
        _useFirebase = false;
        await _loadLocalData();
      }
      _error = null;
    } catch (e) {
      print('Firebase not available, using local storage: $e');
      _useFirebase = false;
      await _loadLocalData();
      _error = null; // Don't show error for Firebase fallback
    }
    
    _isLoading = false;
    notifyListeners();
  }
  
  Future<void> switchToFirebase(String familyId) async {
    _isLoadingFamilyData = true;
    notifyListeners();
    
    try {
      print('Switching to Firebase for family: $familyId');
      _useFirebase = true;
      await _loadFirebaseData(familyId);
      _error = null;
      print('Successfully loaded Firebase data for family: $familyId');
    } catch (e) {
      print('Failed to switch to Firebase: $e');
      _useFirebase = false;
      _error = 'Failed to load family data: $e';
      await _loadLocalData();
    } finally {
      _isLoadingFamilyData = false;
      notifyListeners();
    }
  }
  
  Future<void> switchToLocal() async {
    _useFirebase = false;
    await _loadLocalData();
    notifyListeners();
  }
  
  Future<void> _loadFirebaseData(String familyId) async {
    try {
      // Subscribe to Firebase streams
      FirebaseService.instance.watchFamilyMembers(familyId).listen((snapshot) {
        _familyMembers = snapshot.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>?;
          if (data != null) {
            return FamilyMember.fromFirestore(doc.id, data);
          }
          return null;
        }).where((member) => member != null).cast<FamilyMember>().toList();
        notifyListeners();
      }, onError: (error) {
        print('Error loading family members from Firebase: $error');
        _fallbackToLocal();
      });
      
      FirebaseService.instance.watchEvents(familyId).listen((snapshot) {
        _calendarEvents = snapshot.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>?;
          if (data != null) {
            return CalendarEvent.fromFirestore(doc.id, data);
          }
          return null;
        }).where((event) => event != null).cast<CalendarEvent>().toList();
        notifyListeners();
      }, onError: (error) {
        print('Error loading calendar events from Firebase: $error');
      });
      
      FirebaseService.instance.watchTasks(familyId).listen((snapshot) {
        _householdTasks = snapshot.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>?;
          if (data != null) {
            return HouseholdTask.fromFirestore(doc.id, data);
          }
          return null;
        }).where((task) => task != null).cast<HouseholdTask>().toList();
        notifyListeners();
      }, onError: (error) {
        print('Error loading tasks from Firebase: $error');
      });
      
      FirebaseService.instance.watchItems(familyId).listen((snapshot) {
        _trackedItems = snapshot.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>?;
          if (data != null) {
            return TrackedItem.fromFirestore(doc.id, data);
          }
          return null;
        }).where((item) => item != null).cast<TrackedItem>().toList();
        notifyListeners();
      }, onError: (error) {
        print('Error loading items from Firebase: $error');
      });
      
      FirebaseService.instance.watchEmergencyContacts(familyId).listen((snapshot) {
        _emergencyContacts = snapshot.docs.map((doc) {
          final data = doc.data() as Map<String, dynamic>?;
          if (data != null) {
            return EmergencyContact.fromFirestore(doc.id, data);
          }
          return null;
        }).where((contact) => contact != null).cast<EmergencyContact>().toList();
        notifyListeners();
      }, onError: (error) {
        print('Error loading emergency contacts from Firebase: $error');
      });
    } catch (e) {
      throw Exception('Failed to load Firebase data: $e');
    }
  }
  
  Future<void> _loadLocalData() async {
    try {
      _familyMembers = await StorageService.getFamilyMembers();
      _calendarEvents = await StorageService.getCalendarEvents();
      _householdTasks = await StorageService.getHouseholdTasks();
      _trackedItems = await StorageService.getTrackedItems();
      _emergencyContacts = await StorageService.getEmergencyContacts();
    } catch (e) {
      print('Error loading local data: $e');
      // Fallback to sample data
      _familyMembers = FamilyMember.getSampleMembers();
      _calendarEvents = CalendarEvent.getSampleEvents();
      _householdTasks = HouseholdTask.getSampleTasks();
      _trackedItems = TrackedItem.getSampleItems();
      _emergencyContacts = EmergencyContact.getSampleContacts();
    }
  }
  
  Future<void> _fallbackToLocal() async {
    _useFirebase = false;
    await _loadLocalData();
    notifyListeners();
  }
  
  // CRUD Operations
  Future<void> addFamilyMember(FamilyMember member) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.addFamilyMember(familyId, member.toFirestore());
        }
      } else {
        await StorageService.addFamilyMember(member);
        _familyMembers = await StorageService.getFamilyMembers();
        notifyListeners();
      }
    } catch (e) {
      print('Error adding family member: $e');
      _error = 'Failed to add family member';
      notifyListeners();
    }
  }
  
  Future<void> updateFamilyMember(FamilyMember member) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null && member.id != null) {
          await FirebaseService.instance.updateFamilyMember(familyId, member.id!, member.toFirestore());
        }
      } else {
        await StorageService.updateFamilyMember(member);
        _familyMembers = await StorageService.getFamilyMembers();
        notifyListeners();
      }
    } catch (e) {
      print('Error updating family member: $e');
      _error = 'Failed to update family member';
      notifyListeners();
    }
  }
  
  Future<void> deleteFamilyMember(String memberId) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.deleteFamilyMember(familyId, memberId);
        }
      } else {
        await StorageService.deleteFamilyMember(memberId);
        _familyMembers = await StorageService.getFamilyMembers();
        notifyListeners();
      }
    } catch (e) {
      print('Error deleting family member: $e');
      _error = 'Failed to delete family member';
      notifyListeners();
    }
  }
  
  // Calendar Events
  Future<void> addCalendarEvent(CalendarEvent event) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.addEvent(familyId, event.toFirestore());
        }
      } else {
        await StorageService.addCalendarEvent(event);
        _calendarEvents = await StorageService.getCalendarEvents();
        notifyListeners();
      }
    } catch (e) {
      print('Error adding calendar event: $e');
      _error = 'Failed to add calendar event';
      notifyListeners();
    }
  }
  
  Future<void> updateCalendarEvent(CalendarEvent event) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null && event.id != null) {
          await FirebaseService.instance.updateEvent(familyId, event.id!, event.toFirestore());
        }
      } else {
        await StorageService.updateCalendarEvent(event);
        _calendarEvents = await StorageService.getCalendarEvents();
        notifyListeners();
      }
    } catch (e) {
      print('Error updating calendar event: $e');
      _error = 'Failed to update calendar event';
      notifyListeners();
    }
  }
  
  Future<void> deleteCalendarEvent(String eventId) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.deleteEvent(familyId, eventId);
        }
      } else {
        await StorageService.deleteCalendarEvent(eventId);
        _calendarEvents = await StorageService.getCalendarEvents();
        notifyListeners();
      }
    } catch (e) {
      print('Error deleting calendar event: $e');
      _error = 'Failed to delete calendar event';
      notifyListeners();
    }
  }
  
  // Similar methods would be implemented for tasks, items, and emergency contacts...
  // For brevity, I'll add just the task methods as an example:
  
  Future<void> addHouseholdTask(HouseholdTask task) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.addTask(familyId, task.toFirestore());
        }
      } else {
        await StorageService.addHouseholdTask(task);
        _householdTasks = await StorageService.getHouseholdTasks();
        notifyListeners();
      }
    } catch (e) {
      print('Error adding household task: $e');
      _error = 'Failed to add household task';
      notifyListeners();
    }
  }
  
  Future<void> updateHouseholdTask(HouseholdTask task) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null && task.id != null) {
          await FirebaseService.instance.updateTask(familyId, task.id!, task.toFirestore());
        }
      } else {
        await StorageService.updateHouseholdTask(task);
        _householdTasks = await StorageService.getHouseholdTasks();
        notifyListeners();
      }
    } catch (e) {
      print('Error updating household task: $e');
      _error = 'Failed to update household task';
      notifyListeners();
    }
  }
  
  Future<void> deleteHouseholdTask(String taskId) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.deleteTask(familyId, taskId);
        }
      } else {
        await StorageService.deleteHouseholdTask(taskId);
        _householdTasks = await StorageService.getHouseholdTasks();
        notifyListeners();
      }
    } catch (e) {
      print('Error deleting household task: $e');
      _error = 'Failed to delete household task';
      notifyListeners();
    }
  }
  
  // Tracked Items
  Future<void> addTrackedItem(TrackedItem item) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.addItem(familyId, item.toFirestore());
        }
      } else {
        await StorageService.addTrackedItem(item);
        _trackedItems = await StorageService.getTrackedItems();
        notifyListeners();
      }
    } catch (e) {
      print('Error adding tracked item: $e');
      _error = 'Failed to add tracked item';
      notifyListeners();
    }
  }
  
  Future<void> updateTrackedItem(TrackedItem item) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null && item.id != null) {
          await FirebaseService.instance.updateItem(familyId, item.id!, item.toFirestore());
        }
      } else {
        await StorageService.updateTrackedItem(item);
        _trackedItems = await StorageService.getTrackedItems();
        notifyListeners();
      }
    } catch (e) {
      print('Error updating tracked item: $e');
      _error = 'Failed to update tracked item';
      notifyListeners();
    }
  }
  
  Future<void> deleteTrackedItem(String itemId) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.deleteItem(familyId, itemId);
        }
      } else {
        await StorageService.deleteTrackedItem(itemId);
        _trackedItems = await StorageService.getTrackedItems();
        notifyListeners();
      }
    } catch (e) {
      print('Error deleting tracked item: $e');
      _error = 'Failed to delete tracked item';
      notifyListeners();
    }
  }
  
  // Emergency Contacts
  Future<void> addEmergencyContact(EmergencyContact contact) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.addEmergencyContact(familyId, contact.toFirestore());
        }
      } else {
        await StorageService.addEmergencyContact(contact);
        _emergencyContacts = await StorageService.getEmergencyContacts();
        notifyListeners();
      }
    } catch (e) {
      print('Error adding emergency contact: $e');
      _error = 'Failed to add emergency contact';
      notifyListeners();
    }
  }
  
  Future<void> updateEmergencyContact(EmergencyContact contact) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null && contact.id != null) {
          await FirebaseService.instance.updateEmergencyContact(familyId, contact.id!, contact.toFirestore());
        }
      } else {
        await StorageService.updateEmergencyContact(contact);
        _emergencyContacts = await StorageService.getEmergencyContacts();
        notifyListeners();
      }
    } catch (e) {
      print('Error updating emergency contact: $e');
      _error = 'Failed to update emergency contact';
      notifyListeners();
    }
  }
  
  Future<void> deleteEmergencyContact(String contactId) async {
    try {
      if (_useFirebase) {
        final familyId = AuthService.instance.currentFamilyId;
        if (familyId != null) {
          await FirebaseService.instance.deleteEmergencyContact(familyId, contactId);
        }
      } else {
        await StorageService.deleteEmergencyContact(contactId);
        _emergencyContacts = await StorageService.getEmergencyContacts();
        notifyListeners();
      }
    } catch (e) {
      print('Error deleting emergency contact: $e');
      _error = 'Failed to delete emergency contact';
      notifyListeners();
    }
  }
  
  void clearError() {
    _error = null;
    notifyListeners();
  }
  
  Future<void> refresh() async {
    await _initializeService();
  }
  
  // Debug method to get current status
  Map<String, dynamic> getDebugInfo() {
    return {
      'useFirebase': _useFirebase,
      'isLoading': _isLoading,
      'isLoadingFamilyData': _isLoadingFamilyData,
      'error': _error,
      'familyMembersCount': _familyMembers.length,
      'calendarEventsCount': _calendarEvents.length,
      'householdTasksCount': _householdTasks.length,
      'trackedItemsCount': _trackedItems.length,
      'emergencyContactsCount': _emergencyContacts.length,
    };
  }
}