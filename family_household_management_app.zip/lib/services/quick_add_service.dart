import 'package:flutter/foundation.dart';
import '../models/calendar_event.dart';
import '../models/household_task.dart';
import '../models/item_tracker.dart';
import '../models/family_member.dart';
import '../services/firebase_service.dart';
import '../services/auth_service.dart';
import '../services/data_service.dart';


class QuickAddService extends ChangeNotifier {
  static QuickAddService? _instance;
  static QuickAddService get instance => _instance ??= QuickAddService._();
  
  QuickAddService._();
  
  final FirebaseService _firebaseService = FirebaseService.instance;
  final AuthService _authService = AuthService.instance;
  final DataService _dataService = DataService.instance;
  
  bool _isLoading = false;
  String? _error;
  
  bool get isLoading => _isLoading;
  String? get error => _error;
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }
  
  void clearError() {
    _error = null;
    notifyListeners();
  }
  
  // Quick add event
  Future<bool> quickAddEvent({
    required String title,
    String description = '',
    required DateTime date,
    required String assignedMemberId,
    String category = 'Other',
    bool hasReminder = false,
    DateTime? reminderTime,
  }) async {
    _setLoading(true);
    _setError(null);
    
    try {
      final event = CalendarEvent(
        title: title,
        description: description,
        date: date,
        assignedMemberId: assignedMemberId,
        category: category,
        hasReminder: hasReminder,
        reminderTime: reminderTime,
        createdAt: DateTime.now(),
      );
      
      if (_dataService.useFirebase && _authService.currentFamilyId != null) {
        await _firebaseService.addEvent(
          _authService.currentFamilyId!,
          event.toFirestore(),
        );
      } else {
        // Add to local storage
        await _dataService.addCalendarEvent(event);
      }
      
      _setLoading(false);
      return true;
    } catch (e) {
      _setError('Failed to add event: ${e.toString()}');
      _setLoading(false);
      return false;
    }
  }
  
  // Quick add task
  Future<bool> quickAddTask({
    required String title,
    String description = '',
    required String assignedMemberId,
    required DateTime dueDate,
    String category = 'Other',
    String priority = 'Medium',
    bool isRecurring = false,
    String? recurringPattern,
  }) async {
    _setLoading(true);
    _setError(null);
    
    try {
      final task = HouseholdTask(
        title: title,
        description: description,
        assignedMemberId: assignedMemberId,
        dueDate: dueDate,
        category: category,
        priority: priority,
        isRecurring: isRecurring,
        recurringPattern: recurringPattern,
        createdAt: DateTime.now(),
      );
      
      if (_dataService.useFirebase && _authService.currentFamilyId != null) {
        await _firebaseService.addTask(
          _authService.currentFamilyId!,
          task.toFirestore(),
        );
      } else {
        // Add to local storage
        await _dataService.addHouseholdTask(task);
      }
      
      _setLoading(false);
      return true;
    } catch (e) {
      _setError('Failed to add task: ${e.toString()}');
      _setLoading(false);
      return false;
    }
  }
  
  // Quick add item
  Future<bool> quickAddItem({
    required String name,
    String description = '',
    required String currentLocation,
    String category = 'Other',
    String status = 'Available',
    String? borrowedByMemberId,
  }) async {
    _setLoading(true);
    _setError(null);
    
    try {
      // Generate image URL for the item
      String? imageUrl;
      try {
        imageUrl = await "https://pixabay.com/get/g39b5276567fb92a7baf677d28a4c03c5084f50ddf04f4d7f1faeb01322c509502782849816637c3f5b6456ddd6f482df2fc850ebe2020af12027e65741220266_1280.jpg";
      } catch (e) {
        // Continue without image if generation fails
        print('Failed to generate image for item: $e');
      }
      
      final item = TrackedItem(
        name: name,
        description: description,
        currentLocation: currentLocation,
        borrowedByMemberId: borrowedByMemberId,
        borrowedAt: borrowedByMemberId != null ? DateTime.now() : null,
        category: category,
        status: status,
        imageUrl: imageUrl,
        history: [
          ItemHistory(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            action: 'Added',
            memberId: _authService.currentUser?.uid ?? 'unknown',
            location: currentLocation,
            timestamp: DateTime.now(),
            notes: 'Item added to tracking',
          ),
        ],
        createdAt: DateTime.now(),
      );
      
      if (_dataService.useFirebase && _authService.currentFamilyId != null) {
        await _firebaseService.addItem(
          _authService.currentFamilyId!,
          item.toFirestore(),
        );
      } else {
        // Add to local storage
        await _dataService.addTrackedItem(item);
      }
      
      _setLoading(false);
      return true;
    } catch (e) {
      _setError('Failed to add item: ${e.toString()}');
      _setLoading(false);
      return false;
    }
  }
  
  // Quick suggestions based on user history and common patterns
  List<String> getEventSuggestions() {
    return [
      'Doctor Appointment',
      'School Meeting',
      'Birthday Party',
      'Family Dinner',
      'Soccer Practice',
      'Piano Lesson',
      'Grocery Shopping',
      'Movie Night',
      'Dentist Appointment',
      'Vacation Planning',
    ];
  }
  
  List<String> getTaskSuggestions() {
    return [
      'Take out trash',
      'Vacuum living room',
      'Do laundry',
      'Clean bathroom',
      'Mow lawn',
      'Water plants',
      'Feed pets',
      'Wash dishes',
      'Make beds',
      'Organize closet',
    ];
  }
  
  List<String> getItemSuggestions() {
    return [
      'iPad',
      'Headphones',
      'Charger',
      'Book',
      'Soccer Ball',
      'Bicycle',
      'Tools',
      'Kitchen Scale',
      'Board Game',
      'Remote Control',
    ];
  }
  
  // Get smart defaults based on context
  String getDefaultEventCategory(String title) {
    final lowerTitle = title.toLowerCase();
    if (lowerTitle.contains('doctor') || lowerTitle.contains('dentist') || lowerTitle.contains('appointment')) {
      return 'Appointment';
    } else if (lowerTitle.contains('birthday') || lowerTitle.contains('party')) {
      return 'Birthday';
    } else if (lowerTitle.contains('school') || lowerTitle.contains('meeting') || lowerTitle.contains('conference')) {
      return 'School Event';
    } else if (lowerTitle.contains('family') || lowerTitle.contains('dinner') || lowerTitle.contains('movie')) {
      return 'Family Activity';
    }
    return 'Other';
  }
  
  String getDefaultTaskCategory(String title) {
    final lowerTitle = title.toLowerCase();
    if (lowerTitle.contains('clean') || lowerTitle.contains('vacuum') || lowerTitle.contains('trash')) {
      return 'Cleaning';
    } else if (lowerTitle.contains('kitchen') || lowerTitle.contains('dishes') || lowerTitle.contains('cook')) {
      return 'Kitchen';
    } else if (lowerTitle.contains('laundry') || lowerTitle.contains('wash')) {
      return 'Laundry';
    } else if (lowerTitle.contains('yard') || lowerTitle.contains('lawn') || lowerTitle.contains('garden')) {
      return 'Yard Work';
    } else if (lowerTitle.contains('shop') || lowerTitle.contains('grocery')) {
      return 'Shopping';
    } else if (lowerTitle.contains('pet') || lowerTitle.contains('dog') || lowerTitle.contains('cat')) {
      return 'Pet Care';
    }
    return 'Other';
  }
  
  String getDefaultItemCategory(String name) {
    final lowerName = name.toLowerCase();
    if (lowerName.contains('ipad') || lowerName.contains('phone') || lowerName.contains('charger') || 
        lowerName.contains('headphones') || lowerName.contains('tablet')) {
      return 'Electronics';
    } else if (lowerName.contains('tool') || lowerName.contains('drill') || lowerName.contains('hammer')) {
      return 'Tools';
    } else if (lowerName.contains('book') || lowerName.contains('magazine')) {
      return 'Books';
    } else if (lowerName.contains('ball') || lowerName.contains('bike') || lowerName.contains('sports')) {
      return 'Sports Equipment';
    } else if (lowerName.contains('kitchen') || lowerName.contains('scale') || lowerName.contains('pot')) {
      return 'Kitchen Items';
    } else if (lowerName.contains('toy') || lowerName.contains('game')) {
      return 'Toys & Games';
    }
    return 'Other';
  }
  
  String getDefaultTaskPriority(String title) {
    final lowerTitle = title.toLowerCase();
    if (lowerTitle.contains('urgent') || lowerTitle.contains('emergency') || lowerTitle.contains('important')) {
      return 'Urgent';
    } else if (lowerTitle.contains('trash') || lowerTitle.contains('bills') || lowerTitle.contains('appointment')) {
      return 'High';
    } else if (lowerTitle.contains('organize') || lowerTitle.contains('plan')) {
      return 'Low';
    }
    return 'Medium';
  }
}