import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class FirebaseService {
  static FirebaseService? _instance;
  static FirebaseService get instance => _instance ??= FirebaseService._();
  
  FirebaseService._();
  
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  
  // Initialize Firebase
  static Future<void> initialize() async {
    try {
      await Firebase.initializeApp();
      
      // Request permission for iOS
      await FirebaseMessaging.instance.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );
    } catch (e) {
      print('Firebase initialization error: $e');
      // Continue without Firebase for demo purposes
    }
  }
  
  // Authentication methods
  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();
  
  Future<UserCredential?> signInWithEmailAndPassword(String email, String password) async {
    try {
      return await _auth.signInWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      print('Sign in error: $e');
      return null;
    }
  }
  
  Future<UserCredential?> createUserWithEmailAndPassword(String email, String password) async {
    try {
      return await _auth.createUserWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      print('Sign up error: $e');
      return null;
    }
  }
  
  Future<void> signOut() async {
    await _auth.signOut();
  }
  
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      print('Password reset error: $e');
    }
  }
  
  // Firestore methods
  CollectionReference get familiesCollection => _firestore.collection('families');
  CollectionReference get usersCollection => _firestore.collection('users');
  
  // Family management
  Future<DocumentReference> createFamily(Map<String, dynamic> familyData) async {
    return await familiesCollection.add({
      ...familyData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateFamily(String familyId, Map<String, dynamic> data) async {
    await familiesCollection.doc(familyId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<DocumentSnapshot> getFamily(String familyId) async {
    return await familiesCollection.doc(familyId).get();
  }
  
  Stream<DocumentSnapshot> watchFamily(String familyId) {
    return familiesCollection.doc(familyId).snapshots();
  }
  
  // Family members
  Future<void> addFamilyMember(String familyId, Map<String, dynamic> memberData) async {
    await familiesCollection.doc(familyId).collection('members').add({
      ...memberData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateFamilyMember(String familyId, String memberId, Map<String, dynamic> data) async {
    await familiesCollection.doc(familyId).collection('members').doc(memberId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> deleteFamilyMember(String familyId, String memberId) async {
    await familiesCollection.doc(familyId).collection('members').doc(memberId).delete();
  }
  
  Stream<QuerySnapshot> watchFamilyMembers(String familyId) {
    return familiesCollection.doc(familyId).collection('members').snapshots();
  }
  
  // Tasks
  Future<void> addTask(String familyId, Map<String, dynamic> taskData) async {
    await familiesCollection.doc(familyId).collection('tasks').add({
      ...taskData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateTask(String familyId, String taskId, Map<String, dynamic> data) async {
    await familiesCollection.doc(familyId).collection('tasks').doc(taskId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> deleteTask(String familyId, String taskId) async {
    await familiesCollection.doc(familyId).collection('tasks').doc(taskId).delete();
  }
  
  Stream<QuerySnapshot> watchTasks(String familyId) {
    return familiesCollection.doc(familyId).collection('tasks').snapshots();
  }
  
  // Calendar events
  Future<void> addEvent(String familyId, Map<String, dynamic> eventData) async {
    await familiesCollection.doc(familyId).collection('events').add({
      ...eventData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateEvent(String familyId, String eventId, Map<String, dynamic> data) async {
    await familiesCollection.doc(familyId).collection('events').doc(eventId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> deleteEvent(String familyId, String eventId) async {
    await familiesCollection.doc(familyId).collection('events').doc(eventId).delete();
  }
  
  Stream<QuerySnapshot> watchEvents(String familyId) {
    return familiesCollection.doc(familyId).collection('events').snapshots();
  }
  
  // Items tracking
  Future<void> addItem(String familyId, Map<String, dynamic> itemData) async {
    await familiesCollection.doc(familyId).collection('items').add({
      ...itemData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateItem(String familyId, String itemId, Map<String, dynamic> data) async {
    await familiesCollection.doc(familyId).collection('items').doc(itemId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> deleteItem(String familyId, String itemId) async {
    await familiesCollection.doc(familyId).collection('items').doc(itemId).delete();
  }
  
  Stream<QuerySnapshot> watchItems(String familyId) {
    return familiesCollection.doc(familyId).collection('items').snapshots();
  }
  
  // Emergency contacts
  Future<void> addEmergencyContact(String familyId, Map<String, dynamic> contactData) async {
    await familiesCollection.doc(familyId).collection('emergencyContacts').add({
      ...contactData,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateEmergencyContact(String familyId, String contactId, Map<String, dynamic> data) async {
    await familiesCollection.doc(familyId).collection('emergencyContacts').doc(contactId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> deleteEmergencyContact(String familyId, String contactId) async {
    await familiesCollection.doc(familyId).collection('emergencyContacts').doc(contactId).delete();
  }
  
  Stream<QuerySnapshot> watchEmergencyContacts(String familyId) {
    return familiesCollection.doc(familyId).collection('emergencyContacts').snapshots();
  }
  
  // User management
  Future<void> createUserProfile(String userId, Map<String, dynamic> userData) async {
    await usersCollection.doc(userId).set({
      ...userData,
      'familyIds': userData['familyIds'] ?? [], // Support multiple families
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> updateUserProfile(String userId, Map<String, dynamic> data) async {
    await usersCollection.doc(userId).update({
      ...data,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  // User family management
  Future<void> addUserToFamily(String userId, String familyId) async {
    await usersCollection.doc(userId).update({
      'familyIds': FieldValue.arrayUnion([familyId]),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<void> removeUserFromFamily(String userId, String familyId) async {
    await usersCollection.doc(userId).update({
      'familyIds': FieldValue.arrayRemove([familyId]),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
  
  Future<DocumentSnapshot> getUserProfile(String userId) async {
    return await usersCollection.doc(userId).get();
  }
  
  Stream<DocumentSnapshot> watchUserProfile(String userId) {
    return usersCollection.doc(userId).snapshots();
  }
  
  // Get families that a user is a member of
  Stream<QuerySnapshot> watchUserFamilies(String userId) {
    return familiesCollection.where('memberIds', arrayContains: userId).snapshots();
  }
  
  // Push notifications
  Future<String?> getDeviceToken() async {
    return await _messaging.getToken();
  }
  
  Future<void> subscribeToTopic(String topic) async {
    await _messaging.subscribeToTopic(topic);
  }
  
  Future<void> unsubscribeFromTopic(String topic) async {
    await _messaging.unsubscribeFromTopic(topic);
  }
}