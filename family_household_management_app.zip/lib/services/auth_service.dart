import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_service.dart';

class AuthService extends ChangeNotifier {
  static AuthService? _instance;
  static AuthService get instance => _instance ??= AuthService._();
  
  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;
  
  AuthService._() {
    _initializeAuth();
  }
  
  void _initializeAuth() async {
    try {
      // Check if user is already signed in with Firebase
      _currentUser = FirebaseService.instance.currentUser;
      if (_currentUser != null) {
        await _loadUserData(_currentUser!.uid);
        // Update stored preferences if user is authenticated
        await _saveLoginPreferences(_currentUser!.email ?? '');
        // Notify about family load
        await _notifyDataServiceOfFamilyLoad();
      } else {
        // Check stored preferences for debugging purposes
        final storedInfo = await getStoredLoginInfo();
        if (storedInfo != null) {
          print('Found stored login info for: ${storedInfo['email']}');
          print('Last login: ${storedInfo['lastLoginTime']}');
          // Note: Firebase Auth handles persistence automatically
          // If user isn't authenticated here, it means they manually signed out
          // or their session expired, so we should clear preferences
          await _clearLoginPreferences();
        }
      }
      
      // Listen for auth state changes
      FirebaseService.instance.authStateChanges.listen((User? user) async {
        _currentUser = user;
        if (user != null) {
          await _loadUserData(user.uid);
          // Notify about family load when user signs in
          await _notifyDataServiceOfFamilyLoad();
        } else {
          _currentFamilyId = null;
          // Clear preferences when user signs out
          _clearLoginPreferences();
        }
        notifyListeners();
      });
      
      _isInitialized = true;
      notifyListeners();
    } catch (e) {
      print('Auth service initialization error: $e');
      // Continue without Firebase authentication for demo purposes
      _isInitialized = true;
      notifyListeners();
    }
  }
  
  Future<void> _clearLoginPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('isLoggedIn');
      await prefs.remove('userEmail');
      await prefs.remove('lastLoginTime');
    } catch (e) {
      print('Error clearing login preferences: $e');
    }
  }
  
  User? _currentUser;
  User? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  
  String? _currentFamilyId;
  String? get currentFamilyId => _currentFamilyId;
  
  List<String> _userFamilyIds = [];
  List<String> get userFamilyIds => _userFamilyIds;
  
  Future<void> setCurrentFamily(String familyId) async {
    if (_userFamilyIds.contains(familyId)) {
      _currentFamilyId = familyId;
      notifyListeners();
      await _notifyDataServiceOfFamilyLoad();
    }
  }
  
  Future<AuthResult> signInWithEmailAndPassword(String email, String password) async {
    try {
      final credential = await FirebaseService.instance.signInWithEmailAndPassword(email, password);
      if (credential != null && credential.user != null) {
        await _loadUserData(credential.user!.uid);
        await _saveLoginPreferences(email);
        return AuthResult(success: true, message: 'Successfully signed in');
      } else {
        return AuthResult(success: false, message: 'Failed to sign in');
      }
    } catch (e) {
      return AuthResult(success: false, message: e.toString());
    }
  }
  
  Future<AuthResult> createUserWithEmailAndPassword(String email, String password, String name) async {
    try {
      final credential = await FirebaseService.instance.createUserWithEmailAndPassword(email, password);
      if (credential != null && credential.user != null) {
        // Create user profile
        await FirebaseService.instance.createUserProfile(credential.user!.uid, {
          'name': name,
          'email': email,
          'familyIds': [],
        });
        
        // Update display name
        await credential.user!.updateDisplayName(name);
        
        await _loadUserData(credential.user!.uid);
        await _saveLoginPreferences(email);
        return AuthResult(success: true, message: 'Account created successfully');
      } else {
        return AuthResult(success: false, message: 'Failed to create account');
      }
    } catch (e) {
      return AuthResult(success: false, message: e.toString());
    }
  }
  
  Future<void> signOut() async {
    try {
      // Clear any stored preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      
      // Sign out from Firebase
      await FirebaseService.instance.signOut();
      
      // Clear local state
      _currentUser = null;
      _currentFamilyId = null;
      
      notifyListeners();
    } catch (e) {
      print('Error during sign out: $e');
      // Even if there's an error, try to clear local state
      _currentUser = null;
      _currentFamilyId = null;
      notifyListeners();
    }
  }
  
  Future<AuthResult> sendPasswordResetEmail(String email) async {
    try {
      await FirebaseService.instance.sendPasswordResetEmail(email);
      return AuthResult(success: true, message: 'Password reset email sent');
    } catch (e) {
      return AuthResult(success: false, message: e.toString());
    }
  }
  
  Future<void> _loadUserData(String userId) async {
    try {
      final userDoc = await FirebaseService.instance.getUserProfile(userId);
      if (userDoc.exists) {
        final userData = userDoc.data() as Map<String, dynamic>;
        
        // Load family IDs array (new structure)
        final familyIds = List<String>.from(userData['familyIds'] ?? []);
        _userFamilyIds = familyIds;
        
        // For backward compatibility, check for single familyId
        final singleFamilyId = userData['familyId'];
        if (singleFamilyId != null && !familyIds.contains(singleFamilyId)) {
          _userFamilyIds.add(singleFamilyId);
        }
        
        // Set current family ID to the first family or keep existing selection
        if (_currentFamilyId == null || !_userFamilyIds.contains(_currentFamilyId)) {
          _currentFamilyId = _userFamilyIds.isNotEmpty ? _userFamilyIds.first : null;
        }
        
        print('User families loaded: $_userFamilyIds');
        print('Current family ID: $_currentFamilyId');
      }
    } catch (e) {
      print('Error loading user data: $e');
    }
  }
  
  // Callback for notifying when family data should be loaded
  Function(String familyId)? _onFamilyLoaded;
  
  void setFamilyLoadedCallback(Function(String familyId) callback) {
    _onFamilyLoaded = callback;
  }
  
  Future<void> _notifyDataServiceOfFamilyLoad() async {
    try {
      if (_currentFamilyId != null && _onFamilyLoaded != null) {
        _onFamilyLoaded!(_currentFamilyId!);
      }
    } catch (e) {
      print('Error notifying family loaded: $e');
    }
  }
  
  Future<Map<String, dynamic>?> getCurrentFamilyInfo() async {
    if (_currentFamilyId == null) return null;
    
    try {
      final familyDoc = await FirebaseService.instance.getFamily(_currentFamilyId!);
      if (familyDoc.exists) {
        return familyDoc.data() as Map<String, dynamic>?;
      }
    } catch (e) {
      print('Error getting family info: $e');
    }
    return null;
  }
  
  // Method to manually refresh family data (useful for debugging and force refresh)
  Future<void> refreshFamilyData() async {
    if (_currentUser != null) {
      await _loadUserData(_currentUser!.uid);
      await _notifyDataServiceOfFamilyLoad();
      notifyListeners();
    }
  }
  
  Future<void> _saveLoginPreferences(String email) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', true);
      await prefs.setString('userEmail', email);
      await prefs.setString('lastLoginTime', DateTime.now().toIso8601String());
    } catch (e) {
      print('Error saving login preferences: $e');
    }
  }
  
  Future<Map<String, dynamic>?> getStoredLoginInfo() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
      final userEmail = prefs.getString('userEmail');
      final lastLoginTime = prefs.getString('lastLoginTime');
      
      if (isLoggedIn && userEmail != null) {
        return {
          'email': userEmail,
          'lastLoginTime': lastLoginTime,
        };
      }
    } catch (e) {
      print('Error getting stored login info: $e');
    }
    return null;
  }
  
  Future<AuthResult> createFamily(String familyName) async {
    if (_currentUser == null) {
      return AuthResult(success: false, message: 'User not authenticated');
    }
    
    try {
      final familyRef = await FirebaseService.instance.createFamily({
        'name': familyName,
        'ownerId': _currentUser!.uid,
        'memberIds': [_currentUser!.uid],
      });
      
      // Add user to family in user profile
      await FirebaseService.instance.addUserToFamily(_currentUser!.uid, familyRef.id);
      
      // Add user as family member
      await FirebaseService.instance.addFamilyMember(familyRef.id, {
        'userId': _currentUser!.uid,
        'name': _currentUser!.displayName ?? 'User',
        'email': _currentUser!.email,
        'role': 'Admin',
        'isOwner': true,
      });
      
      // Update local state
      _userFamilyIds.add(familyRef.id);
      _currentFamilyId = familyRef.id;
      notifyListeners();
      
      return AuthResult(success: true, message: 'Family created successfully');
    } catch (e) {
      return AuthResult(success: false, message: e.toString());
    }
  }
  
  Future<AuthResult> joinFamily(String familyId) async {
    if (_currentUser == null) {
      return AuthResult(success: false, message: 'User not authenticated');
    }
    
    try {
      // Check if family exists
      final familyDoc = await FirebaseService.instance.getFamily(familyId);
      if (!familyDoc.exists) {
        return AuthResult(success: false, message: 'Family not found');
      }
      
      // Add user to family
      await FirebaseService.instance.addFamilyMember(familyId, {
        'userId': _currentUser!.uid,
        'name': _currentUser!.displayName ?? 'User',
        'email': _currentUser!.email,
        'role': 'Member',
        'isOwner': false,
      });
      
      // Add family to user's family list
      await FirebaseService.instance.addUserToFamily(_currentUser!.uid, familyId);
      
      // Update the family member list in the family doc
      await FirebaseService.instance.updateFamily(familyId, {
        'memberIds': FieldValue.arrayUnion([_currentUser!.uid]),
      });
      
      // Update local state
      _userFamilyIds.add(familyId);
      _currentFamilyId = familyId;
      notifyListeners();
      
      return AuthResult(success: true, message: 'Joined family successfully');
    } catch (e) {
      return AuthResult(success: false, message: e.toString());
    }
  }
  
  Future<AuthResult> leaveFamily(String familyId) async {
    if (_currentUser == null) {
      return AuthResult(success: false, message: 'User not authenticated');
    }
    
    if (!_userFamilyIds.contains(familyId)) {
      return AuthResult(success: false, message: 'User is not a member of this family');
    }
    
    try {
      // Remove user from family members collection
      final membersQuery = await FirebaseService.instance.familiesCollection
          .doc(familyId)
          .collection('members')
          .where('userId', isEqualTo: _currentUser!.uid)
          .get();
      
      for (var doc in membersQuery.docs) {
        await doc.reference.delete();
      }
      
      // Remove user from family's member list
      await FirebaseService.instance.updateFamily(familyId, {
        'memberIds': FieldValue.arrayRemove([_currentUser!.uid]),
      });
      
      // Remove family from user's family list
      await FirebaseService.instance.removeUserFromFamily(_currentUser!.uid, familyId);
      
      // Update local state
      _userFamilyIds.remove(familyId);
      
      // If this was the current family, switch to another or set to null
      if (_currentFamilyId == familyId) {
        _currentFamilyId = _userFamilyIds.isNotEmpty ? _userFamilyIds.first : null;
        if (_currentFamilyId != null) {
          await _notifyDataServiceOfFamilyLoad();
        }
      }
      
      notifyListeners();
      
      return AuthResult(success: true, message: 'Left family successfully');
    } catch (e) {
      return AuthResult(success: false, message: e.toString());
    }
  }
}

class AuthResult {
  final bool success;
  final String message;
  
  AuthResult({required this.success, required this.message});
}