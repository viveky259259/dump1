import 'package:flutter/material.dart';

class NavigationService extends ChangeNotifier {
  static NavigationService? _instance;
  static NavigationService get instance => _instance ??= NavigationService._();
  
  NavigationService._();
  
  int _currentMainTab = 0;
  
  // Main tab indices
  static const int homeTab = 0;
  static const int calendarTab = 1;
  static const int tasksTab = 2;
  static const int itemsTab = 3;
  
  int get currentMainTab => _currentMainTab;
  
  void setMainTab(int index) {
    if (index != _currentMainTab && index >= 0 && index <= 3) {
      _currentMainTab = index;
      notifyListeners();
    }
  }
  
  void navigateToHome() => setMainTab(homeTab);
  void navigateToCalendar() => setMainTab(calendarTab);
  void navigateToTasks() => setMainTab(tasksTab);
  void navigateToItems() => setMainTab(itemsTab);
  
  String get currentTabName {
    switch (_currentMainTab) {
      case homeTab:
        return 'Home';
      case calendarTab:
        return 'Calendar';
      case tasksTab:
        return 'Tasks';
      case itemsTab:
        return 'Items';
      default:
        return 'Home';
    }
  }
  
  IconData get currentTabIcon {
    switch (_currentMainTab) {
      case homeTab:
        return Icons.home_rounded;
      case calendarTab:
        return Icons.calendar_month_rounded;
      case tasksTab:
        return Icons.task_alt_rounded;
      case itemsTab:
        return Icons.inventory_2_rounded;
      default:
        return Icons.home_rounded;
    }
  }
}