import 'package:flutter/material.dart';
import 'package:dart/api.dart'; // From dartastic_opentelemetry_api
import 'package:flutterrific_opentelemetry/flutterrific_opentelemetry.dart'; // The SDK for Flutter
import 'package:logger/logger.dart'; // Still using this for general logging

// --- OpenTelemetry Trace Setup ---
TracerProvider? _tracerProvider; // Declare as nullable to initialize later

void initializeOpenTelemetryTracing() {
  final exporter = OtlpGrpcTraceExporter(
    Uri.parse('http://localhost:4317'), // SigNoz Collector gRPC endpoint for traces
    // For Android Emulator, use 'http://10.0.2.2:4317'
    // For physical device, use 'http://YOUR_DOCKER_HOST_IP:4317'
  );

  final processor = BatchSpanProcessor(exporter);

  _tracerProvider = TracerProvider(
    processors: [processor],
    resource: Resource([
      Attribute.fromString("service.name", "your-flutter-app-name"),
      Attribute.fromString("telemetry.sdk.language", "dart"),
      Attribute.fromString("telemetry.sdk.name", "flutterrific"),
      Attribute.fromString("flutter.app.version", "1.0.0"), // Example app-specific attribute
    ]),
  );

  globalTracerProvider = _tracerProvider!; // Set the global provider
}

// --- OpenTelemetry Log Setup ---
LoggerProvider? _loggerProvider;

void initializeOpenTelemetryLogging() {
  final exporter = OtlpGrpcLogExporter(
    Uri.parse('http://localhost:4317'), // SigNoz Collector gRPC endpoint for logs
    // For Android Emulator, use 'http://10.0.2.2:4317'
    // For physical device, use 'http://YOUR_DOCKER_HOST_IP:4317'
  );

  final logProcessor = BatchLogRecordProcessor(exporter);

  _loggerProvider = LoggerProvider(
    logRecordProcessors: [logProcessor],
    resource: Resource([
      Attribute.fromString("service.name", "your-flutter-app-logs"), // Can be same or different from trace service name
      Attribute.fromString("deployment.environment", "development"),
      Attribute.fromString("host.name", "flutter-device"),
    ]),
  );

  globalLoggerProvider = _loggerProvider!; // Set the global logger provider
}


// --- Custom Logger for OpenTelemetry Integration ---
class OtelLogOutput extends LogOutput {
  // Use the global OpenTelemetry Logger
  final Logger _otelLogger = globalLoggerProvider.getLogger('flutter_app_logger');

  @override
  void output(OutputEvent event) {
    for (var line in event.lines) {
      Level level = event.level;
      Severity severity;
      // Map 'logger' package levels to OpenTelemetry Severity
      switch (level) {
        case Level.trace:
          severity = Severity.trace;
          break;
        case Level.debug:
          severity = Severity.debug;
          break;
        case Level.info:
          severity = Severity.info;
          break;
        case Level.warning:
          severity = Severity.warn;
          break;
        case Level.error:
          severity = Severity.error;
          break;
        case Level.wtf: // What a Terrible Failure (often mapped to FATAL)
        case Level.fatal:
          severity = Severity.fatal;
          break;
        default:
          severity = Severity.unspecified;
      }

      // Create attributes from the logger event if desired
      Map<String, Attribute> attributes = {
        Attribute.fromString('logger.level_name', level.name.toUpperCase()),
        if (event.error != null) Attribute.fromString('exception.message', event.error.toString()),
        if (event.stackTrace != null) Attribute.fromString('exception.stacktrace', event.stackTrace.toString()),
        // Add any additional structured data from the logger payload
        if (event.event != null && event.event is Map<String, dynamic>)
          ..._extractMapAttributes(event.event as Map<String, dynamic>),
      };

      // Emit a LogRecord to OpenTelemetry
      _otelLogger.emit(
        LogRecord(
          body: line, // The log message
          severity: severity,
          timestamp: DateTime.now().toUtc(),
          attributes: attributes,
        ),
      );
    }
  }

  // Helper to convert a Map<String, dynamic> to Map<String, Attribute>
  Map<String, Attribute> _extractMapAttributes(Map<String, dynamic> data) {
    Map<String, Attribute> attrs = {};
    data.forEach((key, value) {
      if (value is String) {
        attrs[key] = Attribute.fromString(key, value);
      } else if (value is int) {
        attrs[key] = Attribute.fromInt(key, value);
      } else if (value is double) {
        attrs[key] = Attribute.fromDouble(key, value);
      } else if (value is bool) {
        attrs[key] = Attribute.fromBoolean(key, value);
      } else if (value is List) {
        // Handle list of strings for now; more complex types might need recursion or specific handling
        final stringList = value.whereType<String>().toList();
        if (stringList.length == value.length) { // Check if all elements are strings
          attrs[key] = Attribute.fromListOfString(key, stringList);
        }
      }
      // Add more type handling as needed (e.g., nested maps)
    });
    return attrs;
  }
}

void main() {
  WidgetsFlutterBinding.ensureInitialized(); // Ensure Flutter bindings are initialized

  // Initialize OpenTelemetry Tracing
  initializeOpenTelemetryTracing();

  // Initialize OpenTelemetry Logging
  initializeOpenTelemetryLogging();

  // Configure the `logger` package to use our OpenTelemetry output
  Logger logger = Logger(
    printer: PrettyPrinter(), // Or your preferred printer
    output: OtelLogOutput(), // Use our custom OpenTelemetry log output
    level: Level.debug, // Set minimum logging level
  );

  runApp(MyApp(appLogger: logger));
}

class MyApp extends StatelessWidget {
  final Logger appLogger;
  const MyApp({super.key, required this.appLogger});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter SigNoz Demo', appLogger: appLogger),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  final Logger appLogger;
  const MyHomePage({super.key, required this.title, required this.appLogger});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // Get the Tracer from the global provider
  final Tracer _tracer = globalTracerProvider.getTracer('my-flutter-app-tracer');

  void _createAndSendTraceAndLog() {
    // Start a root span
    final rootSpan = _tracer.startSpan('button_click_with_logs');
    try {
      widget.appLogger.i('User clicked the button. Starting trace for operation.',
          {'buttonName': 'Generate Trace & Logs'}); // Example of structured log data
      rootSpan.setAttribute(Attribute.fromString('event.type', 'user_interaction'));

      // Create a child span
      final childSpan = _tracer.startSpan('perform_data_fetch', kind: SpanKind.client);
      try {
        widget.appLogger.d('Initiating data fetch simulation for span ${childSpan.spanContext.spanId}');
        Future.delayed(const Duration(milliseconds: 300), () {
          childSpan.setAttribute(Attribute.fromString('http.url', 'https://api.example.com/data'));
          childSpan.addEvent('Data fetched successfully');
          widget.appLogger.v('Successfully fetched simulated data. Span ID: ${childSpan.spanContext.spanId}'); // Verbose/Trace level log
        }).then((_) {
          childSpan.end();
        });
      } catch (e, st) {
        childSpan.recordException(e, stackTrace: st);
        widget.appLogger.e('Error during data fetch: $e', e, st); // Pass error and stack trace to logger
      } finally {
        // Important: In a real async scenario, ensure childSpan.end() is called when the Future completes.
        // The .then() block above handles this.
      }
    } catch (e, st) {
      rootSpan.recordException(e, stackTrace: st);
      widget.appLogger.e('Critical error in button click handler: $e', e, st);
    } finally {
      rootSpan.end();
      widget.appLogger.w('Operation completed. Check SigNoz for traces and logs. Trace ID: ${rootSpan.spanContext.traceId}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: _createAndSendTraceAndLog,
              child: const Text('Generate Trace & Logs'),
            ),
            ElevatedButton(
              onPressed: () {
                widget.appLogger.e('This is an error log sent to SigNoz!',
                    Exception('Simulated error condition'), StackTrace.current); // Pass error and stack trace
              },
              child: const Text('Send Error Log'),
            ),
            ElevatedButton(
              onPressed: () {
                widget.appLogger.i('This is an info log with some extra data.',
                    {'userId': '123', 'action': 'test_info', 'data': [1, 2, 3].map((e) => e.toString()).toList()}); // Structured data
              },
              child: const Text('Send Info Log with Attributes'),
            ),
          ],
        ),
      ),
    );
  }
}