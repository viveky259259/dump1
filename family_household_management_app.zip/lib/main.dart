import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme.dart';
import 'services/storage_service.dart';
import 'services/firebase_service.dart';
import 'services/auth_service.dart';
import 'services/data_service.dart';
import 'services/quick_add_service.dart';
import 'services/family_sync_service.dart';
import 'services/navigation_service.dart';
import 'services/firebase_data_sync_service.dart';
import 'pages/home_page.dart';
import 'pages/auth/login_page.dart';
import 'pages/auth/family_setup_page.dart';
import 'pages/settings/family_management_page.dart';
import 'package:opentelemetry/api.dart';
import 'package:opentelemetry/sdk.dart';

final headers = {
  //INGESTION KEY HERE VARIABLE
  'signoz-ingestion-key': '<your-ingestion-key>',
};

final exporter = CollectorExporter(
  //enter ingestion url here VARIABLE
  Uri.parse('http://192.168.0.101:4318/v1/traces'),
  headers: headers,
);

// Set up span processors
final processor = BatchSpanProcessor(exporter);
final provider = TracerProviderBase(
  processors: [processor],
  //enter service name here VARIABLE
  resource: Resource([Attribute.fromString("service.name", "FamilyHousehold")]),
);
void _createSpan() {
  final Tracer _tracer =
      globalTracerProvider.getTracer('FamilyHousehold-Tracer');

  final inputText = 'Hello world!';

  // Start a root span
  final rootSpan = _tracer.startSpan('root-span');
  try {
    // Create a child span with the input text
    final childSpan = _tracer.startSpan('child-span', kind: SpanKind.client);
    try {
      // Set attribute for the child span
      childSpan.setAttribute(Attribute.fromString('input.name', inputText));

      // Simulate a remote procedure call (this could be a real async call)
      remoteProcedureCall();

      // Add an event to the child span
      childSpan.addEvent('Processed input: $inputText');
    } catch (e) {
      childSpan.recordException(e);
    } finally {
      childSpan.end();
    }
  } catch (e) {
    // Handle any exceptions that may occur while starting spans
    print('Error creating span: $e');
  } finally {
    // End the root span
    rootSpan.end();
  }
}

Future<void> remoteProcedureCall() async {
  final headers = <String, String>{};
  W3CTraceContextPropagator()
      .inject(Context.current, headers, CustomTextMapSetter());
}

class CustomTextMapSetter implements TextMapSetter<Map<String, String>> {
  @override
  void set(Map<String, String> map, String key, String value) {
    map[key] = value;
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    // Initialize Firebase
    await FirebaseService.initialize();
  } catch (e) {
    print('Firebase initialization failed: $e');
    // Continue without Firebase for demo purposes
  }

  try {
    // Initialize storage service
    await StorageService.init();
  } catch (e) {
    print('Storage service initialization failed: $e');
    // Continue without storage service
  }

  try {
    // Initialize family sync service after other services
    await FamilySyncService.instance.initialize();
  } catch (e) {
    print('Family sync service initialization failed: $e');
    // Continue without family sync service
  }

  try {
    // Initialize Firebase data sync service
    await FirebaseDataSyncService.instance.initialize();
  } catch (e) {
    print('Firebase data sync service initialization failed: $e');
    // Continue without Firebase data sync service
  }
  registerGlobalTracerProvider(provider);

  runApp(const FamilyHubApp());
  _createSpan();
}

class FamilyHubApp extends StatelessWidget {
  const FamilyHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService.instance),
        ChangeNotifierProvider(create: (_) => DataService.instance),
        ChangeNotifierProvider(create: (_) => QuickAddService.instance),
        ChangeNotifierProvider(create: (_) => FamilySyncService.instance),
        ChangeNotifierProvider(create: (_) => NavigationService.instance),
        ChangeNotifierProvider(create: (_) => FirebaseDataSyncService.instance),
      ],
      child: MaterialApp(
        title: 'Family Hub - Household Management',
        theme: lightTheme,
        darkTheme: darkTheme,
        themeMode: ThemeMode.system,
        debugShowCheckedModeBanner: false,
        initialRoute: '/',
        routes: {
          '/': (context) => const AuthWrapper(),
          '/login': (context) => const LoginPage(),
          '/home': (context) => const HomePage(),
          '/family-setup': (context) => const FamilySetupPage(),
          '/family-management': (context) => const FamilyManagementPage(),
        },
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer3<AuthService, DataService, FamilySyncService>(
      builder: (context, authService, dataService, familySyncService, child) {
        // Show loading screen while auth service is initializing
        if (!authService.isInitialized) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Initializing app...'),
                ],
              ),
            ),
          );
        }

        // Show loading screen while family sync service is initializing
        if (!familySyncService.isInitialized) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Setting up family data...'),
                ],
              ),
            ),
          );
        }

        // Show loading screen while family data is being synced
        if (authService.isAuthenticated &&
            authService.currentFamilyId != null &&
            (dataService.isLoadingFamilyData || familySyncService.isSyncing)) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading family data...'),
                ],
              ),
            ),
          );
        }

        // For demo purposes, always show the HomePage if Firebase is not available
        try {
          if (authService.isAuthenticated) {
            if (authService.currentFamilyId == null) {
              return const FamilySetupPage();
            }
            return const HomePage();
          } else {
            return const LoginPage();
          }
        } catch (e) {
          print('Auth wrapper error: $e');
          // Fallback to HomePage for demo purposes
          return const HomePage();
        }
      },
    );
  }
}
