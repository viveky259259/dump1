import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/family_member.dart';
import '../models/calendar_event.dart';
import '../models/household_task.dart';
import '../models/item_tracker.dart';
import '../models/emergency_contact.dart';
import '../services/firebase_service.dart';
import '../services/auth_service.dart';

class FirebaseDataProvider extends ChangeNotifier {
  static FirebaseDataProvider? _instance;
  static FirebaseDataProvider get instance => _instance ??= FirebaseDataProvider._();
  
  FirebaseDataProvider._() {
    _initializeStreams();
  }
  
  List<FamilyMember> _familyMembers = [];
  List<CalendarEvent> _calendarEvents = [];
  List<HouseholdTask> _householdTasks = [];
  List<TrackedItem> _trackedItems = [];
  List<EmergencyContact> _emergencyContacts = [];
  
  bool _isLoading = false;
  
  // Getters
  List<FamilyMember> get familyMembers => _familyMembers;
  List<CalendarEvent> get calendarEvents => _calendarEvents;
  List<HouseholdTask> get householdTasks => _householdTasks;
  List<TrackedItem> get trackedItems => _trackedItems;
  List<EmergencyContact> get emergencyContacts => _emergencyContacts;
  bool get isLoading => _isLoading;
  
  void _initializeStreams() {
    AuthService.instance.addListener(() {
      final familyId = AuthService.instance.currentFamilyId;
      if (familyId != null) {
        _subscribeToDataStreams(familyId);
      } else {
        _clearData();
      }
    });
  }
  
  void _subscribeToDataStreams(String familyId) {
    // Subscribe to family members
    FirebaseService.instance.watchFamilyMembers(familyId).listen((snapshot) {
      _familyMembers = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return FamilyMember.fromFirestore(doc.id, data);
      }).toList();
      notifyListeners();
    });
    
    // Subscribe to calendar events
    FirebaseService.instance.watchEvents(familyId).listen((snapshot) {
      _calendarEvents = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return CalendarEvent.fromFirestore(doc.id, data);
      }).toList();
      notifyListeners();
    });
    
    // Subscribe to tasks
    FirebaseService.instance.watchTasks(familyId).listen((snapshot) {
      _householdTasks = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return HouseholdTask.fromFirestore(doc.id, data);
      }).toList();
      notifyListeners();
    });
    
    // Subscribe to items
    FirebaseService.instance.watchItems(familyId).listen((snapshot) {
      _trackedItems = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return TrackedItem.fromFirestore(doc.id, data);
      }).toList();
      notifyListeners();
    });
    
    // Subscribe to emergency contacts
    FirebaseService.instance.watchEmergencyContacts(familyId).listen((snapshot) {
      _emergencyContacts = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return EmergencyContact.fromFirestore(doc.id, data);
      }).toList();
      notifyListeners();
    });
  }
  
  void _clearData() {
    _familyMembers = [];
    _calendarEvents = [];
    _householdTasks = [];
    _trackedItems = [];
    _emergencyContacts = [];
    notifyListeners();
  }
  
  // Family Members
  Future<void> addFamilyMember(FamilyMember member) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.addFamilyMember(familyId, member.toFirestore());
  }
  
  Future<void> updateFamilyMember(FamilyMember member) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null || member.id == null) return;
    
    await FirebaseService.instance.updateFamilyMember(familyId, member.id!, member.toFirestore());
  }
  
  Future<void> deleteFamilyMember(String memberId) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.deleteFamilyMember(familyId, memberId);
  }
  
  // Calendar Events
  Future<void> addCalendarEvent(CalendarEvent event) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.addEvent(familyId, event.toFirestore());
  }
  
  Future<void> updateCalendarEvent(CalendarEvent event) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null || event.id == null) return;
    
    await FirebaseService.instance.updateEvent(familyId, event.id!, event.toFirestore());
  }
  
  Future<void> deleteCalendarEvent(String eventId) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.deleteEvent(familyId, eventId);
  }
  
  // Household Tasks
  Future<void> addHouseholdTask(HouseholdTask task) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.addTask(familyId, task.toFirestore());
  }
  
  Future<void> updateHouseholdTask(HouseholdTask task) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null || task.id == null) return;
    
    await FirebaseService.instance.updateTask(familyId, task.id!, task.toFirestore());
  }
  
  Future<void> deleteHouseholdTask(String taskId) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.deleteTask(familyId, taskId);
  }
  
  // Tracked Items
  Future<void> addTrackedItem(TrackedItem item) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.addItem(familyId, item.toFirestore());
  }
  
  Future<void> updateTrackedItem(TrackedItem item) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null || item.id == null) return;
    
    await FirebaseService.instance.updateItem(familyId, item.id!, item.toFirestore());
  }
  
  Future<void> deleteTrackedItem(String itemId) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.deleteItem(familyId, itemId);
  }
  
  // Emergency Contacts
  Future<void> addEmergencyContact(EmergencyContact contact) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.addEmergencyContact(familyId, contact.toFirestore());
  }
  
  Future<void> updateEmergencyContact(EmergencyContact contact) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null || contact.id == null) return;
    
    await FirebaseService.instance.updateEmergencyContact(familyId, contact.id!, contact.toFirestore());
  }
  
  Future<void> deleteEmergencyContact(String contactId) async {
    final familyId = AuthService.instance.currentFamilyId;
    if (familyId == null) return;
    
    await FirebaseService.instance.deleteEmergencyContact(familyId, contactId);
  }
}