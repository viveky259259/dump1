import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../services/auth_service.dart';
import '../../../services/data_service.dart';
import '../../../services/family_sync_service.dart';

class FamilySyncDebugPage extends StatelessWidget {
  const FamilySyncDebugPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Family Sync Debug'),
        backgroundColor: Colors.blue.shade600,
        foregroundColor: Colors.white,
      ),
      body: Consumer3<AuthService, DataService, FamilySyncService>(
        builder: (context, authService, dataService, familySyncService, child) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSectionCard(
                  title: 'Authentication Status',
                  children: [
                    _buildStatusRow('Initialized', authService.isInitialized),
                    _buildStatusRow('Authenticated', authService.isAuthenticated),
                    _buildInfoRow('User Email', authService.currentUser?.email ?? 'None'),
                    _buildInfoRow('Family ID', authService.currentFamilyId ?? 'None'),
                  ],
                ),
                const SizedBox(height: 16),
                _buildSectionCard(
                  title: 'Data Service Status',
                  children: [
                    _buildStatusRow('Using Firebase', dataService.useFirebase),
                    _buildStatusRow('Loading', dataService.isLoading),
                    _buildStatusRow('Loading Family Data', dataService.isLoadingFamilyData),
                    _buildInfoRow('Error', dataService.error ?? 'None'),
                    _buildInfoRow('Family Members', '${dataService.familyMembers.length}'),
                    _buildInfoRow('Calendar Events', '${dataService.calendarEvents.length}'),
                    _buildInfoRow('Tasks', '${dataService.householdTasks.length}'),
                    _buildInfoRow('Items', '${dataService.trackedItems.length}'),
                    _buildInfoRow('Emergency Contacts', '${dataService.emergencyContacts.length}'),
                  ],
                ),
                const SizedBox(height: 16),
                _buildSectionCard(
                  title: 'Family Sync Service',
                  children: [
                    _buildStatusRow('Initialized', familySyncService.isInitialized),
                    _buildStatusRow('Syncing', familySyncService.isSyncing),
                    _buildInfoRow('Current Family ID', familySyncService.currentFamilyId ?? 'None'),
                    _buildInfoRow('Last Sync Error', familySyncService.lastSyncError ?? 'None'),
                    _buildInfoRow('Last Sync Time', familySyncService.lastSyncTime?.toString() ?? 'None'),
                  ],
                ),
                const SizedBox(height: 24),
                _buildActionsSection(context, authService, dataService, familySyncService),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSectionCard({required String title, required List<Widget> children}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildStatusRow(String label, bool status) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Icon(
            status ? Icons.check_circle : Icons.cancel,
            color: status ? Colors.green : Colors.red,
            size: 20,
          ),
          const SizedBox(width: 8),
          Text(
            status ? 'Yes' : 'No',
            style: TextStyle(
              color: status ? Colors.green : Colors.red,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionsSection(
    BuildContext context,
    AuthService authService,
    DataService dataService,
    FamilySyncService familySyncService,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Actions',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        ElevatedButton.icon(
          onPressed: authService.currentFamilyId != null
              ? () => familySyncService.refreshFamilyData()
              : null,
          icon: const Icon(Icons.refresh),
          label: const Text('Refresh Family Data'),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () => authService.refreshFamilyData(),
          icon: const Icon(Icons.refresh),
          label: const Text('Refresh Auth Data'),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () => dataService.refresh(),
          icon: const Icon(Icons.data_usage),
          label: const Text('Refresh Data Service'),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () => _showDebugInfo(context, dataService, familySyncService),
          icon: const Icon(Icons.info),
          label: const Text('Show Debug Info'),
        ),
      ],
    );
  }

  void _showDebugInfo(
    BuildContext context,
    DataService dataService,
    FamilySyncService familySyncService,
  ) {
    final dataServiceInfo = dataService.getDebugInfo();
    final familySyncInfo = familySyncService.getSyncStatus();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Debug Information'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Data Service:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(dataServiceInfo.toString()),
              const SizedBox(height: 16),
              const Text(
                'Family Sync Service:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(familySyncInfo.toString()),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}