import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme.dart';
import '../models/family_member.dart';
import '../models/emergency_contact.dart';
import '../services/storage_service.dart';

class EmergencyPage extends StatefulWidget {
  final List<FamilyMember> familyMembers;

  const EmergencyPage({
    super.key,
    required this.familyMembers,
  });

  @override
  State<EmergencyPage> createState() => _EmergencyPageState();
}

class _EmergencyPageState extends State<EmergencyPage>
    with TickerProviderStateMixin {
  List<EmergencyContact> _allContacts = [];
  String _selectedTypeFilter = 'All';
  bool _isLoading = true;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadContacts();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadContacts() async {
    setState(() => _isLoading = true);
    
    try {
      final contacts = await StorageService.getEmergencyContacts();
      setState(() {
        _allContacts = contacts;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading contacts: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  List<EmergencyContact> _getContactsByType(String type) {
    switch (type) {
      case 'Emergency':
        return _allContacts.where((c) => c.contactType == 'Emergency Services').toList();
      case 'Medical':
        return _allContacts.where((c) => c.contactType == 'Medical').toList();
      case 'All':
      default:
        return _allContacts;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.error.withOpacity(0.05),
      appBar: AppBar(
        title: Row(
          children: [
            Icon(
              Icons.emergency_rounded,
              color: theme.colorScheme.error,
              size: 28,
            ),
            const SizedBox(width: 8),
            Text(
              'Emergency Contacts',
              style: theme.textTheme.headlineSmall?.copyWith(
                color: theme.colorScheme.error,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        backgroundColor: theme.colorScheme.surface,
        foregroundColor: theme.colorScheme.error,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelColor: theme.colorScheme.error,
          unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.6),
          indicatorColor: theme.colorScheme.error,
          labelStyle: theme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          tabs: [
            Tab(
              text: 'Emergency (\${_getContactsByType(\'Emergency\').length})',
            ),
            Tab(
              text: 'Medical (\${_getContactsByType(\'Medical\').length})',
            ),
            Tab(
              text: 'All (\${_getContactsByType(\'All\').length})',
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: _showAddContactDialog,
            icon: Icon(
              Icons.add_rounded,
              color: theme.colorScheme.error,
            ),
            tooltip: 'Add Contact',
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadContacts,
              child: Column(
                children: [
                  _buildEmergencyHeader(),
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        _buildContactsList(_getContactsByType('Emergency')),
                        _buildContactsList(_getContactsByType('Medical')),
                        _buildContactsList(_getContactsByType('All')),
                      ],
                    ),
                  ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _makeEmergencyCall('911'),
        backgroundColor: theme.colorScheme.error,
        foregroundColor: theme.colorScheme.onError,
        child: const Icon(Icons.emergency_rounded),
        tooltip: 'Call 911',
      ),
    );
  }

  Widget _buildEmergencyHeader() {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.all(20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.error,
            theme.colorScheme.error.withOpacity(0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.error.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(
            Icons.warning_rounded,
            color: theme.colorScheme.onError,
            size: 32,
          ),
          const SizedBox(height: 8),
          Text(
            'Emergency Information',
            style: theme.textTheme.titleLarge?.copyWith(
              color: theme.colorScheme.onError,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'In case of emergency, call 911 immediately.\nFor non-emergency situations, use the contacts below.',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onError.withOpacity(0.9),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _makeEmergencyCall('911'),
                  icon: const Icon(Icons.phone_rounded),
                  label: const Text('Call 911'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.onError,
                    foregroundColor: theme.colorScheme.error,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _makeEmergencyCall('1-800-222-1222'),
                  icon: const Icon(Icons.local_hospital_rounded),
                  label: const Text('Poison Control'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.onError,
                    foregroundColor: theme.colorScheme.error,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildContactsList(List<EmergencyContact> contacts) {
    final theme = Theme.of(context);

    if (contacts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.contact_phone_rounded,
              size: 64,
              color: theme.colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              'No contacts found',
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Add emergency contacts for quick access',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.5),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    // Separate primary and regular contacts
    final primaryContacts = contacts.where((c) => c.isPrimary).toList();
    final regularContacts = contacts.where((c) => !c.isPrimary).toList();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (primaryContacts.isNotEmpty) ...[
          _buildSectionHeader('Primary Contacts', Icons.star_rounded, theme.colorScheme.error),
          ...primaryContacts.map((contact) => _buildContactCard(contact, isPrimary: true)),
          const SizedBox(height: 20),
        ],
        if (regularContacts.isNotEmpty) ...[
          _buildSectionHeader('Other Contacts', Icons.contacts_rounded, theme.colorScheme.onSurface),
          ...regularContacts.map((contact) => _buildContactCard(contact)),
        ],
      ],
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, Color color) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(
            icon,
            color: color,
            size: 20,
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: theme.textTheme.titleMedium?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactCard(EmergencyContact contact, {bool isPrimary = false}) {
    final theme = Theme.of(context);
    final cardColor = isPrimary 
        ? theme.colorScheme.error 
        : theme.colorScheme.primary;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showContactDetails(contact),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: isPrimary 
                  ? Border.all(
                      color: theme.colorScheme.error.withOpacity(0.3),
                      width: 2,
                    )
                  : null,
              boxShadow: [
                BoxShadow(
                  color: theme.colorScheme.outline.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: cardColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: cardColor.withOpacity(0.3),
                    ),
                  ),
                  child: Icon(
                    _getContactTypeIcon(contact.contactType),
                    color: cardColor,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              contact.name,
                              style: theme.textTheme.bodyLarge?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: theme.colorScheme.onSurface,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (isPrimary)
                            Icon(
                              Icons.star_rounded,
                              color: theme.colorScheme.error,
                              size: 20,
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        contact.phoneNumber,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: cardColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: cardColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              contact.relationship,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: cardColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            contact.contactType,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurface.withOpacity(0.6),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  children: [
                    IconButton(
                      onPressed: () => _makeEmergencyCall(contact.phoneNumber),
                      icon: Icon(
                        Icons.phone_rounded,
                        color: cardColor,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: cardColor.withOpacity(0.1),
                        padding: const EdgeInsets.all(8),
                      ),
                      tooltip: 'Call \${contact.name}',
                    ),
                    if (contact.phoneNumber.length > 3)
                      IconButton(
                        onPressed: () => _sendSMS(contact.phoneNumber),
                        icon: Icon(
                          Icons.message_rounded,
                          color: cardColor,
                        ),
                        style: IconButton.styleFrom(
                          backgroundColor: cardColor.withOpacity(0.1),
                          padding: const EdgeInsets.all(8),
                        ),
                        tooltip: 'Text \${contact.name}',
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  IconData _getContactTypeIcon(String contactType) {
    switch (contactType.toLowerCase()) {
      case 'emergency services':
        return Icons.emergency_rounded;
      case 'medical':
        return Icons.local_hospital_rounded;
      case 'family':
        return Icons.family_restroom_rounded;
      case 'friend':
        return Icons.person_rounded;
      case 'neighbor':
        return Icons.home_rounded;
      case 'workplace':
        return Icons.work_rounded;
      case 'school':
        return Icons.school_rounded;
      case 'service provider':
        return Icons.build_rounded;
      default:
        return Icons.contact_phone_rounded;
    }
  }

  Future<void> _makeEmergencyCall(String phoneNumber) async {
    try {
      final uri = Uri(scheme: 'tel', path: phoneNumber);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        // Fallback: copy to clipboard
        await Clipboard.setData(ClipboardData(text: phoneNumber));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Phone number copied to clipboard: \$phoneNumber'),
              backgroundColor: Theme.of(context).colorScheme.primary,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error making call: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  Future<void> _sendSMS(String phoneNumber) async {
    try {
      final uri = Uri(scheme: 'sms', path: phoneNumber);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        // Fallback: copy to clipboard
        await Clipboard.setData(ClipboardData(text: phoneNumber));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Phone number copied to clipboard: \$phoneNumber'),
              backgroundColor: Theme.of(context).colorScheme.primary,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error sending SMS: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  void _showContactDetails(EmergencyContact contact) {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              _getContactTypeIcon(contact.contactType),
              color: contact.isPrimary ? theme.colorScheme.error : theme.colorScheme.primary,
            ),
            const SizedBox(width: 8),
            Expanded(child: Text(contact.name)),
            if (contact.isPrimary)
              Icon(
                Icons.star_rounded,
                color: theme.colorScheme.error,
                size: 20,
              ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow(Icons.phone_rounded, 'Phone', contact.phoneNumber),
            const SizedBox(height: 12),
            _buildDetailRow(Icons.person_rounded, 'Relationship', contact.relationship),
            const SizedBox(height: 12),
            _buildDetailRow(Icons.category_rounded, 'Type', contact.contactType),
            if (contact.email != null) ...[
              const SizedBox(height: 12),
              _buildDetailRow(Icons.email_rounded, 'Email', contact.email!),
            ],
            if (contact.address != null) ...[
              const SizedBox(height: 12),
              _buildDetailRow(Icons.location_on_rounded, 'Address', contact.address!),
            ],
            if (contact.notes != null && contact.notes!.isNotEmpty) ...[
              const SizedBox(height: 12),
              _buildDetailRow(Icons.note_rounded, 'Notes', contact.notes!),
            ],
          ],
        ),
        actions: [
          TextButton.icon(
            onPressed: () => _sendSMS(contact.phoneNumber),
            icon: const Icon(Icons.message_rounded),
            label: const Text('Text'),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).pop();
              _makeEmergencyCall(contact.phoneNumber);
            },
            icon: const Icon(Icons.phone_rounded),
            label: const Text('Call'),
            style: ElevatedButton.styleFrom(
              backgroundColor: contact.isPrimary 
                  ? theme.colorScheme.error 
                  : theme.colorScheme.primary,
              foregroundColor: theme.colorScheme.onPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    final theme = Theme.of(context);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 16,
          color: theme.colorScheme.onSurface.withOpacity(0.6),
        ),
        const SizedBox(width: 8),
        Text(
          '\$label: ',
          style: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w500,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: theme.textTheme.bodyMedium,
          ),
        ),
      ],
    );
  }

  void _showAddContactDialog() {
    // This would open a dialog to add a new emergency contact
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Emergency Contact'),
        content: const Text('Contact creation dialog will be implemented'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}