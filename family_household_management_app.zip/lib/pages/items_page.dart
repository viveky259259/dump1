import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../theme.dart';
import '../models/family_member.dart';
import '../models/item_tracker.dart';
import '../services/data_service.dart';
import '../services/firebase_data_sync_service.dart';
import 'package:provider/provider.dart';
import '../widgets/family_member_avatar.dart';
import '../widgets/quick_add_dialog.dart';
import '../widgets/edit_item_dialog.dart';

class ItemsPage extends StatefulWidget {
  final List<FamilyMember> familyMembers;

  const ItemsPage({
    super.key,
    required this.familyMembers,
  });

  @override
  State<ItemsPage> createState() => _ItemsPageState();
}

class _ItemsPageState extends State<ItemsPage> with TickerProviderStateMixin {
  List<TrackedItem> _allItems = [];
  String? _selectedMemberFilter;
  String? _selectedCategoryFilter;
  String? _selectedLocationFilter;
  String _selectedStatusFilter = 'All';
  bool _isLoading = true;
  bool _isGridView = false;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadItems();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadItems() async {
    setState(() => _isLoading = true);
    
    try {
      final dataService = Provider.of<DataService>(context, listen: false);
      final items = dataService.trackedItems;
      setState(() {
        _allItems = items;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading items: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  List<TrackedItem> _getItemsByStatus(String status) {
    switch (status) {
      case 'Available':
        return _allItems.where((i) => i.status == 'Available').toList();
      case 'Borrowed':
        return _allItems.where((i) => i.status == 'Borrowed').toList();
      case 'In Use':
        return _allItems.where((i) => i.status == 'In Use').toList();
      case 'All':
      default:
        return _allItems;
    }
  }

  List<TrackedItem> _getFilteredItems(List<TrackedItem> items) {
    return items.where((item) {
      bool matchesMember = _selectedMemberFilter == null || 
                          item.borrowedByMemberId == _selectedMemberFilter;
      bool matchesCategory = _selectedCategoryFilter == null || 
                            item.category == _selectedCategoryFilter;
      bool matchesLocation = _selectedLocationFilter == null ||
                            item.currentLocation == _selectedLocationFilter;
      
      return matchesMember && matchesCategory && matchesLocation;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer2<DataService, FirebaseDataSyncService>(
      builder: (context, dataService, syncService, child) {
        // Use Firebase sync service data if available, otherwise fall back to data service
        final items = syncService.isInitialized ? syncService.trackedItems : dataService.trackedItems;
        
        // Update items when data changes
        if (_allItems != items) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              setState(() {
                _allItems = items;
              });
            }
          });
        }

        return Scaffold(
          backgroundColor: theme.colorScheme.surface,
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(kToolbarHeight + 48),
            child: AppBar(
              title: Text(
                'Family Items',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: theme.colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                ),
              ),
              backgroundColor: theme.colorScheme.surface,
              foregroundColor: theme.colorScheme.onSurface,
              elevation: 0,
              automaticallyImplyLeading: false,
              actions: [
                IconButton(
                  onPressed: () => setState(() => _isGridView = !_isGridView),
                  icon: Icon(
                    _isGridView ? Icons.view_list_rounded : Icons.grid_view_rounded,
                    color: theme.colorScheme.primary,
                  ),
                  tooltip: _isGridView ? 'List View' : 'Grid View',
                ),
                IconButton(
                  onPressed: _showFilters,
                  icon: Icon(
                    Icons.filter_list_rounded,
                    color: theme.colorScheme.primary,
                  ),
                  tooltip: 'Filter Items',
                ),
                IconButton(
                  onPressed: _showAddItemDialog,
                  icon: Icon(
                    Icons.add_rounded,
                    color: theme.colorScheme.primary,
                  ),
                  tooltip: 'Add Item',
                ),
                const SizedBox(width: 8),
              ],
              bottom: TabBar(
                controller: _tabController,
                labelColor: theme.colorScheme.primary,
                unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.6),
                indicatorColor: theme.colorScheme.primary,
                isScrollable: true,
                labelStyle: theme.textTheme.labelMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                tabs: [
                  Tab(
                    text: 'All (${_getItemsByStatus('All').length})',
                  ),
                  Tab(
                    text: 'Available (${_getItemsByStatus('Available').length})',
                  ),
                  Tab(
                    text: 'Borrowed (${_getItemsByStatus('Borrowed').length})',
                  ),
                  Tab(
                    text: 'In Use (${_getItemsByStatus('In Use').length})',
                  ),
                ],
              ),
            ),
          ),
          body: (_isLoading || syncService.isLoading)
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: () async {
                    await _loadItems();
                    if (syncService.isInitialized) {
                      await syncService.initialize();
                    }
                  },
                  child: Column(
                    children: [
                      if (_hasActiveFilters()) _buildActiveFilters(),
                      Expanded(
                        child: TabBarView(
                          controller: _tabController,
                          children: [
                            _buildItemsList(_getItemsByStatus('All')),
                            _buildItemsList(_getItemsByStatus('Available')),
                            _buildItemsList(_getItemsByStatus('Borrowed')),
                            _buildItemsList(_getItemsByStatus('In Use')),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
          floatingActionButton: FloatingActionButton(
            onPressed: _showAddItemDialog,
            backgroundColor: theme.colorScheme.primary,
            foregroundColor: theme.colorScheme.onPrimary,
            child: const Icon(Icons.add_rounded),
          ),
        );
      },
    );
  }

  bool _hasActiveFilters() {
    return _selectedMemberFilter != null ||
           _selectedCategoryFilter != null ||
           _selectedLocationFilter != null;
  }

  Widget _buildActiveFilters() {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            if (_selectedMemberFilter != null) ...[
              _buildFilterChip(
                label: widget.familyMembers
                    .firstWhere((m) => m.id == _selectedMemberFilter)
                    .name,
                color: widget.familyMembers
                    .firstWhere((m) => m.id == _selectedMemberFilter)
                    .color,
                onRemove: () => setState(() => _selectedMemberFilter = null),
              ),
              const SizedBox(width: 8),
            ],
            if (_selectedCategoryFilter != null) ...[
              _buildFilterChip(
                label: _selectedCategoryFilter!,
                color: theme.colorScheme.secondary,
                onRemove: () => setState(() => _selectedCategoryFilter = null),
              ),
              const SizedBox(width: 8),
            ],
            if (_selectedLocationFilter != null) ...[
              _buildFilterChip(
                label: _selectedLocationFilter!,
                color: theme.colorScheme.tertiary,
                onRemove: () => setState(() => _selectedLocationFilter = null),
              ),
              const SizedBox(width: 8),
            ],
            TextButton(
              onPressed: () {
                setState(() {
                  _selectedMemberFilter = null;
                  _selectedCategoryFilter = null;
                  _selectedLocationFilter = null;
                });
              },
              child: Text(
                'Clear All',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: theme.colorScheme.primary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required Color color,
    required VoidCallback onRemove,
  }) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onRemove,
            child: Icon(
              Icons.close_rounded,
              size: 16,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildItemsList(List<TrackedItem> items) {
    final theme = Theme.of(context);
    final filteredItems = _getFilteredItems(items);

    if (filteredItems.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inventory_2_rounded,
              size: 64,
              color: theme.colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              'No items found',
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Add a new item or adjust your filters',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.5),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    if (_isGridView) {
      return GridView.builder(
        padding: const EdgeInsets.all(20),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.85,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
        ),
        itemCount: filteredItems.length,
        itemBuilder: (context, index) {
          final item = filteredItems[index];
          final member = item.borrowedByMemberId != null
              ? widget.familyMembers.firstWhere(
                  (m) => m.id == item.borrowedByMemberId,
                  orElse: () => widget.familyMembers.first,
                )
              : null;

          return _buildItemGridCard(item, member);
        },
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: filteredItems.length,
      itemBuilder: (context, index) {
        final item = filteredItems[index];
        final member = item.borrowedByMemberId != null
            ? widget.familyMembers.firstWhere(
                (m) => m.id == item.borrowedByMemberId,
                orElse: () => widget.familyMembers.first,
              )
            : null;

        return _buildItemListCard(item, member);
      },
    );
  }

  Widget _buildItemListCard(TrackedItem item, FamilyMember? member) {
    final theme = Theme.of(context);
    final statusColor = _getStatusColor(item.status, theme);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showItemDetails(item, member),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: theme.colorScheme.outline.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: statusColor.withOpacity(0.2),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: item.imageUrl != null
                        ? Image.network(
                            item.imageUrl!,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(
                                _getCategoryIcon(item.category),
                                color: statusColor,
                                size: 30,
                              );
                            },
                          )
                        : Icon(
                            _getCategoryIcon(item.category),
                            color: statusColor,
                            size: 30,
                          ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.name,
                        style: theme.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.onSurface,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.currentLocation,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurface.withOpacity(0.6),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              item.status,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: statusColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.secondary.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              item.category,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.secondary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (member != null) ...[
                  const SizedBox(width: 12),
                  Column(
                    children: [
                      FamilyMemberAvatar(
                        member: member,
                        size: 32,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        member.name,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurface.withOpacity(0.6),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildItemGridCard(TrackedItem item, FamilyMember? member) {
    final theme = Theme.of(context);
    final statusColor = _getStatusColor(item.status, theme);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _showItemDetails(item, member),
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: theme.colorScheme.outline.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                height: 80,
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: statusColor.withOpacity(0.2),
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: item.imageUrl != null
                      ? Image.network(
                          item.imageUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Icon(
                              _getCategoryIcon(item.category),
                              color: statusColor,
                              size: 40,
                            );
                          },
                        )
                      : Icon(
                          _getCategoryIcon(item.category),
                          color: statusColor,
                          size: 40,
                        ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                item.name,
                style: theme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onSurface,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                item.currentLocation,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
              const Spacer(),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      item.status,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: statusColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 10,
                      ),
                    ),
                  ),
                  const Spacer(),
                  if (member != null)
                    FamilyMemberAvatar(
                      member: member,
                      size: 24,
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status, ThemeData theme) {
    switch (status.toLowerCase()) {
      case 'available':
        return Colors.green;
      case 'borrowed':
        return Colors.orange;
      case 'in use':
        return Colors.blue;
      case 'lost':
        return theme.colorScheme.error;
      case 'maintenance':
        return Colors.purple;
      default:
        return theme.colorScheme.onSurface.withOpacity(0.6);
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'electronics':
        return Icons.devices_rounded;
      case 'tools':
        return Icons.build_rounded;
      case 'books':
        return Icons.book_rounded;
      case 'sports equipment':
        return Icons.sports_basketball_rounded;
      case 'kitchen items':
        return Icons.kitchen_rounded;
      case 'clothing':
        return Icons.checkroom_rounded;
      case 'toys & games':
        return Icons.toys_rounded;
      case 'documents':
        return Icons.description_rounded;
      default:
        return Icons.category_rounded;
    }
  }

  void _showFilters() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _buildFiltersSheet(),
    );
  }

  Widget _buildFiltersSheet() {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Filter Items',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            'Borrowed By',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: widget.familyMembers.map((member) {
              final isSelected = _selectedMemberFilter == member.id;
              return FamilyMemberChip(
                member: member,
                isSelected: isSelected,
                onTap: () {
                  setState(() {
                    _selectedMemberFilter = isSelected ? null : member.id;
                  });
                  Navigator.of(context).pop();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          Text(
            'Category',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: TrackedItem.categories.map((category) {
              final isSelected = _selectedCategoryFilter == category;
              return FilterChip(
                label: Text(category),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    _selectedCategoryFilter = selected ? category : null;
                  });
                  Navigator.of(context).pop();
                },
                selectedColor: theme.colorScheme.secondary.withOpacity(0.2),
                checkmarkColor: theme.colorScheme.secondary,
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          Text(
            'Location',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: TrackedItem.locations.map((location) {
              final isSelected = _selectedLocationFilter == location;
              return FilterChip(
                label: Text(location),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    _selectedLocationFilter = selected ? location : null;
                  });
                  Navigator.of(context).pop();
                },
                selectedColor: theme.colorScheme.tertiary.withOpacity(0.2),
                checkmarkColor: theme.colorScheme.tertiary,
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _selectedMemberFilter = null;
                  _selectedCategoryFilter = null;
                  _selectedLocationFilter = null;
                });
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.surface,
                foregroundColor: theme.colorScheme.primary,
                side: BorderSide(color: theme.colorScheme.primary),
              ),
              child: const Text('Clear Filters'),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom),
        ],
      ),
    );
  }

  void _showItemDetails(TrackedItem item, FamilyMember? member) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(item.name),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item.description.isNotEmpty) ...[
              Text(item.description),
              const SizedBox(height: 16),
            ],
            Row(
              children: [
                const Icon(Icons.location_on_rounded, size: 16),
                const SizedBox(width: 8),
                Text(item.currentLocation),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.category_rounded, size: 16),
                const SizedBox(width: 8),
                Text(item.category),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.info_rounded, size: 16),
                const SizedBox(width: 8),
                Text(item.status),
              ],
            ),
            if (member != null) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.person_rounded, size: 16),
                  const SizedBox(width: 8),
                  Text('Borrowed by \${member.name}'),
                ],
              ),
            ],
            if (item.borrowedAt != null) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.schedule_rounded, size: 16),
                  const SizedBox(width: 8),
                  Text('Since \${DateFormat(\'MMM d, yyyy\').format(item.borrowedAt!)}'),
                ],
              ),
            ],
          ],
        ),
        actions: [
          if (item.status == 'Borrowed' && member != null)
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _returnItem(item);
              },
              child: const Text('Return Item'),
            ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _editItem(item);
            },
            child: const Text('Edit'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _returnItem(TrackedItem item) async {
    try {
      final dataService = Provider.of<DataService>(context, listen: false);
      final updatedItem = item.copyWith(
        status: 'Available',
        borrowedByMemberId: null,
        borrowedAt: null,
        returnedAt: DateTime.now(),
      );
      await dataService.updateTrackedItem(updatedItem);
      await _loadItems();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('\${item.name} has been returned successfully!'),
            backgroundColor: Theme.of(context).colorScheme.primary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error returning item: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  Future<void> _editItem(TrackedItem item) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => EditItemDialog(
        item: item,
        familyMembers: widget.familyMembers,
      ),
    );
    
    if (result == true) {
      await _loadItems(); // Refresh the items list
    }
  }

  void _showAddItemDialog() {
    showDialog(
      context: context,
      builder: (context) => const QuickAddDialog(type: QuickAddType.item),
    ).then((result) {
      if (result == true) {
        // Refresh the items list
        _loadItems();
      }
    });
  }
}