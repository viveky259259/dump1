import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../theme.dart';
import '../models/family_member.dart';
import '../models/household_task.dart';
import '../services/data_service.dart';
import '../services/firebase_data_sync_service.dart';
import 'package:provider/provider.dart';
import '../widgets/family_member_avatar.dart';
import '../widgets/family_member_chip.dart' as chips;
import '../widgets/quick_add_dialog.dart';

class TasksPage extends StatefulWidget {
  final List<FamilyMember> familyMembers;

  const TasksPage({
    super.key,
    required this.familyMembers,
  });

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage>
    with TickerProviderStateMixin {
  List<HouseholdTask> _allTasks = [];
  String? _selectedMemberFilter;
  String? _selectedCategoryFilter;
  String _selectedStatusFilter = 'All';
  bool _isLoading = true;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadTasks();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadTasks() async {
    setState(() => _isLoading = true);
    
    try {
      final dataService = Provider.of<DataService>(context, listen: false);
      final tasks = dataService.householdTasks;
      setState(() {
        _allTasks = tasks;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading tasks: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  List<HouseholdTask> _getFilteredTasks() {
    return _allTasks.where((task) {
      bool matchesMember = _selectedMemberFilter == null || 
                          task.assignedMemberId == _selectedMemberFilter;
      bool matchesCategory = _selectedCategoryFilter == null || 
                            task.category == _selectedCategoryFilter;
      
      bool matchesStatus = true;
      switch (_selectedStatusFilter) {
        case 'Pending':
          matchesStatus = !task.isCompleted;
          break;
        case 'Completed':
          matchesStatus = task.isCompleted;
          break;
        case 'Overdue':
          matchesStatus = task.isOverdue;
          break;
        case 'All':
        default:
          matchesStatus = true;
          break;
      }
      
      return matchesMember && matchesCategory && matchesStatus;
    }).toList();
  }

  List<HouseholdTask> _getTasksByStatus(String status) {
    switch (status) {
      case 'Pending':
        return _allTasks.where((t) => !t.isCompleted && !t.isOverdue).toList();
      case 'Overdue':
        return _allTasks.where((t) => t.isOverdue).toList();
      case 'Completed':
        return _allTasks.where((t) => t.isCompleted).toList();
      case 'All':
      default:
        return _allTasks;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer2<DataService, FirebaseDataSyncService>(
      builder: (context, dataService, syncService, child) {
        // Use Firebase sync service data if available, otherwise fall back to data service
        final tasks = syncService.isInitialized ? syncService.householdTasks : dataService.householdTasks;
        
        // Update tasks when data changes
        if (_allTasks != tasks) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              setState(() {
                _allTasks = tasks;
              });
            }
          });
        }

        return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight + 48),
        child: AppBar(
          title: Text(
            'Family Tasks',
            style: theme.textTheme.headlineSmall?.copyWith(
              color: theme.colorScheme.onSurface,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: theme.colorScheme.surface,
          foregroundColor: theme.colorScheme.onSurface,
          elevation: 0,
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              onPressed: _showFilters,
              icon: Icon(
                Icons.filter_list_rounded,
                color: theme.colorScheme.primary,
              ),
              tooltip: 'Filter Tasks',
            ),
            IconButton(
              onPressed: _showAddTaskDialog,
              icon: Icon(
                Icons.add_rounded,
                color: theme.colorScheme.primary,
              ),
              tooltip: 'Add Task',
            ),
            const SizedBox(width: 8),
          ],
          bottom: TabBar(
            controller: _tabController,
            labelColor: theme.colorScheme.primary,
            unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.6),
            indicatorColor: theme.colorScheme.primary,
            isScrollable: true,
            labelStyle: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            tabs: [
              Tab(
                text: 'All (${_getTasksByStatus('All').length})',
              ),
              Tab(
                text: 'Pending (${_getTasksByStatus('Pending').length})',
              ),
              Tab(
                text: 'Overdue (${_getTasksByStatus('Overdue').length})',
              ),
              Tab(
                text: 'Done (${_getTasksByStatus('Completed').length})',
              ),
            ],
          ),
        ),
      ),
      body: (_isLoading || syncService.isLoading)
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async {
                await _loadTasks();
                if (syncService.isInitialized) {
                  await syncService.initialize();
                }
              },
              child: Column(
                children: [
                  if (_selectedMemberFilter != null || _selectedCategoryFilter != null)
                    _buildActiveFilters(),
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        _buildTasksList(_getTasksByStatus('All')),
                        _buildTasksList(_getTasksByStatus('Pending')),
                        _buildTasksList(_getTasksByStatus('Overdue')),
                        _buildTasksList(_getTasksByStatus('Completed')),
                      ],
                    ),
                  ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTaskDialog,
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: theme.colorScheme.onPrimary,
        child: const Icon(Icons.add_rounded),
      ),
        );
      },
    );
  }

  Widget _buildActiveFilters() {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        children: [
          if (_selectedMemberFilter != null) ...[
            _buildFilterChip(
              label: widget.familyMembers
                  .firstWhere((m) => m.id == _selectedMemberFilter)
                  .name,
              color: widget.familyMembers
                  .firstWhere((m) => m.id == _selectedMemberFilter)
                  .color,
              onRemove: () => setState(() => _selectedMemberFilter = null),
            ),
            const SizedBox(width: 8),
          ],
          if (_selectedCategoryFilter != null) ...[
            _buildFilterChip(
              label: _selectedCategoryFilter!,
              color: theme.colorScheme.secondary,
              onRemove: () => setState(() => _selectedCategoryFilter = null),
            ),
            const SizedBox(width: 8),
          ],
          TextButton(
            onPressed: () {
              setState(() {
                _selectedMemberFilter = null;
                _selectedCategoryFilter = null;
              });
            },
            child: Text(
              'Clear All',
              style: theme.textTheme.labelMedium?.copyWith(
                color: theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required Color color,
    required VoidCallback onRemove,
  }) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onRemove,
            child: Icon(
              Icons.close_rounded,
              size: 16,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTasksList(List<HouseholdTask> tasks) {
    final theme = Theme.of(context);
    final filteredTasks = tasks.where((task) {
      bool matchesMember = _selectedMemberFilter == null || 
                          task.assignedMemberId == _selectedMemberFilter;
      bool matchesCategory = _selectedCategoryFilter == null || 
                            task.category == _selectedCategoryFilter;
      return matchesMember && matchesCategory;
    }).toList();

    if (filteredTasks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.task_alt_rounded,
              size: 64,
              color: theme.colorScheme.onSurface.withOpacity(0.3),
            ),
            const SizedBox(height: 16),
            Text(
              'No tasks found',
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Create a new task or adjust your filters',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.5),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    // Group tasks by member
    final groupedTasks = <String, List<HouseholdTask>>{};
    for (final task in filteredTasks) {
      groupedTasks.putIfAbsent(task.assignedMemberId, () => []).add(task);
    }

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: groupedTasks.length,
      itemBuilder: (context, index) {
        final memberId = groupedTasks.keys.elementAt(index);
        final memberTasks = groupedTasks[memberId]!;
        final member = widget.familyMembers.firstWhere(
          (m) => m.id == memberId,
          orElse: () => widget.familyMembers.first,
        );

        memberTasks.sort((a, b) {
          // Sort by completion status first, then by due date
          if (a.isCompleted != b.isCompleted) {
            return a.isCompleted ? 1 : -1;
          }
          return a.dueDate.compareTo(b.dueDate);
        });

        return _buildMemberTaskGroup(member, memberTasks);
      },
    );
  }

  Widget _buildMemberTaskGroup(FamilyMember member, List<HouseholdTask> tasks) {
    final theme = Theme.of(context);
    final completedCount = tasks.where((t) => t.isCompleted).length;
    final totalCount = tasks.length;

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.outline.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: member.color.withOpacity(0.05),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              children: [
                FamilyMemberAvatar(
                  member: member,
                  size: 40,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        member.name,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '\$completedCount of \$totalCount tasks completed',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: member.color,
                        ),
                      ),
                    ],
                  ),
                ),
                if (totalCount > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: member.color.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '\${((completedCount / totalCount) * 100).round()}%',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: member.color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          ...tasks.asMap().entries.map((entry) {
            final index = entry.key;
            final task = entry.value;
            final isLast = index == tasks.length - 1;
            
            return _buildTaskCard(task, member, isLast);
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildTaskCard(HouseholdTask task, FamilyMember member, bool isLast) {
    final theme = Theme.of(context);
    final isOverdue = task.isOverdue;
    final timeUntilDue = task.dueDate.difference(DateTime.now());
    final daysUntilDue = timeUntilDue.inDays;

    String dueDateText;
    if (task.isCompleted) {
      dueDateText = 'Completed';
    } else if (isOverdue) {
      dueDateText = 'Overdue';
    } else if (daysUntilDue == 0) {
      dueDateText = 'Due today';
    } else if (daysUntilDue == 1) {
      dueDateText = 'Due tomorrow';
    } else {
      dueDateText = 'Due in \${daysUntilDue}d';
    }

    return Container(
      margin: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: isLast ? 16 : 8,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showTaskDetails(task, member),
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: task.isCompleted
                  ? theme.colorScheme.surface
                  : (isOverdue
                      ? theme.colorScheme.error.withOpacity(0.05)
                      : Colors.transparent),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: task.isCompleted
                    ? theme.colorScheme.outline.withOpacity(0.2)
                    : (isOverdue
                        ? theme.colorScheme.error.withOpacity(0.3)
                        : member.color.withOpacity(0.2)),
              ),
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => _toggleTaskCompletion(task, member),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: task.isCompleted
                          ? member.color
                          : Colors.transparent,
                      border: Border.all(
                        color: task.isCompleted
                            ? member.color
                            : theme.colorScheme.outline,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: task.isCompleted
                        ? Icon(
                            Icons.check_rounded,
                            size: 16,
                            color: theme.colorScheme.onPrimary,
                          )
                        : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        task.title,
                        style: theme.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: task.isCompleted
                              ? theme.colorScheme.onSurface.withOpacity(0.6)
                              : theme.colorScheme.onSurface,
                          decoration: task.isCompleted
                              ? TextDecoration.lineThrough
                              : null,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: member.color.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              task.category,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: member.color,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: _getPriorityColor(task.priority, theme).withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              task.priority,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: _getPriorityColor(task.priority, theme),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (task.description.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          task.description,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withOpacity(0.6),
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      dueDateText,
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: task.isCompleted
                            ? theme.colorScheme.onSurface.withOpacity(0.6)
                            : (isOverdue
                                ? theme.colorScheme.error
                                : member.color),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      DateFormat('MMM d, yyyy').format(task.dueDate),
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurface.withOpacity(0.5),
                      ),
                    ),
                    if (task.dueDate.hour != 0 || task.dueDate.minute != 0) ...[
                      const SizedBox(height: 1),
                      Text(
                        DateFormat('h:mm a').format(task.dueDate),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurface.withOpacity(0.4),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getPriorityColor(String priority, ThemeData theme) {
    switch (priority.toLowerCase()) {
      case 'urgent':
        return theme.colorScheme.error;
      case 'high':
        return theme.colorScheme.tertiary;
      case 'medium':
        return theme.colorScheme.secondary;
      case 'low':
      default:
        return theme.colorScheme.onSurface.withOpacity(0.6);
    }
  }

  Future<void> _toggleTaskCompletion(HouseholdTask task, FamilyMember member) async {
    final updatedTask = task.copyWith(
      isCompleted: !task.isCompleted,
      completedAt: !task.isCompleted ? DateTime.now() : null,
      completedByMemberId: !task.isCompleted ? member.id : null,
    );

    try {
      final syncService = Provider.of<FirebaseDataSyncService>(context, listen: false);
      final dataService = Provider.of<DataService>(context, listen: false);
      
      // Try Firebase sync service first, fall back to data service
      if (syncService.isInitialized) {
        await syncService.updateHouseholdTask(updatedTask);
      } else {
        await dataService.updateHouseholdTask(updatedTask);
        await _loadTasks();
      }
      
      if (mounted) {
        final theme = Theme.of(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              task.isCompleted 
                  ? 'Task marked as incomplete' 
                  : 'Task completed! Great job! 🎉',
            ),
            backgroundColor: task.isCompleted 
                ? theme.colorScheme.secondary
                : theme.colorScheme.primary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating task: \$e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  void _showFilters() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _buildFiltersSheet(),
    );
  }

  Widget _buildFiltersSheet() {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Filter Tasks',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            'Family Member',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: widget.familyMembers.map((member) {
              final isSelected = _selectedMemberFilter == member.id;
              return chips.FamilyMemberChip(
                member: member,
                isSelected: isSelected,
                onTap: () {
                  setState(() {
                    _selectedMemberFilter = isSelected ? null : member.id;
                  });
                  Navigator.of(context).pop();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          Text(
            'Category',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: HouseholdTask.categories.map((category) {
              final isSelected = _selectedCategoryFilter == category;
              return FilterChip(
                label: Text(category),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    _selectedCategoryFilter = selected ? category : null;
                  });
                  Navigator.of(context).pop();
                },
                selectedColor: theme.colorScheme.secondary.withOpacity(0.2),
                checkmarkColor: theme.colorScheme.secondary,
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _selectedMemberFilter = null;
                  _selectedCategoryFilter = null;
                });
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.surface,
                foregroundColor: theme.colorScheme.primary,
                side: BorderSide(color: theme.colorScheme.primary),
              ),
              child: const Text('Clear Filters'),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom),
        ],
      ),
    );
  }

  void _showTaskDetails(HouseholdTask task, FamilyMember member) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(task.title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (task.description.isNotEmpty) ...[
              Text(task.description),
              const SizedBox(height: 16),
            ],
            Row(
              children: [
                const Icon(Icons.person_rounded, size: 16),
                const SizedBox(width: 8),
                Text(member.name),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.category_rounded, size: 16),
                const SizedBox(width: 8),
                Text(task.category),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.priority_high_rounded, size: 16),
                const SizedBox(width: 8),
                Text(task.priority),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.schedule_rounded, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Due: ${DateFormat('MMM d, yyyy').format(task.dueDate)}',
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                      if (task.dueDate.hour != 0 || task.dueDate.minute != 0)
                        Text(
                          'at ${DateFormat('h:mm a').format(task.dueDate)}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            if (task.isCompleted && task.completedAt != null) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.check_circle_rounded, size: 16),
                  const SizedBox(width: 8),
                  Text('Completed on \${DateFormat(\'MMM d, yyyy\').format(task.completedAt!)}'),
                ],
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showAddTaskDialog() {
    showDialog(
      context: context,
      builder: (context) => const QuickAddDialog(type: QuickAddType.task),
    ).then((result) {
      if (result == true) {
        // Refresh the tasks list
        _loadTasks();
      }
    });
  }
}