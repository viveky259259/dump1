import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../models/family_member.dart';
import '../models/calendar_event.dart';
import '../models/household_task.dart';
import '../models/item_tracker.dart';
import '../services/data_service.dart';
import '../services/auth_service.dart';
import '../services/navigation_service.dart';
import '../services/firebase_data_sync_service.dart';
import '../widgets/family_member_avatar.dart';
import 'calendar_page.dart';
import 'tasks_page.dart';
import 'items_page.dart';
import 'emergency_page.dart';
import '../widgets/quick_add_fab.dart';
import '../widgets/family_selector.dart';
import '../widgets/quick_add_dialog.dart';
import 'debug/family_sync_debug_page.dart';
import 'settings/family_management_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  int _currentIndex = 0;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    
    // Listen to tab changes and synchronize the current index
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() {
          _currentIndex = _tabController.index;
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Sign Out'),
          content: const Text(
            'Are you sure you want to sign out? Your login details will be cleared and you\'ll need to sign in again next time.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                // Show loading indicator
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => const Center(
                    child: CircularProgressIndicator(),
                  ),
                );
                
                try {
                  await AuthService.instance.signOut();
                  // Navigate to login page
                  if (context.mounted) {
                    Navigator.of(context).pop(); // Close loading dialog
                    Navigator.of(context).pushReplacementNamed('/login');
                  }
                } catch (e) {
                  if (context.mounted) {
                    Navigator.of(context).pop(); // Close loading dialog
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Error signing out: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              },
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
              ),
              child: const Text('Sign Out'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer3<DataService, NavigationService, FirebaseDataSyncService>(
      builder: (context, dataService, navigationService, syncService, child) {
        // Sync tab controller with navigation service
        if (_tabController.index != navigationService.currentMainTab) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && _tabController.index != navigationService.currentMainTab) {
              _tabController.animateTo(navigationService.currentMainTab);
            }
          });
        }

        return Scaffold(
          backgroundColor: theme.colorScheme.surface,
          body: TabBarView(
            controller: _tabController,
            children: [
              _buildDashboard(),
              CalendarPage(familyMembers: syncService.isInitialized ? syncService.familyMembers : dataService.familyMembers),
              TasksPage(familyMembers: syncService.isInitialized ? syncService.familyMembers : dataService.familyMembers),
              ItemsPage(familyMembers: syncService.isInitialized ? syncService.familyMembers : dataService.familyMembers),
            ],
          ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          boxShadow: [
            BoxShadow(
              color: theme.colorScheme.outline.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: TabBar(
          controller: _tabController,
          labelColor: theme.colorScheme.primary,
          unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.6),
          indicatorColor: Colors.transparent,
          labelStyle: theme.textTheme.labelSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: theme.textTheme.labelSmall,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
            // Update navigation service
            NavigationService.instance.setMainTab(index);
          },
          tabs: [
            Tab(
              icon: Icon(Icons.home_rounded),
              text: 'Home',
            ),
            Tab(
              icon: Icon(Icons.calendar_month_rounded),
              text: 'Calendar',
            ),
            Tab(
              icon: Icon(Icons.task_alt_rounded),
              text: 'Tasks',
            ),
            Tab(
              icon: Icon(Icons.inventory_2_rounded),
              text: 'Items',
            ),
          ],
        ),
      ),
          floatingActionButton: const QuickAddFAB(useBottomSheet: true),
        );
      },
    );
  }

  Widget _buildDashboard() {
    final theme = Theme.of(context);

    return Consumer2<DataService, FirebaseDataSyncService>(
      builder: (context, dataService, syncService, child) {
        // Use Firebase sync service data if available, otherwise fall back to data service
        final familyMembers = syncService.isInitialized ? syncService.familyMembers : dataService.familyMembers;
        final events = syncService.isInitialized ? syncService.calendarEvents : dataService.calendarEvents;
        final tasks = syncService.isInitialized ? syncService.householdTasks : dataService.householdTasks;
        final items = syncService.isInitialized ? syncService.trackedItems : dataService.trackedItems;

        final now = DateTime.now();
        final recentEvents = events
            .where((e) => e.date.isAfter(now))
            .toList()
          ..sort((a, b) => a.date.compareTo(b.date));
        final upcomingEvents = recentEvents.take(3).toList();

        final pendingTasks = tasks
            .where((t) => !t.isCompleted)
            .toList()
          ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
        final limitedPendingTasks = pendingTasks.take(5).toList();

        final borrowedItems = items
            .where((i) => i.isBorrowed)
            .toList();

        if (dataService.isLoading || syncService.isLoading) {
          return Scaffold(
            backgroundColor: theme.colorScheme.surface,
            body: const Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        return Scaffold(
          backgroundColor: theme.colorScheme.surface,
          body: RefreshIndicator(
            onRefresh: () async {
              await dataService.refresh();
              if (syncService.isInitialized) {
                await syncService.initialize();
              }
            },
            child: CustomScrollView(
              slivers: [
          SliverAppBar(
            expandedHeight: 120,
            floating: true,
            pinned: true,
            backgroundColor: theme.colorScheme.surface,
            foregroundColor: theme.colorScheme.onSurface,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Family Hub',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: theme.colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                ),
              ),
              titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
            ),
            actions: [
              IconButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => EmergencyPage(familyMembers: familyMembers),
                  ),
                ),
                icon: Icon(
                  Icons.emergency_rounded,
                  color: theme.colorScheme.error,
                ),
                tooltip: 'Emergency Contacts',
              ),
              PopupMenuButton<String>(
                icon: Icon(
                  Icons.account_circle,
                  color: theme.colorScheme.onSurface,
                ),
                tooltip: 'Account Options',
                onSelected: (value) async {
                  if (value == 'logout') {
                    _showLogoutDialog(context);
                  } else if (value == 'debug') {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const FamilySyncDebugPage(),
                      ),
                    );
                  } else if (value == 'family_management') {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const FamilyManagementPage(),
                      ),
                    );
                  }
                },
                itemBuilder: (BuildContext context) => [
                  PopupMenuItem<String>(
                    value: 'family_management',
                    child: Row(
                      children: [
                        Icon(
                          Icons.family_restroom,
                          color: theme.colorScheme.onSurface,
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        const Text('Manage Families'),
                      ],
                    ),
                  ),
                  PopupMenuItem<String>(
                    value: 'debug',
                    child: Row(
                      children: [
                        Icon(
                          Icons.bug_report,
                          color: theme.colorScheme.primary,
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'Debug Family Sync',
                          style: TextStyle(
                            color: theme.colorScheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  PopupMenuItem<String>(
                    value: 'logout',
                    child: Row(
                      children: [
                        Icon(
                          Icons.logout,
                          color: theme.colorScheme.error,
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'Sign Out',
                          style: TextStyle(
                            color: theme.colorScheme.error,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 8),
            ],
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                const FamilySelector(),
                const SizedBox(height: 16),
                _buildFamilyMembersSection(familyMembers),
                const SizedBox(height: 24),
                _buildQuickActionsSection(),
                const SizedBox(height: 24),
                _buildUpcomingEventsSection(upcomingEvents, familyMembers),
                const SizedBox(height: 24),
                _buildPendingTasksSection(limitedPendingTasks, familyMembers),
                const SizedBox(height: 24),
                _buildBorrowedItemsSection(borrowedItems, familyMembers),
                const SizedBox(height: 100), // Extra space for FAB
              ]),
            ),
          ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildFamilyMembersSection(List<FamilyMember> familyMembers) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.primary.withOpacity(0.1),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.family_restroom_rounded,
                color: theme.colorScheme.primary,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Family Members',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 12,
            children: familyMembers.map((member) {
              return FamilyMemberAvatar(
                member: member,
                size: 50,
                showName: true,
                showRole: true,
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildUpcomingEventsSection(List<CalendarEvent> upcomingEvents, List<FamilyMember> familyMembers) {
    final theme = Theme.of(context);

    return _buildDashboardSection(
      title: 'Upcoming Events',
      icon: Icons.event_rounded,
      color: theme.colorScheme.secondary,
      itemCount: upcomingEvents.length,
      emptyMessage: 'No upcoming events',
      onViewAll: () => _tabController.animateTo(1),
      children: upcomingEvents.map((event) {
        final member = familyMembers.isNotEmpty 
          ? familyMembers.firstWhere(
              (m) => m.id == event.assignedMemberId,
              orElse: () => familyMembers.first,
            )
          : null;

        return member != null ? _buildEventCard(event, member) : const SizedBox.shrink();
      }).toList(),
    );
  }

  Widget _buildPendingTasksSection(List<HouseholdTask> pendingTasks, List<FamilyMember> familyMembers) {
    final theme = Theme.of(context);

    return _buildDashboardSection(
      title: 'Pending Tasks',
      icon: Icons.task_rounded,
      color: theme.colorScheme.tertiary,
      itemCount: pendingTasks.length,
      emptyMessage: 'No pending tasks',
      onViewAll: () => _tabController.animateTo(2),
      children: pendingTasks.map((task) {
        final member = familyMembers.isNotEmpty 
          ? familyMembers.firstWhere(
              (m) => m.id == task.assignedMemberId,
              orElse: () => familyMembers.first,
            )
          : null;

        return member != null ? _buildTaskCard(task, member) : const SizedBox.shrink();
      }).toList(),
    );
  }

  Widget _buildBorrowedItemsSection(List<TrackedItem> borrowedItems, List<FamilyMember> familyMembers) {
    final theme = Theme.of(context);

    return _buildDashboardSection(
      title: 'Currently Borrowed',
      icon: Icons.swap_horiz_rounded,
      color: theme.colorScheme.primary,
      itemCount: borrowedItems.length,
      emptyMessage: 'No items currently borrowed',
      onViewAll: () => _tabController.animateTo(3),
      children: borrowedItems.map((item) {
        final member = familyMembers.isNotEmpty 
          ? familyMembers.firstWhere(
              (m) => m.id == item.borrowedByMemberId,
              orElse: () => familyMembers.first,
            )
          : null;

        return member != null ? _buildItemCard(item, member) : const SizedBox.shrink();
      }).toList(),
    );
  }

  Widget _buildDashboardSection({
    required String title,
    required IconData icon,
    required Color color,
    required int itemCount,
    required String emptyMessage,
    required VoidCallback onViewAll,
    required List<Widget> children,
  }) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.outline.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    icon,
                    color: color,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: theme.colorScheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (itemCount > 0)
                  TextButton(
                    onPressed: onViewAll,
                    child: Text(
                      'View All',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: color,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (itemCount == 0)
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Text(
                emptyMessage,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
            )
          else
            ...children,
        ],
      ),
    );
  }

  Widget _buildEventCard(CalendarEvent event, FamilyMember member) {
    final theme = Theme.of(context);
    final timeLeft = event.date.difference(DateTime.now());
    final daysLeft = timeLeft.inDays;

    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: member.color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: member.color.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          FamilyMemberAvatar(
            member: member,
            size: 32,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  event.category,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: member.color,
                  ),
                ),
              ],
            ),
          ),
          Text(
            daysLeft == 0 ? 'Today' : daysLeft == 1 ? 'Tomorrow' : '\${daysLeft}d',
            style: theme.textTheme.labelMedium?.copyWith(
              color: member.color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskCard(HouseholdTask task, FamilyMember member) {
    final theme = Theme.of(context);
    final isOverdue = task.isOverdue;

    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isOverdue
            ? theme.colorScheme.error.withOpacity(0.05)
            : member.color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isOverdue
              ? theme.colorScheme.error.withOpacity(0.2)
              : member.color.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          FamilyMemberAvatar(
            member: member,
            size: 32,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  task.title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  task.category,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isOverdue ? theme.colorScheme.error : member.color,
                  ),
                ),
              ],
            ),
          ),
          if (isOverdue)
            Icon(
              Icons.warning_rounded,
              color: theme.colorScheme.error,
              size: 20,
            ),
        ],
      ),
    );
  }

  Widget _buildItemCard(TrackedItem item, FamilyMember member) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: member.color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: member.color.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          FamilyMemberAvatar(
            member: member,
            size: 32,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: theme.colorScheme.onSurface,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  item.currentLocation,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: member.color,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.location_on_rounded,
            color: member.color,
            size: 16,
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.5),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.flash_on_rounded,
                color: theme.colorScheme.primary,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Quick Actions',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.event_outlined,
                  title: 'Add Event',
                  subtitle: 'Plan something',
                  color: Colors.blue,
                  onTap: () => _showQuickAddDialog(QuickAddType.event),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.task_alt_outlined,
                  title: 'Add Task',
                  subtitle: 'Get it done',
                  color: Colors.green,
                  onTap: () => _showQuickAddDialog(QuickAddType.task),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildQuickActionCard(
                  icon: Icons.inventory_2_outlined,
                  title: 'Add Item',
                  subtitle: 'Track it',
                  color: Colors.orange,
                  onTap: () => _showQuickAddDialog(QuickAddType.item),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 18,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.onSurface,
              ),
              textAlign: TextAlign.center,
            ),
            Text(
              subtitle,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _showQuickAddDialog(QuickAddType type) {
    showDialog(
      context: context,
      builder: (context) => QuickAddDialog(type: type),
    ).then((result) {
      if (result == true) {
        // Refresh data after successful addition
        Provider.of<DataService>(context, listen: false).refresh();
      }
    });
  }


}