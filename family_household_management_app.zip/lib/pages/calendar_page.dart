import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import '../theme.dart';
import '../models/family_member.dart';
import '../models/calendar_event.dart';
import '../services/data_service.dart';
import '../services/firebase_data_sync_service.dart';
import 'package:provider/provider.dart';
import '../widgets/family_member_avatar.dart';
import '../widgets/quick_add_dialog.dart';

class CalendarPage extends StatefulWidget {
  final List<FamilyMember> familyMembers;

  const CalendarPage({
    super.key,
    required this.familyMembers,
  });

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage>
    with TickerProviderStateMixin {
  late final ValueNotifier<List<CalendarEvent>> _selectedEvents;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  List<CalendarEvent> _allEvents = [];
  String? _selectedMemberFilter;
  String? _selectedCategoryFilter;
  bool _isLoading = true;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _selectedDay = DateTime.now();
    _selectedEvents = ValueNotifier(_getEventsForDay(_selectedDay!));
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _loadEvents();
  }

  @override
  void dispose() {
    _selectedEvents.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadEvents() async {
    setState(() => _isLoading = true);

    try {
      final syncService =
          Provider.of<FirebaseDataSyncService>(context, listen: false);
      final dataService = Provider.of<DataService>(context, listen: false);

      List<CalendarEvent> events;
      if (syncService.isInitialized) {
        events = syncService.calendarEvents;
      } else {
        events = dataService.calendarEvents;
      }

      setState(() {
        _allEvents = events;
        _selectedEvents.value = _getEventsForDay(_selectedDay!);
        _isLoading = false;
      });
      _animationController.forward();
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading events: $e'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  List<CalendarEvent> _getEventsForDay(DateTime day) {
    return _allEvents.where((event) {
      final eventDate =
          DateTime(event.date.year, event.date.month, event.date.day);
      final checkDate = DateTime(day.year, day.month, day.day);

      bool matchesDate = eventDate == checkDate;
      bool matchesMember = _selectedMemberFilter == null ||
          event.assignedMemberId == _selectedMemberFilter;
      bool matchesCategory = _selectedCategoryFilter == null ||
          event.category == _selectedCategoryFilter;

      return matchesDate && matchesMember && matchesCategory;
    }).toList();
  }

  List<CalendarEvent> _getFilteredEvents() {
    return _allEvents.where((event) {
      bool matchesMember = _selectedMemberFilter == null ||
          event.assignedMemberId == _selectedMemberFilter;
      bool matchesCategory = _selectedCategoryFilter == null ||
          event.category == _selectedCategoryFilter;

      return matchesMember && matchesCategory;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer2<DataService, FirebaseDataSyncService>(
      builder: (context, dataService, syncService, child) {
        // Use Firebase sync service data if available, otherwise fall back to data service
        final events = syncService.isInitialized
            ? syncService.calendarEvents
            : dataService.calendarEvents;

        // Update events when data changes
        if (_allEvents != events) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              setState(() {
                _allEvents = events;
                _selectedEvents.value = _getEventsForDay(_selectedDay!);
              });
            }
          });
        }

        return Scaffold(
          backgroundColor: theme.colorScheme.surface,
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(kToolbarHeight + 48),
            child: AppBar(
              title: Text(
                'Family Calendar',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: theme.colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                ),
              ),
              backgroundColor: theme.colorScheme.surface,
              foregroundColor: theme.colorScheme.onSurface,
              elevation: 0,
              automaticallyImplyLeading: false,
              actions: [
                IconButton(
                  onPressed: _showFilters,
                  icon: Icon(
                    Icons.filter_list_rounded,
                    color: theme.colorScheme.primary,
                  ),
                  tooltip: 'Filter Events',
                ),
                IconButton(
                  onPressed: _showAddEventDialog,
                  icon: Icon(
                    Icons.add_rounded,
                    color: theme.colorScheme.primary,
                  ),
                  tooltip: 'Add Event',
                ),
                const SizedBox(width: 8),
              ],
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(48),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Text(
                        'View: ${DateFormat('MMMM yyyy').format(_focusedDay)}',
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            _focusedDay = DateTime.now();
                            _selectedDay = DateTime.now();
                            _selectedEvents.value =
                                _getEventsForDay(_selectedDay!);
                          });
                        },
                        icon: Icon(
                          Icons.today_rounded,
                          color: theme.colorScheme.primary,
                        ),
                        tooltip: 'Today',
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          body: (_isLoading || syncService.isLoading)
              ? const Center(child: CircularProgressIndicator())
              : Consumer<FirebaseDataSyncService>(
                  builder: (context, syncService, child) {
                    // Update events when Firebase data changes
                    if (syncService.isInitialized &&
                        _allEvents != syncService.calendarEvents) {
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        setState(() {
                          _allEvents = syncService.calendarEvents;
                          _selectedEvents.value =
                              _getEventsForDay(_selectedDay!);
                        });
                      });
                    }

                    return RefreshIndicator(
                      onRefresh: () async {
                        await _loadEvents();
                        if (syncService.isInitialized) {
                          await syncService.initialize();
                        }
                      },
                      child: AnimatedBuilder(
                        animation: _animationController,
                        builder: (context, child) {
                          return FadeTransition(
                            opacity: _animationController,
                            child: Column(
                              children: [
                                if (_selectedMemberFilter != null ||
                                    _selectedCategoryFilter != null)
                                  _buildActiveFilters(),
                                _buildCalendar(),
                                const SizedBox(height: 8),
                                Expanded(
                                  child: _buildEventsList(),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
        );
      },
    );
  }

  Widget _buildActiveFilters() {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        children: [
          if (_selectedMemberFilter != null) ...[
            _buildFilterChip(
              label: widget.familyMembers
                  .firstWhere((m) => m.id == _selectedMemberFilter)
                  .name,
              color: widget.familyMembers
                  .firstWhere((m) => m.id == _selectedMemberFilter)
                  .color,
              onRemove: () {
                setState(() {
                  _selectedMemberFilter = null;
                  _selectedEvents.value = _getEventsForDay(_selectedDay!);
                });
              },
            ),
            const SizedBox(width: 8),
          ],
          if (_selectedCategoryFilter != null) ...[
            _buildFilterChip(
              label: _selectedCategoryFilter!,
              color: theme.colorScheme.secondary,
              onRemove: () {
                setState(() {
                  _selectedCategoryFilter = null;
                  _selectedEvents.value = _getEventsForDay(_selectedDay!);
                });
              },
            ),
            const SizedBox(width: 8),
          ],
          TextButton(
            onPressed: () {
              setState(() {
                _selectedMemberFilter = null;
                _selectedCategoryFilter = null;
                _selectedEvents.value = _getEventsForDay(_selectedDay!);
              });
            },
            child: Text(
              'Clear All',
              style: theme.textTheme.labelMedium?.copyWith(
                color: theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required Color color,
    required VoidCallback onRemove,
  }) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onRemove,
            child: Icon(
              Icons.close_rounded,
              size: 16,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalendar() {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.outline.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: TableCalendar<CalendarEvent>(
        firstDay: DateTime.utc(2020, 1, 1),
        lastDay: DateTime.utc(2030, 12, 31),
        focusedDay: _focusedDay,
        calendarFormat: CalendarFormat.month,
        eventLoader: _getEventsForDay,
        startingDayOfWeek: StartingDayOfWeek.sunday,
        calendarStyle: CalendarStyle(
          outsideDaysVisible: false,
          weekendTextStyle: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface,
              ) ??
              TextStyle(color: theme.colorScheme.onSurface),
          holidayTextStyle: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.error,
              ) ??
              TextStyle(color: theme.colorScheme.error),
          selectedDecoration: BoxDecoration(
            color: theme.colorScheme.primary,
            shape: BoxShape.circle,
          ),
          todayDecoration: BoxDecoration(
            color: theme.colorScheme.primary.withOpacity(0.3),
            shape: BoxShape.circle,
          ),
          markerDecoration: BoxDecoration(
            color: theme.colorScheme.secondary,
            shape: BoxShape.circle,
          ),
          markersMaxCount: 3,
        ),
        headerStyle: HeaderStyle(
          formatButtonVisible: false,
          titleCentered: true,
          titleTextStyle: theme.textTheme.titleLarge?.copyWith(
                color: theme.colorScheme.onSurface,
                fontWeight: FontWeight.bold,
              ) ??
              TextStyle(
                color: theme.colorScheme.onSurface,
                fontWeight: FontWeight.bold,
              ),
          leftChevronIcon: Icon(
            Icons.chevron_left_rounded,
            color: theme.colorScheme.primary,
          ),
          rightChevronIcon: Icon(
            Icons.chevron_right_rounded,
            color: theme.colorScheme.primary,
          ),
        ),
        selectedDayPredicate: (day) {
          return isSameDay(_selectedDay, day);
        },
        onDaySelected: (selectedDay, focusedDay) {
          if (!isSameDay(_selectedDay, selectedDay)) {
            setState(() {
              _selectedDay = selectedDay;
              _focusedDay = focusedDay;
              _selectedEvents.value = _getEventsForDay(selectedDay);
            });
          }
        },
        onPageChanged: (focusedDay) {
          _focusedDay = focusedDay;
        },
      ),
    );
  }

  Widget _buildEventsList() {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: theme.colorScheme.outline.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Icon(
                  Icons.event_rounded,
                  color: theme.colorScheme.primary,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  _selectedDay != null
                      ? 'Events for ${DateFormat("MMM d, yyyy").format(_selectedDay!)}'
                      : 'Select a date',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: theme.colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ValueListenableBuilder<List<CalendarEvent>>(
              valueListenable: _selectedEvents,
              builder: (context, events, _) {
                if (events.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.event_busy_rounded,
                          size: 48,
                          color: theme.colorScheme.onSurface.withOpacity(0.3),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'No events for this day',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.only(bottom: 20),
                  itemCount: events.length,
                  itemBuilder: (context, index) {
                    final event = events[index];
                    final member = widget.familyMembers.firstWhere(
                      (m) => m.id == event.assignedMemberId,
                      orElse: () => widget.familyMembers.first,
                    );

                    return _buildEventCard(event, member);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventCard(CalendarEvent event, FamilyMember member) {
    final theme = Theme.of(context);
    final timeFormat = DateFormat('h:mm a');

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showEventDetails(event, member),
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: member.color.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: member.color.withOpacity(0.2),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 4,
                  height: 40,
                  decoration: BoxDecoration(
                    color: member.color,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        event.title,
                        style: theme.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.onSurface,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: member.color.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              event.category,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: member.color,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            timeFormat.format(event.date),
                            style: theme.textTheme.bodySmall?.copyWith(
                              color:
                                  theme.colorScheme.onSurface.withOpacity(0.6),
                            ),
                          ),
                        ],
                      ),
                      if (event.description.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          event.description,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withOpacity(0.8),
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                FamilyMemberAvatar(
                  member: member,
                  size: 32,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showFilters() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => _buildFiltersSheet(),
    );
  }

  Widget _buildFiltersSheet() {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Filter Events',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            'Family Member',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: widget.familyMembers.map((member) {
              final isSelected = _selectedMemberFilter == member.id;
              return FamilyMemberChip(
                member: member,
                isSelected: isSelected,
                onTap: () {
                  setState(() {
                    _selectedMemberFilter = isSelected ? null : member.id;
                    _selectedEvents.value = _getEventsForDay(_selectedDay!);
                  });
                  Navigator.of(context).pop();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 24),
          Text(
            'Category',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: CalendarEvent.categories.map((category) {
              final isSelected = _selectedCategoryFilter == category;
              return FilterChip(
                label: Text(category),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    _selectedCategoryFilter = selected ? category : null;
                    _selectedEvents.value = _getEventsForDay(_selectedDay!);
                  });
                  Navigator.of(context).pop();
                },
                selectedColor: theme.colorScheme.secondary.withOpacity(0.2),
                checkmarkColor: theme.colorScheme.secondary,
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _selectedMemberFilter = null;
                  _selectedCategoryFilter = null;
                  _selectedEvents.value = _getEventsForDay(_selectedDay!);
                });
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.surface,
                foregroundColor: theme.colorScheme.primary,
                side: BorderSide(color: theme.colorScheme.primary),
              ),
              child: const Text('Clear Filters'),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom),
        ],
      ),
    );
  }

  void _showEventDetails(CalendarEvent event, FamilyMember member) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(event.title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (event.description.isNotEmpty) ...[
              Text(event.description),
              const SizedBox(height: 16),
            ],
            Row(
              children: [
                const Icon(Icons.person_rounded, size: 16),
                const SizedBox(width: 8),
                Text(member.name),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.category_rounded, size: 16),
                const SizedBox(width: 8),
                Text(event.category),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.schedule_rounded, size: 16),
                const SizedBox(width: 8),
                Text(
                    DateFormat('MMM d, yyyy \'at\' h:mm a').format(event.date)),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showAddEventDialog() {
    showDialog(
      context: context,
      builder: (context) => const QuickAddDialog(type: QuickAddType.event),
    ).then((result) {
      if (result == true) {
        // Refresh the events list
        _loadEvents();
      }
    });
  }
}
