import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';

class CalendarEvent {
  final String? id;
  final String title;
  final String description;
  final DateTime date;
  final String assignedMemberId;
  final String category;
  final bool hasReminder;
  final DateTime? reminderTime;
  final bool isCompleted;
  final DateTime createdAt;

  const CalendarEvent({
    this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.assignedMemberId,
    required this.category,
    this.hasReminder = false,
    this.reminderTime,
    this.isCompleted = false,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'date': date.toIso8601String(),
        'assignedMemberId': assignedMemberId,
        'category': category,
        'hasReminder': hasReminder,
        'reminderTime': reminderTime?.toIso8601String(),
        'isCompleted': isCompleted,
        'createdAt': createdAt.toIso8601String(),
      };

  factory CalendarEvent.fromJson(Map<String, dynamic> json) => CalendarEvent(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        date: DateTime.parse(json['date']),
        assignedMemberId: json['assignedMemberId'],
        category: json['category'],
        hasReminder: json['hasReminder'] ?? false,
        reminderTime: json['reminderTime'] != null
            ? DateTime.parse(json['reminderTime'])
            : null,
        isCompleted: json['isCompleted'] ?? false,
        createdAt: DateTime.parse(json['createdAt']),
      );

  // Firebase conversion methods
  Map<String, dynamic> toFirestore() => {
        'title': title,
        'description': description,
        'date': Timestamp.fromDate(date),
        'assignedMemberId': assignedMemberId,
        'category': category,
        'hasReminder': hasReminder,
        'reminderTime': reminderTime != null ? Timestamp.fromDate(reminderTime!) : null,
        'isCompleted': isCompleted,
      };

  factory CalendarEvent.fromFirestore(String docId, Map<String, dynamic> data) {
    final dateTimestamp = data['date'] as Timestamp?;
    final reminderTimestamp = data['reminderTime'] as Timestamp?;
    final createdAtTimestamp = data['createdAt'] as Timestamp?;
    
    return CalendarEvent(
      id: docId,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      date: dateTimestamp?.toDate() ?? DateTime.now(),
      assignedMemberId: data['assignedMemberId'] ?? '',
      category: data['category'] ?? 'Other',
      hasReminder: data['hasReminder'] ?? false,
      reminderTime: reminderTimestamp?.toDate(),
      isCompleted: data['isCompleted'] ?? false,
      createdAt: createdAtTimestamp?.toDate() ?? DateTime.now(),
    );
  }

  CalendarEvent copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? date,
    String? assignedMemberId,
    String? category,
    bool? hasReminder,
    DateTime? reminderTime,
    bool? isCompleted,
    DateTime? createdAt,
  }) =>
      CalendarEvent(
        id: id ?? this.id,
        title: title ?? this.title,
        description: description ?? this.description,
        date: date ?? this.date,
        assignedMemberId: assignedMemberId ?? this.assignedMemberId,
        category: category ?? this.category,
        hasReminder: hasReminder ?? this.hasReminder,
        reminderTime: reminderTime ?? this.reminderTime,
        isCompleted: isCompleted ?? this.isCompleted,
        createdAt: createdAt ?? this.createdAt,
      );

  static List<String> get categories => [
        'Birthday',
        'Anniversary',
        'Appointment',
        'School Event',
        'Family Activity',
        'Work',
        'Personal',
        'Holiday',
        'Reminder',
        'Other',
      ];

  static List<CalendarEvent> getSampleEvents() {
    final now = DateTime.now();
    return [
      CalendarEvent(
        id: '1',
        title: 'Emma\'s Soccer Practice',
        description: 'Weekly soccer practice at community center',
        date: now.add(const Duration(days: 1)),
        assignedMemberId: '3',
        category: 'School Event',
        hasReminder: true,
        reminderTime: now.add(const Duration(days: 1)).subtract(const Duration(hours: 1)),
        createdAt: now.subtract(const Duration(days: 5)),
      ),
      CalendarEvent(
        id: '2',
        title: 'Family Movie Night',
        description: 'Weekly family bonding time',
        date: now.add(const Duration(days: 2)),
        assignedMemberId: '1',
        category: 'Family Activity',
        hasReminder: true,
        reminderTime: now.add(const Duration(days: 2)).subtract(const Duration(hours: 2)),
        createdAt: now.subtract(const Duration(days: 7)),
      ),
      CalendarEvent(
        id: '3',
        title: 'Jake\'s Birthday Party',
        description: 'Celebrating Jake\'s 12th birthday with friends',
        date: now.add(const Duration(days: 5)),
        assignedMemberId: '4',
        category: 'Birthday',
        hasReminder: true,
        reminderTime: now.add(const Duration(days: 4)),
        createdAt: now.subtract(const Duration(days: 10)),
      ),
      CalendarEvent(
        id: '4',
        title: 'Doctor Appointment',
        description: 'Annual checkup for Mike',
        date: now.add(const Duration(days: 7)),
        assignedMemberId: '2',
        category: 'Appointment',
        hasReminder: true,
        reminderTime: now.add(const Duration(days: 7)).subtract(const Duration(hours: 24)),
        createdAt: now.subtract(const Duration(days: 2)),
      ),
      CalendarEvent(
        id: '5',
        title: 'Parent-Teacher Conference',
        description: 'Meeting with Emma\'s teacher',
        date: now.add(const Duration(days: 10)),
        assignedMemberId: '1',
        category: 'School Event',
        hasReminder: true,
        reminderTime: now.add(const Duration(days: 9)),
        createdAt: now.subtract(const Duration(days: 1)),
      ),
    ];
  }
}