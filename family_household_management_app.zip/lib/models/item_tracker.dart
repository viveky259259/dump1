import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';

class TrackedItem {
  final String? id;
  final String name;
  final String description;
  final String currentLocation;
  final String? borrowedByMemberId;
  final DateTime? borrowedAt;
  final DateTime? returnedAt;
  final String category;
  final String status;
  final String? imageUrl;
  final List<ItemHistory> history;
  final DateTime createdAt;

  const TrackedItem({
    this.id,
    required this.name,
    required this.description,
    required this.currentLocation,
    this.borrowedByMemberId,
    this.borrowedAt,
    this.returnedAt,
    required this.category,
    required this.status,
    this.imageUrl,
    required this.history,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'currentLocation': currentLocation,
        'borrowedByMemberId': borrowedByMemberId,
        'borrowedAt': borrowedAt?.toIso8601String(),
        'returnedAt': returnedAt?.toIso8601String(),
        'category': category,
        'status': status,
        'imageUrl': imageUrl,
        'history': history.map((h) => h.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
      };

  factory TrackedItem.fromJson(Map<String, dynamic> json) => TrackedItem(
        id: json['id'],
        name: json['name'],
        description: json['description'],
        currentLocation: json['currentLocation'],
        borrowedByMemberId: json['borrowedByMemberId'],
        borrowedAt: json['borrowedAt'] != null
            ? DateTime.parse(json['borrowedAt'])
            : null,
        returnedAt: json['returnedAt'] != null
            ? DateTime.parse(json['returnedAt'])
            : null,
        category: json['category'],
        status: json['status'],
        imageUrl: json['imageUrl'],
        history: (json['history'] as List)
            .map((h) => ItemHistory.fromJson(h))
            .toList(),
        createdAt: DateTime.parse(json['createdAt']),
      );

  // Firebase conversion methods
  Map<String, dynamic> toFirestore() => {
        'name': name,
        'description': description,
        'currentLocation': currentLocation,
        'borrowedByMemberId': borrowedByMemberId,
        'borrowedAt': borrowedAt != null ? Timestamp.fromDate(borrowedAt!) : null,
        'returnedAt': returnedAt != null ? Timestamp.fromDate(returnedAt!) : null,
        'category': category,
        'status': status,
        'imageUrl': imageUrl,
        'history': history.map((h) => h.toFirestore()).toList(),
      };

  factory TrackedItem.fromFirestore(String docId, Map<String, dynamic> data) {
    final borrowedAtTimestamp = data['borrowedAt'] as Timestamp?;
    final returnedAtTimestamp = data['returnedAt'] as Timestamp?;
    final createdAtTimestamp = data['createdAt'] as Timestamp?;
    
    return TrackedItem(
      id: docId,
      name: data['name'] ?? '',
      description: data['description'] ?? '',
      currentLocation: data['currentLocation'] ?? '',
      borrowedByMemberId: data['borrowedByMemberId'],
      borrowedAt: borrowedAtTimestamp?.toDate(),
      returnedAt: returnedAtTimestamp?.toDate(),
      category: data['category'] ?? 'Other',
      status: data['status'] ?? 'Available',
      imageUrl: data['imageUrl'],
      history: (data['history'] as List<dynamic>? ?? [])
          .map((h) => ItemHistory.fromFirestore(h as Map<String, dynamic>))
          .toList(),
      createdAt: createdAtTimestamp?.toDate() ?? DateTime.now(),
    );
  }

  TrackedItem copyWith({
    String? id,
    String? name,
    String? description,
    String? currentLocation,
    String? borrowedByMemberId,
    DateTime? borrowedAt,
    DateTime? returnedAt,
    String? category,
    String? status,
    String? imageUrl,
    List<ItemHistory>? history,
    DateTime? createdAt,
  }) =>
      TrackedItem(
        id: id ?? this.id,
        name: name ?? this.name,
        description: description ?? this.description,
        currentLocation: currentLocation ?? this.currentLocation,
        borrowedByMemberId: borrowedByMemberId ?? this.borrowedByMemberId,
        borrowedAt: borrowedAt ?? this.borrowedAt,
        returnedAt: returnedAt ?? this.returnedAt,
        category: category ?? this.category,
        status: status ?? this.status,
        imageUrl: imageUrl ?? this.imageUrl,
        history: history ?? this.history,
        createdAt: createdAt ?? this.createdAt,
      );

  static List<String> get categories => [
        'Electronics',
        'Tools',
        'Books',
        'Sports Equipment',
        'Kitchen Items',
        'Clothing',
        'Toys & Games',
        'Documents',
        'Other',
      ];

  static List<String> get statuses => [
        'Available',
        'Borrowed',
        'In Use',
        'Lost',
        'Maintenance',
      ];

  static List<String> get locations => [
        'Living Room',
        'Kitchen',
        'Master Bedroom',
        'Kids Room',
        'Garage',
        'Basement',
        'Office',
        'Bathroom',
        'Attic',
        'Outside',
        'Car',
        'Unknown',
      ];

  bool get isBorrowed => status == 'Borrowed' && borrowedByMemberId != null;

  static List<TrackedItem> getSampleItems() {
    final now = DateTime.now();
    return [
      TrackedItem(
        id: '1',
        name: 'iPad Pro',
        description: 'Family tablet for entertainment and homework',
        currentLocation: 'Living Room',
        borrowedByMemberId: '3',
        borrowedAt: now.subtract(const Duration(hours: 2)),
        category: 'Electronics',
        status: 'Borrowed',
        history: [
          ItemHistory(
            id: '1',
            action: 'Borrowed',
            memberId: '3',
            location: 'Living Room',
            timestamp: now.subtract(const Duration(hours: 2)),
            notes: 'For homework project',
          ),
        ],
        createdAt: now.subtract(const Duration(days: 30)),
      ),
      TrackedItem(
        id: '2',
        name: 'Bluetooth Headphones',
        description: 'Noise-canceling headphones',
        currentLocation: 'Kids Room',
        borrowedByMemberId: '4',
        borrowedAt: now.subtract(const Duration(days: 1)),
        category: 'Electronics',
        status: 'Borrowed',
        history: [
          ItemHistory(
            id: '2',
            action: 'Borrowed',
            memberId: '4',
            location: 'Kids Room',
            timestamp: now.subtract(const Duration(days: 1)),
            notes: 'For gaming session',
          ),
        ],
        createdAt: now.subtract(const Duration(days: 45)),
      ),
      TrackedItem(
        id: '3',
        name: 'Power Drill',
        description: 'Cordless drill for home projects',
        currentLocation: 'Garage',
        category: 'Tools',
        status: 'Available',
        history: [
          ItemHistory(
            id: '3',
            action: 'Returned',
            memberId: '2',
            location: 'Garage',
            timestamp: now.subtract(const Duration(days: 3)),
            notes: 'Finished fixing deck',
          ),
        ],
        createdAt: now.subtract(const Duration(days: 60)),
      ),
      TrackedItem(
        id: '4',
        name: 'Soccer Ball',
        description: 'Official size soccer ball',
        currentLocation: 'Garage',
        category: 'Sports Equipment',
        status: 'Available',
        history: [
          ItemHistory(
            id: '4',
            action: 'Added',
            memberId: '1',
            location: 'Garage',
            timestamp: now.subtract(const Duration(days: 7)),
            notes: 'New soccer ball for Emma',
          ),
        ],
        createdAt: now.subtract(const Duration(days: 7)),
      ),
      TrackedItem(
        id: '5',
        name: 'Kitchen Scale',
        description: 'Digital scale for baking',
        currentLocation: 'Kitchen',
        borrowedByMemberId: '1',
        borrowedAt: now.subtract(const Duration(hours: 4)),
        category: 'Kitchen Items',
        status: 'In Use',
        history: [
          ItemHistory(
            id: '5',
            action: 'In Use',
            memberId: '1',
            location: 'Kitchen',
            timestamp: now.subtract(const Duration(hours: 4)),
            notes: 'Baking cookies for school event',
          ),
        ],
        createdAt: now.subtract(const Duration(days: 20)),
      ),
    ];
  }
}

class ItemHistory {
  final String id;
  final String action;
  final String memberId;
  final String location;
  final DateTime timestamp;
  final String notes;

  const ItemHistory({
    required this.id,
    required this.action,
    required this.memberId,
    required this.location,
    required this.timestamp,
    required this.notes,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'action': action,
        'memberId': memberId,
        'location': location,
        'timestamp': timestamp.toIso8601String(),
        'notes': notes,
      };

  factory ItemHistory.fromJson(Map<String, dynamic> json) => ItemHistory(
        id: json['id'],
        action: json['action'],
        memberId: json['memberId'],
        location: json['location'],
        timestamp: DateTime.parse(json['timestamp']),
        notes: json['notes'],
      );

  // Firebase conversion methods
  Map<String, dynamic> toFirestore() => {
        'id': id,
        'action': action,
        'memberId': memberId,
        'location': location,
        'timestamp': Timestamp.fromDate(timestamp),
        'notes': notes,
      };

  factory ItemHistory.fromFirestore(Map<String, dynamic> data) {
    final timestampData = data['timestamp'] as Timestamp?;
    return ItemHistory(
      id: data['id'] ?? '',
      action: data['action'] ?? '',
      memberId: data['memberId'] ?? '',
      location: data['location'] ?? '',
      timestamp: timestampData?.toDate() ?? DateTime.now(),
      notes: data['notes'] ?? '',
    );
  }
}