import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';

class HouseholdTask {
  final String? id;
  final String title;
  final String description;
  final String assignedMemberId;
  final DateTime dueDate;
  final String category;
  final String priority;
  final bool isCompleted;
  final DateTime? completedAt;
  final String? completedByMemberId;
  final bool isRecurring;
  final String? recurringPattern;
  final DateTime createdAt;

  const HouseholdTask({
    this.id,
    required this.title,
    required this.description,
    required this.assignedMemberId,
    required this.dueDate,
    required this.category,
    required this.priority,
    this.isCompleted = false,
    this.completedAt,
    this.completedByMemberId,
    this.isRecurring = false,
    this.recurringPattern,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'assignedMemberId': assignedMemberId,
        'dueDate': dueDate.toIso8601String(),
        'category': category,
        'priority': priority,
        'isCompleted': isCompleted,
        'completedAt': completedAt?.toIso8601String(),
        'completedByMemberId': completedByMemberId,
        'isRecurring': isRecurring,
        'recurringPattern': recurringPattern,
        'createdAt': createdAt.toIso8601String(),
      };

  factory HouseholdTask.fromJson(Map<String, dynamic> json) => HouseholdTask(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        assignedMemberId: json['assignedMemberId'],
        dueDate: DateTime.parse(json['dueDate']),
        category: json['category'],
        priority: json['priority'],
        isCompleted: json['isCompleted'] ?? false,
        completedAt: json['completedAt'] != null
            ? DateTime.parse(json['completedAt'])
            : null,
        completedByMemberId: json['completedByMemberId'],
        isRecurring: json['isRecurring'] ?? false,
        recurringPattern: json['recurringPattern'],
        createdAt: DateTime.parse(json['createdAt']),
      );

  // Firebase conversion methods
  Map<String, dynamic> toFirestore() => {
        'title': title,
        'description': description,
        'assignedMemberId': assignedMemberId,
        'dueDate': Timestamp.fromDate(dueDate),
        'category': category,
        'priority': priority,
        'isCompleted': isCompleted,
        'completedAt': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
        'completedByMemberId': completedByMemberId,
        'isRecurring': isRecurring,
        'recurringPattern': recurringPattern,
      };

  factory HouseholdTask.fromFirestore(String docId, Map<String, dynamic> data) {
    final dueDateTimestamp = data['dueDate'] as Timestamp?;
    final completedAtTimestamp = data['completedAt'] as Timestamp?;
    final createdAtTimestamp = data['createdAt'] as Timestamp?;
    
    return HouseholdTask(
      id: docId,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      assignedMemberId: data['assignedMemberId'] ?? '',
      dueDate: dueDateTimestamp?.toDate() ?? DateTime.now(),
      category: data['category'] ?? 'Other',
      priority: data['priority'] ?? 'Medium',
      isCompleted: data['isCompleted'] ?? false,
      completedAt: completedAtTimestamp?.toDate(),
      completedByMemberId: data['completedByMemberId'],
      isRecurring: data['isRecurring'] ?? false,
      recurringPattern: data['recurringPattern'],
      createdAt: createdAtTimestamp?.toDate() ?? DateTime.now(),
    );
  }

  HouseholdTask copyWith({
    String? id,
    String? title,
    String? description,
    String? assignedMemberId,
    DateTime? dueDate,
    String? category,
    String? priority,
    bool? isCompleted,
    DateTime? completedAt,
    String? completedByMemberId,
    bool? isRecurring,
    String? recurringPattern,
    DateTime? createdAt,
  }) =>
      HouseholdTask(
        id: id ?? this.id,
        title: title ?? this.title,
        description: description ?? this.description,
        assignedMemberId: assignedMemberId ?? this.assignedMemberId,
        dueDate: dueDate ?? this.dueDate,
        category: category ?? this.category,
        priority: priority ?? this.priority,
        isCompleted: isCompleted ?? this.isCompleted,
        completedAt: completedAt ?? this.completedAt,
        completedByMemberId: completedByMemberId ?? this.completedByMemberId,
        isRecurring: isRecurring ?? this.isRecurring,
        recurringPattern: recurringPattern ?? this.recurringPattern,
        createdAt: createdAt ?? this.createdAt,
      );

  static List<String> get categories => [
        'Cleaning',
        'Kitchen',
        'Laundry',
        'Yard Work',
        'Maintenance',
        'Shopping',
        'Pet Care',
        'Organization',
        'Bills & Finance',
        'Other',
      ];

  static List<String> get priorities => [
        'Low',
        'Medium',
        'High',
        'Urgent',
      ];

  bool get isOverdue => !isCompleted && dueDate.isBefore(DateTime.now());

  static List<HouseholdTask> getSampleTasks() {
    final now = DateTime.now();
    return [
      HouseholdTask(
        id: '1',
        title: 'Take out trash',
        description: 'Weekly garbage and recycling pickup',
        assignedMemberId: '4',
        dueDate: now.add(const Duration(days: 1)),
        category: 'Cleaning',
        priority: 'Medium',
        isRecurring: true,
        recurringPattern: 'Weekly',
        createdAt: now.subtract(const Duration(days: 7)),
      ),
      HouseholdTask(
        id: '2',
        title: 'Vacuum living room',
        description: 'Weekly deep cleaning of main living area',
        assignedMemberId: '3',
        dueDate: now.add(const Duration(days: 2)),
        category: 'Cleaning',
        priority: 'Medium',
        isRecurring: true,
        recurringPattern: 'Weekly',
        createdAt: now.subtract(const Duration(days: 5)),
      ),
      HouseholdTask(
        id: '3',
        title: 'Grocery shopping',
        description: 'Weekly grocery run for the family',
        assignedMemberId: '1',
        dueDate: now.add(const Duration(days: 3)),
        category: 'Shopping',
        priority: 'High',
        isRecurring: true,
        recurringPattern: 'Weekly',
        createdAt: now.subtract(const Duration(days: 2)),
      ),
      HouseholdTask(
        id: '4',
        title: 'Mow the lawn',
        description: 'Bi-weekly yard maintenance',
        assignedMemberId: '2',
        dueDate: now.add(const Duration(days: 4)),
        category: 'Yard Work',
        priority: 'Medium',
        isRecurring: true,
        recurringPattern: 'Bi-weekly',
        createdAt: now.subtract(const Duration(days: 10)),
      ),
      HouseholdTask(
        id: '5',
        title: 'Clean bathroom',
        description: 'Deep clean main bathroom',
        assignedMemberId: '1',
        dueDate: now.subtract(const Duration(days: 1)),
        category: 'Cleaning',
        priority: 'High',
        isCompleted: false,
        createdAt: now.subtract(const Duration(days: 8)),
      ),
      HouseholdTask(
        id: '6',
        title: 'Feed pets',
        description: 'Daily pet feeding and water',
        assignedMemberId: '3',
        dueDate: now,
        category: 'Pet Care',
        priority: 'High',
        isRecurring: true,
        recurringPattern: 'Daily',
        createdAt: now.subtract(const Duration(days: 1)),
      ),
    ];
  }
}