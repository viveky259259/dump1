import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';

class EmergencyContact {
  final String? id;
  final String name;
  final String phoneNumber;
  final String relationship;
  final String contactType;
  final String? email;
  final String? address;
  final String? notes;
  final bool isPrimary;
  final DateTime createdAt;

  const EmergencyContact({
    this.id,
    required this.name,
    required this.phoneNumber,
    required this.relationship,
    required this.contactType,
    this.email,
    this.address,
    this.notes,
    this.isPrimary = false,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phoneNumber': phoneNumber,
        'relationship': relationship,
        'contactType': contactType,
        'email': email,
        'address': address,
        'notes': notes,
        'isPrimary': isPrimary,
        'createdAt': createdAt.toIso8601String(),
      };

  factory EmergencyContact.fromJson(Map<String, dynamic> json) => EmergencyContact(
        id: json['id'],
        name: json['name'],
        phoneNumber: json['phoneNumber'],
        relationship: json['relationship'],
        contactType: json['contactType'],
        email: json['email'],
        address: json['address'],
        notes: json['notes'],
        isPrimary: json['isPrimary'] ?? false,
        createdAt: DateTime.parse(json['createdAt']),
      );

  // Firebase conversion methods
  Map<String, dynamic> toFirestore() => {
        'name': name,
        'phoneNumber': phoneNumber,
        'relationship': relationship,
        'contactType': contactType,
        'email': email,
        'address': address,
        'notes': notes,
        'isPrimary': isPrimary,
      };

  factory EmergencyContact.fromFirestore(String docId, Map<String, dynamic> data) {
    final createdAtTimestamp = data['createdAt'] as Timestamp?;
    return EmergencyContact(
      id: docId,
      name: data['name'] ?? '',
      phoneNumber: data['phoneNumber'] ?? '',
      relationship: data['relationship'] ?? '',
      contactType: data['contactType'] ?? 'Personal',
      email: data['email'],
      address: data['address'],
      notes: data['notes'],
      isPrimary: data['isPrimary'] ?? false,
      createdAt: createdAtTimestamp?.toDate() ?? DateTime.now(),
    );
  }

  EmergencyContact copyWith({
    String? id,
    String? name,
    String? phoneNumber,
    String? relationship,
    String? contactType,
    String? email,
    String? address,
    String? notes,
    bool? isPrimary,
    DateTime? createdAt,
  }) =>
      EmergencyContact(
        id: id ?? this.id,
        name: name ?? this.name,
        phoneNumber: phoneNumber ?? this.phoneNumber,
        relationship: relationship ?? this.relationship,
        contactType: contactType ?? this.contactType,
        email: email ?? this.email,
        address: address ?? this.address,
        notes: notes ?? this.notes,
        isPrimary: isPrimary ?? this.isPrimary,
        createdAt: createdAt ?? this.createdAt,
      );

  static List<String> get contactTypes => [
        'Emergency Services',
        'Medical',
        'Family',
        'Friend',
        'Neighbor',
        'Workplace',
        'School',
        'Service Provider',
        'Other',
      ];

  static List<String> get relationships => [
        'Parent',
        'Sibling',
        'Grandparent',
        'Aunt/Uncle',
        'Cousin',
        'Friend',
        'Neighbor',
        'Doctor',
        'Emergency Contact',
        'Other',
      ];

  static List<EmergencyContact> getSampleContacts() {
    final now = DateTime.now();
    return [
      EmergencyContact(
        id: '1',
        name: 'Emergency Services',
        phoneNumber: '911',
        relationship: 'Emergency Contact',
        contactType: 'Emergency Services',
        notes: 'For life-threatening emergencies only',
        isPrimary: true,
        createdAt: now.subtract(const Duration(days: 30)),
      ),
      EmergencyContact(
        id: '2',
        name: 'Dr. Johnson',
        phoneNumber: '(555) 123-4567',
        relationship: 'Doctor',
        contactType: 'Medical',
        email: 'dr.johnson@familyhealth.com',
        address: '123 Medical Center Dr, City, ST 12345',
        notes: 'Family physician - Emma and Jake\'s pediatrician',
        isPrimary: true,
        createdAt: now.subtract(const Duration(days: 25)),
      ),
      EmergencyContact(
        id: '3',
        name: 'Grandma Betty',
        phoneNumber: '(555) 987-6543',
        relationship: 'Grandparent',
        contactType: 'Family',
        email: 'betty.smith@email.com',
        address: '456 Oak Street, City, ST 12345',
        notes: 'Sarah\'s mother - always available for emergencies',
        isPrimary: true,
        createdAt: now.subtract(const Duration(days: 30)),
      ),
      EmergencyContact(
        id: '4',
        name: 'Tom Wilson',
        phoneNumber: '(555) 555-0123',
        relationship: 'Neighbor',
        contactType: 'Neighbor',
        email: 'tom.wilson@email.com',
        address: '789 Maple Lane, City, ST 12345',
        notes: 'Next door neighbor - has spare key',
        createdAt: now.subtract(const Duration(days: 20)),
      ),
      EmergencyContact(
        id: '5',
        name: 'Poison Control',
        phoneNumber: '1-800-222-1222',
        relationship: 'Emergency Contact',
        contactType: 'Emergency Services',
        notes: 'National poison control hotline',
        createdAt: now.subtract(const Duration(days: 30)),
      ),
      EmergencyContact(
        id: '6',
        name: 'Emma\'s School',
        phoneNumber: '(555) 246-8101',
        relationship: 'Other',
        contactType: 'School',
        email: 'office@elementaryschool.edu',
        address: '321 School Street, City, ST 12345',
        notes: 'Riverside Elementary School - Main Office',
        createdAt: now.subtract(const Duration(days: 15)),
      ),
    ];
  }
}