import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FamilyMember {
  final String? id;
  final String name;
  final String role;
  final Color color;
  final String? profileImageUrl;
  final String? userId;
  final String? email;
  final bool isOwner;
  final DateTime createdAt;

  const FamilyMember({
    this.id,
    required this.name,
    required this.role,
    required this.color,
    this.profileImageUrl,
    this.userId,
    this.email,
    this.isOwner = false,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'role': role,
        'colorValue': color.value,
        'profileImageUrl': profileImageUrl,
        'userId': userId,
        'email': email,
        'isOwner': isOwner,
        'createdAt': createdAt.toIso8601String(),
      };

  factory FamilyMember.fromJson(Map<String, dynamic> json) => FamilyMember(
        id: json['id'],
        name: json['name'],
        role: json['role'],
        color: Color(json['colorValue']),
        profileImageUrl: json['profileImageUrl'],
        userId: json['userId'],
        email: json['email'],
        isOwner: json['isOwner'] ?? false,
        createdAt: DateTime.parse(json['createdAt']),
      );

  // Firebase conversion methods
  Map<String, dynamic> toFirestore() => {
        'name': name,
        'role': role,
        'colorValue': color.value,
        'profileImageUrl': profileImageUrl,
        'userId': userId,
        'email': email,
        'isOwner': isOwner,
      };

  factory FamilyMember.fromFirestore(String docId, Map<String, dynamic> data) {
    final timestamp = data['createdAt'] as Timestamp?;
    return FamilyMember(
      id: docId,
      name: data['name'] ?? '',
      role: data['role'] ?? '',
      color: Color(data['colorValue'] ?? 0xFF6F61EF),
      profileImageUrl: data['profileImageUrl'],
      userId: data['userId'],
      email: data['email'],
      isOwner: data['isOwner'] ?? false,
      createdAt: timestamp?.toDate() ?? DateTime.now(),
    );
  }

  FamilyMember copyWith({
    String? id,
    String? name,
    String? role,
    Color? color,
    String? profileImageUrl,
    String? userId,
    String? email,
    bool? isOwner,
    DateTime? createdAt,
  }) =>
      FamilyMember(
        id: id ?? this.id,
        name: name ?? this.name,
        role: role ?? this.role,
        color: color ?? this.color,
        profileImageUrl: profileImageUrl ?? this.profileImageUrl,
        userId: userId ?? this.userId,
        email: email ?? this.email,
        isOwner: isOwner ?? this.isOwner,
        createdAt: createdAt ?? this.createdAt,
      );

  static List<FamilyMember> getSampleMembers() => [
        FamilyMember(
          id: '1',
          name: 'Sarah',
          role: 'Mom',
          color: const Color(0xFF6F61EF),
          isOwner: true,
          createdAt: DateTime.now().subtract(const Duration(days: 30)),
        ),
        FamilyMember(
          id: '2',
          name: 'Mike',
          role: 'Dad',
          color: const Color(0xFF39D2C0),
          createdAt: DateTime.now().subtract(const Duration(days: 30)),
        ),
        FamilyMember(
          id: '3',
          name: 'Emma',
          role: 'Daughter',
          color: const Color(0xFFEE8B60),
          createdAt: DateTime.now().subtract(const Duration(days: 30)),
        ),
        FamilyMember(
          id: '4',
          name: 'Jake',
          role: 'Son',
          color: const Color(0xFF4CAF50),
          createdAt: DateTime.now().subtract(const Duration(days: 30)),
        ),
      ];
}