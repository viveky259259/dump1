# Persistent Login Implementation Guide

## Overview
The Family Household Management app now features automatic login persistence using Firebase Authentication. Users will remain logged in across app restarts and will only need to re-authenticate when they explicitly sign out.

## How It Works

### 1. Firebase Authentication Persistence
- Firebase Auth automatically handles session persistence at the native level
- User authentication tokens are securely stored in device keychain/keystore
- Authentication state is automatically restored when the app starts

### 2. App Startup Flow
1. **App launches** → `main.dart` initializes Firebase
2. **AuthService initializes** → Checks for existing Firebase Auth session
3. **AuthWrapper evaluates** → Shows loading screen while checking auth state
4. **Routes user to**:
   - **Login Page** if not authenticated
   - **Family Setup Page** if authenticated but no family
   - **Home Page** if authenticated with family

### 3. Login Process
1. User enters credentials
2. Firebase Auth authenticates user
3. User profile data is loaded from Firestore
4. Login preferences are saved to SharedPreferences (for convenience)
5. User is routed to appropriate page

### 4. Logout Process
1. User taps account icon → "Sign Out" in popup menu
2. Confirmation dialog explains that login details will be cleared
3. If confirmed:
   - SharedPreferences are cleared
   - Firebase Auth session is terminated
   - User is routed back to Login Page

## Security Features

### Data Storage
- **Firebase Auth Tokens**: Stored securely in device keychain/keystore
- **User Preferences**: Stored in SharedPreferences (email, last login time)
- **Sensitive Data**: Only stored in Firebase's secure storage

### Auto-Logout Scenarios
- User explicitly signs out
- Firebase session expires (configurable, typically 1 hour of inactivity)
- App is uninstalled and reinstalled
- Device security is compromised (Firebase detects and invalidates tokens)

## User Experience

### First Login
- User enters email and password
- App shows "Your login details are securely saved" message
- Credentials are saved for future sessions

### Subsequent App Opens
- App automatically checks for valid authentication
- If valid, user goes directly to home page
- If invalid/expired, user sees login page with last used email pre-filled

### Logout
- Clear logout flow with confirmation
- Explains what happens when signing out
- Clean slate for next login

## Implementation Details

### Key Files Modified
- `lib/services/auth_service.dart`: Added persistent login logic
- `lib/main.dart`: Updated AuthWrapper with loading state
- `lib/pages/auth/login_page.dart`: Added last email pre-filling
- `lib/pages/home_page.dart`: Added logout functionality

### Methods Added
- `AuthService.isInitialized`: Check if auth state is determined
- `AuthService._saveLoginPreferences()`: Save login metadata
- `AuthService.getStoredLoginInfo()`: Retrieve stored login metadata
- `AuthService._clearLoginPreferences()`: Clear stored metadata
- `HomePage._showLogoutDialog()`: Logout confirmation dialog

## Testing

### Test Scenarios
1. **First Login**: Verify credentials are saved and user stays logged in
2. **App Restart**: Verify user remains logged in after app restart
3. **Logout**: Verify user is properly logged out and credentials cleared
4. **Re-login**: Verify email is pre-filled after logout
5. **Session Expiry**: Verify graceful handling of expired sessions

### Testing Commands
```bash
# Hot restart to test persistence
flutter hot restart

# Full app restart
flutter run

# Test on different devices
flutter run -d <device_id>
```

## Security Considerations

### Best Practices Implemented
- Uses Firebase Auth's built-in security features
- No passwords stored locally
- Tokens automatically rotated by Firebase
- Secure storage for authentication tokens
- Clear logout process that removes all traces

### Additional Security Notes
- Firebase Auth tokens are automatically refreshed
- Biometric authentication can be added later if needed
- Multi-factor authentication is supported by Firebase Auth
- Suspicious activity detection is built into Firebase Auth

## Troubleshooting

### Common Issues
1. **User not staying logged in**: Check Firebase configuration
2. **Email not pre-filling**: Check SharedPreferences permissions
3. **Logout not working**: Check Firebase Auth signOut implementation

### Debug Information
- Auth state changes are logged to console
- Stored login info can be checked via `getStoredLoginInfo()`
- Firebase Auth errors are caught and displayed to user