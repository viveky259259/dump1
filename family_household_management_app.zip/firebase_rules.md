# Updated Firestore Security Rules for Multiple Family Support

To support multiple family memberships, the following Firebase Firestore security rules should be applied:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users can read/write their own profile
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Family documents
    match /families/{familyId} {
      // Users can read families they are members of
      allow read: if request.auth != null && 
                    request.auth.uid in resource.data.memberIds;
      
      // Users can create families (they will be added as owner/member automatically)
      allow create: if request.auth != null && 
                      request.auth.uid == request.resource.data.ownerId &&
                      request.auth.uid in request.resource.data.memberIds;
      
      // Only family owner can update family info (except member list which is managed separately)
      allow update: if request.auth != null && 
                      request.auth.uid == resource.data.ownerId;
      
      // Only owner can delete family
      allow delete: if request.auth != null && 
                      request.auth.uid == resource.data.ownerId;
      
      // Family members subcollection
      match /members/{memberId} {
        // Family members can read all member documents
        allow read: if request.auth != null && 
                      request.auth.uid in get(/databases/$(database)/documents/families/$(familyId)).data.memberIds;
        
        // Users can create their own member document when joining
        allow create: if request.auth != null && 
                        request.auth.uid == request.resource.data.userId &&
                        request.auth.uid in get(/databases/$(database)/documents/families/$(familyId)).data.memberIds;
        
        // Users can update their own member document, owner can update any
        allow update: if request.auth != null && 
                        (request.auth.uid == resource.data.userId || 
                         request.auth.uid == get(/databases/$(database)/documents/families/$(familyId)).data.ownerId);
        
        // Users can delete their own member document, owner can delete any
        allow delete: if request.auth != null && 
                        (request.auth.uid == resource.data.userId || 
                         request.auth.uid == get(/databases/$(database)/documents/families/$(familyId)).data.ownerId);
      }
      
      // Family events, tasks, items, and emergency contacts
      match /{collection}/{documentId} {
        // Family members can read all documents
        allow read: if request.auth != null && 
                      request.auth.uid in get(/databases/$(database)/documents/families/$(familyId)).data.memberIds;
        
        // Family members can create documents
        allow create: if request.auth != null && 
                        request.auth.uid in get(/databases/$(database)/documents/families/$(familyId)).data.memberIds;
        
        // Family members can update documents
        allow update: if request.auth != null && 
                        request.auth.uid in get(/databases/$(database)/documents/families/$(familyId)).data.memberIds;
        
        // Family members can delete documents (could be restricted further if needed)
        allow delete: if request.auth != null && 
                        request.auth.uid in get(/databases/$(database)/documents/families/$(familyId)).data.memberIds;
      }
    }
  }
}
```

## Key Changes from Previous Rules:

1. **Multiple Family Support**: Users can now be members of multiple families through the `memberIds` array
2. **User Profile Structure**: User profiles now support `familyIds` array instead of a single `familyId`
3. **Family Member Management**: Enhanced rules for joining/leaving families
4. **Flexible Membership**: Users can manage their membership across multiple families

## Database Structure Changes:

### User Document:
```javascript
{
  name: "User Name",
  email: "user@example.com",
  familyIds: ["familyId1", "familyId2"], // Array of family IDs
  createdAt: timestamp,
  updatedAt: timestamp
}
```

### Family Document:
```javascript
{
  name: "Family Name",
  ownerId: "userIdOfOwner",
  memberIds: ["userId1", "userId2", "userId3"], // Array of member IDs
  createdAt: timestamp,
  updatedAt: timestamp
}
```

These rules ensure secure multi-family functionality while maintaining proper access control.