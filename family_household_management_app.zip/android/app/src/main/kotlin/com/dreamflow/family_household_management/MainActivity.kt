package com.dreamflow.family_household_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}