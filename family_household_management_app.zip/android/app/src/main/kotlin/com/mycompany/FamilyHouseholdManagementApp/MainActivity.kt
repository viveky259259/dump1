package com.mycompany.FamilyHouseholdManagementApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
