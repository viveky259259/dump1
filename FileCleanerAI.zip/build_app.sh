#!/bin/bash

# Enhanced Build Script for FileCleanerAI macOS App
# Supports debug, release, signing, and distribution builds

set -e  # Exit on error

# Configuration
APP_NAME="AI File Cleaner"
BUNDLE_ID="com.filecleaner.ai"
VERSION="1.0.0"
BUILD_NUMBER="1"
MIN_MACOS="15.0"
DEVELOPER_ID="Developer ID Application: Vivek Yadav (CU3457GT8T)"
TEAM_ID="CU3457GT8T"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_header() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  🚀 FileCleanerAI Build Script v2.0              ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════╝${NC}"
    echo ""
}

print_step() {
    echo -e "${GREEN}➜${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC}  $1"
}

# Parse arguments
BUILD_CONFIG="release"
CLEAN=false
OPEN_APP=false
CREATE_DMG=false
SIGN_APP=false
NOTARIZE=false
VERBOSE=false

while [[ $# -gt 0 ]]; do
    case $1 in
        -d|--debug)
            BUILD_CONFIG="debug"
            shift
            ;;
        -r|--release)
            BUILD_CONFIG="release"
            shift
            ;;
        -c|--clean)
            CLEAN=true
            shift
            ;;
        -o|--open)
            OPEN_APP=true
            shift
            ;;
        --dmg)
            CREATE_DMG=true
            shift
            ;;
        -s|--sign)
            SIGN_APP=true
            shift
            ;;
        -n|--notarize)
            NOTARIZE=true
            SIGN_APP=true  # Notarization requires signing
            shift
            ;;
        --dist|--distribute)
            # Full distribution build: sign + dmg + notarize
            SIGN_APP=true
            CREATE_DMG=true
            NOTARIZE=true
            shift
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [options]"
            echo ""
            echo "Options:"
            echo "  -d, --debug       Build in debug mode (default: release)"
            echo "  -r, --release     Build in release mode"
            echo "  -c, --clean       Clean before building"
            echo "  -o, --open        Open app after building"
            echo "  --dmg             Create DMG installer"
            echo "  -s, --sign        Sign app with Developer ID"
            echo "  -n, --notarize    Notarize app with Apple (implies --sign)"
            echo "  --dist            Full distribution build (sign + dmg + notarize)"
            echo "  -v, --verbose     Verbose output"
            echo "  -h, --help        Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 -c --dmg           # Clean build with DMG (unsigned)"
            echo "  $0 -s --dmg           # Signed build with DMG"
            echo "  $0 --dist             # Full distribution (signed + notarized + DMG)"
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            echo "Use -h or --help for usage information"
            exit 1
            ;;
    esac
done

# Start build
print_header
print_step "Build Configuration: $BUILD_CONFIG"
if [ "$SIGN_APP" = true ]; then
    echo "    ➜ Code signing: enabled"
fi
if [ "$NOTARIZE" = true ]; then
    echo "    ➜ Notarization: enabled"
fi
if [ "$CREATE_DMG" = true ]; then
    echo "    ➜ DMG creation: enabled"
fi
echo ""

# Set build directory
BUILD_DIR=".build/${BUILD_CONFIG}"
APP_BUNDLE="${BUILD_DIR}/${APP_NAME}.app"

# Clean if requested
if [ "$CLEAN" = true ]; then
    print_step "Cleaning previous builds..."
    rm -rf ".build"
    print_success "Clean complete"
    echo ""
fi

# Build executable
print_step "Compiling Swift code..."
if [ "$VERBOSE" = true ]; then
    swift build -c ${BUILD_CONFIG}
else
    swift build -c ${BUILD_CONFIG} 2>&1 | grep -E "(warning:|error:|Build complete)" || true
fi

if [ $? -ne 0 ]; then
    print_error "Build failed!"
    exit 1
fi

print_success "Build complete"
echo ""

# Create app bundle
print_step "Creating app bundle..."
mkdir -p "${APP_BUNDLE}/Contents/MacOS"
mkdir -p "${APP_BUNDLE}/Contents/Resources"

# Copy executable
cp "${BUILD_DIR}/FileCleanerAI" "${APP_BUNDLE}/Contents/MacOS/${APP_NAME}"
chmod +x "${APP_BUNDLE}/Contents/MacOS/${APP_NAME}"

# Copy app icon if it exists
if [ -f "FileCleanerAI/AppIcon.icns" ]; then
    cp "FileCleanerAI/AppIcon.icns" "${APP_BUNDLE}/Contents/Resources/AppIcon.icns"
fi

# Copy entitlements if they exist
if [ -f "FileCleanerAI/FileCleanerAI.entitlements" ]; then
    cp "FileCleanerAI/FileCleanerAI.entitlements" "${APP_BUNDLE}/Contents/Resources/"
fi

# Copy and configure Info.plist
cp "FileCleanerAI/Info.plist" "${APP_BUNDLE}/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleExecutable '${APP_NAME}'" "${APP_BUNDLE}/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier '${BUNDLE_ID}'" "${APP_BUNDLE}/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString '${VERSION}'" "${APP_BUNDLE}/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion '${BUILD_NUMBER}'" "${APP_BUNDLE}/Contents/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :LSMinimumSystemVersion '${MIN_MACOS}'" "${APP_BUNDLE}/Contents/Info.plist" 2>/dev/null || true

print_success "App bundle created"
echo ""

# Code signing
if [ "$SIGN_APP" = true ]; then
    print_step "Signing app with Developer ID..."
    
    # Check if certificate exists
    if ! security find-identity -v -p codesigning | grep -q "Developer ID Application"; then
        print_error "Developer ID Application certificate not found!"
        echo "    Please ensure you have a valid Developer ID certificate installed."
        exit 1
    fi
    
    # Sign with hardened runtime (required for notarization)
    ENTITLEMENTS_FLAG=""
    if [ -f "FileCleanerAI/FileCleanerAI.entitlements" ]; then
        ENTITLEMENTS_FLAG="--entitlements FileCleanerAI/FileCleanerAI.entitlements"
    fi
    
    codesign --deep --force --verify --verbose \
        --options runtime \
        --sign "${DEVELOPER_ID}" \
        ${ENTITLEMENTS_FLAG} \
        "${APP_BUNDLE}"
    
    # Verify signature
    if codesign --verify --deep --strict "${APP_BUNDLE}" 2>/dev/null; then
        print_success "App signed successfully"
        codesign -dv "${APP_BUNDLE}" 2>&1 | grep -E "^(Authority|TeamIdentifier)" | head -2
    else
        print_error "Code signing verification failed!"
        exit 1
    fi
    echo ""
else
    # Just check if certificate exists
    if security find-identity -v -p codesigning | grep -q "Developer ID Application"; then
        print_warning "App is NOT signed. Use -s or --sign to sign the app."
    else
        print_warning "No code signing certificate found"
        print_warning "App will run locally but cannot be distributed"
    fi
    echo ""
fi

# Notarization
if [ "$NOTARIZE" = true ]; then
    print_step "Notarizing app with Apple..."
    echo "    This may take several minutes..."
    
    # Create a ZIP for notarization
    NOTARIZE_ZIP=".build/notarize-${VERSION}.zip"
    ditto -c -k --keepParent "${APP_BUNDLE}" "${NOTARIZE_ZIP}"
    
    # Submit for notarization
    # Note: Requires App Store Connect API key or Apple ID credentials stored in keychain
    # You may need to run: xcrun notarytool store-credentials "notarytool-profile" --apple-id "your@email.com" --team-id "TEAM_ID"
    
    if xcrun notarytool submit "${NOTARIZE_ZIP}" \
        --keychain-profile "notarytool-profile" \
        --wait 2>&1 | tee .build/notarize-log.txt; then
        
        print_success "Notarization submitted successfully"
        
        # Check if accepted
        if grep -q "status: Accepted" .build/notarize-log.txt; then
            print_success "Notarization accepted!"
            
            # Staple the notarization ticket
            print_step "Stapling notarization ticket..."
            if xcrun stapler staple "${APP_BUNDLE}"; then
                print_success "Notarization ticket stapled"
            else
                print_warning "Stapling failed (app still works, just needs internet for first launch)"
            fi
        else
            print_warning "Notarization may have failed. Check .build/notarize-log.txt"
        fi
    else
        print_error "Notarization failed!"
        echo "    Check .build/notarize-log.txt for details"
        echo ""
        echo "    If you haven't set up notarytool credentials, run:"
        echo "    xcrun notarytool store-credentials \"notarytool-profile\" --apple-id \"YOUR_EMAIL\" --team-id \"${TEAM_ID}\""
        echo ""
    fi
    
    # Clean up
    rm -f "${NOTARIZE_ZIP}"
    echo ""
fi

# Create DMG if requested
if [ "$CREATE_DMG" = true ]; then
    print_step "Creating DMG installer with Applications shortcut..."
    DMG_NAME="${APP_NAME}-${VERSION}.dmg"
    DMG_PATH=".build/${DMG_NAME}"
    DMG_TEMP=".build/dmg_temp"
    DMG_TEMP_DMG=".build/temp.dmg"
    
    # Remove old files
    [ -f "$DMG_PATH" ] && rm "$DMG_PATH"
    [ -f "$DMG_TEMP_DMG" ] && rm "$DMG_TEMP_DMG"
    rm -rf "$DMG_TEMP"
    
    # Create temp directory with app and Applications symlink
    mkdir -p "$DMG_TEMP"
    cp -r "${APP_BUNDLE}" "$DMG_TEMP/"
    ln -s /Applications "$DMG_TEMP/Applications"
    
    # Create initial DMG (read-write)
    hdiutil create -volname "${APP_NAME}" -srcfolder "$DMG_TEMP" -ov -format UDRW "$DMG_TEMP_DMG"
    
    # Mount DMG to customize it
    MOUNT_DIR=$(hdiutil attach -readwrite -noverify "$DMG_TEMP_DMG" | grep -E '^\s*/Volumes/' | sed 's/.*\(\/Volumes\/.*\)/\1/')
    
    if [ -n "$MOUNT_DIR" ]; then
        # Set window properties using AppleScript
        osascript << EOF
tell application "Finder"
    tell disk "${APP_NAME}"
        open
        set current view of container window to icon view
        set toolbar visible of container window to false
        set statusbar visible of container window to false
        set bounds of container window to {400, 200, 1000, 600}
        set theViewOptions to the icon view options of container window
        set arrangement of theViewOptions to not arranged
        set icon size of theViewOptions to 100
        
        -- Position icons
        set position of item "${APP_NAME}.app" of container window to {140, 180}
        set position of item "Applications" of container window to {460, 180}
        
        close
        open
        update without registering applications
        delay 1
        close
    end tell
end tell
EOF
        
        # Unmount - try multiple times if needed
        sync
        sleep 2
        hdiutil detach "$MOUNT_DIR" -force 2>/dev/null || true
        sleep 1
    fi
    
    # Ensure no volumes are mounted
    hdiutil detach "/Volumes/${APP_NAME}" -force 2>/dev/null || true
    sleep 1
    
    # Convert to compressed final DMG
    hdiutil convert "$DMG_TEMP_DMG" -format UDZO -o "$DMG_PATH"
    
    # Clean up
    rm -rf "$DMG_TEMP"
    rm -f "$DMG_TEMP_DMG"
    
    if [ -f "$DMG_PATH" ]; then
        # Sign the DMG if we're signing
        if [ "$SIGN_APP" = true ]; then
            print_step "Signing DMG..."
            codesign --force --sign "${DEVELOPER_ID}" "$DMG_PATH"
            print_success "DMG signed"
        fi
        
        print_success "DMG created: $DMG_PATH"
        echo "    ➜ Includes Applications shortcut for easy install"
        if [ "$SIGN_APP" = true ]; then
            echo "    ➜ Signed with Developer ID"
        fi
        if [ "$NOTARIZE" = true ]; then
            echo "    ➜ Contains notarized app"
        fi
    else
        print_error "DMG creation failed"
    fi
    echo ""
fi

# Print summary
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
print_success "Build successful!"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""
echo "📱 App Bundle:"
echo "   ${APP_BUNDLE}"
echo ""
echo "📦 Size:"
du -sh "${APP_BUNDLE}" | awk '{print "   " $1}'
echo ""
echo "ℹ️  Info:"
echo "   Name:    ${APP_NAME}"
echo "   Version: ${VERSION} (${BUILD_NUMBER})"
echo "   Bundle:  ${BUNDLE_ID}"
echo "   Min OS:  macOS ${MIN_MACOS}"
if [ "$SIGN_APP" = true ]; then
    echo "   Signed:  ✅ Yes (Developer ID)"
else
    echo "   Signed:  ❌ No"
fi
if [ "$NOTARIZE" = true ]; then
    echo "   Notarized: ✅ Yes"
fi
echo ""

if [ "$CREATE_DMG" = true ]; then
    echo "💿 DMG Installer:"
    echo "   ${DMG_PATH}"
    du -sh "$DMG_PATH" 2>/dev/null | awk '{print "   Size: " $1}'
    echo ""
fi

echo "🚀 To run:"
echo "   open '${APP_BUNDLE}'"
echo ""
echo "📥 To install:"
echo "   cp -r '${APP_BUNDLE}' /Applications/"
echo ""

if [ "$SIGN_APP" != true ] && [ "$BUILD_CONFIG" = "release" ]; then
    echo "📦 To distribute (not yet signed):"
    echo "   ./build_app.sh --dist    # Full distribution build"
    echo ""
fi

# Open app if requested
if [ "$OPEN_APP" = true ]; then
    print_step "Opening app..."
    killall "${APP_NAME}" 2>/dev/null || true
    sleep 1
    open "${APP_BUNDLE}"
fi

print_success "Done!"
