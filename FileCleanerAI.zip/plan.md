# Implementation Plan: Mole-Inspired Improvements

## Completed (Phase 1)
- [x] Smart App Uninstaller — full app removal with 20+ remnant locations
- [x] System Optimizer — DNS flush, memory purge, Spotlight rebuild, Launch Services, font/icon/QuickLook caches
- [x] Developer Projects View — per-project artifact scanner with staleness detection

## Completed (Phase 2)
- [x] Dry-Run / Preview Mode — DeletionPreviewSheet (SystemDataView only)
- [x] Expanded Browser Support — Firefox, Arc, Brave, Edge
- [x] Homebrew Cleanup — auto-detect, cleanup, autoremove, cache clear
- [x] CoreSimulator / Xcode Deep Clean — 8 categories, simctl integration
- [x] Docker Cleanup — system prune, builder prune
- [x] Scheduled Cleaning — intervals, targets, notifications, threshold alerts

## Phase 3 — Remaining Features

| Step | Feature | Impact | Effort | Status |
|------|---------|--------|--------|--------|
| 1 | Wire DeletionPreviewSheet into all views | High | Low | Done |
| 2 | App Cache Analyzer (per-app cache + recommendations) | Medium | Medium | Done |
| 3 | APFS Snapshot Manager | Medium | Medium | Done |
| 4 | MenuBar Status Icon (quick-access disk health) | Medium | Medium | Done |
| 5 | Export/Import Configuration | Low | Low | Done |

## All features complete.
