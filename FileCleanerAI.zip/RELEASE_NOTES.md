# v1.0.0 - First Public Release

An intelligent macOS file cleaner powered by on-device AI. Reclaim gigabytes of disk space safely.

## Highlights

- 🤖 **On-Device AI** - Intelligent file analysis with Apple FoundationModels
- 🔍 **Smart Detection** - Finds node_modules, build artifacts, caches, temp files
- 🛡️ **Safety Scoring** - High/Medium/Low ratings for each file pattern
- 📊 **Visual Analytics** - Disk usage charts and file groupings
- 💬 **AI Chat** - Ask questions about your files in natural language
- 🗑️ **Safe Deletion** - Moves to Trash, never permanently deletes
- 🔒 **100% Private** - All processing happens locally on your Mac

## Requirements

- macOS 15.0+
- Apple Silicon recommended (M1/M2/M3/M4)

## Installation

1. Download the DMG
2. Drag to Applications
3. Launch and start scanning!

## What's Included

- `AI File Cleaner.app` - The application
- Applications shortcut for easy install

---

**Full Changelog:** [CHANGELOG.md](https://github.com/nicholasareed/FileCleanerAI/blob/main/CHANGELOG.md)
