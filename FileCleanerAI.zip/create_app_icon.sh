#!/bin/bash

# Create macOS app icon (.icns) from logo.svg
# Requires: rsvg-convert (from librsvg) or qlmanage (built-in macOS)

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOGO_SVG="$SCRIPT_DIR/logo.svg"
ICONSET_DIR="$SCRIPT_DIR/AppIcon.iconset"
OUTPUT_ICNS="$SCRIPT_DIR/FileCleanerAI/AppIcon.icns"

echo "🎨 Creating macOS app icon from logo.svg..."

# Create iconset directory
rm -rf "$ICONSET_DIR"
mkdir -p "$ICONSET_DIR"

# Check if rsvg-convert is available (better quality)
if command -v rsvg-convert &> /dev/null; then
    echo "Using rsvg-convert for high-quality rendering..."
    
    # Generate all required sizes
    rsvg-convert -w 16 -h 16 "$LOGO_SVG" > "$ICONSET_DIR/icon_16x16.png"
    rsvg-convert -w 32 -h 32 "$LOGO_SVG" > "$ICONSET_DIR/icon_16x16@2x.png"
    rsvg-convert -w 32 -h 32 "$LOGO_SVG" > "$ICONSET_DIR/icon_32x32.png"
    rsvg-convert -w 64 -h 64 "$LOGO_SVG" > "$ICONSET_DIR/icon_32x32@2x.png"
    rsvg-convert -w 128 -h 128 "$LOGO_SVG" > "$ICONSET_DIR/icon_128x128.png"
    rsvg-convert -w 256 -h 256 "$LOGO_SVG" > "$ICONSET_DIR/icon_128x128@2x.png"
    rsvg-convert -w 256 -h 256 "$LOGO_SVG" > "$ICONSET_DIR/icon_256x256.png"
    rsvg-convert -w 512 -h 512 "$LOGO_SVG" > "$ICONSET_DIR/icon_256x256@2x.png"
    rsvg-convert -w 512 -h 512 "$LOGO_SVG" > "$ICONSET_DIR/icon_512x512.png"
    rsvg-convert -w 1024 -h 1024 "$LOGO_SVG" > "$ICONSET_DIR/icon_512x512@2x.png"
    
elif command -v sips &> /dev/null; then
    echo "Using sips (macOS built-in)..."
    
    # First, create a high-res PNG using qlmanage or Safari
    # We'll use a workaround with sips if available
    
    # Check if we can use qlmanage to render SVG
    if command -v qlmanage &> /dev/null; then
        # Create a temporary 1024px PNG
        TEMP_PNG="$SCRIPT_DIR/temp_icon_1024.png"
        
        # Use qlmanage to generate a preview (works for SVG on macOS)
        qlmanage -t -s 1024 -o "$SCRIPT_DIR" "$LOGO_SVG" 2>/dev/null || true
        
        # qlmanage outputs as logo.svg.png
        if [ -f "$SCRIPT_DIR/logo.svg.png" ]; then
            mv "$SCRIPT_DIR/logo.svg.png" "$TEMP_PNG"
        else
            echo "⚠️  Could not render SVG. Please install librsvg:"
            echo "   brew install librsvg"
            exit 1
        fi
        
        # Generate all sizes from the 1024px PNG
        sips -z 16 16 "$TEMP_PNG" --out "$ICONSET_DIR/icon_16x16.png"
        sips -z 32 32 "$TEMP_PNG" --out "$ICONSET_DIR/icon_16x16@2x.png"
        sips -z 32 32 "$TEMP_PNG" --out "$ICONSET_DIR/icon_32x32.png"
        sips -z 64 64 "$TEMP_PNG" --out "$ICONSET_DIR/icon_32x32@2x.png"
        sips -z 128 128 "$TEMP_PNG" --out "$ICONSET_DIR/icon_128x128.png"
        sips -z 256 256 "$TEMP_PNG" --out "$ICONSET_DIR/icon_128x128@2x.png"
        sips -z 256 256 "$TEMP_PNG" --out "$ICONSET_DIR/icon_256x256.png"
        sips -z 512 512 "$TEMP_PNG" --out "$ICONSET_DIR/icon_256x256@2x.png"
        sips -z 512 512 "$TEMP_PNG" --out "$ICONSET_DIR/icon_512x512.png"
        cp "$TEMP_PNG" "$ICONSET_DIR/icon_512x512@2x.png"
        
        rm -f "$TEMP_PNG"
    fi
else
    echo "❌ No suitable SVG converter found."
    echo "   Please install librsvg: brew install librsvg"
    exit 1
fi

# Create the .icns file
echo "📦 Creating .icns file..."
iconutil -c icns "$ICONSET_DIR" -o "$OUTPUT_ICNS"

# Clean up
rm -rf "$ICONSET_DIR"

echo "✅ App icon created: $OUTPUT_ICNS"
echo ""
echo "The icon will be included in the next build."
