# Mole Project Analysis & Enhancement Plan

## Project Overview

**Mole** is a popular macOS CLI tool (32k+ GitHub stars) that combines functionality of CleanMyMac, AppCleaner, DaisyDisk, and iStat Menus into a single binary.

- **Languages**: Shell (80%) + Go (20%)
- **License**: MIT
- **Commands**: `mo clean`, `mo uninstall`, `mo optimize`, `mo analyze`, `mo status`, `mo purge`

---

## 1. IMPROVEMENTS

### 1.1 Code Architecture Improvements

| Area | Current State | Improvement |
|------|---------------|-------------|
| **Module Loading** | Sequential sourcing of shell modules | Implement lazy loading - only source modules when command is used |
| **Error Handling** | Basic `set -euo pipefail` | Add structured error types with recovery suggestions |
| **Configuration** | Hardcoded paths/values | Centralize in a config module with user overrides (`~/.config/mole/config.sh`) |
| **Logging** | File-based logging | Add log levels (DEBUG/INFO/WARN/ERROR) with optional JSON output for parsing |

### 1.2 Clean Module Improvements

```bash
# Current: Fixed age thresholds
MOLE_TEMP_FILE_AGE_DAYS=7
MOLE_LOG_AGE_DAYS=14

# Improvement: User-configurable with smart defaults
# Add to ~/.config/mole/config.sh
MOLE_TEMP_FILE_AGE_DAYS="${MOLE_TEMP_FILE_AGE_DAYS:-7}"
MOLE_LOG_AGE_DAYS="${MOLE_LOG_AGE_DAYS:-14}"
MOLE_CACHE_AGE_DAYS="${MOLE_CACHE_AGE_DAYS:-30}"
```

**Additional clean improvements:**
- Add pattern-based exclusions (regex support for whitelist)
- Improve browser detection (add Arc, Brave, Vivaldi, Opera)
- Add iCloud Drive cache cleanup
- Add Xcode derived data with version awareness (keep current SDK caches)

### 1.3 Uninstall Module Improvements

- **Current limitation**: Uses hardcoded list of known app remnant paths
- **Improvement**: Implement receipt-based detection using `pkgutil` records
- **Add**: Launch agent/daemon detection in `/Library/LaunchAgents`, `/Library/LaunchDaemons`
- **Add**: Kernel extension detection in `/Library/Extensions`

```bash
# Example: Query pkg receipts for app-related files
pkgutil --files "com.adobe.pkg.Photoshop2024" 2>/dev/null
```

### 1.4 Status Module Improvements

- Add disk health monitoring (S.M.A.R.T. status via `diskutil info`)
- Add thermal throttling detection
- Improve health score algorithm with weighted factors
- Add historical tracking (store metrics for trend analysis)

### 1.5 Analyze Module (Go) Improvements

```go
// Current: Fixed large file threshold
largeFileMinSize := int64(largeFileWarmupMinSize)

// Improvement: Dynamic threshold based on disk size
func calculateLargeFileThreshold(diskSize int64) int64 {
    switch {
    case diskSize > 2*TB:
        return 500 * MB  // 500MB+ on 2TB+ drives
    case diskSize > 500*GB:
        return 100 * MB  // 100MB+ on 500GB+ drives
    default:
        return 50 * MB   // 50MB+ on smaller drives
    }
}
```

---

## 2. NEW FEATURES

### 2.1 Scheduled Cleaning (High Priority)

Add a scheduling system for automated cleanup:

```bash
mo schedule clean --daily          # Run daily at 3am
mo schedule clean --weekly         # Run weekly on Sunday
mo schedule status                 # Show scheduled jobs
mo schedule remove clean           # Remove schedule

# Implementation: Use launchd plist
# ~/Library/LaunchAgents/com.tw93.mole.clean.plist
```

### 2.2 Duplicate File Finder (High Priority)

```bash
mo duplicates                      # Find duplicate files
mo duplicates --min-size 10MB      # Only files >= 10MB
mo duplicates --path ~/Documents   # Specific directory
mo duplicates --dry-run            # Preview only

# Algorithm:
# 1. Group by file size (fast filter)
# 2. Compare first 4KB of files with same size
# 3. Full hash comparison for candidates
# 4. Present grouped results with actions
```

### 2.3 App Cache Analyzer (Medium Priority)

Show per-app cache usage with intelligent suggestions:

```bash
mo cache-audit

╔═══════════════════════════════════════════════════════════════════╗
║ App Cache Usage Analysis                                          ║
╠═══════════════════════════════════════════════════════════════════╣
║ App                    Cache    Last Used  Recommendation         ║
╠═══════════════════════════════════════════════════════════════════╣
║ Xcode                  45.2GB   2 days     Keep (active dev)      ║
║ Chrome                 8.3GB    < 1 day    Cleanup (safe)         ║
║ Slack                  2.1GB    30+ days   Remove (stale)         ║
║ Photoshop 2023         4.8GB    90+ days   Remove (unused app)    ║
╚═══════════════════════════════════════════════════════════════════╝
```

### 2.4 Network Cache/Proxy Cleanup (Medium Priority)

```bash
mo clean --network

# Cleans:
# - DNS cache (dscacheutil -flushcache)
# - Proxy pac cache
# - mDNSResponder cache
# - Network preferences cache
# - VPN certificates (with confirmation)
```

### 2.5 Snapshot Manager (Medium Priority)

APFS snapshot management:

```bash
mo snapshots                       # List APFS snapshots
mo snapshots --cleanup             # Remove old snapshots
mo snapshots --before 2024-01-01   # Remove snapshots before date

# Uses: tmutil listlocalsnapshotdates / thinlocalsnapshots
```

### 2.6 Privacy Cleaner (Low Priority)

```bash
mo privacy

# Cleans:
# - Recent documents lists
# - Recent app usage data
# - Spotlight suggestions cache
# - Siri suggestions data
# - Location services history
# - Diagnostic & usage data
```

### 2.7 Startup Optimizer (Low Priority)

```bash
mo startup                         # Analyze startup items
mo startup --disable AppName       # Disable startup item
mo startup --enable AppName        # Re-enable startup item

# Analyzes:
# - Login items (~/Library/LaunchAgents)
# - System agents (/Library/LaunchAgents)
# - Daemons (/Library/LaunchDaemons)
# - Shows CPU/memory impact of each
```

### 2.8 Export/Import Configuration

```bash
mo config export > mole-config.json
mo config import mole-config.json

# Exports:
# - Whitelist rules
# - Schedule settings
# - Custom thresholds
# - Scan paths for purge
```

---

## 3. PERFORMANCE OPTIMIZATIONS

### 3.1 Parallel File Scanning (High Impact)

**Current**: Sequential scanning in shell scripts
**Improvement**: Parallel scanning with worker pools

```bash
# Current approach
while IFS= read -r -d '' file; do
    process_file "$file"
done < <(find ...)

# Optimized approach using GNU parallel or xargs
find ... -print0 | xargs -0 -P $(nproc) -I {} bash -c 'process_file "$@"' _ {}

# Or native bash with job control
MAX_JOBS=8
for file in "${files[@]}"; do
    ((++job_count > MAX_JOBS)) && wait -n
    process_file "$file" &
done
wait
```

### 3.2 Cached Disk Metadata (High Impact)

Cache expensive operations:

```bash
# Cache directory sizes (expires after 5 minutes)
CACHE_DIR="$HOME/.cache/mole"
CACHE_TTL=300

get_cached_size() {
    local path="$1"
    local cache_file="$CACHE_DIR/sizes/$(echo -n "$path" | md5)"

    if [[ -f "$cache_file" ]]; then
        local age=$(($(date +%s) - $(stat -f%m "$cache_file")))
        if ((age < CACHE_TTL)); then
            cat "$cache_file"
            return
        fi
    fi

    local size=$(du -sk "$path" 2>/dev/null | cut -f1)
    echo "$size" > "$cache_file"
    echo "$size"
}
```

### 3.3 Go Scanner Optimizations (High Impact)

```go
// Current: Single singleflight group
var scanGroup singleflight.Group

// Improvement: Add caching layer with TTL
type CachedScanner struct {
    cache    *sync.Map
    cacheTTL time.Duration
}

type cachedResult struct {
    result    scanResult
    timestamp time.Time
}

func (s *CachedScanner) Scan(path string) (scanResult, error) {
    // Check cache first
    if cached, ok := s.cache.Load(path); ok {
        cr := cached.(cachedResult)
        if time.Since(cr.timestamp) < s.cacheTTL {
            return cr.result, nil
        }
    }

    // Scan and cache
    result, err := scanPathConcurrent(path, ...)
    if err == nil {
        s.cache.Store(path, cachedResult{result, time.Now()})
    }
    return result, err
}
```

### 3.4 Reduce System Calls (Medium Impact)

**Current**: Multiple stat calls per file
**Improvement**: Batch resource value retrieval

```go
// Current: Multiple operations
info, _ := os.Stat(path)
isDir := info.IsDir()
size := info.Size()
mtime := info.ModTime()

// Optimized: Single syscall with all attributes
func getFileAttributes(path string) (isDir bool, size int64, mtime time.Time, err error) {
    var stat syscall.Stat_t
    if err := syscall.Lstat(path, &stat); err != nil {
        return false, 0, time.Time{}, err
    }

    isDir = stat.Mode&syscall.S_IFDIR != 0
    size = stat.Size
    mtime = time.Unix(stat.Mtimespec.Sec, stat.Mtimespec.Nsec)
    return
}
```

### 3.5 Smart Skip Patterns (Medium Impact)

Skip known large/uncleanable directories early:

```bash
# Add to file_ops.sh
SKIP_PATTERNS=(
    ".git/objects"
    "node_modules/.cache"
    ".npm/_cacache"
    "Library/Application Support/MobileSync"  # iOS backups
    "Library/Developer/CoreSimulator"          # iOS simulators
)

should_skip() {
    local path="$1"
    for pattern in "${SKIP_PATTERNS[@]}"; do
        [[ "$path" == *"$pattern"* ]] && return 0
    done
    return 1
}
```

### 3.6 Memory-Efficient Large Directory Handling

```go
// Current: Load all entries into memory
children, err := os.ReadDir(root)

// Improvement: Stream-based iteration for huge directories
func streamDir(path string, handler func(fs.DirEntry) error) error {
    f, err := os.Open(path)
    if err != nil {
        return err
    }
    defer f.Close()

    for {
        entries, err := f.ReadDir(1000) // Read in batches
        if err == io.EOF {
            break
        }
        if err != nil {
            return err
        }

        for _, entry := range entries {
            if err := handler(entry); err != nil {
                return err
            }
        }
    }
    return nil
}
```

### 3.7 Incremental Scanning

Track changes since last scan instead of full rescan:

```bash
# Use FSEvents or kqueue for macOS
# Store last scan timestamp
LAST_SCAN_FILE="$HOME/.cache/mole/last_scan"

get_changed_files() {
    local since=$(cat "$LAST_SCAN_FILE" 2>/dev/null || echo "1970-01-01")
    find "$1" -newer "$LAST_SCAN_FILE" -type f 2>/dev/null
}
```

### 3.8 Lazy UI Updates

```go
// Current: Update UI on every file
currentPath.Store(fullPath)

// Improvement: Throttled updates (every 100ms)
type ThrottledUpdater struct {
    value    atomic.Value
    lastSent time.Time
    mu       sync.Mutex
    interval time.Duration
}

func (u *ThrottledUpdater) Update(path string) {
    u.value.Store(path)

    u.mu.Lock()
    defer u.mu.Unlock()

    if time.Since(u.lastSent) > u.interval {
        // Actually update UI
        u.lastSent = time.Now()
    }
}
```

---

## 4. IMPLEMENTATION PRIORITY

### Phase 1 (Quick Wins)
1. Configuration file support
2. Parallel file scanning in shell
3. Go scanner caching
4. Additional browser support

### Phase 2 (Medium Effort)
1. Duplicate file finder
2. Scheduled cleaning
3. Cache analyzer
4. Incremental scanning

### Phase 3 (Larger Features)
1. Snapshot manager
2. Privacy cleaner
3. Startup optimizer
4. Historical metrics tracking

---

## 5. COMPARISON WITH FileCleanerAI

| Feature | Mole | FileCleanerAI |
|---------|------|---------------|
| Interface | CLI | Native macOS GUI |
| Scanning | Shell + Go hybrid | Pure Swift with async/await |
| Size Calculation | `du` + Go concurrent scan | URLResourceKey with sampling + extrapolation |
| Priority Queue | N/A | High/low priority with smart batching |
| Cancel Support | Ctrl+C only | Per-operation cancellation |
| Memory Monitoring | `mo status` real-time | DebugView with system metrics |
| Symlink Handling | Basic | Full detection to prevent double-counting |

### Ideas to Port from FileCleanerAI to Mole:
1. **Smart size estimation** - Sample + extrapolate for huge directories
2. **Priority queue system** - Prioritize current folder calculations
3. **Per-operation cancellation** - Instead of just Ctrl+C
4. **Symlink awareness** - Prevent double-counting linked directories

### Ideas to Port from Mole to FileCleanerAI:
1. **Health score algorithm** - Weighted system health metric
2. **Interactive TUI** - Vim-style navigation in file lists
3. **Project artifact purge** - Language-specific build cache cleanup
4. **Whitelist management** - User-defined protection rules

---

## Summary

Mole is a well-designed CLI tool with good architecture. The main opportunities are:

1. **Performance**: Add parallel processing, caching, and incremental scanning
2. **Features**: Duplicate finder, scheduling, and deeper privacy cleaning
3. **UX**: Better configuration management and error recovery
4. **Integration**: Ideas can flow both ways between Mole and FileCleanerAI
