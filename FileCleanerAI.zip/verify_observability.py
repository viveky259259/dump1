#!/usr/bin/env python3
"""
AI Verification Module for FileCleanerAI

This module provides programmatic access to observability data for AI agents
to verify that the app works correctly.

Usage:
    python3 verify_observability.py [command] [options]

Commands:
    check           Run all verification checks
    events          List all events
    errors          Show only error events
    metrics         Show metrics summary
    trace <id>      Show events for a specific trace
    wait            Wait for specific events to appear
    watch           Continuously watch for new events

Examples:
    python3 verify_observability.py check
    python3 verify_observability.py events --type scan_completed
    python3 verify_observability.py wait --event app_launched --timeout 10
"""

import json
import os
import sys
import time
import argparse
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

# Default log file location
DEFAULT_LOG_FILE = os.path.join(os.environ.get('TMPDIR', '/tmp'), 'filecleaner_observability.jsonl')


class VerificationStatus(Enum):
    PASS = "pass"
    FAIL = "fail"
    WARN = "warn"
    SKIP = "skip"


@dataclass
class VerificationResult:
    name: str
    status: VerificationStatus
    message: str
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "name": self.name,
            "status": self.status.value,
            "message": self.message
        }
        if self.details:
            result["details"] = self.details
        return result


class ObservabilityReader:
    """Reads and parses observability log files."""

    def __init__(self, log_file: str = DEFAULT_LOG_FILE):
        self.log_file = log_file
        self._events: List[Dict[str, Any]] = []
        self._last_read_pos = 0

    def read_events(self, refresh: bool = False) -> List[Dict[str, Any]]:
        """Read all events from the log file."""
        if refresh or not self._events:
            self._events = []
            self._last_read_pos = 0

        if not os.path.exists(self.log_file):
            return self._events

        with open(self.log_file, 'r') as f:
            f.seek(self._last_read_pos)
            for line in f:
                line = line.strip()
                if line:
                    try:
                        event = json.loads(line)
                        self._events.append(event)
                    except json.JSONDecodeError:
                        pass
            self._last_read_pos = f.tell()

        return self._events

    def get_events_by_type(self, event_type: str) -> List[Dict[str, Any]]:
        """Get all events of a specific type."""
        events = self.read_events()
        return [e for e in events if e.get('event') == event_type]

    def get_events_by_component(self, component: str) -> List[Dict[str, Any]]:
        """Get all events from a specific component."""
        events = self.read_events()
        return [e for e in events if e.get('component') == component]

    def get_events_by_status(self, status: str) -> List[Dict[str, Any]]:
        """Get all events with a specific status."""
        events = self.read_events()
        return [e for e in events if e.get('status') == status]

    def get_trace_events(self, trace_id: str) -> List[Dict[str, Any]]:
        """Get all events for a specific trace."""
        events = self.read_events()
        return [e for e in events if e.get('traceId') == trace_id]

    def get_errors(self) -> List[Dict[str, Any]]:
        """Get all error events."""
        return self.get_events_by_status('failure')

    def get_metrics(self) -> Dict[str, float]:
        """Get the latest metrics from all events."""
        events = self.read_events()
        metrics = {}
        for event in events:
            if 'metrics' in event and event['metrics']:
                metrics.update(event['metrics'])
        return metrics

    def has_event(self, event_type: str) -> bool:
        """Check if an event type exists."""
        return len(self.get_events_by_type(event_type)) > 0

    def wait_for_event(self, event_type: str, timeout: float = 30.0, poll_interval: float = 0.5) -> Optional[Dict[str, Any]]:
        """Wait for a specific event to appear."""
        start_time = time.time()
        while time.time() - start_time < timeout:
            events = self.get_events_by_type(event_type)
            if events:
                return events[-1]  # Return the latest
            time.sleep(poll_interval)
            self.read_events(refresh=True)
        return None


class AppVerifier:
    """Verifies that the app is working correctly based on observability data."""

    def __init__(self, reader: ObservabilityReader):
        self.reader = reader
        self.results: List[VerificationResult] = []

    def check_app_launched(self) -> VerificationResult:
        """Verify the app launched successfully."""
        events = self.reader.get_events_by_type('app_launched')
        if events:
            success_events = [e for e in events if e.get('status') == 'success']
            if success_events:
                return VerificationResult(
                    name="app_launched",
                    status=VerificationStatus.PASS,
                    message="App launched successfully",
                    details={"event_count": len(success_events)}
                )
            else:
                return VerificationResult(
                    name="app_launched",
                    status=VerificationStatus.FAIL,
                    message="App launched but with non-success status",
                    details={"events": events}
                )
        return VerificationResult(
            name="app_launched",
            status=VerificationStatus.FAIL,
            message="No app_launched event found"
        )

    def check_no_errors(self) -> VerificationResult:
        """Verify there are no error events."""
        errors = self.reader.get_errors()
        if not errors:
            return VerificationResult(
                name="no_errors",
                status=VerificationStatus.PASS,
                message="No error events found"
            )
        return VerificationResult(
            name="no_errors",
            status=VerificationStatus.FAIL,
            message=f"Found {len(errors)} error event(s)",
            details={"errors": errors}
        )

    def check_view_rendered(self) -> VerificationResult:
        """Verify that views rendered successfully."""
        events = self.reader.get_events_by_type('view_appeared')
        if events:
            views = [e.get('details', {}).get('view', e.get('component')) for e in events]
            return VerificationResult(
                name="view_rendered",
                status=VerificationStatus.PASS,
                message=f"Views rendered: {', '.join(set(views))}",
                details={"views": list(set(views))}
            )
        return VerificationResult(
            name="view_rendered",
            status=VerificationStatus.WARN,
            message="No view_appeared events found (UI may not have fully loaded)"
        )

    def check_scan_flow(self) -> VerificationResult:
        """Verify a complete scan flow if it occurred."""
        started = self.reader.get_events_by_type('scan_started')
        completed = self.reader.get_events_by_type('scan_completed')

        if not started and not completed:
            return VerificationResult(
                name="scan_flow",
                status=VerificationStatus.SKIP,
                message="No scan was initiated"
            )

        if started and not completed:
            return VerificationResult(
                name="scan_flow",
                status=VerificationStatus.FAIL,
                message="Scan started but did not complete",
                details={"started": started}
            )

        if started and completed:
            latest_completed = completed[-1]
            metrics = latest_completed.get('metrics', {})
            return VerificationResult(
                name="scan_flow",
                status=VerificationStatus.PASS,
                message=f"Scan completed successfully",
                details={
                    "files_found": metrics.get('files_found', 0),
                    "duration_ms": metrics.get('scan_duration_ms', 0)
                }
            )

        return VerificationResult(
            name="scan_flow",
            status=VerificationStatus.WARN,
            message="Unexpected scan state"
        )

    def check_valid_json(self) -> VerificationResult:
        """Verify all log entries are valid JSON."""
        if not os.path.exists(self.reader.log_file):
            return VerificationResult(
                name="valid_json",
                status=VerificationStatus.FAIL,
                message="Log file not found"
            )

        valid_count = 0
        invalid_count = 0
        invalid_lines = []

        with open(self.reader.log_file, 'r') as f:
            for i, line in enumerate(f, 1):
                line = line.strip()
                if line:
                    try:
                        json.loads(line)
                        valid_count += 1
                    except json.JSONDecodeError as e:
                        invalid_count += 1
                        invalid_lines.append({"line": i, "error": str(e)})

        if invalid_count == 0 and valid_count > 0:
            return VerificationResult(
                name="valid_json",
                status=VerificationStatus.PASS,
                message=f"All {valid_count} log lines are valid JSON"
            )
        elif invalid_count > 0:
            return VerificationResult(
                name="valid_json",
                status=VerificationStatus.FAIL,
                message=f"Found {invalid_count} invalid JSON lines",
                details={"invalid_lines": invalid_lines[:5]}  # Show first 5
            )
        else:
            return VerificationResult(
                name="valid_json",
                status=VerificationStatus.WARN,
                message="Log file is empty"
            )

    def run_all_checks(self) -> List[VerificationResult]:
        """Run all verification checks."""
        self.results = [
            self.check_valid_json(),
            self.check_app_launched(),
            self.check_view_rendered(),
            self.check_no_errors(),
            self.check_scan_flow(),
        ]
        return self.results

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of verification results."""
        if not self.results:
            self.run_all_checks()

        passed = sum(1 for r in self.results if r.status == VerificationStatus.PASS)
        failed = sum(1 for r in self.results if r.status == VerificationStatus.FAIL)
        warned = sum(1 for r in self.results if r.status == VerificationStatus.WARN)
        skipped = sum(1 for r in self.results if r.status == VerificationStatus.SKIP)

        overall = VerificationStatus.PASS if failed == 0 else VerificationStatus.FAIL

        return {
            "overall": overall.value,
            "passed": passed,
            "failed": failed,
            "warned": warned,
            "skipped": skipped,
            "total": len(self.results),
            "checks": [r.to_dict() for r in self.results],
            "log_file": self.reader.log_file,
            "timestamp": datetime.now().isoformat()
        }


def format_event(event: Dict[str, Any], verbose: bool = False) -> str:
    """Format an event for display."""
    status_icons = {
        "success": "✅",
        "failure": "❌",
        "in_progress": "🔄",
        "warning": "⚠️",
        "info": "ℹ️"
    }

    icon = status_icons.get(event.get('status', ''), "•")
    timestamp = event.get('timestamp', '')[:19]  # Trim to seconds
    component = event.get('component', 'Unknown')
    event_type = event.get('event', 'unknown')

    line = f"{icon} [{timestamp}] [{component}] {event_type}"

    if verbose:
        if event.get('details'):
            details = ', '.join(f"{k}={v}" for k, v in event['details'].items())
            line += f"\n   Details: {details}"
        if event.get('metrics'):
            metrics = ', '.join(f"{k}={v:.2f}" for k, v in event['metrics'].items())
            line += f"\n   Metrics: {metrics}"
        if event.get('traceId'):
            line += f"\n   Trace: {event['traceId'][:8]}..."

    return line


def cmd_check(args):
    """Run verification checks."""
    reader = ObservabilityReader(args.log_file)
    verifier = AppVerifier(reader)
    summary = verifier.get_summary()

    if args.json:
        print(json.dumps(summary, indent=2))
    else:
        print("\n" + "=" * 50)
        print("  FileCleanerAI Verification Results")
        print("=" * 50 + "\n")

        for result in verifier.results:
            icon = {"pass": "✅", "fail": "❌", "warn": "⚠️", "skip": "⏭️"}[result.status.value]
            print(f"{icon} {result.name}: {result.message}")
            if args.verbose and result.details:
                for k, v in result.details.items():
                    print(f"   {k}: {v}")

        print("\n" + "-" * 50)
        print(f"Overall: {summary['overall'].upper()}")
        print(f"Passed: {summary['passed']}, Failed: {summary['failed']}, Warnings: {summary['warned']}, Skipped: {summary['skipped']}")
        print(f"Log file: {summary['log_file']}")
        print("-" * 50 + "\n")

    return 0 if summary['failed'] == 0 else 1


def cmd_events(args):
    """List events."""
    reader = ObservabilityReader(args.log_file)
    events = reader.read_events()

    if args.type:
        events = [e for e in events if e.get('event') == args.type]
    if args.component:
        events = [e for e in events if e.get('component') == args.component]
    if args.status:
        events = [e for e in events if e.get('status') == args.status]

    if args.json:
        print(json.dumps(events, indent=2))
    else:
        if not events:
            print("No events found")
            return 0

        for event in events:
            print(format_event(event, args.verbose))
            if args.verbose:
                print()

    return 0


def cmd_errors(args):
    """Show error events."""
    reader = ObservabilityReader(args.log_file)
    errors = reader.get_errors()

    if args.json:
        print(json.dumps(errors, indent=2))
    else:
        if not errors:
            print("✅ No errors found")
            return 0

        print(f"❌ Found {len(errors)} error(s):\n")
        for error in errors:
            print(format_event(error, verbose=True))
            print()

    return 1 if errors else 0


def cmd_metrics(args):
    """Show metrics."""
    reader = ObservabilityReader(args.log_file)
    metrics = reader.get_metrics()

    if args.json:
        print(json.dumps(metrics, indent=2))
    else:
        if not metrics:
            print("No metrics found")
            return 0

        print("\nCurrent Metrics:")
        print("-" * 40)
        for name, value in sorted(metrics.items()):
            print(f"  {name}: {value:.2f}")
        print("-" * 40)

    return 0


def cmd_wait(args):
    """Wait for an event."""
    reader = ObservabilityReader(args.log_file)
    print(f"Waiting for event '{args.event}' (timeout: {args.timeout}s)...")

    event = reader.wait_for_event(args.event, timeout=args.timeout)

    if event:
        print(f"✅ Event received:")
        if args.json:
            print(json.dumps(event, indent=2))
        else:
            print(format_event(event, verbose=True))
        return 0
    else:
        print(f"❌ Timeout waiting for event '{args.event}'")
        return 1


def cmd_watch(args):
    """Watch for new events."""
    reader = ObservabilityReader(args.log_file)
    print(f"Watching {args.log_file} for new events (Ctrl+C to stop)...\n")

    try:
        while True:
            events = reader.read_events(refresh=True)
            if events:
                for event in events[-10:]:  # Show last 10 new events
                    print(format_event(event, args.verbose))
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nStopped watching.")
        return 0


def main():
    parser = argparse.ArgumentParser(
        description="AI Verification Module for FileCleanerAI",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('--log-file', default=DEFAULT_LOG_FILE,
                        help=f"Path to log file (default: {DEFAULT_LOG_FILE})")
    parser.add_argument('--json', action='store_true',
                        help="Output as JSON")
    parser.add_argument('--verbose', '-v', action='store_true',
                        help="Verbose output")

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # check command
    check_parser = subparsers.add_parser('check', help='Run verification checks')

    # events command
    events_parser = subparsers.add_parser('events', help='List events')
    events_parser.add_argument('--type', help='Filter by event type')
    events_parser.add_argument('--component', help='Filter by component')
    events_parser.add_argument('--status', help='Filter by status')

    # errors command
    errors_parser = subparsers.add_parser('errors', help='Show error events')

    # metrics command
    metrics_parser = subparsers.add_parser('metrics', help='Show metrics')

    # wait command
    wait_parser = subparsers.add_parser('wait', help='Wait for an event')
    wait_parser.add_argument('--event', required=True, help='Event type to wait for')
    wait_parser.add_argument('--timeout', type=float, default=30.0, help='Timeout in seconds')

    # watch command
    watch_parser = subparsers.add_parser('watch', help='Watch for new events')

    args = parser.parse_args()

    if args.command == 'check':
        return cmd_check(args)
    elif args.command == 'events':
        return cmd_events(args)
    elif args.command == 'errors':
        return cmd_errors(args)
    elif args.command == 'metrics':
        return cmd_metrics(args)
    elif args.command == 'wait':
        return cmd_wait(args)
    elif args.command == 'watch':
        return cmd_watch(args)
    else:
        # Default to check
        args.command = 'check'
        return cmd_check(args)


if __name__ == '__main__':
    sys.exit(main())
