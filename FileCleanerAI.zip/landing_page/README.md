# FileCleanerAI Landing Page

A beautiful, modern landing page for FileCleanerAI built with [Jaspr](https://jaspr.site) - the web framework for Dart developers.

## Features

- Modern, responsive design with mobile support
- Built entirely with Dart and Jaspr
- CSS-in-Dart styling system
- Static site generation for fast loading
- SEO optimized with meta tags

## Preview

The landing page includes:
- **Hero Section** - Eye-catching intro with app mockup
- **Features Section** - 6 key features in a responsive grid
- **How It Works** - 4-step process explanation
- **What It Finds** - Categories of files the app detects
- **Privacy & Safety** - Trust-building section
- **CTA Section** - Download call-to-action with stats
- **Footer** - Links and branding

## Getting Started

### Prerequisites

- Dart SDK 3.0+
- Jaspr CLI

### Installation

1. Install the Jaspr CLI:

```bash
dart pub global activate jaspr_cli
```

2. Install dependencies:

```bash
cd landing_page
dart pub get
```

### Development

Run the development server with hot reload:

```bash
jaspr serve
```

The site will be available at `http://localhost:8080`.

### Build for Production

Generate static files:

```bash
jaspr build
```

The built files will be in the `build/jaspr` directory, ready to deploy to any static hosting service.

## Project Structure

```
landing_page/
├── lib/
│   ├── main.server.dart              # App entry point
│   ├── app.dart                      # Main app component with global styles
│   ├── components/
│   │   ├── hero_section.dart         # Hero with logo, tagline, mockup
│   │   ├── features_section.dart     # 6-feature grid
│   │   ├── how_it_works_section.dart # 4-step process
│   │   ├── what_it_finds_section.dart# File category cards
│   │   ├── privacy_section.dart      # Privacy & safety features
│   │   ├── cta_section.dart          # Download CTA with stats
│   │   └── footer.dart               # Footer with links
│   └── styles/
│       └── theme.dart                # Theme colors & constants
├── web/
│   └── assets/
│       ├── logo.svg                  # App logo
│       └── favicon.svg               # Favicon
├── build/
│   └── jaspr/                        # Built static files
├── pubspec.yaml                      # Dependencies
└── analysis_options.yaml             # Dart linting
```

## Deployment

The landing page can be deployed to any static hosting service:

### GitHub Pages
```bash
jaspr build
# Copy build/jaspr contents to gh-pages branch
```

### Vercel/Netlify
- Connect your repo
- Set build command: `dart pub global activate jaspr_cli && jaspr build`
- Set output directory: `build/jaspr`

### Firebase Hosting
```bash
jaspr build
firebase deploy --only hosting
```

## Customization

### Colors

Edit `lib/styles/theme.dart` to change the color scheme:

```dart
static const Color primary = Color('#3498DB');
static const Color accent = Color('#9B59B6');
```

### Content

Each section is a separate component in `lib/components/`. Edit the content directly in the component files.

### Adding Sections

1. Create a new component file in `lib/components/`
2. Import and add it to `lib/app.dart`

## Tech Stack

- **Jaspr 0.22.0** - Dart web framework
- **Static Mode** - Pre-rendered HTML for performance
- **CSS-in-Dart** - Type-safe styling with `@css` annotation
- **Google Fonts** - Inter font family

## License

MIT License - Same as the main FileCleanerAI project.
