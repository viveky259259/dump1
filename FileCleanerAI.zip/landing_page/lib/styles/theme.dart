import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';

/// App-wide theme colors and constants
class AppTheme {
  AppTheme._();

  // Primary colors
  static const Color primary = Color('#3498DB');
  static const Color primaryDark = Color('#2980B9');
  static const Color primaryLight = Color('#5DADE2');

  // Accent colors
  static const Color accent = Color('#9B59B6');
  static const Color accentLight = Color('#BB8FCE');

  // Status colors
  static const Color success = Color('#27AE60');
  static const Color warning = Color('#F39C12');
  static const Color danger = Color('#E74C3C');

  // Safety score colors
  static const Color safetyHigh = Color('#27AE60');
  static const Color safetyMedium = Color('#F39C12');
  static const Color safetyLow = Color('#E74C3C');

  // Neutral colors
  static const Color background = Color('#FAFBFC');
  static const Color surface = Color('#FFFFFF');
  static const Color surfaceAlt = Color('#F5F7FA');
  static const Color border = Color('#E1E8ED');

  // Text colors
  static const Color textPrimary = Color('#1A1A2E');
  static const Color textSecondary = Color('#6C757D');
  static const Color textMuted = Color('#9CA3AF');

  // Gradients (as CSS strings)
  static const String gradientPrimary =
      'linear-gradient(135deg, #3498DB 0%, #9B59B6 100%)';
  static const String gradientHero =
      'linear-gradient(180deg, #FAFBFC 0%, #EBF5FB 100%)';
  static const String gradientCard =
      'linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)';

  // Shadows
  static const String shadowSm = '0 1px 2px rgba(0, 0, 0, 0.05)';
  static const String shadowMd =
      '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)';
  static const String shadowLg =
      '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1)';
  static const String shadowXl =
      '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)';
}
