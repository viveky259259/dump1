import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import 'components/hero_section.dart';
import 'components/features_section.dart';
import 'components/how_it_works_section.dart';
import 'components/what_it_finds_section.dart';
import 'components/privacy_section.dart';
import 'components/cta_section.dart';
import 'components/footer.dart';
import 'styles/theme.dart';

class App extends StatelessComponent {
  const App({super.key});

  @override
  Component build(BuildContext context) {
    return div(
      classes: 'app',
      [
        const HeroSection(),
        const FeaturesSection(),
        const HowItWorksSection(),
        const WhatItFindsSection(),
        const PrivacySection(),
        const CtaSection(),
        const Footer(),
      ],
      
    );
  }

  @css
  static final List<StyleRule> styles = [
    // CSS Reset & Global Styles
    css('*').styles(
      margin: Margin.zero,
      padding: Padding.zero,
      boxSizing: BoxSizing.borderBox,
    ),
    css('html, body').styles(
      fontFamily: const FontFamily.list([
        FontFamily('Inter'),
        FontFamilies.sansSerif,
      ]),
      fontSize: Unit.pixels(16),
      lineHeight: Unit.pixels(26),
      color: AppTheme.textPrimary,
      backgroundColor: AppTheme.background,
    ),
    css('.app').styles(minHeight: Unit.vh(100)),
    // Container utility
    css('.container').styles(
      maxWidth: Unit.pixels(1200),
      margin: Margin.symmetric(horizontal: Unit.auto),
      padding: Padding.symmetric(horizontal: Unit.pixels(24)),
    ),
    // Section base styles
    css('section').styles(padding: Padding.symmetric(vertical: Unit.pixels(80))),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(768)), [
      css('section').styles(padding: Padding.symmetric(vertical: Unit.pixels(60))),
    ]),
    // Heading styles
    css('h1, h2, h3, h4, h5, h6').styles(
      fontWeight: FontWeight.w700,
      lineHeight: Unit.em(1.2),
      color: AppTheme.textPrimary,
    ),
    css('h1').styles(fontSize: Unit.rem(3.5)),
    css('h2').styles(fontSize: Unit.rem(2.5)),
    css('h3').styles(fontSize: Unit.rem(1.5)),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(768)), [
      css('h1').styles(fontSize: Unit.rem(2.5)),
      css('h2').styles(fontSize: Unit.rem(2)),
      css('h3').styles(fontSize: Unit.rem(1.25)),
    ]),
    // Button styles
    css('.btn').styles(
      display: Display.inlineFlex,
      alignItems: AlignItems.center,
      justifyContent: JustifyContent.center,
      padding: Padding.symmetric(horizontal: Unit.pixels(32), vertical: Unit.pixels(16)),
      fontSize: Unit.rem(1),
      fontWeight: FontWeight.w600,
      radius: BorderRadius.circular(Unit.pixels(12)),
      textDecoration: TextDecoration.none,
      cursor: Cursor.pointer,
      transition: const Transition('all', duration: Duration(milliseconds: 200)),
    ),
    css('.btn-primary').styles(
      backgroundColor: AppTheme.primary,
      color: Colors.white,
      border: Border.all(color: AppTheme.primary, width: Unit.pixels(2)),
    ),
    css('.btn-primary:hover').styles(
      backgroundColor: AppTheme.primaryDark,
      border: Border.all(color: AppTheme.primaryDark, width: Unit.pixels(2)),
      raw: {'transform': 'translateY(-2px)'},
    ),
    css('.btn-secondary').styles(
      backgroundColor: Colors.transparent,
      color: AppTheme.primary,
      border: Border.all(color: AppTheme.primary, width: Unit.pixels(2)),
    ),
    css('.btn-secondary:hover').styles(backgroundColor: AppTheme.primary, color: Colors.white),
    // Text utilities
    css('.text-center').styles(textAlign: TextAlign.center),
    css('.text-muted').styles(color: AppTheme.textSecondary),
    css('.text-gradient').styles(
      raw: {
        'background': 'linear-gradient(135deg, #3498DB 0%, #9B59B6 100%)',
        '-webkit-background-clip': 'text',
        '-webkit-text-fill-color': 'transparent',
        'background-clip': 'text',
      },
    ),
    // Grid utilities
    css('.grid').styles(display: Display.grid, gap: Gap(row: Unit.pixels(32), column: Unit.pixels(32))),
    css('.grid-2').styles(raw: {'grid-template-columns': 'repeat(2, 1fr)'}),
    css('.grid-3').styles(raw: {'grid-template-columns': 'repeat(3, 1fr)'}),
    css('.grid-4').styles(raw: {'grid-template-columns': 'repeat(4, 1fr)'}),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.grid-3, .grid-4').styles(raw: {'grid-template-columns': 'repeat(2, 1fr)'}),
    ]),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(576)), [
      css('.grid-2, .grid-3, .grid-4').styles(raw: {'grid-template-columns': '1fr'}),
    ]),
  ];
}
