// dart format off
// ignore_for_file: type=lint

// GENERATED FILE, DO NOT MODIFY
// Generated with jaspr_builder

import 'package:jaspr/server.dart';
import 'package:filecleaner_landing/components/cta_section.dart'
    as _cta_section;
import 'package:filecleaner_landing/components/features_section.dart'
    as _features_section;
import 'package:filecleaner_landing/components/footer.dart' as _footer;
import 'package:filecleaner_landing/components/hero_section.dart'
    as _hero_section;
import 'package:filecleaner_landing/components/how_it_works_section.dart'
    as _how_it_works_section;
import 'package:filecleaner_landing/components/privacy_section.dart'
    as _privacy_section;
import 'package:filecleaner_landing/components/what_it_finds_section.dart'
    as _what_it_finds_section;
import 'package:filecleaner_landing/app.dart' as _app;

/// Default [ServerOptions] for use with your Jaspr project.
///
/// Use this to initialize Jaspr **before** calling [runApp].
///
/// Example:
/// ```dart
/// import 'main.server.options.dart';
///
/// void main() {
///   Jaspr.initializeApp(
///     options: defaultServerOptions,
///   );
///
///   runApp(...);
/// }
/// ```
ServerOptions get defaultServerOptions => ServerOptions(
  styles: () => [
    ..._cta_section.CtaSection.styles,
    ..._features_section.FeaturesSection.styles,
    ..._footer.Footer.styles,
    ..._hero_section.HeroSection.styles,
    ..._how_it_works_section.HowItWorksSection.styles,
    ..._privacy_section.PrivacySection.styles,
    ..._what_it_finds_section.WhatItFindsSection.styles,
    ..._app.App.styles,
  ],
);
