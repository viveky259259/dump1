import 'package:jaspr/server.dart';
import 'package:jaspr/dom.dart';
import 'app.dart';

void main() async {
  Jaspr.initializeApp();

  const siteUrl = 'https://filecleanerai.com';
  const siteName = 'AI File Cleaner';
  const siteTitle = 'AI File Cleaner - Intelligent macOS Disk Cleanup';
  const siteDescription = 'Free, open-source macOS app that uses on-device AI to find and safely delete temporary files, build artifacts, node_modules, and other space-consuming files. Privacy-focused with 100% local processing.';
  const siteKeywords = 'macOS disk cleaner, AI file cleaner, mac cleanup app, delete node_modules, remove build artifacts, DerivedData cleaner, cache cleaner mac, free disk space mac, open source mac cleaner, privacy-focused cleaner, local AI processing, Apple Silicon optimized';

  runApp(
    Document(
      title: siteTitle,
      meta: {
        // Basic SEO
        'description': siteDescription,
        'keywords': siteKeywords,
        'author': 'FileCleanerAI',
        'viewport': 'width=device-width, initial-scale=1.0',
        'theme-color': '#7C3AED',
        'robots': 'index, follow',
        'googlebot': 'index, follow, max-video-preview:-1, max-image-preview:large, max-snippet:-1',
        
        // Open Graph / Facebook
        'og:type': 'website',
        'og:url': siteUrl,
        'og:title': siteTitle,
        'og:description': siteDescription,
        'og:image': '$siteUrl/assets/og-image.png',
        'og:image:width': '1200',
        'og:image:height': '630',
        'og:site_name': siteName,
        'og:locale': 'en_US',
        
        // Twitter Card
        'twitter:card': 'summary_large_image',
        'twitter:url': siteUrl,
        'twitter:title': siteTitle,
        'twitter:description': siteDescription,
        'twitter:image': '$siteUrl/assets/og-image.png',
        
        // Apple-specific
        'apple-mobile-web-app-capable': 'yes',
        'apple-mobile-web-app-status-bar-style': 'black-translucent',
        'apple-mobile-web-app-title': siteName,
        
        // Additional SEO
        'application-name': siteName,
        'msapplication-TileColor': '#7C3AED',
        'format-detection': 'telephone=no',
      },
      head: [
        // Stylesheets
        link(rel: 'stylesheet', href: '/styles.css'),
        
        // Favicon
        link(rel: 'icon', href: '/assets/favicon.svg', type: 'image/svg+xml'),
        link(rel: 'apple-touch-icon', href: '/assets/logo.svg'),
        
        // Canonical URL
        link(rel: 'canonical', href: siteUrl),
        
        // Preconnect for performance
        link(rel: 'preconnect', href: 'https://fonts.googleapis.com'),
        link(rel: 'preconnect', href: 'https://fonts.gstatic.com', attributes: {'crossorigin': ''}),
      ],
      body: const App(),
    ),
  );
}
