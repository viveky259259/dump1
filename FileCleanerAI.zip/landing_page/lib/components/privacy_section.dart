import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class PrivacySection extends StatelessComponent {
  const PrivacySection({super.key});

  static const privacyFeatures = [
    (icon: '✅', title: '100% Local Processing', description: 'No data sent to external servers. Everything happens on your Mac.'),
    (icon: '✅', title: 'Safe Deletion', description: 'Files moved to Trash, not permanently deleted. Easily recover if needed.'),
    (icon: '✅', title: 'No System Files', description: 'Automatically skips critical system directories. Your Mac stays safe.'),
    (icon: '✅', title: 'Transparent', description: 'Shows exactly what will be deleted. No hidden actions or surprises.'),
  ];

  @override
  Component build(BuildContext context) {
    return section(classes: 'privacy', [
      div(classes: 'container', [
        div(classes: 'privacy-grid', [
          div(classes: 'privacy-content', [
            span(classes: 'section-label', [text('Privacy & Safety')]),
            h2([text('Your files, your control')]),
            p(classes: 'privacy-subtitle', [
              text('AI File Cleaner is designed with privacy and safety as core principles. We believe your data should stay on your device.'),
            ]),
            div(classes: 'privacy-features', [
              for (final feature in privacyFeatures)
                div(classes: 'privacy-feature', [
                  span(classes: 'privacy-check', [text(feature.icon)]),
                  div([
                    h4([text(feature.title)]),
                    p([text(feature.description)]),
                  ]),
                ]),
            ]),
          ]),
          div(classes: 'privacy-illustration', [
            div(classes: 'shield-container', [
              div(classes: 'shield', [span(classes: 'shield-icon', [text('🛡️')])]),
              div(classes: 'shield-ring ring-1', []),
              div(classes: 'shield-ring ring-2', []),
              div(classes: 'shield-ring ring-3', []),
            ]),
          ]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.privacy').styles(backgroundColor: AppTheme.surfaceAlt, raw: {'background': AppTheme.gradientHero}),
    css('.privacy-grid').styles(
      display: Display.grid,
      gap: Gap.all(Unit.pixels(60)),
      alignItems: AlignItems.center,
      raw: {'grid-template-columns': '1fr 1fr'},
    ),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.privacy-grid').styles(raw: {'grid-template-columns': '1fr'}),
      css('.privacy-illustration').styles(display: Display.none),
    ]),
    css('.privacy-content').styles(display: Display.flex, flexDirection: FlexDirection.column, gap: Gap.all(Unit.pixels(24))),
    css('.privacy-subtitle').styles(fontSize: Unit.rem(1.125), color: AppTheme.textSecondary, lineHeight: Unit.em(1.7)),
    css('.privacy-features').styles(
      display: Display.flex,
      flexDirection: FlexDirection.column,
      gap: Gap.all(Unit.pixels(20)),
      margin: Margin.only(top: Unit.pixels(16)),
    ),
    css('.privacy-feature').styles(display: Display.flex, gap: Gap.all(Unit.pixels(16)), alignItems: AlignItems.start),
    css('.privacy-check').styles(fontSize: Unit.rem(1.25), margin: Margin.only(top: Unit.pixels(2))),
    css('.privacy-feature h4').styles(fontSize: Unit.rem(1), fontWeight: FontWeight.w600, margin: Margin.only(bottom: Unit.pixels(4))),
    css('.privacy-feature p').styles(color: AppTheme.textSecondary, fontSize: Unit.rem(0.9375)),
    css('.privacy-illustration').styles(display: Display.flex, alignItems: AlignItems.center, justifyContent: JustifyContent.center),
    css('.shield-container').styles(
      position: Position.relative(),
      width: Unit.pixels(300),
      height: Unit.pixels(300),
      display: Display.flex,
      alignItems: AlignItems.center,
      justifyContent: JustifyContent.center,
    ),
    css('.shield').styles(
      width: Unit.pixels(120),
      height: Unit.pixels(120),
      backgroundColor: AppTheme.surface,
      radius: BorderRadius.circular(Unit.pixels(24)),
      display: Display.flex,
      alignItems: AlignItems.center,
      justifyContent: JustifyContent.center,
      zIndex: const ZIndex(10),
      raw: {'box-shadow': AppTheme.shadowXl},
    ),
    css('.shield-icon').styles(fontSize: Unit.rem(4)),
    css('.shield-ring').styles(
      position: Position.absolute(top: Unit.percent(50), left: Unit.percent(50)),
      radius: BorderRadius.circular(Unit.percent(50)),
      border: Border.all(color: AppTheme.primary, width: Unit.pixels(2)),
      raw: {'transform': 'translate(-50%, -50%)', 'opacity': '0.3'},
    ),
    css('.ring-1').styles(width: Unit.pixels(180), height: Unit.pixels(180), raw: {'opacity': '0.3'}),
    css('.ring-2').styles(width: Unit.pixels(240), height: Unit.pixels(240), raw: {'opacity': '0.2'}),
    css('.ring-3').styles(width: Unit.pixels(300), height: Unit.pixels(300), raw: {'opacity': '0.1'}),
  ];
}
