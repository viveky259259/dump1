import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class HowItWorksSection extends StatelessComponent {
  const HowItWorksSection({super.key});

  static const steps = [
    (number: '1', title: 'Scan', description: 'Click "Scan for Files" to analyze your system. The scanner progressively shows files as they\'re discovered.', icon: '🔍'),
    (number: '2', title: 'Review', description: 'AI groups files into patterns with safety scores. Green is safe, yellow needs review, red requires caution.', icon: '🤖'),
    (number: '3', title: 'Ask AI', description: 'Not sure about a file? Ask the AI Assistant. It explains what files are and if they\'re safe to remove.', icon: '💬'),
    (number: '4', title: 'Clean', description: 'Select patterns and move them to Trash. Files are never permanently deleted, so you can always recover.', icon: '✨'),
  ];

  @override
  Component build(BuildContext context) {
    return section(classes: 'how-it-works', [
      div(classes: 'container', [
        div(classes: 'section-header', [
          span(classes: 'section-label', [text('How It Works')]),
          h2([text('Clean your Mac in 4 simple steps')]),
          p(classes: 'section-subtitle', [text('No complex setup required. Just scan, review, and clean.')]),
        ]),
        div(classes: 'steps-grid', [
          for (final step in steps)
            div(classes: 'step-card', [
              div(classes: 'step-number', [text(step.number)]),
              div(classes: 'step-icon', [text(step.icon)]),
              h3([text(step.title)]),
              p([text(step.description)]),
            ]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.how-it-works').styles(backgroundColor: AppTheme.surfaceAlt, raw: {'background': AppTheme.gradientHero}),
    css('.steps-grid').styles(
      display: Display.grid,
      gap: Gap.all(Unit.pixels(32)),
      position: Position.relative(),
      raw: {'grid-template-columns': 'repeat(4, 1fr)'},
    ),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.steps-grid').styles(raw: {'grid-template-columns': 'repeat(2, 1fr)'}),
    ]),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(576)), [
      css('.steps-grid').styles(raw: {'grid-template-columns': '1fr'}),
    ]),
    css('.step-card').styles(
      textAlign: TextAlign.center,
      padding: Padding.all(Unit.pixels(32)),
      backgroundColor: AppTheme.surface,
      radius: BorderRadius.circular(Unit.pixels(16)),
      position: Position.relative(),
      zIndex: const ZIndex(1),
      raw: {'box-shadow': AppTheme.shadowMd},
    ),
    css('.step-number').styles(
      position: Position.absolute(top: Unit.pixels(-16), left: Unit.percent(50)),
      width: Unit.pixels(32),
      height: Unit.pixels(32),
      display: Display.flex,
      alignItems: AlignItems.center,
      justifyContent: JustifyContent.center,
      backgroundColor: AppTheme.primary,
      color: Colors.white,
      radius: BorderRadius.circular(Unit.percent(50)),
      fontSize: Unit.rem(0.875),
      fontWeight: FontWeight.w700,
      raw: {'transform': 'translateX(-50%)'},
    ),
    css('.step-icon').styles(
      display: Display.flex,
      alignItems: AlignItems.center,
      justifyContent: JustifyContent.center,
      width: Unit.pixels(80),
      height: Unit.pixels(80),
      margin: Margin.symmetric(horizontal: Unit.auto),
      backgroundColor: const Color('#EBF5FB'),
      radius: BorderRadius.circular(Unit.percent(50)),
      fontSize: Unit.rem(2.5),
      raw: {'margin-top': '16px', 'margin-bottom': '20px'},
    ),
    css('.step-card h3').styles(margin: Margin.only(bottom: Unit.pixels(12)), color: AppTheme.textPrimary),
    css('.step-card p').styles(color: AppTheme.textSecondary, fontSize: Unit.rem(0.9375), lineHeight: Unit.em(1.7)),
  ];
}
