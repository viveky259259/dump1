import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class CtaSection extends StatelessComponent {
  const CtaSection({super.key});

  @override
  Component build(BuildContext context) {
    return section(id: 'download', classes: 'cta', [
      div(classes: 'container', [
        div(classes: 'cta-card', [
          div(classes: 'cta-content', [
            h2([text('Ready to reclaim your disk space?')]),
            p([text('Download AI File Cleaner for free and discover how much space you can recover. No subscription required.')]),
            div(classes: 'cta-stats', [
              div(classes: 'stat', [
                span(classes: 'stat-value', [text('10GB+')]),
                span(classes: 'stat-label', [text('Average Space Saved')]),
              ]),
              div(classes: 'stat-divider', []),
              div(classes: 'stat', [
                span(classes: 'stat-value', [text('100%')]),
                span(classes: 'stat-label', [text('Local Processing')]),
              ]),
              div(classes: 'stat-divider', []),
              div(classes: 'stat', [
                span(classes: 'stat-value', [text('Free')]),
                span(classes: 'stat-label', [text('No Hidden Costs')]),
              ]),
            ]),
            div(classes: 'cta-actions', [
              a(classes: 'btn btn-primary btn-large', href: 'https://github.com/ff-vivek/macos_dev_cleaner/releases/download/v1.0.0/AI.File.Cleaner-1.0.0.dmg', [
                span(classes: 'btn-icon', [text('🚀')]),
                text('Download Free'),
              ]),
              a(classes: 'btn btn-secondary btn-large', href: 'https://github.com/ff-vivek/macos_dev_cleaner', target: Target.blank, [
                span(classes: 'btn-icon', [text('⭐')]),
                text('View on GitHub'),
              ]),
            ]),
            p(classes: 'cta-requirements', [text('Open source under MIT License • macOS 15.0+ • Apple Silicon recommended')]),
          ]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.cta').styles(backgroundColor: AppTheme.surface, padding: Padding.symmetric(vertical: Unit.pixels(100))),
    css('.cta-card').styles(
      padding: Padding.all(Unit.pixels(60)),
      radius: BorderRadius.circular(Unit.pixels(24)),
      textAlign: TextAlign.center,
      raw: {'background': AppTheme.gradientPrimary},
    ),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(768)), [
      css('.cta-card').styles(padding: Padding.all(Unit.pixels(40))),
    ]),
    css('.cta-content h2').styles(color: Colors.white, fontSize: Unit.rem(2.5), margin: Margin.only(bottom: Unit.pixels(16))),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(768)), [
      css('.cta-content h2').styles(fontSize: Unit.rem(2)),
    ]),
    css('.cta-content > p').styles(
      color: const Color('#FFFFFFCC'),
      fontSize: Unit.rem(1.125),
      maxWidth: Unit.pixels(600),
      margin: Margin.symmetric(horizontal: Unit.auto),
      raw: {'margin-bottom': '40px'},
    ),
    css('.cta-stats').styles(
      display: Display.flex,
      justifyContent: JustifyContent.center,
      alignItems: AlignItems.center,
      gap: Gap.all(Unit.pixels(32)),
      flexWrap: FlexWrap.wrap,
      margin: Margin.only(bottom: Unit.pixels(40)),
    ),
    css('.stat').styles(textAlign: TextAlign.center),
    css('.stat-value').styles(display: Display.block, fontSize: Unit.rem(2), fontWeight: FontWeight.w800, color: Colors.white),
    css('.stat-label').styles(display: Display.block, fontSize: Unit.rem(0.875), color: const Color('#FFFFFFAA'), margin: Margin.only(top: Unit.pixels(4))),
    css('.stat-divider').styles(width: Unit.pixels(1), height: Unit.pixels(40), backgroundColor: const Color('#FFFFFF33')),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(576)), [
      css('.stat-divider').styles(display: Display.none),
    ]),
    css('.cta-actions').styles(display: Display.flex, justifyContent: JustifyContent.center, gap: Gap.all(Unit.pixels(16)), flexWrap: FlexWrap.wrap),
    css('.btn-large').styles(padding: Padding.symmetric(horizontal: Unit.pixels(40), vertical: Unit.pixels(18)), fontSize: Unit.rem(1.125)),
    css('.cta .btn-primary').styles(backgroundColor: Colors.white, color: AppTheme.primary, border: Border.all(color: Colors.white, width: Unit.pixels(2))),
    css('.cta .btn-primary:hover').styles(backgroundColor: const Color('#F0F0F0'), border: Border.all(color: const Color('#F0F0F0'), width: Unit.pixels(2))),
    css('.cta .btn-secondary').styles(backgroundColor: Colors.transparent, color: Colors.white, border: Border.all(color: Colors.white, width: Unit.pixels(2))),
    css('.cta .btn-secondary:hover').styles(backgroundColor: const Color('#FFFFFF22')),
    css('.cta-requirements').styles(margin: Margin.only(top: Unit.pixels(24)), fontSize: Unit.rem(0.875), color: const Color('#FFFFFF99')),
  ];
}
