import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class HeroSection extends StatelessComponent {
  const HeroSection({super.key});

  @override
  Component build(BuildContext context) {
    return section(classes: 'hero', [
      div(classes: 'container', [
        div(classes: 'hero-content', [
          div(classes: 'hero-logo', [
            img(src: '/assets/logo.svg', alt: 'AI File Cleaner Logo', width: 120, height: 120),
          ]),
          div(classes: 'hero-badge', [
            span(classes: 'badge-icon', [text('🤖')]),
            text('Powered by On-Device AI'),
          ]),
          h1([
            text('Clean Your Mac '),
            span(classes: 'text-gradient', [text('Intelligently')]),
          ]),
          p(classes: 'hero-subtitle', [
            text('AI File Cleaner uses on-device artificial intelligence to find and safely delete temporary files, build artifacts, and other space-consuming files. Privacy-focused, powerful, and completely local.'),
          ]),
          div(classes: 'hero-actions', [
            a(classes: 'btn btn-primary', href: 'https://github.com/ff-vivek/macos_dev_cleaner/releases/download/v1.0.0/AI.File.Cleaner-1.0.0.dmg', [
              span(classes: 'btn-icon', [text('🚀')]),
              text('Download Free'),
            ]),
            a(classes: 'btn btn-secondary', href: '#features', [text('Learn More')]),
          ]),
          p(classes: 'hero-requirements', [text('Open Source • macOS 15.0+ • Apple Silicon recommended')]),
        ]),
        div(classes: 'hero-illustration', [
          div(classes: 'mockup-window', [
            div(classes: 'mockup-header', [
              span(classes: 'mockup-dot red', []),
              span(classes: 'mockup-dot yellow', []),
              span(classes: 'mockup-dot green', []),
              span(classes: 'mockup-title', [text('AI File Cleaner')]),
            ]),
            div(classes: 'mockup-content', [
              div(classes: 'mockup-scan', [
                div(classes: 'scan-item high', [
                  span(classes: 'scan-icon', [text('📦')]),
                  span(classes: 'scan-name', [text('node_modules')]),
                  span(classes: 'scan-size', [text('2.4 GB')]),
                  span(classes: 'scan-badge', [text('Safe')]),
                ]),
                div(classes: 'scan-item high', [
                  span(classes: 'scan-icon', [text('🔨')]),
                  span(classes: 'scan-name', [text('DerivedData')]),
                  span(classes: 'scan-size', [text('8.1 GB')]),
                  span(classes: 'scan-badge', [text('Safe')]),
                ]),
                div(classes: 'scan-item medium', [
                  span(classes: 'scan-icon', [text('📄')]),
                  span(classes: 'scan-name', [text('*.log files')]),
                  span(classes: 'scan-size', [text('512 MB')]),
                  span(classes: 'scan-badge', [text('Review')]),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.hero').styles(
      padding: Padding.only(top: Unit.pixels(100), bottom: Unit.pixels(80)),
      raw: {'background': AppTheme.gradientHero},
    ),
    css('.hero .container').styles(
      display: Display.grid,
      gap: Gap.all(Unit.pixels(60)),
      alignItems: AlignItems.center,
      raw: {'grid-template-columns': '1fr 1fr'},
    ),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.hero .container').styles(raw: {'grid-template-columns': '1fr'}, textAlign: TextAlign.center),
    ]),
    css('.hero-content').styles(display: Display.flex, flexDirection: FlexDirection.column, gap: Gap.all(Unit.pixels(24))),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.hero-content').styles(alignItems: AlignItems.center),
    ]),
    css('.hero-logo').styles(margin: Margin.only(bottom: Unit.pixels(8))),
    css('.hero-logo img').styles(raw: {'filter': 'drop-shadow(0 8px 24px rgba(52, 152, 219, 0.3))'}),
    css('.hero-badge').styles(
      display: Display.inlineFlex,
      alignItems: AlignItems.center,
      gap: Gap.all(Unit.pixels(8)),
      padding: Padding.symmetric(horizontal: Unit.pixels(16), vertical: Unit.pixels(8)),
      backgroundColor: AppTheme.surface,
      radius: BorderRadius.circular(Unit.pixels(100)),
      fontSize: Unit.rem(0.875),
      fontWeight: FontWeight.w500,
      color: AppTheme.textSecondary,
      raw: {'box-shadow': AppTheme.shadowSm},
    ),
    css('.badge-icon').styles(fontSize: Unit.rem(1)),
    css('.hero h1').styles(fontSize: Unit.rem(3.5), fontWeight: FontWeight.w800, lineHeight: Unit.em(1.1)),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(768)), [
      css('.hero h1').styles(fontSize: Unit.rem(2.5)),
    ]),
    css('.hero-subtitle').styles(
      fontSize: Unit.rem(1.25),
      color: AppTheme.textSecondary,
      maxWidth: Unit.pixels(540),
      lineHeight: Unit.em(1.7),
    ),
    css('.hero-actions').styles(display: Display.flex, gap: Gap.all(Unit.pixels(16)), flexWrap: FlexWrap.wrap),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.hero-actions').styles(justifyContent: JustifyContent.center),
    ]),
    css('.btn-icon').styles(margin: Margin.only(right: Unit.pixels(8))),
    css('.hero-requirements').styles(fontSize: Unit.rem(0.875), color: AppTheme.textMuted),
    css('.hero-illustration').styles(display: Display.flex, justifyContent: JustifyContent.center),
    css('.mockup-window').styles(
      width: Unit.percent(100),
      maxWidth: Unit.pixels(480),
      backgroundColor: AppTheme.surface,
      radius: BorderRadius.circular(Unit.pixels(16)),
      overflow: Overflow.hidden,
      raw: {'box-shadow': AppTheme.shadowXl},
    ),
    css('.mockup-header').styles(
      display: Display.flex,
      alignItems: AlignItems.center,
      gap: Gap.all(Unit.pixels(8)),
      padding: Padding.symmetric(horizontal: Unit.pixels(16), vertical: Unit.pixels(12)),
      backgroundColor: AppTheme.surfaceAlt,
      raw: {'border-bottom': '1px solid #E1E8ED'},
    ),
    css('.mockup-dot').styles(width: Unit.pixels(12), height: Unit.pixels(12), radius: BorderRadius.circular(Unit.percent(50))),
    css('.mockup-dot.red').styles(backgroundColor: const Color('#FF5F56')),
    css('.mockup-dot.yellow').styles(backgroundColor: const Color('#FFBD2E')),
    css('.mockup-dot.green').styles(backgroundColor: const Color('#27C93F')),
    css('.mockup-title').styles(
      margin: Margin.only(left: Unit.pixels(8)),
      fontSize: Unit.rem(0.875),
      fontWeight: FontWeight.w500,
      color: AppTheme.textSecondary,
    ),
    css('.mockup-content').styles(padding: Padding.all(Unit.pixels(20))),
    css('.mockup-scan').styles(display: Display.flex, flexDirection: FlexDirection.column, gap: Gap.all(Unit.pixels(12))),
    css('.scan-item').styles(
      display: Display.flex,
      alignItems: AlignItems.center,
      gap: Gap.all(Unit.pixels(12)),
      padding: Padding.all(Unit.pixels(12)),
      backgroundColor: AppTheme.surfaceAlt,
      radius: BorderRadius.circular(Unit.pixels(8)),
      border: Border.all(color: AppTheme.border, width: Unit.pixels(1)),
    ),
    css('.scan-icon').styles(fontSize: Unit.rem(1.25)),
    css('.scan-name').styles(flex: const Flex(grow: 1), fontWeight: FontWeight.w500),
    css('.scan-size').styles(fontSize: Unit.rem(0.875), color: AppTheme.textSecondary),
    css('.scan-badge').styles(
      padding: Padding.symmetric(horizontal: Unit.pixels(8), vertical: Unit.pixels(4)),
      radius: BorderRadius.circular(Unit.pixels(4)),
      fontSize: Unit.rem(0.75),
      fontWeight: FontWeight.w600,
    ),
    css('.scan-item.high .scan-badge').styles(backgroundColor: const Color('#D4EDDA'), color: AppTheme.safetyHigh),
    css('.scan-item.medium .scan-badge').styles(backgroundColor: const Color('#FFF3CD'), color: AppTheme.safetyMedium),
    css('.scan-item.low .scan-badge').styles(backgroundColor: const Color('#F8D7DA'), color: AppTheme.safetyLow),
  ];
}
