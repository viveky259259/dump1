import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class FeaturesSection extends StatelessComponent {
  const FeaturesSection({super.key});

  static const features = [
    (icon: '🤖', title: 'On-Device AI', description: 'Privacy-focused local AI processing with intelligent rule-based fallback. Your data never leaves your Mac.'),
    (icon: '🔍', title: 'Smart Detection', description: 'Automatically identifies temp files, build artifacts, node_modules, caches, and other space hogs.'),
    (icon: '🛡️', title: 'Safety Scoring', description: 'AI analyzes each file pattern and provides safety ratings so you know exactly what\'s safe to delete.'),
    (icon: '💬', title: 'Natural Language', description: 'Chat with AI to understand your files. Ask questions like "What are these .cache files?"'),
    (icon: '📊', title: 'Visual Analytics', description: 'File patterns grouped by type, size, and safety. Beautiful charts help you understand disk usage.'),
    (icon: '🗑️', title: 'Safe Deletion', description: 'Files are moved to Trash, not permanently deleted. You can always restore if needed.'),
  ];

  @override
  Component build(BuildContext context) {
    return section(id: 'features', classes: 'features', [
      div(classes: 'container', [
        div(classes: 'section-header', [
          span(classes: 'section-label', [text('Features')]),
          h2([text('Everything you need to clean your Mac')]),
          p(classes: 'section-subtitle', [
            text('Powerful features wrapped in a simple, intuitive interface. Let AI do the heavy lifting.'),
          ]),
        ]),
        div(classes: 'grid grid-3 features-grid', [
          for (final feature in features)
            div(classes: 'feature-card', [
              div(classes: 'feature-icon', [text(feature.icon)]),
              h3([text(feature.title)]),
              p([text(feature.description)]),
            ]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.features').styles(backgroundColor: AppTheme.surface),
    css('.section-header').styles(textAlign: TextAlign.center, margin: Margin.only(bottom: Unit.pixels(60))),
    css('.section-label').styles(
      display: Display.inlineBlock,
      padding: Padding.symmetric(horizontal: Unit.pixels(16), vertical: Unit.pixels(6)),
      backgroundColor: const Color('#EBF5FB'),
      color: AppTheme.primary,
      radius: BorderRadius.circular(Unit.pixels(100)),
      fontSize: Unit.rem(0.875),
      fontWeight: FontWeight.w600,
      margin: Margin.only(bottom: Unit.pixels(16)),
      textTransform: TextTransform.upperCase,
      raw: {'letter-spacing': '0.05em'},
    ),
    css('.section-subtitle').styles(
      fontSize: Unit.rem(1.125),
      color: AppTheme.textSecondary,
      maxWidth: Unit.pixels(600),
      margin: Margin.symmetric(horizontal: Unit.auto),
    ),
    css('.feature-card').styles(
      padding: Padding.all(Unit.pixels(32)),
      backgroundColor: AppTheme.surface,
      radius: BorderRadius.circular(Unit.pixels(16)),
      border: Border.all(color: AppTheme.border, width: Unit.pixels(1)),
      transition: const Transition('all', duration: Duration(milliseconds: 200)),
    ),
    css('.feature-card:hover').styles(
      raw: {'box-shadow': AppTheme.shadowLg, 'transform': 'translateY(-4px)', 'border-color': 'transparent'},
    ),
    css('.feature-icon').styles(
      display: Display.flex,
      alignItems: AlignItems.center,
      justifyContent: JustifyContent.center,
      width: Unit.pixels(64),
      height: Unit.pixels(64),
      backgroundColor: const Color('#EBF5FB'),
      radius: BorderRadius.circular(Unit.pixels(16)),
      fontSize: Unit.rem(2),
      margin: Margin.only(bottom: Unit.pixels(20)),
    ),
    css('.feature-card h3').styles(margin: Margin.only(bottom: Unit.pixels(12))),
    css('.feature-card p').styles(color: AppTheme.textSecondary, lineHeight: Unit.em(1.7)),
  ];
}
