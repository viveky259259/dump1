import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class WhatItFindsSection extends StatelessComponent {
  const WhatItFindsSection({super.key});

  static const categories = [
    (title: 'Development', color: '#3498DB', items: [
      (name: 'node_modules', desc: 'npm packages'),
      (name: 'build / dist', desc: 'Build artifacts'),
      (name: 'target', desc: 'Rust/Java builds'),
      (name: 'DerivedData', desc: 'Xcode cache'),
    ]),
    (title: 'Dependencies', color: '#9B59B6', items: [
      (name: '.gradle', desc: 'Gradle cache'),
      (name: 'Pods', desc: 'CocoaPods'),
      (name: '__pycache__', desc: 'Python bytecode'),
      (name: '.pytest_cache', desc: 'Test cache'),
    ]),
    (title: 'Temp Files', color: '#E67E22', items: [
      (name: '*.log', desc: 'Log files'),
      (name: '*.tmp', desc: 'Temporary files'),
      (name: '*.cache', desc: 'Cache files'),
      (name: '.DS_Store', desc: 'macOS metadata'),
    ]),
    (title: 'Archives', color: '#27AE60', items: [
      (name: '*.zip', desc: 'ZIP archives'),
      (name: '*.tar.gz', desc: 'Tarballs'),
      (name: '*.dmg', desc: 'Disk images'),
      (name: '*.pkg', desc: 'Installers'),
    ]),
  ];

  @override
  Component build(BuildContext context) {
    return section(classes: 'what-it-finds', [
      div(classes: 'container', [
        div(classes: 'section-header', [
          span(classes: 'section-label', [text('What It Finds')]),
          h2([text('Reclaim gigabytes of disk space')]),
          p(classes: 'section-subtitle', [
            text('AI File Cleaner intelligently identifies common space wasters across all your projects.'),
          ]),
        ]),
        div(classes: 'grid grid-4 categories-grid', [
          for (final category in categories)
            div(classes: 'category-card', [
              div(classes: 'category-header', styles: Styles(raw: {'background': 'linear-gradient(135deg, ${category.color} 0%, ${category.color}CC 100%)'}), [
                h3([text(category.title)]),
              ]),
              div(classes: 'category-items', [
                for (final item in category.items)
                  div(classes: 'category-item', [
                    code([text(item.name)]),
                    span([text(item.desc)]),
                  ]),
              ]),
            ]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.what-it-finds').styles(backgroundColor: AppTheme.surface),
    css('.category-card').styles(
      radius: BorderRadius.circular(Unit.pixels(16)),
      overflow: Overflow.hidden,
      border: Border.all(color: AppTheme.border, width: Unit.pixels(1)),
      transition: const Transition('all', duration: Duration(milliseconds: 200)),
    ),
    css('.category-card:hover').styles(raw: {'box-shadow': AppTheme.shadowLg, 'transform': 'translateY(-4px)'}),
    css('.category-header').styles(padding: Padding.all(Unit.pixels(20)), color: Colors.white),
    css('.category-header h3').styles(color: Colors.white, fontSize: Unit.rem(1.125)),
    css('.category-items').styles(padding: Padding.all(Unit.pixels(16)), backgroundColor: AppTheme.surface),
    css('.category-item').styles(
      display: Display.flex,
      justifyContent: JustifyContent.spaceBetween,
      alignItems: AlignItems.center,
      padding: Padding.symmetric(vertical: Unit.pixels(10), horizontal: Unit.pixels(12)),
      radius: BorderRadius.circular(Unit.pixels(8)),
      margin: Margin.only(bottom: Unit.pixels(4)),
    ),
    css('.category-item:hover').styles(backgroundColor: AppTheme.surfaceAlt),
    css('.category-item code').styles(
      fontFamily: const FontFamily.list([FontFamily('SF Mono'), FontFamily('Monaco'), FontFamilies.monospace]),
      fontSize: Unit.rem(0.875),
      fontWeight: FontWeight.w500,
      color: AppTheme.textPrimary,
    ),
    css('.category-item span').styles(fontSize: Unit.rem(0.75), color: AppTheme.textMuted),
  ];
}
