import 'package:jaspr/jaspr.dart';
import 'package:jaspr/dom.dart';
import '../styles/theme.dart';

class Footer extends StatelessComponent {
  const Footer({super.key});

  @override
  Component build(BuildContext context) {
    return footer(classes: 'footer', [
      div(classes: 'container', [
        div(classes: 'footer-grid', [
          div(classes: 'footer-brand', [
            div(classes: 'footer-logo', [
              img(src: '/assets/logo.svg', alt: 'AI File Cleaner', width: 48, height: 48),
              span([text('AI File Cleaner')]),
            ]),
            p([text('An intelligent macOS application that uses on-device AI to help you find and safely delete temporary files.')]),
          ]),
          div(classes: 'footer-links', [
            h4([text('Product')]),
            ul([
              li([a(href: '#features', [text('Features')])]),
              li([a(href: 'https://github.com/ff-vivek/macos_dev_cleaner/releases/download/v1.0.0/AI.File.Cleaner-1.0.0.dmg', [text('Download')])]),
              li([span(classes: 'coming-soon-text', [text('Changelog (Coming Soon)')])]),
            ]),
          ]),
          div(classes: 'footer-links', [
            h4([text('Resources')]),
            ul([
              li([a(href: 'https://github.com/ff-vivek/macos_dev_cleaner', target: Target.blank, [text('GitHub')])]),
              li([a(href: 'https://github.com/ff-vivek/macos_dev_cleaner/issues', target: Target.blank, [text('Report Issue')])]),
              li([a(href: 'https://github.com/ff-vivek/macos_dev_cleaner/blob/main/CONTRIBUTING.md', target: Target.blank, [text('Contributing')])]),
            ]),
          ]),
          div(classes: 'footer-links', [
            h4([text('Legal')]),
            ul([
              li([a(href: 'https://github.com/ff-vivek/macos_dev_cleaner/blob/main/LICENSE', target: Target.blank, [text('MIT License')])]),
              li([a(href: '#privacy', [text('Privacy Policy')])]),
            ]),
          ]),
        ]),
        div(classes: 'footer-bottom', [
          p([text('Made with ❤️ for macOS')]),
          p(classes: 'footer-copyright', [text('© 2026 AI File Cleaner. Open source under MIT License.')]),
        ]),
      ]),
    ]);
  }

  @css
  static final List<StyleRule> styles = [
    css('.footer').styles(
      backgroundColor: AppTheme.textPrimary,
      color: Colors.white,
      padding: Padding.only(top: Unit.pixels(80), bottom: Unit.pixels(40)),
    ),
    css('.footer-grid').styles(
      display: Display.grid,
      gap: Gap.all(Unit.pixels(40)),
      padding: Padding.only(bottom: Unit.pixels(40)),
      raw: {'grid-template-columns': '2fr 1fr 1fr 1fr', 'border-bottom': '1px solid #333'},
    ),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(992)), [
      css('.footer-grid').styles(raw: {'grid-template-columns': 'repeat(2, 1fr)'}),
    ]),
    css.media(const MediaQuery.screen(maxWidth: Unit.pixels(576)), [
      css('.footer-grid').styles(raw: {'grid-template-columns': '1fr'}),
    ]),
    css('.footer-brand').styles(maxWidth: Unit.pixels(300)),
    css('.footer-logo').styles(
      display: Display.flex,
      alignItems: AlignItems.center,
      gap: Gap.all(Unit.pixels(12)),
      margin: Margin.only(bottom: Unit.pixels(16)),
    ),
    css('.footer-logo span').styles(fontSize: Unit.rem(1.25), fontWeight: FontWeight.w700),
    css('.footer-brand p').styles(color: const Color('#9CA3AF'), fontSize: Unit.rem(0.9375), lineHeight: Unit.em(1.7)),
    css('.footer-links h4').styles(
      color: Colors.white,
      fontSize: Unit.rem(1),
      fontWeight: FontWeight.w600,
      margin: Margin.only(bottom: Unit.pixels(20)),
    ),
    css('.footer-links ul').styles(listStyle: ListStyle.none, padding: Padding.zero),
    css('.footer-links li').styles(margin: Margin.only(bottom: Unit.pixels(12))),
    css('.footer-links a').styles(
      color: const Color('#9CA3AF'),
      textDecoration: TextDecoration.none,
      transition: const Transition('color', duration: Duration(milliseconds: 200)),
    ),
    css('.footer-links a:hover').styles(color: Colors.white),
    css('.footer-bottom').styles(padding: Padding.only(top: Unit.pixels(32)), textAlign: TextAlign.center),
    css('.footer-bottom p').styles(color: const Color('#9CA3AF'), fontSize: Unit.rem(0.9375)),
    css('.footer-copyright').styles(margin: Margin.only(top: Unit.pixels(8)), fontSize: Unit.rem(0.875)),
  ];
}
