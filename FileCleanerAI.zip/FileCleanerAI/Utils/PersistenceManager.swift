import Foundation

@MainActor
class PersistenceManager {
    static let shared = PersistenceManager()
    
    private let fileManager = FileManager.default
    private let scanDataURL: URL
    
    private init() {
        // Create app support directory
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let appDirectory = appSupport.appendingPathComponent("FileCleanerAI", isDirectory: true)
        
        // Create directory if it doesn't exist
        try? fileManager.createDirectory(at: appDirectory, withIntermediateDirectories: true)
        
        scanDataURL = appDirectory.appendingPathComponent("scan_data.json")
    }
    
    // MARK: - Save/Load Scan Data
    
    func saveScanData(files: [DiscoveredFile], patterns: [FilePattern]) {
        let scanData = ScanDataStorage(
            files: files,
            patterns: patterns,
            scanDate: Date()
        )
        
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(scanData)
            try data.write(to: scanDataURL)
            
            LogManager.shared.log("Scan data saved successfully", level: .success, category: .system)
        } catch {
            LogManager.shared.log("Failed to save scan data: \(error.localizedDescription)", level: .error, category: .system)
        }
    }
    
    func loadScanData() -> ScanDataStorage? {
        guard fileManager.fileExists(atPath: scanDataURL.path) else {
            LogManager.shared.log("No saved scan data found", level: .info, category: .system)
            return nil
        }
        
        do {
            let data = try Data(contentsOf: scanDataURL)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let scanData = try decoder.decode(ScanDataStorage.self, from: data)
            
            LogManager.shared.log("Loaded scan data from \(scanData.scanDate.formatted())", level: .success, category: .system)
            return scanData
        } catch {
            LogManager.shared.log("Failed to load scan data: \(error.localizedDescription)", level: .error, category: .system)
            return nil
        }
    }
    
    func clearScanData() {
        try? fileManager.removeItem(at: scanDataURL)
        LogManager.shared.log("Scan data cleared", level: .info, category: .system)
    }
    
    func getScanDataAge() -> String? {
        guard let scanData = loadScanData() else { return nil }
        
        let timeInterval = Date().timeIntervalSince(scanData.scanDate)
        
        if timeInterval < 3600 {
            let minutes = Int(timeInterval / 60)
            return "\(minutes) minute\(minutes == 1 ? "" : "s") ago"
        } else if timeInterval < 86400 {
            let hours = Int(timeInterval / 3600)
            return "\(hours) hour\(hours == 1 ? "" : "s") ago"
        } else {
            let days = Int(timeInterval / 86400)
            return "\(days) day\(days == 1 ? "" : "s") ago"
        }
    }
    
    // MARK: - Save/Load Disk Usage Data
    
    private var diskUsageDataURL: URL {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let appDirectory = appSupport.appendingPathComponent("FileCleanerAI", isDirectory: true)
        return appDirectory.appendingPathComponent("disk_usage_data.json")
    }
    
    func saveDiskUsageData(categories: [StorageCategory]) {
        let diskUsageData = DiskUsageDataStorage(
            categories: categories,
            scanDate: Date()
        )
        
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(diskUsageData)
            try data.write(to: diskUsageDataURL)
            
            LogManager.shared.log("Disk usage data saved successfully", level: .success, category: .system)
        } catch {
            LogManager.shared.log("Failed to save disk usage data: \(error.localizedDescription)", level: .error, category: .system)
        }
    }
    
    func loadDiskUsageData() -> DiskUsageDataStorage? {
        guard fileManager.fileExists(atPath: diskUsageDataURL.path) else {
            LogManager.shared.log("No saved disk usage data found", level: .info, category: .system)
            return nil
        }
        
        do {
            let data = try Data(contentsOf: diskUsageDataURL)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let diskUsageData = try decoder.decode(DiskUsageDataStorage.self, from: data)
            
            LogManager.shared.log("Loaded disk usage data from \(diskUsageData.scanDate.formatted())", level: .success, category: .system)
            return diskUsageData
        } catch {
            LogManager.shared.log("Failed to load disk usage data: \(error.localizedDescription)", level: .error, category: .system)
            return nil
        }
    }
    
    func getDiskUsageDataAge() -> String? {
        guard let diskUsageData = loadDiskUsageData() else { return nil }
        
        let timeInterval = Date().timeIntervalSince(diskUsageData.scanDate)
        
        if timeInterval < 3600 {
            let minutes = Int(timeInterval / 60)
            return "\(minutes) minute\(minutes == 1 ? "" : "s") ago"
        } else if timeInterval < 86400 {
            let hours = Int(timeInterval / 3600)
            return "\(hours) hour\(hours == 1 ? "" : "s") ago"
        } else {
            let days = Int(timeInterval / 86400)
            return "\(days) day\(days == 1 ? "" : "s") ago"
        }
    }
    
    func clearDiskUsageData() {
        try? fileManager.removeItem(at: diskUsageDataURL)
        LogManager.shared.log("Disk usage data cleared", level: .info, category: .system)
    }
    
    // MARK: - Size Cache Persistence
    
    private var sizeCacheURL: URL {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let appDirectory = appSupport.appendingPathComponent("FileCleanerAI", isDirectory: true)
        return appDirectory.appendingPathComponent("size_cache.json")
    }
    
    func saveSizeCache(_ cache: [String: CachedSizeEntry]) {
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(cache)
            try data.write(to: sizeCacheURL)
            
            LogManager.shared.log("Size cache saved (\(cache.count) entries)", level: .debug, category: .system)
        } catch {
            LogManager.shared.log("Failed to save size cache: \(error.localizedDescription)", level: .error, category: .system)
        }
    }
    
    func loadSizeCache() -> [String: CachedSizeEntry] {
        guard fileManager.fileExists(atPath: sizeCacheURL.path) else {
            LogManager.shared.log("No saved size cache found", level: .debug, category: .system)
            return [:]
        }
        
        do {
            let data = try Data(contentsOf: sizeCacheURL)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let cache = try decoder.decode([String: CachedSizeEntry].self, from: data)
            
            LogManager.shared.log("Loaded size cache (\(cache.count) entries)", level: .debug, category: .system)
            return cache
        } catch {
            LogManager.shared.log("Failed to load size cache: \(error.localizedDescription)", level: .error, category: .system)
            return [:]
        }
    }
    
    func clearSizeCache() {
        try? fileManager.removeItem(at: sizeCacheURL)
        LogManager.shared.log("Size cache cleared", level: .info, category: .system)
    }
    
    // MARK: - Performance Data Persistence
    
    private var performanceDataURL: URL {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let appDirectory = appSupport.appendingPathComponent("FileCleanerAI", isDirectory: true)
        return appDirectory.appendingPathComponent("performance_data.json")
    }
    
    func savePerformanceData(_ data: PerformanceDataStorage) {
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let encoded = try encoder.encode(data)
            try encoded.write(to: performanceDataURL)
            
            LogManager.shared.log("Performance data saved (\(data.sessions.count) sessions)", level: .debug, category: .system)
        } catch {
            LogManager.shared.log("Failed to save performance data: \(error.localizedDescription)", level: .error, category: .system)
        }
    }
    
    func loadPerformanceData() -> PerformanceDataStorage? {
        guard fileManager.fileExists(atPath: performanceDataURL.path) else {
            LogManager.shared.log("No saved performance data found", level: .debug, category: .system)
            return nil
        }
        
        do {
            let data = try Data(contentsOf: performanceDataURL)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let performanceData = try decoder.decode(PerformanceDataStorage.self, from: data)
            
            LogManager.shared.log("Loaded performance data (\(performanceData.sessions.count) sessions)", level: .debug, category: .system)
            return performanceData
        } catch {
            LogManager.shared.log("Failed to load performance data: \(error.localizedDescription)", level: .error, category: .system)
            return nil
        }
    }
    
    func clearPerformanceData() {
        try? fileManager.removeItem(at: performanceDataURL)
        LogManager.shared.log("Performance data cleared", level: .info, category: .system)
    }
    
    // MARK: - Navigation Path Persistence
    
    private var navigationPathURL: URL {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let appDirectory = appSupport.appendingPathComponent("FileCleanerAI", isDirectory: true)
        return appDirectory.appendingPathComponent("disk_usage_navigation.json")
    }
    
    func saveNavigationPath(_ path: [StorageItem]) {
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(path)
            try data.write(to: navigationPathURL)
            
            LogManager.shared.log("Navigation path saved (\(path.count) items)", level: .debug, category: .system)
        } catch {
            LogManager.shared.log("Failed to save navigation path: \(error.localizedDescription)", level: .error, category: .system)
        }
    }
    
    func loadNavigationPath() -> [StorageItem]? {
        guard fileManager.fileExists(atPath: navigationPathURL.path) else {
            LogManager.shared.log("No saved navigation path found", level: .debug, category: .system)
            return nil
        }
        
        do {
            let data = try Data(contentsOf: navigationPathURL)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let path = try decoder.decode([StorageItem].self, from: data)
            
            // Validate that paths still exist
            let validPath = path.filter { item in
                // For virtual paths (like System Data), always include
                if item.path == DiskScanner.systemDataVirtualPath {
                    return true
                }
                // Check if path exists
                return fileManager.fileExists(atPath: item.path)
            }
            
            if validPath.count != path.count {
                LogManager.shared.log("Filtered out \(path.count - validPath.count) invalid paths from navigation", level: .info, category: .system)
            }
            
            LogManager.shared.log("Loaded navigation path (\(validPath.count) items)", level: .debug, category: .system)
            return validPath.isEmpty ? nil : validPath
        } catch {
            LogManager.shared.log("Failed to load navigation path: \(error.localizedDescription)", level: .error, category: .system)
            return nil
        }
    }
    
    func clearNavigationPath() {
        try? fileManager.removeItem(at: navigationPathURL)
        LogManager.shared.log("Navigation path cleared", level: .info, category: .system)
    }
}

// MARK: - Storage Models

struct ScanDataStorage: Codable {
    let files: [DiscoveredFile]
    let patterns: [FilePattern]
    let scanDate: Date
}

// Make DiscoveredFile Codable
extension DiscoveredFile: Codable {
    enum CodingKeys: String, CodingKey {
        case path, size, name, isDirectory, modificationDate
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        path = try container.decode(String.self, forKey: .path)
        size = try container.decode(Int64.self, forKey: .size)
        name = try container.decode(String.self, forKey: .name)
        isDirectory = try container.decode(Bool.self, forKey: .isDirectory)
        modificationDate = try container.decodeIfPresent(Date.self, forKey: .modificationDate)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(path, forKey: .path)
        try container.encode(size, forKey: .size)
        try container.encode(name, forKey: .name)
        try container.encode(isDirectory, forKey: .isDirectory)
        try container.encodeIfPresent(modificationDate, forKey: .modificationDate)
    }
}

// MARK: - Disk Usage Storage Model

struct DiskUsageDataStorage: Codable {
    let categories: [StorageCategory]
    let scanDate: Date
}

// MARK: - Size Cache Entry

struct CachedSizeEntry: Codable {
    let size: Int64
    let timestamp: Date
    let modificationDate: Date?
    
    var isValid: Bool {
        // Check if cache is still valid (5 minute TTL)
        Date().timeIntervalSince(timestamp) < 300
    }
}