import Foundation
import UserNotifications

// MARK: - Schedule Configuration

enum CleaningInterval: String, CaseIterable, Codable {
    case daily = "Daily"
    case weekly = "Weekly"
    case monthly = "Monthly"

    var seconds: TimeInterval {
        switch self {
        case .daily: return 86400
        case .weekly: return 604800
        case .monthly: return 2592000
        }
    }

    var description: String {
        switch self {
        case .daily: return "Every day"
        case .weekly: return "Every week"
        case .monthly: return "Every month"
        }
    }
}

struct CleaningScheduleConfig: Codable {
    var isEnabled: Bool = false
    var interval: CleaningInterval = .weekly
    var cleanSystemData: Bool = true
    var cleanBrowserCaches: Bool = true
    var cleanDevArtifacts: Bool = false
    var cleanXcodeData: Bool = false
    var notifyBeforeCleaning: Bool = true
    var notifyAfterCleaning: Bool = true
    var alertThresholdGB: Double = 5.0 // Notify when cleanable data exceeds this
    var lastCleanDate: Date?
    var lastScanDate: Date?
    var lastCleanedBytes: Int64 = 0
}

struct ScheduledCleaningSummary {
    var systemDataSize: Int64 = 0
    var browserCacheSize: Int64 = 0
    var devArtifactSize: Int64 = 0
    var xcodeDataSize: Int64 = 0

    var totalSize: Int64 {
        systemDataSize + browserCacheSize + devArtifactSize + xcodeDataSize
    }

    var formattedTotal: String {
        ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file)
    }

    var exceedsThreshold: Bool {
        false // Will be checked against config
    }
}

// MARK: - Scheduled Cleaning Manager

@MainActor
class ScheduledCleaningManager: ObservableObject {
    static let shared = ScheduledCleaningManager()

    @Published var config: CleaningScheduleConfig {
        didSet { saveConfig() }
    }
    @Published var isScanning = false
    @Published var isCleaning = false
    @Published var lastSummary: ScheduledCleaningSummary?
    @Published var nextScheduledDate: Date?

    private var checkTimer: Timer?
    private let logManager = LogManager.shared
    private let configKey = "com.filecleanerai.schedule.config"

    private init() {
        config = CleaningScheduleConfig()
        loadConfig()
        requestNotificationPermission()
        startScheduleCheck()
    }

    // MARK: - Persistence

    private func loadConfig() {
        guard let data = UserDefaults.standard.data(forKey: configKey),
              let saved = try? JSONDecoder().decode(CleaningScheduleConfig.self, from: data) else {
            return
        }
        config = saved
        updateNextScheduledDate()
    }

    private func saveConfig() {
        if let data = try? JSONEncoder().encode(config) {
            UserDefaults.standard.set(data, forKey: configKey)
        }
        updateNextScheduledDate()
    }

    // MARK: - Schedule Management

    func startScheduleCheck() {
        checkTimer?.invalidate()

        guard config.isEnabled else {
            nextScheduledDate = nil
            return
        }

        updateNextScheduledDate()

        // Check every 5 minutes if it's time to run
        checkTimer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.checkIfDue()
            }
        }

        // Also check immediately
        checkIfDue()
    }

    func stopScheduleCheck() {
        checkTimer?.invalidate()
        checkTimer = nil
    }

    private func updateNextScheduledDate() {
        guard config.isEnabled else {
            nextScheduledDate = nil
            return
        }

        if let last = config.lastCleanDate {
            nextScheduledDate = last.addingTimeInterval(config.interval.seconds)
        } else {
            // Never run before — schedule for now
            nextScheduledDate = Date()
        }
    }

    private func checkIfDue() {
        guard config.isEnabled,
              let nextDate = nextScheduledDate,
              Date() >= nextDate else {
            return
        }

        Task {
            await runScheduledScan()
        }
    }

    // MARK: - Scanning

    func runScheduledScan() async {
        guard !isScanning, !isCleaning else { return }

        isScanning = true
        var summary = ScheduledCleaningSummary()

        // Scan system data
        if config.cleanSystemData {
            let scanner = SystemDataScanner.shared
            await scanner.scanForSystemData()
            summary.systemDataSize = scanner.totalDataFound
        }

        // Scan Xcode data
        if config.cleanXcodeData {
            let manager = XcodeCleanupManager.shared
            await manager.scan()
            summary.xcodeDataSize = manager.totalReclaimable
        }

        // Scan dev artifacts
        if config.cleanDevArtifacts {
            let scanner = DevProjectScanner.shared
            await scanner.scanForProjects()
            let staleSize = scanner.projects.filter { $0.isStale }.reduce(0) { $0 + $1.totalArtifactSize }
            summary.devArtifactSize = staleSize
        }

        lastSummary = summary
        config.lastScanDate = Date()
        isScanning = false

        // Check threshold and notify
        let thresholdBytes = Int64(config.alertThresholdGB * 1_073_741_824)
        if summary.totalSize >= thresholdBytes {
            if config.notifyBeforeCleaning {
                sendNotification(
                    title: "FileCleanerAI: Cleanup Available",
                    body: "\(summary.formattedTotal) of cleanable data found. Open FileCleanerAI to review and clean."
                )
            }
        }

        logManager.log(
            "Scheduled scan complete: \(summary.formattedTotal) cleanable",
            level: .info, category: .scanning
        )
    }

    // MARK: - Cleaning

    func runScheduledClean() async {
        guard !isCleaning else { return }

        isCleaning = true
        var totalFreed: Int64 = 0

        // Clean system data
        if config.cleanSystemData {
            let scanner = SystemDataScanner.shared
            let result = await scanner.cleanSelectedCategories()
            totalFreed += result.bytesFreed
        }

        // Clean Xcode data
        if config.cleanXcodeData {
            let manager = XcodeCleanupManager.shared
            let result = await manager.cleanSelected()
            totalFreed += result.bytesFreed
        }

        // Clean stale dev artifacts
        if config.cleanDevArtifacts {
            let scanner = DevProjectScanner.shared
            let result = await scanner.cleanAllStaleProjects()
            totalFreed += result.bytesFreed
        }

        config.lastCleanDate = Date()
        config.lastCleanedBytes = totalFreed
        isCleaning = false

        updateNextScheduledDate()

        if config.notifyAfterCleaning {
            sendNotification(
                title: "FileCleanerAI: Cleanup Complete",
                body: "Freed \(ByteCountFormatter.string(fromByteCount: totalFreed, countStyle: .file)) of disk space."
            )
        }

        logManager.log(
            "Scheduled clean complete: freed \(ByteCountFormatter.string(fromByteCount: totalFreed, countStyle: .file))",
            level: .success, category: .deletion
        )
    }

    // MARK: - Notifications

    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func sendNotification(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil // Deliver immediately
        )

        UNUserNotificationCenter.current().add(request)
    }

    // MARK: - Quick Status

    var statusText: String {
        if !config.isEnabled { return "Disabled" }
        if let next = nextScheduledDate {
            if next <= Date() { return "Due now" }
            let formatter = RelativeDateTimeFormatter()
            formatter.unitsStyle = .abbreviated
            return "Next: \(formatter.localizedString(for: next, relativeTo: Date()))"
        }
        return "Enabled"
    }

    var hasCleanableData: Bool {
        (lastSummary?.totalSize ?? 0) > 0
    }
}
