import Foundation
import AppKit
import SwiftUI

@MainActor
class MemoryMonitor: ObservableObject {
    static let shared = MemoryMonitor()
    
    @Published var physicalMemory: Int64 = 0
    @Published var usedMemory: Int64 = 0
    @Published var appMemoryUsage: Int64 = 0
    @Published var memoryPressure: MemoryPressure = .normal
    
    enum MemoryPressure {
        case normal
        case warning
        case critical
        
        var color: Color {
            switch self {
            case .normal: return .green
            case .warning: return .orange
            case .critical: return .red
            }
        }
        
        var description: String {
            switch self {
            case .normal: return "Normal"
            case .warning: return "Warning"
            case .critical: return "Critical"
            }
        }
    }
    
    private var updateTimer: Timer?
    
    private init() {
        updateMemoryInfo()
    }
    
    func startMonitoring(interval: TimeInterval = 2.0) {
        stopMonitoring()
        updateTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.updateMemoryInfo()
            }
        }
    }
    
    func stopMonitoring() {
        updateTimer?.invalidate()
        updateTimer = nil
    }
    
    func updateMemoryInfo() {
        // Get system physical memory
        physicalMemory = Int64(ProcessInfo.processInfo.physicalMemory)
        
        // Get app's memory usage
        appMemoryUsage = getAppMemoryUsage()
        
        // Get system-wide memory usage (approximate)
        usedMemory = getSystemMemoryUsage()
        
        // Calculate memory pressure
        memoryPressure = calculateMemoryPressure()
    }
    
    private func getAppMemoryUsage() -> Int64 {
        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size / MemoryLayout<integer_t>.size)
        
        let kerr: kern_return_t = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: 1) {
                task_info(mach_task_self_,
                         task_flavor_t(MACH_TASK_BASIC_INFO),
                         $0,
                         &count)
            }
        }
        
        if kerr == KERN_SUCCESS {
            return Int64(info.resident_size)
        }
        
        return 0
    }
    
    private func getSystemMemoryUsage() -> Int64 {
        var stats = vm_statistics64()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)

        let result = withUnsafeMutablePointer(to: &stats) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_statistics64(mach_host_self(),
                                HOST_VM_INFO64,
                                $0,
                                &count)
            }
        }

        if result == KERN_SUCCESS {
            // Get page size in a thread-safe way
            var pageSize: vm_size_t = 0
            let pageSizeResult = host_page_size(mach_host_self(), &pageSize)

            if pageSizeResult == KERN_SUCCESS {
                let pageSizeInt64 = Int64(pageSize)

                // Calculate used memory like Activity Monitor does:
                // Used = Active + Wired + Compressed
                // This excludes inactive/cached memory that can be reclaimed
                let activeMemory = Int64(stats.active_count) * pageSizeInt64
                let wiredMemory = Int64(stats.wire_count) * pageSizeInt64
                let compressedMemory = Int64(stats.compressor_page_count) * pageSizeInt64

                return activeMemory + wiredMemory + compressedMemory
            }
        }

        return 0
    }
    
    private func calculateMemoryPressure() -> MemoryPressure {
        guard physicalMemory > 0 else { return .normal }
        
        let usagePercent = Double(usedMemory) / Double(physicalMemory) * 100
        
        if usagePercent > 90 {
            return .critical
        } else if usagePercent > 75 {
            return .warning
        } else {
            return .normal
        }
    }
    
    // MARK: - Formatted Strings
    
    func formattedPhysicalMemory() -> String {
        return ByteCountFormatter.string(fromByteCount: physicalMemory, countStyle: .memory)
    }
    
    func formattedUsedMemory() -> String {
        return ByteCountFormatter.string(fromByteCount: usedMemory, countStyle: .memory)
    }
    
    func formattedAppMemory() -> String {
        return ByteCountFormatter.string(fromByteCount: appMemoryUsage, countStyle: .memory)
    }
    
    func formattedFreeMemory() -> String {
        let freeMemory = physicalMemory - usedMemory
        return ByteCountFormatter.string(fromByteCount: freeMemory, countStyle: .memory)
    }
    
    func memoryUsagePercent() -> Double {
        guard physicalMemory > 0 else { return 0 }
        return Double(usedMemory) / Double(physicalMemory) * 100
    }
    
    func appMemoryPercent() -> Double {
        guard physicalMemory > 0 else { return 0 }
        return Double(appMemoryUsage) / Double(physicalMemory) * 100
    }
}
