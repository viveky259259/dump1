import Foundation

// MARK: - Data Models

struct APFSSnapshot: Identifiable {
    let id: String
    let name: String
    let date: Date
    let size: Int64? // May not always be available

    var formattedDate: String {
        date.formatted(date: .abbreviated, time: .shortened)
    }

    var formattedSize: String {
        if let size = size {
            return ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
        }
        return "Unknown"
    }

    var age: String {
        let days = Calendar.current.dateComponents([.day], from: date, to: Date()).day ?? 0
        if days == 0 { return "Today" }
        if days == 1 { return "Yesterday" }
        if days < 30 { return "\(days) days ago" }
        return "\(days / 30) months ago"
    }
}

// MARK: - Snapshot Manager

@MainActor
class SnapshotManager: ObservableObject {
    static let shared = SnapshotManager()

    @Published var snapshots: [APFSSnapshot] = []
    @Published var isLoading = false
    @Published var isDeleting = false
    @Published var totalSnapshotCount = 0
    @Published var timeMachineEnabled = false
    @Published var errorMessage: String?

    private let logManager = LogManager.shared

    private init() {}

    // MARK: - List Snapshots

    func loadSnapshots() async {
        isLoading = true
        errorMessage = nil
        snapshots = []

        // Get snapshot dates via tmutil
        let dateOutput = await runCommand("/usr/bin/tmutil", arguments: ["listlocalsnapshotdates", "/"])

        guard let output = dateOutput else {
            errorMessage = "Could not list snapshots. Time Machine local snapshots may be disabled."
            isLoading = false
            return
        }

        let lines = output.components(separatedBy: "\n").filter { !$0.isEmpty }

        // First line is usually a header, skip it
        let dateLines = lines.dropFirst().filter { $0.contains("-") }

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd-HHmmss"

        var loadedSnapshots: [APFSSnapshot] = []

        for dateLine in dateLines {
            let trimmed = dateLine.trimmingCharacters(in: .whitespaces)
            if let date = dateFormatter.date(from: trimmed) {
                loadedSnapshots.append(APFSSnapshot(
                    id: trimmed,
                    name: "com.apple.TimeMachine.\(trimmed).local",
                    date: date,
                    size: nil
                ))
            }
        }

        snapshots = loadedSnapshots.sorted { $0.date > $1.date }
        totalSnapshotCount = snapshots.count
        timeMachineEnabled = !snapshots.isEmpty
        isLoading = false

        logManager.log("Found \(snapshots.count) local APFS snapshots", level: .info, category: .scanning)
    }

    // MARK: - Delete Snapshots

    func deleteSnapshot(_ snapshot: APFSSnapshot) async -> Bool {
        isDeleting = true

        let result = await runAdminCommand("tmutil deletelocalsnapshots \(snapshot.id)")

        isDeleting = false

        if result {
            snapshots.removeAll { $0.id == snapshot.id }
            totalSnapshotCount = snapshots.count
            logManager.log("Deleted snapshot: \(snapshot.id)", level: .success, category: .deletion)
            return true
        } else {
            logManager.log("Failed to delete snapshot: \(snapshot.id)", level: .error, category: .deletion)
            return false
        }
    }

    func deleteSnapshotsBefore(_ date: Date) async -> Int {
        isDeleting = true
        var deletedCount = 0

        let toDelete = snapshots.filter { $0.date < date }
        for snapshot in toDelete {
            let result = await runAdminCommand("tmutil deletelocalsnapshots \(snapshot.id)")
            if result {
                deletedCount += 1
            }
        }

        isDeleting = false
        await loadSnapshots()

        logManager.log("Deleted \(deletedCount) snapshots before \(date.formatted())", level: .success, category: .deletion)
        return deletedCount
    }

    func thinSnapshots(urgency: Int = 4) async -> Bool {
        // urgency: 1 (gentle) to 4 (aggressive)
        isDeleting = true

        let result = await runAdminCommand("tmutil thinlocalsnapshots / \(urgency)")

        isDeleting = false

        if result {
            await loadSnapshots()
            logManager.log("Thinned local snapshots (urgency \(urgency))", level: .success, category: .deletion)
            return true
        }
        return false
    }

    // MARK: - Helpers

    private func runCommand(_ executable: String, arguments: [String]) async -> String? {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments

        let outputPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = FileHandle.nullDevice

        do {
            try process.run()
            return await withCheckedContinuation { continuation in
                process.terminationHandler = { p in
                    if p.terminationStatus == 0 {
                        let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
                        continuation.resume(returning: String(data: data, encoding: .utf8))
                    } else {
                        continuation.resume(returning: nil)
                    }
                }
            }
        } catch {
            return nil
        }
    }

    private func runAdminCommand(_ command: String) async -> Bool {
        let script = "do shell script \"\(command)\" with administrator privileges"

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        process.arguments = ["-e", script]
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice

        do {
            try process.run()
            return await withCheckedContinuation { continuation in
                process.terminationHandler = { p in
                    continuation.resume(returning: p.terminationStatus == 0)
                }
            }
        } catch {
            return false
        }
    }
}
