import Foundation

// MARK: - Homebrew Cleaner

@MainActor
class HomebrewCleaner: ObservableObject {
    static let shared = HomebrewCleaner()

    @Published var isAvailable = false
    @Published var isRunning = false
    @Published var cacheSize: Int64 = 0
    @Published var outdatedCount = 0
    @Published var results: [HomebrewResult] = []

    private let logManager = LogManager.shared
    private let fileManager = FileManager.default

    private var brewPath: String? {
        // Check common brew locations
        for path in ["/opt/homebrew/bin/brew", "/usr/local/bin/brew"] {
            if fileManager.fileExists(atPath: path) {
                return path
            }
        }
        return nil
    }

    private init() {
        isAvailable = brewPath != nil
    }

    struct HomebrewResult: Identifiable {
        let id = UUID()
        let action: String
        let success: Bool
        let message: String
    }

    // MARK: - Info

    func checkStatus() async {
        guard let brew = brewPath else {
            isAvailable = false
            return
        }
        isAvailable = true

        // Get cache size
        let home = FileManager.default.homeDirectoryForCurrentUser.path
        let cacheDirs = [
            "\(home)/Library/Caches/Homebrew",
            "/opt/homebrew/var/homebrew/cache",
        ]
        cacheSize = 0
        for dir in cacheDirs {
            cacheSize += await Task.detached {
                self.calculateSize(at: dir)
            }.value
        }

        // Get outdated count
        if let output = await runBrewCommand(brew, args: ["outdated", "--quiet"]) {
            outdatedCount = output.components(separatedBy: "\n").filter { !$0.isEmpty }.count
        }
    }

    // MARK: - Cleanup Actions

    func runFullCleanup() async {
        guard let brew = brewPath else { return }

        isRunning = true
        results = []

        // 1. brew cleanup --prune=all
        let cleanupResult = await runBrewCommand(brew, args: ["cleanup", "--prune=all"])
        results.append(HomebrewResult(
            action: "Cleanup old versions",
            success: cleanupResult != nil,
            message: cleanupResult ?? "Failed"
        ))

        // 2. brew autoremove
        let autoremoveResult = await runBrewCommand(brew, args: ["autoremove"])
        results.append(HomebrewResult(
            action: "Remove orphaned dependencies",
            success: autoremoveResult != nil,
            message: autoremoveResult ?? "Failed"
        ))

        // 3. Clean Homebrew cache directory
        let home = FileManager.default.homeDirectoryForCurrentUser.path
        let cacheDir = "\(home)/Library/Caches/Homebrew"
        var cacheFreed: Int64 = 0
        if fileManager.fileExists(atPath: cacheDir) {
            let sizeBefore = await Task.detached { self.calculateSize(at: cacheDir) }.value
            if let contents = try? fileManager.contentsOfDirectory(atPath: cacheDir) {
                for item in contents {
                    let fullPath = (cacheDir as NSString).appendingPathComponent(item)
                    try? fileManager.removeItem(atPath: fullPath)
                }
            }
            let sizeAfter = await Task.detached { self.calculateSize(at: cacheDir) }.value
            cacheFreed = sizeBefore - sizeAfter
        }

        results.append(HomebrewResult(
            action: "Clear Homebrew cache",
            success: true,
            message: "Freed \(ByteCountFormatter.string(fromByteCount: cacheFreed, countStyle: .file))"
        ))

        isRunning = false

        // Refresh status
        await checkStatus()

        logManager.log("Homebrew cleanup complete", level: .success, category: .system)
    }

    // MARK: - Helpers

    private func runBrewCommand(_ brew: String, args: [String]) async -> String? {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: brew)
        process.arguments = args

        let outputPipe = Pipe()
        let errorPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = errorPipe

        do {
            try process.run()

            return await withCheckedContinuation { continuation in
                process.terminationHandler = { _ in
                    let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
                    let output = String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
                    continuation.resume(returning: output)
                }
            }
        } catch {
            return nil
        }
    }

    nonisolated private func calculateSize(at path: String) -> Int64 {
        let fm = FileManager.default
        let url = URL(fileURLWithPath: path)
        var totalSize: Int64 = 0

        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }
        return totalSize
    }

    var formattedCacheSize: String {
        ByteCountFormatter.string(fromByteCount: cacheSize, countStyle: .file)
    }
}
