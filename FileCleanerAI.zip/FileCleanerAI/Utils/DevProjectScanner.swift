import Foundation

// MARK: - Data Models

struct DevProject: Identifiable {
    let id: String
    let name: String
    let path: String
    let language: ProjectLanguage
    let lastModified: Date
    var artifacts: [DevArtifact]
    var totalArtifactSize: Int64 { artifacts.reduce(0) { $0 + $1.size } }

    var formattedArtifactSize: String {
        ByteCountFormatter.string(fromByteCount: totalArtifactSize, countStyle: .file)
    }

    var staleness: String {
        let days = Calendar.current.dateComponents([.day], from: lastModified, to: Date()).day ?? 0
        if days == 0 { return "Today" }
        if days == 1 { return "Yesterday" }
        if days < 30 { return "\(days) days ago" }
        if days < 365 { return "\(days / 30) months ago" }
        return "\(days / 365) years ago"
    }

    var isStale: Bool {
        let days = Calendar.current.dateComponents([.day], from: lastModified, to: Date()).day ?? 0
        return days > 90
    }
}

struct DevArtifact: Identifiable {
    let id: String
    let path: String
    let name: String
    let size: Int64
    let type: ArtifactType

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }
}

enum ProjectLanguage: String, CaseIterable {
    case javascript = "JavaScript/Node"
    case python = "Python"
    case rust = "Rust"
    case swift = "Swift/Xcode"
    case java = "Java/Gradle"
    case go = "Go"
    case ruby = "Ruby"
    case dotnet = ".NET"
    case flutter = "Flutter/Dart"
    case php = "PHP"
    case unknown = "Other"

    var icon: String {
        switch self {
        case .javascript: return "j.square.fill"
        case .python: return "p.square.fill"
        case .rust: return "r.square.fill"
        case .swift: return "swift"
        case .java: return "cup.and.saucer.fill"
        case .go: return "g.square.fill"
        case .ruby: return "diamond.fill"
        case .dotnet: return "number.square.fill"
        case .flutter: return "f.square.fill"
        case .php: return "chevron.left.forwardslash.chevron.right"
        case .unknown: return "questionmark.square"
        }
    }

    var color: String {
        switch self {
        case .javascript: return "yellow"
        case .python: return "blue"
        case .rust: return "orange"
        case .swift: return "red"
        case .java: return "brown"
        case .go: return "cyan"
        case .ruby: return "red"
        case .dotnet: return "purple"
        case .flutter: return "blue"
        case .php: return "indigo"
        case .unknown: return "gray"
        }
    }
}

enum ArtifactType: String {
    case nodeModules = "node_modules"
    case dist = "dist/build"
    case pythonVenv = "virtualenv"
    case pycache = "__pycache__"
    case rustTarget = "target"
    case derivedData = "DerivedData"
    case pods = "Pods"
    case swiftBuild = ".build"
    case gradle = ".gradle"
    case javaBuild = "build/target"
    case goCache = "go_vendor"
    case rubyBundle = "vendor/bundle"
    case dotnetBin = "bin/obj"
    case flutterBuild = ".dart_tool/build"
    case phpVendor = "php_vendor"
    case coverage = "coverage"
    case cache = "cache"
}

// MARK: - Project Signature (how to detect a project root)

private struct ProjectSignature {
    let markerFile: String
    let language: ProjectLanguage
    let artifactDirs: [(name: String, type: ArtifactType)]
}

private let projectSignatures: [ProjectSignature] = [
    ProjectSignature(markerFile: "package.json", language: .javascript, artifactDirs: [
        ("node_modules", .nodeModules), ("dist", .dist), ("build", .dist),
        (".next", .cache), (".nuxt", .cache), (".cache", .cache),
        ("coverage", .coverage), (".parcel-cache", .cache), (".turbo", .cache),
    ]),
    ProjectSignature(markerFile: "requirements.txt", language: .python, artifactDirs: [
        (".venv", .pythonVenv), ("venv", .pythonVenv), ("env", .pythonVenv),
        ("__pycache__", .pycache), (".pytest_cache", .cache),
        (".mypy_cache", .cache), ("htmlcov", .coverage), (".tox", .cache),
    ]),
    ProjectSignature(markerFile: "pyproject.toml", language: .python, artifactDirs: [
        (".venv", .pythonVenv), ("venv", .pythonVenv),
        ("__pycache__", .pycache), (".pytest_cache", .cache),
        (".mypy_cache", .cache), ("htmlcov", .coverage),
    ]),
    ProjectSignature(markerFile: "Cargo.toml", language: .rust, artifactDirs: [
        ("target", .rustTarget),
    ]),
    ProjectSignature(markerFile: "Package.swift", language: .swift, artifactDirs: [
        (".build", .swiftBuild), ("DerivedData", .derivedData),
    ]),
    ProjectSignature(markerFile: "Podfile", language: .swift, artifactDirs: [
        ("Pods", .pods), ("DerivedData", .derivedData),
    ]),
    ProjectSignature(markerFile: "build.gradle", language: .java, artifactDirs: [
        (".gradle", .gradle), ("build", .javaBuild),
    ]),
    ProjectSignature(markerFile: "build.gradle.kts", language: .java, artifactDirs: [
        (".gradle", .gradle), ("build", .javaBuild),
    ]),
    ProjectSignature(markerFile: "pom.xml", language: .java, artifactDirs: [
        ("target", .javaBuild), (".m2", .cache),
    ]),
    ProjectSignature(markerFile: "go.mod", language: .go, artifactDirs: [
        ("vendor", .goCache),
    ]),
    ProjectSignature(markerFile: "Gemfile", language: .ruby, artifactDirs: [
        ("vendor/bundle", .rubyBundle), (".bundle", .cache),
        ("coverage", .coverage), ("tmp/cache", .cache),
    ]),
    ProjectSignature(markerFile: "pubspec.yaml", language: .flutter, artifactDirs: [
        (".dart_tool", .flutterBuild), ("build", .flutterBuild),
    ]),
    ProjectSignature(markerFile: "composer.json", language: .php, artifactDirs: [
        ("vendor", .phpVendor),
    ]),
]

// MARK: - Dev Project Scanner

@MainActor
class DevProjectScanner: ObservableObject {
    static let shared = DevProjectScanner()

    @Published var projects: [DevProject] = []
    @Published var isScanning = false
    @Published var scanProgress: Double = 0.0
    @Published var totalReclaimable: Int64 = 0

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let home = FileManager.default.homeDirectoryForCurrentUser.path

    private init() {}

    /// Directories to search for dev projects
    private var searchRoots: [String] {
        [
            "\(home)/Documents",
            "\(home)/Projects",
            "\(home)/Developer",
            "\(home)/Desktop",
            "\(home)/code",
            "\(home)/dev",
            "\(home)/workspace",
            "\(home)/repos",
            "\(home)/src",
            "\(home)/git",
        ].filter { fileManager.fileExists(atPath: $0) }
    }

    // MARK: - Scanning

    func scanForProjects() async {
        isScanning = true
        scanProgress = 0.0
        projects = []
        totalReclaimable = 0

        let roots = searchRoots
        let totalRoots = Double(roots.count)

        var allProjects: [DevProject] = []

        for (index, root) in roots.enumerated() {
            let found = await Task.detached {
                self.findProjects(in: root, maxDepth: 4)
            }.value
            allProjects.append(contentsOf: found)
            scanProgress = Double(index + 1) / totalRoots * 0.5
        }

        // Deduplicate by path
        var seen = Set<String>()
        allProjects = allProjects.filter { seen.insert($0.path).inserted }

        // Calculate artifact sizes in parallel
        let total = Double(allProjects.count)
        for i in allProjects.indices {
            var updatedArtifacts: [DevArtifact] = []
            for artifact in allProjects[i].artifacts {
                let size = await Task.detached {
                    self.calculateDirectorySize(at: artifact.path)
                }.value
                if size > 0 {
                    updatedArtifacts.append(DevArtifact(
                        id: artifact.id, path: artifact.path,
                        name: artifact.name, size: size, type: artifact.type
                    ))
                }
            }
            allProjects[i].artifacts = updatedArtifacts
            scanProgress = 0.5 + (Double(i + 1) / total * 0.5)
        }

        // Filter out projects with no artifacts
        allProjects = allProjects.filter { $0.totalArtifactSize > 0 }

        // Sort by artifact size descending
        allProjects.sort { $0.totalArtifactSize > $1.totalArtifactSize }

        projects = allProjects
        totalReclaimable = allProjects.reduce(0) { $0 + $1.totalArtifactSize }
        isScanning = false
        scanProgress = 1.0

        logManager.log(
            "Dev project scan: found \(projects.count) projects with \(ByteCountFormatter.string(fromByteCount: totalReclaimable, countStyle: .file)) reclaimable",
            level: .info, category: .scanning
        )
    }

    private nonisolated func findProjects(in root: String, maxDepth: Int) -> [DevProject] {
        let fm = FileManager.default
        var results: [DevProject] = []

        guard maxDepth > 0 else { return results }
        guard let contents = try? fm.contentsOfDirectory(atPath: root) else { return results }

        for item in contents {
            guard !item.hasPrefix(".") else { continue }
            let itemPath = (root as NSString).appendingPathComponent(item)

            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: itemPath, isDirectory: &isDir), isDir.boolValue else { continue }

            // Check if this directory is a project root
            if let project = detectProject(at: itemPath) {
                results.append(project)
                // Don't recurse into recognized projects
                continue
            }

            // Recurse into subdirectories
            results.append(contentsOf: findProjects(in: itemPath, maxDepth: maxDepth - 1))
        }

        return results
    }

    private nonisolated func detectProject(at path: String) -> DevProject? {
        let fm = FileManager.default

        for sig in projectSignatures {
            let markerPath = (path as NSString).appendingPathComponent(sig.markerFile)
            guard fm.fileExists(atPath: markerPath) else { continue }

            // Found a project — collect artifacts
            var artifacts: [DevArtifact] = []
            for (dirName, type) in sig.artifactDirs {
                let artifactPath = (path as NSString).appendingPathComponent(dirName)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: artifactPath, isDirectory: &isDir), isDir.boolValue {
                    artifacts.append(DevArtifact(
                        id: artifactPath, path: artifactPath,
                        name: dirName, size: 0, type: type
                    ))
                }
            }

            // Get last modified date
            let url = URL(fileURLWithPath: path)
            let lastModified = (try? url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? Date.distantPast

            let name = (path as NSString).lastPathComponent
            return DevProject(
                id: path, name: name, path: path,
                language: sig.language, lastModified: lastModified,
                artifacts: artifacts
            )
        }

        return nil
    }

    // MARK: - Cleaning

    func cleanProject(_ project: DevProject) async -> CleaningResult {
        var success = 0
        var failed = 0
        var bytesFreed: Int64 = 0

        for artifact in project.artifacts {
            do {
                try fileManager.trashItem(at: URL(fileURLWithPath: artifact.path), resultingItemURL: nil)
                success += 1
                bytesFreed += artifact.size
                logManager.log("Cleaned: \(artifact.path)", level: .success, category: .deletion)
            } catch {
                failed += 1
                logManager.log("Failed: \(artifact.path) — \(error.localizedDescription)", level: .error, category: .deletion)
            }
        }

        // Refresh
        if let index = projects.firstIndex(where: { $0.path == project.path }) {
            projects[index].artifacts = []
            totalReclaimable = projects.reduce(0) { $0 + $1.totalArtifactSize }
        }

        return CleaningResult(success: success, failed: failed, bytesFreed: bytesFreed)
    }

    func cleanAllStaleProjects() async -> CleaningResult {
        let stale = projects.filter { $0.isStale }
        var totalSuccess = 0
        var totalFailed = 0
        var totalFreed: Int64 = 0

        for project in stale {
            let result = await cleanProject(project)
            totalSuccess += result.success
            totalFailed += result.failed
            totalFreed += result.bytesFreed
        }

        return CleaningResult(success: totalSuccess, failed: totalFailed, bytesFreed: totalFreed)
    }

    // MARK: - Helpers

    nonisolated private func calculateDirectorySize(at path: String) -> Int64 {
        let fm = FileManager.default
        let url = URL(fileURLWithPath: path)
        var totalSize: Int64 = 0

        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }

        return totalSize
    }
}
