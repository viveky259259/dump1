import Foundation

/// Manages smart batching of file/folder size calculations with prioritization
@MainActor
class SizeCalculationManager: ObservableObject {
    static let shared = SizeCalculationManager()
    
    /// Published property to notify when sizes are calculated
    @Published var calculatedSizes: [String: Int64] = [:]

    // MARK: - Debug Info (Published for DebugView)

    @Published private(set) var debugHighPriorityCount: Int = 0
    @Published private(set) var debugLowPriorityCount: Int = 0
    @Published private(set) var debugActiveCount: Int = 0
    @Published private(set) var debugCacheCount: Int = 0
    @Published private(set) var debugCurrentFolder: String = "None"

    // MARK: - Priority Queues
    
    /// High priority queue for currently open folder and its children
    private var highPriorityQueue: [SizeCalculationTask] = []
    
    /// Low priority queue for previously calculated folders
    private var lowPriorityQueue: [SizeCalculationTask] = []
    
    /// Currently active calculations
    private var activeCalculations: [String: Task<Void, Never>] = [:]
    
    /// Track which folder is currently open
    private var currentOpenFolder: String?
    
    /// Track retry attempts for each path (max 3)
    private var retryAttempts: [String: Int] = [:]
    
    /// Maximum retry attempts
    private let maxRetryAttempts = 3
    
    /// Maximum concurrent calculations
    private let maxConcurrentCalculations = 3
    
    /// Currently running calculation count
    private var runningCalculationCount = 0
    
    /// Size cache
    private var sizeCache: [String: Int64] = [:]
    
    /// Callbacks for when sizes are calculated
    private var sizeCallbacks: [String: (Int64) -> Void] = [:]
    
    private let logManager = LogManager.shared
    
    private init() {
        startProcessingQueues()
    }

    // MARK: - Debug API

    /// Get list of pending high priority paths (for debug view)
    var pendingHighPriorityPaths: [String] {
        highPriorityQueue.prefix(10).map { $0.path }
    }

    /// Get list of pending low priority paths (for debug view)
    var pendingLowPriorityPaths: [String] {
        lowPriorityQueue.prefix(10).map { $0.path }
    }

    /// Get list of active calculation paths (for debug view)
    var activeCalculationPaths: [String] {
        Array(activeCalculations.keys)
    }

    /// Cancel all pending and active calculations
    func cancelAllCalculations() {
        // Cancel all active tasks
        for (_, task) in activeCalculations {
            task.cancel()
        }
        activeCalculations.removeAll()
        runningCalculationCount = 0

        // Clear queues
        highPriorityQueue.removeAll()
        lowPriorityQueue.removeAll()

        // Clear callbacks
        sizeCallbacks.removeAll()

        updateDebugInfo()
        logManager.log("All calculations cancelled", level: .info, category: .system)
    }

    /// Update debug info (called when internal state changes)
    private func updateDebugInfo() {
        debugHighPriorityCount = highPriorityQueue.count
        debugLowPriorityCount = lowPriorityQueue.count
        debugActiveCount = activeCalculations.count
        debugCacheCount = sizeCache.count
        debugCurrentFolder = currentOpenFolder ?? "None"
    }

    // MARK: - Public API
    
    /// Set the currently open folder - prioritizes its calculations
    func setCurrentOpenFolder(_ path: String?) {
        let previousFolder = currentOpenFolder
        currentOpenFolder = path
        
        // If folder changed, move previous folder's tasks to low priority
        if let previous = previousFolder, previous != path {
            moveToLowPriority(for: previous)
        }
        
        // Prioritize current folder's tasks
        if let current = path {
            prioritizeFolder(current)
        }
        
        updateDebugInfo()
        logManager.log("Current folder set to: \(path ?? "none")", level: .debug, category: .system)
    }

    /// Request size calculation for a path
    func requestSizeCalculation(
        for path: String,
        priority: CalculationPriority = .normal,
        callback: @escaping (Int64) -> Void
    ) {
        // Check cache first
        if let cachedSize = sizeCache[path] {
            callback(cachedSize)
            return
        }
        
        // Check if already calculating
        if activeCalculations[path] != nil {
            // Store callback to be called when calculation completes
            sizeCallbacks[path] = callback
            return
        }
        
        // Check if already in queue
        if highPriorityQueue.contains(where: { $0.path == path }) ||
           lowPriorityQueue.contains(where: { $0.path == path }) {
            // Update callback
            sizeCallbacks[path] = callback
            return
        }
        
        // Create new task
        let task = SizeCalculationTask(
            path: path,
            priority: priority,
            retryCount: retryAttempts[path] ?? 0
        )
        
        // Add to appropriate queue
        if priority == .high || isCurrentFolderOrChild(path) {
            highPriorityQueue.append(task)
            logManager.log("Added to high priority queue: \(path)", level: .debug, category: .system)
        } else {
            lowPriorityQueue.append(task)
            logManager.log("Added to low priority queue: \(path)", level: .debug, category: .system)
        }

        // Store callback
        sizeCallbacks[path] = callback
        updateDebugInfo()
    }
    
    /// Cancel calculations for a folder and its children
    func cancelCalculations(for folderPath: String) {
        let prefix = folderPath.hasSuffix("/") ? folderPath : folderPath + "/"
        
        // Cancel active calculations
        for (path, task) in activeCalculations {
            if path == folderPath || path.hasPrefix(prefix) {
                task.cancel()
                activeCalculations.removeValue(forKey: path)
                runningCalculationCount -= 1
                logManager.log("Cancelled calculation for: \(path)", level: .debug, category: .system)
            }
        }
        
        // Remove from queues
        highPriorityQueue.removeAll { $0.path == folderPath || $0.path.hasPrefix(prefix) }
        lowPriorityQueue.removeAll { $0.path == folderPath || $0.path.hasPrefix(prefix) }
        
        // Remove callbacks
        sizeCallbacks = sizeCallbacks.filter { path, _ in
            path != folderPath && !path.hasPrefix(prefix)
        }
        updateDebugInfo()
    }

    /// Get cached size if available
    func getCachedSize(for path: String) -> Int64? {
        return sizeCache[path]
    }
    
    /// Check if path is current folder or its child (public method)
    func isCurrentFolderOrChild(_ path: String) -> Bool {
        guard let current = currentOpenFolder else { return false }
        return path == current || path.hasPrefix(current + "/")
    }
    
    /// Clear cache for a path
    func clearCache(for path: String) {
        sizeCache.removeValue(forKey: path)
    }
    
    // MARK: - Private Methods
    
    private func prioritizeFolder(_ folderPath: String) {
        let prefix = folderPath.hasSuffix("/") ? folderPath : folderPath + "/"
        
        // Move matching tasks from low to high priority
        let toPromote = lowPriorityQueue.filter { task in
            task.path == folderPath || task.path.hasPrefix(prefix)
        }
        
        lowPriorityQueue.removeAll { task in
            task.path == folderPath || task.path.hasPrefix(prefix)
        }
        
        highPriorityQueue.append(contentsOf: toPromote)
        
        if !toPromote.isEmpty {
            logManager.log("Promoted \(toPromote.count) tasks to high priority for folder: \(folderPath)", level: .debug, category: .system)
        }
    }
    
    private func moveToLowPriority(for folderPath: String) {
        let prefix = folderPath.hasSuffix("/") ? folderPath : folderPath + "/"
        
        // Move matching tasks from high to low priority
        let toDemote = highPriorityQueue.filter { task in
            task.path == folderPath || task.path.hasPrefix(prefix)
        }
        
        highPriorityQueue.removeAll { task in
            task.path == folderPath || task.path.hasPrefix(prefix)
        }
        
        lowPriorityQueue.append(contentsOf: toDemote)
        
        if !toDemote.isEmpty {
            logManager.log("Moved \(toDemote.count) tasks to low priority for folder: \(folderPath)", level: .debug, category: .system)
        }
    }
    
    private func startProcessingQueues() {
        Task {
            while true {
                await processQueues()
                try? await Task.sleep(nanoseconds: 100_000_000) // 100ms
            }
        }
    }
    
    private func processQueues() async {
        // Process high priority queue first
        while runningCalculationCount < maxConcurrentCalculations,
              let task = highPriorityQueue.first {
            highPriorityQueue.removeFirst()
            updateDebugInfo()
            await startCalculation(task)
        }

        // Then process low priority queue
        while runningCalculationCount < maxConcurrentCalculations,
              let task = lowPriorityQueue.first {
            lowPriorityQueue.removeFirst()
            updateDebugInfo()
            await startCalculation(task)
        }
    }
    
    private func startCalculation(_ task: SizeCalculationTask) async {
        guard runningCalculationCount < maxConcurrentCalculations else { return }
        
        runningCalculationCount += 1
        let path = task.path
        
        let calculationTask = Task {
            defer {
                Task { @MainActor in
                    self.activeCalculations.removeValue(forKey: path)
                    self.runningCalculationCount -= 1
                    self.updateDebugInfo()
                }
            }
            
            // Check if macOS provides direct size (for files)
            let size = await calculateSize(for: path)
            
            await MainActor.run {
                // Cache the result
                self.sizeCache[path] = size
                
                // Publish the calculated size for UI updates
                self.calculatedSizes[path] = size
                
                // Call callback if exists
                if let callback = self.sizeCallbacks.removeValue(forKey: path) {
                    callback(size)
                }
                
                // Reset retry count on success
                self.retryAttempts.removeValue(forKey: path)
                
                self.logManager.log("Calculated size for \(path): \(ByteCountFormatter.string(fromByteCount: size, countStyle: .file))", level: .debug, category: .system)
                self.updateDebugInfo()
            }
        }

        activeCalculations[path] = calculationTask
        updateDebugInfo()
        
        // Monitor task completion and handle retries
        Task {
            await calculationTask.value
            
            await MainActor.run {
                // Check if calculation actually completed (not cancelled)
                if calculationTask.isCancelled {
                    return
                }
                
                // Verify calculation happened - check if we have size or callback was called
                let hasSize = self.sizeCache[path] != nil
                let hadCallback = self.sizeCallbacks[path] == nil
                
                // If calculation didn't produce result and we haven't exceeded retries, retry
                if !hasSize && !hadCallback {
                    let retryCount = self.retryAttempts[path] ?? 0
                    if retryCount < self.maxRetryAttempts {
                        self.retryAttempts[path] = retryCount + 1
                        self.logManager.log("Retrying size calculation for \(path) (attempt \(retryCount + 1)/\(self.maxRetryAttempts))", level: .debug, category: .system)
                        
                        // Re-add to queue with higher priority
                        let retryTask = SizeCalculationTask(
                            path: path,
                            priority: .high,
                            retryCount: retryCount + 1
                        )
                        self.highPriorityQueue.insert(retryTask, at: 0) // Insert at front
                    } else {
                        self.logManager.log("Max retries reached for \(path), giving up", level: .warning, category: .system)
                        // Call callback with -2 to indicate failure
                        if let callback = self.sizeCallbacks.removeValue(forKey: path) {
                            callback(-2)
                        }
                    }
                }
            }
        }
    }
    
    /// Calculate size using macOS APIs when possible
    private func calculateSize(for path: String) async -> Int64 {
        return await Task.detached(priority: .userInitiated) {
            let url = URL(fileURLWithPath: path)
            let fileManager = FileManager.default
            
            do {
                let resourceValues = try url.resourceValues(forKeys: [
                    .fileSizeKey,
                    .isDirectoryKey,
                    .totalFileAllocatedSizeKey
                ])
                
                let isDirectory = resourceValues.isDirectory ?? false
                
                if isDirectory {
                    // For directories, we need to calculate recursively
                    // But we can use totalFileAllocatedSize for better performance on some systems
                    return await self.calculateDirectorySizeOptimized(at: url, fileManager: fileManager)
                } else {
                    // For files, macOS provides direct size via fileSizeKey
                    // Use totalFileAllocatedSize if available (more accurate for disk usage)
                    if let allocatedSize = resourceValues.totalFileAllocatedSize {
                        return Int64(allocatedSize)
                    } else if let fileSize = resourceValues.fileSize {
                        return Int64(fileSize)
                    }
                    return 0
                }
            } catch {
                return -2 // -2 = calculation failed
            }
        }.value
    }
    
    /// Optimized directory size calculation with batching
    private func calculateDirectorySizeOptimized(at url: URL, fileManager: FileManager) async -> Int64 {
        var totalSize: Int64 = 0

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles]
        ) else {
            return -2 // -2 = calculation failed (e.g., permission denied)
        }

        var batchCount = 0
        let batchSize = 1000

        while let fileURL = enumerator.nextObject() as? URL {
            // Check for cancellation
            if Task.isCancelled {
                break
            }

            do {
                let resourceValues = try fileURL.resourceValues(forKeys: [
                    .fileSizeKey,
                    .totalFileAllocatedSizeKey,
                    .isDirectoryKey,
                    .isSymbolicLinkKey
                ])

                // Skip symlinks to avoid double-counting
                if resourceValues.isSymbolicLink == true {
                    continue
                }

                // Only count files, not directories
                if let isDirectory = resourceValues.isDirectory, !isDirectory {
                    // Prefer allocated size (more accurate for disk usage)
                    if let allocatedSize = resourceValues.totalFileAllocatedSize {
                        totalSize += Int64(allocatedSize)
                    } else if let fileSize = resourceValues.fileSize {
                        totalSize += Int64(fileSize)
                    }
                }
            } catch {
                // Continue on error
                continue
            }

            batchCount += 1
            if batchCount % batchSize == 0 {
                await Task.yield()
            }
        }

        return totalSize
    }
}

// MARK: - Supporting Types

struct SizeCalculationTask {
    let path: String
    let priority: CalculationPriority
    let retryCount: Int
    let createdAt: Date
    
    init(path: String, priority: CalculationPriority, retryCount: Int = 0) {
        self.path = path
        self.priority = priority
        self.retryCount = retryCount
        self.createdAt = Date()
    }
}

enum CalculationPriority {
    case high
    case normal
    case low
}
