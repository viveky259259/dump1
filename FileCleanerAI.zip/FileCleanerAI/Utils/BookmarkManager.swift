import Foundation
import AppKit

/// Manages security-scoped bookmarks to persist folder access permissions
@MainActor
final class BookmarkManager {
    static let shared = BookmarkManager()
    
    private let userDefaults = UserDefaults.standard
    private let bookmarkKey = "savedBookmarks"
    private var activeBookmarks: [URL: Data] = [:]
    
    private init() {
        loadSavedBookmarks()
    }
    
    // MARK: - Save/Load Bookmarks
    
    /// Check if we have a bookmark for a URL
    func hasBookmark(for url: URL) -> Bool {
        return activeBookmarks[url] != nil
    }
    
    /// Save a security-scoped bookmark for a URL
    func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            
            activeBookmarks[url] = bookmarkData
            saveBookmarksToDisk()
            
            LogManager.shared.log("Saved bookmark for: \(url.path)", level: .debug, category: .system)
        } catch {
            LogManager.shared.log("Failed to save bookmark for \(url.path): \(error.localizedDescription)", level: .warning, category: .system)
        }
    }
    
    /// Load all saved bookmarks and start accessing them
    private func loadSavedBookmarks() {
        guard let savedData = userDefaults.dictionary(forKey: bookmarkKey) as? [String: Data] else {
            return
        }
        
        for (pathString, bookmarkData) in savedData {
            do {
                var isStale = false
                let url = try URL(
                    resolvingBookmarkData: bookmarkData,
                    options: [.withSecurityScope],
                    relativeTo: nil,
                    bookmarkDataIsStale: &isStale
                )
                
                if isStale {
                    LogManager.shared.log("Bookmark is stale for: \(pathString)", level: .warning, category: .system)
                    continue
                }
                
                // Start accessing the security-scoped resource
                guard url.startAccessingSecurityScopedResource() else {
                    LogManager.shared.log("Failed to access bookmark for: \(pathString)", level: .warning, category: .system)
                    continue
                }
                
                activeBookmarks[url] = bookmarkData
                LogManager.shared.log("Restored bookmark for: \(url.path)", level: .debug, category: .system)
                
            } catch {
                LogManager.shared.log("Failed to resolve bookmark for \(pathString): \(error.localizedDescription)", level: .warning, category: .system)
            }
        }
    }
    
    private func saveBookmarksToDisk() {
        var bookmarksDict: [String: Data] = [:]
        
        for (url, data) in activeBookmarks {
            bookmarksDict[url.path] = data
        }
        
        userDefaults.set(bookmarksDict, forKey: bookmarkKey)
    }
    
    // MARK: - Request Access
    
    /// Start accessing a security-scoped resource using saved bookmark
    func startAccessingSecurityScopedResource(for url: URL) -> Bool {
        // Check if we have a bookmark for this URL
        guard let bookmarkData = activeBookmarks[url] else {
            return false
        }
        
        do {
            var isStale = false
            let resolvedURL = try URL(
                resolvingBookmarkData: bookmarkData,
                options: [.withSecurityScope],
                relativeTo: nil,
                bookmarkDataIsStale: &isStale
            )
            
            if isStale {
                // Bookmark is stale, remove it
                activeBookmarks.removeValue(forKey: url)
                saveBookmarksToDisk()
                return false
            }
            
            // Start accessing the resource
            return resolvedURL.startAccessingSecurityScopedResource()
        } catch {
            LogManager.shared.log("Failed to access bookmark: \(error.localizedDescription)", level: .warning, category: .system)
            return false
        }
    }
    
    /// Request access to a folder with a file picker, then save the bookmark
    func requestAccess(for url: URL) -> Bool {
        let folderPath = url.path
        let openPanel = NSOpenPanel()
        openPanel.message = "Grant AI File Cleaner access to scan and manage files in this folder"
        openPanel.prompt = "Grant Access"
        openPanel.canChooseFiles = false
        openPanel.canChooseDirectories = true
        openPanel.allowsMultipleSelection = false
        openPanel.directoryURL = URL(fileURLWithPath: folderPath)
        
        let response = openPanel.runModal()
        
        if response == .OK, let selectedURL = openPanel.url {
            // Start accessing the resource
            guard selectedURL.startAccessingSecurityScopedResource() else {
                return false
            }
            
            // Save the bookmark
            saveBookmark(for: selectedURL)
            return true
        }
        
        return false
    }
    
    /// Check if we have bookmark access to a folder
    func hasBookmark(for path: String) -> Bool {
        let url = URL(fileURLWithPath: path)
        return activeBookmarks.keys.contains(where: { $0.path == url.path })
    }
    
    /// Stop accessing a specific security-scoped resource
    func stopAccessingSecurityScopedResource(for url: URL) {
        url.stopAccessingSecurityScopedResource()
    }

    /// Stop accessing all security-scoped resources (call on app termination)
    func stopAccessingAll() {
        for url in activeBookmarks.keys {
            url.stopAccessingSecurityScopedResource()
        }
    }
}
