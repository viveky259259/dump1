import Foundation
import AppKit

// MARK: - Data Models

struct SystemDataCategory: Identifiable {
    let id: String
    let name: String
    let description: String
    let icon: String
    let paths: [String]
    var isSelected: Bool
    var requiresAdmin: Bool
    var warningMessage: String?
    var detectedSize: Int64
    var detectedItems: [SystemDataItem]

    init(
        id: String,
        name: String,
        description: String,
        icon: String,
        paths: [String],
        isSelected: Bool = false,
        requiresAdmin: Bool = false,
        warningMessage: String? = nil
    ) {
        self.id = id
        self.name = name
        self.description = description
        self.icon = icon
        self.paths = paths
        self.isSelected = isSelected
        self.requiresAdmin = requiresAdmin
        self.warningMessage = warningMessage
        self.detectedSize = 0
        self.detectedItems = []
    }

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: detectedSize, countStyle: .file)
    }

    var hasData: Bool {
        detectedSize > 0
    }

    var itemCount: Int {
        detectedItems.count
    }
}

struct SystemDataItem: Identifiable, Hashable {
    let id: String
    let path: String
    let name: String
    var size: Int64
    let isDirectory: Bool
    let iconName: String
    let parentCategoryId: String

    var formattedSize: String {
        if size < 0 {
            return "Calculating..."
        }
        return ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(path)
    }

    static func == (lhs: SystemDataItem, rhs: SystemDataItem) -> Bool {
        lhs.path == rhs.path
    }
}

// MARK: - System Data Scanner

@MainActor
class SystemDataScanner: ObservableObject {
    static let shared = SystemDataScanner()

    @Published var categories: [SystemDataCategory] = []
    @Published var isScanning = false
    @Published var isCleaning = false
    @Published var cleaningProgress: Double = 0.0
    @Published var totalDataFound: Int64 = 0
    @Published var lastScanDate: Date?
    @Published var scanProgress: Double = 0.0

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let homeDirectory = FileManager.default.homeDirectoryForCurrentUser.path

    private init() {
        initializeCategories()
    }

    // MARK: - Category Definitions

    private func initializeCategories() {
        categories = [
            SystemDataCategory(
                id: "user_caches",
                name: "User Caches",
                description: "Application caches stored in your Library folder",
                icon: "folder.badge.gearshape",
                paths: ["~/Library/Caches"],
                isSelected: true
            ),
            SystemDataCategory(
                id: "system_caches",
                name: "System Caches",
                description: "System-level caches shared across all users",
                icon: "gearshape.2.fill",
                paths: ["/Library/Caches"],
                requiresAdmin: true
            ),
            SystemDataCategory(
                id: "user_logs",
                name: "User Logs",
                description: "Application and system logs in your Library",
                icon: "doc.text.fill",
                paths: ["~/Library/Logs"],
                isSelected: true
            ),
            SystemDataCategory(
                id: "system_logs",
                name: "System Logs",
                description: "System-wide log files and diagnostics",
                icon: "doc.text.magnifyingglass",
                paths: ["/var/log", "/Library/Logs"],
                requiresAdmin: true
            ),
            SystemDataCategory(
                id: "temp_files",
                name: "Temporary Files",
                description: "Temporary files created by the system and apps",
                icon: "clock.arrow.circlepath",
                paths: ["/tmp", "/private/var/folders"],
                requiresAdmin: true,
                warningMessage: "Some temporary files may be in use by running applications. Deleting them could cause issues."
            ),
            SystemDataCategory(
                id: "app_support",
                name: "Application Support",
                description: "App configuration data, preferences, and support files",
                icon: "app.badge.fill",
                paths: ["~/Library/Application Support"],
                warningMessage: "Deleting application support data may reset app configurations and preferences."
            ),
            SystemDataCategory(
                id: "ios_backups",
                name: "iOS Device Backups",
                description: "iPhone and iPad backups stored on this Mac",
                icon: "iphone.gen3",
                paths: ["~/Library/Application Support/MobileSync/Backup"],
                warningMessage: "Deleting iOS backups is permanent and cannot be recovered from Trash."
            ),
            SystemDataCategory(
                id: "xcode_developer",
                name: "Xcode/Developer Data",
                description: "Xcode derived data, archives, and developer caches",
                icon: "hammer.fill",
                paths: ["~/Library/Developer"],
                isSelected: true
            ),
            SystemDataCategory(
                id: "mail_downloads",
                name: "Mail Downloads",
                description: "Attachments downloaded from Mail app",
                icon: "envelope.fill",
                paths: ["~/Library/Containers/com.apple.mail/Data/Library/Mail Downloads"],
                isSelected: true
            ),
            SystemDataCategory(
                id: "saved_app_state",
                name: "Saved Application State",
                description: "Window positions and state saved by applications",
                icon: "square.stack.3d.up.fill",
                paths: ["~/Library/Saved Application State"],
                isSelected: true
            )
        ]
    }

    // MARK: - Scanning

    func scanForSystemData() async {
        isScanning = true
        totalDataFound = 0
        scanProgress = 0.0

        let totalCategories = Double(categories.count)

        for i in categories.indices {
            var categorySize: Int64 = 0
            var allItems: [SystemDataItem] = []

            for pathPattern in categories[i].paths {
                let expandedPath = (pathPattern as NSString).expandingTildeInPath

                guard fileManager.fileExists(atPath: expandedPath) else { continue }

                let items = getTopLevelItems(at: expandedPath, categoryId: categories[i].id)
                allItems.append(contentsOf: items)

                // Calculate sizes on background thread
                let path = expandedPath
                let size = await Task.detached {
                    self.calculateDirectorySize(at: path)
                }.value

                categorySize += size
            }

            categories[i].detectedSize = categorySize
            categories[i].detectedItems = allItems
            totalDataFound += categorySize
            scanProgress = Double(i + 1) / totalCategories
        }

        lastScanDate = Date()
        isScanning = false
        scanProgress = 1.0

        logManager.log(
            "System data scan complete. Found \(ByteCountFormatter.string(fromByteCount: totalDataFound, countStyle: .file)) of system data",
            level: .info, category: .scanning
        )
    }

    // MARK: - Directory Browsing

    func getTopLevelItems(at path: String, categoryId: String) -> [SystemDataItem] {
        guard let contents = try? fileManager.contentsOfDirectory(atPath: path) else {
            return []
        }

        return contents.compactMap { name -> SystemDataItem? in
            guard !name.hasPrefix(".") || name == ".Trash" else { return nil }

            let fullPath = (path as NSString).appendingPathComponent(name)
            var isDir: ObjCBool = false
            guard fileManager.fileExists(atPath: fullPath, isDirectory: &isDir) else { return nil }

            let size = fileSizeQuick(at: fullPath, isDirectory: isDir.boolValue)
            let icon = isDir.boolValue ? "folder.fill" : iconForFile(name: name)

            return SystemDataItem(
                id: fullPath,
                path: fullPath,
                name: name,
                size: size,
                isDirectory: isDir.boolValue,
                iconName: icon,
                parentCategoryId: categoryId
            )
        }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    func getChildItems(at path: String, categoryId: String) -> [SystemDataItem] {
        return getTopLevelItems(at: path, categoryId: categoryId)
    }

    /// Get children of a SystemDataItem (for NavigationStack drill-down)
    func getChildren(for item: SystemDataItem) -> [SystemDataItem] {
        return getTopLevelItems(at: item.path, categoryId: item.parentCategoryId)
    }

    /// Calculate sizes for multiple directories in parallel
    func calculateSizesInParallel(for items: [SystemDataItem]) async -> [String: Int64] {
        await withTaskGroup(of: (String, Int64).self) { group in
            for item in items where item.isDirectory && item.size == -1 {
                let path = item.path
                group.addTask {
                    let size = self.calculateDirectorySize(at: path)
                    return (path, size)
                }
            }

            var results: [String: Int64] = [:]
            for await (path, size) in group {
                results[path] = size
            }
            return results
        }
    }

    // MARK: - Size Calculation

    nonisolated func calculateDirectorySize(at path: String) -> Int64 {
        let fm = FileManager.default
        let url = URL(fileURLWithPath: path)

        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return 0 }

        if !isDir.boolValue {
            if let values = try? url.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileSizeKey]) {
                return Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
            return 0
        }

        var totalSize: Int64 = 0
        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }

        return totalSize
    }

    // MARK: - Cleaning

    func cleanSelectedCategories() async -> CleaningResult {
        let selectedCategories = categories.filter { $0.isSelected && $0.hasData }

        guard !selectedCategories.isEmpty else {
            return CleaningResult(success: 0, failed: 0, bytesFreed: 0)
        }

        isCleaning = true
        cleaningProgress = 0.0

        var successCount = 0
        var failedCount = 0
        var bytesFreed: Int64 = 0

        let totalItems = selectedCategories.reduce(0) { $0 + $1.detectedItems.count }
        var processedItems = 0

        for category in selectedCategories {
            logManager.log("Cleaning system data category: \(category.name)", level: .info, category: .deletion)

            for item in category.detectedItems {
                let sizeBefore = item.size > 0 ? item.size : Int64(0)

                do {
                    if category.requiresAdmin {
                        try await PrivilegedFileManager.shared.deleteItem(at: item.path)
                    } else {
                        try fileManager.trashItem(at: URL(fileURLWithPath: item.path), resultingItemURL: nil)
                    }
                    successCount += 1
                    bytesFreed += sizeBefore
                    logManager.log("Cleaned: \(item.path)", level: .success, category: .deletion)
                } catch {
                    failedCount += 1
                    logManager.log("Failed to clean: \(item.path) - \(error.localizedDescription)", level: .error, category: .deletion)
                }

                processedItems += 1
                cleaningProgress = Double(processedItems) / Double(max(totalItems, 1))
            }
        }

        isCleaning = false
        cleaningProgress = 1.0

        await scanForSystemData()

        logManager.log(
            "System data cleaning complete. Freed \(ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file))",
            level: .success, category: .deletion
        )

        return CleaningResult(success: successCount, failed: failedCount, bytesFreed: bytesFreed)
    }

    func cleanCategory(_ category: SystemDataCategory) async -> CleaningResult {
        var successCount = 0
        var failedCount = 0
        var bytesFreed: Int64 = 0

        for item in category.detectedItems {
            let sizeBefore = item.size > 0 ? item.size : Int64(0)

            do {
                if category.requiresAdmin {
                    try await PrivilegedFileManager.shared.deleteItem(at: item.path)
                } else {
                    try fileManager.trashItem(at: URL(fileURLWithPath: item.path), resultingItemURL: nil)
                }
                successCount += 1
                bytesFreed += sizeBefore
            } catch {
                failedCount += 1
            }
        }

        await scanForSystemData()

        return CleaningResult(success: successCount, failed: failedCount, bytesFreed: bytesFreed)
    }

    func deleteItem(at path: String, requiresAdmin: Bool) async throws {
        if requiresAdmin || PrivilegedFileManager.shared.requiresAdminPrivileges(path: path) {
            try await PrivilegedFileManager.shared.deleteItem(at: path)
        } else {
            try fileManager.trashItem(at: URL(fileURLWithPath: path), resultingItemURL: nil)
        }
    }

    // MARK: - Helpers

    private func fileSizeQuick(at path: String, isDirectory: Bool) -> Int64 {
        if isDirectory {
            return -1 // Will be calculated on demand
        }
        let url = URL(fileURLWithPath: path)
        if let values = try? url.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileSizeKey]) {
            return Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
        }
        return 0
    }

    private func iconForFile(name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        switch ext {
        case "log", "txt":
            return "doc.text"
        case "plist", "xml", "json", "yaml", "yml":
            return "doc.badge.gearshape"
        case "db", "sqlite", "sqlite3":
            return "cylinder.fill"
        case "zip", "gz", "tar", "bz2", "xz":
            return "doc.zipper"
        case "dmg", "iso", "img":
            return "opticaldiscdrive.fill"
        case "app":
            return "app"
        case "framework", "dylib":
            return "shippingbox.fill"
        case "png", "jpg", "jpeg", "gif", "tiff", "bmp", "heic":
            return "photo"
        case "pdf":
            return "doc.richtext"
        case "mp3", "wav", "aac", "m4a":
            return "music.note"
        case "mp4", "mov", "avi", "mkv":
            return "film"
        default:
            return "doc"
        }
    }
}
