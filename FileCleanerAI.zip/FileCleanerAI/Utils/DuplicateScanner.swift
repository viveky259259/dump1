import Foundation
import CryptoKit
import AppKit

/// Scans for duplicate files using an efficient multi-stage algorithm:
/// 1. Group files by size (fast filter - most files have unique sizes)
/// 2. Compare first 4KB of files with same size (quick elimination)
/// 3. Full hash comparison for remaining candidates
@MainActor
class DuplicateScanner: ObservableObject {
    static let shared = DuplicateScanner()

    // MARK: - Published Properties

    @Published var duplicateGroups: [DuplicateGroup] = []
    @Published var isScanning = false
    @Published var scanProgress: Double = 0.0
    @Published var currentPhase: ScanPhase = .idle
    @Published var filesProcessed: Int = 0
    @Published var duplicatesFound: Int = 0
    @Published var potentialSpaceSaved: Int64 = 0

    // MARK: - Scan Configuration

    var minimumFileSize: Int64 = 1024 // 1KB minimum
    var scanPaths: [String] = []
    var excludeHiddenFiles = true
    var excludeSystemDirectories = true

    // MARK: - Private Properties

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private var scanTask: Task<Void, Never>?

    enum ScanPhase: String {
        case idle = "Ready"
        case collectingFiles = "Collecting files..."
        case groupingBySize = "Grouping by size..."
        case comparingHeaders = "Comparing file headers..."
        case hashingFiles = "Computing file hashes..."
        case complete = "Scan complete"
    }

    private init() {}

    // MARK: - Public Methods

    func startScan(paths: [String], minSize: Int64 = 1024) async {
        guard !isScanning else { return }

        isScanning = true
        scanProgress = 0
        duplicateGroups = []
        filesProcessed = 0
        duplicatesFound = 0
        potentialSpaceSaved = 0
        minimumFileSize = minSize
        scanPaths = paths

        logManager.log("Starting duplicate scan on \(paths.count) paths, min size: \(ByteCountFormatter.string(fromByteCount: minSize, countStyle: .file))", level: .info, category: .scanning)

        scanTask = Task {
            await performScan()
        }

        await scanTask?.value
        isScanning = false
    }

    func cancelScan() {
        scanTask?.cancel()
        scanTask = nil
        isScanning = false
        currentPhase = .idle
        logManager.log("Duplicate scan cancelled", level: .info, category: .scanning)
    }

    // MARK: - Scan Implementation

    private func performScan() async {
        // Phase 1: Collect all files
        currentPhase = .collectingFiles
        let allFiles = await collectAllFiles()
        guard !Task.isCancelled else { return }

        logManager.log("Collected \(allFiles.count) files for duplicate analysis", level: .info, category: .scanning)
        scanProgress = 0.2

        // Phase 2: Group files by size
        currentPhase = .groupingBySize
        let sizeGroups = groupFilesBySize(allFiles)
        guard !Task.isCancelled else { return }

        // Filter to only groups with 2+ files
        let potentialDuplicates = sizeGroups.filter { $0.value.count >= 2 }
        logManager.log("Found \(potentialDuplicates.count) size groups with potential duplicates", level: .info, category: .scanning)
        scanProgress = 0.4

        // Phase 3: Compare file headers (first 4KB)
        currentPhase = .comparingHeaders
        var confirmedDuplicates: [[FileInfo]] = []

        let totalGroups = potentialDuplicates.count
        var processedGroups = 0

        for (_, files) in potentialDuplicates {
            guard !Task.isCancelled else { return }

            let headerGroups = await compareFileHeaders(files)

            for group in headerGroups where group.count >= 2 {
                confirmedDuplicates.append(group)
            }

            processedGroups += 1
            scanProgress = 0.4 + (0.3 * Double(processedGroups) / Double(max(1, totalGroups)))
            filesProcessed = processedGroups
        }

        logManager.log("After header comparison: \(confirmedDuplicates.count) potential duplicate groups", level: .info, category: .scanning)

        // Phase 4: Full hash comparison for remaining candidates
        currentPhase = .hashingFiles
        var finalGroups: [DuplicateGroup] = []

        let totalCandidates = confirmedDuplicates.count
        var processedCandidates = 0

        for candidateGroup in confirmedDuplicates {
            guard !Task.isCancelled else { return }

            let hashGroups = await computeFullHashes(candidateGroup)

            for (hash, files) in hashGroups where files.count >= 2 {
                let group = DuplicateGroup(
                    hash: hash,
                    files: files,
                    fileSize: files.first?.size ?? 0
                )
                finalGroups.append(group)
            }

            processedCandidates += 1
            scanProgress = 0.7 + (0.3 * Double(processedCandidates) / Double(max(1, totalCandidates)))
        }

        // Sort by potential space savings (largest first)
        finalGroups.sort { ($0.fileSize * Int64($0.files.count - 1)) > ($1.fileSize * Int64($1.files.count - 1)) }

        duplicateGroups = finalGroups
        duplicatesFound = finalGroups.reduce(0) { $0 + $1.files.count }
        potentialSpaceSaved = finalGroups.reduce(0) { $0 + $1.potentialSavings }

        currentPhase = .complete
        scanProgress = 1.0

        logManager.log("Duplicate scan complete: Found \(finalGroups.count) groups with \(duplicatesFound) duplicates, potential savings: \(ByteCountFormatter.string(fromByteCount: potentialSpaceSaved, countStyle: .file))", level: .success, category: .scanning)
    }

    // MARK: - File Collection

    private func collectAllFiles() async -> [FileInfo] {
        var allFiles: [FileInfo] = []

        for path in scanPaths {
            guard !Task.isCancelled else { break }

            let expandedPath = (path as NSString).expandingTildeInPath
            let url = URL(fileURLWithPath: expandedPath)

            guard let enumerator = fileManager.enumerator(
                at: url,
                includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey, .isSymbolicLinkKey, .contentModificationDateKey],
                options: excludeHiddenFiles ? [.skipsHiddenFiles] : []
            ) else { continue }

            var batchCount = 0
            let batchSize = 500

            while let fileURL = enumerator.nextObject() as? URL {
                guard !Task.isCancelled else { break }

                // Skip directories and symlinks
                guard let resourceValues = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey]),
                      resourceValues.isDirectory == false,
                      resourceValues.isSymbolicLink != true else {
                    continue
                }

                // Skip system directories
                if excludeSystemDirectories && shouldSkipPath(fileURL.path) {
                    enumerator.skipDescendants()
                    continue
                }

                // Skip files smaller than minimum size
                guard let size = resourceValues.fileSize, Int64(size) >= minimumFileSize else {
                    continue
                }

                let fileInfo = FileInfo(
                    url: fileURL,
                    size: Int64(size),
                    modificationDate: (try? fileURL.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date.distantPast
                )
                allFiles.append(fileInfo)

                batchCount += 1
                if batchCount % batchSize == 0 {
                    await Task.yield()
                }
            }
        }

        return allFiles
    }

    private func shouldSkipPath(_ path: String) -> Bool {
        let skipPatterns = [
            "/System", "/Library/System", "/private", "/Applications",
            "/usr", "/bin", "/sbin", "/dev",
            "Library/Application Support", "Library/Preferences",
            ".Trash", ".Spotlight-V100", ".fseventsd"
        ]

        for pattern in skipPatterns {
            if path.contains(pattern) {
                return true
            }
        }
        return false
    }

    // MARK: - Size Grouping

    private func groupFilesBySize(_ files: [FileInfo]) -> [Int64: [FileInfo]] {
        var sizeGroups: [Int64: [FileInfo]] = [:]

        for file in files {
            sizeGroups[file.size, default: []].append(file)
        }

        return sizeGroups
    }

    // MARK: - Header Comparison (First 4KB)

    private func compareFileHeaders(_ files: [FileInfo]) async -> [[FileInfo]] {
        let headerSize = 4096 // 4KB

        var headerGroups: [Data: [FileInfo]] = [:]

        for file in files {
            guard !Task.isCancelled else { break }

            if let header = readFileHeader(file.url, bytes: headerSize) {
                headerGroups[header, default: []].append(file)
            }
        }

        return Array(headerGroups.values)
    }

    private func readFileHeader(_ url: URL, bytes: Int) -> Data? {
        guard let fileHandle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? fileHandle.close() }

        return try? fileHandle.read(upToCount: bytes)
    }

    // MARK: - Full Hash Computation

    private func computeFullHashes(_ files: [FileInfo]) async -> [String: [FileInfo]] {
        var hashGroups: [String: [FileInfo]] = [:]

        for file in files {
            guard !Task.isCancelled else { break }

            if let hash = await computeFileHash(file.url) {
                hashGroups[hash, default: []].append(file)
            }
        }

        return hashGroups
    }

    private func computeFileHash(_ url: URL) async -> String? {
        return await Task.detached(priority: .userInitiated) {
            guard let fileHandle = try? FileHandle(forReadingFrom: url) else { return nil }
            defer { try? fileHandle.close() }

            var hasher = SHA256()
            let bufferSize = 64 * 1024 // 64KB chunks

            while true {
                guard let data = try? fileHandle.read(upToCount: bufferSize), !data.isEmpty else {
                    break
                }
                hasher.update(data: data)

                // Check cancellation periodically
                if Task.isCancelled { return nil }
            }

            let digest = hasher.finalize()
            return digest.map { String(format: "%02x", $0) }.joined()
        }.value
    }

    // MARK: - Deletion

    func deleteFiles(_ files: [FileInfo], keepFirst: Bool = true) async -> (success: Int, failed: Int) {
        let filesToDelete = keepFirst ? Array(files.dropFirst()) : files
        var successCount = 0
        var failCount = 0

        for file in filesToDelete {
            let success = await deleteSingleFile(url: file.url)
            if success {
                successCount += 1
            } else {
                failCount += 1
            }

            // Yield to allow UI updates
            await Task.yield()
        }

        // Update groups after deletion
        await refreshAfterDeletion(deletedFiles: filesToDelete)

        return (successCount, failCount)
    }

    /// Delete a single file with proper error handling for permission prompts
    private func deleteSingleFile(url: URL) async -> Bool {
        do {
            // Check if file still exists
            guard fileManager.fileExists(atPath: url.path) else {
                logManager.log("File no longer exists: \(url.path)", level: .warning, category: .deletion)
                return true
            }

            try fileManager.trashItem(at: url, resultingItemURL: nil)
            logManager.log("Moved to trash: \(url.path)", level: .success, category: .deletion)
            return true

        } catch let error as NSError {
            if error.domain == NSCocoaErrorDomain {
                switch error.code {
                case NSFileNoSuchFileError:
                    logManager.log("File not found: \(url.path)", level: .warning, category: .deletion)
                    return true // File already gone
                case NSFileWriteNoPermissionError:
                    logManager.log("Permission denied: \(url.path) - Try granting Full Disk Access", level: .error, category: .deletion)
                case NSUserCancelledError:
                    logManager.log("User cancelled deletion: \(url.path)", level: .info, category: .deletion)
                default:
                    logManager.log("Failed to delete: \(url.path) - \(error.localizedDescription)", level: .error, category: .deletion)
                }
            } else {
                logManager.log("Failed to delete: \(url.path) - \(error.localizedDescription)", level: .error, category: .deletion)
            }
            return false
        }
    }

    private func refreshAfterDeletion(deletedFiles: [FileInfo]) async {
        let deletedPaths = Set(deletedFiles.map { $0.url.path })

        duplicateGroups = duplicateGroups.compactMap { group in
            let remainingFiles = group.files.filter { !deletedPaths.contains($0.url.path) }
            if remainingFiles.count < 2 {
                return nil // No longer a duplicate group
            }
            return DuplicateGroup(hash: group.hash, files: remainingFiles, fileSize: group.fileSize)
        }

        duplicatesFound = duplicateGroups.reduce(0) { $0 + $1.files.count }
        potentialSpaceSaved = duplicateGroups.reduce(0) { $0 + $1.potentialSavings }
    }
}

// MARK: - Supporting Types

struct FileInfo: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let size: Int64
    let modificationDate: Date

    var name: String { url.lastPathComponent }
    var path: String { url.path }
    var displayPath: String {
        path.replacingOccurrences(of: FileManager.default.homeDirectoryForCurrentUser.path, with: "~")
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(url)
    }

    static func == (lhs: FileInfo, rhs: FileInfo) -> Bool {
        lhs.url == rhs.url
    }
}

struct DuplicateGroup: Identifiable {
    let id = UUID()
    let hash: String
    let files: [FileInfo]
    let fileSize: Int64

    var count: Int { files.count }

    /// Space that could be saved by keeping only one copy
    var potentialSavings: Int64 {
        fileSize * Int64(files.count - 1)
    }

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file)
    }

    var formattedSavings: String {
        ByteCountFormatter.string(fromByteCount: potentialSavings, countStyle: .file)
    }
}
