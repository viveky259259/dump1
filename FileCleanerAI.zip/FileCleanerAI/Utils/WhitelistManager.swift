import Foundation
import SwiftUI

/// Manages user-defined protection rules (whitelist) for paths and patterns
/// that should never be deleted during cleanup operations
@MainActor
class WhitelistManager: ObservableObject {
    static let shared = WhitelistManager()

    // MARK: - Published Properties

    @Published var whitelistRules: [WhitelistRule] = []

    // MARK: - Storage Keys

    private let storageKey = "com.aifilecleaner.whitelist.rules"

    // MARK: - Default Protected Paths

    static let systemProtectedPaths: Set<String> = [
        "/System",
        "/Library/System",
        "/usr",
        "/bin",
        "/sbin",
        "/private/var/db",
        "/private/var/protected",
        "~/Library/Keychains",
        "~/Library/Accounts",
        "~/.ssh",
        "~/.gnupg",
        "~/.aws/credentials"
    ]

    // MARK: - Initialization

    private init() {
        loadRules()
    }

    // MARK: - Public Methods

    /// Check if a path is protected (either by system or user rules)
    func isProtected(_ path: String) -> Bool {
        let expandedPath = (path as NSString).expandingTildeInPath

        // Check system protected paths
        for protected in Self.systemProtectedPaths {
            let expandedProtected = (protected as NSString).expandingTildeInPath
            if expandedPath.hasPrefix(expandedProtected) {
                return true
            }
        }

        // Check user whitelist rules
        for rule in whitelistRules where rule.isEnabled {
            if rule.matches(path: expandedPath) {
                return true
            }
        }

        return false
    }

    /// Get the reason why a path is protected (if any)
    func protectionReason(for path: String) -> String? {
        let expandedPath = (path as NSString).expandingTildeInPath

        // Check system protected paths
        for protected in Self.systemProtectedPaths {
            let expandedProtected = (protected as NSString).expandingTildeInPath
            if expandedPath.hasPrefix(expandedProtected) {
                return "System protected path"
            }
        }

        // Check user whitelist rules
        for rule in whitelistRules where rule.isEnabled {
            if rule.matches(path: expandedPath) {
                return rule.reason.isEmpty ? "User protected" : rule.reason
            }
        }

        return nil
    }

    /// Add a new whitelist rule
    func addRule(type: WhitelistRule.RuleType, pattern: String, reason: String = "") {
        let rule = WhitelistRule(type: type, pattern: pattern, reason: reason)
        whitelistRules.append(rule)
        saveRules()
    }

    /// Remove a whitelist rule
    func removeRule(_ rule: WhitelistRule) {
        whitelistRules.removeAll { $0.id == rule.id }
        saveRules()
    }

    /// Update a whitelist rule
    func updateRule(_ rule: WhitelistRule) {
        if let index = whitelistRules.firstIndex(where: { $0.id == rule.id }) {
            whitelistRules[index] = rule
            saveRules()
        }
    }

    /// Toggle a rule's enabled state
    func toggleRule(_ rule: WhitelistRule) {
        if let index = whitelistRules.firstIndex(where: { $0.id == rule.id }) {
            whitelistRules[index].isEnabled.toggle()
            saveRules()
        }
    }

    /// Import rules from a file
    func importRules(from url: URL) throws {
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        let importedRules = try decoder.decode([WhitelistRule].self, from: data)
        whitelistRules.append(contentsOf: importedRules)
        saveRules()
    }

    /// Export rules to a file
    func exportRules(to url: URL) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        let data = try encoder.encode(whitelistRules)
        try data.write(to: url)
    }

    // MARK: - Preset Rules

    func addDeveloperPresets() {
        let presets: [(WhitelistRule.RuleType, String, String)] = [
            (.exactPath, "~/.gitconfig", "Git configuration"),
            (.exactPath, "~/.zshrc", "Shell configuration"),
            (.exactPath, "~/.bashrc", "Shell configuration"),
            (.pattern, "*.env", "Environment files (may contain secrets)"),
            (.pattern, "*.pem", "Certificate files"),
            (.pattern, "*.key", "Private key files"),
            (.directory, "~/.config", "Application configs"),
            (.directory, "~/.local/share", "Application data")
        ]

        for (type, pattern, reason) in presets {
            // Don't add if similar rule exists
            let exists = whitelistRules.contains { $0.pattern == pattern }
            if !exists {
                addRule(type: type, pattern: pattern, reason: reason)
            }
        }
    }

    func addMediaPresets() {
        let presets: [(WhitelistRule.RuleType, String, String)] = [
            (.directory, "~/Pictures/Photos Library.photoslibrary", "Photos library"),
            (.directory, "~/Music/Music", "Music library"),
            (.directory, "~/Movies", "Movies folder")
        ]

        for (type, pattern, reason) in presets {
            let exists = whitelistRules.contains { $0.pattern == pattern }
            if !exists {
                addRule(type: type, pattern: pattern, reason: reason)
            }
        }
    }

    // MARK: - Persistence

    private func loadRules() {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else { return }

        do {
            let decoder = JSONDecoder()
            whitelistRules = try decoder.decode([WhitelistRule].self, from: data)
        } catch {
            print("Failed to load whitelist rules: \(error)")
        }
    }

    private func saveRules() {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(whitelistRules)
            UserDefaults.standard.set(data, forKey: storageKey)
        } catch {
            print("Failed to save whitelist rules: \(error)")
        }
    }
}

// MARK: - Whitelist Rule

struct WhitelistRule: Identifiable, Codable, Hashable {
    let id: UUID
    var type: RuleType
    var pattern: String
    var reason: String
    var isEnabled: Bool
    var createdAt: Date

    enum RuleType: String, Codable, CaseIterable {
        case exactPath = "Exact Path"
        case directory = "Directory"
        case pattern = "Pattern"
        case regex = "Regex"

        var icon: String {
            switch self {
            case .exactPath: return "doc.fill"
            case .directory: return "folder.fill"
            case .pattern: return "staroflife.fill"
            case .regex: return "function"
            }
        }

        var description: String {
            switch self {
            case .exactPath: return "Matches exact file path"
            case .directory: return "Matches directory and all contents"
            case .pattern: return "Matches glob pattern (e.g., *.env)"
            case .regex: return "Matches regular expression"
            }
        }
    }

    init(type: RuleType, pattern: String, reason: String = "", isEnabled: Bool = true) {
        self.id = UUID()
        self.type = type
        self.pattern = pattern
        self.reason = reason
        self.isEnabled = isEnabled
        self.createdAt = Date()
    }

    /// Check if this rule matches the given path
    func matches(path: String) -> Bool {
        guard isEnabled else { return false }

        let expandedPattern = (pattern as NSString).expandingTildeInPath

        switch type {
        case .exactPath:
            return path == expandedPattern

        case .directory:
            let dirPath = expandedPattern.hasSuffix("/") ? expandedPattern : expandedPattern + "/"
            return path == expandedPattern || path.hasPrefix(dirPath)

        case .pattern:
            return matchesGlobPattern(path: path, pattern: expandedPattern)

        case .regex:
            return matchesRegex(path: path, pattern: pattern)
        }
    }

    private func matchesGlobPattern(path: String, pattern: String) -> Bool {
        // Convert glob pattern to regex
        var regexPattern = NSRegularExpression.escapedPattern(for: pattern)

        // Convert glob wildcards to regex
        regexPattern = regexPattern
            .replacingOccurrences(of: "\\*\\*", with: ".*")   // ** matches anything including /
            .replacingOccurrences(of: "\\*", with: "[^/]*")   // * matches anything except /
            .replacingOccurrences(of: "\\?", with: ".")       // ? matches single char

        // If pattern doesn't start with /, match anywhere in path
        if !pattern.hasPrefix("/") && !pattern.hasPrefix("~") {
            regexPattern = ".*" + regexPattern
        }

        regexPattern = "^" + regexPattern + "$"

        return matchesRegex(path: path, pattern: regexPattern)
    }

    private func matchesRegex(path: String, pattern: String) -> Bool {
        do {
            let regex = try NSRegularExpression(pattern: pattern, options: [.caseInsensitive])
            let range = NSRange(path.startIndex..., in: path)
            return regex.firstMatch(in: path, options: [], range: range) != nil
        } catch {
            return false
        }
    }
}
