import Foundation
import AppKit

// MARK: - Data Models

struct InstalledApp: Identifiable, Hashable {
    let id: String // bundleIdentifier or path
    let name: String
    let path: String
    let bundleIdentifier: String?
    let icon: NSImage?
    let appSize: Int64
    let lastUsedDate: Date?
    var remnants: [AppRemnant]
    var totalRemnantSize: Int64 { remnants.reduce(0) { $0 + $1.size } }
    var totalSize: Int64 { appSize + totalRemnantSize }

    var formattedAppSize: String {
        ByteCountFormatter.string(fromByteCount: appSize, countStyle: .file)
    }

    var formattedTotalSize: String {
        ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file)
    }

    var formattedRemnantSize: String {
        ByteCountFormatter.string(fromByteCount: totalRemnantSize, countStyle: .file)
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(path)
    }

    static func == (lhs: InstalledApp, rhs: InstalledApp) -> Bool {
        lhs.path == rhs.path
    }
}

struct AppRemnant: Identifiable, Hashable {
    let id: String
    let path: String
    let category: RemnantCategory
    let size: Int64
    let name: String

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(path)
    }

    static func == (lhs: AppRemnant, rhs: AppRemnant) -> Bool {
        lhs.path == rhs.path
    }
}

enum RemnantCategory: String, CaseIterable {
    case cache = "Caches"
    case preferences = "Preferences"
    case applicationSupport = "Application Support"
    case logs = "Logs"
    case launchAgent = "Launch Agents"
    case savedState = "Saved State"
    case containers = "Containers"
    case cookies = "Cookies"
    case httpStorage = "HTTP Storage"
    case webkit = "WebKit Data"
    case diagnostics = "Diagnostic Reports"
    case receipts = "Receipts"
    case other = "Other"

    var icon: String {
        switch self {
        case .cache: return "internaldrive"
        case .preferences: return "gearshape"
        case .applicationSupport: return "folder.badge.gearshape"
        case .logs: return "doc.text"
        case .launchAgent: return "arrow.clockwise"
        case .savedState: return "square.stack.3d.up"
        case .containers: return "shippingbox"
        case .cookies: return "birthday.cake"
        case .httpStorage: return "network"
        case .webkit: return "globe"
        case .diagnostics: return "stethoscope"
        case .receipts: return "doc.plaintext"
        case .other: return "questionmark.folder"
        }
    }
}

// MARK: - App Uninstaller

@MainActor
class AppUninstaller: ObservableObject {
    static let shared = AppUninstaller()

    @Published var installedApps: [InstalledApp] = []
    @Published var isLoadingApps = false
    @Published var isScanningRemnants = false
    @Published var isUninstalling = false
    @Published var scanProgress: Double = 0.0
    @Published var uninstallProgress: Double = 0.0

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let home = FileManager.default.homeDirectoryForCurrentUser.path

    private init() {}

    // MARK: - Remnant Search Locations

    private func remnantSearchPaths(bundleId: String?, appName: String) -> [(String, RemnantCategory)] {
        var paths: [(String, RemnantCategory)] = []
        let identifiers = buildIdentifiers(bundleId: bundleId, appName: appName)

        // User Library locations
        let userLibRoots: [(String, RemnantCategory)] = [
            ("Caches", .cache),
            ("Preferences", .preferences),
            ("Application Support", .applicationSupport),
            ("Logs", .logs),
            ("LaunchAgents", .launchAgent),
            ("Saved Application State", .savedState),
            ("Containers", .containers),
            ("Group Containers", .containers),
            ("Cookies", .cookies),
            ("HTTPStorages", .httpStorage),
            ("WebKit", .webkit),
            ("SyncedPreferences", .preferences),
            ("Application Scripts", .applicationSupport),
        ]

        for (folder, category) in userLibRoots {
            let base = "\(home)/Library/\(folder)"
            for identifier in identifiers {
                // Exact match
                let exact = "\(base)/\(identifier)"
                paths.append((exact, category))
                // Plist match (for Preferences)
                if category == .preferences {
                    paths.append(("\(base)/\(identifier).plist", category))
                }
            }
            // Glob-style: scan folder for partial matches
            paths.append(contentsOf: findMatchingItems(in: base, identifiers: identifiers, category: category))
        }

        // Diagnostic Reports (user + system)
        for diagDir in ["\(home)/Library/Logs/DiagnosticReports", "/Library/Logs/DiagnosticReports"] {
            paths.append(contentsOf: findMatchingItems(in: diagDir, identifiers: identifiers, category: .diagnostics))
        }

        // System Library locations (may require admin)
        let systemRoots: [(String, RemnantCategory)] = [
            ("/Library/LaunchAgents", .launchAgent),
            ("/Library/LaunchDaemons", .launchAgent),
            ("/Library/Application Support", .applicationSupport),
            ("/Library/Caches", .cache),
            ("/Library/Preferences", .preferences),
        ]

        for (base, category) in systemRoots {
            for identifier in identifiers {
                let exact = "\(base)/\(identifier)"
                paths.append((exact, category))
                if category == .preferences {
                    paths.append(("\(base)/\(identifier).plist", category))
                }
            }
            paths.append(contentsOf: findMatchingItems(in: base, identifiers: identifiers, category: category))
        }

        // Receipts
        if let bundleId = bundleId {
            let receiptsDir = "\(home)/Library/Receipts"
            paths.append(contentsOf: findMatchingItems(in: receiptsDir, identifiers: [bundleId], category: .receipts))
        }

        return paths
    }

    private func buildIdentifiers(bundleId: String?, appName: String) -> [String] {
        var ids: [String] = []
        if let bundleId = bundleId {
            ids.append(bundleId)
            // Also add reverse-domain variants
            let parts = bundleId.split(separator: ".")
            if parts.count >= 2 {
                // e.g. "com.company.AppName" -> also search "AppName"
                ids.append(String(parts.last!))
            }
        }
        ids.append(appName)
        // Lowercase variant
        let lower = appName.lowercased()
        if lower != appName {
            ids.append(lower)
        }
        // Remove spaces variant
        let noSpaces = appName.replacingOccurrences(of: " ", with: "")
        if noSpaces != appName {
            ids.append(noSpaces)
        }
        return Array(Set(ids)) // deduplicate
    }

    private func findMatchingItems(in directory: String, identifiers: [String], category: RemnantCategory) -> [(String, RemnantCategory)] {
        guard fileManager.fileExists(atPath: directory),
              let contents = try? fileManager.contentsOfDirectory(atPath: directory) else {
            return []
        }

        var results: [(String, RemnantCategory)] = []
        for item in contents {
            let itemLower = item.lowercased()
            for identifier in identifiers {
                let idLower = identifier.lowercased()
                if itemLower.contains(idLower) {
                    let fullPath = (directory as NSString).appendingPathComponent(item)
                    results.append((fullPath, category))
                    break
                }
            }
        }
        return results
    }

    // MARK: - Load Installed Apps

    func loadInstalledApps() async {
        isLoadingApps = true
        defer { isLoadingApps = false }

        var apps: [InstalledApp] = []
        let appDirectories = ["/Applications", "\(home)/Applications"]

        for dir in appDirectories {
            guard let contents = try? fileManager.contentsOfDirectory(atPath: dir) else { continue }

            for item in contents where item.hasSuffix(".app") {
                let appPath = (dir as NSString).appendingPathComponent(item)
                if let app = loadAppInfo(at: appPath) {
                    apps.append(app)
                }
            }
        }

        // Sort by name
        installedApps = apps.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }

        logManager.log("Loaded \(installedApps.count) installed apps", level: .info, category: .scanning)
    }

    private func loadAppInfo(at path: String) -> InstalledApp? {
        let appName = ((path as NSString).lastPathComponent as NSString).deletingPathExtension
        let plistPath = (path as NSString).appendingPathComponent("Contents/Info.plist")
        let bundleId = NSDictionary(contentsOfFile: plistPath)?["CFBundleIdentifier"] as? String

        let icon = NSWorkspace.shared.icon(forFile: path)
        let size = calculateItemSize(at: path)

        // Last used date
        let url = URL(fileURLWithPath: path)
        let lastUsed = (try? url.resourceValues(forKeys: [.contentAccessDateKey]))?.contentAccessDate

        return InstalledApp(
            id: bundleId ?? path,
            name: appName,
            path: path,
            bundleIdentifier: bundleId,
            icon: icon,
            appSize: size,
            lastUsedDate: lastUsed,
            remnants: []
        )
    }

    // MARK: - Scan Remnants for a Single App

    func scanRemnants(for app: InstalledApp) async -> [AppRemnant] {
        let searchPaths = remnantSearchPaths(bundleId: app.bundleIdentifier, appName: app.name)

        var remnants: [AppRemnant] = []
        var seenPaths = Set<String>()

        // Exclude the app bundle itself
        seenPaths.insert(app.path)

        for (path, category) in searchPaths {
            guard !seenPaths.contains(path) else { continue }
            guard fileManager.fileExists(atPath: path) else { continue }
            seenPaths.insert(path)

            let size = await Task.detached {
                self.calculateItemSize(at: path)
            }.value

            let name = (path as NSString).lastPathComponent
            remnants.append(AppRemnant(
                id: path,
                path: path,
                category: category,
                size: size,
                name: name
            ))
        }

        return remnants.sorted { $0.size > $1.size }
    }

    // MARK: - Scan All Apps for Remnants

    func scanAllRemnants() async {
        isScanningRemnants = true
        scanProgress = 0.0

        let total = Double(installedApps.count)
        for i in installedApps.indices {
            let remnants = await scanRemnants(for: installedApps[i])
            installedApps[i].remnants = remnants
            scanProgress = Double(i + 1) / total
        }

        isScanningRemnants = false
        scanProgress = 1.0

        logManager.log("Remnant scan complete for \(installedApps.count) apps", level: .info, category: .scanning)
    }

    // MARK: - Uninstall

    func uninstallApp(_ app: InstalledApp, removeRemnants: Bool = true, selectedRemnants: Set<String>? = nil) async -> CleaningResult {
        isUninstalling = true
        uninstallProgress = 0.0

        var success = 0
        var failed = 0
        var bytesFreed: Int64 = 0

        // Determine items to delete
        var itemsToDelete: [(path: String, size: Int64)] = []

        // App bundle
        itemsToDelete.append((app.path, app.appSize))

        // Remnants
        if removeRemnants {
            let remnantsToRemove: [AppRemnant]
            if let selected = selectedRemnants {
                remnantsToRemove = app.remnants.filter { selected.contains($0.path) }
            } else {
                remnantsToRemove = app.remnants
            }
            for remnant in remnantsToRemove {
                itemsToDelete.append((remnant.path, remnant.size))
            }
        }

        let total = Double(itemsToDelete.count)

        for (index, item) in itemsToDelete.enumerated() {
            do {
                let requiresAdmin = PrivilegedFileManager.shared.requiresAdminPrivileges(path: item.path)
                if requiresAdmin {
                    try await PrivilegedFileManager.shared.deleteItem(at: item.path)
                } else {
                    try fileManager.trashItem(at: URL(fileURLWithPath: item.path), resultingItemURL: nil)
                }
                success += 1
                bytesFreed += item.size
                logManager.log("Removed: \(item.path)", level: .success, category: .deletion)
            } catch {
                // If user cancelled admin prompt, stop entirely
                if (error as NSError).code == NSUserCancelledError {
                    logManager.log("User cancelled admin prompt", level: .info, category: .deletion)
                    break
                }
                failed += 1
                logManager.log("Failed to remove: \(item.path) — \(error.localizedDescription)", level: .error, category: .deletion)
            }

            uninstallProgress = Double(index + 1) / total
        }

        isUninstalling = false
        uninstallProgress = 1.0

        // Remove from list if app bundle was deleted
        if !fileManager.fileExists(atPath: app.path) {
            installedApps.removeAll { $0.path == app.path }
        }

        logManager.log(
            "Uninstall complete: \(app.name). Removed \(success) items, freed \(ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file))",
            level: .success, category: .deletion
        )

        return CleaningResult(success: success, failed: failed, bytesFreed: bytesFreed)
    }

    /// Remove only remnants (keep the app itself)
    func cleanRemnants(for app: InstalledApp, selectedPaths: Set<String>? = nil) async -> CleaningResult {
        var success = 0
        var failed = 0
        var bytesFreed: Int64 = 0

        let remnantsToClean: [AppRemnant]
        if let selected = selectedPaths {
            remnantsToClean = app.remnants.filter { selected.contains($0.path) }
        } else {
            remnantsToClean = app.remnants
        }

        for remnant in remnantsToClean {
            do {
                let requiresAdmin = PrivilegedFileManager.shared.requiresAdminPrivileges(path: remnant.path)
                if requiresAdmin {
                    try await PrivilegedFileManager.shared.deleteItem(at: remnant.path)
                } else {
                    try fileManager.trashItem(at: URL(fileURLWithPath: remnant.path), resultingItemURL: nil)
                }
                success += 1
                bytesFreed += remnant.size
            } catch {
                if (error as NSError).code == NSUserCancelledError { break }
                failed += 1
            }
        }

        // Refresh remnants for this app
        if let index = installedApps.firstIndex(where: { $0.path == app.path }) {
            installedApps[index].remnants = await scanRemnants(for: installedApps[index])
        }

        return CleaningResult(success: success, failed: failed, bytesFreed: bytesFreed)
    }

    // MARK: - Helpers

    nonisolated private func calculateItemSize(at path: String) -> Int64 {
        let fm = FileManager.default
        let url = URL(fileURLWithPath: path)

        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return 0 }

        if !isDir.boolValue {
            if let values = try? url.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileSizeKey]) {
                return Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
            return 0
        }

        var totalSize: Int64 = 0
        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }

        return totalSize
    }
}
