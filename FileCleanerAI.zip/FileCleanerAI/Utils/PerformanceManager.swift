import Foundation

@MainActor
class PerformanceManager: ObservableObject {
    static let shared = PerformanceManager()
    
    @Published var currentSession: PerformanceSession?
    @Published var isTracking = false
    
    private var storage: PerformanceDataStorage
    private let persistenceManager = PersistenceManager.shared
    private let memoryMonitor = MemoryMonitor.shared
    private let logManager = LogManager.shared
    
    // Active operation trackers
    private var activeTrackers: [String: OperationTracker] = [:]
    
    private init() {
        // Load existing data
        let initialSessionCount: Int
        if let loaded = persistenceManager.loadPerformanceData() {
            storage = loaded
            initialSessionCount = loaded.sessions.count
            logManager.log("Loaded \(initialSessionCount) performance sessions", level: .info, category: .system)
        } else {
            storage = PerformanceDataStorage()
            initialSessionCount = 0
            logManager.log("Initialized new performance data storage", level: .info, category: .system)
        }
        
        // Cleanup old sessions (7 days retention)
        storage.cleanupOldSessions(keepDays: 7)
        if storage.sessions.count != initialSessionCount {
            saveData()
        }
    }
    
    // MARK: - Session Management
    
    func startSession() {
        guard currentSession == nil else {
            logManager.log("Session already active", level: .warning, category: .system)
            return
        }
        
        currentSession = PerformanceSession(sessionStart: Date())
        isTracking = true
        logManager.log("Performance tracking session started", level: .info, category: .system)
    }
    
    func endSession() {
        guard var session = currentSession else { return }
        
        session.sessionEnd = Date()
        storage.sessions.append(session)
        currentSession = nil
        isTracking = false
        
        saveData()
        logManager.log("Performance tracking session ended (duration: \(formatDuration(session.sessionDuration)))", level: .info, category: .system)
    }
    
    // MARK: - Operation Tracking
    
    func startOperation(_ type: OperationType, identifier: String = UUID().uuidString) -> OperationTracker {
        let tracker = OperationTracker(operationType: type)
        activeTrackers[identifier] = tracker
        
        logManager.log("Started tracking \(type.rawValue) operation", level: .debug, category: .system)
        return tracker
    }
    
    func endOperation(_ identifier: String) -> TimeInterval? {
        guard let tracker = activeTrackers.removeValue(forKey: identifier) else {
            return nil
        }
        
        let duration = tracker.end()
        logManager.log("Completed \(tracker.operationType.rawValue) operation in \(formatDuration(duration))", level: .debug, category: .system)
        return duration
    }
    
    // MARK: - Scan Metrics
    
    func recordScanMetrics(
        filesScanned: Int,
        directoriesScanned: Int,
        duration: TimeInterval,
        totalSizeScanned: Int64,
        memoryAtStart: Int64,
        peakMemory: Int64
    ) {
        guard var session = currentSession else {
            logManager.log("No active session for scan metrics", level: .warning, category: .system)
            return
        }
        
        let throughput = duration > 0 ? Double(filesScanned) / duration : 0
        
        session.scanMetrics = ScanMetrics(
            filesScanned: filesScanned,
            directoriesScanned: directoriesScanned,
            duration: duration,
            throughput: throughput,
            totalSizeScanned: totalSizeScanned,
            memoryAtStart: memoryAtStart,
            peakMemory: peakMemory
        )
        
        currentSession = session
        
        // Record memory snapshot
        recordMemorySnapshot()
        
        logManager.log("Recorded scan metrics: \(filesScanned) files, \(formatDuration(duration))", level: .debug, category: .system)
    }
    
    // MARK: - AI Analysis Metrics
    
    func recordAIMetrics(
        patternsDetected: Int,
        filesAnalyzed: Int,
        duration: TimeInterval,
        usedAI: Bool,
        memoryAtStart: Int64,
        peakMemory: Int64
    ) {
        guard var session = currentSession else {
            logManager.log("No active session for AI metrics", level: .warning, category: .system)
            return
        }
        
        session.aiMetrics = AIAnalysisMetrics(
            patternsDetected: patternsDetected,
            filesAnalyzed: filesAnalyzed,
            duration: duration,
            usedAI: usedAI,
            memoryAtStart: memoryAtStart,
            peakMemory: peakMemory
        )
        
        currentSession = session
        
        // Record memory snapshot
        recordMemorySnapshot()
        
        logManager.log("Recorded AI metrics: \(patternsDetected) patterns, \(formatDuration(duration))", level: .debug, category: .system)
    }
    
    // MARK: - Deletion Metrics
    
    func recordDeletionMetrics(
        patternsDeleted: Int,
        filesDeleted: Int,
        bytesFreed: Int64,
        duration: TimeInterval,
        successCount: Int,
        failureCount: Int
    ) {
        guard var session = currentSession else {
            logManager.log("No active session for deletion metrics", level: .warning, category: .system)
            return
        }
        
        let metrics = DeletionMetrics(
            patternsDeleted: patternsDeleted,
            filesDeleted: filesDeleted,
            bytesFreed: bytesFreed,
            duration: duration,
            successCount: successCount,
            failureCount: failureCount
        )
        
        session.deletionMetrics.append(metrics)
        currentSession = session
        
        // Record memory snapshot
        recordMemorySnapshot()
        
        logManager.log("Recorded deletion metrics: \(filesDeleted) files, \(ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file)) freed", level: .debug, category: .system)
    }
    
    // MARK: - Memory Snapshots
    
    func recordMemorySnapshot() {
        guard var session = currentSession else { return }
        
        let snapshot = MemorySnapshot(
            timestamp: Date(),
            appMemory: memoryMonitor.appMemoryUsage,
            systemMemory: memoryMonitor.usedMemory,
            physicalMemory: memoryMonitor.physicalMemory,
            memoryPressure: memoryMonitor.memoryPressure.description
        )
        
        session.memorySnapshots.append(snapshot)
        currentSession = session
    }
    
    // MARK: - Data Access
    
    func getMetricsForPeriod(days: Int = 7) -> [PerformanceSession] {
        let cutoffDate = Date().addingTimeInterval(-TimeInterval(days * 24 * 60 * 60))
        return storage.sessions.filter { $0.sessionStart >= cutoffDate }
    }
    
    func getAggregatedStats(days: Int = 7) -> PerformanceStats {
        let sessions = getMetricsForPeriod(days: days)
        
        let scans = sessions.compactMap { $0.scanMetrics }
        let aiAnalyses = sessions.compactMap { $0.aiMetrics }
        let allDeletions = sessions.flatMap { $0.deletionMetrics }
        let allMemorySnapshots = sessions.flatMap { $0.memorySnapshots }
        
        // Calculate scan statistics
        let totalScans = scans.count
        let averageScanDuration = scans.isEmpty ? 0 : scans.map { $0.duration }.reduce(0, +) / Double(scans.count)
        let averageScanThroughput = scans.isEmpty ? 0 : scans.map { $0.throughput }.reduce(0, +) / Double(scans.count)
        let totalFilesScanned = scans.reduce(0) { $0 + $1.filesScanned }
        
        // Calculate AI statistics
        let totalAIAnalyses = aiAnalyses.count
        let averageAIDuration = aiAnalyses.isEmpty ? 0 : aiAnalyses.map { $0.duration }.reduce(0, +) / Double(aiAnalyses.count)
        
        // Calculate deletion statistics
        let totalDeletions = allDeletions.reduce(0) { $0 + $1.filesDeleted }
        let totalBytesFreed = allDeletions.reduce(0) { $0 + $1.bytesFreed }
        let averageDeletionSuccessRate = allDeletions.isEmpty ? 0 : allDeletions.map { $0.successRate }.reduce(0, +) / Double(allDeletions.count)
        
        // Calculate memory statistics
        let memoryValues = allMemorySnapshots.map { $0.appMemory }
        let peakMemoryUsage = memoryValues.max() ?? 0
        let averageMemoryUsage = memoryValues.isEmpty ? 0 : memoryValues.reduce(0, +) / Int64(memoryValues.count)
        
        return PerformanceStats(
            totalScans: totalScans,
            averageScanDuration: averageScanDuration,
            averageScanThroughput: averageScanThroughput,
            totalFilesScanned: totalFilesScanned,
            totalAIAnalyses: totalAIAnalyses,
            averageAIDuration: averageAIDuration,
            totalDeletions: totalDeletions,
            totalBytesFreed: totalBytesFreed,
            averageDeletionSuccessRate: averageDeletionSuccessRate,
            peakMemoryUsage: peakMemoryUsage,
            averageMemoryUsage: averageMemoryUsage
        )
    }
    
    func getAllSessions() -> [PerformanceSession] {
        return storage.sessions
    }
    
    // MARK: - Data Management
    
    func clearAllData() {
        storage = PerformanceDataStorage()
        currentSession = nil
        isTracking = false
        activeTrackers.removeAll()
        saveData()
        logManager.log("Cleared all performance data", level: .info, category: .system)
    }
    
    func exportData() -> String {
        let sessions = storage.sessions
        var export = "Performance Analytics Export\n"
        export += "Generated: \(Date().formatted())\n"
        export += "Total Sessions: \(sessions.count)\n\n"
        
        for (index, session) in sessions.enumerated() {
            export += "=== Session \(index + 1) ===\n"
            export += "Start: \(session.sessionStart.formatted())\n"
            if let end = session.sessionEnd {
                export += "End: \(end.formatted())\n"
                export += "Duration: \(formatDuration(session.sessionDuration))\n"
            }
            
            if let scan = session.scanMetrics {
                export += "\nScan Metrics:\n"
                export += "  Files: \(scan.filesScanned)\n"
                export += "  Directories: \(scan.directoriesScanned)\n"
                export += "  Duration: \(formatDuration(scan.duration))\n"
                export += "  Throughput: \(scan.formattedThroughput)\n"
            }
            
            if let ai = session.aiMetrics {
                export += "\nAI Analysis:\n"
                export += "  Patterns: \(ai.patternsDetected)\n"
                export += "  Files: \(ai.filesAnalyzed)\n"
                export += "  Duration: \(formatDuration(ai.duration))\n"
                export += "  Used AI: \(ai.usedAI ? "Yes" : "No")\n"
            }
            
            if !session.deletionMetrics.isEmpty {
                export += "\nDeletions:\n"
                for deletion in session.deletionMetrics {
                    export += "  Files: \(deletion.filesDeleted), Freed: \(ByteCountFormatter.string(fromByteCount: deletion.bytesFreed, countStyle: .file))\n"
                }
            }
            
            export += "\n"
        }
        
        return export
    }
    
    // MARK: - Private Helpers
    
    private func saveData() {
        storage.lastUpdated = Date()
        persistenceManager.savePerformanceData(storage)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        if duration < 1 {
            return String(format: "%.0f ms", duration * 1000)
        } else if duration < 60 {
            return String(format: "%.1f sec", duration)
        } else {
            let minutes = Int(duration / 60)
            let seconds = Int(duration.truncatingRemainder(dividingBy: 60))
            return "\(minutes)m \(seconds)s"
        }
    }
}
