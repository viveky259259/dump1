import Foundation
import AppKit
import IOKit
import IOKit.ps

/// Calculates a weighted system health score (0-100) based on multiple factors
/// Similar to Mole's health score in `mo status`
@MainActor
class HealthScoreManager: ObservableObject {
    static let shared = HealthScoreManager()

    // MARK: - Published Properties

    @Published var healthScore: Int = 100
    @Published var healthGrade: HealthGrade = .excellent
    @Published var cpuUsage: Double = 0
    @Published var memoryUsage: Double = 0
    @Published var diskUsage: Double = 0
    @Published var batteryHealth: Int = 100
    @Published var thermalState: ThermalState = .nominal

    // MARK: - Component Scores

    @Published var cpuScore: Int = 100
    @Published var memoryScore: Int = 100
    @Published var diskScore: Int = 100
    @Published var batteryScore: Int = 100
    @Published var thermalScore: Int = 100

    // MARK: - Weights for Health Calculation

    private let weights: [String: Double] = [
        "cpu": 0.25,
        "memory": 0.30,
        "disk": 0.25,
        "thermal": 0.10,
        "battery": 0.10
    ]

    // MARK: - Health Grade

    enum HealthGrade: String {
        case excellent = "Excellent"
        case good = "Good"
        case fair = "Fair"
        case poor = "Poor"
        case critical = "Critical"

        var color: NSColor {
            switch self {
            case .excellent: return .systemGreen
            case .good: return .systemBlue
            case .fair: return .systemYellow
            case .poor: return .systemOrange
            case .critical: return .systemRed
            }
        }

        var icon: String {
            switch self {
            case .excellent: return "checkmark.circle.fill"
            case .good: return "checkmark.circle"
            case .fair: return "exclamationmark.circle"
            case .poor: return "exclamationmark.triangle"
            case .critical: return "xmark.circle.fill"
            }
        }

        static func from(score: Int) -> HealthGrade {
            switch score {
            case 90...100: return .excellent
            case 75..<90: return .good
            case 60..<75: return .fair
            case 40..<60: return .poor
            default: return .critical
            }
        }
    }

    // MARK: - Thermal State

    enum ThermalState: String {
        case nominal = "Normal"
        case fair = "Fair"
        case serious = "Serious"
        case critical = "Critical"

        var score: Int {
            switch self {
            case .nominal: return 100
            case .fair: return 75
            case .serious: return 50
            case .critical: return 25
            }
        }
    }

    // MARK: - Update Timer

    private var updateTimer: Timer?

    private init() {
        updateHealthScore()
    }

    // MARK: - Public Methods

    func startMonitoring(interval: TimeInterval = 5.0) {
        stopMonitoring()
        updateHealthScore()
        updateTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.updateHealthScore()
            }
        }
    }

    func stopMonitoring() {
        updateTimer?.invalidate()
        updateTimer = nil
    }

    func updateHealthScore() {
        // Update individual metrics
        cpuUsage = getCPUUsage()
        memoryUsage = getMemoryUsage()
        diskUsage = getDiskUsage()
        batteryHealth = getBatteryHealth()
        thermalState = getThermalState()

        // Calculate component scores
        cpuScore = calculateCPUScore(cpuUsage)
        memoryScore = calculateMemoryScore(memoryUsage)
        diskScore = calculateDiskScore(diskUsage)
        batteryScore = batteryHealth
        thermalScore = thermalState.score

        // Calculate weighted health score
        let weightedScore =
            Double(cpuScore) * weights["cpu"]! +
            Double(memoryScore) * weights["memory"]! +
            Double(diskScore) * weights["disk"]! +
            Double(thermalScore) * weights["thermal"]! +
            Double(batteryScore) * weights["battery"]!

        healthScore = min(100, max(0, Int(weightedScore)))
        healthGrade = HealthGrade.from(score: healthScore)
    }

    // MARK: - Score Calculation Methods

    private func calculateCPUScore(_ usage: Double) -> Int {
        // CPU score decreases as usage increases
        // 0-50% = 100, 50-75% = linear decrease to 75, 75-100% = linear decrease to 25
        switch usage {
        case 0..<50:
            return 100
        case 50..<75:
            return 100 - Int((usage - 50) * 1.0) // 100 -> 75
        case 75..<90:
            return 75 - Int((usage - 75) * 2.0) // 75 -> 45
        default:
            return max(25, 45 - Int((usage - 90) * 2.0))
        }
    }

    private func calculateMemoryScore(_ usage: Double) -> Int {
        // Memory score based on pressure-like thresholds
        switch usage {
        case 0..<60:
            return 100
        case 60..<75:
            return 100 - Int((usage - 60) * 1.67) // 100 -> 75
        case 75..<90:
            return 75 - Int((usage - 75) * 2.5) // 75 -> 37
        default:
            return max(20, 37 - Int((usage - 90) * 1.7))
        }
    }

    private func calculateDiskScore(_ usage: Double) -> Int {
        // Disk score - systems slow down significantly when disk is nearly full
        switch usage {
        case 0..<70:
            return 100
        case 70..<80:
            return 100 - Int((usage - 70) * 2.5) // 100 -> 75
        case 80..<90:
            return 75 - Int((usage - 80) * 3.0) // 75 -> 45
        case 90..<95:
            return 45 - Int((usage - 90) * 4.0) // 45 -> 25
        default:
            return max(10, 25 - Int((usage - 95) * 3.0))
        }
    }

    // MARK: - System Metrics

    private func getCPUUsage() -> Double {
        var cpuInfo: processor_info_array_t?
        var numCPUInfo: mach_msg_type_number_t = 0
        var numCPUs: natural_t = 0

        let result = host_processor_info(mach_host_self(),
                                          PROCESSOR_CPU_LOAD_INFO,
                                          &numCPUs,
                                          &cpuInfo,
                                          &numCPUInfo)

        guard result == KERN_SUCCESS, let cpuInfo = cpuInfo else {
            return 0
        }

        defer {
            let cpuInfoSize = vm_size_t(numCPUInfo) * vm_size_t(MemoryLayout<integer_t>.stride)
            vm_deallocate(mach_task_self_, vm_address_t(bitPattern: cpuInfo), cpuInfoSize)
        }

        var totalUsage: Double = 0

        for i in 0..<Int32(numCPUs) {
            let offset = Int(CPU_STATE_MAX) * Int(i)
            let user = Double(cpuInfo[offset + Int(CPU_STATE_USER)])
            let system = Double(cpuInfo[offset + Int(CPU_STATE_SYSTEM)])
            let nice = Double(cpuInfo[offset + Int(CPU_STATE_NICE)])
            let idle = Double(cpuInfo[offset + Int(CPU_STATE_IDLE)])

            let total = user + system + nice + idle
            let usage = (user + system + nice) / total * 100
            totalUsage += usage
        }

        return totalUsage / Double(numCPUs)
    }

    private func getMemoryUsage() -> Double {
        var stats = vm_statistics64()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)

        let result = withUnsafeMutablePointer(to: &stats) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_statistics64(mach_host_self(), HOST_VM_INFO64, $0, &count)
            }
        }

        guard result == KERN_SUCCESS else { return 0 }

        var pageSize: vm_size_t = 0
        host_page_size(mach_host_self(), &pageSize)

        let physicalMemory = Double(ProcessInfo.processInfo.physicalMemory)
        let activeMemory = Double(stats.active_count) * Double(pageSize)
        let wiredMemory = Double(stats.wire_count) * Double(pageSize)
        let compressedMemory = Double(stats.compressor_page_count) * Double(pageSize)

        let usedMemory = activeMemory + wiredMemory + compressedMemory
        return (usedMemory / physicalMemory) * 100
    }

    private func getDiskUsage() -> Double {
        let fileManager = FileManager.default

        do {
            let attributes = try fileManager.attributesOfFileSystem(forPath: "/")
            guard let totalSize = attributes[.systemSize] as? Int64,
                  let freeSize = attributes[.systemFreeSize] as? Int64 else {
                return 0
            }

            let usedSize = totalSize - freeSize
            return (Double(usedSize) / Double(totalSize)) * 100
        } catch {
            return 0
        }
    }

    private func getBatteryHealth() -> Int {
        // Get battery health using IOKit
        let snapshot = IOPSCopyPowerSourcesInfo().takeRetainedValue()
        let sources = IOPSCopyPowerSourcesList(snapshot).takeRetainedValue() as [CFTypeRef]

        for source in sources {
            if let info = IOPSGetPowerSourceDescription(snapshot, source).takeUnretainedValue() as? [String: Any] {
                if let maxCapacity = info[kIOPSMaxCapacityKey] as? Int,
                   let designCapacity = info[kIOPSDesignCapacityKey] as? Int,
                   designCapacity > 0 {
                    return min(100, (maxCapacity * 100) / designCapacity)
                }
                // If we can't get design capacity, assume 100% health
                return 100
            }
        }

        // No battery (desktop Mac) - return 100%
        return 100
    }

    private func getThermalState() -> ThermalState {
        let thermalState = ProcessInfo.processInfo.thermalState

        switch thermalState {
        case .nominal:
            return .nominal
        case .fair:
            return .fair
        case .serious:
            return .serious
        case .critical:
            return .critical
        @unknown default:
            return .nominal
        }
    }

    // MARK: - Formatted Strings

    func formattedHealthScore() -> String {
        return "\(healthScore)"
    }

    func formattedCPUUsage() -> String {
        return String(format: "%.1f%%", cpuUsage)
    }

    func formattedMemoryUsage() -> String {
        return String(format: "%.1f%%", memoryUsage)
    }

    func formattedDiskUsage() -> String {
        return String(format: "%.1f%%", diskUsage)
    }

    // MARK: - Health Recommendations

    func getRecommendations() -> [HealthRecommendation] {
        var recommendations: [HealthRecommendation] = []

        if cpuScore < 75 {
            recommendations.append(HealthRecommendation(
                category: "CPU",
                message: "High CPU usage detected. Consider closing unused applications.",
                severity: cpuScore < 50 ? .high : .medium,
                icon: "cpu"
            ))
        }

        if memoryScore < 75 {
            recommendations.append(HealthRecommendation(
                category: "Memory",
                message: "Memory pressure is elevated. Close applications to free up RAM.",
                severity: memoryScore < 50 ? .high : .medium,
                icon: "memorychip"
            ))
        }

        if diskScore < 75 {
            recommendations.append(HealthRecommendation(
                category: "Disk",
                message: "Disk space is running low. Run a cleanup to free space.",
                severity: diskScore < 50 ? .high : .medium,
                icon: "internaldrive"
            ))
        }

        if thermalState != .nominal {
            recommendations.append(HealthRecommendation(
                category: "Thermal",
                message: "System is running hot. Ensure proper ventilation.",
                severity: thermalState == .critical ? .high : .medium,
                icon: "thermometer"
            ))
        }

        if batteryScore < 80 {
            recommendations.append(HealthRecommendation(
                category: "Battery",
                message: "Battery health is degraded. Consider battery service.",
                severity: batteryScore < 50 ? .high : .low,
                icon: "battery.25"
            ))
        }

        return recommendations
    }
}

// MARK: - Health Recommendation

struct HealthRecommendation: Identifiable {
    let id = UUID()
    let category: String
    let message: String
    let severity: Severity
    let icon: String

    enum Severity {
        case low, medium, high

        var color: NSColor {
            switch self {
            case .low: return .systemBlue
            case .medium: return .systemOrange
            case .high: return .systemRed
            }
        }
    }
}
