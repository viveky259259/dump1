import Foundation

/// Handles file operations that may require administrator privileges
final class PrivilegedFileManager: Sendable {
    static let shared = PrivilegedFileManager()
    
    private init() {}
    
    /// Attempts to delete a file/folder with administrator privileges using osascript
    func deleteWithAdminPrivileges(path: String) async throws {
        let escapedPath = path.replacingOccurrences(of: "\"", with: "\\\"")
        let script = "do shell script \"rm -rf \\\"\(escapedPath)\\\"\" with administrator privileges"

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        process.arguments = ["-e", script]

        let errorPipe = Pipe()
        process.standardError = errorPipe
        process.standardOutput = FileHandle.nullDevice

        try process.run()

        // Wait for process completion asynchronously via terminationHandler
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            process.terminationHandler = { terminatedProcess in
                if terminatedProcess.terminationStatus == 0 {
                    continuation.resume()
                } else {
                    let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
                    let errorMessage = String(data: errorData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
                        ?? "Unknown error (exit code \(terminatedProcess.terminationStatus))"

                    // Exit code 1 with "User canceled" = user dismissed the password dialog
                    let code = errorMessage.contains("User canceled") ? NSUserCancelledError : 2
                    continuation.resume(throwing: NSError(
                        domain: "PrivilegedFileManager",
                        code: code,
                        userInfo: [NSLocalizedDescriptionKey: errorMessage]
                    ))
                }
            }
        }
    }
    
    /// Checks if a path requires administrator privileges to delete
    func requiresAdminPrivileges(path: String) -> Bool {
        let fileManager = FileManager.default
        
        // Check if we can write to the file itself
        if fileManager.isWritableFile(atPath: path) {
            return false
        }
        
        // Check if we can write to the parent directory
        let url = URL(fileURLWithPath: path)
        let parentPath = url.deletingLastPathComponent().path
        if fileManager.isWritableFile(atPath: parentPath) {
            return false
        }
        
        // Check if it's in a protected system location
        let protectedPaths = ["/Applications", "/System", "/Library", "/usr", "/bin", "/sbin"]
        for protectedPath in protectedPaths {
            if path.hasPrefix(protectedPath) {
                return true
            }
        }
        
        return true
    }
    
    /// Attempts to delete with normal permissions first, then tries with admin if needed
    func deleteItem(at path: String) async throws {
        let fileManager = FileManager.default
        let url = URL(fileURLWithPath: path)
        
        do {
            // Try normal deletion first
            try fileManager.trashItem(at: url, resultingItemURL: nil)
        } catch let error as NSError {
            // Check if it's a permission error
            if error.code == NSFileWriteNoPermissionError || 
               error.domain == NSCocoaErrorDomain && error.code == 513 {
                // Permission error - try with admin privileges
                try await deleteWithAdminPrivileges(path: path)
            } else {
                // Some other error - rethrow it
                throw error
            }
        }
    }
}
