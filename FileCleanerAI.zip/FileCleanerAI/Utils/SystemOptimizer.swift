import Foundation

// MARK: - Optimization Task Model

struct OptimizationTask: Identifiable {
    let id: String
    let name: String
    let description: String
    let icon: String
    let requiresAdmin: Bool
    let warningMessage: String?
    var isSelected: Bool = false
    var status: OptimizationStatus = .pending

    enum OptimizationStatus: Equatable {
        case pending
        case running
        case success(String)
        case failed(String)
        case skipped
    }

    var statusIcon: String {
        switch status {
        case .pending: return "circle"
        case .running: return "arrow.trianglehead.2.clockwise"
        case .success: return "checkmark.circle.fill"
        case .failed: return "xmark.circle.fill"
        case .skipped: return "minus.circle"
        }
    }
}

// MARK: - System Optimizer

@MainActor
class SystemOptimizer: ObservableObject {
    static let shared = SystemOptimizer()

    @Published var tasks: [OptimizationTask] = []
    @Published var isRunning = false
    @Published var progress: Double = 0.0
    @Published var lastRunDate: Date?

    private let logManager = LogManager.shared

    private init() {
        initializeTasks()
    }

    private func initializeTasks() {
        tasks = [
            OptimizationTask(
                id: "dns_cache",
                name: "Flush DNS Cache",
                description: "Clear the DNS resolver cache to fix network issues",
                icon: "network",
                requiresAdmin: true,
                warningMessage: nil,
                isSelected: true
            ),
            OptimizationTask(
                id: "purge_memory",
                name: "Purge Inactive Memory",
                description: "Free up inactive memory pages held by the system",
                icon: "memorychip",
                requiresAdmin: true,
                warningMessage: nil,
                isSelected: true
            ),
            OptimizationTask(
                id: "spotlight_index",
                name: "Rebuild Spotlight Index",
                description: "Re-index Spotlight search database for faster searches",
                icon: "magnifyingglass",
                requiresAdmin: true,
                warningMessage: "This may take several minutes and Spotlight will be temporarily unavailable."
            ),
            OptimizationTask(
                id: "launch_services",
                name: "Rebuild Launch Services",
                description: "Fix duplicate entries in 'Open With' menus",
                icon: "square.grid.2x2",
                requiresAdmin: false,
                warningMessage: nil,
                isSelected: true
            ),
            OptimizationTask(
                id: "font_cache",
                name: "Clear Font Caches",
                description: "Remove cached font data to fix font rendering issues",
                icon: "textformat",
                requiresAdmin: true,
                warningMessage: nil
            ),
            OptimizationTask(
                id: "cups_cache",
                name: "Clear Print System Cache",
                description: "Reset CUPS print queue and clear stale print jobs",
                icon: "printer",
                requiresAdmin: true,
                warningMessage: nil
            ),
            OptimizationTask(
                id: "quicklook_cache",
                name: "Reset QuickLook Cache",
                description: "Clear thumbnail previews to fix broken QuickLook previews",
                icon: "eye",
                requiresAdmin: false,
                warningMessage: nil,
                isSelected: true
            ),
            OptimizationTask(
                id: "icon_cache",
                name: "Clear Icon Cache",
                description: "Reset cached application icons to fix display issues",
                icon: "app.badge.fill",
                requiresAdmin: false,
                warningMessage: nil
            ),
            OptimizationTask(
                id: "homebrew_cleanup",
                name: "Homebrew Cleanup",
                description: "Remove old formula versions, orphaned dependencies, and caches",
                icon: "mug.fill",
                requiresAdmin: false,
                warningMessage: nil,
                isSelected: true
            ),
            OptimizationTask(
                id: "docker_cleanup",
                name: "Docker Cleanup",
                description: "Remove stopped containers, dangling images, and build cache",
                icon: "shippingbox.fill",
                requiresAdmin: false,
                warningMessage: "This will remove stopped containers and unused Docker images."
            ),
        ]
    }

    func resetTasks() {
        for i in tasks.indices {
            tasks[i].status = .pending
        }
        progress = 0.0
    }

    func runSelectedOptimizations() async {
        let selectedTasks = tasks.enumerated().filter { $0.element.isSelected }
        guard !selectedTasks.isEmpty else { return }

        isRunning = true
        progress = 0.0

        let total = Double(selectedTasks.count)

        for (idx, (i, _)) in selectedTasks.enumerated() {
            tasks[i].status = .running

            let result = await executeTask(tasks[i])

            switch result {
            case .success(let message):
                tasks[i].status = .success(message)
                logManager.log("Optimization success: \(tasks[i].name) — \(message)", level: .success, category: .system)
            case .failure(let error):
                tasks[i].status = .failed(error.localizedDescription)
                logManager.log("Optimization failed: \(tasks[i].name) — \(error.localizedDescription)", level: .error, category: .system)
            }

            progress = Double(idx + 1) / total
        }

        // Mark unselected as skipped
        for i in tasks.indices where !tasks[i].isSelected {
            tasks[i].status = .skipped
        }

        isRunning = false
        lastRunDate = Date()
        progress = 1.0
    }

    // MARK: - Task Execution

    private func executeTask(_ task: OptimizationTask) async -> Result<String, Error> {
        switch task.id {
        case "dns_cache":
            return await runShellCommand(
                "/usr/bin/dscacheutil", arguments: ["-flushcache"],
                adminFallback: "/usr/bin/sudo /usr/bin/killall -HUP mDNSResponder",
                successMessage: "DNS cache flushed"
            )

        case "purge_memory":
            return await runAdminShellCommand(
                command: "purge",
                successMessage: "Inactive memory purged"
            )

        case "spotlight_index":
            return await runAdminShellCommand(
                command: "mdutil -E /",
                successMessage: "Spotlight re-indexing started"
            )

        case "launch_services":
            let lsregister = "/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister"
            return await runShellCommand(
                lsregister, arguments: ["-kill", "-r", "-domain", "local", "-domain", "system", "-domain", "user"],
                successMessage: "Launch Services database rebuilt"
            )

        case "font_cache":
            return await runAdminShellCommand(
                command: "atsutil databases -remove",
                successMessage: "Font caches cleared"
            )

        case "cups_cache":
            return await runAdminShellCommand(
                command: "rm -rf /var/spool/cups/cache/*",
                successMessage: "Print system cache cleared"
            )

        case "quicklook_cache":
            return await runShellCommand(
                "/usr/bin/qlmanage", arguments: ["-r", "cache"],
                successMessage: "QuickLook cache reset"
            )

        case "icon_cache":
            let home = FileManager.default.homeDirectoryForCurrentUser.path
            let iconServicesPath = "\(home)/Library/Caches/com.apple.iconservices.store"
            do {
                if FileManager.default.fileExists(atPath: iconServicesPath) {
                    try FileManager.default.removeItem(atPath: iconServicesPath)
                }
                return .success("Icon cache cleared")
            } catch {
                return .failure(error)
            }

        case "homebrew_cleanup":
            return await executeHomebrewCleanup()

        case "docker_cleanup":
            return await executeDockerCleanup()

        default:
            return .failure(NSError(domain: "SystemOptimizer", code: 1, userInfo: [NSLocalizedDescriptionKey: "Unknown task"]))
        }
    }

    private func executeHomebrewCleanup() async -> Result<String, Error> {
        // Find brew
        var brewPath: String?
        for path in ["/opt/homebrew/bin/brew", "/usr/local/bin/brew"] {
            if FileManager.default.fileExists(atPath: path) {
                brewPath = path
                break
            }
        }
        guard let brew = brewPath else {
            return .failure(NSError(domain: "SystemOptimizer", code: 2, userInfo: [NSLocalizedDescriptionKey: "Homebrew not found"]))
        }

        // Run cleanup
        let cleanup = await runShellCommand(brew, arguments: ["cleanup", "--prune=all"], successMessage: "")
        if case .failure(let error) = cleanup { return .failure(error) }

        // Run autoremove
        _ = await runShellCommand(brew, arguments: ["autoremove"], successMessage: "")

        return .success("Homebrew cleaned: old versions removed, orphans cleared")
    }

    private func executeDockerCleanup() async -> Result<String, Error> {
        // Find docker
        var dockerPath: String?
        for path in ["/usr/local/bin/docker", "/opt/homebrew/bin/docker", "/usr/bin/docker"] {
            if FileManager.default.fileExists(atPath: path) {
                dockerPath = path
                break
            }
        }
        guard let docker = dockerPath else {
            return .failure(NSError(domain: "SystemOptimizer", code: 2, userInfo: [NSLocalizedDescriptionKey: "Docker not found"]))
        }

        // docker system prune -f
        let pruneResult = await runShellCommand(docker, arguments: ["system", "prune", "-f"], successMessage: "")
        if case .failure(let error) = pruneResult { return .failure(error) }

        // docker builder prune -f
        _ = await runShellCommand(docker, arguments: ["builder", "prune", "-f"], successMessage: "")

        return .success("Docker cleaned: stopped containers, dangling images, and build cache removed")
    }

    private func runShellCommand(_ executable: String, arguments: [String], adminFallback: String? = nil, successMessage: String) async -> Result<String, Error> {
        do {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: executable)
            process.arguments = arguments
            process.standardOutput = FileHandle.nullDevice
            process.standardError = FileHandle.nullDevice
            try process.run()

            await withCheckedContinuation { continuation in
                process.terminationHandler = { _ in continuation.resume() }
            }

            if process.terminationStatus == 0 {
                return .success(successMessage)
            } else if let fallback = adminFallback {
                return await runAdminShellCommand(command: fallback, successMessage: successMessage)
            } else {
                return .failure(NSError(domain: "SystemOptimizer", code: Int(process.terminationStatus),
                                        userInfo: [NSLocalizedDescriptionKey: "Command exited with code \(process.terminationStatus)"]))
            }
        } catch {
            return .failure(error)
        }
    }

    private func runAdminShellCommand(command: String, successMessage: String) async -> Result<String, Error> {
        let script = "do shell script \"\(command)\" with administrator privileges"

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        process.arguments = ["-e", script]

        let errorPipe = Pipe()
        process.standardError = errorPipe
        process.standardOutput = FileHandle.nullDevice

        do {
            try process.run()

            return await withCheckedContinuation { continuation in
                process.terminationHandler = { p in
                    if p.terminationStatus == 0 {
                        continuation.resume(returning: .success(successMessage))
                    } else {
                        let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
                        let msg = String(data: errorData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown error"
                        continuation.resume(returning: .failure(NSError(
                            domain: "SystemOptimizer", code: Int(p.terminationStatus),
                            userInfo: [NSLocalizedDescriptionKey: msg]
                        )))
                    }
                }
            }
        } catch {
            return .failure(error)
        }
    }
}
