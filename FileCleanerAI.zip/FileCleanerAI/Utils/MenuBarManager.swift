import AppKit
import SwiftUI

@MainActor
class MenuBarManager: ObservableObject {
    static let shared = MenuBarManager()

    @Published var isEnabled = false {
        didSet {
            UserDefaults.standard.set(isEnabled, forKey: "com.filecleanerai.menubar.enabled")
            if isEnabled { setupStatusItem() } else { removeStatusItem() }
        }
    }

    private var statusItem: NSStatusItem?
    private var updateTimer: Timer?
    private let healthManager = HealthScoreManager.shared

    private init() {
        isEnabled = UserDefaults.standard.bool(forKey: "com.filecleanerai.menubar.enabled")
        if isEnabled {
            setupStatusItem()
        }
    }

    // MARK: - Setup

    func setupStatusItem() {
        guard statusItem == nil else {
            updateMenu()
            return
        }

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        updateIcon()
        updateMenu()

        // Start periodic updates
        updateTimer?.invalidate()
        updateTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.updateIcon()
                self?.updateMenu()
            }
        }
    }

    func removeStatusItem() {
        updateTimer?.invalidate()
        updateTimer = nil
        if let item = statusItem {
            NSStatusBar.system.removeStatusItem(item)
            statusItem = nil
        }
    }

    // MARK: - Icon

    private func updateIcon() {
        guard let button = statusItem?.button else { return }

        let score = healthManager.healthScore
        let imageName: String
        if score >= 90 {
            imageName = "leaf.fill"
        } else if score >= 75 {
            imageName = "leaf"
        } else if score >= 60 {
            imageName = "exclamationmark.triangle"
        } else {
            imageName = "exclamationmark.triangle.fill"
        }

        button.image = NSImage(systemSymbolName: imageName, accessibilityDescription: "Disk Health")
        button.image?.size = NSSize(width: 16, height: 16)
        button.toolTip = "FileCleanerAI — Health: \(score)/100"
    }

    // MARK: - Menu

    private func updateMenu() {
        let menu = NSMenu()

        // Health score
        let healthItem = NSMenuItem(title: "Health Score: \(healthManager.healthScore)/100 (\(healthManager.healthGrade.rawValue))", action: nil, keyEquivalent: "")
        healthItem.isEnabled = false
        menu.addItem(healthItem)

        menu.addItem(NSMenuItem.separator())

        // Disk usage
        let diskInfo = getDiskInfo()
        let diskItem = NSMenuItem(title: "Disk: \(diskInfo.used) used of \(diskInfo.total) (\(diskInfo.freePercent)% free)", action: nil, keyEquivalent: "")
        diskItem.isEnabled = false
        menu.addItem(diskItem)

        // CPU & Memory
        let cpuItem = NSMenuItem(title: "CPU: \(Int(healthManager.cpuUsage))%  |  Memory: \(Int(healthManager.memoryUsage))%", action: nil, keyEquivalent: "")
        cpuItem.isEnabled = false
        menu.addItem(cpuItem)

        menu.addItem(NSMenuItem.separator())

        // Schedule status
        let scheduleManager = ScheduledCleaningManager.shared
        let scheduleItem = NSMenuItem(title: "Schedule: \(scheduleManager.statusText)", action: nil, keyEquivalent: "")
        scheduleItem.isEnabled = false
        menu.addItem(scheduleItem)

        menu.addItem(NSMenuItem.separator())

        // Open app
        let openItem = NSMenuItem(title: "Open FileCleanerAI", action: #selector(openApp), keyEquivalent: "o")
        openItem.target = self
        menu.addItem(openItem)

        // Quick scan
        let scanItem = NSMenuItem(title: "Quick Scan", action: #selector(quickScan), keyEquivalent: "s")
        scanItem.target = self
        menu.addItem(scanItem)

        menu.addItem(NSMenuItem.separator())

        // Disable
        let disableItem = NSMenuItem(title: "Hide Menu Bar Icon", action: #selector(disableMenuBar), keyEquivalent: "")
        disableItem.target = self
        menu.addItem(disableItem)

        statusItem?.menu = menu
    }

    // MARK: - Actions

    @objc private func openApp() {
        NSApp.activate(ignoringOtherApps: true)
        if let window = NSApp.windows.first {
            window.makeKeyAndOrderFront(nil)
        }
    }

    @objc private func quickScan() {
        NSApp.activate(ignoringOtherApps: true)
        Task {
            await ScheduledCleaningManager.shared.runScheduledScan()
        }
    }

    @objc private func disableMenuBar() {
        isEnabled = false
    }

    // MARK: - Disk Info

    private func getDiskInfo() -> (total: String, used: String, free: String, freePercent: Int) {
        let fm = FileManager.default
        do {
            let attrs = try fm.attributesOfFileSystem(forPath: "/")
            let total = attrs[.systemSize] as? Int64 ?? 0
            let free = attrs[.systemFreeSize] as? Int64 ?? 0
            let used = total - free
            let freePercent = total > 0 ? Int(Double(free) / Double(total) * 100) : 0
            return (
                ByteCountFormatter.string(fromByteCount: total, countStyle: .file),
                ByteCountFormatter.string(fromByteCount: used, countStyle: .file),
                ByteCountFormatter.string(fromByteCount: free, countStyle: .file),
                freePercent
            )
        } catch {
            return ("?", "?", "?", 0)
        }
    }
}
