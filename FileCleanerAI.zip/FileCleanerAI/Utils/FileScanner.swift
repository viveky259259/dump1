import Foundation
import AppKit

@MainActor
class FileScanner: ObservableObject {
    @Published var discoveredFiles: [DiscoveredFile] = []
    @Published var filePatterns: [FilePattern] = []
    @Published var isScanning = false
    @Published var scanProgress: Double = 0.0
    @Published var scanDirectories: [ScanDirectory] = []

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let performanceManager = PerformanceManager.shared
    private let memoryMonitor = MemoryMonitor.shared
    private let whitelistManager = WhitelistManager.shared
    private let observability = ObservabilityManager.shared
    
    // MARK: - Pre-compiled Pattern Matching (Performance Optimization #6)
    // Note: nonisolated(unsafe) is needed because these are accessed from nonisolated static methods
    
    /// Pre-compiled set of patterns for O(1) exact matching
    nonisolated(unsafe) private static let patternSet: Set<String> = Set(ScanConfiguration.commonTempPatterns)
    
    /// Pre-compiled set of extensions (without dots) for O(1) matching
    nonisolated(unsafe) private static let extensionSet: Set<String> = Set(
        ScanConfiguration.fileExtensions.map { $0.hasPrefix(".") ? String($0.dropFirst()) : $0 }
    )
    
    /// Combined skip paths set for O(1) lookup
    nonisolated(unsafe) private static let skipPathComponents: Set<String> = Set([
        "/System", "/Library/System", "/private", "/Applications",
        "/usr", "/bin", "/sbin", "/dev",
        "Library/Application Support", "Library/Preferences"
    ])
    
    // MARK: - Bookmark Management
    
    private func requestAndSaveBookmarks(for directories: [String]) async {
        await MainActor.run {
            for directory in directories {
                let url = URL(fileURLWithPath: directory)
                
                // Check if we already have bookmark for this directory
                if BookmarkManager.shared.hasBookmark(for: url) {
                    // Try to access with existing bookmark
                    if BookmarkManager.shared.startAccessingSecurityScopedResource(for: url) {
                        continue // Already have access
                    }
                }
                
                // Request new bookmark (this will save it automatically)
                BookmarkManager.shared.requestAccess(for: url)
            }
        }
    }
    
    // MARK: - Scanning
    
    func scanDirectories() async {
        logManager.log("Starting directory scan", level: .info, category: .scanning)
        discoveredFiles.removeAll()
        scanProgress = 0.0

        // Performance tracking: Start scan operation
        let scanStartTime = Date()
        let memoryAtStart = memoryMonitor.appMemoryUsage
        var peakMemory = memoryAtStart

        // Expand home directory paths
        let directories = ScanConfiguration.defaultDirectories.map { dir in
            (dir as NSString).expandingTildeInPath
        }

        // Observability: Emit scan started event
        observability.scanStarted(directories: directories)
        
        // Request and save bookmarks for persistent access
        await requestAndSaveBookmarks(for: directories)
        
        // Initialize scan directory tracking
        scanDirectories = directories.map { path in
            let displayName = (path as NSString).lastPathComponent.isEmpty ?
                (path as NSString).deletingLastPathComponent : (path as NSString).lastPathComponent
            
            return ScanDirectory(
                path: path,
                displayName: displayName,
                status: .pending,
                subdirectories: [],
                itemsFound: 0,
                totalSize: 0
            )
        }
        
        logManager.log("Scanning \(directories.count) directories", level: .info, category: .scanning)
        let totalDirs = Double(directories.count)
        
        for (index, directory) in directories.enumerated() {
            // Update status to in progress
            if index < scanDirectories.count {
                scanDirectories[index].status = .inProgress
            }
            
            logManager.log("Scanning: \(directory)", level: .info, category: .scanning)
            await scanDirectorySinglePass(directory, directoryIndex: index)
            scanProgress = Double(index + 1) / totalDirs

            // Observability: Emit progress
            observability.scanProgress(
                scanned: index + 1,
                total: Int(totalDirs),
                currentDirectory: directory
            )
            
            // Track peak memory during scan
            peakMemory = max(peakMemory, memoryMonitor.appMemoryUsage)
            
            // Update status to completed
            if index < scanDirectories.count {
                scanDirectories[index].status = .completed
            }
            
            // Yield to allow UI updates after each directory
            await Task.yield()
        }
        
        // Performance tracking: Record scan metrics
        let scanDuration = Date().timeIntervalSince(scanStartTime)
        let totalSizeScanned = discoveredFiles.reduce(Int64(0)) { $0 + $1.size }
        
        await performanceManager.recordScanMetrics(
            filesScanned: discoveredFiles.count,
            directoriesScanned: directories.count,
            duration: scanDuration,
            totalSizeScanned: totalSizeScanned,
            memoryAtStart: memoryAtStart,
            peakMemory: peakMemory
        )

        logManager.log("Scan complete: Found \(discoveredFiles.count) files", level: .success, category: .scanning)

        // Observability: Emit scan completed event
        observability.scanCompleted(
            filesFound: discoveredFiles.count,
            totalSize: totalSizeScanned,
            duration: scanDuration
        )
    }
    
    // MARK: - Single-Pass Directory Scanning (Performance Optimization #1 & #2)
    
    /// Scans directory once, matching all patterns and extensions in a single pass
    /// This replaces the previous approach of enumerating once per pattern/extension
    private func scanDirectorySinglePass(_ path: String, directoryIndex: Int) async {
        guard fileManager.fileExists(atPath: path) else {
            logManager.log("Directory does not exist: \(path)", level: .warning, category: .scanning)
            return
        }
        
        logManager.log("Single-pass scan for patterns in: \(path)", level: .debug, category: .scanning)
        
        // Capture pattern/extension sets for use in detached task
        let patterns = Self.patternSet
        let extensions = Self.extensionSet
        
        // Single enumeration for all patterns and extensions
        let foundFiles: [DiscoveredFile] = await Task.detached(priority: .userInitiated) { () -> [DiscoveredFile] in
            let url = URL(fileURLWithPath: path)
            let fileManager = FileManager.default

            guard let enumerator = fileManager.enumerator(
                at: url,
                includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey, .contentModificationDateKey, .isSymbolicLinkKey],
                options: [.skipsHiddenFiles]
            ) else { return [] }

            var files: [DiscoveredFile] = []
            var directorySizes: [String: Int64] = [:] // Cache for directory sizes
            var processedCount = 0
            let batchSize = 1000

            // Process files in batches to avoid memory pressure
            while let element = enumerator.nextObject() as? URL {
                // Use autoreleasepool to release temporary objects immediately
                autoreleasepool {
                    let filePath = element.path

                    // Skip system directories using optimized check
                    if Self.shouldSkipPathOptimized(filePath) {
                        enumerator.skipDescendants()
                        return // return from autoreleasepool, continue loop
                    }

                    // Skip symlinks to avoid double-counting
                    if let resourceValues = try? element.resourceValues(forKeys: [.isSymbolicLinkKey]),
                       resourceValues.isSymbolicLink == true {
                        return // return from autoreleasepool, continue loop
                    }

                    let fileName = element.lastPathComponent
                    let fileExtension = element.pathExtension

                    // Check if file matches any pattern or extension (O(1) lookups)
                    let matchesPattern = patterns.contains(fileName) ||
                        patterns.contains { pattern in fileName.contains(pattern) }
                    let matchesExtension = extensions.contains(fileExtension)

                    if matchesPattern || matchesExtension {
                        // Create discovered file without recursive directory size calculation
                        if let file = Self.createDiscoveredFileOptimized(
                            from: element,
                            fileManager: fileManager,
                            directorySizeCache: &directorySizes
                        ) {
                            files.append(file)

                            // Skip descendants if this is a directory we're tracking (e.g., node_modules)
                            if file.isDirectory {
                                enumerator.skipDescendants()
                            }
                        }
                    }

                    processedCount += 1
                }

                // Yield periodically to prevent blocking
                if processedCount % batchSize == 0 {
                    await Task.yield()
                }
            }

            return files
        }.value
        
        // Add found files immediately - this triggers UI update
        if !foundFiles.isEmpty {
            discoveredFiles.append(contentsOf: foundFiles)

            // Update scan directory stats
            if directoryIndex < scanDirectories.count {
                scanDirectories[directoryIndex].itemsFound = foundFiles.count
                scanDirectories[directoryIndex].totalSize = foundFiles.reduce(Int64(0)) { $0 + $1.size }
            }

            // Log summary
            let totalSize = foundFiles.reduce(Int64(0)) { $0 + $1.size }
            let sizeStr = ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file)
            logManager.log("Found \(foundFiles.count) items in single pass (\(sizeStr))", level: .info, category: .scanning)

            // Log first few files found
            for file in foundFiles.prefix(3) {
                let size = ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file)
                logManager.log("  → \(file.displayPath) (\(size))", level: .debug, category: .scanning)
            }
            if foundFiles.count > 3 {
                logManager.log("  → ... and \(foundFiles.count - 3) more", level: .debug, category: .scanning)
            }
        }
    }
    
    // MARK: - Deletion

    @Published var isDeletingFiles = false
    @Published var deletionProgress: Double = 0.0
    @Published var currentDeletingFile: String = ""

    func moveToTrash(pattern: FilePattern) async -> (successCount: Int, failureCount: Int) {
        logManager.log("Moving pattern '\(pattern.patternName)' to trash (\(pattern.count) items)", level: .info, category: .deletion)

        // Observability: Emit deletion started
        observability.deletionStarted(patternCount: 1, fileCount: pattern.count)

        // Filter out protected paths first
        var pathsToDelete: [String] = []
        var skippedCount = 0

        for path in pattern.paths {
            if whitelistManager.isProtected(path) {
                if let reason = whitelistManager.protectionReason(for: path) {
                    logManager.log("Skipped protected path: \(path) - \(reason)", level: .warning, category: .deletion)
                }
                skippedCount += 1
            } else {
                pathsToDelete.append(path)
            }
        }

        if skippedCount > 0 {
            logManager.log("Skipped \(skippedCount) protected items", level: .info, category: .deletion)
        }

        guard !pathsToDelete.isEmpty else {
            return (successCount: 0, failureCount: 0)
        }

        // Set deletion state
        await MainActor.run {
            isDeletingFiles = true
            deletionProgress = 0.0
        }

        // Perform deletion in a detached task to avoid blocking
        let result = await performDeletionBatch(paths: pathsToDelete)

        // Reset deletion state
        await MainActor.run {
            isDeletingFiles = false
            deletionProgress = 1.0
            currentDeletingFile = ""
        }

        if result.failureCount == 0 {
            logManager.log("Successfully moved \(result.successCount) items to trash", level: .success, category: .deletion)
        } else {
            logManager.log("Completed with \(result.successCount) successes and \(result.failureCount) failures", level: .warning, category: .deletion)
        }

        // Observability: Emit deletion completed
        observability.deletionCompleted(
            successCount: result.successCount,
            failureCount: result.failureCount,
            bytesFreed: Int64(pattern.totalSize),
            duration: 0 // Duration tracked elsewhere
        )

        return result
    }

    /// Perform deletion in batches with proper error handling for permission prompts
    private func performDeletionBatch(paths: [String]) async -> (successCount: Int, failureCount: Int) {
        var successCount = 0
        var failCount = 0
        let totalCount = paths.count

        for (index, path) in paths.enumerated() {
            // Update progress on main thread
            await MainActor.run {
                deletionProgress = Double(index) / Double(totalCount)
                currentDeletingFile = (path as NSString).lastPathComponent
            }

            // Perform the actual deletion
            let success = await deleteSingleFile(path: path)

            if success {
                successCount += 1
            } else {
                failCount += 1
            }

            // Small yield to allow UI updates and not block the main thread
            await Task.yield()
        }

        return (successCount: successCount, failureCount: failCount)
    }

    /// Delete a single file with proper error handling
    /// Returns true on success, false on failure
    private func deleteSingleFile(path: String) async -> Bool {
        let url = URL(fileURLWithPath: path)

        // Try to use security-scoped bookmark if available
        let hasAccess = BookmarkManager.shared.startAccessingSecurityScopedResource(for: url)

        defer {
            if hasAccess {
                BookmarkManager.shared.stopAccessingSecurityScopedResource(for: url)
            }
        }

        // Perform deletion synchronously but with proper error handling
        do {
            // Check if file still exists
            guard fileManager.fileExists(atPath: path) else {
                logManager.log("File no longer exists: \(path)", level: .warning, category: .deletion)
                return true // Consider it a success since it's already gone
            }

            // Try trashItem (preferred method)
            try fileManager.trashItem(at: url, resultingItemURL: nil)
            logManager.log("Moved to trash: \(path)", level: .success, category: .deletion)
            return true

        } catch let error as NSError {
            // Handle specific error codes
            if error.domain == NSCocoaErrorDomain {
                switch error.code {
                case NSFileNoSuchFileError:
                    logManager.log("File not found: \(path)", level: .warning, category: .deletion)
                    return true // File already gone
                case NSFileWriteNoPermissionError:
                    logManager.log("Permission denied: \(path) - Try granting Full Disk Access in System Settings", level: .error, category: .deletion)
                case NSUserCancelledError:
                    logManager.log("User cancelled deletion: \(path)", level: .info, category: .deletion)
                default:
                    logManager.log("Failed to trash: \(path) - \(error.localizedDescription)", level: .error, category: .deletion)
                }
            } else {
                logManager.log("Failed to trash: \(path) - \(error.localizedDescription)", level: .error, category: .deletion)
            }
            return false
        }
    }
    
    // MARK: - Helper Methods
    
    private func createDiscoveredFile(from url: URL) -> DiscoveredFile? {
        do {
            let resourceValues = try url.resourceValues(forKeys: [
                .fileSizeKey,
                .isDirectoryKey,
                .contentModificationDateKey,
                .totalFileAllocatedSizeKey,
                .isSymbolicLinkKey
            ])

            // Skip symlinks
            if resourceValues.isSymbolicLink == true {
                return nil
            }

            let size: Int64
            if let isDirectory = resourceValues.isDirectory, isDirectory {
                size = directorySize(at: url)
            } else {
                // Prefer allocated size for disk usage accuracy
                if let allocatedSize = resourceValues.totalFileAllocatedSize {
                    size = Int64(allocatedSize)
                } else {
                    size = Int64(resourceValues.fileSize ?? 0)
                }
            }

            return DiscoveredFile(
                path: url.path,
                size: size,
                name: url.lastPathComponent,
                isDirectory: resourceValues.isDirectory ?? false,
                modificationDate: resourceValues.contentModificationDate
            )
        } catch {
            return nil
        }
    }

    private func directorySize(at url: URL) -> Int64 {
        var totalSize: Int64 = 0

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isSymbolicLinkKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            // Skip symlinks
            if let values = try? fileURL.resourceValues(forKeys: [.isSymbolicLinkKey]),
               values.isSymbolicLink == true {
                continue
            }

            // Only count files, not directories
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               let isDir = values.isDirectory, !isDir {
                if let allocatedSize = values.totalFileAllocatedSize {
                    totalSize += Int64(allocatedSize)
                } else if let fileSize = values.fileSize {
                    totalSize += Int64(fileSize)
                }
            }
        }

        return totalSize
    }
    
    // MARK: - Optimized Static Methods (Performance Optimization #2 & #6)
    
    /// Optimized path skipping using component-based checking
    nonisolated private static func shouldSkipPathOptimized(_ path: String) -> Bool {
        // Fast check for common skip patterns
        for component in skipPathComponents {
            if path.contains(component) {
                return true
            }
        }
        return false
    }
    
    private func shouldSkipPath(_ path: String) -> Bool {
        return Self.shouldSkipPathOptimized(path)
    }
    
    nonisolated private static func shouldSkipPathStatic(_ path: String) -> Bool {
        return shouldSkipPathOptimized(path)
    }
    
    /// Optimized file creation that uses cached directory sizes
    /// Avoids O(n²) re-enumeration by calculating size during initial traversal
    nonisolated private static func createDiscoveredFileOptimized(
        from url: URL,
        fileManager: FileManager,
        directorySizeCache: inout [String: Int64]
    ) -> DiscoveredFile? {
        do {
            let resourceValues = try url.resourceValues(forKeys: [
                .fileSizeKey,
                .isDirectoryKey,
                .contentModificationDateKey,
                .totalFileAllocatedSizeKey,
                .isSymbolicLinkKey
            ])

            // Skip symlinks
            if resourceValues.isSymbolicLink == true {
                return nil
            }

            let isDirectory = resourceValues.isDirectory ?? false
            let size: Int64

            if isDirectory {
                // Check cache first
                if let cachedSize = directorySizeCache[url.path] {
                    size = cachedSize
                } else {
                    // Calculate directory size and cache it
                    let calculatedSize = directorySizeOptimized(at: url, fileManager: fileManager)
                    directorySizeCache[url.path] = calculatedSize
                    size = calculatedSize
                }
            } else {
                // Use allocated size if available (more accurate), fallback to file size
                if let allocatedSize = resourceValues.totalFileAllocatedSize {
                    size = Int64(allocatedSize)
                } else {
                    size = Int64(resourceValues.fileSize ?? 0)
                }
            }

            return DiscoveredFile(
                path: url.path,
                size: size,
                name: url.lastPathComponent,
                isDirectory: isDirectory,
                modificationDate: resourceValues.contentModificationDate
            )
        } catch {
            return nil
        }
    }

    /// Optimized directory size calculation - uses batch resource fetching with symlink handling
    nonisolated private static func directorySizeOptimized(at url: URL, fileManager: FileManager) -> Int64 {
        var totalSize: Int64 = 0

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else { return 0 }

        // Process in batches to reduce memory pressure
        var batchURLs: [URL] = []
        let batchSize = 500

        while let element = enumerator.nextObject() as? URL {
            batchURLs.append(element)

            if batchURLs.count >= batchSize {
                totalSize += processBatchForSize(batchURLs)
                batchURLs.removeAll(keepingCapacity: true)
            }
        }

        // Process remaining
        if !batchURLs.isEmpty {
            totalSize += processBatchForSize(batchURLs)
        }

        return totalSize
    }

    /// Process a batch of URLs to calculate total size
    nonisolated private static func processBatchForSize(_ urls: [URL]) -> Int64 {
        var size: Int64 = 0
        for url in urls {
            if let values = try? url.resourceValues(forKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey, .isSymbolicLinkKey]),
               values.isSymbolicLink != true,  // Skip symlinks
               let isDir = values.isDirectory, !isDir {
                // Prefer allocated size for disk usage accuracy
                if let allocatedSize = values.totalFileAllocatedSize {
                    size += Int64(allocatedSize)
                } else if let fileSize = values.fileSize {
                    size += Int64(fileSize)
                }
            }
        }
        return size
    }
    
    nonisolated private static func createDiscoveredFileStatic(from url: URL, fileManager: FileManager) -> DiscoveredFile? {
        var cache: [String: Int64] = [:]
        return createDiscoveredFileOptimized(from: url, fileManager: fileManager, directorySizeCache: &cache)
    }

    nonisolated private static func directorySizeStatic(at url: URL, fileManager: FileManager) -> Int64 {
        return directorySizeOptimized(at: url, fileManager: fileManager)
    }
}

