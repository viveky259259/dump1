import Foundation
import ServiceManagement
import AppKit

/// Manages macOS startup/login items including LaunchAgents and LaunchDaemons
@MainActor
class StartupItemsManager: ObservableObject {
    static let shared = StartupItemsManager()

    // MARK: - Published Properties

    @Published var startupItems: [StartupItem] = []
    @Published var isScanning = false
    @Published var lastScanDate: Date?

    // MARK: - Private Properties

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared

    // Known safe Apple/system identifiers that should not be disabled
    private static let systemIdentifiers: Set<String> = [
        "com.apple",
        "com.microsoft",
        "com.google.keystone",
        "com.adobe.ARM"
    ]

    // Known potentially unwanted/unnecessary identifiers
    private static let unwantedPatterns: [String] = [
        "updater",
        "helper",
        "agent",
        "daemon"
    ]

    private init() {}

    // MARK: - LaunchAgent Paths

    private var launchAgentPaths: [(String, StartupItemLocation)] {
        let home = fileManager.homeDirectoryForCurrentUser.path
        return [
            ("\(home)/Library/LaunchAgents", .userLaunchAgents),
            ("/Library/LaunchAgents", .systemLaunchAgents),
            ("/Library/LaunchDaemons", .systemLaunchDaemons)
        ]
    }

    // MARK: - Public Methods

    /// Scan for all startup items
    func scanStartupItems() async {
        isScanning = true
        startupItems = []

        for (path, location) in launchAgentPaths {
            let items = await scanDirectory(path, location: location)
            startupItems.append(contentsOf: items)
        }

        // Sort by name
        startupItems.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }

        lastScanDate = Date()
        isScanning = false

        logManager.log("Found \(startupItems.count) startup items", level: .info, category: .scanning)
    }

    /// Enable a startup item
    func enableItem(_ item: StartupItem) async -> Bool {
        guard !item.isEnabled else { return true }

        let disabledPath = item.path + ".disabled"

        // If it was disabled by renaming, rename it back
        if fileManager.fileExists(atPath: disabledPath) {
            do {
                try fileManager.moveItem(atPath: disabledPath, toPath: item.path)
                logManager.log("Enabled startup item: \(item.name)", level: .success, category: .system)
                await scanStartupItems()
                return true
            } catch {
                logManager.log("Failed to enable \(item.name): \(error.localizedDescription)", level: .error, category: .system)
                return false
            }
        }

        // Try using launchctl
        let result = await runLaunchctl(["load", "-w", item.path])
        if result {
            await scanStartupItems()
        }
        return result
    }

    /// Disable a startup item
    func disableItem(_ item: StartupItem) async -> Bool {
        guard item.isEnabled else { return true }

        // First try launchctl unload
        let unloadResult = await runLaunchctl(["unload", "-w", item.path])

        // Additionally rename the plist to prevent it from loading on next boot
        // This is more reliable than just launchctl
        let disabledPath = item.path + ".disabled"

        if !fileManager.fileExists(atPath: disabledPath) {
            do {
                try fileManager.moveItem(atPath: item.path, toPath: disabledPath)
                logManager.log("Disabled startup item: \(item.name)", level: .success, category: .system)
                await scanStartupItems()
                return true
            } catch {
                logManager.log("Failed to disable \(item.name): \(error.localizedDescription)", level: .error, category: .system)
                // If rename failed, at least launchctl might have worked
                if unloadResult {
                    await scanStartupItems()
                    return true
                }
                return false
            }
        }

        if unloadResult {
            await scanStartupItems()
        }
        return unloadResult
    }

    /// Remove a startup item completely
    func removeItem(_ item: StartupItem) async -> Bool {
        // First disable it
        _ = await disableItem(item)

        // Then trash the file
        do {
            let pathToRemove = fileManager.fileExists(atPath: item.path) ? item.path : item.path + ".disabled"
            try fileManager.trashItem(at: URL(fileURLWithPath: pathToRemove), resultingItemURL: nil)
            logManager.log("Removed startup item: \(item.name)", level: .success, category: .deletion)
            await scanStartupItems()
            return true
        } catch {
            logManager.log("Failed to remove \(item.name): \(error.localizedDescription)", level: .error, category: .deletion)
            return false
        }
    }

    /// Get recommendation for an item
    func getRecommendation(for item: StartupItem) -> StartupRecommendation {
        // Check if it's a system item
        for prefix in Self.systemIdentifiers {
            if item.identifier.hasPrefix(prefix) {
                return .keep(reason: "System component - required for normal operation")
            }
        }

        // Check for potentially unwanted patterns
        let lowerName = item.name.lowercased()
        let lowerIdentifier = item.identifier.lowercased()

        for pattern in Self.unwantedPatterns {
            if lowerName.contains(pattern) || lowerIdentifier.contains(pattern) {
                return .consider(reason: "Helper/updater service - may be unnecessary")
            }
        }

        // Check if the associated app still exists
        if let program = item.program {
            if !fileManager.fileExists(atPath: program) {
                return .remove(reason: "Associated application not found")
            }
        }

        return .neutral
    }

    // MARK: - Private Methods

    private func scanDirectory(_ path: String, location: StartupItemLocation) async -> [StartupItem] {
        var items: [StartupItem] = []

        guard fileManager.fileExists(atPath: path) else { return items }

        do {
            let contents = try fileManager.contentsOfDirectory(atPath: path)

            for filename in contents {
                // Include both .plist and .plist.disabled files
                guard filename.hasSuffix(".plist") || filename.hasSuffix(".plist.disabled") else { continue }

                let fullPath: String
                let isDisabled: Bool

                if filename.hasSuffix(".plist.disabled") {
                    fullPath = (path as NSString).appendingPathComponent(filename.replacingOccurrences(of: ".disabled", with: ""))
                    isDisabled = true
                } else {
                    fullPath = (path as NSString).appendingPathComponent(filename)
                    isDisabled = false
                }

                if let item = parselaunchPlist(at: isDisabled ? fullPath + ".disabled" : fullPath, location: location, isDisabled: isDisabled) {
                    items.append(item)
                }
            }
        } catch {
            logManager.log("Error scanning \(path): \(error.localizedDescription)", level: .error, category: .scanning)
        }

        return items
    }

    private func parselaunchPlist(at path: String, location: StartupItemLocation, isDisabled: Bool) -> StartupItem? {
        guard let dict = NSDictionary(contentsOfFile: path) as? [String: Any] else { return nil }

        let identifier = dict["Label"] as? String ?? (path as NSString).lastPathComponent.replacingOccurrences(of: ".plist", with: "").replacingOccurrences(of: ".disabled", with: "")

        let program: String?
        if let prog = dict["Program"] as? String {
            program = prog
        } else if let args = dict["ProgramArguments"] as? [String], let first = args.first {
            program = first
        } else {
            program = nil
        }

        let runAtLoad = dict["RunAtLoad"] as? Bool ?? false
        let keepAlive = dict["KeepAlive"] as? Bool ?? false

        // Determine the app name from the identifier or program
        let name = extractAppName(from: identifier, program: program)

        // Check if currently loaded
        let isLoaded = checkIfLoaded(identifier: identifier)

        return StartupItem(
            id: UUID(),
            name: name,
            identifier: identifier,
            path: path.replacingOccurrences(of: ".disabled", with: ""),
            location: location,
            program: program,
            isEnabled: !isDisabled && (runAtLoad || keepAlive || isLoaded),
            runAtLoad: runAtLoad,
            keepAlive: keepAlive,
            isLoaded: isLoaded
        )
    }

    private func extractAppName(from identifier: String, program: String?) -> String {
        // Try to extract a friendly name from the identifier
        let components = identifier.split(separator: ".")

        if components.count >= 3 {
            // e.g., "com.spotify.webhelper" -> "Spotify"
            let name = String(components[2])
            return name.prefix(1).uppercased() + name.dropFirst()
        }

        // Fallback to program name
        if let program = program {
            let programName = (program as NSString).lastPathComponent
            return programName.replacingOccurrences(of: "Helper", with: "")
                .replacingOccurrences(of: "Agent", with: "")
                .trimmingCharacters(in: .whitespaces)
        }

        return identifier
    }

    private func checkIfLoaded(identifier: String) -> Bool {
        let process = Process()
        process.launchPath = "/bin/launchctl"
        process.arguments = ["list", identifier]

        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
            process.waitUntilExit()
            return process.terminationStatus == 0
        } catch {
            return false
        }
    }

    private func runLaunchctl(_ arguments: [String]) async -> Bool {
        return await withCheckedContinuation { continuation in
            let process = Process()
            process.launchPath = "/bin/launchctl"
            process.arguments = arguments

            do {
                try process.run()
                process.waitUntilExit()
                let success = process.terminationStatus == 0
                if success {
                    logManager.log("launchctl \(arguments.joined(separator: " ")) succeeded", level: .debug, category: .system)
                } else {
                    logManager.log("launchctl \(arguments.joined(separator: " ")) failed with status \(process.terminationStatus)", level: .warning, category: .system)
                }
                continuation.resume(returning: success)
            } catch {
                logManager.log("launchctl error: \(error.localizedDescription)", level: .error, category: .system)
                continuation.resume(returning: false)
            }
        }
    }
}

// MARK: - Supporting Types

struct StartupItem: Identifiable {
    let id: UUID
    let name: String
    let identifier: String
    let path: String
    let location: StartupItemLocation
    let program: String?
    let isEnabled: Bool
    let runAtLoad: Bool
    let keepAlive: Bool
    let isLoaded: Bool

    var displayPath: String {
        path.replacingOccurrences(of: FileManager.default.homeDirectoryForCurrentUser.path, with: "~")
    }

    var statusDescription: String {
        var parts: [String] = []
        if isLoaded { parts.append("Running") }
        if runAtLoad { parts.append("Runs at Login") }
        if keepAlive { parts.append("Keep Alive") }
        return parts.isEmpty ? "Inactive" : parts.joined(separator: ", ")
    }
}

enum StartupItemLocation: String {
    case userLaunchAgents = "User Launch Agents"
    case systemLaunchAgents = "System Launch Agents"
    case systemLaunchDaemons = "System Launch Daemons"

    var icon: String {
        switch self {
        case .userLaunchAgents: return "person.fill"
        case .systemLaunchAgents: return "gearshape.fill"
        case .systemLaunchDaemons: return "server.rack"
        }
    }

    var requiresAdmin: Bool {
        switch self {
        case .userLaunchAgents: return false
        case .systemLaunchAgents, .systemLaunchDaemons: return true
        }
    }
}

enum StartupRecommendation {
    case keep(reason: String)
    case consider(reason: String)
    case remove(reason: String)
    case neutral

    var color: NSColor {
        switch self {
        case .keep: return .systemGreen
        case .consider: return .systemOrange
        case .remove: return .systemRed
        case .neutral: return .secondaryLabelColor
        }
    }

    var icon: String {
        switch self {
        case .keep: return "checkmark.shield.fill"
        case .consider: return "exclamationmark.triangle.fill"
        case .remove: return "xmark.circle.fill"
        case .neutral: return "questionmark.circle"
        }
    }
}
