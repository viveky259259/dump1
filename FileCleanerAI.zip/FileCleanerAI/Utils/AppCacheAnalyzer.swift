import Foundation
import AppKit

// MARK: - Data Models

struct AppCacheEntry: Identifiable {
    let id: String
    let appName: String
    let bundleId: String
    let cachePath: String
    let cacheSize: Int64
    let lastAccessed: Date
    let icon: NSImage?
    let recommendation: CacheRecommendation

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: cacheSize, countStyle: .file)
    }

    var staleDays: Int {
        Calendar.current.dateComponents([.day], from: lastAccessed, to: Date()).day ?? 0
    }

    var stalenessLabel: String {
        let days = staleDays
        if days == 0 { return "Today" }
        if days == 1 { return "Yesterday" }
        if days < 7 { return "\(days) days ago" }
        if days < 30 { return "\(days / 7) weeks ago" }
        if days < 365 { return "\(days / 30) months ago" }
        return "\(days / 365)+ years ago"
    }
}

enum CacheRecommendation: String {
    case keep = "Keep"
    case safe = "Safe to Clean"
    case recommended = "Recommended"
    case stale = "Stale — Remove"

    var color: String {
        switch self {
        case .keep: return "green"
        case .safe: return "blue"
        case .recommended: return "orange"
        case .stale: return "red"
        }
    }

    var icon: String {
        switch self {
        case .keep: return "checkmark.shield"
        case .safe: return "hand.thumbsup"
        case .recommended: return "exclamationmark.triangle"
        case .stale: return "trash"
        }
    }
}

// MARK: - App Cache Analyzer

@MainActor
class AppCacheAnalyzer: ObservableObject {
    static let shared = AppCacheAnalyzer()

    @Published var entries: [AppCacheEntry] = []
    @Published var isScanning = false
    @Published var totalCacheSize: Int64 = 0
    @Published var reclaimableSize: Int64 = 0

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let home = FileManager.default.homeDirectoryForCurrentUser.path

    private init() {}

    // MARK: - Scanning

    func scan() async {
        isScanning = true
        entries = []
        totalCacheSize = 0
        reclaimableSize = 0

        let cachesDir = "\(home)/Library/Caches"
        guard let cacheContents = try? fileManager.contentsOfDirectory(atPath: cachesDir) else {
            isScanning = false
            return
        }

        var allEntries: [AppCacheEntry] = []

        for item in cacheContents {
            guard !item.hasPrefix(".") else { continue }
            let fullPath = (cachesDir as NSString).appendingPathComponent(item)

            var isDir: ObjCBool = false
            guard fileManager.fileExists(atPath: fullPath, isDirectory: &isDir) else { continue }

            let size = await Task.detached { self.calculateSize(at: fullPath) }.value
            guard size > 100_000 else { continue } // Skip tiny caches (<100KB)

            let url = URL(fileURLWithPath: fullPath)
            let lastAccessed = (try? url.resourceValues(forKeys: [.contentAccessDateKey]))?.contentAccessDate ?? Date.distantPast

            // Try to resolve to an app name
            let (appName, icon) = resolveAppInfo(bundleId: item)

            let recommendation = classifyCache(bundleId: item, size: size, lastAccessed: lastAccessed)

            let entry = AppCacheEntry(
                id: fullPath,
                appName: appName,
                bundleId: item,
                cachePath: fullPath,
                cacheSize: size,
                lastAccessed: lastAccessed,
                icon: icon,
                recommendation: recommendation
            )
            allEntries.append(entry)
            totalCacheSize += size
            if recommendation != .keep {
                reclaimableSize += size
            }
        }

        entries = allEntries.sorted { $0.cacheSize > $1.cacheSize }
        isScanning = false

        logManager.log(
            "Cache analysis: \(entries.count) apps, \(ByteCountFormatter.string(fromByteCount: totalCacheSize, countStyle: .file)) total, \(ByteCountFormatter.string(fromByteCount: reclaimableSize, countStyle: .file)) reclaimable",
            level: .info, category: .scanning
        )
    }

    // MARK: - Classification

    private func classifyCache(bundleId: String, size: Int64, lastAccessed: Date) -> CacheRecommendation {
        let days = Calendar.current.dateComponents([.day], from: lastAccessed, to: Date()).day ?? 0

        // System/critical caches — always keep
        let criticalPrefixes = ["com.apple.", "Apple"]
        if criticalPrefixes.contains(where: { bundleId.hasPrefix($0) }) {
            // Even Apple caches can be stale
            if days > 180 && size > 500_000_000 { return .safe }
            return .keep
        }

        // App not used in 90+ days — stale
        if days > 90 { return .stale }

        // App not used in 30+ days — recommended cleanup
        if days > 30 { return .recommended }

        // Large cache (>1GB) for recently used app — safe to clean
        if size > 1_073_741_824 { return .safe }

        // Recently used, small cache — keep
        return .keep
    }

    private func resolveAppInfo(bundleId: String) -> (String, NSImage?) {
        // Try to find the app by bundle ID
        if let appURL = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleId) {
            let appName = ((appURL.lastPathComponent as NSString).deletingPathExtension)
            let icon = NSWorkspace.shared.icon(forFile: appURL.path)
            return (appName, icon)
        }

        // Fallback: derive name from bundle ID
        let parts = bundleId.split(separator: ".")
        let name = parts.last.map(String.init) ?? bundleId
        return (name, nil)
    }

    // MARK: - Cleaning

    func cleanEntries(_ entriesToClean: [AppCacheEntry]) async -> CleaningResult {
        var success = 0
        var failed = 0
        var bytesFreed: Int64 = 0

        for entry in entriesToClean {
            do {
                try fileManager.trashItem(at: URL(fileURLWithPath: entry.cachePath), resultingItemURL: nil)
                success += 1
                bytesFreed += entry.cacheSize
                logManager.log("Cleaned cache: \(entry.appName) (\(entry.formattedSize))", level: .success, category: .deletion)
            } catch {
                failed += 1
                logManager.log("Failed to clean: \(entry.cachePath) — \(error.localizedDescription)", level: .error, category: .deletion)
            }
        }

        await scan()
        return CleaningResult(success: success, failed: failed, bytesFreed: bytesFreed)
    }

    func cleanByRecommendation(_ recommendations: Set<CacheRecommendation>) async -> CleaningResult {
        let toClean = entries.filter { recommendations.contains($0.recommendation) }
        return await cleanEntries(toClean)
    }

    // MARK: - Helpers

    nonisolated private func calculateSize(at path: String) -> Int64 {
        let fm = FileManager.default
        let url = URL(fileURLWithPath: path)
        var totalSize: Int64 = 0

        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return 0 }

        if !isDir.boolValue {
            if let values = try? url.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileSizeKey]) {
                return Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
            return 0
        }

        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }
        return totalSize
    }
}
