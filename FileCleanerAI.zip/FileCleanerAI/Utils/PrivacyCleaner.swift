import Foundation
import AppKit

/// Cleans privacy-related data including recent documents, app usage data,
/// Spotlight suggestions, Siri data, and diagnostic information
@MainActor
class PrivacyCleaner: ObservableObject {
    static let shared = PrivacyCleaner()

    // MARK: - Published Properties

    @Published var categories: [PrivacyCategory] = []
    @Published var isScanning = false
    @Published var isCleaning = false
    @Published var cleaningProgress: Double = 0.0
    @Published var totalDataFound: Int64 = 0
    @Published var lastScanDate: Date?

    // MARK: - Private Properties

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let homeDirectory = FileManager.default.homeDirectoryForCurrentUser.path

    private init() {
        initializeCategories()
    }

    // MARK: - Category Definitions

    private func initializeCategories() {
        categories = [
            PrivacyCategory(
                id: "recent_docs",
                name: "Recent Documents",
                description: "Recently opened files tracked by Finder and apps",
                icon: "clock.arrow.circlepath",
                paths: [
                    "~/Library/Application Support/com.apple.sharedfilelist/com.apple.LSSharedFileList.RecentDocuments.sfl2",
                    "~/Library/Application Support/com.apple.sharedfilelist/com.apple.LSSharedFileList.RecentApplications.sfl2",
                    "~/Library/Application Support/com.apple.sharedfilelist/com.apple.LSSharedFileList.RecentServers.sfl2",
                    "~/Library/Application Support/com.apple.sharedfilelist/com.apple.LSSharedFileList.RecentHosts.sfl2"
                ],
                isSelected: true
            ),
            PrivacyCategory(
                id: "spotlight_suggestions",
                name: "Spotlight Suggestions",
                description: "Spotlight search history and suggestions cache",
                icon: "magnifyingglass",
                paths: [
                    "~/Library/Caches/com.apple.Spotlight",
                    "~/Library/Application Support/com.apple.spotlight.Shortcuts"
                ],
                isSelected: true
            ),
            PrivacyCategory(
                id: "siri_data",
                name: "Siri & Dictation",
                description: "Siri suggestions, voice data, and dictation cache",
                icon: "waveform",
                paths: [
                    "~/Library/Caches/com.apple.Siri",
                    "~/Library/Caches/com.apple.SiriTTSTraining",
                    "~/Library/Assistant/SiriAnalytics.db",
                    "~/Library/Caches/com.apple.parsecd"
                ],
                isSelected: false
            ),
            PrivacyCategory(
                id: "quicklook",
                name: "QuickLook Cache",
                description: "Thumbnail previews and QuickLook data",
                icon: "eye",
                paths: [
                    "~/Library/Caches/com.apple.QuickLook.thumbnailcache"
                ],
                isSelected: true
            ),
            PrivacyCategory(
                id: "diagnostic_data",
                name: "Diagnostic Reports",
                description: "Crash reports, diagnostic data, and analytics",
                icon: "stethoscope",
                paths: [
                    "~/Library/Logs/DiagnosticReports",
                    "~/Library/Logs/CrashReporter",
                    "~/Library/Application Support/CrashReporter"
                ],
                isSelected: true
            ),
            PrivacyCategory(
                id: "safari_data",
                name: "Safari Privacy Data",
                description: "Safari history, downloads history, and local storage",
                icon: "safari",
                paths: [
                    "~/Library/Safari/History.db",
                    "~/Library/Safari/History.db-lock",
                    "~/Library/Safari/History.db-shm",
                    "~/Library/Safari/History.db-wal",
                    "~/Library/Safari/Downloads.plist",
                    "~/Library/Safari/RecentlyClosedTabs.plist",
                    "~/Library/Safari/LastSession.plist",
                    "~/Library/Caches/com.apple.Safari/Cache.db"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This will clear Safari browsing history"
            ),
            PrivacyCategory(
                id: "chrome_data",
                name: "Chrome Privacy Data",
                description: "Chrome history, cookies, and cache",
                icon: "globe",
                paths: [
                    "~/Library/Application Support/Google/Chrome/Default/History",
                    "~/Library/Application Support/Google/Chrome/Default/History-journal",
                    "~/Library/Application Support/Google/Chrome/Default/Visited Links",
                    "~/Library/Application Support/Google/Chrome/Default/Top Sites",
                    "~/Library/Caches/Google/Chrome"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This will clear Chrome browsing history"
            ),
            PrivacyCategory(
                id: "firefox_data",
                name: "Firefox Privacy Data",
                description: "Firefox history, cache, and session data",
                icon: "flame",
                paths: [
                    "~/Library/Caches/Firefox",
                    "~/Library/Caches/Mozilla/updates/Applications/Firefox",
                    "~/Library/Application Support/Firefox/Crash Reports"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This will clear Firefox cache and crash reports"
            ),
            PrivacyCategory(
                id: "arc_data",
                name: "Arc Privacy Data",
                description: "Arc browser history, cache, and local storage",
                icon: "circle.hexagongrid",
                paths: [
                    "~/Library/Caches/company.thebrowser.Browser",
                    "~/Library/Application Support/Arc/User Data/Default/History",
                    "~/Library/Application Support/Arc/User Data/Default/History-journal",
                    "~/Library/Application Support/Arc/User Data/Default/Visited Links",
                    "~/Library/Application Support/Arc/User Data/Default/Top Sites"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This will clear Arc browsing history and cache"
            ),
            PrivacyCategory(
                id: "brave_data",
                name: "Brave Privacy Data",
                description: "Brave browser history, cache, and cookies",
                icon: "shield.lefthalf.filled",
                paths: [
                    "~/Library/Caches/BraveSoftware/Brave-Browser",
                    "~/Library/Application Support/BraveSoftware/Brave-Browser/Default/History",
                    "~/Library/Application Support/BraveSoftware/Brave-Browser/Default/History-journal",
                    "~/Library/Application Support/BraveSoftware/Brave-Browser/Default/Visited Links",
                    "~/Library/Application Support/BraveSoftware/Brave-Browser/Default/Top Sites"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This will clear Brave browsing history and cache"
            ),
            PrivacyCategory(
                id: "edge_data",
                name: "Edge Privacy Data",
                description: "Microsoft Edge history, cache, and cookies",
                icon: "globe.americas",
                paths: [
                    "~/Library/Caches/Microsoft Edge",
                    "~/Library/Application Support/Microsoft Edge/Default/History",
                    "~/Library/Application Support/Microsoft Edge/Default/History-journal",
                    "~/Library/Application Support/Microsoft Edge/Default/Visited Links",
                    "~/Library/Application Support/Microsoft Edge/Default/Top Sites"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This will clear Edge browsing history and cache"
            ),
            PrivacyCategory(
                id: "finder_recents",
                name: "Finder Recent Places",
                description: "Recent folders and Go menu history",
                icon: "folder.badge.gearshape",
                paths: [
                    "~/Library/Application Support/com.apple.sharedfilelist/com.apple.LSSharedFileList.FavoriteItems.sfl2",
                    "~/Library/Preferences/com.apple.finder.plist"
                ],
                isSelected: false,
                warningMessage: "May reset some Finder preferences"
            ),
            PrivacyCategory(
                id: "cookies",
                name: "Cookies",
                description: "System and Safari cookies",
                icon: "shield.slash",
                paths: [
                    "~/Library/Cookies/Cookies.binarycookies",
                    "~/Library/Cookies/HSTS.plist"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "You may be logged out of websites"
            ),
            PrivacyCategory(
                id: "app_usage",
                name: "App Usage Data",
                description: "Application usage statistics and screen time data",
                icon: "apps.iphone",
                paths: [
                    "~/Library/Application Support/com.apple.TCC",
                    "~/Library/Application Support/Knowledge"
                ],
                isSelected: false,
                requiresConfirmation: true,
                warningMessage: "This may affect app permissions"
            )
        ]
    }

    // MARK: - Public Methods

    /// Scan for privacy data and calculate sizes
    func scanForPrivacyData() async {
        isScanning = true
        totalDataFound = 0

        for i in categories.indices {
            var totalSize: Int64 = 0
            var existingPaths: [String] = []

            for pathPattern in categories[i].paths {
                let expandedPath = (pathPattern as NSString).expandingTildeInPath

                if fileManager.fileExists(atPath: expandedPath) {
                    existingPaths.append(expandedPath)
                    totalSize += getSize(at: expandedPath)
                }
            }

            categories[i].detectedSize = totalSize
            categories[i].detectedPaths = existingPaths
            totalDataFound += totalSize
        }

        lastScanDate = Date()
        isScanning = false

        logManager.log("Privacy scan complete. Found \(ByteCountFormatter.string(fromByteCount: totalDataFound, countStyle: .file)) of privacy data", level: .info, category: .scanning)
    }

    /// Clean selected privacy categories
    func cleanSelectedCategories() async -> CleaningResult {
        let selectedCategories = categories.filter { $0.isSelected && !$0.detectedPaths.isEmpty }

        guard !selectedCategories.isEmpty else {
            return CleaningResult(success: 0, failed: 0, bytesFreed: 0)
        }

        isCleaning = true
        cleaningProgress = 0

        var successCount = 0
        var failedCount = 0
        var bytesFreed: Int64 = 0

        let totalItems = selectedCategories.reduce(0) { $0 + $1.detectedPaths.count }
        var processedItems = 0

        for category in selectedCategories {
            logManager.log("Cleaning privacy category: \(category.name)", level: .info, category: .deletion)

            for path in category.detectedPaths {
                let sizeBefore = getSize(at: path)

                do {
                    // Special handling for plist files - clear contents instead of deleting
                    if path.hasSuffix(".plist") && !path.contains("History") {
                        // For plists, we clear the recent items but keep the file
                        if let dict = NSMutableDictionary(contentsOfFile: path) {
                            // Clear array values that typically store recent items
                            for key in dict.allKeys {
                                if let keyString = key as? String,
                                   (keyString.contains("Recent") || keyString.contains("History")) {
                                    dict.removeObject(forKey: key)
                                }
                            }
                            dict.write(toFile: path, atomically: true)
                            successCount += 1
                            bytesFreed += sizeBefore / 2 // Estimate
                        }
                    } else {
                        try fileManager.trashItem(at: URL(fileURLWithPath: path), resultingItemURL: nil)
                        successCount += 1
                        bytesFreed += sizeBefore
                    }

                    logManager.log("Cleaned: \(path)", level: .success, category: .deletion)
                } catch {
                    failedCount += 1
                    logManager.log("Failed to clean: \(path) - \(error.localizedDescription)", level: .error, category: .deletion)
                }

                processedItems += 1
                cleaningProgress = Double(processedItems) / Double(totalItems)
            }
        }

        // Clear system caches that require commands
        await clearSystemCaches()

        isCleaning = false
        cleaningProgress = 1.0

        // Rescan to update state
        await scanForPrivacyData()

        logManager.log("Privacy cleaning complete. Freed \(ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file))", level: .success, category: .deletion)

        return CleaningResult(success: successCount, failed: failedCount, bytesFreed: bytesFreed)
    }

    /// Clear specific category
    func cleanCategory(_ category: PrivacyCategory) async -> CleaningResult {
        var successCount = 0
        var failedCount = 0
        var bytesFreed: Int64 = 0

        for path in category.detectedPaths {
            let sizeBefore = getSize(at: path)

            do {
                try fileManager.trashItem(at: URL(fileURLWithPath: path), resultingItemURL: nil)
                successCount += 1
                bytesFreed += sizeBefore
            } catch {
                failedCount += 1
            }
        }

        // Rescan to update state
        await scanForPrivacyData()

        return CleaningResult(success: successCount, failed: failedCount, bytesFreed: bytesFreed)
    }

    // MARK: - System Cache Clearing

    private func clearSystemCaches() async {
        // Clear DNS cache
        let dnsTask = Process()
        dnsTask.launchPath = "/usr/bin/dscacheutil"
        dnsTask.arguments = ["-flushcache"]
        try? dnsTask.run()
        dnsTask.waitUntilExit()

        // Restart mDNSResponder to fully clear DNS
        let killallTask = Process()
        killallTask.launchPath = "/usr/bin/killall"
        killallTask.arguments = ["-HUP", "mDNSResponder"]
        try? killallTask.run()
        killallTask.waitUntilExit()

        logManager.log("Cleared system DNS cache", level: .info, category: .system)
    }

    // MARK: - Helper Methods

    private func getSize(at path: String) -> Int64 {
        let url = URL(fileURLWithPath: path)

        do {
            let resourceValues = try url.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey])

            if resourceValues.isDirectory == true {
                return directorySize(at: url)
            } else {
                return Int64(resourceValues.totalFileAllocatedSize ?? resourceValues.fileSize ?? 0)
            }
        } catch {
            return 0
        }
    }

    private func directorySize(at url: URL) -> Int64 {
        var totalSize: Int64 = 0

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: []
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }

        return totalSize
    }
}

// MARK: - Supporting Types

struct PrivacyCategory: Identifiable {
    let id: String
    let name: String
    let description: String
    let icon: String
    let paths: [String]
    var isSelected: Bool
    var requiresConfirmation: Bool
    var warningMessage: String?
    var detectedSize: Int64
    var detectedPaths: [String]

    init(
        id: String,
        name: String,
        description: String,
        icon: String,
        paths: [String],
        isSelected: Bool = false,
        requiresConfirmation: Bool = false,
        warningMessage: String? = nil
    ) {
        self.id = id
        self.name = name
        self.description = description
        self.icon = icon
        self.paths = paths
        self.isSelected = isSelected
        self.requiresConfirmation = requiresConfirmation
        self.warningMessage = warningMessage
        self.detectedSize = 0
        self.detectedPaths = []
    }

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: detectedSize, countStyle: .file)
    }

    var hasData: Bool {
        detectedSize > 0
    }
}

struct CleaningResult {
    let success: Int
    let failed: Int
    let bytesFreed: Int64

    var formattedBytesFreed: String {
        ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file)
    }
}
