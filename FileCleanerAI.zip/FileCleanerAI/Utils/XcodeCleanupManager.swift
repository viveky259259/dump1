import Foundation

// MARK: - Data Models

struct XcodeCleanupCategory: Identifiable {
    let id: String
    let name: String
    let description: String
    let icon: String
    let path: String
    var isSelected: Bool
    var size: Int64 = 0
    var itemCount: Int = 0
    var items: [XcodeCleanupItem] = []

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }

    var hasData: Bool { size > 0 }
}

struct XcodeCleanupItem: Identifiable {
    let id: String
    let path: String
    let name: String
    let size: Int64
    let lastModified: Date

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }

    var staleness: String {
        let days = Calendar.current.dateComponents([.day], from: lastModified, to: Date()).day ?? 0
        if days == 0 { return "Today" }
        if days < 30 { return "\(days) days" }
        if days < 365 { return "\(days / 30) months" }
        return "\(days / 365)y \(days % 365 / 30)m"
    }
}

// MARK: - Xcode Cleanup Manager

@MainActor
class XcodeCleanupManager: ObservableObject {
    static let shared = XcodeCleanupManager()

    @Published var categories: [XcodeCleanupCategory] = []
    @Published var isScanning = false
    @Published var isCleaning = false
    @Published var scanProgress: Double = 0.0
    @Published var totalReclaimable: Int64 = 0

    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let home = FileManager.default.homeDirectoryForCurrentUser.path

    private init() {
        initializeCategories()
    }

    private func initializeCategories() {
        categories = [
            XcodeCleanupCategory(
                id: "derived_data",
                name: "DerivedData",
                description: "Build products and intermediate files for each project",
                icon: "hammer.fill",
                path: "\(home)/Library/Developer/Xcode/DerivedData",
                isSelected: true
            ),
            XcodeCleanupCategory(
                id: "simulators_unavailable",
                name: "Unavailable Simulators",
                description: "Simulator devices for deleted or outdated iOS runtimes",
                icon: "iphone.slash",
                path: "\(home)/Library/Developer/CoreSimulator/Devices",
                isSelected: true
            ),
            XcodeCleanupCategory(
                id: "simulator_caches",
                name: "Simulator Caches",
                description: "Cached data from iOS/watchOS/tvOS simulators",
                icon: "iphone.badge.play",
                path: "\(home)/Library/Developer/CoreSimulator/Caches",
                isSelected: true
            ),
            XcodeCleanupCategory(
                id: "archives",
                name: "Xcode Archives",
                description: "Previously archived builds (.xcarchive)",
                icon: "archivebox.fill",
                path: "\(home)/Library/Developer/Xcode/Archives",
                isSelected: false
            ),
            XcodeCleanupCategory(
                id: "device_support",
                name: "iOS Device Support",
                description: "Debug symbols for physical iOS devices",
                icon: "iphone.gen3",
                path: "\(home)/Library/Developer/Xcode/iOS DeviceSupport",
                isSelected: false
            ),
            XcodeCleanupCategory(
                id: "watchos_support",
                name: "watchOS Device Support",
                description: "Debug symbols for Apple Watch devices",
                icon: "applewatch",
                path: "\(home)/Library/Developer/Xcode/watchOS DeviceSupport",
                isSelected: false
            ),
            XcodeCleanupCategory(
                id: "xcode_cache",
                name: "Xcode Caches",
                description: "Xcode internal caches and documentation index",
                icon: "internaldrive",
                path: "\(home)/Library/Caches/com.apple.dt.Xcode",
                isSelected: true
            ),
            XcodeCleanupCategory(
                id: "previews",
                name: "SwiftUI Previews",
                description: "Cached SwiftUI preview builds",
                icon: "eye.fill",
                path: "\(home)/Library/Developer/Xcode/UserData/Previews",
                isSelected: true
            ),
        ]
    }

    // MARK: - Scanning

    func scan() async {
        isScanning = true
        scanProgress = 0.0
        totalReclaimable = 0

        let total = Double(categories.count)

        for i in categories.indices {
            let path = categories[i].path

            let categoryId = categories[i].id

            if categoryId == "simulators_unavailable" {
                // Special handling: use simctl to find unavailable devices
                await scanUnavailableSimulators(categoryIndex: i)
            } else {
                // Standard: enumerate items in directory
                let (items, size) = await Task.detached {
                    self.scanDirectory(at: path, categoryId: categoryId)
                }.value

                categories[i].items = items
                categories[i].size = size
                categories[i].itemCount = items.count
            }

            totalReclaimable += categories[i].size
            scanProgress = Double(i + 1) / total
        }

        isScanning = false
        scanProgress = 1.0

        logManager.log(
            "Xcode cleanup scan: \(ByteCountFormatter.string(fromByteCount: totalReclaimable, countStyle: .file)) reclaimable",
            level: .info, category: .scanning
        )
    }

    private nonisolated func scanDirectory(at path: String, categoryId: String) -> ([XcodeCleanupItem], Int64) {
        let fm = FileManager.default
        guard let contents = try? fm.contentsOfDirectory(atPath: path) else { return ([], 0) }

        var items: [XcodeCleanupItem] = []
        var totalSize: Int64 = 0

        for name in contents {
            guard !name.hasPrefix(".") else { continue }
            let fullPath = (path as NSString).appendingPathComponent(name)
            let url = URL(fileURLWithPath: fullPath)

            let lastModified = (try? url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? Date.distantPast
            let size = calculateSize(at: fullPath)

            items.append(XcodeCleanupItem(
                id: fullPath,
                path: fullPath,
                name: name,
                size: size,
                lastModified: lastModified
            ))
            totalSize += size
        }

        items.sort { $0.size > $1.size }
        return (items, totalSize)
    }

    private func scanUnavailableSimulators(categoryIndex i: Int) async {
        let categoryPath = categories[i].path

        // Run xcrun simctl list devices unavailable -j
        let result = await runCommand("/usr/bin/xcrun", arguments: ["simctl", "list", "devices", "unavailable", "-j"])

        guard let data = result?.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let devices = json["devices"] as? [String: [[String: Any]]] else {
            // Fallback: just scan the directory
            let (items, size) = await Task.detached {
                self.scanDirectory(at: categoryPath, categoryId: "simulators_unavailable")
            }.value
            categories[i].items = items
            categories[i].size = size
            categories[i].itemCount = items.count
            return
        }

        var unavailableUDIDs: Set<String> = []
        for (_, deviceList) in devices {
            for device in deviceList {
                if let udid = device["udid"] as? String,
                   let isAvailable = device["isAvailable"] as? Bool, !isAvailable {
                    unavailableUDIDs.insert(udid)
                }
            }
        }

        // Map UDIDs to directories
        let devicesDir = categories[i].path
        var items: [XcodeCleanupItem] = []
        var totalSize: Int64 = 0

        if let contents = try? fileManager.contentsOfDirectory(atPath: devicesDir) {
            for name in contents {
                let fullPath = (devicesDir as NSString).appendingPathComponent(name)
                // Check if this directory's name (UDID) is in the unavailable set
                if unavailableUDIDs.contains(name) {
                    let size = await Task.detached { self.calculateSize(at: fullPath) }.value
                    let url = URL(fileURLWithPath: fullPath)
                    let lastMod = (try? url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? Date.distantPast

                    items.append(XcodeCleanupItem(
                        id: fullPath, path: fullPath, name: name, size: size, lastModified: lastMod
                    ))
                    totalSize += size
                }
            }
        }

        items.sort { $0.size > $1.size }
        categories[i].items = items
        categories[i].size = totalSize
        categories[i].itemCount = items.count
    }

    // MARK: - Cleaning

    func cleanSelected() async -> CleaningResult {
        isCleaning = true
        var success = 0
        var failed = 0
        var bytesFreed: Int64 = 0

        for category in categories where category.isSelected && category.hasData {
            if category.id == "simulators_unavailable" {
                // Use simctl delete unavailable
                let result = await runCommand("/usr/bin/xcrun", arguments: ["simctl", "delete", "unavailable"])
                if result != nil {
                    success += category.itemCount
                    bytesFreed += category.size
                    logManager.log("Deleted unavailable simulators", level: .success, category: .deletion)
                } else {
                    failed += category.itemCount
                }
            } else {
                for item in category.items {
                    do {
                        try fileManager.trashItem(at: URL(fileURLWithPath: item.path), resultingItemURL: nil)
                        success += 1
                        bytesFreed += item.size
                    } catch {
                        failed += 1
                        logManager.log("Failed: \(item.path) — \(error.localizedDescription)", level: .error, category: .deletion)
                    }
                }
            }
        }

        isCleaning = false

        // Rescan
        await scan()

        logManager.log(
            "Xcode cleanup done: freed \(ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file))",
            level: .success, category: .deletion
        )

        return CleaningResult(success: success, failed: failed, bytesFreed: bytesFreed)
    }

    func cleanCategory(_ category: XcodeCleanupCategory) async -> CleaningResult {
        var success = 0
        var failed = 0
        var bytesFreed: Int64 = 0

        if category.id == "simulators_unavailable" {
            let result = await runCommand("/usr/bin/xcrun", arguments: ["simctl", "delete", "unavailable"])
            if result != nil {
                success = category.itemCount
                bytesFreed = category.size
            } else {
                failed = category.itemCount
            }
        } else {
            for item in category.items {
                do {
                    try fileManager.trashItem(at: URL(fileURLWithPath: item.path), resultingItemURL: nil)
                    success += 1
                    bytesFreed += item.size
                } catch {
                    failed += 1
                }
            }
        }

        await scan()
        return CleaningResult(success: success, failed: failed, bytesFreed: bytesFreed)
    }

    // MARK: - Helpers

    nonisolated private func calculateSize(at path: String) -> Int64 {
        let fm = FileManager.default
        let url = URL(fileURLWithPath: path)
        var totalSize: Int64 = 0

        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               values.isDirectory == false {
                totalSize += Int64(values.totalFileAllocatedSize ?? values.fileSize ?? 0)
            }
        }
        return totalSize
    }

    private func runCommand(_ executable: String, arguments: [String]) async -> String? {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments

        let outputPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = FileHandle.nullDevice

        do {
            try process.run()

            return await withCheckedContinuation { continuation in
                process.terminationHandler = { p in
                    if p.terminationStatus == 0 {
                        let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
                        let output = String(data: data, encoding: .utf8)
                        continuation.resume(returning: output)
                    } else {
                        continuation.resume(returning: nil)
                    }
                }
            }
        } catch {
            return nil
        }
    }
}
