import Foundation

// MARK: - Observability System for AI Verification
// This system provides structured logging, metrics, and tracing that can be consumed by
// both humans (via console/UI) and AI agents (via JSON log files) for verification.

// MARK: - Event Types

/// Represents different types of observable events
enum ObservabilityEventType: String, Codable {
    // Lifecycle events
    case appLaunched = "app_launched"
    case appTerminated = "app_terminated"
    case viewAppeared = "view_appeared"
    case viewDisappeared = "view_disappeared"

    // Scanning events
    case scanStarted = "scan_started"
    case scanProgress = "scan_progress"
    case scanCompleted = "scan_completed"
    case filesDiscovered = "files_discovered"
    case patternMatched = "pattern_matched"

    // AI events
    case aiAnalysisStarted = "ai_analysis_started"
    case aiAnalysisCompleted = "ai_analysis_completed"
    case aiFallbackUsed = "ai_fallback_used"

    // User actions
    case userAction = "user_action"
    case buttonTapped = "button_tapped"
    case tabSelected = "tab_selected"
    case selectionChanged = "selection_changed"

    // Deletion events
    case deletionStarted = "deletion_started"
    case deletionProgress = "deletion_progress"
    case deletionCompleted = "deletion_completed"
    case fileMovedToTrash = "file_moved_to_trash"
    case deletionFailed = "deletion_failed"

    // System events
    case permissionRequested = "permission_requested"
    case permissionGranted = "permission_granted"
    case permissionDenied = "permission_denied"
    case error = "error"
    case warning = "warning"

    // Health events
    case healthScoreUpdated = "health_score_updated"
    case memoryWarning = "memory_warning"

    // State events
    case stateChanged = "state_changed"
    case dataLoaded = "data_loaded"
    case dataSaved = "data_saved"
}

/// Status of an event
enum ObservabilityStatus: String, Codable {
    case success
    case failure
    case inProgress = "in_progress"
    case warning
    case info
}

// MARK: - Observable Event

/// A structured event that can be consumed by AI or humans
struct ObservableEvent: Codable {
    let timestamp: String
    let timestampUnix: Double
    let event: String
    let component: String
    let status: String
    let traceId: String?
    let spanId: String?
    let parentSpanId: String?
    let details: [String: String]?
    let metrics: [String: Double]?

    init(
        event: ObservabilityEventType,
        component: String,
        status: ObservabilityStatus,
        traceId: String? = nil,
        spanId: String? = nil,
        parentSpanId: String? = nil,
        details: [String: String]? = nil,
        metrics: [String: Double]? = nil
    ) {
        let now = Date()
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        self.timestamp = formatter.string(from: now)
        self.timestampUnix = now.timeIntervalSince1970
        self.event = event.rawValue
        self.component = component
        self.status = status.rawValue
        self.traceId = traceId
        self.spanId = spanId
        self.parentSpanId = parentSpanId
        self.details = details
        self.metrics = metrics
    }
}

// MARK: - Trace Context

/// Manages trace context for distributed tracing style observability
class TraceContext {
    let traceId: String
    private(set) var currentSpanId: String
    private var spanStack: [(spanId: String, name: String, startTime: Date)] = []

    init() {
        self.traceId = UUID().uuidString.lowercased().replacingOccurrences(of: "-", with: "").prefix(16).description
        self.currentSpanId = Self.generateSpanId()
    }

    private static func generateSpanId() -> String {
        return UUID().uuidString.lowercased().replacingOccurrences(of: "-", with: "").prefix(8).description
    }

    /// Start a new span (operation)
    func startSpan(_ name: String) -> String {
        let newSpanId = Self.generateSpanId()
        spanStack.append((spanId: newSpanId, name: name, startTime: Date()))
        let parentSpanId = currentSpanId
        currentSpanId = newSpanId
        return parentSpanId
    }

    /// End the current span and return duration
    func endSpan() -> (name: String, duration: TimeInterval)? {
        guard let span = spanStack.popLast() else { return nil }
        let duration = Date().timeIntervalSince(span.startTime)
        currentSpanId = spanStack.last?.spanId ?? Self.generateSpanId()
        return (span.name, duration)
    }
}

// MARK: - Observability Manager

/// Central manager for all observability concerns
@MainActor
class ObservabilityManager: ObservableObject {
    static let shared = ObservabilityManager()

    // MARK: - Configuration

    /// Path to the JSON Lines log file for AI consumption
    private let logFilePath: String

    /// Whether to write to file (for AI verification)
    @Published var fileLoggingEnabled: Bool = true

    /// Whether to print to console (for human debugging)
    @Published var consoleLoggingEnabled: Bool = true

    /// Current trace context
    private var currentTrace: TraceContext?

    /// Event buffer for batched writes
    private var eventBuffer: [ObservableEvent] = []
    private let bufferFlushInterval: TimeInterval = 1.0
    private var flushTask: Task<Void, Never>?

    // MARK: - Metrics Storage

    /// Current metrics snapshot
    @Published var currentMetrics: [String: Double] = [:]

    /// Metrics history for trending
    private var metricsHistory: [[String: Double]] = []
    private let maxHistorySize = 100

    // MARK: - Initialization

    private init() {
        // Use a known location for AI to read
        let tempDir = FileManager.default.temporaryDirectory
        self.logFilePath = tempDir.appendingPathComponent("filecleaner_observability.jsonl").path

        // Clear previous log file on start
        try? FileManager.default.removeItem(atPath: logFilePath)

        // Start periodic flush
        startPeriodicFlush()

        // Log initialization
        emit(
            event: .appLaunched,
            component: "ObservabilityManager",
            status: .success,
            details: [
                "log_file": logFilePath,
                "version": "1.0.0"
            ]
        )
    }

    // MARK: - Event Emission

    /// Emit an observable event
    func emit(
        event: ObservabilityEventType,
        component: String,
        status: ObservabilityStatus,
        details: [String: String]? = nil,
        metrics: [String: Double]? = nil
    ) {
        let observableEvent = ObservableEvent(
            event: event,
            component: component,
            status: status,
            traceId: currentTrace?.traceId,
            spanId: currentTrace?.currentSpanId,
            details: details,
            metrics: metrics
        )

        // Buffer the event
        eventBuffer.append(observableEvent)

        // Update metrics if provided
        if let metrics = metrics {
            for (key, value) in metrics {
                currentMetrics[key] = value
            }
        }

        // Console output for humans
        if consoleLoggingEnabled {
            printToConsole(observableEvent)
        }

        // Immediate flush for errors
        if status == .failure {
            flushBuffer()
        }
    }

    /// Emit with trace context
    func emitWithTrace(
        event: ObservabilityEventType,
        component: String,
        status: ObservabilityStatus,
        details: [String: String]? = nil,
        metrics: [String: Double]? = nil
    ) {
        guard let trace = currentTrace else {
            emit(event: event, component: component, status: status, details: details, metrics: metrics)
            return
        }

        let observableEvent = ObservableEvent(
            event: event,
            component: component,
            status: status,
            traceId: trace.traceId,
            spanId: trace.currentSpanId,
            details: details,
            metrics: metrics
        )

        eventBuffer.append(observableEvent)

        if let metrics = metrics {
            for (key, value) in metrics {
                currentMetrics[key] = value
            }
        }

        if consoleLoggingEnabled {
            printToConsole(observableEvent)
        }
    }

    // MARK: - Tracing

    /// Start a new trace (for a complete operation like "scan")
    func startTrace() -> String {
        currentTrace = TraceContext()
        return currentTrace!.traceId
    }

    /// Start a span within the current trace
    func startSpan(_ name: String) {
        _ = currentTrace?.startSpan(name)
        emitWithTrace(
            event: .stateChanged,
            component: name,
            status: .inProgress,
            details: ["span_started": name]
        )
    }

    /// End the current span
    func endSpan() {
        if let result = currentTrace?.endSpan() {
            emitWithTrace(
                event: .stateChanged,
                component: result.name,
                status: .success,
                details: ["span_ended": result.name],
                metrics: ["duration_ms": result.duration * 1000]
            )
        }
    }

    /// End the current trace
    func endTrace() {
        currentTrace = nil
    }

    // MARK: - Metrics

    /// Record a metric value
    func recordMetric(_ name: String, value: Double) {
        currentMetrics[name] = value

        // Add to history
        var snapshot = currentMetrics
        snapshot["_timestamp"] = Date().timeIntervalSince1970
        metricsHistory.append(snapshot)

        // Trim history
        if metricsHistory.count > maxHistorySize {
            metricsHistory.removeFirst()
        }
    }

    /// Get metrics summary
    func getMetricsSummary() -> [String: [String: Double]] {
        var summary: [String: [String: Double]] = [:]

        for key in currentMetrics.keys where !key.starts(with: "_") {
            let values = metricsHistory.compactMap { $0[key] }
            guard !values.isEmpty else { continue }

            summary[key] = [
                "current": currentMetrics[key] ?? 0,
                "min": values.min() ?? 0,
                "max": values.max() ?? 0,
                "avg": values.reduce(0, +) / Double(values.count)
            ]
        }

        return summary
    }

    // MARK: - File Operations

    private func startPeriodicFlush() {
        flushTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: UInt64(1_000_000_000)) // 1 second
                await self?.flushBuffer()
            }
        }
    }

    /// Flush buffered events to file
    func flushBuffer() {
        guard fileLoggingEnabled, !eventBuffer.isEmpty else { return }

        let encoder = JSONEncoder()
        encoder.outputFormatting = [] // Compact JSON for JSONL

        var lines: [String] = []
        for event in eventBuffer {
            if let data = try? encoder.encode(event),
               let line = String(data: data, encoding: .utf8) {
                lines.append(line)
            }
        }

        eventBuffer.removeAll(keepingCapacity: true)

        guard !lines.isEmpty else { return }

        let content = lines.joined(separator: "\n") + "\n"

        // Append to file
        if FileManager.default.fileExists(atPath: logFilePath) {
            if let handle = FileHandle(forWritingAtPath: logFilePath) {
                handle.seekToEndOfFile()
                if let data = content.data(using: .utf8) {
                    handle.write(data)
                }
                handle.closeFile()
            }
        } else {
            try? content.write(toFile: logFilePath, atomically: true, encoding: .utf8)
        }
    }

    /// Get the log file path for AI consumption
    func getLogFilePath() -> String {
        flushBuffer() // Ensure all events are written
        return logFilePath
    }

    /// Export current state as JSON for AI verification
    func exportStateForVerification() -> String {
        flushBuffer()

        struct VerificationState: Codable {
            let logFile: String
            let currentMetrics: [String: Double]
            let metricsSummary: [String: [String: Double]]
            let activeTrace: String?
        }

        let state = VerificationState(
            logFile: logFilePath,
            currentMetrics: currentMetrics,
            metricsSummary: getMetricsSummary(),
            activeTrace: currentTrace?.traceId
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]

        if let data = try? encoder.encode(state),
           let json = String(data: data, encoding: .utf8) {
            return json
        }

        return "{}"
    }

    // MARK: - Console Output

    private func printToConsole(_ event: ObservableEvent) {
        let statusEmoji: String
        switch event.status {
        case "success": statusEmoji = "✅"
        case "failure": statusEmoji = "❌"
        case "in_progress": statusEmoji = "🔄"
        case "warning": statusEmoji = "⚠️"
        default: statusEmoji = "ℹ️"
        }

        var output = "[\(event.timestamp)] \(statusEmoji) [\(event.component)] \(event.event)"

        if let details = event.details, !details.isEmpty {
            let detailStr = details.map { "\($0.key)=\($0.value)" }.joined(separator: ", ")
            output += " | \(detailStr)"
        }

        if let metrics = event.metrics, !metrics.isEmpty {
            let metricStr = metrics.map { "\($0.key)=\(String(format: "%.2f", $0.value))" }.joined(separator: ", ")
            output += " | \(metricStr)"
        }

        if let traceId = event.traceId {
            output += " [trace:\(traceId.prefix(8))]"
        }

        print(output)
    }
}

// MARK: - Convenience Extensions

extension ObservabilityManager {

    // MARK: - Lifecycle Events

    func appLaunched() {
        emit(event: .appLaunched, component: "App", status: .success)
    }

    func appTerminated() {
        emit(event: .appTerminated, component: "App", status: .success)
        flushBuffer()
    }

    func viewAppeared(_ viewName: String) {
        emit(
            event: .viewAppeared,
            component: viewName,
            status: .success,
            details: ["view": viewName]
        )
    }

    func viewDisappeared(_ viewName: String) {
        emit(
            event: .viewDisappeared,
            component: viewName,
            status: .success,
            details: ["view": viewName]
        )
    }

    // MARK: - Scan Events

    func scanStarted(directories: [String]) {
        _ = startTrace()
        startSpan("scan")
        emit(
            event: .scanStarted,
            component: "FileScanner",
            status: .inProgress,
            details: [
                "directory_count": "\(directories.count)",
                "directories": directories.joined(separator: ", ")
            ]
        )
    }

    func scanProgress(scanned: Int, total: Int, currentDirectory: String) {
        emit(
            event: .scanProgress,
            component: "FileScanner",
            status: .inProgress,
            details: ["current_directory": currentDirectory],
            metrics: [
                "scanned_directories": Double(scanned),
                "total_directories": Double(total),
                "progress_percent": Double(scanned) / Double(max(total, 1)) * 100
            ]
        )
    }

    func scanCompleted(filesFound: Int, totalSize: Int64, duration: TimeInterval) {
        endSpan()
        emit(
            event: .scanCompleted,
            component: "FileScanner",
            status: .success,
            details: [
                "files_found": "\(filesFound)",
                "total_size_bytes": "\(totalSize)",
                "total_size_formatted": ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file)
            ],
            metrics: [
                "files_found": Double(filesFound),
                "total_size_bytes": Double(totalSize),
                "scan_duration_ms": duration * 1000,
                "files_per_second": Double(filesFound) / max(duration, 0.001)
            ]
        )
        endTrace()
    }

    func filesDiscovered(count: Int, inDirectory: String) {
        emit(
            event: .filesDiscovered,
            component: "FileScanner",
            status: .success,
            details: ["directory": inDirectory],
            metrics: ["files_in_batch": Double(count)]
        )
    }

    // MARK: - AI Events

    func aiAnalysisStarted(fileCount: Int) {
        startSpan("ai_analysis")
        emit(
            event: .aiAnalysisStarted,
            component: "AIService",
            status: .inProgress,
            details: ["file_count": "\(fileCount)"]
        )
    }

    func aiAnalysisCompleted(patternsFound: Int, duration: TimeInterval, usedFallback: Bool) {
        endSpan()
        emit(
            event: .aiAnalysisCompleted,
            component: "AIService",
            status: .success,
            details: [
                "patterns_found": "\(patternsFound)",
                "used_fallback": "\(usedFallback)"
            ],
            metrics: [
                "patterns_found": Double(patternsFound),
                "analysis_duration_ms": duration * 1000
            ]
        )
    }

    // MARK: - User Actions

    func userAction(_ action: String, details: [String: String]? = nil) {
        emit(
            event: .userAction,
            component: "UI",
            status: .success,
            details: (details ?? [:]).merging(["action": action]) { _, new in new }
        )
    }

    func buttonTapped(_ buttonName: String, in viewName: String) {
        emit(
            event: .buttonTapped,
            component: viewName,
            status: .success,
            details: ["button": buttonName]
        )
    }

    func tabSelected(_ tabName: String) {
        emit(
            event: .tabSelected,
            component: "ContentView",
            status: .success,
            details: ["tab": tabName]
        )
    }

    // MARK: - Deletion Events

    func deletionStarted(patternCount: Int, fileCount: Int) {
        startSpan("deletion")
        emit(
            event: .deletionStarted,
            component: "FileScanner",
            status: .inProgress,
            details: [
                "pattern_count": "\(patternCount)",
                "file_count": "\(fileCount)"
            ]
        )
    }

    func deletionCompleted(successCount: Int, failureCount: Int, bytesFreed: Int64, duration: TimeInterval) {
        endSpan()
        emit(
            event: .deletionCompleted,
            component: "FileScanner",
            status: failureCount == 0 ? .success : .warning,
            details: [
                "success_count": "\(successCount)",
                "failure_count": "\(failureCount)",
                "bytes_freed": "\(bytesFreed)",
                "bytes_freed_formatted": ByteCountFormatter.string(fromByteCount: bytesFreed, countStyle: .file)
            ],
            metrics: [
                "files_deleted": Double(successCount),
                "files_failed": Double(failureCount),
                "bytes_freed": Double(bytesFreed),
                "deletion_duration_ms": duration * 1000
            ]
        )
    }

    // MARK: - Error Events

    func error(_ message: String, component: String, details: [String: String]? = nil) {
        emit(
            event: .error,
            component: component,
            status: .failure,
            details: (details ?? [:]).merging(["message": message]) { _, new in new }
        )
    }

    func warning(_ message: String, component: String, details: [String: String]? = nil) {
        emit(
            event: .warning,
            component: component,
            status: .warning,
            details: (details ?? [:]).merging(["message": message]) { _, new in new }
        )
    }

    // MARK: - Health Events

    func healthScoreUpdated(score: Int, components: [String: Double]) {
        var details: [String: String] = ["score": "\(score)"]
        for (key, value) in components {
            details[key] = String(format: "%.1f", value)
        }

        emit(
            event: .healthScoreUpdated,
            component: "HealthScoreManager",
            status: score >= 70 ? .success : (score >= 40 ? .warning : .failure),
            details: details,
            metrics: components.merging(["health_score": Double(score)]) { _, new in new }
        )
    }
}

// MARK: - AI Verification Helper

/// Helper struct for AI to query observability state
struct AIVerificationHelper {

    /// Check if app launched successfully by reading logs
    static func checkAppLaunched(logFilePath: String) -> Bool {
        guard let content = try? String(contentsOfFile: logFilePath, encoding: .utf8) else {
            return false
        }
        return content.contains("\"event\":\"app_launched\"") && content.contains("\"status\":\"success\"")
    }

    /// Get all events of a specific type
    static func getEvents(ofType type: String, from logFilePath: String) -> [[String: Any]] {
        guard let content = try? String(contentsOfFile: logFilePath, encoding: .utf8) else {
            return []
        }

        var events: [[String: Any]] = []
        for line in content.components(separatedBy: "\n") where !line.isEmpty {
            if let data = line.data(using: .utf8),
               let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               json["event"] as? String == type {
                events.append(json)
            }
        }
        return events
    }

    /// Check for any errors in the log
    static func hasErrors(in logFilePath: String) -> Bool {
        guard let content = try? String(contentsOfFile: logFilePath, encoding: .utf8) else {
            return true // Can't read = error
        }
        return content.contains("\"status\":\"failure\"")
    }

    /// Get error messages
    static func getErrors(from logFilePath: String) -> [String] {
        let events = getEvents(ofType: "error", from: logFilePath)
        return events.compactMap { event in
            if let details = event["details"] as? [String: String] {
                return details["message"]
            }
            return nil
        }
    }

    /// Verify a complete scan flow
    static func verifyScanFlow(in logFilePath: String) -> (success: Bool, message: String) {
        guard let content = try? String(contentsOfFile: logFilePath, encoding: .utf8) else {
            return (false, "Cannot read log file")
        }

        // Check for scan_started
        guard content.contains("\"event\":\"scan_started\"") else {
            return (false, "Scan never started")
        }

        // Check for scan_completed
        guard content.contains("\"event\":\"scan_completed\"") else {
            return (false, "Scan did not complete")
        }

        // Check for errors during scan
        if content.contains("\"status\":\"failure\"") {
            return (false, "Errors occurred during scan")
        }

        return (true, "Scan completed successfully")
    }
}
