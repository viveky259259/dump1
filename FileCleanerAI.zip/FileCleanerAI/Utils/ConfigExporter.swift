import Foundation
import AppKit

// MARK: - Exportable Configuration

struct ExportableConfig: Codable {
    var version: String = "1.0"
    var exportDate: Date = Date()

    // Whitelist rules
    var whitelistRules: [WhitelistRuleExport]

    // Schedule config
    var scheduleConfig: CleaningScheduleConfig

    // MenuBar setting
    var menuBarEnabled: Bool

    // Scan directories (from UserDefaults if customized)
    var customScanPaths: [String]
}

struct WhitelistRuleExport: Codable {
    let type: String
    let pattern: String
    let reason: String
    let isEnabled: Bool
}

// MARK: - Config Exporter

@MainActor
class ConfigExporter: ObservableObject {
    static let shared = ConfigExporter()

    @Published var lastExportPath: String?
    @Published var lastImportDate: Date?

    private let logManager = LogManager.shared

    private init() {}

    // MARK: - Export

    func exportConfig() -> ExportableConfig {
        // Gather whitelist rules
        let whitelistManager = WhitelistManager.shared
        let rules = whitelistManager.whitelistRules.map { rule in
            WhitelistRuleExport(
                type: rule.type.rawValue,
                pattern: rule.pattern,
                reason: rule.reason,
                isEnabled: rule.isEnabled
            )
        }

        // Schedule config
        let scheduleConfig = ScheduledCleaningManager.shared.config

        // MenuBar
        let menuBarEnabled = MenuBarManager.shared.isEnabled

        return ExportableConfig(
            whitelistRules: rules,
            scheduleConfig: scheduleConfig,
            menuBarEnabled: menuBarEnabled,
            customScanPaths: []
        )
    }

    func exportToFile() async -> URL? {
        let config = exportConfig()

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601

        guard let data = try? encoder.encode(config) else {
            logManager.log("Failed to encode config for export", level: .error, category: .system)
            return nil
        }

        let panel = NSSavePanel()
        panel.title = "Export Configuration"
        panel.nameFieldStringValue = "FileCleanerAI_config.json"
        panel.allowedContentTypes = [.json]

        let response = await panel.begin()
        guard response == .OK, let url = panel.url else { return nil }

        do {
            try data.write(to: url)
            lastExportPath = url.path
            logManager.log("Configuration exported to: \(url.path)", level: .success, category: .system)
            return url
        } catch {
            logManager.log("Export failed: \(error.localizedDescription)", level: .error, category: .system)
            return nil
        }
    }

    // MARK: - Import

    func importFromFile() async -> Bool {
        let panel = NSOpenPanel()
        panel.title = "Import Configuration"
        panel.allowedContentTypes = [.json]
        panel.allowsMultipleSelection = false

        let response = await panel.begin()
        guard response == .OK, let url = panel.url else { return false }

        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601

            let config = try decoder.decode(ExportableConfig.self, from: data)
            applyConfig(config)
            lastImportDate = Date()

            logManager.log("Configuration imported from: \(url.path)", level: .success, category: .system)
            return true
        } catch {
            logManager.log("Import failed: \(error.localizedDescription)", level: .error, category: .system)
            return false
        }
    }

    private func applyConfig(_ config: ExportableConfig) {
        // Apply whitelist rules
        let whitelistManager = WhitelistManager.shared
        for rule in config.whitelistRules {
            let ruleType = WhitelistRule.RuleType(rawValue: rule.type) ?? .pattern
            whitelistManager.addRule(type: ruleType, pattern: rule.pattern, reason: rule.reason)
        }

        // Apply schedule config
        ScheduledCleaningManager.shared.config = config.scheduleConfig

        // Apply MenuBar setting
        MenuBarManager.shared.isEnabled = config.menuBarEnabled
    }
}
