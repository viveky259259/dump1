import Foundation
import AppKit

// MARK: - Storage Item
struct StorageItem: Identifiable, Hashable, Codable {
    let id: UUID
    let path: String
    let name: String
    var size: Int64
    let isDirectory: Bool
    let iconName: String
    var isSelected: Bool
    var children: [StorageItem]?
    var hasLoadedChildren: Bool
    
    init(path: String, name: String, size: Int64, isDirectory: Bool, iconName: String = "", isSelected: Bool = false, children: [StorageItem]? = nil, hasLoadedChildren: Bool = false) {
        self.id = UUID()
        self.path = path
        self.name = name
        self.size = size
        self.isDirectory = isDirectory
        self.iconName = iconName.isEmpty ? (isDirectory ? "folder.fill" : Self.iconForFile(name)) : iconName
        self.isSelected = isSelected
        self.children = children
        self.hasLoadedChildren = hasLoadedChildren
    }
    
    // Hashable conformance - use path as the hash since it's unique
    func hash(into hasher: inout Hasher) {
        hasher.combine(path)
    }
    
    static func == (lhs: StorageItem, rhs: StorageItem) -> Bool {
        lhs.path == rhs.path
    }
    
    // Codable conformance - custom encoding to handle optional children
    enum CodingKeys: String, CodingKey {
        case id, path, name, size, isDirectory, iconName, isSelected, children, hasLoadedChildren
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        path = try container.decode(String.self, forKey: .path)
        name = try container.decode(String.self, forKey: .name)
        size = try container.decode(Int64.self, forKey: .size)
        isDirectory = try container.decode(Bool.self, forKey: .isDirectory)
        iconName = try container.decode(String.self, forKey: .iconName)
        isSelected = try container.decodeIfPresent(Bool.self, forKey: .isSelected) ?? false
        children = try container.decodeIfPresent([StorageItem].self, forKey: .children)
        hasLoadedChildren = try container.decodeIfPresent(Bool.self, forKey: .hasLoadedChildren) ?? false
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(path, forKey: .path)
        try container.encode(name, forKey: .name)
        try container.encode(size, forKey: .size)
        try container.encode(isDirectory, forKey: .isDirectory)
        try container.encode(iconName, forKey: .iconName)
        try container.encode(isSelected, forKey: .isSelected)
        try container.encodeIfPresent(children, forKey: .children)
        try container.encode(hasLoadedChildren, forKey: .hasLoadedChildren)
    }
    
    // Get icon name based on file extension or directory type
    private static func iconForFile(_ fileName: String) -> String {
        let ext = (fileName as NSString).pathExtension.lowercased()
        
        switch ext {
        case "jpg", "jpeg", "png", "gif", "heic", "webp":
            return "photo.fill"
        case "mp4", "mov", "avi", "mkv":
            return "video.fill"
        case "mp3", "m4a", "wav", "flac":
            return "music.note"
        case "pdf":
            return "doc.fill"
        case "doc", "docx":
            return "doc.text.fill"
        case "xls", "xlsx":
            return "tablecells.fill"
        case "zip", "tar", "gz", "rar":
            return "archivebox.fill"
        case "app":
            return "app.fill"
        default:
            return "doc.fill"
        }
    }
    
    // Get system icon for a path
    static func systemIcon(for path: String) -> NSImage? {
        let url = URL(fileURLWithPath: path)
        return NSWorkspace.shared.icon(forFile: url.path)
    }
}

// MARK: - Storage Category
struct StorageCategory: Identifiable, Codable {
    let id: String
    let name: String
    let path: String
    let iconName: String
    var size: Int64
    var items: [StorageItem]
    
    init(name: String, path: String, iconName: String, size: Int64 = 0, items: [StorageItem] = []) {
        self.id = name
        self.name = name
        self.path = path
        self.iconName = iconName
        self.size = size
        self.items = items
    }
}
