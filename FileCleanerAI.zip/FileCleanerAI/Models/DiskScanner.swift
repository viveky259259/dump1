import Foundation
import AppKit

@MainActor
class DiskScanner: ObservableObject {
    @Published var categories: [StorageCategory] = []
    @Published var isScanning = false
    @Published var scanProgress: Double = 0.0
    
    private let fileManager = FileManager.default
    private let logManager = LogManager.shared
    private let sizeCalculationManager = SizeCalculationManager.shared
    
    // MARK: - Improved Size Cache (Performance Optimization #8)
    
    /// Thread-safe size cache with TTL support and persistence
    private var sizeCache: [String: CachedSize] = [:]
    private let cacheTTL: TimeInterval = 300 // 5 minutes
    private let saveCacheInterval: TimeInterval = 10 // Save cache every 10 seconds
    private var lastCacheSave: Date = Date()
    
    private struct CachedSize {
        let size: Int64
        let timestamp: Date
        let modificationDate: Date?
        
        var isValid: Bool {
            Date().timeIntervalSince(timestamp) < 300 // 5 minute TTL
        }
        
        func toCachedSizeEntry() -> CachedSizeEntry {
            return CachedSizeEntry(
                size: size,
                timestamp: timestamp,
                modificationDate: modificationDate
            )
        }
        
        static func fromCachedSizeEntry(_ entry: CachedSizeEntry) -> CachedSize {
            return CachedSize(
                size: entry.size,
                timestamp: entry.timestamp,
                modificationDate: entry.modificationDate
            )
        }
    }

    static let systemDataVirtualPath = "/__filecleanerai_system_data__"

    private enum SkipMode {
        case standard
        case systemData
    }
    
    init() {
        loadPersistedSizeCache()
    }
    
    private func loadPersistedSizeCache() {
        let persistedCache = PersistenceManager.shared.loadSizeCache()
        
        // Convert persisted cache to in-memory cache, checking for stale entries
        for (path, entry) in persistedCache {
            // Check if entry is still valid and not stale
            if entry.isValid && !isCacheStale(path: path, cachedDate: entry.modificationDate) {
                sizeCache[path] = CachedSize.fromCachedSizeEntry(entry)
            }
        }
        
        logManager.log("Loaded \(sizeCache.count) valid size cache entries from disk", level: .debug, category: .system)
    }
    
    private func isCacheStale(path: String, cachedDate: Date?) -> Bool {
        guard let cachedDate = cachedDate else { return false }
        
        guard let url = try? URL(fileURLWithPath: path),
              let resourceValues = try? url.resourceValues(forKeys: [.contentModificationDateKey]),
              let folderModDate = resourceValues.contentModificationDate else {
            return false
        }
        
        return folderModDate > cachedDate
    }
    
    private func savePersistedSizeCache() {
        // Convert in-memory cache to persisted format
        var persistedCache: [String: CachedSizeEntry] = [:]
        for (path, cached) in sizeCache {
            persistedCache[path] = cached.toCachedSizeEntry()
        }
        
        PersistenceManager.shared.saveSizeCache(persistedCache)
        lastCacheSave = Date()
    }

    func invalidateSizeCache(for path: String, includeChildren: Bool = true) {
        if includeChildren {
            let prefix = path.hasSuffix("/") ? path : path + "/"
            sizeCache = sizeCache.filter { key, _ in
                key != path && !key.hasPrefix(prefix)
            }
        } else {
            sizeCache.removeValue(forKey: path)
        }
        savePersistedSizeCache()
    }
    
    /// Pre-compiled skip paths for O(1) lookup (Performance Optimization #6)
    // Note: nonisolated(unsafe) needed because accessed from nonisolated static methods
    // Only absolute system paths - using prefix matching to avoid false positives
    nonisolated(unsafe) private static let skipPathComponents: Set<String> = Set([
        "/System",
        "/Library/System",
        "/private/var/vm",
        "/private/var/db",
        "/usr",
        "/bin",
        "/sbin",
        "/dev"
    ])
    
    /// Get the app's own data directory path to exclude from scans
    nonisolated private static func getAppDataDirectory() -> String {
        let fileManager = FileManager.default
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return appSupport.appendingPathComponent("FileCleanerAI", isDirectory: true).path
    }
    
    // MARK: - Top-Level Categories (Performance Optimization #3 - Parallel Scanning)
    
    func scanTopLevelCategories() async {
        logManager.log("Starting parallel category scan", level: .info, category: .scanning)
        isScanning = true
        scanProgress = 0.0
        categories = []
        
        // Clean expired cache entries and limit cache size to prevent unbounded growth
        cleanExpiredCache()
        
        // Limit cache size to prevent unbounded growth (keep max 1000 entries)
        if sizeCache.count > 1000 {
            // Remove oldest entries, keeping most recent 1000
            let sortedEntries = sizeCache.sorted { $0.value.timestamp > $1.value.timestamp }
            let topEntries = Array(sortedEntries.prefix(1000))
            sizeCache = Dictionary(uniqueKeysWithValues: topEntries.map { ($0.key, $0.value) })
            logManager.log("Trimmed size cache to 1000 entries", level: .debug, category: .system)
        }
        
        let categoryPaths = getTopLevelCategoryPaths()
        let totalCategories = Double(categoryPaths.count)
        
        // Use TaskGroup for parallel scanning
        var scannedCategories: [(Int, StorageCategory)] = []
        var completedCount = 0
        
        await withTaskGroup(of: (Int, StorageCategory).self) { group in
            for (index, categoryPath) in categoryPaths.enumerated() {
                group.addTask { [self] in
                    let category: StorageCategory
                    if categoryPath.name == "System Data" {
                        category = await self.scanSystemDataCategory(categoryPath)
                    } else {
                        category = await self.scanCategoryOptimized(categoryPath)
                    }
                    return (index, category)
                }
            }
            
            // Collect results and update progress
            for await result in group {
                scannedCategories.append(result)
                completedCount += 1
                scanProgress = Double(completedCount) / totalCategories
                
                // Update UI progressively - sort and show what we have so far
                let sortedSoFar = scannedCategories.sorted { $0.0 < $1.0 }.map { $0.1 }
                categories = sortedSoFar
            }
        }
        
        // Final sort by original index to maintain order
        categories = scannedCategories.sorted { $0.0 < $1.0 }.map { $0.1 }
        isScanning = false
        scanProgress = 1.0
        
        // Save scan results
        PersistenceManager.shared.saveDiskUsageData(categories: categories)
        
        // Save size cache after scan
        savePersistedSizeCache()
        
        logManager.log("Parallel scan complete: \(categories.count) categories", level: .success, category: .scanning)
    }
    
    /// Clean expired cache entries
    private func cleanExpiredCache() {
        let now = Date()
        sizeCache = sizeCache.filter { _, cached in
            now.timeIntervalSince(cached.timestamp) < cacheTTL
        }
    }
    
    private func getTopLevelCategoryPaths() -> [(name: String, path: String, icon: String)] {
        let homePath = fileManager.homeDirectoryForCurrentUser.path
        
        return [
            ("Applications", "/Applications", "app.fill"),
            ("Developer", homePath + "/Developer", "wrench.and.screwdriver.fill"),
            ("Documents", homePath + "/Documents", "doc.fill"),
            ("iCloud Drive", homePath + "/Library/Mobile Documents/com~apple~CloudDocs", "cloud.fill"),
            ("Mail", homePath + "/Library/Mail", "envelope.fill"),
            ("Messages", homePath + "/Library/Messages", "message.fill"),
            ("Music", homePath + "/Music", "music.note"),
            ("Photos", homePath + "/Pictures", "photo.fill"),
            ("Other Users & Shared", "/Users/Shared", "person.2.fill"),
            ("macOS", "/System", "desktopcomputer"),
            ("System Data", homePath + "/Library", "ellipsis.circle.fill")
        ]
    }

    private func getSystemDataRootPaths() -> [String] {
        let homePath = fileManager.homeDirectoryForCurrentUser.path
        return [
            homePath + "/Library",
            "/Library",
            "/private/var"
        ]
    }

    private func getSystemDataRootItems() -> [StorageItem] {
        let homePath = fileManager.homeDirectoryForCurrentUser.path
        let roots: [(String, String, String)] = [
            ("User Library", homePath + "/Library", "person.crop.circle"),
            ("System Library", "/Library", "folder.fill"),
            ("Private Var", "/private/var", "lock.shield")
        ]
        return roots.map { name, path, icon in
            StorageItem(
                path: path,
                name: name,
                size: -1, // -1 = not yet calculated
                isDirectory: true,
                iconName: icon
            )
        }
    }
    
    /// Optimized category scanning - calculates size during item enumeration
    private func scanCategoryOptimized(_ categoryPath: (name: String, path: String, icon: String)) async -> StorageCategory {
        let expandedPath = (categoryPath.path as NSString).expandingTildeInPath
        
        guard fileManager.fileExists(atPath: expandedPath) else {
            await MainActor.run {
                logManager.log("Category path does not exist: \(expandedPath)", level: .warning, category: .scanning)
            }
            return StorageCategory(
                name: categoryPath.name,
                path: expandedPath,
                iconName: categoryPath.icon,
                size: 0,
                items: []
            )
        }
        
        // Check cache for size
        let cachedSize = sizeCache[expandedPath]
        let useCache = cachedSize?.isValid == true
        
        // Get items and calculate size in parallel
        let skipMode: SkipMode = categoryPath.name == "macOS" ? .systemData : .standard
        async let itemsTask = getTopLevelItems(in: expandedPath, maxItems: 10, skipMode: skipMode)
        async let sizeTask: Int64 = useCache ? cachedSize!.size : calculateDirectorySizeOptimized(at: expandedPath, skipMode: skipMode)
        
        let (items, rawSize) = await (itemsTask, sizeTask)
        let size = max(rawSize, 0) // Treat failed calculations (-2) as 0 for category totals

        // Cache the size if we calculated it
        if !useCache && size >= 0 {
            let folderModDate = getFolderModificationDate(path: expandedPath)
            sizeCache[expandedPath] = CachedSize(
                size: size,
                timestamp: Date(),
                modificationDate: folderModDate
            )
        }
        
        return StorageCategory(
            name: categoryPath.name,
            path: expandedPath,
            iconName: categoryPath.icon,
            size: size,
            items: items
        )
    }

    private func scanSystemDataCategory(_ categoryPath: (name: String, path: String, icon: String)) async -> StorageCategory {
        let roots = getSystemDataRootPaths()
        var totalSize: Int64 = 0

        await withTaskGroup(of: Int64.self) { group in
            for root in roots {
                group.addTask { [self] in
                    return await self.calculateDirectorySizeOptimized(at: root, skipMode: .systemData)
                }
            }

            for await size in group {
                if size >= 0 {
                    totalSize += size
                }
            }
        }

        return StorageCategory(
            name: categoryPath.name,
            path: categoryPath.path,
            iconName: categoryPath.icon,
            size: totalSize,
            items: []
        )
    }
    
    // MARK: - Directory Size Calculation (Performance Optimization #2)
    
    func calculateDirectorySize(at path: String) async -> Int64 {
        // Check cache first with TTL
        if let cached = sizeCache[path], cached.isValid {
            // Check if folder has been modified
            if !isCacheStale(path: path, cachedDate: cached.modificationDate) {
                return cached.size
            } else {
                // Cache is stale, remove it
                sizeCache.removeValue(forKey: path)
                sizeCalculationManager.clearCache(for: path)
            }
        }
        
        // Check SizeCalculationManager cache
        if let cachedSize = sizeCalculationManager.getCachedSize(for: path) {
            // Update our cache too
            let folderModDate = getFolderModificationDate(path: path)
            sizeCache[path] = CachedSize(
                size: cachedSize,
                timestamp: Date(),
                modificationDate: folderModDate
            )
            return cachedSize
        }
        
        // Use smart batching manager for calculation
        return await withCheckedContinuation { continuation in
            sizeCalculationManager.requestSizeCalculation(for: path, priority: .normal) { size in
                // Cache the result
                let folderModDate = self.getFolderModificationDate(path: path)
                self.sizeCache[path] = CachedSize(
                    size: size,
                    timestamp: Date(),
                    modificationDate: folderModDate
                )
                
                // Periodically save cache to disk
                if Date().timeIntervalSince(self.lastCacheSave) > self.saveCacheInterval {
                    self.savePersistedSizeCache()
                }
                
                continuation.resume(returning: size)
            }
        }
    }
    
    private func getFolderModificationDate(path: String) -> Date? {
        guard let url = try? URL(fileURLWithPath: path),
              let resourceValues = try? url.resourceValues(forKeys: [.contentModificationDateKey]) else {
            return nil
        }
        return resourceValues.contentModificationDate
    }
    
    /// Optimized directory size calculation using batch processing
    private func calculateDirectorySizeOptimized(at path: String, skipMode: SkipMode = .standard) async -> Int64 {
        return await Task.detached(priority: .userInitiated) {
            let url = URL(fileURLWithPath: path)
            let fileManager = FileManager.default
            var totalSize: Int64 = 0
            
            guard let enumerator = fileManager.enumerator(
                at: url,
                includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey, .isSymbolicLinkKey],
                options: [.skipsHiddenFiles]  // Removed skipsPackageDescendants to include .app bundles
            ) else {
                return Int64(-2) // -2 = calculation failed (e.g., permission denied)
            }
            
            // Process in batches for better performance
            var batchCount = 0
            let yieldInterval = 1000
            
            while let fileURL = enumerator.nextObject() as? URL {
                // Skip system directories using optimized check
                let shouldSkip: Bool
                switch skipMode {
                case .standard:
                    shouldSkip = Self.shouldSkipPathOptimized(fileURL.path)
                case .systemData:
                    shouldSkip = Self.shouldSkipPathSystemData(fileURL.path)
                }
                if shouldSkip {
                    enumerator.skipDescendants()
                    continue
                }
                
                do {
                    let resourceValues = try fileURL.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey, .isSymbolicLinkKey])
                    
                    // Skip symlinks to avoid double-counting
                    if resourceValues.isSymbolicLink == true {
                        continue
                    }
                    
                    // Only count files, not directories (directories are counted by their contents)
                    if let isDirectory = resourceValues.isDirectory,
                       !isDirectory,
                       let fileSize = resourceValues.fileSize {
                        totalSize += Int64(fileSize)
                    }
                } catch {
                    // Log permission errors but continue processing
                    // Most errors are permission-related and can be safely ignored
                    continue
                }
                
                batchCount += 1
                if batchCount % yieldInterval == 0 {
                    await Task.yield()
                }
            }
            
            return totalSize
        }.value
    }
    
    // MARK: - Get Children (Performance Optimization #4 - Parallel Size Calculations)
    
    func getChildren(for item: StorageItem) async -> [StorageItem] {
        guard item.isDirectory else { return [] }

        if item.path == Self.systemDataVirtualPath {
            return getSystemDataRootItems()
        }
        
        // Check if already loaded
        if item.hasLoadedChildren, let children = item.children {
            return children
        }

        if isSystemDataPath(item.path) {
            return await getItems(in: item.path, skipMode: .systemData)
        }

        return await getItems(in: item.path)
    }
    
    /// Get items with parallel size calculation for directories
    private func getItems(in directoryPath: String, skipMode: SkipMode = .standard) async -> [StorageItem] {
        let items = await Task.detached(priority: .userInitiated) {
            let url = URL(fileURLWithPath: directoryPath)
            let fileManager = FileManager.default
            var items: [StorageItem] = []
            
            guard let contents = try? fileManager.contentsOfDirectory(
                at: url,
                includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey, .contentModificationDateKey, .isSymbolicLinkKey],
                options: [.skipsHiddenFiles]
            ) else {
                return [StorageItem]()
            }
            
            for fileURL in contents {
                // Skip system directories
                let shouldSkip: Bool
                switch skipMode {
                case .standard:
                    shouldSkip = Self.shouldSkipPathOptimized(fileURL.path)
                case .systemData:
                    shouldSkip = Self.shouldSkipPathSystemData(fileURL.path)
                }
                if shouldSkip {
                    continue
                }
                
                // Skip symlinks when listing items
                if let resourceValues = try? fileURL.resourceValues(forKeys: [.isSymbolicLinkKey]),
                   resourceValues.isSymbolicLink == true {
                    continue
                }
                
                if let item = Self.createStorageItemOptimized(from: fileURL, fileManager: fileManager) {
                    items.append(item)
                }
            }
            
            return items
        }.value
        
        // Request size calculations for directories using smart batching
        await MainActor.run {
            for item in items where item.isDirectory && item.size == -1 {
                // Check cache first
                if let cached = sizeCache[item.path], cached.isValid {
                    continue
                }
                
                // Request calculation with high priority if it's in current folder
                let priority: CalculationPriority = sizeCalculationManager.isCurrentFolderOrChild(item.path) ? .high : .normal
                
                sizeCalculationManager.requestSizeCalculation(for: item.path, priority: priority) { [weak self] size in
                    Task { @MainActor [self] in
                        guard let self = self else { return }
                        // Update item size in cache
                        let folderModDate = self.getFolderModificationDate(path: item.path)
                        self.sizeCache[item.path] = CachedSize(
                            size: size,
                            timestamp: Date(),
                            modificationDate: folderModDate
                        )
                    }
                }
            }
        }
        
        // Sort by size descending, then by name
        return items.sorted { item1, item2 in
            if item1.size != item2.size {
                return item1.size > item2.size
            }
            return item1.name.localizedCaseInsensitiveCompare(item2.name) == .orderedAscending
        }
    }

    private func isSystemDataPath(_ path: String) -> Bool {
        let roots = getSystemDataRootPaths()
        for root in roots {
            if path == root || path.hasPrefix(root + "/") {
                return true
            }
        }
        return false
    }
    
    /// Calculate sizes for multiple directories in parallel
    func calculateSizesInParallel(for items: [StorageItem]) async -> [String: Int64] {
        var sizes: [String: Int64] = [:]
        
        await withTaskGroup(of: (String, Int64).self) { group in
            for item in items where item.isDirectory && item.size == -1 {
                // Check cache first
                if let cached = sizeCache[item.path], cached.isValid {
                    sizes[item.path] = cached.size
                    continue
                }

                group.addTask { [self] in
                    let size = await self.calculateDirectorySizeOptimized(at: item.path)
                    return (item.path, size)
                }
            }
            
            for await (path, size) in group {
                sizes[path] = size
                // Only cache successful calculations (not -2 failures)
                if size >= 0 {
                    let folderModDate = getFolderModificationDate(path: path)
                    sizeCache[path] = CachedSize(
                        size: size,
                        timestamp: Date(),
                        modificationDate: folderModDate
                    )
                }
            }
            
            // Save cache after batch calculation
            savePersistedSizeCache()
        }
        
        return sizes
    }
    
    private func getTopLevelItems(in directoryPath: String, maxItems: Int = 10, skipMode: SkipMode = .standard) async -> [StorageItem] {
        let allItems = await getItems(in: directoryPath, skipMode: skipMode)
        return Array(allItems.prefix(maxItems))
    }
    
    // MARK: - Optimized Helper Methods
    
    /// Optimized storage item creation
    nonisolated private static func createStorageItemOptimized(from url: URL, fileManager: FileManager) -> StorageItem? {
        do {
            let resourceValues = try url.resourceValues(forKeys: [
                .fileSizeKey,
                .isDirectoryKey,
                .contentModificationDateKey,
                .isSymbolicLinkKey
            ])
            
            // Skip symlinks
            if resourceValues.isSymbolicLink == true {
                return nil
            }
            
            let isDirectory = resourceValues.isDirectory ?? false
            let name = url.lastPathComponent
            
            // Use actual file size, not allocated size
            let size: Int64
            if isDirectory {
                size = -1 // -1 = not yet calculated (will be calculated on-demand)
            } else {
                size = Int64(resourceValues.fileSize ?? 0)
            }
            
            return StorageItem(
                path: url.path,
                name: name,
                size: size,
                isDirectory: isDirectory,
                iconName: "",
                isSelected: false,
                children: nil,
                hasLoadedChildren: false
            )
        } catch {
            return nil
        }
    }
    
    /// Optimized path skipping using prefix matching to avoid false positives
    nonisolated private static func shouldSkipPathOptimized(_ path: String) -> Bool {
        // Skip app's own data directory to avoid counting our own cache files
        let appDataDir = getAppDataDirectory()
        if path == appDataDir || path.hasPrefix(appDataDir + "/") {
            return true
        }
        
        for component in skipPathComponents {
            // Only skip if path starts with or is exactly the component
            // This prevents false positives like "/Users/john/Library/Application Support"
            if path == component || path.hasPrefix(component + "/") {
                return true
            }
        }
        return false
    }

    nonisolated private static func shouldSkipPathSystemData(_ path: String) -> Bool {
        let appDataDir = getAppDataDirectory()
        if path == appDataDir || path.hasPrefix(appDataDir + "/") {
            return true
        }

        let homePath = FileManager.default.homeDirectoryForCurrentUser.path
        let excludedPaths = [
            homePath + "/Library/Mobile Documents/com~apple~CloudDocs",
            homePath + "/Library/Mail",
            homePath + "/Library/Messages"
        ]

        for component in excludedPaths {
            if path == component || path.hasPrefix(component + "/") {
                return true
            }
        }

        return false
    }
    
    private static func shouldSkipPath(_ path: String) -> Bool {
        return shouldSkipPathOptimized(path)
    }
    
    nonisolated private static func shouldSkipPathStatic(_ path: String) -> Bool {
        return shouldSkipPathOptimized(path)
    }
    
    nonisolated private static func createStorageItem(from url: URL, fileManager: FileManager) -> StorageItem? {
        return createStorageItemOptimized(from: url, fileManager: fileManager)
    }
    
    // MARK: - Get All Children Recursively (Optimized with parallel processing)
    
    func getAllChildrenRecursively(for item: StorageItem) async -> [StorageItem] {
        guard item.isDirectory else {
            return [item]
        }
        
        return await Task.detached(priority: .userInitiated) { [self] in
            var allItems: [StorageItem] = [item]
            let directChildren = await self.getChildren(for: item)
            
            // Process children in parallel for better performance
            await withTaskGroup(of: [StorageItem].self) { group in
                for child in directChildren {
                    if child.isDirectory {
                        group.addTask {
                            await self.getAllChildrenRecursively(for: child)
                        }
                    } else {
                        allItems.append(child)
                    }
                }
                
                for await subItems in group {
                    allItems.append(contentsOf: subItems)
                }
            }
            
            return allItems
        }.value
    }
    
    // MARK: - Deletion
    
    func moveToTrash(items: [StorageItem]) async {
        logManager.log("Moving \(items.count) item(s) to trash", level: .info, category: .deletion)
        var successCount = 0
        var failCount = 0
        
        for item in items {
            do {
                let url = URL(fileURLWithPath: item.path)
                try fileManager.trashItem(at: url, resultingItemURL: nil)
                successCount += 1
                logManager.log("Moved to trash: \(item.path)", level: .success, category: .deletion)
                
                // Remove from cache
                sizeCache.removeValue(forKey: item.path)
            } catch {
                failCount += 1
                logManager.log("Failed to trash: \(item.path) - \(error.localizedDescription)", level: .error, category: .deletion)
            }
        }
        
        if failCount == 0 {
            logManager.log("Successfully moved \(successCount) items to trash", level: .success, category: .deletion)
        } else {
            logManager.log("Completed with \(successCount) successes and \(failCount) failures", level: .warning, category: .deletion)
        }
    }
}
