import Foundation

// MARK: - Scan Directory Status
struct ScanDirectory: Identifiable, Hashable {
    let id = UUID()
    let path: String
    var displayName: String
    var status: ScanStatus
    var subdirectories: [ScanSubdirectory]
    var itemsFound: Int
    var totalSize: Int64
    
    // Hashable conformance
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: ScanDirectory, rhs: ScanDirectory) -> Bool {
        lhs.id == rhs.id
    }
    
    enum ScanStatus {
        case pending
        case inProgress
        case completed
        case failed(Error)
        
        var displayText: String {
            switch self {
            case .pending: return "Pending"
            case .inProgress: return "In Progress"
            case .completed: return "Completed"
            case .failed: return "Failed"
            }
        }
        
        var color: String {
            switch self {
            case .pending: return "gray"
            case .inProgress: return "blue"
            case .completed: return "green"
            case .failed: return "red"
            }
        }
    }
}

// MARK: - Scan Subdirectory
struct ScanSubdirectory: Identifiable {
    let id = UUID()
    let name: String
    let path: String
    var status: ScanDirectory.ScanStatus
    var itemsFound: Int
}

