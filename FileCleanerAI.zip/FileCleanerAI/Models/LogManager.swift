import Foundation
import SwiftUI

// MARK: - Log Entry
struct LogEntry: Identifiable {
    let id = UUID()
    let timestamp: Date
    let level: LogLevel
    let message: String
    let category: LogCategory
    
    enum LogLevel: String {
        case info = "INFO"
        case success = "SUCCESS"
        case warning = "WARNING"
        case error = "ERROR"
        case debug = "DEBUG"
        
        var color: Color {
            switch self {
            case .info: return .blue
            case .success: return .green
            case .warning: return .orange
            case .error: return .red
            case .debug: return .secondary
            }
        }
        
        var icon: String {
            switch self {
            case .info: return "info.circle.fill"
            case .success: return "checkmark.circle.fill"
            case .warning: return "exclamationmark.triangle.fill"
            case .error: return "xmark.circle.fill"
            case .debug: return "ant.circle.fill"
            }
        }
    }
    
    enum LogCategory: String {
        case scanning = "Scanning"
        case ai = "AI Analysis"
        case deletion = "Deletion"
        case system = "System"
        case general = "General"
    }
    
    var formattedTimestamp: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: timestamp)
    }
}

// MARK: - Log Manager (Performance Optimization #7 - Batched UI Updates)
@MainActor
class LogManager: ObservableObject {
    static let shared = LogManager()
    
    @Published var logs: [LogEntry] = []
    @Published var maxLogs: Int = 500
    
    // MARK: - Batching Configuration
    
    /// Pending logs waiting to be flushed to UI
    private var pendingLogs: [LogEntry] = []
    
    /// Task for debounced UI updates
    private var updateTask: Task<Void, Never>?
    
    /// Minimum interval between UI updates (milliseconds)
    private let updateDebounceMs: UInt64 = 50
    
    /// Maximum pending logs before forcing immediate flush
    private let maxPendingLogs = 20
    
    private init() {
        // Use immediate log for initialization
        logImmediate("Log system initialized", level: .info, category: .system)
    }
    
    /// Primary logging method with batched UI updates
    func log(_ message: String, level: LogEntry.LogLevel = .info, category: LogEntry.LogCategory = .general) {
        let entry = LogEntry(
            timestamp: Date(),
            level: level,
            message: message,
            category: category
        )
        
        // Add to pending logs
        pendingLogs.append(entry)
        
        // Also print to console immediately for debugging
        print("[\(level.rawValue)] [\(category.rawValue)] \(message)")
        
        // Force immediate flush for errors or if too many pending
        if level == .error || pendingLogs.count >= maxPendingLogs {
            flushPendingLogs()
            return
        }
        
        // Schedule debounced UI update
        scheduleFlush()
    }
    
    /// Logs immediately without batching (for critical messages)
    func logImmediate(_ message: String, level: LogEntry.LogLevel = .info, category: LogEntry.LogCategory = .general) {
        let entry = LogEntry(
            timestamp: Date(),
            level: level,
            message: message,
            category: category
        )
        
        logs.insert(entry, at: 0)
        trimLogsIfNeeded()
        
        print("[\(level.rawValue)] [\(category.rawValue)] \(message)")
    }
    
    /// Schedule a debounced flush of pending logs
    private func scheduleFlush() {
        // Cancel any existing scheduled update
        updateTask?.cancel()
        
        updateTask = Task { @MainActor in
            do {
                try await Task.sleep(nanoseconds: updateDebounceMs * 1_000_000)
                flushPendingLogs()
            } catch {
                // Task was cancelled, that's okay
            }
        }
    }
    
    /// Flush all pending logs to the UI in one batch
    private func flushPendingLogs() {
        guard !pendingLogs.isEmpty else { return }
        
        // Insert all pending logs at once (single UI update)
        logs.insert(contentsOf: pendingLogs, at: 0)
        pendingLogs.removeAll(keepingCapacity: true)
        
        trimLogsIfNeeded()
    }
    
    /// Trim logs to maxLogs limit
    private func trimLogsIfNeeded() {
        if logs.count > maxLogs {
            logs = Array(logs.prefix(maxLogs))
        }
    }
    
    func clearLogs() {
        pendingLogs.removeAll()
        logs.removeAll()
        logImmediate("Logs cleared", level: .info, category: .system)
    }
    
    func exportLogs() -> String {
        // Flush pending before export
        flushPendingLogs()
        
        return logs.reversed().map { entry in
            "[\(entry.formattedTimestamp)] [\(entry.level.rawValue)] [\(entry.category.rawValue)] \(entry.message)"
        }.joined(separator: "\n")
    }
}

