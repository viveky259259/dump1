import Foundation

// MARK: - File Pattern
struct FilePattern: Identifiable, Codable {
    let id: String
    let patternName: String
    let paths: [String]
    let safetyScore: SafetyScore
    let reason: String
    let count: Int
    let totalSize: Int64

    init(patternName: String, paths: [String], safetyScore: SafetyScore, reason: String, count: Int, totalSize: Int64) {
        self.id = UUID().uuidString
        self.patternName = patternName
        self.paths = paths
        self.safetyScore = safetyScore
        self.reason = reason
        self.count = count
        self.totalSize = totalSize
    }
}

// MARK: - Safety Score
enum SafetyScore: String, Codable {
    case high = "High"
    case medium = "Medium"
    case low = "Low"
}

// MARK: - Discovered File
/// Lightweight file reference - stores ONLY metadata, NOT file contents
/// Memory per instance: ~200 bytes (path string + metadata)
/// For 15,000 files: ~3MB total
struct DiscoveredFile {
    let path: String            // File path reference (not contents!)
    let size: Int64             // File size in bytes (metadata only)
    let name: String            // File name (extracted from path)
    let isDirectory: Bool       // Directory flag (metadata only)
    let modificationDate: Date? // Last modified date (metadata only)
    
    var displayPath: String {
        path.replacingOccurrences(of: FileManager.default.homeDirectoryForCurrentUser.path, with: "~")
    }
    
    /// Estimate memory footprint of this struct
    var estimatedMemorySize: Int {
        // String path: ~100 bytes average
        // String name: ~20 bytes average
        // Int size: 8 bytes
        // Bool: 1 byte
        // Date?: 16 bytes
        // Overhead: ~50 bytes
        return path.count + name.count + 75
    }
}

// MARK: - Chat Message
struct ChatMessage: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool
    let timestamp = Date()
}

// MARK: - Scan Configuration
struct ScanConfiguration {
    static let defaultDirectories = [
        "~/Documents",
        "~/Downloads",
        "~/Desktop",
        "~/Library/Caches",
        "~/Library/Logs"
    ]

    // MARK: - Project Artifact Patterns by Category

    /// JavaScript/Node.js artifacts
    static let jsPatterns = [
        "node_modules",
        ".npm",
        ".yarn",
        ".pnpm-store",
        ".next",
        ".nuxt",
        ".output",
        ".vercel",
        ".netlify",
        ".cache",
        "dist",
        "build",
        ".parcel-cache",
        ".turbo",
        ".svelte-kit",
        ".astro",
        "coverage"
    ]

    /// Python artifacts
    static let pythonPatterns = [
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".tox",
        ".nox",
        ".venv",
        "venv",
        "env",
        ".eggs",
        "*.egg-info",
        ".ipynb_checkpoints",
        ".pytype",
        "htmlcov",
        ".coverage"
    ]

    /// Rust artifacts
    static let rustPatterns = [
        "target",
        ".cargo"
    ]

    /// Go artifacts
    static let goPatterns = [
        "pkg",
        "bin",
        "vendor"
    ]

    /// Java/Kotlin/Android artifacts
    static let javaPatterns = [
        ".gradle",
        ".m2",
        "build",
        "target",
        ".idea",
        "*.iml",
        "out",
        "gradle-wrapper.jar"
    ]

    /// iOS/macOS (Swift/Objective-C) artifacts
    static let applePatterns = [
        "DerivedData",
        "Pods",
        ".build",
        "Build",
        "*.xcodeproj/xcuserdata",
        "*.xcworkspace/xcuserdata",
        "Carthage/Build",
        ".swiftpm"
    ]

    /// Ruby artifacts
    static let rubyPatterns = [
        "vendor/bundle",
        ".bundle",
        "coverage",
        "tmp/cache"
    ]

    /// PHP artifacts
    static let phpPatterns = [
        "vendor",
        ".phpunit.cache",
        "storage/framework/cache"
    ]

    /// .NET/C# artifacts
    static let dotnetPatterns = [
        "bin",
        "obj",
        "packages",
        ".vs",
        "*.suo",
        "*.user"
    ]

    /// Elixir/Erlang artifacts
    static let elixirPatterns = [
        "_build",
        "deps",
        ".elixir_ls"
    ]

    /// Docker artifacts
    static let dockerPatterns = [
        ".docker"
    ]

    /// IDE/Editor artifacts
    static let idePatterns = [
        ".idea",
        ".vscode",
        "*.code-workspace",
        ".project",
        ".settings",
        ".classpath"
    ]

    /// Version control artifacts
    static let vcsPatterns = [
        ".git",
        ".svn",
        ".hg"
    ]

    /// Combined common temp patterns (all categories)
    static let commonTempPatterns = jsPatterns +
        pythonPatterns +
        rustPatterns +
        goPatterns +
        javaPatterns +
        applePatterns +
        rubyPatterns +
        phpPatterns +
        dotnetPatterns +
        elixirPatterns +
        dockerPatterns +
        idePatterns + [
            ".DS_Store",
            "Thumbs.db",
            "*.swp",
            "*.swo",
            "*~"
        ]

    /// File extensions to detect
    static let fileExtensions = [
        ".log",
        ".tmp",
        ".temp",
        ".cache",
        ".bak",
        ".old",
        ".orig"
    ]

    /// Large file extensions (archives, installers, disk images)
    static let largeFileExtensions = [
        ".zip",
        ".tar",
        ".gz",
        ".bz2",
        ".xz",
        ".7z",
        ".rar",
        ".dmg",
        ".pkg",
        ".iso",
        ".app"
    ]

    // MARK: - Pattern Categories for UI Grouping

    enum PatternCategory: String, CaseIterable {
        case javascript = "JavaScript/Node.js"
        case python = "Python"
        case rust = "Rust"
        case go = "Go"
        case java = "Java/Kotlin"
        case apple = "iOS/macOS"
        case ruby = "Ruby"
        case php = "PHP"
        case dotnet = ".NET/C#"
        case elixir = "Elixir"
        case docker = "Docker"
        case ide = "IDE/Editor"
        case system = "System"

        var patterns: [String] {
            switch self {
            case .javascript: return ScanConfiguration.jsPatterns
            case .python: return ScanConfiguration.pythonPatterns
            case .rust: return ScanConfiguration.rustPatterns
            case .go: return ScanConfiguration.goPatterns
            case .java: return ScanConfiguration.javaPatterns
            case .apple: return ScanConfiguration.applePatterns
            case .ruby: return ScanConfiguration.rubyPatterns
            case .php: return ScanConfiguration.phpPatterns
            case .dotnet: return ScanConfiguration.dotnetPatterns
            case .elixir: return ScanConfiguration.elixirPatterns
            case .docker: return ScanConfiguration.dockerPatterns
            case .ide: return ScanConfiguration.idePatterns
            case .system: return [".DS_Store", "Thumbs.db"]
            }
        }

        var icon: String {
            switch self {
            case .javascript: return "j.circle.fill"
            case .python: return "p.circle.fill"
            case .rust: return "r.circle.fill"
            case .go: return "g.circle.fill"
            case .java: return "cup.and.saucer.fill"
            case .apple: return "apple.logo"
            case .ruby: return "diamond.fill"
            case .php: return "p.circle"
            case .dotnet: return "number.circle.fill"
            case .elixir: return "drop.fill"
            case .docker: return "shippingbox.fill"
            case .ide: return "hammer.fill"
            case .system: return "gearshape.fill"
            }
        }

        var description: String {
            switch self {
            case .javascript: return "node_modules, .next, dist, coverage"
            case .python: return "__pycache__, .venv, .pytest_cache"
            case .rust: return "target directory"
            case .go: return "pkg, bin, vendor"
            case .java: return ".gradle, build, target, .m2"
            case .apple: return "DerivedData, Pods, Build"
            case .ruby: return "vendor/bundle, .bundle"
            case .php: return "vendor, cache"
            case .dotnet: return "bin, obj, packages"
            case .elixir: return "_build, deps"
            case .docker: return ".docker"
            case .ide: return ".idea, .vscode"
            case .system: return ".DS_Store, Thumbs.db"
            }
        }
    }

    /// Get category for a given pattern
    static func category(for pattern: String) -> PatternCategory? {
        for category in PatternCategory.allCases {
            if category.patterns.contains(pattern) {
                return category
            }
        }
        return nil
    }
}

