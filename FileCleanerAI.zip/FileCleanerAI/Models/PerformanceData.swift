import Foundation

// MARK: - Operation Types

enum OperationType: String, Codable {
    case scan = "Scan"
    case aiAnalysis = "AI Analysis"
    case deletion = "Deletion"
    case appLaunch = "App Launch"
}

// MARK: - Base Performance Metric

struct PerformanceMetric: Codable, Identifiable {
    let id = UUID()
    let timestamp: Date
    let operationType: OperationType
    let duration: TimeInterval
    
    enum CodingKeys: String, CodingKey {
        case timestamp, operationType, duration
    }
    
    init(timestamp: Date, operationType: OperationType, duration: TimeInterval) {
        self.timestamp = timestamp
        self.operationType = operationType
        self.duration = duration
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        timestamp = try container.decode(Date.self, forKey: .timestamp)
        operationType = try container.decode(OperationType.self, forKey: .operationType)
        duration = try container.decode(TimeInterval.self, forKey: .duration)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(timestamp, forKey: .timestamp)
        try container.encode(operationType, forKey: .operationType)
        try container.encode(duration, forKey: .duration)
    }
}

// MARK: - Scan Metrics

struct ScanMetrics: Codable {
    let filesScanned: Int
    let directoriesScanned: Int
    let duration: TimeInterval
    let throughput: Double // files per second
    let totalSizeScanned: Int64 // bytes
    let memoryAtStart: Int64
    let peakMemory: Int64
    
    var filesPerSecond: Double {
        guard duration > 0 else { return 0 }
        return Double(filesScanned) / duration
    }
    
    var formattedThroughput: String {
        String(format: "%.1f files/sec", throughput)
    }
}

// MARK: - Memory Snapshot

struct MemorySnapshot: Codable {
    let timestamp: Date
    let appMemory: Int64
    let systemMemory: Int64
    let physicalMemory: Int64
    let memoryPressure: String // "normal", "warning", "critical"
    
    var appMemoryPercent: Double {
        guard physicalMemory > 0 else { return 0 }
        return Double(appMemory) / Double(physicalMemory) * 100
    }
    
    var systemMemoryPercent: Double {
        guard physicalMemory > 0 else { return 0 }
        return Double(systemMemory) / Double(physicalMemory) * 100
    }
}

// MARK: - AI Analysis Metrics

struct AIAnalysisMetrics: Codable {
    let patternsDetected: Int
    let filesAnalyzed: Int
    let duration: TimeInterval
    let usedAI: Bool // true if AI was used, false if rule-based
    let memoryAtStart: Int64
    let peakMemory: Int64
    
    var filesPerSecond: Double {
        guard duration > 0 else { return 0 }
        return Double(filesAnalyzed) / duration
    }
}

// MARK: - Deletion Metrics

struct DeletionMetrics: Codable {
    let patternsDeleted: Int
    let filesDeleted: Int
    let bytesFreed: Int64
    let duration: TimeInterval
    let successCount: Int
    let failureCount: Int
    
    var successRate: Double {
        let total = successCount + failureCount
        guard total > 0 else { return 0 }
        return Double(successCount) / Double(total) * 100
    }
    
    var filesPerSecond: Double {
        guard duration > 0 else { return 0 }
        return Double(filesDeleted) / duration
    }
}

// MARK: - Performance Session

struct PerformanceSession: Codable, Identifiable {
    let id = UUID()
    let sessionStart: Date
    var sessionEnd: Date?
    var scanMetrics: ScanMetrics?
    var aiMetrics: AIAnalysisMetrics?
    var deletionMetrics: [DeletionMetrics] = []
    var memorySnapshots: [MemorySnapshot] = []
    
    enum CodingKeys: String, CodingKey {
        case sessionStart, sessionEnd, scanMetrics, aiMetrics, deletionMetrics, memorySnapshots
    }
    
    init(sessionStart: Date, sessionEnd: Date? = nil) {
        self.sessionStart = sessionStart
        self.sessionEnd = sessionEnd
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        sessionStart = try container.decode(Date.self, forKey: .sessionStart)
        sessionEnd = try container.decodeIfPresent(Date.self, forKey: .sessionEnd)
        scanMetrics = try container.decodeIfPresent(ScanMetrics.self, forKey: .scanMetrics)
        aiMetrics = try container.decodeIfPresent(AIAnalysisMetrics.self, forKey: .aiMetrics)
        deletionMetrics = try container.decodeIfPresent([DeletionMetrics].self, forKey: .deletionMetrics) ?? []
        memorySnapshots = try container.decodeIfPresent([MemorySnapshot].self, forKey: .memorySnapshots) ?? []
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(sessionStart, forKey: .sessionStart)
        try container.encodeIfPresent(sessionEnd, forKey: .sessionEnd)
        try container.encodeIfPresent(scanMetrics, forKey: .scanMetrics)
        try container.encodeIfPresent(aiMetrics, forKey: .aiMetrics)
        try container.encode(deletionMetrics, forKey: .deletionMetrics)
        try container.encode(memorySnapshots, forKey: .memorySnapshots)
    }
    
    var sessionDuration: TimeInterval {
        let end = sessionEnd ?? Date()
        return end.timeIntervalSince(sessionStart)
    }
    
    var totalDeletions: Int {
        deletionMetrics.reduce(0) { $0 + $1.filesDeleted }
    }
    
    var totalBytesFreed: Int64 {
        deletionMetrics.reduce(0) { $0 + $1.bytesFreed }
    }
}

// MARK: - Performance Data Storage

struct PerformanceDataStorage: Codable {
    var sessions: [PerformanceSession]
    var lastUpdated: Date
    
    init(sessions: [PerformanceSession] = [], lastUpdated: Date = Date()) {
        self.sessions = sessions
        self.lastUpdated = lastUpdated
    }
    
    /// Removes sessions older than specified days
    mutating func cleanupOldSessions(keepDays: Int = 7) {
        let cutoffDate = Date().addingTimeInterval(-TimeInterval(keepDays * 24 * 60 * 60))
        sessions = sessions.filter { $0.sessionStart >= cutoffDate }
    }
}

// MARK: - Aggregated Performance Statistics

struct PerformanceStats {
    let totalScans: Int
    let averageScanDuration: TimeInterval
    let averageScanThroughput: Double
    let totalFilesScanned: Int
    let totalAIAnalyses: Int
    let averageAIDuration: TimeInterval
    let totalDeletions: Int
    let totalBytesFreed: Int64
    let averageDeletionSuccessRate: Double
    let peakMemoryUsage: Int64
    let averageMemoryUsage: Int64
    
    var formattedAverageScanDuration: String {
        formatDuration(averageScanDuration)
    }
    
    var formattedAverageAIDuration: String {
        formatDuration(averageAIDuration)
    }
    
    var formattedTotalBytesFreed: String {
        ByteCountFormatter.string(fromByteCount: totalBytesFreed, countStyle: .file)
    }
    
    var formattedPeakMemory: String {
        ByteCountFormatter.string(fromByteCount: peakMemoryUsage, countStyle: .memory)
    }
    
    var formattedAverageMemory: String {
        ByteCountFormatter.string(fromByteCount: averageMemoryUsage, countStyle: .memory)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        if duration < 1 {
            return String(format: "%.0f ms", duration * 1000)
        } else if duration < 60 {
            return String(format: "%.1f sec", duration)
        } else {
            let minutes = Int(duration / 60)
            let seconds = Int(duration.truncatingRemainder(dividingBy: 60))
            return "\(minutes)m \(seconds)s"
        }
    }
}

// MARK: - Operation Tracker

class OperationTracker {
    let operationType: OperationType
    let startTime: Date
    var endTime: Date?
    
    init(operationType: OperationType) {
        self.operationType = operationType
        self.startTime = Date()
    }
    
    func end() -> TimeInterval {
        endTime = Date()
        return endTime!.timeIntervalSince(startTime)
    }
    
    var duration: TimeInterval {
        guard let end = endTime else { return Date().timeIntervalSince(startTime) }
        return end.timeIntervalSince(startTime)
    }
}
