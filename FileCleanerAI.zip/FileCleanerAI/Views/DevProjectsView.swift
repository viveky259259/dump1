import SwiftUI

struct DevProjectsView: View {
    @StateObject private var scanner = DevProjectScanner.shared
    @State private var searchText = ""
    @State private var filterLanguage: ProjectLanguage?
    @State private var showStaleOnly = false
    @State private var showingCleanConfirmation = false
    @State private var projectToClean: DevProject?
    @State private var showingResult = false
    @State private var cleaningResult: CleaningResult?
    @State private var showingBulkCleanConfirmation = false
    @State private var showingPreview = false
    @State private var previewItems: [DeletionPreviewItem] = []

    private var filteredProjects: [DevProject] {
        var result = scanner.projects
        if !searchText.isEmpty {
            result = result.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
        if let lang = filterLanguage {
            result = result.filter { $0.language == lang }
        }
        if showStaleOnly {
            result = result.filter { $0.isStale }
        }
        return result
    }

    private var staleProjects: [DevProject] {
        scanner.projects.filter { $0.isStale }
    }

    private var staleSize: Int64 {
        staleProjects.reduce(0) { $0 + $1.totalArtifactSize }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            DevProjectsHeaderView(
                scanner: scanner,
                searchText: $searchText,
                filterLanguage: $filterLanguage,
                showStaleOnly: $showStaleOnly,
                onScan: {
                    Task { await scanner.scanForProjects() }
                },
                onCleanStale: {
                    // Build preview from stale projects
                    previewItems = staleProjects.flatMap { project in
                        project.artifacts.map { artifact in
                            DeletionPreviewItem(
                                id: artifact.path,
                                path: artifact.path,
                                name: "\(project.name)/\(artifact.name)",
                                size: artifact.size,
                                category: project.language.rawValue,
                                icon: project.language.icon
                            )
                        }
                    }
                    showingPreview = true
                }
            )

            Divider()

            if scanner.isScanning {
                VStack(spacing: 16) {
                    Spacer()
                    ProgressView(value: scanner.scanProgress)
                        .progressViewStyle(LinearProgressViewStyle())
                        .frame(width: 300)
                    Text("Scanning for developer projects...")
                        .font(.headline)
                    Text("\(Int(scanner.scanProgress * 100))%")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if filteredProjects.isEmpty {
                VStack(spacing: 12) {
                    Spacer()
                    Image(systemName: "hammer.fill")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text(scanner.projects.isEmpty ? "No projects found" : "No matching projects")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    if scanner.projects.isEmpty {
                        Button("Scan Now") {
                            Task { await scanner.scanForProjects() }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(filteredProjects) { project in
                        DevProjectRow(
                            project: project,
                            onClean: {
                                projectToClean = project
                                showingCleanConfirmation = true
                            }
                        )
                    }
                }
                .listStyle(.inset(alternatesRowBackgrounds: true))
            }

            // Footer
            if scanner.totalReclaimable > 0 {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Total reclaimable: \(ByteCountFormatter.string(fromByteCount: scanner.totalReclaimable, countStyle: .file))")
                            .font(.callout)

                        if !staleProjects.isEmpty {
                            Text("\(staleProjects.count) stale projects (>90 days): \(ByteCountFormatter.string(fromByteCount: staleSize, countStyle: .file))")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                    }

                    Spacer()

                    Text("\(filteredProjects.count) projects")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding()
                .background(Color(NSColor.controlBackgroundColor))
            }
        }
        .alert("Clean Project Artifacts", isPresented: $showingCleanConfirmation) {
            Button("Cancel", role: .cancel) { projectToClean = nil }
            Button("Move to Trash", role: .destructive) {
                if let project = projectToClean {
                    Task {
                        cleaningResult = await scanner.cleanProject(project)
                        showingResult = true
                    }
                }
                projectToClean = nil
            }
        } message: {
            if let project = projectToClean {
                Text("Clean \(project.artifacts.count) build artifact\(project.artifacts.count == 1 ? "" : "s") from \"\(project.name)\"?\n\nThis will free \(project.formattedArtifactSize).\n\nArtifacts:\n\(project.artifacts.map { "• \($0.name) (\($0.formattedSize))" }.joined(separator: "\n"))")
            }
        }
        .alert("Clean All Stale Projects", isPresented: $showingBulkCleanConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Clean \(staleProjects.count) Projects", role: .destructive) {
                Task {
                    cleaningResult = await scanner.cleanAllStaleProjects()
                    showingResult = true
                }
            }
        } message: {
            Text("Clean build artifacts from \(staleProjects.count) projects not modified in 90+ days?\n\nThis will free \(ByteCountFormatter.string(fromByteCount: staleSize, countStyle: .file)).")
        }
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") { cleaningResult = nil }
        } message: {
            if let result = cleaningResult {
                Text("Removed \(result.success) items.\nFreed \(result.formattedBytesFreed) of space.")
            }
        }
        .sheet(isPresented: $showingPreview) {
            DeletionPreviewSheet(
                items: $previewItems,
                title: "Preview: Stale Dev Artifacts",
                onConfirm: { _ in
                    showingPreview = false
                    Task {
                        cleaningResult = await scanner.cleanAllStaleProjects()
                        showingResult = true
                    }
                },
                onCancel: { showingPreview = false }
            )
        }
        .onAppear {
            if scanner.projects.isEmpty {
                Task { await scanner.scanForProjects() }
            }
        }
    }
}

// MARK: - Header

struct DevProjectsHeaderView: View {
    @ObservedObject var scanner: DevProjectScanner
    @Binding var searchText: String
    @Binding var filterLanguage: ProjectLanguage?
    @Binding var showStaleOnly: Bool
    let onScan: () -> Void
    let onCleanStale: () -> Void

    private var detectedLanguages: [ProjectLanguage] {
        let langs = Set(scanner.projects.map { $0.language })
        return ProjectLanguage.allCases.filter { langs.contains($0) }
    }

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "hammer.fill")
                            .foregroundStyle(.indigo)
                        Text("Developer Projects")
                            .font(.headline)
                    }
                    Text("Find and clean build artifacts from your development projects")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button(action: onScan) {
                    Label("Rescan", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(scanner.isScanning)

                if scanner.projects.contains(where: { $0.isStale }) {
                    Button(action: onCleanStale) {
                        Label("Clean Stale", systemImage: "trash")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.orange)
                    .disabled(scanner.isScanning)
                }
            }

            HStack(spacing: 8) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Search projects...", text: $searchText)
                        .textFieldStyle(.plain)
                }
                .padding(6)
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color(NSColor.separatorColor), lineWidth: 0.5)
                )

                Picker("Language", selection: $filterLanguage) {
                    Text("All Languages").tag(nil as ProjectLanguage?)
                    ForEach(detectedLanguages, id: \.self) { lang in
                        Text(lang.rawValue).tag(lang as ProjectLanguage?)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 160)

                Toggle("Stale only", isOn: $showStaleOnly)
                    .toggleStyle(.checkbox)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Project Row

struct DevProjectRow: View {
    let project: DevProject
    let onClean: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            // Language icon
            Image(systemName: project.language.icon)
                .font(.title2)
                .foregroundStyle(.indigo)
                .frame(width: 30)

            // Project info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(project.name)
                        .font(.subheadline)
                        .fontWeight(.medium)

                    Text(project.language.rawValue)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Capsule().fill(Color.indigo.opacity(0.15)))
                        .foregroundStyle(.indigo)

                    if project.isStale {
                        Text("STALE")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Color.orange.opacity(0.15)))
                            .foregroundStyle(.orange)
                    }
                }

                Text(project.path)
                    .font(.caption)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
                    .truncationMode(.middle)

                // Artifacts
                HStack(spacing: 8) {
                    ForEach(project.artifacts) { artifact in
                        Text("\(artifact.name) (\(artifact.formattedSize))")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            Spacer()

            // Staleness
            VStack(alignment: .trailing, spacing: 2) {
                Text(project.formattedArtifactSize)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundStyle(project.isStale ? .orange : .indigo)

                Text(project.staleness)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            // Clean button
            Button(action: onClean) {
                Image(systemName: "trash")
            }
            .buttonStyle(.bordered)
            .help("Clean build artifacts")
        }
        .padding(.vertical, 6)
        .contextMenu {
            Button(action: {
                NSWorkspace.shared.selectFile(project.path, inFileViewerRootedAtPath: "")
            }) {
                Label("Open in Finder", systemImage: "folder")
            }

            Button(action: onClean) {
                Label("Clean Artifacts", systemImage: "trash")
            }
        }
    }
}

#Preview {
    DevProjectsView()
}
