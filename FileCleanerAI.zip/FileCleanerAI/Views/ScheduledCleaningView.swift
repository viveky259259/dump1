import SwiftUI

struct ScheduledCleaningView: View {
    @StateObject private var manager = ScheduledCleaningManager.shared
    @State private var showingCleanConfirmation = false
    @State private var showingResult = false
    @State private var resultMessage = ""

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "calendar.badge.clock")
                            .foregroundStyle(.green)
                        Text("Scheduled Cleaning")
                            .font(.headline)
                    }
                    Text("Automate scanning and cleaning on a regular schedule")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                // Quick status
                HStack(spacing: 8) {
                    Circle()
                        .fill(manager.config.isEnabled ? .green : .secondary)
                        .frame(width: 8, height: 8)

                    Text(manager.statusText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            ScrollView {
                VStack(spacing: 20) {
                    // Enable toggle
                    ScheduleToggleSection(config: $manager.config, onToggle: {
                        manager.startScheduleCheck()
                    })

                    if manager.config.isEnabled {
                        // Interval picker
                        ScheduleIntervalSection(config: $manager.config)

                        // What to clean
                        ScheduleTargetsSection(config: $manager.config)

                        // Notification settings
                        ScheduleNotificationSection(config: $manager.config)

                        // Threshold
                        ScheduleThresholdSection(config: $manager.config)
                    }

                    Divider()

                    // Manual actions
                    ScheduleActionsSection(
                        manager: manager,
                        onScan: {
                            Task { await manager.runScheduledScan() }
                        },
                        onClean: {
                            showingCleanConfirmation = true
                        }
                    )

                    // Last scan summary
                    if let summary = manager.lastSummary {
                        ScheduleSummarySection(summary: summary, config: manager.config)
                    }

                    // History
                    ScheduleHistorySection(config: manager.config)
                }
                .padding()
            }
        }
        .alert("Run Scheduled Clean?", isPresented: $showingCleanConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Clean Now", role: .destructive) {
                Task {
                    await manager.runScheduledClean()
                    let freed = manager.config.lastCleanedBytes
                    resultMessage = "Freed \(ByteCountFormatter.string(fromByteCount: freed, countStyle: .file)) of space."
                    showingResult = true
                }
            }
        } message: {
            if let summary = manager.lastSummary {
                Text("This will clean \(summary.formattedTotal) of data based on your schedule settings.")
            } else {
                Text("Run a scan first to see what will be cleaned.")
            }
        }
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") {}
        } message: {
            Text(resultMessage)
        }
    }
}

// MARK: - Toggle Section

struct ScheduleToggleSection: View {
    @Binding var config: CleaningScheduleConfig
    let onToggle: () -> Void

    var body: some View {
        GroupBox {
            Toggle(isOn: $config.isEnabled) {
                HStack {
                    Image(systemName: "power")
                        .foregroundStyle(config.isEnabled ? .green : .secondary)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Enable Scheduled Cleaning")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        Text("Automatically scan and notify you when cleanup is recommended")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .onChange(of: config.isEnabled) { _, _ in onToggle() }
        }
    }
}

// MARK: - Interval Section

struct ScheduleIntervalSection: View {
    @Binding var config: CleaningScheduleConfig

    var body: some View {
        GroupBox(label: Label("Schedule", systemImage: "clock")) {
            Picker("Cleaning interval", selection: $config.interval) {
                ForEach(CleaningInterval.allCases, id: \.self) { interval in
                    Text(interval.description).tag(interval)
                }
            }
            .pickerStyle(.segmented)
        }
    }
}

// MARK: - Targets Section

struct ScheduleTargetsSection: View {
    @Binding var config: CleaningScheduleConfig

    var body: some View {
        GroupBox(label: Label("What to Clean", systemImage: "checklist")) {
            VStack(alignment: .leading, spacing: 10) {
                Toggle(isOn: $config.cleanSystemData) {
                    HStack {
                        Image(systemName: "externaldrive.fill")
                            .foregroundStyle(.teal)
                            .frame(width: 20)
                        Text("System Data (caches, logs, temp files)")
                            .font(.subheadline)
                    }
                }

                Toggle(isOn: $config.cleanBrowserCaches) {
                    HStack {
                        Image(systemName: "globe")
                            .foregroundStyle(.blue)
                            .frame(width: 20)
                        Text("Browser Caches (Safari, Chrome, Firefox, Arc, Brave, Edge)")
                            .font(.subheadline)
                    }
                }

                Toggle(isOn: $config.cleanDevArtifacts) {
                    HStack {
                        Image(systemName: "hammer.fill")
                            .foregroundStyle(.indigo)
                            .frame(width: 20)
                        Text("Stale Dev Artifacts (node_modules, target, etc. >90 days)")
                            .font(.subheadline)
                    }
                }

                Toggle(isOn: $config.cleanXcodeData) {
                    HStack {
                        Image(systemName: "hammer.circle.fill")
                            .foregroundStyle(.orange)
                            .frame(width: 20)
                        Text("Xcode Data (DerivedData, old simulators, caches)")
                            .font(.subheadline)
                    }
                }
            }
        }
    }
}

// MARK: - Notification Section

struct ScheduleNotificationSection: View {
    @Binding var config: CleaningScheduleConfig

    var body: some View {
        GroupBox(label: Label("Notifications", systemImage: "bell")) {
            VStack(alignment: .leading, spacing: 10) {
                Toggle("Notify before cleaning (preview what will be removed)", isOn: $config.notifyBeforeCleaning)
                    .font(.subheadline)

                Toggle("Notify after cleaning (show freed space)", isOn: $config.notifyAfterCleaning)
                    .font(.subheadline)
            }
        }
    }
}

// MARK: - Threshold Section

struct ScheduleThresholdSection: View {
    @Binding var config: CleaningScheduleConfig

    var body: some View {
        GroupBox(label: Label("Alert Threshold", systemImage: "exclamationmark.triangle")) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Notify when cleanable data exceeds:")
                        .font(.subheadline)

                    Spacer()

                    Text("\(String(format: "%.1f", config.alertThresholdGB)) GB")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.orange)
                }

                Slider(value: $config.alertThresholdGB, in: 0.5...50, step: 0.5)
                    .tint(.orange)

                HStack {
                    Text("0.5 GB")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("50 GB")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}

// MARK: - Actions Section

struct ScheduleActionsSection: View {
    @ObservedObject var manager: ScheduledCleaningManager
    let onScan: () -> Void
    let onClean: () -> Void

    var body: some View {
        GroupBox(label: Label("Manual Actions", systemImage: "hand.tap")) {
            HStack(spacing: 12) {
                Button(action: onScan) {
                    VStack(spacing: 6) {
                        Image(systemName: "magnifyingglass")
                            .font(.title2)
                        Text("Scan Now")
                            .font(.caption)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                }
                .buttonStyle(.bordered)
                .disabled(manager.isScanning || manager.isCleaning)

                Button(action: onClean) {
                    VStack(spacing: 6) {
                        Image(systemName: "trash")
                            .font(.title2)
                        Text("Clean Now")
                            .font(.caption)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(manager.isScanning || manager.isCleaning || !manager.hasCleanableData)
            }

            if manager.isScanning {
                HStack {
                    ProgressView()
                        .scaleEffect(0.7)
                    Text("Scanning...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if manager.isCleaning {
                HStack {
                    ProgressView()
                        .scaleEffect(0.7)
                    Text("Cleaning...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}

// MARK: - Summary Section

struct ScheduleSummarySection: View {
    let summary: ScheduledCleaningSummary
    let config: CleaningScheduleConfig

    var body: some View {
        GroupBox(label: Label("Last Scan Results", systemImage: "chart.bar")) {
            VStack(spacing: 8) {
                SummaryRow(label: "System Data", size: summary.systemDataSize, enabled: config.cleanSystemData, icon: "externaldrive.fill", color: .teal)
                SummaryRow(label: "Dev Artifacts (stale)", size: summary.devArtifactSize, enabled: config.cleanDevArtifacts, icon: "hammer.fill", color: .indigo)
                SummaryRow(label: "Xcode Data", size: summary.xcodeDataSize, enabled: config.cleanXcodeData, icon: "hammer.circle.fill", color: .orange)

                Divider()

                HStack {
                    Text("Total Cleanable")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    Spacer()
                    Text(summary.formattedTotal)
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundStyle(.green)
                }
            }
        }
    }
}

struct SummaryRow: View {
    let label: String
    let size: Int64
    let enabled: Bool
    let icon: String
    let color: Color

    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundStyle(enabled ? color : .secondary)
                .frame(width: 20)

            Text(label)
                .font(.subheadline)
                .foregroundStyle(enabled ? .primary : .secondary)

            Spacer()

            Text(ByteCountFormatter.string(fromByteCount: size, countStyle: .file))
                .font(.subheadline)
                .foregroundStyle(enabled ? .primary : .tertiary)

            if !enabled {
                Text("(disabled)")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
        }
    }
}

// MARK: - History Section

struct ScheduleHistorySection: View {
    let config: CleaningScheduleConfig

    var body: some View {
        GroupBox(label: Label("History", systemImage: "clock.arrow.circlepath")) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Last scan:")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Spacer()
                    if let date = config.lastScanDate {
                        Text(date.formatted(date: .abbreviated, time: .shortened))
                            .font(.subheadline)
                    } else {
                        Text("Never")
                            .font(.subheadline)
                            .foregroundStyle(.tertiary)
                    }
                }

                HStack {
                    Text("Last clean:")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Spacer()
                    if let date = config.lastCleanDate {
                        Text(date.formatted(date: .abbreviated, time: .shortened))
                            .font(.subheadline)
                    } else {
                        Text("Never")
                            .font(.subheadline)
                            .foregroundStyle(.tertiary)
                    }
                }

                if config.lastCleanedBytes > 0 {
                    HStack {
                        Text("Last freed:")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text(ByteCountFormatter.string(fromByteCount: config.lastCleanedBytes, countStyle: .file))
                            .font(.subheadline)
                            .foregroundStyle(.green)
                    }
                }
            }
        }
    }
}

#Preview {
    ScheduledCleaningView()
}
