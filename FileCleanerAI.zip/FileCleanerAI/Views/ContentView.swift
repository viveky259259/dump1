import SwiftUI

struct ContentView: View {
    @StateObject private var scanner = FileScanner()
    @StateObject private var aiService = AIService()
    @StateObject private var logManager = LogManager.shared
    @StateObject private var performanceManager = PerformanceManager.shared
    @StateObject private var observability = ObservabilityManager.shared
    @State private var selectedPatterns: Set<String> = []
    @State private var showingDeleteConfirmation = false
    @State private var searchQuery = ""
    @State private var showingLogs = false
    @State private var showingDebugView = false
    @State private var lastScanDate: String?
    @State private var selectedTab: TabSelection = .patternScan
    
    enum TabSelection {
        case patternScan
        case duplicates
        case privacy
        case diskUsage
        case systemData
        case uninstaller
        case devProjects
        case xcodeCleanup
        case optimizer
        case cacheAnalyzer
        case snapshots
        case schedule
        case settings
    }
    
    var body: some View {
        ZStack(alignment: .trailing) {
            // Main Content
            VStack(spacing: 0) {
                // Header with Tab Selection
                HeaderViewWithTabs(
                    selectedTab: $selectedTab,
                    isScanning: scanner.isScanning,
                    onScan: startScan,
                    onShowLogs: {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                            showingLogs.toggle()
                        }
                    },
                    onShowDebug: {
                        showingDebugView = true
                    },
                    logCount: logManager.logs.count,
                    hasNewLogs: logManager.logs.first?.timestamp.timeIntervalSinceNow ?? -100 > -5,
                    lastScanDate: lastScanDate
                )
                
                Divider()
                
                // Tab Content
                if selectedTab == .patternScan {
                    PatternScanContentView(
                        scanner: scanner,
                        aiService: aiService,
                        selectedPatterns: $selectedPatterns,
                        searchQuery: searchQuery,
                        showingDeleteConfirmation: $showingDeleteConfirmation,
                        onDelete: deleteSelectedPatterns,
                        calculateSelectedSize: calculateSelectedSize
                    )
                } else if selectedTab == .duplicates {
                    DuplicateFinderView()
                } else if selectedTab == .privacy {
                    PrivacyCleanerView()
                } else if selectedTab == .diskUsage {
                    DiskUsageView()
                } else if selectedTab == .systemData {
                    SystemDataView()
                } else if selectedTab == .uninstaller {
                    AppUninstallerView()
                } else if selectedTab == .devProjects {
                    DevProjectsView()
                } else if selectedTab == .xcodeCleanup {
                    XcodeCleanupView()
                } else if selectedTab == .optimizer {
                    SystemOptimizerView()
                } else if selectedTab == .cacheAnalyzer {
                    AppCacheAnalyzerView()
                } else if selectedTab == .snapshots {
                    SnapshotManagerView()
                } else if selectedTab == .schedule {
                    ScheduledCleaningView()
                } else {
                    SettingsView()
                }
            }
            .frame(minWidth: 900, minHeight: 600)
            
            // Log Drawer (Sliding from right)
            if showingLogs {
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                            showingLogs = false
                        }
                    }
                
                HStack(spacing: 0) {
                    Spacer()
                    
                    LogView(logManager: logManager, isShowing: $showingLogs)
                        .shadow(color: .black.opacity(0.3), radius: 20, x: -5, y: 0)
                        .transition(.move(edge: .trailing))
                }
                .ignoresSafeArea()
            }
        }
        .alert("Confirm Deletion", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Move to Trash", role: .destructive) {
                deleteSelectedPatterns()
            }
        } message: {
            Text("Are you sure you want to move \(selectedPatterns.count) pattern(s) to trash? This will delete approximately \(calculateSelectedSize()).")
        }
        .sheet(isPresented: $showingDebugView) {
            DebugView()
        }
        .onAppear {
            loadSavedData()
            observability.viewAppeared("ContentView")
        }
        .onChange(of: selectedTab) { _, newTab in
            let tabName: String
            switch newTab {
            case .patternScan: tabName = "PatternScan"
            case .duplicates: tabName = "Duplicates"
            case .privacy: tabName = "Privacy"
            case .diskUsage: tabName = "DiskUsage"
            case .systemData: tabName = "SystemData"
            case .uninstaller: tabName = "Uninstaller"
            case .devProjects: tabName = "DevProjects"
            case .xcodeCleanup: tabName = "XcodeCleanup"
            case .optimizer: tabName = "Optimizer"
            case .cacheAnalyzer: tabName = "CacheAnalyzer"
            case .snapshots: tabName = "Snapshots"
            case .schedule: tabName = "Schedule"
            case .settings: tabName = "Settings"
            }
            observability.tabSelected(tabName)
        }
    }
    
    private func startScan() {
        logManager.log("User initiated scan", level: .info, category: .system)
        observability.buttonTapped("Scan", in: "ContentView")
        selectedPatterns.removeAll()
        
        // Start performance tracking session
        performanceManager.startSession()
        
        // MEMORY OPTIMIZATION: Clear all previous data for fresh scan
        scanner.filePatterns = []
        scanner.discoveredFiles = [] // Free memory from previous scan
        aiService.patterns = []
        
        Task {
            // Set scanning state to true
            scanner.isScanning = true
            logManager.log("Set isScanning = true", level: .debug, category: .system)
            
            // Start background task to update patterns continuously
            let analysisTask = Task {
                await updatePatternsContinuously()
            }
            
            // Scan directories - files are added progressively
            await scanner.scanDirectories()
            logManager.log("Directory scan complete, discovered \(scanner.discoveredFiles.count) files", level: .debug, category: .system)
            
            // Wait for scanning to complete, then cancel analysis task
            analysisTask.cancel()
            
            // Final comprehensive analysis
            if !scanner.discoveredFiles.isEmpty {
                logManager.log("Running final analysis on \(scanner.discoveredFiles.count) files", level: .info, category: .system)
                
                await aiService.analyzeAndGroupFiles(scanner.discoveredFiles)
                
                logManager.log("AIService created \(aiService.patterns.count) patterns", level: .debug, category: .system)
                
                // Update patterns and set scanning to false - ALL IN ONE MainActor block
                await MainActor.run {
                    scanner.filePatterns = aiService.patterns
                    logManager.log("Scanner now has \(scanner.filePatterns.count) patterns", level: .info, category: .system)
                    
                    // CRITICAL: Set isScanning to false AFTER patterns are updated
                    scanner.isScanning = false
                    scanner.scanProgress = 1.0
                    logManager.log("Set isScanning = false (patterns ready)", level: .debug, category: .system)
                }
                
                // Save scan data (before clearing)
                PersistenceManager.shared.saveScanData(
                    files: scanner.discoveredFiles,
                    patterns: scanner.filePatterns
                )
                lastScanDate = PersistenceManager.shared.getScanDataAge()
                
                // MEMORY OPTIMIZATION: Clear discoveredFiles - we only need patterns now
                // This frees up memory (15,000 objects × ~200 bytes = ~3MB)
                scanner.discoveredFiles.removeAll()
                logManager.log("Cleared discoveredFiles to free memory", level: .debug, category: .system)
                
                // MEMORY OPTIMIZATION: Clear AIService patterns - already copied to scanner
                aiService.patterns.removeAll()
                
                logManager.log("Scan complete - UI showing \(scanner.filePatterns.count) patterns", level: .success, category: .system)
            } else {
                logManager.log("No files found during scan", level: .warning, category: .system)
                // Set scanning to false even if no files found
                scanner.isScanning = false
                scanner.scanProgress = 1.0
            }
            
            // End performance tracking session
            performanceManager.endSession()
        }
    }
    
    // MARK: - Incremental Pattern Analysis (Performance Optimization #5)
    
    /// Incrementally analyzes only new files instead of re-analyzing everything
    private func updatePatternsContinuously() async {
        var lastFileCount = 0
        var lastUpdateTime = Date()
        let minUpdateInterval: TimeInterval = 0.5 // Minimum 500ms between updates
        
        while scanner.isScanning {
            let currentFileCount = scanner.discoveredFiles.count
            let timeSinceLastUpdate = Date().timeIntervalSince(lastUpdateTime)
            
            // Only update if we have new files AND enough time has passed
            // This prevents excessive re-analysis and UI updates
            if currentFileCount > lastFileCount && 
               currentFileCount > 0 && 
               timeSinceLastUpdate >= minUpdateInterval {
                
                // Only analyze new files (incremental analysis)
                let newFiles = Array(scanner.discoveredFiles.dropFirst(lastFileCount))
                
                if !newFiles.isEmpty {
                    // Use incremental analysis for better performance
                    await aiService.analyzeIncrementally(newFiles: newFiles, existingPatterns: aiService.patterns)
                    
                    // Ensure UI update happens on main actor
                    await MainActor.run {
                        scanner.filePatterns = aiService.patterns
                    }
                }
                
                lastFileCount = currentFileCount
                lastUpdateTime = Date()
            }
            
            // Adaptive sleep - check less frequently if no changes
            let sleepTime: UInt64 = currentFileCount == lastFileCount ? 500_000_000 : 200_000_000
            try? await Task.sleep(nanoseconds: sleepTime)
        }
    }
    
    private func loadSavedData() {
        logManager.log("Checking for saved scan data", level: .info, category: .system)
        
        if let savedData = PersistenceManager.shared.loadScanData() {
            scanner.discoveredFiles = savedData.files
            scanner.filePatterns = savedData.patterns
            aiService.patterns = savedData.patterns
            lastScanDate = PersistenceManager.shared.getScanDataAge()
            
            logManager.log("Loaded \(savedData.patterns.count) patterns from previous scan", level: .success, category: .system)
        } else {
            logManager.log("No saved data found - please run a scan", level: .info, category: .system)
        }
    }
    
    private func calculateSelectedSize() -> String {
        let totalBytes = scanner.filePatterns
            .filter { selectedPatterns.contains($0.id) }
            .reduce(0) { $0 + $1.totalSize }
        return ByteCountFormatter.string(fromByteCount: Int64(totalBytes), countStyle: .file)
    }
    
    private func deleteSelectedPatterns() {
        logManager.log("User confirmed deletion of \(selectedPatterns.count) pattern(s)", level: .info, category: .deletion)
        Task {
            // Performance tracking: Start deletion
            let deletionStartTime = Date()
            var successCount = 0
            var failureCount = 0
            var totalBytesFreed: Int64 = 0
            var totalFilesDeleted = 0
            
            let patternsToDelete = scanner.filePatterns.filter { selectedPatterns.contains($0.id) }
            
            for pattern in patternsToDelete {
                let bytesBefore = Int64(pattern.totalSize)
                let filesBefore = pattern.count
                
                let result = await scanner.moveToTrash(pattern: pattern)
                
                // Track success/failure from actual deletion results
                successCount += result.successCount
                failureCount += result.failureCount
                totalBytesFreed += bytesBefore
                totalFilesDeleted += filesBefore
            }
            
            // Performance tracking: Record deletion metrics
            let deletionDuration = Date().timeIntervalSince(deletionStartTime)
            await performanceManager.recordDeletionMetrics(
                patternsDeleted: patternsToDelete.count,
                filesDeleted: totalFilesDeleted,
                bytesFreed: totalBytesFreed,
                duration: deletionDuration,
                successCount: successCount,
                failureCount: failureCount
            )
            
            selectedPatterns.removeAll()
            
            logManager.log("Starting rescan after deletion", level: .info, category: .system)
            
            // Set scanning state
            scanner.isScanning = true
            
            // Rescan after deletion
            await scanner.scanDirectories()
            
            if !scanner.discoveredFiles.isEmpty {
                await aiService.analyzeAndGroupFiles(scanner.discoveredFiles)
                
                // Update patterns and set scanning to false
                await MainActor.run {
                    scanner.filePatterns = aiService.patterns
                    scanner.isScanning = false
                    scanner.scanProgress = 1.0
                }
                
                // Save updated data (before clearing)
                PersistenceManager.shared.saveScanData(
                    files: scanner.discoveredFiles,
                    patterns: scanner.filePatterns
                )
                
                // MEMORY OPTIMIZATION: Clear temporary data
                scanner.discoveredFiles.removeAll()
                aiService.patterns.removeAll()
                lastScanDate = PersistenceManager.shared.getScanDataAge()
            } else {
                scanner.isScanning = false
                scanner.scanProgress = 1.0
            }
        }
    }
}

// MARK: - Header View with Tabs
struct HeaderViewWithTabs: View {
    @Binding var selectedTab: ContentView.TabSelection
    @StateObject private var memoryMonitor = MemoryMonitor.shared
    @StateObject private var healthManager = HealthScoreManager.shared
    @State private var showingHealthDetail = false
    let isScanning: Bool
    let onScan: () -> Void
    let onShowLogs: () -> Void
    let onShowDebug: () -> Void
    let logCount: Int
    let hasNewLogs: Bool
    let lastScanDate: String?

    var body: some View {
        VStack(spacing: 0) {
            // Top row with title and actions
            HStack {
                Image(systemName: "sparkles")
                    .font(.title2)
                    .foregroundStyle(.blue)

                VStack(alignment: .leading, spacing: 2) {
                    Text("AI File Cleaner")
                        .font(.title2)
                        .fontWeight(.semibold)

                    if let lastScan = lastScanDate, selectedTab == .patternScan {
                        Text("Last scan: \(lastScan)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Spacer()

                // Health Score Badge (clickable for details)
                Button(action: { showingHealthDetail = true }) {
                    HealthScoreBadge(healthManager: healthManager)
                }
                .buttonStyle(.plain)
                .sheet(isPresented: $showingHealthDetail) {
                    HealthScoreDetailView(healthManager: healthManager)
                }

                // Live Memory Usage Display
                HStack(spacing: 6) {
                    Image(systemName: "memorychip")
                        .font(.caption2)
                        .foregroundStyle(memoryMonitor.memoryPressure.color)

                    VStack(alignment: .trailing, spacing: 1) {
                        Text(memoryMonitor.formattedAppMemory())
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundStyle(memoryMonitor.memoryPressure.color)

                        Text("\(String(format: "%.0f", memoryMonitor.memoryUsagePercent()))%")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }

                    // Memory pressure indicator
                    Circle()
                        .fill(memoryMonitor.memoryPressure.color)
                        .frame(width: 6, height: 6)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(memoryMonitor.memoryPressure.color.opacity(0.1))
                .cornerRadius(6)
                .help("App: \(memoryMonitor.formattedAppMemory()) | System: \(memoryMonitor.formattedUsedMemory()) / \(memoryMonitor.formattedPhysicalMemory())")
                
                // Logs Button
                Button(action: onShowLogs) {
                    HStack(spacing: 6) {
                        Image(systemName: "doc.text.fill")
                        Text("Logs")
                        if logCount > 0 {
                            Text("\(logCount)")
                                .font(.caption2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(hasNewLogs ? Color.green : Color.secondary)
                                .cornerRadius(8)
                        }
                    }
                }
                .buttonStyle(.bordered)
                .help("View activity logs")

                // Debug Button
                Button(action: onShowDebug) {
                    Image(systemName: "ant.circle.fill")
                }
                .buttonStyle(.bordered)
                .help("Debug Monitor")

                if selectedTab == .patternScan {
                    Button(action: onScan) {
                        Label(isScanning ? "Scanning..." : "Scan for Files", systemImage: "magnifyingglass")
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isScanning)
                }
            }
            .padding()
            .onAppear {
                // Start memory monitoring when header appears
                memoryMonitor.startMonitoring()
                // Start health monitoring
                healthManager.startMonitoring(interval: 5.0)
            }
            
            // Tab Selection
            HStack(spacing: 0) {
                TabButton(
                    title: "Pattern Scan",
                    icon: "magnifyingglass",
                    isSelected: selectedTab == .patternScan
                ) {
                    selectedTab = .patternScan
                }

                TabButton(
                    title: "Duplicates",
                    icon: "doc.on.doc.fill",
                    isSelected: selectedTab == .duplicates
                ) {
                    selectedTab = .duplicates
                }

                TabButton(
                    title: "Privacy",
                    icon: "hand.raised.fill",
                    isSelected: selectedTab == .privacy
                ) {
                    selectedTab = .privacy
                }

                TabButton(
                    title: "Disk Usage",
                    icon: "internaldrive.fill",
                    isSelected: selectedTab == .diskUsage
                ) {
                    selectedTab = .diskUsage
                }

                TabButton(
                    title: "System Data",
                    icon: "externaldrive.fill.badge.icloud",
                    isSelected: selectedTab == .systemData
                ) {
                    selectedTab = .systemData
                }

                TabButton(
                    title: "Uninstaller",
                    icon: "trash.slash.fill",
                    isSelected: selectedTab == .uninstaller
                ) {
                    selectedTab = .uninstaller
                }

                TabButton(
                    title: "Dev Projects",
                    icon: "hammer.fill",
                    isSelected: selectedTab == .devProjects
                ) {
                    selectedTab = .devProjects
                }

                TabButton(
                    title: "Xcode",
                    icon: "hammer.circle.fill",
                    isSelected: selectedTab == .xcodeCleanup
                ) {
                    selectedTab = .xcodeCleanup
                }

                TabButton(
                    title: "Optimizer",
                    icon: "bolt.fill",
                    isSelected: selectedTab == .optimizer
                ) {
                    selectedTab = .optimizer
                }

                TabButton(
                    title: "Caches",
                    icon: "chart.bar.doc.horizontal",
                    isSelected: selectedTab == .cacheAnalyzer
                ) {
                    selectedTab = .cacheAnalyzer
                }

                TabButton(
                    title: "Snapshots",
                    icon: "camera.on.rectangle",
                    isSelected: selectedTab == .snapshots
                ) {
                    selectedTab = .snapshots
                }

                TabButton(
                    title: "Schedule",
                    icon: "calendar.badge.clock",
                    isSelected: selectedTab == .schedule
                ) {
                    selectedTab = .schedule
                }

                TabButton(
                    title: "Settings",
                    icon: "chart.line.uptrend.xyaxis",
                    isSelected: selectedTab == .settings
                ) {
                    selectedTab = .settings
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Tab Button
struct TabButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                Text(title)
            }
            .font(.subheadline)
            .fontWeight(isSelected ? .semibold : .regular)
            .foregroundStyle(isSelected ? .primary : .secondary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(isSelected ? Color.accentColor.opacity(0.1) : Color.clear)
            .cornerRadius(6)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Pattern Scan Content View
struct PatternScanContentView: View {
    @ObservedObject var scanner: FileScanner
    @ObservedObject var aiService: AIService
    @Binding var selectedPatterns: Set<String>
    let searchQuery: String
    @Binding var showingDeleteConfirmation: Bool
    let onDelete: () -> Void
    let calculateSelectedSize: () -> String
    
    var body: some View {
        VStack(spacing: 0) {
            // Main Content Area
            if scanner.isScanning {
                // Show scan dashboard during scanning
                ScanDashboardView(scanner: scanner)
            } else if scanner.filePatterns.isEmpty {
                EmptyStateView()
            } else {
                HSplitView {
                    // File Patterns List
                    FilePatternListView(
                        patterns: scanner.filePatterns,
                        selectedPatterns: $selectedPatterns,
                        searchQuery: searchQuery
                    )
                    .frame(minWidth: 400)
                    
                    // AI Assistant Sidebar
                    AIAssistantView(
                        aiService: aiService,
                        scanner: scanner,
                        selectedPatterns: $selectedPatterns
                    )
                    .frame(minWidth: 300, idealWidth: 350, maxWidth: 500)
                }
            }
            
            Divider()
            
            // Footer Actions
            FooterView(
                selectedCount: selectedPatterns.count,
                totalSize: calculateSelectedSize(),
                onDelete: {
                    showingDeleteConfirmation = true
                },
                onClear: {
                    selectedPatterns.removeAll()
                }
            )
        }
    }
}

// MARK: - Header View (kept for compatibility)
struct HeaderView: View {
    let isScanning: Bool
    let onScan: () -> Void
    let onShowLogs: () -> Void
    let logCount: Int
    let hasNewLogs: Bool
    let lastScanDate: String?
    
    var body: some View {
        HStack {
            Image(systemName: "sparkles")
                .font(.title2)
                .foregroundStyle(.blue)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("AI File Cleaner")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                if let lastScan = lastScanDate {
                    Text("Last scan: \(lastScan)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            
            Spacer()
            
            // Logs Button
            Button(action: onShowLogs) {
                HStack(spacing: 6) {
                    Image(systemName: "doc.text.fill")
                    Text("Logs")
                    if logCount > 0 {
                        Text("\(logCount)")
                            .font(.caption2)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(hasNewLogs ? Color.green : Color.secondary)
                            .cornerRadius(8)
                    }
                }
            }
            .buttonStyle(.bordered)
            .help("View activity logs")
            
            Button(action: onScan) {
                Label(isScanning ? "Scanning..." : "Scan for Files", systemImage: "magnifyingglass")
            }
            .buttonStyle(.borderedProminent)
            .disabled(isScanning)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Empty State
struct EmptyStateView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "doc.text.magnifyingglass")
                .font(.system(size: 64))
                .foregroundStyle(.secondary)
            
            Text("No Files Scanned")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Click 'Scan for Files' to start analyzing your system for temporary and build files.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .frame(maxWidth: 400)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Loading View
struct LoadingView: View {
    var body: some View {
        VStack(spacing: 20) {
            ProgressView()
                .scaleEffect(1.5)
            
            Text("Scanning directories and analyzing with AI...")
                .font(.headline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Footer View
struct FooterView: View {
    let selectedCount: Int
    let totalSize: String
    let onDelete: () -> Void
    let onClear: () -> Void
    
    var body: some View {
        HStack {
            if selectedCount > 0 {
                Text("\(selectedCount) pattern(s) selected • \(totalSize)")
                    .font(.callout)
                    .foregroundStyle(.secondary)
                
                Spacer()
                
                Button("Clear Selection", action: onClear)
                    .buttonStyle(.plain)
                
                Button(action: onDelete) {
                    Label("Move to Trash", systemImage: "trash")
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
            } else {
                Text("Select patterns to delete")
                    .font(.callout)
                    .foregroundStyle(.secondary)
                
                Spacer()
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

#Preview {
    ContentView()
}

