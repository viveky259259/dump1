import SwiftUI
import AppKit
import Charts

// MARK: - Chart Type
enum StorageChartType: String, CaseIterable {
    case donut = "Donut"
    case bar = "Bar"
    
    var icon: String {
        switch self {
        case .donut: return "chart.pie.fill"
        case .bar: return "chart.bar.fill"
        }
    }
}

// MARK: - Storage Chart View
struct StorageChartView: View {
    let categories: [StorageCategory]
    @State private var selectedCategory: StorageCategory?
    @State private var chartType: StorageChartType = .donut
    @State private var hoveredItem: String?

    // Actual disk info
    private var diskInfo: (total: Int64, free: Int64) {
        let fm = FileManager.default
        do {
            let attrs = try fm.attributesOfFileSystem(forPath: "/")
            let total = attrs[.systemSize] as? Int64 ?? 0
            let free = attrs[.systemFreeSize] as? Int64 ?? 0
            return (total, free)
        } catch {
            return (0, 0)
        }
    }

    private var diskCapacity: Int64 { diskInfo.total }
    private var diskFree: Int64 { diskInfo.free }
    private var diskUsed: Int64 { diskCapacity - diskFree }

    /// Sum of scanned category sizes (may exceed disk used due to overlaps)
    private var categoriesSum: Int64 {
        categories.reduce(0) { $0 + max($1.size, 0) }
    }

    /// The reference total for the chart — use actual disk capacity
    private var totalSize: Int64 { diskCapacity }

    private var chartData: [ChartDataItem] {
        // Filter out zero-size categories and sort by size
        let filtered = categories.filter { $0.size > 0 }
            .sorted { $0.size > $1.size }

        var items: [ChartDataItem] = []

        // Take top 7 categories, group rest as "Other"
        if filtered.count <= 7 {
            items = filtered.enumerated().map { index, category in
                ChartDataItem(
                    id: category.id,
                    name: category.name,
                    size: category.size,
                    color: chartColor(for: index)
                )
            }
        } else {
            items = filtered.prefix(6).enumerated().map { index, category in
                ChartDataItem(
                    id: category.id,
                    name: category.name,
                    size: category.size,
                    color: chartColor(for: index)
                )
            }

            let otherSize = filtered.dropFirst(6).reduce(0) { $0 + $1.size }
            items.append(ChartDataItem(
                id: "other",
                name: "Other",
                size: otherSize,
                color: .gray
            ))
        }

        // Add free space slice
        if diskFree > 0 {
            items.append(ChartDataItem(
                id: "free_space",
                name: "Free Space",
                size: diskFree,
                color: Color(NSColor.separatorColor).opacity(0.3)
            ))
        }

        return items
    }
    
    private func chartColor(for index: Int) -> Color {
        let colors: [Color] = [
            .blue, .green, .orange, .purple, .pink, .cyan, .yellow, .red
        ]
        return colors[index % colors.count]
    }
    
    var body: some View {
        VStack(spacing: 16) {
            // Chart Header
            HStack {
                Image(systemName: chartType.icon)
                    .foregroundStyle(.blue)
                Text("Storage Distribution")
                    .font(.headline)
                
                Spacer()
                
                // Chart Type Picker
                Picker("Chart Type", selection: $chartType) {
                    ForEach(StorageChartType.allCases, id: \.self) { type in
                        Label(type.rawValue, systemImage: type.icon)
                            .tag(type)
                    }
                }
                .pickerStyle(.segmented)
                .frame(width: 120)
                
                Text("\(formatSize(diskUsed)) used of \(formatSize(diskCapacity))")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .padding(.leading, 8)
            }
            
            if totalSize == 0 {
                // Empty state
                VStack(spacing: 8) {
                    Image(systemName: "chart.pie")
                        .font(.system(size: 40))
                        .foregroundStyle(.secondary)
                    Text("No data to display")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .frame(height: 200)
            } else {
                switch chartType {
                case .donut:
                    donutChartView
                case .bar:
                    barChartView
                }
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
        .animation(.easeInOut(duration: 0.3), value: chartType)
    }
    
    // MARK: - Donut Chart View
    private var donutChartView: some View {
        HStack(alignment: .center, spacing: 24) {
            // Donut Chart
            ZStack {
                Chart(chartData) { item in
                    SectorMark(
                        angle: .value("Size", item.size),
                        innerRadius: .ratio(0.6),
                        angularInset: 1.5
                    )
                    .foregroundStyle(item.color)
                    .cornerRadius(4)
                    .opacity(hoveredItem == nil || hoveredItem == item.id ? 1.0 : 0.4)
                }
                .chartLegend(.hidden)
                .frame(width: 180, height: 180)
                
                // Center text
                VStack(spacing: 2) {
                    if let hovered = hoveredItem,
                       let item = chartData.first(where: { $0.id == hovered }) {
                        Text(item.name)
                            .font(.caption)
                            .fontWeight(.medium)
                            .lineLimit(1)
                        Text(formatSize(item.size))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Text(percentageString(item.size))
                            .font(.caption2)
                            .foregroundStyle(.blue)
                    } else {
                        Text("Disk")
                            .font(.caption)
                            .fontWeight(.medium)
                        Text(formatSize(diskCapacity))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Text("\(formatSize(diskFree)) free")
                            .font(.caption2)
                            .foregroundStyle(.green)
                    }
                }
                .frame(width: 80)
            }
            
            // Legend
            legendView
        }
    }
    
    // MARK: - Bar Chart View
    private var barChartView: some View {
        VStack(spacing: 12) {
            Chart(chartData) { item in
                BarMark(
                    x: .value("Size", item.size),
                    y: .value("Category", item.name)
                )
                .foregroundStyle(item.color)
                .cornerRadius(4)
                .opacity(hoveredItem == nil || hoveredItem == item.id ? 1.0 : 0.5)
                .annotation(position: .trailing, alignment: .leading, spacing: 4) {
                    Text(formatSize(item.size))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .chartXAxis {
                AxisMarks(position: .bottom) { value in
                    AxisGridLine()
                    AxisValueLabel {
                        if let bytes = value.as(Int64.self) {
                            Text(formatSizeCompact(bytes))
                                .font(.caption2)
                        }
                    }
                }
            }
            .chartYAxis {
                AxisMarks(position: .leading) { _ in
                    AxisValueLabel()
                }
            }
            .frame(height: CGFloat(chartData.count) * 32 + 40)
        }
    }
    
    // MARK: - Legend View
    private var legendView: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(chartData) { item in
                HStack(spacing: 8) {
                    Circle()
                        .fill(item.color)
                        .frame(width: 10, height: 10)
                    
                    Text(item.name)
                        .font(.caption)
                        .lineLimit(1)
                    
                    Spacer()
                    
                    Text(formatSize(item.size))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    Text(percentageString(item.size))
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                        .frame(width: 40, alignment: .trailing)
                }
                .padding(.vertical, 2)
                .padding(.horizontal, 6)
                .background(
                    RoundedRectangle(cornerRadius: 4)
                        .fill(hoveredItem == item.id ? Color.accentColor.opacity(0.1) : Color.clear)
                )
                .onHover { isHovering in
                    hoveredItem = isHovering ? item.id : nil
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    // MARK: - Helpers
    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
    
    private func formatSizeCompact(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowedUnits = [.useGB, .useMB]
        formatter.zeroPadsFractionDigits = false
        return formatter.string(fromByteCount: bytes)
    }
    
    private func percentageString(_ size: Int64) -> String {
        guard totalSize > 0 else { return "0%" }
        let percentage = Double(size) / Double(totalSize) * 100
        return String(format: "%.1f%%", percentage)
    }
}

// MARK: - Chart Data Item
struct ChartDataItem: Identifiable {
    let id: String
    let name: String
    let size: Int64
    let color: Color
}

struct DiskUsageView: View {
    @StateObject private var scanner = DiskScanner()
    @StateObject private var logManager = LogManager.shared
    @StateObject private var sizeCalculationManager = SizeCalculationManager.shared
    @State private var selectedItems: Set<String> = [] // Use path as identifier
    @State private var navigationPath: [StorageItem] = []
    @State private var showingDeleteConfirmation = false
    @State private var showingDeletionProgress = false
    @State private var deletionCurrentItem = 0
    @State private var deletionCurrentItemName = ""
    @State private var deletionIsCompleted = false
    @State private var deletionSuccessCount = 0
    @State private var deletionFailedCount = 0
    @State private var deletionTotalItems = 0
    @State private var loadingItems: Set<String> = []
    @State private var allItems: [String: StorageItem] = [:] // Track all items by path
    @State private var sortOrder: SortOrder = .sizeDescending
    @State private var lastScanDate: String?
    
    enum SortOrder: String, CaseIterable {
        case sizeDescending = "Size (Largest)"
        case sizeAscending = "Size (Smallest)"
        case nameAscending = "Name (A-Z)"
        case nameDescending = "Name (Z-A)"
        case typeFirst = "Type (Folders First)"
    }
    
    var sortedCategories: [StorageCategory] {
        var result = scanner.categories
        switch sortOrder {
        case .sizeDescending:
            result.sort { $0.size > $1.size }
        case .sizeAscending:
            result.sort { $0.size < $1.size }
        case .nameAscending:
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case .nameDescending:
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedDescending }
        case .typeFirst:
            // Categories are all directories, so just sort by name
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        }
        return result
    }
    
    var body: some View {
        NavigationStack(path: $navigationPath) {
            VStack(spacing: 0) {
                // Header
                DiskUsageHeaderView(
                    isScanning: scanner.isScanning,
                    progress: scanner.scanProgress,
                    lastScanDate: lastScanDate,
                    onScan: {
                        Task {
                            await scanner.scanTopLevelCategories()
                            lastScanDate = PersistenceManager.shared.getDiskUsageDataAge()
                        }
                    }
                )
                
                Divider()
                
                // Sort Controls
                if !scanner.categories.isEmpty {
                    HStack {
                        Text("Sort by:")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        
                        Picker("Sort", selection: $sortOrder) {
                            ForEach(SortOrder.allCases, id: \.self) { order in
                                Text(order.rawValue).tag(order)
                            }
                        }
                        .pickerStyle(.menu)
                        .frame(width: 180)
                        
                        Spacer()
                        
                        // Refresh Categories Button
                        Button(action: {
                            Task {
                                await scanner.scanTopLevelCategories()
                                lastScanDate = PersistenceManager.shared.getDiskUsageDataAge()
                                // Clear allItems after refresh
                                allItems.removeAll()
                            }
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: "arrow.clockwise")
                                Text("Refresh")
                            }
                            .font(.caption)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        .disabled(scanner.isScanning)
                        .help("Refresh all categories and recalculate sizes")
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .background(Color(NSColor.controlBackgroundColor).opacity(0.5))
                    
                    Divider()
                }
                
                // Content
                if scanner.isScanning {
                    ProgressView(value: scanner.scanProgress) {
                        Text("Scanning disk storage...")
                            .font(.headline)
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if scanner.categories.isEmpty {
                    EmptyDiskUsageView(onScan: {
                        Task {
                            await scanner.scanTopLevelCategories()
                        }
                    })
                } else {
                    ScrollView {
                        VStack(spacing: 0) {
                            // Storage Chart
                            StorageChartView(categories: scanner.categories)
                                .padding()
                            
                            Divider()
                            
                            // Categories List
                            LazyVStack(spacing: 0) {
                                ForEach(sortedCategories) { category in
                                    StorageCategoryRow(
                                        category: category,
                                        isSelected: false, // Categories not selectable directly
                                        onSelect: { },
                                        onNavigate: {
                                            // Navigate to category detail
                                            let destinationPath = category.name == "System Data"
                                                ? DiskScanner.systemDataVirtualPath
                                                : category.path
                                            let categoryItem = StorageItem(
                                                path: destinationPath,
                                                name: category.name,
                                                size: category.size,
                                                isDirectory: true,
                                                iconName: category.iconName
                                            )
                                            navigationPath.append(categoryItem)
                                            
                                            // Set current folder for size calculation prioritization
                                            sizeCalculationManager.setCurrentOpenFolder(destinationPath)
                                        }
                                    )
                                    .padding(.horizontal)
                                    .padding(.vertical, 4)
                                    
                                    if category.id != sortedCategories.last?.id {
                                        Divider()
                                            .padding(.leading, 54)
                                    }
                                }
                            }
                            .padding(.vertical, 8)
                        }
                    }
                }
                
                Divider()
                
                // Footer
                DiskUsageFooterView(
                    selectedCount: selectedItems.count,
                    totalSize: calculateSelectedSize(),
                    onDelete: {
                        showingDeleteConfirmation = true
                    },
                    onClear: {
                        selectedItems.removeAll()
                    }
                )
            }
            .navigationDestination(for: StorageItem.self) { item in
                StorageItemDetailView(
                    item: item,
                    scanner: scanner,
                    selectedItems: $selectedItems,
                    navigationPath: $navigationPath,
                    loadingItems: $loadingItems,
                    allItems: $allItems
                )
                .onAppear {
                    // Set current folder when navigating to it
                    sizeCalculationManager.setCurrentOpenFolder(item.path)
                }
                .onDisappear {
                    // Cancel calculations when leaving folder
                    sizeCalculationManager.cancelCalculations(for: item.path)
                }
            }
            .onChange(of: navigationPath.count) { oldCount, newCount in
                // When going back (path count decreases), cancel calculations for closed folders
                if newCount < oldCount {
                    // Find which folder was closed
                    // Note: navigationPath is updated by SwiftUI, so we need to track previous path
                    // For simplicity, we'll cancel calculations for folders not in current path
                    let currentPaths = Set(navigationPath.map { $0.path })
                    // This is a simplified approach - in a real implementation, we'd track the previous path
                }
            }
        }
        .alert("Confirm Deletion", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Move to Trash", role: .destructive) {
                deleteSelectedItems()
            }
        } message: {
            let count = selectedItems.count
            let size = calculateSelectedSize()
            Text("Are you sure you want to move \(count) item\(count == 1 ? "" : "s") (\(size)) to trash?\n\nThis action will move the items to your Trash where they can be recovered.")
        }
        .sheet(isPresented: $showingDeletionProgress) {
            DeletionProgressView(
                totalItems: $deletionTotalItems,
                currentItem: $deletionCurrentItem,
                currentItemName: $deletionCurrentItemName,
                isCompleted: $deletionIsCompleted,
                successCount: $deletionSuccessCount,
                failedCount: $deletionFailedCount
            )
            .interactiveDismissDisabled(!deletionIsCompleted)
        }
        .onAppear {
            loadSavedData()
            loadNavigationPath()
        }
        .onDisappear {
            // Save navigation path when view disappears (e.g., switching tabs)
            saveNavigationPath()
        }
        .onChange(of: navigationPath) { oldPath, newPath in
            // Save navigation path whenever it changes
            saveNavigationPath()
            
            // Update size calculation manager with current folder
            if let currentFolder = newPath.last {
                sizeCalculationManager.setCurrentOpenFolder(currentFolder.path)
            } else {
                // If navigation path is empty, clear current folder
                sizeCalculationManager.setCurrentOpenFolder(nil)
            }
        }
    }
    
    private func calculateSelectedSize() -> String {
        let totalBytes = selectedItems.compactMap { path -> Int64 in
            let size = allItems[path]?.size ?? 0
            return max(size, 0)
        }.reduce(Int64(0), +)
        return ByteCountFormatter.string(fromByteCount: totalBytes, countStyle: .file)
    }
    
    private func loadSavedData() {
        if let savedData = PersistenceManager.shared.loadDiskUsageData() {
            scanner.categories = savedData.categories
            lastScanDate = PersistenceManager.shared.getDiskUsageDataAge()
            logManager.log("Loaded \(savedData.categories.count) categories from saved data", level: .success, category: .system)
        } else {
            logManager.log("No saved disk usage data found", level: .info, category: .system)
        }
        
        // Clear allItems when loading fresh data to prevent accumulation
        allItems.removeAll()
    }
    
    private func loadNavigationPath() {
        guard let savedPath = PersistenceManager.shared.loadNavigationPath(), !savedPath.isEmpty else {
            return
        }
        
        // Restore navigation path
        navigationPath = savedPath
        
        // Set current folder for size calculation prioritization
        if let currentFolder = savedPath.last {
            sizeCalculationManager.setCurrentOpenFolder(currentFolder.path)
        }
        
        logManager.log("Restored navigation path with \(savedPath.count) items", level: .info, category: .system)
    }
    
    private func saveNavigationPath() {
        // Only save if navigation path is not empty
        guard !navigationPath.isEmpty else {
            return
        }
        
        PersistenceManager.shared.saveNavigationPath(navigationPath)
    }
    
    private func deleteSelectedItems() {
        let selectedPaths = Array(selectedItems)
        
        Task {
            // Collect items to delete
            var itemsToDelete: [StorageItem] = []
            for path in selectedPaths {
                if let item = allItems[path] {
                    itemsToDelete.append(item)
                }
            }

            // Initialize progress
            await MainActor.run {
                deletionTotalItems = itemsToDelete.count
                deletionCurrentItem = 0
                deletionCurrentItemName = ""
                deletionIsCompleted = false
                deletionSuccessCount = 0
                deletionFailedCount = 0
                showingDeletionProgress = true
            }
            
            // Delete items one by one with progress updates
            var successPaths: [String] = []
            
            for (index, item) in itemsToDelete.enumerated() {
                await MainActor.run {
                    deletionCurrentItem = index + 1
                    deletionCurrentItemName = item.name
                }
                
            do {
                // Try to delete using privileged file manager (handles permissions automatically)
                try await PrivilegedFileManager.shared.deleteItem(at: item.path)
                successPaths.append(item.path)
                
                await MainActor.run {
                    deletionSuccessCount += 1
                }
                
                LogManager.shared.log("Moved to trash: \(item.path)", level: .success, category: .deletion)
            } catch {
                await MainActor.run {
                    deletionFailedCount += 1
                }
                
                let errorMsg = (error as NSError).localizedDescription
                LogManager.shared.log("❌ Failed to delete \(item.path): \(errorMsg)", level: .error, category: .deletion)
            }
                
                // Small delay to show progress
                try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 second
            }
            
            // Mark as completed
            await MainActor.run {
                deletionIsCompleted = true
            }
            
            // Wait a moment to show results
            try? await Task.sleep(nanoseconds: 1_500_000_000) // 1.5 seconds
            
            // Update UI
            await MainActor.run {
                showingDeletionProgress = false
                selectedItems.removeAll()
                for path in successPaths {
                    allItems.removeValue(forKey: path)
                }
            }
            
            // Refresh scan to update categories and sizes
            LogManager.shared.log("Refreshing disk usage view...", level: .info, category: .system)
            await scanner.scanTopLevelCategories()
            
            await MainActor.run {
                lastScanDate = PersistenceManager.shared.getDiskUsageDataAge()
                // Clear allItems after refresh to prevent accumulation
                allItems.removeAll()
            }
        }
    }

}

// MARK: - Header View
struct DiskUsageHeaderView: View {
    let isScanning: Bool
    let progress: Double
    let lastScanDate: String?
    let onScan: () -> Void
    
    var body: some View {
        HStack {
            Image(systemName: "internaldrive.fill")
                .font(.title2)
                .foregroundStyle(.blue)
            
            VStack(alignment: .leading, spacing: 2) {
                Text("Disk Usage")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                if let lastScan = lastScanDate {
                    Text("Last scan: \(lastScan)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Text("Browse and manage disk storage")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            
            Spacer()
            
            if isScanning {
                ProgressView(value: progress)
                    .frame(width: 200)
            }
            
            Button(action: onScan) {
                Label(isScanning ? "Scanning..." : "Scan Disk", systemImage: "magnifyingglass")
            }
            .buttonStyle(.borderedProminent)
            .disabled(isScanning)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Empty State
struct EmptyDiskUsageView: View {
    let onScan: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "internaldrive")
                .font(.system(size: 64))
                .foregroundStyle(.secondary)
            
            Text("No Disk Scan")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Click 'Scan Disk' to analyze your disk storage.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .frame(maxWidth: 400)
            
            Button(action: onScan) {
                Label("Scan Disk", systemImage: "magnifyingglass")
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Category Row
struct StorageCategoryRow: View {
    let category: StorageCategory
    let isSelected: Bool
    let onSelect: () -> Void
    let onNavigate: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // Icon
            Image(systemName: category.iconName)
                .font(.title2)
                .foregroundStyle(.blue)
                .frame(width: 30)
            
            // Name
            Text(category.name)
                .font(.headline)
            
            Spacer()
            
            // Size
            if category.size == -2 {
                HStack(spacing: 4) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                    Text("Unable to calculate")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else {
                Text(formatSize(max(category.size, 0)))
                    .font(.body)
                    .foregroundStyle(.secondary)
            }
            
            // Info button (optional)
            Button(action: {}) {
                Image(systemName: "info.circle")
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
            .help("View details")
            
            // Chevron for navigation
            Button(action: onNavigate) {
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            onNavigate()
        }
        .contextMenu {
            Button(action: {
                openInFinder(category.path)
            }) {
                Label("Open in Finder", systemImage: "folder")
            }
            
            Button(action: {
                onNavigate()
            }) {
                Label("Open", systemImage: "arrow.right.circle")
            }
        }
    }
    
    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
    
    private func openInFinder(_ path: String) {
        NSWorkspace.shared.selectFile(path, inFileViewerRootedAtPath: "")
        LogManager.shared.log("Opened in Finder: \(path)", level: .info, category: .general)
    }
}

// MARK: - Storage Item Detail View
struct StorageItemDetailView: View {
    let item: StorageItem
    @ObservedObject var scanner: DiskScanner
    @Binding var selectedItems: Set<String>
    @Binding var navigationPath: [StorageItem]
    @Binding var loadingItems: Set<String>
    @Binding var allItems: [String: StorageItem]
    @StateObject private var sizeCalculationManager = SizeCalculationManager.shared
    @State private var children: [StorageItem] = []
    @State private var isLoading = false
    @State private var sortOrder: ItemSortOrder = .sizeDescending
    @State private var showingDeleteConfirmation = false
    @State private var showingDeletionProgress = false
    @State private var deletionCurrentItem = 0
    @State private var deletionCurrentItemName = ""
    @State private var deletionIsCompleted = false
    @State private var deletionSuccessCount = 0
    @State private var deletionFailedCount = 0
    @State private var deletionTotalItems = 0
    
    enum ItemSortOrder: String, CaseIterable {
        case sizeDescending = "Size (Largest)"
        case sizeAscending = "Size (Smallest)"
        case nameAscending = "Name (A-Z)"
        case nameDescending = "Name (Z-A)"
        case typeFirst = "Type (Folders First)"
    }
    
    var sortedChildren: [StorageItem] {
        var result = children
        switch sortOrder {
        case .sizeDescending:
            result.sort { $0.size > $1.size }
        case .sizeAscending:
            result.sort { $0.size < $1.size }
        case .nameAscending:
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case .nameDescending:
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedDescending }
        case .typeFirst:
            result.sort { item1, item2 in
                // Folders first, then files
                if item1.isDirectory != item2.isDirectory {
                    return item1.isDirectory && !item2.isDirectory
                }
                // Within same type, sort by size descending
                if item1.size != item2.size {
                    return item1.size > item2.size
                }
                // Then by name
                return item1.name.localizedCaseInsensitiveCompare(item2.name) == .orderedAscending
            }
        }
        return result
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Image(systemName: item.iconName)
                    .font(.title)
                    .foregroundStyle(.blue)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.name)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text(item.path)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                Text(formatSize(item.size))
                    .font(.headline)
                    .foregroundStyle(.secondary)
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            
            Divider()
            
            // Sort Controls
            if !children.isEmpty {
                HStack {
                    Text("Sort by:")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    Picker("Sort", selection: $sortOrder) {
                        ForEach(ItemSortOrder.allCases, id: \.self) { order in
                            Text(order.rawValue).tag(order)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(width: 180)

                    Button(action: {
                        toggleSelectAllInView()
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: allItemsSelectedInView() ? "checkmark.square.fill" : "checkmark.square")
                            Text(allItemsSelectedInView() ? "Deselect All" : "Select All")
                        }
                        .font(.caption)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    
                    Spacer()
                    
                    // Refresh Folder Button
                    Button(action: {
                        Task {
                            await refreshCurrentFolder()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.clockwise")
                            Text("Refresh")
                        }
                        .font(.caption)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    .disabled(isLoading)
                    .help("Refresh folder contents and recalculate sizes")
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(NSColor.controlBackgroundColor).opacity(0.5))
                
                Divider()
            }
            
            // Items List
            if isLoading {
                ProgressView("Loading...")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if children.isEmpty {
                Text("No items found")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(sortedChildren) { child in
                        StorageItemRow(
                            item: child,
                            isSelected: selectedItems.contains(child.path),
                            isLoading: loadingItems.contains(child.path),
                            onSelect: {
                                toggleSelection(child)
                            },
                            onNavigate: {
                                if child.isDirectory {
                                    navigationPath.append(child)
                                    // Set current folder for size calculation prioritization
                                    sizeCalculationManager.setCurrentOpenFolder(child.path)
                                }
                            }
                        )
                    }
                }
                .listStyle(.inset(alternatesRowBackgrounds: true))
            }
            
            Divider()
            
            // Footer with delete button
            StorageItemFooterView(
                selectedCount: selectedItemsInThisView().count,
                totalSize: formatSize(calculateSelectedSizeInView()),
                onDelete: {
                    // Show confirmation dialog
                    showingDeleteConfirmation = true
                },
                onClear: {
                    // Clear selection in this view
                    clearSelectionInView()
                }
            )
        }
        .navigationTitle(item.name)
        .onAppear {
            // Set current folder when view appears
            sizeCalculationManager.setCurrentOpenFolder(item.path)
        }
        .onDisappear {
            // Cancel calculations when leaving folder
            sizeCalculationManager.cancelCalculations(for: item.path)
        }
        .onChange(of: sizeCalculationManager.calculatedSizes) { oldSizes, newSizes in
            // Update children sizes when calculations complete
            for (index, child) in children.enumerated() {
                if let newSize = newSizes[child.path], newSize != child.size {
                    children[index].size = newSize
                }
            }
        }
        .task {
            await loadChildren()
        }
        .alert("Confirm Deletion", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Move to Trash", role: .destructive) {
                Task {
                    await deleteSelectedInView()
                }
            }
        } message: {
            let count = selectedItemsInThisView().count
            let size = formatSize(calculateSelectedSizeInView())
            Text("Are you sure you want to move \(count) item\(count == 1 ? "" : "s") (\(size)) to trash?\n\nThis action will move the items to your Trash where they can be recovered.")
        }
        .sheet(isPresented: $showingDeletionProgress) {
            DeletionProgressView(
                totalItems: $deletionTotalItems,
                currentItem: $deletionCurrentItem,
                currentItemName: $deletionCurrentItemName,
                isCompleted: $deletionIsCompleted,
                successCount: $deletionSuccessCount,
                failedCount: $deletionFailedCount
            )
            .interactiveDismissDisabled(!deletionIsCompleted)
        }
    }
    
    // MARK: - Selection Management
    
    private func selectedItemsInThisView() -> [StorageItem] {
        return children.filter { selectedItems.contains($0.path) }
    }
    
    private func calculateSelectedSizeInView() -> Int64 {
        return selectedItemsInThisView().reduce(0) { $0 + max($1.size, 0) }
    }
    
    private func clearSelectionInView() {
        let childPaths = Set(children.map { $0.path })
        selectedItems.subtract(childPaths)
    }

    private func selectAllInView() {
        let childPaths = Set(children.map { $0.path })
        selectedItems.formUnion(childPaths)
    }

    private func allItemsSelectedInView() -> Bool {
        !children.isEmpty && selectedItemsInThisView().count == children.count
    }

    private func toggleSelectAllInView() {
        if allItemsSelectedInView() {
            clearSelectionInView()
        } else {
            selectAllInView()
        }
    }
    
    private func deleteSelectedInView() async {
        let itemsToDelete = selectedItemsInThisView()
        guard !itemsToDelete.isEmpty else { return }

        // Initialize progress
        await MainActor.run {
            deletionTotalItems = itemsToDelete.count
            deletionCurrentItem = 0
            deletionCurrentItemName = ""
            deletionIsCompleted = false
            deletionSuccessCount = 0
            deletionFailedCount = 0
            showingDeletionProgress = true
        }
        
        var deletedPaths: [String] = []
        
        for (index, item) in itemsToDelete.enumerated() {
            await MainActor.run {
                deletionCurrentItem = index + 1
                deletionCurrentItemName = item.name
            }
            
            do {
                // Try to delete using privileged file manager (handles permissions automatically)
                try await PrivilegedFileManager.shared.deleteItem(at: item.path)
                deletedPaths.append(item.path)
                
                await MainActor.run {
                    deletionSuccessCount += 1
                }
                
                LogManager.shared.log("Moved to trash: \(item.path)", level: .success, category: .deletion)
            } catch {
                await MainActor.run {
                    deletionFailedCount += 1
                }
                
                let errorMsg = (error as NSError).localizedDescription
                LogManager.shared.log("❌ Failed to delete \(item.path): \(errorMsg)", level: .error, category: .deletion)
            }
            
            // Small delay to show progress
            try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 second
        }
        
        // Mark as completed
        await MainActor.run {
            deletionIsCompleted = true
        }
        
        // Wait a moment to show results
        try? await Task.sleep(nanoseconds: 1_500_000_000) // 1.5 seconds
        
        // Update UI
        await MainActor.run {
            showingDeletionProgress = false
            
            // Remove deleted items from selection and children list
            for path in deletedPaths {
                selectedItems.remove(path)
                children.removeAll { $0.path == path }
                allItems.removeValue(forKey: path)
            }
        }
        
        // Refresh folder to update sizes
        await refreshCurrentFolder()
    }

    
    private func refreshCurrentFolder() async {
        isLoading = true
        defer {
            // Always reset loading state, even if there's an error
            isLoading = false
        }

        do {
            // Clear cached sizes for this folder and its children
            scanner.invalidateSizeCache(for: item.path, includeChildren: true)
            
            // Reload children to refresh the view
            let refreshedChildren = await scanner.getChildren(for: item)
            
            await MainActor.run {
                // Clear old children data to prevent accumulation
                let oldPaths = Set(children.map { $0.path })
                children = refreshedChildren
                
                // Remove old items from allItems that are no longer in this folder
                for oldPath in oldPaths {
                    if !refreshedChildren.contains(where: { $0.path == oldPath }) {
                        allItems.removeValue(forKey: oldPath)
                    }
                }
                
                // Update allItems with refreshed data
                for child in refreshedChildren {
                    allItems[child.path] = child
                }
            }
            
            // Recalculate sizes for directories that need it (only if we have children)
            if !refreshedChildren.isEmpty {
                await calculateSizesForChildrenOptimized(refreshedChildren)
            }
        } catch {
            // Handle errors gracefully
            await MainActor.run {
                LogManager.shared.log("Error refreshing folder \(item.path): \(error.localizedDescription)", level: .error, category: .system)
            }
        }
    }
    
    // MARK: - Optimized Children Loading (Performance Optimization #4)
    
    private func loadChildren() async {
        guard item.isDirectory else {
            isLoading = false
            return
        }
        
        isLoading = true
        defer {
            // Always reset loading state, even if there's an error
            isLoading = false
        }
        
        do {
            // Get children immediately - don't wait for size calculations
            let loadedChildren = await scanner.getChildren(for: item)
            
            // Show items immediately in UI (even if empty)
            await MainActor.run {
                children = loadedChildren
                
                // Store all items for selection tracking
                for child in loadedChildren {
                    allItems[child.path] = child
                }
            }
            
            // Calculate sizes in parallel using optimized batch method
            // Only if we have children
            if !loadedChildren.isEmpty {
                await calculateSizesForChildrenOptimized(loadedChildren)
            }
        } catch {
            // Handle errors gracefully
            await MainActor.run {
                children = []
                LogManager.shared.log("Error loading children for \(item.path): \(error.localizedDescription)", level: .error, category: .system)
            }
        }
    }
    
    /// Optimized size calculation using DiskScanner's parallel batch method
    private func calculateSizesForChildrenOptimized(_ items: [StorageItem]) async {
        let directoriesNeedingSize = items.filter { $0.isDirectory && $0.size == -1 }
        
        guard !directoriesNeedingSize.isEmpty else { return }
        
        // Mark all as loading at once
        for item in directoriesNeedingSize {
            loadingItems.insert(item.path)
        }
        
        // Use the optimized parallel batch calculation from DiskScanner
        let sizes = await scanner.calculateSizesInParallel(for: directoriesNeedingSize)
        
        // Update all children with calculated sizes in one pass
        var updatedChildren = children
        for index in updatedChildren.indices {
            if let size = sizes[updatedChildren[index].path] {
                updatedChildren[index].size = size
                allItems[updatedChildren[index].path] = updatedChildren[index]
                loadingItems.remove(updatedChildren[index].path)
            }
        }
        
        // Update children array (will be sorted by sortedChildren computed property)
        children = updatedChildren
    }
    
    private func toggleSelection(_ item: StorageItem) {
        if selectedItems.contains(item.path) {
            // Deselect only this item to avoid loading full subtree
            selectedItems.remove(item.path)
        } else {
            // Select only this item to avoid loading full subtree
            selectedItems.insert(item.path)
            allItems[item.path] = item
        }
    }
    
    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}

// MARK: - Storage Item Row
struct StorageItemRow: View {
    let item: StorageItem
    let isSelected: Bool
    let isLoading: Bool
    let onSelect: () -> Void
    let onNavigate: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // Checkbox
            Button(action: onSelect) {
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(isSelected ? .blue : .secondary)
            }
            .buttonStyle(.plain)
            
            // Icon
            Image(systemName: item.iconName)
                .foregroundStyle(item.isDirectory ? .blue : .secondary)
                .frame(width: 24)
            
            // Name
            Text(item.name)
                .font(.body)
            
            Spacer()
            
            // Size
            if isLoading || (item.isDirectory && item.size == -1) {
                HStack(spacing: 4) {
                    ProgressView()
                        .scaleEffect(0.7)
                    Text("Calculating...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else if item.size == -2 {
                HStack(spacing: 4) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                    Text("Unable to calculate")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else {
                Text(formatSize(item.size))
                    .font(.body)
                    .foregroundStyle(.secondary)
            }
            
            // Chevron for directories
            if item.isDirectory {
                Button(action: onNavigate) {
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
        .onTapGesture {
            if item.isDirectory {
                onNavigate()
            } else {
                onSelect()
            }
        }
        .contextMenu {
            Button(action: {
                openInFinder(item.path)
            }) {
                Label("Open in Finder", systemImage: "folder")
            }
            
            if item.isDirectory {
                Button(action: {
                    onNavigate()
                }) {
                    Label("Open", systemImage: "arrow.right.circle")
                }
            }
            
            Divider()
            
            Button(action: {
                onSelect()
            }) {
                Label(isSelected ? "Deselect" : "Select", systemImage: isSelected ? "checkmark.square" : "square")
            }
        }
    }
    
    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
    
    private func openInFinder(_ path: String) {
        NSWorkspace.shared.selectFile(path, inFileViewerRootedAtPath: "")
        LogManager.shared.log("Opened in Finder: \(path)", level: .info, category: .general)
    }
}

// MARK: - Footer View
struct DiskUsageFooterView: View {
    let selectedCount: Int
    let totalSize: String
    let onDelete: () -> Void
    let onClear: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            if selectedCount > 0 {
                // Selection info with icon
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.blue)
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(selectedCount) item\(selectedCount == 1 ? "" : "s") selected")
                            .font(.caption)
                            .fontWeight(.medium)
                        
                        Text("Total: \(totalSize)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                
                Spacer()
                
                // Action buttons
                HStack(spacing: 8) {
                    Button("Clear") {
                        onClear()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    
                    Button(action: onDelete) {
                        HStack(spacing: 4) {
                            Image(systemName: "trash.fill")
                            Text("Delete \(selectedCount) Item\(selectedCount == 1 ? "" : "s")")
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .controlSize(.regular)
                    .help("Move selected items to trash")
                }
            } else {
                Image(systemName: "info.circle")
                    .foregroundStyle(.secondary)
                
                Text("💡 Click checkbox to select files/folders • Scroll down to browse")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                Spacer()
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .animation(.easeInOut(duration: 0.2), value: selectedCount)
    }
}

// MARK: - Storage Item Footer View
struct StorageItemFooterView: View {
    let selectedCount: Int
    let totalSize: String
    let onDelete: () -> Void
    let onClear: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            if selectedCount > 0 {
                // Selection info with icon
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.blue)
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(selectedCount) item\(selectedCount == 1 ? "" : "s") selected")
                            .font(.caption)
                            .fontWeight(.medium)
                        
                        Text("Total: \(totalSize)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                
                Spacer()
                
                // Action buttons
                HStack(spacing: 8) {
                    Button("Clear") {
                        onClear()
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    
                    Button(action: onDelete) {
                        HStack(spacing: 4) {
                            Image(systemName: "trash.fill")
                            Text("Delete \(selectedCount) Item\(selectedCount == 1 ? "" : "s")")
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .controlSize(.regular)
                    .help("Move selected items to trash")
                }
            } else {
                Image(systemName: "info.circle")
                    .foregroundStyle(.secondary)
                
                Text("💡 Click checkbox to select items")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                Spacer()
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .animation(.easeInOut(duration: 0.2), value: selectedCount)
    }
}

#Preview {
    DiskUsageView()
}
