import SwiftUI

// MARK: - Health Score Badge (Compact for Header)

struct HealthScoreBadge: View {
    @ObservedObject var healthManager: HealthScoreManager

    var body: some View {
        HStack(spacing: 6) {
            // Health Score Circle
            ZStack {
                Circle()
                    .stroke(Color(healthManager.healthGrade.color).opacity(0.2), lineWidth: 3)
                    .frame(width: 28, height: 28)

                Circle()
                    .trim(from: 0, to: CGFloat(healthManager.healthScore) / 100)
                    .stroke(Color(healthManager.healthGrade.color), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .frame(width: 28, height: 28)
                    .rotationEffect(.degrees(-90))

                Text("\(healthManager.healthScore)")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(Color(healthManager.healthGrade.color))
            }

            VStack(alignment: .leading, spacing: 1) {
                Text("Health")
                    .font(.caption2)
                    .foregroundStyle(.secondary)

                Text(healthManager.healthGrade.rawValue)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundStyle(Color(healthManager.healthGrade.color))
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(Color(healthManager.healthGrade.color).opacity(0.1))
        .cornerRadius(8)
        .help("System Health: \(healthManager.healthScore)/100 - \(healthManager.healthGrade.rawValue)")
    }
}

// MARK: - Health Score Detail View (Full Panel)

struct HealthScoreDetailView: View {
    @ObservedObject var healthManager: HealthScoreManager
    @State private var showRecommendations = true

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header with overall score
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("System Health")
                            .font(.title2)
                            .fontWeight(.bold)

                        Text("Based on CPU, memory, disk, thermal, and battery metrics")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    // Large health score indicator
                    ZStack {
                        Circle()
                            .stroke(Color(healthManager.healthGrade.color).opacity(0.2), lineWidth: 8)
                            .frame(width: 80, height: 80)

                        Circle()
                            .trim(from: 0, to: CGFloat(healthManager.healthScore) / 100)
                            .stroke(Color(healthManager.healthGrade.color), style: StrokeStyle(lineWidth: 8, lineCap: .round))
                            .frame(width: 80, height: 80)
                            .rotationEffect(.degrees(-90))
                            .animation(.spring(response: 0.6), value: healthManager.healthScore)

                        VStack(spacing: 0) {
                            Text("\(healthManager.healthScore)")
                                .font(.system(size: 24, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(healthManager.healthGrade.color))

                            Text(healthManager.healthGrade.rawValue)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding()
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(12)

                // Component Scores Grid
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 12) {
                    ComponentScoreCard(
                        title: "CPU",
                        score: healthManager.cpuScore,
                        usage: healthManager.formattedCPUUsage(),
                        icon: "cpu",
                        color: scoreColor(healthManager.cpuScore)
                    )

                    ComponentScoreCard(
                        title: "Memory",
                        score: healthManager.memoryScore,
                        usage: healthManager.formattedMemoryUsage(),
                        icon: "memorychip",
                        color: scoreColor(healthManager.memoryScore)
                    )

                    ComponentScoreCard(
                        title: "Disk",
                        score: healthManager.diskScore,
                        usage: healthManager.formattedDiskUsage(),
                        icon: "internaldrive",
                        color: scoreColor(healthManager.diskScore)
                    )

                    ComponentScoreCard(
                        title: "Thermal",
                        score: healthManager.thermalScore,
                        usage: healthManager.thermalState.rawValue,
                        icon: "thermometer",
                        color: scoreColor(healthManager.thermalScore)
                    )

                    ComponentScoreCard(
                        title: "Battery",
                        score: healthManager.batteryScore,
                        usage: "\(healthManager.batteryHealth)% health",
                        icon: "battery.100",
                        color: scoreColor(healthManager.batteryScore)
                    )
                }

                // Recommendations Section
                let recommendations = healthManager.getRecommendations()
                if !recommendations.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "lightbulb.fill")
                                .foregroundStyle(.yellow)
                            Text("Recommendations")
                                .font(.headline)
                            Spacer()
                            Button(action: { showRecommendations.toggle() }) {
                                Image(systemName: showRecommendations ? "chevron.up" : "chevron.down")
                            }
                            .buttonStyle(.plain)
                        }

                        if showRecommendations {
                            ForEach(recommendations) { rec in
                                RecommendationRow(recommendation: rec)
                            }
                        }
                    }
                    .padding()
                    .background(Color(NSColor.controlBackgroundColor))
                    .cornerRadius(12)
                }

                // System Info
                VStack(alignment: .leading, spacing: 8) {
                    Text("System Information")
                        .font(.headline)

                    SystemInfoRow(label: "macOS", value: ProcessInfo.processInfo.operatingSystemVersionString)
                    SystemInfoRow(label: "CPU Cores", value: "\(ProcessInfo.processInfo.processorCount)")
                    SystemInfoRow(label: "RAM", value: ByteCountFormatter.string(fromByteCount: Int64(ProcessInfo.processInfo.physicalMemory), countStyle: .memory))
                    SystemInfoRow(label: "Uptime", value: formatUptime(ProcessInfo.processInfo.systemUptime))
                }
                .padding()
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(12)
            }
            .padding()
        }
        .frame(minWidth: 400, minHeight: 500)
        .onAppear {
            healthManager.startMonitoring(interval: 2.0)
        }
        .onDisappear {
            healthManager.stopMonitoring()
        }
    }

    private func scoreColor(_ score: Int) -> Color {
        switch score {
        case 90...100: return .green
        case 75..<90: return .blue
        case 60..<75: return .yellow
        case 40..<60: return .orange
        default: return .red
        }
    }

    private func formatUptime(_ seconds: TimeInterval) -> String {
        let days = Int(seconds) / 86400
        let hours = (Int(seconds) % 86400) / 3600
        let minutes = (Int(seconds) % 3600) / 60

        if days > 0 {
            return "\(days)d \(hours)h \(minutes)m"
        } else if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
}

// MARK: - Component Score Card

struct ComponentScoreCard: View {
    let title: String
    let score: Int
    let usage: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(color)
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.medium)
                Spacer()
                Text("\(score)")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundStyle(color)
            }

            ProgressView(value: Double(score), total: 100)
                .tint(color)

            Text(usage)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(color.opacity(0.1))
        .cornerRadius(10)
    }
}

// MARK: - Recommendation Row

struct RecommendationRow: View {
    let recommendation: HealthRecommendation

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: recommendation.icon)
                .foregroundStyle(Color(recommendation.severity.color))
                .frame(width: 20)

            VStack(alignment: .leading, spacing: 2) {
                Text(recommendation.category)
                    .font(.subheadline)
                    .fontWeight(.medium)

                Text(recommendation.message)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - System Info Row

struct SystemInfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .fontWeight(.medium)
        }
        .font(.caption)
    }
}

#Preview {
    HealthScoreDetailView(healthManager: HealthScoreManager.shared)
}
