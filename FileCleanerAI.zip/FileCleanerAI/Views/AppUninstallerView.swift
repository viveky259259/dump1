import SwiftUI

struct AppUninstallerView: View {
    @StateObject private var uninstaller = AppUninstaller.shared
    @State private var searchText = ""
    @State private var selectedApp: InstalledApp?
    @State private var sortOrder: AppSortOrder = .name
    @State private var showingUninstallConfirmation = false
    @State private var showingResult = false
    @State private var cleaningResult: CleaningResult?

    enum AppSortOrder: String, CaseIterable {
        case name = "Name"
        case size = "Size"
        case remnants = "Remnant Size"
        case lastUsed = "Last Used"
    }

    private var filteredApps: [InstalledApp] {
        var apps = uninstaller.installedApps
        if !searchText.isEmpty {
            apps = apps.filter {
                $0.name.localizedCaseInsensitiveContains(searchText) ||
                ($0.bundleIdentifier?.localizedCaseInsensitiveContains(searchText) ?? false)
            }
        }
        switch sortOrder {
        case .name:
            apps.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case .size:
            apps.sort { $0.totalSize > $1.totalSize }
        case .remnants:
            apps.sort { $0.totalRemnantSize > $1.totalRemnantSize }
        case .lastUsed:
            apps.sort {
                ($0.lastUsedDate ?? .distantPast) < ($1.lastUsedDate ?? .distantPast)
            }
        }
        return apps
    }

    var body: some View {
        HSplitView {
            // Left: App list
            VStack(spacing: 0) {
                AppUninstallerHeaderView(
                    uninstaller: uninstaller,
                    searchText: $searchText,
                    sortOrder: $sortOrder,
                    onLoad: {
                        Task {
                            await uninstaller.loadInstalledApps()
                            await uninstaller.scanAllRemnants()
                        }
                    }
                )

                Divider()

                if uninstaller.isLoadingApps {
                    VStack(spacing: 12) {
                        Spacer()
                        ProgressView()
                        Text("Loading installed apps...")
                            .font(.headline)
                        Spacer()
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if uninstaller.isScanningRemnants {
                    VStack(spacing: 12) {
                        Spacer()
                        ProgressView(value: uninstaller.scanProgress)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 250)
                        Text("Scanning for app remnants...")
                            .font(.headline)
                        Text("\(Int(uninstaller.scanProgress * 100))%")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if filteredApps.isEmpty {
                    VStack(spacing: 12) {
                        Spacer()
                        Image(systemName: "app.badge.checkmark")
                            .font(.largeTitle)
                            .foregroundStyle(.secondary)
                        Text(searchText.isEmpty ? "No apps found" : "No matching apps")
                            .font(.headline)
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(filteredApps, selection: $selectedApp) { app in
                        AppListRow(app: app)
                            .tag(app)
                    }
                    .listStyle(.inset(alternatesRowBackgrounds: true))
                }
            }
            .frame(minWidth: 350)

            // Right: Detail
            if let app = selectedApp,
               let liveApp = uninstaller.installedApps.first(where: { $0.path == app.path }) {
                AppDetailView(
                    app: liveApp,
                    uninstaller: uninstaller,
                    onUninstall: {
                        showingUninstallConfirmation = true
                    },
                    onCleanRemnants: { selectedPaths in
                        Task {
                            let result = await uninstaller.cleanRemnants(for: liveApp, selectedPaths: selectedPaths)
                            cleaningResult = result
                            showingResult = true
                        }
                    }
                )
            } else {
                VStack(spacing: 12) {
                    Spacer()
                    Image(systemName: "arrow.left.circle")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text("Select an app to view details")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .alert("Uninstall App", isPresented: $showingUninstallConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Move to Trash", role: .destructive) {
                if let app = selectedApp {
                    Task {
                        let result = await uninstaller.uninstallApp(app)
                        cleaningResult = result
                        showingResult = true
                        selectedApp = nil
                    }
                }
            }
        } message: {
            if let app = selectedApp {
                Text("Uninstall \"\(app.name)\" and remove \(app.remnants.count) associated files?\n\nTotal: \(app.formattedTotalSize)\n\nThe app will be moved to Trash.")
            }
        }
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") { cleaningResult = nil }
        } message: {
            if let result = cleaningResult {
                Text("Removed \(result.success) items.\nFreed \(result.formattedBytesFreed) of space.")
            }
        }
        .onAppear {
            if uninstaller.installedApps.isEmpty {
                Task {
                    await uninstaller.loadInstalledApps()
                    await uninstaller.scanAllRemnants()
                }
            }
        }
    }
}

// MARK: - Header

struct AppUninstallerHeaderView: View {
    @ObservedObject var uninstaller: AppUninstaller
    @Binding var searchText: String
    @Binding var sortOrder: AppUninstallerView.AppSortOrder
    let onLoad: () -> Void

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "trash.slash.fill")
                            .foregroundStyle(.red)
                        Text("App Uninstaller")
                            .font(.headline)
                    }
                    Text("Remove apps completely with all associated files")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button(action: onLoad) {
                    Label("Rescan", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(uninstaller.isLoadingApps || uninstaller.isScanningRemnants)
            }

            HStack(spacing: 8) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Search apps...", text: $searchText)
                        .textFieldStyle(.plain)
                }
                .padding(6)
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color(NSColor.separatorColor), lineWidth: 0.5)
                )

                Picker("Sort", selection: $sortOrder) {
                    ForEach(AppUninstallerView.AppSortOrder.allCases, id: \.self) { order in
                        Text(order.rawValue).tag(order)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 130)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - App List Row

struct AppListRow: View {
    let app: InstalledApp

    var body: some View {
        HStack(spacing: 10) {
            if let icon = app.icon {
                Image(nsImage: icon)
                    .resizable()
                    .frame(width: 32, height: 32)
                    .cornerRadius(6)
            } else {
                Image(systemName: "app.fill")
                    .font(.title)
                    .foregroundStyle(.secondary)
                    .frame(width: 32, height: 32)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(app.name)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .lineLimit(1)

                HStack(spacing: 8) {
                    Text(app.formattedAppSize)
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if app.totalRemnantSize > 0 {
                        Text("+ \(app.formattedRemnantSize) remnants")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }
            }

            Spacer()

            if app.totalRemnantSize > 0 {
                Text("\(app.remnants.count)")
                    .font(.caption2)
                    .fontWeight(.bold)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Capsule().fill(.orange))
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - App Detail View

struct AppDetailView: View {
    let app: InstalledApp
    @ObservedObject var uninstaller: AppUninstaller
    let onUninstall: () -> Void
    let onCleanRemnants: (Set<String>?) -> Void

    @State private var selectedRemnants: Set<String> = []
    @State private var showAllRemnants = true

    var body: some View {
        VStack(spacing: 0) {
            // App info header
            HStack(spacing: 16) {
                if let icon = app.icon {
                    Image(nsImage: icon)
                        .resizable()
                        .frame(width: 64, height: 64)
                        .cornerRadius(12)
                } else {
                    Image(systemName: "app.fill")
                        .font(.system(size: 48))
                        .foregroundStyle(.secondary)
                        .frame(width: 64, height: 64)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(app.name)
                        .font(.title2)
                        .fontWeight(.bold)

                    if let bundleId = app.bundleIdentifier {
                        Text(bundleId)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    HStack(spacing: 16) {
                        Label(app.formattedAppSize, systemImage: "app")
                            .font(.caption)

                        if let lastUsed = app.lastUsedDate {
                            Label(lastUsed.formatted(date: .abbreviated, time: .omitted), systemImage: "clock")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Spacer()

                VStack(spacing: 8) {
                    Button(action: onUninstall) {
                        Label("Uninstall", systemImage: "trash")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .disabled(uninstaller.isUninstalling)

                    Text(app.formattedTotalSize)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            // Remnants section
            if app.remnants.isEmpty {
                VStack(spacing: 12) {
                    Spacer()
                    Image(systemName: "checkmark.seal.fill")
                        .font(.largeTitle)
                        .foregroundStyle(.green)
                    Text("No remnants found")
                        .font(.headline)
                    Text("This app has no associated files outside its bundle")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                // Remnant controls
                HStack {
                    Text("Associated Files (\(app.remnants.count))")
                        .font(.subheadline)
                        .fontWeight(.medium)

                    Spacer()

                    Button(action: toggleSelectAll) {
                        Text(allSelected ? "Deselect All" : "Select All")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)

                    if !selectedRemnants.isEmpty {
                        Button(action: { onCleanRemnants(selectedRemnants) }) {
                            Label("Clean \(selectedRemnants.count) Items", systemImage: "trash")
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.orange)
                        .controlSize(.small)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)

                // Remnant list grouped by category
                List {
                    ForEach(groupedRemnants, id: \.0) { category, remnants in
                        Section(header:
                            HStack {
                                Image(systemName: category.icon)
                                Text(category.rawValue)
                                Spacer()
                                Text(formatGroupSize(remnants))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        ) {
                            ForEach(remnants) { remnant in
                                RemnantRow(
                                    remnant: remnant,
                                    isSelected: selectedRemnants.contains(remnant.path),
                                    onToggle: { toggleRemnant(remnant) }
                                )
                            }
                        }
                    }
                }
                .listStyle(.inset(alternatesRowBackgrounds: true))
            }

            // Footer
            if !app.remnants.isEmpty {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Total remnant data: \(app.formattedRemnantSize)")
                            .font(.callout)
                        if !selectedRemnants.isEmpty {
                            Text("Selected: \(selectedRemnants.count) items (\(formatSelectedSize))")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                    }
                    Spacer()
                }
                .padding()
                .background(Color(NSColor.controlBackgroundColor))
            }
        }
        .onAppear {
            // Auto-select all remnants by default
            selectedRemnants = Set(app.remnants.map { $0.path })
        }
        .onChange(of: app) {
            selectedRemnants = Set(app.remnants.map { $0.path })
        }
    }

    private var groupedRemnants: [(RemnantCategory, [AppRemnant])] {
        let grouped = Dictionary(grouping: app.remnants) { $0.category }
        return grouped
            .sorted { $0.value.reduce(0) { $0 + $1.size } > $1.value.reduce(0) { $0 + $1.size } }
    }

    private var allSelected: Bool {
        !app.remnants.isEmpty && selectedRemnants.count == app.remnants.count
    }

    private func toggleSelectAll() {
        if allSelected {
            selectedRemnants.removeAll()
        } else {
            selectedRemnants = Set(app.remnants.map { $0.path })
        }
    }

    private func toggleRemnant(_ remnant: AppRemnant) {
        if selectedRemnants.contains(remnant.path) {
            selectedRemnants.remove(remnant.path)
        } else {
            selectedRemnants.insert(remnant.path)
        }
    }

    private func formatGroupSize(_ remnants: [AppRemnant]) -> String {
        let total = remnants.reduce(0) { $0 + $1.size }
        return ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
    }

    private var formatSelectedSize: String {
        let total = app.remnants
            .filter { selectedRemnants.contains($0.path) }
            .reduce(0) { $0 + $1.size }
        return ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
    }
}

// MARK: - Remnant Row

struct RemnantRow: View {
    let remnant: AppRemnant
    let isSelected: Bool
    let onToggle: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Button(action: onToggle) {
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(isSelected ? .orange : .secondary)
            }
            .buttonStyle(.plain)

            Image(systemName: remnant.category.icon)
                .foregroundStyle(.secondary)
                .frame(width: 20)

            VStack(alignment: .leading, spacing: 2) {
                Text(remnant.name)
                    .font(.subheadline)
                    .lineLimit(1)

                Text(remnant.path)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            Spacer()

            Text(remnant.formattedSize)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
        .contentShape(Rectangle())
        .onTapGesture { onToggle() }
        .contextMenu {
            Button(action: {
                NSWorkspace.shared.selectFile(remnant.path, inFileViewerRootedAtPath: "")
            }) {
                Label("Show in Finder", systemImage: "folder")
            }
            Button(action: {
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(remnant.path, forType: .string)
            }) {
                Label("Copy Path", systemImage: "doc.on.doc")
            }
        }
    }
}

#Preview {
    AppUninstallerView()
}
