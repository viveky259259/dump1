import SwiftUI

struct StartupItemsView: View {
    @StateObject private var manager = StartupItemsManager.shared
    @State private var selectedLocation: StartupItemLocation?
    @State private var showingRemoveConfirmation = false
    @State private var itemToRemove: StartupItem?
    @State private var searchText = ""

    var filteredItems: [StartupItem] {
        var items = manager.startupItems

        if let location = selectedLocation {
            items = items.filter { $0.location == location }
        }

        if !searchText.isEmpty {
            items = items.filter {
                $0.name.localizedCaseInsensitiveContains(searchText) ||
                $0.identifier.localizedCaseInsensitiveContains(searchText)
            }
        }

        return items
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            StartupHeaderView(
                manager: manager,
                selectedLocation: $selectedLocation,
                searchText: $searchText
            )

            Divider()

            if manager.isScanning {
                StartupScanningView()
            } else if manager.startupItems.isEmpty {
                StartupEmptyView(onScan: {
                    Task { await manager.scanStartupItems() }
                })
            } else {
                // Items List
                ScrollView {
                    LazyVStack(spacing: 8) {
                        // Group by location
                        ForEach(groupedItems.keys.sorted(by: { $0.rawValue < $1.rawValue }), id: \.self) { location in
                            if let items = groupedItems[location], !items.isEmpty {
                                StartupLocationSection(
                                    location: location,
                                    items: items,
                                    manager: manager,
                                    onRemove: { item in
                                        itemToRemove = item
                                        showingRemoveConfirmation = true
                                    }
                                )
                            }
                        }
                    }
                    .padding()
                }

                // Footer
                StartupFooterView(
                    totalCount: manager.startupItems.count,
                    enabledCount: manager.startupItems.filter { $0.isEnabled }.count,
                    lastScan: manager.lastScanDate
                )
            }
        }
        .alert("Remove Startup Item", isPresented: $showingRemoveConfirmation) {
            Button("Cancel", role: .cancel) {
                itemToRemove = nil
            }
            Button("Remove", role: .destructive) {
                if let item = itemToRemove {
                    Task { await manager.removeItem(item) }
                }
                itemToRemove = nil
            }
        } message: {
            if let item = itemToRemove {
                Text("Are you sure you want to remove '\(item.name)'? This will move the launch agent to trash.")
            }
        }
        .onAppear {
            if manager.startupItems.isEmpty {
                Task { await manager.scanStartupItems() }
            }
        }
    }

    private var groupedItems: [StartupItemLocation: [StartupItem]] {
        Dictionary(grouping: filteredItems, by: { $0.location })
    }
}

// MARK: - Header View

struct StartupHeaderView: View {
    @ObservedObject var manager: StartupItemsManager
    @Binding var selectedLocation: StartupItemLocation?
    @Binding var searchText: String

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "bolt.fill")
                            .foregroundStyle(.yellow)
                        Text("Startup Items")
                            .font(.headline)
                    }

                    Text("Manage apps and services that run at login")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button(action: {
                    Task { await manager.scanStartupItems() }
                }) {
                    Label("Refresh", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(manager.isScanning)
            }

            HStack {
                // Search field
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Search startup items...", text: $searchText)
                        .textFieldStyle(.plain)
                }
                .padding(8)
                .background(Color(NSColor.textBackgroundColor))
                .cornerRadius(8)

                // Location filter
                Picker("Location", selection: $selectedLocation) {
                    Text("All Locations").tag(nil as StartupItemLocation?)
                    Divider()
                    ForEach([StartupItemLocation.userLaunchAgents, .systemLaunchAgents, .systemLaunchDaemons], id: \.self) { loc in
                        HStack {
                            Image(systemName: loc.icon)
                            Text(loc.rawValue)
                        }
                        .tag(loc as StartupItemLocation?)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 200)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Scanning View

struct StartupScanningView: View {
    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            ProgressView()
                .scaleEffect(1.5)

            Text("Scanning startup items...")
                .font(.headline)

            Text("Checking LaunchAgents and LaunchDaemons")
                .font(.caption)
                .foregroundStyle(.secondary)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Empty View

struct StartupEmptyView: View {
    let onScan: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            Image(systemName: "bolt.slash")
                .font(.system(size: 64))
                .foregroundStyle(.secondary)

            Text("No Startup Items Found")
                .font(.title2)
                .fontWeight(.semibold)

            Text("Click 'Refresh' to scan for LaunchAgents and LaunchDaemons")
                .font(.caption)
                .foregroundStyle(.secondary)

            Button(action: onScan) {
                Label("Scan Now", systemImage: "magnifyingglass")
            }
            .buttonStyle(.borderedProminent)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Location Section

struct StartupLocationSection: View {
    let location: StartupItemLocation
    let items: [StartupItem]
    let manager: StartupItemsManager
    let onRemove: (StartupItem) -> Void

    @State private var isExpanded = true

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Section header
            Button(action: { isExpanded.toggle() }) {
                HStack {
                    Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                        .foregroundStyle(.secondary)
                        .frame(width: 16)

                    Image(systemName: location.icon)
                        .foregroundStyle(.blue)

                    Text(location.rawValue)
                        .font(.subheadline)
                        .fontWeight(.semibold)

                    Text("(\(items.count))")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    if location.requiresAdmin {
                        Image(systemName: "lock.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .help("Requires administrator privileges")
                    }

                    Spacer()
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if isExpanded {
                ForEach(items) { item in
                    StartupItemRow(
                        item: item,
                        recommendation: manager.getRecommendation(for: item),
                        onToggle: {
                            Task {
                                if item.isEnabled {
                                    await manager.disableItem(item)
                                } else {
                                    await manager.enableItem(item)
                                }
                            }
                        },
                        onRemove: { onRemove(item) }
                    )
                }
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(10)
    }
}

// MARK: - Item Row

struct StartupItemRow: View {
    let item: StartupItem
    let recommendation: StartupRecommendation
    let onToggle: () -> Void
    let onRemove: () -> Void

    @State private var showingDetails = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Toggle("", isOn: Binding(
                    get: { item.isEnabled },
                    set: { _ in onToggle() }
                ))
                .toggleStyle(.switch)
                .controlSize(.small)

                // Recommendation indicator
                Image(systemName: recommendation.icon)
                    .foregroundStyle(Color(recommendation.color))
                    .frame(width: 20)
                    .help(recommendationText)

                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name)
                        .font(.subheadline)
                        .fontWeight(.medium)

                    Text(item.identifier)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }

                Spacer()

                // Status
                HStack(spacing: 4) {
                    if item.isLoaded {
                        Circle()
                            .fill(.green)
                            .frame(width: 6, height: 6)
                        Text("Running")
                            .font(.caption)
                            .foregroundStyle(.green)
                    } else {
                        Circle()
                            .fill(.secondary)
                            .frame(width: 6, height: 6)
                        Text("Stopped")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Button(action: { showingDetails.toggle() }) {
                    Image(systemName: "info.circle")
                }
                .buttonStyle(.borderless)

                Button(action: onRemove) {
                    Image(systemName: "trash")
                        .foregroundStyle(.red)
                }
                .buttonStyle(.borderless)
                .help("Remove startup item")
            }

            if showingDetails {
                Divider()
                    .padding(.vertical, 8)

                VStack(alignment: .leading, spacing: 4) {
                    DetailRow(label: "Path", value: item.displayPath)

                    if let program = item.program {
                        DetailRow(label: "Program", value: program)
                    }

                    DetailRow(label: "Status", value: item.statusDescription)

                    if case .keep(let reason) = recommendation {
                        DetailRow(label: "Note", value: reason, color: .green)
                    } else if case .consider(let reason) = recommendation {
                        DetailRow(label: "Note", value: reason, color: .orange)
                    } else if case .remove(let reason) = recommendation {
                        DetailRow(label: "Warning", value: reason, color: .red)
                    }
                }
                .padding(.leading, 40)
            }
        }
        .padding(.vertical, 8)
    }

    private var recommendationText: String {
        switch recommendation {
        case .keep(let reason): return "Keep: \(reason)"
        case .consider(let reason): return "Consider: \(reason)"
        case .remove(let reason): return "Remove: \(reason)"
        case .neutral: return "No recommendation"
        }
    }
}

// MARK: - Detail Row

struct DetailRow: View {
    let label: String
    let value: String
    var color: Color = .secondary

    var body: some View {
        HStack(alignment: .top) {
            Text(label + ":")
                .font(.caption)
                .foregroundStyle(.tertiary)
                .frame(width: 60, alignment: .trailing)

            Text(value)
                .font(.caption)
                .foregroundStyle(color)
                .lineLimit(2)
        }
    }
}

// MARK: - Footer View

struct StartupFooterView: View {
    let totalCount: Int
    let enabledCount: Int
    let lastScan: Date?

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("\(totalCount) startup items (\(enabledCount) enabled)")
                    .font(.callout)

                if let lastScan = lastScan {
                    Text("Last scanned: \(lastScan.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            Text("Disabling startup items can improve boot time")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

#Preview {
    StartupItemsView()
}
