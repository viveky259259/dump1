import SwiftUI

struct FilePatternDetailView: View {
    let pattern: FilePattern
    @Binding var isPresented: Bool
    @State private var searchText = ""
    @State private var selectedFiles: Set<String> = []
    @State private var showingDeleteConfirmation = false
    @State private var showFilesOnly = false
    @State private var showFoldersOnly = false
    @State private var sortOrder: SortOrder = .nameAscending
    @State private var sizeCache: [String: Int64] = [:]
    @State private var isCalculatingSizes = false
    @State private var loadedSizes: Set<String> = [] // Track which sizes we've already calculated
    @State private var selectedTotalSize: Int64 = 0 // Cached selected size
    @State private var showDeleteButton = false // Show delete button when items selected
    @State private var sizeCacheVersion: Int = 0 // Increment to force re-sort when cache updates
    @State private var calculationTask: Task<Void, Never>? // Track calculation task for cancellation
    
    // Cache size limit to prevent unbounded growth
    private let maxCacheSize = 1000
    
    enum SortOrder: String, CaseIterable {
        case nameAscending = "Name (A-Z)"
        case nameDescending = "Name (Z-A)"
        case sizeDescending = "Size (Largest)"
        case sizeAscending = "Size (Smallest)"
        case typeFilesFirst = "Files First"
        case typeFoldersFirst = "Folders First"
    }
    
    var filteredPaths: [String] {
        // Depend on sizeCacheVersion to force recomputation when cache updates
        _ = sizeCacheVersion

        var paths = pattern.paths

        // Apply search filter
        if !searchText.isEmpty {
            paths = paths.filter { path in
                path.localizedCaseInsensitiveContains(searchText)
            }
        }

        // Apply file type filters (both can be off, or one at a time)
        if showFilesOnly && !showFoldersOnly {
            paths = paths.filter { !isPathDirectory($0) }
        } else if showFoldersOnly && !showFilesOnly {
            paths = paths.filter { isPathDirectory($0) }
        }
        // If both are on or both are off, show all

        // Apply sorting
        paths = sortPaths(paths)

        return paths
    }
    
    private func sortPaths(_ paths: [String]) -> [String] {
        switch sortOrder {
        case .nameAscending:
            return paths.sorted { path1, path2 in
                let name1 = (path1 as NSString).lastPathComponent
                let name2 = (path2 as NSString).lastPathComponent
                return name1.localizedCaseInsensitiveCompare(name2) == .orderedAscending
            }
        case .nameDescending:
            return paths.sorted { path1, path2 in
                let name1 = (path1 as NSString).lastPathComponent
                let name2 = (path2 as NSString).lastPathComponent
                return name1.localizedCaseInsensitiveCompare(name2) == .orderedDescending
            }
        case .sizeDescending:
            // Start calculating sizes if not already started
            if sizeCache.isEmpty && !isCalculatingSizes {
                // Dispatch async to avoid modifying state during view update
                DispatchQueue.main.async {
                    self.calculateSizesAsync(for: paths)
                }
            }
            // Always sort by size - unknown sizes get 0, will re-sort when cache updates
            return paths.sorted { path1, path2 in
                let size1 = sizeCache[path1] ?? 0
                let size2 = sizeCache[path2] ?? 0
                if size1 != size2 {
                    return size1 > size2
                }
                // Fallback to name sort for equal/unknown sizes
                let name1 = (path1 as NSString).lastPathComponent
                let name2 = (path2 as NSString).lastPathComponent
                return name1.localizedCaseInsensitiveCompare(name2) == .orderedAscending
            }
        case .sizeAscending:
            // Start calculating sizes if not already started
            if sizeCache.isEmpty && !isCalculatingSizes {
                DispatchQueue.main.async {
                    self.calculateSizesAsync(for: paths)
                }
            }
            // Always sort by size - unknown sizes get 0, will re-sort when cache updates
            return paths.sorted { path1, path2 in
                let size1 = sizeCache[path1] ?? 0
                let size2 = sizeCache[path2] ?? 0
                if size1 != size2 {
                    return size1 < size2
                }
                // Fallback to name sort for equal/unknown sizes
                let name1 = (path1 as NSString).lastPathComponent
                let name2 = (path2 as NSString).lastPathComponent
                return name1.localizedCaseInsensitiveCompare(name2) == .orderedAscending
            }
        case .typeFilesFirst:
            return paths.sorted { path1, path2 in
                let isDir1 = isPathDirectory(path1)
                let isDir2 = isPathDirectory(path2)
                if isDir1 != isDir2 {
                    return !isDir1 // Files (false) come before folders (true)
                }
                // If same type, sort by name
                let name1 = (path1 as NSString).lastPathComponent
                let name2 = (path2 as NSString).lastPathComponent
                return name1.localizedCaseInsensitiveCompare(name2) == .orderedAscending
            }
        case .typeFoldersFirst:
            return paths.sorted { path1, path2 in
                let isDir1 = isPathDirectory(path1)
                let isDir2 = isPathDirectory(path2)
                if isDir1 != isDir2 {
                    return isDir1 // Folders (true) come before files (false)
                }
                // If same type, sort by name
                let name1 = (path1 as NSString).lastPathComponent
                let name2 = (path2 as NSString).lastPathComponent
                return name1.localizedCaseInsensitiveCompare(name2) == .orderedAscending
            }
        }
    }
    
    private func calculateSizesAsync(for paths: [String]) {
        guard !isCalculatingSizes else { return }

        isCalculatingSizes = true

        calculationTask = Task.detached(priority: .userInitiated) {
            var cache: [String: Int64] = [:]
            let pathsCopy = paths // Capture paths

            for path in pathsCopy {
                // Check for cancellation
                if Task.isCancelled { break }

                let size = await Self.calculatePathSizeAsync(path)
                cache[path] = size

                // Update cache incrementally for better UX
                if cache.count % 10 == 0 {
                    await MainActor.run {
                        self.sizeCache.merge(cache) { _, new in new }
                        self.sizeCacheVersion += 1
                    }
                }
            }

            await MainActor.run {
                if !Task.isCancelled {
                    self.sizeCache.merge(cache) { _, new in new }
                    self.sizeCacheVersion += 1
                }
                self.isCalculatingSizes = false
                self.calculationTask = nil
            }
        }
    }

    private func cancelCalculations() {
        calculationTask?.cancel()
        calculationTask = nil
        isCalculatingSizes = false
    }

    private static func calculatePathSizeAsync(_ path: String) async -> Int64 {
        let url = URL(fileURLWithPath: path)

        do {
            let resourceValues = try url.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey, .totalFileAllocatedSizeKey])

            if let isDir = resourceValues.isDirectory, isDir {
                // Calculate directory size
                return calculateDirectorySizeStatic(at: url)
            } else {
                // Return file size (prefer allocated size for disk usage accuracy)
                if let allocatedSize = resourceValues.totalFileAllocatedSize {
                    return Int64(allocatedSize)
                }
                return Int64(resourceValues.fileSize ?? 0)
            }
        } catch {
            return -2 // -2 = calculation failed
        }
    }

    /// Full directory size calculation with symlink handling
    private static func calculateDirectorySizeStatic(at url: URL) -> Int64 {
        let fileManager = FileManager.default
        var totalSize: Int64 = 0

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isSymbolicLinkKey, .isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            // Skip symlinks to avoid double-counting
            if let values = try? fileURL.resourceValues(forKeys: [.isSymbolicLinkKey]),
               values.isSymbolicLink == true {
                continue
            }

            // Only count files, not directories
            if let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey, .fileSizeKey]),
               let isDir = values.isDirectory, !isDir {
                if let allocatedSize = values.totalFileAllocatedSize {
                    totalSize += Int64(allocatedSize)
                } else if let fileSize = values.fileSize {
                    totalSize += Int64(fileSize)
                }
            }
        }

        return totalSize
    }
    
    private func isPathDirectory(_ path: String) -> Bool {
        var isDir: ObjCBool = false
        FileManager.default.fileExists(atPath: path, isDirectory: &isDir)
        return isDir.boolValue
    }
    
    var totalSize: String {
        ByteCountFormatter.string(fromByteCount: pattern.totalSize, countStyle: .file)
    }
    
    var selectedSizeString: String {
        if selectedTotalSize > 0 {
            return ByteCountFormatter.string(fromByteCount: selectedTotalSize, countStyle: .file)
        } else if !selectedFiles.isEmpty {
            return "Calculating..."
        } else {
            return "0 bytes"
        }
    }
    
    // Calculate selected size efficiently - only when selection changes
    private func updateSelectedSize() {
        // Quick calculation from cache (skip failed calculations)
        var total: Int64 = 0
        for path in selectedFiles {
            if let size = sizeCache[path], size >= 0 {
                total += size
            }
        }
        selectedTotalSize = total
        showDeleteButton = !selectedFiles.isEmpty

        // If we have uncached items, calculate them in background
        let uncachedPaths = selectedFiles.filter { sizeCache[$0] == nil }
        if !uncachedPaths.isEmpty {
            calculateSelectedSizes(for: Array(uncachedPaths))
        }
    }
    
    // Background calculation for selected items only
    private func calculateSelectedSizes(for paths: [String]) {
        Task.detached(priority: .userInitiated) {
            var sizes: [String: Int64] = [:]

            for path in paths {
                let url = URL(fileURLWithPath: path)

                autoreleasepool {
                    do {
                        let resourceValues = try url.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey, .totalFileAllocatedSizeKey])

                        if let isDirectory = resourceValues.isDirectory, isDirectory {
                            // Quick estimation for directories
                            sizes[path] = Self.estimateDirectorySize(at: url)
                        } else {
                            // Prefer allocated size for disk usage accuracy
                            if let allocatedSize = resourceValues.totalFileAllocatedSize {
                                sizes[path] = Int64(allocatedSize)
                            } else {
                                sizes[path] = Int64(resourceValues.fileSize ?? 0)
                            }
                        }
                    } catch {
                        sizes[path] = -2 // -2 = calculation failed
                    }
                }
            }

            // Update cache and recalculate total
            await MainActor.run {
                self.sizeCache.merge(sizes) { _, new in new }
                self.loadedSizes.formUnion(sizes.keys)
                self.sizeCacheVersion += 1

                // Recalculate selected total (skip failed calculations)
                var total: Int64 = 0
                for path in self.selectedFiles {
                    if let size = self.sizeCache[path], size >= 0 {
                        total += size
                    }
                }
                self.selectedTotalSize = total
            }
        }
    }

    /// Directory size estimation with proper extrapolation for large directories
    nonisolated private static func estimateDirectorySize(at url: URL) -> Int64 {
        let fileManager = FileManager.default
        var totalSize: Int64 = 0
        var fileCount = 0
        var totalFileCount = 0
        let sampleLimit = 500  // Increased sample size for better accuracy

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            totalFileCount += 1

            // Skip symlinks
            if let values = try? fileURL.resourceValues(forKeys: [.isSymbolicLinkKey]),
               values.isSymbolicLink == true {
                continue
            }

            // Sample files up to limit
            if fileCount < sampleLimit {
                if let size = try? fileURL.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileSizeKey]),
                   let allocatedSize = size.totalFileAllocatedSize {
                    totalSize += Int64(allocatedSize)
                } else if let size = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                    totalSize += Int64(size)
                }
                fileCount += 1
            }
        }

        // Extrapolate if we hit sample limit
        if fileCount >= sampleLimit && totalFileCount > sampleLimit {
            let averageSize = totalSize / Int64(fileCount)
            return averageSize * Int64(totalFileCount)
        }

        return totalSize
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(pattern.patternName)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    HStack(spacing: 12) {
                        Label("\(pattern.count) items", systemImage: "doc.fill")
                        Label(totalSize, systemImage: "internaldrive")
                        Label(pattern.safetyScore.rawValue, systemImage: safetyIcon)
                            .foregroundStyle(safetyColor)
                    }
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                Button(action: { isPresented = false }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.title2)
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .help("Close detail view")
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            
            Divider()
            
            // Safety Info
            HStack {
                Image(systemName: safetyIcon)
                    .foregroundStyle(safetyColor)
                    .font(.title3)
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("Safety Assessment")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(pattern.reason)
                        .font(.subheadline)
                }
                
                Spacer()
            }
            .padding()
            .background(safetyColor.opacity(0.1))
            
            Divider()
            
            // Search Bar with Toggleable Filter Icons
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.secondary)
                
                TextField("Search files and folders...", text: $searchText)
                    .textFieldStyle(.plain)
                
                if !searchText.isEmpty {
                    Button(action: { searchText = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                }
                
                Divider()
                    .frame(height: 20)
                    .padding(.horizontal, 8)
                
                // Toggleable filter icons
                Button(action: {
                    showFilesOnly.toggle()
                    if showFilesOnly && showFoldersOnly {
                        showFoldersOnly = false
                    }
                }) {
                    Image(systemName: "doc.fill")
                        .foregroundStyle(showFilesOnly ? .blue : .secondary)
                        .font(.body)
                }
                .buttonStyle(.plain)
                .help(showFilesOnly ? "Showing files only (click to show all)" : "Show files only")
                
                Button(action: {
                    showFoldersOnly.toggle()
                    if showFoldersOnly && showFilesOnly {
                        showFilesOnly = false
                    }
                }) {
                    Image(systemName: "folder.fill")
                        .foregroundStyle(showFoldersOnly ? .blue : .secondary)
                        .font(.body)
                }
                .buttonStyle(.plain)
                .help(showFoldersOnly ? "Showing folders only (click to show all)" : "Show folders only")
                
                Divider()
                    .frame(height: 20)
                    .padding(.horizontal, 8)
                
                Text("\(filteredPaths.count) of \(pattern.paths.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                // Delete selected button (always visible)
                if !selectedFiles.isEmpty {
                    Divider()
                        .frame(height: 20)
                        .padding(.horizontal, 8)
                    
                    Button(action: { showingDeleteConfirmation = true }) {
                        HStack(spacing: 4) {
                            Image(systemName: "trash")
                            Text("\(selectedFiles.count)")
                        }
                        .font(.caption)
                        .foregroundStyle(.red)
                    }
                    .buttonStyle(.bordered)
                    .tint(.red)
                    .help("Delete \(selectedFiles.count) selected item\(selectedFiles.count == 1 ? "" : "s")")
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            
            Divider()
            
            // Sort Controls
            HStack {
                Text("Sort by:")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                Picker("Sort", selection: $sortOrder) {
                    ForEach(SortOrder.allCases, id: \.self) { order in
                        Text(order.rawValue).tag(order)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 180)
                
                if isCalculatingSizes {
                    ProgressView()
                        .scaleEffect(0.6)
                        .padding(.leading, 4)
                    Text("Calculating... (\(sizeCache.count)/\(pattern.paths.count))")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Button(action: cancelCalculations) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                    .help("Cancel size calculations")
                }
                
                Spacer()
                
                if showFilesOnly || showFoldersOnly || !searchText.isEmpty {
                    Text("\(filteredPaths.count) of \(pattern.paths.count)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(NSColor.controlBackgroundColor).opacity(0.5))
            
            Divider()
            
            // Files List
            if filteredPaths.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "doc.text.magnifyingglass")
                        .font(.system(size: 48))
                        .foregroundStyle(.secondary)
                    Text("No files match your search")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List(filteredPaths, id: \.self, selection: $selectedFiles) { path in
                    FilePathRow(
                        path: path,
                        sharedSizeCache: $sizeCache,
                        sharedLoadedSizes: $loadedSizes
                    )
                    .onTapGesture(count: 2) {
                        openInFinder(path: path)
                    }
                    .contextMenu {
                        // Right-click context menu
                        Button(action: { openInFinder(path: path) }) {
                            Label("Open in Finder", systemImage: "folder")
                        }
                        
                        Divider()
                        
                        Button(role: .destructive, action: {
                            selectedFiles.insert(path)
                            showingDeleteConfirmation = true
                        }) {
                            Label("Delete This Item", systemImage: "trash")
                        }
                    }
                }
                .listStyle(.plain)
            }
            
            Divider()
            
            // Footer with selection actions
            HStack(spacing: 12) {
                if selectedFiles.isEmpty {
                    Image(systemName: "info.circle")
                        .foregroundStyle(.secondary)
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text("💡 Click checkbox to select • Double-click to open in Finder • Right-click for options")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                } else {
                    // Selection info
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.blue)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(selectedFiles.count) item\(selectedFiles.count == 1 ? "" : "s") selected")
                        .font(.caption)
                                .fontWeight(.medium)
                            
                            Text("Total: \(selectedSizeString)")
                                .font(.caption2)
                        .foregroundStyle(.secondary)
                        }
                    }
                    
                    Spacer()
                    
                    // Action buttons
                    HStack(spacing: 8) {
                        Button("Clear") {
                        selectedFiles.removeAll()
                            selectedTotalSize = 0
                    }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    
                    Button(action: { showingDeleteConfirmation = true }) {
                            HStack(spacing: 4) {
                                Image(systemName: "trash.fill")
                                Text("Delete \(selectedFiles.count) Item\(selectedFiles.count == 1 ? "" : "s")")
                            }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                        .controlSize(.regular)
                        .help("Move selected items to trash")
                    }
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            .animation(.easeInOut(duration: 0.2), value: selectedFiles.isEmpty)
        }
        .frame(width: 700, height: 600)
        .background(Color(NSColor.windowBackgroundColor))
        .alert("Confirm Deletion", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Move to Trash", role: .destructive) {
                deleteSelectedFiles()
            }
        } message: {
            Text("Are you sure you want to move \(selectedFiles.count) item(s) (\(selectedSizeString)) to trash?")
        }
        .onChange(of: selectedFiles) {
            // Update selected size when selection changes
            updateSelectedSize()
        }
        .onDisappear {
            // Cancel any running calculations
            cancelCalculations()
            // Clear caches to free memory when view closes
            sizeCache.removeAll()
            loadedSizes.removeAll()
            selectedTotalSize = 0
            showDeleteButton = false
        }
    }
    
    private var safetyIcon: String {
        switch pattern.safetyScore {
        case .high: return "checkmark.shield.fill"
        case .medium: return "exclamationmark.shield.fill"
        case .low: return "xmark.shield.fill"
        }
    }
    
    private var safetyColor: Color {
        switch pattern.safetyScore {
        case .high: return .green
        case .medium: return .orange
        case .low: return .red
        }
    }
    
    private func deleteSelectedFiles() {
        let filesToDelete = Array(selectedFiles)
        
        Task { @MainActor in
            LogManager.shared.log("Deleting \(filesToDelete.count) individual files from pattern '\(pattern.patternName)'", level: .info, category: .deletion)
            
            let fileManager = FileManager.default
            var successCount = 0
            var failCount = 0
            
            for path in filesToDelete {
                do {
                    let url = URL(fileURLWithPath: path)
                    try fileManager.trashItem(at: url, resultingItemURL: nil)
                    successCount += 1
                    LogManager.shared.log("Moved to trash: \(path)", level: .success, category: .deletion)
                } catch {
                    failCount += 1
                    LogManager.shared.log("Failed to trash: \(path) - \(error.localizedDescription)", level: .error, category: .deletion)
                }
            }
            
            if failCount == 0 {
                LogManager.shared.log("Successfully moved \(successCount) items to trash", level: .success, category: .deletion)
            } else {
                LogManager.shared.log("Completed with \(successCount) successes and \(failCount) failures", level: .warning, category: .deletion)
            }
            
            // Clear selection and close
            selectedFiles.removeAll()
            isPresented = false
        }
    }
    
    private func openInFinder(path: String) {
        NSWorkspace.shared.selectFile(path, inFileViewerRootedAtPath: "")
        LogManager.shared.log("Opened in Finder: \(path)", level: .info, category: .general)
    }
}

// MARK: - File Path Row
struct FilePathRow: View {
    let path: String
    let sharedSizeCache: Binding<[String: Int64]>
    let sharedLoadedSizes: Binding<Set<String>>
    
    @State private var fileSize: String = "..."
    @State private var isDirectory: Bool = false
    @State private var hasLoadedInfo = false
    @State private var sizeCalculationFailed: Bool = false
    
    var displayPath: String {
        path.replacingOccurrences(of: FileManager.default.homeDirectoryForCurrentUser.path, with: "~")
    }
    
    var fileName: String {
        (path as NSString).lastPathComponent
    }
    
    var directoryPath: String {
        (path as NSString).deletingLastPathComponent
            .replacingOccurrences(of: FileManager.default.homeDirectoryForCurrentUser.path, with: "~")
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Icon
            Image(systemName: isDirectory ? "folder.fill" : "doc.fill")
                .foregroundStyle(isDirectory ? .blue : .secondary)
                .font(.title3)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                // File/Folder name
                Text(fileName)
                    .font(.body)
                    .lineLimit(1)
                
                // Directory path
                Text(directoryPath)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                
                // Size
                if sizeCalculationFailed {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(.orange)
                        Text("Unable to calculate")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                } else {
                    Text(fileSize)
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
            
            Spacer()
        }
        .padding(.vertical, 4)
        .onAppear {
            loadFileInfo()
        }
    }
    
    private func loadFileInfo() {
        // Prevent re-loading on every appear
        guard !hasLoadedInfo else { return }
        hasLoadedInfo = true

        // Check if we already have this size in cache
        if let cachedSize = sharedSizeCache.wrappedValue[path] {
            fileSize = ByteCountFormatter.string(fromByteCount: cachedSize, countStyle: .file)

            // Get directory status quickly
            var isDir: ObjCBool = false
            FileManager.default.fileExists(atPath: path, isDirectory: &isDir)
            isDirectory = isDir.boolValue
            return
        }

        // Check if already being loaded
        guard !sharedLoadedSizes.wrappedValue.contains(path) else {
            fileSize = "Loading..."
            return
        }

        // Mark as being loaded
        sharedLoadedSizes.wrappedValue.insert(path)

        Task.detached(priority: .utility) {
            let url = URL(fileURLWithPath: path)

            do {
                let resourceValues = try url.resourceValues(forKeys: [.fileSizeKey, .isDirectoryKey, .totalFileAllocatedSizeKey])

                let isDirValue = resourceValues.isDirectory ?? false
                let size: Int64

                if isDirValue {
                    // For directories, use quick estimation instead of full scan
                    size = Self.estimateDirectorySize(at: url)
                } else {
                    // Prefer allocated size for disk usage accuracy
                    if let allocatedSize = resourceValues.totalFileAllocatedSize {
                        size = Int64(allocatedSize)
                    } else {
                        size = Int64(resourceValues.fileSize ?? 0)
                    }
                }

                let sizeString = ByteCountFormatter.string(fromByteCount: size, countStyle: .file)

                await MainActor.run {
                    self.isDirectory = isDirValue
                    self.fileSize = sizeString

                    // Store in shared cache
                    self.sharedSizeCache.wrappedValue[path] = size
                }
            } catch {
                await MainActor.run {
                    self.sizeCalculationFailed = true
                }
            }
        }
    }

    /// Directory size estimation with proper extrapolation for large directories
    nonisolated private static func estimateDirectorySize(at url: URL) -> Int64 {
        let fileManager = FileManager.default
        var totalSize: Int64 = 0
        var fileCount = 0
        var totalFileCount = 0
        let sampleLimit = 500  // Increased sample size for better accuracy

        guard let enumerator = fileManager.enumerator(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .totalFileAllocatedSizeKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else { return 0 }

        for case let fileURL as URL in enumerator {
            totalFileCount += 1

            // Skip symlinks
            if let values = try? fileURL.resourceValues(forKeys: [.isSymbolicLinkKey]),
               values.isSymbolicLink == true {
                continue
            }

            // Sample files up to limit
            if fileCount < sampleLimit {
                if let size = try? fileURL.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileSizeKey]),
                   let allocatedSize = size.totalFileAllocatedSize {
                    totalSize += Int64(allocatedSize)
                } else if let size = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                    totalSize += Int64(size)
                }
                fileCount += 1
            }
        }

        // Extrapolate if we hit sample limit
        if fileCount >= sampleLimit && totalFileCount > sampleLimit {
            let averageSize = totalSize / Int64(fileCount)
            return averageSize * Int64(totalFileCount)
        }

        return totalSize
    }
}

#Preview {
    FilePatternDetailView(
        pattern: FilePattern(
            patternName: "node_modules",
            paths: [
                "/Users/test/project1/node_modules",
                "/Users/test/project2/node_modules",
                "/Users/test/old-project/node_modules"
            ],
            safetyScore: .high,
            reason: "NPM package cache that can be regenerated with npm install",
            count: 3,
            totalSize: 250_000_000
        ),
        isPresented: .constant(true)
    )
}
