import SwiftUI

struct SystemDataView: View {
    @StateObject private var scanner = SystemDataScanner.shared
    @State private var navigationPath: [SystemDataItem] = []
    @State private var selectedItems: Set<String> = []
    @State private var allItems: [String: SystemDataItem] = [:]
    @State private var loadingItems: Set<String> = []
    @State private var showingCleanConfirmation = false
    @State private var showingCategoryWarning = false
    @State private var categoryToClean: SystemDataCategory?
    @State private var cleaningResult: CleaningResult?
    @State private var showingResult = false
    @State private var showingPreview = false
    @State private var previewItems: [DeletionPreviewItem] = []

    var body: some View {
        NavigationStack(path: $navigationPath) {
            VStack(spacing: 0) {
                // Header
                SystemDataHeaderView(
                    scanner: scanner,
                    onScan: {
                        Task { await scanner.scanForSystemData() }
                    },
                    onClean: {
                        // Build preview items from selected categories
                        previewItems = scanner.categories
                            .filter { $0.isSelected && $0.hasData }
                            .flatMap { category in
                                category.detectedItems.map { item in
                                    DeletionPreviewItem(
                                        id: item.path,
                                        path: item.path,
                                        name: item.name,
                                        size: item.size,
                                        category: category.name,
                                        icon: item.iconName
                                    )
                                }
                            }
                        if previewItems.isEmpty {
                            // Fallback: show category-level preview
                            previewItems = scanner.categories
                                .filter { $0.isSelected && $0.hasData }
                                .map { category in
                                    DeletionPreviewItem(
                                        id: category.id,
                                        path: (category.paths.first! as NSString).expandingTildeInPath,
                                        name: category.name,
                                        size: category.detectedSize,
                                        category: "System Data",
                                        icon: category.icon
                                    )
                                }
                        }
                        showingPreview = true
                    }
                )

                Divider()

                if scanner.isScanning {
                    SystemDataScanningView(progress: scanner.scanProgress)
                } else if scanner.isCleaning {
                    SystemDataCleaningView(progress: scanner.cleaningProgress)
                } else {
                    // Categories list
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach($scanner.categories) { $category in
                                SystemDataCategoryRow(
                                    category: $category,
                                    onNavigate: {
                                        guard category.hasData else { return }
                                        // Navigate into first path of category
                                        let expandedPath = (category.paths.first! as NSString).expandingTildeInPath
                                        let item = SystemDataItem(
                                            id: expandedPath,
                                            path: expandedPath,
                                            name: category.name,
                                            size: category.detectedSize,
                                            isDirectory: true,
                                            iconName: category.icon,
                                            parentCategoryId: category.id
                                        )
                                        navigationPath.append(item)
                                    },
                                    onClean: {
                                        if category.warningMessage != nil || category.requiresAdmin {
                                            categoryToClean = category
                                            showingCategoryWarning = true
                                        } else {
                                            Task {
                                                let result = await scanner.cleanCategory(category)
                                                cleaningResult = result
                                                showingResult = true
                                            }
                                        }
                                    }
                                )
                                .padding(.horizontal)
                                .padding(.vertical, 4)

                                if category.id != scanner.categories.last?.id {
                                    Divider()
                                        .padding(.leading, 54)
                                }
                            }
                        }
                        .padding(.vertical, 8)
                    }

                    // Footer
                    if scanner.totalDataFound > 0 {
                        SystemDataFooterView(
                            totalSize: scanner.totalDataFound,
                            selectedSize: selectedDataSize,
                            selectedCount: selectedCount,
                            lastScan: scanner.lastScanDate
                        )
                    }
                }
            }
            .navigationDestination(for: SystemDataItem.self) { item in
                SystemDataDetailView(
                    item: item,
                    scanner: scanner,
                    selectedItems: $selectedItems,
                    navigationPath: $navigationPath,
                    loadingItems: $loadingItems,
                    allItems: $allItems
                )
            }
        }
        // Bulk clean confirmation
        .alert("Clean System Data", isPresented: $showingCleanConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Clean Selected", role: .destructive) {
                Task { await performCleaning() }
            }
        } message: {
            let warnings = scanner.categories
                .filter { $0.isSelected && $0.warningMessage != nil }
                .compactMap { $0.warningMessage }
            let adminCategories = scanner.categories
                .filter { $0.isSelected && $0.requiresAdmin }
                .map { $0.name }

            if !adminCategories.isEmpty && !warnings.isEmpty {
                Text("Admin privileges required for: \(adminCategories.joined(separator: ", "))\n\nWarnings:\n\(warnings.joined(separator: "\n"))\n\nThis action cannot be undone.")
            } else if !adminCategories.isEmpty {
                Text("Admin privileges required for: \(adminCategories.joined(separator: ", "))\n\nThis action cannot be undone.")
            } else if !warnings.isEmpty {
                Text("Warnings:\n\(warnings.joined(separator: "\n"))\n\nThis action cannot be undone.")
            } else {
                Text("Are you sure you want to clean the selected system data? This action cannot be undone.")
            }
        }
        // Category warning
        .alert("Warning", isPresented: $showingCategoryWarning) {
            Button("Cancel", role: .cancel) {
                categoryToClean = nil
            }
            Button("Clean Anyway", role: .destructive) {
                if let category = categoryToClean {
                    Task {
                        let result = await scanner.cleanCategory(category)
                        cleaningResult = result
                        showingResult = true
                    }
                }
                categoryToClean = nil
            }
        } message: {
            Text(categoryToClean?.warningMessage ?? "This action cannot be undone.")
        }
        // Cleaning result
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") { cleaningResult = nil }
        } message: {
            if let result = cleaningResult {
                Text("Cleaned \(result.success) items.\nFreed \(result.formattedBytesFreed) of space.")
            }
        }
        .sheet(isPresented: $showingPreview) {
            DeletionPreviewSheet(
                items: $previewItems,
                title: "Preview: System Data Cleanup",
                onConfirm: { confirmed in
                    showingPreview = false
                    Task { await performCleaning() }
                },
                onCancel: {
                    showingPreview = false
                }
            )
        }
        .onAppear {
            if scanner.lastScanDate == nil {
                Task { await scanner.scanForSystemData() }
            }
        }
    }

    private var selectedDataSize: Int64 {
        scanner.categories
            .filter { $0.isSelected }
            .reduce(0) { $0 + $1.detectedSize }
    }

    private var selectedCount: Int {
        scanner.categories.filter { $0.isSelected && $0.hasData }.count
    }

    private func performCleaning() async {
        let result = await scanner.cleanSelectedCategories()
        cleaningResult = result
        showingResult = true
    }
}

// MARK: - Header View

struct SystemDataHeaderView: View {
    @ObservedObject var scanner: SystemDataScanner
    let onScan: () -> Void
    let onClean: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Image(systemName: "externaldrive.fill.badge.icloud")
                        .foregroundStyle(.teal)
                    Text("System Data")
                        .font(.headline)
                }

                Text("Scan and clean caches, logs, temporary files, and developer data")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button(action: onScan) {
                Label("Scan", systemImage: "arrow.clockwise")
            }
            .buttonStyle(.bordered)
            .disabled(scanner.isScanning || scanner.isCleaning)

            Button(action: onClean) {
                Label("Clean Selected", systemImage: "trash")
            }
            .buttonStyle(.borderedProminent)
            .tint(.teal)
            .disabled(scanner.isScanning || scanner.isCleaning || selectedCount == 0)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }

    private var selectedCount: Int {
        scanner.categories.filter { $0.isSelected && $0.hasData }.count
    }
}

// MARK: - Scanning View

struct SystemDataScanningView: View {
    let progress: Double

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            ProgressView(value: progress)
                .progressViewStyle(LinearProgressViewStyle())
                .frame(width: 300)

            Text("Scanning system data...")
                .font(.headline)

            Text("Checking caches, logs, temp files, and developer data (\(Int(progress * 100))%)")
                .font(.caption)
                .foregroundStyle(.secondary)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Cleaning View

struct SystemDataCleaningView: View {
    let progress: Double

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            ProgressView(value: progress)
                .progressViewStyle(LinearProgressViewStyle())
                .frame(width: 300)

            Text("Cleaning system data...")
                .font(.headline)

            Text("\(Int(progress * 100))% complete")
                .font(.caption)
                .foregroundStyle(.secondary)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Category Row (top-level list)

struct SystemDataCategoryRow: View {
    @Binding var category: SystemDataCategory
    let onNavigate: () -> Void
    let onClean: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            // Checkbox
            Toggle("", isOn: $category.isSelected)
                .toggleStyle(.checkbox)
                .disabled(!category.hasData)

            // Icon
            Image(systemName: category.icon)
                .font(.title2)
                .foregroundStyle(category.hasData ? .teal : .secondary)
                .frame(width: 30)

            // Name & description
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(category.name)
                        .font(.subheadline)
                        .fontWeight(.medium)

                    if category.requiresAdmin {
                        Image(systemName: "lock.shield.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .help("Requires administrator privileges")
                    }

                    if category.warningMessage != nil {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .help(category.warningMessage ?? "")
                    }
                }

                Text(category.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if category.hasData {
                // Size
                VStack(alignment: .trailing, spacing: 2) {
                    Text(category.formattedSize)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.teal)

                    Text("\(category.itemCount) items")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                // Clean button
                Button(action: onClean) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.bordered)
                .help("Clean this category")

                // Navigate chevron
                Button(action: onNavigate) {
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            } else {
                Text("No data")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
        .onTapGesture {
            onNavigate()
        }
        .contextMenu {
            if category.hasData {
                Button(action: onNavigate) {
                    Label("Browse", systemImage: "arrow.right.circle")
                }

                Button(action: {
                    let path = (category.paths.first! as NSString).expandingTildeInPath
                    NSWorkspace.shared.selectFile(path, inFileViewerRootedAtPath: "")
                }) {
                    Label("Open in Finder", systemImage: "folder")
                }

                Divider()

                Button(action: onClean) {
                    Label("Clean", systemImage: "trash")
                }
            }
        }
    }
}

// MARK: - Detail View (NavigationStack destination, like StorageItemDetailView)

struct SystemDataDetailView: View {
    let item: SystemDataItem
    @ObservedObject var scanner: SystemDataScanner
    @Binding var selectedItems: Set<String>
    @Binding var navigationPath: [SystemDataItem]
    @Binding var loadingItems: Set<String>
    @Binding var allItems: [String: SystemDataItem]
    @State private var children: [SystemDataItem] = []
    @State private var isLoading = false
    @State private var sortOrder: SystemDataSortOrder = .sizeDescending
    @State private var showingDeleteConfirmation = false
    @State private var showingDeletionProgress = false
    @State private var deletionCurrentItem = 0
    @State private var deletionCurrentItemName = ""
    @State private var deletionIsCompleted = false
    @State private var deletionSuccessCount = 0
    @State private var deletionFailedCount = 0
    @State private var deletionTotalItems = 0

    enum SystemDataSortOrder: String, CaseIterable {
        case sizeDescending = "Size (Largest)"
        case sizeAscending = "Size (Smallest)"
        case nameAscending = "Name (A-Z)"
        case nameDescending = "Name (Z-A)"
        case typeFirst = "Type (Folders First)"
    }

    var sortedChildren: [SystemDataItem] {
        var result = children
        switch sortOrder {
        case .sizeDescending:
            result.sort { $0.size > $1.size }
        case .sizeAscending:
            result.sort { $0.size < $1.size }
        case .nameAscending:
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case .nameDescending:
            result.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedDescending }
        case .typeFirst:
            result.sort { item1, item2 in
                if item1.isDirectory != item2.isDirectory {
                    return item1.isDirectory && !item2.isDirectory
                }
                if item1.size != item2.size {
                    return item1.size > item2.size
                }
                return item1.name.localizedCaseInsensitiveCompare(item2.name) == .orderedAscending
            }
        }
        return result
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Image(systemName: item.iconName)
                    .font(.title)
                    .foregroundStyle(.teal)

                VStack(alignment: .leading, spacing: 4) {
                    Text(item.name)
                        .font(.title2)
                        .fontWeight(.bold)

                    Text(item.path)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Text(formatSize(item.size))
                    .font(.headline)
                    .foregroundStyle(.secondary)
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            // Sort controls
            if !children.isEmpty {
                HStack {
                    Text("Sort by:")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Picker("Sort", selection: $sortOrder) {
                        ForEach(SystemDataSortOrder.allCases, id: \.self) { order in
                            Text(order.rawValue).tag(order)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(width: 180)

                    Button(action: toggleSelectAllInView) {
                        HStack(spacing: 4) {
                            Image(systemName: allItemsSelectedInView() ? "checkmark.square.fill" : "checkmark.square")
                            Text(allItemsSelectedInView() ? "Deselect All" : "Select All")
                        }
                        .font(.caption)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)

                    Spacer()

                    Button(action: {
                        Task { await refreshCurrentFolder() }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.clockwise")
                            Text("Refresh")
                        }
                        .font(.caption)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    .disabled(isLoading)
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(NSColor.controlBackgroundColor).opacity(0.5))

                Divider()
            }

            // Items list
            if isLoading {
                ProgressView("Loading...")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if children.isEmpty {
                Text("No items found")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(sortedChildren) { child in
                        SystemDataItemRow(
                            item: child,
                            isSelected: selectedItems.contains(child.path),
                            isLoading: loadingItems.contains(child.path),
                            onSelect: { toggleSelection(child) },
                            onNavigate: {
                                if child.isDirectory {
                                    navigationPath.append(child)
                                }
                            }
                        )
                    }
                }
                .listStyle(.inset(alternatesRowBackgrounds: true))
            }

            Divider()

            // Footer
            SystemDataItemFooterView(
                selectedCount: selectedItemsInThisView().count,
                totalSize: formatSize(calculateSelectedSizeInView()),
                onDelete: { showingDeleteConfirmation = true },
                onClear: { clearSelectionInView() }
            )
        }
        .navigationTitle(item.name)
        .task {
            await loadChildren()
        }
        .alert("Confirm Deletion", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Move to Trash", role: .destructive) {
                Task { await deleteSelectedInView() }
            }
        } message: {
            let count = selectedItemsInThisView().count
            let size = formatSize(calculateSelectedSizeInView())
            Text("Are you sure you want to move \(count) item\(count == 1 ? "" : "s") (\(size)) to trash?")
        }
        .sheet(isPresented: $showingDeletionProgress) {
            DeletionProgressView(
                totalItems: $deletionTotalItems,
                currentItem: $deletionCurrentItem,
                currentItemName: $deletionCurrentItemName,
                isCompleted: $deletionIsCompleted,
                successCount: $deletionSuccessCount,
                failedCount: $deletionFailedCount
            )
            .interactiveDismissDisabled(!deletionIsCompleted)
        }
    }

    // MARK: - Data Loading

    private func loadChildren() async {
        guard item.isDirectory else { return }

        isLoading = true
        defer { isLoading = false }

        let loadedChildren = scanner.getChildren(for: item)

        children = loadedChildren
        for child in loadedChildren {
            allItems[child.path] = child
        }

        // Calculate sizes for directories in parallel
        let directoriesNeedingSize = loadedChildren.filter { $0.isDirectory && $0.size == -1 }
        guard !directoriesNeedingSize.isEmpty else { return }

        for item in directoriesNeedingSize {
            loadingItems.insert(item.path)
        }

        let sizes = await scanner.calculateSizesInParallel(for: directoriesNeedingSize)

        for index in children.indices {
            if let size = sizes[children[index].path] {
                children[index].size = size
                allItems[children[index].path]?.size = size
                loadingItems.remove(children[index].path)
            }
        }
    }

    private func refreshCurrentFolder() async {
        isLoading = true
        defer { isLoading = false }

        let refreshedChildren = scanner.getChildren(for: item)

        let oldPaths = Set(children.map { $0.path })
        children = refreshedChildren

        for oldPath in oldPaths {
            if !refreshedChildren.contains(where: { $0.path == oldPath }) {
                allItems.removeValue(forKey: oldPath)
            }
        }
        for child in refreshedChildren {
            allItems[child.path] = child
        }

        let directoriesNeedingSize = refreshedChildren.filter { $0.isDirectory && $0.size == -1 }
        if !directoriesNeedingSize.isEmpty {
            for item in directoriesNeedingSize {
                loadingItems.insert(item.path)
            }

            let sizes = await scanner.calculateSizesInParallel(for: directoriesNeedingSize)

            for index in children.indices {
                if let size = sizes[children[index].path] {
                    children[index].size = size
                    allItems[children[index].path]?.size = size
                    loadingItems.remove(children[index].path)
                }
            }
        }
    }

    // MARK: - Selection

    private func toggleSelection(_ item: SystemDataItem) {
        if selectedItems.contains(item.path) {
            selectedItems.remove(item.path)
        } else {
            selectedItems.insert(item.path)
            allItems[item.path] = item
        }
    }

    private func selectedItemsInThisView() -> [SystemDataItem] {
        children.filter { selectedItems.contains($0.path) }
    }

    private func calculateSelectedSizeInView() -> Int64 {
        selectedItemsInThisView().reduce(0) { $0 + max($1.size, 0) }
    }

    private func clearSelectionInView() {
        let childPaths = Set(children.map { $0.path })
        selectedItems.subtract(childPaths)
    }

    private func allItemsSelectedInView() -> Bool {
        !children.isEmpty && selectedItemsInThisView().count == children.count
    }

    private func toggleSelectAllInView() {
        if allItemsSelectedInView() {
            clearSelectionInView()
        } else {
            let childPaths = Set(children.map { $0.path })
            selectedItems.formUnion(childPaths)
        }
    }

    // MARK: - Deletion

    private func deleteSelectedInView() async {
        let itemsToDelete = selectedItemsInThisView()
        guard !itemsToDelete.isEmpty else { return }

        deletionTotalItems = itemsToDelete.count
        deletionCurrentItem = 0
        deletionCurrentItemName = ""
        deletionIsCompleted = false
        deletionSuccessCount = 0
        deletionFailedCount = 0
        showingDeletionProgress = true

        var deletedPaths: [String] = []

        for (index, item) in itemsToDelete.enumerated() {
            deletionCurrentItem = index + 1
            deletionCurrentItemName = item.name

            do {
                try await scanner.deleteItem(
                    at: item.path,
                    requiresAdmin: PrivilegedFileManager.shared.requiresAdminPrivileges(path: item.path)
                )
                deletedPaths.append(item.path)
                deletionSuccessCount += 1
                LogManager.shared.log("Moved to trash: \(item.path)", level: .success, category: .deletion)
            } catch {
                deletionFailedCount += 1
                LogManager.shared.log("Failed to delete \(item.path): \(error.localizedDescription)", level: .error, category: .deletion)
            }

            try? await Task.sleep(nanoseconds: 100_000_000)
        }

        deletionIsCompleted = true
        try? await Task.sleep(nanoseconds: 1_500_000_000)

        showingDeletionProgress = false
        selectedItems.subtract(deletedPaths)
        children.removeAll { deletedPaths.contains($0.path) }
        for path in deletedPaths {
            allItems.removeValue(forKey: path)
        }

        await refreshCurrentFolder()
    }

    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: max(bytes, 0), countStyle: .file)
    }
}

// MARK: - Item Row (like StorageItemRow)

struct SystemDataItemRow: View {
    let item: SystemDataItem
    let isSelected: Bool
    let isLoading: Bool
    let onSelect: () -> Void
    let onNavigate: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            // Checkbox
            Button(action: onSelect) {
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(isSelected ? .teal : .secondary)
            }
            .buttonStyle(.plain)

            // Icon
            Image(systemName: item.iconName)
                .foregroundStyle(item.isDirectory ? .teal : .secondary)
                .frame(width: 24)

            // Name
            Text(item.name)
                .font(.body)

            Spacer()

            // Size
            if isLoading || (item.isDirectory && item.size == -1) {
                HStack(spacing: 4) {
                    ProgressView()
                        .scaleEffect(0.7)
                    Text("Calculating...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else {
                Text(formatSize(item.size))
                    .font(.body)
                    .foregroundStyle(.secondary)
            }

            // Chevron for directories
            if item.isDirectory {
                Button(action: onNavigate) {
                    Image(systemName: "chevron.right")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
        .onTapGesture {
            if item.isDirectory {
                onNavigate()
            } else {
                onSelect()
            }
        }
        .contextMenu {
            Button(action: {
                NSWorkspace.shared.selectFile(item.path, inFileViewerRootedAtPath: "")
            }) {
                Label("Open in Finder", systemImage: "folder")
            }

            if item.isDirectory {
                Button(action: onNavigate) {
                    Label("Open", systemImage: "arrow.right.circle")
                }
            }

            Divider()

            Button(action: onSelect) {
                Label(isSelected ? "Deselect" : "Select", systemImage: isSelected ? "checkmark.square" : "square")
            }
        }
    }

    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: max(bytes, 0), countStyle: .file)
    }
}

// MARK: - Item Footer View

struct SystemDataItemFooterView: View {
    let selectedCount: Int
    let totalSize: String
    let onDelete: () -> Void
    let onClear: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            if selectedCount > 0 {
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.teal)

                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(selectedCount) item\(selectedCount == 1 ? "" : "s") selected")
                            .font(.caption)
                            .fontWeight(.medium)

                        Text("Total: \(totalSize)")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }

                Spacer()

                HStack(spacing: 8) {
                    Button("Clear") { onClear() }
                        .buttonStyle(.bordered)
                        .controlSize(.small)

                    Button(action: onDelete) {
                        HStack(spacing: 4) {
                            Image(systemName: "trash.fill")
                            Text("Delete \(selectedCount) Item\(selectedCount == 1 ? "" : "s")")
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .controlSize(.regular)
                }
            } else {
                Image(systemName: "info.circle")
                    .foregroundStyle(.secondary)

                Text("Click checkbox to select files/folders for deletion")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Spacer()
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .animation(.easeInOut(duration: 0.2), value: selectedCount)
    }
}

// MARK: - Footer View (top-level categories)

struct SystemDataFooterView: View {
    let totalSize: Int64
    let selectedSize: Int64
    let selectedCount: Int
    let lastScan: Date?

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Total system data: \(ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file))")
                    .font(.callout)

                if selectedCount > 0 {
                    Text("Selected: \(selectedCount) categories (\(ByteCountFormatter.string(fromByteCount: selectedSize, countStyle: .file)))")
                        .font(.caption)
                        .foregroundStyle(.teal)
                }

                if let lastScan = lastScan {
                    Text("Last scanned: \(lastScan.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

#Preview {
    SystemDataView()
}
