import SwiftUI

struct PrivacyCleanerView: View {
    @StateObject private var privacyCleaner = PrivacyCleaner.shared
    @State private var showingCleanConfirmation = false
    @State private var showingCategoryWarning = false
    @State private var categoryToClean: PrivacyCategory?
    @State private var cleaningResult: CleaningResult?
    @State private var showingResult = false
    @State private var showingPreview = false
    @State private var previewItems: [DeletionPreviewItem] = []

    var body: some View {
        VStack(spacing: 0) {
            // Header
            PrivacyHeaderView(
                privacyCleaner: privacyCleaner,
                onScan: {
                    Task { await privacyCleaner.scanForPrivacyData() }
                },
                onClean: {
                    // Build preview from selected categories
                    previewItems = privacyCleaner.categories
                        .filter { $0.isSelected && $0.hasData }
                        .flatMap { category in
                            category.detectedPaths.map { path in
                                DeletionPreviewItem(
                                    id: path,
                                    path: path,
                                    name: (path as NSString).lastPathComponent,
                                    size: 0, // individual sizes not tracked
                                    category: category.name,
                                    icon: category.icon
                                )
                            }
                        }
                    if previewItems.isEmpty {
                        previewItems = privacyCleaner.categories
                            .filter { $0.isSelected && $0.hasData }
                            .map { category in
                                DeletionPreviewItem(
                                    id: category.id,
                                    path: category.paths.first ?? "",
                                    name: category.name,
                                    size: category.detectedSize,
                                    category: "Privacy Data",
                                    icon: category.icon
                                )
                            }
                    }
                    showingPreview = true
                }
            )

            Divider()

            if privacyCleaner.isScanning {
                PrivacyScanningView()
            } else if privacyCleaner.isCleaning {
                PrivacyCleaningProgressView(progress: privacyCleaner.cleaningProgress)
            } else {
                // Categories List
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach($privacyCleaner.categories) { $category in
                            PrivacyCategoryCard(
                                category: $category,
                                onClean: {
                                    if category.requiresConfirmation {
                                        categoryToClean = category
                                        showingCategoryWarning = true
                                    } else {
                                        Task {
                                            let result = await privacyCleaner.cleanCategory(category)
                                            cleaningResult = result
                                            showingResult = true
                                        }
                                    }
                                }
                            )
                        }
                    }
                    .padding()
                }

                // Footer with summary
                if privacyCleaner.totalDataFound > 0 {
                    PrivacyFooterView(
                        totalSize: privacyCleaner.totalDataFound,
                        selectedSize: selectedDataSize,
                        selectedCount: selectedCount,
                        lastScan: privacyCleaner.lastScanDate
                    )
                }
            }
        }
        .alert("Clean Privacy Data", isPresented: $showingCleanConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Clean Selected", role: .destructive) {
                Task { await performCleaning() }
            }
        } message: {
            let warnings = privacyCleaner.categories
                .filter { $0.isSelected && $0.warningMessage != nil }
                .compactMap { $0.warningMessage }

            if warnings.isEmpty {
                Text("Are you sure you want to clean the selected privacy data? This action cannot be undone.")
            } else {
                Text("Warning:\n" + warnings.joined(separator: "\n") + "\n\nThis action cannot be undone.")
            }
        }
        .alert("Warning", isPresented: $showingCategoryWarning) {
            Button("Cancel", role: .cancel) {
                categoryToClean = nil
            }
            Button("Clean Anyway", role: .destructive) {
                if let category = categoryToClean {
                    Task {
                        let result = await privacyCleaner.cleanCategory(category)
                        cleaningResult = result
                        showingResult = true
                    }
                }
                categoryToClean = nil
            }
        } message: {
            Text(categoryToClean?.warningMessage ?? "This action cannot be undone.")
        }
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") {
                cleaningResult = nil
            }
        } message: {
            if let result = cleaningResult {
                Text("Cleaned \(result.success) items.\nFreed \(result.formattedBytesFreed) of space.")
            }
        }
        .sheet(isPresented: $showingPreview) {
            DeletionPreviewSheet(
                items: $previewItems,
                title: "Preview: Privacy Data Cleanup",
                onConfirm: { _ in
                    showingPreview = false
                    Task { await performCleaning() }
                },
                onCancel: { showingPreview = false }
            )
        }
        .onAppear {
            if privacyCleaner.lastScanDate == nil {
                Task { await privacyCleaner.scanForPrivacyData() }
            }
        }
    }

    private var selectedDataSize: Int64 {
        privacyCleaner.categories
            .filter { $0.isSelected }
            .reduce(0) { $0 + $1.detectedSize }
    }

    private var selectedCount: Int {
        privacyCleaner.categories.filter { $0.isSelected && $0.hasData }.count
    }

    private func performCleaning() async {
        let result = await privacyCleaner.cleanSelectedCategories()
        cleaningResult = result
        showingResult = true
    }
}

// MARK: - Header View

struct PrivacyHeaderView: View {
    @ObservedObject var privacyCleaner: PrivacyCleaner
    let onScan: () -> Void
    let onClean: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Image(systemName: "hand.raised.fill")
                        .foregroundStyle(.purple)
                    Text("Privacy Cleaner")
                        .font(.headline)
                }

                Text("Remove tracking data, browsing history, and diagnostic reports")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button(action: onScan) {
                Label("Scan", systemImage: "arrow.clockwise")
            }
            .buttonStyle(.bordered)
            .disabled(privacyCleaner.isScanning || privacyCleaner.isCleaning)

            Button(action: onClean) {
                Label("Clean Selected", systemImage: "trash")
            }
            .buttonStyle(.borderedProminent)
            .tint(.purple)
            .disabled(privacyCleaner.isScanning || privacyCleaner.isCleaning || selectedCount == 0)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }

    private var selectedCount: Int {
        privacyCleaner.categories.filter { $0.isSelected && $0.hasData }.count
    }
}

// MARK: - Scanning View

struct PrivacyScanningView: View {
    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            ProgressView()
                .scaleEffect(1.5)

            Text("Scanning for privacy data...")
                .font(.headline)

            Text("Checking system caches, recent files, and browser data")
                .font(.caption)
                .foregroundStyle(.secondary)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Cleaning Progress View

struct PrivacyCleaningProgressView: View {
    let progress: Double

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            ProgressView(value: progress)
                .progressViewStyle(LinearProgressViewStyle())
                .frame(width: 300)

            Text("Cleaning privacy data...")
                .font(.headline)

            Text("\(Int(progress * 100))% complete")
                .font(.caption)
                .foregroundStyle(.secondary)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Category Card

struct PrivacyCategoryCard: View {
    @Binding var category: PrivacyCategory
    let onClean: () -> Void

    var body: some View {
        HStack {
            Toggle("", isOn: $category.isSelected)
                .toggleStyle(.checkbox)
                .disabled(!category.hasData)

            Image(systemName: category.icon)
                .font(.title2)
                .foregroundStyle(category.hasData ? .purple : .secondary)
                .frame(width: 32)

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(category.name)
                        .font(.subheadline)
                        .fontWeight(.medium)

                    if category.requiresConfirmation {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .help(category.warningMessage ?? "Requires confirmation")
                    }
                }

                Text(category.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if category.hasData {
                VStack(alignment: .trailing, spacing: 2) {
                    Text(category.formattedSize)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.purple)

                    Text("\(category.detectedPaths.count) items")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Button(action: onClean) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.bordered)
                .help("Clean this category")
            } else {
                Text("No data")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(10)
        .opacity(category.hasData ? 1.0 : 0.6)
    }
}

// MARK: - Footer View

struct PrivacyFooterView: View {
    let totalSize: Int64
    let selectedSize: Int64
    let selectedCount: Int
    let lastScan: Date?

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Total privacy data: \(ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file))")
                    .font(.callout)

                if selectedCount > 0 {
                    Text("Selected: \(selectedCount) categories (\(ByteCountFormatter.string(fromByteCount: selectedSize, countStyle: .file)))")
                        .font(.caption)
                        .foregroundStyle(.purple)
                }

                if let lastScan = lastScan {
                    Text("Last scanned: \(lastScan.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

#Preview {
    PrivacyCleanerView()
}
