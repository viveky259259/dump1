import SwiftUI
import Charts
import AppKit

struct SettingsView: View {
    @StateObject private var performanceManager = PerformanceManager.shared
    @State private var showingClearConfirmation = false
    @State private var selectedTimeRange: TimeRange = .week
    
    enum TimeRange: String, CaseIterable {
        case week = "Last 7 Days"
        case month = "Last 30 Days"
        case all = "All Time"
        
        var days: Int? {
            switch self {
            case .week: return 7
            case .month: return 30
            case .all: return nil
            }
        }
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Header
                HStack {
                    Image(systemName: "chart.line.uptrend.xyaxis")
                        .font(.title2)
                        .foregroundStyle(.blue)
                    
                    Text("Performance Analytics")
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    Spacer()
                    
                    // Time range selector
                    Picker("Time Range", selection: $selectedTimeRange) {
                        ForEach(TimeRange.allCases, id: \.self) { range in
                            Text(range.rawValue).tag(range)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(width: 150)
                }
                .padding(.horizontal)
                .padding(.top)
                
                Divider()
                
                // Summary Cards
                SummaryCardsView(stats: performanceManager.getAggregatedStats(days: selectedTimeRange.days ?? 365))
                    .padding(.horizontal)
                
                // Charts Section
                VStack(alignment: .leading, spacing: 16) {
                    Text("Performance Trends")
                        .font(.headline)
                        .padding(.horizontal)
                    
                    // Scan Duration Chart
                    ScanDurationChartView(sessions: performanceManager.getMetricsForPeriod(days: selectedTimeRange.days ?? 365))
                        .frame(height: 200)
                        .padding(.horizontal)
                    
                    // Memory Usage Chart
                    MemoryUsageChartView(sessions: performanceManager.getMetricsForPeriod(days: selectedTimeRange.days ?? 365))
                        .frame(height: 200)
                        .padding(.horizontal)
                }
                
                // Recent Operations
                RecentOperationsView(sessions: performanceManager.getMetricsForPeriod(days: selectedTimeRange.days ?? 365))
                    .padding(.horizontal)
                
                // Protection Rules (Whitelist)
                WhitelistView()
                    .padding(.horizontal)

                // Startup Items Manager
                StartupItemsView()
                    .padding(.horizontal)

                // App Settings
                AppSettingsSection()
                    .padding(.horizontal)

                // Data Management
                DataManagementView(
                    showingClearConfirmation: $showingClearConfirmation,
                    onClear: {
                        performanceManager.clearAllData()
                    },
                    onExport: {
                        exportPerformanceData()
                    }
                )
                .padding(.horizontal)
                .padding(.bottom)
            }
        }
        .alert("Clear All Performance Data", isPresented: $showingClearConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Clear", role: .destructive) {
                performanceManager.clearAllData()
            }
        } message: {
            Text("This will permanently delete all performance analytics data. This action cannot be undone.")
        }
    }
    
    private func exportPerformanceData() {
        let exportText = performanceManager.exportData()
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.plainText]
        savePanel.nameFieldStringValue = "FileCleanerAI_Performance_\(Date().formatted(date: .numeric, time: .shortened)).txt"
        
        savePanel.begin { response in
            if response == .OK, let url = savePanel.url {
                try? exportText.write(to: url, atomically: true, encoding: .utf8)
            }
        }
    }
}

// MARK: - Summary Cards

struct SummaryCardsView: View {
    let stats: PerformanceStats
    
    var body: some View {
        LazyVGrid(columns: [
            GridItem(.flexible()),
            GridItem(.flexible()),
            GridItem(.flexible()),
            GridItem(.flexible())
        ], spacing: 16) {
            SummaryCard(
                title: "Total Scans",
                value: "\(stats.totalScans)",
                icon: "magnifyingglass",
                color: .blue
            )
            
            SummaryCard(
                title: "Avg Scan Time",
                value: stats.formattedAverageScanDuration,
                icon: "clock",
                color: .orange
            )
            
            SummaryCard(
                title: "Files Cleaned",
                value: "\(stats.totalDeletions)",
                icon: "trash",
                color: .red
            )
            
            SummaryCard(
                title: "Space Freed",
                value: stats.formattedTotalBytesFreed,
                icon: "externaldrive",
                color: .green
            )
        }
    }
}

struct SummaryCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(color)
                Spacer()
            }
            
            Text(value)
                .font(.title2)
                .fontWeight(.semibold)
            
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
    }
}

// MARK: - Scan Duration Chart

struct ScanDurationChartView: View {
    let sessions: [PerformanceSession]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Scan Duration Over Time")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            
            if #available(macOS 14.0, *) {
                Chart {
                    ForEach(sessions.compactMap { session -> (Date, TimeInterval)? in
                        guard let scan = session.scanMetrics else { return nil }
                        return (session.sessionStart, scan.duration)
                    }, id: \.0) { item in
                        LineMark(
                            x: .value("Date", item.0),
                            y: .value("Duration", item.1)
                        )
                        .foregroundStyle(.blue)
                        .interpolationMethod(.catmullRom)
                        
                        AreaMark(
                            x: .value("Date", item.0),
                            y: .value("Duration", item.1)
                        )
                        .foregroundStyle(.blue.opacity(0.1))
                        .interpolationMethod(.catmullRom)
                    }
                }
                .chartXAxis {
                    AxisMarks(values: .automatic(desiredCount: 5))
                }
                .chartYAxis {
                    AxisMarks { value in
                        AxisGridLine()
                        AxisValueLabel {
                            if let duration = value.as(TimeInterval.self) {
                                Text(formatDuration(duration))
                            }
                        }
                    }
                }
            } else {
                // Fallback for macOS < 14.0
                Text("Charts require macOS 14.0+")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        if duration < 60 {
            return String(format: "%.0fs", duration)
        } else {
            let minutes = Int(duration / 60)
            return "\(minutes)m"
        }
    }
}

// MARK: - Memory Usage Chart

struct MemoryUsageChartView: View {
    let sessions: [PerformanceSession]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Peak Memory Usage")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            
            if #available(macOS 14.0, *) {
                Chart {
                    ForEach(sessions.compactMap { session -> (Date, Int64)? in
                        guard let scan = session.scanMetrics else { return nil }
                        return (session.sessionStart, scan.peakMemory)
                    }, id: \.0) { item in
                        BarMark(
                            x: .value("Date", item.0),
                            y: .value("Memory", item.1)
                        )
                        .foregroundStyle(.orange.gradient)
                    }
                }
                .chartXAxis {
                    AxisMarks(values: .automatic(desiredCount: 5))
                }
                .chartYAxis {
                    AxisMarks { value in
                        AxisGridLine()
                        AxisValueLabel {
                            if let bytes = value.as(Int64.self) {
                                Text(formatBytes(bytes))
                            }
                        }
                    }
                }
            } else {
                // Fallback for macOS < 14.0
                Text("Charts require macOS 14.0+")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
    }
    
    private func formatBytes(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .memory
        formatter.allowedUnits = [.useMB, .useGB]
        return formatter.string(fromByteCount: bytes)
    }
}

// MARK: - Recent Operations

struct RecentOperationsView: View {
    let sessions: [PerformanceSession]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Recent Operations")
                .font(.headline)
            
            if sessions.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "chart.bar.doc.horizontal")
                        .font(.system(size: 48))
                        .foregroundStyle(.secondary)
                    
                    Text("No Performance Data")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    
                    Text("Performance data will appear here after you run scans and deletions.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
            } else {
                ForEach(Array(sessions.prefix(10).reversed()), id: \.id) { session in
                    OperationRowView(session: session)
                }
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
    }
}

struct OperationRowView: View {
    let session: PerformanceSession
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(session.sessionStart.formatted(date: .abbreviated, time: .shortened))
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Spacer()
                
                if let end = session.sessionEnd {
                    Text(formatDuration(end.timeIntervalSince(session.sessionStart)))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            
            HStack(spacing: 16) {
                if let scan = session.scanMetrics {
                    OperationBadge(
                        icon: "magnifyingglass",
                        label: "\(scan.filesScanned) files",
                        color: .blue
                    )
                }
                
                if let ai = session.aiMetrics {
                    OperationBadge(
                        icon: "sparkles",
                        label: "\(ai.patternsDetected) patterns",
                        color: .purple
                    )
                }
                
                if !session.deletionMetrics.isEmpty {
                    let totalDeleted = session.totalDeletions
                    OperationBadge(
                        icon: "trash",
                        label: "\(totalDeleted) deleted",
                        color: .red
                    )
                }
            }
        }
        .padding(.vertical, 4)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        if duration < 60 {
            return String(format: "%.0fs", duration)
        } else {
            let minutes = Int(duration / 60)
            let seconds = Int(duration.truncatingRemainder(dividingBy: 60))
            return "\(minutes)m \(seconds)s"
        }
    }
}

struct OperationBadge: View {
    let icon: String
    let label: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .font(.caption2)
            Text(label)
                .font(.caption)
        }
        .foregroundStyle(color)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(color.opacity(0.1))
        .cornerRadius(6)
    }
}

// MARK: - Data Management

struct DataManagementView: View {
    @Binding var showingClearConfirmation: Bool
    let onClear: () -> Void
    let onExport: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Data Management")
                .font(.headline)
            
            HStack(spacing: 12) {
                Button(action: onExport) {
                    Label("Export Data", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(.bordered)
                
                Button(role: .destructive, action: {
                    showingClearConfirmation = true
                }) {
                    Label("Clear All Data", systemImage: "trash")
                }
                .buttonStyle(.bordered)
            }
            
            Text("Performance data is automatically retained for 7 days. You can export it for analysis or clear it manually.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
    }
}

// MARK: - App Settings Section

struct AppSettingsSection: View {
    @StateObject private var menuBarManager = MenuBarManager.shared
    @StateObject private var configExporter = ConfigExporter.shared
    @State private var showingImportResult = false
    @State private var importSuccess = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("App Settings")
                .font(.headline)

            // Menu Bar Toggle
            GroupBox {
                Toggle(isOn: $menuBarManager.isEnabled) {
                    HStack {
                        Image(systemName: "menubar.rectangle")
                            .foregroundStyle(.blue)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Show in Menu Bar")
                                .font(.subheadline)
                            Text("Quick access to disk health, schedule status, and scanning")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }

            // Export / Import
            GroupBox(label: Label("Configuration", systemImage: "gearshape.2")) {
                HStack(spacing: 12) {
                    Button(action: {
                        Task { _ = await configExporter.exportToFile() }
                    }) {
                        VStack(spacing: 4) {
                            Image(systemName: "square.and.arrow.up")
                                .font(.title3)
                            Text("Export")
                                .font(.caption)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                    }
                    .buttonStyle(.bordered)

                    Button(action: {
                        Task {
                            importSuccess = await configExporter.importFromFile()
                            showingImportResult = true
                        }
                    }) {
                        VStack(spacing: 4) {
                            Image(systemName: "square.and.arrow.down")
                                .font(.title3)
                            Text("Import")
                                .font(.caption)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)
                    }
                    .buttonStyle(.bordered)
                }

                Text("Export/import whitelist rules, schedule settings, and preferences")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
        .alert(importSuccess ? "Import Successful" : "Import Failed", isPresented: $showingImportResult) {
            Button("OK") {}
        } message: {
            Text(importSuccess ? "Configuration has been applied." : "Failed to import configuration. Check the file format.")
        }
    }
}

#Preview {
    SettingsView()
        .frame(width: 900, height: 700)
}
