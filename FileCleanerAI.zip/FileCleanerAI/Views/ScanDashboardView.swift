import SwiftUI

struct ScanDashboardView: View {
    @ObservedObject var scanner: FileScanner
    @State private var selectedDirectory: ScanDirectory?
    
    var body: some View {
        HStack(spacing: 0) {
            // Left: Directory List
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Scan Locations")
                        .font(.headline)
                        .fontWeight(.semibold)
                    
                    Spacer()
                    
                    Text("\(scanner.scanDirectories.count) folders")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding()
                .background(Color(NSColor.controlBackgroundColor))
                
                Divider()
                
                // Directory List
                List(scanner.scanDirectories, selection: $selectedDirectory) { directory in
                    DirectoryRowView(directory: directory)
                        .tag(directory)
                }
                .listStyle(.sidebar)
            }
            .frame(width: 300)
            
            Divider()
            
            // Right: Detail View
            if let directory = selectedDirectory {
                DirectoryDetailView(directory: directory)
            } else {
                EmptySelectionView()
            }
        }
    }
}

// MARK: - Directory Row
struct DirectoryRowView: View {
    let directory: ScanDirectory
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: "folder.fill")
                    .foregroundStyle(.blue)
                
                Text(directory.displayName)
                    .font(.body)
                    .fontWeight(.medium)
                
                Spacer()
                
                StatusBadge(status: directory.status)
            }
            
            HStack(spacing: 12) {
                Label("\(directory.itemsFound) items", systemImage: "doc")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                if directory.totalSize > 0 {
                    Label(formatSize(directory.totalSize), systemImage: "internaldrive")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            
            // Progress bar for scanning
            if case .inProgress = directory.status {
                ProgressView()
                    .progressViewStyle(.linear)
                    .scaleEffect(x: 1, y: 0.5)
            }
        }
        .padding(.vertical, 4)
    }
    
    private func formatSize(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}

// MARK: - Status Badge
struct StatusBadge: View {
    let status: ScanDirectory.ScanStatus
    
    var body: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(statusColor)
                .frame(width: 8, height: 8)
            
            Text(status.displayText)
                .font(.caption2)
                .fontWeight(.medium)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(statusColor.opacity(0.15))
        .cornerRadius(8)
    }
    
    private var statusColor: Color {
        switch status {
        case .pending: return .gray
        case .inProgress: return .blue
        case .completed: return .green
        case .failed: return .red
        }
    }
}

// MARK: - Directory Detail View
struct DirectoryDetailView: View {
    let directory: ScanDirectory
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "folder.fill")
                        .font(.title)
                        .foregroundStyle(.blue)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(directory.displayName)
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text(directory.path)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                    
                    StatusBadge(status: directory.status)
                }
                
                // Stats
                HStack(spacing: 20) {
                    ScanStatItem(
                        icon: "doc.fill",
                        label: "Items Found",
                        value: "\(directory.itemsFound)",
                        color: .blue
                    )
                    
                    if directory.totalSize > 0 {
                        ScanStatItem(
                            icon: "internaldrive",
                            label: "Total Size",
                            value: ByteCountFormatter.string(fromByteCount: Int64(directory.totalSize), countStyle: .file),
                            color: .orange
                        )
                    }
                    
                    ScanStatItem(
                        icon: "folder",
                        label: "Subdirectories",
                        value: "\(directory.subdirectories.count)",
                        color: .purple
                    )
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            
            Divider()
            
            // Subdirectories
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(directory.subdirectories) { subdir in
                        SubdirectoryRowView(subdirectory: subdir)
                        Divider()
                    }
                }
            }
        }
    }
}

// MARK: - Subdirectory Row
struct SubdirectoryRowView: View {
    let subdirectory: ScanSubdirectory
    
    var body: some View {
        HStack(spacing: 12) {
            // Status indicator
            Circle()
                .fill(statusColor)
                .frame(width: 12, height: 12)
            
            Image(systemName: "folder")
                .foregroundStyle(.blue)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(subdirectory.name)
                    .font(.body)
                
                Text(subdirectory.path)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 4) {
                Text(subdirectory.status.displayText)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundStyle(statusColor)
                
                if subdirectory.itemsFound > 0 {
                    Text("\(subdirectory.itemsFound) items")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            
            // Progress indicator for in-progress
            if case .inProgress = subdirectory.status {
                ProgressView()
                    .scaleEffect(0.7)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor).opacity(0.3))
    }
    
    private var statusColor: Color {
        switch subdirectory.status {
        case .pending: return .gray
        case .inProgress: return .blue
        case .completed: return .green
        case .failed: return .red
        }
    }
}

// MARK: - Scan Stat Item
struct ScanStatItem: View {
    let icon: String
    let label: String
    let value: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .font(.title3)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(label)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(value)
                    .font(.headline)
            }
        }
    }
}

// MARK: - Empty Selection View
struct EmptySelectionView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "folder.badge.questionmark")
                .font(.system(size: 64))
                .foregroundStyle(.secondary)
            
            Text("Select a Folder")
                .font(.title2)
                .fontWeight(.semibold)
            
            Text("Click on a folder to see its scan progress and subdirectories")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .frame(maxWidth: 400)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    ScanDashboardView(scanner: FileScanner())
}

