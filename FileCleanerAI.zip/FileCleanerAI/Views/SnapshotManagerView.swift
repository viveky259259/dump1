import SwiftUI

struct SnapshotManagerView: View {
    @StateObject private var manager = SnapshotManager.shared
    @State private var showingDeleteConfirmation = false
    @State private var snapshotToDelete: APFSSnapshot?
    @State private var showingThinConfirmation = false
    @State private var showingDeleteOldConfirmation = false
    @State private var deleteBeforeDays = 30

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "camera.on.rectangle")
                            .foregroundStyle(.mint)
                        Text("APFS Snapshot Manager")
                            .font(.headline)
                    }
                    Text("Manage Time Machine local snapshots to reclaim disk space")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button(action: { Task { await manager.loadSnapshots() } }) {
                    Label("Refresh", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(manager.isLoading)
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            if manager.isLoading {
                VStack(spacing: 12) {
                    Spacer()
                    ProgressView()
                    Text("Loading snapshots...")
                        .font(.headline)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let error = manager.errorMessage {
                VStack(spacing: 12) {
                    Spacer()
                    Image(systemName: "exclamationmark.triangle")
                        .font(.largeTitle)
                        .foregroundStyle(.orange)
                    Text(error)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    Button("Try Again") { Task { await manager.loadSnapshots() } }
                        .buttonStyle(.borderedProminent)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding()
            } else if manager.snapshots.isEmpty {
                VStack(spacing: 12) {
                    Spacer()
                    Image(systemName: "checkmark.seal.fill")
                        .font(.largeTitle)
                        .foregroundStyle(.green)
                    Text("No local snapshots found")
                        .font(.headline)
                    Text("Time Machine local snapshots are either disabled or have been cleaned.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                // Bulk actions bar
                HStack(spacing: 12) {
                    Text("\(manager.totalSnapshotCount) snapshots")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    Spacer()

                    Picker("Delete older than", selection: $deleteBeforeDays) {
                        Text("7 days").tag(7)
                        Text("14 days").tag(14)
                        Text("30 days").tag(30)
                        Text("60 days").tag(60)
                        Text("90 days").tag(90)
                    }
                    .pickerStyle(.menu)
                    .frame(width: 140)

                    Button(action: { showingDeleteOldConfirmation = true }) {
                        Label("Delete Old", systemImage: "trash")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                    .disabled(manager.isDeleting)

                    Button(action: { showingThinConfirmation = true }) {
                        Label("Thin Snapshots", systemImage: "scissors")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.mint)
                    .controlSize(.small)
                    .disabled(manager.isDeleting)
                }
                .padding(.horizontal)
                .padding(.vertical, 8)

                Divider()

                // Snapshot list
                List {
                    ForEach(manager.snapshots) { snapshot in
                        HStack(spacing: 12) {
                            Image(systemName: "camera.fill")
                                .foregroundStyle(.mint)
                                .frame(width: 24)

                            VStack(alignment: .leading, spacing: 2) {
                                Text(snapshot.formattedDate)
                                    .font(.subheadline)
                                    .fontWeight(.medium)

                                Text(snapshot.name)
                                    .font(.caption2)
                                    .foregroundStyle(.tertiary)
                                    .lineLimit(1)
                            }

                            Spacer()

                            Text(snapshot.age)
                                .font(.caption)
                                .foregroundStyle(.secondary)

                            Button(action: {
                                snapshotToDelete = snapshot
                                showingDeleteConfirmation = true
                            }) {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.bordered)
                            .controlSize(.small)
                            .disabled(manager.isDeleting)
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listStyle(.inset(alternatesRowBackgrounds: true))
            }
        }
        .alert("Delete Snapshot", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) { snapshotToDelete = nil }
            Button("Delete", role: .destructive) {
                if let snapshot = snapshotToDelete {
                    Task { _ = await manager.deleteSnapshot(snapshot) }
                }
                snapshotToDelete = nil
            }
        } message: {
            if let snapshot = snapshotToDelete {
                Text("Delete snapshot from \(snapshot.formattedDate)?\n\nThis requires administrator privileges and cannot be undone.")
            }
        }
        .alert("Delete Old Snapshots", isPresented: $showingDeleteOldConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                let cutoff = Calendar.current.date(byAdding: .day, value: -deleteBeforeDays, to: Date()) ?? Date()
                Task { _ = await manager.deleteSnapshotsBefore(cutoff) }
            }
        } message: {
            let cutoff = Calendar.current.date(byAdding: .day, value: -deleteBeforeDays, to: Date()) ?? Date()
            let count = manager.snapshots.filter { $0.date < cutoff }.count
            Text("Delete \(count) snapshots older than \(deleteBeforeDays) days?\n\nThis requires administrator privileges.")
        }
        .alert("Thin Snapshots", isPresented: $showingThinConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Thin", role: .destructive) {
                Task { _ = await manager.thinSnapshots() }
            }
        } message: {
            Text("Ask macOS to aggressively thin local snapshots?\n\nThis uses `tmutil thinlocalsnapshots` and requires administrator privileges.")
        }
        .onAppear {
            if manager.snapshots.isEmpty && manager.errorMessage == nil {
                Task { await manager.loadSnapshots() }
            }
        }
    }
}

#Preview {
    SnapshotManagerView()
}
