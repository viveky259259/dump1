import SwiftUI

struct DebugView: View {
    @ObservedObject private var sizeCalcManager = SizeCalculationManager.shared
    @ObservedObject private var memoryMonitor = MemoryMonitor.shared
    @ObservedObject private var logManager = LogManager.shared

    @State private var isAutoRefresh = true
    @State private var refreshTimer: Timer?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Header
                HStack {
                    Label("Debug Monitor", systemImage: "ant.circle.fill")
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()

                    Toggle("Auto Refresh", isOn: $isAutoRefresh)
                        .toggleStyle(.switch)
                        .controlSize(.small)

                    Button(action: refreshAll) {
                        Label("Refresh", systemImage: "arrow.clockwise")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
                .padding(.bottom, 8)

                // Memory Section
                DebugSection(title: "Memory", icon: "memorychip") {
                    DebugGrid {
                        DebugStatRow(label: "App Memory", value: memoryMonitor.formattedAppMemory(), color: .blue)
                        DebugStatRow(label: "System Used", value: memoryMonitor.formattedUsedMemory(), color: .orange)
                        DebugStatRow(label: "System Free", value: memoryMonitor.formattedFreeMemory(), color: .green)
                        DebugStatRow(label: "Physical RAM", value: memoryMonitor.formattedPhysicalMemory(), color: .secondary)
                    }

                    HStack {
                        Text("Memory Pressure:")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(memoryMonitor.memoryPressure.description)
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundStyle(memoryMonitor.memoryPressure.color)

                        Spacer()

                        Text(String(format: "%.1f%% used", memoryMonitor.memoryUsagePercent()))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    ProgressView(value: memoryMonitor.memoryUsagePercent(), total: 100)
                        .tint(memoryMonitor.memoryPressure.color)
                }

                // Size Calculation Queue Section
                DebugSection(title: "Size Calculation Queue", icon: "list.bullet.rectangle") {
                    DebugGrid {
                        DebugStatRow(label: "High Priority", value: "\(sizeCalcManager.debugHighPriorityCount)", color: .red)
                        DebugStatRow(label: "Low Priority", value: "\(sizeCalcManager.debugLowPriorityCount)", color: .orange)
                        DebugStatRow(label: "Active", value: "\(sizeCalcManager.debugActiveCount)", color: .green)
                        DebugStatRow(label: "Cache Entries", value: "\(sizeCalcManager.debugCacheCount)", color: .blue)
                    }

                    HStack {
                        Text("Current Folder:")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(sizeCalcManager.debugCurrentFolder)
                            .font(.caption)
                            .fontWeight(.medium)
                            .lineLimit(1)
                            .truncationMode(.middle)
                    }

                    // Cancel button
                    if sizeCalcManager.debugActiveCount > 0 || sizeCalcManager.debugHighPriorityCount > 0 || sizeCalcManager.debugLowPriorityCount > 0 {
                        Button(action: {
                            sizeCalcManager.cancelAllCalculations()
                        }) {
                            Label("Cancel All Calculations", systemImage: "xmark.circle")
                                .foregroundStyle(.red)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    }
                }

                // Active Calculations Section
                if !sizeCalcManager.activeCalculationPaths.isEmpty {
                    DebugSection(title: "Active Calculations", icon: "gear.circle.fill") {
                        ForEach(sizeCalcManager.activeCalculationPaths, id: \.self) { path in
                            HStack {
                                ProgressView()
                                    .scaleEffect(0.6)
                                Text(shortenPath(path))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                            }
                        }
                    }
                }

                // Pending High Priority Section
                if !sizeCalcManager.pendingHighPriorityPaths.isEmpty {
                    DebugSection(title: "Pending (High Priority)", icon: "exclamationmark.circle.fill") {
                        ForEach(sizeCalcManager.pendingHighPriorityPaths, id: \.self) { path in
                            Text(shortenPath(path))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                                .truncationMode(.middle)
                        }
                        if sizeCalcManager.debugHighPriorityCount > 10 {
                            Text("... and \(sizeCalcManager.debugHighPriorityCount - 10) more")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }
                }

                // Pending Low Priority Section
                if !sizeCalcManager.pendingLowPriorityPaths.isEmpty {
                    DebugSection(title: "Pending (Low Priority)", icon: "circle.fill") {
                        ForEach(sizeCalcManager.pendingLowPriorityPaths, id: \.self) { path in
                            Text(shortenPath(path))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                                .truncationMode(.middle)
                        }
                        if sizeCalcManager.debugLowPriorityCount > 10 {
                            Text("... and \(sizeCalcManager.debugLowPriorityCount - 10) more")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }
                }

                // Recent Logs Section
                DebugSection(title: "Recent Logs (\(logManager.logs.count))", icon: "doc.text") {
                    ForEach(logManager.logs.suffix(20).reversed()) { log in
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: log.level.icon)
                                .font(.caption)
                                .foregroundStyle(log.level.color)
                                .frame(width: 16)

                            VStack(alignment: .leading, spacing: 2) {
                                HStack {
                                    Text(log.formattedTimestamp)
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                    Text(log.category.rawValue)
                                        .font(.caption2)
                                        .padding(.horizontal, 4)
                                        .background(Color.secondary.opacity(0.2))
                                        .cornerRadius(2)
                                }
                                Text(log.message)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(2)
                            }
                        }
                        .padding(.vertical, 2)
                    }
                }
            }
            .padding()
        }
        .frame(minWidth: 400, minHeight: 500)
        .onAppear {
            memoryMonitor.startMonitoring(interval: 1.0)
            startAutoRefresh()
        }
        .onDisappear {
            memoryMonitor.stopMonitoring()
            stopAutoRefresh()
        }
        .onChange(of: isAutoRefresh) { _, newValue in
            if newValue {
                startAutoRefresh()
            } else {
                stopAutoRefresh()
            }
        }
    }

    private func refreshAll() {
        memoryMonitor.updateMemoryInfo()
    }

    private func startAutoRefresh() {
        stopAutoRefresh()
        refreshTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            Task { @MainActor in
                // The observed objects will auto-update the view
            }
        }
    }

    private func stopAutoRefresh() {
        refreshTimer?.invalidate()
        refreshTimer = nil
    }

    private func shortenPath(_ path: String) -> String {
        let home = FileManager.default.homeDirectoryForCurrentUser.path
        return path.replacingOccurrences(of: home, with: "~")
    }
}

// MARK: - Debug Section View

struct DebugSection<Content: View>: View {
    let title: String
    let icon: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(.secondary)
                Text(title)
                    .font(.headline)
            }

            VStack(alignment: .leading, spacing: 6) {
                content
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            .cornerRadius(8)
        }
    }
}

// MARK: - Debug Grid

struct DebugGrid<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        LazyVGrid(columns: [
            GridItem(.flexible()),
            GridItem(.flexible())
        ], spacing: 8) {
            content
        }
    }
}

// MARK: - Debug Stat Row

struct DebugStatRow: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        HStack {
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer()
            Text(value)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundStyle(color)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(color.opacity(0.1))
        .cornerRadius(4)
    }
}

#Preview {
    DebugView()
}
