import SwiftUI

struct WhitelistView: View {
    @StateObject private var whitelistManager = WhitelistManager.shared
    @State private var showingAddRule = false
    @State private var editingRule: WhitelistRule?
    @State private var showingImportExport = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Label("Protection Rules", systemImage: "shield.checkered")
                        .font(.headline)

                    Text("Files and folders matching these rules will never be deleted")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Menu {
                    Button(action: { whitelistManager.addDeveloperPresets() }) {
                        Label("Add Developer Presets", systemImage: "hammer")
                    }

                    Button(action: { whitelistManager.addMediaPresets() }) {
                        Label("Add Media Presets", systemImage: "photo.on.rectangle")
                    }

                    Divider()

                    Button(action: { showingImportExport = true }) {
                        Label("Import/Export...", systemImage: "square.and.arrow.up.on.square")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .menuStyle(.borderlessButton)

                Button(action: { showingAddRule = true }) {
                    Label("Add Rule", systemImage: "plus")
                }
                .buttonStyle(.borderedProminent)
            }

            Divider()

            // Rules List
            if whitelistManager.whitelistRules.isEmpty {
                WhitelistEmptyState(onAddRule: { showingAddRule = true })
            } else {
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(whitelistManager.whitelistRules) { rule in
                            WhitelistRuleRow(
                                rule: rule,
                                onToggle: { whitelistManager.toggleRule(rule) },
                                onEdit: { editingRule = rule },
                                onDelete: { whitelistManager.removeRule(rule) }
                            )
                        }
                    }
                }
            }

            // System Protected Paths Info
            DisclosureGroup {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(WhitelistManager.systemProtectedPaths).sorted(), id: \.self) { path in
                        HStack {
                            Image(systemName: "lock.fill")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text(path)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.vertical, 4)
            } label: {
                HStack {
                    Image(systemName: "lock.shield")
                        .foregroundStyle(.orange)
                    Text("System Protected Paths")
                        .font(.subheadline)
                    Text("(Always protected)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
            .cornerRadius(8)
        }
        .padding()
        .sheet(isPresented: $showingAddRule) {
            WhitelistRuleEditor(
                rule: nil,
                onSave: { newRule in
                    whitelistManager.addRule(
                        type: newRule.type,
                        pattern: newRule.pattern,
                        reason: newRule.reason
                    )
                }
            )
        }
        .sheet(item: $editingRule) { rule in
            WhitelistRuleEditor(
                rule: rule,
                onSave: { updatedRule in
                    whitelistManager.updateRule(updatedRule)
                }
            )
        }
    }
}

// MARK: - Empty State

struct WhitelistEmptyState: View {
    let onAddRule: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Spacer()

            Image(systemName: "shield.slash")
                .font(.system(size: 48))
                .foregroundStyle(.secondary)

            Text("No Custom Protection Rules")
                .font(.headline)

            Text("Add rules to protect specific files, folders, or patterns from being deleted during cleanup.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: 300)

            Button(action: onAddRule) {
                Label("Add First Rule", systemImage: "plus")
            }
            .buttonStyle(.borderedProminent)

            Spacer()
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Rule Row

struct WhitelistRuleRow: View {
    let rule: WhitelistRule
    let onToggle: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack {
            Toggle("", isOn: Binding(
                get: { rule.isEnabled },
                set: { _ in onToggle() }
            ))
            .toggleStyle(.switch)
            .controlSize(.small)

            Image(systemName: rule.type.icon)
                .foregroundStyle(rule.isEnabled ? .blue : .secondary)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 2) {
                Text(rule.pattern)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundStyle(rule.isEnabled ? .primary : .secondary)

                HStack(spacing: 8) {
                    Text(rule.type.rawValue)
                        .font(.caption2)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(4)

                    if !rule.reason.isEmpty {
                        Text(rule.reason)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            Spacer()

            Button(action: onEdit) {
                Image(systemName: "pencil")
            }
            .buttonStyle(.borderless)

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .foregroundStyle(.red)
            }
            .buttonStyle(.borderless)
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(8)
        .opacity(rule.isEnabled ? 1.0 : 0.7)
    }
}

// MARK: - Rule Editor

struct WhitelistRuleEditor: View {
    let rule: WhitelistRule?
    let onSave: (WhitelistRule) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var ruleType: WhitelistRule.RuleType
    @State private var pattern: String
    @State private var reason: String
    @State private var showingFilePicker = false
    @State private var showingFolderPicker = false

    init(rule: WhitelistRule?, onSave: @escaping (WhitelistRule) -> Void) {
        self.rule = rule
        self.onSave = onSave
        _ruleType = State(initialValue: rule?.type ?? .exactPath)
        _pattern = State(initialValue: rule?.pattern ?? "")
        _reason = State(initialValue: rule?.reason ?? "")
    }

    var body: some View {
        VStack(spacing: 20) {
            // Header
            HStack {
                Text(rule == nil ? "Add Protection Rule" : "Edit Protection Rule")
                    .font(.headline)
                Spacer()
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }

            // Rule Type
            VStack(alignment: .leading, spacing: 8) {
                Text("Rule Type")
                    .font(.subheadline)
                    .fontWeight(.medium)

                Picker("Type", selection: $ruleType) {
                    ForEach(WhitelistRule.RuleType.allCases, id: \.self) { type in
                        HStack {
                            Image(systemName: type.icon)
                            Text(type.rawValue)
                        }
                        .tag(type)
                    }
                }
                .pickerStyle(.segmented)

                Text(ruleType.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            // Pattern Input
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Pattern")
                        .font(.subheadline)
                        .fontWeight(.medium)

                    Spacer()

                    if ruleType == .exactPath {
                        Button("Browse File...") {
                            showingFilePicker = true
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    } else if ruleType == .directory {
                        Button("Browse Folder...") {
                            showingFolderPicker = true
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                    }
                }

                TextField(placeholderText, text: $pattern)
                    .textFieldStyle(.roundedBorder)

                // Pattern examples
                patternExamples
            }

            // Reason
            VStack(alignment: .leading, spacing: 8) {
                Text("Reason (Optional)")
                    .font(.subheadline)
                    .fontWeight(.medium)

                TextField("Why is this protected?", text: $reason)
                    .textFieldStyle(.roundedBorder)
            }

            Spacer()

            // Actions
            HStack {
                Button("Cancel") {
                    dismiss()
                }
                .buttonStyle(.bordered)

                Spacer()

                Button("Save") {
                    let newRule = WhitelistRule(
                        type: ruleType,
                        pattern: pattern,
                        reason: reason,
                        isEnabled: rule?.isEnabled ?? true
                    )
                    onSave(newRule)
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .disabled(pattern.isEmpty)
            }
        }
        .padding()
        .frame(width: 450, height: 400)
        .fileImporter(
            isPresented: $showingFilePicker,
            allowedContentTypes: [.item],
            onCompletion: { result in
                if case .success(let url) = result {
                    pattern = url.path
                }
            }
        )
        .fileImporter(
            isPresented: $showingFolderPicker,
            allowedContentTypes: [.folder],
            onCompletion: { result in
                if case .success(let url) = result {
                    pattern = url.path
                }
            }
        )
    }

    private var placeholderText: String {
        switch ruleType {
        case .exactPath: return "~/Documents/important.txt"
        case .directory: return "~/Projects/my-project"
        case .pattern: return "*.env or **/.secrets/*"
        case .regex: return ".*\\.pem$"
        }
    }

    private var examplesForRuleType: [(String, String)] {
        switch ruleType {
        case .exactPath:
            return [
                ("~/.gitconfig", "Git config file"),
                ("~/Documents/work.xlsx", "Specific file")
            ]
        case .directory:
            return [
                ("~/Projects/important", "Entire folder"),
                ("~/.config", "Config directory")
            ]
        case .pattern:
            return [
                ("*.env", "All .env files"),
                ("**/.git", "All .git folders"),
                ("*.key", "All key files")
            ]
        case .regex:
            return [
                (".*credentials.*", "Contains 'credentials'"),
                (".*\\.pem$", "Ends with .pem")
            ]
        }
    }

    @ViewBuilder
    private var patternExamples: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Examples:")
                .font(.caption)
                .foregroundStyle(.secondary)

            ForEach(examplesForRuleType, id: \.0) { example, desc in
                HStack {
                    Text(example)
                        .font(.caption)
                        .fontDesign(.monospaced)
                    Text("-")
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                    Text(desc)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(8)
        .background(Color(NSColor.textBackgroundColor))
        .cornerRadius(6)
    }
}

#Preview {
    WhitelistView()
        .frame(width: 500, height: 600)
}
