import SwiftUI

struct DeletionProgressView: View {
    @Binding var totalItems: Int
    @Binding var currentItem: Int
    @Binding var currentItemName: String
    @Binding var isCompleted: Bool
    @Binding var successCount: Int
    @Binding var failedCount: Int
    
    var progress: Double {
        guard totalItems > 0 else { return 0 }
        return Double(currentItem) / Double(totalItems)
    }
    
    var body: some View {
        VStack(spacing: 20) {
            // Header
            HStack {
                Image(systemName: isCompleted ? "checkmark.circle.fill" : "trash.fill")
                    .font(.largeTitle)
                    .foregroundStyle(isCompleted ? .green : .red)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(isCompleted ? "Deletion Complete" : "Deleting Items...")
                        .font(.headline)
                    
                    if !isCompleted {
                        Text("\(currentItem) of \(totalItems)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                
                Spacer()
            }
            
            // Progress bar
            if !isCompleted {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: progress) {
                        Text(currentItemName)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .progressViewStyle(.linear)
                }
            }
            
            // Results
            if isCompleted {
                VStack(spacing: 12) {
                    HStack(spacing: 20) {
                        // Success
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.green)
                            Text("\(successCount) deleted")
                                .font(.callout)
                                .fontWeight(.medium)
                        }
                        
                        // Failed
                        if failedCount > 0 {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundStyle(.orange)
                                Text("\(failedCount) failed")
                                    .font(.callout)
                                    .fontWeight(.medium)
                            }
                        }
                    }
                    
                    // Permission error hint
                    if failedCount > 0 {
                        Text("💡 Failed items may require administrator privileges. Check the logs for details.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                }
                .padding(.vertical, 8)
            }
            
            // Spinner while processing
            if !isCompleted && currentItem == 0 {
                HStack {
                    ProgressView()
                        .scaleEffect(0.8)
                    Text("Preparing...")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(24)
        .frame(width: 400)
        .background(Color(NSColor.windowBackgroundColor))
    }
}

#Preview {
    DeletionProgressView(
        totalItems: .constant(10),
        currentItem: .constant(5),
        currentItemName: .constant("/Users/test/Documents/file.txt"),
        isCompleted: .constant(false),
        successCount: .constant(5),
        failedCount: .constant(0)
    )
}
