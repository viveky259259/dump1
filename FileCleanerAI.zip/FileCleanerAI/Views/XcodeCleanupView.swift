import SwiftUI

struct XcodeCleanupView: View {
    @StateObject private var manager = XcodeCleanupManager.shared
    @State private var showingCleanConfirmation = false
    @State private var categoryToClean: XcodeCleanupCategory?
    @State private var showingCategoryConfirm = false
    @State private var showingResult = false
    @State private var cleaningResult: CleaningResult?

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "hammer.fill")
                            .foregroundStyle(.blue)
                        Text("Xcode & Simulator Cleanup")
                            .font(.headline)
                    }
                    Text("Clean DerivedData, old simulators, archives, and device support files")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Button(action: {
                    Task { await manager.scan() }
                }) {
                    Label("Scan", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(manager.isScanning || manager.isCleaning)

                Button(action: {
                    showingCleanConfirmation = true
                }) {
                    Label("Clean Selected", systemImage: "trash")
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .disabled(manager.isScanning || manager.isCleaning || selectedCount == 0)
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            if manager.isScanning {
                VStack(spacing: 16) {
                    Spacer()
                    ProgressView(value: manager.scanProgress)
                        .progressViewStyle(LinearProgressViewStyle())
                        .frame(width: 300)
                    Text("Scanning Xcode data...")
                        .font(.headline)
                    Text("\(Int(manager.scanProgress * 100))%")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach($manager.categories) { $category in
                            XcodeCleanupCategoryRow(
                                category: $category,
                                onClean: {
                                    categoryToClean = category
                                    showingCategoryConfirm = true
                                }
                            )
                            .padding(.horizontal)
                            .padding(.vertical, 4)

                            if category.id != manager.categories.last?.id {
                                Divider()
                                    .padding(.leading, 54)
                            }
                        }
                    }
                    .padding(.vertical, 8)
                }

                // Footer
                if manager.totalReclaimable > 0 {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Total reclaimable: \(ByteCountFormatter.string(fromByteCount: manager.totalReclaimable, countStyle: .file))")
                                .font(.callout)

                            let selectedSize = manager.categories
                                .filter { $0.isSelected && $0.hasData }
                                .reduce(0) { $0 + $1.size }
                            if selectedSize > 0 {
                                Text("Selected: \(ByteCountFormatter.string(fromByteCount: selectedSize, countStyle: .file))")
                                    .font(.caption)
                                    .foregroundStyle(.blue)
                            }
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color(NSColor.controlBackgroundColor))
                }
            }
        }
        .alert("Clean Selected", isPresented: $showingCleanConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Clean", role: .destructive) {
                Task {
                    cleaningResult = await manager.cleanSelected()
                    showingResult = true
                }
            }
        } message: {
            let selected = manager.categories.filter { $0.isSelected && $0.hasData }
            let totalSize = selected.reduce(0) { $0 + $1.size }
            Text("Clean \(selected.count) categories?\n\nThis will free approximately \(ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file)).")
        }
        .alert("Clean Category", isPresented: $showingCategoryConfirm) {
            Button("Cancel", role: .cancel) { categoryToClean = nil }
            Button("Clean", role: .destructive) {
                if let category = categoryToClean {
                    Task {
                        cleaningResult = await manager.cleanCategory(category)
                        showingResult = true
                    }
                }
                categoryToClean = nil
            }
        } message: {
            if let category = categoryToClean {
                Text("Clean \(category.name)?\n\n\(category.itemCount) items, \(category.formattedSize)")
            }
        }
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") { cleaningResult = nil }
        } message: {
            if let result = cleaningResult {
                Text("Removed \(result.success) items.\nFreed \(result.formattedBytesFreed) of space.")
            }
        }
        .onAppear {
            if manager.totalReclaimable == 0 {
                Task { await manager.scan() }
            }
        }
    }

    private var selectedCount: Int {
        manager.categories.filter { $0.isSelected && $0.hasData }.count
    }
}

// MARK: - Category Row

struct XcodeCleanupCategoryRow: View {
    @Binding var category: XcodeCleanupCategory
    let onClean: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Toggle("", isOn: $category.isSelected)
                .toggleStyle(.checkbox)
                .disabled(!category.hasData)

            Image(systemName: category.icon)
                .font(.title2)
                .foregroundStyle(category.hasData ? .blue : .secondary)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 4) {
                Text(category.name)
                    .font(.subheadline)
                    .fontWeight(.medium)

                Text(category.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if category.hasData {
                VStack(alignment: .trailing, spacing: 2) {
                    Text(category.formattedSize)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.blue)

                    Text("\(category.itemCount) items")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Button(action: onClean) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.bordered)
            } else {
                Text("Empty")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.vertical, 8)
    }
}

#Preview {
    XcodeCleanupView()
}
