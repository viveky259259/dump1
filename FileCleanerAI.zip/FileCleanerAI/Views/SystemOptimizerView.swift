import SwiftUI

struct SystemOptimizerView: View {
    @StateObject private var optimizer = SystemOptimizer.shared
    @State private var showingConfirmation = false

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "bolt.fill")
                            .foregroundStyle(.purple)
                        Text("System Optimizer")
                            .font(.headline)
                    }

                    Text("Rebuild caches, flush DNS, purge memory, and optimize macOS performance")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                if optimizer.isRunning {
                    ProgressView(value: optimizer.progress)
                        .progressViewStyle(LinearProgressViewStyle())
                        .frame(width: 120)
                }

                Button(action: {
                    optimizer.resetTasks()
                }) {
                    Label("Reset", systemImage: "arrow.counterclockwise")
                }
                .buttonStyle(.bordered)
                .disabled(optimizer.isRunning)

                Button(action: {
                    let hasAdmin = optimizer.tasks.contains { $0.isSelected && $0.requiresAdmin }
                    let hasWarning = optimizer.tasks.contains { $0.isSelected && $0.warningMessage != nil }
                    if hasAdmin || hasWarning {
                        showingConfirmation = true
                    } else {
                        Task { await optimizer.runSelectedOptimizations() }
                    }
                }) {
                    Label("Optimize", systemImage: "bolt.fill")
                }
                .buttonStyle(.borderedProminent)
                .tint(.purple)
                .disabled(optimizer.isRunning || optimizer.tasks.filter({ $0.isSelected }).isEmpty)
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            // Task list
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach($optimizer.tasks) { $task in
                        OptimizationTaskRow(task: $task, isRunning: optimizer.isRunning)
                            .padding(.horizontal)
                            .padding(.vertical, 6)

                        if task.id != optimizer.tasks.last?.id {
                            Divider()
                                .padding(.leading, 54)
                        }
                    }
                }
                .padding(.vertical, 8)
            }

            // Footer
            HStack {
                let selected = optimizer.tasks.filter { $0.isSelected }.count
                let total = optimizer.tasks.count
                Text("\(selected) of \(total) optimizations selected")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Spacer()

                if let lastRun = optimizer.lastRunDate {
                    Text("Last run: \(lastRun.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))
        }
        .alert("Run Optimizations", isPresented: $showingConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Run", role: .destructive) {
                Task { await optimizer.runSelectedOptimizations() }
            }
        } message: {
            let adminTasks = optimizer.tasks.filter { $0.isSelected && $0.requiresAdmin }.map { $0.name }
            let warnings = optimizer.tasks.filter { $0.isSelected && $0.warningMessage != nil }.compactMap { $0.warningMessage }

            if !adminTasks.isEmpty && !warnings.isEmpty {
                Text("Admin privileges required for:\n\(adminTasks.joined(separator: ", "))\n\nWarnings:\n\(warnings.joined(separator: "\n"))")
            } else if !adminTasks.isEmpty {
                Text("Admin privileges required for:\n\(adminTasks.joined(separator: ", "))")
            } else {
                Text("Warnings:\n\(warnings.joined(separator: "\n"))")
            }
        }
    }
}

// MARK: - Task Row

struct OptimizationTaskRow: View {
    @Binding var task: OptimizationTask
    let isRunning: Bool

    var body: some View {
        HStack(spacing: 12) {
            // Checkbox
            Toggle("", isOn: $task.isSelected)
                .toggleStyle(.checkbox)
                .disabled(isRunning)

            // Status icon
            statusView

            // Info
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(task.name)
                        .font(.subheadline)
                        .fontWeight(.medium)

                    if task.requiresAdmin {
                        Image(systemName: "lock.shield.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .help("Requires administrator privileges")
                    }

                    if task.warningMessage != nil {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.caption)
                            .foregroundStyle(.yellow)
                            .help(task.warningMessage ?? "")
                    }
                }

                Text(task.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                // Status message
                switch task.status {
                case .success(let msg):
                    Text(msg)
                        .font(.caption2)
                        .foregroundStyle(.green)
                case .failed(let msg):
                    Text(msg)
                        .font(.caption2)
                        .foregroundStyle(.red)
                        .lineLimit(2)
                default:
                    EmptyView()
                }
            }

            Spacer()
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder
    private var statusView: some View {
        switch task.status {
        case .pending:
            Image(systemName: task.icon)
                .font(.title2)
                .foregroundStyle(task.isSelected ? .purple : .secondary)
                .frame(width: 30)
        case .running:
            ProgressView()
                .scaleEffect(0.8)
                .frame(width: 30)
        case .success:
            Image(systemName: "checkmark.circle.fill")
                .font(.title2)
                .foregroundStyle(.green)
                .frame(width: 30)
        case .failed:
            Image(systemName: "xmark.circle.fill")
                .font(.title2)
                .foregroundStyle(.red)
                .frame(width: 30)
        case .skipped:
            Image(systemName: "minus.circle")
                .font(.title2)
                .foregroundStyle(.secondary)
                .frame(width: 30)
        }
    }
}

#Preview {
    SystemOptimizerView()
}
