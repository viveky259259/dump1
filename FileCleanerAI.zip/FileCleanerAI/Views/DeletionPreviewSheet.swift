import SwiftUI

// MARK: - Data Model

struct DeletionPreviewItem: Identifiable {
    let id: String
    let path: String
    let name: String
    let size: Int64
    let category: String
    let icon: String
    var isSelected: Bool = true

    var formattedSize: String {
        ByteCountFormatter.string(fromByteCount: max(size, 0), countStyle: .file)
    }
}

// MARK: - Preview Sheet

struct DeletionPreviewSheet: View {
    @Binding var items: [DeletionPreviewItem]
    let title: String
    let onConfirm: ([DeletionPreviewItem]) -> Void
    let onCancel: () -> Void

    private var selectedItems: [DeletionPreviewItem] {
        items.filter { $0.isSelected }
    }

    private var totalSelectedSize: Int64 {
        selectedItems.reduce(0) { $0 + max($1.size, 0) }
    }

    private var groupedItems: [(String, [Int])] {
        var groups: [String: [Int]] = [:]
        for (index, item) in items.enumerated() {
            groups[item.category, default: []].append(index)
        }
        return groups.sorted { lhs, rhs in
            let lhsSize = lhs.value.reduce(0) { $0 + max(items[$1].size, 0) }
            let rhsSize = rhs.value.reduce(0) { $0 + max(items[$1].size, 0) }
            return lhsSize > rhsSize
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Image(systemName: "eye.fill")
                    .foregroundStyle(.blue)
                Text(title)
                    .font(.headline)

                Spacer()

                Text("\(selectedItems.count) of \(items.count) items")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding()

            Divider()

            // Controls
            HStack {
                Button(action: selectAll) {
                    Text(allSelected ? "Deselect All" : "Select All")
                }
                .buttonStyle(.bordered)
                .controlSize(.small)

                Spacer()

                VStack(alignment: .trailing) {
                    Text("Total: \(ByteCountFormatter.string(fromByteCount: totalSelectedSize, countStyle: .file))")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)

            Divider()

            // Item list grouped by category
            List {
                ForEach(groupedItems, id: \.0) { category, indices in
                    Section(header:
                        HStack {
                            Text(category)
                                .font(.caption)
                                .fontWeight(.semibold)
                            Spacer()
                            Text(formatGroupSize(indices))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    ) {
                        ForEach(indices, id: \.self) { index in
                            PreviewItemRow(item: $items[index])
                        }
                    }
                }
            }
            .listStyle(.inset(alternatesRowBackgrounds: true))

            Divider()

            // Footer with actions
            HStack {
                Button("Cancel") {
                    onCancel()
                }
                .buttonStyle(.bordered)
                .keyboardShortcut(.cancelAction)

                Spacer()

                Text("\(selectedItems.count) items (\(ByteCountFormatter.string(fromByteCount: totalSelectedSize, countStyle: .file)))")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Button(action: {
                    onConfirm(selectedItems)
                }) {
                    Label("Delete Selected", systemImage: "trash")
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .disabled(selectedItems.isEmpty)
                .keyboardShortcut(.defaultAction)
            }
            .padding()
        }
        .frame(width: 600, height: 500)
    }

    private var allSelected: Bool {
        items.allSatisfy { $0.isSelected }
    }

    private func selectAll() {
        let newValue = !allSelected
        for i in items.indices {
            items[i].isSelected = newValue
        }
    }

    private func formatGroupSize(_ indices: [Int]) -> String {
        let total = indices.reduce(0) { $0 + max(items[$1].size, 0) }
        return ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
    }
}

// MARK: - Item Row

struct PreviewItemRow: View {
    @Binding var item: DeletionPreviewItem

    var body: some View {
        HStack(spacing: 10) {
            Toggle("", isOn: $item.isSelected)
                .toggleStyle(.checkbox)

            Image(systemName: item.icon)
                .foregroundStyle(.secondary)
                .frame(width: 18)

            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.subheadline)
                    .lineLimit(1)

                Text(item.path)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            Spacer()

            Text(item.formattedSize)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}
