import SwiftUI

struct DuplicateFinderView: View {
    @StateObject private var scanner = DuplicateScanner.shared
    @State private var selectedPaths: Set<String> = []
    @State private var showingDeleteConfirmation = false
    @State private var filesToDelete: [FileInfo] = []
    @State private var minSizeOption: MinSizeOption = .oneKB
    @State private var expandedGroups: Set<UUID> = []

    enum MinSizeOption: String, CaseIterable {
        case oneKB = "1 KB"
        case oneHundredKB = "100 KB"
        case oneMB = "1 MB"
        case tenMB = "10 MB"
        case oneHundredMB = "100 MB"

        var bytes: Int64 {
            switch self {
            case .oneKB: return 1024
            case .oneHundredKB: return 100 * 1024
            case .oneMB: return 1024 * 1024
            case .tenMB: return 10 * 1024 * 1024
            case .oneHundredMB: return 100 * 1024 * 1024
            }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            DuplicateHeaderView(
                scanner: scanner,
                minSizeOption: $minSizeOption,
                onScan: startScan,
                onCancel: scanner.cancelScan
            )

            Divider()

            // Content
            if scanner.isScanning {
                DuplicateScanProgressView(scanner: scanner)
            } else if scanner.duplicateGroups.isEmpty {
                DuplicateEmptyStateView()
            } else {
                DuplicateResultsView(
                    groups: scanner.duplicateGroups,
                    expandedGroups: $expandedGroups,
                    onDeleteGroup: { group in
                        filesToDelete = Array(group.files.dropFirst())
                        showingDeleteConfirmation = true
                    },
                    onDeleteFile: { file in
                        filesToDelete = [file]
                        showingDeleteConfirmation = true
                    }
                )
            }

            // Footer
            if !scanner.duplicateGroups.isEmpty && !scanner.isScanning {
                DuplicateFooterView(
                    totalGroups: scanner.duplicateGroups.count,
                    totalDuplicates: scanner.duplicatesFound,
                    potentialSavings: scanner.potentialSpaceSaved,
                    onDeleteAll: {
                        filesToDelete = scanner.duplicateGroups.flatMap { Array($0.files.dropFirst()) }
                        showingDeleteConfirmation = true
                    }
                )
            }
        }
        .alert("Confirm Deletion", isPresented: $showingDeleteConfirmation) {
            Button("Cancel", role: .cancel) {
                filesToDelete = []
            }
            Button("Move to Trash", role: .destructive) {
                Task {
                    await scanner.deleteFiles(filesToDelete, keepFirst: false)
                    filesToDelete = []
                }
            }
        } message: {
            let totalSize = filesToDelete.reduce(0) { $0 + $1.size }
            Text("Are you sure you want to move \(filesToDelete.count) file(s) to trash? This will free \(ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file)).")
        }
    }

    private func startScan() {
        let paths = [
            "~/Documents",
            "~/Downloads",
            "~/Desktop",
            "~/Pictures",
            "~/Movies",
            "~/Music"
        ]

        Task {
            await scanner.startScan(paths: paths, minSize: minSizeOption.bytes)
        }
    }
}

// MARK: - Header View

struct DuplicateHeaderView: View {
    @ObservedObject var scanner: DuplicateScanner
    @Binding var minSizeOption: DuplicateFinderView.MinSizeOption
    let onScan: () -> Void
    let onCancel: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Image(systemName: "doc.on.doc.fill")
                        .foregroundStyle(.orange)
                    Text("Duplicate Finder")
                        .font(.headline)
                }

                Text("Find and remove duplicate files to free up space")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if !scanner.isScanning {
                HStack(spacing: 12) {
                    Picker("Min Size", selection: $minSizeOption) {
                        ForEach(DuplicateFinderView.MinSizeOption.allCases, id: \.self) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(width: 120)

                    Button(action: onScan) {
                        Label("Scan for Duplicates", systemImage: "magnifyingglass")
                    }
                    .buttonStyle(.borderedProminent)
                }
            } else {
                Button(action: onCancel) {
                    Label("Cancel", systemImage: "xmark.circle")
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Scan Progress View

struct DuplicateScanProgressView: View {
    @ObservedObject var scanner: DuplicateScanner

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            ProgressView(value: scanner.scanProgress)
                .progressViewStyle(LinearProgressViewStyle())
                .frame(width: 300)

            VStack(spacing: 8) {
                Text(scanner.currentPhase.rawValue)
                    .font(.headline)

                if scanner.filesProcessed > 0 {
                    Text("\(scanner.filesProcessed) groups processed")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Text("\(Int(scanner.scanProgress * 100))%")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Empty State View

struct DuplicateEmptyStateView: View {
    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            Image(systemName: "doc.on.doc")
                .font(.system(size: 64))
                .foregroundStyle(.secondary)

            Text("No Duplicates Found")
                .font(.title2)
                .fontWeight(.semibold)

            Text("Click 'Scan for Duplicates' to search your files for exact duplicates.\nFiles are compared by content, not just name.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .frame(maxWidth: 400)

            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Results View

struct DuplicateResultsView: View {
    let groups: [DuplicateGroup]
    @Binding var expandedGroups: Set<UUID>
    let onDeleteGroup: (DuplicateGroup) -> Void
    let onDeleteFile: (FileInfo) -> Void

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(groups) { group in
                    DuplicateGroupCard(
                        group: group,
                        isExpanded: expandedGroups.contains(group.id),
                        onToggle: {
                            if expandedGroups.contains(group.id) {
                                expandedGroups.remove(group.id)
                            } else {
                                expandedGroups.insert(group.id)
                            }
                        },
                        onDeleteGroup: { onDeleteGroup(group) },
                        onDeleteFile: onDeleteFile
                    )
                }
            }
            .padding()
        }
    }
}

// MARK: - Duplicate Group Card

struct DuplicateGroupCard: View {
    let group: DuplicateGroup
    let isExpanded: Bool
    let onToggle: () -> Void
    let onDeleteGroup: () -> Void
    let onDeleteFile: (FileInfo) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header
            Button(action: onToggle) {
                HStack {
                    Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                        .foregroundStyle(.secondary)
                        .frame(width: 20)

                    // File icon based on extension
                    FileIconView(filename: group.files.first?.name ?? "file")

                    VStack(alignment: .leading, spacing: 2) {
                        Text(group.files.first?.name ?? "Unknown")
                            .font(.headline)
                            .lineLimit(1)

                        HStack(spacing: 12) {
                            Text("\(group.count) copies")
                                .font(.caption)
                                .foregroundStyle(.secondary)

                            Text(group.formattedSize + " each")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Save \(group.formattedSavings)")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.orange)

                        Text("by removing \(group.count - 1) copies")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Button(action: onDeleteGroup) {
                        Image(systemName: "trash")
                            .foregroundStyle(.red)
                    }
                    .buttonStyle(.bordered)
                    .help("Keep first copy, delete rest")
                }
                .padding()
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            // Expanded file list
            if isExpanded {
                Divider()
                    .padding(.horizontal)

                VStack(spacing: 0) {
                    ForEach(Array(group.files.enumerated()), id: \.element.id) { index, file in
                        HStack {
                            if index == 0 {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                                    .frame(width: 24)
                                    .help("Original (keep this)")
                            } else {
                                Image(systemName: "circle")
                                    .foregroundStyle(.secondary)
                                    .frame(width: 24)
                            }

                            VStack(alignment: .leading, spacing: 2) {
                                Text(file.displayPath)
                                    .font(.caption)
                                    .lineLimit(1)
                                    .truncationMode(.middle)

                                Text(formatDate(file.modificationDate))
                                    .font(.caption2)
                                    .foregroundStyle(.tertiary)
                            }

                            Spacer()

                            if index > 0 {
                                Button(action: { onDeleteFile(file) }) {
                                    Image(systemName: "trash")
                                        .font(.caption)
                                }
                                .buttonStyle(.borderless)
                                .foregroundStyle(.red)
                            }

                            Button(action: { revealInFinder(file.url) }) {
                                Image(systemName: "folder")
                                    .font(.caption)
                            }
                            .buttonStyle(.borderless)
                            .help("Reveal in Finder")
                        }
                        .padding(.horizontal)
                        .padding(.vertical, 8)

                        if index < group.files.count - 1 {
                            Divider()
                                .padding(.leading, 40)
                        }
                    }
                }
            }
        }
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(10)
    }

    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private func revealInFinder(_ url: URL) {
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }
}

// MARK: - File Icon View

struct FileIconView: View {
    let filename: String

    var body: some View {
        let ext = (filename as NSString).pathExtension.lowercased()
        let icon: String

        switch ext {
        case "jpg", "jpeg", "png", "gif", "heic", "webp":
            icon = "photo"
        case "mp4", "mov", "avi", "mkv":
            icon = "film"
        case "mp3", "wav", "aac", "m4a":
            icon = "music.note"
        case "pdf":
            icon = "doc.richtext"
        case "doc", "docx":
            icon = "doc.text"
        case "xls", "xlsx":
            icon = "tablecells"
        case "zip", "tar", "gz", "rar":
            icon = "archivebox"
        case "dmg", "pkg":
            icon = "shippingbox"
        default:
            icon = "doc"
        }

        return Image(systemName: icon)
            .font(.title2)
            .foregroundStyle(.secondary)
            .frame(width: 32)
    }
}

// MARK: - Footer View

struct DuplicateFooterView: View {
    let totalGroups: Int
    let totalDuplicates: Int
    let potentialSavings: Int64
    let onDeleteAll: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("\(totalGroups) duplicate groups • \(totalDuplicates) total files")
                    .font(.callout)
                    .foregroundStyle(.secondary)

                Text("Potential savings: \(ByteCountFormatter.string(fromByteCount: potentialSavings, countStyle: .file))")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }

            Spacer()

            Button(action: onDeleteAll) {
                Label("Delete All Duplicates", systemImage: "trash")
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
            .help("Keep first copy of each group, delete the rest")
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

#Preview {
    DuplicateFinderView()
}
