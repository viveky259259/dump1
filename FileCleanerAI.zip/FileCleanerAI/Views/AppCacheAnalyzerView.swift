import SwiftUI

struct AppCacheAnalyzerView: View {
    @StateObject private var analyzer = AppCacheAnalyzer.shared
    @State private var searchText = ""
    @State private var filterRecommendation: CacheRecommendation?
    @State private var selectedEntries: Set<String> = []
    @State private var showingCleanConfirmation = false
    @State private var showingResult = false
    @State private var cleaningResult: CleaningResult?

    private var filteredEntries: [AppCacheEntry] {
        var result = analyzer.entries
        if !searchText.isEmpty {
            result = result.filter {
                $0.appName.localizedCaseInsensitiveContains(searchText) ||
                $0.bundleId.localizedCaseInsensitiveContains(searchText)
            }
        }
        if let filter = filterRecommendation {
            result = result.filter { $0.recommendation == filter }
        }
        return result
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Image(systemName: "chart.bar.doc.horizontal")
                            .foregroundStyle(.cyan)
                        Text("App Cache Analyzer")
                            .font(.headline)
                    }
                    Text("Per-app cache usage with intelligent cleanup recommendations")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                if analyzer.totalCacheSize > 0 {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Total: \(ByteCountFormatter.string(fromByteCount: analyzer.totalCacheSize, countStyle: .file))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text("Reclaimable: \(ByteCountFormatter.string(fromByteCount: analyzer.reclaimableSize, countStyle: .file))")
                            .font(.caption)
                            .foregroundStyle(.cyan)
                    }
                }

                Button(action: { Task { await analyzer.scan() } }) {
                    Label("Scan", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .disabled(analyzer.isScanning)
            }
            .padding()
            .background(Color(NSColor.controlBackgroundColor))

            Divider()

            // Filters
            HStack(spacing: 8) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Search apps...", text: $searchText)
                        .textFieldStyle(.plain)
                }
                .padding(6)
                .background(Color(NSColor.controlBackgroundColor))
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color(NSColor.separatorColor), lineWidth: 0.5)
                )

                Picker("Filter", selection: $filterRecommendation) {
                    Text("All").tag(nil as CacheRecommendation?)
                    Text("Keep").tag(CacheRecommendation.keep as CacheRecommendation?)
                    Text("Safe").tag(CacheRecommendation.safe as CacheRecommendation?)
                    Text("Recommended").tag(CacheRecommendation.recommended as CacheRecommendation?)
                    Text("Stale").tag(CacheRecommendation.stale as CacheRecommendation?)
                }
                .pickerStyle(.menu)
                .frame(width: 150)

                if !selectedEntries.isEmpty {
                    Button(action: { showingCleanConfirmation = true }) {
                        Label("Clean \(selectedEntries.count)", systemImage: "trash")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .controlSize(.small)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)

            Divider()

            // Content
            if analyzer.isScanning {
                VStack(spacing: 12) {
                    Spacer()
                    ProgressView()
                    Text("Analyzing app caches...")
                        .font(.headline)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if filteredEntries.isEmpty {
                VStack(spacing: 12) {
                    Spacer()
                    Image(systemName: "chart.bar.doc.horizontal")
                        .font(.largeTitle)
                        .foregroundStyle(.secondary)
                    Text(analyzer.entries.isEmpty ? "No caches found" : "No matching caches")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    if analyzer.entries.isEmpty {
                        Button("Scan Now") { Task { await analyzer.scan() } }
                            .buttonStyle(.borderedProminent)
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(filteredEntries) { entry in
                        CacheEntryRow(
                            entry: entry,
                            isSelected: selectedEntries.contains(entry.id),
                            onToggle: { toggleSelection(entry) }
                        )
                    }
                }
                .listStyle(.inset(alternatesRowBackgrounds: true))
            }

            // Recommendation summary footer
            if !analyzer.entries.isEmpty {
                CacheRecommendationFooter(
                    entries: analyzer.entries,
                    onCleanRecommended: {
                        selectedEntries = Set(
                            analyzer.entries
                                .filter { $0.recommendation == .stale || $0.recommendation == .recommended }
                                .map { $0.id }
                        )
                        showingCleanConfirmation = true
                    }
                )
            }
        }
        .alert("Clean Selected Caches", isPresented: $showingCleanConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Move to Trash", role: .destructive) {
                let toClean = analyzer.entries.filter { selectedEntries.contains($0.id) }
                Task {
                    cleaningResult = await analyzer.cleanEntries(toClean)
                    selectedEntries.removeAll()
                    showingResult = true
                }
            }
        } message: {
            let toClean = analyzer.entries.filter { selectedEntries.contains($0.id) }
            let size = toClean.reduce(0) { $0 + $1.cacheSize }
            Text("Clean \(toClean.count) app caches?\n\nThis will free \(ByteCountFormatter.string(fromByteCount: size, countStyle: .file)).")
        }
        .alert("Cleaning Complete", isPresented: $showingResult) {
            Button("OK") { cleaningResult = nil }
        } message: {
            if let result = cleaningResult {
                Text("Removed \(result.success) caches.\nFreed \(result.formattedBytesFreed) of space.")
            }
        }
        .onAppear {
            if analyzer.entries.isEmpty {
                Task { await analyzer.scan() }
            }
        }
    }

    private func toggleSelection(_ entry: AppCacheEntry) {
        if selectedEntries.contains(entry.id) {
            selectedEntries.remove(entry.id)
        } else {
            selectedEntries.insert(entry.id)
        }
    }
}

// MARK: - Cache Entry Row

struct CacheEntryRow: View {
    let entry: AppCacheEntry
    let isSelected: Bool
    let onToggle: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Button(action: onToggle) {
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .foregroundStyle(isSelected ? .cyan : .secondary)
            }
            .buttonStyle(.plain)

            if let icon = entry.icon {
                Image(nsImage: icon)
                    .resizable()
                    .frame(width: 28, height: 28)
                    .cornerRadius(6)
            } else {
                Image(systemName: "app.fill")
                    .font(.title2)
                    .foregroundStyle(.secondary)
                    .frame(width: 28, height: 28)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(entry.appName)
                    .font(.subheadline)
                    .fontWeight(.medium)

                Text(entry.bundleId)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
            }

            Spacer()

            Text(entry.stalenessLabel)
                .font(.caption)
                .foregroundStyle(.secondary)

            // Recommendation badge
            RecommendationBadge(recommendation: entry.recommendation)

            Text(entry.formattedSize)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundStyle(.cyan)
                .frame(width: 80, alignment: .trailing)
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
        .onTapGesture { onToggle() }
        .contextMenu {
            Button(action: {
                NSWorkspace.shared.selectFile(entry.cachePath, inFileViewerRootedAtPath: "")
            }) {
                Label("Show in Finder", systemImage: "folder")
            }
            Button(action: {
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(entry.cachePath, forType: .string)
            }) {
                Label("Copy Path", systemImage: "doc.on.doc")
            }
        }
    }
}

// MARK: - Recommendation Badge

struct RecommendationBadge: View {
    let recommendation: CacheRecommendation

    var color: Color {
        switch recommendation {
        case .keep: return .green
        case .safe: return .blue
        case .recommended: return .orange
        case .stale: return .red
        }
    }

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: recommendation.icon)
                .font(.caption2)
            Text(recommendation.rawValue)
                .font(.caption2)
                .fontWeight(.medium)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 3)
        .background(Capsule().fill(color.opacity(0.15)))
        .foregroundStyle(color)
    }
}

// MARK: - Recommendation Footer

struct CacheRecommendationFooter: View {
    let entries: [AppCacheEntry]
    let onCleanRecommended: () -> Void

    private var staleCount: Int { entries.filter { $0.recommendation == .stale }.count }
    private var recommendedCount: Int { entries.filter { $0.recommendation == .recommended }.count }
    private var reclaimableSize: Int64 {
        entries.filter { $0.recommendation == .stale || $0.recommendation == .recommended }
            .reduce(0) { $0 + $1.cacheSize }
    }

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 16) {
                    Label("\(staleCount) stale", systemImage: "trash")
                        .font(.caption)
                        .foregroundStyle(.red)
                    Label("\(recommendedCount) recommended", systemImage: "exclamationmark.triangle")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
                Text("Suggested cleanup: \(ByteCountFormatter.string(fromByteCount: reclaimableSize, countStyle: .file))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if staleCount + recommendedCount > 0 {
                Button(action: onCleanRecommended) {
                    Label("Clean Recommended", systemImage: "sparkles")
                }
                .buttonStyle(.borderedProminent)
                .tint(.cyan)
                .controlSize(.small)
            }
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
    }
}

#Preview {
    AppCacheAnalyzerView()
}
