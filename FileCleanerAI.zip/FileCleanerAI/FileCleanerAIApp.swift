import SwiftUI

@main
struct FileCleanerAIApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .defaultSize(width: 1000, height: 700)
    }
}

// MARK: - App Delegate
@MainActor
class AppDelegate: NSObject, NSApplicationDelegate {
    private let observability = ObservabilityManager.shared

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Initialize bookmark manager to restore saved folder access
        _ = BookmarkManager.shared
        LogManager.shared.log("AI File Cleaner launched", level: .info, category: .system)

        // Start scheduled cleaning checks and menu bar
        _ = ScheduledCleaningManager.shared
        _ = MenuBarManager.shared

        // Emit observability event for AI verification
        observability.appLaunched()
        observability.emit(
            event: .stateChanged,
            component: "App",
            status: .success,
            details: [
                "bookmark_manager": "initialized",
                "log_file": observability.getLogFilePath()
            ]
        )
    }

    func applicationWillTerminate(_ notification: Notification) {
        // Stop accessing all security-scoped resources
        BookmarkManager.shared.stopAccessingAll()
        LogManager.shared.log("AI File Cleaner terminated", level: .info, category: .system)

        // Emit observability event and flush
        observability.appTerminated()
    }
}
