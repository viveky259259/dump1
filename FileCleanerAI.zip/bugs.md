# FileCleanerAI Bug Tracker

## Completed Bugs

### Bug #1: Pattern Dialog Sort Not Updating
**Status:** ✅ Fixed
**Priority:** High
**File:** `FilePatternDetailView.swift`

**Description:**
When viewing a pattern's file list, items are sorted but the size calculations happen asynchronously. The sorted order never updates after sizes are calculated.

**Root Cause:**
- `sortPaths()` was called during initial render
- Size calculations happened in background via `calculateSizesAsync()`
- When sizes completed, `sizeCache` was updated but the view didn't re-sort

**Fix Applied:**
- Added `sizeCacheVersion` state variable that increments when cache updates
- Modified `filteredPaths` to depend on `sizeCacheVersion` for automatic re-computation
- Updated `calculateSizesAsync()` to update cache incrementally (every 10 items) for better UX
- Sort now always uses size values (0 for unknown) instead of conditional sorting

---

### Bug #2: No Cancel for File Search/Calculation
**Status:** ✅ Fixed
**Priority:** High
**Files:** `FilePatternDetailView.swift`, `SizeCalculationManager.swift`

**Description:**
Once a file search or size calculation starts, there's no way to cancel it.

**Root Cause:**
- Background tasks were started with `Task.detached` but task handles weren't stored
- No cancellation mechanism exposed to the UI

**Fix Applied:**
- Added `calculationTask` state to store task reference
- Added `cancelCalculations()` method to cancel running task
- Added cancel button in UI (shows during calculation with progress indicator)
- Added `onDisappear` handler to cancel calculations when view closes
- Added `cancelAllCalculations()` to `SizeCalculationManager` for global cancellation

---

### Bug #3: Missing Debug View
**Status:** ✅ Fixed
**Priority:** Medium
**File:** New file: `DebugView.swift`

**Description:**
No way to see what's happening under the hood - pending operations, active calculations, memory usage, etc.

**Fix Applied:**
- Created `DebugView.swift` with:
  - Memory monitoring (App memory, System used/free, Physical RAM, Memory pressure)
  - Size calculation queue status (High/Low priority counts, Active count, Cache entries)
  - Active calculation paths (with progress indicators)
  - Pending high/low priority paths
  - Recent logs (last 20 entries)
  - Auto-refresh toggle
  - Cancel All Calculations button
- Added debug info properties to `SizeCalculationManager`:
  - `debugHighPriorityCount`, `debugLowPriorityCount`, `debugActiveCount`, `debugCacheCount`
  - `pendingHighPriorityPaths`, `pendingLowPriorityPaths`, `activeCalculationPaths`
  - `cancelAllCalculations()` method
- Added debug button (ant icon) to header bar
- Debug view accessible via sheet from main app

---

## Active Bugs

(None currently)

---

## Notes

- Created: 2024-02-01
- Last Updated: 2024-02-01
- All 3 initial bugs have been fixed and tested
