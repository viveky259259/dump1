#!/bin/bash

# =============================================================================
# AI Verification Script for FileCleanerAI
# =============================================================================
# This script enables AI agents to verify that the app works correctly by:
# 1. Building the app
# 2. Running it briefly
# 3. Analyzing observability logs
# 4. Reporting verification results
#
# Usage:
#   ./verify_app.sh [options]
#
# Options:
#   --build-only    Only build, don't run verification
#   --skip-build    Skip building, only run verification on existing build
#   --verbose       Show detailed output
#   --json          Output results as JSON (for AI consumption)
# =============================================================================

set -e

# Colors for human-readable output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="FileCleanerAI"
BUILD_DIR="${SCRIPT_DIR}/.build"
APP_PATH="${BUILD_DIR}/release/${APP_NAME}"
LOG_FILE="${TMPDIR}filecleaner_observability.jsonl"
VERIFICATION_TIMEOUT=10  # seconds to wait for app to emit logs

# Parse arguments
BUILD_ONLY=false
SKIP_BUILD=false
VERBOSE=false
JSON_OUTPUT=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --build-only) BUILD_ONLY=true; shift ;;
        --skip-build) SKIP_BUILD=true; shift ;;
        --verbose) VERBOSE=true; shift ;;
        --json) JSON_OUTPUT=true; shift ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

# Logging functions
log_info() {
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${BLUE}ℹ${NC} $1"
    fi
}

log_success() {
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${GREEN}✓${NC} $1"
    fi
}

log_warning() {
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${YELLOW}⚠${NC} $1"
    fi
}

log_error() {
    if [ "$JSON_OUTPUT" = false ]; then
        echo -e "${RED}✗${NC} $1"
    fi
}

log_verbose() {
    if [ "$VERBOSE" = true ] && [ "$JSON_OUTPUT" = false ]; then
        echo -e "  ${NC}$1"
    fi
}

# Build the app
build_app() {
    log_info "Building ${APP_NAME}..."

    cd "${SCRIPT_DIR}"

    if [ "$VERBOSE" = true ]; then
        swift build -c release 2>&1
    else
        swift build -c release 2>&1 | tail -5
    fi

    if [ -f "${APP_PATH}" ]; then
        log_success "Build successful: ${APP_PATH}"
        return 0
    else
        log_error "Build failed: executable not found"
        return 1
    fi
}

# Run the app and collect logs
run_app_for_verification() {
    log_info "Running app for verification (${VERIFICATION_TIMEOUT}s timeout)..."

    # Clear previous log file
    rm -f "${LOG_FILE}"

    # Run the app in background
    "${APP_PATH}" &
    APP_PID=$!

    log_verbose "App started with PID: ${APP_PID}"

    # Wait for log file to be created and have content
    local waited=0
    while [ $waited -lt $VERIFICATION_TIMEOUT ]; do
        if [ -f "${LOG_FILE}" ] && [ -s "${LOG_FILE}" ]; then
            # Check if we have the key events
            if grep -q '"event":"app_launched"' "${LOG_FILE}" 2>/dev/null; then
                log_verbose "App launched event detected"
                break
            fi
        fi
        sleep 1
        waited=$((waited + 1))
        log_verbose "Waiting for app to emit logs... (${waited}s)"
    done

    # Give app a moment to fully initialize
    sleep 2

    # Terminate the app gracefully
    if kill -0 $APP_PID 2>/dev/null; then
        log_verbose "Sending SIGTERM to app..."
        kill -TERM $APP_PID 2>/dev/null || true
        sleep 1
        # Force kill if still running
        if kill -0 $APP_PID 2>/dev/null; then
            kill -9 $APP_PID 2>/dev/null || true
        fi
    fi

    log_success "App run completed"
}

# Analyze the observability logs
analyze_logs() {
    log_info "Analyzing observability logs..."

    if [ ! -f "${LOG_FILE}" ]; then
        log_error "Log file not found: ${LOG_FILE}"
        return 1
    fi

    local log_content=$(cat "${LOG_FILE}")
    local checks_passed=0
    local checks_failed=0
    local results=()

    # Check 1: App launched
    if echo "$log_content" | grep -q '"event":"app_launched".*"status":"success"'; then
        log_success "Check: app_launched event found"
        checks_passed=$((checks_passed + 1))
        results+=('{"check": "app_launched", "status": "pass"}')
    else
        log_error "Check: app_launched event NOT found"
        checks_failed=$((checks_failed + 1))
        results+=('{"check": "app_launched", "status": "fail"}')
    fi

    # Check 2: View appeared
    if echo "$log_content" | grep -q '"event":"view_appeared"'; then
        log_success "Check: view_appeared event found"
        checks_passed=$((checks_passed + 1))
        results+=('{"check": "view_appeared", "status": "pass"}')
    else
        log_warning "Check: view_appeared event NOT found (UI may not have loaded)"
        checks_failed=$((checks_failed + 1))
        results+=('{"check": "view_appeared", "status": "warn"}')
    fi

    # Check 3: No errors
    if echo "$log_content" | grep -q '"status":"failure"'; then
        local error_count=$(echo "$log_content" | grep -c '"status":"failure"' || echo 0)
        log_error "Check: Found ${error_count} error event(s)"
        checks_failed=$((checks_failed + 1))
        results+=("{\"check\": \"no_errors\", \"status\": \"fail\", \"error_count\": ${error_count}}")

        # Show errors if verbose
        if [ "$VERBOSE" = true ]; then
            echo "$log_content" | grep '"status":"failure"' | while read line; do
                log_verbose "  Error: $line"
            done
        fi
    else
        log_success "Check: No error events found"
        checks_passed=$((checks_passed + 1))
        results+=('{"check": "no_errors", "status": "pass"}')
    fi

    # Check 4: Log file has valid JSON lines
    local valid_lines=0
    local invalid_lines=0
    while IFS= read -r line; do
        if [ -n "$line" ]; then
            if echo "$line" | python3 -c "import json,sys; json.load(sys.stdin)" 2>/dev/null; then
                valid_lines=$((valid_lines + 1))
            else
                invalid_lines=$((invalid_lines + 1))
            fi
        fi
    done < "${LOG_FILE}"

    if [ $invalid_lines -eq 0 ] && [ $valid_lines -gt 0 ]; then
        log_success "Check: All ${valid_lines} log lines are valid JSON"
        checks_passed=$((checks_passed + 1))
        results+=("{\"check\": \"valid_json\", \"status\": \"pass\", \"line_count\": ${valid_lines}}")
    else
        log_error "Check: Found ${invalid_lines} invalid JSON lines"
        checks_failed=$((checks_failed + 1))
        results+=("{\"check\": \"valid_json\", \"status\": \"fail\", \"invalid_count\": ${invalid_lines}}")
    fi

    # Summary
    echo ""
    if [ "$JSON_OUTPUT" = true ]; then
        local results_json=$(printf '%s\n' "${results[@]}" | paste -sd ',' -)
        echo "{\"verification\": {\"passed\": ${checks_passed}, \"failed\": ${checks_failed}, \"checks\": [${results_json}], \"log_file\": \"${LOG_FILE}\"}}"
    else
        if [ $checks_failed -eq 0 ]; then
            log_success "═══════════════════════════════════════════"
            log_success "VERIFICATION PASSED: ${checks_passed}/${checks_passed} checks passed"
            log_success "═══════════════════════════════════════════"
        else
            log_error "═══════════════════════════════════════════"
            log_error "VERIFICATION FAILED: ${checks_passed} passed, ${checks_failed} failed"
            log_error "═══════════════════════════════════════════"
        fi
        echo ""
        log_info "Log file: ${LOG_FILE}"
    fi

    [ $checks_failed -eq 0 ]
}

# Show log file contents
show_logs() {
    if [ "$VERBOSE" = true ] && [ -f "${LOG_FILE}" ]; then
        echo ""
        log_info "Raw log contents:"
        echo "─────────────────────────────────────────"
        cat "${LOG_FILE}" | python3 -m json.tool 2>/dev/null || cat "${LOG_FILE}"
        echo "─────────────────────────────────────────"
    fi
}

# Main execution
main() {
    echo ""
    if [ "$JSON_OUTPUT" = false ]; then
        echo "═══════════════════════════════════════════"
        echo "  FileCleanerAI Verification Script"
        echo "═══════════════════════════════════════════"
        echo ""
    fi

    # Build step
    if [ "$SKIP_BUILD" = false ]; then
        if ! build_app; then
            if [ "$JSON_OUTPUT" = true ]; then
                echo '{"verification": {"status": "build_failed"}}'
            fi
            exit 1
        fi
    else
        log_info "Skipping build (--skip-build)"
        if [ ! -f "${APP_PATH}" ]; then
            log_error "No existing build found at ${APP_PATH}"
            exit 1
        fi
    fi

    # Exit if build-only
    if [ "$BUILD_ONLY" = true ]; then
        log_info "Build-only mode, skipping verification"
        exit 0
    fi

    echo ""

    # Run and verify
    run_app_for_verification

    echo ""

    # Analyze results
    analyze_logs
    local result=$?

    show_logs

    exit $result
}

main "$@"
