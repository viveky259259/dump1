# AI File Cleaner v1.0.0

## Overview

AI File Cleaner is an intelligent macOS application that uses on-device AI to help you find and safely delete temporary files, build artifacts, and other space-consuming files. Reclaim gigabytes of disk space while keeping your important files safe.

## What's New in v1.0.0

This is the first public release of AI File Cleaner!

### Features

- **On-Device AI Analysis** - Uses Apple's FoundationModels for intelligent file pattern detection with smart rule-based fallback
- **Smart Pattern Detection** - Automatically identifies and groups similar files (node_modules, build artifacts, caches, logs)
- **Safety Scoring System** - AI analyzes each file pattern and provides safety ratings:
  - 🟢 **High Safety** - Build artifacts, dependencies (safe to delete)
  - 🟡 **Medium Safety** - Temp files, logs (usually safe)
  - 🔴 **Low Safety** - Review carefully before deletion
- **Progressive Scanning** - Real-time updates as files are discovered
- **Disk Usage Visualization** - Interactive charts showing storage breakdown
- **Safe Deletion** - Moves files to Trash (not permanent deletion)
- **AI Chat Assistant** - Ask questions about your files in natural language
- **100% Local Processing** - No data sent to external servers

### What It Finds

| Category | Examples | Typical Size |
|----------|----------|--------------|
| Package Dependencies | `node_modules`, `Pods`, `.gradle` | 1-10 GB |
| Build Artifacts | `build/`, `target/`, `dist/`, `DerivedData` | 2-15 GB |
| Caches | `.cache`, `__pycache__`, `.pytest_cache` | 500 MB - 5 GB |
| Temporary Files | `.tmp`, `.log`, `.DS_Store` | 100 MB - 1 GB |
| Archives | `.zip`, `.tar.gz` (in temp locations) | Varies |

## System Requirements

- **macOS 15.0** (Sequoia) or later
- **Apple Silicon recommended** (M1/M2/M3/M4) for AI features
- Intel Macs supported with rule-based analysis fallback

## Installation

1. Download `AI File Cleaner-1.0.0.dmg`
2. Open the DMG file
3. Drag "AI File Cleaner" to the Applications folder
4. Launch from Applications or Spotlight

**Note:** On first launch, macOS may show a security prompt. Go to System Settings → Privacy & Security and click "Open Anyway".

## Privacy & Security

- ✅ **100% Local** - All processing happens on your device
- ✅ **No Network Calls** - The app never connects to external servers
- ✅ **Safe Deletion** - Files are moved to Trash, not permanently deleted
- ✅ **No System Files** - Critical system directories are automatically skipped
- ✅ **Transparent** - See exactly what will be deleted before confirming

## Screenshots

*Coming soon*

## Known Limitations

- AI chat features require macOS 26.0+ with Apple Intelligence enabled
- First scan may take longer as caches are built
- Some protected system directories may show permission warnings

## Feedback & Support

- **Report Issues:** [GitHub Issues](https://github.com/nicholasareed/FileCleanerAI/issues)
- **Contribute:** [Contributing Guide](https://github.com/nicholasareed/FileCleanerAI/blob/main/CONTRIBUTING.md)
- **Source Code:** [GitHub Repository](https://github.com/nicholasareed/FileCleanerAI)

## License

MIT License - Free to use, modify, and distribute.

---

**Download:** [AI File Cleaner-1.0.0.dmg](https://github.com/nicholasareed/FileCleanerAI/releases/download/v1.0.0/AI.File.Cleaner-1.0.0.dmg)

Made with ❤️ for macOS
