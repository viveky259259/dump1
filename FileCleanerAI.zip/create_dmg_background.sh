#!/bin/bash

# Create a DMG background image with drag-to-Applications arrow
# This creates a simple PNG background

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/dmg_assets"
BACKGROUND="$OUTPUT_DIR/background.png"

mkdir -p "$OUTPUT_DIR"

# Create background using Python (available on macOS)
python3 << 'PYTHON_SCRIPT'
import os

# Create a simple SVG background
svg_content = '''<svg width="600" height="400" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#1a1a2e"/>
      <stop offset="100%" style="stop-color:#16213e"/>
    </linearGradient>
    <linearGradient id="arrow" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#3498DB"/>
      <stop offset="100%" style="stop-color:#9B59B6"/>
    </linearGradient>
  </defs>
  
  <!-- Background -->
  <rect width="600" height="400" fill="url(#bg)"/>
  
  <!-- Subtle grid pattern -->
  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#ffffff" stroke-width="0.5" stroke-opacity="0.05"/>
  </pattern>
  <rect width="600" height="400" fill="url(#grid)"/>
  
  <!-- Arrow pointing right -->
  <g transform="translate(300, 200)">
    <!-- Arrow body -->
    <rect x="-60" y="-15" width="100" height="30" rx="15" fill="url(#arrow)" opacity="0.9"/>
    <!-- Arrow head -->
    <polygon points="50,-30 90,0 50,30" fill="url(#arrow)" opacity="0.9"/>
  </g>
  
  <!-- Text labels -->
  <text x="140" y="340" font-family="SF Pro Display, -apple-system, BlinkMacSystemFont, Helvetica Neue, sans-serif" font-size="14" fill="#ffffff" opacity="0.7" text-anchor="middle">AI File Cleaner</text>
  <text x="460" y="340" font-family="SF Pro Display, -apple-system, BlinkMacSystemFont, Helvetica Neue, sans-serif" font-size="14" fill="#ffffff" opacity="0.7" text-anchor="middle">Applications</text>
  
  <!-- Instruction text -->
  <text x="300" y="380" font-family="SF Pro Display, -apple-system, BlinkMacSystemFont, Helvetica Neue, sans-serif" font-size="12" fill="#ffffff" opacity="0.5" text-anchor="middle">Drag to install</text>
</svg>'''

script_dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in dir() else os.getcwd()
output_dir = os.path.join(script_dir, 'dmg_assets')
os.makedirs(output_dir, exist_ok=True)

svg_path = os.path.join(output_dir, 'background.svg')
with open(svg_path, 'w') as f:
    f.write(svg_content)

print(f"Created: {svg_path}")
PYTHON_SCRIPT

# Convert SVG to PNG using rsvg-convert if available
if command -v rsvg-convert &> /dev/null; then
    rsvg-convert -w 600 -h 400 "$OUTPUT_DIR/background.svg" > "$BACKGROUND"
    echo "✅ Created DMG background: $BACKGROUND"
else
    # Keep SVG for manual conversion
    echo "⚠️  rsvg-convert not found. SVG saved at: $OUTPUT_DIR/background.svg"
    echo "   Install with: brew install librsvg"
fi
