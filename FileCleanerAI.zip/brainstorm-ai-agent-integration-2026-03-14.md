# Brainstorm: How AI Agents Can Use FileCleanerAI as an Agent
**Date**: 2026-03-14
**Type**: exploration + ideation

## Central Question
How can Claude (or any AI agent) use FileCleanerAI as an agent tool — invoking its scanning, cleaning, and optimization capabilities programmatically?

## Mind Map

```
                          ┌─── MCP Server (Model Context Protocol)
                          │    ├── Tool definitions for each manager
                          │    ├── Resource exposure (health, disk stats)
                          │    └── Prompt templates for cleanup workflows
                          │
                          ├─── CLI Interface
                          │    ├── Subcommands: scan, clean, health, optimize
                          │    ├── JSON output mode for machine parsing
                          │    └── Exit codes for success/failure
                          │
                          ├─── URL Scheme / Apple Events
   [AI Agent Integration] │    ├── x-filecleaner:// deep links
                          │    ├── AppleScript dictionary
                          │    └── Shortcuts.app actions
                          │
                          ├─── HTTP API (Local)
                          │    ├── REST endpoints on localhost
                          │    ├── WebSocket for live progress
                          │    └── Auth via local token
                          │
                          ├─── Agent-to-Agent Protocol
                          │    ├── Structured JSON request/response
                          │    ├── Capability discovery
                          │    └── Safety confirmations
                          │
                          └─── Wild Cards
                               ├── FileCleanerAI AS the AI agent itself
                               ├── Natural language command parsing
                               └── Autonomous disk guardian daemon
```

## Branch Analysis

### 1. MCP Server (Most Promising for Claude)

**What**: Model Context Protocol — the standard way Claude Code and Claude Desktop
connect to external tools. FileCleanerAI exposes its capabilities as MCP tools.

**Architecture**:
```
┌──────────────┐     stdio/SSE      ┌──────────────────────┐
│  Claude Code  │ ◄──────────────► │  FileCleanerAI MCP    │
│  / Desktop    │    JSON-RPC       │  Server (Swift)       │
└──────────────┘                    │                       │
                                    │  Tools:               │
                                    │  - scan_disk          │
                                    │  - scan_duplicates    │
                                    │  - scan_system_data   │
                                    │  - get_health_score   │
                                    │  - clean_category     │
                                    │  - list_dev_projects  │
                                    │  - clean_stale_projects│
                                    │  - optimize_system    │
                                    │  - get_recommendations│
                                    │                       │
                                    │  Resources:           │
                                    │  - disk://health      │
                                    │  - disk://usage       │
                                    │  - disk://schedule    │
                                    └──────────────────────┘
```

**MCP Tools Design**:

| Tool | Parameters | Returns |
|------|-----------|---------|
| `scan_disk` | `paths?: string[]` | Categories with sizes |
| `scan_duplicates` | `paths: string[], min_size?: int` | Duplicate groups |
| `scan_system_data` | — | 10 categories with sizes |
| `get_health_score` | — | Score 0-100, grade, metrics |
| `clean_category` | `category_id: string, dry_run?: bool` | CleaningResult |
| `clean_stale_projects` | `older_than_days?: int` | CleaningResult |
| `list_dev_projects` | — | Projects with artifact sizes |
| `optimize_system` | `tasks: string[]` | Task results |
| `get_recommendations` | — | Prioritized cleanup actions |
| `manage_snapshots` | `action: "list"|"delete"|"thin"` | Snapshot info |
| `analyze_app_caches` | — | Per-app cache entries |
| `check_homebrew` | — | Cleanup opportunities |
| `uninstall_app` | `app_name: string, dry_run?: bool` | Remnants found/cleaned |

**MCP Resources**:
- `disk://health` — Live health score + metrics
- `disk://usage` — Current disk usage breakdown
- `disk://schedule` — Next scheduled clean, last results
- `disk://whitelist` — Current protection rules

**Why this is #1**: Claude Code already supports MCP. Users just add the server to
their config and Claude can immediately use it. No new protocols needed.

**Implementation approach**:
- Build a separate Swift executable `filecleaner-mcp` that communicates via stdio
- It imports the same manager classes from the main app (shared Swift package)
- Or: embed MCP server directly in the app, communicating via named pipe/socket

---

### 2. CLI Interface

**What**: A command-line tool (`filecleaner`) that wraps the same manager classes.

**Design**:
```bash
# Scanning
filecleaner scan disk --json
filecleaner scan duplicates ~/Documents --min-size 1MB --json
filecleaner scan system-data --json
filecleaner scan dev-projects --json

# Health
filecleaner health --json
filecleaner health recommendations

# Cleaning (requires --confirm or --dry-run)
filecleaner clean system-data --category caches --dry-run
filecleaner clean system-data --category caches --confirm
filecleaner clean stale-projects --older-than 90d --confirm
filecleaner clean duplicates --keep newest --confirm

# Optimization
filecleaner optimize --tasks dns,memory,spotlight
filecleaner optimize --all

# Configuration
filecleaner config export > config.json
filecleaner config import < config.json
filecleaner whitelist add --pattern "*.important" --reason "business files"

# Status
filecleaner status  # quick disk + health summary
```

**Why CLI matters**: Any AI agent that can execute shell commands (Claude Code, Cursor,
Copilot, Aider, etc.) can use this. It's the universal interface.

**JSON output mode** is critical — all commands support `--json` flag for machine-readable
structured output that agents can parse reliably.

**Safety**: Destructive operations require explicit `--confirm` flag. `--dry-run` shows
what would happen without acting. This maps perfectly to agent confirmation flows.

---

### 3. URL Scheme + Apple Events

**What**: Register `x-filecleaner://` URL scheme and an AppleScript dictionary.

```
x-filecleaner://scan?type=disk
x-filecleaner://health
x-filecleaner://clean?category=system-caches&dry-run=true
```

**AppleScript**:
```applescript
tell application "AI File Cleaner"
    set healthScore to get health score
    set diskInfo to scan disk usage
    clean system data category "caches" with dry run
end tell
```

**Shortcuts.app Integration**:
- "Scan Disk" action
- "Get Health Score" action
- "Clean Category" action with category picker
- "Quick Optimize" action

**Why**: Enables Siri, Shortcuts, and any macOS automation tool to drive FileCleanerAI.
Also enables multi-agent workflows where a higher-level agent orchestrates multiple apps.

---

### 4. Local HTTP API

**What**: Lightweight HTTP server on localhost (e.g., port 19384) with REST endpoints.

```
GET  /api/health           → { score: 87, grade: "good", ... }
GET  /api/disk/usage       → { categories: [...] }
POST /api/scan/duplicates  → { groups: [...] }
POST /api/clean            → { result: { success: 12, freed: "2.3 GB" } }
GET  /api/recommendations  → [{ action: "clean_caches", impact: "high" }]
WS   /api/progress         → Live scan/clean progress stream
```

**Why**: Language-agnostic. Python agents, JavaScript agents, any HTTP client works.
WebSocket gives real-time progress for long operations.

**Auth**: Local-only binding + file-based token in `~/.filecleaner/auth-token`.

---

### 5. Agent-to-Agent Protocol (Structured Handoff)

**What**: A higher-level protocol where AI agents communicate intent, not just commands.

```json
{
  "intent": "free_disk_space",
  "context": {
    "reason": "user needs 10GB for Xcode update",
    "urgency": "medium",
    "constraints": ["preserve_dev_projects", "no_browser_data"]
  },
  "preferences": {
    "dry_run_first": true,
    "max_deletion_gb": 20,
    "require_confirmation": true
  }
}
```

**Response**:
```json
{
  "plan": [
    { "action": "clean_system_caches", "estimated_freed": "3.2 GB", "risk": "low" },
    { "action": "clean_xcode_derived_data", "estimated_freed": "8.1 GB", "risk": "low" },
    { "action": "clean_stale_projects", "estimated_freed": "4.7 GB", "risk": "medium" }
  ],
  "total_estimated": "16.0 GB",
  "meets_requirement": true,
  "awaiting_confirmation": true
}
```

**Why**: This is how agents SHOULD talk to each other — with intent and constraints,
not raw commands. FileCleanerAI can make smart decisions about what to clean.

---

### 6. Wild Cards

#### FileCleanerAI AS an AI Agent
Instead of being a tool for other agents, FileCleanerAI itself becomes an autonomous
agent that monitors the system and takes action:
- Watches disk usage trends
- Predicts when disk will be full
- Proactively suggests cleanups
- Learns user patterns (what they clean, what they keep)
- Auto-escalates to user when high-impact decisions needed

#### Natural Language Interface
Embed an LLM (local or API) directly in the app:
- "Free up 5GB, don't touch my photos"
- "Clean everything from projects I haven't touched in 6 months"
- "What's eating my disk space?"
- "Set up weekly cleaning but skip browser data"

#### Daemon Mode
A background daemon that other agents can query via Unix socket:
- Always running, always monitoring
- Instant responses (no app launch delay)
- LaunchAgent integration for auto-start

---

## Deep Dives

### Deep Dive 1: MCP Server Implementation

**Architecture Decision: Embedded vs Standalone**

Option A: **Standalone MCP binary** (Recommended)
```
FileCleanerAI.app (GUI)
filecleaner-mcp (CLI, MCP server)  ← shares Swift package
filecleaner (CLI tool)              ← shares Swift package
```

All three targets share the same Swift package with manager classes. The MCP server
is a separate executable that Claude Code launches as a subprocess.

Option B: **Embedded in app**
The app itself listens on a named pipe. MCP client connects to it.
Problem: App must be running. Not ideal for headless/background use.

**Recommendation**: Option A. Create a Swift Package with shared business logic,
then three targets: app, CLI, and MCP server.

**MCP Server in Swift**:
```swift
// Using swift-mcp-server or custom implementation
struct FileCleanerMCPServer {
    let healthManager = HealthScoreManager.shared
    let systemScanner = SystemDataScanner.shared
    let diskScanner = DiskScanner.shared

    func handleToolCall(_ tool: String, _ params: JSON) async -> JSON {
        switch tool {
        case "get_health_score":
            healthManager.updateHealthScore()
            return JSON([
                "score": healthManager.healthScore,
                "grade": healthManager.healthGrade.rawValue,
                "cpu": healthManager.cpuUsage,
                "memory": healthManager.memoryUsage,
                "disk": healthManager.diskUsage,
                "recommendations": healthManager.getRecommendations()
            ])
        case "scan_system_data":
            await systemScanner.scanForSystemData()
            return JSON(systemScanner.categories.map { ... })
        // ... more tools
        }
    }
}
```

**Claude Code config** (`~/.claude/mcp.json`):
```json
{
  "mcpServers": {
    "filecleaner": {
      "command": "/Applications/AI File Cleaner.app/Contents/MacOS/filecleaner-mcp",
      "args": []
    }
  }
}
```

**User experience**:
```
User: "My disk is almost full, help me free up space"
Claude: [calls get_health_score] → sees disk at 92% usage
Claude: [calls scan_system_data] → finds 8.3 GB reclaimable
Claude: [calls list_dev_projects] → finds 12 stale projects, 15 GB
Claude: "Your disk is at 92%. Here's what I found:
         - 8.3 GB in system caches (safe to clean)
         - 15 GB in stale dev project artifacts
         Want me to clean the system caches first?"
User: "Yes, go ahead"
Claude: [calls clean_category with category_id="system_caches"]
Claude: "Freed 8.3 GB. Disk now at 83%. Want me to tackle stale projects too?"
```

---

### Deep Dive 2: CLI Tool Design

**Safety-First Design for AI Agents**:

The CLI must be designed with the assumption that an AI agent is calling it.
Key principles:

1. **No destructive action without explicit flag**
   ```bash
   filecleaner clean system-data          # ERROR: must specify --dry-run or --confirm
   filecleaner clean system-data --dry-run  # Shows plan, no action
   filecleaner clean system-data --confirm  # Actually cleans
   ```

2. **Machine-readable output by default when piped**
   ```bash
   filecleaner health              # Human-readable when TTY
   filecleaner health --json       # Always JSON
   filecleaner health | jq .score  # Auto-JSON when piped
   ```

3. **Idempotent operations**
   Running the same clean twice should not error — just report "0 items cleaned".

4. **Progress on stderr, results on stdout**
   ```bash
   filecleaner scan disk --json 2>/dev/null  # Clean JSON on stdout
   ```

5. **Meaningful exit codes**
   - 0: Success
   - 1: Error
   - 2: Nothing to clean
   - 3: Requires confirmation (dry-run showed results)
   - 4: Permission denied (needs admin)

---

### Deep Dive 3: Safety & Trust Model

**Critical Question**: How much autonomy should an AI agent have over file deletion?

**Tiered Trust Model**:
```
┌─────────────────────────────────────────────┐
│ Level 0: Read-Only (Default)                │
│ - Health checks, scans, recommendations     │
│ - No file modification whatsoever            │
├─────────────────────────────────────────────┤
│ Level 1: Safe Cleanup                       │
│ - System caches, temp files, logs           │
│ - Items with safety score "High"            │
│ - Requires dry-run confirmation             │
├─────────────────────────────────────────────┤
│ Level 2: Standard Cleanup                   │
│ - Dev artifacts, browser caches             │
│ - Duplicate files (keep newest)             │
│ - Items with safety score "Medium"          │
├─────────────────────────────────────────────┤
│ Level 3: Full Access                        │
│ - App uninstallation                        │
│ - APFS snapshot deletion                    │
│ - System optimization commands              │
│ - Requires per-action user confirmation     │
└─────────────────────────────────────────────┘
```

**Configuration** (`~/.filecleaner/agent-policy.json`):
```json
{
  "trust_level": 1,
  "require_dry_run": true,
  "max_single_deletion_gb": 5,
  "protected_paths": ["~/Documents", "~/Desktop"],
  "allowed_categories": ["system_caches", "temp_files", "logs"],
  "audit_log": true
}
```

**Audit Trail**: Every agent action is logged with timestamp, agent identity,
action taken, and bytes affected. User can review in app UI.

---

## Synthesis

### Key Insights

1. **MCP is the highest-leverage integration** — it connects directly to Claude Code/Desktop with minimal friction, uses an established protocol, and the existing singleton architecture maps cleanly to MCP tools.

2. **CLI is the universal fallback** — any agent that can run shell commands gets access. Combined with `--json` output, it's the most broadly compatible option.

3. **Safety is the #1 design concern** — an AI agent deleting the wrong files is catastrophic. The tiered trust model + mandatory dry-run + audit logging are non-negotiable.

4. **The existing architecture is already agent-ready** — singleton managers with clear async APIs, structured return types (CleaningResult), and an observability system mean the plumbing exists. What's missing is the external interface layer.

5. **Intent-based communication is the future** — rather than "delete /path/to/cache", agents should say "free 5GB safely" and let FileCleanerAI decide how. This plays to the app's existing recommendation engine.

### Recommended Implementation Order

| Priority | Feature | Effort | Impact |
|----------|---------|--------|--------|
| 1 | **MCP Server** | Medium | Very High — Claude integration |
| 2 | **CLI Tool** | Medium | High — universal agent access |
| 3 | **Agent Safety Policy** | Low | Critical — trust & audit |
| 4 | **URL Scheme** | Low | Medium — macOS automation |
| 5 | **Intent Protocol** | High | High — future-proof |
| 6 | **Local HTTP API** | Medium | Medium — cross-language |

### Decision Points
- Should the MCP server be standalone binary or embedded in app?
- What default trust level for AI agents?
- Should the CLI ship inside the .app bundle or as a separate install?
- Do we need real-time progress streaming for long scans?

### Next Steps
1. Refactor business logic into a shared Swift package (separate from UI)
2. Build `filecleaner` CLI with `--json` output and safety flags
3. Build `filecleaner-mcp` server implementing MCP protocol
4. Add agent policy configuration (trust levels, audit log)
5. Register URL scheme in Info.plist
6. Add Shortcuts.app actions via App Intents framework
