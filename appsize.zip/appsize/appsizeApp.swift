//
//  appsizeApp.swift
//  appsize
//
//  Created by Vivek Yadav on 10/12/24.
//

import SwiftUI

@main
struct appsizeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
