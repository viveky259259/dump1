//
//  appsizeTests.swift
//  appsizeTests
//
//  Created by Vivek Yadav on 10/12/24.
//

import Testing
@testable import appsize

struct appsizeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
