//
//  testTests.swift
//  testTests
//
//  Created by Vivek Yadav on 18/12/24.
//

import Testing
@testable import test

struct testTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
