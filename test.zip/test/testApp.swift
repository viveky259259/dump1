//
//  testApp.swift
//  test
//
//  Created by Vivek Yadav on 18/12/24.
//

import SwiftUI

@main
struct testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
