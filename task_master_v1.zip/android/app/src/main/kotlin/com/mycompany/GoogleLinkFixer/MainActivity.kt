package com.mycompany.GoogleLinkFixer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
