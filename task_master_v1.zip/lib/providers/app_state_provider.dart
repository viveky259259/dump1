import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../data_schema.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';

class AppStateProvider extends ChangeNotifier {
  final AuthService _authService;
  final FirestoreService _firestoreService;
  
  // Auth state
  User? _currentUser;
  bool _isLoading = false;
  String? _error;
  
  // App state
  List<ProfileModel> _profiles = [];
  List<TaskModel> _tasks = [];
  ProfileModel? _selectedProfile;
  TaskFilter _currentFilter = TaskFilter();
  UserSettingsModel? _userSettings;
  
  // Getters
  User? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  bool get isAnonymous => _currentUser?.isAnonymous ?? false;
  bool get isLoading => _isLoading;
  String? get error => _error;
  
  List<ProfileModel> get profiles => _profiles;
  List<TaskModel> get tasks => _filteredTasks;
  ProfileModel? get selectedProfile => _selectedProfile;
  TaskFilter get currentFilter => _currentFilter;
  UserSettingsModel? get userSettings => _userSettings;
  
  AppStateProvider(this._authService, this._firestoreService) {
    _initializeApp();
  }
  
  void _initializeApp() {
    _authService.authStateChanges.listen((user) {
      _currentUser = user;
      if (user != null) {
        _loadUserData();
      } else {
        _clearUserData();
      }
      notifyListeners();
    });
  }
  
  Future<void> _loadUserData() async {
    setLoading(true);
    try {
      // Load profiles
      _firestoreService.getProfiles().listen((profiles) {
        _profiles = profiles;
        
        // Create a default profile for new users (including anonymous)
        if (profiles.isEmpty) {
          _createDefaultProfile();
        } else {
          // Set default profile if none selected
          if (_selectedProfile == null) {
            _selectedProfile = profiles.firstWhere(
              (p) => p.isDefault,
              orElse: () => profiles.first,
            );
          }
          
          // Load tasks for selected profile
          if (_selectedProfile != null) {
            _loadTasks();
          }
        }
        
        notifyListeners();
      });
      
      // Load user settings
      _firestoreService.getSettingsStream().listen((settings) {
        _userSettings = settings;
        notifyListeners();
      });
      
    } catch (e) {
      setError(e.toString());
    } finally {
      setLoading(false);
    }
  }
  
  Future<void> _createDefaultProfile() async {
    try {
      final isAnonymousUser = _currentUser?.isAnonymous ?? false;
      final profileName = isAnonymousUser ? 'Guest Profile' : 'My Tasks';
      
      final defaultProfile = ProfileModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: profileName,
        colorCode: '#6F61EF',
        createdAt: DateTime.now(),
        isDefault: true,
      );
      
      await _firestoreService.createProfile(defaultProfile);
      _selectedProfile = defaultProfile;
      
      // Create a welcome task for new users
      if (isAnonymousUser) {
        await _createWelcomeTask();
      }
      
    } catch (e) {
      setError(e.toString());
    }
  }
  
  Future<void> _createWelcomeTask() async {
    try {
      if (_selectedProfile == null) return;
      
      final welcomeTask = TaskModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: 'Welcome to TaskFlow Pro! 👋',
        description: 'This is your first task. Try editing it, marking it complete, or creating new ones. Don\'t forget to upgrade your account to keep your tasks safe!',
        stage: TaskStage.todo.value,
        priority: TaskPriority.medium.value,
        profileId: _selectedProfile!.id,
        tags: ['welcome', 'getting-started'],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      
      await _firestoreService.createTask(welcomeTask);
    } catch (e) {
      // Don't show error for welcome task creation failure
      debugPrint('Failed to create welcome task: $e');
    }
  }
  
  void _loadTasks() {
    _firestoreService.getTasks(filter: _currentFilter).listen((tasks) {
      _tasks = tasks;
      notifyListeners();
    });
  }
  
  void _clearUserData() {
    _profiles = [];
    _tasks = [];
    _selectedProfile = null;
    _currentFilter = TaskFilter();
    _userSettings = null;
  }
  
  // Filtered tasks based on current filter
  List<TaskModel> get _filteredTasks {
    List<TaskModel> filtered = List.from(_tasks);
    
    // Filter out soft-deleted tasks (extra safety check)
    filtered = filtered.where((task) => !task.isDeleted).toList();
    
    // Apply profile filter
    if (_currentFilter.profileId != null) {
      filtered = filtered.where((task) => task.profileId == _currentFilter.profileId).toList();
    } else if (_selectedProfile != null) {
      filtered = filtered.where((task) => task.profileId == _selectedProfile!.id).toList();
    }
    
    return filtered;
  }
  
  // Loading state management
  void setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void setError(String? error) {
    _error = error;
    notifyListeners();
  }
  
  void clearError() {
    _error = null;
    notifyListeners();
  }
  
  // Profile operations
  Future<void> createProfile(String name, String colorCode) async {
    try {
      setLoading(true);
      final isFirstProfile = _profiles.isEmpty;
      
      final profile = ProfileModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name,
        colorCode: colorCode,
        createdAt: DateTime.now(),
        isDefault: isFirstProfile, // First profile is default
      );
      
      await _firestoreService.createProfile(profile);
      
      // Immediately update local state for better UX
      _profiles.add(profile);
      
      // If this is the first profile, select it
      if (isFirstProfile) {
        _selectedProfile = profile;
      }
      
      // Notify listeners of the changes
      notifyListeners();
      
    } catch (e) {
      setError(e.toString());
    } finally {
      setLoading(false);
    }
  }
  
  Future<void> updateProfile(ProfileModel profile) async {
    try {
      setLoading(true);
      await _firestoreService.updateProfile(profile);
      
      // Update local state immediately
      final index = _profiles.indexWhere((p) => p.id == profile.id);
      if (index != -1) {
        _profiles[index] = profile;
      }
      
      // Update selected profile if it's the same
      if (_selectedProfile?.id == profile.id) {
        _selectedProfile = profile;
      }
      
      // Notify listeners of the changes
      notifyListeners();
      
    } catch (e) {
      setError(e.toString());
    } finally {
      setLoading(false);
    }
  }
  
  Future<void> deleteProfile(String profileId) async {
    try {
      setLoading(true);
      await _firestoreService.deleteProfile(profileId);
      
      // Update local state immediately
      _profiles.removeWhere((p) => p.id == profileId);
      
      // If deleted profile was selected, select another one
      if (_selectedProfile?.id == profileId) {
        _selectedProfile = _profiles.isNotEmpty ? _profiles.first : null;
      }
      
      // Notify listeners of the changes
      notifyListeners();
      
    } catch (e) {
      setError(e.toString());
    } finally {
      setLoading(false);
    }
  }
  
  void selectProfile(ProfileModel profile) {
    _selectedProfile = profile;
    _loadTasks(); // Reload tasks for new profile
    notifyListeners();
  }
  
  // Task operations
  Future<void> createTask({
    required String title,
    String description = '',
    TaskStage stage = TaskStage.todo,
    TaskPriority priority = TaskPriority.medium,
    DateTime? dueDate,
    List<String> tags = const [],
  }) async {
    if (_selectedProfile == null) {
      setError('No profile selected');
      return;
    }
    
    try {
      final task = TaskModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        description: description,
        stage: stage.value,
        priority: priority.value,
        dueDate: dueDate,
        profileId: _selectedProfile!.id,
        tags: tags,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      
      await _firestoreService.createTask(task);
      
    } catch (e) {
      setError(e.toString());
    }
  }
  
  Future<void> updateTask(TaskModel task) async {
    try {
      final updatedTask = task.copyWith(updatedAt: DateTime.now());
      await _firestoreService.updateTask(updatedTask);
    } catch (e) {
      setError(e.toString());
    }
  }
  
  Future<void> deleteTask(String taskId) async {
    try {
      await _firestoreService.deleteTask(taskId);
    } catch (e) {
      setError(e.toString());
    }
  }
  
  Future<void> toggleTaskComplete(TaskModel task) async {
    final updatedTask = task.copyWith(
      completed: !task.completed,
      stage: !task.completed ? TaskStage.complete.value : TaskStage.todo.value,
    );
    await updateTask(updatedTask);
  }
  
  Future<void> moveTaskToStage(TaskModel task, TaskStage newStage) async {
    final updatedTask = task.copyWith(
      stage: newStage.value,
      completed: newStage == TaskStage.complete,
    );
    await updateTask(updatedTask);
  }
  
  // Filter operations
  void updateFilter(TaskFilter filter) {
    _currentFilter = filter;
    _loadTasks();
    notifyListeners();
  }
  
  void clearFilter() {
    _currentFilter = TaskFilter();
    _loadTasks();
    notifyListeners();
  }
  
  // Settings operations
  Future<void> updateSettings(UserSettingsModel settings) async {
    try {
      await _firestoreService.saveSettings(settings);
    } catch (e) {
      setError(e.toString());
    }
  }
  
  // Quick stats
  int get totalTasks => _tasks.where((t) => !t.isDeleted).length;
  int get completedTasks => _tasks.where((t) => !t.isDeleted && t.completed).length;
  int get pendingTasks => _tasks.where((t) => !t.isDeleted && !t.completed).length;
  int get overdueTasks => _tasks.where((t) => 
      !t.isDeleted &&
      !t.completed && 
      t.dueDate != null && 
      t.dueDate!.isBefore(DateTime.now())
  ).length;
  
  Map<String, int> get tasksByStage {
    final Map<String, int> counts = {};
    for (final task in _tasks.where((t) => !t.isDeleted)) {
      counts[task.stage] = (counts[task.stage] ?? 0) + 1;
    }
    return counts;
  }
  
  Map<String, int> get tasksByPriority {
    final Map<String, int> counts = {};
    for (final task in _tasks.where((t) => !t.isDeleted)) {
      counts[task.priority] = (counts[task.priority] ?? 0) + 1;
    }
    return counts;
  }
}