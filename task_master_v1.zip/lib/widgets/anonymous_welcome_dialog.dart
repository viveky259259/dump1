import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AnonymousWelcomeDialog extends StatefulWidget {
  const AnonymousWelcomeDialog({super.key});

  @override
  State<AnonymousWelcomeDialog> createState() => _AnonymousWelcomeDialogState();
}

class _AnonymousWelcomeDialogState extends State<AnonymousWelcomeDialog>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  int _currentStep = 0;
  
  final List<WelcomeStep> _steps = [
    WelcomeStep(
      icon: Icons.waving_hand,
      title: 'Welcome to TaskFlow Pro!',
      description: 'You\'re using Guest Mode - a quick way to try out the app without creating an account.',
      color: Colors.blue,
    ),
    WelcomeStep(
      icon: Icons.task_alt,
      title: 'Organize Your Tasks',
      description: 'Create tasks, set priorities, add due dates, and organize them into different stages.',
      color: Colors.green,
    ),
    WelcomeStep(
      icon: Icons.person_add,
      title: 'Create Multiple Profiles',
      description: 'Separate your work, personal, and other tasks with different profiles.',
      color: Colors.purple,
    ),
    WelcomeStep(
      icon: Icons.security,
      title: 'Keep Your Data Safe',
      description: 'Upgrade to a permanent account anytime to ensure your tasks are never lost.',
      color: Colors.orange,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  
  static Future<void> showIfNeeded(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final hasSeenWelcome = prefs.getBool('anonymous_welcome_shown') ?? false;
    
    if (!hasSeenWelcome && context.mounted) {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const AnonymousWelcomeDialog(),
      );
      
      await prefs.setBool('anonymous_welcome_shown', true);
    }
  }
  
  void _nextStep() {
    if (_currentStep < _steps.length - 1) {
      setState(() => _currentStep++);
      _animationController.reset();
      _animationController.forward();
    } else {
      Navigator.of(context).pop();
    }
  }
  
  void _skip() {
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final currentStepData = _steps[_currentStep];
    
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      elevation: 16,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 400, maxHeight: 500),
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) => FadeTransition(
            opacity: _fadeAnimation,
            child: ScaleTransition(
              scale: _scaleAnimation,
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Skip button
                    Align(
                      alignment: Alignment.topRight,
                      child: TextButton(
                        onPressed: _skip,
                        child: Text(
                          'Skip',
                          style: TextStyle(
                            color: colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                      ),
                    ),
                    
                    // Icon
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: currentStepData.color.withOpacity(0.1),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: currentStepData.color.withOpacity(0.3),
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        currentStepData.icon,
                        size: 40,
                        color: currentStepData.color,
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Title
                    Text(
                      currentStepData.title,
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Description
                    Text(
                      currentStepData.description,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withOpacity(0.8),
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // Progress indicators
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _steps.length,
                        (index) => AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          width: index == _currentStep ? 24 : 8,
                          height: 8,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          decoration: BoxDecoration(
                            color: index == _currentStep
                                ? currentStepData.color
                                : colorScheme.outline.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Action button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _nextStep,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: currentStepData.color,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 2,
                        ),
                        child: Text(
                          _currentStep == _steps.length - 1 ? 'Get Started' : 'Next',
                          style: theme.textTheme.labelLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class WelcomeStep {
  final IconData icon;
  final String title;
  final String description;
  final Color color;

  WelcomeStep({
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
  });
}