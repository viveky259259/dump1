import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../data_schema.dart';
import '../providers/app_state_provider.dart';

class FilterPanel extends StatefulWidget {
  const FilterPanel({super.key});

  @override
  State<FilterPanel> createState() => _FilterPanelState();
}

class _FilterPanelState extends State<FilterPanel>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;
  bool _isExpanded = false;

  final TextEditingController _searchController = TextEditingController();
  TaskStage? _selectedStage;
  TaskPriority? _selectedPriority;
  bool? _completionFilter;
  DateTime? _startDate;
  DateTime? _endDate;
  String _selectedDateRange = 'all';

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );

    // Initialize search controller with current filter
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final appState = Provider.of<AppStateProvider>(context, listen: false);
      _searchController.text = appState.currentFilter.searchQuery;
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _toggleExpanded() {
    setState(() {
      _isExpanded = !_isExpanded;
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  void _applyFilters() {
    final appState = Provider.of<AppStateProvider>(context, listen: false);
    
    final filter = TaskFilter(
      searchQuery: _searchController.text,
      stage: _selectedStage,
      priority: _selectedPriority,
      completed: _completionFilter,
      startDate: _startDate,
      endDate: _endDate,
    );
    
    appState.updateFilter(filter);
  }

  void _clearFilters() {
    setState(() {
      _searchController.clear();
      _selectedStage = null;
      _selectedPriority = null;
      _completionFilter = null;
      _startDate = null;
      _endDate = null;
      _selectedDateRange = 'all';
    });
    
    final appState = Provider.of<AppStateProvider>(context, listen: false);
    appState.clearFilter();
  }

  void _setDateRange(String range) {
    setState(() {
      _selectedDateRange = range;
      final now = DateTime.now();
      
      switch (range) {
        case 'today':
          _startDate = DateTime(now.year, now.month, now.day);
          _endDate = DateTime(now.year, now.month, now.day, 23, 59, 59);
          break;
        case 'this_week':
          final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
          _startDate = DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day);
          _endDate = DateTime(now.year, now.month, now.day, 23, 59, 59);
          break;
        case 'this_month':
          _startDate = DateTime(now.year, now.month, 1);
          _endDate = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
          break;
        case 'overdue':
          _startDate = null;
          _endDate = DateTime(now.year, now.month, now.day);
          _completionFilter = false;
          break;
        default:
          _startDate = null;
          _endDate = null;
      }
    });
    _applyFilters();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Consumer<AppStateProvider>(
      builder: (context, appState, child) {
        final hasActiveFilters = appState.currentFilter.hasActiveFilters;

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorScheme.outline.withOpacity(0.2)),
            boxShadow: [
              BoxShadow(
                color: colorScheme.shadow.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              // Header with search bar
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Search bar
                    TextField(
                      controller: _searchController,
                      decoration: InputDecoration(
                        hintText: 'Search tasks...',
                        prefixIcon: Icon(Icons.search, color: colorScheme.primary),
                        suffixIcon: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_searchController.text.isNotEmpty)
                              IconButton(
                                onPressed: () {
                                  _searchController.clear();
                                  _applyFilters();
                                },
                                icon: Icon(Icons.clear, color: colorScheme.onSurface.withOpacity(0.6)),
                              ),
                            IconButton(
                              onPressed: _toggleExpanded,
                              icon: AnimatedRotation(
                                turns: _isExpanded ? 0.5 : 0,
                                duration: const Duration(milliseconds: 300),
                                child: Badge(
                                  isLabelVisible: hasActiveFilters,
                                  backgroundColor: colorScheme.error,
                                  child: Icon(
                                    Icons.tune,
                                    color: hasActiveFilters ? colorScheme.primary : colorScheme.onSurface.withOpacity(0.6),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: colorScheme.outline.withOpacity(0.3)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: colorScheme.primary, width: 2),
                        ),
                      ),
                      onChanged: (_) => _applyFilters(),
                    ),
                    
                    // Quick filter chips
                    const SizedBox(height: 12),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildQuickFilterChip('All', 'all', theme, colorScheme),
                          const SizedBox(width: 8),
                          _buildQuickFilterChip('Today', 'today', theme, colorScheme),
                          const SizedBox(width: 8),
                          _buildQuickFilterChip('This Week', 'this_week', theme, colorScheme),
                          const SizedBox(width: 8),
                          _buildQuickFilterChip('This Month', 'this_month', theme, colorScheme),
                          const SizedBox(width: 8),
                          _buildQuickFilterChip('Overdue', 'overdue', theme, colorScheme),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              // Expanded filters
              SizeTransition(
                sizeFactor: _expandAnimation,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Divider(color: colorScheme.outline.withOpacity(0.2)),
                      const SizedBox(height: 16),
                      
                      // Filter by stage
                      Text(
                        'Stage',
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          _buildStageChip(null, 'All Stages', theme, colorScheme),
                          ...TaskStage.values.map((stage) =>
                              _buildStageChip(stage, stage.displayName, theme, colorScheme)),
                        ],
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Filter by priority
                      Text(
                        'Priority',
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          _buildPriorityChip(null, 'All Priorities', theme, colorScheme),
                          ...TaskPriority.values.map((priority) =>
                              _buildPriorityChip(priority, priority.displayName, theme, colorScheme)),
                        ],
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Filter by completion
                      Text(
                        'Status',
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          _buildCompletionChip(null, 'All Tasks', theme, colorScheme),
                          _buildCompletionChip(false, 'Pending', theme, colorScheme),
                          _buildCompletionChip(true, 'Completed', theme, colorScheme),
                        ],
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Custom date range
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                final date = await showDatePicker(
                                  context: context,
                                  initialDate: _startDate ?? DateTime.now(),
                                  firstDate: DateTime(2020),
                                  lastDate: DateTime(2030),
                                );
                                if (date != null) {
                                  setState(() {
                                    _startDate = date;
                                    _selectedDateRange = 'custom';
                                  });
                                  _applyFilters();
                                }
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  border: Border.all(color: colorScheme.outline.withOpacity(0.3)),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.calendar_today,
                                      size: 16,
                                      color: colorScheme.primary,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      _startDate != null
                                          ? DateFormat('MMM dd').format(_startDate!)
                                          : 'Start Date',
                                      style: theme.textTheme.bodySmall?.copyWith(
                                        color: _startDate != null
                                            ? colorScheme.onSurface
                                            : colorScheme.onSurface.withOpacity(0.6),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          
                          const SizedBox(width: 8),
                          Text('to', style: theme.textTheme.bodySmall),
                          const SizedBox(width: 8),
                          
                          Expanded(
                            child: InkWell(
                              onTap: () async {
                                final date = await showDatePicker(
                                  context: context,
                                  initialDate: _endDate ?? DateTime.now(),
                                  firstDate: DateTime(2020),
                                  lastDate: DateTime(2030),
                                );
                                if (date != null) {
                                  setState(() {
                                    _endDate = date;
                                    _selectedDateRange = 'custom';
                                  });
                                  _applyFilters();
                                }
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  border: Border.all(color: colorScheme.outline.withOpacity(0.3)),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.calendar_today,
                                      size: 16,
                                      color: colorScheme.primary,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      _endDate != null
                                          ? DateFormat('MMM dd').format(_endDate!)
                                          : 'End Date',
                                      style: theme.textTheme.bodySmall?.copyWith(
                                        color: _endDate != null
                                            ? colorScheme.onSurface
                                            : colorScheme.onSurface.withOpacity(0.6),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Clear filters button
                      if (hasActiveFilters)
                        Center(
                          child: TextButton.icon(
                            onPressed: _clearFilters,
                            icon: Icon(Icons.clear_all, color: colorScheme.error),
                            label: Text(
                              'Clear All Filters',
                              style: TextStyle(color: colorScheme.error),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildQuickFilterChip(String label, String value, ThemeData theme, ColorScheme colorScheme) {
    final isSelected = _selectedDateRange == value;
    
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => _setDateRange(value),
      backgroundColor: colorScheme.surface,
      selectedColor: colorScheme.primary.withOpacity(0.2),
      checkmarkColor: colorScheme.primary,
      labelStyle: TextStyle(
        color: isSelected ? colorScheme.primary : colorScheme.onSurface,
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: isSelected ? colorScheme.primary : colorScheme.outline.withOpacity(0.3),
        ),
      ),
    );
  }

  Widget _buildStageChip(TaskStage? stage, String label, ThemeData theme, ColorScheme colorScheme) {
    final isSelected = _selectedStage == stage;
    
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) {
        setState(() => _selectedStage = isSelected ? null : stage);
        _applyFilters();
      },
      backgroundColor: colorScheme.surface,
      selectedColor: colorScheme.primary.withOpacity(0.2),
      checkmarkColor: colorScheme.primary,
      labelStyle: TextStyle(
        color: isSelected ? colorScheme.primary : colorScheme.onSurface,
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: isSelected ? colorScheme.primary : colorScheme.outline.withOpacity(0.3),
        ),
      ),
    );
  }

  Widget _buildPriorityChip(TaskPriority? priority, String label, ThemeData theme, ColorScheme colorScheme) {
    final isSelected = _selectedPriority == priority;
    
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) {
        setState(() => _selectedPriority = isSelected ? null : priority);
        _applyFilters();
      },
      backgroundColor: colorScheme.surface,
      selectedColor: colorScheme.primary.withOpacity(0.2),
      checkmarkColor: colorScheme.primary,
      labelStyle: TextStyle(
        color: isSelected ? colorScheme.primary : colorScheme.onSurface,
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: isSelected ? colorScheme.primary : colorScheme.outline.withOpacity(0.3),
        ),
      ),
    );
  }

  Widget _buildCompletionChip(bool? completed, String label, ThemeData theme, ColorScheme colorScheme) {
    final isSelected = _completionFilter == completed;
    
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) {
        setState(() => _completionFilter = isSelected ? null : completed);
        _applyFilters();
      },
      backgroundColor: colorScheme.surface,
      selectedColor: colorScheme.primary.withOpacity(0.2),
      checkmarkColor: colorScheme.primary,
      labelStyle: TextStyle(
        color: isSelected ? colorScheme.primary : colorScheme.onSurface,
        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: isSelected ? colorScheme.primary : colorScheme.outline.withOpacity(0.3),
        ),
      ),
    );
  }
}