import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../data_schema.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  String? get _userId => _auth.currentUser?.uid;
  
  // Get user document reference
  DocumentReference? get _userDoc => _userId != null 
      ? _firestore.collection('users').doc(_userId)
      : null;
  
  // Profile operations
  Future<void> createProfile(ProfileModel profile) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('profiles')
        .doc(profile.id)
        .set(profile.toJson());
  }
  
  Future<void> updateProfile(ProfileModel profile) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('profiles')
        .doc(profile.id)
        .update(profile.toJson());
  }
  
  Future<void> deleteProfile(String profileId) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    final now = DateTime.now();
    
    // Soft delete all tasks associated with this profile
    final tasksQuery = await _userDoc!
        .collection('tasks')
        .where('profileId', isEqualTo: profileId)
        .where('isDeleted', isEqualTo: false)
        .get();
    
    final batch = _firestore.batch();
    
    for (final doc in tasksQuery.docs) {
      batch.update(doc.reference, {
        'isDeleted': true,
        'deletedAt': Timestamp.fromDate(now),
        'updatedAt': Timestamp.fromDate(now),
      });
    }
    
    // Soft delete the profile
    batch.update(_userDoc!.collection('profiles').doc(profileId), {
      'isDeleted': true,
      'deletedAt': Timestamp.fromDate(now),
    });
    
    await batch.commit();
  }
  
  Stream<List<ProfileModel>> getProfiles() {
    if (_userDoc == null) return Stream.value([]);
    
    return _userDoc!
        .collection('profiles')
        .where('isDeleted', isEqualTo: false)
        .orderBy('createdAt', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ProfileModel.fromJson(doc.data(), doc.id))
            .toList());
  }
  
  // Task operations
  Future<void> createTask(TaskModel task) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('tasks')
        .doc(task.id)
        .set(task.toJson());
  }
  
  Future<void> updateTask(TaskModel task) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('tasks')
        .doc(task.id)
        .update(task.toJson());
  }
  
  Future<void> deleteTask(String taskId) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    final now = DateTime.now();
    await _userDoc!
        .collection('tasks')
        .doc(taskId)
        .update({
          'isDeleted': true,
          'deletedAt': Timestamp.fromDate(now),
          'updatedAt': Timestamp.fromDate(now),
        });
  }
  
  Stream<List<TaskModel>> getTasks({TaskFilter? filter}) {
    if (_userDoc == null) return Stream.value([]);
    
    Query query = _userDoc!.collection('tasks');
    
    // Always filter out soft-deleted tasks
    query = query.where('isDeleted', isEqualTo: false);
    
    // Apply filters
    if (filter != null) {
      if (filter.profileId != null) {
        query = query.where('profileId', isEqualTo: filter.profileId);
      }
      
      if (filter.stage != null) {
        query = query.where('stage', isEqualTo: filter.stage!.value);
      }
      
      if (filter.priority != null) {
        query = query.where('priority', isEqualTo: filter.priority!.value);
      }
      
      if (filter.completed != null) {
        query = query.where('completed', isEqualTo: filter.completed);
      }
      
      if (filter.startDate != null) {
        query = query.where('dueDate', 
            isGreaterThanOrEqualTo: Timestamp.fromDate(filter.startDate!));
      }
      
      if (filter.endDate != null) {
        query = query.where('dueDate', 
            isLessThanOrEqualTo: Timestamp.fromDate(filter.endDate!));
      }
      
      if (filter.tags.isNotEmpty) {
        query = query.where('tags', arrayContainsAny: filter.tags);
      }
    }
    
    return query
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
          List<TaskModel> tasks = snapshot.docs
              .map((doc) => TaskModel.fromJson(doc.data() as Map<String, dynamic>, doc.id))
              .toList();
          
          // Apply search filter (client-side)
          if (filter?.searchQuery.isNotEmpty == true) {
            final searchQuery = filter!.searchQuery.toLowerCase();
            tasks = tasks.where((task) =>
                task.title.toLowerCase().contains(searchQuery) ||
                task.description.toLowerCase().contains(searchQuery) ||
                task.tags.any((tag) => tag.toLowerCase().contains(searchQuery))
            ).toList();
          }
          
          return tasks;
        });
  }
  
  // Get tasks by profile
  Stream<List<TaskModel>> getTasksByProfile(String profileId) {
    if (_userDoc == null) return Stream.value([]);
    
    return _userDoc!
        .collection('tasks')
        .where('profileId', isEqualTo: profileId)
        .where('isDeleted', isEqualTo: false)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TaskModel.fromJson(doc.data(), doc.id))
            .toList());
  }
  
  // Get overdue tasks
  Stream<List<TaskModel>> getOverdueTasks() {
    if (_userDoc == null) return Stream.value([]);
    
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    
    return _userDoc!
        .collection('tasks')
        .where('isDeleted', isEqualTo: false)
        .where('completed', isEqualTo: false)
        .where('dueDate', isLessThan: Timestamp.fromDate(today))
        .orderBy('dueDate', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TaskModel.fromJson(doc.data(), doc.id))
            .toList());
  }
  
  // Get today's tasks
  Stream<List<TaskModel>> getTodaysTasks() {
    if (_userDoc == null) return Stream.value([]);
    
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59);
    
    return _userDoc!
        .collection('tasks')
        .where('isDeleted', isEqualTo: false)
        .where('dueDate', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('dueDate', isLessThanOrEqualTo: Timestamp.fromDate(endOfDay))
        .orderBy('dueDate', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TaskModel.fromJson(doc.data(), doc.id))
            .toList());
  }
  
  // Settings operations
  Future<void> saveSettings(UserSettingsModel settings) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('settings')
        .doc('preferences')
        .set(settings.toJson(), SetOptions(merge: true));
  }
  
  Future<UserSettingsModel?> getSettings() async {
    if (_userDoc == null) return null;
    
    final doc = await _userDoc!
        .collection('settings')
        .doc('preferences')
        .get();
    
    if (doc.exists) {
      return UserSettingsModel.fromJson(doc.data()!);
    }
    return null;
  }
  
  Stream<UserSettingsModel?> getSettingsStream() {
    if (_userDoc == null) return Stream.value(null);
    
    return _userDoc!
        .collection('settings')
        .doc('preferences')
        .snapshots()
        .map((snapshot) => snapshot.exists 
            ? UserSettingsModel.fromJson(snapshot.data()!)
            : null);
  }
  
  // Batch operations
  Future<void> batchUpdateTasks(List<TaskModel> tasks) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    final batch = _firestore.batch();
    
    for (final task in tasks) {
      final taskRef = _userDoc!.collection('tasks').doc(task.id);
      batch.update(taskRef, task.toJson());
    }
    
    await batch.commit();
  }
  
  // Analytics helper methods
  Future<Map<String, int>> getTaskCountByStage(String profileId) async {
    if (_userDoc == null) return {};
    
    final tasks = await _userDoc!
        .collection('tasks')
        .where('profileId', isEqualTo: profileId)
        .where('isDeleted', isEqualTo: false)
        .get();
    
    final Map<String, int> counts = {};
    
    for (final doc in tasks.docs) {
      final task = TaskModel.fromJson(doc.data(), doc.id);
      counts[task.stage] = (counts[task.stage] ?? 0) + 1;
    }
    
    return counts;
  }
  
  Future<int> getCompletedTasksCount(String profileId, DateTime startDate, DateTime endDate) async {
    if (_userDoc == null) return 0;
    
    final tasks = await _userDoc!
        .collection('tasks')
        .where('profileId', isEqualTo: profileId)
        .where('isDeleted', isEqualTo: false)
        .where('completed', isEqualTo: true)
        .where('updatedAt', isGreaterThanOrEqualTo: Timestamp.fromDate(startDate))
        .where('updatedAt', isLessThanOrEqualTo: Timestamp.fromDate(endDate))
        .get();
    
    return tasks.docs.length;
  }
  
  // Soft delete recovery methods
  Future<void> restoreTask(String taskId) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    final now = DateTime.now();
    await _userDoc!
        .collection('tasks')
        .doc(taskId)
        .update({
          'isDeleted': false,
          'deletedAt': null,
          'updatedAt': Timestamp.fromDate(now),
        });
  }
  
  Future<void> restoreProfile(String profileId) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('profiles')
        .doc(profileId)
        .update({
          'isDeleted': false,
          'deletedAt': null,
        });
  }
  
  // Get soft-deleted items (for admin/recovery purposes)
  Stream<List<TaskModel>> getDeletedTasks() {
    if (_userDoc == null) return Stream.value([]);
    
    return _userDoc!
        .collection('tasks')
        .where('isDeleted', isEqualTo: true)
        .orderBy('deletedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => TaskModel.fromJson(doc.data(), doc.id))
            .toList());
  }
  
  Stream<List<ProfileModel>> getDeletedProfiles() {
    if (_userDoc == null) return Stream.value([]);
    
    return _userDoc!
        .collection('profiles')
        .where('isDeleted', isEqualTo: true)
        .orderBy('deletedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ProfileModel.fromJson(doc.data(), doc.id))
            .toList());
  }
  
  // Permanent delete (hard delete) - use with caution
  Future<void> permanentlyDeleteTask(String taskId) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    await _userDoc!
        .collection('tasks')
        .doc(taskId)
        .delete();
  }
  
  Future<void> permanentlyDeleteProfile(String profileId) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    // First permanently delete all tasks associated with this profile
    final tasksQuery = await _userDoc!
        .collection('tasks')
        .where('profileId', isEqualTo: profileId)
        .get();
    
    final batch = _firestore.batch();
    
    for (final doc in tasksQuery.docs) {
      batch.delete(doc.reference);
    }
    
    // Permanently delete the profile
    batch.delete(_userDoc!.collection('profiles').doc(profileId));
    
    await batch.commit();
  }
  
  // Cleanup old soft-deleted items (can be called periodically)
  Future<void> cleanupOldDeletedItems({int daysOld = 30}) async {
    if (_userDoc == null) throw Exception('User not authenticated');
    
    final cutoffDate = DateTime.now().subtract(Duration(days: daysOld));
    
    // Get old deleted tasks
    final oldDeletedTasks = await _userDoc!
        .collection('tasks')
        .where('isDeleted', isEqualTo: true)
        .where('deletedAt', isLessThan: Timestamp.fromDate(cutoffDate))
        .get();
    
    // Get old deleted profiles
    final oldDeletedProfiles = await _userDoc!
        .collection('profiles')
        .where('isDeleted', isEqualTo: true)
        .where('deletedAt', isLessThan: Timestamp.fromDate(cutoffDate))
        .get();
    
    final batch = _firestore.batch();
    
    // Permanently delete old tasks
    for (final doc in oldDeletedTasks.docs) {
      batch.delete(doc.reference);
    }
    
    // Permanently delete old profiles
    for (final doc in oldDeletedProfiles.docs) {
      batch.delete(doc.reference);
    }
    
    await batch.commit();
  }
}