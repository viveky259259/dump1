import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    clientId: kIsWeb ? '199892233398-web_oauth_client_id.apps.googleusercontent.com' : null,
    scopes: ['email', 'profile'],
    serverClientId: kIsWeb ? null : '199892233398-server_oauth_client_id.apps.googleusercontent.com',
  );
  
  AuthService() {
    _initializeGoogleSignIn();
  }
  
  User? get currentUser => _auth.currentUser;
  bool get isAuthenticated => currentUser != null;
  bool get isAnonymous => currentUser?.isAnonymous ?? false;
  
  Stream<User?> get authStateChanges => _auth.authStateChanges();
  
  // Initialize Google Sign-In for web
  Future<void> _initializeGoogleSignIn() async {
    try {
      if (kIsWeb) {
        debugPrint('Initializing Google Sign-In for web...');
        await _googleSignIn.signInSilently();
      }
    } catch (e) {
      debugPrint('Google Sign-In initialization error: $e');
      // Non-fatal error, continue with app initialization
    }
  }
  
  // Sign in with email and password
  Future<UserCredential?> signInWithEmailAndPassword(String email, String password) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      notifyListeners();
      return credential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  // Register with email and password
  Future<UserCredential?> registerWithEmailAndPassword(String email, String password) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      notifyListeners();
      return credential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  // Sign in anonymously
  Future<UserCredential?> signInAnonymously() async {
    try {
      final credential = await _auth.signInAnonymously();
      notifyListeners();
      return credential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  // Sign in with Google
  Future<UserCredential?> signInWithGoogle() async {
    try {
      debugPrint('Starting Google Sign-In process...');
      
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      
      if (googleUser == null) {
        debugPrint('Google Sign-In: User canceled the sign-in');
        return null;
      }
      
      debugPrint('Google Sign-In: User selected, getting auth details...');
      
      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      
      if (googleAuth.accessToken == null || googleAuth.idToken == null) {
        throw Exception('Failed to obtain Google authentication tokens');
      }
      
      debugPrint('Google Sign-In: Auth tokens obtained, creating credential...');
      
      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      
      debugPrint('Google Sign-In: Signing in to Firebase...');
      
      // Sign in to Firebase with the Google credential
      final userCredential = await _auth.signInWithCredential(credential);
      
      debugPrint('Google Sign-In: Success! User: ${userCredential.user?.email}');
      
      notifyListeners();
      return userCredential;
    } on FirebaseAuthException catch (e) {
      debugPrint('Google Sign-In FirebaseAuth Error: ${e.code} - ${e.message}');
      throw _handleAuthError(e);
    } catch (e) {
      debugPrint('Google Sign-In General Error: $e');
      throw Exception('Google sign-in failed: ${e.toString()}');
    }
  }
  
  // Sign out
  Future<void> signOut() async {
    try {
      await Future.wait([
        _auth.signOut(),
        _googleSignIn.signOut(),
      ]);
      notifyListeners();
    } catch (e) {
      throw Exception('Sign out failed: ${e.toString()}');
    }
  }
  
  // Reset password
  Future<void> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  // Update user profile
  Future<void> updateProfile({String? displayName, String? photoURL}) async {
    try {
      final user = currentUser;
      if (user != null) {
        await user.updateDisplayName(displayName);
        if (photoURL != null) {
          await user.updatePhotoURL(photoURL);
        }
        await user.reload();
        notifyListeners();
      }
    } catch (e) {
      throw Exception('Profile update failed: ${e.toString()}');
    }
  }
  
  // Handle authentication errors
  String _handleAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'No user found with this email address.';
      case 'wrong-password':
        return 'Wrong password provided.';
      case 'email-already-in-use':
        return 'An account already exists with this email address.';
      case 'weak-password':
        return 'The password provided is too weak.';
      case 'invalid-email':
        return 'The email address is not valid.';
      case 'user-disabled':
        return 'This user account has been disabled.';
      case 'too-many-requests':
        return 'Too many requests. Please try again later.';
      case 'operation-not-allowed':
        return 'Email/password accounts are not enabled.';
      case 'provider-already-linked':
        return 'This account is already linked to another provider.';
      case 'credential-already-in-use':
        return 'This credential is already associated with a different user account.';
      case 'account-exists-with-different-credential':
        return 'An account already exists with the same email address but different sign-in credentials. Try signing in with a different method.';
      case 'invalid-credential':
        return 'The credential is malformed or has expired. Please try again.';
      case 'popup-closed-by-user':
        return 'The sign-in popup was closed before completing the sign-in process.';
      case 'popup-blocked':
        return 'The sign-in popup was blocked by the browser. Please allow popups and try again.';
      case 'network-request-failed':
        return 'Network error occurred. Please check your internet connection and try again.';
      default:
        return 'Authentication failed: ${e.message ?? e.code}';
    }
  }
  
  // Check if email is verified
  bool get isEmailVerified => currentUser?.emailVerified ?? false;
  
  // Send email verification
  Future<void> sendEmailVerification() async {
    try {
      await currentUser?.sendEmailVerification();
    } catch (e) {
      throw Exception('Failed to send email verification: ${e.toString()}');
    }
  }
  
  // Link anonymous account with email/password
  Future<UserCredential?> linkWithEmailAndPassword(String email, String password) async {
    try {
      if (!isAnonymous) {
        throw Exception('User is not anonymous');
      }
      
      final credential = EmailAuthProvider.credential(email: email, password: password);
      final userCredential = await currentUser!.linkWithCredential(credential);
      notifyListeners();
      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  // Link anonymous account with Google
  Future<UserCredential?> linkWithGoogle() async {
    try {
      if (!isAnonymous) {
        throw Exception('User is not anonymous');
      }
      
      debugPrint('Starting Google Link process for anonymous user...');
      
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      
      if (googleUser == null) {
        debugPrint('Google Link: User canceled the sign-in');
        return null;
      }
      
      debugPrint('Google Link: User selected, getting auth details...');
      
      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      
      if (googleAuth.accessToken == null || googleAuth.idToken == null) {
        throw Exception('Failed to obtain Google authentication tokens');
      }
      
      debugPrint('Google Link: Auth tokens obtained, creating credential...');
      
      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      
      debugPrint('Google Link: Linking credential with anonymous user...');
      
      // Link the credential with the current anonymous user
      final userCredential = await currentUser!.linkWithCredential(credential);
      
      debugPrint('Google Link: Success! User upgraded: ${userCredential.user?.email}');
      
      notifyListeners();
      return userCredential;
    } on FirebaseAuthException catch (e) {
      debugPrint('Google Link FirebaseAuth Error: ${e.code} - ${e.message}');
      throw _handleAuthError(e);
    } catch (e) {
      debugPrint('Google Link General Error: $e');
      throw Exception('Google linking failed: ${e.toString()}');
    }
  }
  
  // Convert anonymous user to permanent account
  Future<void> upgradeAnonymousAccount(String email, String password) async {
    try {
      if (!isAnonymous) {
        throw Exception('User is not anonymous');
      }
      
      await linkWithEmailAndPassword(email, password);
      
      // Update the display name if not set
      if (currentUser?.displayName == null || currentUser!.displayName!.isEmpty) {
        await updateProfile(displayName: email.split('@')[0]);
      }
    } catch (e) {
      throw Exception('Account upgrade failed: ${e.toString()}');
    }
  }
  
  // Delete user account
  Future<void> deleteAccount() async {
    try {
      await currentUser?.delete();
      notifyListeners();
    } catch (e) {
      throw Exception('Failed to delete account: ${e.toString()}');
    }
  }
}