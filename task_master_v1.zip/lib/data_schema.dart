import 'package:cloud_firestore/cloud_firestore.dart';

// Task Model
class TaskModel {
  final String id;
  final String title;
  final String description;
  final String stage;
  final String priority;
  final DateTime? dueDate;
  final String profileId;
  final List<String> tags;
  final bool completed;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isDeleted;
  final DateTime? deletedAt;

  TaskModel({
    required this.id,
    required this.title,
    this.description = '',
    required this.stage,
    required this.priority,
    this.dueDate,
    required this.profileId,
    this.tags = const [],
    this.completed = false,
    required this.createdAt,
    required this.updatedAt,
    this.isDeleted = false,
    this.deletedAt,
  });

  factory TaskModel.fromJson(Map<String, dynamic> json, String id) {
    return TaskModel(
      id: id,
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      stage: json['stage'] ?? 'todo',
      priority: json['priority'] ?? 'medium',
      dueDate: json['dueDate'] != null 
          ? (json['dueDate'] as Timestamp).toDate() 
          : null,
      profileId: json['profileId'] ?? '',
      tags: List<String>.from(json['tags'] ?? []),
      completed: json['completed'] ?? false,
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      updatedAt: (json['updatedAt'] as Timestamp).toDate(),
      isDeleted: json['isDeleted'] ?? false,
      deletedAt: json['deletedAt'] != null 
          ? (json['deletedAt'] as Timestamp).toDate() 
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'stage': stage,
      'priority': priority,
      'dueDate': dueDate != null ? Timestamp.fromDate(dueDate!) : null,
      'profileId': profileId,
      'tags': tags,
      'completed': completed,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'isDeleted': isDeleted,
      'deletedAt': deletedAt != null ? Timestamp.fromDate(deletedAt!) : null,
    };
  }

  TaskModel copyWith({
    String? title,
    String? description,
    String? stage,
    String? priority,
    DateTime? dueDate,
    String? profileId,
    List<String>? tags,
    bool? completed,
    DateTime? updatedAt,
    bool? isDeleted,
    DateTime? deletedAt,
  }) {
    return TaskModel(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      stage: stage ?? this.stage,
      priority: priority ?? this.priority,
      dueDate: dueDate ?? this.dueDate,
      profileId: profileId ?? this.profileId,
      tags: tags ?? this.tags,
      completed: completed ?? this.completed,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
      isDeleted: isDeleted ?? this.isDeleted,
      deletedAt: deletedAt ?? this.deletedAt,
    );
  }
}

// Profile Model
class ProfileModel {
  final String id;
  final String name;
  final String colorCode;
  final DateTime createdAt;
  final bool isDefault;
  final bool isDeleted;
  final DateTime? deletedAt;

  ProfileModel({
    required this.id,
    required this.name,
    required this.colorCode,
    required this.createdAt,
    this.isDefault = false,
    this.isDeleted = false,
    this.deletedAt,
  });

  factory ProfileModel.fromJson(Map<String, dynamic> json, String id) {
    return ProfileModel(
      id: id,
      name: json['name'] ?? '',
      colorCode: json['colorCode'] ?? '#6F61EF',
      createdAt: (json['createdAt'] as Timestamp).toDate(),
      isDefault: json['isDefault'] ?? false,
      isDeleted: json['isDeleted'] ?? false,
      deletedAt: json['deletedAt'] != null 
          ? (json['deletedAt'] as Timestamp).toDate() 
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'colorCode': colorCode,
      'createdAt': Timestamp.fromDate(createdAt),
      'isDefault': isDefault,
      'isDeleted': isDeleted,
      'deletedAt': deletedAt != null ? Timestamp.fromDate(deletedAt!) : null,
    };
  }

  ProfileModel copyWith({
    String? name,
    String? colorCode,
    bool? isDefault,
    bool? isDeleted,
    DateTime? deletedAt,
  }) {
    return ProfileModel(
      id: id,
      name: name ?? this.name,
      colorCode: colorCode ?? this.colorCode,
      createdAt: createdAt,
      isDefault: isDefault ?? this.isDefault,
      isDeleted: isDeleted ?? this.isDeleted,
      deletedAt: deletedAt ?? this.deletedAt,
    );
  }
}

// User Settings Model
class UserSettingsModel {
  final String defaultProfileId;
  final bool notificationEnabled;
  final int reminderFrequency;

  UserSettingsModel({
    required this.defaultProfileId,
    this.notificationEnabled = true,
    this.reminderFrequency = 3,
  });

  factory UserSettingsModel.fromJson(Map<String, dynamic> json) {
    return UserSettingsModel(
      defaultProfileId: json['defaultProfileId'] ?? '',
      notificationEnabled: json['notificationEnabled'] ?? true,
      reminderFrequency: json['reminderFrequency'] ?? 3,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'defaultProfileId': defaultProfileId,
      'notificationEnabled': notificationEnabled,
      'reminderFrequency': reminderFrequency,
    };
  }
}

// Enums for type safety
enum TaskStage {
  todo('todo', 'To Do'),
  inProgress('in_progress', 'In Progress'),
  review('review', 'Review'),
  complete('complete', 'Complete');

  const TaskStage(this.value, this.displayName);
  final String value;
  final String displayName;

  static TaskStage fromString(String value) {
    return TaskStage.values.firstWhere(
      (stage) => stage.value == value,
      orElse: () => TaskStage.todo,
    );
  }
}

enum TaskPriority {
  high('high', 'High'),
  medium('medium', 'Medium'),
  low('low', 'Low');

  const TaskPriority(this.value, this.displayName);
  final String value;
  final String displayName;

  static TaskPriority fromString(String value) {
    return TaskPriority.values.firstWhere(
      (priority) => priority.value == value,
      orElse: () => TaskPriority.medium,
    );
  }
}

// Filter Model for advanced filtering
class TaskFilter {
  final String? profileId;
  final TaskStage? stage;
  final TaskPriority? priority;
  final DateTime? startDate;
  final DateTime? endDate;
  final List<String> tags;
  final bool? completed;
  final String searchQuery;

  TaskFilter({
    this.profileId,
    this.stage,
    this.priority,
    this.startDate,
    this.endDate,
    this.tags = const [],
    this.completed,
    this.searchQuery = '',
  });

  TaskFilter copyWith({
    String? profileId,
    TaskStage? stage,
    TaskPriority? priority,
    DateTime? startDate,
    DateTime? endDate,
    List<String>? tags,
    bool? completed,
    String? searchQuery,
  }) {
    return TaskFilter(
      profileId: profileId ?? this.profileId,
      stage: stage ?? this.stage,
      priority: priority ?? this.priority,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      tags: tags ?? this.tags,
      completed: completed ?? this.completed,
      searchQuery: searchQuery ?? this.searchQuery,
    );
  }

  bool get hasActiveFilters {
    return profileId != null ||
        stage != null ||
        priority != null ||
        startDate != null ||
        endDate != null ||
        tags.isNotEmpty ||
        completed != null ||
        searchQuery.isNotEmpty;
  }
}