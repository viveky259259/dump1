import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:security_plus/security_plus.dart';
import 'package:freerasp/freerasp.dart';

late TalsecConfig config;
void main() {
  print("Main: ${SecurityPlus.isDevelopmentModeEnable}");
// create a configuration for freeRASP
  config = TalsecConfig(
    /// For Android
    androidConfig: AndroidConfig(
      packageName: 'com.example.tamper_detection',
      signingCertHashes: [
        'OPISqOIijIKomJTqsk+XuHCsyPMnmk/qlu5HN0W2P8A='
      ], // Replace with your release (!) signing certificate hash(es)
    ),

    /// For iOS
    iosConfig: IOSConfig(
      bundleIds: ['YOUR_APP_BUNDLE_ID'],
      teamId: 'M8AK35...',
    ),
    watcherMail: 'tamperdetection@gmail.com',
    isProd: true,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    SecurityPlus.isDevelopmentModeEnable.then((value) {
      print("MyApp: $value");
    });
    return MaterialApp(
      title: 'Security Checks',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a blue toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Device Security Status'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool? _isRooted;
  bool? _isJailBroken;
  bool? _isEmulator;
  bool? _isOnExternalStorage;
  bool? _isDevelopmentModeEnabled;
  bool? _isMockLocationEnabled;
  String? _error;
  bool _loading = false;
  String status = "";
  @override
  void initState() {
    print("initState: ${SecurityPlus.isDevelopmentModeEnable}");
    super.initState();
    _refreshSecurityStatus();

    initTalSec();
  }

  void updateStatus(String status) {
    setState(() {
      this.status += status + "\n";
    });
  }

  void initTalSec() async {
    await Talsec.instance.start(config);
    // Setting up callbacks
    final callback = ThreatCallback(
      onAppIntegrity: () => updateStatus("App integrity\n"),
      onObfuscationIssues: () => updateStatus("Obfuscation issues\n"),
      onDebug: () => updateStatus("Debugging\n"),
      onDeviceBinding: () => updateStatus("Device binding\n"),
      onDeviceID: () => updateStatus("Device ID\n"),
      onHooks: () => updateStatus("Hooks\n"),
      onPasscode: () => updateStatus("Passcode not set\n"),
      onPrivilegedAccess: () => updateStatus("Privileged access\n"),
      onSecureHardwareNotAvailable: () =>
          updateStatus("Secure hardware not available\n"),
      onSimulator: () => updateStatus("Simulator\n"),
      onSystemVPN: () => updateStatus("System VPN\n"),
      onDevMode: () => updateStatus("Developer mode\n"),
      onADBEnabled: () => updateStatus("USB debugging enabled\n"),
      onUnofficialStore: () => updateStatus("Unofficial store\n"),
      onScreenshot: () => updateStatus("Screenshot\n"),
      onScreenRecording: () => updateStatus("Screen recording\n"),
      onMultiInstance: () => updateStatus("Multi instance\n"),
      onMalware: (malware) => updateStatus("Malware: $malware\n"),
    );

    // Attaching listener
    Talsec.instance.attachListener(callback);
  }

  Future<void> _refreshSecurityStatus() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    print("Main: ${await SecurityPlus.isDevelopmentModeEnable}");
    try {
      final results = await Future.wait<bool?>([
        _safeCall(() => SecurityPlus.isRooted),
        _safeCall(() => SecurityPlus.isJailBroken),
        _safeCall(() => SecurityPlus.isEmulator),
        _safeCall(() => SecurityPlus.isOnExternalStorage),
        _safeCall(() => SecurityPlus.isDevelopmentModeEnable),
        _safeCall(() => SecurityPlus.isMockLocationEnabled),
      ]);

      setState(() {
        _isRooted = results[0];
        _isJailBroken = results[1];
        _isEmulator = results[2];
        _isOnExternalStorage = results[3];
        _isDevelopmentModeEnabled = results[4];
        _isMockLocationEnabled = results[5];
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  Future<T?> _safeCall<T>(Future<T> Function() fn) async {
    try {
      return await fn();
    } on PlatformException catch (e) {
      // Some checks may not be implemented on a platform or need permissions
      debugPrint('Security check PlatformException: ${e.code} ${e.message}');
      return null;
    } catch (e) {
      debugPrint('Security check error: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _refreshSecurityStatus,
            icon: _loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        children: [
          Text(status),
          if (_error != null)
            Card(
              color: Colors.red.withOpacity(0.1),
              child: ListTile(
                leading: const Icon(Icons.error, color: Colors.red),
                title: const Text('Error while running checks'),
                subtitle: Text(_error!),
              ),
            ),
          _buildStatusTile('Android: Rooted device', _isRooted),
          _buildStatusTile('iOS: Jailbroken device', _isJailBroken),
          _buildStatusTile('Emulator detected', _isEmulator),
          _buildStatusTile(
              'Installed on external storage', _isOnExternalStorage),
          _buildStatusTile('Developer mode enabled', _isDevelopmentModeEnabled),
          _buildStatusTile('Mock location enabled', _isMockLocationEnabled,
              hint: 'May require location permission on Android'),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _loading ? null : _refreshSecurityStatus,
            icon: const Icon(Icons.shield),
            label: const Text('Run Security Checks'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusTile(String label, bool? value, {String? hint}) {
    IconData icon;
    Color color;
    String text;

    if (value == null) {
      icon = Icons.help_outline;
      color = Colors.grey;
      text = 'Unavailable';
    } else if (value == true) {
      icon = Icons.warning_amber_rounded;
      color = Colors.orange;
      text = 'Detected';
    } else {
      icon = Icons.check_circle;
      color = Colors.green;
      text = 'Not detected';
    }

    return Card(
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(label),
        subtitle: hint != null ? Text(hint) : null,
        trailing: Text(
          text,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
