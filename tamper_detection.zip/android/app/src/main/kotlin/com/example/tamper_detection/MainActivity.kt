package com.example.tamper_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
