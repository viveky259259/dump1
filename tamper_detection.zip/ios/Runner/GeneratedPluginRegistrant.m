//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<freerasp/FreeraspPlugin.h>)
#import <freerasp/FreeraspPlugin.h>
#else
@import freerasp;
#endif

#if __has_include(<security_plus/SecurityPlusPlugin.h>)
#import <security_plus/SecurityPlusPlugin.h>
#else
@import security_plus;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FreeraspPlugin registerWithRegistrar:[registry registrarForPlugin:@"FreeraspPlugin"]];
  [SecurityPlusPlugin registerWithRegistrar:[registry registrarForPlugin:@"SecurityPlusPlugin"]];
}

@end
