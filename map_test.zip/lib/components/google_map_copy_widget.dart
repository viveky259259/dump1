import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'google_map_copy_model.dart';
export 'google_map_copy_model.dart';

class GoogleMapCopyWidget extends StatefulWidget {
  const GoogleMapCopyWidget({
    super.key,
    bool? loadMap,
  }) : this.loadMap = loadMap ?? false;

  final bool loadMap;

  @override
  State<GoogleMapCopyWidget> createState() => _GoogleMapCopyWidgetState();
}

class _GoogleMapCopyWidgetState extends State<GoogleMapCopyWidget> {
  late GoogleMapCopyModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GoogleMapCopyModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FlutterFlowGoogleMap(
      controller: _model.googleMapsController,
      onCameraIdle: (latLng) => _model.googleMapsCenter = latLng,
      initialLocation: _model.googleMapsCenter ??=
          LatLng(13.106061, -59.613158),
      markerColor: GoogleMarkerColor.violet,
      mapType: MapType.normal,
      style: GoogleMapStyle.standard,
      initialZoom: 14.0,
      allowInteraction: true,
      allowZoom: true,
      showZoomControls: true,
      showLocation: true,
      showCompass: false,
      showMapToolbar: false,
      showTraffic: false,
      centerMapOnMarkerTap: true,
    );
  }
}
