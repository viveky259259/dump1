import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';

String? getStaticImageUrl(
  LatLng? location,
  String? key,
) {
  if (location == null) {
    print('Null location');
    return '';
  }
  print(
      "https://maps.googleapis.com/maps/api/staticmap?center=${location.latitude},${location.longitude}&zoom=14&maptype=roadmap&size=200x200&maptype=roadmap&key=$key");
  return "https://maps.googleapis.com/maps/api/staticmap?center=${location.latitude},${location.longitude}&zoom=14&maptype=roadmap&size=200x200&maptype=roadmap&key=$key";
}
