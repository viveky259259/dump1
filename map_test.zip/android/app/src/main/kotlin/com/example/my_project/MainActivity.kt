package com.mycompany.maptest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
