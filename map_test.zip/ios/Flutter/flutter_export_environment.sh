#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/vivekyadav/Library/Application Support/io.flutterflow.prod.mac/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/vivekyadav/Documents/Projects/poc/maps/map_test"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/vivekyadav/Documents/Projects/poc/maps/map_test/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/vivekyadav/Documents/Projects/poc/maps/map_test/.dart_tool/package_config.json"
