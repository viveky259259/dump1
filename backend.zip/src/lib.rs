use std::collections::HashMap;
use std::convert::TryFrom;
use std::ffi::{c_char, CStr, CString};
use std::fs;
use std::path::Path;

use git2::build::CheckoutBuilder;
use git2::{Branch, BranchType, FileFavor, MergeOptions, Oid, Reference, Repository, Sort};
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

static VERSION: Lazy<String> = Lazy::new(|| env!("CARGO_PKG_VERSION").to_string());

const DEFAULT_COMMIT_LIMIT: u32 = 50;
const MAX_COMMIT_LIMIT: u32 = 500;

#[derive(Debug, Deserialize)]
struct CommandRequest {
    command: String,
    #[serde(default)]
    payload: Value,
}

#[derive(Debug, Serialize)]
struct CommandResponse {
    status: &'static str,
    #[serde(skip_serializing_if = "Option::is_none")]
    message: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    data: Option<Value>,
}

#[derive(Debug, Serialize)]
struct BranchResponse {
    repository: RepositoryMetadata,
    current_branch: Option<String>,
    branches: Vec<BranchInfo>,
}

#[derive(Debug, Serialize)]
struct RepositoryMetadata {
    requested_path: String,
    resolved_workdir: Option<String>,
}

#[derive(Debug, Serialize)]
struct BranchInfo {
    name: String,
    reference: String,
    #[serde(rename = "type")]
    kind: BranchKind,
    remote: Option<String>,
    upstream: Option<String>,
    is_head: bool,
    target: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    relation: Option<BranchRelation>,
    #[serde(skip_serializing_if = "Option::is_none")]
    latest_commit: Option<CommitSummary>,
}

#[derive(Debug, Serialize)]
struct BranchRelation {
    ahead: u32,
    behind: u32,
}

#[derive(Debug, Serialize)]
struct CommitSummary {
    id: String,
    message: Option<String>,
    author: Option<String>,
    time: i64,
    offset_minutes: i32,
}

#[derive(Debug, Serialize, Clone, Copy, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum BranchKind {
    Local,
    Remote,
}

#[derive(Default, Deserialize)]
struct ListBranchesRequest {
    #[serde(default)]
    repo_path: Option<String>,
}

#[derive(Default, Deserialize)]
struct ListCommitsRequest {
    #[serde(default)]
    repo_path: Option<String>,
    #[serde(default)]
    branch: Option<String>,
    #[serde(default)]
    author: Option<String>,
    #[serde(default)]
    message_query: Option<String>,
    #[serde(default)]
    skip: Option<u32>,
    #[serde(default)]
    limit: Option<u32>,
    #[serde(default)]
    after: Option<i64>,
    #[serde(default)]
    before: Option<i64>,
}

#[derive(Default, Deserialize)]
struct FileBlameRequest {
    #[serde(default)]
    repo_path: Option<String>,
    file_path: String,
    #[serde(default)]
    commit: Option<String>,
}

#[derive(Default, Deserialize)]
struct CreateBranchRequest {
    #[serde(default)]
    repo_path: Option<String>,
    branch_name: String,
    #[serde(default)]
    start_point: Option<String>,
    #[serde(default)]
    force: bool,
}

#[derive(Default, Deserialize)]
struct CheckoutBranchRequest {
    #[serde(default)]
    repo_path: Option<String>,
    branch: String,
    #[serde(default)]
    allow_dirty: bool,
}

#[derive(Debug, Deserialize)]
struct MergePreviewRequest {
    #[serde(default)]
    repo_path: Option<String>,
    source: String,
    #[serde(default)]
    target: Option<String>,
    #[serde(default)]
    strategy: Option<MergeStrategy>,
}

#[derive(Debug, Deserialize)]
struct PerformMergeRequest {
    #[serde(default)]
    repo_path: Option<String>,
    source: String,
    #[serde(default)]
    target: Option<String>,
    #[serde(default)]
    strategy: Option<MergeStrategy>,
    #[serde(default)]
    allow_dirty: bool,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum MergeStrategy {
    FastForward,
    ThreeWay,
    Squash,
}

impl Default for MergeStrategy {
    fn default() -> Self {
        MergeStrategy::ThreeWay
    }
}

#[derive(Debug, Serialize)]
struct CommitListResponse {
    repository: RepositoryMetadata,
    page: PageInfo,
    commits: Vec<CommitInfo>,
}

#[derive(Debug, Serialize)]
struct PageInfo {
    skip: u32,
    limit: u32,
    returned: u32,
    has_more: bool,
}

#[derive(Debug, Serialize)]
struct CommitInfo {
    id: String,
    summary: Option<String>,
    message: Option<String>,
    author: SignatureInfo,
    committer: SignatureInfo,
    parents: Vec<String>,
    refs: Vec<ReferenceInfo>,
}

#[derive(Debug, Serialize)]
struct MergePreviewResponse {
    repository: RepositoryMetadata,
    target: MergeEndpoint,
    source: MergeEndpoint,
    ahead: u32,
    behind: u32,
    status: MergeStatusSummary,
    conflicts: Vec<MergeConflictEntry>,
    warnings: Vec<String>,
}

#[derive(Debug, Serialize)]
struct MergeEndpoint {
    reference: Option<String>,
    shorthand: Option<String>,
    commit: CommitSummary,
}

#[derive(Debug, Serialize)]
struct MergeStatusSummary {
    strategy: MergeStrategy,
    fast_forward_possible: bool,
    up_to_date: bool,
    would_conflict: bool,
    merge_base: Option<String>,
}

#[derive(Debug, Serialize, Clone)]
struct MergeConflictEntry {
    path: String,
}

#[derive(Debug, Serialize)]
struct MergeOutcome {
    strategy: MergeStrategy,
    fast_forward_performed: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    merge_commit: Option<String>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    conflicts: Vec<MergeConflictEntry>,
    working_tree_dirty: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    message: Option<String>,
}

#[derive(Debug, Serialize)]
struct BlameResponse {
    repository: RepositoryMetadata,
    file_path: String,
    commit: Option<String>,
    hunks: Vec<BlameHunk>,
}

#[derive(Debug, Serialize)]
struct BlameHunk {
    start_line: usize,
    lines: Vec<BlameLine>,
    commit: BlameCommitInfo,
}

#[derive(Debug, Serialize)]
struct BlameLine {
    number: usize,
    text: String,
}

#[derive(Debug, Serialize)]
struct BlameCommitInfo {
    id: String,
    summary: Option<String>,
    author: SignatureInfo,
    committer: SignatureInfo,
}

#[derive(Debug, Serialize)]
struct SignatureInfo {
    name: Option<String>,
    email: Option<String>,
    time: i64,
    offset_minutes: i32,
}

#[derive(Debug, Serialize, Clone)]
struct ReferenceInfo {
    name: String,
    shorthand: Option<String>,
    #[serde(rename = "type")]
    kind: ReferenceKind,
}

#[derive(Debug, Serialize)]
struct OperationResponse {
    message: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    warnings: Option<Vec<String>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    data: Option<Value>,
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "snake_case")]
enum ReferenceKind {
    LocalBranch,
    RemoteBranch,
    Tag,
    Note,
    Other,
}

fn to_c_string<S: Into<String>>(value: S) -> *mut c_char {
    CString::new(value.into())
        .expect("CString conversion failed")
        .into_raw()
}

fn from_c_string(ptr: *const c_char) -> Result<String, CommandResponse> {
    if ptr.is_null() {
        return Err(error_response("Null pointer received"));
    }

    let c_str = unsafe { CStr::from_ptr(ptr) };
    c_str
        .to_str()
        .map(|s| s.to_owned())
        .map_err(|_| error_response("Invalid UTF-8 sequence in request"))
}

fn ok_response(data: Value) -> CommandResponse {
    CommandResponse {
        status: "ok",
        message: None,
        data: Some(data),
    }
}

fn error_response(message: impl Into<String>) -> CommandResponse {
    CommandResponse {
        status: "error",
        message: Some(message.into()),
        data: None,
    }
}

fn list_branches(payload: Value) -> CommandResponse {
    let params: ListBranchesRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    let resolved_workdir = repo
        .workdir()
        .and_then(|path| fs::canonicalize(path).ok())
        .or_else(|| {
            repo.path()
                .parent()
                .and_then(|path| fs::canonicalize(path).ok())
        })
        .map(|path| path.to_string_lossy().into_owned());

    let head_name = repo
        .head()
        .ok()
        .filter(|head| head.is_branch())
        .and_then(|head| head.shorthand().map(|s| s.to_string()));

    let mut branches = Vec::new();

    if let Err(err) = collect_branches(
        &repo,
        BranchType::Local,
        BranchKind::Local,
        head_name.as_deref(),
        &mut branches,
    ) {
        return error_response(err);
    }

    if let Err(err) = collect_branches(
        &repo,
        BranchType::Remote,
        BranchKind::Remote,
        head_name.as_deref(),
        &mut branches,
    ) {
        return error_response(err);
    }

    branches.sort_by(|a, b| {
        kind_rank(a.kind)
            .cmp(&kind_rank(b.kind))
            .then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))
    });

    let response = BranchResponse {
        repository: RepositoryMetadata {
            requested_path,
            resolved_workdir,
        },
        current_branch: head_name,
        branches,
    };

    match serde_json::to_value(response) {
        Ok(data) => ok_response(data),
        Err(err) => error_response(format!("Failed to encode branch response: {err}")),
    }
}

fn collect_branches(
    repo: &Repository,
    branch_type: BranchType,
    kind: BranchKind,
    head_name: Option<&str>,
    output: &mut Vec<BranchInfo>,
) -> Result<(), String> {
    let iter = repo
        .branches(Some(branch_type))
        .map_err(|err| format!("Failed to load {} branches: {err}", kind_label(kind)))?;

    for item in iter {
        let (branch, _) =
            item.map_err(|err| format!("Failed to iterate {} branches: {err}", kind_label(kind)))?;
        let info = build_branch_info(repo, branch, kind, head_name)?;
        output.push(info);
    }

    Ok(())
}

fn build_branch_info(
    repo: &Repository,
    branch: Branch<'_>,
    kind: BranchKind,
    head_name: Option<&str>,
) -> Result<BranchInfo, String> {
    let reference = branch.get();
    let (name, reference_name) = reference_names(reference);
    let target_id = reference.target();

    let latest_commit = target_id
        .and_then(|oid| repo.find_commit(oid).ok())
        .map(|commit| summarize_commit(&commit));

    let upstream = if matches!(kind, BranchKind::Local) {
        branch.upstream().ok()
    } else {
        None
    };

    let upstream_name = upstream
        .as_ref()
        .and_then(|b| b.name().ok().flatten().map(|s| s.to_string()));

    let remote = match kind {
        BranchKind::Local => upstream_name
            .as_ref()
            .and_then(|full| full.split_once('/').map(|(remote, _)| remote.to_string())),
        BranchKind::Remote => name.split_once('/').map(|(remote, _)| remote.to_string()),
    };

    let relation = if let (Some(local_oid), Some(upstream_branch)) = (target_id, upstream.as_ref())
    {
        if let Some(upstream_oid) = upstream_branch.get().target() {
            match repo.graph_ahead_behind(local_oid, upstream_oid) {
                Ok((ahead, behind)) if ahead > 0 || behind > 0 => Some(BranchRelation {
                    ahead: clamp_u32(ahead),
                    behind: clamp_u32(behind),
                }),
                Ok(_) => None,
                Err(err) => {
                    return Err(format!(
                        "Failed to compare branch {} with upstream: {err}",
                        name
                    ));
                }
            }
        } else {
            None
        }
    } else {
        None
    };

    let is_head =
        matches!(kind, BranchKind::Local) && head_name.map(|head| head == name).unwrap_or(false);

    Ok(BranchInfo {
        name,
        reference: reference_name,
        kind,
        remote,
        upstream: upstream_name,
        is_head,
        target: target_id.map(|oid| oid.to_string()),
        relation,
        latest_commit,
    })
}

fn summarize_commit(commit: &git2::Commit<'_>) -> CommitSummary {
    CommitSummary {
        id: commit.id().to_string(),
        message: commit.summary().map(|s| s.to_string()),
        author: commit.author().name().map(|s| s.to_string()),
        time: commit.time().seconds(),
        offset_minutes: commit.time().offset_minutes(),
    }
}

fn collect_conflicts(index: &git2::Index) -> Result<Vec<MergeConflictEntry>, git2::Error> {
    let mut conflicts = Vec::new();
    if !index.has_conflicts() {
        return Ok(conflicts);
    }

    let mut iter = index.conflicts()?;
    while let Some(conflict) = iter.next() {
        let conflict = conflict?;
        let path_entry = conflict
            .their
            .as_ref()
            .or(conflict.our.as_ref())
            .or(conflict.ancestor.as_ref());

        let path = path_entry
            .and_then(|entry| std::str::from_utf8(&entry.path).ok())
            .unwrap_or("(unknown)")
            .to_string();

        conflicts.push(MergeConflictEntry { path });
    }

    Ok(conflicts)
}

fn saturating_u32(value: usize) -> u32 {
    u32::try_from(value).unwrap_or(u32::MAX)
}

fn compute_merge_preview<'repo>(
    repo: &'repo Repository,
    requested_path: String,
    target_spec: &str,
    source_spec: &str,
    strategy: MergeStrategy,
) -> Result<
    (
        MergePreviewResponse,
        git2::Commit<'repo>,
        git2::Commit<'repo>,
    ),
    String,
> {
    let (target_obj, target_ref) = repo
        .revparse_ext(target_spec)
        .map_err(|err| format!("Failed to resolve target {target_spec}: {err}"))?;
    let target_commit = target_obj
        .peel_to_commit()
        .map_err(|err| format!("Target {target_spec} does not resolve to a commit: {err}"))?;

    let (source_obj, source_ref) = repo
        .revparse_ext(source_spec)
        .map_err(|err| format!("Failed to resolve source {source_spec}: {err}"))?;
    let source_commit = source_obj
        .peel_to_commit()
        .map_err(|err| format!("Source {source_spec} does not resolve to a commit: {err}"))?;

    let target_reference = target_ref
        .as_ref()
        .and_then(|reference| reference.name().map(|s| s.to_string()));
    let target_shorthand = target_ref
        .as_ref()
        .and_then(|reference| reference.shorthand().map(|s| s.to_string()));
    let source_reference = source_ref
        .as_ref()
        .and_then(|reference| reference.name().map(|s| s.to_string()))
        .unwrap_or_else(|| source_spec.to_string());
    let source_shorthand = source_ref
        .as_ref()
        .and_then(|reference| reference.shorthand().map(|s| s.to_string()))
        .unwrap_or_else(|| source_spec.to_string());

    let mut warnings = Vec::new();
    if let Ok(head) = repo.head() {
        if let Some(name) = head.name() {
            if target_reference
                .as_ref()
                .map(|value| value != name)
                .unwrap_or(true)
            {
                warnings.push("Target branch differs from current HEAD".to_string());
            }
        }
    } else {
        warnings.push("Repository is in detached HEAD state".to_string());
    }

    let (ahead_raw, behind_raw) = repo
        .graph_ahead_behind(source_commit.id(), target_commit.id())
        .unwrap_or((0, 0));
    let ahead = saturating_u32(ahead_raw);
    let behind = saturating_u32(behind_raw);
    let merge_base = repo.merge_base(target_commit.id(), source_commit.id()).ok();
    let merge_base_string = merge_base.map(|oid| oid.to_string());

    let mut conflicts = Vec::new();
    let mut would_conflict = false;

    if let Some(base_oid) = merge_base {
        match repo.find_commit(base_oid).and_then(|commit| {
            let base_tree = commit.tree()?;
            let target_tree = target_commit.tree()?;
            let source_tree = source_commit.tree()?;
            Ok((base_tree, target_tree, source_tree))
        }) {
            Ok((base_tree, target_tree, source_tree)) => {
                let mut merge_opts = MergeOptions::new();
                match repo.merge_trees(
                    &base_tree,
                    &target_tree,
                    &source_tree,
                    Some(&mut merge_opts),
                ) {
                    Ok(index) => {
                        if let Ok(entries) = collect_conflicts(&index) {
                            if !entries.is_empty() {
                                conflicts = entries;
                                would_conflict = true;
                            }
                        }
                    }
                    Err(err) => {
                        warnings.push(format!("Failed to compute merge preview: {err}"));
                        would_conflict = true;
                    }
                }
            }
            Err(err) => {
                warnings.push(format!(
                    "Unable to load commit trees for merge preview: {err}"
                ));
                would_conflict = true;
            }
        }
    } else {
        warnings.push(
            "Branches do not share a common ancestor; merge will likely require manual resolution."
                .to_string(),
        );
        would_conflict = true;
    }

    let fast_forward_possible = merge_base == Some(target_commit.id());
    let up_to_date = ahead == 0 && behind == 0;

    if strategy == MergeStrategy::FastForward && !fast_forward_possible {
        warnings.push(
            "Requested fast-forward strategy but merge requires standard reconciliation."
                .to_string(),
        );
    }

    let status = MergeStatusSummary {
        strategy,
        fast_forward_possible,
        up_to_date,
        would_conflict,
        merge_base: merge_base_string,
    };

    let preview = MergePreviewResponse {
        repository: RepositoryMetadata {
            requested_path,
            resolved_workdir: repo
                .workdir()
                .and_then(|path| fs::canonicalize(path).ok())
                .map(|path| path.to_string_lossy().into_owned()),
        },
        target: MergeEndpoint {
            reference: target_reference,
            shorthand: target_shorthand,
            commit: summarize_commit(&target_commit),
        },
        source: MergeEndpoint {
            reference: Some(source_reference),
            shorthand: Some(source_shorthand),
            commit: summarize_commit(&source_commit),
        },
        ahead,
        behind,
        status,
        conflicts,
        warnings,
    };

    Ok((preview, target_commit, source_commit))
}

fn reference_names(reference: &git2::Reference) -> (String, String) {
    let shorthand = reference
        .shorthand()
        .map(|s| s.to_string())
        .unwrap_or_else(|| lossy_name(reference.name_bytes()));

    let full = reference
        .name()
        .map(|s| s.to_string())
        .unwrap_or_else(|| shorthand.clone());

    (shorthand, full)
}

fn lossy_name(bytes: &[u8]) -> String {
    String::from_utf8_lossy(bytes).into_owned()
}

fn kind_rank(kind: BranchKind) -> u8 {
    match kind {
        BranchKind::Local => 0,
        BranchKind::Remote => 1,
    }
}

fn kind_label(kind: BranchKind) -> &'static str {
    match kind {
        BranchKind::Local => "local",
        BranchKind::Remote => "remote",
    }
}

fn clamp_u32(value: usize) -> u32 {
    u32::try_from(value).unwrap_or(u32::MAX)
}

fn list_commits(payload: Value) -> CommandResponse {
    let params: ListCommitsRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    let resolved_workdir = repo
        .workdir()
        .and_then(|path| fs::canonicalize(path).ok())
        .or_else(|| {
            repo.path()
                .parent()
                .and_then(|path| fs::canonicalize(path).ok())
        })
        .map(|path| path.to_string_lossy().into_owned());

    let mut revwalk = match repo.revwalk() {
        Ok(walk) => walk,
        Err(err) => return error_response(format!("Failed to initialize revwalk: {err}")),
    };

    if let Err(err) = revwalk.set_sorting(Sort::TOPOLOGICAL | Sort::TIME) {
        return error_response(format!("Failed to set revwalk sorting: {err}"));
    }

    if let Some(branch) = params.branch.clone() {
        let mut tried = Vec::new();
        let mut push_ref = |name: &str| match revwalk.push_ref(name) {
            Ok(_) => Ok(()),
            Err(err) => Err((name.to_string(), err)),
        };

        let candidates = candidate_refs_for_branch(&branch);
        let mut pushed = false;
        for candidate in candidates {
            match push_ref(&candidate) {
                Ok(_) => {
                    pushed = true;
                    break;
                }
                Err((name, err)) => {
                    tried.push((name, err));
                }
            }
        }

        if !pushed {
            let errors = tried
                .into_iter()
                .map(|(name, err)| format!("{name}: {err}"))
                .collect::<Vec<_>>()
                .join("; ");
            return error_response(format!(
                "Failed to push branch {} into revwalk ({errors})",
                branch
            ));
        }
    } else if let Err(err) = revwalk.push_head() {
        return error_response(format!("Failed to push HEAD: {err}"));
    }

    let reference_index = match build_reference_index(&repo) {
        Ok(map) => map,
        Err(err) => return error_response(err),
    };

    let author_filter = params.author.map(|v| v.to_lowercase());
    let message_filter = params.message_query.map(|v| v.to_lowercase());
    let after_filter = params.after;
    let before_filter = params.before;

    let skip = params.skip.unwrap_or(0);
    let limit = params
        .limit
        .map(|value| value.min(MAX_COMMIT_LIMIT).max(1))
        .unwrap_or(DEFAULT_COMMIT_LIMIT);

    let mut commits = Vec::new();
    let mut seen = 0usize;
    let mut has_more = false;

    for oid_result in revwalk {
        let oid = match oid_result {
            Ok(oid) => oid,
            Err(err) => return error_response(format!("Revwalk error: {err}")),
        };

        let commit = match repo.find_commit(oid) {
            Ok(commit) => commit,
            Err(err) => return error_response(format!("Failed to load commit {oid}: {err}")),
        };

        let commit_time = commit.time().seconds();
        if let Some(after) = after_filter {
            if commit_time < after {
                continue;
            }
        }
        if let Some(before) = before_filter {
            if commit_time > before {
                continue;
            }
        }

        if let Some(filter) = author_filter.as_ref() {
            let author = commit.author();
            let name_matches = author
                .name()
                .map(|name| name.to_lowercase().contains(filter))
                .unwrap_or(false);
            let email_matches = author
                .email()
                .map(|email| email.to_lowercase().contains(filter))
                .unwrap_or(false);
            if !(name_matches || email_matches) {
                continue;
            }
        }

        if let Some(filter) = message_filter.as_ref() {
            let summary = commit.summary().unwrap_or_default().to_lowercase();
            let message = commit.message().unwrap_or_default().to_lowercase();
            if !summary.contains(filter) && !message.contains(filter) {
                continue;
            }
        }

        if seen < skip as usize {
            seen += 1;
            continue;
        }

        if commits.len() as u32 >= limit {
            has_more = true;
            break;
        }

        let parents = commit
            .parents()
            .map(|parent| parent.id().to_string())
            .collect::<Vec<_>>();

        let refs = reference_index.get(&oid).cloned().unwrap_or_default();

        commits.push(CommitInfo {
            id: commit.id().to_string(),
            summary: commit.summary().map(|s| s.to_string()),
            message: commit.message().map(|s| s.to_string()),
            author: signature_info(commit.author()),
            committer: signature_info(commit.committer()),
            parents,
            refs,
        });

        seen += 1;
    }

    let response = CommitListResponse {
        repository: RepositoryMetadata {
            requested_path,
            resolved_workdir,
        },
        page: PageInfo {
            skip,
            limit,
            returned: commits.len() as u32,
            has_more,
        },
        commits,
    };

    match serde_json::to_value(response) {
        Ok(value) => ok_response(value),
        Err(err) => error_response(format!("Failed to encode commit response: {err}")),
    }
}

fn build_reference_index(repo: &Repository) -> Result<HashMap<Oid, Vec<ReferenceInfo>>, String> {
    let mut map: HashMap<Oid, Vec<ReferenceInfo>> = HashMap::new();
    let mut iter = repo
        .references()
        .map_err(|err| format!("Failed to enumerate references: {err}"))?;

    while let Some(reference_result) = iter.next() {
        let reference =
            reference_result.map_err(|err| format!("Failed to read reference: {err}"))?;

        if reference.kind() == Some(git2::ReferenceType::Symbolic) {
            continue;
        }

        let target = if let Ok(commit) = reference.peel_to_commit() {
            commit.id()
        } else if let Some(oid) = reference.target() {
            oid
        } else {
            continue;
        };

        let info = reference_info(&reference);
        map.entry(target).or_default().push(info);
    }

    Ok(map)
}

fn reference_info(reference: &Reference) -> ReferenceInfo {
    let name = reference.name().unwrap_or_default().to_string();
    let shorthand = reference.shorthand().map(|s| s.to_string());
    let kind = classify_reference(&name);

    ReferenceInfo {
        name,
        shorthand,
        kind,
    }
}

fn classify_reference(name: &str) -> ReferenceKind {
    if name.starts_with("refs/heads/") {
        ReferenceKind::LocalBranch
    } else if name.starts_with("refs/remotes/") {
        ReferenceKind::RemoteBranch
    } else if name.starts_with("refs/tags/") {
        ReferenceKind::Tag
    } else if name.starts_with("refs/notes/") {
        ReferenceKind::Note
    } else {
        ReferenceKind::Other
    }
}

fn signature_info(signature: git2::Signature<'_>) -> SignatureInfo {
    let when = signature.when();
    SignatureInfo {
        name: signature.name().map(|s| s.to_string()),
        email: signature.email().map(|s| s.to_string()),
        time: when.seconds(),
        offset_minutes: when.offset_minutes(),
    }
}

fn candidate_refs_for_branch(branch: &str) -> Vec<String> {
    let mut candidates = Vec::new();
    if branch.starts_with("refs/") {
        candidates.push(branch.to_string());
    } else {
        candidates.push(format!("refs/heads/{branch}"));
        candidates.push(format!("refs/remotes/{branch}"));
        if !branch.contains('/') {
            candidates.push(format!("refs/tags/{branch}"));
        }
    }
    candidates.push(branch.to_string());
    candidates
}

fn empty_signature_info() -> SignatureInfo {
    SignatureInfo {
        name: None,
        email: None,
        time: 0,
        offset_minutes: 0,
    }
}

fn get_file_blame(payload: Value) -> CommandResponse {
    let params: FileBlameRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    if params.file_path.trim().is_empty() {
        return error_response("file_path cannot be empty");
    }

    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    let resolved_workdir = repo
        .workdir()
        .and_then(|path| fs::canonicalize(path).ok())
        .or_else(|| {
            repo.path()
                .parent()
                .and_then(|path| fs::canonicalize(path).ok())
        })
        .map(|path| path.to_string_lossy().into_owned());

    let target_commit = match params.commit {
        Some(ref spec) => match repo.revparse_single(spec) {
            Ok(obj) => match obj.peel_to_commit() {
                Ok(commit) => commit,
                Err(err) => {
                    return error_response(format!("Failed to peel commit {spec}: {err}"));
                }
            },
            Err(err) => {
                return error_response(format!("Failed to parse commit {spec}: {err}"));
            }
        },
        None => match repo.head() {
            Ok(head) => match head.peel_to_commit() {
                Ok(commit) => commit,
                Err(err) => {
                    return error_response(format!("Failed to resolve HEAD commit: {err}"));
                }
            },
            Err(err) => {
                return error_response(format!("Failed to read HEAD: {err}"));
            }
        },
    };

    let mut blame_opts = git2::BlameOptions::new();
    blame_opts.newest_commit(target_commit.id());

    let blame = match repo.blame_file(Path::new(&params.file_path), Some(&mut blame_opts)) {
        Ok(blame) => blame,
        Err(err) => {
            return error_response(format!(
                "Failed to compute blame for {}: {err}",
                params.file_path
            ));
        }
    };

    let file_contents = match load_file_contents(&repo, &target_commit, &params.file_path) {
        Ok(text) => text,
        Err(err) => return error_response(err),
    };
    let lines: Vec<String> = file_contents.lines().map(|line| line.to_string()).collect();

    let mut hunks = Vec::new();
    for blame_hunk in blame.iter() {
        let start_line = blame_hunk.final_start_line() as usize;
        let line_count = blame_hunk.lines_in_hunk() as usize;
        let mut blame_lines = Vec::with_capacity(line_count);

        for offset in 0..line_count {
            let line_number = start_line + offset;
            let text = lines
                .get(line_number.saturating_sub(1))
                .cloned()
                .unwrap_or_default();
            blame_lines.push(BlameLine {
                number: line_number,
                text,
            });
        }

        let final_commit_id = blame_hunk.final_commit_id();
        let commit = repo.find_commit(final_commit_id).ok();
        let (summary, author, committer) = if let Some(commit) = commit {
            (
                commit.summary().map(|s| s.to_string()),
                signature_info(commit.author()),
                signature_info(commit.committer()),
            )
        } else {
            (None, empty_signature_info(), empty_signature_info())
        };

        hunks.push(BlameHunk {
            start_line,
            lines: blame_lines,
            commit: BlameCommitInfo {
                id: final_commit_id.to_string(),
                summary,
                author,
                committer,
            },
        });
    }

    let response = BlameResponse {
        repository: RepositoryMetadata {
            requested_path,
            resolved_workdir,
        },
        file_path: params.file_path,
        commit: Some(target_commit.id().to_string()),
        hunks,
    };

    match serde_json::to_value(response) {
        Ok(value) => ok_response(value),
        Err(err) => error_response(format!("Failed to encode blame response: {err}")),
    }
}

fn load_file_contents(
    repo: &Repository,
    commit: &git2::Commit<'_>,
    file_path: &str,
) -> Result<String, String> {
    let path = Path::new(file_path);
    let tree = commit
        .tree()
        .map_err(|err| format!("Failed to load commit tree: {err}"))?;
    let entry = tree
        .get_path(path)
        .map_err(|_| format!("File {file_path} not found in commit {}", commit.id()))?;
    let blob = repo
        .find_blob(entry.id())
        .map_err(|err| format!("Failed to read blob for {file_path}: {err}"))?;

    std::str::from_utf8(blob.content())
        .map(|s| s.to_string())
        .map_err(|_| format!("File {file_path} is not valid UTF-8"))
}

fn create_branch(payload: Value) -> CommandResponse {
    let params: CreateBranchRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    if params.branch_name.trim().is_empty() {
        return error_response("branch_name cannot be empty");
    }

    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    let commit = match params.start_point {
        Some(ref start) if !start.trim().is_empty() => match repo.revparse_single(start) {
            Ok(obj) => match obj.peel_to_commit() {
                Ok(commit) => commit,
                Err(err) => {
                    return error_response(format!("Failed to peel commit {start}: {err}"));
                }
            },
            Err(err) => {
                return error_response(format!("Failed to resolve {start}: {err}"));
            }
        },
        _ => match repo.head() {
            Ok(head) => match head.peel_to_commit() {
                Ok(commit) => commit,
                Err(err) => return error_response(format!("Failed to resolve HEAD commit: {err}")),
            },
            Err(err) => return error_response(format!("Failed to read HEAD: {err}")),
        },
    };

    let branch_result = repo.branch(&params.branch_name, &commit, params.force);
    match branch_result {
        Ok(_) => {
            let response = OperationResponse {
                message: Some(format!(
                    "Branch '{}' created at {}",
                    params.branch_name,
                    commit.id()
                )),
                warnings: None,
                data: Some(json!({
                    "branch": params.branch_name,
                    "target": commit.id().to_string()
                })),
            };
            ok_response(json!(response))
        }
        Err(err) => error_response(format!(
            "Failed to create branch {}: {err}",
            params.branch_name
        )),
    }
}

fn checkout_branch(payload: Value) -> CommandResponse {
    let params: CheckoutBranchRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    if params.branch.trim().is_empty() {
        return error_response("branch cannot be empty");
    }

    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    match ensure_clean_workdir(&repo) {
        Ok(_) => (),
        Err(files) => {
            if !params.allow_dirty {
                return CommandResponse {
                    status: "error",
                    message: Some("Working tree has uncommitted changes".to_string()),
                    data: Some(json!({ "dirty_files": files })),
                };
            }
        }
    }

    let branch = match repo.find_branch(&params.branch, BranchType::Local) {
        Ok(branch) => branch,
        Err(err) => {
            return error_response(format!(
                "Failed to find local branch {}: {err}",
                params.branch
            ));
        }
    };

    let commit = match branch.get().peel_to_commit() {
        Ok(commit) => commit,
        Err(err) => {
            return error_response(format!(
                "Failed to resolve target commit for {}: {err}",
                params.branch
            ));
        }
    };

    if let Err(err) = repo.checkout_tree(commit.as_object(), None) {
        return error_response(format!("Failed to checkout tree: {err}"));
    }

    if let Err(err) = repo.set_head(branch.get().name().unwrap_or_default()) {
        return error_response(format!("Failed to set HEAD: {err}"));
    }

    let response = OperationResponse {
        message: Some(format!(
            "Checked out branch '{}' at {}",
            params.branch,
            commit.id()
        )),
        warnings: None,
        data: Some(json!({
            "branch": params.branch,
            "commit": commit.id().to_string()
        })),
    };

    ok_response(json!(response))
}

fn merge_preview(payload: Value) -> CommandResponse {
    let params: MergePreviewRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    let source_spec = params.source.trim();
    if source_spec.is_empty() {
        return error_response("source cannot be empty");
    }

    let strategy = params.strategy.unwrap_or_default();
    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    let target_spec = params
        .target
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .unwrap_or("HEAD");

    let (preview, _, _) =
        match compute_merge_preview(&repo, requested_path, target_spec, source_spec, strategy) {
            Ok(value) => value,
            Err(err) => return error_response(err),
        };

    match serde_json::to_value(preview) {
        Ok(data) => ok_response(data),
        Err(err) => error_response(format!("Failed to serialize merge preview: {err}")),
    }
}

fn merge_branch(payload: Value) -> CommandResponse {
    let params: PerformMergeRequest = match serde_json::from_value(payload) {
        Ok(value) => value,
        Err(err) => return error_response(format!("Invalid request payload: {err}")),
    };

    let source_spec = params.source.trim();
    if source_spec.is_empty() {
        return error_response("source cannot be empty");
    }

    let strategy = params.strategy.unwrap_or_default();
    let requested_path = params.repo_path.unwrap_or_else(|| ".".to_string());
    let repo = match Repository::discover(&requested_path) {
        Ok(repo) => repo,
        Err(err) => {
            return error_response(format!(
                "Failed to open repository at {}: {err}",
                requested_path
            ));
        }
    };

    match ensure_clean_workdir(&repo) {
        Ok(_) => {}
        Err(files) => {
            if !params.allow_dirty {
                return CommandResponse {
                    status: "error",
                    message: Some("Working tree has uncommitted changes".to_string()),
                    data: Some(json!({ "dirty_files": files })),
                };
            }
        }
    }

    let target_spec = params
        .target
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .unwrap_or("HEAD");

    let (preview, _target_commit, source_commit) =
        match compute_merge_preview(&repo, requested_path, target_spec, source_spec, strategy) {
            Ok(value) => value,
            Err(err) => return error_response(err),
        };

    let mut warnings = preview.warnings.clone();
    let mut outcome_conflicts = preview.conflicts.clone();

    match strategy {
        MergeStrategy::FastForward => {
            if !preview.status.fast_forward_possible {
                return error_response(
                    "Fast-forward merge is not possible; choose a different strategy.",
                );
            }

            let mut checkout = CheckoutBuilder::new();
            checkout.force();

            if let Err(err) = repo.checkout_tree(source_commit.as_object(), Some(&mut checkout)) {
                return error_response(format!("Failed to update working tree: {err}"));
            }

            match repo.head() {
                Ok(head_ref) if head_ref.is_branch() => {
                    if let Some(name) = head_ref.name() {
                        if let Err(err) = repo.find_reference(name).and_then(|mut reference| {
                            reference.set_target(source_commit.id(), "Fast-forward merge")
                        }) {
                            return error_response(format!(
                                "Failed to update branch reference {name}: {err}"
                            ));
                        }

                        if let Err(err) = repo.set_head(name) {
                            return error_response(format!("Failed to set HEAD: {err}"));
                        }
                    } else if let Err(err) = repo.set_head_detached(source_commit.id()) {
                        return error_response(format!("Failed to detach HEAD: {err}"));
                    }
                }
                Ok(_) => {
                    if let Err(err) = repo.set_head_detached(source_commit.id()) {
                        return error_response(format!("Failed to detach HEAD: {err}"));
                    }
                }
                Err(err) => {
                    return error_response(format!("Failed to read HEAD: {err}"));
                }
            }

            if let Err(err) = repo.checkout_head(Some(CheckoutBuilder::new().force())) {
                warnings.push(format!(
                    "Checkout verification encountered an issue but merge succeeded: {err}"
                ));
            }

            let outcome = MergeOutcome {
                strategy,
                fast_forward_performed: true,
                merge_commit: Some(source_commit.id().to_string()),
                conflicts: Vec::new(),
                working_tree_dirty: false,
                message: Some("Fast-forward applied".to_string()),
            };

            let response = OperationResponse {
                message: Some(format!("Fast-forwarded to commit {}", source_commit.id())),
                warnings: if warnings.is_empty() {
                    None
                } else {
                    Some(warnings)
                },
                data: Some(json!({ "outcome": outcome, "preview": preview })),
            };

            ok_response(json!(response))
        }
        MergeStrategy::ThreeWay | MergeStrategy::Squash => {
            let annotated = match repo.find_annotated_commit(source_commit.id()) {
                Ok(commit) => commit,
                Err(err) => {
                    return error_response(format!(
                        "Failed to prepare annotated commit for merge: {err}"
                    ));
                }
            };

            let mut merge_opts = MergeOptions::new();
            merge_opts.file_favor(FileFavor::Normal);

            let mut checkout_opts = CheckoutBuilder::new();
            checkout_opts.allow_conflicts(true).safe();

            if let Err(err) = repo.merge(
                &[&annotated],
                Some(&mut merge_opts),
                Some(&mut checkout_opts),
            ) {
                return error_response(format!("Merge operation failed: {err}"));
            }

            let mut index = match repo.index() {
                Ok(index) => index,
                Err(err) => {
                    return error_response(format!("Failed to open repository index: {err}"));
                }
            };

            if let Err(err) = index.write() {
                warnings.push(format!("Unable to write index after merge: {err}"));
            }

            match collect_conflicts(&index) {
                Ok(conflicts) => {
                    if !conflicts.is_empty() {
                        outcome_conflicts = conflicts;
                    } else {
                        outcome_conflicts.clear();
                    }
                }
                Err(err) => warnings.push(format!("Failed to enumerate conflicts: {err}")),
            }

            let outcome = MergeOutcome {
                strategy,
                fast_forward_performed: false,
                merge_commit: None,
                conflicts: outcome_conflicts.clone(),
                working_tree_dirty: true,
                message: Some(
                    match strategy {
                        MergeStrategy::Squash => {
                            "Squash merge applied; commit the staged changes to finalize."
                        }
                        _ => {
                            "Merge applied to working tree; review changes and commit to finalize."
                        }
                    }
                    .to_string(),
                ),
            };

            let response = OperationResponse {
                message: Some(match strategy {
                    MergeStrategy::Squash => "Squash merge staged changes.".to_string(),
                    _ => "Merge applied with potential conflicts.".to_string(),
                }),
                warnings: if warnings.is_empty() {
                    None
                } else {
                    Some(warnings)
                },
                data: Some(json!({ "outcome": outcome, "preview": preview })),
            };

            ok_response(json!(response))
        }
    }
}

fn ensure_clean_workdir(repo: &Repository) -> Result<(), Vec<String>> {
    let mut opts = git2::StatusOptions::new();
    opts.include_untracked(true)
        .recurse_untracked_dirs(true)
        .include_ignored(false);

    let statuses = repo
        .statuses(Some(&mut opts))
        .map_err(|_| Vec::<String>::new())?;

    let dirty_files: Vec<String> = statuses
        .iter()
        .filter_map(|entry| {
            let status = entry.status();
            if status.is_wt_new()
                || status.is_wt_modified()
                || status.is_wt_deleted()
                || status.is_index_deleted()
                || status.is_index_modified()
                || status.is_conflicted()
            {
                entry.path().map(|p| p.to_string())
            } else {
                None
            }
        })
        .collect();

    if dirty_files.is_empty() {
        Ok(())
    } else {
        Err(dirty_files)
    }
}
fn dispatch(request: CommandRequest) -> CommandResponse {
    let CommandRequest { command, payload } = request;

    match command.as_str() {
        "ping" => CommandResponse {
            status: "ok",
            message: Some("pong".to_string()),
            data: Some(json!({ "version": &*VERSION })),
        },
        "get_version" => CommandResponse {
            status: "ok",
            message: None,
            data: Some(json!({ "version": &*VERSION })),
        },
        "list_branches" => list_branches(payload),
        "list_commits" => list_commits(payload),
        "get_file_blame" => get_file_blame(payload),
        "create_branch" => create_branch(payload),
        "checkout_branch" => checkout_branch(payload),
        "merge_preview" => merge_preview(payload),
        "merge_branch" => merge_branch(payload),
        command => CommandResponse {
            status: "error",
            message: Some(format!("Unknown command: {command}")),
            data: None,
        },
    }
}

#[no_mangle]
pub extern "C" fn git_dispatch(request_ptr: *const c_char) -> *mut c_char {
    let response = match from_c_string(request_ptr) {
        Ok(raw) => match serde_json::from_str::<CommandRequest>(&raw) {
            Ok(cmd) => dispatch(cmd),
            Err(_) => CommandResponse {
                status: "error",
                message: Some("Failed to decode request payload".to_string()),
                data: None,
            },
        },
        Err(err) => err,
    };

    match serde_json::to_string(&response) {
        Ok(json) => to_c_string(json),
        Err(err) => to_c_string(
            serde_json::json!({
                "status": "error",
                "message": format!("Serialization failure: {err}")
            })
            .to_string(),
        ),
    }
}
#[no_mangle]
pub extern "C" fn git_string_free(ptr: *mut c_char) {
    if ptr.is_null() {
        return;
    }
    unsafe {
        drop(CString::from_raw(ptr));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use git2::{build::CheckoutBuilder, Repository as GitRepository, Signature};
    use std::path::Path;
    use tempfile::TempDir;

    #[test]
    fn ping_command_responds() {
        let request = json!({ "command": "ping" }).to_string();
        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        assert_eq!(parsed["message"], "pong");
        assert_eq!(parsed["data"]["version"], VERSION.as_str());

        git_string_free(ptr);
    }

    #[test]
    fn unknown_command_errors() {
        let request = json!({ "command": "missing" }).to_string();
        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "error");

        git_string_free(ptr);
    }

    #[test]
    fn list_branches_returns_local_head() {
        let repo_dir = init_repo_with_commit();
        let request = json!({
            "command": "list_branches",
            "payload": { "repo_path": repo_dir.path().to_str().unwrap() }
        })
        .to_string();
        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        assert!(
            parsed["data"]["branches"]
                .as_array()
                .expect("branches array")
                .iter()
                .any(|branch| branch["is_head"].as_bool().unwrap_or(false)),
            "expected at least one head branch"
        );

        let resolved = parsed["data"]["repository"]["resolved_workdir"]
            .as_str()
            .expect("resolved path");
        let expected = std::fs::canonicalize(repo_dir.path()).expect("canonicalize repo path");
        assert_eq!(resolved, expected.to_string_lossy());

        git_string_free(ptr);
    }

    #[test]
    fn list_branches_errors_for_missing_repo() {
        let request = json!({
            "command": "list_branches",
            "payload": { "repo_path": "/tmp/definitely/missing/repo" }
        })
        .to_string();
        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "error");

        git_string_free(ptr);
    }

    #[test]
    fn list_commits_returns_history() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        commit_file(
            &repo,
            Path::new("src/lib.rs"),
            "pub fn demo() {}\n",
            "add demo",
        );

        let head_commit = repo.head().unwrap().peel_to_commit().unwrap();
        let signature = Signature::now("Tagger", "tagger@example.com").unwrap();
        let head_object = repo
            .find_object(head_commit.id(), None)
            .expect("find head object");
        repo.tag("v1.0.0", &head_object, &signature, "release tag", false)
            .expect("create tag");

        let request = json!({
            "command": "list_commits",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "limit": 10
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        let commits = parsed["data"]["commits"].as_array().expect("commit array");
        assert!(commits.len() >= 2);

        let first_commit = commits.first().expect("first commit");
        assert!(first_commit["id"].as_str().unwrap().len() >= 7);

        let has_tag = commits.iter().any(|commit| {
            commit["refs"].as_array().unwrap().iter().any(|reference| {
                reference["name"]
                    .as_str()
                    .unwrap()
                    .contains("refs/tags/v1.0.0")
            })
        });
        assert!(
            has_tag,
            "expected at least one commit to include the v1.0.0 tag"
        );

        git_string_free(ptr);
    }

    #[test]
    fn list_commits_supports_filters() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        commit_file(
            &repo,
            Path::new("feature.txt"),
            "feature work\n",
            "feat: add feature",
        );

        commit_file(&repo, Path::new("bug.txt"), "bug fix\n", "fix: bug");

        let request = json!({
            "command": "list_commits",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "message_query": "feat",
                "limit": 5
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        let commits = parsed["data"]["commits"].as_array().unwrap();
        assert!(commits
            .iter()
            .all(|commit| commit["message"].as_str().unwrap().contains("feat")));

        git_string_free(ptr);
    }

    #[test]
    fn get_file_blame_returns_hunks() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        commit_file(
            &repo,
            Path::new("README.md"),
            "hello world\nsecond line\n",
            "add second line",
        );

        let request = json!({
            "command": "get_file_blame",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "file_path": "README.md"
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        let hunks = parsed["data"]["hunks"].as_array().expect("hunks array");
        assert!(!hunks.is_empty());
        let first_hunk = hunks.first().unwrap();
        assert!(first_hunk["lines"].as_array().unwrap().len() >= 1);

        git_string_free(ptr);
    }

    #[test]
    fn get_file_blame_errors_for_missing_file() {
        let repo_dir = init_repo_with_commit();

        let request = json!({
            "command": "get_file_blame",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "file_path": "missing.txt"
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "error");

        git_string_free(ptr);
    }

    #[test]
    fn create_branch_rejects_empty_name() {
        let repo_dir = init_repo_with_commit();
        let request = json!({
            "command": "create_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch_name": ""
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "error");

        git_string_free(ptr);
    }

    #[test]
    fn checkout_branch_allows_dirty_with_flag() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        commit_file(
            &repo,
            Path::new("src/lib.rs"),
            "pub fn sample() {}\n",
            "add sample",
        );

        let create_request = json!({
            "command": "create_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch_name": "feature/dirty",
                "start_point": "HEAD"
            }
        })
        .to_string();
        let create_request_c = CString::new(create_request).unwrap();
        let create_ptr = git_dispatch(create_request_c.as_ptr());
        git_string_free(create_ptr);

        std::fs::write(repo_dir.path().join("README.md"), "dirty change\n")
            .expect("write dirty file");

        let checkout_request = json!({
            "command": "checkout_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch": "feature/dirty",
                "allow_dirty": true
            }
        })
        .to_string();

        let checkout_request_c = CString::new(checkout_request).unwrap();
        let ptr = git_dispatch(checkout_request_c.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");

        git_string_free(ptr);
    }

    #[test]
    fn create_branch_creates_branch() {
        let repo_dir = init_repo_with_commit();
        let request = json!({
            "command": "create_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch_name": "feature/test",
                "start_point": "HEAD"
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");

        let repo = GitRepository::open(repo_dir.path()).expect("open repo");
        let branch = repo
            .find_branch("feature/test", git2::BranchType::Local)
            .expect("branch present");
        assert!(branch.get().name().unwrap().contains("feature/test"));

        git_string_free(ptr);
    }

    #[test]
    fn checkout_branch_blocks_dirty_workdir() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        commit_file(
            &repo,
            Path::new("src/lib.rs"),
            "pub fn sample() {}\n",
            "add sample",
        );

        let create_request = json!({
            "command": "create_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch_name": "feature/checkout",
                "start_point": "HEAD"
            }
        })
        .to_string();
        let create_request_c = CString::new(create_request).unwrap();
        let create_ptr = git_dispatch(create_request_c.as_ptr());
        git_string_free(create_ptr);

        std::fs::write(repo_dir.path().join("README.md"), "dirty change\n")
            .expect("write dirty file");

        let checkout_request = json!({
            "command": "checkout_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch": "feature/checkout"
            }
        })
        .to_string();

        let checkout_request_c = CString::new(checkout_request).unwrap();
        let ptr = git_dispatch(checkout_request_c.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "error");
        assert!(parsed["data"]["dirty_files"].as_array().unwrap().len() >= 1);

        git_string_free(ptr);
    }

    #[test]
    fn checkout_branch_switches_when_clean() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        commit_file(
            &repo,
            Path::new("src/lib.rs"),
            "pub fn sample() {}\n",
            "add sample",
        );

        let create_request = json!({
            "command": "create_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch_name": "feature/clean",
                "start_point": "HEAD"
            }
        })
        .to_string();
        let create_request_c = CString::new(create_request).unwrap();
        let create_ptr = git_dispatch(create_request_c.as_ptr());
        git_string_free(create_ptr);

        let checkout_request = json!({
            "command": "checkout_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "branch": "feature/clean"
            }
        })
        .to_string();

        let checkout_request_c = CString::new(checkout_request).unwrap();
        let ptr = git_dispatch(checkout_request_c.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");

        git_string_free(ptr);
    }

    #[test]
    fn merge_preview_reports_fast_forward() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        let main_ref = repo
            .head()
            .expect("head")
            .name()
            .expect("head name")
            .to_string();
        let head_commit = repo
            .head()
            .expect("head")
            .peel_to_commit()
            .expect("peel head");

        repo.branch("feature/ff", &head_commit, false)
            .expect("create feature branch");
        repo.set_head("refs/heads/feature/ff")
            .expect("set head to feature");
        repo.checkout_head(Some(CheckoutBuilder::new().force()))
            .expect("checkout feature branch");

        commit_file(
            &repo,
            Path::new("feature.txt"),
            "feature work\n",
            "feature commit",
        );

        repo.set_head(&main_ref).expect("restore head");
        repo.checkout_head(Some(CheckoutBuilder::new().force()))
            .expect("checkout main");

        let request = json!({
            "command": "merge_preview",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "source": "feature/ff",
                "strategy": "fast_forward"
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        assert!(parsed["data"]["ahead"].as_u64().unwrap_or(0) >= 1);
        assert!(parsed["data"]["status"]["fast_forward_possible"]
            .as_bool()
            .unwrap());

        git_string_free(ptr);
    }

    #[test]
    fn merge_branch_fast_forward_updates_target() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        let main_ref = repo
            .head()
            .expect("head")
            .name()
            .expect("head name")
            .to_string();
        let head_commit = repo
            .head()
            .expect("head")
            .peel_to_commit()
            .expect("peel head");

        repo.branch("feature/integration", &head_commit, false)
            .expect("create feature branch");
        repo.set_head("refs/heads/feature/integration")
            .expect("set head to feature");
        repo.checkout_head(Some(CheckoutBuilder::new().force()))
            .expect("checkout feature branch");

        commit_file(
            &repo,
            Path::new("lib/core.rs"),
            "pub fn feature() {}\n",
            "feature commit",
        );
        let feature_commit = repo
            .head()
            .expect("feature head")
            .target()
            .expect("feature commit");
        let feature_commit_str = feature_commit.to_string();

        repo.set_head(&main_ref).expect("restore head");
        repo.checkout_head(Some(CheckoutBuilder::new().force()))
            .expect("checkout main");

        let request = json!({
            "command": "merge_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "source": "feature/integration",
                "strategy": "fast_forward"
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "ok");
        assert_eq!(
            parsed["data"]["data"]["outcome"]["merge_commit"]
                .as_str()
                .unwrap(),
            feature_commit_str
        );

        git_string_free(ptr);

        let repo = GitRepository::open(repo_dir.path()).expect("open repo after merge");
        let current_head = repo.head().expect("head").target().expect("head oid");
        assert_eq!(current_head, feature_commit);

        let main_branch = repo
            .find_reference(&main_ref)
            .expect("find main ref")
            .target()
            .expect("main target");
        assert_eq!(main_branch, feature_commit);
    }

    #[test]
    fn merge_branch_respects_dirty_workdir() {
        let repo_dir = init_repo_with_commit();
        let repo = GitRepository::open(repo_dir.path()).expect("open repo");

        let main_ref = repo
            .head()
            .expect("head")
            .name()
            .expect("head name")
            .to_string();
        let head_commit = repo
            .head()
            .expect("head")
            .peel_to_commit()
            .expect("peel head");

        repo.branch("feature/conflict", &head_commit, false)
            .expect("create feature branch");
        repo.set_head("refs/heads/feature/conflict")
            .expect("set head to feature");
        repo.checkout_head(Some(CheckoutBuilder::new().force()))
            .expect("checkout feature branch");

        commit_file(
            &repo,
            Path::new("src/new.rs"),
            "pub fn new_feature() {}\n",
            "new feature",
        );

        repo.set_head(&main_ref).expect("restore head");
        repo.checkout_head(Some(CheckoutBuilder::new().force()))
            .expect("checkout main");

        std::fs::write(repo_dir.path().join("README.md"), "dirty\n").expect("dirty write");

        let request = json!({
            "command": "merge_branch",
            "payload": {
                "repo_path": repo_dir.path().to_str().unwrap(),
                "source": "feature/conflict",
                "strategy": "fast_forward"
            }
        })
        .to_string();

        let c_request = CString::new(request).unwrap();
        let ptr = git_dispatch(c_request.as_ptr());

        let response = unsafe { CStr::from_ptr(ptr) }
            .to_str()
            .expect("response utf8");
        let parsed: serde_json::Value =
            serde_json::from_str(response).expect("valid json response");

        assert_eq!(parsed["status"], "error");
        assert!(parsed["data"]["dirty_files"].as_array().unwrap().len() >= 1);

        git_string_free(ptr);
    }

    fn init_repo_with_commit() -> TempDir {
        let dir = tempfile::tempdir().expect("tempdir");
        let repo = GitRepository::init(dir.path()).expect("init repo");

        commit_file(
            &repo,
            Path::new("README.md"),
            "hello world\n",
            "initial commit",
        );

        dir
    }

    fn commit_file(repo: &GitRepository, relative_path: &Path, contents: &str, message: &str) {
        let workdir = repo.workdir().expect("workdir");
        let full_path = workdir.join(relative_path);
        if let Some(parent) = full_path.parent() {
            std::fs::create_dir_all(parent).expect("create dirs");
        }
        std::fs::write(&full_path, contents).expect("write file");

        let mut index = repo.index().expect("index");
        index
            .add_path(relative_path)
            .unwrap_or_else(|err| panic!("add path {:?}: {err}", relative_path));
        index.write().expect("write index");

        let tree_id = index.write_tree().expect("write tree");
        let tree = repo.find_tree(tree_id).expect("find tree");

        let signature = Signature::now("Test User", "test@example.com").expect("signature");
        let parents = repo
            .head()
            .ok()
            .and_then(|head| head.peel_to_commit().ok())
            .map(|commit| vec![commit])
            .unwrap_or_default();
        let parent_refs: Vec<&git2::Commit> = parents.iter().collect();

        repo.commit(
            Some("HEAD"),
            &signature,
            &signature,
            message,
            &tree,
            &parent_refs,
        )
        .expect("commit");
    }
}
