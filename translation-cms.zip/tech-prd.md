# Translation CMS Tech PRD

## 1. Problem Overview
Global content teams manage marketing sites, product docs, and app strings across dozens of locales, but current workflows rely on disconnected spreadsheets, agency portals, and one-off scripts. This causes:
- Long lead time (2–4 weeks) between source content approval and localized publish because translation requests are manual and lack SLA tracking.
- Inconsistent terminology and tone due to fragmented translation memory that is not shared across channels.
- Minimal observability into localization cost, throughput, or quality, making it hard to prioritize high-value content.
- High engineering effort to backport translation-ready assets into legacy CMSs or code repositories, slowing product release cycles.
The Translation CMS aims to become a single platform for content modeling, translation automation, and multi-channel delivery with built-in quality signals.

## 2. Goals and Non-Goals
**Goals**
- Reduce translation turnaround time by 60% (baseline 14 days ➜ target 6 days) through workflow automation and vendor integrations.
- Provide an API-first content hub that enforces locale completeness before publish, eliminating manual checklists.
- Centralize translation memory, glossary, and style guides so translators reuse >40% of strings and maintain consistent tone.
- Give localization leads real-time visibility into progress, cost, and quality metrics with alerting on SLA breaches.
- Offer developer-friendly SDKs/webhooks to sync localized assets into web, mobile, and docs pipelines with version control.

**Non-Goals**
- Building a general-purpose WYSIWYG marketing CMS; we focus on translation-centric capabilities and assume source content exists upstream.
- Creating proprietary machine translation engines; we integrate commercial MT providers and human vendors.
- Replacing enterprise billing or procurement tools; the system will export cost data but not issue invoices.

## 3. Personas and User Journeys
| Persona | Responsibilities | Key Journeys |
| --- | --- | --- |
| Localization Program Manager (LPM) | Prioritizes content, tracks SLAs, owns vendors | Create translation projects, assign locales, monitor dashboards, unblock escalations |
| Content Author | Writes source content in upstream CMS or repo | Trigger localization request, view status, receive localized assets for publish |
| Translator / Vendor PM | Produces translations, leverages TM/glossary | Accept tasks, use translation editor, submit for review, receive feedback |
| Reviewer / Regional Marketer | Ensures cultural accuracy, legal compliance | Perform linguistic QA, add comments, approve or request rework |
| Developer / Release Engineer | Integrates CMS via API to product pipelines | Configure schemas, subscribe to webhooks, pull localized bundles |
| Compliance Officer | Ensures data residency and audit readiness | Review audit trails, ensure PII controls, certify locales before launch |

**Critical Journeys**
1. Content Author marks a doc as “Ready for Localization,” automatically creating locale-specific tasks with due dates.
2. LPM bulk assigns tasks, auto-pulls MT suggestions, and escalates overdue locales.
3. Translator works in in-context editor with translation memory suggestions, runs QA checks, and submits for review.
4. Reviewer annotates issues, translator resolves, and once approved the system publishes via API/webhook to downstream channels.
5. LPM reviews metrics dashboard for turnaround time, cost per word, and TM leverage to plan next sprint.

## 4. Functional Requirements
- **Content Modeling:** Define translation units (documents, components, strings) with schema inheritance, locale fallbacks, and custom metadata (eg. priority, regulatory tags).
- **Project & Workflow Management:** Create projects per release or campaign, attach locales, set SLAs, and auto-generate tasks when source content changes via diffing.
- **Automation Rules:** Support rules like “auto-assign DE/FR tasks to Vendor A,” “reuse MT output for tier-3 locales,” or “block publish until legal review tag applied.”
- **Translation Workspace:** Provide side-by-side editor with translation memory matches, glossary enforcement, inline comments, screenshots, and context metadata from upstream CMS.
- **Quality Assurance:** Built-in checks for placeholders, length limits, brand term violations, and pseudo-localization previews; capture review scores for vendors.
- **Collaboration:** Threaded comments, mentions, and Slack/Teams notifications per job; maintain audit log of all changes.
- **Versioning & Rollback:** Track versions per locale, allow diffing between releases, and revert to prior approved translation.
- **Publishing & Delivery:** Offer REST/GraphQL APIs, CLI, and webhooks to push localized bundles, plus connectors to Git (strings JSON), static site generators, and headless CMS targets.
- **Analytics:** Real-time dashboards covering throughput, TM leverage, cost per locale, quality scores, and bottleneck alerts.
- **Admin & Permissions:** Granular roles (Author, Translator, Reviewer, Developer, Admin) with SOC 2-ready audit trails, SSO/SAML, and SCIM provisioning.

## 5. System Architecture
The platform follows a modular, event-driven design:
1. **Content Intake Layer:** Webhooks and APIs ingest source content snapshots, normalize schemas, and detect diffs.
2. **Workflow Service:** Stateful engine that orchestrates tasks, SLAs, assignments, and escalations backed by a rules service.
3. **Localization Services:** Translation Memory (TM), Terminology, and Style Guide services provide suggestions and enforcement.
4. **Execution Layer:** Connectors to MT vendors and human providers, plus queue-based dispatch for scalability.
5. **Experience Layer:** Web app for LPMs/translators, public APIs/SDKs, and webhook delivery infrastructure.

**Tech Stack Guardrails**
- Experience layer is built with Jaspr to deliver reactive, component-streaming UIs that stay performant even on low bandwidth reviewer laptops.
- All backend microservices—including workflow, localization services, and connectors—are implemented in Rust for deterministic performance, memory safety, and straightforward deployment into a multi-region Kubernetes cluster.
- Shared libraries (authn/authz, telemetry, SDK clients) must expose Rust crates first, with TypeScript/other language bindings generated from Rust interfaces to keep parity across integrations.

```mermaid
flowchart LR
  UpCMS["Upstream CMS / Git"] --> Intake["Content Intake Service"]
  Intake --> Queue[Job Queue]
  Queue --> Workflow["Workflow Engine"]
  Workflow --> TM["Translation Memory & Terminology"]
  Workflow --> Vendors["Vendor Connectors"]
  Workflow --> MT["MT Providers"]
  Workflow --> Delivery["Publishers & Webhooks"]
  TM --> Delivery
  Delivery --> Channels["Web / Mobile / Docs"]
  Workflow --> Notify["Notifications & Analytics"]
```

## 6. Data Model
| Entity | Description | Key Fields |
| --- | --- | --- |
| `Project` | Logical grouping of source assets for a release or campaign | id, name, priority, source_version, owner, due_date |
| `Locale` | Supported language-region pair with SLA metadata | locale_code, time_zone, tier, sla_days |
| `ContentEntry` | Translation unit referencing source content | entry_id, project_id, schema_id, checksum, priority |
| `Task` | Locale-specific work item with workflow state | task_id, entry_id, locale_code, status, assignee_id, due_date, word_count |
| `TranslationMemoryUnit` | Source-target pair with metadata | tm_id, source_text, target_text, locale_code, match_percent, last_used_at |
| `GlossaryTerm` | Terminology entries for enforcement | term_id, source_term, approved_translation, part_of_speech, notes |
| `Review` | QA action on a task | review_id, task_id, reviewer_id, severity, comments, score |
| `AuditEvent` | Immutable log for compliance | event_id, actor_id, action, entity_ref, timestamp, payload |

Relationships: Projects have many entries; entries spawn tasks per locale; tasks reference TM units and reviews; audit events capture all state transitions.

## 7. Workflow Orchestration
- **States:** Draft ➜ Ready for Localization ➜ In Translation ➜ In Review ➜ Approved ➜ Published. Blocked and Rework are side states triggered via automation.
- **State Machine Rules:** Each transition requires role-based actions (eg. only Reviewer can move to Approved). Automation can auto-transition to Published once all locales complete and integration tests pass.
- **SLA Tracking:** Each task inherits locale SLA; workflow service calculates due dates, flags tasks when 80% SLA consumed, and auto-escalates to secondary vendor.
- **Batch Operations:** LPMs can reassign groups of tasks, trigger pseudolocalization smoke tests, or pause locales if product scope changes.
- **Fallback Handling:** If a locale misses SLA, system can publish fallback (eg. English) but logs exception and notifies stakeholders.

## 8. Integrations
- **Source Systems:** Webhooks for upstream CMS (Contentful, Sanity, Drupal), Git repositories (strings files), Figma for UI copy, and product DB exports.
- **Vendor & MT:** Prebuilt connectors for RWS, Lionbridge, and Smartling vendor portals, plus MT providers (Google, DeepL, Azure). Supports custom connectors via OAuth credentials.
- **Communication:** Slack/Teams bots for notifications and approvals, email digests, Jira ticket creation for blockers.
- **Delivery Targets:** GitHub PR automation, static site generators (Next.js i18n), mobile string bundles (iOS .strings, Android XML), docs platforms, and REST/GraphQL endpoints for programmatic consumption.
- **Analytics & BI:** Expose metrics to Snowflake via event streams and include Looker/Tableau dashboards; emit webhooks for data warehouse ingestion.

## 9. Non-Functional Requirements
- **Scalability:** Support 5M strings, 200 locales, and 1,000 concurrent translators; horizontal scaling via stateless services and sharded TM store.
- **Performance:** UI operations <300 ms p95, API read latency <200 ms p95, publish webhook dispatch <60 seconds from approval.
- **Availability:** 99.9% uptime for workflow and delivery APIs with active-active deployment across at least two regions.
- **Security & Compliance:** SOC 2 Type II, ISO 27001, GDPR compliance (data residency controls per locale), SSO/SAML 2.0, SCIM, role-based access control, encryption at rest (AES-256) and in transit (TLS 1.2+).
- **Observability:** Centralized logging, distributed tracing, and anomaly detection on SLA breaches; self-healing job retries with dead-letter queues.

## 10. Release Plan and Milestones
| Date (Target) | Milestone | Scope |
| --- | --- | --- |
| March 7, 2026 | Architecture Spike Complete | Finalize schemas, choose queue and DB tech, stand up Rust service skeletons, and prove Jaspr front-end shell communicating over GraphQL subscriptions. |
| April 30, 2026 | MVP | Projects, locales, basic workflows, MT suggestions, manual vendor upload, REST API for pull publishing. |
| June 30, 2026 | Private Beta | Add translation memory, glossary enforcement, Slack notifications, Git/webhook connectors, analytics dashboard v1. |
| September 30, 2026 | GA | Multi-vendor routing, advanced QA checks, role-based permissions, SOC 2 controls, SDKs, and scalable delivery adapters. |
| December 15, 2026 | Growth Enhancements | Smart prioritization, cost reporting exports, in-context preview embeds, and beta mobile SDK. |

Dependencies: hiring 2 backend engineers by March 1, 2026; vendor connector contracts signed by April 1, 2026.

## 11. Risks and Mitigations
| Risk | Impact | Mitigation |
| --- | --- | --- |
| Complex connector onboarding delays timeline | Without connectors, users cannot automate intake/delivery | Allocate dedicated integration squad, ship generic webhook adapter first, provide SDKs for clients to self-build |
| Translation memory performance degrades >2M units | Slows translator productivity | Use vector-friendly search (eg. pgvector/Elastic) with caching, shard TM by locale tier, run load tests before beta |
| Data privacy violations when sharing content with vendors | Regulatory penalties | Enforce PII tagging, redact sensitive fields before vendor export, log consent and vendor agreements |
| Change management for translators unused to new tool | Low adoption despite launch | Offer vendor onboarding toolkit, optional CAT tool connector, and embed user education flows |
| MT quality harmful for high-visibility locales | Brand risk | Allow locale-level MT opt-out, require human review for tier-1 locales, capture quality scores to tune MT usage |

## 12. Metrics and Analytics
- **Leading Indicators:** % tasks auto-assigned, % TM leverage, MT post-edit distance, SLA compliance rate, average comments per review cycle.
- **Lagging Indicators:** End-to-end turnaround time per locale, cost per word, defect rate post-publish, publish readiness (locales completed / total).
- **Product Health:** Weekly active translators, LPM dashboard engagement, API success rate, connector uptime.
- **Instrumentation:** Emit structured events for every workflow transition, integrate with Snowflake and Looker, provide configurable alerts (email/Slack) for SLA breaches or publish failures.
- **Experimentation:** Support A/B of MT providers and vendor routing rules by capturing objective quality scores and automatically comparing throughput/cost.

## 13. Case Studies
**Startups (Series A SaaS)**
- Scenario: 12-person product org launches in U.S./Canada and must add Spanish (es-ES + es-MX) and Japanese within 45 days.
- Implementation: Use Jaspr front-end widgets embedded into existing admin to trigger localization; rely on auto-generated translation projects driven by Git commits. Rust workflow engine routes tier-1 locales to agency, tier-2 through MT + human review.
- Outcomes: TM reuse hits 35% by week 4, turnaround drops from 10 to 4 days, and automated webhook delivery cuts engineering handoffs to <1 hour per release.

**Mid-Size Applications (Global Fintech)**
- Scenario: 200-person company supports 18 locales with regulatory disclosures that change monthly and needs audit-ready traceability.
- Implementation: Content authors flag updates in upstream Contentful; intake service enforces schema versions. Workflow SLAs escalate to regional reviewers, and analytics dashboard triggers Slack alerts when SLA breaches exceed 5%. Glossary service stores 2,000 mandated legal terms with locale variants.
- Outcomes: SLA compliance rises to 97%, compliance officers export audit trails quarterly, and localization cost per word falls 22% thanks to TM leverage and vendor routing automation.

**Enterprise (Highly Regulated Healthcare Suite)**
- Scenario: 4,000-person enterprise serving 60+ locales plus accessibility variants, requiring on-prem data residency in EU and APAC alongside strict vendor privacy controls.
- Implementation: Rust microservices deploy across two regions with geo-fenced data stores; connectors feed downstream Epic/Cerner integrations. Workflow enforces dual approval (medical + legal), and delivery webhooks push both structured copy and binary assets (PDFs) into regulated repositories. Observability stack ties into enterprise SIEM.
- Outcomes: Publish readiness improves from 65% to 94% before regional launches, regulatory audits pass without exceptions due to immutable audit events, and localized critical communications release within 48 hours of source sign-off.
