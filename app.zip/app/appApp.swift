//
//  appApp.swift
//  app
//
//  Created by Vivek Yadav on 09/09/25.
//

import SwiftUI

@main
struct appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
