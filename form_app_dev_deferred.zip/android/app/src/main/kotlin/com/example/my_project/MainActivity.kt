package com.mycompany.formappdev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
