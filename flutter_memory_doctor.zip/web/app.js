// Flutter Memory Doctor — Dashboard Application

const MAX_CHART_POINTS = 300;
let chart = null;
let sampleCount = 0;
let eventSource = null;

// ── Chart Setup ───────────────────────────────────────────────────────────

function initChart() {
  const ctx = document.getElementById('memoryChart').getContext('2d');
  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [
        {
          label: 'Heap Usage',
          data: [],
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          fill: true,
          tension: 0.3,
          pointRadius: 0,
          borderWidth: 2,
        },
        {
          label: 'Heap Capacity',
          data: [],
          borderColor: '#64748b',
          borderDash: [5, 5],
          fill: false,
          tension: 0.3,
          pointRadius: 0,
          borderWidth: 1,
        },
        {
          label: 'External',
          data: [],
          borderColor: '#22c55e',
          backgroundColor: 'rgba(34, 197, 94, 0.1)',
          fill: true,
          tension: 0.3,
          pointRadius: 0,
          borderWidth: 2,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 0 },
      interaction: { mode: 'index', intersect: false },
      scales: {
        x: {
          display: true,
          ticks: {
            color: '#64748b',
            maxTicksLimit: 10,
            maxRotation: 0,
          },
          grid: { color: 'rgba(51, 65, 85, 0.3)' },
        },
        y: {
          display: true,
          ticks: {
            color: '#64748b',
            callback: function(val) { return formatBytes(val); },
          },
          grid: { color: 'rgba(51, 65, 85, 0.3)' },
        },
      },
      plugins: {
        legend: {
          labels: { color: '#94a3b8', usePointStyle: true },
        },
        tooltip: {
          callbacks: {
            label: function(ctx) {
              return ctx.dataset.label + ': ' + formatBytes(ctx.raw);
            },
          },
        },
      },
    },
  });
}

function addSample(sample) {
  if (!chart) return;

  const time = new Date(sample.timestamp).toLocaleTimeString();
  chart.data.labels.push(time);
  chart.data.datasets[0].data.push(sample.heapUsage);
  chart.data.datasets[1].data.push(sample.heapCapacity);
  chart.data.datasets[2].data.push(sample.externalUsage);

  // Trim to max points
  while (chart.data.labels.length > MAX_CHART_POINTS) {
    chart.data.labels.shift();
    chart.data.datasets.forEach(ds => ds.data.shift());
  }

  chart.update('none');

  // Update stats
  sampleCount++;
  document.getElementById('statHeap').textContent = formatBytes(sample.heapUsage);
  document.getElementById('statCapacity').textContent = formatBytes(sample.heapCapacity);
  document.getElementById('statExternal').textContent = formatBytes(sample.externalUsage);
  document.getElementById('statSamples').textContent = sampleCount;
}

function clearChart() {
  if (!chart) return;
  chart.data.labels = [];
  chart.data.datasets.forEach(ds => { ds.data = []; });
  chart.update();
  sampleCount = 0;
  document.getElementById('statSamples').textContent = '0';
}

// ── SSE Connection ────────────────────────────────────────────────────────

function connectSSE() {
  if (eventSource) {
    eventSource.close();
  }

  eventSource = new EventSource('/api/samples/stream');

  eventSource.addEventListener('connected', function() {
    setStatus(true);
  });

  eventSource.addEventListener('sample', function(e) {
    const sample = JSON.parse(e.data);
    addSample(sample);
  });

  eventSource.addEventListener('analysis', function(e) {
    const result = JSON.parse(e.data);
    renderAnalysis(result);
  });

  eventSource.addEventListener('snapshot', function(e) {
    // Snapshot data received; could show notification
  });

  eventSource.onerror = function() {
    setStatus(false);
    // Auto-reconnect is built into EventSource
  };
}

function setStatus(connected) {
  const dot = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  if (connected) {
    dot.classList.remove('disconnected');
    text.textContent = 'Connected';
  } else {
    dot.classList.add('disconnected');
    text.textContent = 'Disconnected';
  }
}

// ── API Calls ─────────────────────────────────────────────────────────────

async function runAnalysis() {
  const btn = document.getElementById('btnAnalyze');
  btn.disabled = true;
  btn.innerHTML = '<span class="loading"></span> Analyzing...';

  try {
    const resp = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ useClaude: true }),
    });
    const result = await resp.json();
    renderAnalysis(result);
  } catch (e) {
    document.getElementById('analysisPanel').innerHTML =
      '<div class="empty-state">Analysis failed: ' + e.message + '</div>';
  } finally {
    btn.disabled = false;
    btn.textContent = 'Analyze';
  }
}

async function takeSnapshot() {
  const btn = document.getElementById('btnSnapshot');
  btn.disabled = true;
  btn.innerHTML = '<span class="loading"></span> Taking snapshot...';

  try {
    const resp = await fetch('/api/snapshot', { method: 'POST' });
    const data = await resp.json();

    if (data.error) {
      alert('Snapshot failed: ' + data.error);
    }
  } catch (e) {
    alert('Snapshot failed: ' + e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Take Snapshot';
  }
}

async function generateFixes() {
  const btn = document.getElementById('btnGenerateFix');
  btn.disabled = true;
  btn.innerHTML = '<span class="loading"></span> Generating...';

  try {
    const resp = await fetch('/api/fix/generate', { method: 'POST' });
    const data = await resp.json();

    if (data.error) {
      alert('Fix generation failed: ' + data.error);
      return;
    }

    renderFixes(data.fixes || []);
  } catch (e) {
    alert('Fix generation failed: ' + e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Generate Fixes';
  }
}

async function applyFix(index) {
  const btn = document.querySelector(`[data-fix-index="${index}"]`);
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Applying...';
  }

  try {
    const resp = await fetch('/api/fix/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fixIndex: index }),
    });
    const data = await resp.json();

    if (data.applied) {
      if (btn) {
        btn.textContent = 'Applied';
        btn.classList.add('btn-applied');
      }
    } else {
      alert('Fix was not applied: original code did not match.');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Apply';
      }
    }
  } catch (e) {
    alert('Failed to apply fix: ' + e.message);
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Apply';
    }
  }
}

// ── Rendering ─────────────────────────────────────────────────────────────

function renderAnalysis(result) {
  const panel = document.getElementById('analysisPanel');
  const badge = document.getElementById('severityBadge');

  badge.style.display = 'inline-block';
  badge.textContent = result.severity;
  badge.className = 'severity-badge severity-' + result.severity;

  let html = '<p style="margin-bottom:0.75rem"><strong>' + escapeHtml(result.summary) + '</strong></p>';

  if (result.diagnosis) {
    html += '<pre style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.75rem;white-space:pre-wrap">'
      + escapeHtml(result.diagnosis) + '</pre>';
  }

  if (result.leaks && result.leaks.length > 0) {
    html += '<h3 style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.5rem">POTENTIAL LEAKS</h3>';
    html += '<ul class="leak-list">';
    for (const leak of result.leaks) {
      html += '<li class="leak-item">';
      html += '<span class="class-name">' + escapeHtml(leak.className) + '</span>';
      html += ' <span class="severity-badge severity-' + (leak.severity || 'medium') + '">'
        + Math.round((leak.confidence || 0) * 100) + '%</span>';
      if (leak.evidence) {
        html += '<div class="evidence">' + leak.evidence.map(escapeHtml).join('<br>') + '</div>';
      }
      html += '</li>';
    }
    html += '</ul>';
    document.getElementById('btnGenerateFix').disabled = false;
  }

  if (result.suggestions && result.suggestions.length > 0) {
    html += '<h3 style="font-size:0.8rem;color:var(--text-secondary);margin:0.75rem 0 0.5rem">SUGGESTIONS</h3>';
    html += '<ul class="suggestions">';
    for (const s of result.suggestions) {
      html += '<li>' + escapeHtml(s) + '</li>';
    }
    html += '</ul>';
  }

  panel.innerHTML = html;
}

function renderFixes(fixes) {
  const panel = document.getElementById('fixPanel');
  const content = document.getElementById('fixContent');

  if (fixes.length === 0) {
    content.innerHTML = '<div class="empty-state">No fixes generated.</div>';
    panel.style.display = 'block';
    return;
  }

  let html = '';
  for (let i = 0; i < fixes.length; i++) {
    const fix = fixes[i];
    html += '<div class="fix-item">';
    html += '<div class="fix-header">';
    html += '<span style="font-family:var(--font-mono);font-size:0.8rem">'
      + escapeHtml(fix.filePath) + ':' + fix.startLine + '-' + fix.endLine + '</span>';
    html += '<button class="btn btn-primary" data-fix-index="' + i + '" onclick="applyFix(' + i + ')">Apply</button>';
    html += '</div>';
    html += '<div class="fix-explanation">' + escapeHtml(fix.explanation) + '</div>';
    html += '<div class="diff-view">';
    for (const line of (fix.originalCode || '').split('\n')) {
      html += '<span class="diff-remove">- ' + escapeHtml(line) + '</span>\n';
    }
    for (const line of (fix.patchedCode || '').split('\n')) {
      html += '<span class="diff-add">+ ' + escapeHtml(line) + '</span>\n';
    }
    html += '</div>';
    html += '</div>';
  }

  content.innerHTML = html;
  panel.style.display = 'block';
}

// ── Utilities ─────────────────────────────────────────────────────────────

function formatBytes(bytes) {
  if (bytes == null || isNaN(bytes)) return '--';
  if (bytes < 1024) return bytes + 'B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + 'KB';
  return (bytes / (1024 * 1024)).toFixed(1) + 'MB';
}

function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ── Initialize ────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', function() {
  initChart();
  connectSSE();

  // Load existing samples
  fetch('/api/samples?count=300')
    .then(r => r.json())
    .then(samples => {
      if (Array.isArray(samples)) {
        for (const sample of samples) {
          addSample(sample);
        }
      }
    })
    .catch(() => {});
});
