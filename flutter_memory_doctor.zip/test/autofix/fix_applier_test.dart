import 'dart:io';

import 'package:flutter_memory_doctor/src/autofix/fix_applier.dart';
import 'package:flutter_memory_doctor/src/models/fix_patch.dart';
import 'package:path/path.dart' as p;
import 'package:test/test.dart';

void main() {
  group('FixApplier', () {
    late Directory tempDir;
    late FixApplier applier;

    setUp(() {
      tempDir = Directory.systemTemp.createTempSync('fix_applier_test_');
      applier = FixApplier(requireConfirmation: false);
    });

    tearDown(() {
      tempDir.deleteSync(recursive: true);
    });

    test('applies a simple patch correctly', () async {
      final filePath = p.join(tempDir.path, 'test.dart');
      File(filePath).writeAsStringSync(
        'line1\nline2\nline3\nline4\nline5\n',
      );

      final fix = FixPatch(
        filePath: filePath,
        startLine: 2,
        endLine: 3,
        originalCode: 'line2\nline3',
        patchedCode: 'newLine2\nnewLine3\nnewLine3b',
        explanation: 'Fix test',
      );

      final applied = await applier.applyFix(fix);
      expect(applied, isTrue);

      final result = File(filePath).readAsStringSync();
      expect(result, equals('line1\nnewLine2\nnewLine3\nnewLine3b\nline4\nline5\n'));

      // Verify backup was created
      expect(File('$filePath.memory_doctor_backup').existsSync(), isTrue);
    });

    test('returns false if original code does not match', () async {
      final filePath = p.join(tempDir.path, 'test.dart');
      File(filePath).writeAsStringSync(
        'line1\nline2\nline3\n',
      );

      final fix = FixPatch(
        filePath: filePath,
        startLine: 2,
        endLine: 2,
        originalCode: 'different_code',
        patchedCode: 'newLine2',
        explanation: 'Fix test',
      );

      final applied = await applier.applyFix(fix);
      expect(applied, isFalse);

      // File should be unchanged
      expect(
        File(filePath).readAsStringSync(),
        equals('line1\nline2\nline3\n'),
      );
    });

    test('throws for non-existent file', () async {
      final fix = FixPatch(
        filePath: p.join(tempDir.path, 'nonexistent.dart'),
        startLine: 1,
        endLine: 1,
        originalCode: 'code',
        patchedCode: 'new_code',
        explanation: 'Fix test',
      );

      expect(
        () => applier.applyFix(fix),
        throwsA(isA<FixApplierException>()),
      );
    });

    test('throws for invalid line range', () async {
      final filePath = p.join(tempDir.path, 'test.dart');
      File(filePath).writeAsStringSync('line1\n');

      final fix = FixPatch(
        filePath: filePath,
        startLine: 1,
        endLine: 10,
        originalCode: 'code',
        patchedCode: 'new_code',
        explanation: 'Fix test',
      );

      expect(
        () => applier.applyFix(fix),
        throwsA(isA<FixApplierException>()),
      );
    });

    test('restoreBackup restores original file', () async {
      final filePath = p.join(tempDir.path, 'test.dart');
      File(filePath).writeAsStringSync('original\n');

      final fix = FixPatch(
        filePath: filePath,
        startLine: 1,
        endLine: 1,
        originalCode: 'original',
        patchedCode: 'modified',
        explanation: 'Fix test',
      );

      await applier.applyFix(fix);
      expect(File(filePath).readAsStringSync(), contains('modified'));

      final restored = FixApplier.restoreBackup(filePath);
      expect(restored, isTrue);
      expect(File(filePath).readAsStringSync(), equals('original\n'));
    });

    test('restoreBackup returns false when no backup exists', () {
      final restored = FixApplier.restoreBackup(
        p.join(tempDir.path, 'no_backup.dart'),
      );
      expect(restored, isFalse);
    });

    test('respects confirmation callback', () async {
      final filePath = p.join(tempDir.path, 'test.dart');
      File(filePath).writeAsStringSync('line1\n');

      var confirmCalled = false;
      final confirmApplier = FixApplier(
        requireConfirmation: true,
        confirmCallback: (fix) async {
          confirmCalled = true;
          return false; // Reject
        },
      );

      final fix = FixPatch(
        filePath: filePath,
        startLine: 1,
        endLine: 1,
        originalCode: 'line1',
        patchedCode: 'newLine1',
        explanation: 'Fix test',
      );

      final applied = await confirmApplier.applyFix(fix);
      expect(applied, isFalse);
      expect(confirmCalled, isTrue);
      expect(File(filePath).readAsStringSync(), equals('line1\n'));
    });
  });
}
