import 'package:flutter_memory_doctor/src/models/memory_sample.dart';
import 'package:test/test.dart';

void main() {
  group('MemorySample', () {
    test('toJson/fromJson round-trip', () {
      final sample = MemorySample(
        timestamp: DateTime(2024, 6, 15, 12, 30, 0),
        heapUsage: 10485760,
        heapCapacity: 20971520,
        externalUsage: 1048576,
        gcOccurred: true,
      );

      final json = sample.toJson();
      final restored = MemorySample.fromJson(json);

      expect(restored.timestamp, equals(sample.timestamp));
      expect(restored.heapUsage, equals(sample.heapUsage));
      expect(restored.heapCapacity, equals(sample.heapCapacity));
      expect(restored.externalUsage, equals(sample.externalUsage));
      expect(restored.gcOccurred, equals(sample.gcOccurred));
    });

    test('totalUsage is heap + external', () {
      final sample = MemorySample(
        timestamp: DateTime.now(),
        heapUsage: 1000,
        heapCapacity: 2000,
        externalUsage: 500,
      );

      expect(sample.totalUsage, equals(1500));
    });

    test('heapUtilization is usage/capacity', () {
      final sample = MemorySample(
        timestamp: DateTime.now(),
        heapUsage: 1000,
        heapCapacity: 2000,
        externalUsage: 0,
      );

      expect(sample.heapUtilization, equals(0.5));
    });

    test('heapUtilization is 0 when capacity is 0', () {
      final sample = MemorySample(
        timestamp: DateTime.now(),
        heapUsage: 0,
        heapCapacity: 0,
        externalUsage: 0,
      );

      expect(sample.heapUtilization, equals(0.0));
    });

    test('gcOccurred defaults to false', () {
      final sample = MemorySample(
        timestamp: DateTime.now(),
        heapUsage: 1000,
        heapCapacity: 2000,
        externalUsage: 500,
      );

      expect(sample.gcOccurred, isFalse);
    });

    test('toString formats correctly', () {
      final sample = MemorySample(
        timestamp: DateTime.now(),
        heapUsage: 1048576,
        heapCapacity: 2097152,
        externalUsage: 512,
      );

      final str = sample.toString();
      expect(str, contains('1.0MB'));
      expect(str, contains('2.0MB'));
      expect(str, contains('512B'));
    });
  });
}
