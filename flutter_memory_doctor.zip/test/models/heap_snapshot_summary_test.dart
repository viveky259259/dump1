import 'package:flutter_memory_doctor/src/models/heap_snapshot_summary.dart';
import 'package:test/test.dart';

void main() {
  group('HeapSnapshotSummary', () {
    test('diff computes deltas correctly', () {
      final older = HeapSnapshotSummary(
        timestamp: DateTime(2024, 1, 1, 12, 0, 0),
        totalSize: 10000,
        totalObjects: 500,
        totalExternalSize: 1000,
        classes: [
          ClassSummary(
            className: 'Widget',
            libraryUri: 'package:app/widget.dart',
            instanceCount: 100,
            shallowSize: 5000,
            retainedSize: 7000,
          ),
          ClassSummary(
            className: 'String',
            libraryUri: 'dart:core',
            instanceCount: 200,
            shallowSize: 3000,
            retainedSize: 3000,
          ),
        ],
      );

      final newer = HeapSnapshotSummary(
        timestamp: DateTime(2024, 1, 1, 12, 0, 30),
        totalSize: 15000,
        totalObjects: 700,
        totalExternalSize: 1200,
        classes: [
          ClassSummary(
            className: 'Widget',
            libraryUri: 'package:app/widget.dart',
            instanceCount: 150,
            shallowSize: 7500,
            retainedSize: 10500,
          ),
          ClassSummary(
            className: 'String',
            libraryUri: 'dart:core',
            instanceCount: 200,
            shallowSize: 3000,
            retainedSize: 3000,
          ),
          ClassSummary(
            className: 'NewClass',
            libraryUri: 'package:app/new.dart',
            instanceCount: 50,
            shallowSize: 2500,
            retainedSize: 4000,
          ),
        ],
      );

      final diff = newer.diff(older);

      expect(diff.totalSizeDelta, equals(5000));
      expect(diff.totalObjectsDelta, equals(200));
      expect(diff.timeSpan.inSeconds, equals(30));
      expect(diff.newClasses, hasLength(1));
      expect(diff.newClasses.first.className, equals('NewClass'));

      final widgetDiff = diff.classDiffs.firstWhere(
        (d) => d.className == 'Widget',
      );
      expect(widgetDiff.instanceDelta, equals(50));
      expect(widgetDiff.retainedSizeDelta, equals(3500));

      expect(diff.growingClasses, hasLength(1));
      expect(diff.growingClasses.first.className, equals('Widget'));
    });

    test('toJson/fromJson round-trip', () {
      final summary = HeapSnapshotSummary(
        timestamp: DateTime(2024, 6, 15, 12, 0, 0),
        totalSize: 10000,
        totalObjects: 500,
        totalExternalSize: 1000,
        classes: [
          ClassSummary(
            className: 'Widget',
            libraryUri: 'package:app/widget.dart',
            instanceCount: 100,
            shallowSize: 5000,
            retainedSize: 7000,
          ),
        ],
      );

      final json = summary.toJson();
      final restored = HeapSnapshotSummary.fromJson(json);

      expect(restored.totalSize, equals(summary.totalSize));
      expect(restored.totalObjects, equals(summary.totalObjects));
      expect(restored.classes, hasLength(1));
      expect(restored.classes.first.className, equals('Widget'));
    });

    test('topByRetainedSize sorts correctly', () {
      final summary = HeapSnapshotSummary(
        timestamp: DateTime.now(),
        totalSize: 20000,
        totalObjects: 300,
        totalExternalSize: 0,
        classes: [
          ClassSummary(
            className: 'Small',
            libraryUri: 'a',
            instanceCount: 10,
            shallowSize: 100,
            retainedSize: 100,
          ),
          ClassSummary(
            className: 'Large',
            libraryUri: 'b',
            instanceCount: 5,
            shallowSize: 10000,
            retainedSize: 15000,
          ),
          ClassSummary(
            className: 'Medium',
            libraryUri: 'c',
            instanceCount: 50,
            shallowSize: 5000,
            retainedSize: 5000,
          ),
        ],
      );

      final top = summary.topByRetainedSize;
      expect(top.first.className, equals('Large'));
      expect(top.last.className, equals('Small'));
    });
  });
}
