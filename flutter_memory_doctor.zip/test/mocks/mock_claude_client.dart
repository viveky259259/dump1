import 'dart:convert';

import 'package:flutter_memory_doctor/src/analysis/claude_client.dart';
import 'package:http/http.dart' as http;

/// A mock Claude client for testing without API calls.
class MockClaudeClient extends ClaudeClient {
  MockClaudeClient()
      : super(
          apiKey: 'mock-api-key',
          model: 'mock-model',
        );

  /// The response to return from [sendMessage].
  Map<String, dynamic>? nextJsonResponse;

  /// The text to return from [ask].
  String? nextTextResponse;

  /// Whether to throw on the next call.
  bool shouldThrow = false;

  /// Count of calls made.
  int callCount = 0;

  /// Last system prompt received.
  String? lastSystemPrompt;

  /// Last user message received.
  String? lastUserMessage;

  @override
  Future<ClaudeResponse> sendMessage({
    required String systemPrompt,
    required String userMessage,
  }) async {
    callCount++;
    lastSystemPrompt = systemPrompt;
    lastUserMessage = userMessage;

    if (shouldThrow) {
      throw ClaudeApiException(statusCode: 500, message: 'Mock error');
    }

    final text = nextTextResponse ??
        jsonEncode(nextJsonResponse ?? _defaultResponse());

    return ClaudeResponse(
      id: 'mock-${callCount}',
      model: 'mock-model',
      content: [ContentBlock(type: 'text', text: text)],
      stopReason: 'end_turn',
      usage: TokenUsage(inputTokens: 100, outputTokens: 50),
    );
  }

  @override
  Future<String> ask({
    required String systemPrompt,
    required String userMessage,
  }) async {
    final response = await sendMessage(
      systemPrompt: systemPrompt,
      userMessage: userMessage,
    );
    return response.textContent;
  }

  @override
  Future<Map<String, dynamic>> askJson({
    required String systemPrompt,
    required String userMessage,
  }) async {
    callCount++;
    lastSystemPrompt = systemPrompt;
    lastUserMessage = userMessage;

    if (shouldThrow) {
      throw ClaudeApiException(statusCode: 500, message: 'Mock error');
    }

    return nextJsonResponse ?? _defaultResponse();
  }

  Map<String, dynamic> _defaultResponse() => {
        'severity': 'warning',
        'summary': 'Potential memory leak detected in MyWidget',
        'diagnosis': 'MyWidget instances are growing linearly.',
        'leaks': [
          {
            'className': 'MyWidget',
            'libraryUri': 'package:my_app/my_widget.dart',
            'growthRate': 250.0,
            'confidence': 0.85,
            'evidence': ['Instance count growing at 5/sec'],
          }
        ],
        'suggestions': [
          'Check MyWidget.dispose() for missing cleanup.',
          'Ensure StreamSubscriptions are cancelled.',
        ],
      };

  @override
  void dispose() {}
}

/// A mock HTTP client for testing ClaudeClient directly.
class MockHttpClient extends http.BaseClient {
  int statusCode = 200;
  Map<String, dynamic>? responseBody;
  http.BaseRequest? lastRequest;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    lastRequest = request;

    final body = responseBody ??
        {
          'id': 'msg_mock',
          'model': 'mock-model',
          'content': [
            {'type': 'text', 'text': 'Mock response'}
          ],
          'stop_reason': 'end_turn',
          'usage': {'input_tokens': 100, 'output_tokens': 50},
        };

    return http.StreamedResponse(
      Stream.value(utf8.encode(jsonEncode(body))),
      statusCode,
      headers: {'content-type': 'application/json'},
    );
  }
}
