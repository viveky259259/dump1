import 'dart:async';

import 'package:vm_service/vm_service.dart';

/// A mock VmService for testing without a real Dart VM connection.
class MockVmService implements VmService {
  int _heapUsage = 10 * 1024 * 1024; // 10MB
  int _heapCapacity = 20 * 1024 * 1024; // 20MB
  int _externalUsage = 1 * 1024 * 1024; // 1MB
  int _callCount = 0;

  /// Growth per call in bytes (simulate leak).
  int heapGrowthPerCall = 0;

  /// Whether to simulate errors.
  bool simulateErrors = false;

  final _gcController = StreamController<Event>.broadcast();
  final _isolateController = StreamController<Event>.broadcast();

  void emitGcEvent() {
    _gcController.add(Event(
      kind: EventKind.kGC,
      timestamp: DateTime.now().millisecondsSinceEpoch,
      isolate: IsolateRef(
        id: 'isolates/1',
        number: '1',
        name: 'main',
        isSystemIsolate: false,
      ),
    ));
  }

  @override
  Future<MemoryUsage> getMemoryUsage(String isolateId) async {
    if (simulateErrors) throw RPCError('getMemoryUsage', 100, 'Simulated error');

    _callCount++;
    _heapUsage += heapGrowthPerCall;

    return MemoryUsage(
      heapUsage: _heapUsage,
      heapCapacity: _heapCapacity,
      externalUsage: _externalUsage,
    );
  }

  @override
  Future<AllocationProfile> getAllocationProfile(
    String isolateId, {
    bool? gc,
    bool? reset,
  }) async {
    return AllocationProfile(
      members: [
        ClassHeapStats(
          classRef: ClassRef(
            id: 'classes/1',
            name: 'MyWidget',
            library: LibraryRef(
              id: 'libs/1',
              name: 'my_app',
              uri: 'package:my_app/my_widget.dart',
            ),
          ),
          instancesCurrent: 100 + _callCount * 5,
          instancesAccumulated: 200 + _callCount * 5,
          bytesCurrent: 5000 + _callCount * 250,
          accumulatedSize: 10000 + _callCount * 250,
        ),
        ClassHeapStats(
          classRef: ClassRef(
            id: 'classes/2',
            name: 'String',
            library: LibraryRef(
              id: 'libs/2',
              name: 'dart:core',
              uri: 'dart:core',
            ),
          ),
          instancesCurrent: 5000,
          instancesAccumulated: 8000,
          bytesCurrent: 100000,
          accumulatedSize: 160000,
        ),
      ],
      dateLastServiceGC: DateTime.now().millisecondsSinceEpoch,
    );
  }

  @override
  Future<VM> getVM() async {
    return VM(
      isolates: [
        IsolateRef(
          id: 'isolates/1',
          number: '1',
          name: 'main',
          isSystemIsolate: false,
        ),
      ],
      name: 'vm',
      architectureBits: 64,
      hostCPU: 'x64',
      operatingSystem: 'macos',
      targetCPU: 'x64',
      version: '3.0.0',
      pid: 1234,
      startTime: DateTime.now().millisecondsSinceEpoch,
    );
  }

  @override
  Future<Success> streamListen(String streamId) async {
    return Success();
  }

  @override
  Future<Success> streamCancel(String streamId) async {
    return Success();
  }

  @override
  Stream<Event> get onGCEvent => _gcController.stream;

  @override
  Stream<Event> get onIsolateEvent => _isolateController.stream;

  @override
  Future<void> get onDone => Completer<void>().future;

  @override
  Future<void> dispose() async {
    await _gcController.close();
    await _isolateController.close();
  }

  // -- Stubs for other VmService methods --

  @override
  dynamic noSuchMethod(Invocation invocation) {
    throw UnimplementedError(
      'MockVmService.${invocation.memberName} is not implemented',
    );
  }
}
