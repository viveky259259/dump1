import 'package:flutter_memory_doctor/src/analysis/memory_analyzer.dart';
import 'package:flutter_memory_doctor/src/models/allocation_record.dart';
import 'package:flutter_memory_doctor/src/models/analysis_result.dart';
import 'package:flutter_memory_doctor/src/models/memory_sample.dart';
import 'package:test/test.dart';

void main() {
  group('MemoryAnalyzer', () {
    group('detectMonotonicGrowth', () {
      test('returns false for empty samples', () {
        expect(MemoryAnalyzer.detectMonotonicGrowth([]), isFalse);
      });

      test('returns false for too few samples', () {
        final samples = List.generate(
          10,
          (i) => _makeSample(heapUsage: i * 1000),
        );
        expect(MemoryAnalyzer.detectMonotonicGrowth(samples), isFalse);
      });

      test('detects monotonic growth over threshold', () {
        final samples = List.generate(
          35,
          (i) => _makeSample(heapUsage: 1000 + i * 100),
        );
        expect(MemoryAnalyzer.detectMonotonicGrowth(samples), isTrue);
      });

      test('returns false for fluctuating values', () {
        final samples = List.generate(
          35,
          (i) => _makeSample(heapUsage: 1000 + (i % 2 == 0 ? 100 : -50)),
        );
        expect(MemoryAnalyzer.detectMonotonicGrowth(samples), isFalse);
      });

      test('returns false for stable values', () {
        final samples = List.generate(
          35,
          (i) => _makeSample(heapUsage: 5000),
        );
        expect(MemoryAnalyzer.detectMonotonicGrowth(samples), isFalse);
      });
    });

    group('detectLeakingClasses', () {
      test('returns empty for insufficient data', () {
        expect(MemoryAnalyzer.detectLeakingClasses([]), isEmpty);
        expect(
          MemoryAnalyzer.detectLeakingClasses([_makeAllocation(0)]),
          isEmpty,
        );
      });

      test('detects linearly growing class', () {
        final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
        final records = List.generate(10, (i) {
          return AllocationRecord(
            timestamp: baseTime.add(Duration(seconds: i)),
            classes: [
              ClassAllocationInfo(
                className: 'LeakyWidget',
                libraryUri: 'package:app/leaky.dart',
                instancesCurrent: 100 + i * 10,
                instancesAccumulated: 200 + i * 10,
                bytesCurrent: 5000 + i * 500,
                bytesAccumulated: 10000,
              ),
              ClassAllocationInfo(
                className: 'StableWidget',
                libraryUri: 'package:app/stable.dart',
                instancesCurrent: 50,
                instancesAccumulated: 100,
                bytesCurrent: 2500,
                bytesAccumulated: 5000,
              ),
            ],
          );
        });

        final leaks = MemoryAnalyzer.detectLeakingClasses(records);
        expect(leaks, hasLength(1));
        expect(leaks.first.className, equals('LeakyWidget'));
        expect(leaks.first.confidence, greaterThan(0.8));
      });

      test('does not flag stable classes', () {
        final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
        final records = List.generate(10, (i) {
          return AllocationRecord(
            timestamp: baseTime.add(Duration(seconds: i)),
            classes: [
              ClassAllocationInfo(
                className: 'StableWidget',
                libraryUri: 'package:app/stable.dart',
                instancesCurrent: 50 + (i % 3 - 1), // slight fluctuation
                instancesAccumulated: 100,
                bytesCurrent: 2500,
                bytesAccumulated: 5000,
              ),
            ],
          );
        });

        final leaks = MemoryAnalyzer.detectLeakingClasses(records);
        expect(leaks, isEmpty);
      });
    });

    group('detectMemorySpikes', () {
      test('returns empty for stable memory', () {
        final samples = List.generate(
          10,
          (i) => MemorySample(
            timestamp: DateTime(2024, 1, 1, 12, 0, i),
            heapUsage: 5000000,
            heapCapacity: 10000000,
            externalUsage: 500000,
          ),
        );
        expect(MemoryAnalyzer.detectMemorySpikes(samples), isEmpty);
      });

      test('detects >2x spike within 5 seconds', () {
        final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
        final samples = [
          MemorySample(
            timestamp: baseTime,
            heapUsage: 5000000,
            heapCapacity: 10000000,
            externalUsage: 500000,
          ),
          MemorySample(
            timestamp: baseTime.add(const Duration(seconds: 2)),
            heapUsage: 11000000, // >2x
            heapCapacity: 20000000,
            externalUsage: 500000,
          ),
        ];

        final spikes = MemoryAnalyzer.detectMemorySpikes(samples);
        expect(spikes, hasLength(1));
        expect(spikes.first.multiplier, greaterThan(2.0));
      });

      test('ignores gradual growth', () {
        final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
        final samples = List.generate(20, (i) {
          return MemorySample(
            timestamp: baseTime.add(Duration(seconds: i)),
            heapUsage: 5000000 + i * 100000,
            heapCapacity: 20000000,
            externalUsage: 500000,
          );
        });

        final spikes = MemoryAnalyzer.detectMemorySpikes(samples);
        expect(spikes, isEmpty);
      });
    });

    group('computeGrowthRates', () {
      test('returns empty for insufficient data', () {
        expect(MemoryAnalyzer.computeGrowthRates([]), isEmpty);
      });

      test('computes bytes/sec growth', () {
        final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
        final records = [
          AllocationRecord(
            timestamp: baseTime,
            classes: [
              ClassAllocationInfo(
                className: 'Widget',
                libraryUri: 'package:app/widget.dart',
                instancesCurrent: 100,
                instancesAccumulated: 200,
                bytesCurrent: 10000,
                bytesAccumulated: 20000,
              ),
            ],
          ),
          AllocationRecord(
            timestamp: baseTime.add(const Duration(seconds: 10)),
            classes: [
              ClassAllocationInfo(
                className: 'Widget',
                libraryUri: 'package:app/widget.dart',
                instancesCurrent: 200,
                instancesAccumulated: 400,
                bytesCurrent: 20000,
                bytesAccumulated: 40000,
              ),
            ],
          ),
        ];

        final rates = MemoryAnalyzer.computeGrowthRates(records);
        expect(rates['Widget'], equals(1000.0)); // 10000 bytes / 10 sec
      });
    });

    group('analyze', () {
      test('returns healthy for stable memory', () {
        final samples = List.generate(
          10,
          (i) => _makeSample(heapUsage: 5000),
        );

        final result = MemoryAnalyzer.analyze(
          samples: samples,
          allocations: [],
        );

        expect(result.severity, equals(AnalysisSeverity.healthy));
        expect(result.leaks, isEmpty);
      });

      test('returns warning for monotonic growth with leaks', () {
        final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
        final samples = List.generate(
          35,
          (i) => MemorySample(
            timestamp: baseTime.add(Duration(seconds: i)),
            heapUsage: 1000 + i * 100,
            heapCapacity: 10000,
            externalUsage: 500,
          ),
        );

        final allocations = List.generate(10, (i) {
          return AllocationRecord(
            timestamp: baseTime.add(Duration(seconds: i * 3)),
            classes: [
              ClassAllocationInfo(
                className: 'Leaker',
                libraryUri: 'package:app/leaker.dart',
                instancesCurrent: 100 + i * 20,
                instancesAccumulated: 300,
                bytesCurrent: 5000 + i * 1000,
                bytesAccumulated: 15000,
              ),
            ],
          );
        });

        final result = MemoryAnalyzer.analyze(
          samples: samples,
          allocations: allocations,
        );

        // Critical because leaking class has high confidence (>0.9)
        expect(result.severity,
            anyOf(equals(AnalysisSeverity.warning), equals(AnalysisSeverity.critical)));
        expect(result.leaks, isNotEmpty);
        expect(result.suggestions, isNotEmpty);
      });
    });
  });
}

MemorySample _makeSample({required int heapUsage}) {
  return MemorySample(
    timestamp: DateTime.now(),
    heapUsage: heapUsage,
    heapCapacity: heapUsage * 2,
    externalUsage: 500,
  );
}

AllocationRecord _makeAllocation(int offset) {
  return AllocationRecord(
    timestamp: DateTime.now().add(Duration(seconds: offset)),
    classes: [
      ClassAllocationInfo(
        className: 'Widget',
        libraryUri: 'package:app/widget.dart',
        instancesCurrent: 100,
        instancesAccumulated: 200,
        bytesCurrent: 5000,
        bytesAccumulated: 10000,
      ),
    ],
  );
}
