import 'dart:convert';

import 'package:flutter_memory_doctor/src/analysis/claude_prompts.dart';
import 'package:flutter_memory_doctor/src/models/allocation_record.dart';
import 'package:flutter_memory_doctor/src/models/analysis_result.dart';
import 'package:flutter_memory_doctor/src/models/heap_snapshot_summary.dart';
import 'package:flutter_memory_doctor/src/models/leak_candidate.dart';
import 'package:flutter_memory_doctor/src/models/memory_sample.dart';
import 'package:test/test.dart';

void main() {
  group('ClaudePrompts', () {
    test('buildTrendAnalysisPrompt produces valid JSON', () {
      final samples = List.generate(5, (i) {
        return MemorySample(
          timestamp: DateTime(2024, 1, 1, 12, 0, i),
          heapUsage: 1000 + i * 100,
          heapCapacity: 5000,
          externalUsage: 200,
        );
      });

      final allocations = [
        AllocationRecord(
          timestamp: DateTime(2024, 1, 1, 12, 0, 0),
          classes: [
            ClassAllocationInfo(
              className: 'Widget',
              libraryUri: 'package:app/w.dart',
              instancesCurrent: 50,
              instancesAccumulated: 100,
              bytesCurrent: 2500,
              bytesAccumulated: 5000,
            ),
          ],
        ),
      ];

      final prompt = ClaudePrompts.buildTrendAnalysisPrompt(
        samples: samples,
        allocations: allocations,
        growthRates: {'Widget': 100.0},
        localLeaks: [],
      );

      // Should be valid JSON
      final parsed = jsonDecode(prompt) as Map<String, dynamic>;
      expect(parsed['task'], equals('memory_trend_analysis'));
      expect(parsed['samples'], hasLength(5));
      expect(parsed['topClasses'], hasLength(1));
      expect(parsed['growthRates'], hasLength(1));
    });

    test('buildSnapshotDiffPrompt produces valid JSON', () {
      final diff = HeapSnapshotDiff(
        olderTimestamp: DateTime(2024, 1, 1, 12, 0, 0),
        newerTimestamp: DateTime(2024, 1, 1, 12, 0, 30),
        totalSizeDelta: 5000,
        totalObjectsDelta: 100,
        classDiffs: [
          ClassDiff(
            className: 'Widget',
            libraryUri: 'package:app/w.dart',
            instanceDelta: 10,
            retainedSizeDelta: 500,
            shallowSizeDelta: 300,
          ),
        ],
        newClasses: [],
      );

      final prompt = ClaudePrompts.buildSnapshotDiffPrompt(diff: diff);
      final parsed = jsonDecode(prompt) as Map<String, dynamic>;
      expect(parsed['task'], equals('heap_snapshot_diff'));
      expect(parsed['timeSpanSeconds'], equals(30));
      expect(parsed['growingClasses'], hasLength(1));
    });

    test('buildFixGenerationPrompt includes source files', () {
      final analysis = AnalysisResult(
        timestamp: DateTime.now(),
        severity: AnalysisSeverity.warning,
        summary: 'Leak detected',
        diagnosis: 'Widget leaking',
        leaks: [
          LeakCandidate(
            className: 'Widget',
            libraryUri: 'package:app/w.dart',
            growthRate: 100,
            confidence: 0.9,
            evidence: ['Growing linearly'],
          ),
        ],
        suggestions: ['Fix it'],
      );

      final prompt = ClaudePrompts.buildFixGenerationPrompt(
        analysis: analysis,
        sourceFiles: {
          'lib/widget.dart': 'class Widget {}',
        },
      );

      final parsed = jsonDecode(prompt) as Map<String, dynamic>;
      expect(parsed['task'], equals('generate_fixes'));
      expect(parsed['sourceFiles'], hasLength(1));
      expect(parsed['leaks'], hasLength(1));
    });

    test('downsamples large sample sets', () {
      final samples = List.generate(200, (i) {
        return MemorySample(
          timestamp: DateTime(2024, 1, 1, 12, 0, 0)
              .add(Duration(seconds: i)),
          heapUsage: 1000 + i,
          heapCapacity: 5000,
          externalUsage: 200,
        );
      });

      final prompt = ClaudePrompts.buildTrendAnalysisPrompt(
        samples: samples,
        allocations: [],
        growthRates: {},
        localLeaks: [],
      );

      final parsed = jsonDecode(prompt) as Map<String, dynamic>;
      final sampleList = parsed['samples'] as List;
      // Should be downsampled to <= 61 (60 + possible last)
      expect(sampleList.length, lessThanOrEqualTo(61));
    });
  });
}
