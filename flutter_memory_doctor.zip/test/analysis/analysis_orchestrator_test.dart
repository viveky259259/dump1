import 'package:flutter_memory_doctor/src/analysis/analysis_orchestrator.dart';
import 'package:flutter_memory_doctor/src/collector/memory_collector.dart';
import 'package:flutter_memory_doctor/src/models/analysis_result.dart';
import 'package:flutter_memory_doctor/src/models/memory_sample.dart';
import 'package:test/test.dart';

import '../mocks/mock_claude_client.dart';

void main() {
  group('AnalysisOrchestrator', () {
    late MemoryDataStore dataStore;
    late MockClaudeClient mockClaude;
    late AnalysisOrchestrator orchestrator;

    setUp(() {
      dataStore = MemoryDataStore();
      mockClaude = MockClaudeClient();
      orchestrator = AnalysisOrchestrator(
        dataStore: dataStore,
        claudeClient: mockClaude,
      );
    });

    tearDown(() {
      dataStore.dispose();
    });

    test('analyzeLocal returns healthy for empty data', () {
      final result = orchestrator.analyzeLocal();
      expect(result.severity, equals(AnalysisSeverity.healthy));
    });

    test('analyzeLocal detects issues in data', () {
      final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
      for (var i = 0; i < 35; i++) {
        dataStore.addSample(MemorySample(
          timestamp: baseTime.add(Duration(seconds: i)),
          heapUsage: 1000 + i * 100,
          heapCapacity: 10000,
          externalUsage: 500,
        ));
      }

      final result = orchestrator.analyzeLocal();
      expect(result.severity, isNot(equals(AnalysisSeverity.healthy)));
    });

    test('analyzeWithClaude calls Claude API', () async {
      // Add some data
      for (var i = 0; i < 10; i++) {
        dataStore.addSample(MemorySample(
          timestamp: DateTime.now().add(Duration(seconds: i)),
          heapUsage: 1000 + i * 100,
          heapCapacity: 10000,
          externalUsage: 500,
        ));
      }

      final result = await orchestrator.analyzeWithClaude();
      expect(result.severity, equals(AnalysisSeverity.warning));
      expect(result.leaks, hasLength(1));
      expect(result.leaks.first.className, equals('MyWidget'));
      expect(mockClaude.callCount, equals(1));
    });

    test('analyzeWithClaude falls back to local on API error', () async {
      mockClaude.shouldThrow = true;

      for (var i = 0; i < 10; i++) {
        dataStore.addSample(MemorySample(
          timestamp: DateTime.now().add(Duration(seconds: i)),
          heapUsage: 5000,
          heapCapacity: 10000,
          externalUsage: 500,
        ));
      }

      final result = await orchestrator.analyzeWithClaude();
      // Falls back to local analysis
      expect(result, isNotNull);
      expect(result.severity, equals(AnalysisSeverity.healthy));
    });

    test('analyzeWithClaude returns local-only when no client', () async {
      final localOrchestrator = AnalysisOrchestrator(
        dataStore: dataStore,
        claudeClient: null,
      );

      final result = await localOrchestrator.analyzeWithClaude();
      expect(result, isNotNull);
    });

    test('lastResult is updated after analysis', () async {
      expect(orchestrator.lastResult, isNull);

      orchestrator.analyzeLocal();
      expect(orchestrator.lastResult, isNotNull);
    });

    test('generateFixes throws without Claude client', () async {
      final localOrchestrator = AnalysisOrchestrator(
        dataStore: dataStore,
        claudeClient: null,
      );

      final analysis = AnalysisResult(
        timestamp: DateTime.now(),
        severity: AnalysisSeverity.warning,
        summary: 'test',
        diagnosis: 'test',
        leaks: [],
        suggestions: [],
      );

      expect(
        () => localOrchestrator.generateFixes(
          analysis: analysis,
          sourceFiles: {},
        ),
        throwsStateError,
      );
    });

    test('generateFixes returns patches from Claude', () async {
      mockClaude.nextJsonResponse = {
        'fixes': [
          {
            'filePath': 'lib/my_widget.dart',
            'startLine': 10,
            'endLine': 15,
            'originalCode': 'old code',
            'patchedCode': 'new code',
            'explanation': 'Fixed leak',
            'leakClassName': 'MyWidget',
          }
        ],
      };

      final analysis = AnalysisResult(
        timestamp: DateTime.now(),
        severity: AnalysisSeverity.warning,
        summary: 'test',
        diagnosis: 'test',
        leaks: [],
        suggestions: [],
      );

      final fixes = await orchestrator.generateFixes(
        analysis: analysis,
        sourceFiles: {'lib/my_widget.dart': 'source code'},
      );

      expect(fixes, hasLength(1));
      expect(fixes.first.filePath, equals('lib/my_widget.dart'));
      expect(fixes.first.explanation, equals('Fixed leak'));
    });
  });
}
