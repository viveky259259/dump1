import 'dart:convert';

import 'package:flutter_memory_doctor/src/analysis/claude_client.dart';
import 'package:test/test.dart';

import '../mocks/mock_claude_client.dart';

void main() {
  group('ClaudeClient', () {
    group('with MockHttpClient', () {
      late MockHttpClient mockHttp;
      late ClaudeClient client;

      setUp(() {
        mockHttp = MockHttpClient();
        client = ClaudeClient(
          apiKey: 'test-key',
          model: 'test-model',
          httpClient: mockHttp,
        );
      });

      tearDown(() {
        client.dispose();
      });

      test('sends correct headers', () async {
        mockHttp.responseBody = {
          'id': 'msg_1',
          'model': 'test-model',
          'content': [
            {'type': 'text', 'text': 'response'}
          ],
          'stop_reason': 'end_turn',
          'usage': {'input_tokens': 10, 'output_tokens': 5},
        };

        await client.sendMessage(
          systemPrompt: 'system',
          userMessage: 'user',
        );

        final request = mockHttp.lastRequest!;
        expect(request.headers['x-api-key'], equals('test-key'));
        expect(request.headers['anthropic-version'], equals('2023-06-01'));
        expect(request.headers['Content-Type'], equals('application/json'));
      });

      test('parses response correctly', () async {
        mockHttp.responseBody = {
          'id': 'msg_test',
          'model': 'test-model',
          'content': [
            {'type': 'text', 'text': 'Hello world'}
          ],
          'stop_reason': 'end_turn',
          'usage': {'input_tokens': 100, 'output_tokens': 50},
        };

        final response = await client.sendMessage(
          systemPrompt: 'system',
          userMessage: 'user',
        );

        expect(response.id, equals('msg_test'));
        expect(response.textContent, equals('Hello world'));
        expect(response.usage.totalTokens, equals(150));
      });

      test('throws on non-200 status', () async {
        mockHttp.statusCode = 401;
        mockHttp.responseBody = {'error': 'unauthorized'};

        expect(
          () => client.sendMessage(
            systemPrompt: 'system',
            userMessage: 'user',
          ),
          throwsA(isA<ClaudeApiException>()),
        );
      });

      test('askJson parses JSON from response', () async {
        final jsonData = {'key': 'value', 'num': 42};
        mockHttp.responseBody = {
          'id': 'msg_1',
          'model': 'test-model',
          'content': [
            {'type': 'text', 'text': jsonEncode(jsonData)}
          ],
          'stop_reason': 'end_turn',
          'usage': {'input_tokens': 10, 'output_tokens': 5},
        };

        final result = await client.askJson(
          systemPrompt: 'system',
          userMessage: 'user',
        );

        expect(result['key'], equals('value'));
        expect(result['num'], equals(42));
      });

      test('askJson extracts JSON from markdown code blocks', () async {
        final jsonData = {'extracted': true};
        mockHttp.responseBody = {
          'id': 'msg_1',
          'model': 'test-model',
          'content': [
            {
              'type': 'text',
              'text': 'Here is the result:\n```json\n${jsonEncode(jsonData)}\n```',
            }
          ],
          'stop_reason': 'end_turn',
          'usage': {'input_tokens': 10, 'output_tokens': 5},
        };

        final result = await client.askJson(
          systemPrompt: 'system',
          userMessage: 'user',
        );

        expect(result['extracted'], isTrue);
      });
    });

    group('MockClaudeClient', () {
      late MockClaudeClient mockClient;

      setUp(() {
        mockClient = MockClaudeClient();
      });

      test('returns default response', () async {
        final result = await mockClient.askJson(
          systemPrompt: 'system',
          userMessage: 'user',
        );

        expect(result['severity'], equals('warning'));
        expect(result['leaks'], isNotEmpty);
      });

      test('tracks call count', () async {
        await mockClient.ask(
          systemPrompt: 'system',
          userMessage: 'msg1',
        );
        await mockClient.ask(
          systemPrompt: 'system',
          userMessage: 'msg2',
        );

        expect(mockClient.callCount, equals(2));
      });

      test('throws when configured', () async {
        mockClient.shouldThrow = true;

        expect(
          () => mockClient.askJson(
            systemPrompt: 'system',
            userMessage: 'user',
          ),
          throwsA(isA<ClaudeApiException>()),
        );
      });

      test('returns custom response', () async {
        mockClient.nextJsonResponse = {'custom': true};

        final result = await mockClient.askJson(
          systemPrompt: 'system',
          userMessage: 'user',
        );

        expect(result['custom'], isTrue);
      });
    });
  });
}
