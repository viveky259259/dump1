import 'dart:convert';

import 'package:flutter_memory_doctor/src/analysis/analysis_orchestrator.dart';
import 'package:flutter_memory_doctor/src/collector/memory_collector.dart';
import 'package:flutter_memory_doctor/src/dashboard/api_routes.dart';
import 'package:flutter_memory_doctor/src/dashboard/sse_handler.dart';
import 'package:flutter_memory_doctor/src/models/memory_sample.dart';
import 'package:shelf/shelf.dart';
import 'package:test/test.dart';

void main() {
  group('ApiRoutes', () {
    late MemoryDataStore dataStore;
    late AnalysisOrchestrator orchestrator;
    late SseHandler sseHandler;
    late ApiRoutes apiRoutes;

    setUp(() {
      dataStore = MemoryDataStore();
      orchestrator = AnalysisOrchestrator(
        dataStore: dataStore,
        claudeClient: null,
      );
      sseHandler = SseHandler();
      apiRoutes = ApiRoutes(
        dataStore: dataStore,
        orchestrator: orchestrator,
        sseHandler: sseHandler,
      );
    });

    tearDown(() {
      dataStore.dispose();
    });

    test('GET /api/samples returns empty list initially', () async {
      final handler = apiRoutes.router.call;
      final request = Request('GET', Uri.parse('http://localhost/api/samples'));
      final response = await handler(request);

      expect(response.statusCode, equals(200));
      final body = jsonDecode(await response.readAsString());
      expect(body, isEmpty);
    });

    test('GET /api/samples returns stored samples', () async {
      dataStore.addSample(MemorySample(
        timestamp: DateTime(2024, 1, 1, 12, 0, 0),
        heapUsage: 1000,
        heapCapacity: 2000,
        externalUsage: 500,
      ));

      final handler = apiRoutes.router.call;
      final request = Request('GET', Uri.parse('http://localhost/api/samples'));
      final response = await handler(request);

      expect(response.statusCode, equals(200));
      final body = jsonDecode(await response.readAsString()) as List;
      expect(body, hasLength(1));
      expect(body.first['heapUsage'], equals(1000));
    });

    test('GET /api/samples?count=N limits results', () async {
      for (var i = 0; i < 10; i++) {
        dataStore.addSample(MemorySample(
          timestamp: DateTime.now().add(Duration(seconds: i)),
          heapUsage: i * 1000,
          heapCapacity: 20000,
          externalUsage: 500,
        ));
      }

      final handler = apiRoutes.router.call;
      final request = Request(
        'GET',
        Uri.parse('http://localhost/api/samples?count=3'),
      );
      final response = await handler(request);

      expect(response.statusCode, equals(200));
      final body = jsonDecode(await response.readAsString()) as List;
      expect(body, hasLength(3));
    });

    test('GET /api/status returns status info', () async {
      dataStore.addSample(MemorySample(
        timestamp: DateTime.now(),
        heapUsage: 5000,
        heapCapacity: 10000,
        externalUsage: 1000,
      ));

      final handler = apiRoutes.router.call;
      final request = Request('GET', Uri.parse('http://localhost/api/status'));
      final response = await handler(request);

      expect(response.statusCode, equals(200));
      final body =
          jsonDecode(await response.readAsString()) as Map<String, dynamic>;
      expect(body['connected'], isTrue);
      expect(body['sampleCount'], equals(1));
      expect(body['hasAnalysis'], isFalse);
    });

    test('POST /api/analyze runs analysis', () async {
      for (var i = 0; i < 10; i++) {
        dataStore.addSample(MemorySample(
          timestamp: DateTime.now().add(Duration(seconds: i)),
          heapUsage: 5000,
          heapCapacity: 10000,
          externalUsage: 500,
        ));
      }

      final handler = apiRoutes.router.call;
      final request = Request(
        'POST',
        Uri.parse('http://localhost/api/analyze'),
        body: jsonEncode({'useClaude': false}),
      );
      final response = await handler(request);

      expect(response.statusCode, equals(200));
      final body =
          jsonDecode(await response.readAsString()) as Map<String, dynamic>;
      expect(body['severity'], isNotNull);
      expect(body['summary'], isNotNull);
    });

    test('GET /api/analysis returns no_analysis_yet initially', () async {
      final handler = apiRoutes.router.call;
      final request =
          Request('GET', Uri.parse('http://localhost/api/analysis'));
      final response = await handler(request);

      expect(response.statusCode, equals(200));
      final body =
          jsonDecode(await response.readAsString()) as Map<String, dynamic>;
      expect(body['status'], equals('no_analysis_yet'));
    });

    test('POST /api/fix/generate returns 501 without generator', () async {
      final handler = apiRoutes.router.call;
      final request = Request(
        'POST',
        Uri.parse('http://localhost/api/fix/generate'),
      );
      final response = await handler(request);

      expect(response.statusCode, equals(501));
    });

    test('CORS headers are present', () async {
      final handler = apiRoutes.router.call;
      final request = Request('GET', Uri.parse('http://localhost/api/status'));
      final response = await handler(request);

      expect(
          response.headers['Access-Control-Allow-Origin'], equals('*'));
    });
  });
}
