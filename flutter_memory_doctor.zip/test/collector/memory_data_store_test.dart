import 'package:flutter_memory_doctor/src/collector/memory_collector.dart';
import 'package:flutter_memory_doctor/src/models/memory_sample.dart';
import 'package:test/test.dart';

void main() {
  group('MemoryDataStore', () {
    late MemoryDataStore store;

    setUp(() {
      store = MemoryDataStore(maxSamples: 5, maxAllocations: 3);
    });

    tearDown(() {
      store.dispose();
    });

    test('starts empty', () {
      expect(store.samples, isEmpty);
      expect(store.allocations, isEmpty);
      expect(store.latestSample, isNull);
    });

    test('addSample stores samples', () {
      final sample = _makeSample(heapUsage: 1000);
      store.addSample(sample);

      expect(store.samples, hasLength(1));
      expect(store.latestSample, equals(sample));
    });

    test('ring buffer evicts old samples beyond max', () {
      for (var i = 0; i < 8; i++) {
        store.addSample(_makeSample(heapUsage: i * 1000));
      }

      expect(store.samples, hasLength(5));
      expect(store.samples.first.heapUsage, equals(3000));
      expect(store.samples.last.heapUsage, equals(7000));
    });

    test('recentSamples returns last N', () {
      for (var i = 0; i < 5; i++) {
        store.addSample(_makeSample(heapUsage: i * 1000));
      }

      final recent = store.recentSamples(3);
      expect(recent, hasLength(3));
      expect(recent.first.heapUsage, equals(2000));
      expect(recent.last.heapUsage, equals(4000));
    });

    test('recentSamples returns all if count > total', () {
      store.addSample(_makeSample(heapUsage: 1000));
      store.addSample(_makeSample(heapUsage: 2000));

      final recent = store.recentSamples(10);
      expect(recent, hasLength(2));
    });

    test('onSample emits new samples', () async {
      final samples = <MemorySample>[];
      store.onSample.listen(samples.add);

      store.addSample(_makeSample(heapUsage: 1000));
      store.addSample(_makeSample(heapUsage: 2000));

      await Future<void>.delayed(Duration.zero);
      expect(samples, hasLength(2));
    });

    test('clear removes all data', () {
      for (var i = 0; i < 3; i++) {
        store.addSample(_makeSample(heapUsage: i * 1000));
      }

      store.clear();
      expect(store.samples, isEmpty);
      expect(store.latestSample, isNull);
    });

    test('samplesInRange filters by time', () {
      final baseTime = DateTime(2024, 1, 1, 12, 0, 0);
      for (var i = 0; i < 5; i++) {
        store.addSample(MemorySample(
          timestamp: baseTime.add(Duration(seconds: i)),
          heapUsage: i * 1000,
          heapCapacity: 10000,
          externalUsage: 500,
        ));
      }

      final range = store.samplesInRange(
        baseTime.add(const Duration(seconds: 1)),
        baseTime.add(const Duration(seconds: 3)),
      );
      expect(range, hasLength(3));
      expect(range.first.heapUsage, equals(1000));
      expect(range.last.heapUsage, equals(3000));
    });
  });
}

MemorySample _makeSample({required int heapUsage}) {
  return MemorySample(
    timestamp: DateTime.now(),
    heapUsage: heapUsage,
    heapCapacity: heapUsage * 2,
    externalUsage: 500,
  );
}
