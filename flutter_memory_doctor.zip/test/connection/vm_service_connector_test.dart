import 'package:flutter_memory_doctor/src/connection/vm_service_connector.dart';
import 'package:test/test.dart';

void main() {
  group('VmServiceConnector.normalizeUri', () {
    test('converts http to ws and appends /ws', () {
      expect(
        VmServiceConnector.normalizeUri('http://127.0.0.1:8181/abc=/'),
        equals('ws://127.0.0.1:8181/abc=/ws'),
      );
    });

    test('converts https to wss and appends /ws', () {
      expect(
        VmServiceConnector.normalizeUri('https://127.0.0.1:8181/abc=/'),
        equals('wss://127.0.0.1:8181/abc=/ws'),
      );
    });

    test('does not double-append /ws', () {
      expect(
        VmServiceConnector.normalizeUri('ws://127.0.0.1:8181/abc=/ws'),
        equals('ws://127.0.0.1:8181/abc=/ws'),
      );
    });

    test('handles URI without trailing slash', () {
      expect(
        VmServiceConnector.normalizeUri('http://127.0.0.1:8181/abc='),
        equals('ws://127.0.0.1:8181/abc=/ws'),
      );
    });

    test('handles bare host:port', () {
      expect(
        VmServiceConnector.normalizeUri('127.0.0.1:8181'),
        equals('ws://127.0.0.1:8181/ws'),
      );
    });

    test('trims whitespace', () {
      expect(
        VmServiceConnector.normalizeUri('  http://127.0.0.1:8181/  '),
        equals('ws://127.0.0.1:8181/ws'),
      );
    });

    test('preserves ws:// scheme', () {
      expect(
        VmServiceConnector.normalizeUri('ws://127.0.0.1:8181/token=/'),
        equals('ws://127.0.0.1:8181/token=/ws'),
      );
    });

    test('preserves wss:// scheme', () {
      expect(
        VmServiceConnector.normalizeUri('wss://127.0.0.1:8181/'),
        equals('wss://127.0.0.1:8181/ws'),
      );
    });
  });
}
