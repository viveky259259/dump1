import 'package:flutter_memory_doctor/src/connection/isolate_manager.dart';
import 'package:test/test.dart';

import '../mocks/mock_vm_service.dart';

void main() {
  group('IsolateManager', () {
    late MockVmService mockService;
    late IsolateManager manager;

    setUp(() {
      mockService = MockVmService();
      manager = IsolateManager(mockService);
    });

    tearDown(() async {
      await manager.dispose();
    });

    test('discoverMainIsolate finds the main isolate', () async {
      final isolate = await manager.discoverMainIsolate();
      expect(isolate.name, equals('main'));
      expect(isolate.id, equals('isolates/1'));
    });

    test('hasMainIsolate is false before discovery', () {
      expect(manager.hasMainIsolate, isFalse);
    });

    test('hasMainIsolate is true after discovery', () async {
      await manager.discoverMainIsolate();
      expect(manager.hasMainIsolate, isTrue);
    });

    test('mainIsolateId returns correct id', () async {
      await manager.discoverMainIsolate();
      expect(manager.mainIsolateId, equals('isolates/1'));
    });

    test('throws if accessing mainIsolate before discovery', () {
      expect(() => manager.mainIsolate, throwsStateError);
    });
  });
}
