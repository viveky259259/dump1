# Developer Guide

Guide for contributors and maintainers of `flutter_memory_doctor`.

## Prerequisites

- Dart SDK >= 3.0.0
- A running Flutter app (for manual/integration testing)
- An Anthropic API key (for Claude-related features)

## Setup

```bash
cd flutter_memory_doctor
dart pub get
```

## Project Structure

```
flutter_memory_doctor/
├── bin/
│   └── flutter_memory_doctor.dart          # CLI entry point
├── lib/
│   ├── flutter_memory_doctor.dart          # Barrel export
│   └── src/
│       ├── cli/                            # CLI commands (CommandRunner)
│       ├── connection/                     # VM Service connection + isolate management
│       ├── collector/                      # Memory polling, GC events, heap snapshots
│       ├── models/                         # Data classes (samples, allocations, leaks, etc.)
│       ├── analysis/                       # Local heuristics + Claude API integration
│       ├── dashboard/                      # HTTP server, REST routes, SSE, static assets
│       └── autofix/                        # Fix generation, application, validation
├── web/                                    # Dashboard frontend (HTML/JS/CSS)
├── test/                                   # Unit and integration tests
│   ├── analysis/
│   ├── autofix/
│   ├── collector/
│   ├── connection/
│   ├── dashboard/
│   ├── models/
│   └── mocks/                              # MockVmService, MockClaudeClient
├── pubspec.yaml
└── analysis_options.yaml
```

## Architecture

```
CLI Layer (args, CommandRunner)
    │
    v
Connection Layer (VmServiceConnector → IsolateManager)
    │
    v
Collector Layer (MemoryPoller + GcEventListener + HeapSnapshotManager)
    │
    v
Data Store (MemoryDataStore — in-memory ring buffer with broadcast streams)
    │
    ├──→ Local Analyzer (MemoryAnalyzer — heuristic detection)
    │        │
    │        v
    ├──→ Analysis Orchestrator ──→ Claude Client (Anthropic Messages API)
    │                                   │
    │                                   v
    ├──→ Dashboard Server ←── AnalysisResult / FixPatch
    │        ├── SSE Handler (real-time push to browser)
    │        ├── API Routes (REST endpoints)
    │        └── Static Assets (HTML/JS/CSS)
    │
    v
AutoFix Module (FixGenerator → FixApplier → FixValidator)
```

### Data Flow

1. `VmServiceConnector` establishes a WebSocket connection to the Dart VM, normalizing HTTP URIs to `ws://` and retrying with exponential backoff.
2. `IsolateManager` discovers the main UI isolate (preferring name `'main'`) and listens for isolate lifecycle events to handle hot restart.
3. `MemoryPoller` runs a periodic timer calling `getMemoryUsage()` every tick and `getAllocationProfile()` every 10th tick.
4. `GcEventListener` subscribes to `EventStreams.kGC` and forwards events.
5. `MemoryCollector` orchestrates the poller, GC listener, and snapshot manager, feeding data into `MemoryDataStore`.
6. `MemoryDataStore` maintains ring buffers (configurable max size) and exposes broadcast streams for new data.
7. `MemoryAnalyzer` runs local heuristics (monotonic growth, linear regression leak detection, spike detection).
8. `AnalysisOrchestrator` combines local analysis with Claude API calls, falling back to local-only on API failure.
9. `DashboardServer` serves the REST API and static web assets. `SseHandler` pushes samples to connected browsers in real time.
10. `FixGenerator` resolves source files from library URIs, `FixApplier` applies patches with backup, and `FixValidator` runs `dart analyze` post-patch.

## Key Design Decisions

### Ring Buffer Data Store

`MemoryDataStore` uses `Queue` as a ring buffer with configurable `maxSamples` (default 3600 = 1 hour at 1s interval) and `maxAllocations` (default 360). Old entries are evicted automatically. Broadcast streams allow multiple consumers (dashboard SSE, analyzer) without coupling.

### Linear Regression for Leak Detection

`MemoryAnalyzer.detectLeakingClasses()` performs linear regression on per-class instance counts over time. Time values are normalized to relative milliseconds from the first record to avoid floating-point precision loss with large epoch timestamps. Classes with positive slope and R-squared > 0.8 are flagged as leak candidates.

### URI Normalization

`VmServiceConnector.normalizeUri()` handles the various URI formats Flutter/Dart can produce:
- `http://` → `ws://`
- `https://` → `wss://`
- Appends `/ws` if not present
- Trims whitespace
- Adds `ws://` prefix if no scheme present

### Snapshot Manager takes IsolateRef

`HeapSnapshotGraph.getSnapshot()` in `vm_service` requires an `IsolateRef`, not a string ID. The `HeapSnapshotManager` stores the `IsolateRef` directly.

### Optional Snapshot Manager in API Routes

`ApiRoutes.snapshotManager` is optional (`HeapSnapshotManager?`) to allow testing API routes without a real VM Service connection. Snapshot endpoints return 501 when unavailable.

### Claude API Fallback

`AnalysisOrchestrator.analyzeWithClaude()` always runs local analysis first. If the Claude API call fails (network error, auth error, etc.), it returns the local result rather than throwing. This ensures the tool remains useful without an API key.

### JSON Extraction from Claude Responses

`ClaudeClient.askJson()` handles responses where JSON may be wrapped in markdown code blocks (`` ```json ... ``` ``). It tries code block extraction first, then falls back to finding raw JSON delimiters.

## Running Tests

```bash
# All tests
dart test

# Specific test file
dart test test/analysis/memory_analyzer_test.dart

# With verbose output
dart test --reporter expanded
```

### Test Organization

| Directory | What it tests |
|-----------|---------------|
| `test/models/` | Serialization round-trips, computed properties |
| `test/connection/` | URI normalization, isolate discovery |
| `test/collector/` | Ring buffer behavior, sample filtering |
| `test/analysis/` | Heuristic detection, Claude client, prompt construction, orchestrator |
| `test/dashboard/` | API route responses, status codes, CORS headers |
| `test/autofix/` | Patch application, backup/restore, confirmation flow |
| `test/mocks/` | `MockVmService` and `MockClaudeClient` shared across tests |

### Mock Classes

**`MockVmService`** — implements `VmService` with `noSuchMethod` fallback. Provides:
- Configurable `heapGrowthPerCall` to simulate leaks
- `simulateErrors` flag to test error handling
- `emitGcEvent()` to manually trigger GC events
- Realistic `getVM()`, `getMemoryUsage()`, `getAllocationProfile()` responses

**`MockClaudeClient`** — extends `ClaudeClient` with:
- `nextJsonResponse` / `nextTextResponse` to control responses
- `shouldThrow` flag for error testing
- `callCount`, `lastSystemPrompt`, `lastUserMessage` for assertions

**`MockHttpClient`** — extends `http.BaseClient` for testing `ClaudeClient` directly, with configurable status codes and response bodies.

## Static Analysis

```bash
dart analyze
```

The project uses strict analysis options:
- `strict-casts: true`
- `strict-inference: true`
- `strict-raw-types: true`
- Linter rules: `prefer_single_quotes`, `prefer_final_locals`, `unawaited_futures`

## Adding a New Analysis Heuristic

1. Add a static method to `lib/src/analysis/memory_analyzer.dart`:

```dart
static bool detectNewPattern(List<MemorySample> samples) {
  // Your detection logic
}
```

2. Wire it into `MemoryAnalyzer.analyze()` to affect severity, summary, and suggestions.
3. Add tests in `test/analysis/memory_analyzer_test.dart`.
4. Update `ClaudePrompts` if the heuristic produces data that should be sent to Claude.

## Adding a New API Endpoint

1. Add the handler method to `lib/src/dashboard/api_routes.dart`.
2. Register it in the `router` getter.
3. Add a test in `test/dashboard/api_routes_test.dart`.
4. If the endpoint pushes real-time data, use `sseHandler.broadcast()`.

## Adding a New CLI Command

1. Create a new `Command<int>` subclass in `lib/src/cli/`.
2. Register it in `CliRunner` constructor with `addCommand()`.
3. Export it from `lib/flutter_memory_doctor.dart`.

## VM Service API Reference

Key APIs used from `package:vm_service`:

| Method | Used In | Purpose |
|--------|---------|---------|
| `vmServiceConnectUri()` | `VmServiceConnector` | WebSocket connection |
| `getVM()` | `IsolateManager` | Discover isolates |
| `getMemoryUsage()` | `MemoryPoller` | Heap usage, capacity, external |
| `getAllocationProfile()` | `MemoryPoller` | Per-class allocation stats |
| `HeapSnapshotGraph.getSnapshot()` | `HeapSnapshotManager` | Full heap snapshot with object graph |
| `streamListen(EventStreams.kGC)` | `GcEventListener` | GC event subscription |
| `streamListen(EventStreams.kIsolate)` | `IsolateManager` | Isolate lifecycle events |

## Troubleshooting

### "Failed to connect to VM Service after 20 attempts"

- Verify the Flutter app is still running
- Check the URI is correct (copy the full URI from `flutter run` output)
- The tool auto-converts `http://` to `ws://` and appends `/ws`

### Claude analysis returns local-only results

- Check that `ANTHROPIC_API_KEY` is set or `--api-key` is provided
- Verify the API key is valid
- Check network connectivity to `api.anthropic.com`
- The tool silently falls back to local analysis on API errors — run with `--verbose` for details

### Dashboard not loading

- Check the port isn't already in use (`--port` to change)
- Verify the `web/` directory is accessible relative to the binary
- Static asset serving looks in several candidate paths relative to the script and working directory
