# flutter_memory_doctor

AI-powered memory diagnostics for Flutter applications.

Connects to running Flutter apps via the VM Service Protocol, continuously monitors memory consumption, and uses the Claude API to analyze memory issues, suggest fixes, and optionally auto-apply them. Includes a real-time web dashboard for visualization.

## Features

- **Real-time memory monitoring** — polls heap usage, capacity, and external memory at configurable intervals
- **Allocation profiling** — tracks per-class instance counts and byte usage over time
- **Heap snapshots** — on-demand snapshot capture with class-level aggregation and diffing between snapshots
- **GC event tracking** — listens to garbage collection events from the VM
- **Local heuristic analysis** — detects monotonic heap growth, leaking classes (via linear regression), and memory spikes
- **Claude AI analysis** — sends memory data to the Anthropic API for deeper diagnosis and actionable suggestions
- **Web dashboard** — real-time Chart.js visualization with SSE, analysis results panel, and fix management
- **Auto-fix** — generates code patches from Claude, displays diffs, applies with backup and validation

## Installation

```bash
dart pub global activate --source path .
```

Or add as a dependency:

```yaml
dependencies:
  flutter_memory_doctor:
    path: /path/to/flutter_memory_doctor
```

## Quick Start

1. Run your Flutter app and note the VM Service URI:

```bash
flutter run
# Prints: An Observatory debugger and profiler on ... is available at: http://127.0.0.1:8181/abc=/
```

2. Run the memory doctor:

```bash
dart run bin/flutter_memory_doctor.dart monitor \
  --uri http://127.0.0.1:8181/abc=/ \
  --api-key $ANTHROPIC_API_KEY
```

3. Open the dashboard at `http://localhost:8080`

## Commands

### `monitor`

Continuous monitoring with a real-time web dashboard.

```bash
flutter_memory_doctor monitor --uri <VM_SERVICE_URI> [options]
```

| Option | Default | Description |
|--------|---------|-------------|
| `--port`, `-p` | `8080` | Dashboard server port |
| `--interval` | `1` | Polling interval in seconds |
| `--no-dashboard` | off | Disable the web dashboard |
| `--auto-analyze` | off | Automatically run analysis every 60s when issues are detected |
| `--project-root` | none | Project root for source file resolution and auto-fix |

### `analyze`

One-shot memory analysis. Collects data for a duration, analyzes, and exits.

```bash
flutter_memory_doctor analyze --uri <VM_SERVICE_URI> [options]
```

| Option | Default | Description |
|--------|---------|-------------|
| `--duration` | `30` | Seconds to collect data before analysis |
| `--with-snapshot` | off | Include a heap snapshot in the analysis |
| `--output`, `-o` | none | Write results to a JSON file |
| `--project-root` | none | Project root for source resolution |

### `snapshot`

Take and diff heap snapshots.

```bash
flutter_memory_doctor snapshot --uri <VM_SERVICE_URI> [options]
```

| Option | Default | Description |
|--------|---------|-------------|
| `--diff` | off | Take two snapshots and diff them |
| `--delay` | `30` | Seconds between snapshots (with `--diff`) |
| `--output`, `-o` | none | Write snapshot/diff data to a JSON file |

### Global Options

| Option | Description |
|--------|-------------|
| `--uri`, `-u` | VM Service URI (required) |
| `--api-key` | Anthropic API key (or set `ANTHROPIC_API_KEY` env var) |
| `--model` | Claude model to use (default: `claude-sonnet-4-20250514`) |
| `--verbose`, `-v` | Enable verbose logging |

## Dashboard

The web dashboard (served at `http://localhost:8080` by default) provides three panels:

- **Memory Usage** — real-time line chart showing heap usage, heap capacity, and external memory
- **Analysis** — severity badge, diagnosis text, detected leaks with confidence scores, and actionable suggestions
- **Fix Suggestions** — code diffs with per-patch "Apply" buttons (visible after generating fixes)

### Dashboard API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/samples` | Memory samples (optional `?count=N`) |
| GET | `/api/samples/stream` | SSE stream of real-time samples |
| GET | `/api/allocations` | Allocation profile records |
| POST | `/api/snapshot` | Take a heap snapshot |
| GET | `/api/snapshots` | List stored snapshots |
| POST | `/api/analyze` | Run analysis (`{"useClaude": true}`) |
| GET | `/api/analysis` | Last analysis result |
| POST | `/api/fix/generate` | Generate code fixes |
| POST | `/api/fix/apply` | Apply a fix (`{"fixIndex": 0}`) |
| GET | `/api/status` | Connection and collection status |

## Analysis Heuristics

The local analyzer applies these heuristics before (optionally) sending data to Claude:

| Heuristic | Trigger | Severity |
|-----------|---------|----------|
| Monotonic growth | Heap usage increases for 30+ consecutive samples | Warning |
| Leaking classes | Linear regression on instance count with R² > 0.8 and positive slope | Warning–Critical |
| Memory spike | Heap usage doubles within 5 seconds | Info |

## Configuration

### Environment Variables

| Variable | Description |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Anthropic API key for Claude analysis |

### Claude API

- Default model: `claude-sonnet-4-20250514`
- Override with `--model` flag
- Analysis works without an API key (local heuristics only); Claude provides deeper diagnosis and fix generation

## Dependencies

| Package | Purpose |
|---------|---------|
| `vm_service` | Dart VM Service Protocol client |
| `shelf` / `shelf_router` | HTTP server for dashboard |
| `http` | Anthropic API client |
| `args` | CLI argument parsing |
| `web_socket_channel` | WebSocket connection to VM |
| `async` | Stream utilities |
| `collection` | Data structure helpers |
| `path` | File path resolution |

## License

MIT
