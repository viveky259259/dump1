/// AI-powered memory diagnostics for Flutter applications.
///
/// Connects to running Flutter apps via VM Service Protocol,
/// monitors memory consumption, and uses Claude API to analyze
/// memory issues, suggest fixes, and optionally auto-apply them.
library flutter_memory_doctor;

// Models
export 'src/models/memory_sample.dart';
export 'src/models/allocation_record.dart';
export 'src/models/heap_snapshot_summary.dart';
export 'src/models/leak_candidate.dart';
export 'src/models/analysis_result.dart';
export 'src/models/fix_patch.dart';

// Connection
export 'src/connection/vm_service_connector.dart';
export 'src/connection/isolate_manager.dart';

// Collector
export 'src/collector/memory_poller.dart';
export 'src/collector/gc_event_listener.dart';
export 'src/collector/heap_snapshot_manager.dart';
export 'src/collector/memory_collector.dart';

// Analysis
export 'src/analysis/memory_analyzer.dart';
export 'src/analysis/claude_client.dart';
export 'src/analysis/claude_prompts.dart';
export 'src/analysis/analysis_orchestrator.dart';

// Dashboard
export 'src/dashboard/dashboard_server.dart';
export 'src/dashboard/api_routes.dart';
export 'src/dashboard/sse_handler.dart';
export 'src/dashboard/static_assets.dart';

// AutoFix
export 'src/autofix/fix_generator.dart';
export 'src/autofix/fix_applier.dart';
export 'src/autofix/fix_validator.dart';

// CLI
export 'src/cli/cli_runner.dart';
export 'src/cli/monitor_command.dart';
export 'src/cli/analyze_command.dart';
export 'src/cli/snapshot_command.dart';
