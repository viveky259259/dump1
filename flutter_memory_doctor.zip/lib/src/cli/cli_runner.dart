import 'package:args/command_runner.dart';

import 'analyze_command.dart';
import 'monitor_command.dart';
import 'snapshot_command.dart';

/// Main CLI command runner for flutter_memory_doctor.
class CliRunner extends CommandRunner<int> {
  CliRunner()
      : super(
          'flutter_memory_doctor',
          'AI-powered memory diagnostics for Flutter apps.\n\n'
              'Connects to a running Flutter app via VM Service Protocol,\n'
              'monitors memory, and uses Claude API to analyze and fix issues.',
        ) {
    argParser
      ..addOption(
        'uri',
        abbr: 'u',
        help: 'VM Service URI (e.g., http://127.0.0.1:8181/abc=/)',
      )
      ..addOption(
        'api-key',
        help: 'Anthropic API key (or set ANTHROPIC_API_KEY env var)',
      )
      ..addOption(
        'model',
        help: 'Claude model to use',
        defaultsTo: 'claude-sonnet-4-20250514',
      )
      ..addFlag(
        'verbose',
        abbr: 'v',
        help: 'Enable verbose logging',
        negatable: false,
      );

    addCommand(MonitorCommand());
    addCommand(AnalyzeCommand());
    addCommand(SnapshotCommand());
  }
}
