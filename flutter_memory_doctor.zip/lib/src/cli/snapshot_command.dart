import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:args/command_runner.dart';

import '../collector/heap_snapshot_manager.dart';
import '../connection/isolate_manager.dart';
import '../connection/vm_service_connector.dart';

/// The `snapshot` command — take and diff heap snapshots.
class SnapshotCommand extends Command<int> {
  SnapshotCommand() {
    argParser
      ..addFlag(
        'diff',
        help: 'Take two snapshots and diff them',
        negatable: false,
      )
      ..addOption(
        'delay',
        help: 'Delay between snapshots in seconds (for --diff)',
        defaultsTo: '30',
      )
      ..addOption(
        'output',
        abbr: 'o',
        help: 'Output file for snapshot data (JSON)',
      );
  }

  @override
  String get name => 'snapshot';

  @override
  String get description => 'Take and diff heap snapshots.';

  @override
  Future<int> run() async {
    final globals = globalResults!;
    final uri = globals['uri'] as String?;
    if (uri == null) {
      usageException('--uri is required. Provide the VM Service URI.');
    }

    final verbose = globals['verbose'] as bool;
    final doDiff = argResults!['diff'] as bool;
    final delaySec = int.parse(argResults!['delay'] as String);
    final outputPath = argResults!['output'] as String?;

    // Connect
    stdout.writeln('Connecting to VM Service at $uri...');
    final connector = VmServiceConnector(uri: uri);
    final service = await connector.connect();

    final isolateManager = IsolateManager(service);
    final mainIsolate = await isolateManager.discoverMainIsolate();
    stdout.writeln('Connected to isolate: ${mainIsolate.name}');

    final snapshotManager = HeapSnapshotManager(
      service: service,
      isolateRef: mainIsolate,
    );

    // Take first snapshot
    stdout.writeln('Taking heap snapshot...');
    final snapshot1 = await snapshotManager.takeSnapshot();
    stdout.writeln(
      'Snapshot 1: ${snapshot1.totalObjects} objects, '
      '${_formatBytes(snapshot1.totalSize)} total',
    );

    // Print top classes
    stdout.writeln('\nTop classes by size:');
    for (final cls in snapshot1.topByRetainedSize.take(15)) {
      stdout.writeln(
        '  ${cls.className.padRight(40)} '
        '${cls.instanceCount.toString().padLeft(8)} instances  '
        '${_formatBytes(cls.retainedSize).padLeft(10)}',
      );
    }

    if (doDiff) {
      stdout.writeln('\nWaiting ${delaySec}s before second snapshot...');
      for (var i = 0; i < delaySec; i++) {
        await Future<void>.delayed(const Duration(seconds: 1));
        if (verbose) {
          stdout.write('\r  ${i + 1}/${delaySec}s');
        }
      }
      stdout.writeln();

      stdout.writeln('Taking second snapshot...');
      final snapshot2 = await snapshotManager.takeSnapshot();
      stdout.writeln(
        'Snapshot 2: ${snapshot2.totalObjects} objects, '
        '${_formatBytes(snapshot2.totalSize)} total',
      );

      final diff = snapshot2.diff(snapshot1);
      stdout.writeln('\n=== Snapshot Diff ===');
      stdout.writeln(
        'Time span: ${diff.timeSpan.inSeconds}s',
      );
      stdout.writeln(
        'Size delta: ${_formatBytesDelta(diff.totalSizeDelta)}',
      );
      stdout.writeln(
        'Object delta: ${_signedInt(diff.totalObjectsDelta)}',
      );

      final growing = diff.growingClasses;
      if (growing.isNotEmpty) {
        stdout.writeln('\nGrowing classes:');
        for (final cls in growing.take(15)) {
          stdout.writeln(
            '  ${cls.className.padRight(40)} '
            '${_signedInt(cls.instanceDelta).padLeft(8)} instances  '
            '${_formatBytesDelta(cls.retainedSizeDelta).padLeft(10)}',
          );
        }
      }

      if (diff.newClasses.isNotEmpty) {
        stdout.writeln('\nNew classes (not in first snapshot):');
        for (final cls in diff.newClasses.take(10)) {
          stdout.writeln(
            '  ${cls.className.padRight(40)} '
            '${cls.instanceCount.toString().padLeft(8)} instances',
          );
        }
      }

      // Write output
      if (outputPath != null) {
        final json = const JsonEncoder.withIndent('  ').convert(diff.toJson());
        File(outputPath).writeAsStringSync(json);
        stdout.writeln('\nDiff written to $outputPath');
      }
    } else if (outputPath != null) {
      final json =
          const JsonEncoder.withIndent('  ').convert(snapshot1.toJson());
      File(outputPath).writeAsStringSync(json);
      stdout.writeln('\nSnapshot written to $outputPath');
    }

    // Cleanup
    await isolateManager.dispose();
    await connector.disconnect();

    return 0;
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
  }

  String _formatBytesDelta(int bytes) {
    final sign = bytes >= 0 ? '+' : '';
    return '$sign${_formatBytes(bytes.abs())}';
  }

  String _signedInt(int value) {
    return value >= 0 ? '+$value' : '$value';
  }
}
