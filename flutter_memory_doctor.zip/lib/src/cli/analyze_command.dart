import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:args/command_runner.dart';

import '../analysis/analysis_orchestrator.dart';
import '../analysis/claude_client.dart';
import '../collector/memory_collector.dart';
import '../connection/isolate_manager.dart';
import '../connection/vm_service_connector.dart';

/// The `analyze` command — one-shot memory analysis.
class AnalyzeCommand extends Command<int> {
  AnalyzeCommand() {
    argParser
      ..addFlag(
        'with-snapshot',
        help: 'Include a heap snapshot in the analysis',
        negatable: false,
      )
      ..addOption(
        'output',
        abbr: 'o',
        help: 'Output file for analysis results (JSON)',
      )
      ..addOption(
        'project-root',
        help: 'Project root for source resolution',
      )
      ..addOption(
        'duration',
        help: 'Monitoring duration in seconds before analysis',
        defaultsTo: '30',
      );
  }

  @override
  String get name => 'analyze';

  @override
  String get description =>
      'One-shot memory analysis. Collects data, analyzes, and exits.';

  @override
  Future<int> run() async {
    final globals = globalResults!;
    final uri = globals['uri'] as String?;
    if (uri == null) {
      usageException('--uri is required. Provide the VM Service URI.');
    }

    final apiKey = globals['api-key'] as String? ??
        Platform.environment['ANTHROPIC_API_KEY'];
    final model = globals['model'] as String;
    final verbose = globals['verbose'] as bool;
    final withSnapshot = argResults!['with-snapshot'] as bool;
    final outputPath = argResults!['output'] as String?;
    final durationSec = int.parse(argResults!['duration'] as String);

    // Connect
    stdout.writeln('Connecting to VM Service at $uri...');
    final connector = VmServiceConnector(uri: uri);
    final service = await connector.connect();

    final isolateManager = IsolateManager(service);
    final mainIsolate = await isolateManager.discoverMainIsolate();
    stdout.writeln('Connected to isolate: ${mainIsolate.name}');

    // Collect data
    final collector = MemoryCollector(
      service: service,
      isolateId: mainIsolate.id!,
      isolateRef: mainIsolate,
    );
    await collector.start();
    stdout.writeln('Collecting memory data for ${durationSec}s...');

    // Show progress
    for (var i = 0; i < durationSec; i++) {
      await Future<void>.delayed(const Duration(seconds: 1));
      final sample = collector.dataStore.latestSample;
      if (sample != null && verbose) {
        stdout.write(
          '\r  [${i + 1}/${durationSec}s] '
          'Heap: ${_formatBytes(sample.heapUsage)} ',
        );
      }
    }
    stdout.writeln();

    // Take snapshot if requested
    if (withSnapshot) {
      stdout.writeln('Taking heap snapshot...');
      await collector.snapshotManager.takeSnapshot();
      stdout.writeln('Snapshot complete.');
    }

    await collector.stop();

    // Analyze
    ClaudeClient? claudeClient;
    if (apiKey != null) {
      claudeClient = ClaudeClient(apiKey: apiKey, model: model);
    }

    final orchestrator = AnalysisOrchestrator(
      dataStore: collector.dataStore,
      claudeClient: claudeClient,
    );

    stdout.writeln('Analyzing...');
    final result = apiKey != null
        ? await orchestrator.analyzeWithClaude()
        : orchestrator.analyzeLocal();

    // Output results
    stdout.writeln();
    stdout.writeln('=== Analysis Result ===');
    stdout.writeln('Severity: ${result.severity.label}');
    stdout.writeln('Summary: ${result.summary}');
    stdout.writeln();
    stdout.writeln(result.diagnosis);

    if (result.leaks.isNotEmpty) {
      stdout.writeln();
      stdout.writeln('--- Potential Leaks ---');
      for (final leak in result.leaks) {
        stdout.writeln(
          '  ${leak.className} '
          '(confidence: ${(leak.confidence * 100).toStringAsFixed(0)}%, '
          'growth: ${leak.growthRate.toStringAsFixed(1)} bytes/s)',
        );
        for (final e in leak.evidence) {
          stdout.writeln('    - $e');
        }
      }
    }

    if (result.suggestions.isNotEmpty) {
      stdout.writeln();
      stdout.writeln('--- Suggestions ---');
      for (final s in result.suggestions) {
        stdout.writeln('  - $s');
      }
    }

    // Write to file if requested
    if (outputPath != null) {
      final json = const JsonEncoder.withIndent('  ').convert(result.toJson());
      File(outputPath).writeAsStringSync(json);
      stdout.writeln('\nResults written to $outputPath');
    }

    // Cleanup
    await collector.dispose();
    await isolateManager.dispose();
    await connector.disconnect();
    claudeClient?.dispose();

    return result.isHealthy ? 0 : 1;
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
  }
}
