import 'dart:async';
import 'dart:io';

import 'package:args/command_runner.dart';

import '../analysis/analysis_orchestrator.dart';
import '../analysis/claude_client.dart';
import '../autofix/fix_applier.dart';
import '../autofix/fix_generator.dart';
import '../collector/memory_collector.dart';
import '../connection/isolate_manager.dart';
import '../connection/vm_service_connector.dart';
import '../dashboard/dashboard_server.dart';

/// The `monitor` command — continuous monitoring with dashboard.
class MonitorCommand extends Command<int> {
  MonitorCommand() {
    argParser
      ..addOption(
        'port',
        abbr: 'p',
        help: 'Dashboard server port',
        defaultsTo: '8080',
      )
      ..addOption(
        'interval',
        help: 'Polling interval in seconds',
        defaultsTo: '1',
      )
      ..addFlag(
        'no-dashboard',
        help: 'Disable web dashboard',
        negatable: false,
      )
      ..addFlag(
        'auto-analyze',
        help: 'Automatically analyze when issues are detected',
        negatable: false,
      )
      ..addOption(
        'project-root',
        help: 'Project root for source file resolution and auto-fix',
      );
  }

  @override
  String get name => 'monitor';

  @override
  String get description =>
      'Continuous monitoring with real-time dashboard and analysis.';

  @override
  Future<int> run() async {
    final globals = globalResults!;
    final uri = globals['uri'] as String?;
    if (uri == null) {
      usageException('--uri is required. Provide the VM Service URI.');
    }

    final apiKey = globals['api-key'] as String? ??
        Platform.environment['ANTHROPIC_API_KEY'];
    final model = globals['model'] as String;
    final verbose = globals['verbose'] as bool;
    final port = int.parse(argResults!['port'] as String);
    final intervalSec = int.parse(argResults!['interval'] as String);
    final noDashboard = argResults!['no-dashboard'] as bool;
    final autoAnalyze = argResults!['auto-analyze'] as bool;
    final projectRoot = argResults!['project-root'] as String?;

    // Connect to VM Service
    if (verbose) {
      stdout.writeln('Connecting to VM Service at $uri...');
    }

    final connector = VmServiceConnector(uri: uri);
    final service = await connector.connect();

    if (verbose) {
      stdout.writeln('Connected. Discovering isolates...');
    }

    // Discover main isolate
    final isolateManager = IsolateManager(service);
    final mainIsolate = await isolateManager.discoverMainIsolate();
    await isolateManager.startListening();

    if (verbose) {
      stdout.writeln('Main isolate: ${mainIsolate.name} (${mainIsolate.id})');
    }

    // Set up collector
    final collector = MemoryCollector(
      service: service,
      isolateId: mainIsolate.id!,
      isolateRef: mainIsolate,
      pollInterval: Duration(seconds: intervalSec),
    );

    // Set up Claude client
    ClaudeClient? claudeClient;
    if (apiKey != null) {
      claudeClient = ClaudeClient(apiKey: apiKey, model: model);
    } else {
      stdout.writeln(
        'Warning: No API key provided. Claude analysis will be unavailable.\n'
        'Set ANTHROPIC_API_KEY or use --api-key.',
      );
    }

    // Set up orchestrator
    final orchestrator = AnalysisOrchestrator(
      dataStore: collector.dataStore,
      claudeClient: claudeClient,
    );

    // Set up auto-fix (if project root provided)
    FixGenerator? fixGenerator;
    FixApplier? fixApplier;
    if (projectRoot != null) {
      fixGenerator = FixGenerator(
        orchestrator: orchestrator,
        projectRoot: projectRoot,
      );
      fixApplier = FixApplier(requireConfirmation: false);
    }

    // Start collecting
    await collector.start();
    stdout.writeln('Monitoring started (${intervalSec}s interval).');

    // Start dashboard
    DashboardServer? dashboard;
    if (!noDashboard) {
      dashboard = DashboardServer(
        dataStore: collector.dataStore,
        snapshotManager: collector.snapshotManager,
        orchestrator: orchestrator,
        fixGenerator: fixGenerator,
        fixApplier: fixApplier,
        port: port,
      );
      await dashboard.start();
      stdout.writeln('Dashboard available at http://localhost:$port');
    }

    // Auto-analyze loop
    Timer? autoAnalyzeTimer;
    if (autoAnalyze) {
      autoAnalyzeTimer = Timer.periodic(
        const Duration(seconds: 60),
        (_) async {
          final samples = collector.dataStore.samples;
          if (samples.length >= 30) {
            final result = await orchestrator.analyzeWithClaude();
            if (!result.isHealthy) {
              stdout.writeln(
                '\n[Auto-Analysis] ${result.severity.label}: ${result.summary}',
              );
            }
          }
        },
      );
    }

    // Print periodic stats to console
    final statsTimer = Timer.periodic(
      const Duration(seconds: 10),
      (_) {
        final latest = collector.dataStore.latestSample;
        if (latest != null) {
          stdout.write(
            '\r[${latest.timestamp.toLocal().toString().substring(11, 19)}] '
            'Heap: ${_formatBytes(latest.heapUsage)}/${_formatBytes(latest.heapCapacity)} '
            'Ext: ${_formatBytes(latest.externalUsage)} '
            'Samples: ${collector.dataStore.samples.length}  ',
          );
        }
      },
    );

    // Wait for Ctrl+C
    final completer = Completer<int>();
    ProcessSignal.sigint.watch().listen((_) async {
      stdout.writeln('\n\nShutting down...');
      statsTimer.cancel();
      autoAnalyzeTimer?.cancel();
      await dashboard?.stop();
      await collector.dispose();
      await isolateManager.dispose();
      await connector.disconnect();
      claudeClient?.dispose();
      completer.complete(0);
    });

    return completer.future;
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
  }
}
