import 'dart:async';

import 'package:vm_service/vm_service.dart';

import '../models/allocation_record.dart';
import '../models/memory_sample.dart';

/// Periodically polls memory usage and allocation profiles from the VM Service.
///
/// Collects [MemorySample] every [interval], and [AllocationRecord] every
/// [allocationProfileInterval] ticks.
class MemoryPoller {
  MemoryPoller({
    required VmService service,
    required String isolateId,
    this.interval = const Duration(seconds: 1),
    this.allocationProfileInterval = 10,
  })  : _service = service,
        _isolateId = isolateId;

  final VmService _service;
  final String _isolateId;
  final Duration interval;
  final int allocationProfileInterval;

  Timer? _timer;
  int _tickCount = 0;

  final _sampleController = StreamController<MemorySample>.broadcast();
  final _allocationController =
      StreamController<AllocationRecord>.broadcast();

  /// Stream of memory samples.
  Stream<MemorySample> get onSample => _sampleController.stream;

  /// Stream of allocation records.
  Stream<AllocationRecord> get onAllocation => _allocationController.stream;

  bool get isRunning => _timer != null;

  /// Starts the polling timer.
  void start() {
    if (_timer != null) return;
    _tickCount = 0;
    _timer = Timer.periodic(interval, (_) => _poll());
  }

  /// Stops the polling timer.
  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _poll() async {
    _tickCount++;
    try {
      final memUsage = await _service.getMemoryUsage(_isolateId);
      final sample = MemorySample(
        timestamp: DateTime.now(),
        heapUsage: memUsage.heapUsage ?? 0,
        heapCapacity: memUsage.heapCapacity ?? 0,
        externalUsage: memUsage.externalUsage ?? 0,
      );
      _sampleController.add(sample);

      // Collect allocation profile at configured interval
      if (_tickCount % allocationProfileInterval == 0) {
        await _collectAllocationProfile();
      }
    } catch (e) {
      // VM may be temporarily unreachable (e.g., during hot restart)
      if (!_sampleController.isClosed) {
        _sampleController.addError(e);
      }
    }
  }

  Future<void> _collectAllocationProfile() async {
    try {
      final profile = await _service.getAllocationProfile(_isolateId);
      final members = profile.members;
      if (members == null) return;

      final classes = <ClassAllocationInfo>[];
      for (final member in members) {
        final classRef = member.classRef;
        if (classRef == null) continue;

        classes.add(ClassAllocationInfo(
          className: classRef.name ?? 'Unknown',
          libraryUri: classRef.library?.uri ?? '',
          instancesCurrent: member.instancesCurrent ?? 0,
          instancesAccumulated: member.instancesAccumulated ?? 0,
          bytesCurrent: member.bytesCurrent ?? 0,
          bytesAccumulated: member.accumulatedSize ?? 0,
        ));
      }

      final record = AllocationRecord(
        timestamp: DateTime.now(),
        classes: classes,
      );
      _allocationController.add(record);
    } catch (e) {
      // Allocation profile may fail during GC or isolate transitions
    }
  }

  /// Disposes streams.
  Future<void> dispose() async {
    stop();
    await _sampleController.close();
    await _allocationController.close();
  }
}
