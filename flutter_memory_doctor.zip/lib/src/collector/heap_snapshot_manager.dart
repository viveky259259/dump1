import 'dart:async';

import 'package:vm_service/vm_service.dart';

import '../models/heap_snapshot_summary.dart';

/// Manages on-demand heap snapshot collection and diffing.
class HeapSnapshotManager {
  HeapSnapshotManager({
    required VmService service,
    required IsolateRef isolateRef,
    this.maxHistory = 10,
  })  : _service = service,
        _isolateRef = isolateRef;

  final VmService _service;
  final IsolateRef _isolateRef;
  final int maxHistory;

  final List<HeapSnapshotSummary> _history = [];

  /// All stored snapshot summaries.
  List<HeapSnapshotSummary> get history => List.unmodifiable(_history);

  /// The most recent snapshot, if any.
  HeapSnapshotSummary? get latest =>
      _history.isNotEmpty ? _history.last : null;

  /// Takes a heap snapshot and returns a summary.
  ///
  /// Requests a heap snapshot via the VM Service, collects all chunks,
  /// parses the graph, and aggregates into a [HeapSnapshotSummary].
  Future<HeapSnapshotSummary> takeSnapshot() async {
    final graph = await HeapSnapshotGraph.getSnapshot(_service, _isolateRef);
    final summary = _summarizeGraph(graph);

    _history.add(summary);
    if (_history.length > maxHistory) {
      _history.removeAt(0);
    }

    return summary;
  }

  /// Diffs the latest snapshot against the previous one.
  ///
  /// Returns null if there are fewer than 2 snapshots.
  HeapSnapshotDiff? diffLatest() {
    if (_history.length < 2) return null;
    return _history.last.diff(_history[_history.length - 2]);
  }

  /// Diffs two snapshots by index.
  HeapSnapshotDiff diffByIndex(int olderIndex, int newerIndex) {
    return _history[newerIndex].diff(_history[olderIndex]);
  }

  HeapSnapshotSummary _summarizeGraph(HeapSnapshotGraph graph) {
    final classCounts = <String, _ClassAggregation>{};
    var totalSize = 0;
    var totalObjects = 0;
    var totalExternalSize = 0;

    for (final obj in graph.objects) {
      totalObjects++;
      final shallowSize = obj.shallowSize;
      totalSize += shallowSize;

      final classInfo = obj.klass;
      final className = classInfo.name;
      final libraryUri = classInfo.libraryUri.toString();

      final agg = classCounts.putIfAbsent(
        '$libraryUri::$className',
        () => _ClassAggregation(
          className: className,
          libraryUri: libraryUri,
        ),
      );
      agg.instanceCount++;
      agg.shallowSize += shallowSize;
    }

    totalExternalSize = graph.externalSize;

    final classes = classCounts.values
        .map((agg) => ClassSummary(
              className: agg.className,
              libraryUri: agg.libraryUri,
              instanceCount: agg.instanceCount,
              shallowSize: agg.shallowSize,
              retainedSize: agg.shallowSize, // approximate
            ))
        .toList();

    return HeapSnapshotSummary(
      timestamp: DateTime.now(),
      totalSize: totalSize,
      totalObjects: totalObjects,
      totalExternalSize: totalExternalSize,
      classes: classes,
    );
  }
}

class _ClassAggregation {
  _ClassAggregation({
    required this.className,
    required this.libraryUri,
  });

  final String className;
  final String libraryUri;
  int instanceCount = 0;
  int shallowSize = 0;
}
