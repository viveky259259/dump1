import 'dart:async';

import 'package:vm_service/vm_service.dart';

/// Listens to GC events from the VM Service.
class GcEventListener {
  GcEventListener({
    required VmService service,
  }) : _service = service;

  final VmService _service;

  final _gcController = StreamController<GcEventData>.broadcast();
  StreamSubscription<Event>? _subscription;

  /// Stream of GC events.
  Stream<GcEventData> get onGcEvent => _gcController.stream;

  bool get isListening => _subscription != null;

  /// Starts listening for GC events.
  Future<void> start() async {
    if (_subscription != null) return;

    await _service.streamListen(EventStreams.kGC);
    _subscription = _service.onGCEvent.listen((event) {
      final data = GcEventData(
        timestamp: DateTime.now(),
        isolateId: event.isolate?.id ?? '',
        kind: event.kind ?? '',
      );
      _gcController.add(data);
    });
  }

  /// Stops listening for GC events.
  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
  }

  /// Disposes resources.
  Future<void> dispose() async {
    await stop();
    await _gcController.close();
  }
}

/// Data from a GC event.
class GcEventData {
  GcEventData({
    required this.timestamp,
    required this.isolateId,
    required this.kind,
  });

  final DateTime timestamp;
  final String isolateId;
  final String kind;

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'isolateId': isolateId,
        'kind': kind,
      };
}
