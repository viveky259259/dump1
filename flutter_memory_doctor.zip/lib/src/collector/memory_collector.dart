import 'dart:async';
import 'dart:collection';

import 'package:vm_service/vm_service.dart';

import '../models/allocation_record.dart';
import '../models/memory_sample.dart';
import 'gc_event_listener.dart';
import 'heap_snapshot_manager.dart';
import 'memory_poller.dart';

/// Orchestrates all memory data collection and maintains the data store.
class MemoryCollector {
  MemoryCollector({
    required VmService service,
    required String isolateId,
    required IsolateRef isolateRef,
    Duration pollInterval = const Duration(seconds: 1),
    int maxSamples = 3600,
    int maxAllocations = 360,
  })  : _poller = MemoryPoller(
          service: service,
          isolateId: isolateId,
          interval: pollInterval,
        ),
        _gcListener = GcEventListener(service: service),
        _snapshotManager = HeapSnapshotManager(
          service: service,
          isolateRef: isolateRef,
        ),
        _dataStore = MemoryDataStore(
          maxSamples: maxSamples,
          maxAllocations: maxAllocations,
        );

  final MemoryPoller _poller;
  final GcEventListener _gcListener;
  final HeapSnapshotManager _snapshotManager;
  final MemoryDataStore _dataStore;

  StreamSubscription<MemorySample>? _sampleSub;
  StreamSubscription<AllocationRecord>? _allocationSub;
  StreamSubscription<GcEventData>? _gcSub;

  MemoryDataStore get dataStore => _dataStore;
  HeapSnapshotManager get snapshotManager => _snapshotManager;

  /// Starts collecting memory data.
  Future<void> start() async {
    _sampleSub = _poller.onSample.listen((sample) {
      _dataStore.addSample(sample);
    });

    _allocationSub = _poller.onAllocation.listen((record) {
      _dataStore.addAllocation(record);
    });

    _gcSub = _gcListener.onGcEvent.listen((event) {
      _dataStore.recordGcEvent(event);
    });

    await _gcListener.start();
    _poller.start();
  }

  /// Stops collecting.
  Future<void> stop() async {
    _poller.stop();
    await _gcListener.stop();
    await _sampleSub?.cancel();
    await _allocationSub?.cancel();
    await _gcSub?.cancel();
  }

  /// Disposes all resources.
  Future<void> dispose() async {
    await stop();
    await _poller.dispose();
    await _gcListener.dispose();
    _dataStore.dispose();
  }
}

/// In-memory ring buffer data store for memory samples and allocations.
class MemoryDataStore {
  MemoryDataStore({
    this.maxSamples = 3600,
    this.maxAllocations = 360,
  });

  final int maxSamples;
  final int maxAllocations;

  final _samples = Queue<MemorySample>();
  final _allocations = Queue<AllocationRecord>();
  final _gcEvents = <GcEventData>[];

  final _sampleController = StreamController<MemorySample>.broadcast();
  final _allocationController =
      StreamController<AllocationRecord>.broadcast();

  /// Broadcast stream of new memory samples.
  Stream<MemorySample> get onSample => _sampleController.stream;

  /// Broadcast stream of new allocation records.
  Stream<AllocationRecord> get onAllocation => _allocationController.stream;

  /// All stored samples (oldest first).
  List<MemorySample> get samples => _samples.toList();

  /// All stored allocation records (oldest first).
  List<AllocationRecord> get allocations => _allocations.toList();

  /// All recorded GC events.
  List<GcEventData> get gcEvents => List.unmodifiable(_gcEvents);

  /// The most recent sample.
  MemorySample? get latestSample =>
      _samples.isNotEmpty ? _samples.last : null;

  /// The most recent allocation record.
  AllocationRecord? get latestAllocation =>
      _allocations.isNotEmpty ? _allocations.last : null;

  /// Adds a memory sample to the ring buffer.
  void addSample(MemorySample sample) {
    _samples.add(sample);
    while (_samples.length > maxSamples) {
      _samples.removeFirst();
    }
    _sampleController.add(sample);
  }

  /// Adds an allocation record to the ring buffer.
  void addAllocation(AllocationRecord record) {
    _allocations.add(record);
    while (_allocations.length > maxAllocations) {
      _allocations.removeFirst();
    }
    _allocationController.add(record);
  }

  /// Records a GC event.
  void recordGcEvent(GcEventData event) {
    _gcEvents.add(event);
  }

  /// Returns samples within a time range.
  List<MemorySample> samplesInRange(DateTime start, DateTime end) {
    return _samples
        .where((s) => !s.timestamp.isBefore(start) && !s.timestamp.isAfter(end))
        .toList();
  }

  /// Returns the last N samples.
  List<MemorySample> recentSamples(int count) {
    final all = _samples.toList();
    if (all.length <= count) return all;
    return all.sublist(all.length - count);
  }

  /// Clears all data.
  void clear() {
    _samples.clear();
    _allocations.clear();
    _gcEvents.clear();
  }

  /// Disposes streams.
  void dispose() {
    _sampleController.close();
    _allocationController.close();
  }
}
