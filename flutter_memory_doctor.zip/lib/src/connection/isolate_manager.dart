import 'dart:async';

import 'package:vm_service/vm_service.dart';

/// Manages isolate discovery and tracking for a VM Service connection.
///
/// Identifies the main UI isolate and handles hot restart (isolate exit/start).
class IsolateManager {
  IsolateManager(this._service);

  final VmService _service;

  IsolateRef? _mainIsolate;

  final _isolateChangedController = StreamController<IsolateRef>.broadcast();

  /// Stream emitting when the main isolate changes (e.g., hot restart).
  Stream<IsolateRef> get onMainIsolateChanged =>
      _isolateChangedController.stream;

  /// The current main isolate reference.
  IsolateRef get mainIsolate {
    final isolate = _mainIsolate;
    if (isolate == null) {
      throw StateError(
        'No main isolate found. Call discoverMainIsolate() first.',
      );
    }
    return isolate;
  }

  /// The ID of the current main isolate.
  String get mainIsolateId => mainIsolate.id!;

  bool get hasMainIsolate => _mainIsolate != null;

  /// Discovers the main UI isolate from the VM.
  ///
  /// Prefers the isolate named 'main', falls back to the first running isolate.
  Future<IsolateRef> discoverMainIsolate() async {
    final vm = await _service.getVM();
    final isolates = vm.isolates;

    if (isolates == null || isolates.isEmpty) {
      throw StateError('No isolates found in the VM.');
    }

    // Prefer the isolate named 'main'
    IsolateRef? mainRef;
    for (final ref in isolates) {
      if (ref.name == 'main') {
        mainRef = ref;
        break;
      }
    }

    // Fall back to first isolate
    mainRef ??= isolates.first;
    _mainIsolate = mainRef;

    return mainRef;
  }

  /// Starts listening for isolate lifecycle events to handle hot restart.
  Future<void> startListening() async {
    await _service.streamListen(EventStreams.kIsolate);

    _service.onIsolateEvent.listen((event) async {
      if (event.kind == EventKind.kIsolateExit) {
        if (event.isolate?.id == _mainIsolate?.id) {
          _mainIsolate = null;
        }
      } else if (event.kind == EventKind.kIsolateRunnable) {
        // New isolate started — might be hot restart
        if (_mainIsolate == null) {
          try {
            final newMain = await discoverMainIsolate();
            _isolateChangedController.add(newMain);
          } catch (_) {
            // VM may not be ready yet
          }
        }
      }
    });
  }

  /// Disposes resources.
  Future<void> dispose() async {
    await _isolateChangedController.close();
  }
}
