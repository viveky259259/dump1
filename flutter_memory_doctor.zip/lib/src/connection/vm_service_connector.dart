import 'dart:async';

import 'package:vm_service/vm_service.dart';
import 'package:vm_service/vm_service_io.dart';

/// Connects to a running Dart/Flutter VM Service via WebSocket.
///
/// Handles URI normalization (HTTP→WS) and retry with exponential backoff.
class VmServiceConnector {
  VmServiceConnector({
    required this.uri,
    this.maxRetries = 20,
    this.initialBackoff = const Duration(milliseconds: 100),
  });

  final String uri;
  final int maxRetries;
  final Duration initialBackoff;

  VmService? _service;

  VmService get service {
    final s = _service;
    if (s == null) {
      throw StateError('Not connected. Call connect() first.');
    }
    return s;
  }

  bool get isConnected => _service != null;

  /// Normalizes a VM Service URI to its WebSocket form.
  ///
  /// Converts http(s) to ws(s) and ensures the path ends with `/ws`.
  static String normalizeUri(String rawUri) {
    var normalized = rawUri.trim();

    // Replace http(s) with ws(s)
    if (normalized.startsWith('http://')) {
      normalized = 'ws://${normalized.substring('http://'.length)}';
    } else if (normalized.startsWith('https://')) {
      normalized = 'wss://${normalized.substring('https://'.length)}';
    }

    // Ensure ws:// prefix if missing
    if (!normalized.startsWith('ws://') &&
        !normalized.startsWith('wss://')) {
      normalized = 'ws://$normalized';
    }

    // Ensure path ends with /ws
    if (!normalized.endsWith('/ws')) {
      if (normalized.endsWith('/')) {
        normalized = '${normalized}ws';
      } else {
        normalized = '$normalized/ws';
      }
    }

    return normalized;
  }

  /// Connects to the VM Service with exponential backoff retry.
  Future<VmService> connect() async {
    final wsUri = normalizeUri(uri);
    var backoff = initialBackoff;

    for (var attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final service = await vmServiceConnectUri(wsUri);
        _service = service;

        // Listen for disconnect
        unawaited(service.onDone.then((_) {
          _service = null;
        }));

        return service;
      } catch (e) {
        if (attempt == maxRetries - 1) {
          throw VmServiceConnectionException(
            'Failed to connect to VM Service at $wsUri '
            'after $maxRetries attempts: $e',
          );
        }
        await Future<void>.delayed(backoff);
        // Exponential backoff capped at 1600ms
        backoff = Duration(
          milliseconds: (backoff.inMilliseconds * 2).clamp(0, 1600),
        );
      }
    }

    throw VmServiceConnectionException(
      'Failed to connect to VM Service at $wsUri',
    );
  }

  /// Disconnects from the VM Service.
  Future<void> disconnect() async {
    final s = _service;
    if (s != null) {
      await s.dispose();
      _service = null;
    }
  }
}

/// Exception thrown when VM Service connection fails.
class VmServiceConnectionException implements Exception {
  VmServiceConnectionException(this.message);
  final String message;

  @override
  String toString() => 'VmServiceConnectionException: $message';
}
