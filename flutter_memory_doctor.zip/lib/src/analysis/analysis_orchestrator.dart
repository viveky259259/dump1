import 'dart:convert';

import '../collector/memory_collector.dart';
import '../models/analysis_result.dart';
import '../models/fix_patch.dart';
import '../models/heap_snapshot_summary.dart';
import '../models/leak_candidate.dart';
import 'claude_client.dart';
import 'claude_prompts.dart';
import 'memory_analyzer.dart';

/// Combines local heuristic analysis with Claude API analysis.
class AnalysisOrchestrator {
  AnalysisOrchestrator({
    required this.dataStore,
    this.claudeClient,
  });

  final MemoryDataStore dataStore;
  final ClaudeClient? claudeClient;

  AnalysisResult? _lastResult;

  /// The most recent analysis result.
  AnalysisResult? get lastResult => _lastResult;

  /// Runs local heuristic analysis only.
  AnalysisResult analyzeLocal() {
    final result = MemoryAnalyzer.analyze(
      samples: dataStore.samples,
      allocations: dataStore.allocations,
    );
    _lastResult = result;
    return result;
  }

  /// Runs full analysis: local heuristics + Claude API.
  ///
  /// Falls back to local-only if Claude is unavailable.
  Future<AnalysisResult> analyzeWithClaude() async {
    final localResult = analyzeLocal();

    final client = claudeClient;
    if (client == null) {
      return localResult;
    }

    try {
      final growthRates =
          MemoryAnalyzer.computeGrowthRates(dataStore.allocations);

      final prompt = ClaudePrompts.buildTrendAnalysisPrompt(
        samples: dataStore.samples,
        allocations: dataStore.allocations,
        growthRates: growthRates,
        localLeaks: localResult.leaks,
      );

      final responseJson = await client.askJson(
        systemPrompt: ClaudePrompts.analysisSystemPrompt,
        userMessage: prompt,
      );

      final result = _parseAnalysisResponse(responseJson);
      _lastResult = result;
      return result;
    } catch (e) {
      // Fall back to local analysis on API error
      return localResult;
    }
  }

  /// Analyzes a heap snapshot diff using Claude.
  Future<AnalysisResult> analyzeSnapshotDiff(HeapSnapshotDiff diff) async {
    final client = claudeClient;
    if (client == null) {
      return _snapshotDiffLocalAnalysis(diff);
    }

    try {
      final prompt = ClaudePrompts.buildSnapshotDiffPrompt(diff: diff);

      final responseJson = await client.askJson(
        systemPrompt: ClaudePrompts.analysisSystemPrompt,
        userMessage: prompt,
      );

      final result = _parseAnalysisResponse(responseJson);
      _lastResult = result;
      return result;
    } catch (e) {
      return _snapshotDiffLocalAnalysis(diff);
    }
  }

  /// Generates fix patches for detected issues.
  Future<List<FixPatch>> generateFixes({
    required AnalysisResult analysis,
    required Map<String, String> sourceFiles,
  }) async {
    final client = claudeClient;
    if (client == null) {
      throw StateError('Claude API client is required for fix generation.');
    }

    final prompt = ClaudePrompts.buildFixGenerationPrompt(
      analysis: analysis,
      sourceFiles: sourceFiles,
    );

    final responseJson = await client.askJson(
      systemPrompt: ClaudePrompts.fixSystemPrompt,
      userMessage: prompt,
    );

    return _parseFixResponse(responseJson);
  }

  AnalysisResult _parseAnalysisResponse(Map<String, dynamic> json) {
    final leaksJson = json['leaks'] as List<dynamic>? ?? [];
    final leaks = leaksJson
        .map((l) => LeakCandidate(
              className: l['className'] as String? ?? 'Unknown',
              libraryUri: l['libraryUri'] as String? ?? '',
              growthRate: (l['growthRate'] as num?)?.toDouble() ?? 0.0,
              confidence: (l['confidence'] as num?)?.toDouble() ?? 0.5,
              evidence: (l['evidence'] as List<dynamic>?)
                      ?.cast<String>() ??
                  [],
            ))
        .toList();

    final suggestionsJson = json['suggestions'] as List<dynamic>? ?? [];
    final suggestions = suggestionsJson.cast<String>();

    return AnalysisResult(
      timestamp: DateTime.now(),
      severity: _parseSeverity(json['severity'] as String? ?? 'info'),
      summary: json['summary'] as String? ?? 'Analysis complete',
      diagnosis: json['diagnosis'] as String? ?? '',
      leaks: leaks,
      suggestions: suggestions,
      rawResponse: jsonEncode(json),
    );
  }

  List<FixPatch> _parseFixResponse(Map<String, dynamic> json) {
    final fixesJson = json['fixes'] as List<dynamic>? ?? [];
    return fixesJson.map((f) {
      final fix = f as Map<String, dynamic>;
      return FixPatch(
        filePath: fix['filePath'] as String,
        startLine: fix['startLine'] as int,
        endLine: fix['endLine'] as int,
        originalCode: fix['originalCode'] as String,
        patchedCode: fix['patchedCode'] as String,
        explanation: fix['explanation'] as String,
        leakClassName: fix['leakClassName'] as String?,
      );
    }).toList();
  }

  AnalysisSeverity _parseSeverity(String value) {
    switch (value.toLowerCase()) {
      case 'healthy':
        return AnalysisSeverity.healthy;
      case 'info':
        return AnalysisSeverity.info;
      case 'warning':
        return AnalysisSeverity.warning;
      case 'critical':
        return AnalysisSeverity.critical;
      default:
        return AnalysisSeverity.info;
    }
  }

  AnalysisResult _snapshotDiffLocalAnalysis(HeapSnapshotDiff diff) {
    final growing = diff.growingClasses;

    if (growing.isEmpty) {
      return AnalysisResult(
        timestamp: DateTime.now(),
        severity: AnalysisSeverity.healthy,
        summary: 'No significant growth detected between snapshots.',
        diagnosis:
            'Total size delta: ${diff.totalSizeDelta} bytes over ${diff.timeSpan.inSeconds}s.',
        leaks: [],
        suggestions: ['Memory appears stable between snapshots.'],
      );
    }

    final leaks = growing.take(5).map((c) {
      final bytesPerSec = diff.timeSpan.inSeconds > 0
          ? c.retainedSizeDelta / diff.timeSpan.inSeconds
          : 0.0;
      return LeakCandidate(
        className: c.className,
        libraryUri: c.libraryUri,
        growthRate: bytesPerSec,
        confidence: 0.6,
        evidence: [
          'Instance delta: ${c.instanceDelta}',
          'Retained size delta: ${c.retainedSizeDelta} bytes',
        ],
      );
    }).toList();

    return AnalysisResult(
      timestamp: DateTime.now(),
      severity: AnalysisSeverity.warning,
      summary: '${growing.length} classes grew between snapshots.',
      diagnosis: 'Total size grew by ${diff.totalSizeDelta} bytes '
          'over ${diff.timeSpan.inSeconds}s.',
      leaks: leaks,
      suggestions: [
        'Review growing classes for potential leaks.',
        'Consider taking another snapshot to confirm the trend.',
      ],
    );
  }
}
