import 'dart:math' as math;

import '../models/allocation_record.dart';
import '../models/analysis_result.dart';
import '../models/leak_candidate.dart';
import '../models/memory_sample.dart';

/// Local heuristic-based memory analyzer.
///
/// Detects monotonic growth, leaking classes, memory spikes, and computes
/// growth rates from collected memory data.
class MemoryAnalyzer {
  /// Minimum consecutive growing samples to flag monotonic growth.
  static const int monotonicThreshold = 30;

  /// R-squared threshold for linear regression leak detection.
  static const double rSquaredThreshold = 0.8;

  /// Multiplier for spike detection (2x heap in <5 seconds).
  static const double spikeMultiplier = 2.0;

  /// Spike detection window.
  static const Duration spikeWindow = Duration(seconds: 5);

  /// Detects if heap usage is monotonically growing.
  ///
  /// Returns true if heapUsage increases for [monotonicThreshold]+ consecutive
  /// samples.
  static bool detectMonotonicGrowth(List<MemorySample> samples) {
    if (samples.length < monotonicThreshold) return false;

    var consecutiveGrowth = 0;
    for (var i = 1; i < samples.length; i++) {
      if (samples[i].heapUsage > samples[i - 1].heapUsage) {
        consecutiveGrowth++;
        if (consecutiveGrowth >= monotonicThreshold) return true;
      } else {
        consecutiveGrowth = 0;
      }
    }
    return false;
  }

  /// Detects classes whose instance counts are growing linearly.
  ///
  /// Uses linear regression on instancesCurrent over time. Flags classes
  /// with positive slope and R^2 > [rSquaredThreshold].
  static List<LeakCandidate> detectLeakingClasses(
    List<AllocationRecord> records,
  ) {
    if (records.length < 3) return [];

    // Collect per-class time series
    final classTimeSeries = <String, List<_TimePoint>>{};
    final classLibrary = <String, String>{};
    final baseTimeMs =
        records.first.timestamp.millisecondsSinceEpoch.toDouble();

    for (final record in records) {
      // Normalize time to relative milliseconds from first record
      final t =
          record.timestamp.millisecondsSinceEpoch.toDouble() - baseTimeMs;
      for (final cls in record.classes) {
        if (cls.instancesCurrent == 0) continue;
        classTimeSeries
            .putIfAbsent(cls.className, () => [])
            .add(_TimePoint(t, cls.instancesCurrent.toDouble()));
        classLibrary[cls.className] = cls.libraryUri;
      }
    }

    final candidates = <LeakCandidate>[];

    for (final entry in classTimeSeries.entries) {
      final points = entry.value;
      if (points.length < 3) continue;

      final regression = _linearRegression(points);
      if (regression.slope > 0 && regression.rSquared > rSquaredThreshold) {
        // Convert slope from instances/ms to instances/sec
        final instancesPerSec = regression.slope * 1000;

        // Estimate bytes growth from last record
        final lastRecord = records.last;
        final classInfo = lastRecord.classes
            .where((c) => c.className == entry.key)
            .toList();
        final avgBytesPerInstance = classInfo.isNotEmpty &&
                classInfo.first.instancesCurrent > 0
            ? classInfo.first.bytesCurrent / classInfo.first.instancesCurrent
            : 0.0;
        final bytesPerSec = instancesPerSec * avgBytesPerInstance;

        candidates.add(LeakCandidate(
          className: entry.key,
          libraryUri: classLibrary[entry.key] ?? '',
          growthRate: bytesPerSec,
          confidence: regression.rSquared,
          instanceGrowthPerSecond: instancesPerSec,
          bytesGrowthPerSecond: bytesPerSec,
          evidence: [
            'Instance count grew linearly over ${points.length} samples',
            'R² = ${regression.rSquared.toStringAsFixed(3)} '
                '(slope = ${instancesPerSec.toStringAsFixed(2)} instances/sec)',
            'Current instances: ${points.last.y.toInt()}',
          ],
        ));
      }
    }

    // Sort by confidence descending
    candidates.sort((a, b) => b.confidence.compareTo(a.confidence));
    return candidates;
  }

  /// Detects sudden memory spikes (>2x heap usage in <5 seconds).
  static List<MemorySpike> detectMemorySpikes(List<MemorySample> samples) {
    if (samples.length < 2) return [];

    final spikes = <MemorySpike>[];

    for (var i = 1; i < samples.length; i++) {
      final current = samples[i];
      // Look back within the spike window
      for (var j = i - 1; j >= 0; j--) {
        final previous = samples[j];
        final timeDelta = current.timestamp.difference(previous.timestamp);
        if (timeDelta > spikeWindow) break;

        if (previous.heapUsage > 0 &&
            current.heapUsage > previous.heapUsage * spikeMultiplier) {
          spikes.add(MemorySpike(
            timestamp: current.timestamp,
            previousUsage: previous.heapUsage,
            spikeUsage: current.heapUsage,
            duration: timeDelta,
          ));
          break;
        }
      }
    }

    return spikes;
  }

  /// Computes growth rate in bytes/sec for each class across allocation records.
  static Map<String, double> computeGrowthRates(
    List<AllocationRecord> records,
  ) {
    if (records.length < 2) return {};

    final first = records.first;
    final last = records.last;
    final durationSec =
        last.timestamp.difference(first.timestamp).inMilliseconds / 1000.0;
    if (durationSec <= 0) return {};

    final firstMap = <String, int>{};
    for (final cls in first.classes) {
      firstMap[cls.className] = cls.bytesCurrent;
    }

    final rates = <String, double>{};
    for (final cls in last.classes) {
      final firstBytes = firstMap[cls.className] ?? 0;
      final delta = cls.bytesCurrent - firstBytes;
      if (delta > 0) {
        rates[cls.className] = delta / durationSec;
      }
    }

    return rates;
  }

  /// Runs all local heuristics and produces an AnalysisResult.
  static AnalysisResult analyze({
    required List<MemorySample> samples,
    required List<AllocationRecord> allocations,
  }) {
    final isGrowing = detectMonotonicGrowth(samples);
    final leaks = detectLeakingClasses(allocations);
    final spikes = detectMemorySpikes(samples);

    // Determine severity
    AnalysisSeverity severity;
    if (leaks.any((l) => l.severity == LeakSeverity.critical)) {
      severity = AnalysisSeverity.critical;
    } else if (isGrowing || leaks.isNotEmpty) {
      severity = AnalysisSeverity.warning;
    } else if (spikes.isNotEmpty) {
      severity = AnalysisSeverity.info;
    } else {
      severity = AnalysisSeverity.healthy;
    }

    // Build summary
    final summaryParts = <String>[];
    if (isGrowing) {
      summaryParts.add('Monotonic heap growth detected');
    }
    if (leaks.isNotEmpty) {
      summaryParts
          .add('${leaks.length} potential leak(s) detected');
    }
    if (spikes.isNotEmpty) {
      summaryParts.add('${spikes.length} memory spike(s) detected');
    }
    if (summaryParts.isEmpty) {
      summaryParts.add('No memory issues detected');
    }

    // Build diagnosis
    final diagParts = <String>[];
    if (samples.isNotEmpty) {
      final latest = samples.last;
      diagParts.add(
          'Current heap: ${_formatBytes(latest.heapUsage)} / ${_formatBytes(latest.heapCapacity)}');
      diagParts.add('External: ${_formatBytes(latest.externalUsage)}');
    }
    if (isGrowing) {
      diagParts.add(
          'Heap usage has been monotonically increasing for $monotonicThreshold+ samples.');
    }
    for (final leak in leaks) {
      diagParts.add(
          'Class ${leak.className}: growing at ${leak.instanceGrowthPerSecond.toStringAsFixed(1)} instances/sec '
          '(confidence: ${(leak.confidence * 100).toStringAsFixed(0)}%)');
    }
    for (final spike in spikes) {
      diagParts.add(
          'Spike: ${_formatBytes(spike.previousUsage)} -> ${_formatBytes(spike.spikeUsage)} '
          'in ${spike.duration.inMilliseconds}ms');
    }

    // Suggestions
    final suggestions = <String>[];
    if (isGrowing) {
      suggestions.add(
          'Take a heap snapshot to identify which objects are accumulating.');
    }
    if (leaks.isNotEmpty) {
      suggestions.add(
          'Review disposal patterns for: ${leaks.map((l) => l.className).join(', ')}');
      suggestions.add(
          'Check for missing removeListener / cancel calls in StatefulWidget.dispose().');
    }
    if (spikes.isNotEmpty) {
      suggestions.add(
          'Investigate large allocations near spike timestamps. '
          'Consider lazy loading or pagination.');
    }
    if (severity == AnalysisSeverity.healthy) {
      suggestions.add('Memory usage appears stable. Continue monitoring.');
    }

    return AnalysisResult(
      timestamp: DateTime.now(),
      severity: severity,
      summary: summaryParts.join('. '),
      diagnosis: diagParts.join('\n'),
      leaks: leaks,
      suggestions: suggestions,
    );
  }

  static String _formatBytes(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
  }

  /// Simple linear regression on a list of time points.
  static _RegressionResult _linearRegression(List<_TimePoint> points) {
    final n = points.length.toDouble();
    var sumX = 0.0;
    var sumY = 0.0;
    var sumXY = 0.0;
    var sumX2 = 0.0;

    for (final p in points) {
      sumX += p.x;
      sumY += p.y;
      sumXY += p.x * p.y;
      sumX2 += p.x * p.x;
    }

    final slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    final intercept = (sumY - slope * sumX) / n;

    // R-squared
    final meanY = sumY / n;
    var ssRes = 0.0;
    var ssTot = 0.0;
    for (final p in points) {
      final predicted = slope * p.x + intercept;
      ssRes += math.pow(p.y - predicted, 2);
      ssTot += math.pow(p.y - meanY, 2);
    }

    final rSquared = ssTot > 0 ? 1.0 - (ssRes / ssTot) : 0.0;

    return _RegressionResult(
      slope: slope,
      intercept: intercept,
      rSquared: rSquared.clamp(0.0, 1.0),
    );
  }
}

class _TimePoint {
  const _TimePoint(this.x, this.y);
  final double x;
  final double y;
}

class _RegressionResult {
  const _RegressionResult({
    required this.slope,
    required this.intercept,
    required this.rSquared,
  });
  final double slope;
  final double intercept;
  final double rSquared;
}

/// Represents a detected memory spike.
class MemorySpike {
  MemorySpike({
    required this.timestamp,
    required this.previousUsage,
    required this.spikeUsage,
    required this.duration,
  });

  final DateTime timestamp;
  final int previousUsage;
  final int spikeUsage;
  final Duration duration;

  double get multiplier =>
      previousUsage > 0 ? spikeUsage / previousUsage : double.infinity;
}
