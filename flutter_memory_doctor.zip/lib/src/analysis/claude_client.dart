import 'dart:convert';

import 'package:http/http.dart' as http;

/// Client for the Anthropic Messages API.
class ClaudeClient {
  ClaudeClient({
    required this.apiKey,
    this.model = 'claude-sonnet-4-20250514',
    this.baseUrl = 'https://api.anthropic.com',
    this.maxTokens = 4096,
    http.Client? httpClient,
  }) : _httpClient = httpClient ?? http.Client();

  final String apiKey;
  final String model;
  final String baseUrl;
  final int maxTokens;
  final http.Client _httpClient;

  /// Sends a message to the Anthropic Messages API and returns the response.
  Future<ClaudeResponse> sendMessage({
    required String systemPrompt,
    required String userMessage,
  }) async {
    final url = Uri.parse('$baseUrl/v1/messages');

    final body = jsonEncode({
      'model': model,
      'max_tokens': maxTokens,
      'system': systemPrompt,
      'messages': [
        {
          'role': 'user',
          'content': userMessage,
        },
      ],
    });

    final response = await _httpClient.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: body,
    );

    if (response.statusCode != 200) {
      throw ClaudeApiException(
        statusCode: response.statusCode,
        message: 'API request failed: ${response.body}',
      );
    }

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return ClaudeResponse.fromJson(json);
  }

  /// Sends a message and extracts the text content.
  Future<String> ask({
    required String systemPrompt,
    required String userMessage,
  }) async {
    final response = await sendMessage(
      systemPrompt: systemPrompt,
      userMessage: userMessage,
    );
    return response.textContent;
  }

  /// Sends a message and parses the response as JSON.
  Future<Map<String, dynamic>> askJson({
    required String systemPrompt,
    required String userMessage,
  }) async {
    final text = await ask(
      systemPrompt: systemPrompt,
      userMessage: userMessage,
    );

    // Extract JSON from response (may be wrapped in markdown code blocks)
    final jsonStr = _extractJson(text);
    return jsonDecode(jsonStr) as Map<String, dynamic>;
  }

  /// Extracts JSON from text that may contain markdown code blocks.
  String _extractJson(String text) {
    // Try to find JSON in code blocks
    final codeBlockPattern = RegExp(r'```(?:json)?\s*\n?([\s\S]*?)\n?```');
    final match = codeBlockPattern.firstMatch(text);
    if (match != null) {
      return match.group(1)!.trim();
    }

    // Try to find raw JSON object/array
    final jsonStart = text.indexOf('{');
    final jsonEnd = text.lastIndexOf('}');
    if (jsonStart >= 0 && jsonEnd > jsonStart) {
      return text.substring(jsonStart, jsonEnd + 1);
    }

    return text;
  }

  void dispose() {
    _httpClient.close();
  }
}

/// Response from the Anthropic Messages API.
class ClaudeResponse {
  ClaudeResponse({
    required this.id,
    required this.model,
    required this.content,
    required this.stopReason,
    required this.usage,
  });

  factory ClaudeResponse.fromJson(Map<String, dynamic> json) {
    final content = (json['content'] as List<dynamic>)
        .map((e) => ContentBlock.fromJson(e as Map<String, dynamic>))
        .toList();

    final usage = json['usage'] as Map<String, dynamic>;

    return ClaudeResponse(
      id: json['id'] as String,
      model: json['model'] as String,
      content: content,
      stopReason: json['stop_reason'] as String?,
      usage: TokenUsage(
        inputTokens: usage['input_tokens'] as int,
        outputTokens: usage['output_tokens'] as int,
      ),
    );
  }

  final String id;
  final String model;
  final List<ContentBlock> content;
  final String? stopReason;
  final TokenUsage usage;

  /// Returns concatenated text from all text content blocks.
  String get textContent =>
      content.where((b) => b.type == 'text').map((b) => b.text).join('\n');
}

/// A content block in a Claude response.
class ContentBlock {
  ContentBlock({
    required this.type,
    this.text = '',
  });

  factory ContentBlock.fromJson(Map<String, dynamic> json) {
    return ContentBlock(
      type: json['type'] as String,
      text: json['text'] as String? ?? '',
    );
  }

  final String type;
  final String text;
}

/// Token usage information.
class TokenUsage {
  TokenUsage({
    required this.inputTokens,
    required this.outputTokens,
  });

  final int inputTokens;
  final int outputTokens;

  int get totalTokens => inputTokens + outputTokens;
}

/// Exception thrown for Claude API errors.
class ClaudeApiException implements Exception {
  ClaudeApiException({
    required this.statusCode,
    required this.message,
  });

  final int statusCode;
  final String message;

  @override
  String toString() => 'ClaudeApiException($statusCode): $message';
}
