import 'dart:convert';

import '../models/allocation_record.dart';
import '../models/analysis_result.dart';
import '../models/heap_snapshot_summary.dart';
import '../models/leak_candidate.dart';
import '../models/memory_sample.dart';

/// Prompt templates for Claude API analysis and code fix generation.
class ClaudePrompts {
  /// System prompt for memory analysis.
  static const String analysisSystemPrompt = '''
You are an expert Flutter/Dart memory diagnostics assistant. You analyze memory
usage data from running Flutter applications and identify memory leaks, excessive
allocations, and performance issues.

You always respond with valid JSON matching the requested schema. Do not include
any text outside the JSON response.
''';

  /// System prompt for code fix generation.
  static const String fixSystemPrompt = '''
You are an expert Flutter/Dart developer specializing in memory management.
You generate precise code fixes for memory leaks and excessive allocations.

You always respond with valid JSON matching the requested schema. Each fix must
include the exact original code to replace and the corrected code. Do not include
any text outside the JSON response.
''';

  /// Builds the user message for memory trend analysis.
  ///
  /// Sends time-series data, top classes by allocation, and growth rates.
  static String buildTrendAnalysisPrompt({
    required List<MemorySample> samples,
    required List<AllocationRecord> allocations,
    required Map<String, double> growthRates,
    required List<LeakCandidate> localLeaks,
  }) {
    // Downsample to at most 60 data points for the prompt
    final downsampled = _downsample(samples, 60);

    final sampleData = downsampled.map((s) => {
          'ts': s.timestamp.toIso8601String(),
          'heap': s.heapUsage,
          'cap': s.heapCapacity,
          'ext': s.externalUsage,
        });

    // Top 20 classes by current bytes from latest allocation
    List<Map<String, dynamic>> topClasses = [];
    if (allocations.isNotEmpty) {
      topClasses = allocations.last.topBySize
          .take(20)
          .map((c) => {
                'class': c.className,
                'lib': c.libraryUri,
                'instances': c.instancesCurrent,
                'bytes': c.bytesCurrent,
              })
          .toList();
    }

    // Top growth rates
    final topGrowth = (growthRates.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .take(10)
        .map((e) => {'class': e.key, 'bytesPerSec': e.value})
        .toList();

    final localLeakData = localLeaks
        .map((l) => {
              'class': l.className,
              'confidence': l.confidence,
              'growthRate': l.growthRate,
              'evidence': l.evidence,
            })
        .toList();

    return jsonEncode({
      'task': 'memory_trend_analysis',
      'samples': sampleData.toList(),
      'topClasses': topClasses,
      'growthRates': topGrowth,
      'localLeaks': localLeakData,
      'responseSchema': {
        'severity': 'healthy|info|warning|critical',
        'summary': 'string - one sentence summary',
        'diagnosis': 'string - detailed diagnosis',
        'leaks': [
          {
            'className': 'string',
            'libraryUri': 'string',
            'growthRate': 'number - bytes/sec',
            'confidence': 'number 0-1',
            'evidence': ['string'],
          }
        ],
        'suggestions': ['string - actionable suggestions'],
      },
    });
  }

  /// Builds the user message for heap snapshot diff analysis.
  static String buildSnapshotDiffPrompt({
    required HeapSnapshotDiff diff,
  }) {
    final growingClasses = diff.growingClasses
        .take(20)
        .map((c) => {
              'class': c.className,
              'lib': c.libraryUri,
              'instanceDelta': c.instanceDelta,
              'retainedSizeDelta': c.retainedSizeDelta,
            })
        .toList();

    final newClasses = diff.newClasses
        .take(10)
        .map((c) => {
              'class': c.className,
              'lib': c.libraryUri,
              'instances': c.instanceCount,
              'retainedSize': c.retainedSize,
            })
        .toList();

    return jsonEncode({
      'task': 'heap_snapshot_diff',
      'timeSpanSeconds': diff.timeSpan.inSeconds,
      'totalSizeDelta': diff.totalSizeDelta,
      'totalObjectsDelta': diff.totalObjectsDelta,
      'growingClasses': growingClasses,
      'newClasses': newClasses,
      'responseSchema': {
        'severity': 'healthy|info|warning|critical',
        'summary': 'string',
        'diagnosis': 'string',
        'leaks': [
          {
            'className': 'string',
            'libraryUri': 'string',
            'growthRate': 'number',
            'confidence': 'number 0-1',
            'evidence': ['string'],
          }
        ],
        'suggestions': ['string'],
      },
    });
  }

  /// Builds the user message for code fix generation.
  static String buildFixGenerationPrompt({
    required AnalysisResult analysis,
    required Map<String, String> sourceFiles,
  }) {
    final sourceData = sourceFiles.entries
        .map((e) => {
              'path': e.key,
              'content': e.value,
            })
        .toList();

    final leakData = analysis.leaks
        .map((l) => {
              'className': l.className,
              'libraryUri': l.libraryUri,
              'evidence': l.evidence,
            })
        .toList();

    return jsonEncode({
      'task': 'generate_fixes',
      'diagnosis': analysis.diagnosis,
      'leaks': leakData,
      'sourceFiles': sourceData,
      'responseSchema': {
        'fixes': [
          {
            'filePath': 'string',
            'startLine': 'number',
            'endLine': 'number',
            'originalCode': 'string - exact code to replace',
            'patchedCode': 'string - fixed code',
            'explanation': 'string',
            'leakClassName': 'string|null',
          }
        ],
      },
    });
  }

  /// Downsamples a list of samples to at most [maxPoints] entries.
  static List<MemorySample> _downsample(
      List<MemorySample> samples, int maxPoints) {
    if (samples.length <= maxPoints) return samples;

    final step = samples.length / maxPoints;
    final result = <MemorySample>[];
    for (var i = 0.0; i < samples.length; i += step) {
      result.add(samples[i.floor()]);
    }
    // Always include the last sample
    if (result.last != samples.last) {
      result.add(samples.last);
    }
    return result;
  }
}
