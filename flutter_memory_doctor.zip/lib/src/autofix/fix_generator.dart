import 'dart:io';

import 'package:path/path.dart' as p;

import '../analysis/analysis_orchestrator.dart';
import '../models/analysis_result.dart';
import '../models/fix_patch.dart';

/// Generates code fixes for detected memory issues using Claude.
class FixGenerator {
  FixGenerator({
    required this.orchestrator,
    required this.projectRoot,
  });

  final AnalysisOrchestrator orchestrator;
  final String projectRoot;

  /// Generates fix patches for the given analysis result.
  ///
  /// Resolves source files from leak library URIs, reads them,
  /// and sends to Claude for fix generation.
  Future<List<FixPatch>> generateFixes(AnalysisResult analysis) async {
    if (analysis.leaks.isEmpty) return [];

    // Collect source files referenced by leaks
    final sourceFiles = <String, String>{};

    for (final leak in analysis.leaks) {
      final filePath = _resolveLibraryUri(leak.libraryUri);
      if (filePath != null && !sourceFiles.containsKey(filePath)) {
        final file = File(filePath);
        if (file.existsSync()) {
          sourceFiles[filePath] = file.readAsStringSync();
        }
      }
    }

    if (sourceFiles.isEmpty) {
      return [];
    }

    return orchestrator.generateFixes(
      analysis: analysis,
      sourceFiles: sourceFiles,
    );
  }

  /// Resolves a Dart library URI to an absolute file path.
  ///
  /// Handles `package:` URIs by looking in lib/ and .dart_tool/package_config.
  /// Handles `file:` URIs directly. Handles relative paths.
  String? _resolveLibraryUri(String uri) {
    if (uri.isEmpty) return null;

    // file: URI
    if (uri.startsWith('file://')) {
      return Uri.parse(uri).toFilePath();
    }

    // package: URI — resolve relative to project root
    if (uri.startsWith('package:')) {
      final packagePath = uri.substring('package:'.length);
      final parts = packagePath.split('/');
      if (parts.length < 2) return null;

      // Try lib/ directory
      final libPath = p.join(projectRoot, 'lib', parts.sublist(1).join('/'));
      if (File(libPath).existsSync()) return libPath;

      return null;
    }

    // Relative path
    final resolved = p.join(projectRoot, uri);
    if (File(resolved).existsSync()) return resolved;

    return null;
  }
}
