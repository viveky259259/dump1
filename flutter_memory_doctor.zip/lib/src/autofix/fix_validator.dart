import 'dart:io';

/// Validates applied fixes by running `dart analyze` on the target project.
class FixValidator {
  FixValidator({
    required this.projectRoot,
  });

  final String projectRoot;

  /// Runs `dart analyze` and returns the result.
  Future<ValidationResult> validate() async {
    final result = await Process.run(
      'dart',
      ['analyze', '--no-fatal-warnings'],
      workingDirectory: projectRoot,
    );

    final stdout = result.stdout as String;
    final stderr = result.stderr as String;
    final output = '$stdout\n$stderr'.trim();

    // Parse issue count from dart analyze output
    final issues = _parseIssues(output);

    return ValidationResult(
      exitCode: result.exitCode,
      output: output,
      issues: issues,
      passed: result.exitCode == 0,
    );
  }

  /// Validates a specific file.
  Future<ValidationResult> validateFile(String filePath) async {
    final result = await Process.run(
      'dart',
      ['analyze', filePath],
      workingDirectory: projectRoot,
    );

    final stdout = result.stdout as String;
    final stderr = result.stderr as String;
    final output = '$stdout\n$stderr'.trim();

    return ValidationResult(
      exitCode: result.exitCode,
      output: output,
      issues: _parseIssues(output),
      passed: result.exitCode == 0,
    );
  }

  List<AnalysisIssue> _parseIssues(String output) {
    final issues = <AnalysisIssue>[];
    // Parse lines like: "  error - message - path:line:col - code"
    final pattern = RegExp(
      r'\s*(error|warning|info)\s*[-•]\s*(.+?)\s*[-•]\s*(.+?):(\d+):(\d+)\s*[-•]\s*(\S+)',
    );

    for (final match in pattern.allMatches(output)) {
      issues.add(AnalysisIssue(
        severity: match.group(1)!,
        message: match.group(2)!.trim(),
        file: match.group(3)!.trim(),
        line: int.parse(match.group(4)!),
        column: int.parse(match.group(5)!),
        code: match.group(6)!,
      ));
    }

    return issues;
  }
}

/// Result of running dart analyze.
class ValidationResult {
  ValidationResult({
    required this.exitCode,
    required this.output,
    required this.issues,
    required this.passed,
  });

  final int exitCode;
  final String output;
  final List<AnalysisIssue> issues;
  final bool passed;

  int get errorCount => issues.where((i) => i.severity == 'error').length;
  int get warningCount => issues.where((i) => i.severity == 'warning').length;

  @override
  String toString() => passed
      ? 'Validation passed'
      : 'Validation failed: $errorCount errors, $warningCount warnings';
}

/// A single issue from dart analyze.
class AnalysisIssue {
  AnalysisIssue({
    required this.severity,
    required this.message,
    required this.file,
    required this.line,
    required this.column,
    required this.code,
  });

  final String severity;
  final String message;
  final String file;
  final int line;
  final int column;
  final String code;

  @override
  String toString() => '$severity: $message ($file:$line:$column) [$code]';
}
