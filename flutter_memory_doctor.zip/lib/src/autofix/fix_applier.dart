import 'dart:io';

import '../models/fix_patch.dart';

/// Applies generated code patches to source files.
///
/// Creates backups before modification and verifies original code matches.
class FixApplier {
  FixApplier({
    this.requireConfirmation = true,
    this.confirmCallback,
  });

  /// Whether to require user confirmation before applying.
  final bool requireConfirmation;

  /// Callback for user confirmation. If null and [requireConfirmation] is true,
  /// fix will not be applied (use for dashboard/API mode).
  final Future<bool> Function(FixPatch fix)? confirmCallback;

  /// Applies a single fix patch.
  ///
  /// Returns true if the fix was applied successfully.
  Future<bool> applyFix(FixPatch fix) async {
    final file = File(fix.filePath);
    if (!file.existsSync()) {
      throw FixApplierException('File not found: ${fix.filePath}');
    }

    final content = file.readAsStringSync();
    final lines = content.split('\n');

    // Verify line range is valid
    if (fix.startLine < 1 || fix.endLine > lines.length) {
      throw FixApplierException(
        'Invalid line range ${fix.startLine}-${fix.endLine} '
        'for file with ${lines.length} lines.',
      );
    }

    // Extract original code from file and verify it matches
    final actualOriginal =
        lines.sublist(fix.startLine - 1, fix.endLine).join('\n');
    final expectedOriginal = fix.originalCode.trimRight();

    if (_normalize(actualOriginal) != _normalize(expectedOriginal)) {
      return false;
    }

    // Confirm with user if required
    if (requireConfirmation && confirmCallback != null) {
      final confirmed = await confirmCallback!(fix);
      if (!confirmed) return false;
    }

    // Create backup
    final backupPath = '${fix.filePath}.memory_doctor_backup';
    file.copySync(backupPath);

    // Apply the patch
    final newLines = <String>[
      ...lines.sublist(0, fix.startLine - 1),
      ...fix.patchedCode.split('\n'),
      ...lines.sublist(fix.endLine),
    ];

    file.writeAsStringSync(newLines.join('\n'));

    return true;
  }

  /// Applies multiple fixes to the same file, adjusting line numbers.
  ///
  /// Fixes must be sorted by startLine descending to avoid offset issues.
  Future<List<bool>> applyFixes(List<FixPatch> fixes) async {
    // Sort by startLine descending so later fixes don't shift earlier ones
    final sorted = List<FixPatch>.from(fixes)
      ..sort((a, b) => b.startLine.compareTo(a.startLine));

    final results = <bool>[];
    for (final fix in sorted) {
      results.add(await applyFix(fix));
    }
    return results;
  }

  /// Restores a file from its backup.
  static bool restoreBackup(String filePath) {
    final backupPath = '$filePath.memory_doctor_backup';
    final backup = File(backupPath);
    if (!backup.existsSync()) return false;

    backup.copySync(filePath);
    backup.deleteSync();
    return true;
  }

  /// Normalizes whitespace for comparison.
  String _normalize(String s) =>
      s.replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// Exception thrown when fix application fails.
class FixApplierException implements Exception {
  FixApplierException(this.message);
  final String message;

  @override
  String toString() => 'FixApplierException: $message';
}
