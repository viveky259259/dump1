import 'dart:async';
import 'dart:convert';

import 'package:shelf/shelf.dart';

import '../models/memory_sample.dart';

/// Server-Sent Events handler for real-time memory data push.
class SseHandler {
  final _clients = <_SseClient>[];
  StreamSubscription<MemorySample>? _subscription;

  /// Number of connected SSE clients.
  int get clientCount => _clients.length;

  /// Starts listening to a sample stream and forwards to all SSE clients.
  void listenToSamples(Stream<MemorySample> sampleStream) {
    _subscription = sampleStream.listen((sample) {
      broadcast('sample', sample.toJson());
    });
  }

  /// Broadcasts an event to all connected SSE clients.
  void broadcast(String event, Map<String, dynamic> data) {
    final message = 'event: $event\ndata: ${jsonEncode(data)}\n\n';
    final disconnected = <_SseClient>[];

    for (final client in _clients) {
      try {
        client.sink.add(message);
      } catch (_) {
        disconnected.add(client);
      }
    }

    for (final client in disconnected) {
      _clients.remove(client);
      client.sink.close();
    }
  }

  /// Shelf handler for SSE connections at GET /api/samples/stream.
  Response handle(Request request) {
    final controller = StreamController<String>();

    final client = _SseClient(sink: controller);
    _clients.add(client);

    // Send initial connection event
    controller.add('event: connected\ndata: {"status":"ok"}\n\n');

    // Remove client on disconnect
    controller.onCancel = () {
      _clients.remove(client);
    };

    return Response.ok(
      controller.stream,
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*',
      },
    );
  }

  /// Sends an analysis event to all clients.
  void sendAnalysis(Map<String, dynamic> data) {
    broadcast('analysis', data);
  }

  /// Sends a snapshot event to all clients.
  void sendSnapshot(Map<String, dynamic> data) {
    broadcast('snapshot', data);
  }

  /// Disposes resources.
  Future<void> dispose() async {
    await _subscription?.cancel();
    for (final client in _clients) {
      await client.sink.close();
    }
    _clients.clear();
  }
}

class _SseClient {
  _SseClient({required this.sink});
  final StreamController<String> sink;
}
