import 'dart:io';

import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;

import '../analysis/analysis_orchestrator.dart';
import '../autofix/fix_applier.dart';
import '../autofix/fix_generator.dart';
import '../collector/heap_snapshot_manager.dart';
import '../collector/memory_collector.dart';
import 'api_routes.dart';
import 'sse_handler.dart';
import 'static_assets.dart';

/// HTTP server for the memory doctor dashboard.
///
/// Serves REST API endpoints and static web assets.
class DashboardServer {
  DashboardServer({
    required this.dataStore,
    required this.snapshotManager,
    required this.orchestrator,
    this.fixGenerator,
    this.fixApplier,
    this.port = 8080,
    String? webRoot,
  })  : _sseHandler = SseHandler(),
        _staticAssets = StaticAssets(webRoot: webRoot);

  final MemoryDataStore dataStore;
  final HeapSnapshotManager snapshotManager;
  final AnalysisOrchestrator orchestrator;
  final FixGenerator? fixGenerator;
  final FixApplier? fixApplier;
  final int port;

  final SseHandler _sseHandler;
  final StaticAssets _staticAssets;

  HttpServer? _server;

  /// Whether the server is running.
  bool get isRunning => _server != null;

  /// The SSE handler for broadcasting events.
  SseHandler get sseHandler => _sseHandler;

  /// Starts the HTTP server.
  Future<void> start() async {
    if (_server != null) return;

    // Wire up SSE to data store
    _sseHandler.listenToSamples(dataStore.onSample);

    final apiRoutes = ApiRoutes(
      dataStore: dataStore,
      snapshotManager: snapshotManager,
      orchestrator: orchestrator,
      sseHandler: _sseHandler,
      fixGenerator: fixGenerator,
      fixApplier: fixApplier,
    );

    final handler = const Pipeline()
        .addMiddleware(_corsMiddleware())
        .addMiddleware(logRequests())
        .addHandler((Request request) async {
      // Try API routes first
      final apiRouter = apiRoutes.router;
      final apiResponse = await apiRouter.call(request);
      if (apiResponse.statusCode != 404) {
        return apiResponse;
      }

      // Try static files
      final staticResponse = _staticAssets.serveFile(request);
      if (staticResponse != null) {
        return staticResponse;
      }

      // Fallback to index.html for SPA routing
      if (!request.url.path.startsWith('api/')) {
        final indexResponse = _staticAssets.serveFile(
          Request('GET', Uri.parse('http://localhost/index.html')),
        );
        if (indexResponse != null) return indexResponse;
      }

      return Response.notFound('Not found');
    });

    _server = await shelf_io.serve(handler, InternetAddress.anyIPv4, port);
  }

  /// Stops the HTTP server.
  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
    await _sseHandler.dispose();
  }

  /// Creates CORS middleware.
  static Middleware _corsMiddleware() {
    return createMiddleware(
      requestHandler: (Request request) {
        if (request.method == 'OPTIONS') {
          return Response.ok(
            '',
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
              'Access-Control-Allow-Headers': 'Content-Type',
            },
          );
        }
        return null;
      },
      responseHandler: (Response response) {
        return response.change(headers: {
          'Access-Control-Allow-Origin': '*',
        });
      },
    );
  }
}
