import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:shelf/shelf.dart';

/// Serves static web assets (HTML/JS/CSS) for the dashboard.
class StaticAssets {
  StaticAssets({String? webRoot}) : _webRoot = webRoot;

  final String? _webRoot;

  /// Resolves the web directory path.
  String get webDirectory {
    if (_webRoot != null) return _webRoot!;

    // Try relative to script location
    final scriptDir = p.dirname(Platform.script.toFilePath());
    final candidates = [
      p.join(scriptDir, '..', 'web'),
      p.join(scriptDir, 'web'),
      p.join(Directory.current.path, 'web'),
    ];

    for (final candidate in candidates) {
      if (Directory(candidate).existsSync()) {
        return candidate;
      }
    }

    return p.join(Directory.current.path, 'web');
  }

  /// Shelf handler for serving static files.
  Response? serveFile(Request request) {
    var filePath = request.url.path;
    if (filePath.isEmpty || filePath == '/') {
      filePath = 'index.html';
    }

    final fullPath = p.join(webDirectory, filePath);
    final file = File(fullPath);

    if (!file.existsSync()) {
      return null;
    }

    final contentType = _contentType(filePath);
    return Response.ok(
      file.openRead(),
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'no-cache',
      },
    );
  }

  String _contentType(String path) {
    final ext = p.extension(path).toLowerCase();
    switch (ext) {
      case '.html':
        return 'text/html; charset=utf-8';
      case '.js':
        return 'application/javascript; charset=utf-8';
      case '.css':
        return 'text/css; charset=utf-8';
      case '.json':
        return 'application/json; charset=utf-8';
      case '.png':
        return 'image/png';
      case '.svg':
        return 'image/svg+xml';
      case '.ico':
        return 'image/x-icon';
      default:
        return 'application/octet-stream';
    }
  }
}
