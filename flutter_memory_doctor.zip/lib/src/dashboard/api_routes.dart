import 'dart:convert';

import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

import '../analysis/analysis_orchestrator.dart';
import '../autofix/fix_applier.dart';
import '../autofix/fix_generator.dart';
import '../collector/heap_snapshot_manager.dart';
import '../collector/memory_collector.dart';
import '../models/fix_patch.dart';
import 'sse_handler.dart';

/// REST API routes for the dashboard.
class ApiRoutes {
  ApiRoutes({
    required this.dataStore,
    this.snapshotManager,
    required this.orchestrator,
    required this.sseHandler,
    this.fixGenerator,
    this.fixApplier,
  });

  final MemoryDataStore dataStore;
  final HeapSnapshotManager? snapshotManager;
  final AnalysisOrchestrator orchestrator;
  final SseHandler sseHandler;
  final FixGenerator? fixGenerator;
  final FixApplier? fixApplier;

  List<FixPatch> _lastFixes = [];

  /// Builds the shelf Router with all API routes.
  Router get router {
    final router = Router();

    router.get('/api/samples', _getSamples);
    router.get('/api/samples/stream', _getSamplesStream);
    router.get('/api/allocations', _getAllocations);
    router.post('/api/snapshot', _takeSnapshot);
    router.get('/api/snapshots', _getSnapshots);
    router.post('/api/analyze', _runAnalysis);
    router.get('/api/analysis', _getLastAnalysis);
    router.post('/api/fix/generate', _generateFixes);
    router.post('/api/fix/apply', _applyFix);
    router.get('/api/status', _getStatus);

    return router;
  }

  Future<Response> _getSamples(Request request) async {
    final countParam = request.url.queryParameters['count'];
    final count = countParam != null ? int.tryParse(countParam) : null;

    final samples = count != null
        ? dataStore.recentSamples(count)
        : dataStore.samples;

    return _jsonResponse(samples.map((s) => s.toJson()).toList());
  }

  Response _getSamplesStream(Request request) {
    return sseHandler.handle(request);
  }

  Future<Response> _getAllocations(Request request) async {
    final allocations = dataStore.allocations;
    return _jsonResponse(allocations.map((a) => a.toJson()).toList());
  }

  Future<Response> _takeSnapshot(Request request) async {
    final mgr = snapshotManager;
    if (mgr == null) {
      return _errorResponse('Snapshot manager not available.', statusCode: 501);
    }
    try {
      final summary = await mgr.takeSnapshot();

      // Push to SSE clients
      sseHandler.sendSnapshot(summary.toJson());

      // Check for diff
      final diff = mgr.diffLatest();
      final responseData = <String, dynamic>{
        'snapshot': summary.toJson(),
        if (diff != null) 'diff': diff.toJson(),
      };

      return _jsonResponse(responseData);
    } catch (e) {
      return _errorResponse('Failed to take snapshot: $e');
    }
  }

  Future<Response> _getSnapshots(Request request) async {
    final snapshots = snapshotManager?.history ?? [];
    return _jsonResponse(snapshots.map((s) => s.toJson()).toList());
  }

  Future<Response> _runAnalysis(Request request) async {
    try {
      final body = await request.readAsString();
      final params =
          body.isNotEmpty ? jsonDecode(body) as Map<String, dynamic> : <String, dynamic>{};

      final useClaude = params['useClaude'] as bool? ?? true;

      final result = useClaude
          ? await orchestrator.analyzeWithClaude()
          : orchestrator.analyzeLocal();

      // Push to SSE clients
      sseHandler.sendAnalysis(result.toJson());

      return _jsonResponse(result.toJson());
    } catch (e) {
      return _errorResponse('Analysis failed: $e');
    }
  }

  Future<Response> _getLastAnalysis(Request request) async {
    final result = orchestrator.lastResult;
    if (result == null) {
      return _jsonResponse({'status': 'no_analysis_yet'});
    }
    return _jsonResponse(result.toJson());
  }

  Future<Response> _generateFixes(Request request) async {
    final gen = fixGenerator;
    if (gen == null) {
      return _errorResponse(
          'Fix generation not available. Provide --project-root and --api-key.',
          statusCode: 501);
    }

    try {
      final analysis = orchestrator.lastResult;
      if (analysis == null || analysis.leaks.isEmpty) {
        return _errorResponse('No analysis with leaks available. Run analyze first.');
      }

      final fixes = await gen.generateFixes(analysis);
      _lastFixes = fixes;

      return _jsonResponse({
        'fixes': fixes.map((f) => f.toJson()).toList(),
      });
    } catch (e) {
      return _errorResponse('Fix generation failed: $e');
    }
  }

  Future<Response> _applyFix(Request request) async {
    final applier = fixApplier;
    if (applier == null) {
      return _errorResponse('Fix application not available.', statusCode: 501);
    }

    try {
      final body = jsonDecode(await request.readAsString()) as Map<String, dynamic>;
      final fixIndex = body['fixIndex'] as int;

      if (fixIndex < 0 || fixIndex >= _lastFixes.length) {
        return _errorResponse('Invalid fix index: $fixIndex');
      }

      final fix = _lastFixes[fixIndex];
      final applied = await applier.applyFix(fix);

      return _jsonResponse({
        'applied': applied,
        'fix': fix.toJson(),
        if (applied) 'backupPath': '${fix.filePath}.memory_doctor_backup',
      });
    } catch (e) {
      return _errorResponse('Failed to apply fix: $e');
    }
  }

  Future<Response> _getStatus(Request request) async {
    final latest = dataStore.latestSample;
    return _jsonResponse({
      'connected': true,
      'sampleCount': dataStore.samples.length,
      'allocationCount': dataStore.allocations.length,
      'snapshotCount': snapshotManager?.history.length ?? 0,
      'sseClients': sseHandler.clientCount,
      if (latest != null) 'latestSample': latest.toJson(),
      'hasAnalysis': orchestrator.lastResult != null,
    });
  }

  Response _jsonResponse(Object data, {int statusCode = 200}) {
    return Response(
      statusCode,
      body: jsonEncode(data),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    );
  }

  Response _errorResponse(String message, {int statusCode = 500}) {
    return Response(
      statusCode,
      body: jsonEncode({'error': message}),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    );
  }
}
