/// Summarized heap snapshot data aggregated from HeapSnapshotGraph.
class HeapSnapshotSummary {
  HeapSnapshotSummary({
    required this.timestamp,
    required this.totalSize,
    required this.totalObjects,
    required this.totalExternalSize,
    required this.classes,
  });

  factory HeapSnapshotSummary.fromJson(Map<String, dynamic> json) {
    return HeapSnapshotSummary(
      timestamp: DateTime.parse(json['timestamp'] as String),
      totalSize: json['totalSize'] as int,
      totalObjects: json['totalObjects'] as int,
      totalExternalSize: json['totalExternalSize'] as int,
      classes: (json['classes'] as List<dynamic>)
          .map((e) => ClassSummary.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  final DateTime timestamp;
  final int totalSize;
  final int totalObjects;
  final int totalExternalSize;
  final List<ClassSummary> classes;

  /// Top classes by retained size.
  List<ClassSummary> get topByRetainedSize =>
      List<ClassSummary>.from(classes)
        ..sort((a, b) => b.retainedSize.compareTo(a.retainedSize));

  /// Top classes by instance count.
  List<ClassSummary> get topByInstanceCount =>
      List<ClassSummary>.from(classes)
        ..sort((a, b) => b.instanceCount.compareTo(a.instanceCount));

  /// Compute diff between this snapshot and an older one.
  HeapSnapshotDiff diff(HeapSnapshotSummary older) {
    final olderMap = <String, ClassSummary>{};
    for (final cls in older.classes) {
      olderMap[cls.className] = cls;
    }

    final classDiffs = <ClassDiff>[];
    final newClasses = <ClassSummary>[];

    for (final cls in classes) {
      final old = olderMap[cls.className];
      if (old == null) {
        newClasses.add(cls);
      } else {
        classDiffs.add(ClassDiff(
          className: cls.className,
          libraryUri: cls.libraryUri,
          instanceDelta: cls.instanceCount - old.instanceCount,
          retainedSizeDelta: cls.retainedSize - old.retainedSize,
          shallowSizeDelta: cls.shallowSize - old.shallowSize,
        ));
      }
    }

    classDiffs.sort(
        (a, b) => b.retainedSizeDelta.compareTo(a.retainedSizeDelta));

    return HeapSnapshotDiff(
      olderTimestamp: older.timestamp,
      newerTimestamp: timestamp,
      totalSizeDelta: totalSize - older.totalSize,
      totalObjectsDelta: totalObjects - older.totalObjects,
      classDiffs: classDiffs,
      newClasses: newClasses,
    );
  }

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'totalSize': totalSize,
        'totalObjects': totalObjects,
        'totalExternalSize': totalExternalSize,
        'classes': classes.map((c) => c.toJson()).toList(),
      };
}

/// Summary of a single class in a heap snapshot.
class ClassSummary {
  ClassSummary({
    required this.className,
    required this.libraryUri,
    required this.instanceCount,
    required this.shallowSize,
    required this.retainedSize,
  });

  factory ClassSummary.fromJson(Map<String, dynamic> json) {
    return ClassSummary(
      className: json['className'] as String,
      libraryUri: json['libraryUri'] as String,
      instanceCount: json['instanceCount'] as int,
      shallowSize: json['shallowSize'] as int,
      retainedSize: json['retainedSize'] as int,
    );
  }

  final String className;
  final String libraryUri;
  final int instanceCount;
  final int shallowSize;
  final int retainedSize;

  Map<String, dynamic> toJson() => {
        'className': className,
        'libraryUri': libraryUri,
        'instanceCount': instanceCount,
        'shallowSize': shallowSize,
        'retainedSize': retainedSize,
      };
}

/// Diff between two heap snapshots.
class HeapSnapshotDiff {
  HeapSnapshotDiff({
    required this.olderTimestamp,
    required this.newerTimestamp,
    required this.totalSizeDelta,
    required this.totalObjectsDelta,
    required this.classDiffs,
    required this.newClasses,
  });

  final DateTime olderTimestamp;
  final DateTime newerTimestamp;
  final int totalSizeDelta;
  final int totalObjectsDelta;
  final List<ClassDiff> classDiffs;
  final List<ClassSummary> newClasses;

  Duration get timeSpan => newerTimestamp.difference(olderTimestamp);

  /// Classes with positive retained size growth, sorted by delta descending.
  List<ClassDiff> get growingClasses =>
      classDiffs.where((d) => d.retainedSizeDelta > 0).toList();

  Map<String, dynamic> toJson() => {
        'olderTimestamp': olderTimestamp.toIso8601String(),
        'newerTimestamp': newerTimestamp.toIso8601String(),
        'totalSizeDelta': totalSizeDelta,
        'totalObjectsDelta': totalObjectsDelta,
        'classDiffs': classDiffs.map((d) => d.toJson()).toList(),
        'newClasses': newClasses.map((c) => c.toJson()).toList(),
      };
}

/// Diff for a single class between two snapshots.
class ClassDiff {
  ClassDiff({
    required this.className,
    required this.libraryUri,
    required this.instanceDelta,
    required this.retainedSizeDelta,
    required this.shallowSizeDelta,
  });

  final String className;
  final String libraryUri;
  final int instanceDelta;
  final int retainedSizeDelta;
  final int shallowSizeDelta;

  Map<String, dynamic> toJson() => {
        'className': className,
        'libraryUri': libraryUri,
        'instanceDelta': instanceDelta,
        'retainedSizeDelta': retainedSizeDelta,
        'shallowSizeDelta': shallowSizeDelta,
      };
}
