/// A time-series memory data point collected from the VM Service.
class MemorySample {
  MemorySample({
    required this.timestamp,
    required this.heapUsage,
    required this.heapCapacity,
    required this.externalUsage,
    this.gcOccurred = false,
  });

  factory MemorySample.fromJson(Map<String, dynamic> json) {
    return MemorySample(
      timestamp: DateTime.parse(json['timestamp'] as String),
      heapUsage: json['heapUsage'] as int,
      heapCapacity: json['heapCapacity'] as int,
      externalUsage: json['externalUsage'] as int,
      gcOccurred: json['gcOccurred'] as bool? ?? false,
    );
  }

  final DateTime timestamp;
  final int heapUsage;
  final int heapCapacity;
  final int externalUsage;
  final bool gcOccurred;

  int get totalUsage => heapUsage + externalUsage;

  double get heapUtilization =>
      heapCapacity > 0 ? heapUsage / heapCapacity : 0.0;

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'heapUsage': heapUsage,
        'heapCapacity': heapCapacity,
        'externalUsage': externalUsage,
        'gcOccurred': gcOccurred,
      };

  @override
  String toString() =>
      'MemorySample(heap: ${_formatBytes(heapUsage)}/${_formatBytes(heapCapacity)}, '
      'ext: ${_formatBytes(externalUsage)}, gc: $gcOccurred)';

  static String _formatBytes(int bytes) {
    if (bytes < 1024) return '${bytes}B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)}KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)}MB';
  }
}
