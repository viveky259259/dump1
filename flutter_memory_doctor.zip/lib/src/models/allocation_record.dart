/// Per-class allocation statistics from AllocationProfile.
class AllocationRecord {
  AllocationRecord({
    required this.timestamp,
    required this.classes,
  });

  factory AllocationRecord.fromJson(Map<String, dynamic> json) {
    return AllocationRecord(
      timestamp: DateTime.parse(json['timestamp'] as String),
      classes: (json['classes'] as List<dynamic>)
          .map((e) =>
              ClassAllocationInfo.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  final DateTime timestamp;
  final List<ClassAllocationInfo> classes;

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'classes': classes.map((c) => c.toJson()).toList(),
      };

  /// Returns classes sorted by instance count descending.
  List<ClassAllocationInfo> get topByInstances =>
      List<ClassAllocationInfo>.from(classes)
        ..sort((a, b) => b.instancesCurrent.compareTo(a.instancesCurrent));

  /// Returns classes sorted by byte size descending.
  List<ClassAllocationInfo> get topBySize =>
      List<ClassAllocationInfo>.from(classes)
        ..sort((a, b) => b.bytesCurrent.compareTo(a.bytesCurrent));
}

/// Allocation info for a single class.
class ClassAllocationInfo {
  ClassAllocationInfo({
    required this.className,
    required this.libraryUri,
    required this.instancesCurrent,
    required this.instancesAccumulated,
    required this.bytesCurrent,
    required this.bytesAccumulated,
  });

  factory ClassAllocationInfo.fromJson(Map<String, dynamic> json) {
    return ClassAllocationInfo(
      className: json['className'] as String,
      libraryUri: json['libraryUri'] as String,
      instancesCurrent: json['instancesCurrent'] as int,
      instancesAccumulated: json['instancesAccumulated'] as int,
      bytesCurrent: json['bytesCurrent'] as int,
      bytesAccumulated: json['bytesAccumulated'] as int,
    );
  }

  final String className;
  final String libraryUri;
  final int instancesCurrent;
  final int instancesAccumulated;
  final int bytesCurrent;
  final int bytesAccumulated;

  Map<String, dynamic> toJson() => {
        'className': className,
        'libraryUri': libraryUri,
        'instancesCurrent': instancesCurrent,
        'instancesAccumulated': instancesAccumulated,
        'bytesCurrent': bytesCurrent,
        'bytesAccumulated': bytesAccumulated,
      };

  @override
  String toString() =>
      'ClassAllocationInfo($className: $instancesCurrent instances, '
      '${bytesCurrent} bytes)';
}
