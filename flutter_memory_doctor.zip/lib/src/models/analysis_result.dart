import 'leak_candidate.dart';

/// Result of memory analysis combining local heuristics and Claude's diagnosis.
class AnalysisResult {
  AnalysisResult({
    required this.timestamp,
    required this.severity,
    required this.summary,
    required this.diagnosis,
    required this.leaks,
    required this.suggestions,
    this.rawResponse,
  });

  factory AnalysisResult.fromJson(Map<String, dynamic> json) {
    return AnalysisResult(
      timestamp: DateTime.parse(json['timestamp'] as String),
      severity: AnalysisSeverity.values.byName(json['severity'] as String),
      summary: json['summary'] as String,
      diagnosis: json['diagnosis'] as String,
      leaks: (json['leaks'] as List<dynamic>)
          .map((e) => LeakCandidate.fromJson(e as Map<String, dynamic>))
          .toList(),
      suggestions: (json['suggestions'] as List<dynamic>).cast<String>(),
      rawResponse: json['rawResponse'] as String?,
    );
  }

  final DateTime timestamp;
  final AnalysisSeverity severity;
  final String summary;
  final String diagnosis;
  final List<LeakCandidate> leaks;
  final List<String> suggestions;
  final String? rawResponse;

  bool get hasLeaks => leaks.isNotEmpty;
  bool get isHealthy => severity == AnalysisSeverity.healthy;

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'severity': severity.name,
        'summary': summary,
        'diagnosis': diagnosis,
        'leaks': leaks.map((l) => l.toJson()).toList(),
        'suggestions': suggestions,
        if (rawResponse != null) 'rawResponse': rawResponse,
      };

  @override
  String toString() => 'AnalysisResult($severity: $summary)';
}

enum AnalysisSeverity {
  healthy,
  info,
  warning,
  critical;

  String get label {
    switch (this) {
      case AnalysisSeverity.healthy:
        return 'Healthy';
      case AnalysisSeverity.info:
        return 'Info';
      case AnalysisSeverity.warning:
        return 'Warning';
      case AnalysisSeverity.critical:
        return 'Critical';
    }
  }

  String get emoji {
    switch (this) {
      case AnalysisSeverity.healthy:
        return 'green';
      case AnalysisSeverity.info:
        return 'blue';
      case AnalysisSeverity.warning:
        return 'orange';
      case AnalysisSeverity.critical:
        return 'red';
    }
  }
}
