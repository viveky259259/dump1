/// A generated code patch for fixing a memory issue.
class FixPatch {
  FixPatch({
    required this.filePath,
    required this.startLine,
    required this.endLine,
    required this.originalCode,
    required this.patchedCode,
    required this.explanation,
    this.leakClassName,
  });

  factory FixPatch.fromJson(Map<String, dynamic> json) {
    return FixPatch(
      filePath: json['filePath'] as String,
      startLine: json['startLine'] as int,
      endLine: json['endLine'] as int,
      originalCode: json['originalCode'] as String,
      patchedCode: json['patchedCode'] as String,
      explanation: json['explanation'] as String,
      leakClassName: json['leakClassName'] as String?,
    );
  }

  final String filePath;
  final int startLine;
  final int endLine;
  final String originalCode;
  final String patchedCode;
  final String explanation;
  final String? leakClassName;

  int get lineCount => endLine - startLine + 1;

  String get diffPreview {
    final buffer = StringBuffer();
    buffer.writeln('--- a/$filePath');
    buffer.writeln('+++ b/$filePath');
    buffer.writeln('@@ -$startLine,${lineCount} @@');
    for (final line in originalCode.split('\n')) {
      buffer.writeln('- $line');
    }
    for (final line in patchedCode.split('\n')) {
      buffer.writeln('+ $line');
    }
    return buffer.toString();
  }

  Map<String, dynamic> toJson() => {
        'filePath': filePath,
        'startLine': startLine,
        'endLine': endLine,
        'originalCode': originalCode,
        'patchedCode': patchedCode,
        'explanation': explanation,
        if (leakClassName != null) 'leakClassName': leakClassName,
      };

  @override
  String toString() =>
      'FixPatch($filePath:$startLine-$endLine: $explanation)';
}
