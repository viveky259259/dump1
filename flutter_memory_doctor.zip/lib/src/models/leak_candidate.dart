/// A potential memory leak with supporting evidence.
class LeakCandidate {
  LeakCandidate({
    required this.className,
    required this.libraryUri,
    required this.growthRate,
    required this.confidence,
    required this.evidence,
    this.instanceGrowthPerSecond = 0.0,
    this.bytesGrowthPerSecond = 0.0,
  });

  factory LeakCandidate.fromJson(Map<String, dynamic> json) {
    return LeakCandidate(
      className: json['className'] as String,
      libraryUri: json['libraryUri'] as String,
      growthRate: (json['growthRate'] as num).toDouble(),
      confidence: (json['confidence'] as num).toDouble(),
      evidence: (json['evidence'] as List<dynamic>).cast<String>(),
      instanceGrowthPerSecond:
          (json['instanceGrowthPerSecond'] as num?)?.toDouble() ?? 0.0,
      bytesGrowthPerSecond:
          (json['bytesGrowthPerSecond'] as num?)?.toDouble() ?? 0.0,
    );
  }

  final String className;
  final String libraryUri;

  /// Normalized growth rate (bytes/second).
  final double growthRate;

  /// Confidence score 0.0–1.0.
  final double confidence;

  /// Human-readable evidence lines.
  final List<String> evidence;

  /// Instance count growth per second.
  final double instanceGrowthPerSecond;

  /// Bytes growth per second.
  final double bytesGrowthPerSecond;

  LeakSeverity get severity {
    if (confidence >= 0.9) return LeakSeverity.critical;
    if (confidence >= 0.7) return LeakSeverity.high;
    if (confidence >= 0.5) return LeakSeverity.medium;
    return LeakSeverity.low;
  }

  Map<String, dynamic> toJson() => {
        'className': className,
        'libraryUri': libraryUri,
        'growthRate': growthRate,
        'confidence': confidence,
        'evidence': evidence,
        'instanceGrowthPerSecond': instanceGrowthPerSecond,
        'bytesGrowthPerSecond': bytesGrowthPerSecond,
        'severity': severity.name,
      };

  @override
  String toString() =>
      'LeakCandidate($className, confidence: ${(confidence * 100).toStringAsFixed(0)}%, '
      'growth: ${growthRate.toStringAsFixed(1)} bytes/s)';
}

enum LeakSeverity {
  low,
  medium,
  high,
  critical;

  String get label {
    switch (this) {
      case LeakSeverity.low:
        return 'Low';
      case LeakSeverity.medium:
        return 'Medium';
      case LeakSeverity.high:
        return 'High';
      case LeakSeverity.critical:
        return 'Critical';
    }
  }
}
